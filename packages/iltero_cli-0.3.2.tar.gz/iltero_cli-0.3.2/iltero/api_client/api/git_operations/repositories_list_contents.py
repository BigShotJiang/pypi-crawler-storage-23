from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_contents_response_schema import APIResponseModelContentsResponseSchema
from ...types import UNSET, Response, Unset


def _get_kwargs(
    repository_id: str,
    *,
    path: str | Unset = "/",
    branch: str | Unset = "main",
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["path"] = path

    params["branch"] = branch

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/git/{repository_id}/contents".format(
            repository_id=quote(str(repository_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelContentsResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelContentsResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelContentsResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    repository_id: str,
    *,
    client: AuthenticatedClient,
    path: str | Unset = "/",
    branch: str | Unset = "main",
) -> Response[APIResponseModelContentsResponseSchema]:
    """List Repository Contents


            List all contents (files and directories) at a repository path.

            Returns both files and subdirectories with metadata for the specified branch.


    Args:
        repository_id (str):
        path (str | Unset): Directory path in repository Default: '/'.
        branch (str | Unset): Branch name Default: 'main'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelContentsResponseSchema]
    """

    kwargs = _get_kwargs(
        repository_id=repository_id,
        path=path,
        branch=branch,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    repository_id: str,
    *,
    client: AuthenticatedClient,
    path: str | Unset = "/",
    branch: str | Unset = "main",
) -> APIResponseModelContentsResponseSchema | None:
    """List Repository Contents


            List all contents (files and directories) at a repository path.

            Returns both files and subdirectories with metadata for the specified branch.


    Args:
        repository_id (str):
        path (str | Unset): Directory path in repository Default: '/'.
        branch (str | Unset): Branch name Default: 'main'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelContentsResponseSchema
    """

    return sync_detailed(
        repository_id=repository_id,
        client=client,
        path=path,
        branch=branch,
    ).parsed


async def asyncio_detailed(
    repository_id: str,
    *,
    client: AuthenticatedClient,
    path: str | Unset = "/",
    branch: str | Unset = "main",
) -> Response[APIResponseModelContentsResponseSchema]:
    """List Repository Contents


            List all contents (files and directories) at a repository path.

            Returns both files and subdirectories with metadata for the specified branch.


    Args:
        repository_id (str):
        path (str | Unset): Directory path in repository Default: '/'.
        branch (str | Unset): Branch name Default: 'main'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelContentsResponseSchema]
    """

    kwargs = _get_kwargs(
        repository_id=repository_id,
        path=path,
        branch=branch,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    repository_id: str,
    *,
    client: AuthenticatedClient,
    path: str | Unset = "/",
    branch: str | Unset = "main",
) -> APIResponseModelContentsResponseSchema | None:
    """List Repository Contents


            List all contents (files and directories) at a repository path.

            Returns both files and subdirectories with metadata for the specified branch.


    Args:
        repository_id (str):
        path (str | Unset): Directory path in repository Default: '/'.
        branch (str | Unset): Branch name Default: 'main'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelContentsResponseSchema
    """

    return (
        await asyncio_detailed(
            repository_id=repository_id,
            client=client,
            path=path,
            branch=branch,
        )
    ).parsed
