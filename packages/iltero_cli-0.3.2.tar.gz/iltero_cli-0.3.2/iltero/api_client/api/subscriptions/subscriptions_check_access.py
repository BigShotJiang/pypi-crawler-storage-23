from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_subscription_entitlement_response_schema import (
    APIResponseModelSubscriptionEntitlementResponseSchema,
)
from ...types import Response


def _get_kwargs(
    bundle_tier: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/subscriptions/check-access/{bundle_tier}".format(
            bundle_tier=quote(str(bundle_tier), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelSubscriptionEntitlementResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelSubscriptionEntitlementResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelSubscriptionEntitlementResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    bundle_tier: str,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelSubscriptionEntitlementResponseSchema]:
    """Check Bundle Access

     Check if organization can access a specific bundle tier.

    Args:
        bundle_tier (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelSubscriptionEntitlementResponseSchema]
    """

    kwargs = _get_kwargs(
        bundle_tier=bundle_tier,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    bundle_tier: str,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelSubscriptionEntitlementResponseSchema | None:
    """Check Bundle Access

     Check if organization can access a specific bundle tier.

    Args:
        bundle_tier (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelSubscriptionEntitlementResponseSchema
    """

    return sync_detailed(
        bundle_tier=bundle_tier,
        client=client,
    ).parsed


async def asyncio_detailed(
    bundle_tier: str,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelSubscriptionEntitlementResponseSchema]:
    """Check Bundle Access

     Check if organization can access a specific bundle tier.

    Args:
        bundle_tier (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelSubscriptionEntitlementResponseSchema]
    """

    kwargs = _get_kwargs(
        bundle_tier=bundle_tier,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    bundle_tier: str,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelSubscriptionEntitlementResponseSchema | None:
    """Check Bundle Access

     Check if organization can access a specific bundle tier.

    Args:
        bundle_tier (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelSubscriptionEntitlementResponseSchema
    """

    return (
        await asyncio_detailed(
            bundle_tier=bundle_tier,
            client=client,
        )
    ).parsed
