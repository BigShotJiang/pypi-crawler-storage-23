from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_phone_verification_send_response import APIResponseModelPhoneVerificationSendResponse
from ...models.phone_update_schema import PhoneUpdateSchema
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: None | PhoneUpdateSchema | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/auth/verification/phone/send-code",
    }

    if isinstance(body, PhoneUpdateSchema):
        _kwargs["json"] = body.to_dict()
    else:
        _kwargs["json"] = body

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelPhoneVerificationSendResponse | None:
    if response.status_code == 200:
        response_200 = APIResponseModelPhoneVerificationSendResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelPhoneVerificationSendResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: None | PhoneUpdateSchema | Unset = UNSET,
) -> Response[APIResponseModelPhoneVerificationSendResponse]:
    """Send phone verification code


            Sends a verification code via SMS to the user's phone number.

            Generates a one-time verification code and sends it to the provided
            or existing phone number. The code expires after a short period.


    Args:
        body (None | PhoneUpdateSchema | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelPhoneVerificationSendResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: None | PhoneUpdateSchema | Unset = UNSET,
) -> APIResponseModelPhoneVerificationSendResponse | None:
    """Send phone verification code


            Sends a verification code via SMS to the user's phone number.

            Generates a one-time verification code and sends it to the provided
            or existing phone number. The code expires after a short period.


    Args:
        body (None | PhoneUpdateSchema | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelPhoneVerificationSendResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: None | PhoneUpdateSchema | Unset = UNSET,
) -> Response[APIResponseModelPhoneVerificationSendResponse]:
    """Send phone verification code


            Sends a verification code via SMS to the user's phone number.

            Generates a one-time verification code and sends it to the provided
            or existing phone number. The code expires after a short period.


    Args:
        body (None | PhoneUpdateSchema | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelPhoneVerificationSendResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: None | PhoneUpdateSchema | Unset = UNSET,
) -> APIResponseModelPhoneVerificationSendResponse | None:
    """Send phone verification code


            Sends a verification code via SMS to the user's phone number.

            Generates a one-time verification code and sends it to the provided
            or existing phone number. The code expires after a short period.


    Args:
        body (None | PhoneUpdateSchema | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelPhoneVerificationSendResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
