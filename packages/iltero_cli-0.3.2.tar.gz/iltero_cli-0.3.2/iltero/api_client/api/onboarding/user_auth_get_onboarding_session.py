from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_onboarding_session_schema import APIResponseModelOnboardingSessionSchema
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/onboarding/session",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelOnboardingSessionSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelOnboardingSessionSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelOnboardingSessionSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelOnboardingSessionSchema]:
    """Get onboarding session


            Retrieves the current onboarding session for the user.

            Returns session details including current step, completed steps,
            and overall progress through the onboarding wizard.


    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelOnboardingSessionSchema]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
) -> APIResponseModelOnboardingSessionSchema | None:
    """Get onboarding session


            Retrieves the current onboarding session for the user.

            Returns session details including current step, completed steps,
            and overall progress through the onboarding wizard.


    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelOnboardingSessionSchema
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelOnboardingSessionSchema]:
    """Get onboarding session


            Retrieves the current onboarding session for the user.

            Returns session details including current step, completed steps,
            and overall progress through the onboarding wizard.


    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelOnboardingSessionSchema]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
) -> APIResponseModelOnboardingSessionSchema | None:
    """Get onboarding session


            Retrieves the current onboarding session for the user.

            Returns session details including current step, completed steps,
            and overall progress through the onboarding wizard.


    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelOnboardingSessionSchema
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
