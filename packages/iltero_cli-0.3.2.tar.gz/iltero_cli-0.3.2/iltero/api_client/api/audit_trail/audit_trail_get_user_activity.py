import datetime
from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_audit_log_user_activity_response import APIResponseModelAuditLogUserActivityResponse
from ...models.audit_category import AuditCategory
from ...types import UNSET, Response, Unset


def _get_kwargs(
    identifier: str,
    *,
    body: list[AuditCategory] | None | Unset = UNSET,
    start_date: datetime.datetime | None | Unset = UNSET,
    end_date: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 100,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.datetime):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.datetime):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/audit/logs/user/{identifier}".format(
            identifier=quote(str(identifier), safe=""),
        ),
        "params": params,
    }

    if isinstance(body, list):
        _kwargs["json"] = []
        for body_type_0_item_data in body:
            body_type_0_item = body_type_0_item_data.value
            _kwargs["json"].append(body_type_0_item)

    else:
        _kwargs["json"] = body

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelAuditLogUserActivityResponse | None:
    if response.status_code == 200:
        response_200 = APIResponseModelAuditLogUserActivityResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelAuditLogUserActivityResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    identifier: str,
    *,
    client: AuthenticatedClient,
    body: list[AuditCategory] | None | Unset = UNSET,
    start_date: datetime.datetime | None | Unset = UNSET,
    end_date: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 100,
) -> Response[APIResponseModelAuditLogUserActivityResponse]:
    """Get user activity audit logs


            Retrieves audit logs for a specific user's activities.

            Returns all actions performed by the user including resource access,
            modifications, and system interactions. Supports filtering by categories
            and date ranges for detailed activity analysis.


    Args:
        identifier (str):
        start_date (datetime.datetime | None | Unset):
        end_date (datetime.datetime | None | Unset):
        limit (int | Unset):  Default: 100.
        body (list[AuditCategory] | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelAuditLogUserActivityResponse]
    """

    kwargs = _get_kwargs(
        identifier=identifier,
        body=body,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    identifier: str,
    *,
    client: AuthenticatedClient,
    body: list[AuditCategory] | None | Unset = UNSET,
    start_date: datetime.datetime | None | Unset = UNSET,
    end_date: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 100,
) -> APIResponseModelAuditLogUserActivityResponse | None:
    """Get user activity audit logs


            Retrieves audit logs for a specific user's activities.

            Returns all actions performed by the user including resource access,
            modifications, and system interactions. Supports filtering by categories
            and date ranges for detailed activity analysis.


    Args:
        identifier (str):
        start_date (datetime.datetime | None | Unset):
        end_date (datetime.datetime | None | Unset):
        limit (int | Unset):  Default: 100.
        body (list[AuditCategory] | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelAuditLogUserActivityResponse
    """

    return sync_detailed(
        identifier=identifier,
        client=client,
        body=body,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    identifier: str,
    *,
    client: AuthenticatedClient,
    body: list[AuditCategory] | None | Unset = UNSET,
    start_date: datetime.datetime | None | Unset = UNSET,
    end_date: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 100,
) -> Response[APIResponseModelAuditLogUserActivityResponse]:
    """Get user activity audit logs


            Retrieves audit logs for a specific user's activities.

            Returns all actions performed by the user including resource access,
            modifications, and system interactions. Supports filtering by categories
            and date ranges for detailed activity analysis.


    Args:
        identifier (str):
        start_date (datetime.datetime | None | Unset):
        end_date (datetime.datetime | None | Unset):
        limit (int | Unset):  Default: 100.
        body (list[AuditCategory] | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelAuditLogUserActivityResponse]
    """

    kwargs = _get_kwargs(
        identifier=identifier,
        body=body,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    identifier: str,
    *,
    client: AuthenticatedClient,
    body: list[AuditCategory] | None | Unset = UNSET,
    start_date: datetime.datetime | None | Unset = UNSET,
    end_date: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 100,
) -> APIResponseModelAuditLogUserActivityResponse | None:
    """Get user activity audit logs


            Retrieves audit logs for a specific user's activities.

            Returns all actions performed by the user including resource access,
            modifications, and system interactions. Supports filtering by categories
            and date ranges for detailed activity analysis.


    Args:
        identifier (str):
        start_date (datetime.datetime | None | Unset):
        end_date (datetime.datetime | None | Unset):
        limit (int | Unset):  Default: 100.
        body (list[AuditCategory] | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelAuditLogUserActivityResponse
    """

    return (
        await asyncio_detailed(
            identifier=identifier,
            client=client,
            body=body,
            start_date=start_date,
            end_date=end_date,
            limit=limit,
        )
    ).parsed
