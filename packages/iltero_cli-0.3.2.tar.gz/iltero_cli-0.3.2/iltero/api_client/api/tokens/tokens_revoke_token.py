from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_token_revoke_response_schema import APIResponseModelTokenRevokeResponseSchema
from ...types import Response


def _get_kwargs(
    token_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/auth/tokens/id/{token_id}".format(
            token_id=quote(str(token_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelTokenRevokeResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelTokenRevokeResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelTokenRevokeResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    token_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelTokenRevokeResponseSchema]:
    """Revoke Token

     Revoke a token by ID.

    Args:
        request: HTTP request
        token_id: Token ID to revoke

    Returns:
        API response indicating revocation status

    Args:
        token_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelTokenRevokeResponseSchema]
    """

    kwargs = _get_kwargs(
        token_id=token_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    token_id: str,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelTokenRevokeResponseSchema | None:
    """Revoke Token

     Revoke a token by ID.

    Args:
        request: HTTP request
        token_id: Token ID to revoke

    Returns:
        API response indicating revocation status

    Args:
        token_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelTokenRevokeResponseSchema
    """

    return sync_detailed(
        token_id=token_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    token_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelTokenRevokeResponseSchema]:
    """Revoke Token

     Revoke a token by ID.

    Args:
        request: HTTP request
        token_id: Token ID to revoke

    Returns:
        API response indicating revocation status

    Args:
        token_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelTokenRevokeResponseSchema]
    """

    kwargs = _get_kwargs(
        token_id=token_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    token_id: str,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelTokenRevokeResponseSchema | None:
    """Revoke Token

     Revoke a token by ID.

    Args:
        request: HTTP request
        token_id: Token ID to revoke

    Returns:
        API response indicating revocation status

    Args:
        token_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelTokenRevokeResponseSchema
    """

    return (
        await asyncio_detailed(
            token_id=token_id,
            client=client,
        )
    ).parsed
