from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_template_bundle_list_response_schema import (
    APIResponseModelTemplateBundleListResponseSchema,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    industry: None | str | Unset = UNSET,
    provider: None | str | Unset = UNSET,
    frameworks: None | str | Unset = UNSET,
    tier: None | str | Unset = UNSET,
    active_only: bool | Unset = True,
    limit: int | Unset = 50,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_industry: None | str | Unset
    if isinstance(industry, Unset):
        json_industry = UNSET
    else:
        json_industry = industry
    params["industry"] = json_industry

    json_provider: None | str | Unset
    if isinstance(provider, Unset):
        json_provider = UNSET
    else:
        json_provider = provider
    params["provider"] = json_provider

    json_frameworks: None | str | Unset
    if isinstance(frameworks, Unset):
        json_frameworks = UNSET
    else:
        json_frameworks = frameworks
    params["frameworks"] = json_frameworks

    json_tier: None | str | Unset
    if isinstance(tier, Unset):
        json_tier = UNSET
    else:
        json_tier = tier
    params["tier"] = json_tier

    params["active_only"] = active_only

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/iac/bundles",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelTemplateBundleListResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelTemplateBundleListResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelTemplateBundleListResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    industry: None | str | Unset = UNSET,
    provider: None | str | Unset = UNSET,
    frameworks: None | str | Unset = UNSET,
    tier: None | str | Unset = UNSET,
    active_only: bool | Unset = True,
    limit: int | Unset = 50,
) -> Response[APIResponseModelTemplateBundleListResponseSchema]:
    """List Template Bundles


            List template bundles with optional filtering.

            Filters: industry, provider, frameworks, tier, active_only.

            Security: Automatically filters bundles based on organization's subscription tier.
            Only returns bundles the organization has access to.


    Args:
        industry (None | str | Unset):
        provider (None | str | Unset):
        frameworks (None | str | Unset):
        tier (None | str | Unset):
        active_only (bool | Unset):  Default: True.
        limit (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelTemplateBundleListResponseSchema]
    """

    kwargs = _get_kwargs(
        industry=industry,
        provider=provider,
        frameworks=frameworks,
        tier=tier,
        active_only=active_only,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    industry: None | str | Unset = UNSET,
    provider: None | str | Unset = UNSET,
    frameworks: None | str | Unset = UNSET,
    tier: None | str | Unset = UNSET,
    active_only: bool | Unset = True,
    limit: int | Unset = 50,
) -> APIResponseModelTemplateBundleListResponseSchema | None:
    """List Template Bundles


            List template bundles with optional filtering.

            Filters: industry, provider, frameworks, tier, active_only.

            Security: Automatically filters bundles based on organization's subscription tier.
            Only returns bundles the organization has access to.


    Args:
        industry (None | str | Unset):
        provider (None | str | Unset):
        frameworks (None | str | Unset):
        tier (None | str | Unset):
        active_only (bool | Unset):  Default: True.
        limit (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelTemplateBundleListResponseSchema
    """

    return sync_detailed(
        client=client,
        industry=industry,
        provider=provider,
        frameworks=frameworks,
        tier=tier,
        active_only=active_only,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    industry: None | str | Unset = UNSET,
    provider: None | str | Unset = UNSET,
    frameworks: None | str | Unset = UNSET,
    tier: None | str | Unset = UNSET,
    active_only: bool | Unset = True,
    limit: int | Unset = 50,
) -> Response[APIResponseModelTemplateBundleListResponseSchema]:
    """List Template Bundles


            List template bundles with optional filtering.

            Filters: industry, provider, frameworks, tier, active_only.

            Security: Automatically filters bundles based on organization's subscription tier.
            Only returns bundles the organization has access to.


    Args:
        industry (None | str | Unset):
        provider (None | str | Unset):
        frameworks (None | str | Unset):
        tier (None | str | Unset):
        active_only (bool | Unset):  Default: True.
        limit (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelTemplateBundleListResponseSchema]
    """

    kwargs = _get_kwargs(
        industry=industry,
        provider=provider,
        frameworks=frameworks,
        tier=tier,
        active_only=active_only,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    industry: None | str | Unset = UNSET,
    provider: None | str | Unset = UNSET,
    frameworks: None | str | Unset = UNSET,
    tier: None | str | Unset = UNSET,
    active_only: bool | Unset = True,
    limit: int | Unset = 50,
) -> APIResponseModelTemplateBundleListResponseSchema | None:
    """List Template Bundles


            List template bundles with optional filtering.

            Filters: industry, provider, frameworks, tier, active_only.

            Security: Automatically filters bundles based on organization's subscription tier.
            Only returns bundles the organization has access to.


    Args:
        industry (None | str | Unset):
        provider (None | str | Unset):
        frameworks (None | str | Unset):
        tier (None | str | Unset):
        active_only (bool | Unset):  Default: True.
        limit (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelTemplateBundleListResponseSchema
    """

    return (
        await asyncio_detailed(
            client=client,
            industry=industry,
            provider=provider,
            frameworks=frameworks,
            tier=tier,
            active_only=active_only,
            limit=limit,
        )
    ).parsed
