from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_scan_response_schema import APIResponseModelScanResponseSchema
from ...types import Response


def _get_kwargs(
    scan_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/compliance/scans/{scan_id}".format(
            scan_id=quote(str(scan_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelScanResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelScanResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelScanResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    scan_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelScanResponseSchema]:
    """Get scan details


            Retrieves detailed information about a specific compliance scan.

            Use this endpoint to check scan status, retrieve results, and access
            violation details. Poll this endpoint to monitor long-running scans.


    Args:
        scan_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelScanResponseSchema]
    """

    kwargs = _get_kwargs(
        scan_id=scan_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    scan_id: str,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelScanResponseSchema | None:
    """Get scan details


            Retrieves detailed information about a specific compliance scan.

            Use this endpoint to check scan status, retrieve results, and access
            violation details. Poll this endpoint to monitor long-running scans.


    Args:
        scan_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelScanResponseSchema
    """

    return sync_detailed(
        scan_id=scan_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    scan_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelScanResponseSchema]:
    """Get scan details


            Retrieves detailed information about a specific compliance scan.

            Use this endpoint to check scan status, retrieve results, and access
            violation details. Poll this endpoint to monitor long-running scans.


    Args:
        scan_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelScanResponseSchema]
    """

    kwargs = _get_kwargs(
        scan_id=scan_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    scan_id: str,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelScanResponseSchema | None:
    """Get scan details


            Retrieves detailed information about a specific compliance scan.

            Use this endpoint to check scan status, retrieve results, and access
            violation details. Poll this endpoint to monitor long-running scans.


    Args:
        scan_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelScanResponseSchema
    """

    return (
        await asyncio_detailed(
            scan_id=scan_id,
            client=client,
        )
    ).parsed
