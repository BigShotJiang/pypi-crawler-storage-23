from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_email_verification_response import APIResponseModelEmailVerificationResponse
from ...models.email_verification_schema import EmailVerificationSchema
from ...types import Response


def _get_kwargs(
    *,
    body: EmailVerificationSchema,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/auth/verify-email",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelEmailVerificationResponse | None:
    if response.status_code == 200:
        response_200 = APIResponseModelEmailVerificationResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelEmailVerificationResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: EmailVerificationSchema,
) -> Response[APIResponseModelEmailVerificationResponse]:
    """Verify user email address


            Verifies a user's email address using the verification token.

            Validates the token sent via email and marks the user's email as
            verified. This is required before the user can access certain features.


    Args:
        body (EmailVerificationSchema): Schema for email verification.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelEmailVerificationResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: EmailVerificationSchema,
) -> APIResponseModelEmailVerificationResponse | None:
    """Verify user email address


            Verifies a user's email address using the verification token.

            Validates the token sent via email and marks the user's email as
            verified. This is required before the user can access certain features.


    Args:
        body (EmailVerificationSchema): Schema for email verification.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelEmailVerificationResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: EmailVerificationSchema,
) -> Response[APIResponseModelEmailVerificationResponse]:
    """Verify user email address


            Verifies a user's email address using the verification token.

            Validates the token sent via email and marks the user's email as
            verified. This is required before the user can access certain features.


    Args:
        body (EmailVerificationSchema): Schema for email verification.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelEmailVerificationResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: EmailVerificationSchema,
) -> APIResponseModelEmailVerificationResponse | None:
    """Verify user email address


            Verifies a user's email address using the verification token.

            Validates the token sent via email and marks the user's email as
            verified. This is required before the user can access certain features.


    Args:
        body (EmailVerificationSchema): Schema for email verification.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelEmailVerificationResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
