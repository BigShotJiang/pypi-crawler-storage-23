from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_check_email_response_schema import APIResponseModelCheckEmailResponseSchema
from ...models.check_email_request_schema import CheckEmailRequestSchema
from ...types import Response


def _get_kwargs(
    *,
    body: CheckEmailRequestSchema,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/auth/check-email",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelCheckEmailResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelCheckEmailResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelCheckEmailResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CheckEmailRequestSchema,
) -> Response[APIResponseModelCheckEmailResponseSchema]:
    """Check email availability and invitations


            Checks if an email address is available for registration and
            whether there are any pending invitations for that email.

            This endpoint should be called before showing the registration form
            to determine if the user should create a new organization or join
            an existing one via invitation.


    Args:
        body (CheckEmailRequestSchema): Schema for check-email request.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelCheckEmailResponseSchema]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CheckEmailRequestSchema,
) -> APIResponseModelCheckEmailResponseSchema | None:
    """Check email availability and invitations


            Checks if an email address is available for registration and
            whether there are any pending invitations for that email.

            This endpoint should be called before showing the registration form
            to determine if the user should create a new organization or join
            an existing one via invitation.


    Args:
        body (CheckEmailRequestSchema): Schema for check-email request.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelCheckEmailResponseSchema
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CheckEmailRequestSchema,
) -> Response[APIResponseModelCheckEmailResponseSchema]:
    """Check email availability and invitations


            Checks if an email address is available for registration and
            whether there are any pending invitations for that email.

            This endpoint should be called before showing the registration form
            to determine if the user should create a new organization or join
            an existing one via invitation.


    Args:
        body (CheckEmailRequestSchema): Schema for check-email request.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelCheckEmailResponseSchema]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CheckEmailRequestSchema,
) -> APIResponseModelCheckEmailResponseSchema | None:
    """Check email availability and invitations


            Checks if an email address is available for registration and
            whether there are any pending invitations for that email.

            This endpoint should be called before showing the registration form
            to determine if the user should create a new organization or join
            an existing one via invitation.


    Args:
        body (CheckEmailRequestSchema): Schema for check-email request.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelCheckEmailResponseSchema
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
