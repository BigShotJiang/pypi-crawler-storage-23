# Resources

In this section we show how to use `QSTN` to conduct large scale persona experiments.

```{toctree}
:maxdepth: 1

german_general_personas
