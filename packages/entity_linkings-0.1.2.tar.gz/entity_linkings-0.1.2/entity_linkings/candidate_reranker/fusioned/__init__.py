from .fusioned import FUSIONED

__all__ = ["FUSIONED"]
