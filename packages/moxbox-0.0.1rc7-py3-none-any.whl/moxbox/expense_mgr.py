import os
import re
import sys
import json
import click
import datetime
from pathlib import Path

# 使用 try-except 載入 openpyxl (延續之前的防呆設計)
try:
    from openpyxl import load_workbook
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False

from moxtools import app_logging, fileMg

log = app_logging.lazy_logger("ExpenseMgr")

# 1. 定義此工具專屬的預設 Config
DEFAULT_CONFIG = {
    "config": {
        "path": "./data_expense_mgr",
        "dry_run": False
    },
    "excel_in": {
        "name_cell": "D6",
        "amount_cell": "P56"
    }
}

# 動態產生 Help Text
HELP_TEXT = f"""
Read information from Excel and auto-renfiles. 
This tool relies entirely on a JSON configuration file.

\b
[JSON Parameter Description]:
* config.path         : (String) Directory path containing the target Excel files.
* config.dry_run      : (Boolean) Set to True to preview renamed files without actually moving them.
* excel_in.name_cell  : (String) The exact cell coordinate for the Name (e.g., "D6").
* excel_in.amount_cell: (String) The exact cell coordinate for the Amount (e.g., "P56").

\b
[Default config.json Template]:
{json.dumps(DEFAULT_CONFIG, indent=4, ensure_ascii=False)}
"""

# 2. 定義此工具的 CLI 命令 (原本在 cli.py 的部份)
@click.command(name="expense-mgr", help=HELP_TEXT)
@click.option('--config', '-c', type=click.Path(exists=True), help="Specify the JSON config file path")
@click.option('--generate-config', is_flag=True, help="Generate a config_expense_template.json in the current directory")
def cmd_expense_mgr(config, generate_config):
    """Command entry point for Expense Manager"""
    
    # 功能 A: 產生範本 (呼叫 MoxTools 共用功能)
    if generate_config:
        out_file = fileMg.generate_json_template(DEFAULT_CONFIG, "config_expense_template.json")
        click.echo(f"Success! Template file created at: {out_file}")
        sys.exit(0)

    # 功能 B: 執行邏輯
    if not config:
        click.echo("Error: Please provide a JSON file path using --config or -c.")
        click.echo("Hint: Run 'mox-box expense-mgr --help' to see the template.")
        sys.exit(1)

    with open(config, 'r', encoding='utf-8') as f:
        cfg_data = json.load(f)

    process_expense_rename(cfg_data)


# 3. 核心處理邏輯
def get_excel_cell_value(file_path, cell_locations):
    # ... 保留原本的邏輯 ...
    results = []
    try:
        wb = load_workbook(file_path, data_only=True, read_only=True)
        ws = wb.active 
        for loc in cell_locations:
            val = ws[loc].value
            results.append(val)
        wb.close()
    except Exception as e:
        log.error(f"Error reading excel {file_path}: {e}")
        return [None] * len(cell_locations)
    return results

def sanitize_filename(name):
    
    if name is None: return "Unknown"
    # 將非英數、底線、中文以外的字元替換為空，避免檔名錯誤
    # Windows 檔名保留字: < > : " / \ | ? *
    return re.sub(r'[\\/*?:"<>|]', "", str(name)).strip()

def process_expense_rename(config_dict: dict):
    # 【防呆】檢查套件
    if not HAS_OPENPYXL:
        log.error("Missing required package 'openpyxl'. Please run: pip install MoxBox[excel]")
        return

    cfg_main = config_dict.get("config", {})
    cfg_excel = config_dict.get("excel_in", {})
    
    input_path = cfg_main.get("path", "./data_expense_mgr")
    dry_run = str(cfg_main.get("dry_run", "False")).lower() == "true"
    
    name_cell = cfg_excel.get("name_cell", "D6")
    amount_cell = cfg_excel.get("amount_cell", "P56")

    target_dir = fileMg.get_folder_from_path(input_path)
    output_folder = fileMg.generate_output_path(target_dir, "results")
    backup_folder = fileMg.generate_output_path(target_dir, "backup")

    files, _ = fileMg.find_files_with_extensions(input_path, [".xlsx"])
    log.info(f"Starting expense processing in: {input_path}")
    
    for file_path in files:
        file_path_obj = Path(file_path)
        name, amount = get_excel_cell_value(file_path, [name_cell, amount_cell])
        
        if name is None or amount is None:
            log.error(f"---> Skipping {file_path_obj.name}: Cannot find Name or Amount in {name_cell} or {amount_cell}")
            continue

        # 4. 產生新檔名: name_amount_datecode.xlsx
        # datecode = mmdd_hhmmss
        # 格式：mmdd_HHMMSSmmmm (後四位微秒)
        now = datetime.datetime.now()
        date_str = now.strftime("%m%d_%H%M%S")
        micro_str = now.strftime("%f")[:2] # 取微秒的前4位
        datecode = f"{date_str}{micro_str}"

        safe_name = sanitize_filename(name)
        safe_amount = sanitize_filename(amount)
        new_filename = f"{safe_name}_{safe_amount}_{datecode}.xlsx"
        
        dest_path = os.path.join(output_folder, new_filename)
        backup_path = os.path.join(backup_folder, file_path_obj.name)
        
        if dry_run:
            log.info(f"[Dry-Run] Would move: {file_path_obj.name} -> {new_filename}")
            continue

        try:
            log.info(f"Processing: {file_path_obj.name} -> {new_filename}")
            fileMg.move_file_force(src=file_path, dest=dest_path, backup=backup_path)
        except Exception as e:
            log.error(f"Failed to move {file_path}: {e}")