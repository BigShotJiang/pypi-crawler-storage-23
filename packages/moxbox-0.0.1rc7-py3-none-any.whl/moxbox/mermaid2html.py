# moxbox/mermaid2html.py
import os
import subprocess
import sys
import shutil
import click

try:
    import markdown
    HAS_MD = True
except ImportError:
    HAS_MD = False

from moxtools import fileMg, app_logging

log = app_logging.lazy_logger("Mermaid2Html")

# ==========================================
# 網頁模板定義 (保留原本的定義)
# ==========================================
# ==========================================
# 網頁模板定義 (Notion 風格)
# ==========================================
PAGE_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{title}</title>
    <style>
        /* Base Notion Style */
        body {{ 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, "Apple Color Emoji", Arial, sans-serif, "Segoe UI Emoji", "Segoe UI Symbol"; 
            max-width: 900px; margin: 0 auto; padding: 40px 20px; line-height: 1.6; color: #37352f; 
        }}
        header, footer {{ 
            display: flex; justify-content: space-between; align-items: center; 
            padding: 10px 0; border-bottom: 1px solid #edece9; margin-bottom: 30px; 
        }}
        footer {{ border-bottom: none; border-top: 1px solid #edece9; margin-top: 50px; padding-top: 20px; }}
        .back-btn {{ text-decoration: none; color: #37352f; font-weight: 500; border: 1px solid #edece9; padding: 6px 16px; border-radius: 4px; background: #fafafa; transition: background 0.1s; }}
        .back-btn:hover {{ background: #e0e0e0; }}
        .title-text {{ font-size: 1.5em; font-weight: 600; }}
        
        /* Markdown Content Styles */
        .content {{ padding: 10px 0; font-size: 16px; }}
        .content h1, .content h2, .content h3, .content h4 {{ font-weight: 600; margin-top: 1.5em; margin-bottom: 0.5em; }}
        .content h1 {{ font-size: 1.875em; }}
        .content h2 {{ font-size: 1.5em; border-bottom: 1px solid #edece9; padding-bottom: 0.3em; }}
        .content h3 {{ font-size: 1.25em; }}
        .content p {{ margin-top: 0; margin-bottom: 1em; }}
        
        /* Links */
        .content a {{ color: inherit; text-decoration: underline; text-decoration-color: #d3d3d3; text-underline-offset: 2px; }}
        .content a:hover {{ text-decoration-color: #37352f; }}
        
        /* Lists */
        .content ul, .content ol {{ padding-left: 20px; margin-top: 0; margin-bottom: 1em; }}
        .content li {{ margin-bottom: 0.3em; }}
        
        /* Inline Code (灰底紅字 - Notion 風格) */
        .content code {{ 
            background: rgba(135, 131, 120, 0.15); /* 淡灰色底 */
            color: #eb5757;                        /* Notion 紅字 */
            padding: 0.2em 0.4em; 
            border-radius: 3px; 
            font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, Courier, monospace; 
            font-size: 0.9em; 
        }}
        
        /* Code Block (程式碼區塊) */
        .content pre {{ 
            background: #f7f6f3; /* Notion 的區塊底色 */
            padding: 16px; 
            border-radius: 4px; 
            overflow-x: auto; 
            margin-top: 0; 
            margin-bottom: 1em; 
        }}
        /* 覆寫 pre 裡面的 code，讓大區塊的 code 變回一般顏色 */
        .content pre code {{ 
            background: transparent; 
            color: #37352f; 
            padding: 0; 
            border-radius: 0; 
            font-size: 0.9em;
        }}
        
        /* Blockquote (引言) */
        .content blockquote {{ 
            border-left: 3px solid #37352f; 
            margin: 0 0 1em 0; 
            padding-left: 14px; 
            color: #787774; 
        }}
        
        /* Table (表格) */
        .content table {{ border-collapse: collapse; width: 100%; margin-bottom: 1em; }}
        .content th, .content td {{ border: 1px solid #edece9; padding: 8px 12px; text-align: left; }}
        .content th {{ background: #f7f6f3; font-weight: 500; }}
    </style>
</head>
<body>
    <header>
        <div class="title-text">{title}</div>
        <a href="index.html" class="back-btn">← Back</a>
    </header>
    <div class="content">
        {body_content}
    </div>
    <footer>
        <a href="index.html" class="back-btn">← Back to Index</a>
    </footer>
</body>
</html>
"""

INDEX_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{index_title}</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif; 
               max-width: 800px; margin: 0 auto; padding: 40px 20px; line-height: 1.6; color: #37352f; }}
        ul {{ list-style: none; padding: 0; margin-bottom: 40px; }}
        li {{ margin-bottom: 10px; padding: 10px; border: 1px solid #edece9; border-radius: 4px; transition: background 0.2s; }}
        li:hover {{ background: #f7f6f3; }}
        a {{ text-decoration: none; color: #37352f; display: block; }}
        .icon {{ margin-right: 10px; font-size: 1.2em; }}
        h2 {{ border-bottom: 2px solid #edece9; padding-bottom: 10px; }}
        h3 {{ color: #555; margin-top: 30px; border-bottom: 1px dashed #edece9; padding-bottom: 5px; }}
    </style>
</head>
<body>
    <h2>📁 {index_title}</h2>
    {md_section}
    {chart_section}
</body>
</html>
"""

# ==========================================
# 請替換 mermaid2html.py 裡的 DEFAULT_CONFIG
# ==========================================
DEFAULT_CONFIG = {
    "config": {
        "input_folder": "./data_mermaid2html",
        "output_folder": "./data_mermaid2html/html_out",
        "index_title": "Project Documentation",
        "doc_titles": {
            "README.md": "README (v0.1)",
            "test.md": "Test MarkDown Document (v0.1)"
        },
        "chart_titles": {
            "ab.mmd": "A to B Flow",
            "cd.mmd": "C to D Flow"
        }
    }
}

# ==========================================
# 請替換 mermaid2html.py 裡的 MermaidConverter 類別
# ==========================================
class MermaidConverter:
    def __init__(self, config_dict):
        self.conf = config_dict
        self.input_folder = self.conf.get("input_folder", "./data_mermaid2html")
        self.output_folder = self.conf.get("output_folder", "./data_mermaid2html/html_out")
        self.index_title = self.conf.get("index_title", "Project Documentation")
        # 取得兩個字典，如果沒設定就給空字典
        self.doc_titles = self.conf.get("doc_titles", {})
        self.chart_titles = self.conf.get("chart_titles", {})
        log.debug(config_dict)
        
    def _prepare_output_dir(self):
        if not os.path.exists(self.output_folder):
            os.makedirs(self.output_folder)
            log.info(f"Created output directory: {self.output_folder}")

    def _check_mmdc(self):
        return shutil.which("mmdc") is not None

    def run(self):
        if not self._check_mmdc():
            err_msg = "Mermaid CLI ('mmdc') is not installed or not in PATH.\nPlease install it via: npm install -g @mermaid-js/mermaid-cli"
            log.error(err_msg)
            raise RuntimeError(err_msg)

        if not os.path.exists(self.input_folder):
            raise FileNotFoundError(f"Input folder not found: {self.input_folder}")

        self._prepare_output_dir()
        
        md_links = []
        chart_links = []

        # 1. 動態處理所有 Markdown (.md) 檔案
        md_files = [f for f in os.listdir(self.input_folder) if f.lower().endswith('.md')]
        for md in md_files:
            md_path = os.path.join(self.input_folder, md)
            base_name = os.path.splitext(md)[0]
            out_name = f"{base_name}.html"
            out_path = os.path.join(self.output_folder, out_name)
            
            # 從 doc_titles 抓取對應的標題，找不到就直接用檔案的 base_name
            display_title = self.doc_titles.get(md, base_name)
            log.info(f"Processing Markdown: {md} -> {display_title}")
            
            try:
                with open(md_path, "r", encoding="utf-8") as f:
                    md_text = f.read()
                    html_body = markdown.markdown(md_text, extensions=['fenced_code', 'tables'])
                
                full_html = PAGE_TEMPLATE.format(title=display_title, body_content=html_body)
                with open(out_path, "w", encoding="utf-8") as f:
                    f.write(full_html)
                    
                md_links.append(f'<li><a href="{out_name}"><span class="icon">📘</span> {display_title}</a></li>')
            except Exception as e:
                log.error(f"Failed to process {md}: {e}")

        # 2. 處理 MMD 檔案
        mmd_files = [f for f in os.listdir(self.input_folder) if f.lower().endswith('.mmd')]
        for mmd in mmd_files:
            base_name = os.path.splitext(mmd)[0]
            mmd_path = os.path.join(self.input_folder, mmd)
            svg_name = f"{base_name}.svg"
            svg_path = os.path.join(self.output_folder, svg_name)
            html_path = os.path.join(self.output_folder, f"{base_name}.html")
            
            display_title = self.chart_titles.get(mmd, base_name)
            log.info(f"Converting diagram: {mmd} -> {display_title} ...")
            
            try:
                subprocess.run(['mmdc', '-i', mmd_path, '-o', svg_path], check=True, shell=True)
                with open(svg_path, 'r', encoding='utf-8') as f:
                    svg_content = f.read()
                
                page_content = PAGE_TEMPLATE.format(title=display_title, body_content=svg_content)
                with open(html_path, 'w', encoding='utf-8') as f:
                    f.write(page_content)
                    
                chart_links.append(f'<li><a href="{base_name}.html"><span class="icon">📊</span> {display_title}</a></li>')
            except subprocess.CalledProcessError as e:
                log.error(f"Failed to convert {mmd}: {e}")

        # 3. 組合並產生 index.html
        if md_links or chart_links:
            log.info("Generating index.html ...")
            md_section = f"<h3>Documentation</h3><ul>{''.join(md_links)}</ul>" if md_links else ""
            chart_section = f"<h3>Flow Charts</h3><ul>{''.join(chart_links)}</ul>" if chart_links else ""
            
            index_content = INDEX_TEMPLATE.format(
                index_title=self.index_title,
                md_section=md_section,
                chart_section=chart_section
            )
            
            index_path = os.path.join(self.output_folder, "index.html")
            with open(index_path, "w", encoding="utf-8") as f:
                f.write(index_content)
            
            return True, f"Successfully generated documentation in: {self.output_folder}/index.html"
        else:
            return False, "No .md or .mmd files were found in the input folder."

# ==========================================
# CLI 指令定義 (Click)
# ==========================================
@click.command(name="mermaid2html", help="Convert .mmd and markdown files into static HTML pages.")
@click.option('--config', '-c', type=click.Path(exists=True), help="Specify the JSON config file path")
@click.option('--generate-config', is_flag=True, help="Generate config_mermaid2html_template.json")
def cmd_mermaid2html(config, generate_config):
    """Command entry point for Mermaid2Html Generator"""
    if not HAS_MD:
        log.error("Missing Python package 'markdown'. Please run: pip install markdown")
        sys.exit(1)

    if generate_config:
        out_file = fileMg.generate_json_template(DEFAULT_CONFIG, "config_mermaid2html_template.json")
        click.echo(f"Success! Template file created at: {out_file}")
        sys.exit(0)

    if not config:
        click.echo("Error: Please provide a JSON file path using --config or -c.")
        click.echo("Hint: Run 'mox-box mermaid2html --generate-config' to get a template.")
        sys.exit(1)

    loaded = fileMg.load_json_file(config, required_keys=["config"])
    if loaded:
        # loaded 是 load_json_file 回傳的 list，取第 0 個作為 config dict

        app = MermaidConverter(loaded[0])
        try:
            success, msg = app.run()
            click.echo(f"\n[{'DONE' if success else 'WARNING'}] {msg}")
        except Exception as e:
            click.echo(f"\n[ERROR] {str(e)}")
            sys.exit(1)

if __name__ == "__main__":
    cmd_mermaid2html()