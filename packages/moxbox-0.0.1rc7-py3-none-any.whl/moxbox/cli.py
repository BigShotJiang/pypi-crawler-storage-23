# moxbox/cli.py
import os
import sys
import subprocess
import click
from moxtools import app_logging

# 1. 引入所有小工具的指令
from .expense_mgr import cmd_expense_mgr
from .img2pdf import cmd_img2pdf  
from .pdf_merge import cmd_pdf_merge
from .mermaid2html import cmd_mermaid2html

# ==========================================
# 定義 GUI 群組與啟動器
# ==========================================
@click.group(help="Launch independent Web GUI for specific tools")
def gui():
    """管理所有 GUI 啟動的指令群組"""
    pass

def launch_streamlit(script_name):
    """通用的 Streamlit 啟動函數"""
    try:
        import streamlit
    except ImportError:
        click.echo("Error: Streamlit is not installed. Please run 'pip install moxbox[ui]'")
        sys.exit(1)

    # 動態取得 web_ui 目錄下的腳本絕對路徑
    current_dir = os.path.dirname(os.path.abspath(__file__))
    app_path = os.path.join(current_dir, "web_ui", script_name)
    
    if not os.path.exists(app_path):
        click.echo(f"Error: GUI script not found at {app_path}")
        sys.exit(1)

    click.echo(f"Starting Web GUI: {script_name} ...")
    
    # --- 新增的部分：傳遞 Debug 狀態給 Streamlit 子行程 ---
    # 複製目前的環境變數
    env = os.environ.copy()
    # 簡單偵測使用者是否有下 --debug 參數
    if "--debug" in sys.argv:
        env["MOXBOX_DEBUG"] = "1"
        click.echo("GUI Debug mode enabled.")
    # --------------------------------------------------------

    # 啟動 Streamlit，並帶入我們修改過的環境變數 (env=env)
    subprocess.run([sys.executable, "-m", "streamlit", "run", app_path], env=env)
# 註冊對應的 GUI 指令 (檔名為 ui_mermaid2html.py)
@gui.command(name="mermaid2html", help="Launch GUI for Mermaid2Html converter")
def gui_mermaid2html():
    launch_streamlit("ui_mermaid2html.py")

# ==========================================
# 主程式註冊
# ==========================================
@click.group()
@click.option('--debug/--no-debug', default=False, help="Enable global debug mode")
def main(debug):
    """MoxBox: Universal Automation Toolkit"""
    # 統一設定全域 Logging
    app_logging.setup_logging("MoxBox", debug=debug, file=None)

# 2. 註冊子指令 (原本的純 CLI 工具)
main.add_command(cmd_expense_mgr)
main.add_command(cmd_img2pdf)
main.add_command(cmd_pdf_merge)
main.add_command(cmd_mermaid2html)

# 3. 註冊 GUI 群組
main.add_command(gui)

if __name__ == '__main__':
    main()