# MoxBox/pdf_merge.py
import os
import sys
import click

# 嘗試載入 pypdf 庫 (防呆機制)
try:
    from pypdf import PdfReader, PdfWriter, PageObject, Transformation, PaperSize
    from pypdf.generic import NameObject, DictionaryObject, StreamObject
    HAS_PDF_LIBS = True
except ImportError:
    HAS_PDF_LIBS = False

# 使用 MoxTools
from moxtools import fileMg, app_logging

# 設定 Logger
log = app_logging.lazy_logger("PdfMerge")

# 定義預設的 Config 範本
DEFAULT_CONFIG = {
    "config": {
        "input_folder": "./data_pdf_merge",
        "output_file": "./data_pdf_merge/merged_report.pdf",
        "layout": {
            "cols": 2,
            "rows": 2,
            "landscape": False
        },
        "page_size": "A4",
        "margin": 20,
        "debug_grid": False
    }
}

class PdfMerger:
    """處理 PDF 合併與排版的應用類別"""
    
    def __init__(self, config_dict):
        self.conf = config_dict
        
        self.input_folder = self.conf.get("input_folder", "./data_pdf_merge")
        self.output_file = self.conf.get("output_file", "./data_pdf_merge/merged_report.pdf")
        
        layout_conf = self.conf.get("layout", {})
        self.cols = layout_conf.get("cols", 2)
        self.rows = layout_conf.get("rows", 1)
        self.is_landscape = layout_conf.get("landscape", False)
        
        self.margin = self.conf.get("margin", 20)
        self.draw_grid = self.conf.get("debug_grid", False)

        # 設定頁面尺寸 (A4)
        a4_w, a4_h = PaperSize.A4
        if self.is_landscape:
            self.page_width = a4_h
            self.page_height = a4_w
        else:
            self.page_width = a4_w
            self.page_height = a4_h
            
        self.writer = PdfWriter()
        log.info(f"[INIT] Layout: {self.cols}x{self.rows}, Landscape={self.is_landscape}")

    def get_file_list(self):
        if fileMg.checkFileOrDir(self.input_folder) != 0:
            log.error(f"Error: Input folder not found: {self.input_folder}")
            return [], []

        pdf_paths, pdf_names = fileMg.find_files_with_extensions(
            in_path=self.input_folder, extensions=["pdf"], recursive=False
        )
        
        if pdf_paths:
            zipped = sorted(zip(pdf_paths, pdf_names), key=lambda x: x[1])
            pdf_paths, pdf_names = zip(*zipped)
            return list(pdf_paths), list(pdf_names)
        return [], []

    def calculate_cell_layout(self):
        usable_w = self.page_width - (2 * self.margin)
        usable_h = self.page_height - (2 * self.margin)
        cell_w = usable_w / self.cols
        cell_h = usable_h / self.rows
        return cell_w, cell_h

    def _create_red_frame_page(self, x, y, w, h):
        """Debug用紅框"""
        page = PageObject.create_blank_page(width=self.page_width, height=self.page_height)
        ops = "q 1 0 0 RG 2 w {:.2f} {:.2f} {:.2f} {:.2f} re S Q".format(x, y, w, h)
        stream = StreamObject()
        stream._data = ops.encode("ascii")
        page[NameObject("/Contents")] = stream
        page[NameObject("/Resources")] = DictionaryObject()
        return page

    def _get_layout_params(self, source_page, target_rect):
        """計算縮放與位移參數"""
        tx, ty, tw, th = target_rect
        
        rot = source_page.get("/Rotate", 0) 
        cb = source_page.cropbox
        x0, y0 = float(cb.left), float(cb.bottom)
        w0, h0 = float(cb.width), float(cb.height)
        
        if rot in [90, 270]:
            src_w, src_h = h0, w0
        else:
            src_w, src_h = w0, h0

        if src_w == 0 or src_h == 0: return None

        # 計算縮放 (Fit)
        scale = min(tw / src_w, th / src_h) * 0.95
        
        # 計算位置 (置中)
        final_w = src_w * scale
        final_h = src_h * scale
        dest_x = tx + (tw - final_w) / 2
        dest_y = ty + (th - final_h) / 2

        return {
            "scale": scale,
            "tx": dest_x,
            "ty": dest_y,
            "rot": rot,
            "x0": x0,
            "y0": y0,
            "src_w": src_w,
            "src_h": src_h  
        }

    def run(self):
        pdf_paths, pdf_names = self.get_file_list()
        if not pdf_paths: 
            log.warning("No PDF files found to merge.")
            return

        cell_w, cell_h = self.calculate_cell_layout()
        current_output_page = None
        item_index = 0
        items_per_page = self.cols * self.rows
        total_pages = 0

        log.info(f"[STEP 1] Processing {len(pdf_paths)} files...")

        for f_path, f_name in zip(pdf_paths, pdf_names):
            try:
                reader = PdfReader(f_path)
                is_first = True

                for source_page in reader.pages:
                    # --- 換頁邏輯 ---
                    if item_index % items_per_page == 0:
                        if current_output_page is not None:
                            self.writer.add_page(current_output_page)
                        
                        current_output_page = PageObject.create_blank_page(
                            width=self.page_width, height=self.page_height
                        )
                        item_index = 0

                    # --- 計算位置 ---
                    col = item_index % self.cols
                    row = item_index // self.cols
                    x_pos = self.margin + (col * cell_w)
                    y_pos = self.page_height - self.margin - ((row + 1) * cell_h)
                    
                    # --- 計算參數 ---
                    params = self._get_layout_params(source_page, (x_pos, y_pos, cell_w, cell_h))
                    
                    if params:
                        # 建構變形矩陣
                        op = Transformation().translate(tx=-params['x0'], ty=-params['y0'])
                        rot = params['rot']
                        if rot == 90:
                            op = op.rotate(-90).translate(tx=0, ty=params['src_w'])
                        elif rot == 180:
                            op = op.rotate(-180).translate(tx=params['src_w'], ty=params['src_h'])
                        elif rot == 270:
                            op = op.rotate(-270).translate(tx=params['src_h'], ty=0)
                            
                        op = op.scale(sx=params['scale'], sy=params['scale']).translate(tx=params['tx'], ty=params['ty'])
                        
                        current_output_page.merge_transformed_page(
                            source_page, op, expand=False
                        )
                        
                        log.debug(f"    Pg{total_pages}: {f_name} | Sc={params['scale']:.2f} | Loc=({params['tx']:.1f},{params['ty']:.1f})")
                    
                    # --- 繪製紅框 ---
                    if self.draw_grid:
                        grid_page = self._create_red_frame_page(x_pos, y_pos, cell_w, cell_h)
                        current_output_page.merge_page(grid_page)

                    # --- 目錄索引 ---
                    if is_first:
                        self.writer.add_outline_item(title=f_name, page_number=current_output_page)
                        is_first = False
                    
                    item_index += 1
                    total_pages += 1

            except Exception as e:
                log.error(f"Failed {f_name}: {e}")

        if current_output_page is not None:
            self.writer.add_page(current_output_page)

        self._save_file()

    def _save_file(self):
        output_dir = os.path.dirname(self.output_file)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)

        try:
            with open(self.output_file, "wb") as out_f:
                self.writer.write(out_f)
            log.info(f"[DONE] Successfully saved merged report: {self.output_file}")
            click.echo(f"Success: {self.output_file}")
        except Exception as e:
            log.error(f"Save failed: {e}")

# ==========================================
# CLI 指令定義 (Click)
# ==========================================
@click.command(name="pdf-merge", help="Merge multiple PDF files into a single layout report.")
@click.option('--config', '-c', type=click.Path(exists=True), help="Specify the JSON config file path")
@click.option('--generate-config', is_flag=True, help="Generate a config_pdf_merge_template.json in the current directory")
def cmd_pdf_merge(config, generate_config):
    """Command entry point for PDF Merge Tool"""
    
    # 檢查相依套件
    if not HAS_PDF_LIBS:
        log.error("Missing required packages for PDF processing.")
        log.error("Please reinstall with the correct dependencies or run: pip install pypdf")
        sys.exit(1)

    # 處理產生設定檔的指令
    if generate_config:
        out_file = fileMg.generate_json_template(DEFAULT_CONFIG, "config_pdf_merge_template.json")
        click.echo(f"Success! Template file created at: {out_file}")
        sys.exit(0)

    # 檢查是否提供設定檔
    if not config:
        click.echo("Error: Please provide a JSON file path using --config or -c.")
        click.echo("Hint: Run 'moxbox pdf-merge --generate-config' to get a template.")
        sys.exit(1)

    # 使用 MoxTools 的 fileMg 讀取 JSON
    loaded = fileMg.load_json_file(config, required_keys=["config"])
    if loaded:
        # load_json_file 會回傳 List，所以取 [0] 並且取出內層的 "config" 字典傳給 Class
        app = PdfMerger(loaded[0])
        app.run()

if __name__ == "__main__":
    # 若被單獨執行，也可以透過此入口測試
    cmd_pdf_merge()