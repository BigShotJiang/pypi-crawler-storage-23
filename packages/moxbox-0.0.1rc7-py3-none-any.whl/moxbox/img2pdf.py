import os
import math
import json
import sys
import click

# 嘗試載入 PDF 與影像處理相關套件 (防呆機制)
try:
    from fpdf import FPDF
    from PIL import Image
    HAS_PDF_LIBS = True
except ImportError:
    HAS_PDF_LIBS = False
    FPDF = object  # <--- 加入這行！當找不到 FPDF 時，用 Python 原生的 object 頂替，這樣底下繼承就不會報錯了！

from moxtools import app_logging, fileMg, parseTools

log = app_logging.lazy_logger("Img2Pdf")

# 1. 定義預設的 Config 範本
DEFAULT_CONFIG = {
    "config": {
        "image_folder": "./data_img2pdf",
        "file_prefix": "Result",
        "output_file": "test.pdf",
        "page_height": 297,
        "top_margin": 10,
        "bottom_margin": 5,
        "title_buffer": 25,
        "row_gap": 10
    },
    "main_page": {
        "title_of_report": "Chamer PreScan",
        "dut_inform": "atMCU + SC1240",
        "environment": "chamber + corner reflector",
        "user_title_1":  "Radar Setting",
        "user_content_1": "2000_2200_256_59_RX14_RX23",
        "user_title_2":  "Offset Index",
        "user_content_2": "80",
        "user_title_3":  "Remove DC",
        "user_content_3": "0",
        "user_title_4":  "Guard Cell",
        "user_content_4": "20"
    },
    "groups": [
        {
            "name": "Group 0: 1st Experiment (Result by Metric)",
            "pattern": "g8_Peak_60dB",
            "experiments_per_page": 2,
            "cols_per_row": 2
        }
    ]
}

# 動態產生 Help Text (使用 \b 保留換行)
HELP_TEXT = f"""
Generate a PDF report from multiple images based on a JSON configuration.

\b
[JSON Parameter Description]:
* config.image_folder : (String) The folder containing the images.
* config.output_file  : (String) The name of the output PDF file.
* main_page           : (Dict) Key-value pairs displayed on the first TOC page.
* groups              : (List) Define layout and matching patterns for image groups.

\b
[Default config.json Template]:
{json.dumps(DEFAULT_CONFIG, indent=4, ensure_ascii=False)}
"""

# ==========================================
# 核心邏輯類別 (沿用並微調原本的 LabReport.py)
# ==========================================
class LabReport(FPDF):
    def header(self):
        if self.page_no() > 1:
            self.set_font("helvetica", "B", 10)
            self.set_text_color(150)
            self.cell(0, 10, f"Lab Report - Page {self.page_no()}", align="R")
            self.ln(10)

class ReportGenerator:
    def __init__(self, config, main_page, user_groups):
        self.conf = config
        self.main_page = main_page
        self.groups_def = user_groups
        self.pdf = LabReport()
        self.pdf.set_auto_page_break(auto=False)
        self.pdf.set_margins(15, self.conf.get("top_margin", 15), 15)
        self.links = {}

        page_h = self.conf.get("page_height", 297)
        top_m = self.conf.get("top_margin", 15)
        btm_m = self.conf.get("bottom_margin", 15)

        self.total_usable_h = page_h - top_m - btm_m
        log.info(f"[INIT] Total usable height: {self.total_usable_h:.1f}mm")

    def get_max_ratio_from_images(self, images):
        if not images:
            return 0.75
        max_r = 0
        for img_data in images:
            img_path = img_data['path']
            try:
                with Image.open(img_path) as img:
                    w_px, h_px = img.size
                    if w_px > 0:
                        r = h_px / w_px
                        if r > max_r:
                            max_r = r
            except Exception as e:
                log.warning(f"Cannot read image ratio for {img_path}: {e}")
                continue
        return max_r if max_r > 0 else 0.75

    def calculate_layout_size(self, num_rows, standard_cell_w, max_ratio, budget_height):
        title_buffer = self.conf.get('title_buffer', 25)
        row_gap = self.conf.get('row_gap', 10)
        img_budget_h_total = budget_height - title_buffer
        
        if num_rows == 0: return standard_cell_w, 0
        max_allowed_h_per_row = (img_budget_h_total / num_rows) - row_gap
        calc_h = standard_cell_w * max_ratio
        
        if calc_h > max_allowed_h_per_row:
            final_cell_h = max_allowed_h_per_row
            final_cell_w = final_cell_h / max_ratio
        else:
            final_cell_h = calc_h
            final_cell_w = standard_cell_w
            
        return final_cell_w, final_cell_h

    def parse_files(self):
        img_folder = self.conf.get("image_folder", ".")
        log.info(f"Scanning files in {img_folder}...")

        if fileMg.checkFileOrDir(img_folder) != 0:
            log.error(f"Error: Image folder not found: {img_folder}")
            return {}

        target_extensions = ["png", "jpg", "jpeg", "bmp"]
        image_paths, image_names = fileMg.find_files_with_extensions(in_path=img_folder, extensions=target_extensions, recursive=False)
        log.info(f"Total images found: {len(image_paths)}")

        parsed_data = {}
        prefix_setting = self.conf.get("file_prefix", "")

        for g_def in self.groups_def:
            group_name = g_def["name"]
            pattern_str = g_def.get("pattern", "")
            if not pattern_str.strip():
                continue

            parsed_data[group_name] = []
            log.info(f"Matching for Group: {group_name} (Pattern: {pattern_str})")

            for fp, fn in zip(image_paths, image_names):
                matched, caption = parseTools.parseFn_pattern(fn, pattern_str, fn_prefix=prefix_setting)
                if matched:
                    parsed_data[group_name].append({"path": fp, "caption": caption})
            log.info(f"  -> Matched {len(parsed_data[group_name])} images.")

        return parsed_data

    def add_toc(self, data):
        title_of_report = self.main_page.get("title_of_report", "Lab Report")
        self.pdf.add_page()
        self.pdf.set_font("helvetica", "B", 20)
        self.pdf.cell(0, 20, f"{title_of_report}", ln=True, align="C")

        self.pdf.set_font("helvetica", "B", 10)
        self.pdf.set_text_color(0)
        label_w = 35
        label_h = 4
        indent_x = 18
        info_list = []

        if self.main_page.get("dut_inform"):
            info_list.append(("DUT", self.main_page.get("dut_inform")))
        if self.main_page.get("environment"):
            info_list.append(("ENVIRONMENT", self.main_page.get("environment")))

        for i in range(1, 11):
            u_title = self.main_page.get(f"user_title_{i}")
            u_content = self.main_page.get(f"user_content_{i}")
            if u_title and u_content:
                info_list.append((u_title, u_content))            

        for label, content in info_list:
            self.pdf.set_x(indent_x)
            self.pdf.cell(label_w, label_h, label.strip(), ln=0, align="L")
            self.pdf.cell(0, label_h, f":   {content}", ln=True, align="L")
         
        self.pdf.ln(10)
        self.pdf.set_font("helvetica", "U", 12)
        self.pdf.set_text_color(0, 0, 255)

        for i, group in enumerate(data.keys()):
            link_id = self.pdf.add_link()
            self.links[group] = link_id
            self.pdf.cell(0, 10, f"{i+1}. {group}", ln=True, link=link_id)
        self.pdf.set_text_color(0)

    def generate(self):
        data = self.parse_files()
        if not data:
            log.warning("No data found matching patterns. Aborting.")
            return

        self.add_toc(data)
        group_conf_map = {g['name']: g for g in self.groups_def}
        
        page_h = self.conf.get("page_height", 297)
        top_m = self.conf.get("top_margin", 15)
        btm_m = self.conf.get("bottom_margin", 15)
        page_w = 210
        margin_lr = 15
        available_w = page_w - (margin_lr * 2)
        gutter = 5
        row_gap = self.conf.get("row_gap", 10)

        if self.pdf.page_no() == 0:
            self.pdf.add_page()

        for group_name, images in data.items():
            if not images:
                continue
            log.info(f"Processing layout: {group_name}")

            g_conf = group_conf_map.get(group_name, {})
            g_exp_per_page = g_conf.get('experiments_per_page', 1)
            g_cols = g_conf.get('cols_per_row', 1)
            
            current_budget_h = self.total_usable_h / g_exp_per_page
            current_cell_w = (available_w - (g_cols - 1) * gutter) / g_cols
            num_rows = math.ceil(len(images) / g_cols)
            max_ratio = self.get_max_ratio_from_images(images)

            final_cell_w, final_cell_h = self.calculate_layout_size(num_rows, current_cell_w, max_ratio, current_budget_h)

            current_y = self.pdf.get_y()
            bottom_limit = page_h - btm_m
            
            if (current_y + current_budget_h) > bottom_limit:
                self.pdf.add_page()
            else:
                if current_y > (top_m + 10): 
                    separator_y = current_y + 5
                    self.pdf.set_draw_color(200)
                    self.pdf.line(margin_lr, separator_y, page_w - margin_lr, separator_y)
                    self.pdf.set_y(separator_y + 5)

            start_y = self.pdf.get_y()
            if group_name in self.links:
                self.pdf.set_link(self.links[group_name], y=start_y, page=self.pdf.page_no())

            self.pdf.set_font("helvetica", "B", 14)
            self.pdf.set_text_color(0, 51, 102)
            self.pdf.cell(0, 8, f"{group_name}", ln=True)
            self.pdf.ln(1)

            img_batches = [images[i : i + g_cols] for i in range(0, len(images), g_cols)]
            row_start_y = self.pdf.get_y()

            for batch in img_batches:
                for i, img_data in enumerate(batch):
                    x_pos = margin_lr + i * (final_cell_w + gutter)
                    self.pdf.image(img_data["path"], x=x_pos, y=row_start_y, w=final_cell_w, h=final_cell_h)
                    caption_y = row_start_y + final_cell_h + 1
                    self.pdf.set_xy(x_pos, caption_y)
                    self.pdf.set_font("helvetica", "B", 8)
                    self.pdf.set_text_color(0)
                    self.pdf.multi_cell(final_cell_w, 4, f"Figure {i+1}:  {img_data['caption']}", align="C")
                row_start_y += final_cell_h + row_gap

        output_fn = self.conf.get("output_file", "report.pdf")
        img_folder = self.conf.get("image_folder", ".")
        output_path = os.path.join(img_folder, output_fn)
        self.pdf.output(output_path)
        log.info(f"Success! Custom Report Generated: {output_path}")

# ==========================================
# CLI 指令定義
# ==========================================
@click.command(name="img2pdf", help=HELP_TEXT)
@click.option('--config', '-c', type=click.Path(exists=True), help="Specify the JSON config file path")
@click.option('--generate-config', is_flag=True, help="Generate a config_img2pdf_template.json in the current directory")
def cmd_img2pdf(config, generate_config):
    """Command entry point for Img2Pdf Generator"""
    
    # 檢查相依套件
    if not HAS_PDF_LIBS:
        log.error("Missing required packages for PDF generation.")
        log.error("Please reinstall with the PDF feature enabled:")
        log.error("--> pip install MoxBox[pdf]")
        sys.exit(1)

    if generate_config:
        out_file = fileMg.generate_json_template(DEFAULT_CONFIG, "config_img2pdf_template.json")
        click.echo(f"Success! Template file created at: {out_file}")
        sys.exit(0)

    if not config:
        click.echo("Error: Please provide a JSON file path using --config or -c.")
        click.echo("Hint: Run 'mox-box img2pdf --help' to see the template.")
        sys.exit(1)

    # 讀取 JSON 並執行
    with open(config, 'r', encoding='utf-8') as f:
        cfg_data = json.load(f)

    # 檢查必要 Key 是否存在
    config_dict = cfg_data.get("config")
    main_page = cfg_data.get("main_page")
    user_groups = cfg_data.get("groups")

    if not all([config_dict, main_page, user_groups]):
        log.error("Invalid configuration format. Missing 'config', 'main_page', or 'groups'.")
        sys.exit(1)

    app = ReportGenerator(config_dict, main_page, user_groups)
    app.generate()