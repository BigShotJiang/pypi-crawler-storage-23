import streamlit as st
import json
import os
import sys
import webbrowser
import glob

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from moxbox.mermaid2html import MermaidConverter, DEFAULT_CONFIG
from moxtools import app_logging

is_debug = os.environ.get("MOXBOX_DEBUG") == "1"
app_logging.setup_logging("MoxBoxGUI", debug=is_debug, file=None)
log = app_logging.lazy_logger("MoxBoxGUI")

DEFAULT_CONFIG_FILE = "config_mermaid2html_template.json"
CUSTOM_DEFAULT_FILE = "config_mermaid2html.json"

# ==========================================
# --- Session State 初始化與單向綁定邏輯 ---
# ==========================================
# 1. 預設系統啟動時載入的設定檔
if 'active_config' not in st.session_state:
    st.session_state['active_config'] = CUSTOM_DEFAULT_FILE

# 2. 紀錄使用者從 text_input 手動輸入過的路徑歷史
if 'custom_paths' not in st.session_state:
    st.session_state['custom_paths'] = []

# 3. 確保 text_input 初始值為預設的 config_mermaid2html.json
if 'custom_path_input' not in st.session_state:
    st.session_state['custom_path_input'] = CUSTOM_DEFAULT_FILE

# ❌ 移除了強制讓 Selectbox 初始等於 CUSTOM_DEFAULT_FILE 的邏輯

# Callback 1: 當改變下拉選單時 -> 只切換設定檔，【不要】改動 text_input
def update_from_dropdown():
    val = st.session_state['dropdown_select']
    st.session_state['active_config'] = val
    # st.session_state['custom_path_input'] = val  <-- 移除這行，保持 specific path 不變

# Callback 2: 當改變 text_input (按下 Enter) 時 -> 切換設定檔，並加入到下拉選單中
def update_from_text():
    val = st.session_state['custom_path_input'].strip()
    if val:
        st.session_state['active_config'] = val
        # 只有在手動輸入過後，才把它加入歷史紀錄 (Selectbox)
        if val not in st.session_state['custom_paths']:
            st.session_state['custom_paths'].append(val)
        # 同步讓下拉選單也選中這個剛輸入的路徑
        st.session_state['dropdown_select'] = val
    else:
        # 防呆：如果清空文字框，恢復成目前的設定
        st.session_state['custom_path_input'] = st.session_state['active_config']
# ==========================================

def load_config(file_path):
    if os.path.exists(file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError:
            st.warning(f"Config file {file_path} format error, using default empty settings.")
    return {"config": {}}

def save_config(config_data, file_path):
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(config_data, f, indent=4, ensure_ascii=False)

def dict_to_table_data(d):
    if not d:
        return [{"Filename": "", "Title": ""}]
    return [{"Filename": k, "Title": v} for k, v in d.items()]

def table_data_to_dict(lst):
    res = {}
    for item in lst:
        k = str(item.get("Filename", "")).strip()
        v = str(item.get("Title", "")).strip()
        if k:
            res[k] = v
    return res

st.set_page_config(page_title="Mermaid2Html GUI", page_icon="📊", layout="wide")

if st.session_state.get('show_template_toast'):
    st.toast(f"✅ Template generated at {DEFAULT_CONFIG_FILE}", icon="✨")
    st.session_state['show_template_toast'] = False

st.title("📊 Mermaid & Markdown to HTML Converter")
st.markdown("Modify the parameters below and click execute. Settings will be automatically saved to the JSON file.")

# ==========================================
# 1. Configuration Management (設定檔管理區)
# ==========================================
st.subheader("⚙️ Configuration Management")
col_cfg1, col_cfg2 = st.columns([3, 1])

with col_cfg1:
    # 掃描目錄下的檔案，只加入實際存在的檔案和 user 手動輸入過的紀錄
    json_files = glob.glob("*.json")
    # if DEFAULT_CONFIG_FILE not in json_files:
    #     json_files.append(DEFAULT_CONFIG_FILE)
        
    # 組合選項：實際檔案 + 歷史紀錄 (不強制加入 config_mermaid2html.json)
    base_options = json_files + st.session_state['custom_paths']
    final_options = sorted(list(set(base_options)))

    st.selectbox(
        "📂 Select Config File (History & Directory)", 
        options=final_options,
        key="dropdown_select",
        on_change=update_from_dropdown
    )
    
    st.text_input(
        "Or enter specific file path (Press Enter to apply):", 
        key="custom_path_input",
        on_change=update_from_text
    )
    
    st.caption(f"✅ **Currently Loaded Config:** `{st.session_state['active_config']}`")

with col_cfg2:
    st.markdown("<div style='margin-top: 28px;'></div>", unsafe_allow_html=True) 
    
    if st.button("📄 Generate Template", type="secondary", width="stretch"):
        save_config(DEFAULT_CONFIG, DEFAULT_CONFIG_FILE)
        log.info(f"Template successfully generated at: {DEFAULT_CONFIG_FILE}")
        st.session_state['show_template_toast'] = True
        st.rerun()

# 讀取「目前啟用」的設定檔
config_file_path = st.session_state['active_config']
config_data = load_config(config_file_path)
cfg = config_data.get("config", {})
# ==========================================

st.divider()

# 2. Path Settings (Top Row)
col1, col2 = st.columns(2)
with col1:
    st.subheader("📁 Path Settings")
    input_folder = st.text_input("Input Folder", value=cfg.get("input_folder", "./data_mermaid2html"))
    output_folder = st.text_input("Output Folder", value=cfg.get("output_folder", "./data_mermaid2html/html_out"))
    
with col2:
    st.subheader("📄 Index Settings")
    index_title = st.text_input("Index Page Title", value=cfg.get("index_title", "Project Documentation"))

st.divider()

# 3. Dynamic Tables Mapping (Bottom Row)
col_doc, col_chart = st.columns(2)

with col_doc:
    st.subheader("📘 Document Titles")
    st.caption("Click the bottom empty row to add a new file. Select a row and press Delete to remove it.")
    doc_data = dict_to_table_data(cfg.get("doc_titles", {}))
    edited_docs = st.data_editor(
        doc_data,
        column_config={
            "Filename": st.column_config.TextColumn("File Name (e.g., abc.md)", required=True),
            "Title": st.column_config.TextColumn("Display Title", required=True),
        },
        num_rows="dynamic",
        width="stretch",
        key="doc_editor"
    )

with col_chart:
    st.subheader("📊 Chart Titles")
    st.caption("Click the bottom empty row to add a new file. Select a row and press Delete to remove it.")
    chart_data = dict_to_table_data(cfg.get("chart_titles", {}))
    edited_charts = st.data_editor(
        chart_data,
        column_config={
            "Filename": st.column_config.TextColumn("File Name (e.g., flow.mmd)", required=True),
            "Title": st.column_config.TextColumn("Display Title", required=True),
        },
        num_rows="dynamic",
        width="stretch",
        key="chart_editor"
    )

st.divider()

# 4. Execution Logic
if st.button("🚀 Save Settings and Start Conversion", type="primary", width="stretch"):
    try:
        doc_titles = table_data_to_dict(edited_docs)
        chart_titles = table_data_to_dict(edited_charts)
        
        cfg["input_folder"] = input_folder
        cfg["output_folder"] = output_folder
        cfg["index_title"] = index_title
        cfg["doc_titles"] = doc_titles
        cfg["chart_titles"] = chart_titles
        
        cfg.pop("process_readme", None)
        cfg.pop("readme_filename", None)

        config_data["config"] = cfg

        save_config(config_data, config_file_path)
        log.info(f"Settings successfully saved to: {config_file_path}")
        st.toast(f"✅ Settings saved to {config_file_path}!", icon="💾")

        with st.spinner("Processing files, please wait..."):
            app = MermaidConverter(cfg)
            success, msg = app.run()
            
            if success:
                st.success(f"🎉 Conversion Successful!\n\nDetails: `{msg}`")
                st.balloons()
                
                index_abs_path = os.path.abspath(os.path.join(output_folder, "index.html"))
                st.session_state['generated_index'] = index_abs_path
            else:
                st.warning(f"⚠️ {msg}")
                st.session_state['generated_index'] = None

    except Exception as e:
        st.error(f"❌ Error occurred during execution:\n\n`{str(e)}`")

# 5. --- 顯示「打開 index.html」的按鈕區塊 ---
if st.session_state.get('generated_index'):
    st.divider()
    with st.container():
        target_path = st.session_state['generated_index']
        st.info(f"📂 Output is ready at:\n`{target_path}`", icon="💡")
        
        col_space1, col_btn, col_space2 = st.columns([1, 2, 1])
        with col_btn:
            if st.button("🌐 Open `index.html` in Browser", width="stretch"):
                webbrowser.open(f"file://{target_path}")