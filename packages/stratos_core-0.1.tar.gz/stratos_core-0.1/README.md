# Stratos

Stratos is a multi-agent autonomous coding system designed for the terminal. It orchestrates specialized AI agents to generate, modify, and execute code based on high-level specifications. By leveraging Google Gemini, Stratos bridges the gap between natural language requirements and functional software prototypes.

## System Overview

The system operates as a command-line utility that spawns specialized AI agents. These agents work within a controlled sandbox to perform software engineering tasks, including:

*   **Requirement Analysis**: Transforming brief user requests into detailed technical specifications.
*   **Code Generation**: Writing functional Python code efficiently.
*   **Execution & Validation**: Running code within a safety wrapper and analyzing outputs.
*   **Iterative Refinement**: Self-correcting based on execution logs and error streams.

## Core Capabilities

### Autonomous Agent Team
Stratos employs a multi-agent architecture (Manager, Architect, Coder, Reviewer) where distinct roles handle specific aspects of the development lifecycle.

### Security Sandbox
To mitigate the risks associated with executing AI-generated code, Stratos implements a strict sandbox layer. This layer intercepts system calls and validates commands against a safety policy.

### Premium Terminal Dashboard
The interface is built for high-density information display, providing real-time visibility into the agent's thought process, the active task queue, and the raw execution logs.

## Installation

### Prerequisites
*   Python 3.10 or higher
*   A Google Gemini API key

### Setup Steps

1.  **Clone the repository**
    ```bash
    git clone https://github.com/SPTApyo/stratos.git
    cd stratos
    ```

2.  **Run the Global Installer**
    Stratos includes a professional installer to set up the system globally or locally.
    ```bash
    chmod +x install.sh
    ./install.sh
    ```

## Configuration

Stratos requires a Google Gemini API key. Upon first launch, the system will prompt you to enter your key securely. It will be saved in a local `.env` file.

## Usage

Once installed, you can launch Stratos from anywhere:

```bash
stratos
```

### Command Line Options
*   `-p NAME`: Directly launch a specific project.
*   `-d TEXT`: Provide project description via CLI.
*   `--quick`: Quick launch MVP mode (shortcut for `-p *`).
*   `--theme NAME`: Override UI theme.
*   `--debug`: Enable technical tracing.

## Disclaimer

**Experimental Software**: Stratos is an autonomous assistant that executes code on your local machine. Use with caution. The authors are not responsible for any data loss or system instability.

## License

This software is distributed under the MIT License.

Copyright (c) 2026 SPTApyo
