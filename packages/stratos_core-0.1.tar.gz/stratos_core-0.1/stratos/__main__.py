from stratos.cli import main_entry

if __name__ == "__main__":
    main_entry()
