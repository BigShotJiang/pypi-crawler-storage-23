"""Tests for cuvis_ai.training module."""
