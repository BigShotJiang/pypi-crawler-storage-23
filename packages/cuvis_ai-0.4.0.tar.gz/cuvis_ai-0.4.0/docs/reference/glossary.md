!!! warning "Status: Needs Review"
    This page has not been reviewed for accuracy and completeness. Content may be outdated or contain errors.

---

# Glossary

> **Status:** Under Development (Phase 6)
> **Expected Completion:** Week 6

## Coming Soon

Comprehensive glossary of terms used in CUVIS.AI including:
- Node
- Port
- Pipeline
- TrainRun
- Phase (training)
- Stage (execution)
- And more...

---

**Related Pages:**
- [Core Concepts Overview](../concepts/overview.md)
