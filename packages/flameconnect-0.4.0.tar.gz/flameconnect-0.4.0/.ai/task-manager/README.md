# AI Task Manager

This directory contains AI-assisted task management files for this project.

Managed by the [AI Task Manager](https://www.github.com/e0ipso/ai-task-manager) project.

**Documentation**: https://mateuaguilo.com/ai-task-manager
