"""Textual TUI for FlameConnect."""

from __future__ import annotations

from flameconnect.tui.app import run_tui

__all__ = ["run_tui"]
