from flameconnect.cli import main

main()
