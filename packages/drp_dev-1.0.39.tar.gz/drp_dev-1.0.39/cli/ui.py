"""
CLI UI helpers — spinners and progress bars.

    from cli.ui import spinner, download_progress, upload_progress

    with spinner("Fetching..."):
        resp = api_get("/api/v1/keys/abc/")

    download_progress(response, dest_path, filename="photo.jpg")
"""

from __future__ import annotations

import os
import sys
from contextlib import contextmanager
from typing import IO, Iterator

from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)


_console = Console(stderr=True)


# ── Spinner ───────────────────────────────────────────────────────────────────

@contextmanager
def spinner(message: str = "Working...") -> Iterator[None]:
    """Show an animated spinner while a block runs.

    Automatically disabled when stdout is not a TTY (piped / CI).

        with spinner("Uploading..."):
            resp = api_post(...)
    """
    if not sys.stderr.isatty():
        yield
        return
    with _console.status(f"  {message}", spinner="dots") as _status:
        yield


# ── Progress bars ─────────────────────────────────────────────────────────────

def _make_progress() -> Progress:
    """Create a standard download/upload progress bar."""
    return Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]{task.description}"),
        BarColumn(bar_width=30),
        DownloadColumn(),
        TransferSpeedColumn(),
        TimeRemainingColumn(),
        console=_console,
        transient=True,
    )


def download_to_file(
    response,
    dest: str,
    *,
    filename: str = "",
    chunk_size: int = 8192,
) -> int:
    """Stream *response* to *dest* with a progress bar.

    Returns the number of bytes written.
    """
    total = int(response.headers.get("content-length", 0))
    label = filename or os.path.basename(dest)

    if not sys.stderr.isatty() or total == 0:
        # No TTY or unknown size — silent download
        written = 0
        with open(dest, "wb") as f:
            for chunk in response.iter_content(chunk_size):
                f.write(chunk)
                written += len(chunk)
        return written

    with _make_progress() as progress:
        task = progress.add_task(label, total=total)
        with open(dest, "wb") as f:
            for chunk in response.iter_content(chunk_size):
                f.write(chunk)
                progress.advance(task, len(chunk))

    return total


def download_to_buffer(
    response,
    *,
    label: str = "downloading",
    chunk_size: int = 8192,
) -> bytes:
    """Stream *response* into memory with a progress bar.

    Returns the full content as bytes.
    """
    total = int(response.headers.get("content-length", 0))

    if not sys.stderr.isatty() or total == 0:
        return response.content

    chunks: list[bytes] = []
    with _make_progress() as progress:
        task = progress.add_task(label, total=total)
        for chunk in response.iter_content(chunk_size):
            chunks.append(chunk)
            progress.advance(task, len(chunk))

    return b"".join(chunks)


def upload_file(
    api_post_fn,
    url: str,
    path: str,
    *,
    field: str = "file",
    filename: str = "",
    extra_data: dict | None = None,
) -> "requests.Response":
    """Upload *path* with a progress bar via multipart POST.

    Uses a wrapper around the file to track read progress.

    Returns the requests.Response.
    """
    import requests
    from cli.session import _session, api_url

    fname = filename or os.path.basename(path)
    file_size = os.path.getsize(path)

    if not sys.stderr.isatty() or file_size == 0:
        # Fallback — plain upload
        with open(path, "rb") as f:
            return api_post_fn(
                url,
                files={field: (fname, f)},
                data=extra_data or {},
            )

    # Wrap the file object to track progress
    with _make_progress() as progress:
        task = progress.add_task(fname, total=file_size)

        with open(path, "rb") as raw:
            wrapper = _ProgressFileWrapper(raw, progress, task)
            s, _ = _session()
            resp = s.post(
                api_url(url),
                files={field: (fname, wrapper)},
                data=extra_data or {},
            )

    return resp


class _ProgressFileWrapper:
    """File-like wrapper that advances a rich progress bar on read()."""

    def __init__(self, fp: IO[bytes], progress: Progress, task_id) -> None:
        self._fp = fp
        self._progress = progress
        self._task_id = task_id

    def read(self, size: int = -1) -> bytes:
        data = self._fp.read(size)
        if data:
            self._progress.advance(self._task_id, len(data))
        return data

    def seek(self, *args, **kwargs):
        return self._fp.seek(*args, **kwargs)

    def tell(self) -> int:
        return self._fp.tell()

    def __len__(self) -> int:
        pos = self._fp.tell()
        self._fp.seek(0, 2)
        size = self._fp.tell()
        self._fp.seek(pos)
        return size
