"""logout — Revoke the current bearer token and clear local config."""

from . import Command, register

cmd = register(Command(
    name="logout",
    description="Revoke the current bearer token on the server and clear local config.",
))


def run(shell, args_str):
    """Revoke current bearer token and clear local config."""
    from cli.session import api_post, clear_session, is_logged_in
    from cli import config

    if not config.is_setup():
        shell.poutput("not set up — run 'drp setup' to get started")
        return
    if not is_logged_in():
        shell.poutput("not logged in")
        return

    from cli.ui import spinner
    with spinner("Logging out..."):
        resp = api_post("/api/v1/auth/logout/")
    if resp.status_code == 200:
        shell.poutput("logged out")
    else:
        shell.poutput("server logout failed — clearing local session anyway")

    clear_session()
    shell.username = ""
    shell._update_prompt()
