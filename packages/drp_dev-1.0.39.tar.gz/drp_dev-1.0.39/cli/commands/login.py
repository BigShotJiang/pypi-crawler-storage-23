"""login — Authenticate interactively."""

from . import Command, register

cmd = register(Command(
    name="login",
    description="Authenticate interactively. Prompts for username and password.",
))


def run(shell, args_str):
    """Authenticate interactively."""
    import getpass
    from cli.session import api_post, save_session

    shell.poutput("drp login")
    try:
        username = input("  Username or email: ").strip()
        password = getpass.getpass("  Password: ")
    except (EOFError, KeyboardInterrupt):
        shell.poutput("")
        return

    if not username or not password:
        shell.poutput("  username and password required")
        return

    from cli.ui import spinner
    with spinner("Authenticating..."):
        resp = api_post("/api/v1/auth/login/", json={
            "username": username, "password": password,
        })
    if resp.status_code != 200:
        msg = resp.json().get("error", "login failed")
        shell.poutput(f"  error: {msg}")
        return

    data = resp.json()
    save_session(data["token"], data.get("username", ""), data.get("email", ""))
    shell.username = data.get("username", "")
    shell._update_prompt()
    shell.poutput(f"  logged in as {data['username']} ({data.get('plan', 'free')})")
