"""ping — Check connectivity and print round-trip latency."""

from . import Command, register

cmd = register(Command(
    name="ping",
    description="Check connectivity to the server and print round-trip latency.",
))


def run(shell, args_str):
    """Check server connectivity."""
    import time
    from cli.session import api_get

    from cli.ui import spinner
    try:
        t0 = time.monotonic()
        with spinner("Pinging server..."):
            resp = api_get("/api/v1/ping/")
        dt = (time.monotonic() - t0) * 1000
        if resp.status_code == 200:
            shell.poutput(f"pong — {dt:.0f} ms")
        else:
            shell.poutput(f"server returned {resp.status_code}")
    except Exception as e:
        shell.poutput(f"connection failed: {e}")
