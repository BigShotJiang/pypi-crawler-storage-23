from .blesta_cli import cli

__all__ = ["cli"]
