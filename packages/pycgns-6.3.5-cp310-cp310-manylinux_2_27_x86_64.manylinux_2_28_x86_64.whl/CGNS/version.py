
version = "6.3.5"
__version__ = version
full_version = version

git_revision = "89f130c6371280475f084056950b9ffba4e2aa46"
release = 'dev' not in version and '+' not in version
short_version = version.split("+")[0]
