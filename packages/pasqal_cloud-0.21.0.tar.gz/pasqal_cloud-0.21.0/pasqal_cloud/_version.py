__version__ = '0.21.0'
deprecation_date = '2027-02-26'
