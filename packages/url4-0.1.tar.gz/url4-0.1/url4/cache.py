"""
Local response cache for url4.

Caches model API responses keyed by hash(model + prompt + params).
SQLite-backed, zero infrastructure, works standalone in the SDK.

Cache levels:
  - "user": your own calls only (default, always available)
  - "off": skip cache entirely

System-wide cache (shared across users) requires a remote cache service
(caching.url4.ai) — not implemented in local mode.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path

# Default cache location
DEFAULT_CACHE_DIR = Path.home() / ".url4" / "cache"
DEFAULT_DB_PATH = DEFAULT_CACHE_DIR / "responses.db"
DEFAULT_TTL = 86400  # 24 hours

SCHEMA = """
CREATE TABLE IF NOT EXISTS responses (
    cache_key TEXT PRIMARY KEY,
    model TEXT NOT NULL,
    prompt_hash TEXT NOT NULL,
    response_json TEXT NOT NULL,
    created_at REAL NOT NULL,
    ttl INTEGER NOT NULL,
    size_bytes INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_responses_model ON responses(model);
CREATE INDEX IF NOT EXISTS idx_responses_created ON responses(created_at);
"""


@dataclass
class CacheEntry:
    """A cached model response."""

    cache_key: str
    model: str
    response: dict
    created_at: float
    ttl: int
    size_bytes: int

    @property
    def age_seconds(self) -> float:
        return time.time() - self.created_at

    @property
    def expired(self) -> bool:
        return self.age_seconds > self.ttl


@dataclass
class CacheStats:
    """Cache statistics."""

    total_entries: int
    total_bytes: int
    hits: int
    misses: int
    hit_rate: float


class ResponseCache:
    """Local SQLite response cache for url4 model calls."""

    def __init__(self, db_path: Path | str | None = None, default_ttl: int = DEFAULT_TTL):
        self.db_path = Path(db_path) if db_path else DEFAULT_DB_PATH
        self.default_ttl = default_ttl
        self._hits = 0
        self._misses = 0
        self._db: sqlite3.Connection | None = None

    def _get_db(self) -> sqlite3.Connection:
        if self._db is None:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            self._db = sqlite3.connect(str(self.db_path))
            self._db.row_factory = sqlite3.Row
            self._db.executescript(SCHEMA)
        return self._db

    @staticmethod
    def make_key(model: str, prompt: str, params: dict | None = None) -> str:
        """Create a deterministic cache key from model + prompt + params.

        This is the core cache identity: same model, same prompt, same params
        = same key = same cached response.
        """
        parts = {
            "model": model,
            "prompt": prompt,
            "params": params or {},
        }
        raw = json.dumps(parts, sort_keys=True, ensure_ascii=True)
        return hashlib.sha256(raw.encode()).hexdigest()

    def get(self, model: str, prompt: str, params: dict | None = None) -> CacheEntry | None:
        """Look up a cached response. Returns None on miss or expiry."""
        key = self.make_key(model, prompt, params)
        db = self._get_db()
        row = db.execute(
            "SELECT * FROM responses WHERE cache_key = ?", (key,)
        ).fetchone()

        if row is None:
            self._misses += 1
            return None

        entry = CacheEntry(
            cache_key=row["cache_key"],
            model=row["model"],
            response=json.loads(row["response_json"]),
            created_at=row["created_at"],
            ttl=row["ttl"],
            size_bytes=row["size_bytes"],
        )

        if entry.expired:
            # Clean up expired entry
            db.execute("DELETE FROM responses WHERE cache_key = ?", (key,))
            db.commit()
            self._misses += 1
            return None

        self._hits += 1
        return entry

    def put(
        self,
        model: str,
        prompt: str,
        response: dict,
        params: dict | None = None,
        ttl: int | None = None,
    ) -> str:
        """Store a response in the cache. Returns the cache key."""
        key = self.make_key(model, prompt, params)
        response_json = json.dumps(response, ensure_ascii=False)
        db = self._get_db()
        db.execute(
            """INSERT OR REPLACE INTO responses
               (cache_key, model, prompt_hash, response_json, created_at, ttl, size_bytes)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                key,
                model,
                hashlib.sha256(prompt.encode()).hexdigest()[:16],
                response_json,
                time.time(),
                ttl or self.default_ttl,
                len(response_json.encode()),
            ),
        )
        db.commit()
        return key

    def delete(self, model: str, prompt: str, params: dict | None = None) -> bool:
        """Delete a cached entry. Returns True if something was deleted."""
        key = self.make_key(model, prompt, params)
        db = self._get_db()
        cursor = db.execute("DELETE FROM responses WHERE cache_key = ?", (key,))
        db.commit()
        return cursor.rowcount > 0

    def clear(self) -> int:
        """Clear all cached entries. Returns count of entries deleted."""
        db = self._get_db()
        cursor = db.execute("SELECT COUNT(*) as cnt FROM responses")
        count = cursor.fetchone()["cnt"]
        db.execute("DELETE FROM responses")
        db.commit()
        return count

    def cleanup_expired(self) -> int:
        """Remove all expired entries. Returns count removed."""
        db = self._get_db()
        now = time.time()
        cursor = db.execute(
            "DELETE FROM responses WHERE (? - created_at) > ttl", (now,)
        )
        db.commit()
        return cursor.rowcount

    def stats(self) -> CacheStats:
        """Get cache statistics."""
        db = self._get_db()
        row = db.execute(
            "SELECT COUNT(*) as cnt, COALESCE(SUM(size_bytes), 0) as total FROM responses"
        ).fetchone()
        total = self._hits + self._misses
        return CacheStats(
            total_entries=row["cnt"],
            total_bytes=row["total"],
            hits=self._hits,
            misses=self._misses,
            hit_rate=self._hits / total if total > 0 else 0.0,
        )

    def close(self):
        """Close the database connection."""
        if self._db:
            self._db.close()
            self._db = None


# Module-level default cache instance
_default_cache: ResponseCache | None = None


def get_cache(db_path: Path | str | None = None) -> ResponseCache:
    """Get or create the default cache instance."""
    global _default_cache
    if _default_cache is None:
        _default_cache = ResponseCache(db_path=db_path)
    return _default_cache
