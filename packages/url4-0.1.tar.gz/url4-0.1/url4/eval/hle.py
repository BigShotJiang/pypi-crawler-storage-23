"""HLE benchmark loader for url4 eval harness.

Loads the Humanity's Last Exam dataset from HuggingFace,
filtering to text-only questions.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class HLEQuestion:
    """A single HLE benchmark question."""

    id: str
    question: str
    answer: str
    answer_type: str
    category: str


def load_hle(sample: int | None = None, seed: int = 42) -> list[HLEQuestion]:
    """Load HLE text-only questions from HuggingFace.

    Args:
        sample: If set, randomly sample this many questions.
        seed: Random seed for reproducible sampling.

    Returns:
        List of HLEQuestion objects.
    """
    from datasets import load_dataset

    ds = load_dataset("cais/hle", split="test")

    questions = []
    for row in ds:
        # Skip multimodal questions (those with images)
        if row.get("image") is not None:
            continue
        questions.append(HLEQuestion(
            id=row["id"],
            question=row["question"],
            answer=row["answer"],
            answer_type=row.get("answer_type", "exactMatch"),
            category=row.get("category", ""),
        ))

    if sample and sample < len(questions):
        import random
        rng = random.Random(seed)
        questions = rng.sample(questions, sample)

    return questions
