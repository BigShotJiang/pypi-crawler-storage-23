"""Import existing benchmark results into the url4 cache.

Reads hle_*.json files from the benchmark directory and stores
each model's response in the url4 cache, keyed by (model_id, question).

This lets you re-use expensive model calls when iterating on
council configurations.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from url4.cache import get_cache, ResponseCache


# Map filenames to model IDs that the registry would resolve
_FILENAME_TO_MODEL: dict[str, str] = {
    "hle_claude-opus-4-5.json": "claude-opus-4-20250514",
    "hle_claude-opus-4-6-thinking-max.json": "claude-opus-4-6-20250623",
    "hle_claude-sonnet-4-5.json": "claude-sonnet-4-5-20250514",
    "hle_claude-sonnet-4-6.json": "claude-sonnet-4-6-20250514",
    "hle_claude-haiku-4-5-20251001.json": "claude-haiku-4-5-20251001",
    "hle_gpt-5-pro-2025-10-06.json": "gpt-5-pro-2025-10-06",
    "hle_gemini-3-pro-preview.json": "gemini-3-pro-preview",
    "hle_gemini-3.1-pro-preview.json": "gemini-3.1-pro-preview",
    "hle_kimi-k2.5.json": "kimi-k2.5",
    "hle_opus.json": "claude-opus-4-20250514",
}


def import_benchmark_cache(
    benchmark_dir: str | Path,
    cache: ResponseCache | None = None,
    questions_map: dict[str, str] | None = None,
) -> dict[str, int]:
    """Import benchmark results into url4 cache.

    Args:
        benchmark_dir: Path to directory with hle_*.json files.
        cache: Cache to import into. None = default cache.
        questions_map: Optional dict mapping question_id → question_text.
            If not provided, tries to load from HuggingFace dataset.

    Returns:
        Dict mapping filename → number of entries imported.
    """
    benchmark_dir = Path(benchmark_dir)
    if cache is None:
        cache = get_cache()

    # Build question ID → text mapping
    if questions_map is None:
        questions_map = _load_question_map()

    stats: dict[str, int] = {}

    for json_path in sorted(benchmark_dir.glob("hle_*.json")):
        filename = json_path.name
        model_id = _FILENAME_TO_MODEL.get(filename)
        if not model_id:
            # Try to extract model from filename: hle_MODEL.json
            model_id = filename.removeprefix("hle_").removesuffix(".json")

        try:
            with open(json_path) as f:
                data = json.load(f)
        except json.JSONDecodeError:
            # Some files have corruption — try loading with error recovery
            data = _load_json_partial(json_path)
            if not data:
                print(f"  Skipping {filename} (JSON decode error)", file=sys.stderr)
                continue

        imported = 0
        for qid, entry in data.items():
            response = entry.get("response", "")
            if not response:
                continue

            # Get the question text
            question = entry.get("question") or questions_map.get(qid, "")
            if not question:
                continue

            # Store in cache
            usage = entry.get("usage", {})
            if isinstance(usage, dict) and "usage" in usage:
                inner = usage["usage"]
                tokens_in = inner.get("input_tokens", 0) or inner.get("prompt_tokens", 0)
                tokens_out = inner.get("output_tokens", 0) or inner.get("completion_tokens", 0)
            elif isinstance(usage, dict):
                tokens_in = usage.get("input_tokens", 0) or usage.get("prompt_tokens", 0)
                tokens_out = usage.get("output_tokens", 0) or usage.get("completion_tokens", 0)
            else:
                tokens_in = 0
                tokens_out = 0

            cache.put(model_id, question, {
                "response": response,
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
                "provider": "benchmark-import",
                "model_id": model_id,
            })
            imported += 1

        stats[filename] = imported

    return stats


def _load_question_map() -> dict[str, str]:
    """Load question ID → text mapping from HuggingFace."""
    try:
        from datasets import load_dataset
        ds = load_dataset("cais/hle", split="test")
        return {row["id"]: row["question"] for row in ds}
    except Exception:
        return {}


def _load_json_partial(path: Path) -> dict | None:
    """Try to load a JSON file that may have corruption at the end."""
    text = path.read_text()
    try:
        data = json.loads(text)
        return data
    except json.JSONDecodeError as e:
        # Truncate at the last complete entry before the error
        last_good = text.rfind("},", 0, e.pos)
        if last_good > 0:
            try:
                return json.loads(text[:last_good + 1] + "}")
            except json.JSONDecodeError:
                pass
    return None
