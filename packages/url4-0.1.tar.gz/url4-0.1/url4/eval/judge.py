"""Judge module — determines if a model response is correct.

Uses an LLM judge (default: o3-mini via OpenRouter) to compare
the model's response against the ground-truth answer.
"""

from __future__ import annotations

import json
from dataclasses import dataclass

from url4.adapters.registry import resolve_adapter

DEFAULT_JUDGE_MODEL = "o3-mini"

JUDGE_PROMPT = """Judge whether the following [response] to [question] is correct or not based on the precise and unambiguous [correct_answer] below.

[question]: {question}

[response]: {response}

Your judgement must be in the format and criteria specified below:

extracted_final_answer: The final exact answer extracted from the [response]. Put the extracted answer as 'None' if there is no exact, final answer to extract from the response.

[correct_answer]: {correct_answer}

reasoning: Explain why the extracted_final_answer is correct or incorrect based on [correct_answer], focusing only on if there are meaningful differences between [correct_answer] and the extracted_final_answer. Do not comment on any background to the problem, do not attempt to solve the problem, do not argue for any answer different than [correct_answer], focus only on whether the answers match.

correct: Answer 'yes' if extracted_final_answer matches the [correct_answer] given above, or is within a small margin of error for numerical problems. Answer 'no' otherwise.

Respond ONLY with valid JSON in this exact format:
{{"extracted_final_answer": "...", "reasoning": "...", "correct": "yes or no"}}"""


@dataclass
class JudgeResult:
    """Result of judging a model response."""

    correct: bool
    model_answer: str
    reasoning: str


async def judge_response(
    question: str,
    response: str,
    correct_answer: str,
    judge_model: str = DEFAULT_JUDGE_MODEL,
) -> JudgeResult:
    """Judge whether a response correctly answers a question.

    Args:
        question: The original question.
        response: The model's response to judge.
        correct_answer: The ground-truth answer.
        judge_model: Model to use as judge.

    Returns:
        JudgeResult with correctness verdict.
    """
    prompt = JUDGE_PROMPT.format(
        question=question,
        response=response,
        correct_answer=correct_answer,
    )

    adapter, model_id = resolve_adapter(judge_model)
    result = await adapter.query(model_id, prompt)

    # Parse JSON response
    try:
        # Try to extract JSON from the response
        text = result.response.strip()
        # Handle markdown code blocks
        if text.startswith("```"):
            text = text.split("\n", 1)[1].rsplit("```", 1)[0].strip()
        parsed = json.loads(text)
        return JudgeResult(
            correct=parsed.get("correct", "no").lower() == "yes",
            model_answer=parsed.get("extracted_final_answer", ""),
            reasoning=parsed.get("reasoning", ""),
        )
    except (json.JSONDecodeError, AttributeError):
        # If parsing fails, try to find yes/no in the response
        lower = result.response.lower()
        return JudgeResult(
            correct="correct: yes" in lower or '"correct": "yes"' in lower,
            model_answer="",
            reasoning=f"Failed to parse judge response: {result.response[:200]}",
        )
