"""Eval harness — run a council against a benchmark and report accuracy.

Runs each question through the council, judges the response,
and tracks progress with a running accuracy display.
"""

from __future__ import annotations

import asyncio
import sys
import time
from dataclasses import dataclass, field

from url4.council import Council
from url4.eval.hle import HLEQuestion, load_hle
from url4.eval.judge import judge_response, JudgeResult


@dataclass
class EvalResult:
    """Result of running an eval."""

    total: int = 0
    correct: int = 0
    errors: int = 0
    results: list[dict] = field(default_factory=list)

    @property
    def accuracy(self) -> float:
        if self.total == 0:
            return 0.0
        return self.correct / self.total

    @property
    def accuracy_pct(self) -> str:
        return f"{self.accuracy * 100:.1f}%"


async def run_eval(
    council: Council,
    questions: list[HLEQuestion],
    judge_model: str = "o3-mini",
    concurrency: int = 5,
    on_progress: callable | None = None,
) -> EvalResult:
    """Run a council against a list of questions and judge the results.

    Args:
        council: The council to evaluate.
        questions: List of benchmark questions.
        judge_model: Model to use for judging (default: o3-mini).
        concurrency: Max concurrent questions to process.
        on_progress: Optional callback(completed, total, correct, question_id).

    Returns:
        EvalResult with accuracy and per-question breakdown.
    """
    result = EvalResult()
    semaphore = asyncio.Semaphore(concurrency)

    async def process_question(q: HLEQuestion) -> dict:
        async with semaphore:
            entry = {
                "id": q.id,
                "question": q.question[:100],
                "correct_answer": q.answer,
            }

            try:
                # Ask the council
                synth = await council.ask(q.question)
                entry["response"] = synth.response
                entry["cost"] = synth.total_cost

                # Judge the response
                verdict = await judge_response(
                    question=q.question,
                    response=synth.response,
                    correct_answer=q.answer,
                    judge_model=judge_model,
                )
                entry["correct"] = verdict.correct
                entry["model_answer"] = verdict.model_answer
                entry["reasoning"] = verdict.reasoning

            except Exception as e:
                entry["response"] = ""
                entry["correct"] = False
                entry["error"] = str(e)
                result.errors += 1

            # Update totals
            result.total += 1
            if entry.get("correct"):
                result.correct += 1
            result.results.append(entry)

            if on_progress:
                on_progress(result.total, len(questions), result.correct, q.id)

            return entry

    # Run all questions with concurrency limit
    tasks = [process_question(q) for q in questions]
    await asyncio.gather(*tasks)

    return result


def print_progress(completed: int, total: int, correct: int, question_id: str):
    """Default progress printer for terminal output."""
    acc = correct / completed * 100 if completed > 0 else 0
    sys.stderr.write(
        f"\r{completed}/{total} complete, {acc:.1f}% accuracy ({correct} correct)  "
    )
    sys.stderr.flush()
    if completed == total:
        sys.stderr.write("\n")
