"""Cost estimation for url4 ensembles.

Estimates cost without executing queries. Checks cache status
to show potential savings.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from url4.parser import parse, Spec, Source
from url4.adapters.registry import resolve, estimate_cost
from url4.cache import ResponseCache, get_cache


# Rough token estimate: ~4 chars per token (good enough for estimates)
CHARS_PER_TOKEN = 4

# Default output tokens estimate per model call
DEFAULT_OUTPUT_TOKENS = 500


def _estimate_tokens(text: str) -> int:
    """Rough token count from text length."""
    return max(1, len(text) // CHARS_PER_TOKEN)


@dataclass
class SourceEstimate:
    """Cost estimate for a single source."""

    source: str
    provider: str
    model_id: str
    weight: float | None
    estimated_input_tokens: int
    estimated_output_tokens: int
    estimated_cost: float
    cached: bool


@dataclass
class CostEstimate:
    """Full cost estimate for an ensemble query."""

    sources: list[SourceEstimate] = field(default_factory=list)
    """Per-source estimates."""

    synthesis_estimate: SourceEstimate | None = None
    """Estimate for the synthesis step."""

    @property
    def total_cost(self) -> float:
        """Total estimated cost (excluding cached sources)."""
        cost = sum(s.estimated_cost for s in self.sources if not s.cached)
        if self.synthesis_estimate and not self.synthesis_estimate.cached:
            cost += self.synthesis_estimate.estimated_cost
        return cost

    @property
    def full_cost(self) -> float:
        """Cost if nothing were cached."""
        cost = sum(s.estimated_cost for s in self.sources)
        if self.synthesis_estimate:
            cost += self.synthesis_estimate.estimated_cost
        return cost

    @property
    def savings(self) -> float:
        """Savings from cached sources."""
        return self.full_cost - self.total_cost

    @property
    def cached_count(self) -> int:
        return sum(1 for s in self.sources if s.cached)

    @property
    def total_count(self) -> int:
        return len(self.sources)


def estimate_query(
    spec: Spec,
    prompt: str,
    reduce_model: str = "claude-haiku",
    cache: ResponseCache | None = None,
) -> CostEstimate:
    """Estimate cost of a url4 query without executing it.

    Checks cache for each source to determine which would be hits.
    Uses registry pricing data and rough token estimates.

    Args:
        spec: Parsed url4 spec.
        prompt: The prompt that would be sent.
        reduce_model: Model for synthesis step.
        cache: Cache to check for hits. None = use default.

    Returns:
        CostEstimate with per-source breakdown and totals.
    """
    if cache is None:
        cache = get_cache()

    input_tokens = _estimate_tokens(prompt)
    source_estimates = []

    for source in spec.sources:
        if source.nested:
            # For nested specs, rough estimate: sum of inner sources
            inner_est = estimate_query(source.nested, source.nested.prompt or prompt, reduce_model, cache)
            source_estimates.append(SourceEstimate(
                source=f"[nested: {len(source.nested.sources)} sources]",
                provider="nested",
                model_id="",
                weight=source.weight,
                estimated_input_tokens=sum(s.estimated_input_tokens for s in inner_est.sources),
                estimated_output_tokens=sum(s.estimated_output_tokens for s in inner_est.sources),
                estimated_cost=inner_est.total_cost,
                cached=False,
            ))
            continue

        model_name = source.url or ""
        provider_name, model_id, config = resolve(model_name)

        # Check cache
        is_cached = False
        entry = cache.get(model_id, prompt)
        if entry:
            is_cached = True

        # Estimate cost
        cost = estimate_cost(model_name, input_tokens, DEFAULT_OUTPUT_TOKENS)

        source_estimates.append(SourceEstimate(
            source=model_name,
            provider=provider_name,
            model_id=model_id,
            weight=source.weight,
            estimated_input_tokens=input_tokens,
            estimated_output_tokens=DEFAULT_OUTPUT_TOKENS,
            estimated_cost=cost,
            cached=is_cached,
        ))

    # Synthesis estimate (if >1 source)
    synthesis_est = None
    if len(source_estimates) > 1:
        # Synthesis prompt includes all source responses
        synth_input = input_tokens + (DEFAULT_OUTPUT_TOKENS * len(source_estimates))
        provider_name, model_id, config = resolve(reduce_model)
        synth_cost = estimate_cost(reduce_model, synth_input, DEFAULT_OUTPUT_TOKENS)

        synthesis_est = SourceEstimate(
            source=f"[synthesis: {reduce_model}]",
            provider=provider_name,
            model_id=model_id,
            weight=None,
            estimated_input_tokens=synth_input,
            estimated_output_tokens=DEFAULT_OUTPUT_TOKENS,
            estimated_cost=synth_cost,
            cached=False,
        )

    return CostEstimate(
        sources=source_estimates,
        synthesis_estimate=synthesis_est,
    )
