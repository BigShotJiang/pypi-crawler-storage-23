"""Tests for streaming synthesis."""

import pytest

from unittest.mock import AsyncMock, patch, MagicMock

from url4.streaming import stream_synthesis
from url4.orchestrator import SourceResult
from url4.council import Council
from url4.cache import ResponseCache


# ── Helpers ────────────────────────────────────────────────────────

def _make_result(source="model-a", response="Hello", weight=None, error=None):
    return SourceResult(
        source=source,
        weight=weight,
        response=response,
        error=error,
    )


async def _collect(async_gen):
    """Collect all items from an async generator."""
    chunks = []
    async for chunk in async_gen:
        chunks.append(chunk)
    return chunks


# ── stream_synthesis ───────────────────────────────────────────────

class TestStreamSynthesis:
    @pytest.mark.asyncio
    async def test_empty_results_yields_nothing(self):
        chunks = await _collect(stream_synthesis([], "test"))
        assert chunks == []

    @pytest.mark.asyncio
    async def test_all_errors_yields_nothing(self):
        results = [_make_result(response="", error="fail")]
        chunks = await _collect(stream_synthesis(results, "test"))
        assert chunks == []

    @pytest.mark.asyncio
    async def test_single_source_no_synthesis(self):
        """Single valid result is yielded directly — no synthesis model called."""
        results = [_make_result(response="The answer is 42.")]
        chunks = await _collect(stream_synthesis(results, "test"))
        assert chunks == ["The answer is 42."]

    @pytest.mark.asyncio
    async def test_multi_source_streams_synthesis(self, monkeypatch):
        """Multiple sources trigger streaming synthesis."""
        results = [
            _make_result(source="model-a", response="Answer A"),
            _make_result(source="model-b", response="Answer B"),
        ]

        # Mock the adapter to stream chunks
        mock_adapter = MagicMock()

        async def fake_stream(model, prompt, **kwargs):
            for chunk in ["Synth", "esized ", "answer"]:
                yield chunk

        mock_adapter.query_stream = fake_stream

        monkeypatch.setattr(
            "url4.streaming.resolve_adapter",
            lambda m: (mock_adapter, "mock-model"),
        )

        chunks = await _collect(
            stream_synthesis(results, "test question", reduce_model="mock")
        )
        assert chunks == ["Synth", "esized ", "answer"]

    @pytest.mark.asyncio
    async def test_skips_error_sources(self, monkeypatch):
        """Error sources are excluded from synthesis prompt."""
        results = [
            _make_result(source="good-a", response="Good answer"),
            _make_result(source="bad", response="", error="timeout"),
            _make_result(source="good-b", response="Another good answer"),
        ]

        prompts_seen = []
        mock_adapter = MagicMock()

        async def fake_stream(model, prompt, **kwargs):
            prompts_seen.append(prompt)
            yield "ok"

        mock_adapter.query_stream = fake_stream
        monkeypatch.setattr(
            "url4.streaming.resolve_adapter",
            lambda m: (mock_adapter, "mock-model"),
        )

        await _collect(stream_synthesis(results, "test"))
        # The prompt should mention the 2 good sources
        assert "Good answer" in prompts_seen[0]
        assert "Another good answer" in prompts_seen[0]


# ── Council.ask_stream ─────────────────────────────────────────────

class TestCouncilAskStream:
    @pytest.fixture
    def tmp_cache(self, tmp_path):
        return ResponseCache(db_path=tmp_path / "test.db")

    @pytest.mark.asyncio
    async def test_single_source_streams_directly(self, tmp_cache, monkeypatch):
        """Single source streams the response directly (no synthesis)."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test")

        from url4.adapters.base import AdapterResult
        mock_result = AdapterResult(
            model="test-model",
            response="Direct answer",
            tokens_in=5,
            tokens_out=10,
            provider="anthropic",
        )

        async def mock_query(model, prompt, **kwargs):
            return mock_result

        mock_adapter = MagicMock()
        mock_adapter.query = mock_query

        monkeypatch.setattr(
            "url4.orchestrator.resolve_adapter",
            lambda m: (mock_adapter, "test-model"),
        )
        monkeypatch.setattr(
            "url4.orchestrator.estimate_cost",
            lambda m, ti, to: 0.001,
        )

        council = Council("claude-haiku", cache=tmp_cache)
        chunks = await _collect(council.ask_stream("test"))
        assert "".join(chunks) == "Direct answer"

    @pytest.mark.asyncio
    async def test_multi_source_streams_synthesis(self, tmp_cache, monkeypatch):
        """Multi-source council streams the synthesis output."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test")
        monkeypatch.setenv("OPENAI_API_KEY", "test")

        from url4.adapters.base import AdapterResult

        call_count = 0

        async def mock_query(model, prompt, **kwargs):
            nonlocal call_count
            call_count += 1
            return AdapterResult(
                model=model,
                response=f"Response {call_count}",
                tokens_in=5,
                tokens_out=10,
                provider="mock",
            )

        mock_adapter = MagicMock()
        mock_adapter.query = mock_query

        async def mock_stream(model, prompt, **kwargs):
            for chunk in ["The ", "synthesized ", "answer."]:
                yield chunk

        mock_adapter.query_stream = mock_stream

        monkeypatch.setattr(
            "url4.orchestrator.resolve_adapter",
            lambda m: (mock_adapter, m),
        )
        monkeypatch.setattr(
            "url4.streaming.resolve_adapter",
            lambda m: (mock_adapter, m),
        )
        monkeypatch.setattr(
            "url4.orchestrator.estimate_cost",
            lambda m, ti, to: 0.0,
        )

        council = Council("model-a|model-b", cache=tmp_cache)
        chunks = await _collect(council.ask_stream("test"))
        assert "".join(chunks) == "The synthesized answer."

    @pytest.mark.asyncio
    async def test_progress_callback(self, tmp_cache, monkeypatch):
        """on_progress is called for each source after map phase."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test")

        from url4.adapters.base import AdapterResult

        async def mock_query(model, prompt, **kwargs):
            return AdapterResult(
                model=model, response="ok", tokens_in=1, tokens_out=1, provider="mock",
            )

        mock_adapter = MagicMock()
        mock_adapter.query = mock_query

        async def mock_stream(model, prompt, **kwargs):
            yield "done"

        mock_adapter.query_stream = mock_stream

        monkeypatch.setattr(
            "url4.orchestrator.resolve_adapter",
            lambda m: (mock_adapter, m),
        )
        monkeypatch.setattr(
            "url4.streaming.resolve_adapter",
            lambda m: (mock_adapter, m),
        )
        monkeypatch.setattr(
            "url4.orchestrator.estimate_cost",
            lambda m, ti, to: 0.0,
        )

        progress_events = []

        def on_progress(source, status):
            progress_events.append((source, status))

        council = Council("model-a|model-b", cache=tmp_cache)
        chunks = await _collect(council.ask_stream("test", on_progress=on_progress))

        assert len(progress_events) == 2
        assert all(status == "done" for _, status in progress_events)

    @pytest.mark.asyncio
    async def test_progress_reports_cached(self, tmp_cache, monkeypatch):
        """on_progress reports 'cached' for cache hits."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test")

        from url4.adapters.base import AdapterResult

        # Pre-populate cache for one source
        tmp_cache.put("model-a", "test", {
            "response": "cached answer",
            "tokens_in": 1,
            "tokens_out": 1,
            "provider": "mock",
            "model_id": "model-a",
        })

        async def mock_query(model, prompt, **kwargs):
            return AdapterResult(
                model=model, response="fresh", tokens_in=1, tokens_out=1, provider="mock",
            )

        mock_adapter = MagicMock()
        mock_adapter.query = mock_query

        async def mock_stream(model, prompt, **kwargs):
            yield "done"

        mock_adapter.query_stream = mock_stream

        monkeypatch.setattr(
            "url4.orchestrator.resolve_adapter",
            lambda m: (mock_adapter, m),
        )
        monkeypatch.setattr(
            "url4.streaming.resolve_adapter",
            lambda m: (mock_adapter, m),
        )
        monkeypatch.setattr(
            "url4.orchestrator.estimate_cost",
            lambda m, ti, to: 0.0,
        )

        progress_events = []

        council = Council("model-a|model-b", cache=tmp_cache)
        chunks = await _collect(
            council.ask_stream(
                "test",
                on_progress=lambda s, st: progress_events.append((s, st)),
            )
        )

        statuses = dict(progress_events)
        assert statuses.get("model-a") == "cached"
        assert statuses.get("model-b") == "done"
