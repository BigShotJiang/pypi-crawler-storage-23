"""Tests for the eval harness."""

import json
from unittest.mock import AsyncMock, patch, MagicMock

import pytest

from url4.eval.hle import HLEQuestion
from url4.eval.judge import judge_response, JudgeResult
from url4.eval.harness import run_eval, EvalResult
from url4.eval.import_cache import import_benchmark_cache
from url4.council import Council
from url4.adapters.base import AdapterResult
from url4.cache import ResponseCache


# ── HLEQuestion ────────────────────────────────────────────────────

class TestHLEQuestion:
    def test_dataclass(self):
        q = HLEQuestion(
            id="abc123",
            question="What is 2+2?",
            answer="4",
            answer_type="exactMatch",
            category="math",
        )
        assert q.id == "abc123"
        assert q.answer == "4"


# ── Judge ──────────────────────────────────────────────────────────

class TestJudge:
    @pytest.mark.asyncio
    @patch("url4.eval.judge.resolve_adapter")
    async def test_correct_answer(self, mock_resolve):
        adapter = MagicMock()
        adapter.query = AsyncMock(return_value=AdapterResult(
            model="judge",
            response='{"extracted_final_answer": "4", "reasoning": "Matches exactly", "correct": "yes"}',
        ))
        mock_resolve.return_value = (adapter, "o3-mini")

        result = await judge_response("What is 2+2?", "The answer is 4.", "4")
        assert result.correct is True
        assert result.model_answer == "4"

    @pytest.mark.asyncio
    @patch("url4.eval.judge.resolve_adapter")
    async def test_incorrect_answer(self, mock_resolve):
        adapter = MagicMock()
        adapter.query = AsyncMock(return_value=AdapterResult(
            model="judge",
            response='{"extracted_final_answer": "5", "reasoning": "Does not match", "correct": "no"}',
        ))
        mock_resolve.return_value = (adapter, "o3-mini")

        result = await judge_response("What is 2+2?", "The answer is 5.", "4")
        assert result.correct is False

    @pytest.mark.asyncio
    @patch("url4.eval.judge.resolve_adapter")
    async def test_json_in_code_block(self, mock_resolve):
        adapter = MagicMock()
        adapter.query = AsyncMock(return_value=AdapterResult(
            model="judge",
            response='```json\n{"extracted_final_answer": "4", "reasoning": "ok", "correct": "yes"}\n```',
        ))
        mock_resolve.return_value = (adapter, "o3-mini")

        result = await judge_response("Q", "4", "4")
        assert result.correct is True

    @pytest.mark.asyncio
    @patch("url4.eval.judge.resolve_adapter")
    async def test_malformed_response_fallback(self, mock_resolve):
        adapter = MagicMock()
        adapter.query = AsyncMock(return_value=AdapterResult(
            model="judge",
            response="I think correct: yes, the answer matches.",
        ))
        mock_resolve.return_value = (adapter, "o3-mini")

        result = await judge_response("Q", "4", "4")
        assert result.correct is True


# ── EvalResult ─────────────────────────────────────────────────────

class TestEvalResult:
    def test_accuracy(self):
        r = EvalResult(total=10, correct=7)
        assert r.accuracy == 0.7
        assert r.accuracy_pct == "70.0%"

    def test_zero_total(self):
        r = EvalResult()
        assert r.accuracy == 0.0


# ── Harness ────────────────────────────────────────────────────────

class TestHarness:
    @pytest.mark.asyncio
    @patch("url4.eval.judge.resolve_adapter")
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.0)
    async def test_basic_eval(self, mock_cost, mock_orch, mock_judge):
        # Mock the council adapter
        def orch_side_effect(model):
            adapter = MagicMock()
            adapter.provider = "mock"
            adapter.query = AsyncMock(return_value=AdapterResult(
                model=model, response="The answer is 4",
                tokens_in=10, tokens_out=5, provider="mock",
            ))
            return (adapter, model)

        mock_orch.side_effect = orch_side_effect

        # Mock the judge
        judge_adapter = MagicMock()
        judge_adapter.query = AsyncMock(return_value=AdapterResult(
            model="judge",
            response='{"extracted_final_answer": "4", "reasoning": "ok", "correct": "yes"}',
        ))
        mock_judge.return_value = (judge_adapter, "o3-mini")

        questions = [
            HLEQuestion(id="q1", question="What is 2+2?", answer="4",
                        answer_type="exactMatch", category="math"),
            HLEQuestion(id="q2", question="What is 3+3?", answer="6",
                        answer_type="exactMatch", category="math"),
        ]

        council = Council("mock-model")
        result = await run_eval(council, questions)

        assert result.total == 2
        assert result.correct == 2
        assert result.accuracy == 1.0
        assert len(result.results) == 2

    @pytest.mark.asyncio
    @patch("url4.eval.judge.resolve_adapter")
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.0)
    async def test_progress_callback(self, mock_cost, mock_orch, mock_judge):
        def orch_side_effect(model):
            adapter = MagicMock()
            adapter.provider = "mock"
            adapter.query = AsyncMock(return_value=AdapterResult(
                model=model, response="answer", tokens_in=1, tokens_out=1, provider="mock",
            ))
            return (adapter, model)

        mock_orch.side_effect = orch_side_effect

        judge_adapter = MagicMock()
        judge_adapter.query = AsyncMock(return_value=AdapterResult(
            model="judge",
            response='{"extracted_final_answer": "x", "reasoning": "ok", "correct": "no"}',
        ))
        mock_judge.return_value = (judge_adapter, "o3-mini")

        progress_calls = []
        questions = [
            HLEQuestion(id="q1", question="Q1", answer="A1",
                        answer_type="exactMatch", category="test"),
        ]

        council = Council("mock-model")
        await run_eval(
            council, questions,
            on_progress=lambda c, t, co, qid: progress_calls.append((c, t, co)),
        )
        assert len(progress_calls) == 1
        assert progress_calls[0] == (1, 1, 0)  # 1 done, 1 total, 0 correct


# ── Import cache ───────────────────────────────────────────────────

class TestImportCache:
    def test_import_from_dir(self, tmp_path):
        # Create a mock benchmark file
        data = {
            "q1": {
                "model": "test-model",
                "question": "What is 2+2?",
                "response": "The answer is 4.",
                "usage": {"input_tokens": 10, "output_tokens": 5},
            },
            "q2": {
                "model": "test-model",
                "question": "What is 3+3?",
                "response": "The answer is 6.",
                "usage": {"input_tokens": 10, "output_tokens": 5},
            },
        }
        json_path = tmp_path / "hle_test-model.json"
        json_path.write_text(json.dumps(data))

        cache = ResponseCache(db_path=tmp_path / "test.db")
        stats = import_benchmark_cache(tmp_path, cache=cache, questions_map={})

        assert stats["hle_test-model.json"] == 2
        assert cache.stats().total_entries == 2

    def test_import_skips_empty_responses(self, tmp_path):
        data = {
            "q1": {"model": "test", "question": "Q?", "response": ""},
        }
        (tmp_path / "hle_test.json").write_text(json.dumps(data))

        cache = ResponseCache(db_path=tmp_path / "test.db")
        stats = import_benchmark_cache(tmp_path, cache=cache, questions_map={})
        assert stats["hle_test.json"] == 0
