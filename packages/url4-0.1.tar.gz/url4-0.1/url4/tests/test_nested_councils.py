"""Tests for nested councils (councils of councils)."""

from unittest.mock import AsyncMock, patch, MagicMock

import pytest

from url4.parser import parse
from url4.orchestrator import fan_out, SourceResult
from url4.synthesis import synthesize, SynthesisResult
from url4.council import Council
from url4.adapters.base import AdapterResult
from url4.cache import ResponseCache


# ── Helpers ────────────────────────────────────────────────────────

def _make_adapter_result(model: str, response: str) -> AdapterResult:
    return AdapterResult(
        model=model,
        response=response,
        tokens_in=10,
        tokens_out=5,
        latency_ms=100,
        cost=0.0,
        provider="mock",
    )


def _mock_resolve(model: str):
    adapter = MagicMock()
    adapter.provider = "mock"
    adapter.query = AsyncMock(
        return_value=_make_adapter_result(model, f"Response from {model}")
    )
    return (adapter, model)


# ── Nested fan-out with synthesis ──────────────────────────────────

class TestNestedSynthesis:
    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.001)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_two_bracket_groups(self, orch_cost, orch_resolve,
                                      synth_cost, synth_resolve):
        """Two bracket groups each get synthesized independently."""
        orch_resolve.side_effect = _mock_resolve

        synth_calls = []
        def synth_side_effect(model):
            adapter = MagicMock()
            adapter.provider = "mock"
            async def query(m, p, **kw):
                synth_calls.append(p)
                return _make_adapter_result(m, f"Synthesized by {m}")
            adapter.query = query
            return (adapter, model)

        synth_resolve.side_effect = synth_side_effect

        spec = parse("[claude|gpt-4o!draft A]|[gemini|deepseek!draft B]!final&cache=off")
        results = await fan_out(spec)

        assert len(results) == 2
        # Both bracket groups were synthesized
        assert len(synth_calls) == 2
        assert "draft A" in synth_calls[0]
        assert "draft B" in synth_calls[1]

    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.0)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.0)
    async def test_nested_cost_aggregation(self, orch_cost, orch_resolve,
                                            synth_cost, synth_resolve):
        """Nested result aggregates costs from inner sources + synthesis."""
        orch_resolve.side_effect = _mock_resolve
        synth_resolve.side_effect = _mock_resolve

        spec = parse("[a|b!inner]!outer&cache=off")
        results = await fan_out(spec)

        assert len(results) == 1
        # Should have tokens from 2 inner sources + synthesis
        assert results[0].tokens_in > 0
        assert results[0].tokens_out > 0


# ── Full nested Council ────────────────────────────────────────────

class TestNestedCouncil:
    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.001)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_council_of_councils(self, orch_cost, orch_resolve,
                                        synth_cost, synth_resolve):
        """Full pipeline: inner councils draft, outer council synthesizes."""
        orch_resolve.side_effect = _mock_resolve

        synth_call_count = 0
        def synth_side_effect(model):
            nonlocal synth_call_count
            synth_call_count += 1
            adapter = MagicMock()
            adapter.provider = "mock"
            adapter.query = AsyncMock(
                return_value=_make_adapter_result(model, f"Synthesis #{synth_call_count}")
            )
            return (adapter, model)

        synth_resolve.side_effect = synth_side_effect

        council = Council(
            "[claude|gpt-4o!draft answer]|[gemini|deepseek!draft answer]"
        )
        result = await council.ask("What causes tides?")

        assert result.response is not None
        assert len(result.response) > 0
        # 2 inner syntheses + 1 outer synthesis = 3 total
        assert synth_call_count == 3
        assert result.total_cost > 0

    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.001)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_depth_flat(self, orch_cost, orch_resolve,
                              synth_cost, synth_resolve):
        """Flat council has depth 1."""
        orch_resolve.side_effect = _mock_resolve
        synth_resolve.side_effect = _mock_resolve

        council = Council("claude|gpt-4o")
        result = await council.ask("test")
        assert result.depth == 1

    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.001)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_depth_nested(self, orch_cost, orch_resolve,
                                 synth_cost, synth_resolve):
        """Nested council has depth 2."""
        orch_resolve.side_effect = _mock_resolve
        synth_resolve.side_effect = _mock_resolve

        council = Council("[claude|gpt-4o!draft]|[gemini|deepseek!draft]")
        result = await council.ask("test")
        assert result.depth == 2

    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.0)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.0)
    async def test_mixed_nested_and_flat(self, orch_cost, orch_resolve,
                                          synth_cost, synth_resolve):
        """Mix of bracket group and flat sources works."""
        orch_resolve.side_effect = _mock_resolve
        synth_resolve.side_effect = _mock_resolve

        council = Council("[claude|gpt-4o!draft]|deepseek")
        result = await council.ask("test")

        assert result.response is not None
        assert len(result.source_results) == 2

    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.0)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.0)
    async def test_single_source_bracket_passthrough(self, orch_cost, orch_resolve,
                                                      synth_cost, synth_resolve):
        """Single source inside brackets passes through without synthesis."""
        orch_resolve.side_effect = _mock_resolve
        synth_resolve.side_effect = _mock_resolve

        spec = parse("[claude!inner]!outer&cache=off")
        results = await fan_out(spec)

        assert len(results) == 1
        # Single inner source = pass-through
        assert results[0].response == "Response from claude"


# ── Cache at nested levels ─────────────────────────────────────────

class TestNestedCache:
    @pytest.fixture
    def tmp_cache(self, tmp_path):
        return ResponseCache(db_path=tmp_path / "test.db")

    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.0)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.0)
    async def test_inner_sources_cached(self, orch_cost, orch_resolve,
                                         synth_cost, synth_resolve,
                                         tmp_cache):
        """Inner source responses are cached individually."""
        call_count = 0

        def counting_resolve(model):
            nonlocal call_count
            call_count += 1
            return _mock_resolve(model)

        orch_resolve.side_effect = counting_resolve
        synth_resolve.side_effect = _mock_resolve

        spec = parse("[a|b!inner]!outer")

        # First call — 2 inner sources queried
        call_count = 0
        await fan_out(spec, cache=tmp_cache)
        first_calls = call_count

        # Second call — inner sources should be cached
        call_count = 0
        await fan_out(spec, cache=tmp_cache)
        second_calls = call_count

        # First time: both inner sources call resolve_adapter
        assert first_calls == 2
        # Second time: both inner sources are cache hits, resolve still called
        # but adapter.query is NOT called (cache returns early)
        # resolve_adapter is called to get model_id for cache lookup
        assert second_calls == 2  # resolve called but query skipped
