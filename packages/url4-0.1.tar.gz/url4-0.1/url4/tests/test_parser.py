"""Tests for the url4 URL parser."""

import pytest
from url4.parser import parse, ParseError


class TestBasicParsing:
    """Simple source|source!prompt patterns."""

    def test_single_source_with_prompt(self):
        spec = parse("react.dev!explain hooks")
        assert len(spec.sources) == 1
        assert spec.sources[0].url == "react.dev"
        assert spec.prompt == "explain hooks"

    def test_two_sources(self):
        spec = parse("react.dev|mdn.io!explain useEffect")
        assert len(spec.sources) == 2
        assert spec.sources[0].url == "react.dev"
        assert spec.sources[1].url == "mdn.io"
        assert spec.prompt == "explain useEffect"

    def test_three_sources(self):
        spec = parse("claude|gemini|gpt!synthesize")
        assert len(spec.sources) == 3
        assert spec.sources[0].url == "claude"
        assert spec.sources[1].url == "gemini"
        assert spec.sources[2].url == "gpt"
        assert spec.prompt == "synthesize"

    def test_prompt_only_no_sources(self):
        spec = parse("!generate a random number")
        assert len(spec.sources) == 0
        assert spec.prompt == "generate a random number"

    def test_plus_decoded_as_space(self):
        spec = parse("source!hello+world+foo")
        assert spec.prompt == "hello world foo"

    def test_full_url_extraction(self):
        spec = parse("url4.ai/v1/?q=react.dev!explain+hooks")
        assert len(spec.sources) == 1
        assert spec.sources[0].url == "react.dev"
        assert spec.prompt == "explain hooks"


class TestWeights:
    """Weight prefix: float*source."""

    def test_single_weight(self):
        spec = parse("0.7*react.dev!explain")
        assert spec.sources[0].weight == 0.7
        assert spec.sources[0].url == "react.dev"

    def test_multiple_weights(self):
        spec = parse("0.4*claude|0.3*gemini|0.3*gpt!synthesize")
        assert spec.sources[0].weight == 0.4
        assert spec.sources[0].url == "claude"
        assert spec.sources[1].weight == 0.3
        assert spec.sources[1].url == "gemini"
        assert spec.sources[2].weight == 0.3
        assert spec.sources[2].url == "gpt"

    def test_mixed_weighted_and_unweighted(self):
        spec = parse("0.5*claude|gemini!synthesize")
        assert spec.sources[0].weight == 0.5
        assert spec.sources[1].weight is None

    def test_weight_zero(self):
        spec = parse("0.0*claude!test")
        assert spec.sources[0].weight == 0.0

    def test_weight_one(self):
        spec = parse("1.0*claude!test")
        assert spec.sources[0].weight == 1.0

    def test_integer_weight(self):
        spec = parse("1*claude!test")
        assert spec.sources[0].weight == 1.0


class TestNesting:
    """Bracketed sub-specs: [sources!prompt]."""

    def test_simple_nested(self):
        spec = parse("[claude|gemini!draft]|gpt!final")
        assert len(spec.sources) == 2
        # First source is nested
        nested = spec.sources[0].nested
        assert nested is not None
        assert len(nested.sources) == 2
        assert nested.sources[0].url == "claude"
        assert nested.sources[1].url == "gemini"
        assert nested.prompt == "draft"
        # Second source is plain
        assert spec.sources[1].url == "gpt"
        assert spec.prompt == "final"

    def test_two_nested_groups(self):
        spec = parse("[claude|gemini!draft]|[gpt|mistral!draft]!combine")
        assert len(spec.sources) == 2
        assert spec.sources[0].nested is not None
        assert spec.sources[1].nested is not None
        assert spec.sources[0].nested.prompt == "draft"
        assert spec.sources[1].nested.prompt == "draft"
        assert spec.prompt == "combine"

    def test_nested_with_weights(self):
        spec = parse("0.6*[claude|gemini!draft]|0.4*[gpt!draft]!combine")
        assert spec.sources[0].weight == 0.6
        assert spec.sources[0].nested is not None
        assert spec.sources[1].weight == 0.4
        assert spec.sources[1].nested is not None

    def test_deeply_nested(self):
        spec = parse("[[a|b!inner]|c!mid]|d!outer")
        assert spec.prompt == "outer"
        mid = spec.sources[0].nested
        assert mid is not None
        assert mid.prompt == "mid"
        inner = mid.sources[0].nested
        assert inner is not None
        assert inner.prompt == "inner"
        assert inner.sources[0].url == "a"
        assert inner.sources[1].url == "b"

    def test_nested_weights_inside(self):
        spec = parse("[0.7*claude|0.3*gemini!draft]!final")
        nested = spec.sources[0].nested
        assert nested.sources[0].weight == 0.7
        assert nested.sources[1].weight == 0.3


class TestReferrals:
    """Hop characters: source< or source<<."""

    def test_single_hop(self):
        spec = parse("friends<!best recipe")
        assert spec.sources[0].url == "friends"
        assert spec.sources[0].hops == 1

    def test_multi_hop(self):
        spec = parse("friends<<!best recipe")
        assert spec.sources[0].url == "friends"
        assert spec.sources[0].hops == 2

    def test_three_hops(self):
        spec = parse("friends<<<!find experts")
        assert spec.sources[0].hops == 3

    def test_hop_with_tag(self):
        spec = parse("friends<#movies!best film")
        assert spec.sources[0].hops == 1
        assert spec.sources[0].tag == "movies"


class TestTags:
    """Tag annotations: source#tag."""

    def test_simple_tag(self):
        spec = parse("source#category!prompt")
        assert spec.sources[0].url == "source"
        assert spec.sources[0].tag == "category"

    def test_tag_with_weight(self):
        spec = parse("0.5*source#tag!prompt")
        assert spec.sources[0].weight == 0.5
        assert spec.sources[0].tag == "tag"


class TestPrivacyBudgets:
    """Epsilon values: source~epsilon."""

    def test_simple_epsilon(self):
        spec = parse("alice.url4.ai~0.1!best movie")
        assert spec.sources[0].epsilon == 0.1

    def test_weight_and_epsilon(self):
        spec = parse("0.5*alice.url4.ai~0.1|0.5*bob.url4.ai~0.1!best movie")
        assert spec.sources[0].weight == 0.5
        assert spec.sources[0].epsilon == 0.1
        assert spec.sources[1].weight == 0.5
        assert spec.sources[1].epsilon == 0.1

    def test_zero_epsilon(self):
        spec = parse("source~0.0!prompt")
        assert spec.sources[0].epsilon == 0.0

    def test_epsilon_on_nested(self):
        spec = parse("[a|b!inner]~0.5!outer")
        assert spec.sources[0].nested is not None
        assert spec.sources[0].epsilon == 0.5


class TestParams:
    """Query parameters: &key=value."""

    def test_reduce_param(self):
        spec = parse("claude|gemini!synth&reduce=0,-1")
        assert spec.params["reduce"] == "0,-1"
        assert spec.prompt == "synth"

    def test_cache_param(self):
        spec = parse("claude|gemini!synth&cache=system")
        assert spec.params["cache"] == "system"

    def test_multiple_params(self):
        spec = parse("claude|gemini!synth&reduce=0,-1&cache=user&timeout=5000")
        assert spec.params["reduce"] == "0,-1"
        assert spec.params["cache"] == "user"
        assert spec.params["timeout"] == "5000"

    def test_nonce_param(self):
        spec = parse("claude!test&nonce=abc123")
        assert spec.params["nonce"] == "abc123"

    def test_view_param(self):
        spec = parse("claude!test&view=true")
        assert spec.params["view"] == "true"

    def test_estimate_param(self):
        spec = parse("claude|gemini!test&estimate=true")
        assert spec.params["estimate"] == "true"

    def test_wait_and_collect(self):
        spec = parse("claude!test&wait=30s&collect=5m")
        assert spec.params["wait"] == "30s"
        assert spec.params["collect"] == "5m"

    def test_key_param(self):
        spec = parse("claude!test&key=sk-123")
        assert spec.params["key"] == "sk-123"

    def test_flag_param_no_value(self):
        spec = parse("claude!test&view")
        assert spec.params["view"] == "true"


class TestOutputPipes:
    """Output pipe: spec > destination."""

    def test_write_pipe(self):
        spec = parse("claude|gemini!synth>cards.highcouncil.ai/weights")
        assert spec.destination == "cards.highcouncil.ai/weights"
        assert spec.prompt == "synth"

    def test_append_pipe(self):
        spec = parse("claude|gemini!synth>>cards.highcouncil.ai/log")
        assert spec.destination == ">>cards.highcouncil.ai/log"

    def test_pipe_with_params(self):
        spec = parse("claude!synth&cache=off>output.url4.ai/result")
        assert spec.params["cache"] == "off"
        assert spec.destination == "output.url4.ai/result"


class TestFullURLs:
    """Full url4 URLs as sources (not just short names)."""

    def test_adapter_urls(self):
        spec = parse(
            "0.4*openrouter.highcouncil.ai/claude-opus-4"
            "|0.3*openrouter.highcouncil.ai/gemini-pro"
            "|0.3*openrouter.highcouncil.ai/gpt-5"
            "!synthesize"
        )
        assert len(spec.sources) == 3
        assert spec.sources[0].url == "openrouter.highcouncil.ai/claude-opus-4"
        assert spec.sources[0].weight == 0.4
        assert spec.sources[2].url == "openrouter.highcouncil.ai/gpt-5"

    def test_localhost_url(self):
        spec = parse("localhost:11434/llama3|localhost:11434/mistral!synth")
        assert spec.sources[0].url == "localhost:11434/llama3"
        assert spec.sources[1].url == "localhost:11434/mistral"

    def test_full_context_url(self):
        spec = parse(
            "highcouncil.ai/v1/?q="
            "0.4*openrouter.highcouncil.ai/claude-opus-4"
            "|0.3*openrouter.highcouncil.ai/gemini-pro"
            "!synthesize+the+best+answer"
        )
        assert len(spec.sources) == 2
        assert spec.prompt == "synthesize the best answer"


class TestEdgeCases:
    """Edge cases and error handling."""

    def test_empty_string_raises(self):
        with pytest.raises(ParseError):
            parse("")

    def test_no_bang_raises(self):
        with pytest.raises(ParseError):
            parse("just some text with no bang")

    def test_whitespace_only_raises(self):
        with pytest.raises(ParseError):
            parse("   ")

    def test_bang_only(self):
        spec = parse("!")
        assert len(spec.sources) == 0
        assert spec.prompt == ""

    def test_preserves_raw(self):
        raw = "claude|gemini!test"
        spec = parse(raw)
        assert spec.raw == raw

    def test_url_encoded_input(self):
        spec = parse("claude%7Cgemini!hello%20world")
        assert len(spec.sources) == 2
        assert spec.prompt == "hello world"

    def test_single_source_no_url_just_model_name(self):
        spec = parse("claude-opus-4!explain quantum physics")
        assert spec.sources[0].url == "claude-opus-4"
        assert spec.prompt == "explain quantum physics"


class TestHLECouncilExamples:
    """Real-world examples matching the benchmark council configs."""

    def test_simple_council(self):
        spec = parse(
            "0.4*claude-opus-4|0.3*gemini-3.1-pro|0.2*gpt-5|0.1*kimi-k2.5"
            "!synthesize the most accurate answer"
        )
        assert len(spec.sources) == 4
        assert spec.sources[0].weight == 0.4
        assert spec.sources[3].url == "kimi-k2.5"
        assert "synthesize" in spec.prompt

    def test_council_of_councils(self):
        spec = parse(
            "[claude-opus-4|gemini-3.1-pro!draft]"
            "|[gpt-5|kimi-k2.5!draft]"
            "!combine these drafts into the best answer"
        )
        assert len(spec.sources) == 2
        assert spec.sources[0].nested is not None
        assert spec.sources[1].nested is not None
        assert len(spec.sources[0].nested.sources) == 2
        assert len(spec.sources[1].nested.sources) == 2

    def test_council_with_cache_and_reduce(self):
        spec = parse(
            "0.4*claude-opus-4|0.3*gemini-pro|0.3*gpt-5"
            "!synthesize&reduce=0,-1&cache=system"
        )
        assert spec.params["reduce"] == "0,-1"
        assert spec.params["cache"] == "system"
        assert len(spec.sources) == 3
