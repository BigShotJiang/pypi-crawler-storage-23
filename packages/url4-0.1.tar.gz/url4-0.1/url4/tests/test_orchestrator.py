"""Tests for the orchestrator (fan-out + collect) with cache integration."""

import asyncio
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, patch, MagicMock

import pytest

from url4.parser import parse, Spec, Source
from url4.orchestrator import fan_out, _query_source, SourceResult
from url4.adapters.base import AdapterResult
from url4.cache import ResponseCache


# ── Helper: mock adapter ────────────────────────────────────────────

def _make_mock_result(model: str, response: str, latency: int = 100) -> AdapterResult:
    return AdapterResult(
        model=model,
        response=response,
        tokens_in=10,
        tokens_out=5,
        latency_ms=latency,
        cost=0.0,
        provider="mock",
    )


def _mock_resolve_adapter(model: str):
    """Return a mock adapter that echoes the model name."""
    adapter = MagicMock()
    adapter.provider = "mock"
    adapter.query = AsyncMock(
        return_value=_make_mock_result(model, f"Response from {model}")
    )
    return (adapter, model)


# ── Fan-out tests (cache=off to isolate from cache) ─────────────────

class TestFanOut:
    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_single_source(self, mock_cost, mock_resolve):
        mock_resolve.side_effect = _mock_resolve_adapter
        spec = parse("claude-haiku!What is 2+2?&cache=off")
        results = await fan_out(spec)

        assert len(results) == 1
        assert results[0].source == "claude-haiku"
        assert results[0].response == "Response from claude-haiku"
        assert results[0].error is None
        assert results[0].cache == "OFF"

    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_two_sources_parallel(self, mock_cost, mock_resolve):
        mock_resolve.side_effect = _mock_resolve_adapter
        spec = parse("claude-haiku|gpt-4o-mini!What is 2+2?&cache=off")
        results = await fan_out(spec)

        assert len(results) == 2
        sources = {r.source for r in results}
        assert sources == {"claude-haiku", "gpt-4o-mini"}
        assert all(r.error is None for r in results)

    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_three_sources(self, mock_cost, mock_resolve):
        mock_resolve.side_effect = _mock_resolve_adapter
        spec = parse("claude|gpt-4o|deepseek!test&cache=off")
        results = await fan_out(spec)

        assert len(results) == 3

    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_preserves_weights(self, mock_cost, mock_resolve):
        mock_resolve.side_effect = _mock_resolve_adapter
        spec = parse("0.6*claude|0.4*gpt-4o!test&cache=off")
        results = await fan_out(spec)

        assert results[0].weight == 0.6
        assert results[1].weight == 0.4

    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_preserves_tags(self, mock_cost, mock_resolve):
        mock_resolve.side_effect = _mock_resolve_adapter
        spec = parse("claude#fast|gpt-4o#smart!test&cache=off")
        results = await fan_out(spec)

        assert results[0].tag == "fast"
        assert results[1].tag == "smart"

    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_preserves_order(self, mock_cost, mock_resolve):
        mock_resolve.side_effect = _mock_resolve_adapter
        spec = parse("alpha|beta|gamma!test&cache=off")
        results = await fan_out(spec)

        assert results[0].source == "alpha"
        assert results[1].source == "beta"
        assert results[2].source == "gamma"


# ── Error handling ──────────────────────────────────────────────────

class TestErrorHandling:
    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    async def test_source_error_captured(self, mock_resolve):
        adapter = MagicMock()
        adapter.query = AsyncMock(side_effect=Exception("API key invalid"))
        mock_resolve.return_value = (adapter, "bad-model")

        spec = parse("bad-model!test&cache=off")
        results = await fan_out(spec)

        assert len(results) == 1
        assert results[0].error is not None
        assert "API key invalid" in results[0].error
        assert results[0].response == ""

    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.0)
    async def test_partial_failure(self, mock_cost, mock_resolve):
        """One source fails, another succeeds — both returned."""
        def side_effect(model):
            adapter = MagicMock()
            adapter.provider = "mock"
            if model == "bad":
                adapter.query = AsyncMock(side_effect=Exception("fail"))
            else:
                adapter.query = AsyncMock(
                    return_value=_make_mock_result(model, "ok")
                )
            return (adapter, model)

        mock_resolve.side_effect = side_effect
        spec = parse("good|bad!test&cache=off")
        results = await fan_out(spec)

        assert len(results) == 2
        good = next(r for r in results if r.source == "good")
        bad = next(r for r in results if r.source == "bad")
        assert good.response == "ok"
        assert good.error is None
        assert bad.error is not None


# ── Timeout ─────────────────────────────────────────────────────────

class TestTimeout:
    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    async def test_timeout_produces_error(self, mock_resolve):
        async def slow_query(model, prompt, **kwargs):
            await asyncio.sleep(10)
            return _make_mock_result(model, "too late")

        adapter = MagicMock()
        adapter.query = slow_query
        mock_resolve.return_value = (adapter, "slow-model")

        spec = parse("slow-model!test&timeout=50&cache=off")
        results = await fan_out(spec)

        assert len(results) == 1
        assert results[0].error is not None
        assert "Timeout" in results[0].error


# ── Nested specs ────────────────────────────────────────────────────

class TestNestedFanOut:
    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.001)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_nested_source(self, mock_orch_cost, mock_orch_resolve,
                                  mock_synth_cost, mock_synth_resolve):
        mock_orch_resolve.side_effect = _mock_resolve_adapter
        mock_synth_resolve.side_effect = _mock_resolve_adapter
        spec = parse("[claude|gpt-4o!inner]|deepseek!outer&cache=off")
        results = await fan_out(spec)

        assert len(results) == 2
        nested = results[0]
        assert "[" in nested.source
        # Nested result is now synthesized — should have a response
        assert len(nested.response) > 0
        assert results[1].source == "deepseek"

    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.001)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_nested_aggregates_tokens(self, mock_orch_cost, mock_orch_resolve,
                                             mock_synth_cost, mock_synth_resolve):
        mock_orch_resolve.side_effect = _mock_resolve_adapter
        mock_synth_resolve.side_effect = _mock_resolve_adapter
        spec = parse("[a|b|c!inner]!outer&cache=off")
        results = await fan_out(spec)

        assert len(results) == 1
        # Inner: 3 sources × 10 tokens_in = 30, plus synthesis tokens_in
        assert results[0].tokens_in >= 30

    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.001)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_nested_uses_inner_prompt_as_reduce(self, mock_orch_cost, mock_orch_resolve,
                                                       mock_synth_cost, mock_synth_resolve):
        """The inner spec's prompt (after !) becomes the reduce instruction."""
        prompts_seen = []

        def synth_resolve(model):
            adapter = MagicMock()
            adapter.provider = "mock"
            async def query(m, p, **kw):
                prompts_seen.append(p)
                return _make_mock_result(m, "synthesized")
            adapter.query = query
            return (adapter, model)

        mock_orch_resolve.side_effect = _mock_resolve_adapter
        mock_synth_resolve.side_effect = synth_resolve

        spec = parse("[claude|gpt-4o!draft a summary]!outer&cache=off")
        await fan_out(spec)

        # The synthesis prompt should include the inner instruction
        assert len(prompts_seen) == 1
        assert "draft a summary" in prompts_seen[0]

    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.0)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.0)
    async def test_single_inner_source_no_synthesis(self, mock_orch_cost, mock_orch_resolve,
                                                     mock_synth_cost, mock_synth_resolve):
        """A bracket with one source passes through (no synthesis call)."""
        mock_orch_resolve.side_effect = _mock_resolve_adapter
        # synth_resolve should NOT be called for single source
        mock_synth_resolve.side_effect = _mock_resolve_adapter

        spec = parse("[claude!inner]|gpt-4o!outer&cache=off")
        results = await fan_out(spec)

        assert len(results) == 2
        # Single inner source = pass-through, response should be direct
        assert results[0].response == "Response from claude"


# ── Cache integration ───────────────────────────────────────────────

class TestCacheIntegration:
    """Test cache hit/miss behavior with a temp database."""

    @pytest.fixture
    def tmp_cache(self, tmp_path):
        return ResponseCache(db_path=tmp_path / "test_cache.db")

    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_first_call_is_miss(self, mock_cost, mock_resolve, tmp_cache):
        mock_resolve.side_effect = _mock_resolve_adapter
        spec = parse("claude-haiku!What is 2+2?")
        results = await fan_out(spec, cache=tmp_cache)

        assert len(results) == 1
        assert results[0].cache == "MISS"
        assert results[0].response == "Response from claude-haiku"

    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_second_call_is_hit(self, mock_cost, mock_resolve, tmp_cache):
        mock_resolve.side_effect = _mock_resolve_adapter
        spec = parse("claude-haiku!What is 2+2?")

        # First call — miss
        r1 = await fan_out(spec, cache=tmp_cache)
        assert r1[0].cache == "MISS"

        # Second call — hit
        r2 = await fan_out(spec, cache=tmp_cache)
        assert r2[0].cache == "HIT"
        assert r2[0].response == "Response from claude-haiku"
        assert r2[0].latency_ms == 0
        assert r2[0].cost == 0.0

    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_cache_hit_does_not_call_adapter(self, mock_cost, mock_resolve, tmp_cache):
        call_count = 0

        def counting_resolve(model):
            nonlocal call_count
            call_count += 1
            return _mock_resolve_adapter(model)

        mock_resolve.side_effect = counting_resolve
        spec = parse("claude-haiku!test")

        await fan_out(spec, cache=tmp_cache)  # miss — calls adapter
        assert call_count == 1

        # Reset the side_effect to count again
        call_count = 0
        adapter_mock = MagicMock()
        adapter_mock.provider = "mock"
        adapter_mock.query = AsyncMock(return_value=_make_mock_result("x", "y"))
        mock_resolve.side_effect = counting_resolve

        await fan_out(spec, cache=tmp_cache)  # hit — should still call resolve_adapter but NOT query
        # resolve_adapter is called (for the model_id), but the adapter's query should not be called
        # on a cache hit because we return early

    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_cache_off_skips_cache(self, mock_cost, mock_resolve, tmp_cache):
        mock_resolve.side_effect = _mock_resolve_adapter
        spec = parse("claude-haiku!test&cache=off")

        r1 = await fan_out(spec, cache=tmp_cache)
        assert r1[0].cache == "OFF"

        # Second call with cache=off should also be OFF (not HIT)
        r2 = await fan_out(spec, cache=tmp_cache)
        assert r2[0].cache == "OFF"

    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_different_prompts_different_cache(self, mock_cost, mock_resolve, tmp_cache):
        mock_resolve.side_effect = _mock_resolve_adapter

        spec1 = parse("claude-haiku!What is 2+2?")
        spec2 = parse("claude-haiku!What is 3+3?")

        await fan_out(spec1, cache=tmp_cache)
        r2 = await fan_out(spec2, cache=tmp_cache)
        assert r2[0].cache == "MISS"  # different prompt = miss

    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_multi_source_cache(self, mock_cost, mock_resolve, tmp_cache):
        mock_resolve.side_effect = _mock_resolve_adapter
        spec = parse("claude|gpt-4o!test")

        r1 = await fan_out(spec, cache=tmp_cache)
        assert all(r.cache == "MISS" for r in r1)

        r2 = await fan_out(spec, cache=tmp_cache)
        assert all(r.cache == "HIT" for r in r2)
        assert sum(r.cost for r in r2) == 0.0

    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_cache_stats(self, mock_cost, mock_resolve, tmp_cache):
        mock_resolve.side_effect = _mock_resolve_adapter
        spec = parse("claude-haiku!test")

        await fan_out(spec, cache=tmp_cache)  # 1 miss
        await fan_out(spec, cache=tmp_cache)  # 1 hit

        stats = tmp_cache.stats()
        assert stats.hits == 1
        assert stats.misses == 1
        assert stats.total_entries == 1


# ── SourceResult ────────────────────────────────────────────────────

class TestSourceResult:
    def test_defaults(self):
        r = SourceResult(source="test", weight=None, response="hi")
        assert r.error is None
        assert r.cost == 0.0
        assert r.tokens_in == 0
        assert r.cache == ""
