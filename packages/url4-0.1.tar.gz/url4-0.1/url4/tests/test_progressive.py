"""Tests for progressive reduce (&reduce=0,2,-1)."""

import asyncio
from unittest.mock import AsyncMock, patch, MagicMock

import pytest

from url4.parser import parse
from url4.orchestrator import fan_out_progressive, _parse_checkpoints, SourceResult
from url4.council import Council
from url4.adapters.base import AdapterResult
from url4.cache import ResponseCache


# ── Checkpoint parsing ─────────────────────────────────────────────

class TestParseCheckpoints:
    def test_single_index(self):
        assert _parse_checkpoints("0", 3) == [0]

    def test_multiple_indices(self):
        assert _parse_checkpoints("0,2", 3) == [0, 2]

    def test_negative_index(self):
        assert _parse_checkpoints("-1", 3) == [2]

    def test_mixed(self):
        assert _parse_checkpoints("0,-1", 3) == [0, 2]

    def test_deduplicates(self):
        assert _parse_checkpoints("0,0,1", 3) == [0, 1]

    def test_sorted(self):
        assert _parse_checkpoints("2,0,1", 3) == [0, 1, 2]

    def test_out_of_range_ignored(self):
        assert _parse_checkpoints("0,5", 3) == [0]

    def test_empty_string(self):
        assert _parse_checkpoints("", 3) == []

    def test_invalid_ignored(self):
        assert _parse_checkpoints("0,abc,2", 3) == [0, 2]


# ── Progressive fan-out ────────────────────────────────────────────

def _make_adapter(model, response, delay=0):
    adapter = MagicMock()
    adapter.provider = "mock"

    async def query(m, p, **kw):
        if delay:
            await asyncio.sleep(delay)
        return AdapterResult(
            model=m, response=response,
            tokens_in=10, tokens_out=5, provider="mock",
        )

    adapter.query = query
    return adapter


class TestProgressiveFanOut:
    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.0)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.0)
    async def test_single_checkpoint(self, orch_cost, orch_resolve,
                                      synth_cost, synth_resolve):
        """Single checkpoint yields once."""
        def mock_resolve(model):
            return (_make_adapter(model, f"Response from {model}"), model)

        orch_resolve.side_effect = mock_resolve
        synth_resolve.side_effect = mock_resolve

        spec = parse("a|b|c!test&cache=off")
        checkpoints = [2]  # yield after source 2

        results = []
        async for cp, completed in fan_out_progressive(spec, checkpoints):
            results.append((cp, len(completed)))

        assert len(results) == 1
        assert results[0] == (2, 3)  # all 3 complete by index 2

    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.0)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.0)
    async def test_two_checkpoints(self, orch_cost, orch_resolve,
                                    synth_cost, synth_resolve):
        """Two checkpoints yield twice."""
        call_order = []

        def mock_resolve(model):
            async def query(m, p, **kw):
                call_order.append(m)
                return AdapterResult(
                    model=m, response=f"Response from {m}",
                    tokens_in=10, tokens_out=5, provider="mock",
                )
            adapter = MagicMock()
            adapter.provider = "mock"
            adapter.query = query
            return (adapter, model)

        orch_resolve.side_effect = mock_resolve
        synth_resolve.side_effect = mock_resolve

        spec = parse("a|b|c!test&cache=off")
        checkpoints = [0, 2]

        yields = []
        async for cp, completed in fan_out_progressive(spec, checkpoints):
            yields.append((cp, [r.source for r in completed]))

        assert len(yields) == 2
        # First checkpoint: at least source 'a' is done
        assert "a" in yields[0][1]
        # Second checkpoint: all sources done
        assert len(yields[1][1]) == 3


# ── Council.ask_progressive ────────────────────────────────────────

class TestAskProgressive:
    @pytest.fixture
    def tmp_cache(self, tmp_path):
        return ResponseCache(db_path=tmp_path / "test.db")

    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.0)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.0)
    async def test_progressive_yields_at_checkpoints(
        self, orch_cost, orch_resolve, synth_cost, synth_resolve, tmp_cache,
    ):
        def mock_resolve(model):
            adapter = MagicMock()
            adapter.provider = "mock"
            adapter.query = AsyncMock(return_value=AdapterResult(
                model=model, response=f"From {model}",
                tokens_in=10, tokens_out=5, provider="mock",
            ))
            return (adapter, model)

        orch_resolve.side_effect = mock_resolve
        synth_resolve.side_effect = mock_resolve

        council = Council("a|b|c!synthesize&reduce=0,-1", cache=tmp_cache)
        results = []
        async for intermediate in council.ask_progressive("What is dark matter?"):
            results.append(intermediate)

        assert len(results) == 2  # checkpoint 0 and checkpoint -1 (=2)
        # Each result should have a response
        assert all(r.response for r in results)

    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.0)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.0)
    async def test_no_reduce_param_falls_back(
        self, orch_cost, orch_resolve, synth_cost, synth_resolve, tmp_cache,
    ):
        """Without &reduce= param, yields once (full synthesis)."""
        def mock_resolve(model):
            adapter = MagicMock()
            adapter.provider = "mock"
            adapter.query = AsyncMock(return_value=AdapterResult(
                model=model, response=f"From {model}",
                tokens_in=10, tokens_out=5, provider="mock",
            ))
            return (adapter, model)

        orch_resolve.side_effect = mock_resolve
        synth_resolve.side_effect = mock_resolve

        council = Council("a|b", cache=tmp_cache)
        results = []
        async for intermediate in council.ask_progressive("test"):
            results.append(intermediate)

        assert len(results) == 1

    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.0)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.0)
    async def test_progressive_final_has_all_sources(
        self, orch_cost, orch_resolve, synth_cost, synth_resolve, tmp_cache,
    ):
        """The final yield should include all source results."""
        def mock_resolve(model):
            adapter = MagicMock()
            adapter.provider = "mock"
            adapter.query = AsyncMock(return_value=AdapterResult(
                model=model, response=f"From {model}",
                tokens_in=10, tokens_out=5, provider="mock",
            ))
            return (adapter, model)

        orch_resolve.side_effect = mock_resolve
        synth_resolve.side_effect = mock_resolve

        council = Council("a|b|c!test&reduce=0,-1", cache=tmp_cache)
        results = []
        async for intermediate in council.ask_progressive("test"):
            results.append(intermediate)

        # Final result should have all 3 sources
        final = results[-1]
        assert len(final.source_results) == 3

    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.0)
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.0)
    async def test_single_checkpoint_only(
        self, orch_cost, orch_resolve, synth_cost, synth_resolve, tmp_cache,
    ):
        """&reduce=0 yields once — just after first source."""
        def mock_resolve(model):
            adapter = MagicMock()
            adapter.provider = "mock"
            adapter.query = AsyncMock(return_value=AdapterResult(
                model=model, response=f"From {model}",
                tokens_in=10, tokens_out=5, provider="mock",
            ))
            return (adapter, model)

        orch_resolve.side_effect = mock_resolve
        synth_resolve.side_effect = mock_resolve

        council = Council("a|b|c!test&reduce=0", cache=tmp_cache)
        results = []
        async for intermediate in council.ask_progressive("test"):
            results.append(intermediate)

        assert len(results) == 1
