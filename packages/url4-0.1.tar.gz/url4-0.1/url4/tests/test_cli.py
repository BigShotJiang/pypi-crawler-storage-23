"""Tests for the url4 CLI."""

import json
import subprocess
import sys

import pytest


def _run_cli(*args, timeout=10):
    """Run url4 CLI and return (stdout, stderr, returncode)."""
    result = subprocess.run(
        [sys.executable, "-m", "url4", *args],
        capture_output=True, text=True, timeout=timeout,
    )
    return result.stdout, result.stderr, result.returncode


class TestCLIBasics:
    def test_version(self):
        out, _, rc = _run_cli("--version")
        assert rc == 0
        assert "url4" in out
        assert "0.1.0" in out

    def test_no_command_shows_help(self):
        out, _, rc = _run_cli()
        assert rc == 1

    def test_models(self):
        out, _, rc = _run_cli("models")
        assert rc == 0
        assert "anthropic" in out
        assert "openai" in out
        assert "claude" in out

    def test_cache_stats(self):
        out, _, rc = _run_cli("cache-stats")
        assert rc == 0
        assert "Cache entries" in out


class TestCLIEstimate:
    def test_estimate_text(self):
        out, _, rc = _run_cli("estimate", "claude-haiku|gpt-4o", "test")
        assert rc == 0
        assert "Estimated cost" in out
        assert "Sources: 2" in out

    def test_estimate_json(self):
        out, _, rc = _run_cli("estimate", "claude-haiku|gpt-4o", "test", "--json")
        assert rc == 0
        data = json.loads(out)
        assert "total_cost" in data
        assert "sources" in data
        assert len(data["sources"]) == 2

    def test_estimate_single_source(self):
        out, _, rc = _run_cli("estimate", "claude-haiku", "test")
        assert rc == 0
        assert "Sources: 1" in out

    def test_estimate_weighted(self):
        out, _, rc = _run_cli("estimate", "0.7*claude-haiku|0.3*gpt-4o", "test", "--json")
        assert rc == 0
        data = json.loads(out)
        assert data["sources"][0]["weight"] == 0.7
        assert data["sources"][1]["weight"] == 0.3


class TestCLIAsk:
    def test_ask_json_with_mock(self):
        """Test --json output structure (uses real adapters but validates format)."""
        # We can't easily mock in a subprocess, so just test that
        # the CLI parses args correctly and doesn't crash on setup
        # For a real test, we'd need the API keys
        pass

    def test_ask_missing_args(self):
        _, err, rc = _run_cli("ask")
        assert rc != 0
