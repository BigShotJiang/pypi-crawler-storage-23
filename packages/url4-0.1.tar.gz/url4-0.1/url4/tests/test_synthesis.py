"""Tests for synthesis (reduce step) and Council high-level API."""

import asyncio
from unittest.mock import AsyncMock, patch, MagicMock

import pytest

from url4.orchestrator import SourceResult
from url4.synthesis import synthesize, build_synthesis_prompt, SynthesisResult
from url4.council import Council
from url4.adapters.base import AdapterResult
from url4.cache import ResponseCache


# ── Helpers ─────────────────────────────────────────────────────────

def _make_source_result(source: str, response: str, weight: float | None = None) -> SourceResult:
    return SourceResult(
        source=source,
        weight=weight,
        response=response,
        tokens_in=10,
        tokens_out=5,
        latency_ms=100,
        cost=0.001,
        provider="mock",
        model_id=source,
        cache="MISS",
    )


def _mock_adapter_result(response: str) -> AdapterResult:
    return AdapterResult(
        model="mock-synth",
        response=response,
        tokens_in=100,
        tokens_out=50,
        latency_ms=200,
        cost=0.0,
        provider="mock",
    )


# ── Synthesis prompt building ───────────────────────────────────────

class TestBuildSynthesisPrompt:
    def test_includes_question(self):
        results = [_make_source_result("claude", "Paris")]
        prompt = build_synthesis_prompt(results, "What is the capital of France?")
        assert "What is the capital of France?" in prompt

    def test_includes_all_responses(self):
        results = [
            _make_source_result("claude", "Answer A"),
            _make_source_result("gpt", "Answer B"),
            _make_source_result("gemini", "Answer C"),
        ]
        prompt = build_synthesis_prompt(results, "test")
        assert "Answer A" in prompt
        assert "Answer B" in prompt
        assert "Answer C" in prompt

    def test_includes_weights(self):
        results = [
            _make_source_result("claude", "A", weight=0.6),
            _make_source_result("gpt", "B", weight=0.4),
        ]
        prompt = build_synthesis_prompt(results, "test")
        assert "weight=0.6" in prompt
        assert "weight=0.4" in prompt

    def test_includes_source_labels(self):
        results = [_make_source_result("claude-opus", "A")]
        prompt = build_synthesis_prompt(results, "test")
        assert "claude-opus" in prompt

    def test_uses_tag_as_label(self):
        r = _make_source_result("claude", "A")
        r.tag = "expert"
        prompt = build_synthesis_prompt([r], "test")
        assert "expert" in prompt

    def test_custom_reduce_instruction(self):
        results = [_make_source_result("claude", "A")]
        prompt = build_synthesis_prompt(results, "test", "Pick the shortest answer")
        assert "Pick the shortest answer" in prompt

    def test_skips_errored_responses(self):
        r1 = _make_source_result("claude", "Good answer")
        r2 = _make_source_result("gpt", "")
        r2.error = "API timeout"
        prompt = build_synthesis_prompt([r1, r2], "test")
        assert "Good answer" in prompt
        assert "ERROR" in prompt

    def test_response_count(self):
        results = [
            _make_source_result("a", "A"),
            _make_source_result("b", "B"),
            _make_source_result("c", "C"),
        ]
        prompt = build_synthesis_prompt(results, "test")
        assert "3 responses" in prompt


# ── Synthesize function ─────────────────────────────────────────────

class TestSynthesize:
    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.002)
    async def test_basic_synthesis(self, mock_cost, mock_resolve):
        mock_adapter = MagicMock()
        mock_adapter.query = AsyncMock(
            return_value=_mock_adapter_result("Synthesized answer")
        )
        mock_resolve.return_value = (mock_adapter, "claude-haiku")

        results = [
            _make_source_result("claude", "Answer A", weight=0.6),
            _make_source_result("gpt", "Answer B", weight=0.4),
        ]
        synth = await synthesize(results, "What is X?")

        assert synth.response == "Synthesized answer"
        assert synth.synthesis_cost == 0.002
        assert synth.total_cost == 0.002 + 0.001 + 0.001  # synthesis + 2 sources
        assert len(synth.source_results) == 2

    @pytest.mark.asyncio
    async def test_single_response_no_synthesis(self):
        """One model = no synthesis needed, just pass through."""
        results = [_make_source_result("claude", "Only answer")]
        synth = await synthesize(results, "test")

        assert synth.response == "Only answer"
        assert synth.synthesis_cost == 0.0
        assert synth.synthesis_model == ""

    @pytest.mark.asyncio
    async def test_no_valid_responses(self):
        """All models errored — empty response."""
        r1 = _make_source_result("claude", "")
        r1.error = "fail"
        r2 = _make_source_result("gpt", "")
        r2.error = "fail"
        synth = await synthesize([r1, r2], "test")

        assert synth.response == ""

    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.001)
    async def test_custom_reduce_instruction(self, mock_cost, mock_resolve):
        mock_adapter = MagicMock()
        mock_adapter.query = AsyncMock(
            return_value=_mock_adapter_result("Short answer")
        )
        mock_resolve.return_value = (mock_adapter, "claude-haiku")

        results = [
            _make_source_result("a", "Long answer A"),
            _make_source_result("b", "Long answer B"),
        ]
        synth = await synthesize(results, "test", reduce_instruction="Pick the shortest")

        # Verify the custom instruction was passed through
        call_args = mock_adapter.query.call_args
        prompt_sent = call_args[0][1]  # second positional arg
        assert "Pick the shortest" in prompt_sent

    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.001)
    async def test_custom_reduce_model(self, mock_cost, mock_resolve):
        mock_adapter = MagicMock()
        mock_adapter.query = AsyncMock(
            return_value=_mock_adapter_result("Answer")
        )
        mock_resolve.return_value = (mock_adapter, "gpt-4o-mini")

        results = [
            _make_source_result("a", "A"),
            _make_source_result("b", "B"),
        ]
        await synthesize(results, "test", reduce_model="gpt-4o-mini")
        mock_resolve.assert_called_with("gpt-4o-mini")


# ── SynthesisResult breakdown ───────────────────────────────────────

class TestSynthesisResultBreakdown:
    @pytest.mark.asyncio
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.002)
    async def test_breakdown_includes_all_sources_and_synthesis(self, mock_cost, mock_resolve):
        mock_adapter = MagicMock()
        mock_adapter.query = AsyncMock(
            return_value=_mock_adapter_result("Synth")
        )
        mock_resolve.return_value = (mock_adapter, "claude-haiku")

        results = [
            _make_source_result("claude", "A", weight=0.6),
            _make_source_result("gpt", "B", weight=0.4),
        ]
        synth = await synthesize(results, "test")
        bd = synth.breakdown

        assert len(bd) == 3  # 2 sources + 1 synthesis
        assert bd[0]["source"] == "claude"
        assert bd[0]["weight"] == 0.6
        assert bd[1]["source"] == "gpt"
        assert "synthesis" in bd[2]["source"]


# ── Council high-level API ──────────────────────────────────────────

class TestCouncil:
    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    @patch("url4.synthesis.resolve_adapter")
    @patch("url4.synthesis.estimate_cost", return_value=0.002)
    async def test_basic_council(self, synth_cost, synth_resolve, orch_cost, orch_resolve):
        # Mock fan-out adapters
        def mock_orch_adapter(model):
            adapter = MagicMock()
            adapter.provider = "mock"
            adapter.query = AsyncMock(
                return_value=AdapterResult(
                    model=model, response=f"Answer from {model}",
                    tokens_in=10, tokens_out=5, provider="mock",
                )
            )
            return (adapter, model)
        orch_resolve.side_effect = mock_orch_adapter

        # Mock synthesis adapter
        synth_adapter = MagicMock()
        synth_adapter.query = AsyncMock(
            return_value=_mock_adapter_result("Final synthesized answer")
        )
        synth_resolve.return_value = (synth_adapter, "claude-haiku")

        council = Council("claude|gpt-4o")
        result = await council.ask("What is 2+2?")

        assert result.response == "Final synthesized answer"
        assert result.total_cost > 0
        assert len(result.source_results) == 2

    @pytest.mark.asyncio
    @patch("url4.orchestrator.resolve_adapter")
    @patch("url4.orchestrator.estimate_cost", return_value=0.001)
    async def test_single_source_no_synthesis(self, mock_cost, mock_resolve):
        """Council with 1 source skips synthesis."""
        adapter = MagicMock()
        adapter.provider = "mock"
        adapter.query = AsyncMock(
            return_value=AdapterResult(
                model="claude", response="Direct answer",
                tokens_in=10, tokens_out=5, provider="mock",
            )
        )
        mock_resolve.return_value = (adapter, "claude")

        council = Council("claude")
        result = await council.ask("test")

        assert result.response == "Direct answer"
        assert result.synthesis_cost == 0.0

    def test_spec_without_bang(self):
        """Council should handle spec strings without ! separator."""
        c = Council("claude|gpt-4o")
        assert "{prompt}" in c._spec_template
