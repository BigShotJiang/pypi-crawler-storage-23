"""Tests for the Claude Code CLI adapter."""

import asyncio
from unittest.mock import patch, AsyncMock, MagicMock

import pytest

from url4.adapters.claude_code import ClaudeCodeAdapter, is_available
from url4.adapters.registry import resolve, resolve_adapter


# ── is_available ────────────────────────────────────────────────────

class TestIsAvailable:
    @patch("url4.adapters.claude_code.shutil.which", return_value="/usr/local/bin/claude")
    def test_available(self, mock_which):
        assert is_available() is True

    @patch("url4.adapters.claude_code.shutil.which", return_value=None)
    def test_not_available(self, mock_which):
        assert is_available() is False


# ── ClaudeCodeAdapter ───────────────────────────────────────────────

class TestClaudeCodeAdapter:
    @pytest.mark.asyncio
    async def test_successful_query(self):
        adapter = ClaudeCodeAdapter()

        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"4", b""))
        mock_proc.returncode = 0

        with patch("url4.adapters.claude_code.asyncio.create_subprocess_exec",
                    return_value=mock_proc) as mock_exec:
            result = await adapter.query("claude", "What is 2+2?")

            assert result.response == "4"
            assert result.provider == "claude-code"
            assert result.cost == 0.0
            # Verify CLAUDECODE is unset in env
            call_kwargs = mock_exec.call_args
            env = call_kwargs.kwargs.get("env", {}) if call_kwargs.kwargs else {}
            assert "CLAUDECODE" not in env

    @pytest.mark.asyncio
    async def test_error_handling(self):
        adapter = ClaudeCodeAdapter()

        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"", b"Some error"))
        mock_proc.returncode = 1

        with patch("url4.adapters.claude_code.asyncio.create_subprocess_exec",
                    return_value=mock_proc):
            result = await adapter.query("claude", "test")

            assert result.response == ""
            assert result.metadata.get("error") == "Some error"

    @pytest.mark.asyncio
    async def test_passes_prompt_to_cli(self):
        adapter = ClaudeCodeAdapter()

        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"ok", b""))
        mock_proc.returncode = 0

        with patch("url4.adapters.claude_code.asyncio.create_subprocess_exec",
                    return_value=mock_proc) as mock_exec:
            await adapter.query("claude", "My test prompt")

            args = mock_exec.call_args[0]
            assert args == ("claude", "-p", "My test prompt")


# ── Registry fallback ──────────────────────────────────────────────

class TestRegistryFallback:
    def setup_method(self):
        from url4.adapters import registry
        registry._adapter_cache.clear()

    def test_claude_falls_back_to_cli(self, monkeypatch):
        """With no ANTHROPIC_API_KEY and no OPENROUTER_API_KEY,
        claude should fall back to claude-code if CLI is available."""
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)

        with patch("url4.adapters.claude_code.is_available", return_value=True):
            prov, model_id, config = resolve("claude")
            assert prov == "claude-code"
            assert config["protocol"] == "claude-code"

    def test_claude_prefers_api_key(self, monkeypatch):
        """With ANTHROPIC_API_KEY set, should use anthropic directly."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

        prov, model_id, config = resolve("claude")
        assert prov == "anthropic"

    def test_adapter_creation(self, monkeypatch):
        """resolve_adapter should return ClaudeCodeAdapter when falling back."""
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)

        with patch("url4.adapters.claude_code.is_available", return_value=True):
            adapter, model_id = resolve_adapter("claude")
            assert isinstance(adapter, ClaudeCodeAdapter)
            assert adapter.provider == "claude-code"

    def test_unknown_model_falls_back_to_cli(self, monkeypatch):
        """Unknown models with no keys should also try claude-code."""
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)

        with patch("url4.adapters.claude_code.is_available", return_value=True):
            prov, model_id, config = resolve("some-unknown-model")
            assert prov == "claude-code"
