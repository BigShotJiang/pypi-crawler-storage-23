"""Tests for cost estimation."""

import pytest

from url4.parser import parse
from url4.estimator import estimate_query, CostEstimate, _estimate_tokens
from url4.cache import ResponseCache
from url4.council import Council


# ── Token estimation ────────────────────────────────────────────────

class TestTokenEstimation:
    def test_short_text(self):
        assert _estimate_tokens("hi") >= 1

    def test_longer_text(self):
        tokens = _estimate_tokens("What is the meaning of life?")
        assert 5 <= tokens <= 15  # ~7 tokens


# ── Cost estimation ─────────────────────────────────────────────────

class TestEstimateQuery:
    @pytest.fixture
    def tmp_cache(self, tmp_path):
        return ResponseCache(db_path=tmp_path / "test.db")

    def test_single_source(self, tmp_cache, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test")
        spec = parse("claude-haiku!test")
        est = estimate_query(spec, "What is 2+2?", cache=tmp_cache)

        assert len(est.sources) == 1
        assert est.sources[0].source == "claude-haiku"
        assert est.sources[0].estimated_cost > 0
        assert est.sources[0].cached is False
        assert est.synthesis_estimate is None  # single source = no synthesis
        assert est.total_cost > 0

    def test_multi_source(self, tmp_cache, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test")
        monkeypatch.setenv("OPENAI_API_KEY", "test")
        spec = parse("claude-haiku|gpt-4o!test")
        est = estimate_query(spec, "What is 2+2?", cache=tmp_cache)

        assert len(est.sources) == 2
        assert est.synthesis_estimate is not None
        assert est.total_cost > 0
        assert est.total_count == 2
        assert est.cached_count == 0

    def test_cached_source_reduces_cost(self, tmp_cache, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test")
        spec = parse("claude-haiku!test")

        # Estimate before cache
        est1 = estimate_query(spec, "What is 2+2?", cache=tmp_cache)
        cost_before = est1.total_cost

        # Simulate cache hit by storing a response
        from url4.adapters.registry import resolve
        _, model_id, _ = resolve("claude-haiku")
        tmp_cache.put(model_id, "What is 2+2?", {"response": "4"})

        # Estimate after cache
        est2 = estimate_query(spec, "What is 2+2?", cache=tmp_cache)
        assert est2.sources[0].cached is True
        assert est2.total_cost == 0.0  # cached = free
        assert est2.savings == cost_before
        assert est2.cached_count == 1

    def test_weights_preserved(self, tmp_cache, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test")
        monkeypatch.setenv("OPENAI_API_KEY", "test")
        spec = parse("0.7*claude-haiku|0.3*gpt-4o!test")
        est = estimate_query(spec, "test", cache=tmp_cache)

        assert est.sources[0].weight == 0.7
        assert est.sources[1].weight == 0.3

    def test_full_cost_vs_total_cost(self, tmp_cache, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test")
        spec = parse("claude-haiku|claude-haiku!test")
        est = estimate_query(spec, "test", cache=tmp_cache)

        # Nothing cached — full_cost == total_cost
        assert est.full_cost == est.total_cost
        assert est.savings == 0.0


# ── Council.estimate() ──────────────────────────────────────────────

class TestCouncilEstimate:
    @pytest.fixture
    def tmp_cache(self, tmp_path):
        return ResponseCache(db_path=tmp_path / "test.db")

    def test_basic_estimate(self, tmp_cache, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test")
        council = Council("claude-haiku|claude-haiku", cache=tmp_cache)
        est = council.estimate("What is the meaning of life?")

        assert isinstance(est, CostEstimate)
        assert est.total_cost > 0
        assert est.total_count == 2
        assert est.cached_count == 0

    def test_estimate_is_sync(self, tmp_cache, monkeypatch):
        """estimate() should be synchronous (no await needed)."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test")
        council = Council("claude-haiku", cache=tmp_cache)
        # This should work without asyncio.run()
        est = council.estimate("test")
        assert est.total_cost > 0
