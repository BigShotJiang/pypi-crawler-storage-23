"""Tests for the url4 response cache."""

import time
import tempfile
from pathlib import Path

import pytest
from url4.cache import ResponseCache


@pytest.fixture
def cache(tmp_path):
    """Fresh cache in a temp directory."""
    c = ResponseCache(db_path=tmp_path / "test_cache.db", default_ttl=3600)
    yield c
    c.close()


class TestBasicCaching:
    def test_put_and_get(self, cache):
        response = {"text": "The answer is 42", "tokens": 10}
        cache.put("claude-opus-4", "What is the meaning of life?", response)

        entry = cache.get("claude-opus-4", "What is the meaning of life?")
        assert entry is not None
        assert entry.response == response
        assert entry.model == "claude-opus-4"

    def test_cache_miss(self, cache):
        entry = cache.get("claude-opus-4", "never asked this")
        assert entry is None

    def test_same_key_deterministic(self, cache):
        key1 = cache.make_key("claude", "hello", {"temp": "0.7"})
        key2 = cache.make_key("claude", "hello", {"temp": "0.7"})
        assert key1 == key2

    def test_different_model_different_key(self, cache):
        key1 = cache.make_key("claude", "hello")
        key2 = cache.make_key("gpt", "hello")
        assert key1 != key2

    def test_different_prompt_different_key(self, cache):
        key1 = cache.make_key("claude", "hello")
        key2 = cache.make_key("claude", "goodbye")
        assert key1 != key2

    def test_different_params_different_key(self, cache):
        key1 = cache.make_key("claude", "hello", {"temp": "0.7"})
        key2 = cache.make_key("claude", "hello", {"temp": "1.0"})
        assert key1 != key2

    def test_overwrite_existing(self, cache):
        cache.put("claude", "q", {"v": 1})
        cache.put("claude", "q", {"v": 2})
        entry = cache.get("claude", "q")
        assert entry.response == {"v": 2}


class TestTTL:
    def test_entry_not_expired(self, cache):
        cache.put("claude", "q", {"v": 1}, ttl=3600)
        entry = cache.get("claude", "q")
        assert entry is not None
        assert not entry.expired

    def test_entry_expired(self, tmp_path):
        cache = ResponseCache(db_path=tmp_path / "ttl.db", default_ttl=1)
        cache.put("claude", "q", {"v": 1}, ttl=1)
        time.sleep(1.1)
        entry = cache.get("claude", "q")
        assert entry is None
        cache.close()

    def test_cleanup_expired(self, tmp_path):
        cache = ResponseCache(db_path=tmp_path / "cleanup.db", default_ttl=1)
        cache.put("claude", "q1", {"v": 1}, ttl=1)
        cache.put("claude", "q2", {"v": 2}, ttl=3600)
        time.sleep(1.1)
        removed = cache.cleanup_expired()
        assert removed == 1
        assert cache.get("claude", "q2") is not None
        cache.close()


class TestDelete:
    def test_delete_existing(self, cache):
        cache.put("claude", "q", {"v": 1})
        assert cache.delete("claude", "q") is True
        assert cache.get("claude", "q") is None

    def test_delete_nonexistent(self, cache):
        assert cache.delete("claude", "never") is False

    def test_clear_all(self, cache):
        cache.put("claude", "q1", {"v": 1})
        cache.put("gpt", "q2", {"v": 2})
        cache.put("gemini", "q3", {"v": 3})
        count = cache.clear()
        assert count == 3
        assert cache.get("claude", "q1") is None


class TestStats:
    def test_empty_stats(self, cache):
        stats = cache.stats()
        assert stats.total_entries == 0
        assert stats.total_bytes == 0
        assert stats.hit_rate == 0.0

    def test_stats_after_operations(self, cache):
        cache.put("claude", "q1", {"text": "hello"})
        cache.put("gpt", "q2", {"text": "world"})

        # One hit, one miss
        cache.get("claude", "q1")  # hit
        cache.get("claude", "unknown")  # miss

        stats = cache.stats()
        assert stats.total_entries == 2
        assert stats.total_bytes > 0
        assert stats.hits == 1
        assert stats.misses == 1
        assert stats.hit_rate == 0.5


class TestCacheKeyConsistency:
    """Ensure cache keys are stable across runs — critical for eval caching."""

    def test_key_stability(self, cache):
        # These keys must NEVER change — cached eval data depends on them
        key = cache.make_key(
            "openrouter.highcouncil.ai/claude-opus-4",
            "What is the capital of France?",
            {"temperature": "0"},
        )
        # Key is a sha256 hex — 64 chars
        assert len(key) == 64
        # Same inputs always produce same key
        key2 = cache.make_key(
            "openrouter.highcouncil.ai/claude-opus-4",
            "What is the capital of France?",
            {"temperature": "0"},
        )
        assert key == key2

    def test_param_order_irrelevant(self, cache):
        key1 = cache.make_key("claude", "q", {"a": "1", "b": "2"})
        key2 = cache.make_key("claude", "q", {"b": "2", "a": "1"})
        assert key1 == key2  # json.dumps with sort_keys=True
