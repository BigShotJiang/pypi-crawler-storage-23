"""Tests for the registry-driven adapter layer."""

import json
import os
import pytest

from url4.adapters.registry import (
    resolve, resolve_adapter, estimate_cost, list_models,
    _load_registry, _is_url, _is_localhost,
)
from url4.adapters.base import AdapterResult
from url4.adapters.anthropic import AnthropicAdapter
from url4.adapters.openai import OpenAIAdapter
from url4.adapters.ollama import OllamaAdapter


# ── Registry loading ────────────────────────────────────────────────

class TestRegistryLoading:
    def test_loads_valid_json(self):
        reg = _load_registry()
        assert "providers" in reg
        assert "models" in reg

    def test_has_core_providers(self):
        reg = _load_registry()
        providers = reg["providers"]
        assert "anthropic" in providers
        assert "openai" in providers
        assert "openrouter" in providers

    def test_has_core_models(self):
        reg = _load_registry()
        models = reg["models"]
        assert "claude" in models
        assert "gpt-4o" in models
        assert "claude-haiku" in models

    def test_model_entries_have_providers(self):
        reg = _load_registry()
        for name, entry in reg["models"].items():
            assert "providers" in entry, f"{name} missing 'providers'"
            assert len(entry["providers"]) > 0, f"{name} has no providers"

    def test_provider_entries_have_model_id(self):
        reg = _load_registry()
        for model_name, entry in reg["models"].items():
            for prov, prov_entry in entry["providers"].items():
                assert "model_id" in prov_entry, f"{model_name}/{prov} missing 'model_id'"


# ── URL and localhost detection ─────────────────────────────────────

class TestURLDetection:
    def test_http_url(self):
        assert _is_url("http://api.example.com/v1")
        assert _is_url("https://api.example.com/v1")

    def test_not_url(self):
        assert not _is_url("claude-haiku")
        assert not _is_url("gpt-4o")
        assert not _is_url("localhost:11434/llama3")

    def test_localhost(self):
        assert _is_localhost("localhost:11434/llama3")
        assert _is_localhost("127.0.0.1:11434/mistral")

    def test_not_localhost(self):
        assert not _is_localhost("claude")
        assert not _is_localhost("https://api.openai.com/v1")


# ── Model resolution ───────────────────────────────────────────────

class TestResolve:
    def test_claude_resolves_to_anthropic(self, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test")
        prov, model_id, config = resolve("claude")
        assert prov == "anthropic"
        assert "claude" in model_id  # full API model ID
        assert config["protocol"] == "anthropic"

    def test_gpt4o_resolves_to_openai(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "test")
        prov, model_id, config = resolve("gpt-4o")
        assert prov == "openai"
        assert model_id == "gpt-4o"
        assert config["protocol"] == "openai"

    def test_claude_haiku_resolves(self, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test")
        prov, model_id, config = resolve("claude-haiku")
        assert prov == "anthropic"
        assert "haiku" in model_id

    def test_gemini_resolves_to_openrouter(self):
        """Gemini has no direct API key — should find openrouter or groq."""
        prov, model_id, config = resolve("gemini")
        # Will resolve to whatever provider has a key, or first listed
        assert prov in ("openrouter", "groq")

    def test_raw_url_resolves_to_custom(self):
        prov, model_id, config = resolve("https://api.mycompany.com/v1/my-model")
        assert prov == "custom"
        assert config["protocol"] == "openai"

    def test_localhost_resolves_to_ollama(self):
        prov, model_id, config = resolve("localhost:11434/llama3")
        assert prov == "ollama"
        assert model_id == "llama3"
        assert config["protocol"] == "ollama"
        assert "localhost:11434" in config["base_url"]

    def test_unknown_model_defaults_openai(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "test")
        prov, model_id, config = resolve("some-totally-unknown-model")
        assert prov == "openai"
        assert model_id == "some-totally-unknown-model"

    def test_key_fallback(self, monkeypatch):
        """If ANTHROPIC_API_KEY is unset but OPENROUTER_API_KEY is set,
        claude should fall back to openrouter."""
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.setenv("OPENROUTER_API_KEY", "test-key")

        # Clear cached adapters
        from url4.adapters import registry
        registry._adapter_cache.clear()

        prov, model_id, config = resolve("claude")
        assert prov == "openrouter"
        assert config["protocol"] == "openai"  # openrouter uses openai protocol

    def test_prefers_native_when_key_present(self, monkeypatch):
        """If ANTHROPIC_API_KEY is set, claude should use anthropic directly."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

        prov, model_id, config = resolve("claude")
        assert prov == "anthropic"


# ── Cost estimation ─────────────────────────────────────────────────

class TestCostEstimation:
    def test_claude_cost(self):
        # claude-sonnet-4-5: $3/M input, $15/M output
        cost = estimate_cost("claude", 1000, 500)
        expected = (1000 * 3.0 + 500 * 15.0) / 1_000_000
        assert abs(cost - expected) < 0.0001

    def test_claude_opus_cost(self):
        # Opus: $15/M input, $75/M output
        cost = estimate_cost("claude-opus", 1000, 500)
        expected = (1000 * 15.0 + 500 * 75.0) / 1_000_000
        assert abs(cost - expected) < 0.0001

    def test_gpt4o_cost(self):
        # GPT-4o: $2.50/M input, $10/M output
        cost = estimate_cost("gpt-4o", 1000, 500)
        expected = (1000 * 2.50 + 500 * 10.0) / 1_000_000
        assert abs(cost - expected) < 0.0001

    def test_unknown_model_zero_cost(self):
        assert estimate_cost("unknown-model", 1000, 500) == 0.0


# ── Adapter creation ────────────────────────────────────────────────

class TestResolveAdapter:
    def setup_method(self):
        """Clear adapter cache between tests."""
        from url4.adapters import registry
        registry._adapter_cache.clear()

    def test_claude_gets_anthropic_adapter(self, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test")
        adapter, model_id = resolve_adapter("claude")
        assert isinstance(adapter, AnthropicAdapter)
        assert "claude" in model_id

    def test_gpt_gets_openai_adapter(self, monkeypatch):
        monkeypatch.setenv("OPENAI_API_KEY", "test")
        adapter, model_id = resolve_adapter("gpt-4o")
        assert isinstance(adapter, OpenAIAdapter)

    def test_localhost_gets_ollama_adapter(self):
        adapter, model_id = resolve_adapter("localhost:11434/llama3")
        assert isinstance(adapter, OllamaAdapter)
        assert model_id == "llama3"

    def test_raw_url_gets_openai_adapter(self):
        adapter, model_id = resolve_adapter("https://api.example.com/v1/my-model")
        assert isinstance(adapter, OpenAIAdapter)
        assert adapter.provider == "custom"

    def test_returns_model_id(self, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test")
        adapter, model_id = resolve_adapter("claude-haiku")
        assert "haiku" in model_id
        # model_id should be the full API ID, not the short name
        assert model_id != "claude-haiku"


# ── AdapterResult ────────────────────────────────────────────────────

class TestAdapterResult:
    def test_to_dict(self):
        r = AdapterResult(
            model="claude-opus-4-20250514",
            response="Four.",
            tokens_in=10,
            tokens_out=5,
            latency_ms=200,
            cost=0.001,
            provider="anthropic",
            metadata={"stop_reason": "end_turn"},
        )
        d = r.to_dict()
        assert d["model"] == "claude-opus-4-20250514"
        assert d["response"] == "Four."
        assert d["tokens_in"] == 10
        assert d["cost"] == 0.001
        assert d["metadata"]["stop_reason"] == "end_turn"

    def test_defaults(self):
        r = AdapterResult(model="test", response="hi")
        assert r.tokens_in == 0
        assert r.cost == 0.0
        assert r.metadata == {}


# ── list_models ──────────────────────────────────────────────────────

class TestListModels:
    def test_has_providers(self):
        models = list_models()
        assert "anthropic" in models
        assert "openai" in models

    def test_models_sorted(self):
        models = list_models()
        for provider, names in models.items():
            assert names == sorted(names), f"{provider} models not sorted"

    def test_includes_custom_and_ollama(self):
        models = list_models()
        assert "custom" in models
        assert "ollama" in models
