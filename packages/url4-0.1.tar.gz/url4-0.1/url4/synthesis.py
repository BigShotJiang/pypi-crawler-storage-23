"""Synthesis (reduce step) — combine multiple model responses into one.

Takes fan-out results and calls a synthesis model to produce
a single, better answer. This is the "reduce" in map-reduce.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from url4.orchestrator import SourceResult
from url4.adapters.registry import resolve_adapter, estimate_cost
from url4.adapters.base import AdapterResult


# Default synthesis model — cheap and fast
DEFAULT_REDUCE_MODEL = "claude-haiku"


@dataclass
class SynthesisResult:
    """Result of a full ensemble: fan-out + synthesis."""

    response: str
    """The synthesized answer."""

    source_results: list[SourceResult] = field(default_factory=list)
    """Individual model responses from the fan-out."""

    synthesis_cost: float = 0.0
    """Cost of the synthesis step alone."""

    total_cost: float = 0.0
    """Total cost: fan-out + synthesis."""

    synthesis_tokens_in: int = 0
    synthesis_tokens_out: int = 0
    synthesis_latency_ms: int = 0
    synthesis_model: str = ""

    @property
    def depth(self) -> int:
        """Nesting depth. 1 = flat council, 2+ = nested councils."""
        if not self.source_results:
            return 1
        max_inner = 0
        for r in self.source_results:
            if r.source.startswith("[") and r.source != "[synthesis":
                max_inner = max(max_inner, 1)
        return 1 + max_inner

    @property
    def breakdown(self) -> list[dict]:
        """Per-model cost/cache breakdown for display."""
        rows = []
        for r in self.source_results:
            rows.append({
                "source": r.source,
                "weight": r.weight,
                "cost": r.cost,
                "cache": r.cache,
                "latency_ms": r.latency_ms,
                "tokens_in": r.tokens_in,
                "tokens_out": r.tokens_out,
                "response_preview": r.response[:100] if r.response else "",
            })
        rows.append({
            "source": f"[synthesis: {self.synthesis_model}]",
            "weight": None,
            "cost": self.synthesis_cost,
            "cache": "",
            "latency_ms": self.synthesis_latency_ms,
            "tokens_in": self.synthesis_tokens_in,
            "tokens_out": self.synthesis_tokens_out,
            "response_preview": self.response[:100] if self.response else "",
        })
        return rows


def build_synthesis_prompt(
    source_results: list[SourceResult],
    original_prompt: str,
    reduce_instruction: str | None = None,
) -> str:
    """Build the prompt sent to the synthesis model.

    Includes all source responses with labels, weights, and the
    original question. The reduce_instruction controls synthesis style.
    """
    if not reduce_instruction:
        reduce_instruction = (
            "Synthesize the most accurate and complete answer from the "
            "responses below. Weight higher-weighted sources more heavily. "
            "If sources disagree, reason about which is most likely correct. "
            "Give a direct answer — do not mention that multiple models were consulted."
        )

    parts = [
        f"QUESTION: {original_prompt}\n",
        f"INSTRUCTION: {reduce_instruction}\n",
        f"You have received {len(source_results)} responses:\n",
    ]

    for i, r in enumerate(source_results, 1):
        if r.error:
            parts.append(f"--- Response {i} ({r.source}, ERROR: {r.error}) ---\n")
            continue
        label = r.tag or r.source
        weight_str = f", weight={r.weight}" if r.weight is not None else ""
        parts.append(f"--- Response {i} ({label}{weight_str}) ---")
        parts.append(r.response.strip())
        parts.append("")

    parts.append("--- Your synthesized answer ---")

    return "\n".join(parts)


async def synthesize(
    source_results: list[SourceResult],
    original_prompt: str,
    reduce_model: str = DEFAULT_REDUCE_MODEL,
    reduce_instruction: str | None = None,
) -> SynthesisResult:
    """Synthesize multiple model responses into one answer.

    Args:
        source_results: Results from fan_out().
        original_prompt: The original user question.
        reduce_model: Model to use for synthesis (default: claude-haiku).
        reduce_instruction: Custom synthesis instruction (from &reduce= param).

    Returns:
        SynthesisResult with the synthesized answer and cost breakdown.
    """
    # Filter to only successful responses
    valid_results = [r for r in source_results if r.response and not r.error]

    if not valid_results:
        return SynthesisResult(
            response="",
            source_results=source_results,
            total_cost=sum(r.cost for r in source_results),
        )

    # If only one response, return it directly (no synthesis needed)
    if len(valid_results) == 1:
        r = valid_results[0]
        return SynthesisResult(
            response=r.response,
            source_results=source_results,
            total_cost=sum(r.cost for r in source_results),
        )

    # Build synthesis prompt
    prompt = build_synthesis_prompt(valid_results, original_prompt, reduce_instruction)

    # Call synthesis model
    adapter, model_id = resolve_adapter(reduce_model)
    result = await adapter.query(model_id, prompt)

    synthesis_cost = estimate_cost(reduce_model, result.tokens_in, result.tokens_out)
    fan_out_cost = sum(r.cost for r in source_results)

    return SynthesisResult(
        response=result.response,
        source_results=source_results,
        synthesis_cost=synthesis_cost,
        total_cost=fan_out_cost + synthesis_cost,
        synthesis_tokens_in=result.tokens_in,
        synthesis_tokens_out=result.tokens_out,
        synthesis_latency_ms=result.latency_ms,
        synthesis_model=model_id,
    )
