"""Adapter registry — resolves model names to the right provider.

Resolution is driven by url4/data/models.json (the model registry).
Any raw URL (https://...) is treated as an OpenAI-compatible leaf node.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

from url4.adapters.base import BaseAdapter, AdapterResult

# ── Registry loading ────────────────────────────────────────────────

_DATA_DIR = Path(__file__).parent.parent / "data"
_REGISTRY: dict | None = None


def _load_registry() -> dict:
    """Load the model registry JSON (cached after first load)."""
    global _REGISTRY
    if _REGISTRY is None:
        with open(_DATA_DIR / "models.json") as f:
            _REGISTRY = json.load(f)
    return _REGISTRY


def _has_key(env_var: str) -> bool:
    return bool(os.environ.get(env_var, ""))


# ── Resolution ──────────────────────────────────────────────────────

def _is_url(model: str) -> bool:
    """Check if model string is a raw URL."""
    return model.startswith("http://") or model.startswith("https://")


def _is_localhost(model: str) -> bool:
    return model.startswith("localhost") or model.startswith("127.0.0.1")


def _is_claude_model(model: str) -> bool:
    return model.lower().startswith("claude")


def resolve(model: str) -> tuple[str, str, dict]:
    """Resolve a model name to (provider_name, model_id, provider_config).

    Resolution order:
    1. Raw URL (https://...) → OpenAI-compatible adapter pointed at that URL
    2. localhost/127.0.0.1 → Ollama
    3. Registry lookup → pick first provider where user has a key
    4. Unknown → pass through as-is to OpenAI (most common format)

    Returns:
        (provider_name, model_id, provider_config)
        provider_config has: protocol, base_url, key_env
    """
    # 1. Raw URL — treat as direct OpenAI-compatible endpoint
    if _is_url(model):
        # Split "https://api.example.com/v1/some-model" into base_url + model
        # Convention: everything up to /v1 is base_url, rest is model
        # If no clear split, use the whole URL as base_url and model as-is
        return ("custom", model, {
            "protocol": "openai",
            "base_url": model.rsplit("/", 1)[0] if "/" in model.split("//", 1)[-1] else model,
            "key_env": "",
        })

    # 2. Localhost → Ollama
    if _is_localhost(model):
        base_url = "http://localhost:11434"
        if ":" in model:
            parts = model.split("/")
            base_url = f"http://{parts[0]}"
        model_name = model.split("/")[-1] if "/" in model else model
        return ("ollama", model_name, {
            "protocol": "ollama",
            "base_url": base_url,
            "key_env": "",
        })

    # 3. Registry lookup
    registry = _load_registry()
    providers_config = registry.get("providers", {})
    model_entry = registry.get("models", {}).get(model)

    if model_entry:
        # Find the first provider where the user has a key set
        for prov_name, prov_model in model_entry["providers"].items():
            prov_config = providers_config.get(prov_name, {})
            key_env = prov_config.get("key_env", "")
            if not key_env or _has_key(key_env):
                model_id = prov_model.get("model_id", model)
                return (prov_name, model_id, prov_config)

        # No key found — try Claude Code CLI for Claude models
        if _is_claude_model(model):
            from url4.adapters.claude_code import is_available
            if is_available():
                return ("claude-code", model, {"protocol": "claude-code"})

        # No key found — return first provider anyway (will fail with auth error)
        first_prov = next(iter(model_entry["providers"]))
        prov_config = providers_config.get(first_prov, {})
        model_id = model_entry["providers"][first_prov].get("model_id", model)
        return (first_prov, model_id, prov_config)

    # 4. Unknown model — if no API keys at all, try Claude Code CLI
    if not any(_has_key(k) for k in ("OPENAI_API_KEY", "ANTHROPIC_API_KEY", "OPENROUTER_API_KEY")):
        from url4.adapters.claude_code import is_available
        if is_available():
            return ("claude-code", model, {"protocol": "claude-code"})

    # 5. Default to OpenAI
    return ("openai", model, providers_config.get("openai", {
        "protocol": "openai",
        "base_url": "https://api.openai.com/v1",
        "key_env": "OPENAI_API_KEY",
    }))


def estimate_cost(model: str, tokens_in: int, tokens_out: int) -> float:
    """Estimate cost in USD using registry pricing data."""
    registry = _load_registry()
    model_entry = registry.get("models", {}).get(model)
    if not model_entry:
        return 0.0

    # Use pricing from first provider that has it
    for _prov_name, prov_model in model_entry["providers"].items():
        input_price = prov_model.get("input_price")
        output_price = prov_model.get("output_price")
        if input_price is not None and output_price is not None:
            return (tokens_in * input_price + tokens_out * output_price) / 1_000_000

    return 0.0


# ── Adapter creation ────────────────────────────────────────────────

# Lazy imports to avoid circular deps
_adapter_cache: dict[str, BaseAdapter] = {}


def resolve_adapter(model: str) -> tuple[BaseAdapter, str]:
    """Get the right adapter and resolved model_id for a model name.

    Args:
        model: Short name ("claude-haiku"), full name ("claude-opus-4-20250514"),
               URL ("https://api.example.com/v1"), or localhost ("localhost:11434/llama3").

    Returns:
        (adapter, model_id) — the adapter to use and the model ID to pass to it.
    """
    provider_name, model_id, config = resolve(model)
    protocol = config.get("protocol", "openai")
    base_url = config.get("base_url", "")
    key_env = config.get("key_env", "")

    # Cache key includes base_url for custom endpoints
    cache_key = f"{protocol}:{base_url}" if base_url else protocol

    if cache_key not in _adapter_cache:
        if protocol == "claude-code":
            from url4.adapters.claude_code import ClaudeCodeAdapter
            _adapter_cache[cache_key] = ClaudeCodeAdapter()
        elif protocol == "anthropic":
            from url4.adapters.anthropic import AnthropicAdapter
            _adapter_cache[cache_key] = AnthropicAdapter(
                api_key=os.environ.get(key_env, "") if key_env else "",
            )
        elif protocol == "ollama":
            from url4.adapters.ollama import OllamaAdapter
            _adapter_cache[cache_key] = OllamaAdapter(base_url=base_url)
        else:
            # OpenAI-compatible (OpenAI, OpenRouter, Together, Groq, custom)
            from url4.adapters.openai import OpenAIAdapter
            _adapter_cache[cache_key] = OpenAIAdapter(
                api_key=os.environ.get(key_env, "") if key_env else "",
                base_url=base_url or None,
                provider_name=provider_name,
            )

    return (_adapter_cache[cache_key], model_id)


def list_models() -> dict[str, list[str]]:
    """List all known model short names grouped by their first provider."""
    registry = _load_registry()
    result: dict[str, list[str]] = {}
    for model_name, entry in registry.get("models", {}).items():
        first_provider = next(iter(entry.get("providers", {})), "unknown")
        result.setdefault(first_provider, []).append(model_name)
    for v in result.values():
        v.sort()
    result["custom"] = ["(any URL — e.g. https://myapi.com/v1/my-model)"]
    result["ollama"] = ["(any model on localhost:11434)"]
    return result
