"""Anthropic adapter for url4.

Thin protocol implementation — the Anthropic messages API differs from
the OpenAI format, so it needs its own adapter.

Model resolution and pricing live in the registry (url4/data/models.json),
not here.
"""

from __future__ import annotations

import os
import time
from collections.abc import AsyncGenerator

import anthropic

from url4.adapters.base import BaseAdapter, AdapterResult


class AnthropicAdapter(BaseAdapter):
    """Adapter for Anthropic Claude models."""

    provider = "anthropic"

    def __init__(self, api_key: str | None = None):
        self._api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")

    async def query(self, model: str, prompt: str, **kwargs) -> AdapterResult:
        max_tokens = kwargs.get("max_tokens", 4096)

        client = anthropic.AsyncAnthropic(api_key=self._api_key)
        start = time.time()

        message = await client.messages.create(
            model=model,
            max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}],
        )

        latency_ms = int((time.time() - start) * 1000)

        response_text = ""
        for block in message.content:
            if block.type == "text":
                response_text += block.text

        tokens_in = message.usage.input_tokens
        tokens_out = message.usage.output_tokens

        return AdapterResult(
            model=model,
            response=response_text,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=latency_ms,
            cost=0.0,  # cost estimated by registry, not adapter
            provider=self.provider,
            metadata={"stop_reason": message.stop_reason},
        )

    async def query_stream(
        self, model: str, prompt: str, **kwargs
    ) -> AsyncGenerator[str, None]:
        """Stream tokens from Anthropic using native streaming API."""
        max_tokens = kwargs.get("max_tokens", 4096)

        client = anthropic.AsyncAnthropic(api_key=self._api_key)

        async with client.messages.stream(
            model=model,
            max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}],
        ) as stream:
            async for text in stream.text_stream:
                yield text
