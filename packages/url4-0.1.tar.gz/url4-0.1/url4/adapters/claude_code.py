"""Claude Code CLI adapter for url4.

Uses the locally installed `claude` CLI to run prompts.
Zero API key config needed — uses whatever auth Claude Code
already has set up.

Falls back to this automatically when no API key is available
but the `claude` CLI is on PATH.
"""

from __future__ import annotations

import asyncio
import os
import shutil
import time

from url4.adapters.base import BaseAdapter, AdapterResult


def is_available() -> bool:
    """Check if the claude CLI is installed and on PATH."""
    return shutil.which("claude") is not None


class ClaudeCodeAdapter(BaseAdapter):
    """Adapter that shells out to the Claude Code CLI."""

    provider = "claude-code"

    async def query(self, model: str, prompt: str, **kwargs) -> AdapterResult:
        start = time.time()

        # Build env: inherit current env but unset CLAUDECODE
        # (prevents "cannot nest sessions" error)
        env = {k: v for k, v in os.environ.items() if k != "CLAUDECODE"}

        proc = await asyncio.create_subprocess_exec(
            "claude", "-p", prompt,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )
        stdout, stderr = await proc.communicate()

        latency_ms = int((time.time() - start) * 1000)

        if proc.returncode != 0:
            error_msg = stderr.decode().strip() if stderr else f"Exit code {proc.returncode}"
            return AdapterResult(
                model="claude-code",
                response="",
                latency_ms=latency_ms,
                provider=self.provider,
                metadata={"error": error_msg},
            )

        return AdapterResult(
            model="claude-code",
            response=stdout.decode().strip(),
            latency_ms=latency_ms,
            cost=0.0,  # billed through Claude Code subscription
            provider=self.provider,
        )
