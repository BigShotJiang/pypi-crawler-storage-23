"""OpenAI-compatible adapter for url4.

Thin protocol implementation — works with any service that speaks
the OpenAI chat completions API (OpenAI, OpenRouter, Together, Groq,
or any custom endpoint).

Model resolution and pricing live in the registry (url4/data/models.json),
not here.
"""

from __future__ import annotations

import os
import time
from collections.abc import AsyncGenerator

import openai

from url4.adapters.base import BaseAdapter, AdapterResult


class OpenAIAdapter(BaseAdapter):
    """Adapter for any OpenAI-compatible chat completions API."""

    provider = "openai"

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        provider_name: str = "openai",
    ):
        self._api_key = api_key or ""
        self._base_url = base_url
        self.provider = provider_name

    async def query(self, model: str, prompt: str, **kwargs) -> AdapterResult:
        max_tokens = kwargs.get("max_tokens", 4096)

        client_kwargs: dict = {}
        if self._api_key:
            client_kwargs["api_key"] = self._api_key
        if self._base_url:
            client_kwargs["base_url"] = self._base_url
        client = openai.AsyncOpenAI(**client_kwargs)
        start = time.time()

        response = await client.chat.completions.create(
            model=model,
            max_completion_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}],
        )

        latency_ms = int((time.time() - start) * 1000)

        text = response.choices[0].message.content or ""
        tokens_in = response.usage.prompt_tokens if response.usage else 0
        tokens_out = response.usage.completion_tokens if response.usage else 0

        return AdapterResult(
            model=model,
            response=text,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=latency_ms,
            cost=0.0,  # cost estimated by registry, not adapter
            provider=self.provider,
            metadata={
                "finish_reason": response.choices[0].finish_reason,
            },
        )

    async def query_stream(
        self, model: str, prompt: str, **kwargs
    ) -> AsyncGenerator[str, None]:
        """Stream tokens using OpenAI-compatible streaming API."""
        max_tokens = kwargs.get("max_tokens", 4096)

        client_kwargs: dict = {}
        if self._api_key:
            client_kwargs["api_key"] = self._api_key
        if self._base_url:
            client_kwargs["base_url"] = self._base_url
        client = openai.AsyncOpenAI(**client_kwargs)

        stream = await client.chat.completions.create(
            model=model,
            max_completion_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}],
            stream=True,
        )

        async for chunk in stream:
            if chunk.choices and chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content
