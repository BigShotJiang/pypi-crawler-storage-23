"""Ollama adapter for url4 — local models via localhost."""

from __future__ import annotations

import time

import httpx

from url4.adapters.base import BaseAdapter, AdapterResult

DEFAULT_BASE_URL = "http://localhost:11434"


class OllamaAdapter(BaseAdapter):
    """Adapter for local Ollama models."""

    provider = "ollama"

    def __init__(self, base_url: str = DEFAULT_BASE_URL):
        self.base_url = base_url.rstrip("/")

    async def query(self, model: str, prompt: str, **kwargs) -> AdapterResult:
        # Model might be "localhost:11434/llama3" — extract just the model name
        model_name = model.split("/")[-1] if "/" in model else model

        start = time.time()

        async with httpx.AsyncClient(timeout=120.0) as client:
            resp = await client.post(
                f"{self.base_url}/api/chat",
                json={
                    "model": model_name,
                    "messages": [{"role": "user", "content": prompt}],
                    "stream": False,
                },
            )
            resp.raise_for_status()
            data = resp.json()

        latency_ms = int((time.time() - start) * 1000)

        text = data.get("message", {}).get("content", "")
        tokens_in = data.get("prompt_eval_count", 0)
        tokens_out = data.get("eval_count", 0)

        return AdapterResult(
            model=model_name,
            response=text,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=latency_ms,
            cost=0.0,  # local models are free
            provider=self.provider,
            metadata={
                "total_duration": data.get("total_duration"),
                "model": data.get("model"),
            },
        )
