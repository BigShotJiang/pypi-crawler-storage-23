"""Base adapter interface for url4 providers."""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator
from dataclasses import dataclass, field


@dataclass
class AdapterResult:
    """Standardized response from any provider adapter."""

    model: str
    """Full model identifier used in the API call."""

    response: str
    """The text response from the model."""

    tokens_in: int = 0
    """Input/prompt tokens consumed."""

    tokens_out: int = 0
    """Output/completion tokens generated."""

    latency_ms: int = 0
    """Round-trip time in milliseconds."""

    cost: float = 0.0
    """Estimated cost in USD."""

    provider: str = ""
    """Provider name (anthropic, openai, google, ollama)."""

    metadata: dict = field(default_factory=dict)
    """Any extra provider-specific metadata."""

    def to_dict(self) -> dict:
        return {
            "model": self.model,
            "response": self.response,
            "tokens_in": self.tokens_in,
            "tokens_out": self.tokens_out,
            "latency_ms": self.latency_ms,
            "cost": self.cost,
            "provider": self.provider,
            "metadata": self.metadata,
        }


class BaseAdapter(ABC):
    """Abstract base for provider adapters."""

    provider: str = ""

    @abstractmethod
    async def query(self, model: str, prompt: str, **kwargs) -> AdapterResult:
        """Send a prompt to a model and return the result."""
        ...

    async def query_stream(
        self, model: str, prompt: str, **kwargs
    ) -> AsyncGenerator[str, None]:
        """Stream tokens from the model. Yields text chunks.

        Default implementation calls query() and yields the full response.
        Override for native streaming support.
        """
        result = await self.query(model, prompt, **kwargs)
        yield result.response

    @staticmethod
    def _timer() -> float:
        """Start a timer. Call time.time() - start to get elapsed."""
        return time.time()
