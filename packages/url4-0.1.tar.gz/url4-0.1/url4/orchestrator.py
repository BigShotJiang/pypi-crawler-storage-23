"""Orchestrator — fan-out to models, collect responses.

Takes a parsed url4 Spec and queries all sources in parallel,
returning structured results. No synthesis/reduce yet — that's
a separate step.

Cache integration: checks local cache before calling an adapter.
On miss, stores the response. Controlled by &cache= param:
  - "user" (default): check/store in local cache
  - "off": skip cache entirely
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator
from dataclasses import dataclass, field

from url4.parser import Spec, Source
from url4.adapters.registry import resolve_adapter, estimate_cost
from url4.adapters.base import AdapterResult
from url4.cache import ResponseCache, get_cache


@dataclass
class SourceResult:
    """Result from a single source in the fan-out."""

    source: str
    """Model name or URL that was queried."""

    weight: float | None
    """Weight from the spec, or None if unweighted."""

    response: str
    """The model's text response."""

    tokens_in: int = 0
    tokens_out: int = 0
    latency_ms: int = 0
    cost: float = 0.0
    provider: str = ""
    model_id: str = ""

    error: str | None = None
    """Error message if this source failed."""

    tag: str | None = None
    """Optional tag from the spec."""

    cache: str = ""
    """Cache status: 'HIT', 'MISS', or 'OFF'."""


async def _query_source(
    source: Source,
    prompt: str,
    timeout_ms: int | None = None,
    cache: ResponseCache | None = None,
    cache_mode: str = "user",
) -> SourceResult:
    """Query a single source (leaf node), with cache check."""
    model_name = source.url or ""

    try:
        adapter, model_id = resolve_adapter(model_name)

        # Check cache first (unless cache=off)
        if cache and cache_mode != "off":
            entry = cache.get(model_id, prompt)
            if entry:
                resp = entry.response
                return SourceResult(
                    source=model_name,
                    weight=source.weight,
                    response=resp.get("response", ""),
                    tokens_in=resp.get("tokens_in", 0),
                    tokens_out=resp.get("tokens_out", 0),
                    latency_ms=0,
                    cost=0.0,
                    provider=resp.get("provider", ""),
                    model_id=model_id,
                    tag=source.tag,
                    cache="HIT",
                )

        # Cache miss — call the adapter
        if timeout_ms:
            result = await asyncio.wait_for(
                adapter.query(model_id, prompt),
                timeout=timeout_ms / 1000.0,
            )
        else:
            result = await adapter.query(model_id, prompt)

        # Get cost from registry
        cost = estimate_cost(model_name, result.tokens_in, result.tokens_out)

        # Store in cache (unless cache=off)
        if cache and cache_mode != "off":
            cache.put(model_id, prompt, {
                "response": result.response,
                "tokens_in": result.tokens_in,
                "tokens_out": result.tokens_out,
                "provider": result.provider,
                "model_id": model_id,
            })

        return SourceResult(
            source=model_name,
            weight=source.weight,
            response=result.response,
            tokens_in=result.tokens_in,
            tokens_out=result.tokens_out,
            latency_ms=result.latency_ms,
            cost=cost,
            provider=result.provider,
            model_id=model_id,
            tag=source.tag,
            cache="OFF" if cache_mode == "off" else "MISS",
        )

    except asyncio.TimeoutError:
        return SourceResult(
            source=model_name,
            weight=source.weight,
            response="",
            error=f"Timeout after {timeout_ms}ms",
            tag=source.tag,
        )
    except Exception as e:
        return SourceResult(
            source=model_name,
            weight=source.weight,
            response="",
            error=str(e),
            tag=source.tag,
        )


async def fan_out(spec: Spec, cache: ResponseCache | None = None) -> list[SourceResult]:
    """Fan out a parsed spec to all sources in parallel.

    Queries all leaf-node sources concurrently using asyncio.gather().
    Nested specs are recursively fanned out (but not synthesized — that's
    the reduce step).

    Cache behavior controlled by spec.params["cache"]:
      - "user" (default): check/store in local cache
      - "off": skip cache entirely

    Args:
        spec: A parsed url4 Spec.
        cache: Optional cache instance. If None, uses the default cache.

    Returns:
        List of SourceResult, one per source, in the same order as spec.sources.
    """
    cache_mode = spec.params.get("cache", "user")
    if cache is None and cache_mode != "off":
        cache = get_cache()

    timeout_ms = None
    if "timeout" in spec.params:
        try:
            timeout_ms = int(spec.params["timeout"])
        except ValueError:
            pass

    tasks = []
    for source in spec.sources:
        if source.nested:
            tasks.append(_fan_out_nested(source, timeout_ms, cache, cache_mode))
        else:
            tasks.append(_query_source(source, spec.prompt, timeout_ms, cache, cache_mode))

    results = await asyncio.gather(*tasks)
    return list(results)


def _parse_checkpoints(reduce_param: str, num_sources: int) -> list[int]:
    """Parse &reduce=0,2,-1 into sorted list of source indices.

    Supports:
      - Non-negative integers: source index (0-based)
      - Negative integers: count from end (-1 = last source)
    """
    checkpoints = set()
    for part in reduce_param.split(","):
        part = part.strip()
        if not part:
            continue
        try:
            idx = int(part)
            if idx < 0:
                idx = num_sources + idx
            if 0 <= idx < num_sources:
                checkpoints.add(idx)
        except ValueError:
            continue
    return sorted(checkpoints)


async def fan_out_progressive(
    spec: Spec,
    checkpoints: list[int],
    cache: ResponseCache | None = None,
) -> AsyncGenerator[tuple[int, list[SourceResult]], None]:
    """Fan out to all sources, yielding results at checkpoint indices.

    All sources launch in parallel. At each checkpoint index,
    waits for that source to complete, then yields all completed
    results so far.

    Args:
        spec: Parsed url4 spec.
        checkpoints: Sorted list of source indices to yield at.
        cache: Optional cache instance.

    Yields:
        (checkpoint_index, completed_results) at each checkpoint.
    """
    cache_mode = spec.params.get("cache", "user")
    if cache is None and cache_mode != "off":
        cache = get_cache()

    timeout_ms = None
    if "timeout" in spec.params:
        try:
            timeout_ms = int(spec.params["timeout"])
        except ValueError:
            pass

    # Launch all sources as individual tasks
    tasks: list[asyncio.Task] = []
    for source in spec.sources:
        if source.nested:
            coro = _fan_out_nested(source, timeout_ms, cache, cache_mode)
        else:
            coro = _query_source(source, spec.prompt, timeout_ms, cache, cache_mode)
        tasks.append(asyncio.ensure_future(coro))

    results: list[SourceResult | None] = [None] * len(tasks)

    for cp in checkpoints:
        # Wait for the checkpoint source (and all prior checkpoints)
        # to complete
        await tasks[cp]
        results[cp] = tasks[cp].result()

        # Also collect any other tasks that have already completed
        for i, t in enumerate(tasks):
            if results[i] is None and t.done():
                results[i] = t.result()

        # Yield completed results (preserving order, filtering None)
        completed = [r for r in results if r is not None]
        yield (cp, completed)

    # Ensure all remaining tasks complete (don't leak)
    for i, t in enumerate(tasks):
        if results[i] is None:
            results[i] = await t


async def _fan_out_nested(
    source: Source,
    timeout_ms: int | None,
    cache: ResponseCache | None,
    cache_mode: str,
) -> SourceResult:
    """Handle a nested source — fan out inner spec and synthesize.

    Each bracket group is a mini-council: fan out to inner sources,
    then synthesize their responses into a single answer. The inner
    spec's prompt (after !) becomes the reduce instruction.
    """
    nested_spec = source.nested
    if not nested_spec:
        return SourceResult(
            source="[nested]",
            weight=source.weight,
            response="",
            error="Empty nested spec",
            tag=source.tag,
        )

    inner_results = await fan_out(nested_spec, cache=cache)

    # Synthesize inner results (lazy import to avoid circular dep)
    from url4.synthesis import synthesize, DEFAULT_REDUCE_MODEL

    reduce_model = nested_spec.params.get("reduce_model", DEFAULT_REDUCE_MODEL)
    reduce_instruction = nested_spec.prompt if nested_spec.prompt else None

    synth = await synthesize(
        source_results=inner_results,
        original_prompt=nested_spec.prompt or "",
        reduce_model=reduce_model,
        reduce_instruction=reduce_instruction,
    )

    return SourceResult(
        source=f"[{nested_spec.raw or 'nested'}]",
        weight=source.weight,
        response=synth.response,
        tokens_in=synth.synthesis_tokens_in + sum(r.tokens_in for r in inner_results),
        tokens_out=synth.synthesis_tokens_out + sum(r.tokens_out for r in inner_results),
        latency_ms=synth.synthesis_latency_ms + max((r.latency_ms for r in inner_results), default=0),
        cost=synth.total_cost,
        provider=f"nested:{len(inner_results)} sources",
        tag=source.tag,
    )
