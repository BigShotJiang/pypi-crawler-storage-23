"""
url4 URL parser.

Parses the url4 grammar into structured data:

    spec       = source-list "!" prompt [ "&" params ]
    source-list = source *( "|" source )
    source     = [ weight "*" ] ( url | "[" spec "]" ) [ hops ] [ "#" tag ] [ "~" epsilon ]
    hops       = 1*"<"
    weight     = float (0.0 to 1.0)
    epsilon    = float (0.0+)
    prompt     = token *( "+" token )

Extensions from PLAN.md:
    params may include: reduce, cache, nonce, timeout, view, estimate, key, wait, collect
    output pipe: spec [ ">" destination ]
"""

from __future__ import annotations

from dataclasses import dataclass, field
from urllib.parse import unquote_plus


@dataclass
class Source:
    """A single source in a url4 spec."""

    url: str | None = None
    """Raw URL or short model name. None if this source is a nested spec."""

    weight: float | None = None
    """Weight 0.0-1.0, or None if unweighted."""

    nested: Spec | None = None
    """Nested sub-spec if this source is a bracketed group."""

    hops: int = 0
    """Number of referral hops (< characters)."""

    tag: str | None = None
    """Optional tag after #."""

    epsilon: float | None = None
    """Privacy budget (differential privacy epsilon)."""


@dataclass
class Spec:
    """A parsed url4 spec — the content of a ?q= parameter."""

    sources: list[Source] = field(default_factory=list)
    """Ordered list of sources (mappers)."""

    prompt: str = ""
    """The prompt text (after the !)."""

    params: dict[str, str] = field(default_factory=dict)
    """Query parameters: reduce, cache, nonce, timeout, view, estimate, key, wait, collect."""

    destination: str | None = None
    """Output pipe destination (after >). None if no pipe."""

    raw: str = ""
    """Original unparsed string."""


class ParseError(Exception):
    """Raised when a url4 string cannot be parsed."""


def parse(raw: str) -> Spec:
    """Parse a url4 spec string into a Spec object.

    Accepts either a full URL (url4.ai/v1/?q=...) or just the spec part
    (source1|source2!prompt).

    Args:
        raw: The url4 string to parse.

    Returns:
        A Spec object with sources, prompt, and params.

    Raises:
        ParseError: If the string cannot be parsed.
    """
    if not raw or not raw.strip():
        raise ParseError("Empty spec string")

    text = raw.strip()

    # Extract spec from full URL if needed: anything after ?q=
    if "?q=" in text:
        text = text.split("?q=", 1)[1]

    # Decode URL encoding
    text = unquote_plus(text)

    # Parse output pipe (>) — but only at the top level (not inside brackets)
    destination = None
    pipe_pos = _find_top_level_char(text, ">")
    if pipe_pos is not None:
        append = False
        rest = text[pipe_pos + 1 :]
        if rest.startswith(">"):
            append = True
            rest = rest[1:]
        destination = rest.strip()
        if append:
            destination = ">>" + destination  # preserve >> vs > distinction
        text = text[:pipe_pos].rstrip()

    # Split params from spec: & at top level (not inside brackets)
    params = {}
    param_pos = _find_top_level_char(text, "&")
    if param_pos is not None:
        param_str = text[param_pos + 1 :]
        text = text[:param_pos]
        # Parse remaining params (may have multiple &)
        for part in _split_params(param_str):
            if "=" in part:
                k, v = part.split("=", 1)
                params[k.strip()] = v.strip()
            else:
                params[part.strip()] = "true"

    # Find the bang (!) at the top level — separates sources from prompt
    bang_pos = _find_top_level_char(text, "!")
    if bang_pos is None:
        raise ParseError(f"No '!' found in spec: {text!r}")

    sources_str = text[:bang_pos]
    prompt_str = text[bang_pos + 1 :]

    # Parse prompt: + is space
    prompt = prompt_str.replace("+", " ").strip()

    # Parse sources
    sources = _parse_source_list(sources_str)

    return Spec(
        sources=sources,
        prompt=prompt,
        params=params,
        destination=destination,
        raw=raw,
    )


def _parse_source_list(text: str) -> list[Source]:
    """Parse a pipe-separated list of sources."""
    if not text.strip():
        return []

    parts = _split_top_level(text, "|")
    sources = []
    for part in parts:
        part = part.strip()
        if part:
            sources.append(_parse_source(part))
    return sources


def _parse_source(text: str) -> Source:
    """Parse a single source: [weight*] (url | [spec]) [hops] [#tag] [~epsilon]"""
    text = text.strip()
    weight = None
    nested = None
    url = None
    hops = 0
    tag = None
    epsilon = None

    # Parse weight prefix: float*
    weight_end = _find_weight_prefix(text)
    if weight_end is not None:
        weight_str = text[:weight_end]
        try:
            weight = float(weight_str)
        except ValueError:
            raise ParseError(f"Invalid weight: {weight_str!r}")
        text = text[weight_end + 1 :]  # skip the *

    # Check for nested spec: [...]
    if text.startswith("["):
        bracket_end = _find_matching_bracket(text, 0)
        if bracket_end is None:
            raise ParseError(f"Unmatched bracket in: {text!r}")
        inner = text[1:bracket_end]
        nested = parse(inner)
        text = text[bracket_end + 1 :]
    else:
        # URL extends until we hit hops (<), tag (#), epsilon (~), or end
        url_end = len(text)
        for i, ch in enumerate(text):
            if ch in "<#~":
                url_end = i
                break
        url = text[:url_end].strip()
        text = text[url_end:]

    # Parse trailing modifiers: hops, tag, epsilon (in any order)
    while text:
        if text[0] == "<":
            count = 0
            while text and text[0] == "<":
                count += 1
                text = text[1:]
            hops = count
        elif text[0] == "#":
            text = text[1:]
            tag_end = len(text)
            for i, ch in enumerate(text):
                if ch in "<~":
                    tag_end = i
                    break
            tag = text[:tag_end].strip()
            text = text[tag_end:]
        elif text[0] == "~":
            text = text[1:]
            eps_end = len(text)
            for i, ch in enumerate(text):
                if ch in "<#":
                    eps_end = i
                    break
            try:
                epsilon = float(text[:eps_end].strip())
            except ValueError:
                raise ParseError(f"Invalid epsilon: {text[:eps_end]!r}")
            text = text[eps_end:]
        else:
            break

    return Source(
        url=url if url else None,
        weight=weight,
        nested=nested,
        hops=hops,
        tag=tag,
        epsilon=epsilon,
    )


def _find_weight_prefix(text: str) -> int | None:
    """Find the position of * in a weight prefix like '0.4*'.

    Returns the index of *, or None if no weight prefix.
    Only matches if the part before * looks like a number.
    """
    star = text.find("*")
    if star == -1:
        return None
    prefix = text[:star]
    try:
        float(prefix)
        return star
    except ValueError:
        return None


def _find_top_level_char(text: str, char: str) -> int | None:
    """Find first occurrence of char at nesting level 0 (outside brackets)."""
    depth = 0
    for i, ch in enumerate(text):
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
        elif ch == char and depth == 0:
            return i
    return None


def _split_top_level(text: str, sep: str) -> list[str]:
    """Split text by sep, but only at nesting level 0."""
    parts = []
    depth = 0
    current = []
    for ch in text:
        if ch == "[":
            depth += 1
            current.append(ch)
        elif ch == "]":
            depth -= 1
            current.append(ch)
        elif ch == sep and depth == 0:
            parts.append("".join(current))
            current = []
        else:
            current.append(ch)
    parts.append("".join(current))
    return parts


def _find_matching_bracket(text: str, start: int) -> int | None:
    """Find the matching ] for the [ at position start."""
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "[":
            depth += 1
        elif text[i] == "]":
            depth -= 1
            if depth == 0:
                return i
    return None


def _split_params(text: str) -> list[str]:
    """Split parameter string by & at top level."""
    return _split_top_level(text, "&")
