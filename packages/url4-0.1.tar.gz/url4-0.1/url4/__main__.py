"""CLI for url4 — run ensembles from the command line.

Usage:
    python -m url4 ask "claude-haiku|gpt-4o-mini" "What is 2+2?"
    python -m url4 ask "claude|gpt-4o!synthesize" "Explain gravity" --json
    python -m url4 estimate "claude-opus|gpt-4o" "anything"
    python -m url4 cache-stats
    python -m url4 models
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys

from url4 import __version__


def main():
    parser = argparse.ArgumentParser(
        prog="url4",
        description="The open protocol for AI model ensembles.",
    )
    parser.add_argument("--version", action="version", version=f"url4 {__version__}")

    sub = parser.add_subparsers(dest="command")

    # ── ask ─────────────────────────────────────────────────────
    ask_p = sub.add_parser("ask", help="Query an ensemble")
    ask_p.add_argument("spec", help="url4 spec string (e.g. 'claude-haiku|gpt-4o-mini')")
    ask_p.add_argument("prompt", help="The question to ask")
    ask_p.add_argument("--json", dest="json_output", action="store_true",
                       help="Output structured JSON instead of streaming text")
    ask_p.add_argument("--no-stream", action="store_true",
                       help="Wait for full response instead of streaming")
    ask_p.add_argument("--reduce-model", default=None,
                       help="Model for synthesis step (default: claude-haiku)")

    # ── estimate ────────────────────────────────────────────────
    est_p = sub.add_parser("estimate", help="Estimate cost without executing")
    est_p.add_argument("spec", help="url4 spec string")
    est_p.add_argument("prompt", help="The prompt to estimate for")
    est_p.add_argument("--json", dest="json_output", action="store_true",
                       help="Output as JSON")

    # ── cache-stats ─────────────────────────────────────────────
    sub.add_parser("cache-stats", help="Show cache statistics")

    # ── cache-clear ─────────────────────────────────────────────
    sub.add_parser("cache-clear", help="Clear the response cache")

    # ── models ──────────────────────────────────────────────────
    sub.add_parser("models", help="List known models")

    # ── eval ───────────────────────────────────────────────────
    eval_p = sub.add_parser("eval", help="Run eval or import cache")
    eval_sub = eval_p.add_subparsers(dest="eval_command")

    # eval run
    eval_run = eval_sub.add_parser("run", help="Run a council against a benchmark")
    eval_run.add_argument("--council", required=True, help="url4 spec for the council")
    eval_run.add_argument("--benchmark", default="hle", help="Benchmark name (default: hle)")
    eval_run.add_argument("--sample", type=int, default=None, help="Sample N questions")
    eval_run.add_argument("--seed", type=int, default=42, help="Random seed for sampling")
    eval_run.add_argument("--judge", default="o3-mini", help="Judge model (default: o3-mini)")
    eval_run.add_argument("--concurrency", type=int, default=5, help="Max concurrent questions")
    eval_run.add_argument("--json", dest="json_output", action="store_true",
                          help="Output results as JSON")

    # eval import-cache
    eval_import = eval_sub.add_parser("import-cache", help="Import benchmark results into cache")
    eval_import.add_argument("path", help="Path to directory with hle_*.json files")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    if args.command == "ask":
        _cmd_ask(args)
    elif args.command == "estimate":
        _cmd_estimate(args)
    elif args.command == "cache-stats":
        _cmd_cache_stats()
    elif args.command == "cache-clear":
        _cmd_cache_clear()
    elif args.command == "models":
        _cmd_models()
    elif args.command == "eval":
        if args.eval_command == "run":
            _cmd_eval_run(args)
        elif args.eval_command == "import-cache":
            _cmd_eval_import(args)
        else:
            eval_p.print_help()
            sys.exit(1)


# ── Commands ───────────────────────────────────────────────────────

def _cmd_ask(args):
    from url4.council import Council

    kwargs = {}
    if args.reduce_model:
        kwargs["reduce_model"] = args.reduce_model

    council = Council(args.spec, **kwargs)

    if args.json_output or args.no_stream:
        # Non-streaming: get full result
        result = asyncio.run(council.ask(args.prompt))
        if args.json_output:
            out = {
                "response": result.response,
                "total_cost": result.total_cost,
                "synthesis_cost": result.synthesis_cost,
                "synthesis_model": result.synthesis_model,
                "sources": [
                    {
                        "source": r.source,
                        "weight": r.weight,
                        "cost": r.cost,
                        "cache": r.cache,
                        "latency_ms": r.latency_ms,
                        "tokens_in": r.tokens_in,
                        "tokens_out": r.tokens_out,
                        "response_preview": r.response[:200] if r.response else "",
                    }
                    for r in result.source_results
                ],
            }
            json.dump(out, sys.stdout, indent=2)
            sys.stdout.write("\n")
        else:
            print(result.response)
    else:
        # Streaming
        async def _stream():
            async for chunk in council.ask_stream(args.prompt):
                print(chunk, end="", flush=True)
            print()

        asyncio.run(_stream())


def _cmd_estimate(args):
    from url4.council import Council

    council = Council(args.spec)
    est = council.estimate(args.prompt)

    if args.json_output:
        out = {
            "total_cost": est.total_cost,
            "full_cost": est.full_cost,
            "savings": est.savings,
            "total_count": est.total_count,
            "cached_count": est.cached_count,
            "sources": [
                {
                    "source": s.source,
                    "provider": s.provider,
                    "model_id": s.model_id,
                    "weight": s.weight,
                    "estimated_input_tokens": s.estimated_input_tokens,
                    "estimated_output_tokens": s.estimated_output_tokens,
                    "estimated_cost": s.estimated_cost,
                    "cached": s.cached,
                }
                for s in est.sources
            ],
        }
        if est.synthesis_estimate:
            out["synthesis"] = {
                "source": est.synthesis_estimate.source,
                "provider": est.synthesis_estimate.provider,
                "estimated_cost": est.synthesis_estimate.estimated_cost,
            }
        json.dump(out, sys.stdout, indent=2)
        sys.stdout.write("\n")
    else:
        print(f"Estimated cost: ${est.total_cost:.6f}")
        if est.savings > 0:
            print(f"Savings from cache: ${est.savings:.6f}")
        print(f"Sources: {est.total_count} ({est.cached_count} cached)")
        print()
        for s in est.sources:
            cached_tag = " [CACHED]" if s.cached else ""
            print(f"  {s.source} ({s.provider}){cached_tag}")
            print(f"    ~{s.estimated_input_tokens} in / ~{s.estimated_output_tokens} out = ${s.estimated_cost:.6f}")
        if est.synthesis_estimate:
            se = est.synthesis_estimate
            print(f"  {se.source} ({se.provider})")
            print(f"    ~{se.estimated_input_tokens} in / ~{se.estimated_output_tokens} out = ${se.estimated_cost:.6f}")


def _cmd_cache_stats():
    from url4.cache import get_cache

    cache = get_cache()
    stats = cache.stats()
    print(f"Cache entries: {stats.total_entries}")
    print(f"Hits: {stats.hits}")
    print(f"Misses: {stats.misses}")
    if stats.hits + stats.misses > 0:
        rate = stats.hits / (stats.hits + stats.misses) * 100
        print(f"Hit rate: {rate:.1f}%")


def _cmd_cache_clear():
    from url4.cache import get_cache

    cache = get_cache()
    cache.clear()
    print("Cache cleared.")


def _cmd_models():
    from url4.adapters.registry import list_models

    models = list_models()
    for provider, names in sorted(models.items()):
        print(f"\n{provider}:")
        for name in names:
            print(f"  {name}")


def _cmd_eval_run(args):
    from url4.council import Council
    from url4.eval.harness import run_eval, print_progress, EvalResult
    from url4.eval.hle import load_hle

    if args.benchmark != "hle":
        print(f"Unknown benchmark: {args.benchmark}", file=sys.stderr)
        sys.exit(1)

    print(f"Loading HLE benchmark...", file=sys.stderr)
    questions = load_hle(sample=args.sample, seed=args.seed)
    print(f"Loaded {len(questions)} questions", file=sys.stderr)

    council = Council(args.council)

    progress_fn = None if args.json_output else print_progress
    result = asyncio.run(run_eval(
        council=council,
        questions=questions,
        judge_model=args.judge,
        concurrency=args.concurrency,
        on_progress=progress_fn,
    ))

    if args.json_output:
        out = {
            "benchmark": args.benchmark,
            "council": args.council,
            "total": result.total,
            "correct": result.correct,
            "errors": result.errors,
            "accuracy": result.accuracy,
            "accuracy_pct": result.accuracy_pct,
            "results": result.results,
        }
        json.dump(out, sys.stdout, indent=2)
        sys.stdout.write("\n")
    else:
        print(f"\nResults: {result.correct}/{result.total} correct ({result.accuracy_pct})")
        if result.errors > 0:
            print(f"Errors: {result.errors}")


def _cmd_eval_import(args):
    from url4.eval.import_cache import import_benchmark_cache

    print(f"Importing benchmark results from {args.path}...", file=sys.stderr)
    stats = import_benchmark_cache(args.path)

    total = 0
    for filename, count in sorted(stats.items()):
        print(f"  {filename}: {count} entries")
        total += count
    print(f"\nTotal: {total} entries imported into cache")


if __name__ == "__main__":
    main()
