"""Streaming synthesis for url4 ensembles.

Map phase runs in parallel (no streaming), then streams the
synthesis model output token by token.
"""

from __future__ import annotations

from collections.abc import AsyncGenerator, Callable
from dataclasses import dataclass, field

from url4.orchestrator import SourceResult, fan_out
from url4.synthesis import build_synthesis_prompt, DEFAULT_REDUCE_MODEL
from url4.adapters.registry import resolve_adapter
from url4.parser import Spec
from url4.cache import ResponseCache


@dataclass
class StreamResult:
    """Final result available after streaming completes."""

    full_response: str
    source_results: list[SourceResult] = field(default_factory=list)
    synthesis_model: str = ""


async def stream_synthesis(
    source_results: list[SourceResult],
    original_prompt: str,
    reduce_model: str = DEFAULT_REDUCE_MODEL,
    reduce_instruction: str | None = None,
) -> AsyncGenerator[str, None]:
    """Stream the synthesis of multiple model responses.

    Yields text chunks as the synthesis model generates them.
    For a single valid response, yields it in one chunk (no synthesis needed).

    Args:
        source_results: Results from fan_out().
        original_prompt: The original user question.
        reduce_model: Model to use for synthesis.
        reduce_instruction: Custom synthesis instruction.

    Yields:
        Text chunks from the synthesis model.
    """
    valid_results = [r for r in source_results if r.response and not r.error]

    if not valid_results:
        return

    # Single source — yield directly, no synthesis
    if len(valid_results) == 1:
        yield valid_results[0].response
        return

    # Build synthesis prompt and stream from reduce model
    prompt = build_synthesis_prompt(valid_results, original_prompt, reduce_instruction)
    adapter, model_id = resolve_adapter(reduce_model)

    async for chunk in adapter.query_stream(model_id, prompt):
        yield chunk
