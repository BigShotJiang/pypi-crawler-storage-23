"""Council — the high-level API for url4 ensembles.

Ties together parse → fan_out → synthesize into a single call.

Usage:
    from url4 import Council

    council = Council("claude-haiku|gpt-4o-mini")
    result = await council.ask("What causes auroras?")
    print(result.response)
"""

from __future__ import annotations

from collections.abc import AsyncGenerator

from url4.parser import parse, Spec, _find_top_level_char
from url4.orchestrator import fan_out, fan_out_progressive, _parse_checkpoints
from url4.synthesis import synthesize, SynthesisResult, DEFAULT_REDUCE_MODEL
from url4.streaming import stream_synthesis
from url4.estimator import estimate_query, CostEstimate
from url4.cache import ResponseCache, get_cache


class Council:
    """A url4 ensemble — multiple models, one answer.

    Args:
        spec_str: A url4 spec string defining the sources.
            Examples:
                "claude-haiku|gpt-4o-mini"
                "0.5*claude-opus|0.3*gpt-4o|0.2*gemini-pro"
                "claude|gpt-4o|deepseek!synthesize the most accurate answer"
        reduce_model: Model to use for synthesis (default: claude-haiku).
        cache: Optional cache instance. None = use default local cache.
    """

    def __init__(
        self,
        spec_str: str,
        reduce_model: str = DEFAULT_REDUCE_MODEL,
        cache: ResponseCache | None = None,
    ):
        # If spec_str has no top-level !, add a placeholder so it parses
        if _find_top_level_char(spec_str, "!") is None:
            spec_str = spec_str + "!{prompt}"
        self._spec_template = spec_str
        self.reduce_model = reduce_model
        self.cache = cache

    async def ask(self, prompt: str) -> SynthesisResult:
        """Ask the council a question.

        Fans out to all sources in parallel, then synthesizes
        the responses into a single answer.

        Args:
            prompt: The question to ask.

        Returns:
            SynthesisResult with the synthesized answer and cost breakdown.
        """
        # Fill in the prompt placeholder
        spec_str = self._spec_template.replace("{prompt}", prompt)

        # If the spec already has a literal prompt (not our placeholder),
        # use it as the reduce instruction and set the prompt
        spec = parse(spec_str)
        if spec.prompt and spec.prompt != prompt:
            reduce_instruction = spec.prompt
        else:
            reduce_instruction = spec.params.get("reduce")

        # Override prompt in the parsed spec for fan-out
        spec.prompt = prompt

        # Get reduce model from params if specified
        reduce_model = spec.params.get("reduce_model", self.reduce_model)

        # Fan out to all sources
        results = await fan_out(spec, cache=self.cache)

        # Synthesize
        return await synthesize(
            source_results=results,
            original_prompt=prompt,
            reduce_model=reduce_model,
            reduce_instruction=reduce_instruction,
        )

    async def ask_stream(
        self,
        prompt: str,
        on_progress: callable | None = None,
    ) -> AsyncGenerator[str, None]:
        """Ask the council, streaming the synthesis response.

        Map phase runs in parallel (no streaming). Once all sources
        respond, streams the synthesis model output token by token.

        Args:
            prompt: The question to ask.
            on_progress: Optional callback(source, status) called as
                each source completes during the map phase.

        Yields:
            Text chunks from the synthesis model.
        """
        spec_str = self._spec_template.replace("{prompt}", prompt)
        spec = parse(spec_str)
        if spec.prompt and spec.prompt != prompt:
            reduce_instruction = spec.prompt
        else:
            reduce_instruction = spec.params.get("reduce")
        spec.prompt = prompt
        reduce_model = spec.params.get("reduce_model", self.reduce_model)

        # Map phase — fan out to all sources (not streamed)
        results = await fan_out(spec, cache=self.cache)

        # Notify progress for each completed source
        if on_progress:
            for r in results:
                status = "error" if r.error else ("cached" if r.cache == "HIT" else "done")
                on_progress(r.source, status)

        # Stream the synthesis
        async for chunk in stream_synthesis(
            source_results=results,
            original_prompt=prompt,
            reduce_model=reduce_model,
            reduce_instruction=reduce_instruction,
        ):
            yield chunk

    async def ask_progressive(
        self,
        prompt: str,
    ) -> AsyncGenerator[SynthesisResult, None]:
        """Ask with progressive synthesis at reduce checkpoints.

        Synthesizes intermediate results as sources complete,
        controlled by the &reduce= parameter in the spec.

        Example: Council("a|b|c!synthesize&reduce=0,-1")
          - Yields after source 0 completes (synthesized with available results)
          - Yields after all sources complete (final synthesis)

        If no &reduce= param, behaves like a single reduce after all sources.

        Args:
            prompt: The question to ask.

        Yields:
            SynthesisResult at each checkpoint.
        """
        spec_str = self._spec_template.replace("{prompt}", prompt)
        spec = parse(spec_str)
        if spec.prompt and spec.prompt != prompt:
            reduce_instruction = spec.prompt
        else:
            reduce_instruction = spec.params.get("reduce")
        spec.prompt = prompt
        reduce_model = spec.params.get("reduce_model", self.reduce_model)

        reduce_param = spec.params.get("reduce")
        # If reduce param looks like checkpoint indices (contains digits),
        # use progressive mode. Otherwise treat it as a reduce instruction.
        checkpoints = []
        if reduce_param and any(c.isdigit() or c == '-' for c in reduce_param.replace(",", "")):
            checkpoints = _parse_checkpoints(reduce_param, len(spec.sources))
            # Don't use the checkpoint string as a reduce instruction
            reduce_instruction = None

        if not checkpoints:
            # No progressive checkpoints — fall back to normal ask
            result = await self.ask(prompt)
            yield result
            return

        async for cp_idx, completed_results in fan_out_progressive(
            spec, checkpoints, cache=self.cache,
        ):
            result = await synthesize(
                source_results=completed_results,
                original_prompt=prompt,
                reduce_model=reduce_model,
                reduce_instruction=reduce_instruction,
            )
            yield result

    def estimate(self, prompt: str) -> CostEstimate:
        """Estimate cost without executing.

        Checks cache to show which sources would be hits.

        Args:
            prompt: The question to estimate cost for.

        Returns:
            CostEstimate with per-source breakdown, totals, and savings.
        """
        spec_str = self._spec_template.replace("{prompt}", prompt)
        spec = parse(spec_str)
        spec.prompt = prompt

        return estimate_query(
            spec=spec,
            prompt=prompt,
            reduce_model=self.reduce_model,
            cache=self.cache,
        )
