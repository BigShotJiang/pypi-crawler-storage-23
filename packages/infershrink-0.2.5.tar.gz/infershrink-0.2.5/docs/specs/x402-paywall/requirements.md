# Requirements: x402 Paywall for InferShrink

## Overview
An agent-facing HTTP service that accepts x402 USDC micropayments and returns InferShrink optimization results. This is the revenue endpoint — agents pay per-request, get real value back.

## User Story
As an AI agent with a USDC wallet, I want to pay $0.001 per optimization request so that I can route my LLM calls to cheaper models and save 10x on API costs.

## Functional Requirements

### R1: Optimize Endpoint
- GIVEN an authenticated request to `POST /optimize` with `{ prompt, provider, model? }`
- WHEN the payment is verified and settled
- THEN return `{ complexity, recommended_model, estimated_savings_pct, original_model?, routed }`

### R2: Classify Endpoint
- GIVEN an authenticated request to `POST /classify` with `{ prompt }`
- WHEN the payment is verified and settled
- THEN return `{ complexity: "simple"|"moderate"|"complex"|"critical", confidence, tokens_estimated }`

### R3: Status Endpoint (Free)
- GIVEN an unauthenticated request to `GET /status`
- WHEN the server is healthy
- THEN return `{ status: "ok", version, supported_providers, pricing }`
- AND this endpoint MUST NOT require payment

### R4: x402 Payment via Official SDK
- GIVEN a request without valid payment
- WHEN the server receives it on a paid endpoint
- THEN return HTTP 402 with proper `PAYMENT-REQUIRED` header per x402 V2 spec
- AND the header MUST be parseable by `@x402/fetch` client SDK

### R5: Testnet and Mainnet Support
- GIVEN `X402_NETWORK=eip155:84532` (default)
- WHEN using testnet
- THEN use public facilitator at `x402.org/facilitator`
- GIVEN `X402_NETWORK=eip155:8453` with CDP API keys
- WHEN using mainnet
- THEN use CDP facilitator with JWT auth

### R6: Pricing
- GIVEN the pricing table
- WHEN `/classify` is called → $0.0001 USDC
- WHEN `/optimize` is called → $0.001 USDC

### R7: Real InferShrink Integration
- GIVEN a valid paid request
- WHEN processing the optimization
- THEN use the actual InferShrink `classify()` and `route()` functions
- AND return real results, not mocks

### R8: Agent Client SDK
- GIVEN an agent that wants to use InferShrink
- WHEN it installs `@x402/fetch` and `@x402/evm`
- THEN it can call the service with `fetchWithPayment(url, options)`
- AND payment is handled transparently

## Non-Functional Requirements

### NF1: Official SDK Only
- Server MUST use `@x402/express` middleware
- Client MUST use `@x402/fetch` + `@x402/evm`
- No custom x402 format handling

### NF2: Quality Gates
- All code through Kiro-style spec → PR → review
- Unit tests for all endpoints
- Integration test with facilitator mock
- E2e test script for live payment

### NF3: Self-Contained
- Single `docker compose up` or `npx tsx server.ts` to run
- No external dependencies beyond x402 facilitator

### NF4: Skill Experience
- A simulation script that demonstrates the full agent journey:
  1. Agent discovers service via `/status`
  2. Agent tries `/optimize` → gets 402
  3. Agent's x402 client auto-pays
  4. Agent receives optimization result
  5. Agent uses result to route LLM call
