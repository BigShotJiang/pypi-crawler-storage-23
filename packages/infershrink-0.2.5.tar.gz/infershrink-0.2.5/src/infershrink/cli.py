"""
InferShrink CLI.

Usage:
    infershrink index ./docs
    infershrink query "your question"
    infershrink classify "your prompt"
    infershrink stats
    infershrink stats --daily
    infershrink stats --weekly
    infershrink clear
"""

import argparse
import json
import os
import sys
from pathlib import Path

# Early suppression: check for --quiet or --json BEFORE heavy imports
if "--quiet" in sys.argv or "--json" in sys.argv:
    os.environ["TRANSFORMERS_VERBOSITY"] = "error"
    os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    os.environ["TQDM_DISABLE"] = "1"
    import warnings

    warnings.filterwarnings("ignore")
    import logging

    logging.disable(logging.WARNING)

from infershrink import __version__


def main():
    parser = argparse.ArgumentParser(
        prog="infershrink",
        description="Cut LLM costs 80%+. Smart retrieval, prompt compression, model routing.",
    )
    parser.add_argument("--version", action="version", version=f"infershrink {__version__}")
    parser.add_argument(
        "--index-dir",
        default=".tokenshrink",
        help="Directory to store the index (default: .tokenshrink)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output as JSON",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress model loading messages",
    )

    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # index
    index_parser = subparsers.add_parser("index", help="Index files for retrieval")
    index_parser.add_argument("path", help="File or directory to index")
    index_parser.add_argument(
        "-e",
        "--extensions",
        default=".md,.txt,.py,.json,.yaml,.yml",
        help="File extensions to include (comma-separated)",
    )
    index_parser.add_argument(
        "-f",
        "--force",
        action="store_true",
        help="Re-index even if files unchanged",
    )

    # query
    query_parser = subparsers.add_parser("query", help="Get relevant context for a question")
    query_parser.add_argument("question", help="Your question")
    query_parser.add_argument(
        "-k",
        type=int,
        default=5,
        help="Number of chunks to retrieve (default: 5)",
    )
    query_parser.add_argument(
        "-c",
        "--compress",
        action="store_true",
        help="Enable compression (requires llmlingua)",
    )
    query_parser.add_argument(
        "--no-compress",
        action="store_true",
        help="Disable compression",
    )
    query_parser.add_argument(
        "--max-tokens",
        type=int,
        default=2000,
        help="Target token limit (default: 2000)",
    )
    query_parser.add_argument(
        "--adaptive",
        action="store_true",
        default=None,
        help="Enable REFRAG-inspired adaptive compression (default: on)",
    )
    query_parser.add_argument(
        "--no-adaptive",
        action="store_true",
        help="Disable adaptive compression",
    )
    query_parser.add_argument(
        "--no-dedup",
        action="store_true",
        help="Disable cross-passage deduplication",
    )
    query_parser.add_argument(
        "--scores",
        action="store_true",
        help="Show per-chunk importance scores",
    )

    # search (alias for query without compression)
    search_parser = subparsers.add_parser("search", help="Search without compression")
    search_parser.add_argument("question", help="Your question")
    search_parser.add_argument(
        "-k",
        type=int,
        default=5,
        help="Number of chunks to retrieve (default: 5)",
    )

    # classify
    classify_parser = subparsers.add_parser("classify", help="Classify task complexity")
    classify_parser.add_argument("prompt", help="The prompt to classify")
    classify_parser.add_argument(
        "--role",
        default="user",
        help="Message role (default: user)",
    )

    # route
    route_parser = subparsers.add_parser("route", help="Route a model request based on complexity")
    route_parser.add_argument("prompt", help="The prompt to analyze")
    route_parser.add_argument(
        "--model",
        default="claude-sonnet-4-20250514",
        help="Original model to consider routing from (default: claude-sonnet-4-20250514)",
    )

    # status — show version and feature availability
    subparsers.add_parser("status", help="Show version and installed features")

    # stats — cost tracking stats
    stats_parser = subparsers.add_parser("stats", help="Show cost tracking statistics")
    stats_parser.add_argument(
        "--daily",
        action="store_true",
        help="Show per-day breakdown (last 7 days)",
    )
    stats_parser.add_argument(
        "--weekly",
        action="store_true",
        help="Show per-week breakdown",
    )

    # clear
    subparsers.add_parser("clear", help="Clear the index")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    # ── InferShrink-native commands (no heavy deps) ──

    if args.command == "status":
        from infershrink.compressor import is_compression_available
        from infershrink.retrieval import is_retrieval_available

        features = {
            "classifier": True,
            "router": True,
            "tracker": True,
            "wrapper": True,
            "compression": is_compression_available(),
            "retrieval": is_retrieval_available(),
        }

        if args.json:
            print(
                json.dumps(
                    {
                        "version": __version__,
                        "features": features,
                    },
                    indent=2,
                )
            )
        else:
            print(f"InferShrink v{__version__}")
            print()
            print("Core features (always available):")
            print("  ✓ Classifier")
            print("  ✓ Router")
            print("  ✓ Tracker")
            print("  ✓ Wrapper")
            print()
            print("Optional features:")
            if features["compression"]:
                print("  ✓ Compression (LLMLingua)")
            else:
                print("  ✗ Compression — pip install infershrink[compression]")
            if features["retrieval"]:
                print("  ✓ Retrieval (FAISS)")
            else:
                print("  ✗ Retrieval — pip install infershrink[retrieval]")
        return

    if args.command == "classify":
        from infershrink import classify as classify_fn

        messages = [{"role": args.role, "content": args.prompt}]
        result = classify_fn(messages)
        if args.json:
            print(
                json.dumps(
                    {
                        "complexity": result.complexity.value,
                        "reason": result.reason,
                        "estimated_tokens": result.estimated_tokens,
                        "signals": result.signals,
                    },
                    indent=2,
                )
            )
        else:
            print(f"Complexity: {result.complexity.value}")
            print(f"Reason: {result.reason}")
            print(f"Estimated tokens: {result.estimated_tokens}")
        return

    if args.command == "route":
        from infershrink import build_config
        from infershrink import classify as classify_fn
        from infershrink import route as route_fn

        messages = [{"role": "user", "content": args.prompt}]
        classification = classify_fn(messages)
        config = build_config()
        routing = route_fn(args.model, classification.complexity, config)
        if args.json:
            print(
                json.dumps(
                    {
                        "complexity": classification.complexity.value,
                        "original_model": routing.original_model,
                        "routed_model": routing.routed_model,
                        "was_downgraded": routing.was_downgraded,
                    },
                    indent=2,
                )
            )
        else:
            print(f"Complexity: {classification.complexity.value}")
            print(f"Original model: {routing.original_model}")
            print(f"Routed model: {routing.routed_model}")
            if routing.was_downgraded:
                print("↓ Downgraded to cheaper model")
            elif routing.original_model == routing.routed_model:
                print("= No change")
        return

    if args.command == "stats":
        from infershrink.tracker import Tracker

        tracker = Tracker(persist_path=None)  # uses default ~/.infershrink/stats.jsonl

        if args.daily or args.weekly:
            weekly = tracker.weekly_stats()
            if args.json:
                print(json.dumps(weekly, indent=2))
            else:
                print("InferShrink — Daily Breakdown (last 7 days)")
                print("=" * 50)
                for day in weekly:
                    if day["total_requests"] == 0:
                        continue
                    print(
                        f"  {day['date']}: {day['total_requests']} requests, "
                        f"{day['total_tokens_saved']:,} tokens saved, "
                        f"${day['total_savings_usd']:.4f} saved"
                    )
                if all(d["total_requests"] == 0 for d in weekly):
                    print("  No data yet.")
        else:
            lifetime = tracker.lifetime_stats()
            if args.json:
                print(json.dumps(lifetime, indent=2))
            else:
                pct = (
                    (1 - lifetime["compression_ratio"]) * 100
                    if lifetime["compression_ratio"] < 1
                    else 0
                )
                print("InferShrink — Lifetime Stats")
                print("=" * 40)
                print(f"Total requests:       {lifetime['total_requests']}")
                print(f"Original tokens:      {lifetime['total_original_tokens']:,}")
                print(f"Compressed tokens:    {lifetime['total_compressed_tokens']:,}")
                print(f"Tokens saved:         {lifetime['total_tokens_saved']:,} ({pct:.1f}%)")
                print(f"Total cost (original):${lifetime['total_cost_original_usd']:.4f}")
                print(f"Total cost (routed):  ${lifetime['total_cost_routed_usd']:.4f}")
                print(f"Estimated savings:    ${lifetime['total_savings_usd']:.4f}")
                print("=" * 40)
        return

    # ── Retrieval commands (require heavy deps) ──

    # Lazy import to avoid loading ML models for --help/--version/classify/route
    from infershrink.retrieval import TokenShrink

    # Determine compression setting
    compression = True
    if hasattr(args, "no_compress") and args.no_compress:
        compression = False
    if hasattr(args, "compress") and args.compress:
        compression = True

    ts = TokenShrink(
        index_dir=args.index_dir,
        compression=compression,
    )

    if args.command == "index":
        extensions = tuple(
            e.strip() if e.startswith(".") else f".{e.strip()}" for e in args.extensions.split(",")
        )
        result = ts.index(args.path, extensions=extensions, force=args.force)

        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"✓ Indexed {result['files_indexed']} files")
            print(f"  Chunks: {result['chunks_added']} added, {result['total_chunks']} total")
            print(f"  Files: {result['total_files']} tracked")

    elif args.command == "query":
        compress = None
        if args.compress:
            compress = True
        elif args.no_compress:
            compress = False

        adaptive_flag = None
        if getattr(args, "adaptive", None):
            adaptive_flag = True
        elif getattr(args, "no_adaptive", False):
            adaptive_flag = False

        dedup_flag = None
        if getattr(args, "no_dedup", False):
            dedup_flag = False

        result = ts.query(
            args.question,
            k=args.k,
            max_tokens=args.max_tokens,
            compress=compress,
            adaptive=adaptive_flag,
            dedup=dedup_flag,
        )

        if args.json:
            output = {
                "context": result.context,
                "sources": result.sources,
                "original_tokens": result.original_tokens,
                "compressed_tokens": result.compressed_tokens,
                "savings_pct": result.savings_pct,
                "dedup_removed": result.dedup_removed,
            }
            if getattr(args, "scores", False) and result.chunk_scores:
                output["chunk_scores"] = [
                    {
                        "source": Path(cs.source).name,
                        "similarity": round(cs.similarity, 3),
                        "density": round(cs.density, 3),
                        "importance": round(cs.importance, 3),
                        "compression_ratio": round(cs.compression_ratio, 3),
                        "deduplicated": cs.deduplicated,
                    }
                    for cs in result.chunk_scores
                ]
            print(json.dumps(output, indent=2))
        else:
            if result.sources:
                print(f"Sources: {', '.join(Path(s).name for s in result.sources)}")
                print(f"Stats: {result.savings}")

                if result.savings_pct == 0.0:
                    print("  Tip: Install llmlingua for compression: pip install llmlingua")

                if getattr(args, "scores", False) and result.chunk_scores:
                    print("\nChunk Importance Scores:")
                    for cs in result.chunk_scores:
                        status = " [DEDUP]" if cs.deduplicated else ""
                        print(
                            f"  {Path(cs.source).name}: "
                            f"sim={cs.similarity:.2f} density={cs.density:.2f} "
                            f"importance={cs.importance:.2f} ratio={cs.compression_ratio:.2f}"
                            f"{status}"
                        )

                print()
                print(result.context)
            else:
                print("No relevant content found.")

    elif args.command == "search":
        results = ts.search(args.question, k=args.k)

        if args.json:
            print(json.dumps(results, indent=2))
        else:
            if not results:
                print("No results found.")
            else:
                for i, r in enumerate(results, 1):
                    print(f"\n[{i}] {Path(r['source']).name} (score: {r['score']:.3f})")
                    print("-" * 40)
                    print(r["text"][:500] + ("..." if len(r["text"]) > 500 else ""))

    elif args.command == "clear":
        ts.clear()
        if args.json:
            print(json.dumps({"status": "cleared"}))
        else:
            print("✓ Index cleared")


if __name__ == "__main__":
    main()
