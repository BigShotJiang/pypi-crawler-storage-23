"""Prompt compressor — optionally uses TokenShrink to reduce token count."""

from __future__ import annotations

import copy
from typing import Any, Dict, List

from .types import Complexity, CompressionResult

# Try to import the LLMLingua compressor for inline message compression.
# TokenShrink (retrieval module) handles its own compression pipeline;
# here we only check if the underlying compression engine is available.
_llmlingua_available = False

try:
    from llmlingua import (
        PromptCompressor as _PromptCompressor,  # noqa: F401
    )

    _llmlingua_available = True
except ImportError:
    pass


def _estimate_tokens(text: str) -> int:
    """Rough token estimate (~4 chars per token)."""
    return max(1, len(text) // 4)


def _compress_message_content(content: Any) -> Any:
    """Compress a single message's content field.

    Currently a pass-through — inline message-level compression requires
    the LLMLingua integration in TokenShrink. This function exists as a
    hook point for future per-message compression.
    """
    return content


def compress(
    messages: List[Dict[str, Any]],
    complexity: Complexity,
    config: Dict[str, Any],
) -> CompressionResult:
    """Compress messages if conditions are met.

    Parameters
    ----------
    messages:
        The messages array (OpenAI chat format).
    complexity:
        The classified complexity of the task.
    config:
        Full InferShrink config dict.

    Returns
    -------
    CompressionResult
    """
    compression_cfg = config.get("compression", {})
    enabled = compression_cfg.get("enabled", True)
    min_tokens = compression_cfg.get("min_tokens", 500)
    skip_for = compression_cfg.get("skip_for", ["SECURITY_CRITICAL"])

    # Calculate original token count
    original_tokens = 0
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            original_tokens += _estimate_tokens(content)
        elif isinstance(content, list):
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    original_tokens += _estimate_tokens(part.get("text", ""))
                elif isinstance(part, str):
                    original_tokens += _estimate_tokens(part)

    # Determine if we should skip compression
    # Inline message compression requires llmlingua; without it we pass through.
    should_skip = (
        not enabled
        or complexity.value in skip_for
        or original_tokens < min_tokens
        or not _llmlingua_available
    )

    if should_skip:
        return CompressionResult(
            messages=messages,
            original_tokens=original_tokens,
            compressed_tokens=original_tokens,
            compression_ratio=1.0,
            was_compressed=False,
        )

    # Compress messages (skip system messages to preserve instructions)
    compressed_messages = []
    compressed_tokens = 0

    for msg in messages:
        new_msg = copy.deepcopy(msg)
        role = msg.get("role", "")

        # Don't compress system prompts (they're instructions, not data)
        if role == "system":
            content = msg.get("content", "")
            if isinstance(content, str):
                compressed_tokens += _estimate_tokens(content)
            compressed_messages.append(new_msg)
            continue

        # Compress user and assistant messages
        new_msg["content"] = _compress_message_content(msg.get("content", ""))

        content = new_msg.get("content", "")
        if isinstance(content, str):
            compressed_tokens += _estimate_tokens(content)
        elif isinstance(content, list):
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    compressed_tokens += _estimate_tokens(part.get("text", ""))
                elif isinstance(part, str):
                    compressed_tokens += _estimate_tokens(part)

        compressed_messages.append(new_msg)

    ratio = compressed_tokens / original_tokens if original_tokens > 0 else 1.0

    return CompressionResult(
        messages=compressed_messages,
        original_tokens=original_tokens,
        compressed_tokens=compressed_tokens,
        compression_ratio=ratio,
        was_compressed=True,
    )


def is_compression_available() -> bool:
    """Check if inline compression (LLMLingua) is installed and usable."""
    return _llmlingua_available
