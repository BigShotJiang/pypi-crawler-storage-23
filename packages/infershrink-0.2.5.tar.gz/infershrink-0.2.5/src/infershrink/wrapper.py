"""SDK wrapper — the core of InferShrink's one-line integration.

Usage::

    import openai
    from infershrink import optimize

    client = optimize(openai.Client())
    # All chat.completions.create() calls now go through InferShrink
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from .classifier import classify
from .compressor import compress
from .config import build_config
from .license import RequestCounter, get_limits
from .license import validate as validate_license
from .router import route
from .tracker import Tracker
from .types import Config

logger = logging.getLogger(__name__)

# Absolute ceiling for max_tokens retries to prevent runaway costs
_MAX_TOKENS_CEILING = 16384


class _InferShrinkCompletionProxy:
    """Proxy for ``client.chat.completions`` that intercepts ``create()``."""

    def __init__(
        self,
        original_completions: Any,
        config: Dict[str, Any],
        tracker: Tracker,
    ) -> None:
        self._original = original_completions
        self._config = config
        self._tracker = tracker
        self._request_counter = RequestCounter()

    def _classify_compress_route(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """Shared logic: classify, compress, route, track, return modified kwargs."""
        messages = kwargs.get("messages", [])
        original_model = kwargs.get("model", "gpt-4o")

        limits = self._config.get("_license_limits", {"compression_enabled": True})

        # Atomic check-and-increment to prevent race conditions
        max_requests = limits.get("max_requests_per_month")
        self._request_counter.check_and_increment(max_requests)

        classification = classify(messages)

        if limits.get("compression_enabled", True):
            compression = compress(messages, classification.complexity, self._config)
        else:
            from .types import CompressionResult

            token_est = sum(len(str(m.get("content", ""))) // 4 for m in messages)
            compression = CompressionResult(
                messages=messages,
                original_tokens=token_est,
                compressed_tokens=token_est,
                compression_ratio=1.0,
                was_compressed=False,
            )

        routing = route(original_model, classification.complexity, self._config)

        modified_kwargs = dict(kwargs)
        modified_kwargs["messages"] = compression.messages
        modified_kwargs["model"] = routing.routed_model

        if self._config.get("cost_tracking", True):
            self._tracker.record(
                original_model=original_model,
                routed_model=routing.routed_model,
                original_tokens=compression.original_tokens,
                compressed_tokens=compression.compressed_tokens,
                complexity=classification.complexity,
            )

        return modified_kwargs

    def create(self, **kwargs: Any) -> Any:
        """Intercept chat.completions.create() — supports both streaming and non-streaming."""
        modified_kwargs = self._classify_compress_route(kwargs)

        # Streaming: pass through transparently
        if modified_kwargs.get("stream"):
            return self._original.create(**modified_kwargs)

        # Non-streaming: handle null content from thinking models
        response = self._original.create(**modified_kwargs)

        # Only apply null-content recovery to proper response objects
        choices = getattr(response, "choices", None)
        if choices and hasattr(choices[0], "message"):
            content = getattr(choices[0].message, "content", "PRESENT")

            # If content is null and we downgraded, retry with original model
            if content is None and modified_kwargs.get("model") != kwargs.get("model"):
                retry_kwargs = dict(kwargs)
                retry_kwargs["messages"] = modified_kwargs["messages"]
                response = self._original.create(**retry_kwargs)
                choices = getattr(response, "choices", None)
                content = getattr(choices[0].message, "content", "PRESENT") if choices else None

            # If still null (thinking model used all tokens), bump max_tokens
            if (
                content is None
                and choices
                and getattr(choices[0], "finish_reason", None) == "length"
            ):
                retry_kwargs = dict(modified_kwargs)
                current_max = retry_kwargs.get("max_tokens", 1024)
                new_max = min(max(current_max * 4, 4096), _MAX_TOKENS_CEILING)
                if new_max > current_max:
                    retry_kwargs["max_tokens"] = new_max
                    logger.debug("Retrying with max_tokens=%d (was %d)", new_max, current_max)
                    response = self._original.create(**retry_kwargs)

        return response

    def __getattr__(self, name: str) -> Any:
        """Forward all other attribute access to the original completions object."""
        return getattr(self._original, name)


class _InferShrinkChatProxy:
    """Proxy for ``client.chat`` that replaces ``.completions``."""

    def __init__(
        self,
        original_chat: Any,
        config: Dict[str, Any],
        tracker: Tracker,
    ) -> None:
        self._original = original_chat
        self._config = config
        self._tracker = tracker
        self.completions = _InferShrinkCompletionProxy(original_chat.completions, config, tracker)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class _InferShrinkAnthropicProxy:
    """Proxy for Anthropic client that intercepts messages.create()."""

    def __init__(
        self,
        original_client: Any,
        config: Dict[str, Any],
        tracker: Tracker,
    ) -> None:
        self._original = original_client
        self._config = config
        self._tracker = tracker
        self.messages = _AnthropicMessagesProxy(original_client.messages, config, tracker)

    @property
    def infershrink_tracker(self) -> Tracker:
        return self._tracker

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class _AnthropicMessagesProxy:
    """Proxy for ``client.messages`` on Anthropic clients."""

    def __init__(
        self,
        original_messages: Any,
        config: Dict[str, Any],
        tracker: Tracker,
    ) -> None:
        self._original = original_messages
        self._config = config
        self._tracker = tracker
        self._request_counter = RequestCounter()

    def create(self, **kwargs: Any) -> Any:
        """Intercept messages.create() for Anthropic clients."""
        messages = kwargs.get("messages", [])
        original_model = kwargs.get("model", "claude-sonnet-4-20250514")

        limits = self._config.get("_license_limits", {"compression_enabled": True})

        # Atomic check-and-increment to prevent race conditions
        max_requests = limits.get("max_requests_per_month")
        self._request_counter.check_and_increment(max_requests)

        # Anthropic puts system prompt separately
        system = kwargs.get("system", "")
        # Build combined messages for classification
        classify_messages = []
        if system:
            if isinstance(system, str):
                classify_messages.append({"role": "system", "content": system})
            elif isinstance(system, list):
                classify_messages.append(
                    {
                        "role": "system",
                        "content": " ".join(
                            p.get("text", "") if isinstance(p, dict) else str(p) for p in system
                        ),
                    }
                )
        classify_messages.extend(messages)

        # 1. Classify
        classification = classify(classify_messages)

        # 2. Compress (only the messages, not system)
        compression = compress(messages, classification.complexity, self._config)

        # 3. Route
        routing = route(original_model, classification.complexity, self._config)

        # 4. Build modified kwargs
        modified_kwargs = dict(kwargs)
        modified_kwargs["messages"] = compression.messages
        modified_kwargs["model"] = routing.routed_model

        # 5. Track
        if self._config.get("cost_tracking", True):
            self._tracker.record(
                original_model=original_model,
                routed_model=routing.routed_model,
                original_tokens=compression.original_tokens,
                compressed_tokens=compression.compressed_tokens,
                complexity=classification.complexity,
            )

        # 6. Call the real API
        return self._original.create(**modified_kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class InferShrinkClient:
    """Wrapped OpenAI client with InferShrink optimizations.

    Behaves exactly like the original client, but ``chat.completions.create()``
    calls are intercepted for compression and routing.
    """

    def __init__(
        self,
        original_client: Any,
        config: Dict[str, Any],
        tracker: Tracker,
    ) -> None:
        self._original = original_client
        self._config = config
        self._tracker = tracker
        self.chat = _InferShrinkChatProxy(original_client.chat, config, tracker)

    @property
    def infershrink_tracker(self) -> Tracker:
        """Access the cost tracker for this client."""
        return self._tracker

    def __getattr__(self, name: str) -> Any:
        """Forward everything else to the original client."""
        return getattr(self._original, name)


def _detect_client_type(client: Any) -> str:
    """Detect whether client is OpenAI-like or Anthropic-like."""
    client_type = type(client).__module__ or ""
    client_class = type(client).__name__ or ""

    if "anthropic" in client_type.lower() or "anthropic" in client_class.lower():
        return "anthropic"

    # Check for chat.completions pattern (OpenAI)
    if hasattr(client, "chat") and hasattr(getattr(client, "chat", None), "completions"):
        return "openai"

    # Check for messages pattern (Anthropic)
    if hasattr(client, "messages") and hasattr(getattr(client, "messages", None), "create"):
        return "anthropic"

    # Default to openai-compatible
    return "openai"


def optimize(
    client: Any,
    config: Optional[Config] = None,
) -> Any:
    """Wrap an LLM client with InferShrink optimizations.

    This is the main entry point — one line to cut your LLM costs.

    Parameters
    ----------
    client:
        An OpenAI or Anthropic client instance.
    config:
        Optional configuration overrides. Merged with defaults.

    Returns
    -------
    A wrapped client that transparently compresses prompts and routes
    to cheaper models when possible.

    Examples
    --------
    >>> import openai
    >>> from infershrink import optimize
    >>> client = optimize(openai.Client())
    >>> # Now use client.chat.completions.create() as usual
    """
    effective_config = build_config(config)

    # Validate license and inject limits into config
    license_key = (config or {}).get("license_key")
    license_info = validate_license(license_key)
    limits = get_limits(license_info.tier)
    effective_config["_license_info"] = {
        "tier": license_info.tier,
        "valid": license_info.valid,
    }
    effective_config["_license_limits"] = limits

    # Apply tier-based config overrides
    if not limits.get("compression_enabled", True):
        effective_config.setdefault("compression", {})["enabled"] = False

    tracker = Tracker(effective_config)
    client_type = _detect_client_type(client)

    if client_type == "anthropic":
        return _InferShrinkAnthropicProxy(client, effective_config, tracker)

    return InferShrinkClient(client, effective_config, tracker)
