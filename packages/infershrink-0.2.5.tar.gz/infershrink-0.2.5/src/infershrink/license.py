"""License key validation for InferShrink Pro/Team tiers.

Validates keys via LemonSqueezy API with 24h cache.
Free tier: no key needed, features gated by config.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from .types import InferShrinkQuotaError

logger = logging.getLogger(__name__)

LEMONSQUEEZY_VALIDATE_URL = "https://api.lemonsqueezy.com/v1/licenses/validate"
CACHE_TTL_SECONDS = 86400  # 24 hours
GRACE_PERIOD_SECONDS = 259200  # 72 hours — if API unreachable, honor cached result


def _safe_home_dir() -> Path:
    """Return the user's home directory, falling back to /tmp if unavailable."""
    try:
        return Path.home()
    except (RuntimeError, OSError):
        return Path("/tmp")  # noqa: S108


def _cache_path() -> Path:
    return _safe_home_dir() / ".infershrink" / "license_cache.json"


def _hash_key(key: str) -> str:
    """One-way hash of a license key for safe cache comparison."""
    return hashlib.sha256(key.encode()).hexdigest()


@dataclass
class LicenseInfo:
    """Validated license information."""

    tier: str  # "free", "pro", "team"
    valid: bool
    key: str
    instance_id: Optional[str] = None
    customer_email: Optional[str] = None
    expires_at: Optional[str] = None
    error: Optional[str] = None


# Feature gates per tier
TIER_LIMITS: Dict[str, Dict[str, Any]] = {
    "dev": {
        "max_requests_per_month": None,  # unlimited in dev
        "compression_enabled": True,
        "retrieval_enabled": True,
        "dedup_enabled": True,
        "max_models": None,
        "max_keys": 0,
    },
    "free": {
        "max_requests_per_month": 1000,
        "compression_enabled": False,
        "retrieval_enabled": False,
        "dedup_enabled": False,
        "max_models": 2,
        "max_keys": 0,
    },
    "pro": {
        "max_requests_per_month": 50000,
        "compression_enabled": True,
        "retrieval_enabled": True,
        "dedup_enabled": True,
        "max_models": None,  # unlimited
        "max_keys": 1,
    },
    "team": {
        "max_requests_per_month": 500000,
        "compression_enabled": True,
        "retrieval_enabled": True,
        "dedup_enabled": True,
        "max_models": None,
        "max_keys": 5,
    },
}


class RequestCounter:
    """Tracks monthly request usage for tier limits.

    Uses atomic check-and-increment with thread locking to prevent race
    conditions between concurrent callers.
    """

    def __init__(self, usage_file: Optional[Path] = None):
        if usage_file is None:
            usage_file = _safe_home_dir() / ".infershrink" / "usage.json"
        self.usage_file = Path(usage_file)
        self._lock = threading.Lock()

    def _get_current_month(self) -> str:
        """Get current month as YYYY-MM string."""
        return datetime.now(timezone.utc).strftime("%Y-%m")

    def _read_usage(self) -> dict:
        """Read usage data from file."""
        try:
            if not self.usage_file.exists():
                return {"month": self._get_current_month(), "count": 0}
            data = json.loads(self.usage_file.read_text(encoding="utf-8"))
            current_month = self._get_current_month()
            if data.get("month") != current_month:
                return {"month": current_month, "count": 0}
            return dict(data)
        except (json.JSONDecodeError, OSError):
            return {"month": self._get_current_month(), "count": 0}

    def _write_usage(self, data: dict) -> None:
        """Write usage data to file."""
        try:
            self.usage_file.parent.mkdir(parents=True, exist_ok=True)
            self.usage_file.write_text(json.dumps(data), encoding="utf-8")
        except OSError:
            logger.debug("Failed to write usage file: %s", self.usage_file)

    def check_and_increment(self, limit: Optional[int]) -> None:
        """Atomically check quota and increment counter.

        Raises InferShrinkQuotaError if limit would be exceeded.
        """
        with self._lock:
            usage = self._read_usage()
            current_count = usage.get("count", 0)

            if limit is not None and current_count >= limit:
                raise InferShrinkQuotaError(
                    f"Monthly request limit of {limit} exceeded. "
                    "Upgrade to Pro/Team for higher limits."
                )

            usage["count"] = current_count + 1
            usage["month"] = self._get_current_month()
            self._write_usage(usage)

    def check(self, limit: Optional[int]) -> None:
        """Raise InferShrinkQuotaError if limit exceeded."""
        if limit is None:
            return

        usage = self._read_usage()
        current_count = usage.get("count", 0)

        if current_count >= limit:
            raise InferShrinkQuotaError(
                f"Monthly request limit of {limit} exceeded. Upgrade to Pro/Team for higher limits."
            )

    def increment(self) -> None:
        """Increment request count."""
        with self._lock:
            usage = self._read_usage()
            current_count = usage.get("count", 0)
            usage["count"] = current_count + 1
            usage["month"] = self._get_current_month()
            self._write_usage(usage)

    def remaining(self, limit: Optional[int]) -> Optional[int]:
        """Return remaining requests. Returns None if unlimited."""
        if limit is None:
            return None

        usage = self._read_usage()
        current_count = usage.get("count", 0)
        return int(max(0, limit - current_count))


def _read_cache() -> Optional[dict]:
    """Read cached license validation result."""
    try:
        cache_path = _cache_path()
        if not cache_path.exists():
            return None
        data = json.loads(cache_path.read_text(encoding="utf-8"))
        return dict(data)
    except (json.JSONDecodeError, OSError):
        return None


def _write_cache(data: dict) -> None:
    """Write license validation result to cache."""
    try:
        cache_path = _cache_path()
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        cache_path.write_text(json.dumps(data), encoding="utf-8")
    except OSError:
        logger.debug("Failed to write license cache")


def _validate_remote(key: str) -> dict:
    """Call LemonSqueezy API to validate license key."""
    body = json.dumps({"license_key": key}).encode()
    req = urllib.request.Request(
        LEMONSQUEEZY_VALIDATE_URL,
        data=body,
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )
    resp = urllib.request.urlopen(req, timeout=10)  # noqa: S310
    return json.loads(resp.read().decode())  # type: ignore[no-any-return]


def _tier_from_variant(variant_name: str) -> str:
    """Map LemonSqueezy variant/product name to tier."""
    name = variant_name.lower()
    if "team" in name:
        return "team"
    if "pro" in name:
        return "pro"
    return "pro"  # default paid tier


def validate(key: Optional[str] = None) -> LicenseInfo:
    """Validate an InferShrink license key.

    Checks in order:
    1. Explicit key parameter
    2. INFERSHRINK_LICENSE_KEY env var
    3. No key → free tier

    Returns LicenseInfo with tier and feature gates.
    """
    # Resolve key
    if key is None:
        key = os.environ.get("INFERSHRINK_LICENSE_KEY", "")

    if not key or not key.strip():
        # No key = development/local mode — all features enabled, no limits
        return LicenseInfo(tier="dev", valid=True, key="")

    key = key.strip()
    key_hash = _hash_key(key)

    # Check cache first
    cache = _read_cache()
    now = time.time()

    if cache and cache.get("key_hash") == key_hash:
        cached_at = cache.get("validated_at", 0)
        age = now - cached_at

        if age < CACHE_TTL_SECONDS:
            # Fresh cache — use it
            return LicenseInfo(
                tier=cache.get("tier", "free"),
                valid=cache.get("valid", False),
                key=key,
                instance_id=cache.get("instance_id"),
                customer_email=cache.get("customer_email"),
                expires_at=cache.get("expires_at"),
            )

        if age < GRACE_PERIOD_SECONDS:
            # Stale cache but within grace period — try remote, fall back to cache
            try:
                return _do_remote_validation(key, now)
            except Exception:
                return LicenseInfo(
                    tier=cache.get("tier", "free"),
                    valid=cache.get("valid", False),
                    key=key,
                    instance_id=cache.get("instance_id"),
                    error="API unreachable, using cached result (grace period)",
                )

    # No cache or expired beyond grace — must validate
    try:
        return _do_remote_validation(key, now)
    except urllib.error.HTTPError as e:
        if e.code == 404 or e.code == 422:
            return LicenseInfo(
                tier="free",
                valid=False,
                key=key,
                error="Invalid license key",
            )
        return LicenseInfo(
            tier="free",
            valid=False,
            key=key,
            error=f"Validation failed: HTTP {e.code}",
        )
    except Exception as e:
        return LicenseInfo(
            tier="free",
            valid=False,
            key=key,
            error=f"Validation failed: {e}",
        )


def _do_remote_validation(key: str, now: float) -> LicenseInfo:
    """Validate against LemonSqueezy API and cache result."""
    result = _validate_remote(key)

    valid = result.get("valid", False)
    meta = result.get("meta", {})
    license_key = result.get("license_key", {})

    tier = "free"
    if valid:
        variant_name = meta.get("variant_name", "")
        product_name = meta.get("product_name", "")
        tier = _tier_from_variant(variant_name or product_name)

    info = LicenseInfo(
        tier=tier,
        valid=valid,
        key=key,
        instance_id=license_key.get("instance_id"),
        customer_email=license_key.get("customer_email"),
        expires_at=license_key.get("expires_at"),
    )

    # Cache the result (store key hash, never the raw key)
    _write_cache(
        {
            "key_hash": _hash_key(key),
            "tier": tier,
            "valid": valid,
            "validated_at": now,
            "instance_id": info.instance_id,
            "customer_email": info.customer_email,
            "expires_at": info.expires_at,
        }
    )

    return info


def get_limits(tier: str) -> dict:
    """Return feature limits for a tier."""
    return TIER_LIMITS.get(tier, TIER_LIMITS["free"]).copy()
