"""Integration tests for compression features (LLMLingua-2).

Tests in TestCompressionIntegration require: pip install infershrink[compression]
Tests in TestCompressionPassthrough run without LLMLingua.
"""

from __future__ import annotations

import pytest

from infershrink.compressor import compress, is_compression_available
from infershrink.config import build_config
from infershrink.types import Complexity


class TestCompressionAvailability:
    """Test compression availability detection."""

    def test_is_compression_available_returns_bool(self):
        result = is_compression_available()
        assert isinstance(result, bool)

    def test_availability_matches_import(self):
        try:
            import llmlingua  # noqa: F401

            assert is_compression_available() is True
        except ImportError:
            assert is_compression_available() is False


class TestCompressionPassthrough:
    """Tests that run without LLMLingua — verify pass-through behavior."""

    @pytest.fixture
    def config(self):
        return build_config()

    @pytest.fixture
    def config_disabled(self):
        return build_config({"compression": {"enabled": False}})

    def test_passthrough_when_disabled(self, config_disabled):
        messages = [{"role": "user", "content": "Hello world " * 200}]
        result = compress(messages, Complexity.SIMPLE, config_disabled)
        assert result.was_compressed is False
        assert result.messages == messages

    def test_passthrough_for_short_messages(self, config):
        messages = [{"role": "user", "content": "Hello world"}]
        result = compress(messages, Complexity.SIMPLE, config)
        assert result.was_compressed is False
        assert result.messages == messages

    def test_passthrough_for_security_critical(self, config):
        messages = [{"role": "user", "content": "Secret data " * 200}]
        result = compress(messages, Complexity.SECURITY_CRITICAL, config)
        assert result.was_compressed is False
        assert result.messages == messages

    def test_token_estimation(self, config):
        # Token count should be roughly len(text) / 4
        messages = [{"role": "user", "content": "word " * 400}]  # ~400 words ~500 chars
        result = compress(messages, Complexity.SIMPLE, config)
        # Even if not compressed, original_tokens should be estimated
        assert result.original_tokens > 0

    def test_handles_list_content(self, config):
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Hello world " * 200},
                    {"type": "image_url", "image_url": {"url": "http://example.com/img.png"}},
                ],
            }
        ]
        result = compress(messages, Complexity.SIMPLE, config)
        # Should not crash on list content
        assert result is not None


@pytest.mark.skipif(
    not is_compression_available(),
    reason="Requires: pip install infershrink[compression]",
)
class TestCompressionIntegration:
    """Integration tests that actually run LLMLingua compression."""

    @pytest.fixture
    def config(self):
        return build_config({"compression": {"enabled": True, "min_tokens": 50}})

    def test_compresses_long_prompt(self, config):
        # Create a long, repetitive prompt that should compress well
        long_text = (
            "The quick brown fox jumps over the lazy dog. "
            "This sentence contains every letter of the alphabet. "
        ) * 50  # ~1000 words

        messages = [{"role": "user", "content": long_text}]
        result = compress(messages, Complexity.SIMPLE, config)

        # Should actually compress
        assert result.was_compressed is True
        assert result.compressed_tokens <= result.original_tokens
        assert result.compression_ratio <= 1.0

    def test_compression_ratio_reasonable(self, config):
        # Compression should achieve some savings but not destroy content
        text = (
            "Machine learning models require large amounts of training data. "
            "The data should be clean, well-labeled, and representative. "
            "Feature engineering is important for traditional ML models. "
            "Deep learning can learn features automatically. "
        ) * 30

        messages = [{"role": "user", "content": text}]
        result = compress(messages, Complexity.SIMPLE, config)

        if result.was_compressed and result.compression_ratio < 1.0:
            # If compression actually reduced tokens, ratio should be reasonable
            assert 0.1 < result.compression_ratio < 0.9
        # Content should always survive
        assert len(result.messages[0]["content"]) > 100

    def test_respects_min_tokens_threshold(self, config):
        # Text below min_tokens should not be compressed
        short_text = "Hello world, this is a test."  # < 50 tokens
        messages = [{"role": "user", "content": short_text}]
        result = compress(messages, Complexity.SIMPLE, config)
        assert result.was_compressed is False

    def test_preserves_message_structure(self, config):
        text = "Important context for the task. " * 100
        messages = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": text},
        ]
        result = compress(messages, Complexity.SIMPLE, config)

        # Should preserve message structure
        assert len(result.messages) == 2
        assert result.messages[0]["role"] == "system"
        assert result.messages[1]["role"] == "user"

    def test_complexity_affects_compression(self, config):
        text = "Complex reasoning task " * 200

        # SECURITY_CRITICAL should skip compression
        result_critical = compress(
            [{"role": "user", "content": text}], Complexity.SECURITY_CRITICAL, config
        )
        assert result_critical.was_compressed is False

        # SIMPLE should allow compression
        result_simple = compress([{"role": "user", "content": text}], Complexity.SIMPLE, config)
        # May or may not compress depending on LLMLingua, but should run
        assert result_simple is not None
