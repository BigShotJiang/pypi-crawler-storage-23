"""
Shared fixtures for integration tests.

All tests use mock LLM clients that simulate API behavior
without making real API calls. This lets us verify InferShrink's
routing, compression, and tracking logic end-to-end.
"""

import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List

import pytest

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

from infershrink import classify, optimize
from infershrink.types import Complexity

# --- Mock LLM Infrastructure ---


@dataclass
class MockMessage:
    role: str
    content: str


@dataclass
class MockChoice:
    index: int = 0
    message: MockMessage = None
    finish_reason: str = "stop"


@dataclass
class MockUsage:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


@dataclass
class MockCompletion:
    id: str = "mock-completion"
    model: str = "qwen2.5:32b"
    choices: list = field(default_factory=list)
    usage: MockUsage = field(default_factory=MockUsage)
    created: int = 0

    def __post_init__(self):
        if not self.choices:
            self.choices = [
                MockChoice(message=MockMessage(role="assistant", content="Mock response"))
            ]
        self.created = int(time.time())


class MockCompletions:
    """Mock OpenAI chat.completions interface."""

    def __init__(self):
        self.calls: List[Dict] = []
        self._responses: Dict[str, str] = {}

    def set_response(self, pattern: str, response: str):
        """Set a canned response for messages matching a pattern."""
        self._responses[pattern] = response

    def create(self, **kwargs) -> MockCompletion:
        self.calls.append(kwargs)
        model = kwargs.get("model", "claude-opus-4-6")
        messages = kwargs.get("messages", [])

        # Calculate mock token counts
        prompt_text = " ".join(m.get("content", "") for m in messages)
        prompt_tokens = len(prompt_text.split())

        # Check for canned responses
        response_text = "Mock response"
        for pattern, resp in self._responses.items():
            if pattern.lower() in prompt_text.lower():
                response_text = resp
                break

        completion_tokens = len(response_text.split())

        return MockCompletion(
            model=model,
            choices=[MockChoice(message=MockMessage(role="assistant", content=response_text))],
            usage=MockUsage(
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=prompt_tokens + completion_tokens,
            ),
        )


class MockChat:
    def __init__(self):
        self.completions = MockCompletions()


class MockOpenAIClient:
    """Mock openai.Client() that records all calls."""

    def __init__(self):
        self.chat = MockChat()
        self._api_key = "mock-key"

    @property
    def api_key(self):
        return self._api_key


# --- Fixtures ---


@pytest.fixture
def mock_client():
    """Return a raw mock OpenAI client."""
    return MockOpenAIClient()


@pytest.fixture
def optimized_client():
    """Return a mock client wrapped with InferShrink optimize()."""
    client = MockOpenAIClient()
    return optimize(client)


@pytest.fixture
def tracked_client():
    """Return an optimized client with custom tier config for observable routing.

    Uses OpenAI models at all tiers so same-provider routing works.
    """
    client = MockOpenAIClient()
    config = {
        "tiers": {
            "tier1": {
                "models": ["gpt-4o-mini"],
                "max_complexity": "SIMPLE",
                "cost_per_1k_input": 0.00015,
            },
            "tier2": {
                "models": ["gpt-4o"],
                "max_complexity": "MODERATE",
                "cost_per_1k_input": 0.0025,
            },
            "tier3": {
                "models": ["gpt-4.5-preview"],
                "max_complexity": "COMPLEX",
                "cost_per_1k_input": 0.075,
            },
        },
        "compression": {"enabled": False},
        "cost_tracking": True,
    }
    return optimize(client, config=config)


@pytest.fixture
def classify_fn():
    """Return the classify function for direct complexity testing."""
    return classify


@pytest.fixture
def sample_research_corpus(tmp_path):
    """Create a sample document corpus for research tests."""
    docs = {
        "api_docs.md": """# API Documentation
## Rate Limits
- Free tier: 100 requests/minute
- Pro tier: 1000 requests/minute
- Enterprise: custom limits
All rate limits use a sliding window algorithm.
""",
        "setup_guide.md": """# Setup Guide
1. Install the SDK: pip install our-sdk
2. Set your API key: export API_KEY=your-key
3. Initialize: client = SDK(api_key=os.environ['API_KEY'])
4. Make your first call: response = client.query("hello")
""",
        "architecture.md": """# Architecture
The system uses a microservices architecture with:
- API Gateway (nginx)
- Auth Service (JWT + OAuth2)
- Query Engine (PostgreSQL + Redis)
- ML Pipeline (PyTorch, runs on GPU)
- Event Bus (Kafka)
All services communicate via gRPC with mTLS.
""",
        "troubleshooting.md": """# Troubleshooting
## Common Errors
### Error 429: Rate Limited
Wait and retry. Use exponential backoff.
### Error 500: Internal Server Error
Check status page. If persistent, contact support.
### Error 403: Forbidden
Verify your API key and permissions.
""",
        "pricing.md": """# Pricing
## Plans
- Free: 1000 queries/month, basic models
- Pro ($49/mo): 50,000 queries/month, all models
- Enterprise: custom pricing, SLA, dedicated support
Volume discounts available for annual billing.
""",
    }
    corpus_dir = tmp_path / "corpus"
    corpus_dir.mkdir()
    for name, content in docs.items():
        (corpus_dir / name).write_text(content)
    return corpus_dir


@pytest.fixture
def coding_tasks():
    """Return a list of coding tasks with expected complexity."""
    return [
        # Simple tasks
        {
            "prompt": "Add a docstring to this function: def add(a, b): return a + b",
            "expected_complexity": Complexity.SIMPLE,
            "category": "docstring",
        },
        {
            "prompt": "What does the len() function do in Python?",
            "expected_complexity": Complexity.SIMPLE,
            "category": "explanation",
        },
        {
            "prompt": "Fix the typo: pritn('hello')",
            "expected_complexity": Complexity.SIMPLE,
            "category": "typo",
        },
        {
            "prompt": "Convert this list to a set: [1, 2, 2, 3]",
            "expected_complexity": Complexity.SIMPLE,
            "category": "conversion",
        },
        {
            "prompt": "What is the difference between a list and a tuple?",
            "expected_complexity": Complexity.SIMPLE,
            "category": "explanation",
        },
        # Moderate tasks
        {
            "prompt": """Write a function that:
1. Reads a CSV file
2. Filters rows where 'status' == 'active'
3. Groups by 'department'
4. Returns the count per department as a dict

```python
import csv
# your code here
```""",
            "expected_complexity": Complexity.MODERATE,
            "category": "implementation",
        },
        {
            "prompt": """Review this code for bugs:
```python
def process_data(items):
    results = []
    for i in range(len(items)):
        if items[i]['value'] > 0:
            results.append(items[i]['name'])
    return results
```
The function sometimes raises KeyError.""",
            "expected_complexity": Complexity.MODERATE,
            "category": "review",
        },
        {
            "prompt": """Implement a simple LRU cache with get() and put() methods.
The cache should have a maximum capacity. When full, evict the least recently used item.
Use only standard library.""",
            "expected_complexity": Complexity.MODERATE,
            "category": "implementation",
        },
        # Complex tasks
        {
            "prompt": """Refactor this monolithic function into a proper class hierarchy:
```python
def process_order(order_type, items, customer, payment_method, shipping_address,
                  discount_code=None, gift_wrap=False, priority_shipping=False,
                  insurance=False, custom_message=None):
    total = 0
    for item in items:
        if item['type'] == 'physical':
            total += item['price'] * item['quantity']
            if priority_shipping:
                total += 15.99
            if insurance:
                total += item['price'] * 0.02
            if gift_wrap:
                total += 4.99
        elif item['type'] == 'digital':
            total += item['price']
        elif item['type'] == 'subscription':
            total += item['price'] * item.get('months', 1)

    if discount_code:
        if discount_code == 'SAVE10':
            total *= 0.9
        elif discount_code == 'HALFOFF':
            total *= 0.5

    if payment_method == 'credit_card':
        total *= 1.029  # processing fee
    elif payment_method == 'crypto':
        total *= 0.98   # crypto discount

    # ... 200 more lines of similar logic
    return {'total': total, 'items': items, 'customer': customer}
```
Apply SOLID principles. Create separate classes for pricing, discounts, shipping, and payment processing.
Include type hints, docstrings, and unit test stubs.""",
            "expected_complexity": Complexity.COMPLEX,
            "category": "refactor",
        },
        {
            "prompt": """Design and implement a concurrent task scheduler in Python that:
1. Supports priority queues with task dependencies (DAG)
2. Handles task failures with configurable retry policies
3. Provides real-time progress tracking via callbacks
4. Implements backpressure when worker pool is saturated
5. Supports graceful shutdown with in-flight task completion
Use asyncio. Include comprehensive error handling and logging.""",
            "expected_complexity": Complexity.COMPLEX,
            "category": "architecture",
        },
    ]


@pytest.fixture
def support_tickets():
    """Return customer support scenarios with expected complexity."""
    return [
        # Simple - FAQ / status check
        {
            "prompt": "What are your business hours?",
            "expected_complexity": Complexity.SIMPLE,
            "category": "faq",
        },
        {
            "prompt": "Where is my order #12345?",
            "expected_complexity": Complexity.SIMPLE,
            "category": "status",
        },
        {
            "prompt": "How do I reset my password?",
            "expected_complexity": Complexity.SIMPLE,
            "category": "faq",
        },
        {
            "prompt": "What is your return policy?",
            "expected_complexity": Complexity.SIMPLE,
            "category": "faq",
        },
        {
            "prompt": "Do you ship internationally?",
            "expected_complexity": Complexity.SIMPLE,
            "category": "faq",
        },
        {
            "prompt": "What payment methods do you accept?",
            "expected_complexity": Complexity.SIMPLE,
            "category": "faq",
        },
        {
            "prompt": "How do I track my order?",
            "expected_complexity": Complexity.SIMPLE,
            "category": "faq",
        },
        {
            "prompt": "Can I change my delivery address?",
            "expected_complexity": Complexity.SIMPLE,
            "category": "faq",
        },
        # Moderate - needs investigation
        {
            "prompt": """I ordered a laptop (order #98765) on January 15th.
The tracking says delivered but I never received it. I've checked with
my neighbors and the building reception. The delivery photo shows a
completely different building. Can you investigate?""",
            "expected_complexity": Complexity.MODERATE,
            "category": "investigation",
        },
        {
            "prompt": """I've been charged twice for the same subscription.
Transaction IDs: TXN-001 ($49.99 on Feb 1) and TXN-002 ($49.99 on Feb 3).
My account shows only one active subscription. Please refund the duplicate.""",
            "expected_complexity": Complexity.MODERATE,
            "category": "billing",
        },
        {
            "prompt": """Three items from my order arrived damaged:
- Blue widget (cracked screen)
- Red gadget (missing parts)
- Green device (water damage)
Order #45678. I have photos. I want replacements for the first two
and a refund for the third since it's now out of stock.""",
            "expected_complexity": Complexity.MODERATE,
            "category": "returns",
        },
        # Complex - multi-system, escalation
        {
            "prompt": """I'm a business customer (account #BIZ-5000) and I'm having
multiple issues that seem related:
1. Our API integration stopped working yesterday (error 401 on all endpoints)
2. Our billing dashboard shows $0 balance but we got a payment failed email
3. Two team members lost access to the admin panel
4. Our webhook endpoint stopped receiving events
We have a production system depending on your API and this is causing us
significant revenue loss (~$5000/hour). We need immediate escalation to
your engineering team. Our SLA guarantees 99.99% uptime and 15-minute
response time for P1 incidents. Please check if there's an ongoing
infrastructure issue affecting enterprise accounts.""",
            "expected_complexity": Complexity.COMPLEX,
            "category": "escalation",
        },
    ]


@pytest.fixture
def data_tasks():
    """Return data analysis tasks with sample data."""
    return [
        # Simple
        {
            "prompt": "What is the average of these numbers: 10, 20, 30, 40, 50?",
            "expected_complexity": Complexity.SIMPLE,
            "category": "basic_math",
        },
        {
            "prompt": "Count how many items are in this list: apple, banana, cherry, date, elderberry",
            "expected_complexity": Complexity.SIMPLE,
            "category": "counting",
        },
        # Moderate
        {
            "prompt": """Analyze this sales data and identify trends:
| Month | Revenue | Units | Region |
|-------|---------|-------|--------|
| Jan   | $45000  | 120   | North  |
| Feb   | $52000  | 145   | North  |
| Mar   | $48000  | 132   | South  |
| Apr   | $61000  | 168   | North  |
| May   | $55000  | 150   | South  |
| Jun   | $72000  | 195   | North  |

What's the month-over-month growth? Which region performs better?
Calculate the correlation between units and revenue.""",
            "expected_complexity": Complexity.MODERATE,
            "category": "analysis",
        },
        # Complex
        {
            "prompt": """Given this multi-dimensional dataset of customer behavior:

```json
{
  "customers": [
    {"id": 1, "purchases": [10, 25, 5, 50], "visits": 45, "tenure_months": 24, "segment": "premium", "churn_risk": 0.15},
    {"id": 2, "purchases": [100, 200, 150], "visits": 12, "tenure_months": 6, "segment": "new", "churn_risk": 0.65},
    {"id": 3, "purchases": [30, 30, 30, 30, 30], "visits": 60, "tenure_months": 36, "segment": "loyal", "churn_risk": 0.05}
  ]
}
```

1. Build a cohort analysis model
2. Identify key churn predictors using statistical methods
3. Propose an intervention strategy for each risk tier
4. Calculate customer lifetime value (CLV) using probabilistic models
5. Design A/B test parameters for the intervention strategies""",
            "expected_complexity": Complexity.COMPLEX,
            "category": "modeling",
        },
    ]


@pytest.fixture
def content_tasks():
    """Return content generation tasks."""
    return [
        # Simple
        {
            "prompt": "Write a tweet about our new product launch.",
            "expected_complexity": Complexity.SIMPLE,
            "category": "social",
        },
        {
            "prompt": "Write a subject line for a welcome email.",
            "expected_complexity": Complexity.SIMPLE,
            "category": "email",
        },
        {
            "prompt": "Create a one-line product tagline for a fitness app.",
            "expected_complexity": Complexity.SIMPLE,
            "category": "tagline",
        },
        # Moderate
        {
            "prompt": """Write a professional email to a client explaining:
- Their project deadline is being extended by 2 weeks
- The reason is a supply chain delay (not our fault)
- We're adding a 10% discount as goodwill
- Next steps: schedule a call this week to discuss revised timeline
Tone: apologetic but confident. Max 200 words.""",
            "expected_complexity": Complexity.MODERATE,
            "category": "email",
        },
        {
            "prompt": """Write a 500-word blog post introduction about the rise of
AI agents in enterprise. Include:
- A compelling hook
- 2-3 statistics (you can use approximate industry figures)
- A thesis statement
- Transition to the main body
Target audience: CTOs and VPs of Engineering.""",
            "expected_complexity": Complexity.MODERATE,
            "category": "blog",
        },
        # Complex
        {
            "prompt": """Create a comprehensive content strategy document for launching
an AI security product. Include:
1. Executive summary
2. Target persona profiles (3 personas)
3. Content pillars (4-5 themes)
4. Channel strategy (LinkedIn, blog, email, webinars)
5. Content calendar for 3 months (weekly cadence)
6. KPIs and measurement framework
7. Competitive positioning messaging
8. Sample LinkedIn post series (5 posts)
9. Webinar outline for "AI Security in 2026"
The product helps enterprises govern AI agent behavior.""",
            "expected_complexity": Complexity.COMPLEX,
            "category": "strategy",
        },
    ]


@pytest.fixture
def multi_agent_workflows():
    """Return multi-agent workflow scenarios."""
    return [
        {
            "name": "research_to_report",
            "description": "Research agent gathers info, writer agent creates report",
            "steps": [
                {
                    "agent": "researcher",
                    "prompt": "Find the top 3 benefits of microservices architecture",
                    "expected_complexity": Complexity.SIMPLE,
                },
                {
                    "agent": "writer",
                    "prompt": "Write a 300-word executive summary about microservices benefits based on: benefit 1, benefit 2, benefit 3",
                    "expected_complexity": Complexity.MODERATE,
                },
                {
                    "agent": "reviewer",
                    "prompt": "Review this executive summary for accuracy and tone: [summary text]",
                    "expected_complexity": Complexity.MODERATE,
                },
            ],
        },
        {
            "name": "code_review_pipeline",
            "description": "Analyzer finds issues, fixer resolves them, tester validates",
            "steps": [
                {
                    "agent": "analyzer",
                    "prompt": """Analyze this code for security issues:
```python
def login(username, password):
    query = f"SELECT * FROM users WHERE name='{username}' AND pass='{password}'"
    return db.execute(query)
```""",
                    "expected_complexity": Complexity.MODERATE,
                },
                {
                    "agent": "fixer",
                    "prompt": """Fix the SQL injection vulnerability in this code:
```python
def login(username, password):
    query = f"SELECT * FROM users WHERE name='{username}' AND pass='{password}'"
    return db.execute(query)
```
Use parameterized queries.""",
                    "expected_complexity": Complexity.MODERATE,
                },
                {
                    "agent": "tester",
                    "prompt": "Write pytest tests for a login function that uses parameterized SQL queries",
                    "expected_complexity": Complexity.MODERATE,
                },
            ],
        },
    ]


# --- Helpers ---


def assert_routing(client, prompt: str, expected_model_substring: str):
    """Assert that a prompt gets routed to a model containing the expected substring."""
    response = client.chat.completions.create(
        model="claude-opus-4-6",
        messages=[{"role": "user", "content": prompt}],
    )
    actual_model = client.chat.completions.calls[-1].get("model", "")
    assert expected_model_substring in actual_model.lower(), (
        f"Expected model containing '{expected_model_substring}', got '{actual_model}'"
    )
    return response
