#!/usr/bin/env bash
# Run all integration tests — locally or in Docker.
# Usage:
#   ./tests/integration/run_all.sh          # Local
#   ./tests/integration/run_all.sh docker   # Docker

set -euo pipefail
cd "$(dirname "$0")/../.."

MODE="${1:-local}"

if [ "$MODE" = "docker" ]; then
    echo "=== Building Docker image ==="
    docker build -t infershrink-tests -f tests/integration/Dockerfile .
    
    echo "=== Running tests in Docker ==="
    docker run --rm infershrink-tests
    
    echo ""
    echo "=== Docker tests complete ==="
else
    echo "=== Running integration tests locally ==="
    echo ""
    
    PYTHONPATH=src python3 -m pytest tests/integration/ -v --tb=short \
        --junitxml=tests/integration/results.xml
    
    echo ""
    echo "=== Running unit tests ==="
    python3 -m pytest tests/ -q --tb=line \
        --ignore=tests/integration/
    
    echo ""
    echo "=== All tests complete ==="
fi
