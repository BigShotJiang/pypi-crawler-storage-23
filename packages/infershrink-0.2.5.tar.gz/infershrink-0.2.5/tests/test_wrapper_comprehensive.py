"""Comprehensive wrapper tests — parameter preservation, Anthropic, edge cases."""

from unittest.mock import MagicMock

from infershrink.tracker import Tracker
from infershrink.wrapper import (
    _detect_client_type,
    _InferShrinkAnthropicProxy,
    optimize,
)

# ====================================================================
# Mock clients
# ====================================================================


class MockCompletions:
    def create(self, **kwargs):
        self._last_kwargs = kwargs
        return MagicMock(
            choices=[MagicMock(message=MagicMock(content="Response", role="assistant"))],
            model=kwargs.get("model", "qwen2.5:32b"),
            usage=MagicMock(prompt_tokens=10, completion_tokens=5, total_tokens=15),
        )

    def list(self):
        """Another method on completions that should be proxied."""
        return ["model1", "model2"]


class MockChat:
    def __init__(self):
        self.completions = MockCompletions()

    def other_method(self):
        return "chat_other"


class MockOpenAIClient:
    def __init__(self):
        self.chat = MockChat()
        self.api_key = "sk-test"
        self.base_url = "https://api.openai.com"

    def models_list(self):
        return ["claude-opus-4-6", "qwen2.5:32b"]


class MockAnthropicMessages:
    def create(self, **kwargs):
        self._last_kwargs = kwargs
        return MagicMock(
            content=[MagicMock(text="Response", type="text")],
            model=kwargs.get("model", "claude-sonnet-4-20250514"),
            usage=MagicMock(input_tokens=10, output_tokens=5),
        )

    def list(self):
        return ["msg1", "msg2"]


class MockAnthropicClient:
    def __init__(self):
        self.messages = MockAnthropicMessages()
        self.api_key = "sk-ant-test"

    class __class__:
        __module__ = "anthropic"
        __name__ = "Anthropic"


# ====================================================================
# Client type detection
# ====================================================================


class TestClientTypeDetection:
    def test_detects_openai(self):
        assert _detect_client_type(MockOpenAIClient()) == "openai"

    def test_detects_anthropic_by_module(self):
        assert _detect_client_type(MockAnthropicClient()) == "anthropic"

    def test_detects_anthropic_by_messages_pattern(self):
        """Client with .messages.create() pattern detected as anthropic."""
        client = MagicMock()
        client.__class__.__module__ = "my_custom_module"
        client.__class__.__name__ = "CustomClient"
        del client.chat  # Remove chat attribute
        assert _detect_client_type(client) == "anthropic"

    def test_unknown_defaults_to_openai(self):
        """Client with no recognizable pattern defaults to openai."""
        client = MagicMock(spec=[])  # No attributes
        # spec=[] means it has no attributes at all
        # hasattr checks will fail
        result = _detect_client_type(client)
        assert result == "openai"

    def test_detects_openai_by_chat_completions(self):
        """Client with chat.completions pattern detected as openai."""
        client = MagicMock()
        client.__class__.__module__ = "some_module"
        client.__class__.__name__ = "SomeClient"
        # MagicMock already has .chat.completions by default
        assert _detect_client_type(client) == "openai"


# ====================================================================
# OpenAI parameter preservation
# ====================================================================


class TestOpenAIParameterPreservation:
    """Ensure all OpenAI API parameters are forwarded to the underlying client."""

    def test_temperature_preserved(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
            temperature=0.7,
        )
        assert mock.chat.completions._last_kwargs["temperature"] == 0.7

    def test_max_tokens_preserved(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
            max_tokens=100,
        )
        assert mock.chat.completions._last_kwargs["max_tokens"] == 100

    def test_top_p_preserved(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
            top_p=0.9,
        )
        assert mock.chat.completions._last_kwargs["top_p"] == 0.9

    def test_frequency_penalty_preserved(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
            frequency_penalty=0.5,
        )
        assert mock.chat.completions._last_kwargs["frequency_penalty"] == 0.5

    def test_presence_penalty_preserved(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
            presence_penalty=0.3,
        )
        assert mock.chat.completions._last_kwargs["presence_penalty"] == 0.3

    def test_stop_sequences_preserved(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
            stop=["END", "\n\n"],
        )
        assert mock.chat.completions._last_kwargs["stop"] == ["END", "\n\n"]

    def test_stream_preserved(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
            stream=True,
        )
        assert mock.chat.completions._last_kwargs["stream"] is True

    def test_tools_preserved(self):
        tools = [
            {
                "type": "function",
                "function": {
                    "name": "get_weather",
                    "parameters": {"type": "object", "properties": {"city": {"type": "string"}}},
                },
            }
        ]
        mock = MockOpenAIClient()
        client = optimize(mock)
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Weather in Tokyo?"}],
            tools=tools,
        )
        assert mock.chat.completions._last_kwargs["tools"] == tools

    def test_tool_choice_preserved(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
            tool_choice="auto",
        )
        assert mock.chat.completions._last_kwargs["tool_choice"] == "auto"

    def test_response_format_preserved(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
            response_format={"type": "json_object"},
        )
        assert mock.chat.completions._last_kwargs["response_format"] == {"type": "json_object"}

    def test_seed_preserved(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
            seed=42,
        )
        assert mock.chat.completions._last_kwargs["seed"] == 42

    def test_n_preserved(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
            n=3,
        )
        assert mock.chat.completions._last_kwargs["n"] == 3

    def test_logprobs_preserved(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
            logprobs=True,
            top_logprobs=5,
        )
        assert mock.chat.completions._last_kwargs["logprobs"] is True
        assert mock.chat.completions._last_kwargs["top_logprobs"] == 5

    def test_user_preserved(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
            user="user-123",
        )
        assert mock.chat.completions._last_kwargs["user"] == "user-123"

    def test_model_is_overridden(self):
        """Model should be changed by the router (for simple tasks)."""
        mock = MockOpenAIClient()
        client = optimize(mock)
        client.chat.completions.create(
            model="gpt-4o",  # tier2 OpenAI
            messages=[{"role": "user", "content": "Hi"}],
        )
        # Simple task → routed to gpt-4o-mini (tier1 OpenAI, same provider)
        assert mock.chat.completions._last_kwargs["model"] == "gpt-4o-mini"

    def test_all_params_at_once(self):
        """Multiple parameters all preserved simultaneously."""
        mock = MockOpenAIClient()
        client = optimize(mock)
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
            temperature=0.5,
            max_tokens=200,
            top_p=0.95,
            stream=False,
            seed=42,
            n=1,
            user="test-user",
        )
        kwargs = mock.chat.completions._last_kwargs
        assert kwargs["temperature"] == 0.5
        assert kwargs["max_tokens"] == 200
        assert kwargs["top_p"] == 0.95
        assert kwargs["stream"] is False
        assert kwargs["seed"] == 42
        assert kwargs["n"] == 1
        assert kwargs["user"] == "test-user"


# ====================================================================
# Anthropic wrapper tests
# ====================================================================


class TestAnthropicWrapper:
    """Test Anthropic client wrapping."""

    def test_returns_anthropic_proxy(self):
        client = optimize(MockAnthropicClient())
        assert isinstance(client, _InferShrinkAnthropicProxy)

    def test_preserves_api_key(self):
        client = optimize(MockAnthropicClient())
        assert client.api_key == "sk-ant-test"

    def test_has_tracker(self):
        client = optimize(MockAnthropicClient())
        assert isinstance(client.infershrink_tracker, Tracker)

    def test_messages_create_works(self):
        client = optimize(MockAnthropicClient())
        response = client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello!"}],
        )
        assert response is not None

    def test_tracks_requests(self):
        client = optimize(MockAnthropicClient())
        client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello!"}],
        )
        stats = client.infershrink_tracker.stats()
        assert stats.total_requests == 1

    def test_simple_task_downgraded(self):
        mock = MockAnthropicClient()
        client = optimize(mock)
        client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hi"}],
        )
        # Claude Opus (tier3) + simple → claude-sonnet (tier2) same provider
        routed = mock.messages._last_kwargs["model"]
        assert routed in ["claude-sonnet-4-20250514", "claude-3-5-haiku-20241022"]
        stats = client.infershrink_tracker.stats()
        assert stats.requests_downgraded == 1

    def test_security_never_downgraded(self):
        mock = MockAnthropicClient()
        client = optimize(mock)
        client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Store this password safely"}],
        )
        assert mock.messages._last_kwargs["model"] == "claude-opus-4-6"

    def test_system_prompt_classified(self):
        """Anthropic's separate system param should be used for classification."""
        mock = MockAnthropicClient()
        client = optimize(mock)
        client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1024,
            system="You handle passwords and secrets securely.",
            messages=[{"role": "user", "content": "Help me"}],
        )
        # "passwords" and "secrets" are security keywords → security_critical
        assert mock.messages._last_kwargs["model"] == "claude-opus-4-6"

    def test_system_prompt_as_list(self):
        """Anthropic system can be a list of content blocks."""
        mock = MockAnthropicClient()
        client = optimize(mock)
        client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1024,
            system=[{"type": "text", "text": "You are helpful."}],
            messages=[{"role": "user", "content": "Hi"}],
        )
        # Should not crash
        stats = client.infershrink_tracker.stats()
        assert stats.total_requests == 1

    def test_max_tokens_preserved(self):
        mock = MockAnthropicClient()
        client = optimize(mock)
        client.messages.create(
            model="claude-opus-4-6",
            max_tokens=2048,
            messages=[{"role": "user", "content": "Hi"}],
        )
        assert mock.messages._last_kwargs["max_tokens"] == 2048

    def test_temperature_preserved(self):
        mock = MockAnthropicClient()
        client = optimize(mock)
        client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hi"}],
            temperature=0.3,
        )
        assert mock.messages._last_kwargs["temperature"] == 0.3

    def test_top_p_preserved(self):
        mock = MockAnthropicClient()
        client = optimize(mock)
        client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hi"}],
            top_p=0.9,
        )
        assert mock.messages._last_kwargs["top_p"] == 0.9

    def test_stop_sequences_preserved(self):
        mock = MockAnthropicClient()
        client = optimize(mock)
        client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hi"}],
            stop_sequences=["END"],
        )
        assert mock.messages._last_kwargs["stop_sequences"] == ["END"]

    def test_stream_preserved(self):
        mock = MockAnthropicClient()
        client = optimize(mock)
        client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hi"}],
            stream=True,
        )
        assert mock.messages._last_kwargs["stream"] is True

    def test_metadata_preserved(self):
        mock = MockAnthropicClient()
        client = optimize(mock)
        client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hi"}],
            metadata={"user_id": "123"},
        )
        assert mock.messages._last_kwargs["metadata"] == {"user_id": "123"}


# ====================================================================
# Proxy forwarding
# ====================================================================


class TestProxyForwarding:
    """Test that proxies forward unknown attributes to originals."""

    def test_openai_client_forwards_attributes(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        assert client.api_key == "sk-test"
        assert client.base_url == "https://api.openai.com"
        assert client.models_list() == ["claude-opus-4-6", "qwen2.5:32b"]

    def test_openai_chat_forwards_methods(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        assert client.chat._original.other_method() == "chat_other"

    def test_openai_completions_forwards_methods(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        result = client.chat.completions.list()
        assert result == ["model1", "model2"]

    def test_anthropic_client_forwards_attributes(self):
        mock = MockAnthropicClient()
        client = optimize(mock)
        assert client.api_key == "sk-ant-test"

    def test_anthropic_messages_forwards_methods(self):
        mock = MockAnthropicClient()
        client = optimize(mock)
        result = client.messages.list()
        assert result == ["msg1", "msg2"]


# ====================================================================
# Edge cases
# ====================================================================


class TestWrapperEdgeCases:
    def test_no_messages_kwarg(self):
        """If messages is missing, should default to empty list."""
        mock = MockOpenAIClient()
        client = optimize(mock)
        # This should not crash
        response = client.chat.completions.create(model="claude-opus-4-6")
        assert response is not None

    def test_no_model_kwarg(self):
        """If model is missing, should default to claude-opus-4-6."""
        mock = MockOpenAIClient()
        client = optimize(mock)
        response = client.chat.completions.create(messages=[{"role": "user", "content": "Hi"}])
        assert response is not None

    def test_empty_messages(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        response = client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[],
        )
        assert response is not None

    def test_optimize_idempotent_wrapping(self):
        """Optimizing an already-optimized client should work (wraps again)."""
        mock = MockOpenAIClient()
        client1 = optimize(mock)
        optimize(client1)
        # Should not crash — creates a wrapper around a wrapper
        # The inner wrapper's chat.completions acts as the "original"

    def test_multiple_calls_same_client(self):
        mock = MockOpenAIClient()
        client = optimize(mock)
        for i in range(20):
            client.chat.completions.create(
                model="claude-opus-4-6",
                messages=[{"role": "user", "content": f"Message {i}"}],
            )
        stats = client.infershrink_tracker.stats()
        assert stats.total_requests == 20

    def test_anthropic_no_system_prompt(self):
        """Anthropic call without system param should work fine."""
        mock = MockAnthropicClient()
        client = optimize(mock)
        client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hi"}],
        )
        stats = client.infershrink_tracker.stats()
        assert stats.total_requests == 1

    def test_anthropic_empty_system_prompt(self):
        mock = MockAnthropicClient()
        client = optimize(mock)
        client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1024,
            system="",
            messages=[{"role": "user", "content": "Hi"}],
        )
        stats = client.infershrink_tracker.stats()
        assert stats.total_requests == 1


# ====================================================================
# Config variations
# ====================================================================


class TestWrapperConfigVariations:
    def test_cost_tracking_disabled(self):
        mock = MockOpenAIClient()
        client = optimize(mock, config={"cost_tracking": False})
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
        )
        stats = client.infershrink_tracker.stats()
        assert stats.total_requests == 0

    def test_compression_disabled(self):
        mock = MockOpenAIClient()
        client = optimize(mock, config={"compression": {"enabled": False}})
        long_text = "word " * 500
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": long_text}],
        )
        stats = client.infershrink_tracker.stats()
        assert stats.requests_compressed == 0

    def test_custom_tiers(self):
        mock = MockOpenAIClient()
        client = optimize(
            mock,
            config={
                "tiers": {
                    "tier1": {"models": ["gpt-mini-custom"], "cost_per_1k_input": 0.0001},
                }
            },
        )
        client.chat.completions.create(
            model="gpt-4o",  # OpenAI provider
            messages=[{"role": "user", "content": "Hi"}],
        )
        # gpt-4o (openai) + simple → gpt-mini-custom (openai, same provider)
        assert mock.chat.completions._last_kwargs["model"] == "gpt-mini-custom"
