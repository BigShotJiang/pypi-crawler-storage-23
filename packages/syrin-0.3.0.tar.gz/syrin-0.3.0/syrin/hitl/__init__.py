"""Human-in-the-loop approval gates."""

from syrin.hitl._gate import ApprovalGate, ApprovalGateProtocol

__all__ = ["ApprovalGate", "ApprovalGateProtocol"]
