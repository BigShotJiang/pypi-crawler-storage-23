from __future__ import annotations

from dataclasses import dataclass
from typing import Any


class HardsimError(Exception):
    """Base class for all SDK errors."""


class HardsimConfigurationError(HardsimError):
    """Raised when required client configuration is missing or invalid."""


@dataclass
class HardsimRequestError(HardsimError):
    """HTTP request failed with a non-success status code."""

    status_code: int
    detail: str

    def __str__(self) -> str:
        return f"HTTP {self.status_code}: {self.detail}"


class HardsimAuthenticationError(HardsimRequestError):
    """Authentication/authorization failed."""


class HardsimNotFoundError(HardsimRequestError):
    """Requested resource does not exist."""


class HardsimRateLimitError(HardsimRequestError):
    """Request was throttled by the API."""


class HardsimServerError(HardsimRequestError):
    """Server-side error after retries."""


class HardsimTransportError(HardsimError):
    """Network or transport failure after retries."""


@dataclass
class HardsimJobError(HardsimError):
    """Base class for terminal job errors."""

    job_id: str
    status: str
    payload: dict[str, Any]

    def __str__(self) -> str:
        reason = self.payload.get("error") or "unknown job error"
        return f"job {self.job_id} ended with status={self.status}: {reason}"


class HardsimJobFailedError(HardsimJobError):
    """Job reached failed state."""


class HardsimJobCanceledError(HardsimJobError):
    """Job reached canceled state."""


class HardsimJobTimeoutError(HardsimError):
    """wait(...) exceeded timeout before reaching a terminal state."""

