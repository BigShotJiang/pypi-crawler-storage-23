from yt_dude.postprocessor.common import PostProcessor


class NormalPluginPP(PostProcessor):
    REPLACED = False
