from yt_dude.extractor.common import InfoExtractor


class IgnorePluginIE(InfoExtractor):
    pass
