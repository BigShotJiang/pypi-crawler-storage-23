from yt_dude.extractor.common import InfoExtractor


class PackagePluginIE(InfoExtractor):
    _VALID_URL = 'package'
    pass
