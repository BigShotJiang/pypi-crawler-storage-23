from yt_dude.postprocessor.common import PostProcessor


class ZippedPluginPP(PostProcessor):
    pass
