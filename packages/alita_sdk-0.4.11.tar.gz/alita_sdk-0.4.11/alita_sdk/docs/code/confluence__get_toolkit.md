# confluence - get_toolkit

**Toolkit**: `confluence`
**Method**: `get_toolkit`
**Source File**: `__init__.py`
**Class**: `ConfluenceToolkit`

---

## Method Implementation

```python
    def get_toolkit(cls, selected_tools: list[str] | None = None, toolkit_name: Optional[str] = None, **kwargs):
        if selected_tools is None:
            selected_tools = []
        wrapper_payload = {
            **kwargs,
            # TODO use confluence_configuration fields
            **kwargs['confluence_configuration'],
            **(kwargs.get('pgvector_configuration') or {}),
        }
        confluence_api_wrapper = ConfluenceAPIWrapper(**wrapper_payload)
        available_tools = confluence_api_wrapper.get_available_tools()
        tools = []
        for tool in available_tools:
            if selected_tools:
                if tool["name"] not in selected_tools:
                    continue
            description = tool["description"]
            if toolkit_name:
                description = f"Toolkit: {toolkit_name}\n{description}"
            description = f"Confluence space: {confluence_api_wrapper.space}\n{description}"
            description = description[:1000]
            tools.append(BaseAction(
                api_wrapper=confluence_api_wrapper,
                name=tool["name"],
                description=description,
                args_schema=tool["args_schema"],
                metadata={TOOLKIT_NAME_META: toolkit_name, TOOLKIT_TYPE_META: name, TOOL_NAME_META: tool["name"]} if toolkit_name else {TOOL_NAME_META: tool["name"]}
            ))
        return cls(tools=tools)
```
