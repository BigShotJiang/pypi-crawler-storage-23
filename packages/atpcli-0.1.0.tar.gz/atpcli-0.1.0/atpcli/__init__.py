"""atpcli - A Python CLI wrapper around the atproto package."""

__version__ = "0.1.0"
