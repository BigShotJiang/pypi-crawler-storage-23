# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2025 Maurice Garcia

"""Shared API models and utilities."""
from __future__ import annotations

__all__ = []
