# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Maurice Garcia

from __future__ import annotations

from pypnm_cmts.api.routes.serving_group.operations.router import router

__all__ = [
    "router",
]
