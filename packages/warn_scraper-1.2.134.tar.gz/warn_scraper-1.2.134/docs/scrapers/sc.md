---
orphan: true
---

# South Carolina

## Site:
https://scworks.org/employer/employer-programs/at-risk-of-closing/layoff-notification-reports

### 10/8/2021
Sent email to SC asking about a more machine-readable format for data than .pdfs.
