# AnalogAI Foundation

A comprehensive Python package for building AI agent systems with advanced capabilities including emotional intelligence, inference mechanisms, and multi-database support.

## Installation

Install the package in editable mode:

```bash
pip install -e .
```

Install with development dependencies:

```bash
pip install -e ".[dev]"
```

## Project Structure

```
Foundation/
├── src/
│   ├── common/         # Shared utilities and design patterns
│   ├── core/           # Core domain entities and services
│   ├── infrastructure/ # Infrastructure implementations
│   └── libs/           # Library modules (auth, metrics, etc.)
├── pyproject.toml       # Unified package configuration
├── setup.py             # Setup helper
├── MANIFEST.in          # Package manifest
└── README.md
```

## Modules

### Common (`src/common/`)
- **Design Patterns**: Chain of responsibility, singleton, state machine
- **Logging**: Application logging utilities
- **Utils**: Dictionary utilities and helpers

### Core (`src/core/`)
- **Entities**: Domain entities (Agent, Belief, Conversation, etc.)
- **Services**: Business logic services
- **Repositories**: Data access interfaces
- **Enums**: Domain enumerations
- **Mappings**: Emotion and activation mappings

### Infrastructure (`src/infrastructure/core/`)
- **Repositories**: Concrete repository implementations
  - In-memory storage
  - MongoDB storage
  - Neo4j graph database
- **Storage Adapters**: Vector store and query storage adapters
  - FAISS
  - Pinecone
  - In-memory implementations
- **Gateways**: Database gateways

### Libs (`src/libs/`)
- **Authentication**: JWT and authentication services
- **Authorization**: Authorization services
- **Metrics**: Metrics recording and reporting
- **Dev Tools**: Development utilities

## Requirements

- Python >= 3.12
- See `pyproject.toml` for complete dependency list

## Development

### Running Tests

The project uses Python's built-in `unittest` framework:

```bash
python -m unittest discover -s src -p "test_*.py"
```

### Code Quality

Format code with black:

```bash
black src/
```

Lint with ruff:

```bash
ruff check src/
```

Type check with mypy:

```bash
mypy src/
```

### Coverage

Run coverage report:

```bash
coverage run -m unittest discover -s src -p "test_*.py"
coverage report
coverage html
```

## License

MIT

