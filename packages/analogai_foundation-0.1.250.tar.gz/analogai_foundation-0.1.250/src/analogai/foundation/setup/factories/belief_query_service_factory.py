from typing import Optional

from analogai.foundation.extensions.belief_query.services.belief_query_service import BeliefQueryService
from analogai.foundation.modules.belief.belief_service import BeliefService
from analogai.foundation.common.utils.similarity.similarity_service import SimilarityService
from analogai.foundation import config


class BeliefQueryServiceFactory:
    def __init__(
        self,
        belief_service: BeliefService,
        similarity_service: Optional[SimilarityService] = None,
    ):
        self._belief_service = belief_service
        self._similarity_service = similarity_service

    def get_service(self) -> BeliefQueryService:
        similarity_service = self._similarity_service
        if similarity_service is None and config.USE_VECTOR_SEARCH:
            from analogai.foundation.infrastructure.services.embedding_similarity_service import (
                EmbeddingSimilarityService,
            )

            similarity_service = EmbeddingSimilarityService()
        return BeliefQueryService(
            belief_service=self._belief_service,
            similarity_service=similarity_service,
        )
