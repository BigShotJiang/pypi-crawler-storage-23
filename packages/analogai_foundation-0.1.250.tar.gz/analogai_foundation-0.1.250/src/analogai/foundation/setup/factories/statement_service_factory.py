from analogai.foundation.modules.direct_statement.direct_statement_service import StatementService
from .repository_selector import create_repository_strategy


class StatementServiceFactory:
    def __init__(self, repository=None, environment: str | None = None):
        self.repository = repository or create_repository_strategy(environment).get_statement_repository()
        self.service = StatementService(self.repository)

    def get_service(self) -> StatementService:
        return self.service

    def get_repository(self):
        return self.repository