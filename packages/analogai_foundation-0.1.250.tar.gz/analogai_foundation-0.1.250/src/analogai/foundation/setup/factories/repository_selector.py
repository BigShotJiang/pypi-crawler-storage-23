from analogai.foundation.common.enums.environment import Environment
from analogai.foundation import config
from analogai.foundation.infrastructure.factories.repository_factory_strategies.in_memory_repository_strategy import (
    InMemoryRepositoryStrategy,
)
from analogai.foundation.infrastructure.factories.repository_factory_strategies.persistent_repository_strategy import (
    PersistentRepositoryStrategy,
)


def create_repository_strategy(environment: str | None = None):
    env_value = environment or config.ENVIRONMENT
    env = Environment(env_value)
    if env == Environment.DEVELOPMENT:
        return InMemoryRepositoryStrategy()
    if env == Environment.PRODUCTION:
        return PersistentRepositoryStrategy()
    raise ValueError(f"No repository strategy defined for environment: {env}")
