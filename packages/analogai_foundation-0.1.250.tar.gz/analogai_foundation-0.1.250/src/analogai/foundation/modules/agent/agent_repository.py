from abc import ABC, abstractmethod
from typing import Optional, List
from analogai.foundation.modules.agent.agent import Agent

class AgentRepository(ABC):
    @abstractmethod
    def find_by_id(self, id: str) -> Optional[Agent]:
        pass

    @abstractmethod
    def create(self, agent: Agent) -> Agent:
        pass

    @abstractmethod
    def update(self, agent: Agent) -> Agent:
        pass

    @abstractmethod
    def delete(self, id: str) -> bool:
        pass

    @abstractmethod
    def find_by_creator_id(self, creator_id: str) -> List[Agent]:
        pass