from analogai.foundation.modules.agent.agent_repository import AgentRepository
from analogai.foundation.modules.agent.agent import Agent
from analogai.foundation.modules.user.user import User
from typeguard import typechecked
from typing import Optional, List

class AgentService:
    def __init__(self, agent_repository: AgentRepository):
        self.agent_repository = agent_repository

    @typechecked
    def find(self, id: str) -> Optional[Agent]:
        return self.agent_repository.find_by_id(id)

    @typechecked
    def get_agents_by_creator(self, creator_id: str) -> List[Agent]:
        return self.agent_repository.find_by_creator_id(creator_id)

    @typechecked
    def create(self, creator: User, id: str = None, name: str = "", knowledge_base: str = "", roles=None) -> Agent:
        agent_params = {"creator": creator, "name": name, "knowledge_base": knowledge_base, "roles": roles or []}
        if id is not None:
            agent_params["id"] = id
        agent = Agent(**agent_params)
        return self.agent_repository.create(agent)

    @typechecked
    def update(self, agent: Agent) -> Agent:
        return self.agent_repository.update(agent)

    @typechecked
    def delete(self, id: str) -> bool:
        return self.agent_repository.delete(id)