import unittest

from analogai.foundation.common.enums.certainty import Certainty
from analogai.foundation.common.enums.criterion import Criterion
from analogai.foundation.core.value_objects.effect import Effect
from analogai.foundation.core.value_objects.relation import Relation
from analogai.foundation.modules.conditionals.hypothetical_statement import HypotheticalStatement


class TestHypotheticalStatementCertainty(unittest.TestCase):
    def _build_effect(self, certainty=None):
        criteria = {
            Criterion.SubjectCaption: "sky",
            Criterion.ObjectCaption: "blue",
            Criterion.Relation: Relation.from_string("is"),
        }
        if certainty is not None:
            criteria[Criterion.Certainty] = certainty
        return Effect(criteria)

    def test_probability_defaults_to_certain(self):
        hypothetical = HypotheticalStatement(
            agent_id="agent-1",
            causes=[],
            effect=self._build_effect(),
        )
        self.assertEqual(hypothetical.probability, 1.0)

    def test_probability_from_uncertain_certainty(self):
        hypothetical = HypotheticalStatement(
            agent_id="agent-1",
            causes=[],
            effect=self._build_effect(Certainty.UNCERTAIN),
        )
        self.assertEqual(hypothetical.probability, 0.5)

    def test_probability_from_negated_certainty(self):
        hypothetical = HypotheticalStatement(
            agent_id="agent-1",
            causes=[],
            effect=self._build_effect(Certainty.NEGATED),
        )
        self.assertEqual(hypothetical.probability, 0.0)


if __name__ == "__main__":
    unittest.main()
