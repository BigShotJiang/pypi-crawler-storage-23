import uuid
from typing import Optional, List

from analogai.foundation.core.value_objects.attribute import Attribute


class Notion:
    def __init__(
        self,
        user_id: str,
        agent_id: str,
        caption: str,
        id: Optional[str] = None,
        attributes: Optional[List[Attribute]] = None,
    ):
        self.id = id if id else str(uuid.uuid4())
        self.user_id = user_id
        self.agent_id = agent_id
        self.caption = caption
        self.attributes = attributes

    def __str__(self) -> str:
        if not self.attributes:
            return self.caption
        parts = []
        for attr in self.attributes:
            tag = getattr(attr, "tag", None)
            value = getattr(attr, "value", None)
            unit = getattr(attr, "unit", None)
            if value is None and hasattr(attr, "values"):
                values = getattr(attr, "values", None)
                if values is not None:
                    value = values

            if value is None:
                if tag:
                    parts.append(str(tag))
                continue

            if isinstance(value, list):
                value_str = ", ".join(str(v) for v in value)
            else:
                value_str = str(value)

            unit_str = f" {unit}" if unit else ""
            if tag:
                parts.append(f"{tag}={value_str}{unit_str}")
            else:
                parts.append(f"{value_str}{unit_str}")

        if not parts:
            return self.caption
        return f"{self.caption} ({', '.join(parts)})"

    def __repr__(self) -> str:
        return (
            "Notion(id={!r}, user_id={!r}, agent_id={!r}, caption={!r}, attributes={!r})"
        ).format(self.id, self.user_id, self.agent_id, self.caption, self.attributes)

