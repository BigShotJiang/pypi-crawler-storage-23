from abc import ABC, abstractmethod
from typing import Optional, List
from analogai.foundation.modules.notion.notion import Notion
from analogai.foundation.common.dtos.notion_expression import NotionExpression


class NotionRepository(ABC):
    @abstractmethod
    def create(self, notion: Notion) -> Notion:
        pass

    @abstractmethod
    def find(self, agent_id: str, expression: NotionExpression, context_ids: Optional[List[str]] = None) -> Optional[Notion]:
        pass

    @abstractmethod
    def find_by_id(self, notion_id: str) -> Optional[Notion]:
        pass

    @abstractmethod
    def find_all_by_agent(self, agent_id: str) -> List[Notion]:
        pass