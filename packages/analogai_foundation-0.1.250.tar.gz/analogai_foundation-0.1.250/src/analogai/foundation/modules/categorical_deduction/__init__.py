from .categorical_deduction import CategoricalDeduction
from .categorical_deduction_service import CategoricalDeductionService

__all__ = [
    "CategoricalDeduction",
    "CategoricalDeductionService",
]