from analogai.foundation.common.logging.app_logger import app_logger

def calculate_belief_certainties(certainties):
	if not certainties:
		raise ValueError("Certainties should be provided for belief certainties calculator")
		
	total_validity_weight = sum([validity for validity, _ in certainties])
	
	if total_validity_weight == 0:
		raise ValueError("Validities should not be 0")
		
	weighted_sum_probability = sum([validity * probability for validity, probability in certainties])
	weighted_sum_validity = sum([validity**2 for validity, _ in certainties])

	proposed_probability = weighted_sum_probability / total_validity_weight
	proposed_validity = weighted_sum_validity / total_validity_weight

	return round(proposed_probability, 2), round(proposed_validity, 2)

if __name__ == "__main__":	
	p = [(1, 0.5), (0.2, 0.5), (0.2, 0.5), (0.2, 0.5)]
	prop_prob, prop_validity = calculate_belief_certainties(p)
	print(prop_prob, prop_validity)
