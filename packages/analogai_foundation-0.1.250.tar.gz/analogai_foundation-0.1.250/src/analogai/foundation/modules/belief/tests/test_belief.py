import unittest
import uuid
from analogai.foundation.modules.belief.belief import Belief
from analogai.foundation.modules.direct_statement.direct_statement import DirectStatement as Statement
from analogai.foundation.modules.notion.notion import Notion
from analogai.foundation.core.value_objects.relation import Relation


class TestBelief(unittest.TestCase):
    def setUp(self):
        self.user_id = str(uuid.uuid4())
        self.agent_id = str(uuid.uuid4())
        self.subject_notion = Notion(user_id=self.user_id, agent_id=self.agent_id, caption="source", id="sub_id")
        self.complement_notion = Notion(user_id=self.user_id, agent_id=self.agent_id, caption="target", id="obj_id")
        self.relation = Relation.from_string("relationship")
        self.belief = Belief(agent_id=self.agent_id, id=str(uuid.uuid4()))

        pred1 = Statement(
            user_id=self.user_id,
            agent_id=self.agent_id,
            subject_notion=self.subject_notion,
            relation=self.relation,
            complement_notion=self.complement_notion,
            probability=0.7,
            validity=0.8,
        )
        self.statement1 = pred1

        pred2 = Statement(
            user_id=self.user_id,
            agent_id=self.agent_id,
            subject_notion=self.subject_notion,
            relation=self.relation,
            complement_notion=self.complement_notion,
            probability=0.5,
            validity=0.6,
        )
        self.statement2 = pred2

        pred3 = Statement(
            user_id=self.user_id,
            agent_id=self.agent_id,
            subject_notion=self.subject_notion,
            relation=self.relation,
            complement_notion=self.complement_notion,
            probability=0.3,
            validity=0.4,
        )
        self.statement3 = pred3

    def test_initialization(self):
        test_id = str(uuid.uuid4())
        agent_id = str(uuid.uuid4())
        belief = Belief(agent_id=agent_id, id=test_id)

        self.assertEqual(belief.id, test_id)
        self.assertEqual(belief.statements, [])

    def test_initialization_without_id(self):
        agent_id = str(uuid.uuid4())
        belief = Belief(agent_id=agent_id)

        self.assertIsNotNone(belief.id)
        self.assertIsInstance(belief.id, str)
        self.assertEqual(len(belief.id), 36)

    def test_add_statement(self):
        self.belief.add_statement(self.statement1)
        self.assertEqual(self.belief.subject_notion, self.subject_notion)
        self.assertEqual(self.belief.complement_notion, self.complement_notion)
        self.assertEqual(self.belief.relation, self.relation)
        self.assertEqual(len(self.belief.statements), 1)
        self.belief.add_statement(self.statement2)
        self.assertEqual(len(self.belief.statements), 2)
        self.assertIn(self.statement1, self.belief.statements)
        self.assertIn(self.statement2, self.belief.statements)
        self.belief.add_statement(self.statement3)
        self.assertEqual(len(self.belief.statements), 3)
        self.assertIn(self.statement3, self.belief.statements)

    def test_certainties_computed_from_filtered_statements(self):
        self.belief.add_statement(self.statement1)
        self.belief.add_statement(self.statement2)

        self.assertIsNotNone(self.belief.probability)
        self.assertIsNotNone(self.belief.validity)
        self.assertGreater(self.belief.probability, 0)
        self.assertGreater(self.belief.validity, 0)


if __name__ == '__main__':
    unittest.main()
