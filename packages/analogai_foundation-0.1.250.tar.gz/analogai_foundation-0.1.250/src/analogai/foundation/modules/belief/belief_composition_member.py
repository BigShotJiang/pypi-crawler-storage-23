from typing import Protocol, Optional, Any, TYPE_CHECKING

from analogai.foundation.modules.notion.notion import Notion
from analogai.foundation.core.value_objects.modifier import Modifier

if TYPE_CHECKING:
    from analogai.foundation.modules.direct_statement.direct_statement import DirectStatement


class BeliefCompositionMember(Protocol):
    id: str
    agent_id: str
    subject_notion: Notion
    complement_notion: Notion
    relation: Any
    modifier: Optional[Modifier]

    @property
    def probability(self) -> float: ...

    @property
    def validity(self) -> float: ...

    @property
    def location(self) -> Optional[str]: ...

    @property
    def from_time(self) -> Any: ...

    @property
    def to_time(self) -> Any: ...

    @property
    def deontic_modality(self) -> Any: ...

    @property
    def quantity(self) -> Optional[float]: ...

    def visit(self, visitor: Any) -> Any: ...
