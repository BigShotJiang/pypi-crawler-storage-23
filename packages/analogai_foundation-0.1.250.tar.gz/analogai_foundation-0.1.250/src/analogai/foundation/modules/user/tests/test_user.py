import unittest
from datetime import datetime
from analogai.foundation.modules.user.user import User, _get_local_timezone
from zoneinfo import ZoneInfo


class TestUser(unittest.TestCase):

    def test_user_default_timezone_is_iana_format(self):
        user = User(id="test_id", name="Test User", email="test@example.com")

        self.assertIsNotNone(user.timezone)
        try:
            ZoneInfo(user.timezone)
        except Exception as e:
            self.fail(f"Timezone '{user.timezone}' is not a valid IANA timezone format: {e}")

    def test_user_default_timezone_is_valid_zoneinfo(self):
        user = User(id="test_id", name="Test User", email="test@example.com")

        self.assertIsNotNone(user.timezone)
        tz = ZoneInfo(user.timezone)
        self.assertIsNotNone(tz)

    def test_user_timezone_not_windows_format(self):
        user = User(id="test_id", name="Test User", email="test@example.com")

        self.assertIsNotNone(user.timezone)
        self.assertNotIn("Standard Time", user.timezone)
        self.assertNotIn("GMT", user.timezone)
        self.assertNotIn("UTC+", user.timezone)
        self.assertNotIn("UTC-", user.timezone)

    def test_user_timezone_has_slash_format(self):
        user = User(id="test_id", name="Test User", email="test@example.com")

        self.assertIsNotNone(user.timezone)
        self.assertIn("/", user.timezone, f"Timezone should be in IANA format (e.g., 'Asia/Tbilisi'), got: {user.timezone}")

    def test_get_local_timezone_returns_iana_format(self):
        tz = _get_local_timezone()

        self.assertIsNotNone(tz)
        try:
            ZoneInfo(tz)
        except Exception as e:
            self.fail(f"Timezone '{tz}' is not a valid IANA timezone format: {e}")

    def test_get_local_timezone_not_windows_format(self):
        tz = _get_local_timezone()

        self.assertNotIn("Standard Time", tz)
        self.assertNotIn("GMT", tz)
        self.assertNotIn("UTC+", tz)
        self.assertNotIn("UTC-", tz)

    def test_get_local_timezone_returns_valid_iana_format(self):
        tz = _get_local_timezone()
        self.assertIsNotNone(tz)
        self.assertIn("/", tz, f"Timezone should be in IANA format (e.g., 'Asia/Tbilisi'), got: {tz}")
        try:
            ZoneInfo(tz)
        except Exception as e:
            self.fail(f"Timezone '{tz}' is not a valid IANA timezone format: {e}")

    def test_user_with_explicit_timezone(self):
        user = User(
            id="test_id",
            name="Test User",
            email="test@example.com",
            timezone="Asia/Tbilisi"
        )

        self.assertEqual(user.timezone, "Asia/Tbilisi")
        tz = ZoneInfo(user.timezone)
        self.assertIsNotNone(tz)

    def test_user_timezone_works_with_zoneinfo(self):
        user = User(id="test_id", name="Test User", email="test@example.com")

        tz = ZoneInfo(user.timezone)
        dt = datetime.now(tz)
        self.assertIsNotNone(dt)
        self.assertEqual(dt.tzinfo, tz)


if __name__ == '__main__':
    unittest.main()
