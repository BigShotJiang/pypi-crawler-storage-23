import uuid
from dataclasses import dataclass, field
from typing import Optional
from tzlocal import get_localzone_name


def _get_local_timezone() -> str:
    return get_localzone_name()


@dataclass
class User:
    name: str
    email: str
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timezone: Optional[str] = None
    nationality: Optional[str] = None
    location: Optional[str] = None

    def __post_init__(self):
        self.id = self.id if self.id else str(uuid.uuid4())
        if self.timezone is None:
            self.timezone = _get_local_timezone()

    def set_name(self, name: str):
        self.name = name

    def set_nationality(self, nationality: str):
        self.nationality = nationality

    def set_location(self, location: str):
        self.location = location

    def set_timezone(self, timezone: str):
        self.timezone = timezone

    def __repr__(self) -> str:
        return (
            "User("
            f"id='{self.id}', "
            f"name='{self.name}', "
            f"email='{self.email}', "
            f"timezone='{self.timezone}'"
            ")"
        )