"""
AnalogAI Foundation Package
A comprehensive framework for building AI agent systems
"""

__version__ = "0.1.248"

