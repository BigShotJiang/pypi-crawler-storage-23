import os
from abc import ABC, abstractmethod
from analogai.foundation.infrastructure.storage.neo4j.neo4j_gateway import Neo4jGateway
from analogai.foundation.infrastructure.storage.in_memory.in_memory_storage_adapter_impl import InMemoryStorageAdapterImpl
from analogai.foundation.infrastructure.storage.mongodb.mongodb_storage_adapter_impl import MongoDBStorageAdapterImpl
from analogai.foundation import config

class StorageCleaner(ABC):
    @abstractmethod
    def cleanup(self):
        pass

class ProductionEnvironmentStorageCleaner(StorageCleaner):
    def cleanup(self):
        neo4j_gateway = Neo4jGateway()
        with neo4j_gateway.session() as session:
            session.run("MATCH (n) DETACH DELETE n")
        
        storage_adapter = MongoDBStorageAdapterImpl()
        storage_adapter.clear()

class DevEnvironmentStorageCleaner(StorageCleaner):
    def cleanup(self):
        storage_adapter = InMemoryStorageAdapterImpl()
        storage_adapter.clear()

def cleanup_storages():
    cleaner = DevEnvironmentStorageCleaner() if config.ENVIRONMENT == "development" else ProductionEnvironmentStorageCleaner()
    cleaner.cleanup()

if __name__=="__main__":
    cleanup_storages()
