from analogai.foundation.common.enums.environment import Environment
from analogai.foundation import config
from analogai.foundation.infrastructure.factories import StorageAdaptersFactoryImpl
# Application-layer factories removed. Use direct mock or DI as needed.
from analogai.foundation.tests.functional.storage_cleaner import cleanup_storages
from analogai.foundation.modules.user.user import User
from analogai.foundation.modules.agent.agent import Agent, Role
import uuid

from analogai.foundation.setup.factories import (
    AgentServiceFactory,
    BeliefServiceFactory,
    CategoricalDeductionServiceFactory,
    ConditionalDeductionServiceFactory,
    HypotheticalStatementServiceFactory,
    NotionServiceFactory,
    StatementServiceFactory,
    UserServiceFactory,
    create_repository_strategy,
)


class ServicesTestConfig:
    def __init__(self):
        self.storage_adapters_factory = StorageAdaptersFactoryImpl()
        self.storage_adapter = self.storage_adapters_factory.get_storage_adapter()

        self._env = Environment(config.ENVIRONMENT)
        self.repository_strategy = create_repository_strategy()

        self.user = User(id=str(uuid.uuid4()), name="Test User", email="test@example.com")
        self.agent = Agent(id=str(uuid.uuid4()), creator=self.user, roles=[Role(user=self.user, authority=1.0)])

        self.user_repository = self.repository_strategy.get_user_repository()
        self.agent_repository = self.repository_strategy.get_agent_repository()
        self.notion_repository = self.repository_strategy.get_notion_repository()
        self.statement_repository = self.repository_strategy.get_statement_repository()
        self.belief_repository = self.repository_strategy.get_belief_repository()
        self.hypothetical_statement_repository = self.repository_strategy.get_hypothetical_statement_repository()

        self.user_repository.create(self.user)
        self.agent_repository.create(self.agent)

        self.user_service = UserServiceFactory(repository=self.user_repository).get_service()
        self.agent_service = AgentServiceFactory(repository=self.agent_repository).get_service()
        self.notion_service = NotionServiceFactory(repository=self.notion_repository).get_service()
        self.statement_service = StatementServiceFactory(repository=self.statement_repository).get_service()
        self.belief_service = BeliefServiceFactory(
            repository=self.belief_repository,
            notion_service=self.notion_service,
            statement_service=self.statement_service,
        ).get_service()
        self.categorical_deduction_service = CategoricalDeductionServiceFactory(
            belief_service=self.belief_service,
        ).get_service()
        self.conditional_deduction_service = ConditionalDeductionServiceFactory(
            belief_service=self.belief_service,
        ).get_service()
        self.hypothetical_statement_service = HypotheticalStatementServiceFactory(
            repository=self.hypothetical_statement_repository,
        ).get_service()

        self.belief_service.set_categorical_deduction_service(self.categorical_deduction_service)
        self.belief_service.set_conditional_deduction_service(self.conditional_deduction_service)

    def tear_down(self):
        cleanup_storages()
