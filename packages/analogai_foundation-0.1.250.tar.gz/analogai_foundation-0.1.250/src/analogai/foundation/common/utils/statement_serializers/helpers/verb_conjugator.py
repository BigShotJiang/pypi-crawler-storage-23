from analogai.foundation.common.utils.time_utils import Tense


class VerbConjugator:
    @staticmethod
    def conjugate(verb: str, tense: Tense, is_plural: bool = False) -> str:
        if tense == Tense.PAST:
            return VerbConjugator._past_tense(verb, is_plural)
        elif tense == Tense.FUTURE:
            return VerbConjugator._future_tense(verb, is_plural)
        else:
            return verb
    
    @staticmethod
    def _past_tense(verb: str, is_plural: bool) -> str:
        past_forms = {
            "is": "was",
            "are": "were",
            "has": "had",
            "have": "had",
            "does": "did",
            "do": "did",
            "causes": "caused",
            "cause": "caused",
            "is not": "was not",
            "are not": "were not",
            "does not have": "did not have",
            "do not have": "did not have",
            "does not": "did not",
            "do not": "did not",
            "is related to": "was related to",
            "are related to": "were related to",
            "is capable of": "was capable of",
            "are capable of": "were capable of",
            "is part of": "was part of",
            "are part of": "were part of",
            "might be": "might have been",
            "might have": "might have had",
        }
        
        if verb in past_forms:
            return past_forms[verb]
        
        if verb.startswith("is "):
            return verb.replace("is ", "was ", 1)
        if verb.startswith("are "):
            return verb.replace("are ", "were ", 1)
        if verb.startswith("has "):
            return verb.replace("has ", "had ", 1)
        if verb.startswith("have "):
            return verb.replace("have ", "had ", 1)
        if verb.startswith("does "):
            return verb.replace("does ", "did ", 1)
        if verb.startswith("do "):
            return verb.replace("do ", "did ", 1)
        
        if verb.endswith("s") and not is_plural and " " not in verb:
            return verb[:-1] + "ed" if len(verb) > 1 else verb + "ed"
        
        if verb.endswith("e") and " " not in verb:
            return verb + "d"
        
        if " " not in verb:
            return verb + "ed"
        
        return verb
    
    @staticmethod
    def _future_tense(verb: str, is_plural: bool) -> str:
        future_forms = {
            "is": "will be",
            "are": "will be",
            "has": "will have",
            "have": "will have",
            "does": "will",
            "do": "will",
            "causes": "will cause",
            "cause": "will cause",
            "is not": "will not be",
            "are not": "will not be",
            "does not have": "will not have",
            "do not have": "will not have",
            "does not": "will not",
            "do not": "will not",
            "is related to": "will be related to",
            "are related to": "will be related to",
            "is capable of": "will be capable of",
            "are capable of": "will be capable of",
            "is part of": "will be part of",
            "are part of": "will be part of",
        }
        
        if verb in future_forms:
            return future_forms[verb]
        
        if verb.startswith("is "):
            return verb.replace("is ", "will be ", 1)
        if verb.startswith("are "):
            return verb.replace("are ", "will be ", 1)
        if verb.startswith("has "):
            return verb.replace("has ", "will have ", 1)
        if verb.startswith("have "):
            return verb.replace("have ", "will have ", 1)
        if verb.startswith("does "):
            return verb.replace("does ", "will ", 1)
        if verb.startswith("do "):
            return verb.replace("do ", "will ", 1)
        if verb.startswith("might "):
            return verb.replace("might ", "will ", 1)
        
        if " " not in verb:
            return f"will {verb}"
        
        return f"will {verb}"
    
    @staticmethod
    def to_infinitive(verb: str) -> str:
        infinitive_forms = {
            "is": "be",
            "are": "be",
            "was": "be",
            "were": "be",
            "has": "have",
            "have": "have",
            "had": "have",
            "does": "do",
            "do": "do",
            "did": "do",
            "causes": "cause",
            "cause": "cause",
            "caused": "cause",
            "is not": "not be",
            "are not": "not be",
            "was not": "not be",
            "were not": "not be",
            "does not have": "not have",
            "do not have": "not have",
            "did not have": "not have",
            "does not": "not do",
            "do not": "not do",
            "did not": "not do",
            "is related to": "be related to",
            "are related to": "be related to",
            "was related to": "be related to",
            "were related to": "be related to",
            "is capable of": "be capable of",
            "are capable of": "be capable of",
            "was capable of": "be capable of",
            "were capable of": "be capable of",
            "is part of": "be part of",
            "are part of": "be part of",
            "was part of": "be part of",
            "were part of": "be part of",
            "might be": "be",
            "might have": "have",
            "will be": "be",
            "will have": "have",
            "will": "do",
            "will not be": "not be",
            "will not have": "not have",
            "will not": "not do",
        }
        
        if verb in infinitive_forms:
            return infinitive_forms[verb]
        
        if verb.startswith("is "):
            return verb.replace("is ", "be ", 1)
        if verb.startswith("are "):
            return verb.replace("are ", "be ", 1)
        if verb.startswith("was "):
            return verb.replace("was ", "be ", 1)
        if verb.startswith("were "):
            return verb.replace("were ", "be ", 1)
        if verb.startswith("has "):
            return verb.replace("has ", "have ", 1)
        if verb.startswith("have "):
            return verb.replace("have ", "have ", 1)
        if verb.startswith("had "):
            return verb.replace("had ", "have ", 1)
        if verb.startswith("does "):
            return verb.replace("does ", "do ", 1)
        if verb.startswith("do "):
            return verb.replace("do ", "do ", 1)
        if verb.startswith("did "):
            return verb.replace("did ", "do ", 1)
        if verb.startswith("will "):
            return verb.replace("will ", "", 1)
        if verb.startswith("will not "):
            return "not " + verb.replace("will not ", "", 1)
        
        if verb.endswith("s") and " " not in verb:
            return verb[:-1]
        
        if verb.endswith("ed") and " " not in verb:
            if len(verb) > 2 and verb[-3] in "aeiou":
                return verb[:-1]
            return verb[:-2]
        
        return verb


__all__ = ["VerbConjugator"]
