from abc import ABC, abstractmethod


class SimilarityService(ABC):
    @abstractmethod
    def similarity(self, text_a: str, text_b: str) -> float:
        raise NotImplementedError

    def is_similar(self, text_a: str, text_b: str, threshold: float) -> bool:
        return self.similarity(text_a, text_b) >= threshold
