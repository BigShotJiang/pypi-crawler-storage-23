from datetime import datetime
from typing import Union


def from_storage(value: Union[str, datetime]) -> datetime:
    converter = _CONVERTERS.get(type(value))
    if converter is None:
        raise ValueError(f"Unsupported datetime storage type: {type(value)}")
    return converter(value)


_CONVERTERS = {
    str: lambda x: datetime.fromisoformat(x),
    datetime: lambda x: x,
}
