from enum import Enum


class Tense(Enum):
    PAST = "past"
    PRESENT = "present"
    FUTURE = "future"
