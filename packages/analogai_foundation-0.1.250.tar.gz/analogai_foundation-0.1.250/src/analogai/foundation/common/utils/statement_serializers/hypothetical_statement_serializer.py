from __future__ import annotations

from typing import Optional

from typing import TYPE_CHECKING

from analogai.foundation.common.utils.statement_serializers.condition_serializer import serialize_condition
from analogai.foundation.common.utils.statement_serializers.helpers import normalize_timezone
from analogai.foundation.core.value_objects.cause import Cause
from analogai.foundation.core.value_objects.effect import Effect

if TYPE_CHECKING:
    from analogai.foundation.modules.conditionals.hypothetical_statement import HypotheticalStatement


def serialize_hypothetical_statement(
    hypothetical: "HypotheticalStatement",
    timezone: Optional[str] = None,
) -> str:
    timezone = normalize_timezone(timezone)
    causes = [
        serialize_condition(cause.criteria, timezone)
        for cause in hypothetical.causes
        if isinstance(cause, Cause)
    ]
    causes = [c for c in causes if c]
    effect = serialize_condition(
        hypothetical.effect.criteria if isinstance(hypothetical.effect, Effect) else {},
        timezone,
    )
    if not causes and not effect:
        return ""
    causes_part = " and ".join(causes) if causes else "something"
    effect_part = effect or "something"
    return f"If {causes_part}, then {effect_part}."
