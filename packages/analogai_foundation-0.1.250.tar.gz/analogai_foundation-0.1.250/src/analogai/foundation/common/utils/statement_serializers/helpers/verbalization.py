from enum import Enum
from typing import Dict


class Verbalization(Enum):
    IS_A = (
        {"positive": "is",           "negative": "is not",        "uncertain": "might be"},
        {"positive": "are",          "negative": "are not",       "uncertain": "might be"}
    )
    HAS_A = (
        {"positive": "has",          "negative": "does not have", "uncertain": "might have"},
        {"positive": "have",         "negative": "do not have",   "uncertain": "might have"}
    )
    DO = (
        {"positive": "does",         "negative": "does not",      "uncertain": "might"},
        {"positive": "do",           "negative": "do not",        "uncertain": "might"}
    )
    RELATED_TO = (
        {"positive": "is related to",    "negative": "is not related to",    "uncertain": "might be related to"},
        {"positive": "are related to",   "negative": "are not related to",   "uncertain": "might be related to"}
    )
    CAPABLE_OF = (
        {"positive": "is capable of",    "negative": "is not capable of",    "uncertain": "might be capable of"},
        {"positive": "are capable of",   "negative": "are not capable of",   "uncertain": "might be capable of"}
    )
    PART_OF = (
        {"positive": "is part of",       "negative": "is not part of",       "uncertain": "might be part of"},
        {"positive": "are part of",      "negative": "are not part of",      "uncertain": "might be part of"}
    )
    DISTINCT_FROM = (
        {"positive": "is distinct from", "negative": "is not distinct from", "uncertain": "might be distinct from"},
        {"positive": "are distinct from","negative": "are not distinct from","uncertain": "might be distinct from"}
    )
    CAUSES = (
        {"positive": "causes", "negative": "does not cause", "uncertain": "might cause"},
        {"positive": "cause", "negative": "do not cause", "uncertain": "might cause"}
    )
    FORM_OF = (
        {"positive": "is form of", "negative": "is not form of", "uncertain": "might be form of"},
        {"positive": "are form of", "negative": "are not form of", "uncertain": "might be form of"}
    )
    USED_FOR = (
        {"positive": "is used for", "negative": "is not used for", "uncertain": "might be used for"},
        {"positive": "are used for", "negative": "are not used for", "uncertain": "might be used for"}
    )
    AT_LOCATION = (
        {"positive": "is at location", "negative": "is not at location", "uncertain": "might be at location"},
        {"positive": "are at location", "negative": "are not at location", "uncertain": "might be at location"}
    )
    HAS_SUBEVENT = (
        {"positive": "has subevent", "negative": "does not have subevent", "uncertain": "might have subevent"},
        {"positive": "have subevent", "negative": "do not have subevent", "uncertain": "might have subevent"}
    )
    HAS_FIRST_SUBEVENT = (
        {"positive": "has first subevent", "negative": "does not have first subevent", "uncertain": "might have first subevent"},
        {"positive": "have first subevent", "negative": "do not have first subevent", "uncertain": "might have first subevent"}
    )
    HAS_LAST_SUBEVENT = (
        {"positive": "has last subevent", "negative": "does not have last subevent", "uncertain": "might have last subevent"},
        {"positive": "have last subevent", "negative": "do not have last subevent", "uncertain": "might have last subevent"}
    )
    HAS_PREREQUISITE = (
        {"positive": "has prerequisite", "negative": "does not have prerequisite", "uncertain": "might have prerequisite"},
        {"positive": "have prerequisite", "negative": "do not have prerequisite", "uncertain": "might have prerequisite"}
    )
    HAS_PROPERTY = (
        {"positive": "has property", "negative": "does not have property", "uncertain": "might have property"},
        {"positive": "have property", "negative": "do not have property", "uncertain": "might have property"}
    )
    MOTIVATED_BY_GOAL = (
        {"positive": "is motivated by goal", "negative": "is not motivated by goal", "uncertain": "might be motivated by goal"},
        {"positive": "are motivated by goal", "negative": "are not motivated by goal", "uncertain": "might be motivated by goal"}
    )
    OBSTRUCTED_BY = (
        {"positive": "is obstructed by", "negative": "is not obstructed by", "uncertain": "might be obstructed by"},
        {"positive": "are obstructed by", "negative": "are not obstructed by", "uncertain": "might be obstructed by"}
    )
    DESIRES = (
        {"positive": "desires", "negative": "does not desire", "uncertain": "might desire"},
        {"positive": "desire", "negative": "do not desire", "uncertain": "might desire"}
    )
    CREATED_BY = (
        {"positive": "is created by", "negative": "is not created by", "uncertain": "might be created by"},
        {"positive": "are created by", "negative": "are not created by", "uncertain": "might be created by"}
    )
    SYNONYM = (
        {"positive": "is synonym", "negative": "is not synonym", "uncertain": "might be synonym"},
        {"positive": "are synonym", "negative": "are not synonym", "uncertain": "might be synonym"}
    )
    ANTONYM = (
        {"positive": "is antonym", "negative": "is not antonym", "uncertain": "might be antonym"},
        {"positive": "are antonym", "negative": "are not antonym", "uncertain": "might be antonym"}
    )
    DERIVED_FROM = (
        {"positive": "is derived from", "negative": "is not derived from", "uncertain": "might be derived from"},
        {"positive": "are derived from", "negative": "are not derived from", "uncertain": "might be derived from"}
    )
    SYMBOL_OF = (
        {"positive": "is symbol of", "negative": "is not symbol of", "uncertain": "might be symbol of"},
        {"positive": "are symbol of", "negative": "are not symbol of", "uncertain": "might be symbol of"}
    )
    DEFINED_AS = (
        {"positive": "is defined as", "negative": "is not defined as", "uncertain": "might be defined as"},
        {"positive": "are defined as", "negative": "are not defined as", "uncertain": "might be defined as"}
    )
    MANNER_OF = (
        {"positive": "is manner of", "negative": "is not manner of", "uncertain": "might be manner of"},
        {"positive": "are manner of", "negative": "are not manner of", "uncertain": "might be manner of"}
    )
    LOCATED_NEAR = (
        {"positive": "is located near", "negative": "is not located near", "uncertain": "might be located near"},
        {"positive": "are located near", "negative": "are not located near", "uncertain": "might be located near"}
    )
    HAS_CONTEXT = (
        {"positive": "has context", "negative": "does not have context", "uncertain": "might have context"},
        {"positive": "have context", "negative": "do not have context", "uncertain": "might have context"}
    )
    SIMILAR_TO = (
        {"positive": "is similar to", "negative": "is not similar to", "uncertain": "might be similar to"},
        {"positive": "are similar to", "negative": "are not similar to", "uncertain": "might be similar to"}
    )
    ETYMOLOGICALLY_RELATED_TO = (
        {"positive": "is etymologically related to", "negative": "is not etymologically related to", "uncertain": "might be etymologically related to"},
        {"positive": "are etymologically related to", "negative": "are not etymologically related to", "uncertain": "might be etymologically related to"}
    )
    ETYMOLOGICALLY_DERIVED_FROM = (
        {"positive": "is etymologically derived from", "negative": "is not etymologically derived from", "uncertain": "might be etymologically derived from"},
        {"positive": "are etymologically derived from", "negative": "are not etymologically derived from", "uncertain": "might be etymologically derived from"}
    )
    CAUSES_DESIRE = (
        {"positive": "causes desire", "negative": "does not cause desire", "uncertain": "might cause desire"},
        {"positive": "cause desire", "negative": "do not cause desire", "uncertain": "might cause desire"}
    )
    MADE_OF = (
        {"positive": "is made of", "negative": "is not made of", "uncertain": "might be made of"},
        {"positive": "are made of", "negative": "are not made of", "uncertain": "might be made of"}
    )
    RECEIVES_ACTION = (
        {"positive": "receives action", "negative": "does not receive action", "uncertain": "might receive action"},
        {"positive": "receive action", "negative": "do not receive action", "uncertain": "might receive action"}
    )

    def _forms(self, is_plural: bool) -> Dict[str, str]:
        return self.value[1] if is_plural else self.value[0]
