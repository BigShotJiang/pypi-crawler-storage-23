from typing import Optional

from analogai.foundation.common.dtos.belief_expression import BeliefExpression
from analogai.foundation.common.utils.statement_serializers import serialize_statement
from analogai.foundation.common.utils.statement_serializers.helpers import normalize_timezone


def serialize_belief_expression(
    expression: BeliefExpression,
    timezone: Optional[str] = None,
) -> str:
    timezone = normalize_timezone(timezone)
    return serialize_statement(
        subject_notion_caption=expression.subject_notion_expression.caption,
        complement_notion_caption=expression.complement_notion_expression.caption,
        relation=expression.relation,
        probability=expression.probability,
        modifier=expression.modifier,
        timezone=timezone,
        subject_attributes=expression.subject_notion_expression.attributes,
        complement_attributes=expression.complement_notion_expression.attributes,
    )
