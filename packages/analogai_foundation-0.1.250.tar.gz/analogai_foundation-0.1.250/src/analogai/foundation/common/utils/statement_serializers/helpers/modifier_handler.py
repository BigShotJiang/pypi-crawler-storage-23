from typing import Optional
from analogai.foundation.core.value_objects.modifier import Modifier
from analogai.foundation.common.utils.time_utils import TimeFormatter
from analogai.foundation.common.utils.statement_serializers.helpers.sentence_builder import NaturalSentenceBuilder


class ModifierHandler:
    
    @staticmethod
    def apply_to_builder(builder: NaturalSentenceBuilder, modifier: Optional[Modifier]) -> None:
        if not modifier:
            return
        
        ModifierHandler._apply_time(builder, modifier)
        builder.with_location(modifier.location)
        builder.with_deontic_modality(modifier.deontic_modality)
    
    @staticmethod
    def _apply_time(builder: NaturalSentenceBuilder, modifier: Modifier) -> None:
        from_time = modifier.from_time
        to_time = modifier.to_time
        
        if not from_time and not to_time:
            return
        
        if from_time and TimeFormatter.has_time_data(from_time):
            if to_time and TimeFormatter.has_time_data(to_time):
                builder.with_time_range(from_time, to_time)
            else:
                builder.with_from_time(from_time)
        elif to_time and TimeFormatter.has_time_data(to_time):
            builder.with_from_time(to_time)


__all__ = ["ModifierHandler"]
