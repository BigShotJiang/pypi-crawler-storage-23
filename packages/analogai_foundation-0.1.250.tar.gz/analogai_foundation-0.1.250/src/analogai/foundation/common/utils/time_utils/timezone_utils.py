from typing import Optional
from datetime import datetime


class TimezoneUtils:
    
    @staticmethod
    def get_timezone_aware_datetime(timezone: Optional[str] = None, reference_time: Optional[datetime] = None) -> datetime:
        from zoneinfo import ZoneInfo
        
        if reference_time is None:
            if timezone:
                tz = ZoneInfo(timezone)
                return datetime.now(tz)
            else:
                return datetime.now().astimezone()
        elif reference_time.tzinfo is None:
            if timezone:
                tz = ZoneInfo(timezone)
                return reference_time.replace(tzinfo=tz)
            else:
                return reference_time.astimezone()
        else:
            return reference_time
