from typing import Optional, Any

from analogai.foundation.core.value_objects.time import Time
from analogai.foundation.core.value_objects.modifier import Modifier


def resolve_time_to_absolute(
    time: Optional[Time],
    time_service: Optional[Any],
) -> Optional[Time]:
    return time


def resolve_modifier_to_absolute(
    modifier: Optional[Modifier],
    time_service: Optional[Any],
) -> Optional[Modifier]:
    if modifier is None:
        return None
    from_time = resolve_time_to_absolute(modifier.from_time, time_service)
    to_time = resolve_time_to_absolute(modifier.to_time, time_service)
    return Modifier(
        location=modifier.location,
        deontic_modality=modifier.deontic_modality,
        from_time=from_time,
        to_time=to_time,
    )
