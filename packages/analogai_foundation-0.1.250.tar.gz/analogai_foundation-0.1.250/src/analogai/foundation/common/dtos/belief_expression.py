from dataclasses import dataclass
from typing import Optional
from analogai.foundation.common.dtos.notion_expression import NotionExpression
from analogai.foundation.core.value_objects.modifier import Modifier
from analogai.foundation.core.value_objects.relation import Relation


@dataclass
class BeliefExpression:
    subject_notion_expression: NotionExpression
    complement_notion_expression: NotionExpression
    relation: Relation
    probability: float
    validity: float
    modifier: Optional[Modifier] = None

    def __str__(self) -> str:
        from analogai.foundation.common.utils.expressions_serializer import serialize_belief_expression
        return serialize_belief_expression(self)

    def __repr__(self) -> str:
        return (
            f"BeliefExpression(subject_notion_expression={self.subject_notion_expression!r}, "
            f"complement_notion_expression={self.complement_notion_expression!r}, "
            f"relation={self.relation!r}, probability={self.probability!r}, "
            f"validity={self.validity!r}, modifier={self.modifier!r})"
        )
