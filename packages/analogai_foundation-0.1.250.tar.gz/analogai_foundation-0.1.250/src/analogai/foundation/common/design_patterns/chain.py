from abc import ABC, abstractmethod
from typing import List

class BaseChainHandler(ABC):
    def __init__(self):
        self._next_handler = None

    def set_next(self, handler):
        self._next_handler = handler
        return handler
    
    @abstractmethod
    def execute_chain_handler(self, *args, **kwargs):
        pass
    
    def process(self, *args, **kwargs):
        pass

    @abstractmethod
    def execute(self, *args, **kwargs):
        pass

class ChainHandler(BaseChainHandler):
    def execute_chain_handler(self, *args, **kwargs):
        result = self.execute(*args, **kwargs)
        if result is not None:
            return result
        if self._next_handler:
            return self._next_handler.execute_chain_handler(*args, **kwargs)
        return None

class ChainCreator:
    def __init__(self):
        pass

    @staticmethod
    def create(chain_items: List[ChainHandler]):
        if not chain_items:
            raise ValueError("Chain items list cannot be empty")
        for i in range(len(chain_items) - 1):
            chain_items[i].set_next(chain_items[i + 1])
        return _ChainHeadAdapter(chain_items[0])

class _ChainHeadAdapter:
    def __init__(self, head: ChainHandler):
        self._head = head

    def execute(self, *args, **kwargs):
        return self._head.execute_chain_handler(*args, **kwargs)

    def __getattr__(self, name):
        return getattr(self._head, name)


