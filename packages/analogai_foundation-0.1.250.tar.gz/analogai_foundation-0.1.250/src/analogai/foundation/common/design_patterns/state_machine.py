class StateMachine:
    def __init__(self, context):
        self.context = context
        self.current_state = None
        self.previous_state = None

    def state_to(self, next_state):
        self.previous_state = self.current_state
        self.current_state = next_state
        return self.current_state.execute()

    def set_context(self, context):
        self.context = context




class State:
	def __init__(self, state_machine):
		self.state_machine = state_machine

	@property
	def context(self):
		return self.state_machine.context
		
	@context.setter
	def context(self, context):
		self.state_machine.context = context

	def set_context(self, context):
		self.state_machine.context = context
