from enum import Enum


class ConstraintOperator(Enum):
    Eq = "eq"
    Min = "min"
    Max = "max"
    NotNull = "not_null"
    Null = "null"
    Ge = "ge"
    Le = "le"
