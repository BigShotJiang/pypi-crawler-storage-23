from enum import Enum


class Criterion(Enum):
    IntentType = "intent_type"
    SubjectCaption = "subject_caption"
    RelationProbability = "relation_probability"
    Probability = "relation_probability"
    Relation = "relation"
    Certainty = "certainty"
    ObjectCaption = "object_caption"
    ComplementCaption = "object_caption"
    Category = "category"
    AttributeValue = "attribute_value"
    AttributeTag = "attribute_tag"
    AttributeMinValue = "min_value"
    AttributeMaxValue = "max_value"
    AttributeUnit = "unit"
    Location = "location"
    DeonticModality = "deontic_modality"
    FromTime = "from_time"
    ToTime = "to_time"
    Time = "time"
    Quantity = "quantity"
