from enum import Enum

class DeonticModality(Enum):
    OBLIGATORY = "obligatory"
    PERMITTED = "permitted"
    FORBIDDEN = "forbidden"

