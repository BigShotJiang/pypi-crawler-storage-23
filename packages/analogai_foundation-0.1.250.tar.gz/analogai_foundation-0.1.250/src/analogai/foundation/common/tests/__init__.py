# from analogai.foundation.common.config import ENVIRONMENT

# def prevent_tests_in_production():
#     if ENVIRONMENT == 'production':
#         raise RuntimeError(
#             "CRITICAL: Tests cannot be run in production environment! "
#             "Set ENVIRONMENT=staging or ENVIRONMENT=development to run tests."
#         )

# prevent_tests_in_production()
