import unittest

from analogai.foundation import config
from analogai.foundation.common.utils.lemmatization import lemmatize_text


class TestLemmatizer(unittest.TestCase):
    def setUp(self):
        self._original_enabled = config.LEMMATIZATION_ENABLED
        if not config.LEMMATIZATION_ENABLED:
            self.skipTest("Lemmatization disabled")

    def tearDown(self):
        config.LEMMATIZATION_ENABLED = self._original_enabled

    def test_lemmatize_text_preserves_proper_nouns(self):
        result = lemmatize_text("Socrates is a human")
        self.assertIn("Socrates", result)
        
        result = lemmatize_text("George bought an iPhone")
        self.assertIn("George", result)
        self.assertIn("iPhone", result)

    def test_lemmatize_text_preserves_named_entities(self):
        result = lemmatize_text("New York")
        self.assertEqual(result, "New York")

    def test_lemmatize_text_preserves_restricted_words(self):
        result = lemmatize_text("born humans")
        self.assertEqual(result, "birth human")
        self.assertEqual(lemmatize_text("birth"), "birth")
        
    def test_lemmatize_text_lemmatizes_common_nouns(self):
        result = lemmatize_text("humans are mortal")
        self.assertEqual(result, "human be mortal")
        
        result = lemmatize_text("philosophers think deeply")
        self.assertEqual(result, "philosopher think deeply")
        
    def test_lemmatize_text_handles_empty_strings(self):
        self.assertEqual(lemmatize_text(""), "")
        self.assertEqual(lemmatize_text("   "), "")
        self.assertEqual(lemmatize_text(""), "")


if __name__ == "__main__":
    unittest.main()
