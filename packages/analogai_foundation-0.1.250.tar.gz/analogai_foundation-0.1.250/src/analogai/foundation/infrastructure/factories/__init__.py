from analogai.foundation import config
from analogai.foundation.common.enums.environment import Environment
from analogai.foundation.infrastructure.storage.storage_adapters_factory import StorageAdaptersFactory
from analogai.foundation.infrastructure.factories.storage_adapters_factory_strategies.in_memory_storage_adapters_strategy import (
	InMemoryStorageAdaptersStrategy,
)
from analogai.foundation.infrastructure.factories.storage_adapters_factory_strategies.persistent_storage_adapters_strategy import (
	PersistentStorageAdaptersStrategy,
)


class StorageAdaptersFactoryImpl(StorageAdaptersFactory):
	def __init__(self, environment: str | None = None):
		env_value = environment or config.ENVIRONMENT
		env = Environment(env_value)
		if env == Environment.PRODUCTION:
			self._strategy = PersistentStorageAdaptersStrategy()
		elif env == Environment.DEVELOPMENT:
			self._strategy = InMemoryStorageAdaptersStrategy()
		else:
			raise ValueError(f"No storage adapter strategy defined for environment: {env}")

	def get_storage_adapter(self):
		return self._strategy.get_storage_adapter()


__all__ = [
	"StorageAdaptersFactoryImpl",
]
