from analogai.foundation.modules.notion.notion_repository import NotionRepository
from analogai.foundation.modules.belief.belief_repository import BeliefRepository
from analogai.foundation.modules.user.user_repository import UserRepository
from analogai.foundation.modules.agent.agent_repository import AgentRepository
from analogai.foundation.modules.direct_statement.direct_statement_repository import StatementRepository
from analogai.foundation.modules.conditionals.hypothetical_statement_repository import HypotheticalStatementRepository
from analogai.foundation.infrastructure.repositories.neo4j.neo4j_notion_repository_impl import Neo4jNotionRepositoryImpl
from analogai.foundation.infrastructure.repositories.neo4j.neo4j_belief_repository_impl import Neo4jBeliefRepositoryImpl
from analogai.foundation.infrastructure.repositories.neo4j.neo4j_statement_repository_impl import Neo4jStatementRepositoryImpl
from analogai.foundation.infrastructure.repositories.mongodb.mongodb_hypothetical_statement_repository_impl import MongoDBHypotheticalStatementRepositoryImpl
from analogai.foundation.infrastructure.repositories.mongodb.mongodb_user_repository_impl import MongoDBUserRepositoryImpl


class PersistentRepositoryStrategy:
    def __init__(self):
        self._notion_repository = None
        self._belief_repository = None
        self._user_repository = None
        self._agent_repository = None
        self._statement_repository = None
        self._hypothetical_statement_repository = None

    def get_notion_repository(self) -> NotionRepository:
        if not self._notion_repository:
            self._notion_repository = Neo4jNotionRepositoryImpl()
        return self._notion_repository

    def get_belief_repository(self) -> BeliefRepository:
        if not self._belief_repository:
            self._belief_repository = Neo4jBeliefRepositoryImpl()
        return self._belief_repository

    def get_user_repository(self) -> UserRepository:
        if not self._user_repository:
            self._user_repository = MongoDBUserRepositoryImpl()
        return self._user_repository

    def get_agent_repository(self) -> AgentRepository:
        if not self._agent_repository:
            from analogai.foundation.infrastructure.repositories.mongodb.mongodb_agent_repository_impl import MongoDBAgentRepositoryImpl
            self._agent_repository = MongoDBAgentRepositoryImpl()
        return self._agent_repository

    def get_statement_repository(self) -> StatementRepository:
        if not self._statement_repository:
            self._statement_repository = Neo4jStatementRepositoryImpl()
        return self._statement_repository

    def get_hypothetical_statement_repository(self) -> HypotheticalStatementRepository:
        if not self._hypothetical_statement_repository:
            self._hypothetical_statement_repository = MongoDBHypotheticalStatementRepositoryImpl()
        return self._hypothetical_statement_repository

