from analogai.foundation.infrastructure.storage.storage_adapters_factory import StorageAdaptersFactory
from analogai.foundation.infrastructure.storage.in_memory.in_memory_storage_adapter_impl import InMemoryStorageAdapterImpl
# from analogai.foundation.infrastructure.storage.in_memory.in_memory_query_storage_adapter_impl import InMemoryQueryStorageAdapterImpl

class InMemoryStorageAdaptersStrategy(StorageAdaptersFactory):
    def get_storage_adapter(self):
        return InMemoryStorageAdapterImpl()

    # def get_query_storage_adapter(self):
    #     return InMemoryQueryStorageAdapterImpl()

