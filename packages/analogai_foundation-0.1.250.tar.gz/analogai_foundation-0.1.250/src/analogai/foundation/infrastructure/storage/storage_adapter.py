from abc import ABC, abstractmethod
from typing import List, Dict
from analogai.foundation.common.design_patterns.singleton import Singleton

class StorageAdapter(metaclass=Singleton):
    @abstractmethod
    def store(self, collection: str, data: dict) -> dict:
        pass

    @abstractmethod
    def retrieve_by_id(self, collection: str, id: str) -> dict | None:
        pass

    @abstractmethod
    def retrieve_by_attributes(self, collection: str, query: Dict[str, str]) -> List[dict]:
        pass

    @abstractmethod
    def delete(self, collection: str, id: str) -> bool:
        pass

    @abstractmethod
    def clear(self) -> bool:
        pass

