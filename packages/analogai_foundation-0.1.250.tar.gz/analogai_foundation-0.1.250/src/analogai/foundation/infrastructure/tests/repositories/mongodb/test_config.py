import unittest

from analogai.foundation.config import ENVIRONMENT

class MongoDBEnvironmentCheckMixin:
    def setUp(self):
        super().setUp()
        if ENVIRONMENT == 'development':
            self.skipTest(
                "CRITICAL: MongoDB tests cannot be run in development environment! "
                "Set ENVIRONMENT=staging or ENVIRONMENT=production to run MongoDB tests."
            )

