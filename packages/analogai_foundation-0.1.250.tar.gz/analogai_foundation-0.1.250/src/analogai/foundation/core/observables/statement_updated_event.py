from .event import Event
from analogai.foundation.modules.shared.statement_base import StatementBase


class StatementUpdatedEvent(Event):
    def __init__(self, statement: StatementBase):
        super().__init__(statement)
        self.statement = statement