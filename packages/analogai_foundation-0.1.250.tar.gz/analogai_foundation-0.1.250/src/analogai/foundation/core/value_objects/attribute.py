from dataclasses import dataclass
from typing import Optional, Any


@dataclass(frozen=True)
class Attribute:
    tag: str
    value: Any
    unit: Optional[str] = None
