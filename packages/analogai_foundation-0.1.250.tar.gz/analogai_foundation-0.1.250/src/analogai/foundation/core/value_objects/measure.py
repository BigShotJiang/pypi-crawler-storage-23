from analogai.foundation.core.value_objects.attribute import Attribute

Measure = Attribute

__all__ = ["Measure"]

