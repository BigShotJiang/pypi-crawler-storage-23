from dataclasses import dataclass
from typing import Optional, TYPE_CHECKING, List

from analogai.foundation.core.value_objects.time import Time
from analogai.foundation.core.value_objects.attribute import Attribute

from analogai.foundation.common.enums.deontic_modality import DeonticModality

@dataclass
class Modifier:
    location: Optional[str] = None
    deontic_modality: Optional[DeonticModality] = None
    from_time: Optional['Time'] = None
    to_time: Optional['Time'] = None
    attributes: Optional[List[Attribute]] = None
    quantity: Optional[float] = None
