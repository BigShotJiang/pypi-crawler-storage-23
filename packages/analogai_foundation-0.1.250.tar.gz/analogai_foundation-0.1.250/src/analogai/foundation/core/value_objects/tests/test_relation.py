import unittest

from analogai.foundation.common.enums.relationship_type import RelationshipType
from analogai.foundation.core.value_objects.relation import Relation


class TestRelation(unittest.TestCase):
	def test_relation_equality_with_same_value(self):
		self.assertEqual(Relation.from_string("is"), Relation.from_string("is"))

	def test_relation_inequality_with_different_value(self):
		self.assertNotEqual(Relation.from_string("is"), Relation.from_string("has"))

	def test_is_of_type_with_known_relationship_type(self):
		relation = Relation.from_type(RelationshipType.CAUSES)

		self.assertTrue(relation.is_of_type(RelationshipType.CAUSES))
		self.assertFalse(relation.is_of_type(RelationshipType.IS_A))

	def test_is_of_type_with_custom_relation_value(self):
		relation = Relation.from_string("sell")

		self.assertFalse(relation.is_of_type(RelationshipType.IS_A))
		self.assertFalse(relation.is_of_type(RelationshipType.CAUSES))




if __name__ == '__main__':
	unittest.main()
