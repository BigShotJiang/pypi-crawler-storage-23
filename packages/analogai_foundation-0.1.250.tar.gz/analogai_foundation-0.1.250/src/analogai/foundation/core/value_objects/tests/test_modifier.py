import unittest
from analogai.foundation.core.value_objects.modifier import Modifier
from analogai.foundation.core.value_objects.time import Time
from analogai.foundation.common.enums.deontic_modality import DeonticModality

class TestModifier(unittest.TestCase):
    
    def test_create_empty_context(self):
        context = Modifier()
        
        self.assertIsNone(context.location)
        self.assertIsNone(context.deontic_modality)
        self.assertIsNone(context.from_time)
        self.assertIsNone(context.to_time)
    
    def test_create_context_with_location(self):
        context = Modifier(location="New York")
        
        self.assertEqual(context.location, "New York")
        self.assertIsNone(context.deontic_modality)
        self.assertIsNone(context.from_time)
        self.assertIsNone(context.to_time)
    
    def test_create_context_with_deontic_modality(self):
        context = Modifier(deontic_modality=DeonticModality.OBLIGATORY)
        
        self.assertIsNone(context.location)
        self.assertEqual(context.deontic_modality, DeonticModality.OBLIGATORY)
        self.assertIsNone(context.from_time)
        self.assertIsNone(context.to_time)
    
    def test_create_context_with_time(self):
        from_time = Time(year=2024, month=1, day=1)
        to_time = Time(year=2024, month=12, day=31)
        context = Modifier(from_time=from_time, to_time=to_time)
        
        self.assertIsNone(context.location)
        self.assertIsNone(context.deontic_modality)
        self.assertEqual(context.from_time, from_time)
        self.assertEqual(context.to_time, to_time)
    
    def test_create_context_with_all_fields(self):
        from_time = Time(year=2024, month=1, day=1)
        to_time = Time(year=2024, month=12, day=31)
        context = Modifier(
            location="London",
            deontic_modality=DeonticModality.PERMITTED,
            from_time=from_time,
            to_time=to_time
        )
        
        self.assertEqual(context.location, "London")
        self.assertEqual(context.deontic_modality, DeonticModality.PERMITTED)
        self.assertEqual(context.from_time, from_time)
        self.assertEqual(context.to_time, to_time)

if __name__ == '__main__':
    unittest.main()
