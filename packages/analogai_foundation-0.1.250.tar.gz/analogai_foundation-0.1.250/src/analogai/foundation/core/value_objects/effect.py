from typing import Dict, Any

from analogai.foundation.common.enums.criterion import Criterion


class Effect:
    def __init__(self, criteria: Dict[Criterion, Any]):
        self._criteria = dict(criteria) if criteria else {}

    @property
    def criteria(self) -> Dict[Criterion, Any]:
        return self._criteria
