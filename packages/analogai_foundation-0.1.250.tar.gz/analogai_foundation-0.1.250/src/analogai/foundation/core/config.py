"""Deprecated shim. Use analogai.config instead."""

from analogai.foundation.config import *  # noqa: F401,F403