from analogai.foundation.modules.belief.belief_service import BeliefService
from analogai.foundation.extensions.belief_query.search_builder import LearningsSearchBuilder
from analogai.foundation.common.utils.similarity.similarity_service import SimilarityService
from analogai.foundation import config
from typing import Optional


class BeliefQueryService:
    def __init__(
        self,
        belief_service: BeliefService,
        similarity_service: Optional[SimilarityService] = None,
    ):
        if similarity_service is None and config.USE_VECTOR_SEARCH:
            raise ValueError("similarity_service is required when USE_VECTOR_SEARCH is enabled")
        self._belief_service = belief_service
        self._similarity_service = similarity_service

    def search(self, user_id: str, agent_id: str) -> LearningsSearchBuilder:
        return LearningsSearchBuilder(
            belief_service=self._belief_service,
            user_id=user_id,
            agent_id=agent_id,
            similarity_service=self._similarity_service,
    )