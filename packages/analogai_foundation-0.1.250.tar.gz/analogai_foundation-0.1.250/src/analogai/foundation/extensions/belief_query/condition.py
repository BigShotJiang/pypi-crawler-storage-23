from typing import Any, Optional

from analogai.foundation.common.enums.criterion import Criterion
from analogai.foundation.common.enums.constraint_operator import ConstraintOperator


class Condition:
    def __init__(
        self,
        criterion: Criterion,
        operator: ConstraintOperator,
        value: Optional[Any] = None,
    ):
        self.criterion = criterion
        self.operator = operator
        self.value = value
