from analogai.foundation.extensions.belief_query.traversable_notion import TraversableNotion


class NotionWithLearnings(TraversableNotion):
    pass
