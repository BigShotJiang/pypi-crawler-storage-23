from abc import ABC, abstractmethod
from typing import Optional, List
from analogai.foundation.extensions.fallback import Fallback


class FallbackRepository(ABC):
    @abstractmethod
    def create(self, fallback: Fallback) -> Fallback:
        pass

    @abstractmethod
    def find_by_id(self, fallback_id: str) -> Optional[Fallback]:
        pass

    @abstractmethod
    def find_by_agent_id(self, agent_id: str) -> List[Fallback]:
        pass
