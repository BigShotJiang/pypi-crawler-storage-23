from .fallback_service import FallbackService

__all__ = ["FallbackService"]
