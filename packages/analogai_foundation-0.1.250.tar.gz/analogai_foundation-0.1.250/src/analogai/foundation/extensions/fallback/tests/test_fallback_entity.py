
import unittest
from datetime import datetime
from analogai.foundation.extensions.fallback import Fallback


class TestFallback(unittest.TestCase):
    def setUp(self):
        self.user_id = "user-123"
        self.agent_id = "agent-456"
        self.user_question = "What is the meaning of life?"

    def test_create_fallback(self):
        fallback = Fallback(
            user_id=self.user_id,
            agent_id=self.agent_id,
            user_question=self.user_question
        )
        self.assertEqual(fallback.user_id, self.user_id)
        self.assertEqual(fallback.agent_id, self.agent_id)
        self.assertEqual(fallback.user_question, self.user_question)
        self.assertIsNotNone(fallback.id)
        self.assertIsNotNone(fallback.timestamp)
        self.assertIsInstance(fallback.timestamp, datetime)

    def test_fallback_has_unique_id(self):
        fallback1 = Fallback(
            user_id=self.user_id,
            agent_id=self.agent_id,
            user_question=self.user_question
        )
        fallback2 = Fallback(
            user_id=self.user_id,
            agent_id=self.agent_id,
            user_question=self.user_question
        )
        self.assertNotEqual(fallback1.id, fallback2.id)

    def test_fallback_can_have_custom_id(self):
        custom_id = "custom-fallback-id"
        fallback = Fallback(
            user_id=self.user_id,
            agent_id=self.agent_id,
            user_question=self.user_question,
            id=custom_id
        )
        self.assertEqual(fallback.id, custom_id)

    def test_fallback_can_have_custom_timestamp(self):
        custom_timestamp = datetime(2023, 1, 1, 12, 0, 0)
        fallback = Fallback(
            user_id=self.user_id,
            agent_id=self.agent_id,
            user_question=self.user_question,
            timestamp=custom_timestamp
        )
        self.assertEqual(fallback.timestamp, custom_timestamp)

    def test_fallback_validation_empty_user_id(self):
        with self.assertRaises(ValueError):
            Fallback(
                user_id="",
                agent_id=self.agent_id,
                user_question=self.user_question
            )

    def test_fallback_validation_empty_agent_id(self):
        with self.assertRaises(ValueError):
            Fallback(
                user_id=self.user_id,
                agent_id="",
                user_question=self.user_question
            )

    def test_fallback_validation_empty_user_question(self):
        with self.assertRaises(ValueError):
            Fallback(
                user_id=self.user_id,
                agent_id=self.agent_id,
                user_question=""
            )

    def test_fallback_validation_none_user_id(self):
        with self.assertRaises(ValueError):
            Fallback(
                user_id=None,
                agent_id=self.agent_id,
                user_question=self.user_question
            )


if __name__ == '__main__':
    unittest.main()
