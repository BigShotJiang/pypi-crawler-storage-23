from .fallback import Fallback
from .services.fallback_service import FallbackService

__all__ = ["Fallback", "FallbackService"]
