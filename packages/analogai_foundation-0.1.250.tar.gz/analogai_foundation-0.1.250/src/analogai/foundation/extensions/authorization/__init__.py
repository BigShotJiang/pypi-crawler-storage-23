from typing import TYPE_CHECKING

__all__ = [
    "AuthorizationOperation",
    "AuthorizationService",
    "AuthorizationGuard",
    "AuthorizationGuardError",
    "AuthorizationErrorReason",
    "AuthorizationFactoryInterface",
    "AuthorizationContext",
    "AuthorizationFactory",
    "build_authorization_dependency",
    "build_api_authorization_dependency",
]

if TYPE_CHECKING:
    from .core import (
        AuthorizationOperation,
        AuthorizationService,
        AuthorizationGuard,
        AuthorizationGuardError,
        AuthorizationErrorReason,
    )
    from .interfaces import AuthorizationFactoryInterface
    from .models import AuthorizationContext
    from .authorization_factory import AuthorizationFactory
    from .adapters.fastapi import build_authorization_dependency, build_api_authorization_dependency

def __getattr__(name: str):
    if name in {
        "AuthorizationOperation",
        "AuthorizationService",
        "AuthorizationGuard",
        "AuthorizationGuardError",
        "AuthorizationErrorReason",
    }:
        from . import core
        return getattr(core, name)
    if name == "AuthorizationFactoryInterface":
        from .interfaces import AuthorizationFactoryInterface
        return AuthorizationFactoryInterface
    if name == "AuthorizationContext":
        from .models import AuthorizationContext
        return AuthorizationContext
    if name == "AuthorizationFactory":
        from .authorization_factory import AuthorizationFactory
        return AuthorizationFactory
    if name == "build_authorization_dependency":
        from .adapters.fastapi import build_authorization_dependency
        return build_authorization_dependency
    if name == "build_api_authorization_dependency":
        from .adapters.fastapi import build_api_authorization_dependency
        return build_api_authorization_dependency
    raise AttributeError(name)
