from enum import Enum

class AuthorizationOperation(str, Enum):
    CHAT = "chat"
    EDIT = "edit"

