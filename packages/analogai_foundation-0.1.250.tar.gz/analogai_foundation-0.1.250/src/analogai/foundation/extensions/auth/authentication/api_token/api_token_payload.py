from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class ApiTokenPayload:
    token: str
    agent_id: str
    subject: Optional[str] = None
    client_id: Optional[str] = None
    issuer: Optional[str] = None
    audience: Optional[str] = None
