from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional
import uuid

@dataclass
class Turn:
    user_id: str
    agent_id: str
    user_message: str
    agent_response: str
    timestamp: datetime
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
