from analogai.foundation.extensions.conversation.services.conversation_service import ConversationService
from analogai.foundation.extensions.conversation.repositories import InMemoryConversationRepositoryImpl, MongoDBConversationRepositoryImpl
from analogai.foundation import config
from analogai.foundation.common.enums.environment import Environment

class ConversationServiceFactory:
    def create(self) -> ConversationService:
        env = Environment(config.ENVIRONMENT)
        if env == Environment.PRODUCTION:
            repository = MongoDBConversationRepositoryImpl()
        elif env == Environment.DEVELOPMENT:
            repository = InMemoryConversationRepositoryImpl()
        else:
            raise ValueError(f"No repository implementation for environment: {env}")
        return ConversationService(repository)
