from abc import ABC, abstractmethod
from typing import List, Optional
from analogai.foundation.extensions.conversation.conversation import Conversation
from analogai.foundation.extensions.conversation.turn import Turn


class ConversationRepository(ABC):
    @abstractmethod
    def create_conversation(self, user_id: str, agent_id: str) -> Conversation:
        pass

    @abstractmethod
    def find_by_id(self, conversation_id: str) -> Optional[Conversation]:
        pass

    @abstractmethod
    def find_by_agent(self, agent_id: str, page: int = 1, page_size: int = 10) -> List[Conversation]:
        pass

    @abstractmethod
    def find_latest_by_user_and_agent(self, user_id: str, agent_id: str) -> Optional[Conversation]:
        pass

    @abstractmethod
    def add_turn(self, conversation_id: str, turn: Turn) -> Turn:
        pass

    @abstractmethod
    def delete_conversation(self, conversation_id: str) -> bool:
        pass
