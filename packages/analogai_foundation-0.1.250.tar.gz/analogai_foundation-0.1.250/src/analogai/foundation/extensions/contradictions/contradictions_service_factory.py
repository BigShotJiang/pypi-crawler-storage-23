from analogai.foundation.extensions.contradictions.contradictions_service import ContradictionsService
from analogai.foundation.setup.factories.belief_service_factory import BeliefServiceFactory


class ContradictionsServiceFactory:
    def __init__(self, belief_service=None, environment: str | None = None):
        self.belief_service = belief_service or BeliefServiceFactory(environment=environment).get_service()
        self.service = ContradictionsService(self.belief_service)

    def get_service(self) -> ContradictionsService:
        return self.service
