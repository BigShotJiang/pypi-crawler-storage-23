from typing import Iterable, Tuple


def calculate_probability_variance(certainties: Iterable[Tuple[float, float]]) -> float:
    certainties_list = list(certainties)
    if not certainties_list:
        raise ValueError("Certainties list cannot be empty")

    for validity, probability in certainties_list:
        if validity < 0 or probability < 0 or validity > 1 or probability > 1:
            raise ValueError("Validity and probability cannot be negative or above 1")

    total_weight = sum(validity for validity, _ in certainties_list)
    if total_weight == 0:
        return 0.0

    mean = sum(validity * probability for validity, probability in certainties_list) / total_weight
    variance = sum(validity * (probability - mean) ** 2 for validity, probability in certainties_list) / total_weight
    return variance
