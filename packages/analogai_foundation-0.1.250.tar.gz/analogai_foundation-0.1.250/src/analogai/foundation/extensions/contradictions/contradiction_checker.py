from analogai.foundation.extensions.contradictions.config import VARIANCE_THRESHOLD
from analogai.foundation.extensions.contradictions.probability_variance_calculator import calculate_probability_variance


def is_belief_contradictory(belief) -> bool:
    probabilities = [(statement.validity, statement.probability) for statement in belief.statements]
    if not probabilities:
        raise ValueError("Cannot check contradiction for belief without statements")
    variance = calculate_probability_variance(probabilities)
    return variance > VARIANCE_THRESHOLD
