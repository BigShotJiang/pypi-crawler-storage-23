import unittest

from analogai.foundation.extensions.contradictions.contradictions_service_factory import ContradictionsServiceFactory
from analogai.foundation.common.dtos.notion_expression import NotionExpression
from analogai.foundation.core.value_objects.relation import Relation
from analogai.foundation.tests.functional.services.setup import ServicesTestConfig


class TestContradictionsServiceFunctional(unittest.TestCase):
    def setUp(self):
        self.config = ServicesTestConfig()
        self.notion_service = self.config.notion_service
        self.statement_service = self.config.statement_service
        self.belief_service = self.config.belief_service
        self.contradictions_service = ContradictionsServiceFactory(
            belief_service=self.belief_service,
        ).get_service()
        self.user = self.config.user
        self.agent = self.config.agent

    def tearDown(self):
        self.config.tear_down()

    def test_find_contradictory_beliefs_returns_contradictions(self):
        a = self.notion_service.find_or_create(
            self.user.id,
            self.agent.id,
            NotionExpression(caption="alpha"),
        )
        b = self.notion_service.find_or_create(
            self.user.id,
            self.agent.id,
            NotionExpression(caption="beta"),
        )
        c = self.notion_service.find_or_create(
            self.user.id,
            self.agent.id,
            NotionExpression(caption="gamma"),
        )

        relation = Relation.from_string("is")

        self.statement_service.create(
            user_id=self.user.id,
            agent_id=self.agent.id,
            subject_notion=a,
            complement_notion=b,
            relation=relation,
            probability=0.2,
            validity=1.0,
        )
        self.statement_service.create(
            user_id=self.user.id,
            agent_id=self.agent.id,
            subject_notion=b,
            complement_notion=c,
            relation=relation,
            probability=0.2,
            validity=1.0,
        )
        self.statement_service.create(
            user_id=self.user.id,
            agent_id=self.agent.id,
            subject_notion=a,
            complement_notion=c,
            relation=relation,
            probability=0.9,
            validity=1.0,
        )

        contradictions = self.contradictions_service.find_contradictory_beliefs(
            agent_id=self.agent.id,
        )
        matching = [
            belief for belief in contradictions
            if belief.subject_notion.id == a.id
            and belief.complement_notion.id == c.id
            and belief.relation == relation
        ]
        self.assertTrue(matching)


if __name__ == "__main__":
    unittest.main()
