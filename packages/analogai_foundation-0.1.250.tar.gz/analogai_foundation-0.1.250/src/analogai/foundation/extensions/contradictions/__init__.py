from analogai.foundation.extensions.contradictions.config import VARIANCE_THRESHOLD
from analogai.foundation.extensions.contradictions.contradiction_checker import is_belief_contradictory
from analogai.foundation.extensions.contradictions.probability_variance_calculator import calculate_probability_variance
from analogai.foundation.extensions.contradictions.contradictions_service import ContradictionsService
from analogai.foundation.extensions.contradictions.contradictions_service_factory import ContradictionsServiceFactory

__all__ = [
    "VARIANCE_THRESHOLD",
    "is_belief_contradictory",
    "calculate_probability_variance",
    "ContradictionsService",
    "ContradictionsServiceFactory",
]
