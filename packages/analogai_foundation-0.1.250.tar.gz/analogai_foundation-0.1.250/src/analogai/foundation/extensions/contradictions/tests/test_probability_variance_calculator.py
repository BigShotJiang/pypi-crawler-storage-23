import unittest

from analogai.foundation.extensions.contradictions.probability_variance_calculator import calculate_probability_variance


class TestProbabilityVarianceCalculator(unittest.TestCase):
    def test_zero_variance_with_identical_probabilities(self):
        probabilities = [(0.8, 0.5), (0.8, 0.5), (0.8, 0.5)]
        result = calculate_probability_variance(probabilities)
        self.assertAlmostEqual(result, 0.0, places=10)

    def test_variance_with_different_probabilities(self):
        probabilities = [(1.0, 1.0), (1.0, 0.0)]
        expected_variance = 0.25
        result = calculate_probability_variance(probabilities)
        self.assertAlmostEqual(result, expected_variance, places=10)

    def test_weighted_variance_calculation(self):
        probabilities = [(1.0, 0.5), (0.2, 0.5), (0.2, 0.5), (0.2, 0.5)]
        expected_variance = 0.0
        result = calculate_probability_variance(probabilities)
        self.assertAlmostEqual(result, expected_variance, places=10)

    def test_single_probability_returns_zero_variance(self):
        probabilities = [(0.8, 0.7)]
        result = calculate_probability_variance(probabilities)
        self.assertAlmostEqual(result, 0.0, places=10)

    def test_negative_validity_raises(self):
        probabilities = [(-0.5, 0.7), (0.8, 0.3)]
        with self.assertRaises(ValueError):
            calculate_probability_variance(probabilities)

    def test_empty_probabilities_list(self):
        with self.assertRaises(ValueError):
            calculate_probability_variance([])


if __name__ == "__main__":
    unittest.main()
