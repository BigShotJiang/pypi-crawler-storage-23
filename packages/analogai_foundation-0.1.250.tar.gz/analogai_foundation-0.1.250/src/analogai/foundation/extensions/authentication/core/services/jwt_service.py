from abc import ABC, abstractmethod
from typing import Optional, TYPE_CHECKING
from analogai.foundation.modules.user.user import User

if TYPE_CHECKING:
    from analogai.foundation.extensions.authentication.models.token_payload import TokenPayload

class IJWTService(ABC):
    @abstractmethod
    def authenticate_user(self, token: str) -> Optional[User]:
        pass

    @abstractmethod
    def create_token_for_user(self, user_id: str, provider: str = "") -> str:
        pass

    @abstractmethod
    def extract_payload(self, token: str) -> "TokenPayload":
        pass

    @abstractmethod
    def decode_payload(self, token: str) -> dict:
        pass

