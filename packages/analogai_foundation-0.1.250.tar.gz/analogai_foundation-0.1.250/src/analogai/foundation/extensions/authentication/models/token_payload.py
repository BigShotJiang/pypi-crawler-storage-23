from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class TokenPayload:
    token: str
    email: str
    user_id: Optional[str] = None
    name: Optional[str] = None
    provider: Optional[str] = None

