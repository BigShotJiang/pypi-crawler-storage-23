"""Tests for quantum number parsing and validation."""

import pytest

from slater_orbital.quantum_numbers import parse_quantum_numbers


def test_parse_single_value_defaults_l_and_m() -> None:
    qn = parse_quantum_numbers([2])
    assert (qn.n, qn.l, qn.m) == (2, 0, 0)


def test_invalid_magnitude_of_m_raises_error() -> None:
    with pytest.raises(ValueError):
        parse_quantum_numbers([2, 1, 2])
