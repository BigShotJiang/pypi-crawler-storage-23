"""Tests for GUI model-range configuration."""

from slater_orbital.gui import MODEL_Z_RANGES, _element_options_for_model, _model_range_hint, _option_for_z


def test_model_ranges_match_spec() -> None:
    assert MODEL_Z_RANGES["slater_rules"] == (2, 36)
    assert MODEL_Z_RANGES["clementi1963"] == (2, 86)
    assert MODEL_Z_RANGES["guerra2017"] == (2, 118)


def test_slater_element_options_stop_at_36() -> None:
    options = _element_options_for_model("slater_rules")
    assert options[0].startswith("2 ")
    assert options[-1].startswith("36 ")


def test_model_range_hint_text() -> None:
    assert _model_range_hint("slater_rules") == "Z 2-36"
    assert _model_range_hint("clementi1963") == "Z 2-86"
    assert _model_range_hint("guerra2017") == "Z 2-118"


def test_option_for_z_returns_matching_entry() -> None:
    options = _element_options_for_model("clementi1963")
    match = _option_for_z(options, 36)
    assert match is not None
    assert match.startswith("36 ")


def test_option_for_z_returns_none_when_missing() -> None:
    options = _element_options_for_model("slater_rules")
    assert _option_for_z(options, 100) is None
