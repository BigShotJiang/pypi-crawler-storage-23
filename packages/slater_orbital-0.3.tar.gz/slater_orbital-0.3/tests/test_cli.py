"""Tests for CLI parser behavior."""

from slater_orbital.cli import _build_parser, _default_output_name


def test_default_output_name_contains_identifiers() -> None:
    name = _default_output_name(8, 8, 2, 1, 0, "real", "z", 0.0)
    assert name.startswith("slater_Z8_e8_n2_l1_m0_real_z")
    assert name.endswith(".png")


def test_cli_defaults() -> None:
    parser = _build_parser()
    args = parser.parse_args(["2"])
    assert args.element == 1
    assert args.mode == "real"
    assert args.scale == "linear"


def test_cli_accepts_guerra_model() -> None:
    parser = _build_parser()
    args = parser.parse_args(["2", "1", "0", "--model", "guerra2017"])
    assert args.model == "guerra2017"


def test_cli_accepts_clementi_model() -> None:
    parser = _build_parser()
    args = parser.parse_args(["2", "1", "0", "--model", "clementi1963"])
    assert args.model == "clementi1963"
