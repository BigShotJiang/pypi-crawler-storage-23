"""Tests for effective-charge calculations."""

from slater_orbital.slater import compute_effective_charge


def test_hydrogen_1s_zeff_is_1() -> None:
    eff = compute_effective_charge(z=1, electrons=1, n=1, l=0)
    assert abs(eff.zeff - 1.0) < 1e-12


def test_helium_1s_matches_slater_rule() -> None:
    eff = compute_effective_charge(z=2, electrons=2, n=1, l=0)
    assert abs(eff.shielding - 0.30) < 1e-12
    assert abs(eff.zeff - 1.70) < 1e-12


def test_lithium_2s_matches_classic_estimate() -> None:
    eff = compute_effective_charge(z=3, electrons=3, n=2, l=0)
    assert abs(eff.shielding - 1.70) < 1e-12
    assert abs(eff.zeff - 1.30) < 1e-12


def test_guerra_model_oxygen_2p_uses_tabulated_value() -> None:
    eff = compute_effective_charge(z=8, electrons=8, n=2, l=1, model="guerra2017")
    # Table-1 mean of 2p1/2 and 2p3/2 for oxygen: (4.022 + 4.082)/2 = 4.052
    assert abs(eff.zeff - 4.052) < 1e-6
    assert eff.source == "guerra2017-table"


def test_clementi_model_oxygen_2p_converts_xi_to_zeff() -> None:
    eff = compute_effective_charge(z=8, electrons=8, n=2, l=1, model="clementi1963")
    # Clementi 1963 table gives xi(2p)=2.2266 for O; Zeff = n*xi.
    assert abs(eff.zeff - (2.0 * 2.2266)) < 1e-6
    assert eff.source == "clementi1963-xi->zeff"


def test_clementi_ion_correction_uses_slater_delta() -> None:
    # For charged states under Clementi model, correction follows
    # delta(Zeff)_ion from Slater rules.
    z = 8
    n = 2
    l = 1
    neutral = compute_effective_charge(z=z, electrons=z, n=n, l=l, model="clementi1963")
    ion = compute_effective_charge(z=z, electrons=z - 1, n=n, l=l, model="clementi1963")
    s_neutral = compute_effective_charge(z=z, electrons=z, n=n, l=l, model="slater_rules")
    s_ion = compute_effective_charge(z=z, electrons=z - 1, n=n, l=l, model="slater_rules")
    assert abs((ion.zeff - neutral.zeff) - (s_ion.zeff - s_neutral.zeff)) < 1e-6
    assert ion.source == "clementi1963-xi+slater-ion-correction"


def test_guerra_model_barium_6s_uses_table3_value() -> None:
    eff = compute_effective_charge(z=56, electrons=56, n=6, l=0, model="guerra2017")
    assert abs(eff.zeff - 10.612) < 1e-6
    assert eff.source == "guerra2017-table"


def test_guerra_model_tin_5p_uses_table2_average() -> None:
    eff = compute_effective_charge(z=50, electrons=50, n=5, l=1, model="guerra2017")
    assert abs(eff.zeff - 11.4335) < 1e-6
    assert eff.source == "guerra2017-table"


def test_guerra_model_oganesson_7p_uses_table3_average() -> None:
    eff = compute_effective_charge(z=118, electrons=118, n=7, l=1, model="guerra2017")
    # Mean of 7p1/2 and 7p3/2 from Table 3: (34.580 + 24.366) / 2
    assert abs(eff.zeff - 29.473) < 1e-6
    assert eff.source == "guerra2017-table"


def test_guerra_model_oganesson_5f_uses_table2_average() -> None:
    eff = compute_effective_charge(z=118, electrons=118, n=5, l=3, model="guerra2017")
    # Mean of 5f5/2 and 5f7/2 from Table 2: (51.526 + 50.574) / 2
    assert abs(eff.zeff - 51.050) < 1e-6
    assert eff.source == "guerra2017-table"
