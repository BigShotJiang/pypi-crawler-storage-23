"""Parsing and validation helpers for quantum numbers."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class QuantumNumbers:
    """Container for a validated ``(n, l, m)`` triple."""

    n: int
    l: int
    m: int


def parse_quantum_numbers(values: list[int]) -> QuantumNumbers:
    """Parse and validate one to three quantum numbers: ``n [l] [m]``."""
    if not 1 <= len(values) <= 3:
        raise ValueError("Please provide 1 to 3 quantum numbers: n [l] [m].")

    padded = values + [0] * (3 - len(values))
    n, l, m = padded

    if n < 1:
        raise ValueError("Principal quantum number n must be >= 1.")
    if l < 0:
        raise ValueError("Angular momentum quantum number l must be >= 0.")
    if l > n - 1:
        raise ValueError("Angular momentum quantum number l must satisfy l <= n - 1.")
    if abs(m) > l:
        raise ValueError("Magnetic quantum number m must satisfy |m| <= l.")

    return QuantumNumbers(n=n, l=l, m=m)
