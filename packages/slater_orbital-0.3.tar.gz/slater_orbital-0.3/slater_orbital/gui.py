"""Tkinter GUI for side-by-side orbital comparison.

Left panel is fixed to hydrogen (Z=1, e=1). Right panel is a selectable atom
or ion state (electron count control), with selectable effective-charge model.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import numpy as np
from matplotlib import colormaps
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.colors import LogNorm, Normalize, SymLogNorm, TwoSlopeNorm
from matplotlib.figure import Figure

from .analytic import hydrogen_radial_wavefunction, hydrogen_wavefunction, slater_radial_wavefunction, slater_wavefunction
from .auto_settings import auto_extent_a0
from .constants import BOHR_RADIUS
from .electron_config import build_occupations, subshell_label
from .modes import evaluate_mode
from .plotting import resolve_colormap, resolve_density_cmap
from .quantum_numbers import parse_quantum_numbers
from .slicing import build_plane_grid, cartesian_to_spherical
from .slater import compute_effective_charge


COLORMAP_CHOICES = (
    "RdYlBu_r",
    "RdBu_r",
    "coolwarm",
    "seismic",
    "bwr",
    "Spectral_r",
    "PiYG",
    "PRGn",
    "BrBG",
    "viridis",
    "plasma",
    "magma",
    "cividis",
    "turbo",
)


MODEL_Z_RANGES: dict[str, tuple[int, int]] = {
    "slater_rules": (2, 36),
    "clementi1963": (2, 86),
    "guerra2017": (2, 118),
}


def _model_range_hint(model: str) -> str:
    """Return compact model-supported Z range label."""
    z_min, z_max = MODEL_Z_RANGES.get(model, (2, 118))
    return f"Z {z_min}-{z_max}"


ELEMENT_SYMBOLS = [
    "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar",
    "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge", "As", "Se", "Br", "Kr",
    "Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "I", "Xe",
    "Cs", "Ba", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu", "Hf",
    "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th",
    "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs",
    "Mt", "Ds", "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og",
]


def _neutral_configuration_label(z: int) -> str:
    """Build a compact neutral electron configuration string."""
    noble_cores = ((86, "[Rn]"), (54, "[Xe]"), (36, "[Kr]"), (18, "[Ar]"), (10, "[Ne]"), (2, "[He]"))
    core_e = 0
    core_tag = ""
    for e, tag in noble_cores:
        if z > e:
            core_e = e
            core_tag = tag
            break
        if z == e:
            return tag

    full_occ = build_occupations(z)
    core_occ = build_occupations(core_e) if core_e > 0 else []
    core_map = {(o.n, o.l): o.electrons for o in core_occ}

    remainder: list[tuple[int, int, int]] = []
    for occ in full_occ:
        rem = occ.electrons - core_map.get((occ.n, occ.l), 0)
        if rem > 0:
            remainder.append((occ.n, occ.l, rem))

    remainder.sort(key=lambda t: (t[0], t[1]))
    remainder_parts = [f"{subshell_label(n, l)}^{e}" for n, l, e in remainder]
    if core_tag and remainder_parts:
        return f"{core_tag} {' '.join(remainder_parts)}"
    return " ".join(remainder_parts)


def _element_options() -> list[str]:
    """Return dropdown labels like '28 Ni [Ar] 3d^8 4s^2'."""
    options: list[str] = []
    for z in range(2, 119):
        symbol = ELEMENT_SYMBOLS[z - 1]
        cfg = _neutral_configuration_label(z)
        options.append(f"{z} {symbol} {cfg}")
    return options


def _element_options_for_model(model: str) -> list[str]:
    z_min, z_max = MODEL_Z_RANGES.get(model, (2, 118))
    options = _element_options()
    return [opt for opt in options if z_min <= int(opt.split(" ", 1)[0]) <= z_max]


def _option_for_z(options: list[str], z: int) -> str | None:
    """Return element option with given ``z`` if available."""
    for opt in options:
        if int(opt.split(" ", 1)[0]) == z:
            return opt
    return None


def _auto_extent_hydrogen_a0(n: int, l: int, mode: str) -> float:
    """Estimate hydrogen plotting half-range in units of ``a0``."""
    r_max = 12.0 * (n**2) * BOHR_RADIUS
    r = np.linspace(0.0, r_max, 10000)
    radial = hydrogen_radial_wavefunction(n=n, l=l, r=r)

    if mode in {"density", "radial_distribution"}:
        radial_density = (r**2) * (np.abs(radial) ** 2)
        dr = r[1] - r[0]
        cumulative = np.cumsum((radial_density[:-1] + radial_density[1:]) * 0.5 * dr)
        cumulative = np.insert(cumulative, 0, 0.0)
        total = cumulative[-1] if cumulative[-1] > 0.0 else 1.0
        idx = int(np.searchsorted(cumulative / total, 0.995))
        idx = min(max(idx, 1), len(r) - 1)
        raw_extent = 1.2 * (r[idx] / BOHR_RADIUS)
    else:
        abs_radial = np.abs(radial)
        peak = float(np.nanmax(abs_radial)) if abs_radial.size else 0.0
        if peak <= 0.0:
            raw_extent = 6.0
        else:
            cutoff = peak * 2e-3
            significant = np.where(abs_radial >= cutoff)[0]
            edge = r[int(significant[-1])] if significant.size else 4.0 * BOHR_RADIUS
            raw_extent = 1.25 * (edge / BOHR_RADIUS)

    max_extent = max(10.0, (6.0 + 2.0 * float(l)) * float(n))
    return float(np.clip(raw_extent, 4.0, max_extent))


def _auto_plane_and_value_hydrogen(n: int, l: int, m: int, mode: str, extent_a0: float) -> tuple[str, float]:
    """Choose default plane based on hydrogen-only signal scoring."""
    best_plane = "z"
    best_score = -1.0
    for plane in ("z", "x", "y"):
        grid = build_plane_grid(plane=plane, value_a0=0.0, extent_a0=extent_a0, points=121)
        r, theta, phi = cartesian_to_spherical(grid.x, grid.y, grid.z)
        psi = hydrogen_wavefunction(n=n, l=l, m=m, r=r, theta=theta, phi=phi)
        field = np.asarray(evaluate_mode(psi=psi, mode=mode))
        peak = float(np.nanpercentile(np.abs(field), 99.5))
        spread = float(np.nanstd(field))
        score = peak + spread
        if score > best_score:
            best_score = score
            best_plane = plane
    return best_plane, 0.0


class OrbitalCompareApp:
    """Main GUI app with fixed H-left and configurable right panel."""

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Slater-orbital UI (H vs target)")
        self.root.geometry("1120x800")

        self.n_var = tk.IntVar(value=2)
        self.l_var = tk.IntVar(value=1)
        self.m_var = tk.IntVar(value=0)

        self.element_var = tk.StringVar(value="")
        self.charge_var = tk.IntVar(value=0)
        self.model_var = tk.StringVar(value="slater_rules")

        self.mode_var = tk.StringVar(value="real")
        self.plane_var = tk.StringVar(value="auto")
        self.range_var = tk.DoubleVar(value=20.0)
        self.cmap_var = tk.StringVar(value="plasma")
        self.line_mode_var = tk.BooleanVar(value=True)

        self._slider_after_id: str | None = None
        self._update_after_id: str | None = None
        self._updating = False
        self._build_layout()
        self._refresh_element_options(reset_default=True)
        self._install_auto_refresh()
        self._auto_range(show_errors=False)

    def _build_layout(self) -> None:
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=1)

        top = ttk.Frame(self.root, padding=(10, 8))
        top.grid(row=0, column=0, sticky="ew")

        row0 = ttk.Frame(top)
        row0.grid(row=0, column=0, sticky="w")
        row1 = ttk.Frame(top)
        row1.grid(row=1, column=0, sticky="w", pady=(4, 0))

        def add_pair(parent: ttk.Frame, label: str, widget: tk.Widget) -> None:
            ttk.Label(parent, text=label).pack(side="left", padx=(4, 2))
            widget.pack(side="left", padx=(0, 8))

        # Row 0: quantum numbers + element + charge + model
        add_pair(row0, "n", ttk.Spinbox(row0, from_=1, to=8, width=4, textvariable=self.n_var))
        add_pair(row0, "l", ttk.Spinbox(row0, from_=0, to=7, width=4, textvariable=self.l_var))
        add_pair(row0, "m", ttk.Spinbox(row0, from_=-7, to=7, width=4, textvariable=self.m_var))
        self.element_combo = ttk.Combobox(row0, values=(), textvariable=self.element_var, width=30, state="readonly")
        add_pair(row0, "Element", self.element_combo)
        add_pair(row0, "Charge", ttk.Spinbox(row0, from_=-10, to=10, width=4, textvariable=self.charge_var))
        self.model_combo = ttk.Combobox(
            row0,
            values=("slater_rules", "clementi1963", "guerra2017"),
            textvariable=self.model_var,
            width=12,
            state="readonly",
        )
        add_pair(row0, "Model", self.model_combo)
        self.model_range_label = ttk.Label(row0, text=_model_range_hint(self.model_var.get()))
        self.model_range_label.pack(side="left", padx=(0, 8))

        # Row 1: rendering controls grouped by function.
        # Group A: mode + plane
        group_a = ttk.Frame(row1)
        group_a.pack(side="left", padx=(0, 16))
        ttk.Label(group_a, text="mode").pack(side="left", padx=(4, 2))
        ttk.Combobox(
            group_a,
            values=("real", "density", "radial_distribution"),
            textvariable=self.mode_var,
            width=16,
            state="readonly",
        ).pack(side="left", padx=(0, 6))
        ttk.Label(group_a, text="plane").pack(side="left", padx=(2, 2))
        ttk.Combobox(
            group_a,
            values=("auto", "x", "y", "z"),
            textvariable=self.plane_var,
            width=8,
            state="readonly",
        ).pack(side="left", padx=(0, 4))

        # Group B: cmap + line mode
        group_b = ttk.Frame(row1)
        group_b.pack(side="left", padx=(0, 16))
        ttk.Label(group_b, text="cmap").pack(side="left", padx=(4, 2))
        ttk.Combobox(
            group_b,
            values=COLORMAP_CHOICES,
            textvariable=self.cmap_var,
            width=12,
            state="normal",
        ).pack(side="left", padx=(0, 6))
        ttk.Checkbutton(group_b, text="Line mode", variable=self.line_mode_var).pack(side="left", padx=(2, 4))

        # Group C: autorange
        group_c = ttk.Frame(row1)
        group_c.pack(side="left", padx=(0, 12))
        ttk.Button(group_c, text="Auto range", command=self._auto_range).pack(side="left")

        # Group D: export
        group_d = ttk.Frame(row1)
        group_d.pack(side="left", padx=(0, 4))
        ttk.Button(group_d, text="Export", command=self._export).pack(side="left")

        mid = ttk.Frame(self.root, padding=(10, 0, 10, 0))
        mid.grid(row=1, column=0, sticky="nsew")
        mid.columnconfigure(0, weight=1)
        mid.rowconfigure(0, weight=1)

        self.figure = Figure(figsize=(10, 5.8), dpi=120)
        self.canvas = FigureCanvasTkAgg(self.figure, master=mid)
        self.canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew")

        bottom = ttk.Frame(self.root, padding=(12, 8))
        bottom.grid(row=2, column=0, sticky="ew")
        bottom.columnconfigure(1, weight=1)
        ttk.Label(bottom, text="Range (a0)").grid(row=0, column=0, sticky="w", padx=(0, 8))
        ttk.Scale(bottom, from_=4.0, to=80.0, variable=self.range_var, command=self._on_slider).grid(
            row=0,
            column=1,
            sticky="ew",
        )
        self.range_label = ttk.Label(bottom, text=f"{self.range_var.get():.1f}")
        self.range_label.grid(row=0, column=2, sticky="e", padx=(8, 0))

    def _on_slider(self, _: str) -> None:
        self.range_label.configure(text=f"{self.range_var.get():.1f}")
        if self._slider_after_id is not None:
            self.root.after_cancel(self._slider_after_id)
        self._slider_after_id = self.root.after(150, lambda: self._plot_current(show_errors=False))

    def _install_auto_refresh(self) -> None:
        """Refresh plot automatically whenever top controls change."""

        def schedule_plot(*_: object) -> None:
            if self._updating:
                return
            if self._update_after_id is not None:
                self.root.after_cancel(self._update_after_id)
            self._update_after_id = self.root.after(120, lambda: self._plot_current(show_errors=False))

        def schedule_auto_range(*_: object) -> None:
            if self._updating:
                return
            if self._update_after_id is not None:
                self.root.after_cancel(self._update_after_id)
            self._update_after_id = self.root.after(120, lambda: self._auto_range(show_errors=False))

        auto_vars = (
            self.n_var,
            self.l_var,
            self.m_var,
            self.element_var,
            self.charge_var,
            self.mode_var,
        )
        for var in auto_vars:
            var.trace_add("write", schedule_auto_range)

        def on_model_change(*_: object) -> None:
            self._refresh_element_options(reset_default=False)
            schedule_auto_range()

        self.model_var.trace_add("write", on_model_change)

        plot_vars = (
            self.plane_var,
            self.cmap_var,
            self.line_mode_var,
        )
        for var in plot_vars:
            var.trace_add("write", schedule_plot)

    def _selected_z(self) -> int:
        """Parse Z from selected element dropdown label."""
        token = self.element_var.get().split(" ", 1)[0]
        return int(token)

    def _refresh_element_options(self, reset_default: bool) -> None:
        """Apply model-specific element range to dropdown values."""
        model = self.model_var.get()
        self.model_range_label.configure(text=_model_range_hint(model))
        options = _element_options_for_model(model)
        self.element_combo.configure(values=options)
        if not options:
            self.element_var.set("")
            return

        if reset_default:
            # Default element is Z=4 if available, otherwise first in range.
            default = next((opt for opt in options if opt.startswith("4 ")), options[0])
            self.element_var.set(default)
            return

        current = self.element_var.get()
        if current not in options:
            try:
                current_z = int(current.split(" ", 1)[0])
            except (ValueError, IndexError):
                self.element_var.set(options[0])
                return

            z_min, z_max = MODEL_Z_RANGES.get(model, (2, 118))
            clamped = min(max(current_z, z_min), z_max)
            self.element_var.set(_option_for_z(options, clamped) or options[0])

    def _auto_range(self, show_errors: bool = True) -> None:
        try:
            qn = parse_quantum_numbers([self.n_var.get(), self.l_var.get(), self.m_var.get()])
            target_z = self._selected_z()
            z_min, z_max = MODEL_Z_RANGES.get(self.model_var.get(), (2, 118))
            if not (z_min <= target_z <= z_max):
                raise ValueError(f"{self.model_var.get()} supports Z={z_min}..{z_max}; got Z={target_z}.")
            mode = self.mode_var.get()
            eff = compute_effective_charge(
                z=target_z,
                electrons=max(1, target_z - self.charge_var.get()),
                n=qn.n,
                l=qn.l,
                model=self.model_var.get(),
            )
            zeta = eff.zeff / qn.n
            extent_t = auto_extent_a0(n=qn.n, l=qn.l, zeta=zeta, mode=mode)
            extent_h = _auto_extent_hydrogen_a0(n=qn.n, l=qn.l, mode=mode)
            extent = max(extent_t, extent_h)
            self.range_var.set(extent)
            self.range_label.configure(text=f"{extent:.1f}")
            self._plot_current(show_errors=False)
        except ValueError as exc:
            if show_errors:
                messagebox.showerror("Input error", str(exc))

    def _export(self) -> None:
        path = filedialog.asksaveasfilename(
            title="Export Figure",
            defaultextension=".pdf",
            filetypes=[("PDF", "*.pdf"), ("PNG", "*.png"), ("SVG", "*.svg")],
        )
        if not path:
            return
        self.figure.savefig(path, transparent=True, bbox_inches="tight", pad_inches=0.02)
        messagebox.showinfo("Export complete", f"Saved figure to:\n{path}")

    def _plot_current(self, show_errors: bool = True) -> None:
        self._updating = True
        self._slider_after_id = None
        self._update_after_id = None
        try:
            qn = parse_quantum_numbers([self.n_var.get(), self.l_var.get(), self.m_var.get()])
            target_z = self._selected_z()
            charge = self.charge_var.get()
            target_e = target_z - charge
            z_min, z_max = MODEL_Z_RANGES.get(self.model_var.get(), (2, 118))
            if not (z_min <= target_z <= z_max):
                raise ValueError(f"{self.model_var.get()} supports Z={z_min}..{z_max}; got Z={target_z}.")
            if target_z == 1:
                raise ValueError("Right panel target must differ from left-panel H (Z=1).")
            if target_e < 1:
                raise ValueError("Charge state is too high: resulting electron count < 1.")
            if target_e > 118:
                raise ValueError("Resulting electron count > 118 is currently unsupported.")

            mode = self.mode_var.get()
            if mode == "imag":
                mode = "real"
                self.mode_var.set("real")
            value = 0.0
            plane = "z"
            extent = float(self.range_var.get())
            cmap = resolve_colormap(mode=mode, cmap=self.cmap_var.get() or None)
            # Keep GUI default rendering consistent with H-orbital defaults.
            scale = "linear"

            eff_t = compute_effective_charge(
                z=target_z,
                electrons=target_e,
                n=qn.n,
                l=qn.l,
                model=self.model_var.get(),
            )
        except ValueError as exc:
            if show_errors:
                messagebox.showerror("Input error", str(exc))
            self._updating = False
            return

        self.figure.clear()

        if mode == "radial_distribution":
            self._plot_radial_pair(
                n=qn.n,
                l=qn.l,
                extent=extent,
                zeta_t=eff_t.zeff / qn.n,
                eff_t=eff_t,
            )
            self.canvas.draw_idle()
            self._updating = False
            return

        if mode == "real" and scale == "log":
            if show_errors:
                messagebox.showerror("Plot error", "Log scale cannot represent signed fields.")
            self._updating = False
            return
        if mode == "density" and scale == "symlog":
            scale = "linear"

        if self.plane_var.get() == "auto":
            plane, auto_value = _auto_plane_and_value_hydrogen(
                n=qn.n,
                l=qn.l,
                m=qn.m,
                mode=mode,
                extent_a0=extent,
            )
            value = auto_value
        else:
            plane = self.plane_var.get()

        grid = build_plane_grid(plane=plane, value_a0=value, extent_a0=extent, points=301)
        r, theta, phi = cartesian_to_spherical(grid.x, grid.y, grid.z)

        psi_h = hydrogen_wavefunction(n=qn.n, l=qn.l, m=qn.m, r=r, theta=theta, phi=phi)
        psi_t = slater_wavefunction(n=qn.n, l=qn.l, m=qn.m, zeta=eff_t.zeff / qn.n, r=r, theta=theta, phi=phi)
        field_h = np.asarray(evaluate_mode(psi=psi_h, mode=mode))
        field_t = np.asarray(evaluate_mode(psi=psi_t, mode=mode))

        ax_l = self.figure.add_subplot(121)
        ax_r = self.figure.add_subplot(122)
        self.figure.subplots_adjust(wspace=0.34)

        self._draw_slice(ax_l, grid.u, grid.v, field_h, mode, cmap, scale, grid.u_label, grid.v_label, show_ylabel=True)
        self._draw_slice(ax_r, grid.u, grid.v, field_t, mode, cmap, scale, grid.u_label, grid.v_label, show_ylabel=False)

        ax_l.set_title("H atom")
        ax_r.set_title(f"Zeff={eff_t.zeff:.3f}")

        self.figure.suptitle(
            f"n={qn.n}, l={qn.l}, m={qn.m} | mode={mode} | plane={plane} | model={self.model_var.get()}"
        )
        self.canvas.draw_idle()
        self._updating = False

    def _plot_radial_pair(
        self,
        n: int,
        l: int,
        extent: float,
        zeta_t: float,
        eff_t,
    ) -> None:
        r = np.linspace(0.0, extent * BOHR_RADIUS, 401)
        left = (r**2) * (np.abs(hydrogen_radial_wavefunction(n=n, l=l, r=r)) ** 2)
        right = (r**2) * (np.abs(slater_radial_wavefunction(n=n, zeta=zeta_t, r=r)) ** 2)

        ax_l = self.figure.add_subplot(121)
        ax_r = self.figure.add_subplot(122)
        self.figure.subplots_adjust(wspace=0.34)
        ax_l.plot(r / BOHR_RADIUS, left, color="#1f4e79", linewidth=2.0)
        ax_r.plot(r / BOHR_RADIUS, right, color="#1f4e79", linewidth=2.0)
        ax_l.set_title("H atom")
        ax_r.set_title(f"Zeff={eff_t.zeff:.3f}")
        ax_l.set_xlabel("r / a0")
        ax_l.set_ylabel(r"$r^2|R(r)|^2$")
        ax_l.grid(alpha=0.25)
        ax_r.set_xlabel("r / a0")
        ax_r.set_ylabel("")
        ax_r.grid(alpha=0.25)

        self.figure.suptitle(f"n={n}, l={l} | mode=radial_distribution | model={self.model_var.get()}")

    def _draw_slice(
        self,
        ax,
        u: np.ndarray,
        v: np.ndarray,
        field: np.ndarray,
        mode: str,
        cmap: str,
        scale: str,
        u_label: str,
        v_label: str,
        show_ylabel: bool,
    ) -> None:
        line_mode = bool(self.line_mode_var.get())
        if mode == "density":
            if line_mode:
                vmax = max(float(np.nanmax(field)), 1e-16)
                den_cmap = colormaps.get_cmap(cmap)
                den_norm = Normalize(vmin=0.0, vmax=vmax)
                levels = np.linspace(0.12 * vmax, vmax, 8)
                for level in levels:
                    color = den_cmap(den_norm(level))
                    ax.contour(u, v, field, levels=[level], colors=[color], linewidths=1.2, linestyles="solid")
            else:
                density_cmap = resolve_density_cmap(cmap)
                positive = field[field > 0.0]
                if scale == "log" and positive.size > 0:
                    vmax = max(float(np.nanmax(field)), 1e-16)
                    vmin = max(float(np.nanmin(positive)), vmax * 1e-7)
                    levels = np.geomspace(vmin, vmax, 21)
                    ax.contourf(u, v, field, levels=levels, cmap=density_cmap, norm=LogNorm(vmin=vmin, vmax=vmax))
                else:
                    vmax = max(float(np.nanmax(field)), 1e-16)
                    levels = np.linspace(0.0, vmax, 21)
                    ax.contourf(u, v, field, levels=levels, cmap=density_cmap)
        else:
            vlim = max(float(np.nanmax(np.abs(field))), 1e-16)
            if line_mode:
                base_cmap = colormaps.get_cmap(cmap)
                norm = TwoSlopeNorm(vmin=-vlim, vcenter=0.0, vmax=vlim)
                levels = np.linspace(0.12 * vlim, vlim, 8)
                for level in levels:
                    pos_color = base_cmap(norm(level))
                    neg_color = base_cmap(norm(-level))
                    ax.contour(u, v, field, levels=[level], colors=[pos_color], linewidths=1.2, linestyles="solid")
                    ax.contour(u, v, field, levels=[-level], colors=[neg_color], linewidths=1.2, linestyles="dashed")
                ax.contour(u, v, field, levels=[0.0], colors="#a8a8a8", linewidths=0.9)
            else:
                if scale == "symlog":
                    linthresh = max(vlim * 1e-3, 1e-16)
                    neg = -np.geomspace(linthresh, vlim, 10)[::-1]
                    pos = np.geomspace(linthresh, vlim, 10)
                    levels = np.concatenate((neg, [0.0], pos))
                    ax.contourf(
                        u,
                        v,
                        field,
                        levels=levels,
                        cmap=cmap,
                        norm=SymLogNorm(linthresh=linthresh, linscale=1.0, vmin=-vlim, vmax=vlim, base=10),
                    )
                else:
                    levels = np.linspace(-vlim, vlim, 21)
                    ax.contourf(u, v, field, levels=levels, cmap=cmap)
                ax.contour(u, v, field, levels=[0.0], colors="#a8a8a8", linewidths=0.9)

        ax.set_xlabel(u_label)
        ax.set_ylabel(v_label if show_ylabel else "")
        ax.set_aspect("equal")
        ax.grid(alpha=0.18)


def main() -> None:
    """Launch the GUI application."""
    root = tk.Tk()
    app = OrbitalCompareApp(root)
    _ = app
    root.mainloop()


if __name__ == "__main__":
    main()
