"""Rendering mode transformations for complex wavefunction values."""

from __future__ import annotations

import numpy as np


def evaluate_mode(psi: np.ndarray, mode: str) -> np.ndarray:
    """Convert complex wavefunction values into the requested render mode."""
    if mode == "density":
        return np.abs(psi) ** 2
    if mode == "real":
        return np.real(psi)
    if mode == "imag":
        return np.imag(psi)
    raise ValueError(f"Unsupported render mode: {mode}")
