"""Public package API for slater-orbital.

This module exposes the stable, user-facing symbols used by both CLI/GUI and
external Python imports.
"""

from .analytic import slater_wavefunction
from .quantum_numbers import QuantumNumbers, parse_quantum_numbers
from .slater import EffectiveCharge, compute_effective_charge

__version__ = "0.3"

__all__ = [
    "QuantumNumbers",
    "parse_quantum_numbers",
    "EffectiveCharge",
    "compute_effective_charge",
    "slater_wavefunction",
    "__version__",
]
