"""Physical and numeric constants used by the project."""

BOHR_RADIUS = 5.29177210903e-11
DEFAULT_POINTS = 401
