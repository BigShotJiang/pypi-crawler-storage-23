"""Electron configuration helpers for neutral and ionized atoms.

The filling model uses a standard aufbau sequence and capacities for a simple,
deterministic baseline suitable for Slater-rule screening estimates.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class OrbitalOccupation:
    """Occupation of a single subshell."""

    n: int
    l: int
    electrons: int


AUFBAU_SEQUENCE: tuple[tuple[int, int, int], ...] = (
    (1, 0, 2),
    (2, 0, 2),
    (2, 1, 6),
    (3, 0, 2),
    (3, 1, 6),
    (4, 0, 2),
    (3, 2, 10),
    (4, 1, 6),
    (5, 0, 2),
    (4, 2, 10),
    (5, 1, 6),
    (6, 0, 2),
    (4, 3, 14),
    (5, 2, 10),
    (6, 1, 6),
    (7, 0, 2),
    (5, 3, 14),
    (6, 2, 10),
    (7, 1, 6),
)


def build_occupations(electron_count: int) -> list[OrbitalOccupation]:
    """Fill orbitals in aufbau order for the requested electron count."""
    if electron_count < 1:
        raise ValueError("Electron count must be >= 1.")

    remaining = electron_count
    occupations: list[OrbitalOccupation] = []

    for n, l, capacity in AUFBAU_SEQUENCE:
        if remaining <= 0:
            break
        fill = min(capacity, remaining)
        occupations.append(OrbitalOccupation(n=n, l=l, electrons=fill))
        remaining -= fill

    if remaining > 0:
        raise ValueError("Electron count exceeds supported subshell range (up to 7p).")

    return occupations


def subshell_label(n: int, l: int) -> str:
    """Convert ``(n,l)`` to a spectroscopic subshell label."""
    symbols = {0: "s", 1: "p", 2: "d", 3: "f"}
    if l not in symbols:
        raise ValueError(f"Unsupported l={l}. Only s,p,d,f are currently supported.")
    return f"{n}{symbols[l]}"
