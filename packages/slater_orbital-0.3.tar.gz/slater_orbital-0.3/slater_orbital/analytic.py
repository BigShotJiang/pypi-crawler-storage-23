"""Slater-type orbital (STO) wavefunction implementation."""

from __future__ import annotations

import math

import numpy as np
from scipy.special import eval_genlaguerre, lpmv

from .constants import BOHR_RADIUS


def slater_radial_wavefunction(n: int, zeta: float, r: np.ndarray) -> np.ndarray:
    """Evaluate a normalized single-zeta STO radial function.

    The form used is

        R(r) = N * r^(n-1) * exp(-zeta * r / a0)

    with normalization based on ``int |R|^2 r^2 dr = 1``.
    """
    if n < 1:
        raise ValueError("n must be >= 1.")
    if zeta <= 0.0:
        raise ValueError("zeta must be > 0.")

    alpha = zeta / BOHR_RADIUS
    norm = (2.0 * alpha) ** (n + 0.5) / math.sqrt(math.factorial(2 * n))
    return norm * np.power(r, n - 1) * np.exp(-alpha * r)


def spherical_harmonic(l: int, m: int, theta: np.ndarray, phi: np.ndarray) -> np.ndarray:
    """Evaluate normalized spherical harmonic ``Y_l^m(theta, phi)``."""
    m_abs = abs(m)
    normalization = math.sqrt(
        ((2 * l + 1) / (4.0 * math.pi)) * (math.factorial(l - m_abs) / math.factorial(l + m_abs))
    )
    p_lm = lpmv(m_abs, l, np.cos(theta))
    y_positive = normalization * p_lm * np.exp(1j * m_abs * phi)
    if m >= 0:
        return y_positive
    return ((-1) ** m_abs) * np.conjugate(y_positive)


def slater_wavefunction(
    n: int,
    l: int,
    m: int,
    zeta: float,
    r: np.ndarray,
    theta: np.ndarray,
    phi: np.ndarray,
) -> np.ndarray:
    """Compute ``psi(r,theta,phi) = R_sto(r) * Y_l^m(theta,phi)``."""
    radial = slater_radial_wavefunction(n=n, zeta=zeta, r=r)
    angular = spherical_harmonic(l=l, m=m, theta=theta, phi=phi)
    return radial * angular


def hydrogen_radial_wavefunction(n: int, l: int, r: np.ndarray) -> np.ndarray:
    """Evaluate analytic hydrogen radial function ``R_{n,l}(r)``."""
    rho = 2.0 * r / (n * BOHR_RADIUS)
    prefactor = (2.0 / (n * BOHR_RADIUS)) ** 1.5
    norm = math.sqrt(math.factorial(n - l - 1) / (2.0 * n * math.factorial(n + l)))
    laguerre = eval_genlaguerre(n - l - 1, 2 * l + 1, rho)
    return prefactor * norm * np.exp(-rho / 2.0) * np.power(rho, l) * laguerre


def hydrogen_wavefunction(
    n: int,
    l: int,
    m: int,
    r: np.ndarray,
    theta: np.ndarray,
    phi: np.ndarray,
) -> np.ndarray:
    """Compute analytic hydrogen wavefunction ``psi_{n,l,m}``."""
    radial = hydrogen_radial_wavefunction(n=n, l=l, r=r)
    angular = spherical_harmonic(l=l, m=m, theta=theta, phi=phi)
    return radial * angular
