"""Effective nuclear charge models for Slater-type orbitals."""

from __future__ import annotations

from dataclasses import dataclass

from .clementi_data import lookup_clementi_zeff
from .electron_config import OrbitalOccupation, build_occupations, subshell_label
from .guerra_data import lookup_guerra_zeff


@dataclass(frozen=True)
class EffectiveCharge:
    """Computed effective charge and associated metadata."""

    z: int
    electrons: int
    n: int
    l: int
    zeff: float
    shielding: float
    model: str
    subshell: str
    source: str


def _group_index(n: int, l: int) -> int:
    """Return Slater grouping index for ``(n,l)``."""
    if n == 1 and l == 0:
        return 1
    if l <= 1:
        return 2 * n
    if l == 2:
        return 2 * n + 1
    if l == 3:
        return 2 * n + 2
    raise ValueError(f"Unsupported l={l}; supported: 0(s), 1(p), 2(d), 3(f).")


def _electrons_in_orbital(occupations: list[OrbitalOccupation], n: int, l: int) -> int:
    for occ in occupations:
        if occ.n == n and occ.l == l:
            return occ.electrons
    return 0


def _slater_rules_shielding(occupations: list[OrbitalOccupation], n: int, l: int) -> float:
    """Compute Slater shielding constant for a selected electron in ``(n,l)``."""
    target_group = _group_index(n=n, l=l)
    shielding = 0.0

    for occ in occupations:
        occ_group = _group_index(n=occ.n, l=occ.l)

        if occ.n == n and occ.l == l:
            same = max(occ.electrons - 1, 0)
            if n == 1 and l == 0:
                shielding += 0.30 * same
            else:
                shielding += 0.35 * same
            continue

        if l <= 1:
            if occ.n == n - 1:
                if occ.l <= 1:
                    shielding += 0.85 * occ.electrons
                else:
                    shielding += 1.00 * occ.electrons
            elif occ.n <= n - 2:
                shielding += 1.00 * occ.electrons
        else:
            if occ_group < target_group:
                shielding += 1.00 * occ.electrons

    return shielding


def _compute_slater_rules_zeff(z: int, n: int, l: int, electron_count: int) -> tuple[float, float]:
    """Compute Zeff and shielding using classical Slater screening rules."""
    occupations = build_occupations(electron_count)
    if _electrons_in_orbital(occupations, n=n, l=l) == 0:
        occupations = occupations + [OrbitalOccupation(n=n, l=l, electrons=1)]
    shielding = _slater_rules_shielding(occupations=occupations, n=n, l=l)
    zeff = max(float(z) - shielding, 0.10)
    return zeff, shielding


def compute_effective_charge(
    z: int,
    n: int,
    l: int,
    electrons: int | None = None,
    model: str = "slater_rules",
) -> EffectiveCharge:
    """Compute ``Z_eff`` for a selected subshell.

    Args:
        z: Atomic number.
        n: Principal quantum number of the plotted orbital.
        l: Angular quantum number of the plotted orbital.
        electrons: Electron count for the atom/ion state. Defaults to neutral ``z``.
        model: Effective charge model name.
    """
    if z < 1:
        raise ValueError("Atomic number Z must be >= 1.")

    electron_count = z if electrons is None else electrons
    if electron_count < 1:
        raise ValueError("Electron count must be >= 1.")
    if electron_count > 118:
        raise ValueError("Electron count > 118 is currently unsupported.")

    if model not in {"slater_rules", "clementi1963", "guerra2017"}:
        raise ValueError("Supported models: slater_rules, clementi1963, guerra2017")

    zeff_from_table = None
    if model == "guerra2017":
        zeff_from_table = lookup_guerra_zeff(z=z, n=n, l=l)
    elif model == "clementi1963":
        zeff_from_table = lookup_clementi_zeff(z=z, n=n, l=l)

    if zeff_from_table is not None:
        if model == "clementi1963" and electron_count != z:
            # Ion-state correction: keep Clementi neutral baseline but shift it by
            # the Slater-rule ionization delta to preserve a unified Zeff pipeline.
            slater_ion_zeff, _ = _compute_slater_rules_zeff(z=z, n=n, l=l, electron_count=electron_count)
            slater_neutral_zeff, _ = _compute_slater_rules_zeff(z=z, n=n, l=l, electron_count=z)
            delta = slater_ion_zeff - slater_neutral_zeff
            zeff = max(float(zeff_from_table) + delta, 0.10)
            shielding = max(float(z) - zeff, 0.0)
            source = "clementi1963-xi+slater-ion-correction"
        else:
            zeff = max(float(zeff_from_table), 0.10)
            shielding = max(float(z) - zeff, 0.0)
            if model == "clementi1963":
                source = "clementi1963-xi->zeff"
            else:
                source = "guerra2017-table"
    else:
        zeff, shielding = _compute_slater_rules_zeff(z=z, n=n, l=l, electron_count=electron_count)
        source = "slater_rules" if model == "slater_rules" else "fallback:slater_rules"

    return EffectiveCharge(
        z=z,
        electrons=electron_count,
        n=n,
        l=l,
        zeff=zeff,
        shielding=shielding,
        model=model,
        subshell=subshell_label(n=n, l=l),
        source=source,
    )
