"""Command-line interface for Slater orbital plotting."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from .analytic import slater_radial_wavefunction, slater_wavefunction
from .auto_settings import auto_extent_a0, auto_plane_and_value
from .constants import BOHR_RADIUS, DEFAULT_POINTS
from .modes import evaluate_mode
from .plotting import (
    plot_radial_comparison,
    plot_radial_distribution,
    plot_single_panel,
    resolve_colormap,
    resolve_scale,
)
from .quantum_numbers import parse_quantum_numbers
from .slicing import build_plane_grid, cartesian_to_spherical
from .slater import compute_effective_charge


def _build_parser() -> argparse.ArgumentParser:
    """Construct and return the command-line argument parser."""
    parser = argparse.ArgumentParser(
        prog="slater-orbital",
        description="Plot Slater-type orbitals with effective nuclear charge models.",
    )
    parser.add_argument("quantum_numbers", type=int, nargs="*", help="Provide n [l] [m].")
    parser.add_argument("--element", "-Z", type=int, required=False, default=1, help="Atomic number Z.")
    parser.add_argument("--electrons", type=int, default=None, help="Electron count for atom/ion state.")
    parser.add_argument(
        "--model",
        choices=["slater_rules", "clementi1963", "guerra2017"],
        default="slater_rules",
        help="Zeff model.",
    )
    parser.add_argument("--zeta", type=float, default=None, help="Manual STO exponent override.")
    parser.add_argument(
        "--compare-electrons",
        default=None,
        help="Comma-separated electron counts for radial comparison, e.g. 1,2,10.",
    )
    parser.add_argument(
        "--mode",
        choices=["density", "real", "imag", "radial_distribution"],
        default="real",
        help="Render mode.",
    )
    parser.add_argument("--plane", choices=["auto", "x", "y", "z"], default="auto")
    parser.add_argument("--value", type=float, default=None, help="Plane position in a0.")
    parser.add_argument("--range", dest="extent", type=float, default=None, help="Half-range in a0.")
    parser.add_argument("--points", type=int, default=DEFAULT_POINTS, help="Grid samples per axis.")
    parser.add_argument("--cmap", default=None, help="Matplotlib colormap name.")
    parser.add_argument("--scale", choices=["auto", "linear", "log", "symlog"], default="linear")
    parser.add_argument("--colorbar", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--output", default=None, help="Output image path.")
    parser.add_argument("--show", action="store_true", help="Display figure after saving.")
    return parser


def _default_output_name(z: int, electrons: int, n: int, l: int, m: int, mode: str, plane: str, value: float) -> str:
    """Build a deterministic default output filename from plotting parameters."""
    value_tag = str(value).replace("-", "m").replace(".", "p")
    return f"slater_Z{z}_e{electrons}_n{n}_l{l}_m{m}_{mode}_{plane}{value_tag}.png"


def _parse_compare_electrons(raw: str | None) -> list[int]:
    """Parse comma-separated electron counts for radial comparison mode."""
    if not raw:
        return []
    values = []
    for item in raw.split(","):
        item = item.strip()
        if not item:
            continue
        values.append(int(item))
    return values


def main() -> None:
    """CLI entrypoint.

    Flow:
    1) parse/validate input;
    2) resolve Zeff model and zeta;
    3) render radial or slice plot;
    4) save output file and optionally show the figure.
    """
    parser = _build_parser()
    args = parser.parse_args()

    if not args.quantum_numbers:
        parser.print_help()
        return

    try:
        qn = parse_quantum_numbers(args.quantum_numbers)
    except ValueError as exc:
        parser.error(str(exc))

    if args.points < 25:
        parser.error("--points must be at least 25 for stable plotting.")

    z = args.element
    electrons = z if args.electrons is None else args.electrons
    eff = compute_effective_charge(z=z, electrons=electrons, n=qn.n, l=qn.l, model=args.model)
    zeta = args.zeta if args.zeta is not None else eff.zeff / qn.n

    extent = args.extent if args.extent is not None else auto_extent_a0(n=qn.n, l=qn.l, zeta=zeta, mode=args.mode)
    if extent <= 0.0:
        parser.error("--range must be positive.")

    compare_electrons = _parse_compare_electrons(args.compare_electrons)
    if compare_electrons and args.mode != "radial_distribution":
        parser.error("--compare-electrons currently supports only --mode radial_distribution.")

    if compare_electrons:
        output = args.output or f"slater_Z{z}_n{qn.n}_l{qn.l}_radial_compare.png"
        output_path = str(Path(output))
        r = np.linspace(0.0, extent * BOHR_RADIUS, args.points)
        curves: list[tuple[str, np.ndarray]] = []
        for ecount in compare_electrons:
            eff_i = compute_effective_charge(z=z, electrons=ecount, n=qn.n, l=qn.l, model=args.model)
            zeta_i = eff_i.zeff / qn.n
            radial_i = slater_radial_wavefunction(n=qn.n, zeta=zeta_i, r=r)
            curves.append((f"e={ecount}, Zeff={eff_i.zeff:.3f}", (r**2) * (np.abs(radial_i) ** 2)))
        title = f"STO radial comparison | Z={z}, n={qn.n}, l={qn.l}, model={args.model}"
        plot_radial_comparison(r_a0=r / BOHR_RADIUS, curves=curves, title=title, output_path=output_path, show=args.show)
        print(f"Saved plot to: {output_path}")
        return

    if args.mode == "radial_distribution":
        output = args.output or _default_output_name(
            z=z,
            electrons=electrons,
            n=qn.n,
            l=qn.l,
            m=qn.m,
            mode=args.mode,
            plane="r",
            value=0.0,
        )
        output_path = str(Path(output))
        r = np.linspace(0.0, extent * BOHR_RADIUS, args.points)
        radial = slater_radial_wavefunction(n=qn.n, zeta=zeta, r=r)
        radial_prob = (r**2) * (np.abs(radial) ** 2)
        title = f"STO radial | Z={z}, e={electrons}, n={qn.n}, l={qn.l}, Zeff={eff.zeff:.3f}, zeta={zeta:.3f}"
        plot_radial_distribution(
            r_a0=r / BOHR_RADIUS,
            radial_prob=radial_prob,
            title=title,
            output_path=output_path,
            show=args.show,
        )
        print(f"Saved plot to: {output_path}")
        return

    if args.plane == "auto":
        plane, auto_value = auto_plane_and_value(
            n=qn.n,
            l=qn.l,
            m=qn.m,
            zeta=zeta,
            mode=args.mode,
            extent_a0=extent,
        )
    else:
        plane, auto_value = args.plane, 0.0

    value = args.value if args.value is not None else auto_value
    output = args.output or _default_output_name(
        z=z,
        electrons=electrons,
        n=qn.n,
        l=qn.l,
        m=qn.m,
        mode=args.mode,
        plane=plane,
        value=value,
    )
    output_path = str(Path(output))

    grid = build_plane_grid(plane=plane, value_a0=value, extent_a0=extent, points=args.points)
    r, theta, phi = cartesian_to_spherical(grid.x, grid.y, grid.z)
    psi = slater_wavefunction(n=qn.n, l=qn.l, m=qn.m, zeta=zeta, r=r, theta=theta, phi=phi)

    data = evaluate_mode(psi=psi, mode=args.mode)
    cmap = resolve_colormap(mode=args.mode, cmap=args.cmap)
    scale = resolve_scale(mode=args.mode, scale=args.scale)

    if args.mode == "density" and scale == "symlog":
        parser.error("--scale symlog is for signed fields; use linear or log for density.")
    if args.mode in {"real", "imag"} and scale == "log":
        parser.error("--scale log cannot represent signed fields; use linear or symlog.")

    title = (
        f"STO Z={z}, e={electrons} | n={qn.n}, l={qn.l}, m={qn.m} | "
        f"Zeff={eff.zeff:.3f}, zeta={zeta:.3f} | mode={args.mode} | slice={plane}-plane"
    )
    if scale != "linear":
        title = f"{title} | scale={scale}"

    plot_single_panel(
        u=grid.u,
        v=grid.v,
        data=np.asarray(data),
        mode=args.mode,
        title=title,
        x_label=grid.u_label,
        y_label=grid.v_label,
        cmap=cmap,
        scale=scale,
        show_colorbar=args.colorbar,
        output_path=output_path,
        show=args.show,
        show_nodal=True,
    )

    print(f"Saved plot to: {output_path}")
