"""Automatic plotting parameter selection utilities."""

from __future__ import annotations

import numpy as np

from .analytic import slater_radial_wavefunction, slater_wavefunction
from .constants import BOHR_RADIUS
from .modes import evaluate_mode
from .slicing import build_plane_grid, cartesian_to_spherical


def auto_extent_a0(n: int, l: int, zeta: float, mode: str) -> float:
    """Estimate plotting half-range in ``a0`` units for the chosen STO."""
    r_max = max(8.0 * (n**2) * BOHR_RADIUS, 20.0 * BOHR_RADIUS / max(zeta, 0.2))
    r = np.linspace(0.0, r_max, 8000)
    radial = slater_radial_wavefunction(n=n, zeta=zeta, r=r)

    if mode in {"density", "radial_distribution"}:
        radial_density = (r**2) * (np.abs(radial) ** 2)
        dr = r[1] - r[0]
        cumulative = np.cumsum((radial_density[:-1] + radial_density[1:]) * 0.5 * dr)
        cumulative = np.insert(cumulative, 0, 0.0)
        total = cumulative[-1] if cumulative[-1] > 0.0 else 1.0
        target = 0.995
        idx = int(np.searchsorted(cumulative / total, target))
        idx = min(max(idx, 1), len(r) - 1)
        raw_extent = 1.2 * (r[idx] / BOHR_RADIUS)
    else:
        abs_radial = np.abs(radial)
        peak = float(np.nanmax(abs_radial)) if abs_radial.size else 0.0
        if peak <= 0.0:
            raw_extent = 6.0
        else:
            cutoff = peak * 2e-3
            significant = np.where(abs_radial >= cutoff)[0]
            edge = r[int(significant[-1])] if significant.size else 4.0 * BOHR_RADIUS
            raw_extent = 1.3 * (edge / BOHR_RADIUS)

    max_extent = max(10.0, (6.0 + 2.0 * float(l)) * float(n))
    return float(np.clip(raw_extent, 4.0, max_extent))


def auto_plane_and_value(n: int, l: int, m: int, zeta: float, mode: str, extent_a0: float) -> tuple[str, float]:
    """Select a representative plane among x=0, y=0, z=0."""
    best_plane = "z"
    best_score = -1.0

    for plane in ("z", "x", "y"):
        grid = build_plane_grid(plane=plane, value_a0=0.0, extent_a0=extent_a0, points=121)
        r, theta, phi = cartesian_to_spherical(grid.x, grid.y, grid.z)
        psi = slater_wavefunction(n=n, l=l, m=m, zeta=zeta, r=r, theta=theta, phi=phi)
        mode_data = evaluate_mode(psi=psi, mode=mode)
        field = np.asarray(mode_data)
        peak = float(np.nanpercentile(np.abs(field), 99.5))
        spread = float(np.nanstd(field))
        score = peak + spread
        if score > best_score:
            best_score = score
            best_plane = plane

    return best_plane, 0.0
