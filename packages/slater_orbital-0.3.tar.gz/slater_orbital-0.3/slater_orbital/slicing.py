"""Utilities for building 2D planar slices through 3D space."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .constants import BOHR_RADIUS


@dataclass(frozen=True)
class SliceGrid:
    """Container for 2D slice geometry and mapped 3D coordinates."""

    u: np.ndarray
    v: np.ndarray
    x: np.ndarray
    y: np.ndarray
    z: np.ndarray
    u_label: str
    v_label: str
    plane_label: str


def build_plane_grid(plane: str, value_a0: float, extent_a0: float, points: int) -> SliceGrid:
    """Create a 2D grid for a constant x, y, or z plane."""
    axis = np.linspace(-extent_a0, extent_a0, points)
    u, v = np.meshgrid(axis, axis)
    value = value_a0 * BOHR_RADIUS

    if plane == "x":
        x = np.full_like(u, value)
        y = u * BOHR_RADIUS
        z = v * BOHR_RADIUS
        u_label, v_label = "Y", "Z"
    elif plane == "y":
        x = u * BOHR_RADIUS
        y = np.full_like(u, value)
        z = v * BOHR_RADIUS
        u_label, v_label = "X", "Z"
    else:
        x = u * BOHR_RADIUS
        y = v * BOHR_RADIUS
        z = np.full_like(u, value)
        u_label, v_label = "X", "Y"

    return SliceGrid(
        u=u,
        v=v,
        x=x,
        y=y,
        z=z,
        u_label=u_label,
        v_label=v_label,
        plane_label=f"{plane}={value_a0:g} a0",
    )


def cartesian_to_spherical(x: np.ndarray, y: np.ndarray, z: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Convert cartesian coordinates to spherical coordinates."""
    r = np.sqrt(x**2 + y**2 + z**2)
    safe_r = np.where(r == 0.0, 1.0, r)
    theta = np.arccos(np.clip(z / safe_r, -1.0, 1.0))
    theta = np.where(r == 0.0, 0.0, theta)
    phi = np.arctan2(y, x)
    return r, theta, phi
