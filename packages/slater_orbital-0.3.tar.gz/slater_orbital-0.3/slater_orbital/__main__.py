"""Module entrypoint for ``python -m slater_orbital``."""

from .cli import main


if __name__ == "__main__":
    main()
