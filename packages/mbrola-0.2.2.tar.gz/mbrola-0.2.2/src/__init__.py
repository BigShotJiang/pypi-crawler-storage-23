# SPDX-FileCopyrightText: 2024-present gongcastro <gongarciacastro@gmail.com>
#
# SPDX-License-Identifier: MIT
