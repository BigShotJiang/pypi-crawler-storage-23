# about.py

__version__ = "0.1.4"
__package__ = "simple_project_generator"
__program_name__ = "simple-project-generator"
__author__ = "Fernando Pujaico Rivera"
__email__  = "fernando.pujaico.rivera@gmail.com"
__description__ = "my pypi project generator"
__url_source__  = "https://github.com/trucomanx/SimpleProjectGenerator"
__url_doc__  = "https://github.com/trucomanx/SimpleProjectGenerator/tree/main/doc"
__url_funding__ = "https://trucomanx.github.io/en/funding.html"
__url_bugs__    = "https://github.com/trucomanx/SimpleProjectGenerator/issues"
