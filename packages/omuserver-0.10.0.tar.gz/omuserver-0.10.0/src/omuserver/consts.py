from .version import VERSION

USER_AGENT_HEADERS = {"User-Agent": f"OMUAPPS/{VERSION}"}
