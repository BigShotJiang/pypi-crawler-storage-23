from .extension import RegistryExtension

__all__ = ["RegistryExtension"]
