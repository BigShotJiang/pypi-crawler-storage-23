"""commune threads — thread management."""

from __future__ import annotations

from typing import List, Optional

import typer

from ..client import CommuneClient
from ..errors import api_error, auth_required_error, network_error, validation_error
from ..output import print_json, print_list, print_record, print_success
from ..state import AppState

app = typer.Typer(help="Thread management.", no_args_is_help=True)
tags_app = typer.Typer(help="Manage thread tags.", no_args_is_help=True)
app.add_typer(tags_app, name="tags")


@app.command("list")
def threads_list(
    ctx: typer.Context,
    inbox_id: Optional[str] = typer.Option(None, "--inbox-id", help="Filter by inbox ID."),
    domain_id: Optional[str] = typer.Option(None, "--domain-id", help="Filter by domain ID."),
    limit: Optional[int] = typer.Option(None, "--limit", help="Maximum results to return."),
    cursor: Optional[str] = typer.Option(None, "--cursor", help="Pagination cursor."),
    order: Optional[str] = typer.Option(None, "--order", help="Sort order: asc or desc."),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """List email threads. GET /v1/threads."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.get("/v1/threads", params={
            "inbox_id": inbox_id,
            "domain_id": domain_id,
            "limit": limit,
            "cursor": cursor,
            "order": order,
        })
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    print_list(
        r.json(),
        json_output=json_output or state.should_json(),
        title="Threads",
        columns=[
            ("ID", "id"),
            ("Subject", "subject"),
            ("Status", "status"),
            ("Participants", "participantCount"),
            ("Last Activity", "lastActivityAt"),
        ],
    )


@app.command("messages")
def threads_messages(
    ctx: typer.Context,
    thread_id: str = typer.Argument(..., help="Thread ID."),
    limit: Optional[int] = typer.Option(None, "--limit", help="Maximum messages to return."),
    order: Optional[str] = typer.Option(None, "--order", help="Sort order: asc or desc."),
    cursor: Optional[str] = typer.Option(None, "--cursor", help="Pagination cursor."),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """List messages in a thread. GET /v1/threads/{threadId}/messages."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.get(f"/v1/threads/{thread_id}/messages", params={
            "limit": limit,
            "order": order,
            "cursor": cursor,
        })
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    print_list(
        r.json(),
        json_output=json_output or state.should_json(),
        title=f"Messages in Thread {thread_id}",
        columns=[
            ("ID", "id"),
            ("From", "from"),
            ("Subject", "subject"),
            ("Date", "date"),
        ],
    )


@app.command("metadata")
def threads_metadata(
    ctx: typer.Context,
    thread_id: str = typer.Argument(..., help="Thread ID."),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Get thread metadata (status, tags, assignment, participants). GET /v1/threads/{threadId}."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.get(f"/v1/threads/{thread_id}")
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    print_record(r.json(), json_output=json_output or state.should_json(), title=f"Thread {thread_id}")


VALID_STATUSES = ("open", "needs_reply", "waiting", "closed")


@app.command("set-status")
def threads_set_status(
    ctx: typer.Context,
    thread_id: str = typer.Argument(..., help="Thread ID."),
    status: str = typer.Argument(..., help=f"New status. One of: {', '.join(VALID_STATUSES)}."),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Set the status of a thread. PATCH /v1/threads/{threadId}.

    Valid statuses: open, needs_reply, waiting, closed.
    """
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    if status not in VALID_STATUSES:
        validation_error(f"Invalid status '{status}'. Must be one of: {', '.join(VALID_STATUSES)}.",
                         json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.patch(f"/v1/threads/{thread_id}", json={"status": status})
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    if json_output or state.should_json():
        print_json(r.json())
        return
    print_success(f"Thread [bold]{thread_id}[/bold] status → [bold]{status}[/bold]")


@app.command("assign")
def threads_assign(
    ctx: typer.Context,
    thread_id: str = typer.Argument(..., help="Thread ID."),
    to: Optional[str] = typer.Option(None, "--to", help="User email or ID to assign to. Omit to unassign."),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Assign a thread to a user. PATCH /v1/threads/{threadId}."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.patch(f"/v1/threads/{thread_id}", json={"assignedTo": to})
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    if json_output or state.should_json():
        print_json(r.json())
        return
    if to:
        print_success(f"Thread [bold]{thread_id}[/bold] assigned to [bold]{to}[/bold].")
    else:
        print_success(f"Thread [bold]{thread_id}[/bold] unassigned.")


# ── tags subcommands ───────────────────────────────────────────────────────


@tags_app.command("add")
def tags_add(
    ctx: typer.Context,
    thread_id: str = typer.Argument(..., help="Thread ID."),
    tags: List[str] = typer.Argument(..., help="Tags to add (space-separated)."),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Add tags to a thread. POST /v1/threads/{threadId}/tags."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.post(f"/v1/threads/{thread_id}/tags", json={"tags": tags})
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    if json_output or state.should_json():
        print_json(r.json())
        return
    print_success(f"Tags added to thread [bold]{thread_id}[/bold]: {', '.join(tags)}")


@tags_app.command("remove")
def tags_remove(
    ctx: typer.Context,
    thread_id: str = typer.Argument(..., help="Thread ID."),
    tags: List[str] = typer.Argument(..., help="Tags to remove (space-separated)."),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Remove tags from a thread. POST /v1/threads/{threadId}/tags/remove."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.post(f"/v1/threads/{thread_id}/tags/remove", json={"tags": tags})
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    if json_output or state.should_json():
        print_json(r.json())
        return
    print_success(f"Tags removed from thread [bold]{thread_id}[/bold]: {', '.join(tags)}")
