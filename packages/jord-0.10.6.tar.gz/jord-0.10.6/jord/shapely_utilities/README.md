# jord/shapely_utilities

intersection can be accessed with and, &

union can be accessed with or, |

difference can be accessed with minus, -

symmetric_difference can be accessed with xor, ^
