# jord/geometric_analysis

## Vector Geometry Representation

Variations:

- POINT(0 0)
- POINT EMPTY
- LINESTRING(0 0, 0 1, 1 2)
- LINESTRING EMPTY
- POLYGON((0 0, 1 0, 1 1, 0 1, 0 0))
- POLYGON((0 0, 4 0, 4 4, 0 4, 0 0), (1 1, 1 2, 2 2, 2 1, 1 1))
- POLYGON EMPTY
- MULTIPOINT(0 0, 1 1)
- GEOMETRYCOLLECTION(MULTIPOINT(0 0, 1 1), POINT(3 4), LINESTRING(2 3, 3 4))
