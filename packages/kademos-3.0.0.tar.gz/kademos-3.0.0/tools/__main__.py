"""Allow running as python -m tools."""
from tools.cli import main
import sys
sys.exit(main())
