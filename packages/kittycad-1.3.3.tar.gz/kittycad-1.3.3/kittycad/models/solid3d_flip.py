from .base import KittyCadBaseModel


class Solid3dFlip(KittyCadBaseModel):
    """The response from the `Solid3dFlip` command."""
