from .base import KittyCadBaseModel


class Solid3dCutEdges(KittyCadBaseModel):
    """The response from the `Solid3dCutEdges` endpoint."""
