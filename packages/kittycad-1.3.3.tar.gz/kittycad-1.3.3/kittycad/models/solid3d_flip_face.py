from .base import KittyCadBaseModel


class Solid3dFlipFace(KittyCadBaseModel):
    """The response from the `Solid3dFlipFace` command."""
