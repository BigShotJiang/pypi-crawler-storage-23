from .base import KittyCadBaseModel


class ObjectBringToFront(KittyCadBaseModel):
    """The response from the `ObjectBringToFront` endpoint."""
