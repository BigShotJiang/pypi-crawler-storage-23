from .base import KittyCadBaseModel


class SetOrderIndependentTransparency(KittyCadBaseModel):
    """The response from the 'SetOrderIndependentTransparency'."""

    enabled: bool
