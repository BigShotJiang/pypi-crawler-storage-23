from .base import KittyCadBaseModel


class SetSelectionFilter(KittyCadBaseModel):
    """The response from the `SetSelectionFilter` endpoint."""
