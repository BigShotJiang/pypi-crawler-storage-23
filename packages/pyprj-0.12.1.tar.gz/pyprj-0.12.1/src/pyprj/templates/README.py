README_MD: str = r"""# {{pkg_name}}

[![PyPI - Version](https://img.shields.io/pypi/v/{{pkg_name}}.svg)](https://pypi.org/project/{{pkg_name}})
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/{{pkg_name}}.svg)](https://pypi.org/project/{{pkg_name}})

Description of the package.

## Installation

```sh
pip install {{pkg_name}}
```

## License

`{{pkg_name}}` is distributed under the terms of the
[MIT](https://spdx.org/licenses/MIT.html) license.
"""
