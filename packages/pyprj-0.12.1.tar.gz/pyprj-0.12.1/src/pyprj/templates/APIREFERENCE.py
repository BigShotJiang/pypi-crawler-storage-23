APIREFRENCE: str = r"""# API Reference

```{eval-rst}
.. automodule:: {{pkg_name}}
   :members:
   :undoc-members:
   :show-inheritance:
```"""
