import pkl


def test_trace():
    _ = pkl.load("tests/trace.pkl")


if __name__ == "__main__":
    test_trace()
