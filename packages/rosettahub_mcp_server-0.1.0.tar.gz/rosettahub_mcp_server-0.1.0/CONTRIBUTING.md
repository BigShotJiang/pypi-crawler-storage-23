# Contributing

Thanks for your interest in contributing to `rosettahub-mcp-server`!

## Development Setup

```bash
git clone https://github.com/danielcregg/rosettahub-mcp-server.git
cd rosettahub-mcp-server
pip install -e ".[dev]"
```

## Running Tests

```bash
pytest
```

All tests use mocked SOAP responses — **no RosettaHUB API key needed**.

### With coverage

```bash
pytest --cov=rosettahub_mcp_server --cov-report=term-missing
```

## Code Quality

```bash
# Lint
ruff check src/ tests/

# Format
ruff format src/ tests/

# Type check
mypy src/ --ignore-missing-imports
```

All three must pass before merging. The CI workflow checks these automatically.

## Project Structure

```
src/rosettahub_mcp_server/
├── server.py        # FastMCP instance, singletons, entry point
├── config.py        # Env var loading (Config dataclass)
├── client.py        # RosettaHubClient — zeep SOAP wrapper
├── types.py         # TypedDict return types for tools
├── tools/           # Tool implementations (one file per category)
└── resources/       # MCP resource implementations
tests/
├── conftest.py      # Shared fixtures and mock factories
└── test_*.py        # Test files matching source modules
```

## Adding a New Tool

1. Add the tool function in the appropriate `src/.../tools/*.py` module
2. Add a return TypedDict to `types.py` if the tool returns structured data
3. Add a wrapper method to `client.py` if it calls a new SOAP method
4. Add tests in the matching `tests/test_*_tools.py` file
5. Update the tool table in `README.md`
6. Update `CHANGELOG.md`

## Conventions

- Tools return TypedDicts, not strings — structured data is friendlier for AI assistants
- Use `server.get_client()` (via module reference) in tools, not direct imports
- Raise exceptions instead of calling `sys.exit()` — FastMCP handles error responses
- All SOAP responses are mocked with `SimpleNamespace` objects in tests
- Log to stderr only — stdout is reserved for MCP JSON-RPC transport

## Submitting Changes

1. Fork the repo and create a branch from `main`
2. Make your changes
3. Run `pytest` and `ruff check src/ tests/` — both must pass
4. Submit a pull request with a clear description

## Reporting Issues

Open an issue with:
- What you expected to happen
- What actually happened
- Steps to reproduce
- Python version and OS
