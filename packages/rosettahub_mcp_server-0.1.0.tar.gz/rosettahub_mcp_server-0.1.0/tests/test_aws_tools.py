"""Tests for AWS execution and credential tools."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from rosettahub_mcp_server.tools.aws_tools import (
    _validate_aws_command,
    _validate_region,
    aws_exec,
    aws_exec_user,
    ec2_list,
    get_console_url,
    get_sts_credentials,
)
from tests.conftest import make_sts_session, make_student_account


class TestValidateRegion:
    def test_valid_region(self):
        assert _validate_region("eu-west-1") == "eu-west-1"
        assert _validate_region("us-east-1") == "us-east-1"
        assert _validate_region("ap-southeast-2") == "ap-southeast-2"

    def test_rejects_flag_injection(self):
        with pytest.raises(ValueError, match="Invalid AWS region"):
            _validate_region("eu-west-1 --endpoint-url http://evil.com")

    def test_rejects_empty(self):
        with pytest.raises(ValueError, match="Invalid AWS region"):
            _validate_region("")

    def test_rejects_arbitrary_text(self):
        with pytest.raises(ValueError, match="Invalid AWS region"):
            _validate_region("not-a-region")


class TestValidateAwsCommand:
    def test_valid_command(self):
        assert _validate_aws_command("aws s3 ls") == "aws s3 ls"

    def test_strips_whitespace(self):
        assert _validate_aws_command("  aws s3 ls  ") == "aws s3 ls"

    def test_rejects_non_aws(self):
        with pytest.raises(ValueError, match="must start with 'aws '"):
            _validate_aws_command("rm -rf /")

    def test_rejects_empty(self):
        with pytest.raises(ValueError, match="must start with 'aws '"):
            _validate_aws_command("")

    def test_rejects_aws_prefix_only(self):
        with pytest.raises(ValueError, match="must start with 'aws '"):
            _validate_aws_command("awssomething")


class TestAwsExecUser:
    @patch("rosettahub_mcp_server.tools.aws_tools.subprocess.run")
    def test_runs_command(self, mock_run, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice"),
        ]
        mock_service.suGetStsSession.return_value = make_sts_session()
        mock_run.return_value = MagicMock(stdout="output-data\n", stderr="", returncode=0)

        result = aws_exec_user("alice", "aws s3 ls")
        assert result["login"] == "alice"
        assert result["stdout"] == "output-data"
        assert result["return_code"] == 0

    @patch("rosettahub_mcp_server.tools.aws_tools.subprocess.run")
    def test_rejects_non_aws(self, mock_run, mock_get_client, mock_service):
        with pytest.raises(ValueError, match="must start with 'aws '"):
            aws_exec_user("alice", "curl http://evil.com")
        mock_run.assert_not_called()


class TestAwsExec:
    @patch("rosettahub_mcp_server.tools.aws_tools.subprocess.run")
    def test_runs_on_all(self, mock_run, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice"),
            make_student_account(login="bob"),
        ]
        mock_service.suGetStsSession.return_value = make_sts_session()
        mock_run.return_value = MagicMock(stdout="ok\n", stderr="", returncode=0)

        result = aws_exec("aws s3 ls")
        assert result["total_accounts"] == 2
        assert len(result["results"]) == 2
        assert result["results"][0]["login"] == "alice"
        assert result["results"][1]["login"] == "bob"

    @patch("rosettahub_mcp_server.tools.aws_tools.subprocess.run")
    def test_captures_per_account_errors(self, mock_run, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice"),
            make_student_account(login="bob"),
        ]
        mock_service.suGetStsSession.side_effect = [
            make_sts_session(),
            OSError("STS failed"),
        ]
        mock_run.return_value = MagicMock(stdout="ok\n", stderr="", returncode=0)

        result = aws_exec("aws s3 ls")
        assert len(result["results"]) == 2
        assert result["results"][0]["return_code"] == 0
        assert result["results"][1]["return_code"] == -1
        assert "STS failed" in result["results"][1]["stderr"]

    @patch("rosettahub_mcp_server.tools.aws_tools.subprocess.run")
    def test_empty_accounts(self, mock_run, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = []

        result = aws_exec("aws s3 ls")
        assert result["total_accounts"] == 0
        assert result["results"] == []
        mock_run.assert_not_called()


class TestGetStsCredentials:
    def test_returns_credentials(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice", cloudAccountUid="uid-alice"),
        ]
        mock_service.suGetStsSession.return_value = make_sts_session()

        result = get_sts_credentials("alice")
        assert result["login"] == "alice"
        assert result["access_key_id"] == "AKIAIOSFODNN7EXAMPLE"
        assert result["region"] == "eu-west-1"


class TestGetConsoleUrl:
    def test_returns_url(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice"),
        ]
        mock_service.suGetStsSession.return_value = make_sts_session(
            consoleUrl="https://console.aws.amazon.com/test"
        )

        result = get_console_url("alice")
        assert result["login"] == "alice"
        assert "console.aws.amazon.com" in result["url"]


class TestEc2List:
    @patch("rosettahub_mcp_server.tools.aws_tools.subprocess.run")
    def test_returns_instances(self, mock_run, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice"),
        ]
        mock_service.suGetStsSession.return_value = make_sts_session()
        ec2_json = json.dumps([[["i-abc123", "t2.micro", "running", "2026-01-01T00:00:00Z"]]])
        mock_run.return_value = MagicMock(stdout=ec2_json, stderr="", returncode=0)

        result = ec2_list()
        assert len(result) == 1
        assert result[0]["login"] == "alice"
        assert result[0]["instance_id"] == "i-abc123"
        assert result[0]["instance_type"] == "t2.micro"
        assert result[0]["state"] == "running"

    @patch("rosettahub_mcp_server.tools.aws_tools.subprocess.run")
    def test_empty_when_no_instances(self, mock_run, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice"),
        ]
        mock_service.suGetStsSession.return_value = make_sts_session()
        mock_run.return_value = MagicMock(stdout="[]", stderr="", returncode=0)

        result = ec2_list()
        assert result == []

    @patch("rosettahub_mcp_server.tools.aws_tools.subprocess.run")
    def test_uses_custom_region(self, mock_run, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice"),
        ]
        mock_service.suGetStsSession.return_value = make_sts_session()
        mock_run.return_value = MagicMock(stdout="[]", stderr="", returncode=0)

        ec2_list(region="us-east-1")
        # Verify the region was passed through to the command
        call_args = mock_run.call_args
        assert "us-east-1" in " ".join(call_args[0][0])

    @patch("rosettahub_mcp_server.tools.aws_tools.subprocess.run")
    def test_skips_failed_accounts(self, mock_run, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice"),
            make_student_account(login="bob"),
        ]
        mock_service.suGetStsSession.side_effect = [
            make_sts_session(),
            OSError("STS error"),
        ]
        ec2_json = json.dumps([[["i-abc123", "t2.micro", "running", "2026-01-01T00:00:00Z"]]])
        mock_run.return_value = MagicMock(stdout=ec2_json, stderr="", returncode=0)

        result = ec2_list()
        assert len(result) == 1
        assert result[0]["login"] == "alice"

    @patch("rosettahub_mcp_server.tools.aws_tools.subprocess.run")
    def test_handles_command_failure(self, mock_run, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice"),
        ]
        mock_service.suGetStsSession.return_value = make_sts_session()
        mock_run.return_value = MagicMock(stdout="", stderr="error", returncode=1)

        result = ec2_list()
        assert result == []
