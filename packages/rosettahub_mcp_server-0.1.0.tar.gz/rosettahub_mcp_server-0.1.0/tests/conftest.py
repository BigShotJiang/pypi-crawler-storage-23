"""Shared test fixtures — mock zeep responses using SimpleNamespace."""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from rosettahub_mcp_server.client import RosettaHubClient
from rosettahub_mcp_server.config import Config


@pytest.fixture
def config():
    """Test configuration (no real API calls)."""
    return Config(
        api_key="test-api-key",
        org_name="Test-Org",
        aws_region="eu-west-1",
        wsdl_url="https://api.rosettahub.com/public/PlatformServices?wsdl",
    )


@pytest.fixture
def mock_service():
    """A MagicMock standing in for the zeep service proxy."""
    return MagicMock()


@pytest.fixture
def client(config, mock_service):
    """A RosettaHubClient with a pre-injected mock service."""
    c = RosettaHubClient(config)
    c._service = mock_service
    return c


@pytest.fixture
def mock_get_client(client):
    """Patch server.get_client to return our mock client."""
    with patch("rosettahub_mcp_server.server.get_client", return_value=client):
        yield client


# ── Reusable zeep-style response objects ──────────────────────────


def make_user_info(**overrides):
    """Create a mock getUserInfo response."""
    defaults = dict(
        firstname="Daniel",
        lastname="Cregg",
        email="daniel.cregg@atu.ie",
        institutionId="ATU",
        regType="INSTRUCTOR",
        roles=["ADMIN", "INSTRUCTOR"],
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def make_cloud_account(**overrides):
    """Create a mock getBasicCloudAccounts item."""
    defaults = dict(
        login="student1",
        accountNumber="123456789012",
        cloudId="aws",
        cloudAccountUid="uid-student1",
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def make_student_account(**overrides):
    """Create a mock cpocGetFederatedCloudAccounts item."""
    defaults = dict(
        login="student1",
        cloudAccountUid="uid-student1",
        budget=50.0,
        aggregatedCost=10.0,
        amountLeft=40.0,
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def make_federated_user(**overrides):
    """Create a mock cpocGetFederatedUsers item."""
    defaults = dict(
        login="student1",
        enabled=True,
        email="student1@atu.ie",
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def make_sts_session(**overrides):
    """Create a mock suGetStsSession response."""
    defaults = dict(
        stsAccessKeyId="AKIAIOSFODNN7EXAMPLE",
        stsSecretAccessKey="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
        sessionToken="FwoGZXIvYXdzE...exampletoken",
        consoleUrl="https://signin.aws.amazon.com/federation?Action=login&...",
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)
