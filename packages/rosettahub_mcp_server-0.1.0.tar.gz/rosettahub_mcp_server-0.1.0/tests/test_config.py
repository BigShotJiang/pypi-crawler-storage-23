"""Tests for configuration loading."""

from __future__ import annotations

import os
from unittest.mock import patch

import pytest

from rosettahub_mcp_server.config import Config, ConfigError


class TestConfigFromEnv:
    def test_valid_config(self):
        env = {
            "RH_API_KEY": "my-key",
            "RH_ORG": "My-Org",
            "RH_AWS_REGION": "us-east-1",
        }
        with patch.dict(os.environ, env, clear=False):
            cfg = Config.from_env()
        assert cfg.api_key == "my-key"
        assert cfg.org_name == "My-Org"
        assert cfg.aws_region == "us-east-1"

    def test_defaults(self):
        env = {"RH_API_KEY": "my-key", "RH_ORG": "My-Org"}
        with patch.dict(os.environ, env, clear=False):
            cfg = Config.from_env()
        assert cfg.aws_region == "eu-west-1"
        assert "rosettahub.com" in cfg.wsdl_url

    def test_missing_api_key(self):
        env = {"RH_ORG": "My-Org"}
        with patch.dict(os.environ, env, clear=False):
            # Ensure RH_API_KEY is not set
            os.environ.pop("RH_API_KEY", None)
            with pytest.raises(ConfigError, match="RH_API_KEY"):
                Config.from_env()

    def test_missing_org(self):
        env = {"RH_API_KEY": "my-key"}
        with patch.dict(os.environ, env, clear=False):
            os.environ.pop("RH_ORG", None)
            with pytest.raises(ConfigError, match="RH_ORG"):
                Config.from_env()

    def test_wsdl_url_override(self):
        env = {
            "RH_API_KEY": "my-key",
            "RH_ORG": "My-Org",
            "RH_WSDL_URL": "https://custom.example.com/wsdl",
        }
        with patch.dict(os.environ, env, clear=False):
            cfg = Config.from_env()
        assert cfg.wsdl_url == "https://custom.example.com/wsdl"
