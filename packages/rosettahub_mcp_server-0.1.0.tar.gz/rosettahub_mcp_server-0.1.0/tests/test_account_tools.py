"""Tests for account information tools."""

from __future__ import annotations

from rosettahub_mcp_server.tools.account_tools import (
    list_accounts,
    list_api_methods,
    list_student_accounts,
    list_users,
)
from rosettahub_mcp_server.tools.account_tools import (
    test_connection as rh_test_connection,
)
from tests.conftest import (
    make_cloud_account,
    make_federated_user,
    make_student_account,
    make_user_info,
)


class TestTestConnection:
    def test_returns_user_info(self, mock_get_client, mock_service):
        mock_service.getUserInfo.return_value = make_user_info()
        result = rh_test_connection()
        assert result["firstname"] == "Daniel"
        assert result["email"] == "daniel.cregg@atu.ie"
        assert "ADMIN" in result["roles"]


class TestListAccounts:
    def test_returns_accounts(self, mock_get_client, mock_service):
        mock_service.getBasicCloudAccounts.return_value = [
            make_cloud_account(login="acc1"),
            make_cloud_account(login="acc2"),
        ]
        result = list_accounts()
        assert len(result) == 2
        assert result[0]["login"] == "acc1"

    def test_empty(self, mock_get_client, mock_service):
        mock_service.getBasicCloudAccounts.return_value = []
        assert list_accounts() == []

    def test_none_response(self, mock_get_client, mock_service):
        mock_service.getBasicCloudAccounts.return_value = None
        assert list_accounts() == []


class TestListStudentAccounts:
    def test_returns_student_data(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = [
            make_student_account(login="alice", budget=100, aggregatedCost=30, amountLeft=70),
        ]
        result = list_student_accounts()
        assert len(result) == 1
        assert result[0]["login"] == "alice"
        assert result[0]["budget"] == 100.0
        assert result[0]["cost"] == 30.0
        assert result[0]["remaining"] == 70.0


class TestListUsers:
    def test_returns_users(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedUsers.return_value = [
            make_federated_user(login="alice", enabled=True),
            make_federated_user(login="bob", enabled=False),
        ]
        result = list_users()
        assert len(result) == 2
        assert result[0]["login"] == "alice"
        assert result[0]["enabled"] is True
        assert result[1]["enabled"] is False

    def test_empty(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedUsers.return_value = []
        assert list_users() == []

    def test_none_response(self, mock_get_client, mock_service):
        mock_service.cpocGetFederatedUsers.return_value = None
        assert list_users() == []


class TestListApiMethods:
    def test_returns_methods(self, mock_get_client, client):
        client._zeep_client = client._service
        operations = {
            "getUserInfo": None,
            "cpocGetFederatedUsers": None,
        }
        mock_binding = type("B", (), {"_operations": operations})()
        mock_port = type("P", (), {"binding": mock_binding})()
        mock_svc = type("S", (), {"ports": {"p0": mock_port}})()
        client._service.wsdl = type("W", (), {"services": {"s0": mock_svc}})()

        result = list_api_methods()
        assert isinstance(result, list)
        assert "cpocGetFederatedUsers" in result
        assert "getUserInfo" in result

    def test_returns_sorted(self, mock_get_client, client):
        client._zeep_client = client._service
        operations = {"zMethod": None, "aMethod": None, "mMethod": None}
        mock_binding = type("B", (), {"_operations": operations})()
        mock_port = type("P", (), {"binding": mock_binding})()
        mock_svc = type("S", (), {"ports": {"p0": mock_port}})()
        client._service.wsdl = type("W", (), {"services": {"s0": mock_svc}})()

        result = list_api_methods()
        assert result == ["aMethod", "mMethod", "zMethod"]
