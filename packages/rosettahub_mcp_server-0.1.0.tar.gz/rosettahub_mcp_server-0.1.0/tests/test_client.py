"""Tests for the RosettaHubClient wrapper."""

from __future__ import annotations

import pytest

from tests.conftest import make_student_account


class TestFindAccountByLogin:
    def test_found(self, client, mock_service):
        acc1 = make_student_account(login="alice")
        acc2 = make_student_account(login="bob")
        mock_service.cpocGetFederatedCloudAccounts.return_value = [acc1, acc2]

        result = client.find_account_by_login("bob")
        assert result.login == "bob"

    def test_not_found(self, client, mock_service):
        acc1 = make_student_account(login="alice")
        mock_service.cpocGetFederatedCloudAccounts.return_value = [acc1]

        with pytest.raises(ValueError, match="No cloud account found for 'nobody'"):
            client.find_account_by_login("nobody")

    def test_empty_accounts(self, client, mock_service):
        mock_service.cpocGetFederatedCloudAccounts.return_value = []

        with pytest.raises(ValueError, match="No cloud account found"):
            client.find_account_by_login("alice")


class TestClientMethods:
    def test_get_user_info(self, client, mock_service):
        mock_service.getUserInfo.return_value = "info"
        assert client.get_user_info() == "info"
        mock_service.getUserInfo.assert_called_once_with("test-api-key")

    def test_get_sts_session(self, client, mock_service):
        mock_service.suGetStsSession.return_value = "sts"
        assert client.get_sts_session("uid-123", 7200) == "sts"
        mock_service.suGetStsSession.assert_called_once_with("test-api-key", "uid-123", 7200)

    def test_transfer_budget(self, client, mock_service):
        client.transfer_budget(["uid-1", "uid-2"], 10.0)
        mock_service.cpocTransferBudget.assert_called_once_with(
            "test-api-key", ["uid-1", "uid-2"], 10.0, False, None
        )

    def test_quarantine_users(self, client, mock_service):
        client.quarantine_users(["uid-1"])
        mock_service.cpocQuarantineUsers.assert_called_once_with(
            "test-api-key", ["uid-1"], False, None
        )

    def test_unquarantine_users(self, client, mock_service):
        client.unquarantine_users(["uid-1"])
        mock_service.cpocUnquarantineUsers.assert_called_once_with(
            "test-api-key", ["uid-1"], False, None
        )

    def test_set_allowed_regions(self, client, mock_service):
        client.set_allowed_regions(["alice"], "aws", ["eu-west-1"])
        mock_service.cpocSetAllowedRegions.assert_called_once_with(
            "test-api-key", ["alice"], "aws", ["eu-west-1"], None
        )
