"""Configuration loading and validation from environment variables."""

from __future__ import annotations

import os
from dataclasses import dataclass


class ConfigError(Exception):
    """Raised when required configuration is missing."""


@dataclass(frozen=True)
class Config:
    """RosettaHUB API configuration loaded from environment variables."""

    api_key: str
    org_name: str
    aws_region: str
    wsdl_url: str

    @classmethod
    def from_env(cls) -> Config:
        """Load configuration from environment variables.

        Required:
            RH_API_KEY: RosettaHUB API key
            RH_ORG: Organization name

        Optional:
            RH_AWS_REGION: Default AWS region (default: eu-west-1)
            RH_WSDL_URL: WSDL endpoint (default: RosettaHUB public API)
        """
        api_key = os.environ.get("RH_API_KEY", "")
        if not api_key:
            raise ConfigError(
                "RH_API_KEY environment variable is required. Set it to your RosettaHUB API key."
            )

        org_name = os.environ.get("RH_ORG", "")
        if not org_name:
            raise ConfigError(
                "RH_ORG environment variable is required. "
                "Set it to your RosettaHUB organization name."
            )

        return cls(
            api_key=api_key,
            org_name=org_name,
            aws_region=os.environ.get("RH_AWS_REGION", "eu-west-1"),
            wsdl_url=os.environ.get(
                "RH_WSDL_URL",
                "https://api.rosettahub.com/public/PlatformServices?wsdl",
            ),
        )
