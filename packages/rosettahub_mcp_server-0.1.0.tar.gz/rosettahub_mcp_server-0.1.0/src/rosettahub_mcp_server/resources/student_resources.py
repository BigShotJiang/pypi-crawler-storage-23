"""MCP resources for student data."""

from __future__ import annotations

import json

from rosettahub_mcp_server import server


@server.mcp.resource("rosettahub://students")
def student_list() -> str:
    """Current list of student logins in the organization."""
    client = server.get_client()
    accounts = client.get_federated_cloud_accounts()
    logins = [acc.login for acc in (accounts or [])]
    return json.dumps(logins, indent=2)


@server.mcp.resource("rosettahub://budget-summary")
def budget_summary() -> str:
    """Current budget summary for all students."""
    client = server.get_client()
    accounts = client.get_federated_cloud_accounts()

    summary = []
    for acc in accounts or []:
        budget = float(getattr(acc, "budget", 0) or 0)
        cost = float(getattr(acc, "aggregatedCost", 0) or 0)
        remaining = float(getattr(acc, "amountLeft", 0) or 0)
        summary.append(
            {
                "login": acc.login,
                "budget": budget,
                "spent": cost,
                "remaining": remaining,
            }
        )

    return json.dumps(summary, indent=2)
