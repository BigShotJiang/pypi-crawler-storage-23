"""Account and API information tools."""

from __future__ import annotations

from rosettahub_mcp_server import server
from rosettahub_mcp_server.types import (
    CloudAccount,
    FederatedUser,
    StudentAccount,
    UserInfo,
)


@server.mcp.tool()
def test_connection() -> UserInfo:
    """Test the RosettaHUB API connection and return authenticated user info."""
    client = server.get_client()
    info = client.get_user_info()
    return UserInfo(
        firstname=info.firstname,
        lastname=info.lastname,
        email=info.email,
        institution_id=info.institutionId,
        reg_type=info.regType,
        roles=list(info.roles),
    )


@server.mcp.tool()
def list_accounts() -> list[CloudAccount]:
    """List your own RosettaHUB cloud accounts."""
    client = server.get_client()
    accounts = client.get_basic_cloud_accounts()
    return [
        CloudAccount(
            login=acc.login,
            account_number=acc.accountNumber,
            cloud_id=acc.cloudId,
            cloud_account_uid=acc.cloudAccountUid,
        )
        for acc in (accounts or [])
    ]


@server.mcp.tool()
def list_student_accounts() -> list[StudentAccount]:
    """List all student (federated) cloud accounts with budget information."""
    client = server.get_client()
    accounts = client.get_federated_cloud_accounts()
    return [
        StudentAccount(
            login=acc.login,
            cloud_account_uid=acc.cloudAccountUid,
            budget=float(getattr(acc, "budget", 0) or 0),
            cost=float(getattr(acc, "aggregatedCost", 0) or 0),
            remaining=float(getattr(acc, "amountLeft", 0) or 0),
        )
        for acc in (accounts or [])
    ]


@server.mcp.tool()
def list_users() -> list[FederatedUser]:
    """List all federated users in the organization."""
    client = server.get_client()
    users = client.get_federated_users()
    return [
        FederatedUser(
            login=getattr(user, "login", "N/A"),
            enabled=bool(getattr(user, "enabled", False)),
            email=getattr(user, "email", "N/A"),
        )
        for user in (users or [])
    ]


@server.mcp.tool()
def list_api_methods() -> list[str]:
    """List all available RosettaHUB SOAP API method names."""
    client = server.get_client()
    return client.list_api_methods()
