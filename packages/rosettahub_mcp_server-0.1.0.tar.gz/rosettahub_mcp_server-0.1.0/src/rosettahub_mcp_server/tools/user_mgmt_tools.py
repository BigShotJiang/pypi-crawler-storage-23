"""User management tools — quarantine, unquarantine, region control."""

from __future__ import annotations

from rosettahub_mcp_server import server
from rosettahub_mcp_server.types import QuarantineResult, RegionsResult


@server.mcp.tool()
def quarantine_user(login: str) -> QuarantineResult:
    """Quarantine a student, restricting their cloud access.

    This is useful for preventing further AWS spending or restricting a student
    who has violated usage policies.

    Args:
        login: Student login identifier to quarantine
    """
    client = server.get_client()
    acc = client.find_account_by_login(login)
    client.quarantine_users([acc.cloudAccountUid])
    return QuarantineResult(login=login, action="quarantined")


@server.mcp.tool()
def unquarantine_user(login: str) -> QuarantineResult:
    """Unquarantine a student, restoring their cloud access.

    Args:
        login: Student login identifier to unquarantine
    """
    client = server.get_client()
    acc = client.find_account_by_login(login)
    client.unquarantine_users([acc.cloudAccountUid])
    return QuarantineResult(login=login, action="unquarantined")


@server.mcp.tool()
def set_allowed_regions(login: str, regions: str) -> RegionsResult:
    """Set the allowed AWS regions for a student.

    Restricts which AWS regions the student can create resources in.

    Args:
        login: Student login identifier
        regions: Comma-separated list of AWS regions (e.g., 'eu-west-1,eu-west-2')
    """
    region_list = [r.strip() for r in regions.split(",") if r.strip()]
    if not region_list:
        raise ValueError("At least one region must be specified")

    client = server.get_client()
    # Verify the login exists
    client.find_account_by_login(login)
    client.set_allowed_regions([login], "aws", region_list)
    return RegionsResult(login=login, regions=region_list)
