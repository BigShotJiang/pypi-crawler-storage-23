"""AWS execution and credential tools."""

from __future__ import annotations

import json
import logging
import os
import re
import shlex
import subprocess

import zeep.exceptions

from rosettahub_mcp_server import server
from rosettahub_mcp_server.types import (
    AwsExecAllResult,
    AwsExecResult,
    ConsoleUrl,
    Ec2Instance,
    StsCredentials,
)

logger = logging.getLogger(__name__)


_REGION_RE = re.compile(r"^[a-z]{2}(-[a-z]+-\d+)$")
_AWS_CMD_TIMEOUT = 60


def _validate_aws_command(command: str) -> str:
    """Validate that a command starts with 'aws ' to prevent arbitrary execution.

    Returns the validated command string.
    Raises ValueError if the command is invalid.
    """
    stripped = command.strip()
    if not stripped.startswith("aws "):
        raise ValueError(f"Command must start with 'aws '. Got: {stripped[:50]!r}")
    return stripped


def _validate_region(region: str) -> str:
    """Validate an AWS region name to prevent flag injection.

    Raises ValueError if the region format is invalid.
    """
    if not _REGION_RE.match(region):
        raise ValueError(f"Invalid AWS region format: {region!r}")
    return region


def _run_aws_command(sts: object, command: str, region: str | None = None) -> AwsExecResult:
    """Run an AWS CLI command with STS credentials.

    Uses shell=False with shlex.split for security.
    Subprocess environment is minimal (only AWS credentials + PATH).
    """
    env = {
        "PATH": os.environ.get("PATH", ""),
        "AWS_ACCESS_KEY_ID": sts.stsAccessKeyId,  # type: ignore[attr-defined]
        "AWS_SECRET_ACCESS_KEY": sts.stsSecretAccessKey,  # type: ignore[attr-defined]
        "AWS_SESSION_TOKEN": sts.sessionToken,  # type: ignore[attr-defined]
    }
    if region:
        env["AWS_DEFAULT_REGION"] = region

    args = shlex.split(command)
    result = subprocess.run(  # noqa: S603
        args, capture_output=True, text=True, env=env, timeout=_AWS_CMD_TIMEOUT
    )

    return AwsExecResult(
        login="",  # caller fills this in
        stdout=result.stdout.strip(),
        stderr=result.stderr.strip(),
        return_code=result.returncode,
    )


@server.mcp.tool()
def aws_exec(command: str) -> AwsExecAllResult:
    """Execute an AWS CLI command on ALL student accounts.

    The command must start with 'aws ' (e.g., 'aws ec2 describe-instances --region eu-west-1').
    Runs sequentially across all student accounts with temporary STS credentials.

    Args:
        command: AWS CLI command to execute (must start with 'aws ')
    """
    validated = _validate_aws_command(command)
    client = server.get_client()
    accounts = client.get_federated_cloud_accounts()
    results: list[AwsExecResult] = []

    for acc in accounts or []:
        login = acc.login
        try:
            sts = client.get_sts_session(acc.cloudAccountUid)
            result = _run_aws_command(sts, validated, client.aws_region)
            result["login"] = login
            results.append(result)
        except (OSError, ValueError, subprocess.TimeoutExpired, zeep.exceptions.Fault) as e:
            results.append(AwsExecResult(login=login, stdout="", stderr=str(e), return_code=-1))

    return AwsExecAllResult(
        command=validated,
        total_accounts=len(accounts or []),
        results=results,
    )


@server.mcp.tool()
def aws_exec_user(login: str, command: str) -> AwsExecResult:
    """Execute an AWS CLI command on ONE student's account.

    The command must start with 'aws ' (e.g., 'aws s3 ls').

    Args:
        login: Student login identifier
        command: AWS CLI command to execute (must start with 'aws ')
    """
    validated = _validate_aws_command(command)
    client = server.get_client()
    acc = client.find_account_by_login(login)
    sts = client.get_sts_session(acc.cloudAccountUid)
    result = _run_aws_command(sts, validated, client.aws_region)
    result["login"] = login
    return result


@server.mcp.tool()
def ec2_list(region: str | None = None) -> list[Ec2Instance]:
    """List EC2 instances across all student accounts.

    Args:
        region: AWS region to query (default: configured region, typically eu-west-1)
    """
    client = server.get_client()
    target_region = _validate_region(region or client.aws_region)
    accounts = client.get_federated_cloud_accounts()
    command = (
        f"aws ec2 describe-instances --region {target_region} "
        '--query "Reservations[*].Instances[*].'
        '[InstanceId,InstanceType,State.Name,LaunchTime]" --output json'
    )

    instances: list[Ec2Instance] = []
    for acc in accounts or []:
        login = acc.login
        try:
            sts = client.get_sts_session(acc.cloudAccountUid)
            result = _run_aws_command(sts, command, target_region)
            if result["stdout"] and result["return_code"] == 0:
                data = json.loads(result["stdout"])
                for reservation in data:
                    for inst in reservation:
                        instances.append(
                            Ec2Instance(
                                login=login,
                                instance_id=inst[0],
                                instance_type=inst[1],
                                state=inst[2],
                                launch_time=inst[3],
                            )
                        )
        except (
            OSError,
            ValueError,
            json.JSONDecodeError,
            subprocess.TimeoutExpired,
            zeep.exceptions.Fault,
        ) as e:
            logger.warning("Error listing EC2 for %s: %s", login, e)

    return instances


@server.mcp.tool()
def get_sts_credentials(login: str) -> StsCredentials:
    """Get temporary AWS STS credentials for a student's account.

    Returns credentials that can be used to access the student's AWS account directly.

    Args:
        login: Student login identifier
    """
    client = server.get_client()
    acc = client.find_account_by_login(login)
    sts = client.get_sts_session(acc.cloudAccountUid)
    return StsCredentials(
        login=login,
        cloud_account_uid=acc.cloudAccountUid,
        access_key_id=sts.stsAccessKeyId,
        secret_access_key=sts.stsSecretAccessKey,
        session_token=sts.sessionToken,
        region=client.aws_region,
    )


@server.mcp.tool()
def get_console_url(login: str) -> ConsoleUrl:
    """Get an AWS Console sign-in URL for a student's account.

    Returns a temporary URL that provides browser access to the student's AWS Console.

    Args:
        login: Student login identifier
    """
    client = server.get_client()
    acc = client.find_account_by_login(login)
    sts = client.get_sts_session(acc.cloudAccountUid)
    return ConsoleUrl(login=login, url=sts.consoleUrl)
