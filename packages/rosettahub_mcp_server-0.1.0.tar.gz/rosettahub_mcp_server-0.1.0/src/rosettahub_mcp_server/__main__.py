"""Allow running as: python -m rosettahub_mcp_server"""

from __future__ import annotations

from rosettahub_mcp_server.server import main

main()
