"""RosettaHUB MCP Server — manage student AWS cloud accounts via MCP protocol."""

__version__ = "0.1.0"
