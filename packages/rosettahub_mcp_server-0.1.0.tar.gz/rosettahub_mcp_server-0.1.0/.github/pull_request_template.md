## Summary

<!-- What does this PR do? -->

## Changes

-

## Testing

- [ ] Tests pass (`pytest`)
- [ ] Lint passes (`ruff check src/ tests/`)
- [ ] Format passes (`ruff format --check src/ tests/`)
- [ ] New tests added for new functionality (if applicable)
