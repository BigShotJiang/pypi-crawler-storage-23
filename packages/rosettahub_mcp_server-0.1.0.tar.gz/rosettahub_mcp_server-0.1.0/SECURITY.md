# Security Policy

## Supported Versions

| Version | Supported          |
|---------|-------------------|
| 0.1.x   | Yes               |

## Reporting a Vulnerability

If you discover a security vulnerability, please report it responsibly:

1. **Do not** open a public GitHub issue
2. Email **daniel.cregg@atu.ie** with details
3. Include steps to reproduce if possible

You can expect an initial response within 48 hours.

## Security Design

This server handles AWS credentials and runs CLI commands. Key security measures:

- **Command validation**: All commands passed to `aws_exec` and `aws_exec_user` must start with `aws ` — arbitrary command execution is rejected
- **Region validation**: Region parameters are validated against AWS naming format to prevent flag injection
- **No shell injection**: Subprocess calls use `shell=False` with `shlex.split()`
- **Subprocess timeout**: AWS CLI calls are capped at 60 seconds to prevent indefinite hangs
- **Minimal subprocess environment**: Child processes receive only AWS credentials and PATH, not the full host environment
- **Temporary credentials**: AWS access uses short-lived STS sessions (1 hour default), never long-term keys
- **Stdout isolation**: Logging goes to stderr only — stdout is reserved for MCP JSON-RPC transport
- **No credential storage**: API keys and credentials are read from environment variables at runtime, never persisted to disk

**Note**: The `get_sts_credentials` tool intentionally returns temporary AWS credentials over MCP transport. This is by design — it allows AI assistants to provide users with direct AWS access. The credentials are short-lived STS sessions, not long-term keys.
