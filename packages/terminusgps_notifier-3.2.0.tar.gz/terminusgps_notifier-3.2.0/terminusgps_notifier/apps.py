from django.apps import AppConfig


class TerminusgpsNotifierConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "terminusgps_notifier"
    verbose_name = "Terminus GPS Notifier"
