from pydantic_settings import BaseSettings


class BaseServiceConfig(BaseSettings):
    """Base configuration shared across all T-Cinema microservices."""

    service_name: str
    debug: bool = False
    log_level: str = "INFO"

    model_config = {"env_file": ".env", "extra": "ignore"}
