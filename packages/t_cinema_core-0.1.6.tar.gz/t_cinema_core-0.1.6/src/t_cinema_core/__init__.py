__version__ = "0.1.6"

from t_cinema_core.config import BaseServiceConfig

__all__ = ["BaseServiceConfig", "__version__"]
