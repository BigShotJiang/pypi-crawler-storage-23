#!/usr/bin/env python3

import argparse
import json
from pathlib import Path
from sys import stderr
from urllib.parse import quote_plus
from webbrowser import open_new_tab

# Load defaults from package data
defaults = json.load((Path(__file__).parent / "defaults.json").open())
# Change to prod if needed to access those resources
ENV = "dev"


def _cli_find_support_entity(uuid):  # pragma: no cover
    """Find a support entity (is_support + is_image descendant) for the given UUID.

    Mirrors the query in client.py's get_descendant_to_lift().
    """
    import requests as req

    query = {
        "query": {
            "bool": {
                "must": [
                    {"term": {"vitessce-hints": "is_support"}},
                    {"term": {"vitessce-hints": "is_image"}},
                    {"term": {"ancestor_ids": uuid}},
                    {"terms": {"mapped_status.keyword": ["QA", "Published"]}},
                ]
            }
        },
        "sort": [{"last_modified_timestamp": {"order": "desc"}}],
        "size": 1,
    }
    try:
        response = req.post(
            defaults[ENV]["elastic_search_api"],
            headers=headers if "headers" in globals() else {},
            json=query,
        )
        if response.status_code == 200:
            hits = response.json().get("hits", {}).get("hits", [])
            if hits:
                return hits[0]["_source"]
    except Exception as e:
        print(f"Warning: Could not find support entity for {uuid}: {e}", file=stderr)
    return None


def main():  # pragma: no cover
    """CLI entry point for vis-preview command.

    Note: This command requires the [full] install:
        pip install portal-visualization[full]
    """
    # Import heavy dependencies only when CLI is actually run
    try:
        from portal_visualization.builder_factory import get_view_config_builder
    except ImportError as e:
        print(
            "ERROR: The vis-preview CLI requires the [full] installation.\n"
            "Please install with: pip install portal-visualization[full]\n"
            f"Missing dependency: {e}",
            file=stderr,
        )
        return 1
    assets_default_url = defaults[ENV]["assets_url"]
    parser = argparse.ArgumentParser(
        description="""
        Given HuBMAP Dataset JSON, generate a Vitessce viewconf, and load vitessce.io."""
    )
    input = parser.add_mutually_exclusive_group(required=True)
    input.add_argument("--url", help="URL which returns Dataset JSON")
    input.add_argument("--json", type=Path, help="File containing Dataset JSON")

    parser.add_argument(
        "--assets_url",
        metavar="URL",
        help=f"Assets endpoint; default: {assets_default_url}",
        default=assets_default_url,
    )
    parser.add_argument("--token", help="Globus groups token; Only needed if data is not public", default="")
    parser.add_argument("--marker", help="Marker to highlight in visualization; Only used in some visualizations.")
    parser.add_argument("--to_json", action="store_true", help="Output viewconf, rather than open in browser.")
    parser.add_argument(
        "--parent_uuid",
        metavar="UUID",
        help="Parent uuid - Only needed for an image-pyramid support dataset.",
        default=None,
    )

    args = parser.parse_args()
    marker = args.marker
    parent_uuid = args.parent_uuid

    headers = get_headers(args.token)
    entity = get_entity_from_args(args.url, args.json, headers)
    # For testing client
    # from portal_visualization.client import ApiClient
    # client = ApiClient(
    #     groups_token= args.token,
    #     elasticsearch_endpoint=defaults[ENV]['elastic_search_api'],
    #     portal_index_path=defaults[ENV]['portal_index_path'],
    #     ubkg_endpoint=defaults[ENV]['ubkg_endpoint'],
    #     assets_endpoint=assets_default_url,
    #     soft_assay_endpoint=defaults[ENV]["soft_assay_endpoint"],
    #     entity_api_endpoint=defaults[ENV]["entity_api_endpoint"],
    # )

    # conf = client.get_vitessce_conf_cells_and_lifted_uuid(entity, None, True, parent_uuid, epic_uuid).vitessce_conf

    # Resolve parent entity if parent_uuid is provided
    parent = None
    if parent_uuid:
        parent = get_entity(parent_uuid)
        if parent is None:
            print(f"Warning: Could not fetch parent entity {parent_uuid}", file=stderr)
            parent = {"uuid": parent_uuid}

    Builder = get_view_config_builder(entity, get_entity, parent_uuid)
    builder = Builder(
        entity,
        args.token,
        args.assets_url,
        get_entity=get_entity,
        parent=parent or parent_uuid,
        find_support_entity=_cli_find_support_entity,
    )
    print(f"Using: {builder.__class__.__name__}", file=stderr)
    conf_cells = builder.get_conf_cells(marker=marker)

    conf_as_json = json.dumps(conf_cells.conf[0]) if isinstance(conf_cells.conf, list) else json.dumps(conf_cells.conf)

    if args.to_json:
        print(conf_as_json)

    # For testing
    # with open('conf.json', 'w') as file:
    #     if isinstance(conf_cells.conf, list):
    #         json.dump(conf_cells.conf[0], file, indent=4, separators=(',', ': '))
    #     else:
    #         json.dump(conf_cells.conf, file, indent=4, separators=(',', ': '))

    data_url = f"data:,{quote_plus(conf_as_json)}"
    vitessce_url = f"http://vitessce.io/#?url={data_url}"
    open_new_tab(vitessce_url)


def get_headers(token):  # pragma: no cover
    global headers
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def get_entity(uuid):  # pragma: no cover
    import requests

    try:
        response = requests.get(f"{defaults[ENV]['dataset_url']}{uuid}.json", headers=headers)
        if response.status_code != 200:
            print(f"Error: Received status code {response.status_code}")
        else:
            try:
                data = response.json()
                return data
            except Exception as e:
                print(f"Error in parsing the response {str(e)}")
    except Exception as e:
        print(f"Error accessing {defaults[ENV]['assaytypes_url']}{uuid}: {str(e)}")


def get_entity_from_args(url_arg, json_arg, headers):  # pragma: no cover
    if url_arg:
        import requests

        response = requests.get(url_arg, headers=headers)
        if response.status_code == 403:
            raise Exception("Protected data: Download JSON via browser; Redo with --json")
        response.raise_for_status()
        json_str = response.text
    else:
        json_str = json_arg.read_text()
    entity = json.loads(json_str)
    return entity


def debug_builder_selection():  # pragma: no cover
    """CLI entry point for debugging builder selection.

    This command helps diagnose why a particular builder was (or wasn't) selected.
    """
    parser = argparse.ArgumentParser(
        description="Debug builder selection for a dataset",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Check builder selection for a dataset
  python -m portal_visualization.cli debug --json dataset.json

  # Provide hints directly
  python -m portal_visualization.cli debug --hints is_image rna
        """,
    )

    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument("--json", type=Path, help="File containing Dataset JSON")
    input_group.add_argument("--url", help="URL which returns Dataset JSON")
    input_group.add_argument("--hints", nargs="+", help="Hints to test directly")

    parser.add_argument("--assay-type", help="Assay type to test")
    parser.add_argument("--parent-assay-type", help="Parent assay type to test")
    parser.add_argument("--has-parent", action="store_true", help="Simulate having a parent")
    parser.add_argument("--has-epic", action="store_true", help="Simulate having an EPIC UUID")
    parser.add_argument("--token", help="Globus groups token for protected datasets", default="")

    args = parser.parse_args()

    if args.hints:
        # Direct hints mode
        hints = args.hints
        assay_type = args.assay_type
        parent_assay_type = args.parent_assay_type
        has_parent = args.has_parent
        has_epic = args.has_epic
    else:
        # Load from JSON
        entity = get_entity_from_args(args.url, args.json, args.token)
        hints = entity.get("vitessce-hints", [])
        assay_type = entity.get("soft_assaytype")
        parent_assay_type = args.parent_assay_type
        has_parent = args.has_parent
        has_epic = args.has_epic

    print("=" * 80)
    print("BUILDER SELECTION DIAGNOSTICS")
    print("=" * 80)
    print()

    from portal_visualization.builder_registry import get_registry, populate_registry

    populate_registry()
    registry = get_registry()

    diagnostics = registry.get_match_diagnostics(
        hints=hints,
        assay_type=assay_type,
        has_parent=has_parent,
        has_epic=has_epic,
        parent_assay_type=parent_assay_type,
    )

    print("Search Criteria:")
    print(f"  Hints: {diagnostics['search_criteria']['hints']}")
    print(f"  Assay type: {diagnostics['search_criteria']['assay_type'] or '(none)'}")
    print(f"  Has parent: {diagnostics['search_criteria']['has_parent']}")
    if parent_assay_type:
        print(f"  Parent assay type: {parent_assay_type}")
    if has_epic:
        print(f"  Has EPIC UUID: {has_epic}")
    print()

    if diagnostics["selected"]:
        print(f"SELECTED BUILDER: {diagnostics['selected']}")
        print(f"  Priority: {diagnostics['matching_builders'][0]['priority']}")
        print()

        if len(diagnostics["matching_builders"]) > 1:
            print(f"Other matching builders ({len(diagnostics['matching_builders']) - 1}):")
            for match in diagnostics["matching_builders"][1:]:
                print(f"  - {match['builder']} (priority={match['priority']})")
            print()
    else:
        print("NO BUILDER MATCHED")
        print()
        print(registry.format_no_match_message(hints, assay_type, has_parent, has_epic, parent_assay_type))

    print("=" * 80)


if __name__ == "__main__":  # pragma: no cover
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "debug":
        sys.argv.pop(1)  # Remove 'debug' from args
        debug_builder_selection()
    else:
        main()
