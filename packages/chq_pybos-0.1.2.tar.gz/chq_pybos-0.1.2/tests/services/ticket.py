"""
Integration tests for pybos TicketService.

These tests validate that the TicketService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestTicketService:
    """Test cases for TicketService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that TicketService is accessible."""
        assert hasattr(bos_client, "ticket")
        assert bos_client.ticket is not None

