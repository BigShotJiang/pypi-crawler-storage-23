"""
Integration tests for pybos AdapterService.

These tests validate that the AdapterService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestAdapterService:
    """Test cases for AdapterService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that AdapterService is accessible."""
        assert hasattr(bos_client, "adapter")
        assert bos_client.adapter is not None

