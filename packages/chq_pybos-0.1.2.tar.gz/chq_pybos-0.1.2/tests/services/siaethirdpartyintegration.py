"""
Integration tests for pybos SiaeThirdPartyIntegrationService.

These tests validate that the SiaeThirdPartyIntegrationService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestSiaeThirdPartyIntegrationService:
    """Test cases for SiaeThirdPartyIntegrationService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that SiaeThirdPartyIntegrationService is accessible."""
        assert hasattr(bos_client, "siaethirdpartyintegration")
        assert bos_client.siaethirdpartyintegration is not None

