"""
Integration tests for pybos SubscriptionService.

These tests validate that the SubscriptionService works correctly with the actual BOS API.
"""

from pybos import BOS
from pybos.types.subscriptionenquiry import FindAllSubscriptionResponse


class TestSubscriptionService:
    """Test cases for SubscriptionService integration."""

    def test_find_all_subscription(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test finding all subscriptions."""
        result = bos_client.subscription.find_all_subscription()
        
        # Validate response structure
        assert isinstance(result, FindAllSubscriptionResponse)
        assert hasattr(result, "error")
        assert hasattr(result, "subscription_list")

