"""
Integration tests for pybos ReservationService.

These tests validate that the ReservationService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestReservationService:
    """Test cases for ReservationService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that ReservationService is accessible."""
        assert hasattr(bos_client, "reservation")
        assert bos_client.reservation is not None

