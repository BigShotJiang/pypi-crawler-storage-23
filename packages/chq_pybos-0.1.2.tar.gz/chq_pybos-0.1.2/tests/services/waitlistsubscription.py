"""
Integration tests for pybos WaitListSubscriptionService.

These tests validate that the WaitListSubscriptionService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestWaitListSubscriptionService:
    """Test cases for WaitListSubscriptionService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that WaitListSubscriptionService is accessible."""
        assert hasattr(bos_client, "waitlistsubscription")
        assert bos_client.waitlistsubscription is not None

