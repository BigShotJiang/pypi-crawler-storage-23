"""
Integration tests for pybos ThirdPartyService.

These tests validate that the ThirdPartyService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestThirdPartyService:
    """Test cases for ThirdPartyService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that ThirdPartyService is accessible."""
        assert hasattr(bos_client, "thirdparty")
        assert bos_client.thirdparty is not None

