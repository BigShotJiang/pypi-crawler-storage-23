"""
Integration tests for pybos PriceListService.

These tests validate that the PriceListService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestPriceListService:
    """Test cases for PriceListService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that PriceListService is accessible."""
        assert hasattr(bos_client, "pricelist")
        assert bos_client.pricelist is not None

