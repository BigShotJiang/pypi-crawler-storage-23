"""
Integration tests for pybos AdmissionService.

These tests validate that the AdmissionService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestAdmissionService:
    """Test cases for AdmissionService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that AdmissionService is accessible."""
        assert hasattr(bos_client, "admissions")
        assert bos_client.admissions is not None

