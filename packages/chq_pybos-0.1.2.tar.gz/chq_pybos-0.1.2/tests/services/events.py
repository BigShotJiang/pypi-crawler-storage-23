"""
Integration tests for pybos EventService.

These tests validate that the EventService works correctly with the actual BOS API.
"""

from pybos import BOS
from pybos.types.eventenquiry import FindAllEventsResponse, FindAllEventCategoryResponse


class TestEventService:
    """Test cases for EventService integration."""

    def test_find_all_events(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test finding all events."""
        result = bos_client.events.find_all_events()
        
        # Validate response structure
        assert isinstance(result, FindAllEventsResponse)
        assert hasattr(result, "error")
        assert hasattr(result, "event_list")

    def test_find_all_event_category(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test finding all event categories."""
        result = bos_client.events.find_all_event_category()
        
        # Validate response structure
        assert isinstance(result, FindAllEventCategoryResponse)
        assert hasattr(result, "error")

