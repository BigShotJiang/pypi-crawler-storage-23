"""
Integration tests for pybos ShopCartValidationService.

These tests validate that the ShopCartValidationService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestShopCartValidationService:
    """Test cases for ShopCartValidationService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that ShopCartValidationService is accessible."""
        assert hasattr(bos_client, "shopcartvalidation")
        assert bos_client.shopcartvalidation is not None

