"""
Integration tests for pybos ResourceManagementService.

These tests validate that the ResourceManagementService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestResourceManagementService:
    """Test cases for ResourceManagementService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that ResourceManagementService is accessible."""
        assert hasattr(bos_client, "resourcemanagement")
        assert bos_client.resourcemanagement is not None

