"""
Integration tests for pybos CapacityService.

These tests validate that the CapacityService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestCapacityService:
    """Test cases for CapacityService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that CapacityService is accessible."""
        assert hasattr(bos_client, "capacity")
        assert bos_client.capacity is not None

