"""
Integration tests for pybos MaskService.

These tests validate that the MaskService works correctly with the actual BOS API.
"""

from pybos import BOS
from pybos.types.maskenquiry import FindAllAccountCategoriesResponse


class TestMaskService:
    """Test cases for MaskService integration."""

    def test_find_all_account_categories(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test finding all account categories."""
        result = bos_client.masks.find_all_account_categories()
        
        # Validate response structure
        assert isinstance(result, FindAllAccountCategoriesResponse)
        assert hasattr(result, "error")
        assert hasattr(result, "dmg_category_list")

