"""
Integration tests for pybos DonationService.

These tests validate that the DonationService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestDonationService:
    """Test cases for DonationService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that DonationService is accessible."""
        assert hasattr(bos_client, "donation")
        assert bos_client.donation is not None

