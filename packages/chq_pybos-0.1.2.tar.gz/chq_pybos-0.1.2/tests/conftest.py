"""
Pytest configuration and fixtures for pybos integration tests.
"""

import os
from tests.config import load_env_from_files
import pytest
from pybos import BOS


@pytest.fixture(scope="session")
def test_config():
    """Load test configuration from environment variables."""
    # Load .env before reading environment
    load_env_from_files()
    config = {
        "isapi_url": os.getenv("BOS_TEST_URL", "https://test-bos.example.com"),
        "api_key": os.getenv("BOS_TEST_API_KEY", "test-api-key"),
        "username": os.getenv("BOS_TEST_USERNAME", "testuser"),
        "workstation": os.getenv("BOS_TEST_WORKSTATION", "test-workstation"),
        "password": os.getenv("BOS_TEST_PASSWORD", "test-password"),
    }

    # Validate required configuration
    required_fields = ["isapi_url", "api_key"]
    missing_fields = [field for field in required_fields if not config[field]]

    if missing_fields:
        pytest.skip(f"Missing required test configuration: {missing_fields}")

    return config


@pytest.fixture(scope="session")
def bos_client(test_config):
    """Create a BOS client instance for testing."""
    return BOS(
        isapi_url=test_config["isapi_url"],
        api_key=test_config["api_key"],
        username=test_config.get("username"),
        workstation=test_config.get("workstation"),
        password=test_config.get("password"),
    )


@pytest.fixture
def skip_if_no_credentials():
    """Skip test if credentials are not properly configured."""
    load_env_from_files()
    api_key = os.getenv("BOS_TEST_API_KEY")
    if not api_key or api_key == "test-api-key":
        pytest.skip("BOS_TEST_API_KEY not configured - skipping integration test")


@pytest.fixture
def test_account_data():
    """Sample account data for testing."""
    return {
        "dmg_category_ak": "TEST_CATEGORY",
        "fields": [
            {"field_type": 1, "value": "Test Account"},
            {"field_type": 2, "value": "test@example.com"},
        ],
        "status": 1,
    }


@pytest.fixture
def test_user_data():
    """Sample user data for testing."""
    return {
        "username": "testuser",
        "email": "test@example.com",
        "first_name": "Test",
        "last_name": "User",
    }
