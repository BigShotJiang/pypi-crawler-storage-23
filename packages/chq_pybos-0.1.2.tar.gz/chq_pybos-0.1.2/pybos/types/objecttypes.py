"""
BOS API object type (OBJTYPE) IDs for account fields.

Use ObjectType for named references, e.g.:
    ObjectType.AK          -> 0
    ObjectType.FIRST_NAME  -> 1
    ObjectType.EMAIL_ADDRESS_1  -> 21
    ObjectType.Emails      -> 21 (alias for primary email)

Based on Patronbase/BOS API documentation.
"""

from enum import IntEnum
from typing import Dict, Optional


class ObjectType(IntEnum):
    """OBJTYPE IDs for account fields. Use as ObjectType.FIRST_NAME, etc."""

    # Core / Mask
    AK = 0
    SUB_MASK_DETAIL = 0  # alias
    FIRST_NAME = 1
    MIDDLE_NAME = 2
    SUR_NAME = 3
    NAME_PREFIX = 4
    TITLE = 5
    ADDRESS1 = 6
    ADDRESS2 = 7
    CITY = 8
    STATE = 9
    ZIP_CODE = 10
    COUNTRY = 11
    HOME_PHONE = 12
    BUSINESS_PHONE = 13
    FAX = 14
    MOBILE_PHONE = 15
    OTHER_PHONE1 = 17
    OTHER_PHONE2 = 18
    GENDER = 19
    PERSONAL_WEBPAGE = 20
    EMAIL_ADDRESS_1 = 21
    Email = 21  # alias
    EMAIL_ADDRESS_2 = 22
    SPOUSE_NAME = 23
    BIRTH_DATE = 24
    COUNTY = 25
    ACK_NEWSLETTER = 26
    ADDRESS3 = 27
    COMPANY_NAME = 31
    COMPANY_LINE2 = 32
    COMPANY_ADDRESS1 = 36
    COMPANY_ADDRESS2 = 37
    COMPANY_CITY = 38
    COMPANY_STATE = 39
    COMPANY_ZIP_CODE = 40
    COMPANY_COUNTRY = 41
    COMPANY_BUSINESS_PHONE1 = 42
    COMPANY_BUSINESS_PHONE2 = 43
    COMPANY_FAX = 44
    COMPANY_MOBILE_PHONE = 45
    COMPANY_PAGER = 46
    COMPANY_OTHER_PHONE1 = 47
    COMPANY_OTHER_PHONE2 = 48
    COMPANY_SITE = 50
    SOCIAL_SECURITY_NUMBER = 51
    PASSPORT_PHOTO = 52
    JOB_TITLE = 53
    PROVINCE = 54
    EXTERNAL_CODE1 = 55
    ADDITIONAL_INFO1 = 56
    ADDITIONAL_INFO2 = 57
    CC_TOKEN = 58
    VIRTUAL_BANK_ACCOUNT = 59
    IP_ADDRESS = 60
    EXTERNAL_CODE2 = 61
    PLATE = 62
    EMPLOYEE_ID = 63
    CUSTOM1 = 501
    CUSTOM2 = 502
    CUSTOM3 = 503
    CUSTOM4 = 504
    CUSTOM5 = 505
    CUSTOM6 = 506
    CUSTOM7 = 507
    CUSTOM8 = 508
    CUSTOM9 = 509
    CUSTOM10 = 510
    CUSTOM11 = 511
    CUSTOM12 = 512
    CUSTOM13 = 513
    CUSTOM14 = 514
    CUSTOM15 = 515
    CUSTOM16 = 516
    CUSTOM17 = 517
    CUSTOM18 = 518
    CUSTOM19 = 519
    CUSTOM20 = 520
    CUSTOM21 = 521
    CUSTOM22 = 522
    CUSTOM23 = 523
    CUSTOM24 = 524
    CUSTOM25 = 525
    CUSTOM26 = 526
    CUSTOM27 = 527
    CUSTOM28 = 528
    CUSTOM29 = 529
    CUSTOM30 = 530
    CUSTOM31 = 531
    CUSTOM32 = 532
    CUSTOM33 = 533
    CUSTOM34 = 534
    CUSTOM35 = 535
    WEB_INFO_01 = 536
    WEB_INFO_02 = 537
    WEB_INFO_03 = 538
    WEB_INFO_04 = 539
    WEB_INFO_05 = 540
    WEB_INFO_06 = 541
    WEB_INFO_07 = 542
    WEB_INFO_08 = 543
    WEB_INFO_09 = 544
    WEB_INFO_10 = 545
    PLEDGE_GIFT_AID = 546
    PLEDGE_GIFT_AID_AMT = 547
    USERNAME = 548
    PASSWORD = 549
    CONFIRM_PASSWORD = 550
    WEB_INFO_11 = 551
    WEB_INFO_12 = 552
    WEB_INFO_13 = 553
    WEB_INFO_14 = 554
    WEB_INFO_15 = 555
    WEB_INFO_16 = 556
    WEB_INFO_17 = 557
    WEB_INFO_18 = 558
    WEB_INFO_19 = 559
    WEB_INFO_20 = 560
    WEB_INFO_21 = 561
    WEB_INFO_22 = 562
    WEB_INFO_23 = 563
    WEB_INFO_24 = 564
    WEB_INFO_25 = 565
    WEB_INFO_26 = 566
    WEB_INFO_27 = 567
    WEB_INFO_28 = 568
    WEB_INFO_29 = 569
    WEB_INFO_30 = 570
    WEB_INFO_31 = 571
    WEB_INFO_32 = 572
    WEB_INFO_33 = 573
    WEB_INFO_34 = 574
    WEB_INFO_35 = 575
    CUSTOM36 = 576
    CUSTOM37 = 577
    CUSTOM38 = 578
    CUSTOM39 = 579
    CUSTOM40 = 580
    CUSTOM41 = 581
    CUSTOM42 = 582
    CUSTOM43 = 583
    CUSTOM44 = 584
    CUSTOM45 = 585
    CUSTOM46 = 586
    CUSTOM47 = 587
    CUSTOM48 = 588
    CUSTOM49 = 589
    CUSTOM50 = 590
    CUSTOM51 = 591
    CUSTOM52 = 592
    CUSTOM53 = 593
    CUSTOM54 = 594
    CUSTOM55 = 595
    CUSTOM56 = 596
    CUSTOM57 = 597
    CUSTOM58 = 598
    CUSTOM59 = 599
    CUSTOM60 = 600
    WEB_INFO_36 = 601
    WEB_INFO_37 = 602
    WEB_INFO_38 = 603
    WEB_INFO_39 = 604
    WEB_INFO_40 = 605
    WEB_INFO_41 = 606
    WEB_INFO_42 = 607
    WEB_INFO_43 = 608
    WEB_INFO_44 = 609
    WEB_INFO_45 = 610
    WEB_INFO_46 = 611
    WEB_INFO_47 = 612
    WEB_INFO_48 = 613
    WEB_INFO_49 = 614
    WEB_INFO_50 = 615
    WEB_INFO_51 = 616
    WEB_INFO_52 = 617
    WEB_INFO_53 = 618
    WEB_INFO_54 = 619
    WEB_INFO_55 = 620
    WEB_INFO_56 = 621
    WEB_INFO_57 = 622
    WEB_INFO_58 = 623
    WEB_INFO_59 = 624
    WEB_INFO_60 = 625
    CUSTOM_IMAGE1 = 1001
    CUSTOM_IMAGE2 = 1002
    CUSTOM_IMAGE3 = 1003
    CUSTOM_IMAGE4 = 1004
    CUSTOM_IMAGE5 = 1005
    CUSTOM_ATTACHMENT1 = 1006
    CUSTOM_ATTACHMENT2 = 1007
    CUSTOM_ATTACHMENT3 = 1008
    CUSTOM_ATTACHMENT4 = 1009
    CUSTOM_ATTACHMENT5 = 1010
    TVM_IMAGE1 = 2001
    TVM_IMAGE2 = 2002
    TVM_IMAGE3 = 2003
    TVM_TITLE1 = 2011
    TVM_TITLE2 = 2012
    TVM_TITLE3 = 2013
    TVM_DESCRIPTION1 = 2021
    TVM_DESCRIPTION2 = 2022
    TVM_DESCRIPTION3 = 2023
    UPSELL_IMAGE1 = 3001
    UPSELL_TITLE1 = 3011
    UPSELL_DESCRIPTION1 = 3021
    UPSELL_SUBTITLE1 = 3031
    UPGRADE_IMAGE1 = 3101
    SUGGESTIVE_SELL_IMAGE1 = 3201
    RENEWAL_IMAGE1 = 3301
    DONATION_IMAGE1 = 3311
    TIP_IMAGE1 = 3321
    SIAE_TDT_NOME = 4000
    SIAE_TDT_COGNOME = 4001
    SIAE_TDT_CODICE_TESSERA = 4002
    SIAE_TDT_COMUNE_RESIDENZA = 4100
    SIAE_TDT_PROVINCIA_RESIDENZA = 4101
    SIAE_TDT_REGIONE_RESIDENZA = 4102
    SIAE_TDT_NAZIONE_RESIDENZA = 4103
    SIAE_TDT_LOCALITA_RESIDENZA = 4104
    SIAE_TDT_COMUNE_NASCITA = 4120
    SIAE_TDT_PROVINCIA_NASCITA = 4121
    SIAE_TDT_REGIONE_NASCITA = 4122
    SIAE_TDT_NAZIONE_NASCITA = 4123
    SIAE_TDT_LOCALITA_NASCITA = 4124
    SIAE_TDT_COMUNE_DOMICILIO = 4130
    SIAE_TDT_PROVINCIA_DOMICILIO = 4131
    SIAE_TDT_REGIONE_DOMICILIO = 4132
    SIAE_TDT_NAZIONE_DOMICILIO = 4133
    SIAE_TDT_LOCALITA_DOMICILIO = 4134
    SIAE_TDT_COMUNE_SPEDIZIONE = 4140
    SIAE_TDT_PROVINCIA_SPEDIZIONE = 4141
    SIAE_TDT_REGIONE_SPEDIZIONE = 4142
    SIAE_TDT_NAZIONE_SPEDIZIONE = 4143
    SIAE_TDT_LOCALITA_SPEDIZIONE = 4144
    SIAE_TDT_LOCALITA_RILASCIO_DOCUMENTO = 4154
    SIAE_TDT_NAZIONE_NASCITA_TUTORE = 4163
    SIAE_TDT_LOCALITA_NASCITA_TUTORE = 4164
    SIAE_TDT_CODICE_FISCALE_SQUADRA = 4200
    SIAE_BATTELLI_CELLULARE = 4300
    SIAE_BATTELLI_TIPO_AUTENTICAZIONE = 4301
    SIAE_BATTELLI_INDIRIZZO_SPEDIZIONE = 4302
    OPT_IN_EMAIL = 5001
    OPT_IN_MAIL = 5002
    OPT_IN_MOBILE_SMS = 5003
    OPT_IN_PHONE = 5004
    PHOTO_MANAGER = 5501
    SYSTEM_PAYMENT_FLEX_AK = 10001
    VAT_NUMBER = 10002
    TIPOLOGY = 10003
    SEX = 10004
    PRIVACY1 = 10005
    PRIVACY2 = 10006
    PRIVACY3 = 10007
    REFERRED_LINK = 10008
    SIGNATURE = 10009
    POINTS_SEND_POINT = 11001
    POINTS_RANGE1_FROM = 11002
    POINTS_RANGE1_TO = 11003
    POINTS_RANGE2_FROM = 11004
    POINTS_RANGE2_TO = 11005
    POINTS_RANGE3_FROM = 11006
    POINTS_RANGE3_TO = 11007
    POINTS_RANGE4_FROM = 11008
    POINTS_RANGE4_TO = 11009
    POINTS_RANGE5_FROM = 11010
    POINTS_RANGE5_TO = 11011
    POINTS_RANGE1_NAME = 11012
    POINTS_RANGE2_NAME = 11013
    POINTS_RANGE3_NAME = 11014
    POINTS_RANGE4_NAME = 11015
    POINTS_RANGE5_NAME = 11016
    POINTS_RANGE6_NAME = 11017

# Maps OBJTYPE ID to field name
OBJECT_TYPE_NAMES: Dict[int, str] = {
    0: "SubMaskDetail (Ak)",
    1: "FirstName",
    2: "MiddleName",
    3: "SurName",
    4: "NamePrefix",
    5: "Title",
    6: "Address1",
    7: "Address2",
    8: "City",
    9: "State",
    10: "ZipCode",
    11: "Country",
    12: "HomePhone",
    13: "BusinessPhone",
    14: "Fax",
    15: "MobilePhone",
    17: "OtherPhone1",
    18: "OtherPhone2",
    19: "Gender",
    20: "PersonalWebpage",
    21: "EmailAddress1",
    22: "EmailAddress2",
    23: "SpouseName",
    24: "BirthDate",
    25: "County",
    26: "AckNewsletter",
    27: "Address3",
    31: "CompanyName",
    32: "CompanyLine2",
    36: "CompanyAddress1",
    37: "CompanyAddress2",
    38: "CompanyCity",
    39: "CompanyState",
    40: "CompanyZipCode",
    41: "CompanyCountry",
    42: "CompanyBusinessPhone1",
    43: "CompanyBusinessPhone2",
    44: "CompanyFax",
    45: "CompanyMobilePhone",
    46: "CompanyPager",
    47: "CompanyOtherPhone1",
    48: "CompanyOtherPhone2",
    50: "CompanySite",
    51: "SocialSecurityNumber",
    52: "PassportPhoto (Image-compatible)",
    53: "JobTitle",
    54: "Province",
    55: "ExternalCode1",
    56: "AdditionalInfo1",
    57: "AdditionalInfo2",
    58: "CCToken",
    59: "VirtualBankAccount",
    60: "IpAddress",
    61: "ExternalCode2",
    62: "Plate",
    63: "EmployeeId",
    501: "Custom1",
    502: "Custom2",
    503: "Custom3",
    504: "Custom4",
    505: "Custom5",
    506: "Custom6",
    507: "Custom7",
    508: "Custom8",
    509: "Custom9",
    510: "Custom10",
    511: "Custom11",
    512: "Custom12",
    513: "Custom13",
    514: "Custom14",
    515: "Custom15",
    516: "Custom16",
    517: "Custom17",
    518: "Custom18",
    519: "Custom19",
    520: "Custom20",
    521: "Custom21",
    522: "Custom22",
    523: "Custom23",
    524: "Custom24",
    525: "Custom25",
    526: "Custom26",
    527: "Custom27",
    528: "Custom28",
    529: "Custom29",
    530: "Custom30",
    531: "Custom31",
    532: "Custom32",
    533: "Custom33",
    534: "Custom34",
    535: "Custom35",
    536: "WebInfo01",
    537: "WebInfo02",
    538: "WebInfo03",
    539: "WebInfo04",
    540: "WebInfo05",
    541: "WebInfo06",
    542: "WebInfo07",
    543: "WebInfo08",
    544: "WebInfo09",
    545: "WebInfo10",
    546: "PledgeGiftAid",
    547: "PledgeGiftAidAmt",
    548: "Username",
    549: "Password",
    550: "ConfirmPassword",
    551: "WebInfo11",
    552: "WebInfo12",
    553: "WebInfo13",
    554: "WebInfo14",
    555: "WebInfo15",
    556: "WebInfo16",
    557: "WebInfo17",
    558: "WebInfo18",
    559: "WebInfo19",
    560: "WebInfo20",
    561: "WebInfo21",
    562: "WebInfo22",
    563: "WebInfo23",
    564: "WebInfo24",
    565: "WebInfo25",
    566: "WebInfo26",
    567: "WebInfo27",
    568: "WebInfo28",
    569: "WebInfo29",
    570: "WebInfo30",
    571: "WebInfo31",
    572: "WebInfo32",
    573: "WebInfo33",
    574: "WebInfo34",
    575: "WebInfo35",
    576: "Custom36",
    577: "Custom37",
    578: "Custom38",
    579: "Custom39",
    580: "Custom40",
    581: "Custom41",
    582: "Custom42",
    583: "Custom43",
    584: "Custom44",
    585: "Custom45",
    586: "Custom46",
    587: "Custom47",
    588: "Custom48",
    589: "Custom49",
    590: "Custom50",
    591: "Custom51",
    592: "Custom52",
    593: "Custom53",
    594: "Custom54",
    595: "Custom55",
    596: "Custom56",
    597: "Custom57",
    598: "Custom58",
    599: "Custom59",
    600: "Custom60",
    601: "WebInfo36",
    602: "WebInfo37",
    603: "WebInfo38",
    604: "WebInfo39",
    605: "WebInfo40",
    606: "WebInfo41",
    607: "WebInfo42",
    608: "WebInfo43",
    609: "WebInfo44",
    610: "WebInfo45",
    611: "WebInfo46",
    612: "WebInfo47",
    613: "WebInfo48",
    614: "WebInfo49",
    615: "WebInfo50",
    616: "WebInfo51",
    617: "WebInfo52",
    618: "WebInfo53",
    619: "WebInfo54",
    620: "WebInfo55",
    621: "WebInfo56",
    622: "WebInfo57",
    623: "WebInfo58",
    624: "WebInfo59",
    625: "WebInfo60",
    1001: "CustomImage1 (Image-compatible)",
    1002: "CustomImage2 (Image-compatible)",
    1003: "CustomImage3 (Image-compatible)",
    1004: "CustomImage4 (Image-compatible)",
    1005: "CustomImage5 (Image-compatible)",
    1006: "CustomAttachment1 (Attachment-compatible)",
    1007: "CustomAttachment2 (Attachment-compatible)",
    1008: "CustomAttachment3 (Attachment-compatible)",
    1009: "CustomAttachment4 (Attachment-compatible)",
    1010: "CustomAttachment5 (Attachment-compatible)",
    2001: "TVM_Image1",
    2002: "TVM_Image2",
    2003: "TVM_Image3",
    2011: "TVM_Title1",
    2012: "TVM_Title2",
    2013: "TVM_Title3",
    2021: "TVM_Description1",
    2022: "TVM_Description2",
    2023: "TVM_Description3",
    3001: "UpSell_Image1",
    3011: "UpSell_Title1",
    3021: "UpSell_Description1",
    3031: "UpSell_SubTitle1",
    3101: "Upgrade_Image1",
    3201: "Suggestive_Sell_Image1",
    3301: "Renewal_Image1",
    3311: "Donation_Image1",
    3321: "Tip_Image1",
    4000: "SiaeTdTNome",
    4001: "SiaeTdTCognome",
    4002: "SiaeTdTCodiceTessera",
    4100: "SiaeTdTComuneResidenza",
    4101: "SiaeTdTProvinciaResidenza",
    4102: "SiaeTdTRegioneResidenza",
    4103: "SiaeTdTNazioneResidenza",
    4104: "SiaeTdTLocalitaResidenza",
    4120: "SiaeTdTComuneNascita",
    4121: "SiaeTdTProvinciaNascita",
    4122: "SiaeTdTRegioneNascita",
    4123: "SiaeTdTNazioneNascita",
    4124: "SiaeTdTLocalitaNascita",
    4130: "SiaeTdTComuneDomicilio",
    4131: "SiaeTdTProvinciaDomicilio",
    4132: "SiaeTdTRegioneDomicilio",
    4133: "SiaeTdTNazioneDomicilio",
    4134: "SiaeTdTLocalitaDomicilio",
    4140: "SiaeTdTComuneSpedizione",
    4141: "SiaeTdTProvinciaSpedizione",
    4142: "SiaeTdTRegioneSpedizione",
    4143: "SiaeTdTNazioneSpedizione",
    4144: "SiaeTdTLocalitaSpedizione",
    4154: "SiaeTdTLocalitaRilascioDocumento",
    4163: "SiaeTdTNazioneNascitaTutore",
    4164: "SiaeTdTLocalitaNascitaTutore",
    4200: "SiaeTdTCodiceFiscaleSquadra",
    4300: "SiaeBattelliCellulare",
    4301: "SiaeBattelliTipoAutenticazione",
    4302: "SiaeBattelliIndirizzoSpedizione",
    5001: "Opt_In_Email",
    5002: "Opt_In_Mail",
    5003: "Opt_In_MobileSMS",
    5004: "Opt_In_Phone",
    5501: "PhotoManager",
    10001: "System_PaymentFlexAK",
    10002: "VatNumber",
    10003: "Tipology",
    10004: "Sex",
    10005: "Privacy1",
    10006: "Privacy2",
    10007: "Privacy3",
    10008: "Referred_Link",
    10009: "Signature",
    11001: "Points_SendPoint",
    11002: "Points_Range1_From",
    11003: "Points_Range1_To",
    11004: "Points_Range2_From",
    11005: "Points_Range2_To",
    11006: "Points_Range3_From",
    11007: "Points_Range3_To",
    11008: "Points_Range4_From",
    11009: "Points_Range4_To",
    11010: "Points_Range5_From",
    11011: "Points_Range5_To",
    11012: "Points_Range1_Name",
    11013: "Points_Range2_Name",
    11014: "Points_Range3_Name",
    11015: "Points_Range4_Name",
    11016: "Points_Range5_Name",
    11017: "Points_Range6_Name",
}

# Reverse lookup: field name (without parenthetical notes) -> OBJTYPE ID
def _build_reverse_lookup() -> Dict[str, int]:
    result: Dict[str, int] = {}
    for obj_id, name in OBJECT_TYPE_NAMES.items():
        base_name = name.split(" (")[0] if " (" in name else name
        if base_name not in result:
            result[base_name] = obj_id
    return result


OBJECT_TYPE_IDS: Dict[str, int] = _build_reverse_lookup()


def get_object_type_name(obj_type_id: int) -> Optional[str]:
    """Get the field name for an OBJTYPE ID, or None if unknown."""
    return OBJECT_TYPE_NAMES.get(obj_type_id)


def get_object_type_id(name: str) -> Optional[int]:
    """Get the OBJTYPE ID for a field name, or None if unknown."""
    return OBJECT_TYPE_IDS.get(name)
