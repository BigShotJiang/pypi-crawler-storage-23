"""
Type definitions for Ticket.

This module provides structured classes for ticket operations,
replacing tuple-based parameters with type-safe, self-documenting classes.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, BaseDateFilter, BaseTimeFilter, PageRequest, PageResponse


@dataclass
class MagicLinkTicket:
    """Magic link ticket structure.
    
    Attributes:
        ticket_id: Ticket ID
    """
    
    ticket_id: int
    
    @classmethod
    def from_dict(cls, data: dict) -> "MagicLinkTicket":
        """Create MagicLinkTicket from API response dictionary."""
        return cls(
            ticket_id=data.get("ID", 0),
        )
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "ID": self.ticket_id,
        }


@dataclass
class MagicLinkTicketList:
    """Magic link ticket list structure.
    
    Attributes:
        tickets: List of magic link tickets
    """
    
    tickets: List[MagicLinkTicket]
    
    @classmethod
    def from_dict(cls, data: dict) -> "MagicLinkTicketList":
        """Create MagicLinkTicketList from API response dictionary."""
        tickets = []
        if "MAGICLINKTICKET" in data:
            ticket_list = data["MAGICLINKTICKET"]
            if isinstance(ticket_list, list):
                tickets = [MagicLinkTicket.from_dict(t) for t in ticket_list]
            else:
                tickets = [MagicLinkTicket.from_dict(ticket_list)]
        return cls(tickets=tickets)
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "MAGICLINKTICKET": [t.to_dict() for t in self.tickets],
        }


@dataclass
class MagicLinkTicketError:
    """Magic link ticket error structure.
    
    Attributes:
        ticket_id: Ticket ID
        error: Error information
    """
    
    ticket_id: int
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "MagicLinkTicketError":
        """Create MagicLinkTicketError from API response dictionary."""
        return cls(
            ticket_id=data.get("ID", 0),
            error=Error.from_dict(data.get("ERROR", {})),
        )


@dataclass
class MagicLinkTicketErrorList:
    """Magic link ticket error list structure.
    
    Attributes:
        errors: List of magic link ticket errors
    """
    
    errors: List[MagicLinkTicketError]
    
    @classmethod
    def from_dict(cls, data: dict) -> "MagicLinkTicketErrorList":
        """Create MagicLinkTicketErrorList from API response dictionary."""
        errors = []
        if "MAGICLINKTICKETERROR" in data:
            error_list = data["MAGICLINKTICKETERROR"]
            if isinstance(error_list, list):
                errors = [MagicLinkTicketError.from_dict(e) for e in error_list]
            else:
                errors = [MagicLinkTicketError.from_dict(error_list)]
        return cls(errors=errors)


@dataclass
class DynamicQrCodePhoneAssociation:
    """Dynamic QR code phone association structure.
    
    Attributes:
        phone_id: Phone ID
        phone_name_owner: Phone name owner
        phone_surname_owner: Phone surname owner
        phone_email_owner: Phone email owner
        phone_mypass_owner: Phone mypass owner
    """
    
    phone_id: str
    phone_name_owner: str
    phone_surname_owner: str
    phone_email_owner: str
    phone_mypass_owner: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "DynamicQrCodePhoneAssociation":
        """Create DynamicQrCodePhoneAssociation from API response dictionary."""
        return cls(
            phone_id=data.get("PHONEID", ""),
            phone_name_owner=data.get("PHONENAMEOWNER", ""),
            phone_surname_owner=data.get("PHONESURNAMEOWNER", ""),
            phone_email_owner=data.get("PHONEEMAILOWNER", ""),
            phone_mypass_owner=data.get("PHONEMYPASSOWNER", ""),
        )
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "PHONEID": self.phone_id,
            "PHONENAMEOWNER": self.phone_name_owner,
            "PHONESURNAMEOWNER": self.phone_surname_owner,
            "PHONEEMAILOWNER": self.phone_email_owner,
            "PHONEMYPASSOWNER": self.phone_mypass_owner,
        }


@dataclass
class DynamicQrCodeInfo:
    """Dynamic QR code information structure.
    
    Attributes:
        is_dynamic_qr_code: Is dynamic QR code flag
        is_associated: Is associated flag
        magic_link_list: Magic link list (Dict for complex nested structure)
    """
    
    is_dynamic_qr_code: bool
    is_associated: Optional[bool] = None
    magic_link_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "DynamicQrCodeInfo":
        """Create DynamicQrCodeInfo from API response dictionary."""
        return cls(
            is_dynamic_qr_code=data.get("ISDYNAMICQRCODE", False),
            is_associated=data.get("ISASSOCIATED"),
            magic_link_list=data.get("MAGICLINKLIST"),
        )


@dataclass
class QuickProductItem:
    """Quick product item structure.
    
    Attributes:
        product_ak: Product AK
        flat: Flat flag
        value: Value
    """
    
    product_ak: str
    flat: bool
    value: float
    
    @classmethod
    def from_dict(cls, data: dict) -> "QuickProductItem":
        """Create QuickProductItem from API response dictionary."""
        return cls(
            product_ak=data.get("PRODUCTAK", ""),
            flat=data.get("FLAT", False),
            value=data.get("VALUE", 0.0),
        )


@dataclass
class QuickInfo:
    """Quick information structure.
    
    Attributes:
        quick_product_list: Quick product list
        quick_only: Quick only flag
    """
    
    quick_product_list: List[QuickProductItem]
    quick_only: bool
    
    @classmethod
    def from_dict(cls, data: dict) -> "QuickInfo":
        """Create QuickInfo from API response dictionary."""
        products = []
        if "QUICKPRODUCTLIST" in data and "QUICKPRODUCTITEM" in data["QUICKPRODUCTLIST"]:
            item_list = data["QUICKPRODUCTLIST"]["QUICKPRODUCTITEM"]
            if isinstance(item_list, list):
                products = [QuickProductItem.from_dict(p) for p in item_list]
            else:
                products = [QuickProductItem.from_dict(item_list)]
        return cls(
            quick_product_list=products,
            quick_only=data.get("QUICKONLY", False),
        )


@dataclass
class ExtendedCngPerfInfo:
    """Extended change performance information structure.
    
    Attributes:
        changed_perf_restriction_enabled: Changed performance restriction enabled
        changed_perf_op_type: Changed performance operation type
        changed_perf_data_from: Changed performance data from
        changed_perf_data_to: Changed performance data to
        changed_perf_hours: Changed performance hours
        changed_perf_number_enabled: Changed performance number enabled
        changed_perf_number: Changed performance number
    """
    
    changed_perf_restriction_enabled: bool
    changed_perf_op_type: Optional[int] = None
    changed_perf_data_from: Optional[str] = None
    changed_perf_data_to: Optional[str] = None
    changed_perf_hours: Optional[int] = None
    changed_perf_number_enabled: bool = False
    changed_perf_number: Optional[int] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ExtendedCngPerfInfo":
        """Create ExtendedCngPerfInfo from API response dictionary."""
        return cls(
            changed_perf_restriction_enabled=data.get("CHANGEDPERFRESTRICTIONENABLED", False),
            changed_perf_op_type=data.get("CHANGEDPERFOPTYPE"),
            changed_perf_data_from=data.get("CHANGEDPERFDATAFROM"),
            changed_perf_data_to=data.get("CHANGEDPERFDATATO"),
            changed_perf_hours=data.get("CHANGEDPERFHOURS"),
            changed_perf_number_enabled=data.get("CHANGEDPERFNUMBERENABLED", False),
            changed_perf_number=data.get("CHANGEDPERFNUMBER"),
        )


@dataclass
class TicketExport:
    """Ticket export structure.
    
    Attributes:
        ticket_id: Ticket ID
        media_code: Media code
        price: Price
        void_type: Void type
        seat_id: Seat ID
        description: Description
        description2: Description 2
        last_update: Last update
    """
    
    ticket_id: int
    media_code: str
    price: float
    void_type: int
    seat_id: int
    description: str
    description2: str
    last_update: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "TicketExport":
        """Create TicketExport from API response dictionary."""
        return cls(
            ticket_id=data.get("TICKETID", 0),
            media_code=data.get("MEDIACODE", ""),
            price=data.get("PRICE", 0.0),
            void_type=data.get("VOIDTYPE", 0),
            seat_id=data.get("SEATID", 0),
            description=data.get("DESCRIPTION", ""),
            description2=data.get("DESCRIPTION2", ""),
            last_update=data.get("LASTUPDATE", ""),
        )


@dataclass
class TicketExportList:
    """Ticket export list structure.
    
    Attributes:
        tickets: List of ticket exports
    """
    
    tickets: List[TicketExport]
    
    @classmethod
    def from_dict(cls, data: dict) -> "TicketExportList":
        """Create TicketExportList from API response dictionary."""
        tickets = []
        if "TICKETEXPORT" in data:
            ticket_list = data["TICKETEXPORT"]
            if isinstance(ticket_list, list):
                tickets = [TicketExport.from_dict(t) for t in ticket_list]
            else:
                tickets = [TicketExport.from_dict(ticket_list)]
        return cls(tickets=tickets)


@dataclass
class TicketExportFull:
    """Ticket export full structure (extends TicketExport with additional fields).
    
    Attributes:
        ticket_id: Ticket ID
        media_code: Media code
        price: Price
        void_type: Void type
        seat_id: Seat ID
        description: Description
        description2: Description 2
        last_update: Last update
        first_name: First name
        last_name: Last name
        email: Email
        seat: Seat
        seat_category: Seat category
        entries: Entries
        reentries: Reentries
        reservation_ak: Reservation AK
    """
    
    ticket_id: int
    media_code: str
    price: float
    void_type: int
    seat_id: int
    description: str
    description2: str
    last_update: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[str] = None
    seat: Optional[str] = None
    seat_category: Optional[str] = None
    entries: Optional[int] = None
    reentries: Optional[int] = None
    reservation_ak: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "TicketExportFull":
        """Create TicketExportFull from API response dictionary."""
        return cls(
            ticket_id=data.get("TICKETID", 0),
            media_code=data.get("MEDIACODE", ""),
            price=data.get("PRICE", 0.0),
            void_type=data.get("VOIDTYPE", 0),
            seat_id=data.get("SEATID", 0),
            description=data.get("DESCRIPTION", ""),
            description2=data.get("DESCRIPTION2", ""),
            last_update=data.get("LASTUPDATE", ""),
            first_name=data.get("FIRSTNAME"),
            last_name=data.get("LASTNAME"),
            email=data.get("EMAIL"),
            seat=data.get("SEAT"),
            seat_category=data.get("SEATCATEGORY"),
            entries=data.get("ENTRIES"),
            reentries=data.get("REENTRIES"),
            reservation_ak=data.get("RESERVATIONAK"),
        )


@dataclass
class TicketExportListFull:
    """Ticket export list full structure.
    
    Attributes:
        tickets: List of ticket export full
    """
    
    tickets: List[TicketExportFull]
    
    @classmethod
    def from_dict(cls, data: dict) -> "TicketExportListFull":
        """Create TicketExportListFull from API response dictionary."""
        tickets = []
        if "TICKETEXPORTFULL" in data:
            ticket_list = data["TICKETEXPORTFULL"]
            if isinstance(ticket_list, list):
                tickets = [TicketExportFull.from_dict(t) for t in ticket_list]
            else:
                tickets = [TicketExportFull.from_dict(ticket_list)]
        return cls(tickets=tickets)


@dataclass
class GenerateMagicLinkRequest:
    """Generate magic link request structure.
    
    Attributes:
        magic_link_ticket_list: Magic link ticket list
        association_type: Association type (A=Association, R=Reassociation)
        account_ak: Account AK
        email_address: Email address
    """
    
    magic_link_ticket_list: MagicLinkTicketList
    association_type: str
    account_ak: str
    email_address: str
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "MAGICLINKTICKETLIST": self.magic_link_ticket_list.to_dict(),
            "ASSOCIATIONTYPE": self.association_type,
            "ACCOUNTAK": self.account_ak,
            "EMAILADDRESS": self.email_address,
        }


@dataclass
class GenerateMagicLinkResponse:
    """Generate magic link response structure.
    
    Attributes:
        error: Error information
        magic_link: Magic link (if no error for all tickets)
        magic_link_ticket_error_list: Magic link ticket error list
    """
    
    error: Error
    magic_link: Optional[str] = None
    magic_link_ticket_error_list: Optional[MagicLinkTicketErrorList] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "GenerateMagicLinkResponse":
        """Create GenerateMagicLinkResponse from API response dictionary."""
        error_list = None
        if "MAGICLINKTICKETERRORLIST" in data:
            error_list = MagicLinkTicketErrorList.from_dict(data["MAGICLINKTICKETERRORLIST"])
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            magic_link=data.get("MAGICLINK"),
            magic_link_ticket_error_list=error_list,
        )


@dataclass
class SendMagicLinkRequest:
    """Send magic link request structure.
    
    Attributes:
        magic_link_ticket_list: Magic link ticket list
        email_address: Email address
        association_type: Association type (A=Association, R=Reassociation)
        account_ak: Account AK
        doc_template_ak: Document template AK
    """
    
    magic_link_ticket_list: MagicLinkTicketList
    email_address: str
    association_type: str
    account_ak: str
    doc_template_ak: str
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "MAGICLINKTICKETLIST": self.magic_link_ticket_list.to_dict(),
            "EMAILADDRESS": self.email_address,
            "ASSOCIATIONTYPE": self.association_type,
            "ACCOUNTAK": self.account_ak,
            "DOCTEMPLATEAK": self.doc_template_ak,
        }


@dataclass
class SendMagicLinkResponse:
    """Send magic link response structure.
    
    Attributes:
        error: Error information
        magic_link_ticket_error_list: Magic link ticket error list
    """
    
    error: Error
    magic_link_ticket_error_list: Optional[MagicLinkTicketErrorList] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SendMagicLinkResponse":
        """Create SendMagicLinkResponse from API response dictionary."""
        error_list = None
        if "MAGICLINKTICKETERRORLIST" in data:
            error_list = MagicLinkTicketErrorList.from_dict(data["MAGICLINKTICKETERRORLIST"])
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            magic_link_ticket_error_list=error_list,
        )


@dataclass
class DynamicQrCodePhoneAssociationRequest:
    """Dynamic QR code phone association request structure.
    
    Attributes:
        magic_link: Magic link
        phone_owner: Phone owner information
    """
    
    magic_link: str
    phone_owner: DynamicQrCodePhoneAssociation
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "MAGICLINK": self.magic_link,
            "PHONEOWNER": self.phone_owner.to_dict(),
        }


@dataclass
class DynamicQrCodePhoneAssociationResponse:
    """Dynamic QR code phone association response structure.
    
    Attributes:
        error: Error information
        magic_link_ticket_error_list: Magic link ticket error list
    """
    
    error: Error
    magic_link_ticket_error_list: Optional[MagicLinkTicketErrorList] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "DynamicQrCodePhoneAssociationResponse":
        """Create DynamicQrCodePhoneAssociationResponse from API response dictionary."""
        error_list = None
        if "MAGICLINKTICKETERRORLIST" in data:
            error_list = MagicLinkTicketErrorList.from_dict(data["MAGICLINKTICKETERRORLIST"])
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            magic_link_ticket_error_list=error_list,
        )


@dataclass
class DynamicQrCodePhoneReassociationRequest:
    """Dynamic QR code phone reassociation request structure.
    
    Attributes:
        magic_link: Magic link
        phone_owner: Phone owner information
    """
    
    magic_link: str
    phone_owner: DynamicQrCodePhoneAssociation
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "MAGICLINK": self.magic_link,
            "PHONEOWNER": self.phone_owner.to_dict(),
        }


@dataclass
class DynamicQrCodePhoneReassociationResponse:
    """Dynamic QR code phone reassociation response structure.
    
    Attributes:
        error: Error information
        magic_link_ticket_error_list: Magic link ticket error list
    """
    
    error: Error
    magic_link_ticket_error_list: Optional[MagicLinkTicketErrorList] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "DynamicQrCodePhoneReassociationResponse":
        """Create DynamicQrCodePhoneReassociationResponse from API response dictionary."""
        error_list = None
        if "MAGICLINKTICKETERRORLIST" in data:
            error_list = MagicLinkTicketErrorList.from_dict(data["MAGICLINKTICKETERRORLIST"])
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            magic_link_ticket_error_list=error_list,
        )


@dataclass
class ReadTicketByIdResponse:
    """Read ticket by ID response structure.
    
    Attributes:
        error: Error information
        ticket: Ticket information (Dict for complex TICKETFULL structure)
    """
    
    error: Error
    ticket: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadTicketByIdResponse":
        """Create ReadTicketByIdResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ticket=data.get("TICKET"),
        )


@dataclass
class ReadTicketByMediaCodeResponse:
    """Read ticket by media code response structure.
    
    Attributes:
        error: Error information
        ticket_list: Ticket list (Dict for complex TICKETFULL structure)
    """
    
    error: Error
    ticket_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadTicketByMediaCodeResponse":
        """Create ReadTicketByMediaCodeResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ticket_list=data.get("TICKETLIST"),
        )


@dataclass
class ReadTicketUsageResponse:
    """Read ticket usage response structure.
    
    Attributes:
        error: Error information
        usage_recap: Usage recap (Dict for complex structure)
        usage_list: Usage list (Dict for complex structure)
    """
    
    error: Error
    usage_recap: Optional[Dict[str, Any]] = None
    usage_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadTicketUsageResponse":
        """Create ReadTicketUsageResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            usage_recap=data.get("USAGERECAP"),
            usage_list=data.get("USAGELIST"),
        )


@dataclass
class UsageItem:
    """Usage item structure.
    
    Attributes:
        usage_type: Usage type (1=Entry, 2=Reentry, 3=CrossOver, 4=Transit, 10=Exit, etc.)
    """
    
    usage_type: int
    
    @classmethod
    def from_dict(cls, data: dict) -> "UsageItem":
        """Create UsageItem from API response dictionary."""
        return cls(
            usage_type=data.get("USAGETYPE", 0),
        )
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "USAGETYPE": self.usage_type,
        }


@dataclass
class ReadTicketUsageByRequest:
    """Read ticket usage by request structure.
    
    Attributes:
        ticket: Ticket identifier (either media_code or ticket_id)
        usage_date: Usage date filter
        usage_type_list: Usage type list
    """
    
    ticket: Dict[str, Any]  # Either MEDIACODE or TICKETID
    usage_date: Optional[BaseDateFilter] = None
    usage_type_list: Optional[List[UsageItem]] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        result = {"TICKET": self.ticket}
        if self.usage_date:
            result["USAGEDATE"] = self.usage_date.to_dict()
        if self.usage_type_list:
            result["USAGETYPELIST"] = {
                "USAGEITEM": [u.to_dict() for u in self.usage_type_list]
            }
        return result


@dataclass
class ReadTicketUsageByResponse:
    """Read ticket usage by response structure.
    
    Attributes:
        error: Error information
        ticket_usage_list: Ticket usage list (Dict for complex structure)
    """
    
    error: Error
    ticket_usage_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadTicketUsageByResponse":
        """Create ReadTicketUsageByResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ticket_usage_list=data.get("TICKETUSAGELIST"),
        )


@dataclass
class BlockTicketByIdResponse:
    """Block ticket by ID response structure.
    
    Attributes:
        error: Error information
        ticket_id: Ticket ID
    """
    
    error: Error
    ticket_id: Optional[int] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "BlockTicketByIdResponse":
        """Create BlockTicketByIdResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ticket_id=data.get("TICKETID"),
        )


@dataclass
class UnBlockTicketByIdResponse:
    """Unblock ticket by ID response structure.
    
    Attributes:
        error: Error information
        ticket_id: Ticket ID
    """
    
    error: Error
    ticket_id: int
    
    @classmethod
    def from_dict(cls, data: dict) -> "UnBlockTicketByIdResponse":
        """Create UnBlockTicketByIdResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ticket_id=data.get("TICKETID", 0),
        )


@dataclass
class BlockTicketByMediaCodeResponse:
    """Block ticket by media code response structure.
    
    Attributes:
        error: Error information
        media_code: Media code (Dict for complex MEDIACODEBASE structure)
    """
    
    error: Error
    media_code: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "BlockTicketByMediaCodeResponse":
        """Create BlockTicketByMediaCodeResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            media_code=data.get("MEDIACODE"),
        )


@dataclass
class UnBlockTicketByMediaCodeResponse:
    """Unblock ticket by media code response structure.
    
    Attributes:
        error: Error information
        media_code: Media code (Dict for complex MEDIACODEBASE structure)
    """
    
    error: Error
    media_code: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "UnBlockTicketByMediaCodeResponse":
        """Create UnBlockTicketByMediaCodeResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            media_code=data.get("MEDIACODE"),
        )


@dataclass
class BlockMediaByMediaCodeResponse:
    """Block media by media code response structure.
    
    Attributes:
        error: Error information
        media_code: Media code (Dict for complex MEDIACODEBASE structure)
    """
    
    error: Error
    media_code: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "BlockMediaByMediaCodeResponse":
        """Create BlockMediaByMediaCodeResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            media_code=data.get("MEDIACODE"),
        )


@dataclass
class UnBlockMediaByMediaCodeResponse:
    """Unblock media by media code response structure.
    
    Attributes:
        error: Error information
        media_code: Media code (Dict for complex MEDIACODEBASE structure)
    """
    
    error: Error
    media_code: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "UnBlockMediaByMediaCodeResponse":
        """Create UnBlockMediaByMediaCodeResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            media_code=data.get("MEDIACODE"),
        )


@dataclass
class PrintPdfTicketResponse:
    """Print PDF ticket response structure.
    
    Attributes:
        error: Error information
        pdf: PDF content (hex binary)
    """
    
    error: Error
    pdf: Optional[bytes] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "PrintPdfTicketResponse":
        """Create PrintPdfTicketResponse from API response dictionary."""
        pdf_data = data.get("PDF")
        if pdf_data:
            # Convert hex string to bytes if needed
            if isinstance(pdf_data, str):
                pdf_data = bytes.fromhex(pdf_data)
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            pdf=pdf_data,
        )


@dataclass
class PrintPdfTicketSinglePageFile:
    """Print PDF ticket single page file structure.
    
    Attributes:
        media_code_list: Media code list
        pdf: PDF content (hex binary)
    """
    
    media_code_list: List[Dict[str, Any]]
    pdf: bytes
    
    @classmethod
    def from_dict(cls, data: dict) -> "PrintPdfTicketSinglePageFile":
        """Create PrintPdfTicketSinglePageFile from API response dictionary."""
        media_codes = []
        if "MEDIACODELIST" in data and "MEDIACODE" in data["MEDIACODELIST"]:
            mc_list = data["MEDIACODELIST"]["MEDIACODE"]
            if isinstance(mc_list, list):
                media_codes = mc_list
            else:
                media_codes = [mc_list]
        pdf_data = data.get("PDF")
        if pdf_data and isinstance(pdf_data, str):
            pdf_data = bytes.fromhex(pdf_data)
        return cls(
            media_code_list=media_codes,
            pdf=pdf_data or b"",
        )


@dataclass
class PrintPdfTicketSinglePageResponse:
    """Print PDF ticket single page response structure.
    
    Attributes:
        error: Error information
        file_list: File list
    """
    
    error: Error
    file_list: List[PrintPdfTicketSinglePageFile]
    
    @classmethod
    def from_dict(cls, data: dict) -> "PrintPdfTicketSinglePageResponse":
        """Create PrintPdfTicketSinglePageResponse from API response dictionary."""
        files = []
        if "FILELIST" in data and "FILE" in data["FILELIST"]:
            file_list = data["FILELIST"]["FILE"]
            if isinstance(file_list, list):
                files = [PrintPdfTicketSinglePageFile.from_dict(f) for f in file_list]
            else:
                files = [PrintPdfTicketSinglePageFile.from_dict(file_list)]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            file_list=files,
        )


@dataclass
class UpdateTicketValidityByIdRequest:
    """Update ticket validity by ID request structure.
    
    Attributes:
        ticket_id: Ticket ID
        active_from: Active from date
        active_to: Active to date
    """
    
    ticket_id: int
    active_from: str
    active_to: str
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "TICKETID": self.ticket_id,
            "ACTIVEFROM": self.active_from,
            "ACTIVETO": self.active_to,
        }


@dataclass
class UpdateTicketValidityByMediaCodeRequest:
    """Update ticket validity by media code request structure.
    
    Attributes:
        media_code: Media code
        active_from: Active from date
        active_to: Active to date
    """
    
    media_code: str
    active_from: str
    active_to: str
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "MEDIACODE": self.media_code,
            "ACTIVEFROM": self.active_from,
            "ACTIVETO": self.active_to,
        }


@dataclass
class UpdateTicketValidityResponse:
    """Update ticket validity response structure.
    
    Attributes:
        error: Error information
        ticket_id: Ticket ID
        active_from: Active from date
        active_to: Active to date
        media_code_list: Media code list
    """
    
    error: Error
    ticket_id: Optional[int] = None
    active_from: Optional[str] = None
    active_to: Optional[str] = None
    media_code_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "UpdateTicketValidityResponse":
        """Create UpdateTicketValidityResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ticket_id=data.get("TICKETID"),
            active_from=data.get("ACTIVEFROM"),
            active_to=data.get("ACTIVETO"),
            media_code_list=data.get("MEDIACODELIST"),
        )


@dataclass
class ReadRenewInfoByMediaCodeResponse:
    """Read renew info by media code response structure.
    
    Attributes:
        error: Error information
        quick_renew_settings: Quick renew settings
    """
    
    error: Error
    quick_renew_settings: Optional[QuickInfo] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadRenewInfoByMediaCodeResponse":
        """Create ReadRenewInfoByMediaCodeResponse from API response dictionary."""
        quick_info = None
        if "QUICKRENEWSETTINGS" in data:
            quick_info = QuickInfo.from_dict(data["QUICKRENEWSETTINGS"])
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            quick_renew_settings=quick_info,
        )


@dataclass
class ReadUpgradeInfoByMediaCodeResponse:
    """Read upgrade info by media code response structure.
    
    Attributes:
        error: Error information
        quick_upgrade_settings: Quick upgrade settings
    """
    
    error: Error
    quick_upgrade_settings: Optional[QuickInfo] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadUpgradeInfoByMediaCodeResponse":
        """Create ReadUpgradeInfoByMediaCodeResponse from API response dictionary."""
        quick_info = None
        if "QUICKUPGRADESETTINGS" in data:
            quick_info = QuickInfo.from_dict(data["QUICKUPGRADESETTINGS"])
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            quick_upgrade_settings=quick_info,
        )


@dataclass
class ReadUpgradeInfoRequest:
    """Read upgrade info request structure.
    
    Attributes:
        ticket_id: Ticket ID (optional)
        media_code: Media code (optional)
    """
    
    ticket_id: Optional[int] = None
    media_code: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        if self.ticket_id is not None:
            return {"TICKETID": self.ticket_id}
        elif self.media_code:
            return {"MEDIACODE": self.media_code}
        return {}


@dataclass
class ReadUpgradeInfoResponse:
    """Read upgrade info response structure.
    
    Attributes:
        error: Error information
        ticket_item_list_upg: Ticket item list upgrade (Dict for complex structure)
    """
    
    error: Error
    ticket_item_list_upg: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadUpgradeInfoResponse":
        """Create ReadUpgradeInfoResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ticket_item_list_upg=data.get("TICKETITEMLISTUPG"),
        )


@dataclass
class ReadRenewInfoRequest:
    """Read renew info request structure.
    
    Attributes:
        ticket_id: Ticket ID (optional)
        media_code: Media code (optional)
    """
    
    ticket_id: Optional[int] = None
    media_code: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        if self.ticket_id is not None:
            return {"TICKETID": self.ticket_id}
        elif self.media_code:
            return {"MEDIACODE": self.media_code}
        return {}


@dataclass
class ReadRenewInfoResponse:
    """Read renew info response structure.
    
    Attributes:
        error: Error information
        ticket_item_list_rnw: Ticket item list renew (Dict for complex structure)
    """
    
    error: Error
    ticket_item_list_rnw: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadRenewInfoResponse":
        """Create ReadRenewInfoResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ticket_item_list_rnw=data.get("TICKETITEMLISTRNW"),
        )


@dataclass
class ReadChangePerfInfoRequest:
    """Read change performance info request structure.
    
    Attributes:
        ticket_id: Ticket ID (optional)
        media_code: Media code (optional)
    """
    
    ticket_id: Optional[int] = None
    media_code: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        if self.ticket_id is not None:
            return {"TICKETID": self.ticket_id}
        elif self.media_code:
            return {"MEDIACODE": self.media_code}
        return {}


@dataclass
class ReadChangePerfInfoResponse:
    """Read change performance info response structure.
    
    Attributes:
        error: Error information
        ticket_item_list_cngp: Ticket item list change performance (Dict for complex structure)
    """
    
    error: Error
    ticket_item_list_cngp: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadChangePerfInfoResponse":
        """Create ReadChangePerfInfoResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ticket_item_list_cngp=data.get("TICKETITEMLISTCNGP"),
        )


@dataclass
class AddTicketNoteByMediaCodeRequest:
    """Add ticket note by media code request structure.
    
    Attributes:
        media_code: Media code
        note: Note (max 500 characters)
    """
    
    media_code: str
    note: str
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "MEDIACODE": self.media_code,
            "NOTE": self.note[:500],  # Enforce max length
        }


@dataclass
class AddTicketNoteByMediaCodeResponse:
    """Add ticket note by media code response structure.
    
    Attributes:
        error: Error information
        media_code: Media code
        note: Note
    """
    
    error: Error
    media_code: Optional[str] = None
    note: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "AddTicketNoteByMediaCodeResponse":
        """Create AddTicketNoteByMediaCodeResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            media_code=data.get("MEDIACODE"),
            note=data.get("NOTE"),
        )


@dataclass
class AddTicketNoteByIdRequest:
    """Add ticket note by ID request structure.
    
    Attributes:
        ticket_id: Ticket ID
        note: Note (max 500 characters)
    """
    
    ticket_id: int
    note: str
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "TICKETID": self.ticket_id,
            "NOTE": self.note[:500],  # Enforce max length
        }


@dataclass
class AddTicketNoteByIdResponse:
    """Add ticket note by ID response structure.
    
    Attributes:
        error: Error information
        ticket_id: Ticket ID
        note: Note
    """
    
    error: Error
    ticket_id: Optional[int] = None
    note: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "AddTicketNoteByIdResponse":
        """Create AddTicketNoteByIdResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ticket_id=data.get("TICKETID"),
            note=data.get("NOTE"),
        )


@dataclass
class PerformanceChangeItem:
    """Performance change item structure.
    
    Attributes:
        from_perf: From performance AK (optional)
        to_perf: To performance AK (optional)
    """
    
    from_perf: Optional[str] = None
    to_perf: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        result = {}
        if self.from_perf:
            result["FROM"] = self.from_perf
        if self.to_perf:
            result["TO"] = self.to_perf
        return result


@dataclass
class ChangePerformanceRequest:
    """Change performance request structure.
    
    Attributes:
        ticket_id: Ticket ID (optional)
        media_code: Media code (optional)
        performance_list: Performance list
    """
    
    performance_list: List[PerformanceChangeItem]
    ticket_id: Optional[int] = None
    media_code: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        result = {}
        if self.ticket_id is not None:
            result["TICKETID"] = self.ticket_id
        elif self.media_code:
            result["MEDIACODE"] = self.media_code
        result["PERFORMANCELIST"] = {
            "PERFORMANCE": [p.to_dict() for p in self.performance_list]
        }
        return result


@dataclass
class ChangePerformanceResponse:
    """Change performance response structure.
    
    Attributes:
        error: Error information
        ticket_id: Ticket ID
        performance_list: Performance list
    """
    
    error: Error
    ticket_id: Optional[int] = None
    performance_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ChangePerformanceResponse":
        """Create ChangePerformanceResponse from API response dictionary."""
        perf_list = None
        if "PERFORMANCELIST" in data and "PERFORMANCE" in data["PERFORMANCELIST"]:
            perf_list = data["PERFORMANCELIST"]["PERFORMANCE"]
            if not isinstance(perf_list, list):
                perf_list = [perf_list]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ticket_id=data.get("TICKETID"),
            performance_list=perf_list,
        )


@dataclass
class TryChangePerformanceRequest:
    """Try change performance request structure.
    
    Attributes:
        ticket_id: Ticket ID (optional)
        media_code: Media code (optional)
        performance_list: Performance list
    """
    
    performance_list: List[PerformanceChangeItem]
    ticket_id: Optional[int] = None
    media_code: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        result = {}
        if self.ticket_id is not None:
            result["TICKETID"] = self.ticket_id
        elif self.media_code:
            result["MEDIACODE"] = self.media_code
        result["PERFORMANCELIST"] = {
            "PERFORMANCE": [p.to_dict() for p in self.performance_list]
        }
        return result


@dataclass
class TryChangePerformanceResponse:
    """Try change performance response structure.
    
    Attributes:
        error: Error information
        ticket_id: Ticket ID
        performance_list: Performance list
    """
    
    error: Error
    ticket_id: Optional[int] = None
    performance_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "TryChangePerformanceResponse":
        """Create TryChangePerformanceResponse from API response dictionary."""
        perf_list = None
        if "PERFORMANCELIST" in data and "PERFORMANCE" in data["PERFORMANCELIST"]:
            perf_list = data["PERFORMANCELIST"]["PERFORMANCE"]
            if not isinstance(perf_list, list):
                perf_list = [perf_list]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ticket_id=data.get("TICKETID"),
            performance_list=perf_list,
        )


@dataclass
class ChangePerformanceSimpleRequest:
    """Change performance simple request structure.
    
    Attributes:
        media_code: Media code
        performance_list: Performance list (optional)
    """
    
    media_code: str
    performance_list: Optional[List[Dict[str, Any]]] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        result = {"MEDIACODE": self.media_code}
        if self.performance_list:
            result["PERFORMANCELIST"] = {
                "PERFORMANCE": self.performance_list
            }
        return result


@dataclass
class ChangeAccountRequest:
    """Change account request structure.
    
    Attributes:
        performance_ak: Performance AK (optional)
        ticket_id: Ticket ID (optional)
        media_code: Media code (optional)
        account_ak: Account AK
    """
    
    account_ak: str
    performance_ak: Optional[str] = None
    ticket_id: Optional[int] = None
    media_code: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        result = {"ACCOUNTAK": self.account_ak}
        if self.performance_ak:
            result["PERFORMANCEAK"] = self.performance_ak
        if self.ticket_id is not None:
            result["TICKETID"] = self.ticket_id
        elif self.media_code:
            result["MEDIACODE"] = self.media_code
        return result


@dataclass
class ChangeAccountResponse:
    """Change account response structure.
    
    Attributes:
        error: Error information
        account_ak: Account AK
    """
    
    error: Error
    account_ak: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ChangeAccountResponse":
        """Create ChangeAccountResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            account_ak=data.get("ACCOUNTAK"),
        )


@dataclass
class ReadRedeemableProductRequest:
    """Read redeemable product request structure.
    
    Attributes:
        ticket_id: Ticket ID (optional)
        media_code: Media code (optional)
    """
    
    ticket_id: Optional[int] = None
    media_code: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        if self.ticket_id is not None:
            return {"TICKETID": self.ticket_id}
        elif self.media_code:
            return {"MEDIACODE": self.media_code}
        return {}


@dataclass
class ReadRedeemableProductResponse:
    """Read redeemable product response structure.
    
    Attributes:
        error: Error information
        redeemable_product_list: Redeemable product list (Dict for complex structure)
    """
    
    error: Error
    redeemable_product_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadRedeemableProductResponse":
        """Create ReadRedeemableProductResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            redeemable_product_list=data.get("REDEEMABLEPRODUCTLIST"),
        )


@dataclass
class ReadRedeemableProductV2Response:
    """Read redeemable product V2 response structure.
    
    Attributes:
        error: Error information
        media_code: Media code
        ticket_redeem_prod_list: Ticket redeem product list (Dict for complex structure)
    """
    
    error: Error
    media_code: str
    ticket_redeem_prod_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadRedeemableProductV2Response":
        """Create ReadRedeemableProductV2Response from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            media_code=data.get("MEDIACODE", ""),
            ticket_redeem_prod_list=data.get("TICKETREDEEMPRODLIST"),
        )


@dataclass
class RedeemProductRequest:
    """Redeem product request structure.
    
    Attributes:
        ticket_id: Ticket ID (optional)
        media_code: Media code (optional)
        matrix_cell_ak: Matrix cell AK
        ext_redemption_code: External redemption code (optional)
    """
    
    matrix_cell_ak: str
    ticket_id: Optional[int] = None
    media_code: Optional[str] = None
    ext_redemption_code: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        result = {"MATRIXCELLAK": self.matrix_cell_ak}
        if self.ticket_id is not None:
            result["TICKETID"] = self.ticket_id
        elif self.media_code:
            result["MEDIACODE"] = self.media_code
        if self.ext_redemption_code:
            result["EXTREDEMPTIONCODE"] = self.ext_redemption_code
        return result


@dataclass
class RedeemProductResponse:
    """Redeem product response structure.
    
    Attributes:
        error: Error information
        redeemable_product_list: Redeemable product list (Dict for complex structure)
    """
    
    error: Error
    redeemable_product_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "RedeemProductResponse":
        """Create RedeemProductResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            redeemable_product_list=data.get("REDEEMABLEPRODUCTLIST"),
        )


@dataclass
class VoidRedeemProductRequest:
    """Void redeem product request structure.
    
    Attributes:
        ticket_id: Ticket ID (optional)
        media_code: Media code (optional)
        matrix_cell_ak: Matrix cell AK
        ext_redemption_code: External redemption code (optional)
    """
    
    matrix_cell_ak: str
    ticket_id: Optional[int] = None
    media_code: Optional[str] = None
    ext_redemption_code: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        result = {}
        if self.ticket_id is not None:
            result["TICKETID"] = self.ticket_id
        elif self.media_code:
            result["MEDIACODE"] = self.media_code
        if self.ext_redemption_code:
            result["EXTREDEMPTIONCODE"] = self.ext_redemption_code
        return result


@dataclass
class VoidRedeemProductResponse:
    """Void redeem product response structure.
    
    Attributes:
        error: Error information
        redeemable_product_list: Redeemable product list (Dict for complex structure)
    """
    
    error: Error
    redeemable_product_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "VoidRedeemProductResponse":
        """Create VoidRedeemProductResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            redeemable_product_list=data.get("REDEEMABLEPRODUCTLIST"),
        )


@dataclass
class ReadRedeemableEntitlementRequest:
    """Read redeemable entitlement request structure.
    
    Attributes:
        media_code: Media code
    """
    
    media_code: str


@dataclass
class ReadRedeemableEntitlementResponse:
    """Read redeemable entitlement response structure.
    
    Attributes:
        error: Error information
        media_code: Media code
        ticket_redeem_list: Ticket redeem list (Dict for complex structure)
    """
    
    error: Error
    media_code: str
    ticket_redeem_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadRedeemableEntitlementResponse":
        """Create ReadRedeemableEntitlementResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            media_code=data.get("MEDIACODE", ""),
            ticket_redeem_list=data.get("TICKETREDEEMLIST"),
        )


@dataclass
class ReadRedeemableEntitlementV2Request:
    """Read redeemable entitlement V2 request structure.
    
    Attributes:
        media_code: Media code (optional)
        date: Date filter (optional)
        time: Time filter (optional)
        request_type: Request type (0=Entitlement, 1=Sheets)
        sheet_ak: Sheet AK (optional)
    """
    
    media_code: Optional[str] = None
    date: Optional[BaseDateFilter] = None
    time: Optional[BaseTimeFilter] = None
    request_type: int = 0
    sheet_ak: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        result = {"REQUESTTYPE": self.request_type}
        if self.media_code:
            result["MEDIACODE"] = self.media_code
        if self.date:
            result["DATE"] = self.date.to_dict()
        if self.time:
            result["TIME"] = self.time.to_dict()
        if self.sheet_ak:
            result["SHEETAK"] = self.sheet_ak
        return result


@dataclass
class ReadRedeemableEntitlementV2Response:
    """Read redeemable entitlement V2 response structure.
    
    Attributes:
        error: Error information
        media_code: Media code
        redeem_list: Redeem list (Dict for complex structure)
    """
    
    error: Error
    media_code: str
    redeem_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadRedeemableEntitlementV2Response":
        """Create ReadRedeemableEntitlementV2Response from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            media_code=data.get("MEDIACODE", ""),
            redeem_list=data.get("REDEEMLIST"),
        )


@dataclass
class ReadRedeemableEntitlementV3Request:
    """Read redeemable entitlement V3 request structure.
    
    Attributes:
        ticket_id: Ticket ID (optional)
        media_code: Media code (optional)
    """
    
    ticket_id: Optional[int] = None
    media_code: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        if self.ticket_id is not None:
            return {"TICKETID": self.ticket_id}
        elif self.media_code:
            return {"MEDIACODE": self.media_code}
        return {}


@dataclass
class ReadRedeemableEntitlementV3Response:
    """Read redeemable entitlement V3 response structure.
    
    Attributes:
        error: Error information
        media_code: Media code
        ticket_redeem_list: Ticket redeem list (Dict for complex structure)
    """
    
    error: Error
    media_code: str
    ticket_redeem_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadRedeemableEntitlementV3Response":
        """Create ReadRedeemableEntitlementV3Response from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            media_code=data.get("MEDIACODE", ""),
            ticket_redeem_list=data.get("TICKETREDEEMLIST"),
        )


@dataclass
class ReadPerformanceTicketRequest:
    """Read performance ticket request structure.
    
    Attributes:
        performance_ak: Performance AK
        start_date_time: Start date time
        ticket_quantity: Ticket quantity
    """
    
    performance_ak: str
    start_date_time: str
    ticket_quantity: int
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "PERFORMANCEAK": self.performance_ak,
            "STARTDATETIME": self.start_date_time,
            "TICKETQUANTITY": self.ticket_quantity,
        }


@dataclass
class ReadPerformanceTicketResponse:
    """Read performance ticket response structure.
    
    Attributes:
        error: Error information
        start_date_time: Start date time
        performance_ak: Performance AK
        ticket_quantity: Ticket quantity
        has_more: Has more flag
        ticket_export_list: Ticket export list
    """
    
    error: Error
    start_date_time: str
    performance_ak: str
    ticket_quantity: int
    has_more: bool
    ticket_export_list: Optional[TicketExportList] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadPerformanceTicketResponse":
        """Create ReadPerformanceTicketResponse from API response dictionary."""
        export_list = None
        if "TICKETEXPORTLIST" in data:
            export_list = TicketExportList.from_dict(data["TICKETEXPORTLIST"])
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            start_date_time=data.get("STARTDATETIME", ""),
            performance_ak=data.get("PERFORMANCEAK", ""),
            ticket_quantity=data.get("TICKETQUANTITY", 0),
            has_more=data.get("HASMORE", False),
            ticket_export_list=export_list,
        )


@dataclass
class ReadPerformanceTicketFullRequest:
    """Read performance ticket full request structure.
    
    Attributes:
        performance_ak: Performance AK
        start_date_time: Start date time (Dict with DATE and optional TIME)
        ticket_quantity: Ticket quantity
    """
    
    performance_ak: str
    start_date_time: Dict[str, Any]
    ticket_quantity: int
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "PERFORMANCEAK": self.performance_ak,
            "STARTDATETIME": self.start_date_time,
            "TICKETQUANTITY": self.ticket_quantity,
        }


@dataclass
class ReadPerformanceTicketFullResponse:
    """Read performance ticket full response structure.
    
    Attributes:
        error: Error information
        start_date_time: Start date time
        performance_ak: Performance AK
        ticket_quantity: Ticket quantity
        has_more: Has more flag
        ticket_export_list_full: Ticket export list full
    """
    
    error: Error
    start_date_time: str
    performance_ak: str
    ticket_quantity: int
    has_more: bool
    ticket_export_list_full: Optional[TicketExportListFull] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadPerformanceTicketFullResponse":
        """Create ReadPerformanceTicketFullResponse from API response dictionary."""
        export_list = None
        if "TICKETEXPORTLISTFULL" in data:
            export_list = TicketExportListFull.from_dict(data["TICKETEXPORTLISTFULL"])
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            start_date_time=data.get("STARTDATETIME", ""),
            performance_ak=data.get("PERFORMANCEAK", ""),
            ticket_quantity=data.get("TICKETQUANTITY", 0),
            has_more=data.get("HASMORE", False),
            ticket_export_list_full=export_list,
        )


@dataclass
class SwapMediaRequest:
    """Swap media request structure.
    
    Attributes:
        new: New media information (Dict for complex structure)
        old: Old media information (Dict for complex structure)
    """
    
    new: Dict[str, Any]
    old: Dict[str, Any]
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "NEW": self.new,
            "OLD": self.old,
        }


@dataclass
class SwapMediaResponse:
    """Swap media response structure.
    
    Attributes:
        error: Error information
        account: Account information (Dict for complex BASICINFO structure)
        media_code: Media code (Dict for complex MEDIACODEBASE structure)
        performance: Performance information (Dict for complex PERFORMANCEBASE structure)
    """
    
    error: Error
    account: Optional[Dict[str, Any]] = None
    media_code: Optional[Dict[str, Any]] = None
    performance: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SwapMediaResponse":
        """Create SwapMediaResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            account=data.get("ACCOUNT"),
            media_code=data.get("MEDIACODE"),
            performance=data.get("PERFORMANCE"),
        )


@dataclass
class SwapMultipleMediaItem:
    """Swap multiple media item structure.
    
    Attributes:
        from_media: From media (either MEDIACODE or TICKETID)
        to_media_code: To media code
    """
    
    from_media: Dict[str, Any]
    to_media_code: str
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "FROM": self.from_media,
            "TO": {"MEDIACODE": self.to_media_code},
        }


@dataclass
class SwapMultipleMediaRequest:
    """Swap multiple media request structure.
    
    Attributes:
        swap_item_list: Swap item list
    """
    
    swap_item_list: List[SwapMultipleMediaItem]
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "SWAPITEMLIST": {
                "SWAPITEM": [item.to_dict() for item in self.swap_item_list]
            }
        }


@dataclass
class SwapMultipleMediaResponse:
    """Swap multiple media response structure.
    
    Attributes:
        error: Error information
        swap_item_list: Swap item list
    """
    
    error: Error
    swap_item_list: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "SwapMultipleMediaResponse":
        """Create SwapMultipleMediaResponse from API response dictionary."""
        items = []
        if "SWAPITEMLIST" in data and "SWAPITEM" in data["SWAPITEMLIST"]:
            item_list = data["SWAPITEMLIST"]["SWAPITEM"]
            if isinstance(item_list, list):
                items = item_list
            else:
                items = [item_list]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            swap_item_list=items,
        )


@dataclass
class FindAllTicketPackagesResponse:
    """Find all ticket packages response structure.
    
    Attributes:
        error: Error information
        ticket_package_list: Ticket package list (Dict for complex structure)
    """
    
    error: Error
    ticket_package_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllTicketPackagesResponse":
        """Create FindAllTicketPackagesResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ticket_package_list=data.get("TICKETPACKAGELIST"),
        )


@dataclass
class SaveExtendedInfoRequest:
    """Save extended info request structure.
    
    Attributes:
        field_list: Field list (Dict for complex FIELDLIST structure)
        extended_info_ak: Extended info AK (optional)
        dmg_category_ak: DMG category AK
        image_list: Image list (optional, Dict for complex structure)
        attachment_list: Attachment list (optional, Dict for complex structure)
    """
    
    field_list: Dict[str, Any]
    dmg_category_ak: str
    extended_info_ak: Optional[str] = None
    image_list: Optional[Dict[str, Any]] = None
    attachment_list: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        result = {
            "FIELDLIST": self.field_list,
            "DMGCATEGORYAK": self.dmg_category_ak,
        }
        if self.extended_info_ak:
            result["EXTENDEDINFOAK"] = self.extended_info_ak
        if self.image_list:
            result["IMAGELIST"] = self.image_list
        if self.attachment_list:
            result["ATTACHMENTLIST"] = self.attachment_list
        return result


@dataclass
class SaveExtendedInfoResponse:
    """Save extended info response structure.
    
    Attributes:
        error: Error information
        extended_info_ak: Extended info AK
        error_list_obj_type: Error list object type (Dict for complex structure)
    """
    
    error: Error
    extended_info_ak: Optional[str] = None
    error_list_obj_type: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SaveExtendedInfoResponse":
        """Create SaveExtendedInfoResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            extended_info_ak=data.get("EXTENDEDINFOAK"),
            error_list_obj_type=data.get("ERRORLISTOBJTYPE"),
        )


@dataclass
class ReadExtendedInfoByAKResponse:
    """Read extended info by AK response structure.
    
    Attributes:
        error: Error information
        extended_info: Extended info (Dict for complex EXTENDEDINFOFULL structure)
    """
    
    error: Error
    extended_info: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadExtendedInfoByAKResponse":
        """Create ReadExtendedInfoByAKResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            extended_info=data.get("EXTENDEDINFO"),
        )


@dataclass
class SearchTicketRequest:
    """Search ticket request structure.
    
    Attributes:
        page_req: Page request (optional)
        ticket_id_list: Ticket ID list (optional)
        media_code_list: Media code list (optional)
        holder_account_ak: Holder account AK (optional)
        reservation_account_ak: Reservation account AK (optional)
        extended_info_ak: Extended info AK (optional)
        active_from: Active from date (optional)
        active_to: Active to date (optional)
        void_type: Void type (optional)
        used: Used flag (optional)
        matrix_cell_ak: Matrix cell AK (optional)
        static_group_list: Static group list (optional)
        performance_ak_list: Performance AK list (optional)
        not_expired: Not expired flag (optional)
        return_num_changed_performance: Return number of changed performance flag (optional)
        return_dynamic_qr_code_details: Return dynamic QR code details flag (optional)
        reservation_or_holder_account_ak: Reservation or holder account AK (optional)
    """
    
    page_req: Optional[PageRequest] = None
    ticket_id_list: Optional[List[int]] = None
    media_code_list: Optional[List[str]] = None
    holder_account_ak: Optional[str] = None
    reservation_account_ak: Optional[str] = None
    extended_info_ak: Optional[str] = None
    active_from: Optional[str] = None
    active_to: Optional[str] = None
    void_type: Optional[int] = None
    used: Optional[int] = None
    matrix_cell_ak: Optional[str] = None
    static_group_list: Optional[List[str]] = None
    performance_ak_list: Optional[List[str]] = None
    not_expired: Optional[bool] = None
    return_num_changed_performance: Optional[bool] = None
    return_dynamic_qr_code_details: Optional[bool] = None
    reservation_or_holder_account_ak: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        result = {}
        if self.page_req:
            page_dict = self.page_req.to_dict()
            result["PAGEREQ"] = page_dict
        if self.ticket_id_list:
            result["TICKETIDLIST"] = {
                "TICKETIDITEM": [{"TICKETID": tid} for tid in self.ticket_id_list]
            }
        if self.media_code_list:
            result["MEDIACODELIST"] = {
                "MEDIACODEITEM": [{"MEDIACODE": mc} for mc in self.media_code_list]
            }
        if self.holder_account_ak:
            result["HOLDERACCOUNTAK"] = self.holder_account_ak
        if self.reservation_account_ak:
            result["RESERVATIONACCOUNTAK"] = self.reservation_account_ak
        if self.extended_info_ak:
            result["EXTENDEDINFOAK"] = self.extended_info_ak
        if self.active_from:
            result["ACTIVEFROM"] = self.active_from
        if self.active_to:
            result["ACTIVETO"] = self.active_to
        if self.void_type is not None:
            result["VOIDTYPE"] = self.void_type
        if self.used is not None:
            result["USED"] = self.used
        if self.matrix_cell_ak:
            result["MATRIXCELLAK"] = self.matrix_cell_ak
        if self.static_group_list:
            result["STATICGROUPLIST"] = {
                "STATICGROUPITEM": [{"CODE": code} for code in self.static_group_list]
            }
        if self.performance_ak_list:
            result["PERFORMANCEAKLIST"] = {
                "PERFORMANCEAKITEM": [{"PERFORMANCEAK": ak} for ak in self.performance_ak_list]
            }
        if self.not_expired is not None:
            result["NOTEXPIRED"] = self.not_expired
        if self.return_num_changed_performance is not None:
            result["RETURNNUMCHANGEDPERFORMANCE"] = self.return_num_changed_performance
        if self.return_dynamic_qr_code_details is not None:
            result["RETURNDYNAMICQRCODEDETAILS"] = self.return_dynamic_qr_code_details
        if self.reservation_or_holder_account_ak:
            result["RESERVATIONORHOLDERACCOUNTAK"] = self.reservation_or_holder_account_ak
        return result


@dataclass
class SearchTicketResponse:
    """Search ticket response structure.
    
    Attributes:
        error: Error information
        page_resp: Page response
        ticket_list: Ticket list (Dict for complex structure with TICKETFULL)
    """
    
    error: Error
    page_resp: PageResponse
    ticket_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchTicketResponse":
        """Create SearchTicketResponse from API response dictionary."""
        tickets = None
        if "TICKETLIST" in data and "TICKET" in data["TICKETLIST"]:
            ticket_list = data["TICKETLIST"]["TICKET"]
            if isinstance(ticket_list, list):
                tickets = ticket_list
            else:
                tickets = [ticket_list]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            page_resp=PageResponse.from_dict(data.get("PAGERESP", {})),
            ticket_list=tickets,
        )


@dataclass
class ChangePerformanceMultipleTicketsRequest:
    """Change performance multiple tickets request structure.
    
    Attributes:
        ticket_list: Ticket list (list of dicts with TICKETID and/or MEDIACODE)
        performance_list: Performance list (list of dicts with FROM and/or TO)
    """
    
    ticket_list: List[Dict[str, Any]]
    performance_list: List[Dict[str, Any]]
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "TICKETLIST": {
                "TICKET": self.ticket_list
            },
            "PERFORMANCELIST": {
                "PERFORMANCE": self.performance_list
            }
        }


@dataclass
class TicketError:
    """Ticket error structure.
    
    Attributes:
        ticket_id: Ticket ID
        code: Error code
        text: Error text
    """
    
    ticket_id: int
    code: int
    text: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "TicketError":
        """Create TicketError from API response dictionary."""
        return cls(
            ticket_id=data.get("TICKETID", 0),
            code=data.get("CODE", 0),
            text=data.get("TEXT", ""),
        )


@dataclass
class ChangePerformanceMultipleTicketsResponse:
    """Change performance multiple tickets response structure.
    
    Attributes:
        error: Error information
        sale_ak: Sale AK
        ticket_list: Ticket list (list of dicts with TICKETERROR, TICKETID, and PERFORMANCELIST)
    """
    
    error: Error
    sale_ak: Optional[str] = None
    ticket_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ChangePerformanceMultipleTicketsResponse":
        """Create ChangePerformanceMultipleTicketsResponse from API response dictionary."""
        tickets = None
        if "TICKETLIST" in data and "TICKET" in data["TICKETLIST"]:
            ticket_list = data["TICKETLIST"]["TICKET"]
            if isinstance(ticket_list, list):
                tickets = ticket_list
            else:
                tickets = [ticket_list]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            sale_ak=data.get("SALEAK"),
            ticket_list=tickets,
        )


@dataclass
class WhiteListTicketItem:
    """White list ticket item structure.
    
    Attributes:
        media_code: Media code
        identifier_type: Identifier type
        matrix_cell_id: Matrix cell ID
        void_type: Void type
        validity_xml: Validity XML
        ticket_id: Ticket ID
        active_from: Active from date time (optional)
        active_to: Active to date time (optional)
        people_count: People count
        used_people_count: Used people count
    """
    
    media_code: str
    identifier_type: int
    matrix_cell_id: int
    void_type: int
    validity_xml: str
    ticket_id: int
    active_from: Optional[str] = None
    active_to: Optional[str] = None
    people_count: int = 0
    used_people_count: int = 0
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        result = {
            "MEDIACODE": self.media_code,
            "IDENTIFIERTYPE": self.identifier_type,
            "MATRIXCELLID": self.matrix_cell_id,
            "VOIDTYPE": self.void_type,
            "VALIDITYXML": self.validity_xml,
            "TICKETID": self.ticket_id,
            "PEOPLECOUNT": self.people_count,
            "USEDPEOPLECOUNT": self.used_people_count,
        }
        if self.active_from:
            result["ACTIVEFROM"] = self.active_from
        if self.active_to:
            result["ACTIVETO"] = self.active_to
        return result


@dataclass
class WhiteListTicketRequest:
    """White list ticket request structure.
    
    Attributes:
        white_list_ticket_list: White list ticket list (max 50 tickets)
    """
    
    white_list_ticket_list: List[WhiteListTicketItem]
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        return {
            "WHITELISTICKETLIST": {
                "WHITELISTICKET": [t.to_dict() for t in self.white_list_ticket_list[:50]]
            }
        }


@dataclass
class WhiteListTicketResponse:
    """White list ticket response structure.
    
    Attributes:
        error: Error information
    """
    
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "WhiteListTicketResponse":
        """Create WhiteListTicketResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
        )


@dataclass
class ReleasePerformanceRequest:
    """Release performance request structure.
    
    Attributes:
        ticket_id: Ticket ID (optional)
        media_code: Media code (optional)
        performance_ak: Performance AK
        seat_id: Seat ID (optional)
    """
    
    performance_ak: str
    ticket_id: Optional[int] = None
    media_code: Optional[str] = None
    seat_id: Optional[int] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        result = {"PERFORMANCEAK": self.performance_ak}
        if self.ticket_id is not None:
            result["TICKETID"] = self.ticket_id
        elif self.media_code:
            result["MEDIACODE"] = self.media_code
        if self.seat_id is not None:
            result["SEATID"] = self.seat_id
        return result


@dataclass
class ReleasePerformanceResponse:
    """Release performance response structure.
    
    Attributes:
        error: Error information
        ticket_id: Ticket ID
        media_code: Media code
        seat_id: Seat ID
    """
    
    error: Error
    ticket_id: Optional[int] = None
    media_code: Optional[str] = None
    seat_id: Optional[int] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReleasePerformanceResponse":
        """Create ReleasePerformanceResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ticket_id=data.get("TICKETID"),
            media_code=data.get("MEDIACODE"),
            seat_id=data.get("SEATID"),
        )


@dataclass
class PrintPdfTicketV2Request:
    """Print PDF ticket V2 request structure.
    
    Attributes:
        sale_ak: Sale AK (optional)
        ticket_id: Ticket ID (optional)
        media_code: Media code (optional)
        force_print_by_matrix_cell_ak: Force print by matrix cell AK (optional)
        force_print_by_stat_code: Force print by statistical group code (optional)
        template_type: Template type (0/1=PDF, 2=Mobile PDF) (optional)
    """
    
    sale_ak: Optional[str] = None
    ticket_id: Optional[int] = None
    media_code: Optional[str] = None
    force_print_by_matrix_cell_ak: Optional[str] = None
    force_print_by_stat_code: Optional[str] = None
    template_type: Optional[int] = None
    
    def to_dict(self) -> dict:
        """Convert to API request dictionary."""
        result = {}
        if self.sale_ak:
            result["SALEAK"] = self.sale_ak
        if self.ticket_id is not None:
            result["TICKETID"] = self.ticket_id
        if self.media_code:
            result["MEDIACODE"] = self.media_code
        if self.force_print_by_matrix_cell_ak:
            result["FORCEPRINTBYMATRIXCELLAK"] = self.force_print_by_matrix_cell_ak
        if self.force_print_by_stat_code:
            result["FORCEPRINTBYSTATCODE"] = self.force_print_by_stat_code
        if self.template_type is not None:
            result["TEMPLATETYPE"] = self.template_type
        return result


@dataclass
class GenerateWalletResponse:
    """Generate wallet response structure.
    
    Attributes:
        error: Error information
        wallet_list: Wallet list (Dict for complex structure)
    """
    
    error: Error
    wallet_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "GenerateWalletResponse":
        """Create GenerateWalletResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            wallet_list=data.get("WALLETLIST"),
        )


@dataclass
class GenerateWalletPackageResponse:
    """Generate wallet package response structure.
    
    Attributes:
        error: Error information
        wallet_package_list: Wallet package list (Dict for complex structure)
    """
    
    error: Error
    wallet_package_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "GenerateWalletPackageResponse":
        """Create GenerateWalletPackageResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            wallet_package_list=data.get("WALLETPACKAGELIST"),
        )
