"""
Type definitions for APTFrictionless.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any


# TODO: Add type definitions based on APTFrictionless.xsd
