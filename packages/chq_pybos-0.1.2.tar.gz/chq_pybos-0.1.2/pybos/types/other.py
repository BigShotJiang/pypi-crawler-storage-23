"""
Type definitions for Other service.

This module provides structured classes for other/miscellaneous operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error


# Request Classes
@dataclass
class ExecStoredProcedureRequest:
    """Request for ExecStoredProcedure operation.
    
    Based on Other.xsd EXECSTOREDPROCEDUREREQ type.
    
    Attributes:
        stored_procedure_name: Name of the stored procedure
        stored_procedure_parameter_list: List of parameters (optional)
    """
    
    stored_procedure_name: str
    stored_procedure_parameter_list: Optional[List[Dict[str, str]]] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"STOREDPROCEDURENAME": self.stored_procedure_name}
        if self.stored_procedure_parameter_list is not None:
            result["STOREDPROCEDUREPARAMETERLIST"] = {
                "STOREDPROCEDUREPARAMETERITEM": self.stored_procedure_parameter_list
            }
        return result


# Response Classes
@dataclass
class ExecStoredProcedureResponse:
    """Response for ExecStoredProcedure operation.
    
    Based on Other.xsd EXECSTOREDPROCEDURERESP type.
    
    Attributes:
        error: Error information
        stored_procedure_result: Stored procedure result (optional)
    """
    
    error: Error
    stored_procedure_result: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ExecStoredProcedureResponse":
        """Create ExecStoredProcedureResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            stored_procedure_result=data.get("STOREDPROCEDURERESULT"),
        )


@dataclass
class RaiseAnAccessViolationResponse:
    """Response for RaiseAnAccessViolation operation.
    
    Based on Other.xsd RAISEANACCESSVIOLATIONRESP type.
    
    Attributes:
        error: Error information
        dummy: Dummy string
    """
    
    error: Error
    dummy: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "RaiseAnAccessViolationResponse":
        """Create RaiseAnAccessViolationResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            dummy=data.get("DUMMY", ""),
        )
