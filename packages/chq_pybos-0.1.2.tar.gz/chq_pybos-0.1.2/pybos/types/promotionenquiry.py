"""
Type definitions for PromotionEnquiry.

This module provides structured classes for promotion operations,
replacing tuple-based parameters with type-safe, self-documenting classes.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, BaseDateFilter, PageRequest, PageResponse
from .accountfinancial import PriceBase


# Base Types
@dataclass
class PromoBase:
    """Base promotion information structure.
    
    Based on PromotionEnquiry.xsd PROMOBASE type.
    
    Attributes:
        type: Promotion type (optional)
        i18n_list: Internationalization list (optional)
        code: Promotion code (optional)
        name: Promotion name (optional)
        use_quota: Whether to use quota (optional)
        category_ak: Category AK (optional)
    """
    
    type: Optional[int] = None
    i18n_list: Optional[Dict[str, Any]] = None
    code: Optional[str] = None
    name: Optional[str] = None
    use_quota: Optional[bool] = None
    category_ak: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "PromoBase":
        """Create PromoBase from API response dictionary."""
        return cls(
            type=data.get("TYPE"),
            i18n_list=data.get("I18NLIST"),
            code=data.get("CODE"),
            name=data.get("NAME"),
            use_quota=data.get("USEQUOTA"),
            category_ak=data.get("CATEGORYAK"),
        )


@dataclass
class Coupon:
    """Coupon information structure.
    
    Based on PromotionEnquiry.xsd COUPON type (extends PROMOBASE).
    
    Attributes:
        type: Promotion type (optional)
        i18n_list: Internationalization list (optional)
        code: Promotion code (optional)
        name: Promotion name (optional)
        use_quota: Whether to use quota (optional)
        category_ak: Category AK (optional)
        coupon_id: Coupon ID (optional)
        rule_list: Rule list
        individual: Individual coupon info (optional)
    """
    
    rule_list: List[Dict[str, Any]]
    type: Optional[int] = None
    i18n_list: Optional[Dict[str, Any]] = None
    code: Optional[str] = None
    name: Optional[str] = None
    use_quota: Optional[bool] = None
    category_ak: Optional[str] = None
    coupon_id: Optional[int] = None
    individual: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "Coupon":
        """Create Coupon from API response dictionary."""
        rule_data = data.get("RULELIST", {}).get("RULE")
        rule_list = []
        if rule_data:
            if isinstance(rule_data, list):
                rule_list = rule_data
            else:
                rule_list = [rule_data]
        return cls(
            type=data.get("TYPE"),
            i18n_list=data.get("I18NLIST"),
            code=data.get("CODE"),
            name=data.get("NAME"),
            use_quota=data.get("USEQUOTA"),
            category_ak=data.get("CATEGORYAK"),
            coupon_id=data.get("COUPONID"),
            rule_list=rule_list,
            individual=data.get("INDIVIDUAL"),
        )


@dataclass
class Package:
    """Package information structure.
    
    Based on PromotionEnquiry.xsd PACKAGE type (extends PROMOBASE).
    
    Attributes:
        type: Promotion type (optional)
        i18n_list: Internationalization list (optional)
        code: Promotion code (optional)
        name: Promotion name (optional)
        use_quota: Whether to use quota (optional)
        category_ak: Category AK (optional)
        package_item_list: Package item list
        package_individual: Package individual (optional)
        status: Status
        max_package_on_pos: Max package on POS
        non_combinable: Non combinable
        sort_order: Sort order
        void_refund_type: Void refund type
        hide_item_price: Hide item price
        stat_group_list: Statistical group list (optional)
        sellable: Sellable (optional)
        max_tickets_to_add: Max tickets to add
    """
    
    package_item_list: List[Dict[str, Any]]
    status: bool
    max_package_on_pos: int
    non_combinable: bool
    sort_order: int
    void_refund_type: int
    hide_item_price: bool
    max_tickets_to_add: int
    type: Optional[int] = None
    i18n_list: Optional[Dict[str, Any]] = None
    code: Optional[str] = None
    name: Optional[str] = None
    use_quota: Optional[bool] = None
    category_ak: Optional[str] = None
    package_individual: Optional[Dict[str, Any]] = None
    stat_group_list: Optional[List[Dict[str, Any]]] = None
    sellable: Optional[bool] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "Package":
        """Create Package from API response dictionary."""
        package_item_data = data.get("PACKAGEITEMLIST", {}).get("PACKAGEITEM")
        package_item_list = []
        if package_item_data:
            if isinstance(package_item_data, list):
                package_item_list = package_item_data
            else:
                package_item_list = [package_item_data]
        stat_group_data = data.get("STATGROUPLIST", {}).get("STATGROUP")
        stat_group_list = None
        if stat_group_data:
            if isinstance(stat_group_data, list):
                stat_group_list = stat_group_data
            else:
                stat_group_list = [stat_group_data]
        return cls(
            type=data.get("TYPE"),
            i18n_list=data.get("I18NLIST"),
            code=data.get("CODE"),
            name=data.get("NAME"),
            use_quota=data.get("USEQUOTA"),
            category_ak=data.get("CATEGORYAK"),
            package_item_list=package_item_list,
            package_individual=data.get("PACKAGEINDIVIDUAL"),
            status=data.get("STATUS", False),
            max_package_on_pos=data.get("MAXPACKAGEONPOS", 0),
            non_combinable=data.get("NONCOMBINABLE", False),
            sort_order=data.get("SORTORDER", 0),
            void_refund_type=data.get("VOIDREFUNDTYPE", 0),
            hide_item_price=data.get("HIDEITEMPRICE", False),
            stat_group_list=stat_group_list,
            sellable=data.get("SELLABLE"),
            max_tickets_to_add=data.get("MAXTICKETSTOADD", 0),
        )


@dataclass
class ExternalPackage:
    """External package information structure.
    
    Based on PromotionEnquiry.xsd EXTERNALPACKAGE type (extends PACKAGE).
    
    Attributes:
        All attributes from Package plus:
        usability: Usability date filter
    """
    
    usability: BaseDateFilter
    package_item_list: List[Dict[str, Any]]
    status: bool
    max_package_on_pos: int
    non_combinable: bool
    sort_order: int
    void_refund_type: int
    hide_item_price: bool
    max_tickets_to_add: int
    type: Optional[int] = None
    i18n_list: Optional[Dict[str, Any]] = None
    code: Optional[str] = None
    name: Optional[str] = None
    use_quota: Optional[bool] = None
    category_ak: Optional[str] = None
    package_individual: Optional[Dict[str, Any]] = None
    stat_group_list: Optional[List[Dict[str, Any]]] = None
    sellable: Optional[bool] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ExternalPackage":
        """Create ExternalPackage from API response dictionary."""
        usability_data = data.get("USABILITY", {})
        package_data = {k: v for k, v in data.items() if k != "USABILITY"}
        package = Package.from_dict(package_data)
        return cls(
            usability=BaseDateFilter.from_dict(usability_data) if usability_data else BaseDateFilter(from_date="", to_date=""),
            package_item_list=package.package_item_list,
            status=package.status,
            max_package_on_pos=package.max_package_on_pos,
            non_combinable=package.non_combinable,
            sort_order=package.sort_order,
            void_refund_type=package.void_refund_type,
            hide_item_price=package.hide_item_price,
            max_tickets_to_add=package.max_tickets_to_add,
            type=package.type,
            i18n_list=package.i18n_list,
            code=package.code,
            name=package.name,
            use_quota=package.use_quota,
            category_ak=package.category_ak,
            package_individual=package.package_individual,
            stat_group_list=package.stat_group_list,
            sellable=package.sellable,
        )


# Request Classes
@dataclass
class ImportIndividualCodeRequest:
    """Request for ImportIndividualCode operation.
    
    Based on PromotionEnquiry.xsd IMPORTINDIVIDUALCODEREQ type.
    
    Attributes:
        promotion_code: Promotion code
        individual_coupon_list: List of individual coupon codes
    """
    
    promotion_code: str
    individual_coupon_list: List[str]
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "PROMOTIONCODE": self.promotion_code,
            "INDIVIDUALCOUPONLIST": {
                "INDIVIDUALCOUPONITEM": [{"CODE": code} for code in self.individual_coupon_list]
            },
        }


@dataclass
class SearchPromotionRequest:
    """Request for SearchPromotion operation.
    
    Based on PromotionEnquiry.xsd SEARCHPROMOTIONREQ type.
    
    Attributes:
        promotion_filter_list: Promotion filter list (optional)
        promotion_type: Promotion type (optional)
        individual_filter_list: Individual filter list (optional)
        product_filter_list: Product filter list (optional)
        event_filter_list: Event filter list (optional)
        category_filter_list: Category filter list (optional)
        valid_only: Valid only flag (optional)
        page_req: Page request (optional)
    """
    
    promotion_filter_list: Optional[List[Dict[str, str]]] = None
    promotion_type: Optional[int] = None
    individual_filter_list: Optional[List[Dict[str, str]]] = None
    product_filter_list: Optional[List[Dict[str, str]]] = None
    event_filter_list: Optional[List[Dict[str, str]]] = None
    category_filter_list: Optional[List[Dict[str, str]]] = None
    valid_only: Optional[bool] = None
    page_req: Optional[PageRequest] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.promotion_filter_list is not None:
            result["PROMOTIONFILTERLIST"] = {
                "PROMOTION": self.promotion_filter_list
            }
        if self.promotion_type is not None:
            result["PROMOTIONTYPE"] = self.promotion_type
        if self.individual_filter_list is not None:
            result["INDIVIDUALFILTERLIST"] = {
                "INDIVIDUAL": self.individual_filter_list
            }
        if self.product_filter_list is not None:
            result["PRODUCTFILTERLIST"] = {
                "PRODUCT": self.product_filter_list
            }
        if self.event_filter_list is not None:
            result["EVENTFILTERLIST"] = {
                "EVENT": self.event_filter_list
            }
        if self.category_filter_list is not None:
            result["CATEGORYFILTERLIST"] = {
                "CATEGORY": self.category_filter_list
            }
        if self.valid_only is not None:
            result["VALIDONLY"] = self.valid_only
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        return result


@dataclass
class SearchPackageRequest:
    """Request for SearchPackage operation.
    
    Based on PromotionEnquiry.xsd SEARCHPACKAGEREQ type.
    
    Attributes:
        package_filter_list: Package filter list (optional)
        matrix_cell_list: Matrix cell list (optional)
        status: Status (optional)
        stat_group_list: Statistical group list (optional)
        page_req: Page request (optional)
        type: Package type (optional)
        sellable: Sellable flag (optional)
    """
    
    package_filter_list: Optional[List[Dict[str, str]]] = None
    matrix_cell_list: Optional[List[str]] = None
    status: Optional[bool] = None
    stat_group_list: Optional[List[Dict[str, Any]]] = None
    page_req: Optional[PageRequest] = None
    type: Optional[int] = None
    sellable: Optional[bool] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.package_filter_list is not None:
            result["PACKAGEFILTERLIST"] = {
                "PACKAGE": self.package_filter_list
            }
        if self.matrix_cell_list is not None:
            result["MATRIXCELLLIST"] = {
                "MATRIXCELLITEM": [{"AK": ak} for ak in self.matrix_cell_list]
            }
        if self.status is not None:
            result["STATUS"] = self.status
        if self.stat_group_list is not None:
            result["STATGROUPLIST"] = {"STATGROUP": self.stat_group_list}
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        if self.type is not None:
            result["TYPE"] = self.type
        if self.sellable is not None:
            result["SELLABLE"] = self.sellable
        return result


@dataclass
class SearchIndividualCodeRequest:
    """Request for SearchIndividualCode operation.
    
    Based on PromotionEnquiry.xsd SEARCHINDIVIDUALCODEREQ type.
    
    Attributes:
        promotion_filter_list: Promotion filter list (optional)
        promotion_type: Promotion type (optional)
        individual_filter_list: Individual filter list (optional)
        status: Status (optional)
        active: Active flag (optional)
        ins_datetime: Insert datetime filter (optional)
        page_req: Page request (optional)
    """
    
    promotion_filter_list: Optional[List[Dict[str, str]]] = None
    promotion_type: Optional[int] = None
    individual_filter_list: Optional[List[Dict[str, str]]] = None
    status: Optional[int] = None
    active: Optional[bool] = None
    ins_datetime: Optional[BaseDateFilter] = None
    page_req: Optional[PageRequest] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.promotion_filter_list is not None:
            result["PROMOTIONFILTERLIST"] = {
                "PROMOTION": self.promotion_filter_list
            }
        if self.promotion_type is not None:
            result["PROMOTIONTYPE"] = self.promotion_type
        if self.individual_filter_list is not None:
            result["INDIVIDUALFILTERLIST"] = {
                "INDIVIDUAL": self.individual_filter_list
            }
        if self.status is not None:
            result["STATUS"] = {"VALUE": self.status}
        if self.active is not None:
            result["ACTIVE"] = self.active
        if self.ins_datetime is not None:
            result["INSDATETIME"] = self.ins_datetime.to_dict()
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        return result


@dataclass
class GetCouponQuotaPerAccountRequest:
    """Request for GetCouponQuotaPerAccount operation.
    
    Based on PromotionEnquiry.xsd GETCOUPONQUOTAPERACCOUNTREQ type.
    
    Attributes:
        account_ak: Account AK
        coupon_code: Coupon code
        visit: Visit information (DATE or PERFORMANCEAK) (optional)
    """
    
    account_ak: str
    coupon_code: str
    visit: Optional[Dict[str, str]] = None  # {"DATE": "..."} or {"PERFORMANCEAK": "..."}
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "ACCOUNTAK": self.account_ak,
            "COUPONCODE": self.coupon_code,
        }
        if self.visit is not None:
            result["VISIT"] = self.visit
        return result


# Response Classes
@dataclass
class ValidateCouponCodeResponse:
    """Response for ValidateCouponCode operation.
    
    Based on PromotionEnquiry.xsd VALIDATECOUPONCODERESP type.
    
    Attributes:
        error: Error information
        coupon: Coupon information (optional)
    """
    
    error: Error
    coupon: Optional[Coupon] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ValidateCouponCodeResponse":
        """Create ValidateCouponCodeResponse from API response dictionary."""
        coupon_data = data.get("COUPON")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            coupon=Coupon.from_dict(coupon_data) if coupon_data else None,
        )


@dataclass
class ValidateCouponCodeByDmgCategoryResponse:
    """Response for ValidateCouponCodeByDmgCategory operation.
    
    Based on PromotionEnquiry.xsd VALIDATECOUPONCODEBYDMGCATEGORYRESP type.
    
    Attributes:
        error: Error information
        coupon: Coupon information (optional)
    """
    
    error: Error
    coupon: Optional[Coupon] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ValidateCouponCodeByDmgCategoryResponse":
        """Create ValidateCouponCodeByDmgCategoryResponse from API response dictionary."""
        coupon_data = data.get("COUPON")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            coupon=Coupon.from_dict(coupon_data) if coupon_data else None,
        )


@dataclass
class ReadPromotionByCodeResponse:
    """Response for ReadPromotionByCode operation.
    
    Based on PromotionEnquiry.xsd READPROMOTIONBYCODERESP type.
    
    Attributes:
        error: Error information
        promotion: Promotion information
    """
    
    error: Error
    promotion: PromoBase
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadPromotionByCodeResponse":
        """Create ReadPromotionByCodeResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            promotion=PromoBase.from_dict(data.get("PROMOTION", {})),
        )


@dataclass
class FindAllPromotionResponse:
    """Response for FindAllPromotion operation.
    
    Based on PromotionEnquiry.xsd FINDALLPROMOTIONRESP type.
    
    Attributes:
        error: Error information
        promotion_list: List of promotions (optional)
    """
    
    error: Error
    promotion_list: Optional[List[PromoBase]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllPromotionResponse":
        """Create FindAllPromotionResponse from API response dictionary."""
        promotion_data = data.get("PROMOTIONLIST", {}).get("PROMOTIONITEM")
        promotion_list = None
        if promotion_data:
            if isinstance(promotion_data, list):
                promotion_list = [PromoBase.from_dict(p) for p in promotion_data]
            else:
                promotion_list = [PromoBase.from_dict(promotion_data)]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            promotion_list=promotion_list,
        )


@dataclass
class ImportIndividualCodeResponse:
    """Response for ImportIndividualCode operation.
    
    Based on PromotionEnquiry.xsd IMPORTINDIVIDUALCODERESP type.
    
    Attributes:
        error: Error information
        imported_coupon_list: List of imported coupons (optional)
    """
    
    error: Error
    imported_coupon_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ImportIndividualCodeResponse":
        """Create ImportIndividualCodeResponse from API response dictionary."""
        imported_data = data.get("IMPORTEDCOUPONLIST", {}).get("IMPORTEDCOUNPONITEM")
        imported_list = None
        if imported_data:
            if isinstance(imported_data, list):
                imported_list = imported_data
            else:
                imported_list = [imported_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            imported_coupon_list=imported_list,
        )


@dataclass
class ReadPackageByCodeResponse:
    """Response for ReadPackageByCode operation.
    
    Based on PromotionEnquiry.xsd READPACKAGEBYCODERESP type.
    
    Attributes:
        error: Error information
        package: Package information (optional)
    """
    
    error: Error
    package: Optional[Package] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadPackageByCodeResponse":
        """Create ReadPackageByCodeResponse from API response dictionary."""
        package_data = data.get("PACKAGE")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            package=Package.from_dict(package_data) if package_data else None,
        )


@dataclass
class ReadExternalPackageByCodeResponse:
    """Response for ReadExternalPackageByCode operation.
    
    Based on PromotionEnquiry.xsd READEXTERNALPACKAGEBYCODERESP type.
    
    Attributes:
        error: Error information
        package: External package information (optional)
        err_msg: Error message
    """
    
    error: Error
    err_msg: str
    package: Optional[ExternalPackage] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadExternalPackageByCodeResponse":
        """Create ReadExternalPackageByCodeResponse from API response dictionary."""
        package_data = data.get("PACKAGE")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            err_msg=data.get("ERRMSG", ""),
            package=ExternalPackage.from_dict(package_data) if package_data else None,
        )


@dataclass
class SearchPromotionResponse:
    """Response for SearchPromotion operation.
    
    Based on PromotionEnquiry.xsd SEARCHPROMOTIONRESP type.
    
    Attributes:
        error: Error information
        promotion_list: List of promotions (optional)
        page_resp: Page response (optional)
    """
    
    error: Error
    promotion_list: Optional[List[PromoBase]] = None
    page_resp: Optional[PageResponse] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchPromotionResponse":
        """Create SearchPromotionResponse from API response dictionary."""
        promotion_data = data.get("PROMOTIONLIST", {}).get("PROMOTIONITEM")
        promotion_list = None
        if promotion_data:
            if isinstance(promotion_data, list):
                promotion_list = [PromoBase.from_dict(p) for p in promotion_data]
            else:
                promotion_list = [PromoBase.from_dict(promotion_data)]
        page_resp_data = data.get("PAGERESP")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            promotion_list=promotion_list,
            page_resp=PageResponse.from_dict(page_resp_data) if page_resp_data else None,
        )


@dataclass
class SearchPackageResponse:
    """Response for SearchPackage operation.
    
    Based on PromotionEnquiry.xsd SEARCHPACKAGERESP type.
    
    Attributes:
        error: Error information
        result_package_list: List of result packages (optional)
        page_resp: Page response (optional)
    """
    
    error: Error
    result_package_list: Optional[List[Package]] = None
    page_resp: Optional[PageResponse] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchPackageResponse":
        """Create SearchPackageResponse from API response dictionary."""
        package_data = data.get("RESULTPACKAGELIST", {}).get("RESULTPACKAGEITEM")
        package_list = None
        if package_data:
            if isinstance(package_data, list):
                package_list = [Package.from_dict(p) for p in package_data]
            else:
                package_list = [Package.from_dict(package_data)]
        page_resp_data = data.get("PAGERESP")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            result_package_list=package_list,
            page_resp=PageResponse.from_dict(page_resp_data) if page_resp_data else None,
        )


@dataclass
class SearchIndividualCodeResponse:
    """Response for SearchIndividualCode operation.
    
    Based on PromotionEnquiry.xsd SEARCHINDIVIDUALCODERESP type.
    
    Attributes:
        error: Error information
        individual_code_list: List of individual codes (optional)
        page_resp: Page response (optional)
    """
    
    error: Error
    individual_code_list: Optional[List[Dict[str, Any]]] = None
    page_resp: Optional[PageResponse] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchIndividualCodeResponse":
        """Create SearchIndividualCodeResponse from API response dictionary."""
        individual_data = data.get("INDIVIDUALCODELIST", {}).get("INDIVIDUALCODEITEM")
        individual_list = None
        if individual_data:
            if isinstance(individual_data, list):
                individual_list = individual_data
            else:
                individual_list = [individual_data]
        page_resp_data = data.get("PAGERESP")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            individual_code_list=individual_list,
            page_resp=PageResponse.from_dict(page_resp_data) if page_resp_data else None,
        )


@dataclass
class GetCouponQuotaPerAccountResponse:
    """Response for GetCouponQuotaPerAccount operation.
    
    Based on PromotionEnquiry.xsd GETCOUPONQUOTAPERACCOUNTRESP type.
    
    Attributes:
        error: Error information
        account_ak: Account AK
        account_id: Account ID
        coupon_code: Coupon code
        quota_list: Quota list
    """
    
    error: Error
    account_ak: str
    account_id: int
    coupon_code: str
    quota_list: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "GetCouponQuotaPerAccountResponse":
        """Create GetCouponQuotaPerAccountResponse from API response dictionary."""
        quota_data = data.get("QUOTALIST", {}).get("QUOTAITEM")
        quota_list = []
        if quota_data:
            if isinstance(quota_data, list):
                quota_list = quota_data
            else:
                quota_list = [quota_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            account_ak=data.get("ACCOUNTAK", ""),
            account_id=data.get("ACCOUNTID", 0),
            coupon_code=data.get("COUPONCODE", ""),
            quota_list=quota_list,
        )


@dataclass
class ValidatePackageCodeResponse:
    """Response for ValidatePackageCode operation.
    
    Based on PromotionEnquiry.xsd VALIDATEPACKAGECODERESP type.
    
    Attributes:
        error: Error information
        package: Package information (optional)
    """
    
    error: Error
    package: Optional[Package] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ValidatePackageCodeResponse":
        """Create ValidatePackageCodeResponse from API response dictionary."""
        package_data = data.get("PACKAGE")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            package=Package.from_dict(package_data) if package_data else None,
        )
