"""
Type definitions for UserOperation.

This module provides structured classes for user operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, PageRequest, PageResponse


# Request Classes
@dataclass
class SearchUserRoleRequest:
    """Request for SearchUserRole operation.
    
    Based on UserOperation.xsd SEARCHUSERROLEREQ type.
    
    Attributes:
        ak_list: AK list (optional)
        code_list: Code list (optional)
        page_req: Page request (optional)
    """
    
    ak_list: Optional[List[str]] = None
    code_list: Optional[List[str]] = None
    page_req: Optional[PageRequest] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.ak_list is not None:
            result["AKLIST"] = {"AK": [{"CODE": ak} for ak in self.ak_list]}
        if self.code_list is not None:
            result["CODELIST"] = {"CODE": [{"CODE": code} for code in self.code_list]}
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        return result


@dataclass
class SearchUserRequest:
    """Request for SearchUser operation.
    
    Based on UserOperation.xsd SEARCHUSERREQ type.
    
    Attributes:
        ak_list: AK list (optional)
        code_list: Code list (optional)
        role_list: Role list (optional)
        name: Name (optional)
        desc: Description (optional)
        ext_auth: External auth (optional)
        status: Status (optional, 0 or 1)
        page_req: Page request (optional)
    """
    
    ak_list: Optional[List[str]] = None
    code_list: Optional[List[str]] = None
    role_list: Optional[List[str]] = None
    name: Optional[str] = None
    desc: Optional[str] = None
    ext_auth: Optional[str] = None
    status: Optional[int] = None
    page_req: Optional[PageRequest] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.ak_list is not None:
            result["AKLIST"] = {"AK": [{"CODE": ak} for ak in self.ak_list]}
        if self.code_list is not None:
            result["CODELIST"] = {"CODE": [{"CODE": code} for code in self.code_list]}
        if self.role_list is not None:
            result["ROLELIST"] = {"ROLE": [{"CODE": role} for role in self.role_list]}
        if self.name is not None:
            result["NAME"] = self.name
        if self.desc is not None:
            result["DESC"] = self.desc
        if self.ext_auth is not None:
            result["EXTAUTH"] = self.ext_auth
        if self.status is not None:
            result["STATUS"] = self.status
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        return result


@dataclass
class SaveUserRequest:
    """Request for SaveUser operation.
    
    Based on UserOperation.xsd SAVEUSERREQ type.
    
    Attributes:
        ak: User AK (optional)
        code: User code (optional)
        name: User name (optional)
        desc: Description (optional)
        ext_auth: External auth (optional)
        note: Note (optional)
        role_list: Role list (optional)
        status: Status (optional, 0 or 1)
        password: Password (optional)
        reset_password: Reset password flag (optional)
        expiration_date: Expiration date (optional)
    """
    
    ak: Optional[str] = None
    code: Optional[str] = None
    name: Optional[str] = None
    desc: Optional[str] = None
    ext_auth: Optional[str] = None
    note: Optional[str] = None
    role_list: Optional[List[Dict[str, Any]]] = None
    status: Optional[int] = None
    password: Optional[str] = None
    reset_password: Optional[bool] = None
    expiration_date: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.ak is not None:
            result["AK"] = self.ak
        if self.code is not None:
            result["CODE"] = self.code
        if self.name is not None:
            result["NAME"] = self.name
        if self.desc is not None:
            result["DESC"] = self.desc
        if self.ext_auth is not None:
            result["EXTAUTH"] = self.ext_auth
        if self.note is not None:
            result["NOTE"] = self.note
        if self.role_list is not None:
            result["ROLELIST"] = {"ROLE": self.role_list}
        if self.status is not None:
            result["STATUS"] = self.status
        if self.password is not None:
            result["PASSWORD"] = self.password
        if self.reset_password is not None:
            result["RESETPASSWORD"] = self.reset_password
        if self.expiration_date is not None:
            result["EXPIRATIONDATE"] = self.expiration_date
        return result


# Response Classes
@dataclass
class UserLoginResponse:
    """Response for UserLogin operation.
    
    Based on UserOperation.xsd USERLOGINRESP type.
    
    Attributes:
        error: Error information
        session_id: Session ID (optional)
        user_code: User code (optional)
        app_server_version: Application server version (optional)
        language_id: Language ID (optional)
        password_expiration: Password expiration date (optional)
        user_ak: User AK (optional)
        price_list_list: Price list list (optional)
        payment_method_list: Payment method list (optional)
    """
    
    error: Error
    session_id: Optional[str] = None
    user_code: Optional[str] = None
    app_server_version: Optional[str] = None
    language_id: Optional[int] = None
    password_expiration: Optional[str] = None
    user_ak: Optional[str] = None
    price_list_list: Optional[List[Dict[str, Any]]] = None
    payment_method_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "UserLoginResponse":
        """Create UserLoginResponse from API response dictionary."""
        price_list_data = data.get("PRICELISTLIST", {}).get("PRICELIST")
        price_list = None
        if price_list_data:
            if isinstance(price_list_data, list):
                price_list = price_list_data
            else:
                price_list = [price_list_data]
        payment_data = data.get("PAYMENTMETHODLIST", {}).get("PAYMENTMETHOD")
        payment_list = None
        if payment_data:
            if isinstance(payment_data, list):
                payment_list = payment_data
            else:
                payment_list = [payment_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            session_id=data.get("SESSIONID"),
            user_code=data.get("USERCODE"),
            app_server_version=data.get("APPSERVERVERSION"),
            language_id=data.get("LANGUAGEID"),
            password_expiration=data.get("PASSWORDEXPIRATION"),
            user_ak=data.get("USERAK"),
            price_list_list=price_list,
            payment_method_list=payment_list,
        )


@dataclass
class UserLogoutResponse:
    """Response for UserLogout operation.
    
    Based on UserOperation.xsd USERLOGOUTRESP type.
    
    Attributes:
        error: Error information
    """
    
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "UserLogoutResponse":
        """Create UserLogoutResponse from API response dictionary."""
        return cls(error=Error.from_dict(data.get("ERROR", {})))


@dataclass
class ResetISAPICacheResponse:
    """Response for ResetISAPICache operation.
    
    Based on UserOperation.xsd RESETISAPICACHERESP type.
    
    Attributes:
        error: Error information
    """
    
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "ResetISAPICacheResponse":
        """Create ResetISAPICacheResponse from API response dictionary."""
        return cls(error=Error.from_dict(data.get("ERROR", {})))


@dataclass
class CheckSessionResponse:
    """Response for CheckSession operation.
    
    Based on UserOperation.xsd CHECKSESSIONRESP type.
    
    Attributes:
        error: Error information
        app_server_version: Application server version (optional)
    """
    
    error: Error
    app_server_version: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "CheckSessionResponse":
        """Create CheckSessionResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            app_server_version=data.get("APPSERVERVERSION"),
        )


@dataclass
class FindAllPaymentResponse:
    """Response for ReadPaymentMethodByAk and FindAllPaymentMethod operations.
    
    Based on UserOperation.xsd FINDALLPAYMENTRESP type.
    
    Attributes:
        error: Error information
        payment_method_list: Payment method list (optional)
    """
    
    error: Error
    payment_method_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllPaymentResponse":
        """Create FindAllPaymentResponse from API response dictionary."""
        payment_data = data.get("PAYMENTMETHODLIST", {}).get("PAYMENTMETHOD")
        payment_list = None
        if payment_data:
            if isinstance(payment_data, list):
                payment_list = payment_data
            else:
                payment_list = [payment_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            payment_method_list=payment_list,
        )


@dataclass
class SearchUserRoleResponse:
    """Response for SearchUserRole operation.
    
    Based on UserOperation.xsd SEARCHUSERROLERESP type.
    
    Attributes:
        error: Error information
        user_role_list: User role list (optional)
        page_resp: Page response
    """
    
    error: Error
    page_resp: PageResponse
    user_role_list: Optional[List[Dict[str, Any]]] = None
    
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchUserRoleResponse":
        """Create SearchUserRoleResponse from API response dictionary."""
        role_data = data.get("USERROLELIST", {}).get("USERROLE")
        role_list = None
        if role_data:
            if isinstance(role_data, list):
                role_list = role_data
            else:
                role_list = [role_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            user_role_list=role_list,
            page_resp=PageResponse.from_dict(data.get("PAGERESP", {})),
        )


@dataclass
class SearchUserResponse:
    """Response for SearchUser operation.
    
    Based on UserOperation.xsd SEARCHUSERRESP type.
    
    Attributes:
        error: Error information
        user_info_list: User info list (optional)
        page_resp: Page response
    """
    
    error: Error
    page_resp: PageResponse
    user_info_list: Optional[List[Dict[str, Any]]] = None
    
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchUserResponse":
        """Create SearchUserResponse from API response dictionary."""
        user_data = data.get("USERINFOLIST", {}).get("USERINFO")
        user_list = None
        if user_data:
            if isinstance(user_data, list):
                user_list = user_data
            else:
                user_list = [user_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            user_info_list=user_list,
            page_resp=PageResponse.from_dict(data.get("PAGERESP", {})),
        )


@dataclass
class SaveUserResponse:
    """Response for SaveUser operation.
    
    Based on UserOperation.xsd SAVEUSERRESP type.
    
    Attributes:
        error: Error information
        user_info_list: User info list (optional)
    """
    
    error: Error
    user_info_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SaveUserResponse":
        """Create SaveUserResponse from API response dictionary."""
        user_data = data.get("USERINFOLIST", {}).get("USERINFO")
        user_list = None
        if user_data:
            if isinstance(user_data, list):
                user_list = user_data
            else:
                user_list = [user_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            user_info_list=user_list,
        )
