"""
Type definitions for APICommon.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any


# TODO: Add type definitions based on APICommon.xsd
