"""
Type definitions for Expo2020.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any


# TODO: Add type definitions based on Expo2020.xsd
