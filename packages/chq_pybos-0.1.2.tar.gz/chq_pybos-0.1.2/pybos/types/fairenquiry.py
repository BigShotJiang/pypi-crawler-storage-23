"""
Type definitions for FairEnquiry.

This module provides structured classes for fair operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, BaseDateFilter


# Request Classes
@dataclass
class GetFairSalesRequest:
    """Request for GetFairSales operation.
    
    Based on FairEnquiry.xsd GETFAIRSALESREQ type.
    
    Attributes:
        dmg_category_ak: DMG category AK
        filter_range: Date/time filter range
    """
    
    dmg_category_ak: str
    filter_range: Dict[str, str]  # {"FROM": "...", "TO": "..."}
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "DMGCATEGORYAK": self.dmg_category_ak,
            "FILTERRANGE": self.filter_range,
        }


@dataclass
class GetFairAccountsRequest:
    """Request for GetFairAccounts operation.
    
    Based on FairEnquiry.xsd GETFAIRACCOUNTSREQ type.
    
    Attributes:
        dmg_category_ak: DMG category AK
        filter_range: Date/time filter range
    """
    
    dmg_category_ak: str
    filter_range: Dict[str, str]  # {"FROM": "...", "TO": "..."}
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "DMGCATEGORYAK": self.dmg_category_ak,
            "FILTERRANGE": self.filter_range,
        }


@dataclass
class GetFairSalesDashBoardRequest:
    """Request for GetFairSalesDashBoard operation.
    
    Based on FairEnquiry.xsd GETFAIRSALESDASHBOARDREQ type.
    
    Attributes:
        dmg_category_ak: DMG category AK
        filter_range: Date/time filter range
    """
    
    dmg_category_ak: str
    filter_range: Dict[str, str]  # {"FROM": "...", "TO": "..."}
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "DMGCATEGORYAK": self.dmg_category_ak,
            "FILTERRANGE": self.filter_range,
        }


@dataclass
class SendTckOwnerEmailRequest:
    """Request for SendTckOwnerEmail operation.
    
    Based on FairEnquiry.xsd SENDTCKOWNEREMAILREQ type.
    
    Attributes:
        account_ak: Account AK
        sale_ak: Sale AK
        language_ak: Language AK
        email_address: Email address
    """
    
    account_ak: str
    sale_ak: str
    language_ak: str
    email_address: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "ACCOUNTAK": self.account_ak,
            "SALEAK": self.sale_ak,
            "LANGUAGEAK": self.language_ak,
            "EMAILADDRESS": self.email_address,
        }


@dataclass
class GetExtendedSalesRequest:
    """Request for GetExtendedSales operation.
    
    Based on FairEnquiry.xsd GETEXTENDEDSALESREQ type.
    
    Attributes:
        event_ak: Event AK
        date_filter: Date filter
    """
    
    event_ak: str
    date_filter: BaseDateFilter
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "EVENTAK": self.event_ak,
            "DATEFILTER": self.date_filter.to_dict(),
        }


# Response Classes
@dataclass
class GetFairSalesResponse:
    """Response for GetFairSales operation.
    
    Based on FairEnquiry.xsd GETFAIRSALESRESP type.
    
    Attributes:
        error: Error information
        sale_list: List of sales (optional)
    """
    
    error: Error
    sale_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "GetFairSalesResponse":
        """Create GetFairSalesResponse from API response dictionary."""
        sale_data = data.get("SALELIST", {}).get("SALE")
        sale_list = None
        if sale_data:
            if isinstance(sale_data, list):
                sale_list = sale_data
            else:
                sale_list = [sale_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            sale_list=sale_list,
        )


@dataclass
class GetFairAccountsResponse:
    """Response for GetFairAccounts operation.
    
    Based on FairEnquiry.xsd GETFAIRACCOUNTSRESP type.
    
    Attributes:
        error: Error information
        fair_account_list: List of fair accounts
    """
    
    error: Error
    fair_account_list: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "GetFairAccountsResponse":
        """Create GetFairAccountsResponse from API response dictionary."""
        account_data = data.get("FAIRACCOUNTLIST", {}).get("FAIRACCOUNT")
        account_list = []
        if account_data:
            if isinstance(account_data, list):
                account_list = account_data
            else:
                account_list = [account_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            fair_account_list=account_list,
        )


@dataclass
class GetFairAccountCSVResponse:
    """Response for GetFairAccountCSV operation.
    
    Based on FairEnquiry.xsd GETFAIRACCOUNTCSVRESP type.
    
    Attributes:
        error: Error information
        csv: CSV data as hex binary (optional)
    """
    
    error: Error
    csv: Optional[bytes] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "GetFairAccountCSVResponse":
        """Create GetFairAccountCSVResponse from API response dictionary."""
        csv_data = data.get("CSV")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            csv=csv_data,
        )


@dataclass
class GetFairSalesCSVResponse:
    """Response for GetFairSalesCSV operation.
    
    Based on FairEnquiry.xsd GETFAIRSALESCSVRESP type.
    
    Attributes:
        error: Error information
        csv: CSV data as hex binary (optional)
    """
    
    error: Error
    csv: Optional[bytes] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "GetFairSalesCSVResponse":
        """Create GetFairSalesCSVResponse from API response dictionary."""
        csv_data = data.get("CSV")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            csv=csv_data,
        )


@dataclass
class SendTckOwnerEmailResponse:
    """Response for SendTckOwnerEmail operation.
    
    Based on FairEnquiry.xsd SENDTCKOWNEREMAILRESP type.
    
    Attributes:
        error: Error information
    """
    
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "SendTckOwnerEmailResponse":
        """Create SendTckOwnerEmailResponse from API response dictionary."""
        return cls(error=Error.from_dict(data.get("ERROR", {})))


@dataclass
class GetFairSalesDashBoardResponse:
    """Response for GetFairSalesDashBoard operation.
    
    Based on FairEnquiry.xsd GETFAIRSALESDASHBOARDRESP type.
    
    Attributes:
        error: Error information
        dashboard_daily_sales_list: Daily sales list
        dashboard_sales_list: Sales list
        dashboard_totals: Dashboard totals
    """
    
    error: Error
    dashboard_daily_sales_list: List[Dict[str, Any]]
    dashboard_sales_list: List[Dict[str, Any]]
    dashboard_totals: Dict[str, Any]
    
    @classmethod
    def from_dict(cls, data: dict) -> "GetFairSalesDashBoardResponse":
        """Create GetFairSalesDashBoardResponse from API response dictionary."""
        daily_sales_data = data.get("DASHBOARDDAILYSALESLIST", {}).get("DASHBOARDDAILYSALESITEM")
        daily_sales_list = []
        if daily_sales_data:
            if isinstance(daily_sales_data, list):
                daily_sales_list = daily_sales_data
            else:
                daily_sales_list = [daily_sales_data]
        sales_data = data.get("DASHBOARDSALESLIST", {}).get("DASHBOARDSALESITEM")
        sales_list = []
        if sales_data:
            if isinstance(sales_data, list):
                sales_list = sales_data
            else:
                sales_list = [sales_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            dashboard_daily_sales_list=daily_sales_list,
            dashboard_sales_list=sales_list,
            dashboard_totals=data.get("DASHBOARDTOTALS", {}),
        )


@dataclass
class GetExtendedSalesResponse:
    """Response for GetExtendedSales operation.
    
    Based on FairEnquiry.xsd GETEXTENDEDSALESRESP type.
    
    Attributes:
        error: Error information
        extended_sale_list: List of extended sales (optional)
    """
    
    error: Error
    extended_sale_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "GetExtendedSalesResponse":
        """Create GetExtendedSalesResponse from API response dictionary."""
        sale_data = data.get("EXTENDEDSALELIST", {}).get("EXTENDEDSALEITEM")
        sale_list = None
        if sale_data:
            if isinstance(sale_data, list):
                sale_list = sale_data
            else:
                sale_list = [sale_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            extended_sale_list=sale_list,
        )
