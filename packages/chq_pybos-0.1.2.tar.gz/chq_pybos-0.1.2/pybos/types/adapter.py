"""
Adapter service data types for the BOS API.

This module provides structured classes for adapter service operations,
including account management, sales processing, and data retrieval.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error


# Request Classes
@dataclass
class SimpleImportAccountRequest:
    """Structured request for SimpleImportAccount operation.

    Based on Adapter.xsd SIMPLEIMPORTACCOUNTREQ structure.

    Attributes:
        import_account_xml: XML string containing account import data
    """

    import_account_xml: str

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "ImportAccountXML": self.import_account_xml,
        }


@dataclass
class GenerateSaleRequest:
    """Structured request for GenerateSale operation.

    Based on Adapter.xsd GENERATESALEREQ structure.

    Attributes:
        shopcart_xml: XML string containing shopcart data
    """

    shopcart_xml: str

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "ShopcartXml": self.shopcart_xml,
        }


@dataclass
class UpdateReservationInfoRequest:
    """Structured request for UpdateReservationInfo operation.

    Based on Adapter.xsd UPDATERESERVATIONINFOREQ structure.

    Attributes:
        update_reservation_info: XML string containing reservation update data
    """

    update_reservation_info: str

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "UpdateReservationInfo": self.update_reservation_info,
        }


@dataclass
class GetCounterNumberRequest:
    """Structured request for GetCounterNumber operation.

    Based on Adapter.xsd GETCOUNTERNUMBERREQ structure.

    Attributes:
        counter_type: Counter type (1=Adyen, 2=Payfort, 3=Shift4)
    """

    counter_type: int

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "COUNTERTYPE": self.counter_type,
        }


@dataclass
class AccountAccreditationRequest:
    """Structured request for AccountAccreditation operation.

    Based on Adapter.xsd ACCOUNTACCREDITATIONREQ structure.

    Attributes:
        account_accreditation: XML string containing account accreditation data
    """

    account_accreditation: str

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "AccountAccreditation": self.account_accreditation,
        }


@dataclass
class CompleteTransactionXmlRequest:
    """Structured request for CompleteTransactionAndGetTicketsXML operation.

    Based on Adapter.xsd COMPLETETRANSACTIONXMLREQ structure.

    Attributes:
        complete_transaction_xml: XML string containing transaction completion data
    """

    complete_transaction_xml: str

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "CompleteTransactionXML": self.complete_transaction_xml,
        }


@dataclass
class GetDataByIdRequest:
    """Structured request for GetDataById operations.

    Based on Adapter.xsd GETDATABYIDREQ structure.

    Attributes:
        a_id: ID string for data retrieval
    """

    a_id: str

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "AId": self.a_id,
        }


@dataclass
class GetDataRequest:
    """Structured request for GetData operations.

    Based on Adapter.xsd GETDATAREQ structure.

    Attributes:
        xml_query: XML query string
        dataset_name: Name of the dataset
        is_list: Whether the result is a list
    """

    xml_query: str
    dataset_name: str
    is_list: bool

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "XMLQUERY": self.xml_query,
            "DATASETNAME": self.dataset_name,
            "ISLIST": self.is_list,
        }


# Additional adapter request classes referenced by package exports
@dataclass
class NewUpgradeShopcartRequest:
    """Request for NewUpgradeShopcart operation.

    Attributes:
        shopcart_xml: XML string describing the upgrade shopcart
    """

    shopcart_xml: str

    def to_dict(self) -> dict:
        return {
            "ShopcartXml": self.shopcart_xml,
        }


@dataclass
class NewActivationShopcartRequest:
    """Request for NewActivationShopcart operation.

    Attributes:
        shopcart_xml: XML string describing the activation shopcart
    """

    shopcart_xml: str

    def to_dict(self) -> dict:
        return {
            "ShopcartXml": self.shopcart_xml,
        }


@dataclass
class InitPaymentsRequest:
    """Request for InitPayments operation.

    Attributes:
        init_payments_xml: XML string with initialization data
    """

    init_payments_xml: str

    def to_dict(self) -> dict:
        return {
            "InitPaymentsXML": self.init_payments_xml,
        }


@dataclass
class SaveCreditCardRequest:
    """Request for SaveCreditCard operation.

    Attributes:
        card_xml: XML string containing card data
    """

    card_xml: str

    def to_dict(self) -> dict:
        return {
            "CardXML": self.card_xml,
        }


@dataclass
class SetPaymentStatusRequest:
    """Request for SetPaymentStatus operation.

    Attributes:
        payment_status_xml: XML string describing the payment status
    """

    payment_status_xml: str

    def to_dict(self) -> dict:
        return {
            "PaymentStatusXML": self.payment_status_xml,
        }


@dataclass
class ThirdPartyMediaRequest:
    """Request for ThirdPartyMedia operation.

    Attributes:
        media_xml: XML string with media details
    """

    media_xml: str

    def to_dict(self) -> dict:
        return {
            "MediaXML": self.media_xml,
        }


# Response Classes
@dataclass
class OutputResponse:
    """Response for operations that return output data.

    Based on Adapter.xsd OUTPUTRESP structure.

    Attributes:
        error: Error information
        output: Output data (optional)
    """

    error: Error
    output: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "OutputResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            output=data.get("OUTPUT"),
        )


@dataclass
class ErrorResponse:
    """Response for operations that only return error information.

    Based on Adapter.xsd ERRORRESP structure.

    Attributes:
        error: Error information
    """

    error: Error

    @classmethod
    def from_dict(cls, data: dict) -> "ErrorResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
        )


@dataclass
class GetDataResponse:
    """Response for GetData operations.

    Based on Adapter.xsd GETDATARESP structure.

    Attributes:
        error: Error information
        output: Output data (optional)
    """

    error: Error
    output: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "GetDataResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            output=data.get("OUTPUT"),
        )


@dataclass
class AccountAccreditationResponse:
    """Response for AccountAccreditation operation.

    Based on Adapter.xsd ACCOUNTACCREDITATIONRESP structure.

    Attributes:
        error: Error information
        account_id: Account ID (optional)
        account_ak: Account AK (optional)
        dmg_category_id: DMG category ID (optional)
        dmg_category_code: DMG category code (optional)
    """

    error: Error
    account_id: Optional[int] = None
    account_ak: Optional[str] = None
    dmg_category_id: Optional[int] = None
    dmg_category_code: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "AccountAccreditationResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            account_id=data.get("ACCOUNTID"),
            account_ak=data.get("ACCOUNTAK"),
            dmg_category_id=data.get("DMGCATEGORYID"),
            dmg_category_code=data.get("DMGCATEGORYCODE"),
        )


@dataclass
class FindAccountIdResponse:
    """Response for FindAccountIdByObjType operation.

    Based on Adapter.xsd FINDACCOUNTIDRESP structure.

    Attributes:
        error: Error information
        account_id: Account ID (optional)
    """

    error: Error
    account_id: Optional[int] = None

    @classmethod
    def from_dict(cls, data: dict) -> "FindAccountIdResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            account_id=data.get("ACCOUNTID"),
        )


@dataclass
class FindAccountPriceListResponse:
    """Response for FindAccountPriceListId operation.

    Based on Adapter.xsd FINDACCOUNTPRICELISTRESP structure.

    Attributes:
        error: Error information
        price_list_id: Price list ID (optional)
    """

    error: Error
    price_list_id: Optional[int] = None

    @classmethod
    def from_dict(cls, data: dict) -> "FindAccountPriceListResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            price_list_id=data.get("PRICELISTID"),
        )


@dataclass
class FindItemIdFromAkResponse:
    """Response for FindItemIdFromAk and FindItemAKFromId operations.

    Based on Adapter.xsd FINDITEMIDFROMAKRESP structure.

    Attributes:
        error: Error information
        ak: AK string (optional)
        id: ID integer (optional)
    """

    error: Error
    ak: Optional[str] = None
    id: Optional[int] = None

    @classmethod
    def from_dict(cls, data: dict) -> "FindItemIdFromAkResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            ak=data.get("AK"),
            id=data.get("ID"),
        )
