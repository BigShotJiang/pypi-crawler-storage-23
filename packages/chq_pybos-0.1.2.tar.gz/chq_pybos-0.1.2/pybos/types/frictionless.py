"""
Type definitions for Frictionless service.

This module provides structured classes for frictionless operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, BaseDateFilter


# Request Classes
@dataclass
class MediaCodeInfoRequest:
    """Request for MediaCode operation.
    
    Based on Frictionless.xsd MEDIACODEINFOREQ type.
    
    Attributes:
        media_code: Media code
    """
    
    media_code: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"MEDIACODE": self.media_code}


# Response Classes
@dataclass
class MediaCodeInfoResponse:
    """Response for MediaCode operation.
    
    Based on Frictionless.xsd MEDIACODEINFORESP type.
    
    Attributes:
        error: Error information
        media_code_info: Media code information
    """
    
    error: Error
    media_code_info: Dict[str, Any]
    
    @classmethod
    def from_dict(cls, data: dict) -> "MediaCodeInfoResponse":
        """Create MediaCodeInfoResponse from API response dictionary."""
        media_code_data = data.get("MEDIACODEINFO", {})
        validity_data = media_code_data.get("VALIDITY", {})
        if validity_data:
            media_code_data["VALIDITY"] = BaseDateFilter.from_dict(validity_data)
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            media_code_info=media_code_data,
        )
