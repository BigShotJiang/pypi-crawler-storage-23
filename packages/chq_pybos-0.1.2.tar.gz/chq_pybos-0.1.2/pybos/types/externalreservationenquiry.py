"""
Type definitions for ExternalReservationEnquiry.

This module provides structured classes for external reservation operations,
replacing tuple-based parameters with type-safe, self-documenting classes.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, BaseDateFilter


@dataclass
class Owner:
    """Owner information structure.
    
    Attributes:
        name: Owner name
        surname: Owner surname
        email: Owner email
    """
    
    name: str
    surname: str
    email: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "Owner":
        """Create Owner from API response dictionary."""
        return cls(
            name=data.get("NAME", ""),
            surname=data.get("SURNAME", ""),
            email=data.get("EMAIL", ""),
        )
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "NAME": self.name,
            "SURNAME": self.surname,
            "EMAIL": self.email,
        }


@dataclass
class AccountItem:
    """Account item information structure.
    
    Attributes:
        name: Account name
        surname: Account surname
        email: Account email
    """
    
    name: str
    surname: str
    email: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "AccountItem":
        """Create AccountItem from API response dictionary."""
        return cls(
            name=data.get("NAME", ""),
            surname=data.get("SURNAME", ""),
            email=data.get("EMAIL", ""),
        )
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "NAME": self.name,
            "SURNAME": self.surname,
            "EMAIL": self.email,
        }


@dataclass
class HiltonCreateBookingRequest:
    """Hilton create booking request structure.
    
    Attributes:
        reference: Booking reference
        product_code: Product code
        qty: Quantity
        validity: Validity date filter
        owner: Owner information
        account_list: List of account items
    """
    
    reference: str
    product_code: str
    qty: int
    validity: BaseDateFilter
    owner: Owner
    account_list: List[AccountItem]
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "REFERENCE": self.reference,
            "PRODUCTCODE": self.product_code,
            "QTY": self.qty,
            "VALIDITY": self.validity.to_dict(),
            "OWNER": self.owner.to_dict(),
            "ACCOUNTLIST": {
                "ACCOUNTITEM": [item.to_dict() for item in self.account_list]
            },
        }


@dataclass
class CreateBookingRequest:
    """Create booking request structure.
    
    Attributes:
        creation_type: Creation type (1 = Hilton)
        xml_data: XML data
    """
    
    creation_type: str
    xml_data: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "CREATIONTYPE": self.creation_type,
            "XMLDATA": self.xml_data,
        }


@dataclass
class HiltonObj:
    """Hilton object structure.
    
    Attributes:
        internal_code: Internal code
        json_data: JSON data
    """
    
    internal_code: str
    json_data: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "HiltonObj":
        """Create HiltonObj from API response dictionary."""
        return cls(
            internal_code=data.get("INTERNALCODE", ""),
            json_data=data.get("JSONDATA", ""),
        )
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "INTERNALCODE": self.internal_code,
            "JSONDATA": self.json_data,
        }


@dataclass
class HiltonPMSIntegrationRequest:
    """Hilton PMS integration request structure.
    
    Attributes:
        item: Hilton object
    """
    
    item: HiltonObj
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "ITEM": self.item.to_dict(),
        }


@dataclass
class ModifyBookingValidityRequest:
    """Modify booking validity request structure.
    
    Attributes:
        reference: Booking reference
        validity: Validity date filter
    """
    
    reference: str
    validity: BaseDateFilter
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "REFERENCE": self.reference,
            "VALIDITY": self.validity.to_dict(),
        }


@dataclass
class CancelBookingRequest:
    """Cancel booking request structure.
    
    Attributes:
        reference: Booking reference
    """
    
    reference: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "REFERENCE": self.reference,
        }


@dataclass
class BookingResponse:
    """Booking response structure.
    
    Attributes:
        reference: Booking reference
        error: Error information
    """
    
    reference: str
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "BookingResponse":
        """Create BookingResponse from API response dictionary."""
        return cls(
            reference=data.get("REFERENCE", ""),
            error=Error.from_dict(data.get("ERROR", {})),
        )
