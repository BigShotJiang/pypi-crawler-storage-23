"""
Type definitions for Upsell service.

This module provides structured classes for upsell operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, PageRequest, PageResponse


# Request Classes
@dataclass
class SearchUpsellRequest:
    """Request for SearchUpsell operation.
    
    Based on Upsell.xsd SEARCHUPSELLREQ type.
    
    Attributes:
        upsell_ak_list: Upsell AK list (optional)
        matrix_cell_ak: Matrix cell AK (optional)
        page_req: Page request (optional)
        upsell_category_ak_list: Upsell category AK list (optional)
    """
    
    upsell_ak_list: Optional[List[str]] = None
    matrix_cell_ak: Optional[str] = None
    page_req: Optional[PageRequest] = None
    upsell_category_ak_list: Optional[List[str]] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.upsell_ak_list is not None:
            result["UPSELLAKLIST"] = {
                "UPSELLAKITEM": [{"UPSELLAK": ak} for ak in self.upsell_ak_list]
            }
        if self.matrix_cell_ak is not None:
            result["MATRIXCELLAK"] = self.matrix_cell_ak
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        if self.upsell_category_ak_list is not None:
            result["UPSELLCATEGORYAKLIST"] = {
                "UPSELLCATEGORYAKITEM": [
                    {"UPSELLCATEGORYAK": ak} for ak in self.upsell_category_ak_list
                ]
            }
        return result


@dataclass
class CheckShopCartUpsellRequest:
    """Request for CheckShopCartUpsell operation.
    
    Based on Upsell.xsd CHECKSHOPCARTUPSELLREQ type.
    
    Attributes:
        shopcart: Shopcart (SHOPCART type)
    """
    
    shopcart: Dict[str, Any]  # SHOPCART type
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"SHOPCART": self.shopcart}


# Response Classes
@dataclass
class FindAllUpsellResponse:
    """Response for FindAllUpsell operation.
    
    Based on Upsell.xsd FINDALLUPSELLRESP type.
    
    Attributes:
        error: Error information
        upsell_list: List of upsells
    """
    
    error: Error
    upsell_list: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllUpsellResponse":
        """Create FindAllUpsellResponse from API response dictionary."""
        upsell_data = data.get("UPSELLLIST", {}).get("UPSELLITEM")
        upsell_list = []
        if upsell_data:
            if isinstance(upsell_data, list):
                upsell_list = upsell_data
            else:
                upsell_list = [upsell_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            upsell_list=upsell_list,
        )


@dataclass
class FindAllUpsellCategoryResponse:
    """Response for FindAllUpsellCategory operation.
    
    Based on Upsell.xsd FINDALLUPSELLCATEGORYRESP type.
    
    Attributes:
        error: Error information
        upsell_category_list: List of upsell categories
    """
    
    error: Error
    upsell_category_list: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllUpsellCategoryResponse":
        """Create FindAllUpsellCategoryResponse from API response dictionary."""
        category_data = data.get("UPSELLCATEGORYLIST", {}).get("UPSELLCATEGORYLIST")
        category_list = []
        if category_data:
            if isinstance(category_data, list):
                category_list = category_data
            else:
                category_list = [category_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            upsell_category_list=category_list,
        )


@dataclass
class ReadUpsellByAKResponse:
    """Response for ReadUpsellByAK operation.
    
    Based on Upsell.xsd READUPSELLBYAKRESP type.
    
    Attributes:
        error: Error information
        upsell_item: Upsell item (optional)
    """
    
    error: Error
    upsell_item: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadUpsellByAKResponse":
        """Create ReadUpsellByAKResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            upsell_item=data.get("UPSELLITEM"),
        )


@dataclass
class FindUpsellByProductAKResponse:
    """Response for FindUpsellByProductAK operation.
    
    Based on Upsell.xsd FINDUPSELLBYPRODUCTAKRESP type.
    
    Attributes:
        error: Error information
        product_upsell_list: List of product upsells
    """
    
    error: Error
    product_upsell_list: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindUpsellByProductAKResponse":
        """Create FindUpsellByProductAKResponse from API response dictionary."""
        product_data = data.get("PRODUCTUPSELLLIST", {}).get("PRODUCTUPSELLITEM")
        product_list = []
        if product_data:
            if isinstance(product_data, list):
                product_list = product_data
            else:
                product_list = [product_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            product_upsell_list=product_list,
        )


@dataclass
class SearchUpsellResponse:
    """Response for SearchUpsell operation.
    
    Based on Upsell.xsd SEARCHUPSELLRESP type.
    
    Attributes:
        error: Error information
        upsell_list: List of upsells
        page_resp: Page response
    """
    
    error: Error
    upsell_list: List[Dict[str, Any]]
    page_resp: PageResponse
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchUpsellResponse":
        """Create SearchUpsellResponse from API response dictionary."""
        upsell_data = data.get("UPSELLLIST", {}).get("UPSELLITEM")
        upsell_list = []
        if upsell_data:
            if isinstance(upsell_data, list):
                upsell_list = upsell_data
            else:
                upsell_list = [upsell_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            upsell_list=upsell_list,
            page_resp=PageResponse.from_dict(data.get("PAGERESP", {})),
        )


@dataclass
class CheckShopCartUpsellResponse:
    """Response for CheckShopCartUpsell operation.
    
    Based on Upsell.xsd CHECKSHOPCARTUPSELLRESP type.
    
    Attributes:
        error: Error information
        upsell_list: List of upsell AKs (optional)
    """
    
    error: Error
    upsell_list: Optional[List[str]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "CheckShopCartUpsellResponse":
        """Create CheckShopCartUpsellResponse from API response dictionary."""
        upsell_data = data.get("UPSELLLIST", {}).get("UPSELL")
        upsell_list = None
        if upsell_data:
            if isinstance(upsell_data, list):
                upsell_list = [u.get("UPSELLAK", "") for u in upsell_data]
            else:
                upsell_list = [upsell_data.get("UPSELLAK", "")]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            upsell_list=upsell_list,
        )


@dataclass
class CheckShopCartUpsellAndAvailabilityResponse:
    """Response for CheckShopCartUpsellAndAvailability operation.
    
    Based on Upsell.xsd CHECKSHOPCARTUPSELLANDAVAILABILITYRESP type.
    
    Attributes:
        error: Error information
        upsell_list: List of upsells with availability (optional)
    """
    
    error: Error
    upsell_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "CheckShopCartUpsellAndAvailabilityResponse":
        """Create CheckShopCartUpsellAndAvailabilityResponse from API response dictionary."""
        upsell_data = data.get("UPSELLLIST", {}).get("UPSELL")
        upsell_list = None
        if upsell_data:
            if isinstance(upsell_data, list):
                upsell_list = upsell_data
            else:
                upsell_list = [upsell_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            upsell_list=upsell_list,
        )
