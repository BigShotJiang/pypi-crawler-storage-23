"""
Type definitions for ReservationEnquiry.

This module provides structured classes for reservation operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, BaseDateFilter, PageRequest, PageResponse


# Request Classes
@dataclass
class SearchReservationRequest:
    """Request for SearchReservation operation.
    
    Based on ReservationEnquiry.xsd SEARCHRESERVATIONREQ type.
    
    Attributes:
        current_user_only: Current user only flag
        current_op_area_only: Current operation area only flag
        event_filter_list: Event filter list (optional)
        performance_filter_list: Performance filter list (optional)
        account: Account filter (optional)
        sale_date: Sale date filter (optional)
        visit_date: Visit date filter (optional)
        last_modified_date: Last modified date filter (optional)
        flag: Order status flag (optional)
        status_code: Status code (optional)
        page_req: Page request (optional)
        reservation: Reservation filter (optional)
        pick_up_date: Pick up date filter (optional)
        workstation_filter_list: Workstation filter list (optional)
        sale_ak: Sale AK (optional)
        promotion_filter_list: Promotion filter list (optional)
        account_list: Account list (optional)
    """
    
    current_user_only: bool
    current_op_area_only: bool
    event_filter_list: Optional[List[str]] = None
    performance_filter_list: Optional[List[str]] = None
    account: Optional[Dict[str, Any]] = None
    sale_date: Optional[BaseDateFilter] = None
    visit_date: Optional[BaseDateFilter] = None
    last_modified_date: Optional[BaseDateFilter] = None
    flag: Optional[Dict[str, Any]] = None
    status_code: Optional[int] = None
    page_req: Optional[PageRequest] = None
    reservation: Optional[Dict[str, str]] = None
    pick_up_date: Optional[BaseDateFilter] = None
    workstation_filter_list: Optional[List[str]] = None
    sale_ak: Optional[str] = None
    promotion_filter_list: Optional[List[Dict[str, str]]] = None
    account_list: Optional[List[Dict[str, Any]]] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "CURRENTUSERONLY": self.current_user_only,
            "CURRENTOPAREAONLY": self.current_op_area_only,
        }
        if self.event_filter_list is not None:
            result["EVENTFILTERLIST"] = {
                "EVENTFILTERITEM": [{"AK": ak} for ak in self.event_filter_list]
            }
        if self.performance_filter_list is not None:
            result["PERFORMANCEFILTERLIST"] = {
                "PERFORMANCEFILTERITEM": [{"AK": ak} for ak in self.performance_filter_list]
            }
        if self.account is not None:
            result["ACCOUNT"] = self.account
        if self.sale_date is not None:
            result["SALEDATE"] = self.sale_date.to_dict()
        if self.visit_date is not None:
            result["VISITDATE"] = self.visit_date.to_dict()
        if self.last_modified_date is not None:
            result["LASTMODIFIEDDATE"] = self.last_modified_date.to_dict()
        if self.flag is not None:
            result["FLAG"] = self.flag
        if self.status_code is not None:
            result["STATUSCODE"] = self.status_code
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        if self.reservation is not None:
            result["RESERVATION"] = self.reservation
        if self.pick_up_date is not None:
            result["PICKUPDATE"] = self.pick_up_date.to_dict()
        if self.workstation_filter_list is not None:
            result["WORKSTATIONFILTERLIST"] = {
                "WORKSTATIONFILTERITEM": [{"AK": ak} for ak in self.workstation_filter_list]
            }
        if self.sale_ak is not None:
            result["SALEAK"] = self.sale_ak
        if self.promotion_filter_list is not None:
            result["PROMOTIONFILTERLIST"] = {
                "PROMOTIONFILTER": self.promotion_filter_list
            }
        if self.account_list is not None:
            result["ACCOUNTLIST"] = {
                "OWNERLIST": {"OWNERITEM": [{"OWNER": owner} for owner in self.account_list]}
            }
        return result


@dataclass
class ExportReservationCSVRequest:
    """Request for ExportReservationCSV operation.
    
    Based on ReservationEnquiry.xsd EXPORTRESERVATIONCSVREQ type.
    
    Attributes:
        account: Account filter (optional)
        sale_date: Sale date filter (optional)
        reservation: Reservation filter (optional)
        pick_up_date: Pick up date filter (optional)
    """
    
    account: Optional[Dict[str, Any]] = None
    sale_date: Optional[BaseDateFilter] = None
    reservation: Optional[Dict[str, str]] = None
    pick_up_date: Optional[BaseDateFilter] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.account is not None:
            result["ACCOUNT"] = self.account
        if self.sale_date is not None:
            result["SALEDATE"] = self.sale_date.to_dict()
        if self.reservation is not None:
            result["RESERVATION"] = self.reservation
        if self.pick_up_date is not None:
            result["PICKUPDATE"] = self.pick_up_date.to_dict()
        return result


@dataclass
class ExportReservationCSV_V2Request:
    """Request for ExportReservationCSV_V2 operation.
    
    Based on ReservationEnquiry.xsd EXPORTRESERVATIONCSV_V2REQ type.
    
    Attributes:
        sale_date: Sale date filter
        reservation: Reservation filter (optional)
        pick_up_date: Pick up date filter (optional)
        account: Account filter (optional)
    """
    
    sale_date: BaseDateFilter
    reservation: Optional[Dict[str, str]] = None
    pick_up_date: Optional[BaseDateFilter] = None
    account: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"SALEDATE": self.sale_date.to_dict()}
        if self.reservation is not None:
            result["RESERVATION"] = self.reservation
        if self.pick_up_date is not None:
            result["PICKUPDATE"] = self.pick_up_date.to_dict()
        if self.account is not None:
            result["ACCOUNT"] = self.account
        return result


@dataclass
class ExportReservationRequest:
    """Request for ExportReservation operation.
    
    Based on ReservationEnquiry.xsd EXPORTRESERVATIONREQ type.
    
    Attributes:
        account: Account filter (optional)
        sale_date: Sale date filter (optional)
        reservation: Reservation filter (optional)
        pick_up_date: Pick up date filter (optional)
        export_type: Export type (optional)
    """
    
    account: Optional[Dict[str, Any]] = None
    sale_date: Optional[BaseDateFilter] = None
    reservation: Optional[Dict[str, str]] = None
    pick_up_date: Optional[BaseDateFilter] = None
    export_type: Optional[Dict[str, bool]] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.account is not None:
            result["ACCOUNT"] = self.account
        if self.sale_date is not None:
            result["SALEDATE"] = self.sale_date.to_dict()
        if self.reservation is not None:
            result["RESERVATION"] = self.reservation
        if self.pick_up_date is not None:
            result["PICKUPDATE"] = self.pick_up_date.to_dict()
        if self.export_type is not None:
            result["EXPORTTYPE"] = self.export_type
        return result


@dataclass
class SearchReservationTicketRequest:
    """Request for SearchReservationTicket operation.
    
    Based on ReservationEnquiry.xsd SEARCHRESERVATIONTICKETREQ type.
    
    Attributes:
        product_ak_list: Product AK list (optional)
        static_group_list: Static group list (optional)
        workstation_ak: Workstation AK (optional)
        account: Account filter (optional)
        sale_status: Sale status (optional)
        last_modified_date: Last modified date filter (optional)
        has_ticket_owner_account: Has ticket owner account flag (optional)
        page_req: Page request (optional)
    """
    
    product_ak_list: Optional[List[str]] = None
    static_group_list: Optional[List[Dict[str, str]]] = None
    workstation_ak: Optional[str] = None
    account: Optional[Dict[str, Any]] = None
    sale_status: Optional[int] = None
    last_modified_date: Optional[BaseDateFilter] = None
    has_ticket_owner_account: Optional[int] = None
    page_req: Optional[PageRequest] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.product_ak_list is not None:
            result["PRODUCTAKLIST"] = {
                "PRODUCTAKITEM": [{"AK": ak} for ak in self.product_ak_list]
            }
        if self.static_group_list is not None:
            result["STATICGROUPLIST"] = {
                "STATICGROUPITEM": self.static_group_list
            }
        if self.workstation_ak is not None:
            result["WORKSTATIONAK"] = self.workstation_ak
        if self.account is not None:
            result["ACCOUNT"] = self.account
        if self.sale_status is not None:
            result["SALESTATUS"] = self.sale_status
        if self.last_modified_date is not None:
            result["LASTMODIFIEDDATE"] = self.last_modified_date.to_dict()
        if self.has_ticket_owner_account is not None:
            result["HASTICKETOWNERACCOUNT"] = self.has_ticket_owner_account
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        return result


# Response Classes
@dataclass
class SearchReservationResponse:
    """Response for SearchReservation operation.
    
    Based on ReservationEnquiry.xsd SEARCHRESERVATIONRESP type.
    
    Attributes:
        error: Error information
        reservation_item_list: List of reservation items
        page_resp: Page response
        grand_total: Grand total information
    """
    
    error: Error
    reservation_item_list: List[Dict[str, Any]]
    page_resp: PageResponse
    grand_total: Dict[str, Any]
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchReservationResponse":
        """Create SearchReservationResponse from API response dictionary."""
        reservation_data = data.get("RESERVATIONITEMLIST", {}).get("RESERVATIONITEM")
        reservation_list = []
        if reservation_data:
            if isinstance(reservation_data, list):
                reservation_list = reservation_data
            else:
                reservation_list = [reservation_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            reservation_item_list=reservation_list,
            page_resp=PageResponse.from_dict(data.get("PAGERESP", {})),
            grand_total=data.get("GRANDTOTAL", {}),
        )


@dataclass
class ResendReservationEmailResponse:
    """Response for ResendReservationEmail operation.
    
    Based on ReservationEnquiry.xsd RESENDRESERVATIONEMAILRESP type.
    
    Attributes:
        error: Error information
        reservation: Reservation information (optional)
    """
    
    error: Error
    reservation: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ResendReservationEmailResponse":
        """Create ResendReservationEmailResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            reservation=data.get("RESERVATION"),
        )


@dataclass
class ExportReservationCSVResponse:
    """Response for ExportReservationCSV operation.
    
    Based on ReservationEnquiry.xsd EXPORTRESERVATIONCSVRESP type.
    
    Attributes:
        error: Error information
        data: CSV data (hexBinary, optional)
    """
    
    error: Error
    data: Optional[bytes] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ExportReservationCSVResponse":
        """Create ExportReservationCSVResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            data=data.get("DATA"),
        )


@dataclass
class ExportReservationResponse:
    """Response for ExportReservation operation.
    
    Based on ReservationEnquiry.xsd EXPORTRESERVATIONRESP type.
    
    Attributes:
        error: Error information
        data: Export data (hexBinary, optional)
        filename: Filename (optional)
    """
    
    error: Error
    data: Optional[bytes] = None
    filename: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ExportReservationResponse":
        """Create ExportReservationResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            data=data.get("DATA"),
            filename=data.get("FILENAME"),
        )


@dataclass
class SearchReservationTicketResponse:
    """Response for SearchReservationTicket operation.
    
    Based on ReservationEnquiry.xsd SEARCHRESERVATIONTICKETRESP type.
    
    Attributes:
        error: Error information
        reservation_item_list: List of reservation items with tickets
        page_resp: Page response
    """
    
    error: Error
    reservation_item_list: List[Dict[str, Any]]
    page_resp: PageResponse
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchReservationTicketResponse":
        """Create SearchReservationTicketResponse from API response dictionary."""
        reservation_data = data.get("RESERVATIONITEMLIST", {}).get("RESERVATIONITEM")
        reservation_list = []
        if reservation_data:
            if isinstance(reservation_data, list):
                reservation_list = reservation_data
            else:
                reservation_list = [reservation_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            reservation_item_list=reservation_list,
            page_resp=PageResponse.from_dict(data.get("PAGERESP", {})),
        )
