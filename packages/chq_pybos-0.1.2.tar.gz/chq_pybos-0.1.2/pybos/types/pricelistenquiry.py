"""
Type definitions for PriceListEnquiry.

This module provides structured classes for price list operations.
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any
from .common import Error


# Response Classes
@dataclass
class ReadPriceListByAKResponse:
    """Response for ReadPriceListByAK operation.
    
    Based on PriceListEnquiry.xsd READPRICELISTBYAKRESP type.
    
    Attributes:
        error: Error information
        price_list: Price list information (optional)
    """
    
    error: Error
    price_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadPriceListByAKResponse":
        """Create ReadPriceListByAKResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            price_list=data.get("PRICELIST"),
        )


@dataclass
class ReadPriceListByIdResponse:
    """Response for ReadPriceListById operation.
    
    Based on PriceListEnquiry.xsd READPRICELISTBYIDRESP type.
    
    Attributes:
        error: Error information
        price_list: Price list information (optional)
    """
    
    error: Error
    price_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadPriceListByIdResponse":
        """Create ReadPriceListByIdResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            price_list=data.get("PRICELIST"),
        )
