"""
Type definitions for Capacity service.

This module provides structured classes for capacity operations.
"""

from dataclasses import dataclass
from typing import List, Dict, Any
from .common import Error


# Request Classes
@dataclass
class ReleaseCapacityRequest:
    """Request for ReleaseCapacity operation.
    
    Based on Capacity.xsd RELEASECAPACITYREQ type.
    
    Attributes:
        guid_list: List of GUIDs to release
    """
    
    guid_list: List[str]
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"GUIDLIST": {"GUID": self.guid_list}}


@dataclass
class EditCapacityRequest:
    """Request for EditCapacity operation.
    
    Based on Capacity.xsd EDITCAPACITYREQ type.
    
    Attributes:
        search_performance: Search performance filter
        edit_capacity_list: List of capacity edit items
    """
    
    search_performance: Dict[str, Any]  # SEARCHPERFORMANCE type
    edit_capacity_list: List[Dict[str, Any]]  # EDITCAPACITYITEM list
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "SEARCHPERFORMANCE": self.search_performance,
            "EDITCAPACITYLIST": {
                "EDITCAPACITYITEM": self.edit_capacity_list
            },
        }


# Response Classes
@dataclass
class ReleaseCapacityResponse:
    """Response for ReleaseCapacity operation.
    
    Based on Capacity.xsd RELEASECAPACITYRESP type.
    
    Attributes:
        error: Error information
    """
    
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReleaseCapacityResponse":
        """Create ReleaseCapacityResponse from API response dictionary."""
        return cls(error=Error.from_dict(data.get("ERROR", {})))


@dataclass
class EditCapacityResponse:
    """Response for EditCapacity operation.
    
    Based on Capacity.xsd EDITCAPACITYRESP type.
    
    Attributes:
        error: Error information
        performance_list: Performance list
    """
    
    error: Error
    performance_list: Dict[str, Any]  # PERFORMANCELIST2 type
    
    @classmethod
    def from_dict(cls, data: dict) -> "EditCapacityResponse":
        """Create EditCapacityResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            performance_list=data.get("PERFORMANCELIST", {}),
        )
