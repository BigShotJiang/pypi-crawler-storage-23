"""
Type definitions for Invoice service.

This module provides structured classes for invoice operations.
"""

from dataclasses import dataclass
from .common import Error


# Response Classes
@dataclass
class GetShift4InvoiceNoResponse:
    """Response for GetShift4InvoiceNo operation.
    
    Based on IWsAPIInvoice.xml INVOICERESP type.
    
    Attributes:
        error: Error information
        invoice: Invoice number
    """
    
    error: Error
    invoice: int
    
    @classmethod
    def from_dict(cls, data: dict) -> "GetShift4InvoiceNoResponse":
        """Create GetShift4InvoiceNoResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            invoice=data.get("INVOICE", 0),
        )
