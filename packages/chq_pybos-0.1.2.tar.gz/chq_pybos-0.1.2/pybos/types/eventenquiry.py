"""
Type definitions for EventEnquiry.

This module provides structured classes for event operations,
replacing tuple-based parameters with type-safe, self-documenting classes.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, BaseDateFilter, BaseTimeFilter, PageRequest, PageResponse, LocationBase


@dataclass
class Availability:
    """Availability information structure.
    
    Based on APICommon.xsd AVAILABILITY type.
    
    Attributes:
        total: Total availability
        available: Available count
        general_admission: General admission flag
    """
    
    total: int
    available: int
    general_admission: bool
    
    @classmethod
    def from_dict(cls, data: dict) -> "Availability":
        """Create Availability from API response dictionary."""
        return cls(
            total=data.get("TOTAL", 0),
            available=data.get("AVAILABLE", 0),
            general_admission=data.get("GENERALADMISSION", False),
        )
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "TOTAL": self.total,
            "AVAILABLE": self.available,
            "GENERALADMISSION": self.general_admission,
        }


@dataclass
class Category:
    """Category information structure.
    
    Based on EventEnquiry.xsd CATEGORY type.
    
    Attributes:
        code: Category code
    """
    
    code: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "Category":
        """Create Category from API response dictionary."""
        return cls(code=data.get("CODE", ""))
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"CODE": self.code}


@dataclass
class Event:
    """Event information structure.
    
    Based on EventEnquiry.xsd EVENT type.
    
    Attributes:
        ak: Event AK
        code: Event code
        name: Event name
        start_date: Event start date
        end_date: Event end date
        location: Location information
        status: Event status (0: Closed, 1: OnSale, 2: Suspended, 3: Informative, 4: Waiting)
        sellable: Whether event is sellable
        availability: Availability information
        i18n_list: Internationalization list (optional)
        max_per_transaction: Max per transaction (optional)
        event_category_list: Event category list (optional)
        sort_order: Sort order (optional)
        first_sellable_performance_date: First sellable performance date (optional)
    """
    
    ak: str
    code: str
    name: str
    start_date: str
    end_date: str
    location: LocationBase
    status: int
    sellable: bool
    availability: Availability
    i18n_list: Optional[Dict[str, Any]] = None
    max_per_transaction: Optional[int] = None
    event_category_list: Optional[List[Dict[str, Any]]] = None
    sort_order: Optional[int] = None
    first_sellable_performance_date: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "Event":
        """Create Event from API response dictionary."""
        location_data = data.get("LOCATION", {})
        availability_data = data.get("AVAILABILITY", {})
        event_category_data = data.get("EVENTCATEGORYLIST", {}).get("EVENTCATEGORY")
        return cls(
            ak=data.get("AK", ""),
            code=data.get("CODE", ""),
            name=data.get("NAME", ""),
            start_date=data.get("STARTDATE", ""),
            end_date=data.get("ENDDATE", ""),
            location=LocationBase.from_dict(location_data) if location_data else LocationBase(ak="", code=""),
            status=data.get("STATUS", 0),
            sellable=data.get("SELLABLE", False),
            availability=Availability.from_dict(availability_data) if availability_data else Availability(total=0, available=0, general_admission=False),
            i18n_list=data.get("I18NLIST"),
            max_per_transaction=data.get("MAXPERTRANSACTION"),
            event_category_list=event_category_data if isinstance(event_category_data, list) else [event_category_data] if event_category_data else None,
            sort_order=data.get("SORTORDER"),
            first_sellable_performance_date=data.get("FIRSTSELLABLEPERFORMANCEDATE"),
        )


@dataclass
class SearchEventRequest:
    """Request for SearchEvent operation.
    
    Based on EventEnquiry.xsd SEARCHEVENTREQ type.
    
    Attributes:
        date: Date filter (optional)
        time: Time filter (optional)
        event_list: Event list (optional)
        event_category_list: Event category list (optional)
        location_ak: Location AK (optional)
        account_ak: Account AK (optional)
        page_req: Page request (optional)
        event_status: Event status (optional)
        number_of_person: Number of person (optional)
        return_ext_code: Return external code (optional)
        dmg_category_list: DMG category list (optional)
        filter_list: Filter list (optional)
    """
    
    date: Optional[BaseDateFilter] = None
    time: Optional[BaseTimeFilter] = None
    event_list: Optional[List[Dict[str, Any]]] = None
    event_category_list: Optional[List[Category]] = None
    location_ak: Optional[str] = None
    account_ak: Optional[str] = None
    page_req: Optional[PageRequest] = None
    event_status: Optional[int] = None
    number_of_person: Optional[int] = None
    return_ext_code: Optional[bool] = None
    dmg_category_list: Optional[List[Dict[str, str]]] = None
    filter_list: Optional[List[Dict[str, Any]]] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.date is not None:
            result["DATE"] = self.date.to_dict()
        if self.time is not None:
            result["TIME"] = self.time.to_dict()
        if self.event_list is not None:
            result["EVENTLIST"] = {"EVENTITEM": self.event_list}
        if self.event_category_list is not None:
            result["EVENTCATEGORYLIST"] = {
                "EVENTCATEGORY": [cat.to_dict() for cat in self.event_category_list]
            }
        if self.location_ak is not None:
            result["LOCATIONAK"] = self.location_ak
        if self.account_ak is not None:
            result["ACCOUNTAK"] = self.account_ak
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        if self.event_status is not None:
            result["EVENTSTATUS"] = self.event_status
        if self.number_of_person is not None:
            result["NUMBEROFPERSON"] = self.number_of_person
        if self.return_ext_code is not None:
            result["RETURNEXTCODE"] = self.return_ext_code
        if self.dmg_category_list is not None:
            result["DMGCATEGORYLIST"] = {
                "DMGCATEGORY": [{"DMGCATEGORYAK": cat.get("DMGCATEGORYAK", "")} for cat in self.dmg_category_list]
            }
        if self.filter_list is not None:
            result["FILTERLIST"] = {"FILTER": self.filter_list}
        return result


@dataclass
class CreateEventRequest:
    """Request for CreateEvent operation.
    
    Based on EventEnquiry.xsd CREATEEVENTREQ type.
    
    Attributes:
        code: Event code
        title: Event title
        store_ak: Store AK
        start_date: Start date
        end_date: End date
        description: Description (optional)
        color: Color (optional)
        location_ak: Location AK (optional)
        access_configuration_id: Access configuration ID (optional)
        price_table_ak: Price table AK (optional)
        external_code: External code (optional)
        waitlist_enabled: Waitlist enabled (optional)
        event_category_list: Event category list (optional)
        status: Status (optional)
        one_trans_performance: One transaction per performance (optional)
        allow_notification: Allow notification (optional)
        integration_type: Integration type (optional)
        performance_template: Performance template (optional)
        money_card: Money card (optional)
        tvm_settings: TVM settings (optional)
        classification: Classification (optional)
        permissions: Permissions (optional)
    """
    
    code: str
    title: str
    store_ak: str
    start_date: str
    end_date: str
    description: Optional[str] = None
    color: Optional[str] = None
    location_ak: Optional[str] = None
    access_configuration_id: Optional[int] = None
    price_table_ak: Optional[str] = None
    external_code: Optional[str] = None
    waitlist_enabled: Optional[bool] = None
    event_category_list: Optional[List[Category]] = None
    status: Optional[int] = None
    one_trans_performance: Optional[bool] = None
    allow_notification: Optional[bool] = None
    integration_type: Optional[int] = None
    performance_template: Optional[Dict[str, Any]] = None
    money_card: Optional[Dict[str, Any]] = None
    tvm_settings: Optional[Dict[str, Any]] = None
    classification: Optional[Dict[str, Any]] = None
    permissions: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "CODE": self.code,
            "TITLE": self.title,
            "STOREAK": self.store_ak,
            "STARTDATE": self.start_date,
            "ENDDATE": self.end_date,
        }
        if self.description is not None:
            result["DESCRIPTION"] = self.description
        if self.color is not None:
            result["COLOR"] = self.color
        if self.location_ak is not None:
            result["LOCATIONAK"] = self.location_ak
        if self.access_configuration_id is not None:
            result["ACCESSCONFIGURATIONID"] = self.access_configuration_id
        if self.price_table_ak is not None:
            result["PRICETABLEAK"] = self.price_table_ak
        if self.external_code is not None:
            result["EXTERNALCODE"] = self.external_code
        if self.waitlist_enabled is not None:
            result["WAITLISTENABLED"] = self.waitlist_enabled
        if self.event_category_list is not None:
            result["EVENTCATEGORYLIST"] = {
                "EVENTCATEGORY": [cat.to_dict() for cat in self.event_category_list]
            }
        if self.status is not None:
            result["STATUS"] = self.status
        if self.one_trans_performance is not None:
            result["ONETRANSPERPERFORMANCE"] = self.one_trans_performance
        if self.allow_notification is not None:
            result["ALLOWNOTIFICATION"] = self.allow_notification
        if self.integration_type is not None:
            result["INTEGRATIONTYPE"] = self.integration_type
        if self.performance_template is not None:
            result["PERFORMANCETEMPLATE"] = self.performance_template
        if self.money_card is not None:
            result["MONEYCARD"] = self.money_card
        if self.tvm_settings is not None:
            result["TVMSETTINGS"] = self.tvm_settings
        if self.classification is not None:
            result["CLASSIFICATION"] = self.classification
        if self.permissions is not None:
            result["PERMISSIONS"] = self.permissions
        return result


@dataclass
class UpdateEventRequest:
    """Request for UpdateEvent operation.
    
    Based on EventEnquiry.xsd UPDATEEVENTREQ type.
    
    Attributes:
        event_ak: Event AK
        code: Event code (optional)
        title: Event title (optional)
        description: Description (optional)
        color: Color (optional)
        store_ak: Store AK (optional)
        location_ak: Location AK (optional)
        access_configuration_id: Access configuration ID (optional)
        price_table_ak: Price table AK (optional)
        external_code: External code (optional)
        waitlist_enabled: Waitlist enabled (optional)
        event_category_list: Event category list (optional)
        status: Status (optional)
        one_trans_performance: One transaction per performance (optional)
        allow_notification: Allow notification (optional)
        start_date: Start date (optional)
        end_date: End date (optional)
        integration_type: Integration type (optional)
        performance_template: Performance template (optional)
        money_card: Money card (optional)
        tvm_settings: TVM settings (optional)
        classification: Classification (optional)
        permissions: Permissions (optional)
    """
    
    event_ak: str
    code: Optional[str] = None
    title: Optional[str] = None
    description: Optional[str] = None
    color: Optional[str] = None
    store_ak: Optional[str] = None
    location_ak: Optional[str] = None
    access_configuration_id: Optional[int] = None
    price_table_ak: Optional[str] = None
    external_code: Optional[str] = None
    waitlist_enabled: Optional[bool] = None
    event_category_list: Optional[List[Category]] = None
    status: Optional[int] = None
    one_trans_performance: Optional[bool] = None
    allow_notification: Optional[bool] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    integration_type: Optional[int] = None
    performance_template: Optional[Dict[str, Any]] = None
    money_card: Optional[Dict[str, Any]] = None
    tvm_settings: Optional[Dict[str, Any]] = None
    classification: Optional[Dict[str, Any]] = None
    permissions: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"EVENTAK": self.event_ak}
        if self.code is not None:
            result["CODE"] = self.code
        if self.title is not None:
            result["TITLE"] = self.title
        if self.description is not None:
            result["DESCRIPTION"] = self.description
        if self.color is not None:
            result["COLOR"] = self.color
        if self.store_ak is not None:
            result["STOREAK"] = self.store_ak
        if self.location_ak is not None:
            result["LOCATIONAK"] = self.location_ak
        if self.access_configuration_id is not None:
            result["ACCESSCONFIGURATIONID"] = self.access_configuration_id
        if self.price_table_ak is not None:
            result["PRICETABLEAK"] = self.price_table_ak
        if self.external_code is not None:
            result["EXTERNALCODE"] = self.external_code
        if self.waitlist_enabled is not None:
            result["WAITLISTENABLED"] = self.waitlist_enabled
        if self.event_category_list is not None:
            result["EVENTCATEGORYLIST"] = {
                "EVENTCATEGORY": [cat.to_dict() for cat in self.event_category_list]
            }
        if self.status is not None:
            result["STATUS"] = self.status
        if self.one_trans_performance is not None:
            result["ONETRANSPERPERFORMANCE"] = self.one_trans_performance
        if self.allow_notification is not None:
            result["ALLOWNOTIFICATION"] = self.allow_notification
        if self.start_date is not None:
            result["STARTDATE"] = self.start_date
        if self.end_date is not None:
            result["ENDDATE"] = self.end_date
        if self.integration_type is not None:
            result["INTEGRATIONTYPE"] = self.integration_type
        if self.performance_template is not None:
            result["PERFORMANCETEMPLATE"] = self.performance_template
        if self.money_card is not None:
            result["MONEYCARD"] = self.money_card
        if self.tvm_settings is not None:
            result["TVMSETTINGS"] = self.tvm_settings
        if self.classification is not None:
            result["CLASSIFICATION"] = self.classification
        if self.permissions is not None:
            result["PERMISSIONS"] = self.permissions
        return result


# Response Classes
@dataclass
class FindAllEventsResponse:
    """Response for FindAllEvents operation.
    
    Based on EventEnquiry.xsd FINDALLEVENTSRESP type.
    
    Attributes:
        error: Error information
        event_list: List of events (optional)
    """
    
    error: Error
    event_list: Optional[List[Event]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllEventsResponse":
        """Create FindAllEventsResponse from API response dictionary."""
        event_list_data = data.get("EVENTLIST", {}).get("EVENT")
        event_list = None
        if event_list_data:
            if isinstance(event_list_data, list):
                event_list = [Event.from_dict(e) for e in event_list_data]
            else:
                event_list = [Event.from_dict(event_list_data)]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            event_list=event_list,
        )


@dataclass
class ReadEventByCodeResponse:
    """Response for ReadEventByCode operation.
    
    Based on EventEnquiry.xsd READEVENTBYCODERESP type.
    
    Attributes:
        error: Error information
        event: Event information (optional)
    """
    
    error: Error
    event: Optional[Event] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadEventByCodeResponse":
        """Create ReadEventByCodeResponse from API response dictionary."""
        event_data = data.get("EVENT")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            event=Event.from_dict(event_data) if event_data else None,
        )


@dataclass
class ReadEventByAKResponse:
    """Response for ReadEventByAK operation.
    
    Based on EventEnquiry.xsd READEVENTBYAKRESP type.
    
    Attributes:
        error: Error information
        event: Event information (optional)
    """
    
    error: Error
    event: Optional[Event] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadEventByAKResponse":
        """Create ReadEventByAKResponse from API response dictionary."""
        event_data = data.get("EVENT")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            event=Event.from_dict(event_data) if event_data else None,
        )


@dataclass
class FindAllEventCategoryResponse:
    """Response for FindAllEventCategory operation.
    
    Based on EventEnquiry.xsd FINDALLEVENTCATEGORYRESP type.
    
    Attributes:
        error: Error information
        category_list: List of categories (optional)
    """
    
    error: Error
    category_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllEventCategoryResponse":
        """Create FindAllEventCategoryResponse from API response dictionary."""
        category_data = data.get("CATEGORYLIST", {}).get("CATEGORY")
        category_list = None
        if category_data:
            if isinstance(category_data, list):
                category_list = category_data
            else:
                category_list = [category_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            category_list=category_list,
        )


@dataclass
class FindEventsByAccountAKResponse:
    """Response for FindEventsByAccountAK operation.
    
    Based on EventEnquiry.xsd FINDEVENTSBYACCOUNTAKRESP type.
    
    Attributes:
        error: Error information
        event_list: List of events (optional)
    """
    
    error: Error
    event_list: Optional[List[Event]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindEventsByAccountAKResponse":
        """Create FindEventsByAccountAKResponse from API response dictionary."""
        event_list_data = data.get("EVENTLIST", {}).get("EVENT")
        event_list = None
        if event_list_data:
            if isinstance(event_list_data, list):
                event_list = [Event.from_dict(e) for e in event_list_data]
            else:
                event_list = [Event.from_dict(event_list_data)]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            event_list=event_list,
        )


@dataclass
class SearchEventResponse:
    """Response for SearchEvent operation.
    
    Based on EventEnquiry.xsd SEARCHEVENTRESP type.
    
    Attributes:
        error: Error information
        event_list: List of events (optional)
        page_resp: Page response (optional)
    """
    
    error: Error
    event_list: Optional[List[Event]] = None
    page_resp: Optional[PageResponse] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchEventResponse":
        """Create SearchEventResponse from API response dictionary."""
        event_list_data = data.get("EVENTLIST", {}).get("EVENT")
        event_list = None
        if event_list_data:
            if isinstance(event_list_data, list):
                event_list = [Event.from_dict(e) for e in event_list_data]
            else:
                event_list = [Event.from_dict(event_list_data)]
        page_resp_data = data.get("PAGERESP")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            event_list=event_list,
            page_resp=PageResponse.from_dict(page_resp_data) if page_resp_data else None,
        )


@dataclass
class CreateEventResponse:
    """Response for CreateEvent operation.
    
    Based on EventEnquiry.xsd CREATEEVENTRESP type.
    
    Attributes:
        error: Error information
        event_ak: Event AK
    """
    
    error: Error
    event_ak: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "CreateEventResponse":
        """Create CreateEventResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            event_ak=data.get("EVENTAK", ""),
        )


@dataclass
class UpdateEventResponse:
    """Response for UpdateEvent operation.
    
    Based on EventEnquiry.xsd UPDATEEVENTRESP type.
    
    Attributes:
        error: Error information
        event_ak: Event AK
    """
    
    error: Error
    event_ak: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "UpdateEventResponse":
        """Create UpdateEventResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            event_ak=data.get("EVENTAK", ""),
        )
