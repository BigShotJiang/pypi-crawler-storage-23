"""
Type definitions for PerformanceEnquiry.

This module provides structured classes for performance operations,
replacing tuple-based parameters with type-safe, self-documenting classes.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, BaseDateFilter, BaseTimeFilter, PageRequest, PageResponse, PerformanceBase, EventBase


# Supporting Types
@dataclass
class Category:
    """Category information structure."""
    code: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "Category":
        return cls(code=data.get("CODE", ""))
    
    def to_dict(self) -> dict:
        return {"CODE": self.code}


@dataclass
class Availability:
    """Availability information structure."""
    total: int
    available: int
    general_admission: bool
    
    @classmethod
    def from_dict(cls, data: dict) -> "Availability":
        return cls(
            total=data.get("TOTAL", 0),
            available=data.get("AVAILABLE", 0),
            general_admission=data.get("GENERALADMISSION", False),
        )
    
    def to_dict(self) -> dict:
        return {
            "TOTAL": self.total,
            "AVAILABLE": self.available,
            "GENERALADMISSION": self.general_admission,
        }


@dataclass
class PerformanceCategoryList:
    """List of performance categories."""
    performance_category: List[Category]
    
    @classmethod
    def from_dict(cls, data: dict) -> "PerformanceCategoryList":
        categories = data.get("PERFORMANCECATEGORY", [])
        if not isinstance(categories, list):
            categories = [categories] if categories else []
        return cls(
            performance_category=[Category.from_dict(cat) for cat in categories]
        )
    
    def to_dict(self) -> dict:
        return {
            "PERFORMANCECATEGORY": [cat.to_dict() for cat in self.performance_category]
        }


@dataclass
class EventCategoryList:
    """List of event categories."""
    event_category: List[Category]
    
    @classmethod
    def from_dict(cls, data: dict) -> "EventCategoryList":
        categories = data.get("EVENTCATEGORY", [])
        if not isinstance(categories, list):
            categories = [categories] if categories else []
        return cls(
            event_category=[Category.from_dict(cat) for cat in categories]
        )
    
    def to_dict(self) -> dict:
        return {
            "EVENTCATEGORY": [cat.to_dict() for cat in self.event_category]
        }


@dataclass
class CartPerformanceList:
    """List of cart performances."""
    performance: List[Dict[str, str]]  # List of {"AK": "..."}
    
    @classmethod
    def from_dict(cls, data: dict) -> "CartPerformanceList":
        perfs = data.get("PERFORMANCE", [])
        if not isinstance(perfs, list):
            perfs = [perfs] if perfs else []
        return cls(performance=perfs)
    
    def to_dict(self) -> dict:
        return {
            "PERFORMANCE": self.performance
        }


@dataclass
class PerformanceListBasic:
    """Basic performance list structure."""
    performance: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "PerformanceListBasic":
        perfs = data.get("PERFORMANCE", [])
        if not isinstance(perfs, list):
            perfs = [perfs] if perfs else []
        return cls(performance=perfs)
    
    def to_dict(self) -> dict:
        return {
            "PERFORMANCE": self.performance
        }


@dataclass
class Day:
    """Day information with performances and availability."""
    date: str
    availability: Availability
    performance_list: Optional[PerformanceListBasic] = None
    min_price: Optional[float] = None
    max_price: Optional[float] = None
    calculated_range_price: Optional[Dict[str, float]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "Day":
        return cls(
            date=data.get("DATE", ""),
            availability=Availability.from_dict(data.get("AVAILABILITY", {})),
            performance_list=PerformanceListBasic.from_dict(data["PERFORMANCELIST"]) if data.get("PERFORMANCELIST") else None,
            min_price=data.get("MINPRICE"),
            max_price=data.get("MAXPRICE"),
            calculated_range_price=data.get("CALCULATEDRANGEPRICE"),
        )
    
    def to_dict(self) -> dict:
        result = {
            "DATE": self.date,
            "AVAILABILITY": self.availability.to_dict(),
        }
        if self.performance_list:
            result["PERFORMANCELIST"] = self.performance_list.to_dict()
        if self.min_price is not None:
            result["MINPRICE"] = self.min_price
        if self.max_price is not None:
            result["MAXPRICE"] = self.max_price
        if self.calculated_range_price:
            result["CALCULATEDRANGEPRICE"] = self.calculated_range_price
        return result


@dataclass
class DayList:
    """List of days."""
    day: List[Day]
    
    @classmethod
    def from_dict(cls, data: dict) -> "DayList":
        days = data.get("DAY", [])
        if not isinstance(days, list):
            days = [days] if days else []
        return cls(day=[Day.from_dict(d) for d in days])
    
    def to_dict(self) -> dict:
        return {
            "DAY": [d.to_dict() for d in self.day]
        }


@dataclass
class CalendarDay:
    """Calendar day information."""
    date: str
    availability: Availability
    min_price: Optional[float] = None
    max_price: Optional[float] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "CalendarDay":
        return cls(
            date=data.get("DATE", ""),
            availability=Availability.from_dict(data.get("AVAILABILITY", {})),
            min_price=data.get("MINPRICE"),
            max_price=data.get("MAXPRICE"),
        )
    
    def to_dict(self) -> dict:
        result = {
            "DATE": self.date,
            "AVAILABILITY": self.availability.to_dict(),
        }
        if self.min_price is not None:
            result["MINPRICE"] = self.min_price
        if self.max_price is not None:
            result["MAXPRICE"] = self.max_price
        return result


@dataclass
class CalendarDayList:
    """List of calendar days."""
    day: List[CalendarDay]
    
    @classmethod
    def from_dict(cls, data: dict) -> "CalendarDayList":
        days = data.get("DAY", [])
        if not isinstance(days, list):
            days = [days] if days else []
        return cls(day=[CalendarDay.from_dict(d) for d in days])
    
    def to_dict(self) -> dict:
        return {
            "DAY": [d.to_dict() for d in self.day]
        }


@dataclass
class Performance:
    """Full performance information structure."""
    ak: str
    name: str
    datetime: str
    end_datetime: str
    perf_status: int
    opening_time: str
    closing_time: str
    opening_sale: str
    closing_sale: str
    sellable: bool
    blocked: bool
    reachable: bool
    waitlist_enabled: bool
    transferrable: bool
    # Optional fields
    category_list: Optional[PerformanceCategoryList] = None
    priority_validity: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "Performance":
        return cls(
            ak=data.get("AK", ""),
            name=data.get("NAME", ""),
            datetime=data.get("DATETIME", ""),
            end_datetime=data.get("ENDDATETIME", ""),
            perf_status=data.get("PERFSTATUS", 0),
            opening_time=data.get("OPENINGTIME", ""),
            closing_time=data.get("CLOSINGTIME", ""),
            opening_sale=data.get("OPENINGSALE", ""),
            closing_sale=data.get("CLOSINGSALE", ""),
            sellable=data.get("SELLABLE", False),
            blocked=data.get("BLOCKED", False),
            reachable=data.get("REACHABLE", False),
            waitlist_enabled=data.get("WAITLISTENABLED", False),
            transferrable=data.get("TRANSFERRABLE", False),
            category_list=PerformanceCategoryList.from_dict(data["CATEGORYLIST"]) if data.get("CATEGORYLIST") else None,
            priority_validity=data.get("PRIORITYVALIDITY"),
        )
    
    def to_dict(self) -> dict:
        result = {
            "AK": self.ak,
            "NAME": self.name,
            "DATETIME": self.datetime,
            "ENDDATETIME": self.end_datetime,
            "PERFSTATUS": self.perf_status,
            "OPENINGTIME": self.opening_time,
            "CLOSINGTIME": self.closing_time,
            "OPENINGSALE": self.opening_sale,
            "CLOSINGSALE": self.closing_sale,
            "SELLABLE": self.sellable,
            "BLOCKED": self.blocked,
            "REACHABLE": self.reachable,
            "WAITLISTENABLED": self.waitlist_enabled,
            "TRANSFERRABLE": self.transferrable,
        }
        if self.category_list:
            result["CATEGORYLIST"] = self.category_list.to_dict()
        if self.priority_validity:
            result["PRIORITYVALIDITY"] = self.priority_validity
        return result


@dataclass
class PerformanceList:
    """List of performances."""
    performance: List[Performance]
    
    @classmethod
    def from_dict(cls, data: dict) -> "PerformanceList":
        perfs = data.get("PERFORMANCE", [])
        if not isinstance(perfs, list):
            perfs = [perfs] if perfs else []
        return cls(performance=[Performance.from_dict(p) for p in perfs])
    
    def to_dict(self) -> dict:
        return {
            "PERFORMANCE": [p.to_dict() for p in self.performance]
        }


@dataclass
class SpaceStructureBase:
    """Base space structure information."""
    ak: str
    code: str
    description: str
    seat: bool
    i18n_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SpaceStructureBase":
        return cls(
            ak=data.get("AK", ""),
            code=data.get("CODE", ""),
            description=data.get("DESCRIPTION", ""),
            seat=data.get("SEAT", False),
            i18n_list=data.get("I18NLIST"),
        )
    
    def to_dict(self) -> dict:
        result = {
            "AK": self.ak,
            "CODE": self.code,
            "DESCRIPTION": self.description,
            "SEAT": self.seat,
        }
        if self.i18n_list:
            result["I18NLIST"] = self.i18n_list
        return result


@dataclass
class CapacitySeatCategoryList:
    """List of capacity seat categories."""
    capacity_seat_category: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "CapacitySeatCategoryList":
        cats = data.get("CAPACITYSEATCATEGORY", [])
        if not isinstance(cats, list):
            cats = [cats] if cats else []
        return cls(capacity_seat_category=cats)
    
    def to_dict(self) -> dict:
        return {
            "CAPACITYSEATCATEGORY": self.capacity_seat_category
        }


# Request Classes
@dataclass
class ReadPerformanceByDateRequest:
    """Request for ReadPerformanceByDate operation."""
    event_ak: str
    from_date: str
    to_date: str
    cart_performance_list: Optional[CartPerformanceList] = None
    
    def to_dict(self) -> dict:
        result = {
            "EVENTAK": self.event_ak,
            "FROMDATE": self.from_date,
            "TODATE": self.to_date,
        }
        if self.cart_performance_list:
            result["CARTPERFORMANCELIST"] = self.cart_performance_list.to_dict()
        return result


@dataclass
class ReadPerformanceByDateResponse:
    """Response for ReadPerformanceByDate operation."""
    error: Error
    performance_list: Optional[PerformanceList] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadPerformanceByDateResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            performance_list=PerformanceList.from_dict(data["PERFORMANCELIST"]) if data.get("PERFORMANCELIST") else None,
        )


@dataclass
class ReadPerformanceByAKResponse:
    """Response for ReadPerformanceByAK operation."""
    error: Error
    performance: Optional[Performance] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadPerformanceByAKResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            performance=Performance.from_dict(data["PERFORMANCE"]) if data.get("PERFORMANCE") else None,
        )


@dataclass
class ReadSpaceStructureByAKResponse:
    """Response for ReadSpaceStructureByAK operation."""
    error: Error
    space_structure: Optional[SpaceStructureBase] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadSpaceStructureByAKResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            space_structure=SpaceStructureBase.from_dict(data["SPACESTRUCTURE"]) if data.get("SPACESTRUCTURE") else None,
        )


@dataclass
class GetCalendarAvailabilityRequest:
    """Request for GetCalendarAvailability operation."""
    event_ak: str
    from_date: str
    to_date: str
    sellable: Optional[bool] = None
    range_price: bool = False
    attribute_ak: Optional[str] = None
    cart_performance_list: Optional[CartPerformanceList] = None
    product_filter: Optional[Dict[str, str]] = None
    return_performance_name: bool = False
    
    def to_dict(self) -> dict:
        result = {
            "EVENTAK": self.event_ak,
            "FROMDATE": self.from_date,
            "TODATE": self.to_date,
            "RANGEPRICE": self.range_price,
            "RETURNPERFORMANCENAME": self.return_performance_name,
        }
        if self.sellable is not None:
            result["SELLABLE"] = self.sellable
        if self.attribute_ak:
            result["ATTRIBUTEAK"] = self.attribute_ak
        if self.cart_performance_list:
            result["CARTPERFORMANCELIST"] = self.cart_performance_list.to_dict()
        if self.product_filter:
            result["PRODUCTFILTER"] = self.product_filter
        return result


@dataclass
class GetCalendarAvailabilityResponse:
    """Response for GetCalendarAvailability operation."""
    error: Error
    day_list: Optional[DayList] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "GetCalendarAvailabilityResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            day_list=DayList.from_dict(data["DAYLIST"]) if data.get("DAYLIST") else None,
        )


@dataclass
class FindAllPerformanceByCategoriesRequest:
    """Request for FindAllPerformanceByCategories operation."""
    date: Dict[str, str]  # {"FROM": "...", "TO": "..."}
    performance_category_list: Optional[PerformanceCategoryList] = None
    event_category_list: Optional[EventCategoryList] = None
    full_search: Optional[str] = None
    cart_performance_list: Optional[CartPerformanceList] = None
    
    def to_dict(self) -> dict:
        result = {
            "DATE": self.date,
        }
        if self.performance_category_list:
            result["PERFORMANCECATEGORYLIST"] = self.performance_category_list.to_dict()
        if self.event_category_list:
            result["EVENTCATEGORYLIST"] = self.event_category_list.to_dict()
        if self.full_search:
            result["FULLSEARCH"] = self.full_search
        if self.cart_performance_list:
            result["CARTPERFORMANCELIST"] = self.cart_performance_list.to_dict()
        return result


@dataclass
class FindAllPerformanceByCategoriesResponse:
    """Response for FindAllPerformanceByCategories operation."""
    error: Error
    performance_list: Optional[Dict[str, List[Dict[str, Any]]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllPerformanceByCategoriesResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            performance_list=data.get("PERFORMANCELIST"),
        )


@dataclass
class FindAllPerformanceProductByAKRequest:
    """Request for FindAllPerformanceProductByAK operation."""
    performance_ak: str
    account_ak: Optional[str] = None
    stat_group_list: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> dict:
        result = {
            "PERFORMANCEAK": self.performance_ak,
        }
        if self.account_ak:
            result["ACCOUNTAK"] = self.account_ak
        if self.stat_group_list:
            result["STATGROUPLIST"] = self.stat_group_list
        return result


@dataclass
class FindAllPerformanceProductByAKResponse:
    """Response for FindAllPerformanceProductByAK operation."""
    error: Error
    seat_category_list: Optional[List[Dict[str, Any]]] = None
    product_list: Optional[List[Dict[str, Any]]] = None
    performance: Optional[Dict[str, str]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllPerformanceProductByAKResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            seat_category_list=data.get("SEATCATEGORYLIST"),
            product_list=data.get("PRODUCTLIST"),
            performance=data.get("PERFORMANCE"),
        )


@dataclass
class FindAllPerformanceProductByAKV2Response:
    """Response for FindAllPerformanceProductByAKV2 operation."""
    error: Error
    seat_category_list: Optional[List[Dict[str, Any]]] = None
    product_list: Optional[List[Dict[str, Any]]] = None
    performance: Optional[Dict[str, str]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllPerformanceProductByAKV2Response":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            seat_category_list=data.get("SEATCATEGORYLIST"),
            product_list=data.get("PRODUCTLIST"),
            performance=data.get("PERFORMANCE"),
        )


@dataclass
class FindAllPerformanceProductAndAttributeByAKRequest:
    """Request for FindAllPerformanceProductAndAttributeByAK operation."""
    performance_filter_list: Dict[str, List[Dict[str, str]]]  # {"PERFORMANCE": [{"AK": "..."}]}
    account_ak: Optional[str] = None
    dimension_list: Optional[Dict[str, Any]] = None
    stat_group_list: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> dict:
        result = {
            "PERFORMANCEFILTERLIST": self.performance_filter_list,
        }
        if self.account_ak:
            result["ACCOUNTAK"] = self.account_ak
        if self.dimension_list:
            result["DIMENSIONLIST"] = self.dimension_list
        if self.stat_group_list:
            result["STATGROUPLIST"] = self.stat_group_list
        return result


@dataclass
class FindAllPerformanceProductAndAttributeByAKResponse:
    """Response for FindAllPerformanceProductAndAttributeByAK operation."""
    error: Error
    seat_category_list: Optional[List[Dict[str, Any]]] = None
    product_list: Optional[List[Dict[str, Any]]] = None
    performance_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllPerformanceProductAndAttributeByAKResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            seat_category_list=data.get("SEATCATEGORYLIST"),
            product_list=data.get("PRODUCTLIST"),
            performance_list=data.get("PERFORMANCELIST"),
        )


@dataclass
class FindPerformanceCapacityByAKResponse:
    """Response for FindPerformanceCapacityByAK operation."""
    error: Error
    availability: Availability
    capacity_seat_category_list: CapacitySeatCategoryList
    performance: PerformanceBase
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindPerformanceCapacityByAKResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            availability=Availability.from_dict(data.get("AVAILABILITY", {})),
            capacity_seat_category_list=CapacitySeatCategoryList.from_dict(data.get("CAPACITYSEATCATEGORYLIST", {})),
            performance=PerformanceBase.from_dict(data.get("PERFORMANCE", {})),
        )


@dataclass
class FindPerformanceCapacityAndProductByAKRequest:
    """Request for FindPerformanceCapacityAndProductByAK operation."""
    performance_ak: str
    logged_account: Optional[Dict[str, str]] = None
    billing_account: Optional[Dict[str, str]] = None
    stat_group_list: Optional[Dict[str, Any]] = None
    return_only_seat_available: Optional[bool] = None
    
    def to_dict(self) -> dict:
        result = {
            "PERFORMANCEAK": self.performance_ak,
        }
        if self.logged_account:
            result["LOGGEDACCOUNT"] = self.logged_account
        if self.billing_account:
            result["BILLINGACCOUNT"] = self.billing_account
        if self.stat_group_list:
            result["STATGROUPLIST"] = self.stat_group_list
        if self.return_only_seat_available is not None:
            result["RETURNONLYSEATAVAILABLE"] = self.return_only_seat_available
        return result


@dataclass
class FindPerformanceCapacityAndProductByAKResponse:
    """Response for FindPerformanceCapacityAndProductByAK operation."""
    error: Error
    space_structure_list: Optional[Dict[str, List[Dict[str, Any]]]] = None
    performance: Optional[PerformanceBase] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindPerformanceCapacityAndProductByAKResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            space_structure_list=data.get("SPACESTRUCTURELIST"),
            performance=PerformanceBase.from_dict(data["PERFORMANCE"]) if data.get("PERFORMANCE") else None,
        )


@dataclass
class SearchPerformanceRequest:
    """Request for SearchPerformance operation."""
    date: Optional[BaseDateFilter] = None
    time: Optional[BaseTimeFilter] = None
    combine_date_and_time: Optional[bool] = None
    performance_category_list: Optional[PerformanceCategoryList] = None
    event_category_list: Optional[EventCategoryList] = None
    performance_filter_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    event_ak: Optional[str] = None
    event_filter_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    perf_status: Optional[int] = None
    sellable: Optional[bool] = None
    blocked: Optional[bool] = None
    reachable: Optional[bool] = None
    price_table_ak: Optional[str] = None
    waitlist_enabled: Optional[bool] = None
    cart_performance_list: Optional[CartPerformanceList] = None
    page_req: Optional[PageRequest] = None
    
    def to_dict(self) -> dict:
        result = {}
        if self.date:
            result["DATE"] = self.date.to_dict()
        if self.time:
            result["TIME"] = self.time.to_dict()
        if self.combine_date_and_time is not None:
            result["COMBINEDATEANDTIME"] = self.combine_date_and_time
        if self.performance_category_list:
            result["PERFORMANCECATEGORYLIST"] = self.performance_category_list.to_dict()
        if self.event_category_list:
            result["EVENTCATEGORYLIST"] = self.event_category_list.to_dict()
        if self.performance_filter_list:
            result["PERFORMANCEFILTERLIST"] = self.performance_filter_list
        if self.event_ak:
            result["EVENTAK"] = self.event_ak
        if self.event_filter_list:
            result["EVENTFILTERLIST"] = self.event_filter_list
        if self.perf_status is not None:
            result["PERFSTATUS"] = self.perf_status
        if self.sellable is not None:
            result["SELLABLE"] = self.sellable
        if self.blocked is not None:
            result["BLOCKED"] = self.blocked
        if self.reachable is not None:
            result["REACHABLE"] = self.reachable
        if self.price_table_ak:
            result["PRICETABLEAK"] = self.price_table_ak
        if self.waitlist_enabled is not None:
            result["WAITLISTENABLED"] = self.waitlist_enabled
        if self.cart_performance_list:
            result["CARTPERFORMANCELIST"] = self.cart_performance_list.to_dict()
        if self.page_req:
            result["PAGEREQ"] = self.page_req.to_dict()
        return result


@dataclass
class SearchPerformanceResponse:
    """Response for SearchPerformance operation."""
    error: Error
    performance_list: Optional[PerformanceList] = None
    page_resp: Optional[PageResponse] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchPerformanceResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            performance_list=PerformanceList.from_dict(data["PERFORMANCELIST"]) if data.get("PERFORMANCELIST") else None,
            page_resp=PageResponse.from_dict(data["PAGERESP"]) if data.get("PAGERESP") else None,
        )


@dataclass
class SearchCalendarAvailabilityRequest:
    """Request for SearchCalendarAvailability operation."""
    date: BaseDateFilter
    time: Optional[BaseTimeFilter] = None
    performance_category_list: Optional[PerformanceCategoryList] = None
    event_category_list: Optional[EventCategoryList] = None
    performance_filter_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    event_filter_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    perf_status: Optional[int] = None
    sellable: Optional[bool] = None
    blocked: Optional[bool] = None
    event_status: Optional[int] = None
    location_ak: Optional[str] = None
    number_of_tickets: Optional[int] = None
    space_structure_filter_list: Optional[Dict[str, Any]] = None
    cart_performance_list: Optional[CartPerformanceList] = None
    range_price: bool = False
    attribute_filter_list: Optional[Dict[str, Any]] = None
    page_req: Optional[PageRequest] = None
    account_ak: Optional[str] = None
    availability_details: Optional[bool] = None
    product_filter: Optional[Dict[str, str]] = None
    waitlist_enabled: Optional[bool] = None
    check_product_availability: Optional[bool] = None
    not_return_concurrent_performances: Optional[bool] = None
    requirement_ak_filter_list: Optional[Dict[str, Any]] = None
    return_day_only: Optional[bool] = None
    stat_group_list: Optional[Dict[str, Any]] = None
    calculate_range_price: Optional[bool] = None
    return_performance_name: bool = False
    not_return_space_structure_list: Optional[bool] = None
    
    def to_dict(self) -> dict:
        result = {
            "DATE": self.date.to_dict(),
            "RANGEPRICE": self.range_price,
            "RETURNPERFORMANCENAME": self.return_performance_name,
        }
        if self.time:
            result["TIME"] = self.time.to_dict()
        if self.performance_category_list:
            result["PERFORMANCECATEGORYLIST"] = self.performance_category_list.to_dict()
        if self.event_category_list:
            result["EVENTCATEGORYLIST"] = self.event_category_list.to_dict()
        if self.performance_filter_list:
            result["PERFORMANCEFILTERLIST"] = self.performance_filter_list
        if self.event_filter_list:
            result["EVENTFILTERLIST"] = self.event_filter_list
        if self.perf_status is not None:
            result["PERFSTATUS"] = self.perf_status
        if self.sellable is not None:
            result["SELLABLE"] = self.sellable
        if self.blocked is not None:
            result["BLOCKED"] = self.blocked
        if self.event_status is not None:
            result["EVENTSTATUS"] = self.event_status
        if self.location_ak:
            result["LOCATIONAK"] = self.location_ak
        if self.number_of_tickets is not None:
            result["NUMBEROFTICKETS"] = self.number_of_tickets
        if self.space_structure_filter_list:
            result["SPACESTRUCTUREFILTERLIST"] = self.space_structure_filter_list
        if self.cart_performance_list:
            result["CARTPERFORMANCELIST"] = self.cart_performance_list.to_dict()
        if self.attribute_filter_list:
            result["ATTRIBUTEFILTERLIST"] = self.attribute_filter_list
        if self.page_req:
            result["PAGEREQ"] = self.page_req.to_dict()
        if self.account_ak:
            result["ACCOUNTAK"] = self.account_ak
        if self.availability_details is not None:
            result["AVAILABILITYDETAILS"] = self.availability_details
        if self.product_filter:
            result["PRODUCTFILTER"] = self.product_filter
        if self.waitlist_enabled is not None:
            result["WAITLISTENABLED"] = self.waitlist_enabled
        if self.check_product_availability is not None:
            result["CHECKPRODUCTAVAILABILITY"] = self.check_product_availability
        if self.not_return_concurrent_performances is not None:
            result["NOTRETURNCONCURRENTPERFORMANCES"] = self.not_return_concurrent_performances
        if self.requirement_ak_filter_list:
            result["REQUIREMENTAKFILTERLIST"] = self.requirement_ak_filter_list
        if self.return_day_only is not None:
            result["RETURNDAYONLY"] = self.return_day_only
        if self.stat_group_list:
            result["STATGROUPLIST"] = self.stat_group_list
        if self.calculate_range_price is not None:
            result["CALCULATERANGEPRICE"] = self.calculate_range_price
        if self.not_return_space_structure_list is not None:
            result["NOTRETURNSPACESTRUCTURELIST"] = self.not_return_space_structure_list
        return result


@dataclass
class SearchCalendarAvailabilityResponse:
    """Response for SearchCalendarAvailability operation."""
    error: Error
    day_list: Optional[DayList] = None
    page_resp: Optional[PageResponse] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchCalendarAvailabilityResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            day_list=DayList.from_dict(data["DAYLIST"]) if data.get("DAYLIST") else None,
            page_resp=PageResponse.from_dict(data["PAGERESP"]) if data.get("PAGERESP") else None,
        )


@dataclass
class ChangePerformanceStatusRequest:
    """Request for ChangePerformanceStatus operation."""
    search_performance: Dict[str, Any]  # SEARCHPERFORMANCE structure
    perf_status: int
    
    def to_dict(self) -> dict:
        return {
            "SEARCHPERFORMANCE": self.search_performance,
            "PERFSTATUS": self.perf_status,
        }


@dataclass
class ChangePerformanceStatusResponse:
    """Response for ChangePerformanceStatus operation."""
    error: Error
    performance_list: Optional[Dict[str, List[Dict[str, Any]]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ChangePerformanceStatusResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            performance_list=data.get("PERFORMANCELIST"),
        )


@dataclass
class SearchPerformanceEntriesRequest:
    """Request for SearchPerformanceEntries operation."""
    performance: Dict[str, Any]  # PERFORMANCEENTRY structure
    performance_category_list: Optional[PerformanceCategoryList] = None
    event_category_list: Optional[EventCategoryList] = None
    performance_filter_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    event_filter_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    admission: Optional[Dict[str, Any]] = None
    page_req: Optional[PageRequest] = None
    
    def to_dict(self) -> dict:
        result = {
            "PERFORMANCE": self.performance,
        }
        if self.performance_category_list:
            result["PERFORMANCECATEGORYLIST"] = self.performance_category_list.to_dict()
        if self.event_category_list:
            result["EVENTCATEGORYLIST"] = self.event_category_list.to_dict()
        if self.performance_filter_list:
            result["PERFORMANCEFILTERLIST"] = self.performance_filter_list
        if self.event_filter_list:
            result["EVENTFILTERLIST"] = self.event_filter_list
        if self.admission:
            result["ADMISSION"] = self.admission
        if self.page_req:
            result["PAGEREQ"] = self.page_req.to_dict()
        return result


@dataclass
class SearchPerformanceEntriesResponse:
    """Response for SearchPerformanceEntries operation."""
    error: Error
    day_list: Optional[Dict[str, Any]] = None
    page_resp: Optional[PageResponse] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchPerformanceEntriesResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            day_list=data.get("DAYLIST"),
            page_resp=PageResponse.from_dict(data["PAGERESP"]) if data.get("PAGERESP") else None,
        )


@dataclass
class SetPerformancePriceRequest:
    """Request for SetPerformancePrice operation."""
    performance: Dict[str, Any]  # PERFORMANCEENTRY structure
    matrix_cell_ak_list: Dict[str, List[Dict[str, str]]]  # {"MATRIXCELLAKITEM": [{"MATRIXCELLAK": "..."}]}
    price: float
    performance_filter_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    event_filter_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    
    
    def to_dict(self) -> dict:
        result = {
            "PERFORMANCE": self.performance,
            "MATRIXCELLAKLIST": self.matrix_cell_ak_list,
            "PRICE": self.price,
        }
        if self.performance_filter_list:
            result["PERFORMANCEFILTERLIST"] = self.performance_filter_list
        if self.event_filter_list:
            result["EVENTFILTERLIST"] = self.event_filter_list
        return result


@dataclass
class SetPerformancePriceResponse:
    """Response for SetPerformancePrice operation."""
    error: Error
    performance_link_list: Optional[Dict[str, Any]] = None
    price: Optional[float] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SetPerformancePriceResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            performance_link_list=data.get("PERFORMANCELINKLIST"),
            price=data.get("PRICE"),
        )


@dataclass
class GetDaysAvailabilityRequest:
    """Request for GetDaysAvailability operation."""
    date: BaseDateFilter
    time: Optional[BaseTimeFilter] = None
    performance_category_list: Optional[PerformanceCategoryList] = None
    event_category_list: Optional[EventCategoryList] = None
    event_filter_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    event_status: Optional[int] = None
    perf_status: Optional[int] = None
    sellable: Optional[bool] = None
    number_of_tickets: Optional[int] = None
    range_price: bool = False
    attribute_filter_list: Optional[Dict[str, Any]] = None
    account_ak: Optional[str] = None
    stat_group_list: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> dict:
        result = {
            "DATE": self.date.to_dict(),
            "RANGEPRICE": self.range_price,
        }
        if self.time:
            result["TIME"] = self.time.to_dict()
        if self.performance_category_list:
            result["PERFORMANCECATEGORYLIST"] = self.performance_category_list.to_dict()
        if self.event_category_list:
            result["EVENTCATEGORYLIST"] = self.event_category_list.to_dict()
        if self.event_filter_list:
            result["EVENTFILTERLIST"] = self.event_filter_list
        if self.event_status is not None:
            result["EVENTSTATUS"] = self.event_status
        if self.perf_status is not None:
            result["PERFSTATUS"] = self.perf_status
        if self.sellable is not None:
            result["SELLABLE"] = self.sellable
        if self.number_of_tickets is not None:
            result["NUMBEROFTICKETS"] = self.number_of_tickets
        if self.attribute_filter_list:
            result["ATTRIBUTEFILTERLIST"] = self.attribute_filter_list
        if self.account_ak:
            result["ACCOUNTAK"] = self.account_ak
        if self.stat_group_list:
            result["STATGROUPLIST"] = self.stat_group_list
        return result


@dataclass
class GetDaysAvailabilityResponse:
    """Response for GetDaysAvailability operation."""
    error: Error
    day_list: Optional[CalendarDayList] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "GetDaysAvailabilityResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            day_list=CalendarDayList.from_dict(data["DAYLIST"]) if data.get("DAYLIST") else None,
        )


@dataclass
class GetDayPerformancesRequest:
    """Request for GetDayPerformances operation."""
    date: str
    time: Optional[BaseTimeFilter] = None
    performance_category_list: Optional[PerformanceCategoryList] = None
    event_category_list: Optional[EventCategoryList] = None
    performance_filter_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    event_filter_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    perf_status: Optional[int] = None
    sellable: Optional[bool] = None
    blocked: Optional[bool] = None
    event_status: Optional[int] = None
    location_ak: Optional[str] = None
    number_of_tickets: Optional[int] = None
    space_structure_filter_list: Optional[Dict[str, Any]] = None
    cart_performance_list: Optional[CartPerformanceList] = None
    range_price: bool = False
    attribute_filter_list: Optional[Dict[str, Any]] = None
    account_ak: Optional[str] = None
    waitlist_enabled: Optional[bool] = None
    stat_group_list: Optional[Dict[str, Any]] = None
    calculate_range_price: Optional[bool] = None
    space_structure_avail: Optional[bool] = None
    return_performance_name: bool = False
    return_product_info: Optional[bool] = None
    
    def to_dict(self) -> dict:
        result = {
            "DATE": self.date,
            "RANGEPRICE": self.range_price,
            "RETURNPERFORMANCENAME": self.return_performance_name,
        }
        if self.time:
            result["TIME"] = self.time.to_dict()
        if self.performance_category_list:
            result["PERFORMANCECATEGORYLIST"] = self.performance_category_list.to_dict()
        if self.event_category_list:
            result["EVENTCATEGORYLIST"] = self.event_category_list.to_dict()
        if self.performance_filter_list:
            result["PERFORMANCEFILTERLIST"] = self.performance_filter_list
        if self.event_filter_list:
            result["EVENTFILTERLIST"] = self.event_filter_list
        if self.perf_status is not None:
            result["PERFSTATUS"] = self.perf_status
        if self.sellable is not None:
            result["SELLABLE"] = self.sellable
        if self.blocked is not None:
            result["BLOCKED"] = self.blocked
        if self.event_status is not None:
            result["EVENTSTATUS"] = self.event_status
        if self.location_ak:
            result["LOCATIONAK"] = self.location_ak
        if self.number_of_tickets is not None:
            result["NUMBEROFTICKETS"] = self.number_of_tickets
        if self.space_structure_filter_list:
            result["SPACESTRUCTUREFILTERLIST"] = self.space_structure_filter_list
        if self.cart_performance_list:
            result["CARTPERFORMANCELIST"] = self.cart_performance_list.to_dict()
        if self.attribute_filter_list:
            result["ATTRIBUTEFILTERLIST"] = self.attribute_filter_list
        if self.account_ak:
            result["ACCOUNTAK"] = self.account_ak
        if self.waitlist_enabled is not None:
            result["WAITLISTENABLED"] = self.waitlist_enabled
        if self.stat_group_list:
            result["STATGROUPLIST"] = self.stat_group_list
        if self.calculate_range_price is not None:
            result["CALCULATERANGEPRICE"] = self.calculate_range_price
        if self.space_structure_avail is not None:
            result["SPACESTRUCTUREAVAIL"] = self.space_structure_avail
        if self.return_product_info is not None:
            result["RETURNPRODUCTINFO"] = self.return_product_info
        return result


@dataclass
class GetDayPerformancesResponse:
    """Response for GetDayPerformances operation."""
    error: Error
    date: Optional[str] = None
    performance_list: Optional[PerformanceListBasic] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "GetDayPerformancesResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            date=data.get("DATE"),
            performance_list=PerformanceListBasic.from_dict(data["PERFORMANCELIST"]) if data.get("PERFORMANCELIST") else None,
        )


@dataclass
class FindPerformanceBlockedByLimitRequest:
    """Request for FindPerformanceBlockedByLimit operation."""
    event_ak: str
    limit: int
    blocked_hours: int
    workstation_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    
    def to_dict(self) -> dict:
        result = {
            "EVENTAK": self.event_ak,
            "LIMIT": self.limit,
            "BLOCKEDHOURS": self.blocked_hours,
        }
        if self.workstation_list:
            result["WORKSTATIONLIST"] = self.workstation_list
        return result


@dataclass
class FindPerformanceBlockedByLimitResponse:
    """Response for FindPerformanceBlockedByLimit operation."""
    error: Error
    current_value: int
    performance_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindPerformanceBlockedByLimitResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            current_value=data.get("CURRENT_VALUE", 0),
            performance_list=data.get("PERFORMANCELIST"),
        )


@dataclass
class PerformanceSchedule:
    """Performance schedule structure."""
    date_from: str
    date_to: str
    perf_qty_per_timeslot: int
    calendar_ak: Optional[str] = None
    same_date_time_creation: Optional[bool] = None
    sunday: bool = True
    monday: bool = True
    tuesday: bool = True
    wednesday: bool = True
    thursday: bool = True
    friday: bool = True
    saturday: bool = True
    fixed_time_selection_list: Optional[Dict[str, Any]] = None
    interval_time_selection_list: Optional[Dict[str, Any]] = None
    all_day_performance: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> dict:
        result = {
            "DATEFROM": self.date_from,
            "DATETO": self.date_to,
            "PERFQTYPERTIMESLOT": self.perf_qty_per_timeslot,
            "SUNDAY": self.sunday,
            "MONDAY": self.monday,
            "TUESDAY": self.tuesday,
            "WEDNESDAY": self.wednesday,
            "THURSDAY": self.thursday,
            "FRIDAY": self.friday,
            "SATURDAY": self.saturday,
        }
        if self.calendar_ak:
            result["CALENDARAK"] = self.calendar_ak
        if self.same_date_time_creation is not None:
            result["SAMEDATETIMECREATION"] = self.same_date_time_creation
        if self.fixed_time_selection_list:
            result["FIXEDTIMESELECTIONLIST"] = self.fixed_time_selection_list
        if self.interval_time_selection_list:
            result["INTERVALTIMESELECTIONLIST"] = self.interval_time_selection_list
        if self.all_day_performance:
            result["ALLDAYPERFORMANCE"] = self.all_day_performance
        return result


@dataclass
class OnSaleInfo:
    """On sale information structure."""
    from_date: Optional[str] = None
    to_date: Optional[str] = None
    status: Optional[int] = None
    background_color: Optional[str] = None
    time_limit: Optional[int] = None
    one_trans_per_performance: Optional[bool] = None
    sale_validity_override_list: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> dict:
        result = {}
        if self.from_date:
            result["FROMDATE"] = self.from_date
        if self.to_date:
            result["TODATE"] = self.to_date
        if self.status is not None:
            result["STATUS"] = self.status
        if self.background_color:
            result["BACKGROUNDCOLOR"] = self.background_color
        if self.time_limit is not None:
            result["TIMELIMIT"] = self.time_limit
        if self.one_trans_per_performance is not None:
            result["ONETRANSPERPERFORMANCE"] = self.one_trans_per_performance
        if self.sale_validity_override_list:
            result["SALEVALIDITYOVERRIDELIST"] = self.sale_validity_override_list
        return result


@dataclass
class PerformanceRestrictions:
    """Performance restrictions structure."""
    site_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    operating_area_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    workstation_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    user_role_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    user_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    
    def to_dict(self) -> dict:
        result = {}
        if self.site_list:
            result["SITELIST"] = self.site_list
        if self.operating_area_list:
            result["OPERATINGAREALIST"] = self.operating_area_list
        if self.workstation_list:
            result["WORKSTATIONLIST"] = self.workstation_list
        if self.user_role_list:
            result["USERROLELIST"] = self.user_role_list
        if self.user_list:
            result["USERLIST"] = self.user_list
        return result


@dataclass
class CreatePerformancesRequest:
    """Request for CreatePerformances operation."""
    event_ak: str
    schedule: PerformanceSchedule
    price_table_ak: str
    event_location_adm_profile: Optional[bool] = None
    template_performance_ak: Optional[str] = None
    location_ak: Optional[str] = None
    access_configuration_id: Optional[int] = None
    enable_web_pricing: Optional[bool] = None
    web_price_table_ak: Optional[str] = None
    external_id: Optional[str] = None
    performance_name: Optional[str] = None
    performance_code: Optional[str] = None
    on_sale_info: Optional[OnSaleInfo] = None
    restrictions: Optional[PerformanceRestrictions] = None
    dmg_category_ak: Optional[str] = None
    waitlist_enabled: Optional[bool] = None
    allow_notification: Optional[bool] = None
    not_transferrable: Optional[bool] = None
    money_card_type: Optional[int] = None
    money_card_value: Optional[float] = None
    
    def to_dict(self) -> dict:
        result = {
            "EVENTAK": self.event_ak,
            "SCHEDULE": self.schedule.to_dict(),
            "PRICETABLEAK": self.price_table_ak,
        }
        if self.event_location_adm_profile is not None:
            result["EVENTLOCATIONANDADMPROFILE"] = self.event_location_adm_profile
        if self.template_performance_ak:
            result["TEMPLATEPERFORMANCEAK"] = self.template_performance_ak
        if self.location_ak:
            result["LOCATIONAK"] = self.location_ak
        if self.access_configuration_id is not None:
            result["ACCESSCONFIGURATIONID"] = self.access_configuration_id
        if self.enable_web_pricing is not None:
            result["ENABLEWEBPRICING"] = self.enable_web_pricing
        if self.web_price_table_ak:
            result["WEBPRICETABLEAK"] = self.web_price_table_ak
        if self.external_id:
            result["EXTERNALID"] = self.external_id
        if self.performance_name:
            result["PERFORMANCENAME"] = self.performance_name
        if self.performance_code:
            result["PERFORMANCECODE"] = self.performance_code
        if self.on_sale_info:
            result["ONSALEINFO"] = self.on_sale_info.to_dict()
        if self.restrictions:
            result["RESTRICTIONS"] = self.restrictions.to_dict()
        if self.dmg_category_ak:
            result["DMGCATEGORYAK"] = self.dmg_category_ak
        if self.waitlist_enabled is not None:
            result["WAITLISTENABLED"] = self.waitlist_enabled
        if self.allow_notification is not None:
            result["ALLOWNOTIFICATION"] = self.allow_notification
        if self.not_transferrable is not None:
            result["NOTTRANSFERRABLE"] = self.not_transferrable
        if self.money_card_type is not None:
            result["MONEYCARDTYPE"] = self.money_card_type
        if self.money_card_value is not None:
            result["MONEYCARDVALUE"] = self.money_card_value
        return result


@dataclass
class CreatePerformancesResponse:
    """Response for CreatePerformances operation."""
    error: Error
    created: int
    skipped: int
    
    @classmethod
    def from_dict(cls, data: dict) -> "CreatePerformancesResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            created=data.get("CREATED", 0),
            skipped=data.get("SKIPPED", 0),
        )


@dataclass
class UpdatePerformancesRequest:
    """Request for UpdatePerformances operation."""
    performance_list: Dict[str, List[Dict[str, str]]]  # {"PERFORMANCE": [{"AK": "..."}]}
    date_from: Optional[str] = None
    date_to: Optional[str] = None
    adjust_from_time: Optional[int] = None
    adjust_to_time: Optional[int] = None
    minutes_on_screen: Optional[int] = None
    time_opening: Optional[int] = None
    time_limit: Optional[int] = None
    all_day_perf: Optional[bool] = None
    price_table_ak: Optional[str] = None
    web_price_table_ak: Optional[str] = None
    performance_name: Optional[str] = None
    performance_code: Optional[str] = None
    on_sale_info: Optional[OnSaleInfo] = None
    dmg_category_ak: Optional[str] = None
    waitlist_enabled: Optional[bool] = None
    allow_notification: Optional[bool] = None
    not_transferrable: Optional[bool] = None
    money_card_type: Optional[int] = None
    money_card_value: Optional[float] = None
    
    def to_dict(self) -> dict:
        result = {
            "PERFORMANCELIST": self.performance_list,
        }
        if self.date_from:
            result["DATEFROM"] = self.date_from
        if self.date_to:
            result["DATETO"] = self.date_to
        if self.adjust_from_time is not None:
            result["ADJUSTFROMTIME"] = self.adjust_from_time
        if self.adjust_to_time is not None:
            result["ADJUSTTOTIME"] = self.adjust_to_time
        if self.minutes_on_screen is not None:
            result["MINUTESONSCREEN"] = self.minutes_on_screen
        if self.time_opening is not None:
            result["TIMEOPENING"] = self.time_opening
        if self.time_limit is not None:
            result["TIMELIMIT"] = self.time_limit
        if self.all_day_perf is not None:
            result["ALLDAYPERF"] = self.all_day_perf
        if self.price_table_ak:
            result["PRICETABLEAK"] = self.price_table_ak
        if self.web_price_table_ak:
            result["WEBPRICETABLEAK"] = self.web_price_table_ak
        if self.performance_name:
            result["PERFORMANCENAME"] = self.performance_name
        if self.performance_code:
            result["PERFORMANCECODE"] = self.performance_code
        if self.on_sale_info:
            result["ONSALEINFO"] = self.on_sale_info.to_dict()
        if self.dmg_category_ak:
            result["DMGCATEGORYAK"] = self.dmg_category_ak
        if self.waitlist_enabled is not None:
            result["WAITLISTENABLED"] = self.waitlist_enabled
        if self.allow_notification is not None:
            result["ALLOWNOTIFICATION"] = self.allow_notification
        if self.not_transferrable is not None:
            result["NOTTRANSFERRABLE"] = self.not_transferrable
        if self.money_card_type is not None:
            result["MONEYCARDTYPE"] = self.money_card_type
        if self.money_card_value is not None:
            result["MONEYCARDVALUE"] = self.money_card_value
        return result


@dataclass
class UpdatePerformancesResponse:
    """Response for UpdatePerformances operation."""
    error: Error
    updated: int
    partial_updated: int
    skipped: int
    
    @classmethod
    def from_dict(cls, data: dict) -> "UpdatePerformancesResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            updated=data.get("UPDATED", 0),
            partial_updated=data.get("PARTIALUPDATED", 0),
            skipped=data.get("SKIPPED", 0),
        )


@dataclass
class GetPerformanceTotalUsagesRequest:
    """Request for GetPerformanceTotalUsages operation."""
    performance_ak: str
    workstation_list: Optional[Dict[str, List[Dict[str, str]]]] = None
    
    def to_dict(self) -> dict:
        result = {
            "PERFORMANCEAK": self.performance_ak,
        }
        if self.workstation_list:
            result["WORKSTATIONLIST"] = self.workstation_list
        return result


@dataclass
class GetPerformanceTotalUsagesResponse:
    """Response for GetPerformanceTotalUsages operation."""
    error: Error
    performance_ak: str
    current_value: int
    in_venue_limit: int
    
    @classmethod
    def from_dict(cls, data: dict) -> "GetPerformanceTotalUsagesResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            performance_ak=data.get("PERFORMANCEAK", ""),
            current_value=data.get("CURRENT_VALUE", 0),
            in_venue_limit=data.get("IN_VENUE_LIMIT", 0),
        )
