"""
Type definitions for RenewalPlanEnquiry.

This module provides structured classes for renewal plan operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error


# Request Classes
@dataclass
class ChangeRenewalContractStatusRequest:
    """Request for ReactivateRenewalPlan, CancelRenewalPlan, and DeactivateRenewalPlan operations.
    
    Based on RenewalPlanEnquiry.xsd CHANGERENEWALCONTRACTSTATUSREQ type.
    
    Attributes:
        renewal_plan_ak: Renewal plan AK
    """
    
    renewal_plan_ak: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"RENEWALPLANAK": self.renewal_plan_ak}


@dataclass
class InsertCardOnFileRequest:
    """Request for InsertCardOnFile operation.
    
    Based on RenewalPlanEnquiry.xsd INSERTCARDONFILEREQ type.
    
    Attributes:
        account_ak: Account AK
        card_on_file_type: Card on file type (1 = Adyen)
        stored_payment_method_id: Stored payment method ID
        card_name: Card name
        card_number: Card number
        expiration: Expiration (mm-yyyy format)
        holder_name: Holder name
    """
    
    account_ak: str
    card_on_file_type: int
    stored_payment_method_id: str
    card_name: str
    card_number: str
    expiration: str
    holder_name: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "ACCOUNTAK": self.account_ak,
            "CARDONFILETYPE": self.card_on_file_type,
            "STOREDPAYMENTMETHODID": self.stored_payment_method_id,
            "CARDNAME": self.card_name,
            "CARDNUMBER": self.card_number,
            "EXPIRATION": self.expiration,
            "HOLDERNAME": self.holder_name,
        }


@dataclass
class DeleteCardOnFileRequest:
    """Request for DeleteCardOnFile operation.
    
    Based on RenewalPlanEnquiry.xsd DELETECARDONFILEREQ type.
    
    Attributes:
        account_card_on_file_id: Account card on file ID
    """
    
    account_card_on_file_id: int
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"ACCOUNTCARDONFILEID": self.account_card_on_file_id}


@dataclass
class CardOnFileDetailsListRequest:
    """Request for ReadCardOnFileList operation.
    
    Based on RenewalPlanEnquiry.xsd CARDONFILEDETAILSLISTREQ type.
    
    Attributes:
        account_ak: Account AK
    """
    
    account_ak: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"ACCOUNTAK": self.account_ak}


@dataclass
class ReadRenewalPlanInfoByAKRequest:
    """Request for ReadRenewalPlanInfoByAK operation.
    
    Based on RenewalPlanEnquiry.xsd READRENEWALPLANINFOBYAKREQ type.
    
    Attributes:
        renewal_plan_ak: Renewal plan AK
    """
    
    renewal_plan_ak: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"RENEWALPLANAK": self.renewal_plan_ak}


@dataclass
class RenewalPlanListRequest:
    """Request for ReadRenewalPlanList operation.
    
    Based on RenewalPlanEnquiry.xsd RENEWALPLANLISTREQ type.
    
    Attributes:
        account_ak: Account AK (optional)
        status: Status (optional)
    """
    
    account_ak: Optional[str] = None
    status: Optional[int] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.account_ak is not None:
            result["ACCOUNTAK"] = self.account_ak
        if self.status is not None:
            result["STATUS"] = self.status
        return result


@dataclass
class ExecRenewalPlanByAccountAKRequest:
    """Request for ExecRenewalPlanByAccountAK operation.
    
    Based on RenewalPlanEnquiry.xsd EXECRENEWALPLANBYACCOUNTAKREQ type.
    
    Attributes:
        account_ak: Account AK
    """
    
    account_ak: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"ACCOUNTAK": self.account_ak}


@dataclass
class CreateRenewalPlanRequest:
    """Request for CreateRenewalPlan operation.
    
    Based on RenewalPlanEnquiry.xsd CREATERENEWALPLANREQ type.
    
    Attributes:
        ticket_id: Ticket ID
        reservation_owner: Reservation owner (optional)
    """
    
    ticket_id: int
    reservation_owner: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"TICKETID": self.ticket_id}
        if self.reservation_owner is not None:
            result["RESERVATIONOWNER"] = self.reservation_owner
        return result


@dataclass
class ChangeTargetTicketsRequest:
    """Request for ChangeTargetTickets operation.
    
    Based on RenewalPlanEnquiry.xsd CHANGETARGETTICKETSREQ type.
    
    Attributes:
        original_matrix_cell_ak: Original matrix cell AK
        new_matrix_cell_ak: New matrix cell AK
        renewal_plan_ak: Renewal plan AK (optional)
        status: Status filter (optional)
        template_code: Template code (optional)
    """
    
    original_matrix_cell_ak: str
    new_matrix_cell_ak: str
    renewal_plan_ak: Optional[str] = None
    status: Optional[Dict[str, bool]] = None
    template_code: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "ORIGINALMATRIXCELLAK": self.original_matrix_cell_ak,
            "NEWMATRIXCELLAK": self.new_matrix_cell_ak,
        }
        if self.renewal_plan_ak is not None:
            result["RENEWALPLANAK"] = self.renewal_plan_ak
        elif self.status is not None or self.template_code is not None:
            choice_elem = {}
            if self.status is not None:
                choice_elem["STATUS"] = self.status
            if self.template_code is not None:
                choice_elem["TEMPLATECODE"] = self.template_code
            if choice_elem:
                # The XSD shows a choice structure, but we'll include both if provided
                result.update(choice_elem)
        return result


# Response Classes
@dataclass
class ChangeRenewalContractStatusResponse:
    """Response for ReactivateRenewalPlan, CancelRenewalPlan, and DeactivateRenewalPlan operations.
    
    Based on RenewalPlanEnquiry.xsd CHANGERENEWALCONTRACTSTATUSRESP type.
    
    Attributes:
        error: Error information
        renewal_plan_ak: Renewal plan AK
    """
    
    error: Error
    renewal_plan_ak: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "ChangeRenewalContractStatusResponse":
        """Create ChangeRenewalContractStatusResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            renewal_plan_ak=data.get("RENEWALPLANAK", ""),
        )


@dataclass
class CardOnFileResponse:
    """Response for InsertCardOnFile and DeleteCardOnFile operations.
    
    Based on RenewalPlanEnquiry.xsd CARDONFILERESP type.
    
    Attributes:
        error: Error information
        account_card_on_file_id: Account card on file ID
    """
    
    error: Error
    account_card_on_file_id: int
    
    @classmethod
    def from_dict(cls, data: dict) -> "CardOnFileResponse":
        """Create CardOnFileResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            account_card_on_file_id=data.get("ACCOUNTCARDONFILEID", 0),
        )


@dataclass
class CardOnFileDetailsListResponse:
    """Response for ReadCardOnFileList operation.
    
    Based on RenewalPlanEnquiry.xsd CARDONFILEDETAILSLISTRESP type.
    
    Attributes:
        error: Error information
        account_ak: Account AK
        card_on_file_details_list: List of card on file details
    """
    
    error: Error
    account_ak: str
    card_on_file_details_list: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "CardOnFileDetailsListResponse":
        """Create CardOnFileDetailsListResponse from API response dictionary."""
        card_data = data.get("CARDONFILEDETAILSLIST", {}).get("CARDONFILEDETAILS")
        card_list = []
        if card_data:
            if isinstance(card_data, list):
                card_list = card_data
            else:
                card_list = [card_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            account_ak=data.get("ACCOUNTAK", ""),
            card_on_file_details_list=card_list,
        )


@dataclass
class ReadRenewalPlanInfoByAKResponse:
    """Response for ReadRenewalPlanInfoByAK operation.
    
    Based on RenewalPlanEnquiry.xsd READRENEWALPLANINFOBYAKRESP type.
    
    Attributes:
        error: Error information
        renewal_plan_ak: Renewal plan AK
        renewal_plan: Renewal plan information
    """
    
    error: Error
    renewal_plan_ak: str
    renewal_plan: Dict[str, Any]
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadRenewalPlanInfoByAKResponse":
        """Create ReadRenewalPlanInfoByAKResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            renewal_plan_ak=data.get("RENEWALPLANAK", ""),
            renewal_plan=data.get("RENEWALPLAN", {}),
        )


@dataclass
class RenewalPlanListResponse:
    """Response for ReadRenewalPlanList operation.
    
    Based on RenewalPlanEnquiry.xsd RENEWALPLANLISTRESP type.
    
    Attributes:
        error: Error information
        account_ak: Account AK
        renewal_plan_list: List of renewal plans
    """
    
    error: Error
    account_ak: str
    renewal_plan_list: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "RenewalPlanListResponse":
        """Create RenewalPlanListResponse from API response dictionary."""
        plan_data = data.get("RENEWALPLANLIST", {}).get("RENEWALPLAN")
        plan_list = []
        if plan_data:
            if isinstance(plan_data, list):
                plan_list = plan_data
            else:
                plan_list = [plan_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            account_ak=data.get("ACCOUNTAK", ""),
            renewal_plan_list=plan_list,
        )


@dataclass
class ExecRenewalPlanByAccountAKResponse:
    """Response for ExecRenewalPlanByAccountAK operation.
    
    Based on RenewalPlanEnquiry.xsd EXECRENEWALPLANBYACCOUNTAKRESP type.
    
    Attributes:
        error: Error information
        account_ak: Account AK
        message_result: Message result
    """
    
    error: Error
    account_ak: str
    message_result: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "ExecRenewalPlanByAccountAKResponse":
        """Create ExecRenewalPlanByAccountAKResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            account_ak=data.get("ACCOUNTAK", ""),
            message_result=data.get("MESSAGERESULT", ""),
        )


@dataclass
class CreateRenewalPlanResponse:
    """Response for CreateRenewalPlan operation.
    
    Based on RenewalPlanEnquiry.xsd CREATERENEWALPLANRESP type.
    
    Attributes:
        error: Error information
        renewal_plan_ak: Renewal plan AK
    """
    
    error: Error
    renewal_plan_ak: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "CreateRenewalPlanResponse":
        """Create CreateRenewalPlanResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            renewal_plan_ak=data.get("RENEWALPLANAK", ""),
        )


@dataclass
class ChangeTargetTicketsResponse:
    """Response for ChangeTargetTickets operation.
    
    Based on RenewalPlanEnquiry.xsd CHANGETARGETTICKETSRESP type.
    
    Attributes:
        error: Error information
        renewal_plan_ak: Renewal plan AK (optional)
    """
    
    error: Error
    renewal_plan_ak: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ChangeTargetTicketsResponse":
        """Create ChangeTargetTicketsResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            renewal_plan_ak=data.get("RENEWALPLANAK"),
        )
