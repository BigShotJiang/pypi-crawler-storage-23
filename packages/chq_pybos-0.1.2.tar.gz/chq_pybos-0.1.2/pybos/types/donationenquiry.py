"""
Type definitions for DonationEnquiry.

This module provides structured classes for donation operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, PageRequest, PageResponse
from .accountfinancial import PriceBase


# Request Classes
@dataclass
class SearchDonationsRequest:
    """Request for SearchDonations operation.
    
    Based on DonationEnquiry.xsd SEARCHDONATIONSREQ type.
    
    Attributes:
        donation_ak: Donation AK (optional)
        enabled: Enabled flag (optional, default: True)
        matrix_cell_list: Matrix cell list (optional)
        page_req: Page request (optional)
    """
    
    donation_ak: Optional[str] = None
    enabled: Optional[bool] = None
    matrix_cell_list: Optional[List[str]] = None
    page_req: Optional[PageRequest] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.donation_ak is not None:
            result["DONATIONAK"] = self.donation_ak
        if self.enabled is not None:
            result["ENABLED"] = self.enabled
        if self.matrix_cell_list is not None:
            result["MATRIXCELLLIST"] = {
                "MATRIXCELLITEM": [{"AK": ak} for ak in self.matrix_cell_list]
            }
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        return result


# Response Classes
@dataclass
class SearchDonationsResponse:
    """Response for SearchDonations operation.
    
    Based on DonationEnquiry.xsd SEARCHDONATIONSRESP type.
    
    Attributes:
        error: Error information
        donation_group_list: List of donation groups
        page_resp: Page response
    """
    
    error: Error
    donation_group_list: List[Dict[str, Any]]
    page_resp: PageResponse
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchDonationsResponse":
        """Create SearchDonationsResponse from API response dictionary."""
        donation_data = data.get("DONATIONGROUPLIST", {}).get("DONATIONGROUP")
        donation_list = []
        if donation_data:
            if isinstance(donation_data, list):
                donation_list = donation_data
            else:
                donation_list = [donation_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            donation_group_list=donation_list,
            page_resp=PageResponse.from_dict(data.get("PAGERESP", {})),
        )
