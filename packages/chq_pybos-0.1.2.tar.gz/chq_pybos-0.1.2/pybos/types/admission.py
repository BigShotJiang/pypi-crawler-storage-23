"""
Admissions service data types for the BOS API.

This module provides structured classes for admissions operations,
including media code scanning, account scanning, and validation results.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from enum import IntEnum
from .common import Error, BasicInfo


# Enums for better type safety and documentation
class MediaCodeType(IntEnum):
    """Media code types for ticket identification.

    Based on BOS system documentation.
    """

    MAGNETIC = 1
    ALPHA14 = 2  # Alphanumeric 14
    RFID = 3
    NUMERIC10 = 4
    EXTERNAL = 5
    NUMERIC20 = 6
    NUMERIC24 = 7
    SKIDATA20 = 8
    QRCODE = 9
    ALPHA18 = 10
    ALPHA20 = 11
    FAMILYCARD = 12
    TESSERATIFOSO = 13
    EXTERNALAPI = 14
    QSMART = 15
    FIERA_MILANO_ATM = 16
    NEXUS = 17
    NUMERIC14 = 18


class VoidType(IntEnum):
    """Void types for ticket status.

    Based on BOS system documentation.
    """

    ACTIVE = 0
    INACTIVE = 1
    BLOCKED = 2
    CLEANED = 3
    SWAPPED = 4
    CHANGE_VALIDITY = 5
    DEMAGNETIZED = 101
    VOIDED_BY_ENCODING_STATION = 102
    INTERRUPTED_WHILE_ENCODING = 104
    VOIDED_THROUGH_UPGRADE = 107
    VOIDED_THROUGH_BLOCK = 108
    VOIDED_THROUGH_REFUND = 109
    CHANGED_PERFORMANCE = 110
    REPLACED_THROUGH_REISSUE = 111
    STOLEN = 116
    LOST = 117
    TRANSACTION_ABORT = 125
    DASPO = 200
    INSERT_INTO_BLACK_LIST = 201
    SERVICE_VOID = 202
    VOID_DUE_CUSTOMER_REQUEST = 203
    TO_BE_ACTIVATED = 204
    TO_BE_ACTIVATED_BLOCKED = 205
    LINKED_PACKAGE_NOT_VALID = 206
    INSERT_INTO_GRAY_LIST = 207
    SUSPENDED = 208
    RESUMED = 209
    VOID_FOR_UPSELLING = 210
    VOID_DUE_CANCELED_EVENT = 211
    VOID_DUE_LOST_OR_STOLEN = 212
    BLOCKED_DUE_TO_FLEX_CONTRACT = 300
    BLOCK_SUPPORTER_CARD = 301
    UNBLOCK_SUPPORTER_CARD = 302
    LOST_SUPPORTER_CARD = 303
    STOLEN_SUPPORTER_CARD = 304
    EXTINCTION_SUPPORTER_CARD = 305
    RESTORE_SUPPORTER_CARD = 306
    BROKEN_SUPPORTER_CARD = 307
    SOCCER_TICKET_NOT_ASSIGNED = 308
    EXTINCTION_FOR_WRONG_DATA_SUPPORTER_CARD = 309
    EXTINCTION_FOR_RENEWAL_SUPPORTER_CARD = 310
    RECOGNITION_SUPPORTER_CARD = 311
    SUSPENSION_FOR_INVALID_PHOTO_SUPPORTER_CARD = 312
    SUPPORTER_CARD_RECOGNIZED = 313


class LightPattern(IntEnum):
    """Device light patterns for access control.

    Based on BOS system documentation.
    """

    OFF = 0
    ON = 1
    FAST_SWITCH = 2


class FlashEntitlement(IntEnum):
    """Flash at turnstile entitlement.

    Based on BOS system documentation.
    """

    NO = 0
    YES = 1


class ReentryStatus(IntEnum):
    """Reentry status for tickets.

    Based on BOS system documentation.
    """

    NO = 0
    YES = 1


class AccessType(IntEnum):
    """Access types for admission control.

    Based on BOS system documentation.
    """

    ENTRY = 1
    EXIT = 2


class ValidationResultCode(IntEnum):
    """Validation result codes with descriptions.

    Based on BOS system documentation.
    """

    # Success codes (1-99)
    OK = 1
    OK_UNLIMITED = 2
    OK_SAME_DAY_REENTRY = 3
    OK_BONUS_ENTRY = 4
    OK_DIFFERENT_PERS = 5
    OK_OPER_OVERRIDE = 6
    OK_OFFLINE = 7
    OK_OVERRIDE_OPEN_ENTRY = 8
    OK_CT = 9
    OK_CROSSOVER = 10
    OK_MULTI_EVENT_TICKET = 11
    OK_SAME_DAY_REENTRY_MULTI_EVENT_TICKET = 12
    OK_REENTRY_MATCH_ME = 13
    OK_SUCCESS_IDENTIFICATION = 14
    OK_EXIT = 15
    OK_OTHER_FAMILY_CARD_MEMBER = 16
    OK_POINT_ACCESS = 17
    OK_NEW_TEMPLATE = 18
    OK_OVERRIDE_OPEN_REENTRY = 19
    OK_OVERRIDE_CROSS_REENTRY = 20
    OK_OVERRIDE_OPEN_SPECIAL = 21
    OK_GRAYED_LIST = 22
    OK_EXIT_WARNING = 23
    EARLY_EXIT = 24
    OK_TRANSIT = 25
    OK_OVERRIDE_WHITELIST = 26
    OK_OVERRIDE_EXIT = 27
    OK_OVERRIDE_PERFORMANCE = 28
    OK_GOOD_TICKET_LIMIT = 99

    # Information/action required codes (100-199)
    NEED_MORE_INFO = 100
    MANUAL_OPEN = 110

    # Error codes (111-599)
    TICKET_EXPIRED = 111
    INVALID_TIME = 112
    ALREADY_USED = 113
    NO_MORE_ENTRIES = 114
    INVALID_DAY = 115
    TICKET_NOT_IN_MEMORY = 116
    UNKNOWN_TICKET_TYPE = 117
    RECENTLY_USED = 118
    ACCESS_NOT_PERMITTED = 119
    ACCOUNT_NOT_VALID = 120
    ACCOUNT_NOT_PERMITTED = 121
    OVER_CREDIT_LIMIT = 122
    UNKNOWN_ACCESS_AREA = 123
    OTHER_SITE_TICKET = 124
    INVALID_DATA = 125
    INCOHERENT_INFO = 126
    TYPE_NOT_VALID = 127
    SERIAL_OVER_MAX = 128
    NO_CREDIT_ON_TICKET = 129
    AMOUNT_MISSING = 130
    INTERRUPTED = 131
    INCORRECT_ENTRY = 132
    INVALID_PROCEDURE = 133
    TICKET_NOT_ENCODED = 134
    OLD_VOIDED_TICKET_NOT_USED = 135
    RESERVATION_MISSING = 136
    ERROR_IN_EVENT = 137
    TICKET_NOT_ACTIVATED = 138
    UPGRADED_TICKET = 139
    CLIENT_CODE_MISSING = 140
    NO_DEMOGRAPHIC_DATA = 141
    BIOMETRIC_CHECK_FAILURE = 142
    CROSS_OVER_DENIED = 143
    TICKET_BLOCKED = 144
    TICKET_NOT_VALID = 145
    MISSING_PRIMARY_CARD = 146
    PRIMARY_NOT_USED = 147
    CAPACITY_REACHED = 148
    CAPACITY_NR_REACHED = 149
    INVALID_TRANSMISSION = 151
    INVALID_READING = 152
    ACCESS_AREA_REQUIRED = 153
    MISSING_TICKET_TYPE = 154
    REFUNDED_TICKET = 155
    NOT_USED_FOR_ENTRY_REENTRY = 161
    EXIT_TIME_EXPIRED = 162
    ALREADY_EXIT = 163
    NOT_USED_FOR_EXIT = 164
    TIMEOUT_ON_APPROVAL = 171
    APPRV_CODE_MISSING = 172
    TICKET_NOT_READABLE = 173
    PLEASE_INPUT_DATA = 174
    OPERATION_ABORTED = 175
    OPERATOR_NOT_LOGGED = 176
    PRINTER_ERROR = 177
    NO_MORE_REENTRIES = 178
    NO_MORE_CREDIT = 179
    NO_MORE_ITEMS = 180
    UNKNOWN_PRODUCT = 181
    ENTITLEMENT_GUID_NOT_FOUND = 182
    NO_PERFORMANCES_FOR_ACCESS_POINT = 183
    INTERNAL_EXCEPTION = 184
    WAITING_FOR_UPLOAD_FROM_OFFLINE = 185
    INSTALLMENT_BLOCKED_TICKET = 186
    NO_AVAILABILITY_ON_SPECTACLE = 187
    REPLACED_IN_BOS = 188
    CHECK_OUT_NOT_ALLOWED = 189
    VALID_PERFORMANCE_NOT_FOUND = 200
    NO_MORE_DAILY_ENTRIES = 201
    TICKET_NOT_VALID_FOR_APT_EVENT = 202
    INVALID_DATE_OR_TIME = 203
    NOT_ENTRY = 204
    ID_CHECK_FAILURE = 205
    DEVICE_NOT_FOUND = 206
    REENTRY_TIME_RANGE_EXPIRED = 207
    NO_MORE_DAILY_REENTRIES = 208
    SIAE_CARD_UNAVAILABLE = 209
    NO_MORE_CREDIT_ACCESS_CONTROL = 210
    USER_NOT_LOGGED_IN = 211
    ALREADY_USED_FOR_THIS_GATE = 212
    NO_PRIMARY_SECONDARY_CARD = 213
    DEFERRED_EXIT = 214
    GATE_ALREADY_CLOCKED_OUT = 215
    NOL_CARD_FAILED_VALIDATION = 216
    NOL_CARD_FAILED_CARD_TYPE_IDENTIFICATION = 217
    NOL_CARD_CHECK_IN_PRICE_NOT_FOUND = 218
    NOL_CARD_CHECK_IN_FAILED = 219
    NOL_CARD_CHECK_OUT_PRICE_NOT_FOUND = 220
    NOL_CARD_CHECK_OUT_FAILED = 221
    NOL_CARD_READ_ERROR = 222
    NOL_CARD_FAILED_UD_GENERATION = 223
    NOL_CARD_WRITE_ERROR = 224
    NOLCARD_IN_BLK = 225
    NOL_CARD_DEVICE_IN_BLK = 226
    NOL_CARD_BLOCKED = 227
    NOL_CARD_NOT_VALID = 228
    NOL_CARD_EXPIRED = 229
    NOL_CARD_INSUFFICIENT_PURSE_BALANCE = 230
    NOL_CARD_INVALID_CARD = 231
    NOL_CARD_EPURSE_BLOCKED = 232
    NOL_CARD_APPLICATION_NOT_INITIALIZED = 233
    NOL_CARD_EPURSE_NOT_INITIALIZED = 234
    NOL_CARD_RETIRED_CARD = 235
    BIOMETRIC_FAILURE_NO_FACE = 236
    PEOPLE_QTY_ACCESS_CONTROL_FAILURE = 237
    BIOMETRIC_FAILURE_ENTITLEMENT = 238
    ACCREDITATION_SYSTEM_ERROR = 239
    INCORRECT_EXIT = 240

    # Face Recognition codes (300-399)
    FR_FACE_ALREADY_ASSIGNED = 300
    FR_FACE_NOT_RECOGNIZED = 301
    FR_CONSENT_NOT_ALLOWED = 302
    FR_CONSENT_NOT_CHOOSED = 303
    FR_ACCOUNT_AK_NOT_FOUND = 304
    FR_FACE_RECOGNITION_NOT_CONFIGURED = 305
    FR_TICKET_ALREADY_USED = 306
    FR_MEDIACODE_ALREADY_EXISTS = 307
    FR_WRONG_DEVICE_CODE = 308
    FR_UNKNOWN_ERROR = 309

    # Suspended codes (400-499)
    TICKET_SUSPENDED = 400

    # Voided codes (500-599)
    VOIDED_TICKET = 500
    VOIDED = 501

    # Terms and conditions codes (600-699)
    TERMS_CONDITION_NOT_SIGNED = 600
    DEMAGNETIZED = 601
    VOIDED_BY_THE_ENCODING_STATION = 602
    INTERRUPTED_WHILE_ENCODING = 604
    VOIDED_THROUGH_UPGRADE = 607
    VOIDED_THROUGH_BLOCK = 608
    VOIDED_THROUGH_REFUND = 609
    CHANGED_PERFORMANCE = 610
    REPLACED_THROUGH_REISSUE = 611
    STOLEN = 616
    LOST = 617
    TRANSACTION_ABORT = 625

    # DASPO and blacklist codes (700-799)
    DASPO = 700
    INSERT_INTO_BLACK_LIST = 701
    SERVICE_VOID = 702
    VOID_DUE_CUSTOMER_REQUEST = 703
    TO_BE_ACTIVATED = 704
    TO_BE_ACTIVATED_BLOCKED = 705
    LINKED_PACKAGE_NOT_VALID = 706

    # Flex contract codes (800-899)
    BLOCKED_DUE_TO_FLEX_CONTRACT = 800
    VOIDED_TICKET_LIMIT = 899


# Data Classes
@dataclass
class ValidateResult:
    """Validation result structure.

    Based on Admission.xsd VALIDATERESULT type.

    Attributes:
        result_code: Result code indicating validation status (see ValidationResultCode enum)
        message: Messages for operator and customer
        lights: Light indicators (green, yellow, red) - see LightPattern enum
        flash: Flash indicator - see FlashEntitlement enum
        reentry: Reentry indicator - see ReentryStatus enum
        access_type: Access type - see AccessType enum
        product: Product information (optional)
        waiting_rotation: Waiting rotation indicator
    """

    result_code: int
    message: Dict[str, str]
    lights: Dict[str, int]
    flash: int
    reentry: int
    access_type: int
    product: Optional[Dict[str, str]] = None
    waiting_rotation: int = 0

    @classmethod
    def from_dict(cls, data: dict) -> "ValidateResult":
        """Create ValidateResult from API dictionary."""
        return cls(
            result_code=data.get("RESULTCODE", 0),
            message=data.get("MESSAGE", {}),
            lights=data.get("LIGHTS", {}),
            flash=data.get("FLASH", 0),
            reentry=data.get("REENTRY", 0),
            access_type=data.get("ACCESSTYPE", 0),
            product=data.get("PRODUCT"),
            waiting_rotation=data.get("WAITINGROTATION", 0),
        )

    def is_success(self) -> bool:
        """Check if the validation result indicates success."""
        return 1 <= self.result_code <= 99

    def is_error(self) -> bool:
        """Check if the validation result indicates an error."""
        return self.result_code >= 111

    def is_voided(self) -> bool:
        """Check if the ticket is voided."""
        return self.result_code >= 500

    def get_result_description(self) -> str:
        """Get a human-readable description of the result code."""
        try:
            result_enum = ValidationResultCode(self.result_code)
            return result_enum.name.replace("_", " ").title()
        except ValueError:
            return f"Unknown result code: {self.result_code}"


@dataclass
class MediaCodeBase:
    """Base media code information.

    Based on APICommon.xsd MEDIACODEBASE type.

    Attributes:
        identifier: Media identifier
        type: Identifier type (see MediaCodeType enum)
        void_type: Void type (see VoidType enum)
        void_type_desc: Void type description
        account: Account information (optional)
    """

    identifier: str
    type: int
    void_type: int
    void_type_desc: str
    account: Optional[BasicInfo] = None

    @classmethod
    def from_dict(cls, data: dict) -> "MediaCodeBase":
        """Create MediaCodeBase from API dictionary."""
        return cls(
            identifier=data.get("IDENTIFIER", ""),
            type=data.get("TYPE", 0),
            void_type=data.get("VOIDTYPE", 0),
            void_type_desc=data.get("VOIDTYPEDESC", ""),
            account=(
                BasicInfo.from_dict(data.get("ACCOUNT", {}))
                if data.get("ACCOUNT")
                else None
            ),
        )

    def get_media_type_description(self) -> str:
        """Get a human-readable description of the media type."""
        try:
            type_enum = MediaCodeType(self.type)
            return type_enum.name.replace("_", " ").title()
        except ValueError:
            return f"Unknown media type: {self.type}"

    def get_void_type_description(self) -> str:
        """Get a human-readable description of the void type."""
        try:
            void_enum = VoidType(self.void_type)
            return void_enum.name.replace("_", " ").title()
        except ValueError:
            return f"Unknown void type: {self.void_type}"

    def is_active(self) -> bool:
        """Check if the media code is active."""
        return self.void_type == VoidType.ACTIVE

    def is_voided(self) -> bool:
        """Check if the media code is voided."""
        return self.void_type != VoidType.ACTIVE


@dataclass
class MediaCodeBaseFull:
    """Full media code information.

    Based on APICommon.xsd MEDIACODEBASEFULL type.

    Attributes:
        identifier: Media identifier
        type: Identifier type (see MediaCodeType enum)
        void_type: Void type (see VoidType enum)
        void_type_desc: Void type description
        ticket_account: Ticket account information (optional)
        reservation_account: Reservation account information (optional)
        ticket: Ticket information (optional)
    """

    identifier: str
    type: int
    void_type: int
    void_type_desc: str
    ticket_account: Optional[BasicInfo] = None
    reservation_account: Optional[BasicInfo] = None
    ticket: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "MediaCodeBaseFull":
        """Create MediaCodeBaseFull from API dictionary."""
        return cls(
            identifier=data.get("IDENTIFIER", ""),
            type=data.get("TYPE", 0),
            void_type=data.get("VOIDTYPE", 0),
            void_type_desc=data.get("VOIDTYPEDESC", ""),
            ticket_account=(
                BasicInfo.from_dict(data.get("TICKETACCOUNT", {}))
                if data.get("TICKETACCOUNT")
                else None
            ),
            reservation_account=(
                BasicInfo.from_dict(data.get("RESERVATIONACCOUNT", {}))
                if data.get("RESERVATIONACCOUNT")
                else None
            ),
            ticket=data.get("TICKET"),
        )

    def get_media_type_description(self) -> str:
        """Get a human-readable description of the media type."""
        try:
            type_enum = MediaCodeType(self.type)
            return type_enum.name.replace("_", " ").title()
        except ValueError:
            return f"Unknown media type: {self.type}"

    def get_void_type_description(self) -> str:
        """Get a human-readable description of the void type."""
        try:
            void_enum = VoidType(self.void_type)
            return void_enum.name.replace("_", " ").title()
        except ValueError:
            return f"Unknown void type: {self.void_type}"

    def is_active(self) -> bool:
        """Check if the media code is active."""
        return self.void_type == VoidType.ACTIVE

    def is_voided(self) -> bool:
        """Check if the media code is voided."""
        return self.void_type != VoidType.ACTIVE


@dataclass
class AdditionalInfo:
    """Additional information for scanning operations.

    Based on Admission.xsd ADDITIONALINFO type.

    Attributes:
        type: Information type
        info_file: Info file (optional)
        info_string: Info string (optional)
        group_qty: Group quantity (optional)
        overrides: Override options (optional)
        retrieve_original_picture: Whether to retrieve original picture (optional)
    """

    type: int
    info_file: Optional[bytes] = None
    info_string: Optional[str] = None
    group_qty: Optional[int] = None
    overrides: Optional[Dict[str, bool]] = None
    retrieve_original_picture: Optional[bool] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"TYPE": self.type}
        if self.info_file is not None:
            result["INFOFILE"] = self.info_file
        if self.info_string is not None:
            result["INFOSTRING"] = self.info_string
        if self.group_qty is not None:
            result["GROUPQTY"] = self.group_qty
        if self.overrides is not None:
            result["OVERRIDES"] = self.overrides
        if self.retrieve_original_picture is not None:
            result["RETRIEVEORIGINALPICTURE"] = self.retrieve_original_picture
        return result


@dataclass
class ScanDateTime:
    """Scan date and time information.

    Based on Admission.xsd SCANDATETIME type.

    Attributes:
        date: Scan date
        time: Scan time
    """

    date: str
    time: str

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "DATE": self.date,
            "TIME": self.time,
        }


@dataclass
class MediaCodeItem:
    """Media code item for multiple scanning.

    Based on Admission.xsd MEDIACODE type.

    Attributes:
        identifier: Media identifier
    """

    identifier: str

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"IDENTIFIER": self.identifier}


# Request Classes
@dataclass
class ScanMediaCodeRequest:
    """Structured request for ScanMediaCode operation.

    Based on Admission.xsd SCANMEDIACODEINPUT structure.

    Attributes:
        media_code: Media code to scan
        access_point_ak: Access point AK
        access_type: Access type (optional)
        additional_info: Additional information (optional)
    """

    media_code: str
    access_point_ak: str
    access_type: Optional[int] = None
    additional_info: Optional[AdditionalInfo] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "MEDIACODE": self.media_code,
            "ACCESSPOINTAK": self.access_point_ak,
        }
        if self.access_type is not None:
            result["ACCESSTYPE"] = self.access_type
        if self.additional_info is not None:
            result["ADDITIONALINFO"] = self.additional_info.to_dict()
        return result


@dataclass
class ScanAccountAkRequest:
    """Structured request for ScanAccountAK operation.

    Based on Admission.xsd SCANACCOUNTAKINPUT structure.

    Attributes:
        account_ak: Account AK to scan
        access_point_ak: Access point AK (optional)
        access_point_external_code: Access point external code (optional)
    """

    account_ak: str
    access_point_ak: Optional[str] = None
    access_point_external_code: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"ACCOUNTAK": self.account_ak}
        if self.access_point_ak is not None:
            result["ACCESSPOINTAK"] = self.access_point_ak
        if self.access_point_external_code is not None:
            result["ACCESSPOINTEXTERNALCODE"] = self.access_point_external_code
        return result


@dataclass
class ScanMultipleMediaCodeRequest:
    """Structured request for ScanMultipleMediaCode operation.

    Based on Admission.xsd SCANMULTIPLEMEDIACODEINPUT structure.

    Attributes:
        access_point_ak: Access point AK
        access_type: Access type (optional)
        scan_date_time: Scan date and time (optional)
        media_code_list: List of media codes to scan (optional)
    """

    access_point_ak: str
    access_type: Optional[int] = None
    scan_date_time: Optional[ScanDateTime] = None
    media_code_list: Optional[List[MediaCodeItem]] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"ACCESSPOINTAK": self.access_point_ak}
        if self.access_type is not None:
            result["ACCESSTYPE"] = self.access_type
        if self.scan_date_time is not None:
            result["SCANDATETIME"] = self.scan_date_time.to_dict()
        if self.media_code_list is not None:
            result["MEDIACODELIST"] = {
                "MEDIACODE": [item.to_dict() for item in self.media_code_list]
            }
        return result


# Response Classes
@dataclass
class ScanMediaCodeResponse:
    """Response for ScanMediaCode operation.

    Based on Admission.xsd SCANMEDIACODEOUTPUT structure.

    Attributes:
        error: Error information
        media_code_info: Media code information
        scan_result: Scan validation result
        info_file: Info file (optional)
    """

    error: Error
    media_code_info: MediaCodeBase
    scan_result: ValidateResult
    info_file: Optional[bytes] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ScanMediaCodeResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            media_code_info=MediaCodeBase.from_dict(data.get("MEDIACODEINFO", {})),
            scan_result=ValidateResult.from_dict(data.get("SCANRESULT", {})),
            info_file=data.get("INFOFILE"),
        )


@dataclass
class ScanMediaCodeFullResponse:
    """Response for ScanMediaCodeFull operation.

    Based on Admission.xsd SCANMEDIACODEOUTPUTFULL structure.

    Attributes:
        error: Error information
        media_code_info_full: Full media code information
        scan_result: Scan validation result
        first_name: First name
        last_name: Last name
        email: Email address
        seat: Seat information
        price_group: Price group
        modified: Whether modified
        info_file: Info file (optional)
    """

    error: Error
    media_code_info_full: MediaCodeBaseFull
    scan_result: ValidateResult
    first_name: str
    last_name: str
    email: str
    seat: str
    price_group: str
    modified: bool
    info_file: Optional[bytes] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ScanMediaCodeFullResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            media_code_info_full=MediaCodeBaseFull.from_dict(
                data.get("MEDIACODEINFOFULL", {})
            ),
            scan_result=ValidateResult.from_dict(data.get("SCANRESULT", {})),
            first_name=data.get("FIRSTNAME", ""),
            last_name=data.get("LASTNAME", ""),
            email=data.get("EMAIL", ""),
            seat=data.get("SEAT", ""),
            price_group=data.get("PRICEGROUP", ""),
            modified=data.get("MODIFIED", False),
            info_file=data.get("INFOFILE"),
        )


@dataclass
class ScanAccountAkResponse:
    """Response for ScanAccountAK operation.

    Based on Admission.xsd SCANACCOUNTAKOUTPUT structure.

    Attributes:
        error: Error information
        media_code_info: Media code information
        scan_result: Scan validation result
    """

    error: Error
    media_code_info: MediaCodeBase
    scan_result: ValidateResult

    @classmethod
    def from_dict(cls, data: dict) -> "ScanAccountAkResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            media_code_info=MediaCodeBase.from_dict(data.get("MEDIACODEINFO", {})),
            scan_result=ValidateResult.from_dict(data.get("SCANRESULT", {})),
        )


@dataclass
class ScanMultipleMediaCodeResponse:
    """Response for ScanMultipleMediaCode operation.

    Based on Admission.xsd SCANMULTIPLEMEDIACODEOUTPUT structure.

    Attributes:
        error: Error information
        access_point_ak: Access point AK
        scan_date_time: Scan date and time (optional)
        media_code_list: List of scanned media codes (optional)
    """

    error: Error
    access_point_ak: str
    scan_date_time: Optional[str] = None
    media_code_list: Optional[List[Dict[str, Any]]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ScanMultipleMediaCodeResponse":
        """Create response from API dictionary."""
        media_code_list_data = data.get("MEDIACODELIST", {}).get("MEDIACODE", [])
        if not isinstance(media_code_list_data, list):
            media_code_list_data = (
                [media_code_list_data] if media_code_list_data else []
            )

        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            access_point_ak=data.get("ACCESSPOINTAK", ""),
            scan_date_time=data.get("SCANDATETIME"),
            media_code_list=media_code_list_data,
        )
