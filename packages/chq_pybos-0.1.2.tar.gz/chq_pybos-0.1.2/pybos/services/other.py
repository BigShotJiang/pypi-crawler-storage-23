"""
Other service for the BOS API.

This service provides methods for miscellaneous operations including stored procedures.
"""

from ..base_service import BaseService
from ..types.other import (
    ExecStoredProcedureRequest,
    ExecStoredProcedureResponse,
    RaiseAnAccessViolationResponse,
)


class OtherService(BaseService):
    """Service for BOS other/miscellaneous operations.

    This service provides methods for executing stored procedures and other
    miscellaneous operations in the BOS system.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIOther")

    Example:
        >>> service = OtherService(bos_api, "IWsAPIOther")
        >>> request = ExecStoredProcedureRequest(
        ...     stored_procedure_name="sp_GetData",
        ...     stored_procedure_parameter_list=[{"NAME": "param1", "VALUE": "value1"}]
        ... )
        >>> response = service.exec_stored_procedure(request)
        >>> if response.error.is_success:
        ...     print(f"Result: {response.stored_procedure_result}")
    """

    def exec_stored_procedure(
        self, request: ExecStoredProcedureRequest
    ) -> ExecStoredProcedureResponse:
        """Execute a stored procedure.

        Args:
            request: ExecStoredProcedureRequest with procedure name and parameters

        Returns:
            ExecStoredProcedureResponse: Response containing procedure result

        Example:
            >>> request = ExecStoredProcedureRequest(
            ...     stored_procedure_name="sp_GetData",
            ...     stored_procedure_parameter_list=[{"NAME": "param1", "VALUE": "value1"}]
            ... )
            >>> response = service.exec_stored_procedure(request)
            >>> if response.error.is_success:
            ...     print(f"Result: {response.stored_procedure_result}")
        """
        payload = {
            "urn:ExecStoredProcedure": {
                "EXECSTOREDPROCEDUREREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ExecStoredProcedureResponse.from_dict(
            response["ExecStoredProcedureResponse"]["EXECSTOREDPROCEDURERESP"]
        )

    def raise_an_access_violation(
        self, dummy: str
    ) -> RaiseAnAccessViolationResponse:
        """Raise an access violation (for testing purposes).

        Args:
            dummy: Dummy string parameter

        Returns:
            RaiseAnAccessViolationResponse: Response with error information

        Example:
            >>> response = service.raise_an_access_violation("test")
            >>> print(f"Error: {response.error}")
        """
        payload = {"urn:RaiseAnAccessViolation": {"ADummy": dummy}}
        response = self.send_request(payload)
        return RaiseAnAccessViolationResponse.from_dict(
            response["RaiseAnAccessViolationResponse"]["return"]
        )
