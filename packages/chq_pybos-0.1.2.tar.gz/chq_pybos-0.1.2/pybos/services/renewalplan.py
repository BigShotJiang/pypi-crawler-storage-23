"""
Renewal plan service for the BOS API.

This service provides methods for renewal plan operations including creation,
reading, and managing renewal contracts.
"""

from ..base_service import BaseService
from ..types.renewalplanenquiry import (
    ChangeRenewalContractStatusRequest,
    ChangeRenewalContractStatusResponse,
    InsertCardOnFileRequest,
    DeleteCardOnFileRequest,
    CardOnFileResponse,
    CardOnFileDetailsListRequest,
    CardOnFileDetailsListResponse,
    ReadRenewalPlanInfoByAKRequest,
    ReadRenewalPlanInfoByAKResponse,
    RenewalPlanListRequest,
    RenewalPlanListResponse,
    ExecRenewalPlanByAccountAKRequest,
    ExecRenewalPlanByAccountAKResponse,
    CreateRenewalPlanRequest,
    CreateRenewalPlanResponse,
    ChangeTargetTicketsRequest,
    ChangeTargetTicketsResponse,
)


class RenewalPlanService(BaseService):
    """Service for BOS renewal plan operations.

    This service provides methods for renewal plan management including
    creating, reading, and managing renewal contracts in the BOS system.
    All complex data structures use typed classes instead of dictionaries for
    better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIRenewalPlan")

    Example:
        >>> service = RenewalPlanService(bos_api, "IWsAPIRenewalPlan")
        >>> request = ReadRenewalPlanInfoByAKRequest(renewal_plan_ak="PLAN123")
        >>> response = service.read_renewal_plan_info_by_ak(request)
        >>> if response.error.is_success:
        ...     print(f"Plan: {response.renewal_plan.get('RENEWALPLANAK')}")
    """

    def reactivate_renewal_plan(
        self, request: ChangeRenewalContractStatusRequest
    ) -> ChangeRenewalContractStatusResponse:
        """Reactivate renewal plan.

        Args:
            request: ChangeRenewalContractStatusRequest with renewal plan AK

        Returns:
            ChangeRenewalContractStatusResponse: Response with operation result

        Example:
            >>> request = ChangeRenewalContractStatusRequest(renewal_plan_ak="PLAN123")
            >>> response = service.reactivate_renewal_plan(request)
            >>> if response.error.is_success:
            ...     print(f"Reactivated: {response.renewal_plan_ak}")
        """
        payload = {
            "urn:ReactivateRenewalPlan": {
                "CHANGERENEWALCONTRACTSTATUSREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ChangeRenewalContractStatusResponse.from_dict(
            response["ReactivateRenewalPlanResponse"]["return"]
        )

    def cancel_renewal_plan(
        self, request: ChangeRenewalContractStatusRequest
    ) -> ChangeRenewalContractStatusResponse:
        """Cancel renewal plan.

        Args:
            request: ChangeRenewalContractStatusRequest with renewal plan AK

        Returns:
            ChangeRenewalContractStatusResponse: Response with operation result

        Example:
            >>> request = ChangeRenewalContractStatusRequest(renewal_plan_ak="PLAN123")
            >>> response = service.cancel_renewal_plan(request)
            >>> if response.error.is_success:
            ...     print(f"Cancelled: {response.renewal_plan_ak}")
        """
        payload = {
            "urn:CancelRenewalPlan": {
                "CHANGERENEWALCONTRACTSTATUSREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ChangeRenewalContractStatusResponse.from_dict(
            response["CancelRenewalPlanResponse"]["return"]
        )

    def deactivate_renewal_plan(
        self, request: ChangeRenewalContractStatusRequest
    ) -> ChangeRenewalContractStatusResponse:
        """Deactivate renewal plan.

        Args:
            request: ChangeRenewalContractStatusRequest with renewal plan AK

        Returns:
            ChangeRenewalContractStatusResponse: Response with operation result

        Example:
            >>> request = ChangeRenewalContractStatusRequest(renewal_plan_ak="PLAN123")
            >>> response = service.deactivate_renewal_plan(request)
            >>> if response.error.is_success:
            ...     print(f"Deactivated: {response.renewal_plan_ak}")
        """
        payload = {
            "urn:DeactivateRenewalPlan": {
                "CHANGERENEWALCONTRACTSTATUSREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ChangeRenewalContractStatusResponse.from_dict(
            response["DeactivateRenewalPlanResponse"]["return"]
        )

    def insert_card_on_file(
        self, request: InsertCardOnFileRequest
    ) -> CardOnFileResponse:
        """Insert card on file.

        Args:
            request: InsertCardOnFileRequest with card details

        Returns:
            CardOnFileResponse: Response with card on file ID

        Example:
            >>> request = InsertCardOnFileRequest(
            ...     account_ak="ACC123",
            ...     card_on_file_type=1,
            ...     stored_payment_method_id="PM123",
            ...     card_name="Visa",
            ...     card_number="****1234",
            ...     expiration="12-2025",
            ...     holder_name="John Doe"
            ... )
            >>> response = service.insert_card_on_file(request)
            >>> if response.error.is_success:
            ...     print(f"Card ID: {response.account_card_on_file_id}")
        """
        payload = {
            "urn:InsertCardOnFile": {"INSERTCARDONFILEREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return CardOnFileResponse.from_dict(
            response["InsertCardOnFileResponse"]["return"]
        )

    def delete_card_on_file(
        self, request: DeleteCardOnFileRequest
    ) -> CardOnFileResponse:
        """Delete card on file.

        Args:
            request: DeleteCardOnFileRequest with card on file ID

        Returns:
            CardOnFileResponse: Response with operation result

        Example:
            >>> request = DeleteCardOnFileRequest(account_card_on_file_id=123)
            >>> response = service.delete_card_on_file(request)
            >>> if response.error.is_success:
            ...     print("Card deleted")
        """
        payload = {
            "urn:DeleteCardOnFile": {"DELETECARDONFILEREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return CardOnFileResponse.from_dict(
            response["DeleteCardOnFileResponse"]["return"]
        )

    def read_card_on_file_list(
        self, request: CardOnFileDetailsListRequest
    ) -> CardOnFileDetailsListResponse:
        """Read card on file list.

        Args:
            request: CardOnFileDetailsListRequest with account AK

        Returns:
            CardOnFileDetailsListResponse: Response with card list

        Example:
            >>> request = CardOnFileDetailsListRequest(account_ak="ACC123")
            >>> response = service.read_card_on_file_list(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.card_on_file_details_list)} cards")
        """
        payload = {
            "urn:ReadCardOnFileList": {
                "CARDONFILEDETAILSLISTREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return CardOnFileDetailsListResponse.from_dict(
            response["ReadCardOnFileListResponse"]["return"]
        )

    def read_renewal_plan_info_by_ak(
        self, request: ReadRenewalPlanInfoByAKRequest
    ) -> ReadRenewalPlanInfoByAKResponse:
        """Read renewal plan information by AK.

        Args:
            request: ReadRenewalPlanInfoByAKRequest with renewal plan AK

        Returns:
            ReadRenewalPlanInfoByAKResponse: Response with renewal plan details

        Example:
            >>> request = ReadRenewalPlanInfoByAKRequest(renewal_plan_ak="PLAN123")
            >>> response = service.read_renewal_plan_info_by_ak(request)
            >>> if response.error.is_success:
            ...     print(f"Status: {response.renewal_plan.get('STATUS')}")
        """
        payload = {
            "urn:ReadRenewalPlanInfoByAK": {
                "READRENEWALPLANINFOBYAKREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ReadRenewalPlanInfoByAKResponse.from_dict(
            response["ReadRenewalPlanInfoByAKResponse"]["return"]
        )

    def read_renewal_plan_list(
        self, request: RenewalPlanListRequest
    ) -> RenewalPlanListResponse:
        """Read renewal plan list.

        Args:
            request: RenewalPlanListRequest with filters

        Returns:
            RenewalPlanListResponse: Response with renewal plan list

        Example:
            >>> request = RenewalPlanListRequest(account_ak="ACC123", status=1)
            >>> response = service.read_renewal_plan_list(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.renewal_plan_list)} plans")
        """
        payload = {
            "urn:ReadRenewalPlanList": {"RENEWALPLANLISTREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return RenewalPlanListResponse.from_dict(
            response["ReadRenewalPlanListResponse"]["return"]
        )

    def exec_renewal_plan_by_account_ak(
        self, request: ExecRenewalPlanByAccountAKRequest
    ) -> ExecRenewalPlanByAccountAKResponse:
        """Execute renewal plan by account AK.

        Args:
            request: ExecRenewalPlanByAccountAKRequest with account AK

        Returns:
            ExecRenewalPlanByAccountAKResponse: Response with execution result

        Example:
            >>> request = ExecRenewalPlanByAccountAKRequest(account_ak="ACC123")
            >>> response = service.exec_renewal_plan_by_account_ak(request)
            >>> if response.error.is_success:
            ...     print(f"Result: {response.message_result}")
        """
        payload = {
            "urn:ExecRenewalPlanByAccountAK": {
                "EXECRENEWALPLANBYACCOUNTAKREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ExecRenewalPlanByAccountAKResponse.from_dict(
            response["ExecRenewalPlanByAccountAKResponse"]["return"]
        )

    def create_renewal_plan(
        self, request: CreateRenewalPlanRequest
    ) -> CreateRenewalPlanResponse:
        """Create renewal plan.

        Args:
            request: CreateRenewalPlanRequest with ticket ID

        Returns:
            CreateRenewalPlanResponse: Response with created renewal plan AK

        Example:
            >>> request = CreateRenewalPlanRequest(ticket_id=12345)
            >>> response = service.create_renewal_plan(request)
            >>> if response.error.is_success:
            ...     print(f"Created: {response.renewal_plan_ak}")
        """
        payload = {
            "urn:CreateRenewalPlan": {"CREATERENEWALPLANREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return CreateRenewalPlanResponse.from_dict(
            response["CreateRenewalPlanResponse"]["return"]
        )

    def change_target_tickets(
        self, request: ChangeTargetTicketsRequest
    ) -> ChangeTargetTicketsResponse:
        """Change target tickets.

        Args:
            request: ChangeTargetTicketsRequest with ticket changes

        Returns:
            ChangeTargetTicketsResponse: Response with operation result

        Example:
            >>> request = ChangeTargetTicketsRequest(
            ...     original_matrix_cell_ak="CELL123",
            ...     new_matrix_cell_ak="CELL456",
            ...     renewal_plan_ak="PLAN123"
            ... )
            >>> response = service.change_target_tickets(request)
            >>> if response.error.is_success:
            ...     print("Tickets changed")
        """
        payload = {
            "urn:ChangeTargetTickets": {
                "CHANGETARGETTICKETSREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ChangeTargetTicketsResponse.from_dict(
            response["ChangeTargetTicketsResponse"]["return"]
        )
