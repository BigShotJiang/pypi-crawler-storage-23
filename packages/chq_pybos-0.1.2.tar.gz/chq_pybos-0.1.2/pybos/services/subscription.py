"""
Subscription service for the BOS API.

This service provides methods for subscription operations including search,
availability checking, and subscription management.
"""

from ..base_service import BaseService
from ..types.subscriptionenquiry import (
    FindAllSubscriptionResponse,
    ReadSubscriptionByAKResponse,
    GetSubscriptionAvailabilityRequest,
    GetSubscriptionAvailabilityResponse,
    SearchSubscriptionRequest,
    SearchSubscriptionResponse,
)


class SubscriptionService(BaseService):
    """Service for BOS subscription operations with improved developer ergonomics.

    This service provides methods for subscription management, search, and
    availability checking in the BOS system. All complex data structures use
    typed classes instead of dictionaries for better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPISubscription")

    Example:
        >>> service = SubscriptionService(bos_api, "IWsAPISubscription")
        >>> response = service.find_all_subscription()
        >>> if response.error.is_success:
        ...     print(f"Found {len(response.subscription_list)} subscriptions")
    """

    def find_all_subscription(self) -> FindAllSubscriptionResponse:
        """Find all subscriptions.

        Returns:
            FindAllSubscriptionResponse: Response containing list of subscriptions

        Example:
            >>> response = service.find_all_subscription()
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.subscription_list)} subscriptions")
        """
        payload = {"urn:FindAllSubscription": None}
        response = self.send_request(payload)
        return FindAllSubscriptionResponse.from_dict(
            response["FindAllSubscriptionResponse"]["return"]
        )

    def read_subscription_by_ak(
        self, subscription_ak: str
    ) -> ReadSubscriptionByAKResponse:
        """Read subscription details by subscription AK.

        Args:
            subscription_ak: Subscription AK identifier

        Returns:
            ReadSubscriptionByAKResponse: Response containing subscription details

        Example:
            >>> response = service.read_subscription_by_ak("SUB123")
            >>> if response.error.is_success:
            ...     print(f"Subscription: {response.subscription.name}")
        """
        payload = {"urn:ReadSubscriptionByAK": {"ASubscriptionAK": subscription_ak}}
        response = self.send_request(payload)
        return ReadSubscriptionByAKResponse.from_dict(
            response["ReadSubscriptionByAKResponse"]["return"]
        )

    def get_subscription_availability(
        self, request: GetSubscriptionAvailabilityRequest
    ) -> GetSubscriptionAvailabilityResponse:
        """Get subscription availability.

        Args:
            request: GetSubscriptionAvailabilityRequest with subscription AK and reductions

        Returns:
            GetSubscriptionAvailabilityResponse: Response containing availability information

        Example:
            >>> request = GetSubscriptionAvailabilityRequest(
            ...     subscription_ak="SUB123",
            ...     selected_reduction_list=[{"ID": 1, "QUANTITY": 2}]
            ... )
            >>> response = service.get_subscription_availability(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.subscription_perf_list)} performances")
        """
        payload = {
            "urn:GetSubscriptionAvailability": {
                "GETSUBSCRIPTIONAVAILABILITYREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return GetSubscriptionAvailabilityResponse.from_dict(
            response["GetSubscriptionAvailabilityResponse"]["return"]
        )

    def search_subscription(
        self, request: SearchSubscriptionRequest
    ) -> SearchSubscriptionResponse:
        """Search for subscriptions with various filters.

        Args:
            request: SearchSubscriptionRequest with search criteria

        Returns:
            SearchSubscriptionResponse: Response containing list of subscriptions

        Example:
            >>> from ..types.common import PageRequest
            >>> request = SearchSubscriptionRequest(
            ...     subscription_type=1,  # Fixed
            ...     subscription_status=1,  # On Sale
            ...     page_req=PageRequest(page_index=1, page_size=10)
            ... )
            >>> response = service.search_subscription(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.subscription_list)} subscriptions")
        """
        payload = {
            "urn:SearchSubscription": {"SEARCHSUBSCRIPTIONREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return SearchSubscriptionResponse.from_dict(
            response["SearchSubscriptionResponse"]["return"]
        )
