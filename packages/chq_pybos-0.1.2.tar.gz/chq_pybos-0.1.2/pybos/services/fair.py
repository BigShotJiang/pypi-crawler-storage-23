"""
Fair service for the BOS API.

This service provides methods for fair operations including sales reporting,
account management, and email notifications.
"""

from ..base_service import BaseService
from ..types.fairenquiry import (
    GetFairSalesRequest,
    GetFairSalesResponse,
    GetFairAccountsRequest,
    GetFairAccountsResponse,
    GetFairAccountCSVResponse,
    GetFairSalesCSVResponse,
    SendTckOwnerEmailRequest,
    SendTckOwnerEmailResponse,
    GetFairSalesDashBoardRequest,
    GetFairSalesDashBoardResponse,
    GetExtendedSalesRequest,
    GetExtendedSalesResponse,
)


class FairService(BaseService):
    """Service for BOS fair operations with improved developer ergonomics.

    This service provides methods for fair management, sales reporting, account
    management, and email notifications in the BOS system. All complex data
    structures use typed classes instead of dictionaries for better IDE support
    and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIFair")

    Example:
        >>> service = FairService(bos_api, "IWsAPIFair")
        >>> request = GetFairSalesRequest(
        ...     dmg_category_ak="CAT123",
        ...     filter_range={"FROM": "2024-01-01T00:00:00", "TO": "2024-12-31T23:59:59"}
        ... )
        >>> response = service.get_fair_sales(request)
        >>> if response.error.is_success:
        ...     print(f"Found {len(response.sale_list)} sales")
    """

    def get_fair_sales(
        self, request: GetFairSalesRequest
    ) -> GetFairSalesResponse:
        """Get fair sales for a category and date range.

        Args:
            request: GetFairSalesRequest with category and date range

        Returns:
            GetFairSalesResponse: Response containing list of sales

        Example:
            >>> request = GetFairSalesRequest(
            ...     dmg_category_ak="CAT123",
            ...     filter_range={"FROM": "2024-01-01T00:00:00", "TO": "2024-12-31T23:59:59"}
            ... )
            >>> response = service.get_fair_sales(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.sale_list)} sales")
        """
        payload = {
            "urn:GetFairSales": {"GETFAIRSALESREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return GetFairSalesResponse.from_dict(
            response["GetFairSalesResponse"]["return"]
        )

    def get_fair_accounts(
        self, request: GetFairAccountsRequest
    ) -> GetFairAccountsResponse:
        """Get fair accounts for a category and date range.

        Args:
            request: GetFairAccountsRequest with category and date range

        Returns:
            GetFairAccountsResponse: Response containing list of fair accounts

        Example:
            >>> request = GetFairAccountsRequest(
            ...     dmg_category_ak="CAT123",
            ...     filter_range={"FROM": "2024-01-01T00:00:00", "TO": "2024-12-31T23:59:59"}
            ... )
            >>> response = service.get_fair_accounts(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.fair_account_list)} accounts")
        """
        payload = {
            "urn:GetFairAccounts": {"GETFAIRACCOUNTSREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return GetFairAccountsResponse.from_dict(
            response["GetFairAccountsResponse"]["return"]
        )

    def get_fair_account_csv(
        self, dmg_category_ak: str
    ) -> GetFairAccountCSVResponse:
        """Get fair account CSV for a category.

        Args:
            dmg_category_ak: DMG category AK

        Returns:
            GetFairAccountCSVResponse: Response containing CSV data

        Example:
            >>> response = service.get_fair_account_csv("CAT123")
            >>> if response.error.is_success:
            ...     print(f"CSV data: {len(response.csv)} bytes")
        """
        payload = {"urn:GetFairAccountCSV": {"ADmgCategoryAK": dmg_category_ak}}
        response = self.send_request(payload)
        return GetFairAccountCSVResponse.from_dict(
            response["GetFairAccountCSVResponse"]["return"]
        )

    def get_fair_sales_csv(
        self, event_ak: str, date_from: str, date_to: str
    ) -> GetFairSalesCSVResponse:
        """Get fair sales CSV for an event and date range.

        Args:
            event_ak: Event AK
            date_from: Start date (YYYY-MM-DD format)
            date_to: End date (YYYY-MM-DD format)

        Returns:
            GetFairSalesCSVResponse: Response containing CSV data

        Example:
            >>> response = service.get_fair_sales_csv("EVENT123", "2024-01-01", "2024-12-31")
            >>> if response.error.is_success:
            ...     print(f"CSV data: {len(response.csv)} bytes")
        """
        payload = {
            "urn:GetFairSalesCSV": {
                "AEventAK": event_ak,
                "ADateFrom": date_from,
                "ADateTo": date_to,
            }
        }
        response = self.send_request(payload)
        return GetFairSalesCSVResponse.from_dict(
            response["GetFairSalesCSVResponse"]["return"]
        )

    def send_tck_owner_email(
        self, request: SendTckOwnerEmailRequest
    ) -> SendTckOwnerEmailResponse:
        """Send ticket owner email.

        Args:
            request: SendTckOwnerEmailRequest with account, sale, language, and email

        Returns:
            SendTckOwnerEmailResponse: Response with operation result

        Example:
            >>> request = SendTckOwnerEmailRequest(
            ...     account_ak="ACC123",
            ...     sale_ak="SALE123",
            ...     language_ak="LANG123",
            ...     email_address="user@example.com"
            ... )
            >>> response = service.send_tck_owner_email(request)
            >>> if response.error.is_success:
            ...     print("Email sent")
        """
        payload = {
            "urn:SendTckOwnerEmail": {"SENDTCKOWNEREMAILREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return SendTckOwnerEmailResponse.from_dict(
            response["SendTckOwnerEmailResponse"]["return"]
        )

    def send_account_to_be_approved_email(
        self, account_ak: str
    ) -> SendTckOwnerEmailResponse:
        """Send account to be approved email.

        Args:
            account_ak: Account AK

        Returns:
            SendTckOwnerEmailResponse: Response with operation result

        Example:
            >>> response = service.send_account_to_be_approved_email("ACC123")
            >>> if response.error.is_success:
            ...     print("Email sent")
        """
        payload = {"urn:SendAccountToBeApprovedEmail": {"AAccountAk": account_ak}}
        response = self.send_request(payload)
        return SendTckOwnerEmailResponse.from_dict(
            response["SendAccountToBeApprovedEmailResponse"]["return"]
        )

    def send_account_refused_email(
        self, account_ak: str
    ) -> SendTckOwnerEmailResponse:
        """Send account refused email.

        Args:
            account_ak: Account AK

        Returns:
            SendTckOwnerEmailResponse: Response with operation result

        Example:
            >>> response = service.send_account_refused_email("ACC123")
            >>> if response.error.is_success:
            ...     print("Email sent")
        """
        payload = {"urn:SendAccountRefusedEmail": {"AAccountAk": account_ak}}
        response = self.send_request(payload)
        return SendTckOwnerEmailResponse.from_dict(
            response["SendAccountRefusedEmailResponse"]["return"]
        )

    def get_fair_sales_dash_board(
        self, request: GetFairSalesDashBoardRequest
    ) -> GetFairSalesDashBoardResponse:
        """Get fair sales dashboard data.

        Args:
            request: GetFairSalesDashBoardRequest with category and date range

        Returns:
            GetFairSalesDashBoardResponse: Response containing dashboard data

        Example:
            >>> request = GetFairSalesDashBoardRequest(
            ...     dmg_category_ak="CAT123",
            ...     filter_range={"FROM": "2024-01-01T00:00:00", "TO": "2024-12-31T23:59:59"}
            ... )
            >>> response = service.get_fair_sales_dash_board(request)
            >>> if response.error.is_success:
            ...     print(f"Total: {response.dashboard_totals.get('TOTALAMOUNT')}")
        """
        payload = {
            "urn:GetFairSalesDashBoard": {
                "GETFAIRSALESDASHBOARDREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return GetFairSalesDashBoardResponse.from_dict(
            response["GetFairSalesDashBoardResponse"]["return"]
        )

    def get_extended_sales(
        self, request: GetExtendedSalesRequest
    ) -> GetExtendedSalesResponse:
        """Get extended sales for an event and date range.

        Args:
            request: GetExtendedSalesRequest with event AK and date filter

        Returns:
            GetExtendedSalesResponse: Response containing extended sales data

        Example:
            >>> from ..types.common import BaseDateFilter
            >>> request = GetExtendedSalesRequest(
            ...     event_ak="EVENT123",
            ...     date_filter=BaseDateFilter(from_date="2024-01-01", to_date="2024-12-31")
            ... )
            >>> response = service.get_extended_sales(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.extended_sale_list)} extended sales")
        """
        payload = {
            "urn:GetExtendedSales": {"GETEXTENDEDSALESREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return GetExtendedSalesResponse.from_dict(
            response["GetExtendedSalesResponse"]["return"]
        )
