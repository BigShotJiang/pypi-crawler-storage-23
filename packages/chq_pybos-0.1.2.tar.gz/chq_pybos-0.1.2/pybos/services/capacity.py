"""
Capacity service for the BOS API.

This service provides methods for capacity operations including release and editing.
"""

from ..base_service import BaseService
from ..types.capacity import (
    ReleaseCapacityRequest,
    ReleaseCapacityResponse,
    EditCapacityRequest,
    EditCapacityResponse,
)


class CapacityService(BaseService):
    """Service for BOS capacity operations.

    This service provides methods for capacity management including release and
    editing in the BOS system. All complex data structures use typed classes
    instead of dictionaries for better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPICapacity")

    Example:
        >>> service = CapacityService(bos_api, "IWsAPICapacity")
        >>> request = ReleaseCapacityRequest(guid_list=["GUID123"])
        >>> response = service.release_capacity(request)
        >>> if response.error.is_success:
        ...     print("Capacity released")
    """

    def release_capacity(
        self, request: ReleaseCapacityRequest
    ) -> ReleaseCapacityResponse:
        """Release capacity by GUID list.

        Args:
            request: ReleaseCapacityRequest with GUID list

        Returns:
            ReleaseCapacityResponse: Response with operation result

        Example:
            >>> request = ReleaseCapacityRequest(guid_list=["GUID123", "GUID456"])
            >>> response = service.release_capacity(request)
            >>> if response.error.is_success:
            ...     print("Capacity released")
        """
        payload = {
            "urn:ReleaseCapacity": {"ReleaseCapacityReq": request.to_dict()}
        }
        response = self.send_request(payload)
        return ReleaseCapacityResponse.from_dict(
            response["ReleaseCapacityResponse"]["return"]
        )

    def edit_capacity(
        self, request: EditCapacityRequest
    ) -> EditCapacityResponse:
        """Edit capacity for performances.

        Args:
            request: EditCapacityRequest with performance filter and capacity edits

        Returns:
            EditCapacityResponse: Response containing updated performance list

        Example:
            >>> request = EditCapacityRequest(
            ...     search_performance={"PERFORMANCEAK": "PERF123"},
            ...     edit_capacity_list=[
            ...         {
            ...             "EDITCAPACITY": {"DELTACAPACITY": -10},
            ...             "SEATCATEGORYCODE": "CAT123"
            ...         }
            ...     ]
            ... )
            >>> response = service.edit_capacity(request)
            >>> if response.error.is_success:
            ...     print("Capacity updated")
        """
        payload = {
            "urn:EditCapacity": {"EditCapacityReq": request.to_dict()}
        }
        response = self.send_request(payload)
        return EditCapacityResponse.from_dict(
            response["EditCapacityResponse"]["return"]
        )
