"""
Price List service for the BOS API.

This service provides methods for price list operations.
"""

from ..base_service import BaseService
from ..types.pricelistenquiry import (
    ReadPriceListByAKResponse,
    ReadPriceListByIdResponse,
)


class PriceListService(BaseService):
    """Service for BOS price list operations.

    This service provides methods for reading price list information in the
    BOS system. All complex data structures use typed classes instead of
    dictionaries for better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIPriceList")

    Example:
        >>> service = PriceListService(bos_api, "IWsAPIPriceList")
        >>> response = service.read_price_list_by_ak("PRICE123")
        >>> if response.error.is_success:
        ...     print(f"Price list: {response.price_list.get('NAME')}")
    """

    def read_price_list_by_ak(
        self, price_list_ak: str
    ) -> ReadPriceListByAKResponse:
        """Read price list by AK.

        Args:
            price_list_ak: Price list AK identifier

        Returns:
            ReadPriceListByAKResponse: Response containing price list details

        Example:
            >>> response = service.read_price_list_by_ak("PRICE123")
            >>> if response.error.is_success:
            ...     print(f"Price list: {response.price_list.get('NAME')}")
        """
        payload = {"urn:ReadPriceListByAk": {"APriceListAk": price_list_ak}}
        response = self.send_request(payload)
        return ReadPriceListByAKResponse.from_dict(
            response["ReadPriceListByAkResponse"]["return"]
        )

    def read_price_list_by_id(
        self, price_list_id: int
    ) -> ReadPriceListByIdResponse:
        """Read price list by ID.

        Args:
            price_list_id: Price list ID

        Returns:
            ReadPriceListByIdResponse: Response containing price list details

        Example:
            >>> response = service.read_price_list_by_id(12345)
            >>> if response.error.is_success:
            ...     print(f"Price list: {response.price_list.get('NAME')}")
        """
        payload = {"urn:ReadPriceListById": {"APriceListId": price_list_id}}
        response = self.send_request(payload)
        return ReadPriceListByIdResponse.from_dict(
            response["ReadPriceListByIdResponse"]["return"]
        )
