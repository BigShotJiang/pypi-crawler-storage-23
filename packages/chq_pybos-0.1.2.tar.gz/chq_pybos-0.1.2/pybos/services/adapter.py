"""
Adapter service for the BOS API.

This service provides methods for adapter operations including account management,
sales processing, data retrieval, and payment processing.
"""

from ..base_service import BaseService
from ..types.adapter import (
    SimpleImportAccountRequest,
    GenerateSaleRequest,
    UpdateReservationInfoRequest,
    GetCounterNumberRequest,
    AccountAccreditationRequest,
    CompleteTransactionXmlRequest,
    GetDataByIdRequest,
    NewUpgradeShopcartRequest,
    InitPaymentsRequest,
    SaveCreditCardRequest,
    SetPaymentStatusRequest,
    OutputResponse,
    ErrorResponse,
    GetDataResponse,
    AccountAccreditationResponse,
    FindAccountIdResponse,
    FindAccountPriceListResponse,
)


class AdapterService(BaseService):
    """Service for BOS adapter operations with improved developer ergonomics.

    This service provides methods for account management, sales processing,
    data retrieval, and payment operations in the BOS system. All complex data
    structures use typed classes instead of tuples for better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            service_name: Name of the WSDL service (e.g., "IWsAPIAdapter")

    Example:
        >>> service = AdapterService(bos_api, "IWsAPIAdapter")
        >>> request = SimpleImportAccountRequest(import_account_xml="<account>...</account>")
        >>> result = service.simple_import_account(request)
        >>> if result.error.is_success:
        ...     print("Account imported successfully")
    """

    def simple_import_account(
        self, request: SimpleImportAccountRequest
    ) -> OutputResponse:
        """Import account data from XML.

        Args:
            request: Account import request

        Returns:
            OutputResponse with import results
        """
        payload = request.to_dict()
        response = self.send_request("SimpleImportAccount", payload)
        return OutputResponse.from_dict(response)

    def new_item_by_matrix_cell(
        self,
        matrix_cell_id: int,
        performance_id: int,
        envelope_capacity_id: int,
        seat_id: int,
    ) -> OutputResponse:
        """Create new item by matrix cell.

        Args:
            matrix_cell_id: Matrix cell ID
            performance_id: Performance ID
            envelope_capacity_id: Envelope capacity ID
            seat_id: Seat ID

        Returns:
            OutputResponse with creation results
        """
        payload = {
            "AMatrixCellId": matrix_cell_id,
            "APerformanceId": performance_id,
            "AEnvelopeCapacityId": envelope_capacity_id,
            "ASeatId": seat_id,
        }
        response = self.send_request("NewItemByMatrixCell", payload)
        return OutputResponse.from_dict(response)

    def user_login(
        self, workstation_ak: str, username: str, password: str
    ) -> OutputResponse:
        """Login user to the system.

        Args:
            workstation_ak: Workstation AK
            username: Username
            password: Password

        Returns:
            OutputResponse with login results
        """
        payload = {
            "AWorkstationAK": workstation_ak,
            "AUserName": username,
            "APassword": password,
        }
        response = self.send_request("UserLogin", payload)
        return OutputResponse.from_dict(response)

    def update_reservation_info(
        self, request: UpdateReservationInfoRequest
    ) -> OutputResponse:
        """Update reservation information.

        Args:
            request: Reservation update request

        Returns:
            OutputResponse with update results
        """
        payload = request.to_dict()
        response = self.send_request("UpdateReservationInfo", payload)
        return OutputResponse.from_dict(response)

    def generate_sale(self, request: GenerateSaleRequest) -> OutputResponse:
        """Generate a sale from shopcart.

        Args:
            request: Sale generation request

        Returns:
            OutputResponse with sale generation results
        """
        payload = request.to_dict()
        response = self.send_request("GenerateSale", payload)
        return OutputResponse.from_dict(response)

    def get_counter_number(self, request: GetCounterNumberRequest) -> GetDataResponse:
        """Get counter number for payment processing.

        Args:
            request: Counter number request

        Returns:
            GetDataResponse with counter number
        """
        payload = request.to_dict()
        response = self.send_request("GetCounterNumber", payload)
        return GetDataResponse.from_dict(response)

    def set_billing_account(
        self, sale_id: int, billing_account_id: int
    ) -> ErrorResponse:
        """Set billing account for a sale.

        Args:
            sale_id: Sale ID
            billing_account_id: Billing account ID

        Returns:
            ErrorResponse with operation results
        """
        payload = {
            "ASaleId": sale_id,
            "ABillingAccountId": billing_account_id,
        }
        response = self.send_request("SetBillingAccount", payload)
        return ErrorResponse.from_dict(response)

    def payment_done(self, sale_id: int) -> ErrorResponse:
        """Mark payment as done for a sale.

        Args:
            sale_id: Sale ID

        Returns:
            ErrorResponse with operation results
        """
        payload = {"ASaleId": sale_id}
        response = self.send_request("PaymentDone", payload)
        return ErrorResponse.from_dict(response)

    def complete_transaction(self, transaction_id: int) -> ErrorResponse:
        """Complete a transaction.

        Args:
            transaction_id: Transaction ID

        Returns:
            ErrorResponse with operation results
        """
        payload = {"ATransactionId": transaction_id}
        response = self.send_request("CompleteTransaction", payload)
        return ErrorResponse.from_dict(response)

    def complete_transaction_and_get_tickets_xml(
        self, request: CompleteTransactionXmlRequest
    ) -> OutputResponse:
        """Complete transaction and get tickets XML.

        Args:
            request: Transaction completion request

        Returns:
            OutputResponse with tickets XML
        """
        payload = request.to_dict()
        response = self.send_request("CompleteTransactionAndGetTicketsXML", payload)
        return OutputResponse.from_dict(response)

    def sale_get_data_by_id(self, request: GetDataByIdRequest) -> OutputResponse:
        """Get sale data by ID.

        Args:
            request: Data retrieval request

        Returns:
            OutputResponse with sale data
        """
        payload = request.to_dict()
        response = self.send_request("SaleGetDataById", payload)
        return OutputResponse.from_dict(response)

    def get_financial_constraints_xml(self, account_id: int) -> OutputResponse:
        """Get financial constraints XML for an account.

        Args:
            account_id: Account ID

        Returns:
            OutputResponse with financial constraints XML
        """
        payload = {"AAccountId": account_id}
        response = self.send_request("GetFinancialConstraintsXML", payload)
        return OutputResponse.from_dict(response)

    def account_accreditation(
        self, request: AccountAccreditationRequest
    ) -> AccountAccreditationResponse:
        """Process account accreditation.

        Args:
            request: Account accreditation request

        Returns:
            AccountAccreditationResponse with accreditation results
        """
        payload = request.to_dict()
        response = self.send_request("AccountAccreditation", payload)
        return AccountAccreditationResponse.from_dict(response)

    def change_password(self, account_id: int, new_password: str) -> ErrorResponse:
        """Change account password.

        Args:
            account_id: Account ID
            new_password: New password

        Returns:
            ErrorResponse with operation results
        """
        payload = {
            "AAccountId": account_id,
            "aNewPassword": new_password,
        }
        response = self.send_request("ChangePassword", payload)
        return ErrorResponse.from_dict(response)

    def find_account_id_by_obj_type(
        self, obj_type: int, value: str
    ) -> FindAccountIdResponse:
        """Find account ID by object type and value.

        Args:
            obj_type: Object type
            value: Value to search for

        Returns:
            FindAccountIdResponse with account ID
        """
        payload = {
            "AObjType": obj_type,
            "AValue": value,
        }
        response = self.send_request("FindAccountIdByObjType", payload)
        return FindAccountIdResponse.from_dict(response)

    def find_account_price_list_id(
        self, account_id: int
    ) -> FindAccountPriceListResponse:
        """Find account price list ID.

        Args:
            account_id: Account ID

        Returns:
            FindAccountPriceListResponse with price list ID
        """
        payload = {"AAccountId": account_id}
        response = self.send_request("FindAccountPriceListId", payload)
        return FindAccountPriceListResponse.from_dict(response)

    def get_billing_account_sales(
        self, billing_account_id: int, from_date: str, to_date: str
    ) -> OutputResponse:
        """Get billing account sales for date range.

        Args:
            billing_account_id: Billing account ID
            from_date: Start date
            to_date: End date

        Returns:
            OutputResponse with sales data
        """
        payload = {
            "ABillingAccountId": billing_account_id,
            "aFromDate": from_date,
            "aToDate": to_date,
        }
        response = self.send_request("GetBillingAccountSales", payload)
        return OutputResponse.from_dict(response)

    def new_upgrade_shopcart(
        self, request: NewUpgradeShopcartRequest
    ) -> OutputResponse:
        """Create new upgrade shopcart.

        Args:
            request: Upgrade shopcart request

        Returns:
            OutputResponse with shopcart creation results
        """
        payload = request.to_dict()
        response = self.send_request("NewUpgradeShopcart", payload)
        return OutputResponse.from_dict(response)

    def new_renewal_shopcart(
        self, request: NewUpgradeShopcartRequest
    ) -> OutputResponse:
        """Create new renewal shopcart.

        Args:
            request: Renewal shopcart request

        Returns:
            OutputResponse with shopcart creation results
        """
        payload = request.to_dict()
        response = self.send_request("NewRenewalShopcart", payload)
        return OutputResponse.from_dict(response)

    def check_out_items(self, request: GenerateSaleRequest) -> OutputResponse:
        """Check out items from shopcart.

        Args:
            request: Checkout request

        Returns:
            OutputResponse with checkout results
        """
        payload = request.to_dict()
        response = self.send_request("CheckOutItems", payload)
        return OutputResponse.from_dict(response)

    def try_schedule_performance(
        self, performance_id: int, template_id: int, quantity: int
    ) -> ErrorResponse:
        """Try to schedule a performance.

        Args:
            performance_id: Performance ID
            template_id: Template ID
            quantity: Quantity

        Returns:
            ErrorResponse with scheduling results
        """
        payload = {
            "APerformanceId": performance_id,
            "aTemplateId": template_id,
            "aQuantity": quantity,
        }
        response = self.send_request("TrySchedulePerformance", payload)
        return ErrorResponse.from_dict(response)

    def payment_get_data_by_id(self, request: GetDataByIdRequest) -> OutputResponse:
        """Get payment data by ID.

        Args:
            request: Data retrieval request

        Returns:
            OutputResponse with payment data
        """
        payload = request.to_dict()
        response = self.send_request("PaymentGetDataById", payload)
        return OutputResponse.from_dict(response)

    def init_payments(self, request: InitPaymentsRequest) -> OutputResponse:
        """Initialize payments for a transaction.

        Args:
            request: Payment initialization request

        Returns:
            OutputResponse with initialization results
        """
        payload = request.to_dict()
        response = self.send_request("InitPayments", payload)
        return OutputResponse.from_dict(response)

    def save_credit_card_ext_auth_details(
        self, request: SaveCreditCardRequest
    ) -> ErrorResponse:
        """Save credit card external authorization details.

        Args:
            request: Credit card save request

        Returns:
            ErrorResponse with operation results
        """
        payload = request.to_dict()
        response = self.send_request("SaveCreditCardExtAuthDetails", payload)
        return ErrorResponse.from_dict(response)

    def set_payment_status(self, request: SetPaymentStatusRequest) -> ErrorResponse:
        """Set payment status.

        Args:
            request: Payment status request

        Returns:
            ErrorResponse with operation results
        """
        payload = request.to_dict()
        response = self.send_request("SetPaymentStatus", payload)
        return ErrorResponse.from_dict(response)

    def hold(
        self,
        performance_id: int,
        envelope_capacity_id: int,
        item_guid: str,
        hold_quantity: int,
        adjacent: bool,
        is_first_to_hold: bool,
    ) -> ErrorResponse:
        """Hold items for a performance.

        Args:
            performance_id: Performance ID
            envelope_capacity_id: Envelope capacity ID
            item_guid: Item GUID
            hold_quantity: Quantity to hold
            adjacent: Whether to hold adjacent items
            is_first_to_hold: Whether this is the first hold

        Returns:
            ErrorResponse with hold results
        """
        payload = {
            "APerformanceId": performance_id,
            "AEnvelopeCapacityId": envelope_capacity_id,
            "AItemGuid": item_guid,
            "AHoldQuantity": hold_quantity,
            "Adjacent": adjacent,
            "IsFirstToHold": is_first_to_hold,
        }
        response = self.send_request("Hold", payload)
        return ErrorResponse.from_dict(response)
