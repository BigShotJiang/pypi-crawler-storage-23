from ..base_service import BaseService
from ..types.account import (
    # Request types
    SearchAccountRequest,
    SaveAccountRequest,
    ChangeAccountCategoryRequest,
    ManageAccountRelationshipRequest,
    AccountLoginRequest,
    AddAccountNoteRequest,
    ReadAccountSaleHierarchyRequest,
    FindAccountSaleByDateRequest,
    MergeAccountRequest,
    UnmergeAccountRequest,
    AddMediaToAccountRequest,
    ChangeAccountStatusRequest,
    ReadAccountTicketsByAkRequest,
    ResetAccountPasswordRequest,
    SearchTotalsByStatisticalGroupRequest,
    ManageAccountGiftAidRequest,
    SearchZipCodeOnExternalDBRequest,
    # Data types
    AccountFilter,
    AccountField,
    AccountImage,
    AccountAttachment,
    # Response types
    ReadAccountByAkResponse,
    ReadAccountByIdResponse,
    B2BAgencyLoginResponse,
    AccountLoginResponse,
    SearchAccountResponse,
    SaveAccountResponse,
    AccountCanPayResponse,
    AddAccountNoteResponse,
    ChangeAccountCategoryResponse,
    ReadAccountHierarchyResponse,
    ReadAccountSaleHierarchyResponse,
    ReadAccountHistoryByAkResponse,
    ManageAccountRelationshipResponse,
    PrintAccountPdfResponse,
    ChangeAccountPasswordResponse,
    FindAccountSaleByDateResponse,
    MergeAccountResponse,
    UnmergeAccountResponse,
    GetAccountCsvResponse,
    ReadSaleRestrictionResponse,
    AddMediaToAccountResponse,
    ChangeAccountStatusResponse,
    ReadAccountTicketsByAkResponse,
    ResetAccountPasswordResponse,
    SearchTotalsByStatisticalGroupResponse,
    ManageAccountGiftAidResponse,
    SearchZipCodeOnExternalDbResponse,
)
from typing import Optional, List


class AccountService(BaseService):
    """Service for managing BOS accounts with improved developer ergonomics.

    This service provides comprehensive methods for searching, creating, and managing accounts
    in the BOS system. All complex data structures use typed classes instead
    of tuples for better IDE support and type safety.

    The service supports the following operations:

    Queries:
        - AccountCanPay: Check if a Billing Account can pay for an order
        - FindAccountSaleByDate: Retrieve a list of sales linked to an Account starting from the AK
        - ReadAccountByAK: Retrieve information about an Account starting from the AK
        - ReadAccountByID: Retrieve information about an Account starting from the ID
        - ReadAccountHierarchy: Retrieve information about an Account Hierarchy
        - ReadAccountHistoryByAK: Retrieve tickets and orders linked to an Account starting from its AK
        - ReadAccountSaleHierarchy: Retrieve information about an Account and its sales starting from the AK
        - ReadAccountTicketsByAk: Retrieve information about an Account and its tickets starting from the AK
        - ReadSaleRestriction: Retrieve information about Sale Restrictions
        - SearchAccount: Search for an already existing Account
        - SearchTotalsByStatisticalGroup: Retrieve a count of tickets and their statuses with Account and Statistical Group filters
        - SearchZipCodeOnExternalDB: Search for a ZipCode on an external DB

    Operations:
        - AddAccountNote: Add a note to an Account
        - AddMediaToAccount: Add a media identifier to an Account
        - B2BAccountLogIn: Login an Account using its username and password
        - AccountLogIn: Login an Account using any object type
        - ChangeAccountCategory: Change the Account Category of an already existing Account
        - ChangeAccountPassword: Change the Account password
        - ChangeAccountStatus: Enable or disable an account starting from its AK
        - GetAccountCSV: Retrieve accounts and export them to CSV
        - ManageAccountGiftAid: Activate and manage GiftAid at Account level
        - ManageAccountRelationship: Set the relationship between a source Account and a target Account
        - MergeAccount: Merge a list of Accounts to a Main Account
        - PrintAccountPDF: Generate a PDF report from BOS starting from its AK
        - ResetAccountPassword: Reset an Account password
        - SaveAccount: Save and update an Account
        - UnmergeAccount: Unmerge an account from its Main Account

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            service_name: Name of the WSDL service (e.g., "IWsAPIAccount")

    Example:
        >>> service = AccountService(bos_api, "IWsAPIAccount")
        >>> filter_obj = AccountFilter(
        ...     object_type=1,
        ...     value="example@email.com",
        ...     search_type=SearchType.EQUAL
        ... )
        >>> result = service.search_account(filters=[filter_obj])
    """

    def search_account(
        self,
        filters: List[AccountFilter],
        account_ak: Optional[str] = None,
        parent_account_ak: Optional[str] = None,
        active_only: Optional[bool] = None,
        dmg_category_list: Optional[List[str]] = None,
        creation_date: Optional[dict] = None,
        page_req: Optional[dict] = None,
    ) -> SearchAccountResponse:
        """Search for accounts with type-safe structured parameters.

        Args:
            filters: List of AccountFilter objects (required)
            account_ak: Specific account AK to search for
            parent_account_ak: Parent account AK filter
            active_only: Whether to search only active accounts
            dmg_category_list: List of DMG category AKs to search within
            creation_date: Date filter for account creation
            page_req: Pagination parameters

        Returns:
            dict: Search results containing account list and metadata

        Example:
            >>> filter_obj = AccountFilter(1, "john@example.com", SearchType.EQUAL)
            >>> result = service.search_account(filters=[filter_obj], active_only=True)
        """
        request = SearchAccountRequest(
            filters=filters,
            account_ak=account_ak,
            parent_account_ak=parent_account_ak,
            active_only=active_only,
            dmg_category_list=dmg_category_list,
            creation_date=creation_date,
            page_req=page_req,
        )
        payload = {"urn:SearchAccount": {"SEARCHACCOUNTREQ": request.to_dict()}}

        response = self.send_request(payload)
        return SearchAccountResponse.from_dict(
            response["SearchAccountResponse"]["return"]
        )

    def save_account(
        self,
        dmg_category_ak: str,
        fields: List[AccountField],
        account_ak: Optional[str] = None,
        parent_account_ak: Optional[str] = None,
        status: Optional[int] = None,
        images: Optional[List[AccountImage]] = None,
        attachments: Optional[List[AccountAttachment]] = None,
        billing_account_ak: Optional[str] = None,
        del_billing_account: Optional[bool] = None,
        detail_list: Optional[List[dict]] = None,
    ) -> SaveAccountResponse:
        """Save an account to the system with type-safe structured parameters.

        Args:
            dmg_category_ak: DMG category AK for the account
            fields: List of AccountField objects (required)
            account_ak: Account AK for updates (optional for new accounts)
            parent_account_ak: Parent account AK
            status: Account status (1=enabled, 2=disabled)
            images: List of AccountImage objects
            attachments: List of AccountAttachment objects
            billing_account_ak: Billing account AK
            del_billing_account: Whether to delete billing account
            detail_list: Complex detail list structure

        Returns:
            dict: Save response containing account info and any errors

        Example:
            >>> field_obj = AccountField("John Doe", 1)
            >>> image_obj = AccountImage("photo.jpg", "base64content", 2)
            >>> result = service.save_account(
            ...     dmg_category_ak="cat123",
            ...     fields=[field_obj],
            ...     images=[image_obj],
            ...     status=1
            ... )
        """
        request = SaveAccountRequest(
            dmg_category_ak=dmg_category_ak,
            fields=fields,
            account_ak=account_ak,
            parent_account_ak=parent_account_ak,
            status=status,
            images=images,
            attachments=attachments,
            billing_account_ak=billing_account_ak,
            del_billing_account=del_billing_account,
            detail_list=detail_list,
        )
        payload = {"urn:SaveAccount": {"SAVEACCOUNTREQ": request.to_dict()}}

        response = self.send_request(payload)
        return SaveAccountResponse.from_dict(response["SaveAccountResponse"]["return"])

    def change_account_category(
        self, account_ak: str, dmg_category_ak: str
    ) -> ChangeAccountCategoryResponse:
        """Change the category of an account.

        Args:
            account_ak: Account AK to update
            dmg_category_ak: New DMG category AK

        Returns:
            dict: Response containing updated account info and any errors
        """
        request = ChangeAccountCategoryRequest(account_ak, dmg_category_ak)
        payload = {
            "urn:ChangeAccountCategory": {"CHANGEACCOUNTCATEGORYREQ": request.to_dict()}
        }

        response = self.send_request(payload)
        return ChangeAccountCategoryResponse.from_dict(
            response["ChangeAccountCategoryResponse"]["return"]
        )

    def manage_account_relationship(
        self, source_account_ak: str, target_account_ak: str, operation_type: int
    ) -> ManageAccountRelationshipResponse:
        """Manage the relationship between two accounts.

        Args:
            source_account_ak: Source account AK
            target_account_ak: Target account AK
            operation_type: Type of operation to perform

        Returns:
            dict: Response containing hierarchy info and any errors
        """
        request = ManageAccountRelationshipRequest(
            source_account_ak, target_account_ak, operation_type
        )
        payload = {"urn:ManageAccountRelationship": request.to_dict()}
        response = self.send_request(payload)
        return ManageAccountRelationshipResponse.from_dict(
            response["ManageAccountRelationshipResponse"]["return"]
        )

    def read_account_by_ak(self, account_ak: str) -> ReadAccountByAkResponse:
        """Read account details by account AK.

        Args:
            account_ak: Account AK to read

        Returns:
            dict: Account details and metadata
        """
        payload = {"urn:ReadAccountByAK": {"AAccountAK": account_ak}}
        response = self.send_request(payload)
        return ReadAccountByAkResponse.from_dict(
            response["ReadAccountByAKResponse"]["return"]
        )

    def read_account_by_id(self, account_id: int) -> ReadAccountByIdResponse:
        """Read account details by account ID.

        Args:
            account_id: Account ID to read

        Returns:
            dict: Account details and metadata
        """
        payload = {"urn:ReadAccountByID": {"AAccountID": account_id}}
        response = self.send_request(payload)
        return ReadAccountByIdResponse.from_dict(
            response["ReadAccountByIDResponse"]["return"]
        )

    def b2b_account_login(
        self, username: str, password: str, dmg_cat_code: str
    ) -> B2BAgencyLoginResponse:
        """B2B account login for agency accounts.

        Args:
            username: Username for login
            password: Password for login
            dmg_cat_code: DMG category code

        Returns:
            dict: Login response with account info and session data
        """
        payload = {
            "urn:B2BAccountLogIn": {
                "AUsername": username,
                "APsw": password,
                "ADmgCatCode": dmg_cat_code,
            }
        }
        response = self.send_request(payload)
        return B2BAgencyLoginResponse.from_dict(
            response["B2BAccountLogInResponse"]["return"]
        )

    def account_login(self, request: AccountLoginRequest) -> AccountLoginResponse:
        """Account login with structured request.

        Args:
            request: AccountLoginRequest object with login details

        Returns:
            dict: Login response with account info and session data
        """
        payload = {"urn:AccountLogIn": {"ACCOUNTLOGINREQ": request.to_dict()}}
        response = self.send_request(payload)
        return AccountLoginResponse.from_dict(
            response["AccountLogInResponse"]["return"]
        )

    def account_can_pay(
        self, account_ak: str, amount: float, items_count: int
    ) -> AccountCanPayResponse:
        """Check if account can pay for specified amount and items.

        Args:
            account_ak: Account AK to check
            amount: Amount to check payment capability for
            items_count: Number of items

        Returns:
            dict: Payment capability response
        """
        payload = {
            "urn:AccountCanPay": {
                "AAccountAK": account_ak,
                "AAmount": amount,
                "AItemsCount": items_count,
            }
        }
        response = self.send_request(payload)
        return AccountCanPayResponse.from_dict(
            response["AccountCanPayResponse"]["return"]
        )

    def add_account_note(
        self, request: AddAccountNoteRequest
    ) -> AddAccountNoteResponse:
        """Add a note to an account.

        Args:
            request: AddAccountNoteRequest object with note details

        Returns:
            AddAccountNoteResponse: Response containing note info and any errors
        """
        payload = {"urn:AddAccountNote": {"ADDACCOUNTNOTEREQ": request.to_dict()}}
        response = self.send_request(payload)
        return AddAccountNoteResponse.from_dict(
            response["AddAccountNoteResponse"]["return"]
        )

    def read_account_hierarchy(self, account_ak: str) -> ReadAccountHierarchyResponse:
        """Read account hierarchy information.

        Args:
            account_ak: Account AK to read hierarchy for

        Returns:
            ReadAccountHierarchyResponse: Account hierarchy information
        """
        payload = {"urn:ReadAccountHierarchy": {"AAccountAK": account_ak}}
        response = self.send_request(payload)
        return ReadAccountHierarchyResponse.from_dict(
            response["ReadAccountHierarchyResponse"]["return"]
        )

    def read_account_sale_hierarchy(
        self, request: ReadAccountSaleHierarchyRequest
    ) -> ReadAccountSaleHierarchyResponse:
        """Read account sale hierarchy information.

        Args:
            request: ReadAccountSaleHierarchyRequest object

        Returns:
            ReadAccountSaleHierarchyResponse: Account sale hierarchy information
        """
        payload = {
            "urn:ReadAccountSaleHierarchy": {
                "READACCOUNTSALEHIERARCHYREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ReadAccountSaleHierarchyResponse.from_dict(
            response["ReadAccountSaleHierarchyResponse"]["return"]
        )

    def read_account_history_by_ak(
        self, account_ak: str
    ) -> ReadAccountHistoryByAkResponse:
        """Read account history by account AK.

        Args:
            account_ak: Account AK to read history for

        Returns:
            ReadAccountHistoryByAkResponse: Account history information
        """
        payload = {"urn:ReadAccountHistoryByAK": {"AAccountAK": account_ak}}
        response = self.send_request(payload)
        return ReadAccountHistoryByAkResponse.from_dict(
            response["ReadAccountHistoryByAKResponse"]["return"]
        )

    def print_account_pdf(self, account_ak: str) -> PrintAccountPdfResponse:
        """Generate PDF for account.

        Args:
            account_ak: Account AK to generate PDF for

        Returns:
            PrintAccountPdfResponse: PDF generation response with file data
        """
        payload = {"urn:PrintAccountPDF": {"AAccountAK": account_ak}}
        response = self.send_request(payload)
        return PrintAccountPdfResponse.from_dict(
            response["PrintAccountPDFResponse"]["return"]
        )

    def change_account_password(
        self,
        account_ak: str,
        old_password: str,
        new_password: str,
        confirm_password: str,
    ) -> ChangeAccountPasswordResponse:
        """Change account password.

        Args:
            account_ak: Account AK to change password for
            old_password: Current password
            new_password: New password
            confirm_password: Confirmation of new password

        Returns:
            ChangeAccountPasswordResponse: Password change response
        """
        payload = {
            "urn:ChangeAccountPassword": {
                "AAccountAK": account_ak,
                "AOldPassword": old_password,
                "ANewPassword": new_password,
                "AConfirmPassword": confirm_password,
            }
        }
        response = self.send_request(payload)
        return ChangeAccountPasswordResponse.from_dict(
            response["ChangeAccountPasswordResponse"]["return"]
        )

    def find_account_sale_by_date(
        self, request: FindAccountSaleByDateRequest
    ) -> FindAccountSaleByDateResponse:
        """Find account sales by date range.

        Args:
            request: FindAccountSaleByDateRequest object with date criteria

        Returns:
            FindAccountSaleByDateResponse: Account sales information for the date range
        """
        payload = {
            "urn:FindAccountSaleByDate": {"FINDACCOUNTSALEBYDATEREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return FindAccountSaleByDateResponse.from_dict(
            response["FindAccountSaleByDateResponse"]["return"]
        )

    def merge_account(self, request: MergeAccountRequest) -> MergeAccountResponse:
        """Merge two accounts.

        Args:
            request: MergeAccountRequest object with merge details

        Returns:
            MergeAccountResponse: Merge operation response
        """
        payload = {"urn:MergeAccount": {"MERGEACCOUNTREQ": request.to_dict()}}
        response = self.send_request(payload)
        return MergeAccountResponse.from_dict(
            response["MergeAccountResponse"]["return"]
        )

    def unmerge_account(self, request: UnmergeAccountRequest) -> UnmergeAccountResponse:
        """Unmerge previously merged accounts.

        Args:
            request: UnmergeAccountRequest object with unmerge details

        Returns:
            UnmergeAccountResponse: Unmerge operation response
        """
        payload = {"urn:UnmergeAccount": {"UNMERGEACCOUNTREQ": request.to_dict()}}
        response = self.send_request(payload)
        return UnmergeAccountResponse.from_dict(
            response["UnmergeAccountResponse"]["return"]
        )

    def get_account_csv(self, dmg_category_ak: str) -> GetAccountCsvResponse:
        """Get account data as CSV.

        Args:
            dmg_category_ak: DMG category AK to export

        Returns:
            GetAccountCsvResponse: CSV data response
        """
        payload = {"urn:GetAccountCSV": {"ADmgCategoryAK": dmg_category_ak}}
        response = self.send_request(payload)
        return GetAccountCsvResponse.from_dict(
            response["GetAccountCSVResponse"]["return"]
        )

    def read_sale_restriction(self, account_ak: str) -> ReadSaleRestrictionResponse:
        """Read sale restrictions for an account.

        Args:
            account_ak: Account AK to read restrictions for

        Returns:
            ReadSaleRestrictionResponse: Sale restrictions information
        """
        payload = {"urn:ReadSaleRestriction": {"AAccountAK": account_ak}}
        response = self.send_request(payload)
        return ReadSaleRestrictionResponse.from_dict(
            response["ReadSaleRestrictionResponse"]["return"]
        )

    def add_media_to_account(
        self, request: AddMediaToAccountRequest
    ) -> AddMediaToAccountResponse:
        """Add media (images/files) to an account.

        Args:
            request: AddMediaToAccountRequest object with media details

        Returns:
            AddMediaToAccountResponse: Media addition response
        """
        payload = {"urn:AddMediaToAccount": {"ADDMEDIATOACCOUNTREQ": request.to_dict()}}
        response = self.send_request(payload)
        return AddMediaToAccountResponse.from_dict(
            response["AddMediaToAccountResponse"]["return"]
        )

    def change_account_status(
        self, request: ChangeAccountStatusRequest
    ) -> ChangeAccountStatusResponse:
        """Change account status.

        Args:
            request: ChangeAccountStatusRequest object with status details

        Returns:
            ChangeAccountStatusResponse: Status change response
        """
        payload = {
            "urn:ChangeAccountStatus": {"ChangeAccountStatusReq": request.to_dict()}
        }
        response = self.send_request(payload)
        return ChangeAccountStatusResponse.from_dict(
            response["ChangeAccountStatusResponse"]["return"]
        )

    def read_account_tickets_by_ak(
        self, request: ReadAccountTicketsByAkRequest
    ) -> ReadAccountTicketsByAkResponse:
        """Read account tickets by account AK.

        Args:
            request: ReadAccountTicketsByAkRequest object

        Returns:
            ReadAccountTicketsByAkResponse: Account tickets information
        """
        payload = {
            "urn:ReadAccountTicketsByAk": {
                "READACCOUNTTICKETSBYAKREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ReadAccountTicketsByAkResponse.from_dict(
            response["ReadAccountTicketsByAkResponse"]["return"]
        )

    def reset_account_password(
        self, request: ResetAccountPasswordRequest
    ) -> ResetAccountPasswordResponse:
        """Reset account password.

        Args:
            request: ResetAccountPasswordRequest object with reset details

        Returns:
            ResetAccountPasswordResponse: Password reset response
        """
        payload = {
            "urn:ResetAccountPassword": {"RESETACCOUNTPASSWORDREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return ResetAccountPasswordResponse.from_dict(
            response["ResetAccountPasswordResponse"]["return"]
        )

    def search_totals_by_statistical_group(
        self, request: SearchTotalsByStatisticalGroupRequest
    ) -> SearchTotalsByStatisticalGroupResponse:
        """Search totals by statistical group.

        Args:
            request: SearchTotalsByStatisticalGroupRequest object

        Returns:
            SearchTotalsByStatisticalGroupResponse: Statistical totals information
        """
        payload = {
            "urn:SearchTotalsByStatisticalGroup": {
                "SEARCHTOTALSBYSTATISTICALGROUPREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return SearchTotalsByStatisticalGroupResponse.from_dict(
            response["SearchTotalsByStatisticalGroupResponse"]["return"]
        )

    def manage_account_gift_aid(
        self, request: ManageAccountGiftAidRequest
    ) -> ManageAccountGiftAidResponse:
        """Manage account gift aid settings.

        Args:
            request: ManageAccountGiftAidRequest object with gift aid details

        Returns:
            ManageAccountGiftAidResponse: Gift aid management response
        """
        payload = {
            "urn:ManageAccountGiftAid": {"MANAGEACCOUNTGIFTAIDREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return ManageAccountGiftAidResponse.from_dict(
            response["ManageAccountGiftAidResponse"]["MANAGEACCOUNTGIFTAIDRESP"]
        )

    def search_zip_code_on_external_db(
        self, request: SearchZipCodeOnExternalDBRequest
    ) -> SearchZipCodeOnExternalDbResponse:
        """Search zip code on external database.

        Args:
            request: SearchZipCodeOnExternalDBRequest object

        Returns:
            SearchZipCodeOnExternalDbResponse: Zip code search results
        """
        payload = {
            "urn:SearchZipCodeOnExternalDB": {
                "SEARCHZIPCODEONEXTERNALDBREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return SearchZipCodeOnExternalDbResponse.from_dict(
            response["SearchZipCodeOnExternalDBResponse"]["return"]
        )
