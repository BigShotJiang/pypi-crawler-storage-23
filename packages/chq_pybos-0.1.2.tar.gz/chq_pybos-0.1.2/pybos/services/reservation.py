"""
Reservation service for the BOS API.

This service provides methods for reservation operations including search,
export, and email resending.
"""

from ..base_service import BaseService
from ..types.reservationenquiry import (
    SearchReservationRequest,
    SearchReservationResponse,
    ResendReservationEmailResponse,
    ExportReservationCSVRequest,
    ExportReservationCSVResponse,
    ExportReservationCSV_V2Request,
    ExportReservationRequest,
    ExportReservationResponse,
    SearchReservationTicketRequest,
    SearchReservationTicketResponse,
)


class ReservationService(BaseService):
    """Service for BOS reservation operations.

    This service provides methods for reservation management including search,
    export, and email resending in the BOS system. All complex data structures
    use typed classes instead of dictionaries for better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIReservation")

    Example:
        >>> service = ReservationService(bos_api, "IWsAPIReservation")
        >>> from ..types.common import PageRequest
        >>> request = SearchReservationRequest(
        ...     current_user_only=False,
        ...     current_op_area_only=False,
        ...     page_req=PageRequest(page_index=1, page_size=10)
        ... )
        >>> response = service.search_reservation(request)
        >>> if response.error.is_success:
        ...     print(f"Found {len(response.reservation_item_list)} reservations")
    """

    def search_reservation(
        self, request: SearchReservationRequest
    ) -> SearchReservationResponse:
        """Search for reservations.

        Args:
            request: SearchReservationRequest with search criteria

        Returns:
            SearchReservationResponse: Response containing list of reservations

        Example:
            >>> from ..types.common import PageRequest, BaseDateFilter
            >>> request = SearchReservationRequest(
            ...     current_user_only=False,
            ...     current_op_area_only=False,
            ...     sale_date=BaseDateFilter(from_date="2024-01-01", to_date="2024-12-31"),
            ...     page_req=PageRequest(page_index=1, page_size=10)
            ... )
            >>> response = service.search_reservation(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.reservation_item_list)} reservations")
        """
        payload = {
            "urn:SearchReservation": {"SEARCHRESERVATIONREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return SearchReservationResponse.from_dict(
            response["SearchReservationResponse"]["return"]
        )

    def resend_reservation_email(
        self, reservation_ak: str
    ) -> ResendReservationEmailResponse:
        """Resend reservation email.

        Args:
            reservation_ak: Reservation AK identifier

        Returns:
            ResendReservationEmailResponse: Response with operation result

        Example:
            >>> response = service.resend_reservation_email("RESERVATION123")
            >>> if response.error.is_success:
            ...     print("Email resent")
        """
        payload = {"urn:ResendReservationEmail": {"AReservationAK": reservation_ak}}
        response = self.send_request(payload)
        return ResendReservationEmailResponse.from_dict(
            response["ResendReservationEmailResponse"]["RESENDRESERVATIONEMAILRESP"]
        )

    def export_reservation_csv(
        self, request: ExportReservationCSVRequest
    ) -> ExportReservationCSVResponse:
        """Export reservations to CSV.

        Args:
            request: ExportReservationCSVRequest with export criteria

        Returns:
            ExportReservationCSVResponse: Response containing CSV data

        Example:
            >>> from ..types.common import BaseDateFilter
            >>> request = ExportReservationCSVRequest(
            ...     sale_date=BaseDateFilter(from_date="2024-01-01", to_date="2024-12-31")
            ... )
            >>> response = service.export_reservation_csv(request)
            >>> if response.error.is_success:
            ...     csv_data = response.data
        """
        payload = {
            "urn:ExportReservationCSV": {
                "EXPORTRESERVATIONCSVREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ExportReservationCSVResponse.from_dict(
            response["ExportReservationCSVResponse"]["return"]
        )

    def export_reservation_csv_v2(
        self, request: ExportReservationCSV_V2Request
    ) -> ExportReservationCSVResponse:
        """Export reservations to CSV (V2).

        Args:
            request: ExportReservationCSV_V2Request with export criteria

        Returns:
            ExportReservationCSVResponse: Response containing CSV data

        Example:
            >>> from ..types.common import BaseDateFilter
            >>> request = ExportReservationCSV_V2Request(
            ...     sale_date=BaseDateFilter(from_date="2024-01-01", to_date="2024-12-31")
            ... )
            >>> response = service.export_reservation_csv_v2(request)
            >>> if response.error.is_success:
            ...     csv_data = response.data
        """
        payload = {
            "urn:ExportReservationCSV_V2": {
                "EXPORTRESERVATIONCSV_V2REQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ExportReservationCSVResponse.from_dict(
            response["ExportReservationCSV_V2Response"]["return"]
        )

    def export_reservation(
        self, request: ExportReservationRequest
    ) -> ExportReservationResponse:
        """Export reservations.

        Args:
            request: ExportReservationRequest with export criteria

        Returns:
            ExportReservationResponse: Response containing export data

        Example:
            >>> from ..types.common import BaseDateFilter
            >>> request = ExportReservationRequest(
            ...     sale_date=BaseDateFilter(from_date="2024-01-01", to_date="2024-12-31"),
            ...     export_type={"XLSX": True}
            ... )
            >>> response = service.export_reservation(request)
            >>> if response.error.is_success:
            ...     export_data = response.data
        """
        payload = {
            "urn:ExportReservation": {"EXPORTRESERVATIONREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return ExportReservationResponse.from_dict(
            response["ExportReservationResponse"]["return"]
        )

    def search_reservation_ticket(
        self, request: SearchReservationTicketRequest
    ) -> SearchReservationTicketResponse:
        """Search reservation tickets.

        Args:
            request: SearchReservationTicketRequest with search criteria

        Returns:
            SearchReservationTicketResponse: Response containing reservations with tickets

        Example:
            >>> from ..types.common import PageRequest
            >>> request = SearchReservationTicketRequest(
            ...     page_req=PageRequest(page_index=1, page_size=10)
            ... )
            >>> response = service.search_reservation_ticket(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.reservation_item_list)} reservations")
        """
        payload = {
            "urn:SearchReservationTicket": {
                "SEARCHRESERVATIONTICKETREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return SearchReservationTicketResponse.from_dict(
            response["SearchReservationTicketResponse"]["return"]
        )
