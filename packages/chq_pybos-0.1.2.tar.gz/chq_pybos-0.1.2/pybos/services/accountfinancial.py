"""
Account financial service for the BOS API.

This service provides methods for managing account financial operations,
including credit management, payment processing, and financial configuration.
"""

from ..base_service import BaseService
from ..types.accountfinancial import (
    UpdateFinancialConfigRequest,
    UpdateFinancialConfigResponse,
    AdvancePaymentRequest,
    AdvancePaymentResponse,
    SearchCreditRequest,
    SearchCreditResponse,
    CreditSettlementRequest,
    CreditSettlementResponse,
    ChangeCreditDetailsRequest,
    ChangeCreditDetailsResponse,
    ActivateFinancialResponse,
)


class AccountFinancialService(BaseService):
    """Service for managing BOS account financial operations with improved developer ergonomics.

    This service provides methods for financial configuration, credit management,
    payment processing, and account activation in the BOS system. All complex data
    structures use typed classes instead of tuples for better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            service_name: Name of the WSDL service (e.g., "IWsAPIAccountFinancial")

    Example:
        >>> service = AccountFinancialService(bos_api, "IWsAPIAccountFinancial")
        >>> request = UpdateFinancialConfigRequest(
        ...     update_account_ak="ACC123",
        ...     update_credit_info={"CREDITPERTRANS": 1000.0}
        ... )
        >>> result = service.update_financial_config(request)
        >>> if result.error.is_success:
        ...     print("Financial configuration updated successfully")
    """

    def update_financial_config(
        self, request: UpdateFinancialConfigRequest
    ) -> UpdateFinancialConfigResponse:
        """Update financial configuration for an account.

        Args:
            request: Financial configuration update request

        Returns:
            UpdateFinancialConfigResponse with updated account information
        """
        payload = request.to_dict()
        response = self.send_request("UpdateFinancialConfig", payload)
        return UpdateFinancialConfigResponse.from_dict(response)

    def advance_payment(self, request: AdvancePaymentRequest) -> AdvancePaymentResponse:
        """Process an advance payment for an account.

        Args:
            request: Advance payment request

        Returns:
            AdvancePaymentResponse with order information
        """
        payload = request.to_dict()
        response = self.send_request("AdvancePayment", payload)
        return AdvancePaymentResponse.from_dict(response)

    def search_credit(self, request: SearchCreditRequest) -> SearchCreditResponse:
        """Search for credit records.

        Args:
            request: Credit search request

        Returns:
            SearchCreditResponse with list of credit items
        """
        payload = request.to_dict()
        response = self.send_request("SearchCredit", payload)
        return SearchCreditResponse.from_dict(response)

    def activate_financial(self, account_ak: str) -> ActivateFinancialResponse:
        """Activate financial functionality for an account.

        Args:
            account_ak: Account AK to activate

        Returns:
            ActivateFinancialResponse with account information
        """
        payload = {"AccountAK": account_ak}
        response = self.send_request("ActivateFinancial", payload)
        return ActivateFinancialResponse.from_dict(response)

    def credit_settlement(
        self, request: CreditSettlementRequest
    ) -> CreditSettlementResponse:
        """Settle credit records with payment.

        Args:
            request: Credit settlement request

        Returns:
            CreditSettlementResponse with sale information
        """
        payload = request.to_dict()
        response = self.send_request("CreditSettlement", payload)
        return CreditSettlementResponse.from_dict(response)

    def change_credit_details(
        self, request: ChangeCreditDetailsRequest
    ) -> ChangeCreditDetailsResponse:
        """Change details of credit records.

        Args:
            request: Credit details change request

        Returns:
            ChangeCreditDetailsResponse with updated credit list
        """
        payload = request.to_dict()
        response = self.send_request("ChangeCreditDetails", payload)
        return ChangeCreditDetailsResponse.from_dict(response)
