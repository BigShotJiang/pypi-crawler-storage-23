"""
Installment service for the BOS API.

This service provides methods for installment operations including reading,
updating, and managing installment plans.
"""

from ..base_service import BaseService
from ..types.installmentenquiry import (
    ReadInstallmentInfoByAccountAKResponse,
    UpdatePaymentInfoRequest,
    UpdatePaymentInfoResponse,
    ChangeContractStatusResponse,
    TryCancelAutoRenewResponse,
    CancelAutoRenewResponse,
    ReActivateAutoRenewResponse,
    PayInstallmentAmountRequest,
    PayInstallmentAmountResponse,
    ReadInstallmentInfoByAKResponse,
    ReadFlexContractTemplateResponse,
    UpdateRetryInstallmentRequest,
    UpdateRetryInstallmentResponse,
    ReadFlexContractOperationRightsResponse,
    CheckAccountEligibilityAsPayorResponse,
    CancelInstallmentPlanRequest,
    CancelInstallmentPlanResponse,
    VoidInstallmentPlanRequest,
    VoidInstallmentPlanResponse,
)


class InstallmentService(BaseService):
    """Service for BOS installment operations.

    This service provides methods for installment plan management including
    reading, updating, and managing installment contracts in the BOS system.
    All complex data structures use typed classes instead of dictionaries for
    better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIInstallment")

    Example:
        >>> service = InstallmentService(bos_api, "IWsAPIInstallment")
        >>> response = service.read_installment_info_by_account_ak("ACC123")
        >>> if response.error.is_success:
        ...     print(f"Found {len(response.installment_list)} installments")
    """

    def read_installment_info_by_account_ak(
        self, account_ak: str
    ) -> ReadInstallmentInfoByAccountAKResponse:
        """Read installment information by account AK.

        Args:
            account_ak: Account AK identifier

        Returns:
            ReadInstallmentInfoByAccountAKResponse: Response containing installment list

        Example:
            >>> response = service.read_installment_info_by_account_ak("ACC123")
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.installment_list)} installments")
        """
        payload = {"urn:ReadInstallmentInfoByAccountAK": {"AAccountAK": account_ak}}
        response = self.send_request(payload)
        return ReadInstallmentInfoByAccountAKResponse.from_dict(
            response["ReadInstallmentInfoByAccountAKResponse"]["return"]
        )

    def update_payment_info(
        self, request: UpdatePaymentInfoRequest
    ) -> UpdatePaymentInfoResponse:
        """Update payment information.

        Args:
            request: UpdatePaymentInfoRequest with payment info

        Returns:
            UpdatePaymentInfoResponse: Response with operation result

        Example:
            >>> request = UpdatePaymentInfoRequest(
            ...     payment_flex_ak="FLEX123",
            ...     payment_flex_info={"PAYMENTACCOUNTID": 123}
            ... )
            >>> response = service.update_payment_info(request)
            >>> if response.error.is_success:
            ...     print(f"Updated: {response.payment_flex_ak}")
        """
        payload = {
            "urn:UpdatePaymentInfo": {"UPDATEPAYMENTINFOREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return UpdatePaymentInfoResponse.from_dict(
            response["UpdatePaymentInfoResponse"]["return"]
        )

    def reactivate_contract(
        self, payment_flex_ak: str
    ) -> ChangeContractStatusResponse:
        """Reactivate contract.

        Args:
            payment_flex_ak: Payment flex AK identifier

        Returns:
            ChangeContractStatusResponse: Response with operation result

        Example:
            >>> response = service.reactivate_contract("FLEX123")
            >>> if response.error.is_success:
            ...     print(f"Reactivated: {response.payment_flex_ak}")
        """
        payload = {"urn:ReactivateContract": {"APaymentFlexAK": payment_flex_ak}}
        response = self.send_request(payload)
        return ChangeContractStatusResponse.from_dict(
            response["ReactivateContractResponse"]["return"]
        )

    def try_cancel_auto_renew(
        self, payment_flex_ak: str
    ) -> TryCancelAutoRenewResponse:
        """Try to cancel auto renew (preview fees).

        Args:
            payment_flex_ak: Payment flex AK identifier

        Returns:
            TryCancelAutoRenewResponse: Response with fee information

        Example:
            >>> response = service.try_cancel_auto_renew("FLEX123")
            >>> if response.error.is_success:
            ...     print(f"Fee amount: {response.fee_amount}")
        """
        payload = {"urn:TryCancelAutoRenew": {"APaymentFlexAK": payment_flex_ak}}
        response = self.send_request(payload)
        return TryCancelAutoRenewResponse.from_dict(
            response["TryCancelAutoRenewResponse"]["return"]
        )

    def cancel_auto_renew(
        self, payment_flex_ak: str
    ) -> CancelAutoRenewResponse:
        """Cancel auto renew.

        Args:
            payment_flex_ak: Payment flex AK identifier

        Returns:
            CancelAutoRenewResponse: Response with operation result

        Example:
            >>> response = service.cancel_auto_renew("FLEX123")
            >>> if response.error.is_success:
            ...     print(f"Cancelled: {response.payment_flex_ak}")
        """
        payload = {"urn:CancelAutoRenew": {"APaymentFlexAK": payment_flex_ak}}
        response = self.send_request(payload)
        return CancelAutoRenewResponse.from_dict(
            response["CancelAutoRenewResponse"]["return"]
        )

    def reactivate_auto_renew(
        self, payment_flex_ak: str
    ) -> ReActivateAutoRenewResponse:
        """Reactivate auto renew.

        Args:
            payment_flex_ak: Payment flex AK identifier

        Returns:
            ReActivateAutoRenewResponse: Response with operation result

        Example:
            >>> response = service.reactivate_auto_renew("FLEX123")
            >>> if response.error.is_success:
            ...     print("Auto renew reactivated")
        """
        payload = {"urn:ReActivateAutoRenew": {"APaymentFlexAK": payment_flex_ak}}
        response = self.send_request(payload)
        return ReActivateAutoRenewResponse.from_dict(
            response["ReActivateAutoRenewResponse"]["return"]
        )

    def pay_installment_amount(
        self, request: PayInstallmentAmountRequest
    ) -> PayInstallmentAmountResponse:
        """Pay installment amount.

        Args:
            request: PayInstallmentAmountRequest with amount

        Returns:
            PayInstallmentAmountResponse: Response with operation result

        Example:
            >>> request = PayInstallmentAmountRequest(
            ...     payment_flex_ak="FLEX123",
            ...     amount=100.0
            ... )
            >>> response = service.pay_installment_amount(request)
            >>> if response.error.is_success:
            ...     print(f"Paid for sale: {response.sale_ak}")
        """
        payload = {
            "urn:PayInstallmentAmount": {
                "PAYINSTALLMENTAMOUNTREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return PayInstallmentAmountResponse.from_dict(
            response["PayInstallmentAmountResponse"]["return"]
        )

    def read_installment_info_by_ak(
        self, payment_flex_ak: str
    ) -> ReadInstallmentInfoByAKResponse:
        """Read installment information by AK.

        Args:
            payment_flex_ak: Payment flex AK identifier

        Returns:
            ReadInstallmentInfoByAKResponse: Response containing installment details

        Example:
            >>> response = service.read_installment_info_by_ak("FLEX123")
            >>> if response.error.is_success:
            ...     print(f"Status: {response.installment.get('STATUSDESC')}")
        """
        payload = {"urn:ReadInstallmentInfoByAK": {"APaymentFlexAK": payment_flex_ak}}
        response = self.send_request(payload)
        return ReadInstallmentInfoByAKResponse.from_dict(
            response["ReadInstallmentInfoByAKResponse"]["return"]
        )

    def read_flex_contract_template_by_ak(
        self, flex_contract_ak: str
    ) -> ReadFlexContractTemplateResponse:
        """Read flex contract template by AK.

        Args:
            flex_contract_ak: Flex contract AK identifier

        Returns:
            ReadFlexContractTemplateResponse: Response containing template details

        Example:
            >>> response = service.read_flex_contract_template_by_ak("CONTRACT123")
            >>> if response.error.is_success:
            ...     print(f"Template: {response.flex_contract.get('NAME')}")
        """
        payload = {
            "urn:ReadFlexContractTemplateByAK": {"AFlexContractAK": flex_contract_ak}
        }
        response = self.send_request(payload)
        return ReadFlexContractTemplateResponse.from_dict(
            response["ReadFlexContractTemplateByAKResponse"]["return"]
        )

    def deactivate_contract(
        self, payment_flex_ak: str
    ) -> ChangeContractStatusResponse:
        """Deactivate contract.

        Args:
            payment_flex_ak: Payment flex AK identifier

        Returns:
            ChangeContractStatusResponse: Response with operation result

        Example:
            >>> response = service.deactivate_contract("FLEX123")
            >>> if response.error.is_success:
            ...     print(f"Deactivated: {response.payment_flex_ak}")
        """
        payload = {"urn:DeactivateContract": {"APaymentFlexAK": payment_flex_ak}}
        response = self.send_request(payload)
        return ChangeContractStatusResponse.from_dict(
            response["DeactivateContractResponse"]["return"]
        )

    def update_retry_installment(
        self, request: UpdateRetryInstallmentRequest
    ) -> UpdateRetryInstallmentResponse:
        """Update retry installment.

        Args:
            request: UpdateRetryInstallmentRequest with payment plan list

        Returns:
            UpdateRetryInstallmentResponse: Response with operation results

        Example:
            >>> request = UpdateRetryInstallmentRequest(
            ...     payment_plan_list=["PLAN123", "PLAN456"]
            ... )
            >>> response = service.update_retry_installment(request)
            >>> if response.error.is_success:
            ...     print(f"Updated {len(response.payment_plan_list)} plans")
        """
        payload = {
            "urn:UpdateRetryInstallment": {
                "UPDATERETRYINSTALLMENTREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return UpdateRetryInstallmentResponse.from_dict(
            response["UpdateRetryInstallmentResponse"]["return"]
        )

    def read_flex_contract_operation_rights(
        self,
    ) -> ReadFlexContractOperationRightsResponse:
        """Read flex contract operation rights.

        Returns:
            ReadFlexContractOperationRightsResponse: Response containing operation list

        Example:
            >>> response = service.read_flex_contract_operation_rights()
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.operation_list)} operations")
        """
        payload = {"urn:ReadFlexContractOperationRights": None}
        response = self.send_request(payload)
        return ReadFlexContractOperationRightsResponse.from_dict(
            response["ReadFlexContractOperationRightsResponse"]["return"]
        )

    def check_account_eligibility_as_payor(
        self, account_ak: str
    ) -> CheckAccountEligibilityAsPayorResponse:
        """Check account eligibility as payor.

        Args:
            account_ak: Account AK identifier

        Returns:
            CheckAccountEligibilityAsPayorResponse: Response with eligibility status

        Example:
            >>> response = service.check_account_eligibility_as_payor("ACC123")
            >>> if response.error.is_success:
            ...     print(f"Eligible: {response.eligible}")
        """
        payload = {
            "urn:CheckAccountEligibilityAsPayor": {"AAccountAK": account_ak}
        }
        response = self.send_request(payload)
        return CheckAccountEligibilityAsPayorResponse.from_dict(
            response["CheckAccountEligibilityAsPayorResponse"]["return"]
        )

    def cancel_installment(
        self, request: CancelInstallmentPlanRequest
    ) -> CancelInstallmentPlanResponse:
        """Cancel installment plan.

        Args:
            request: CancelInstallmentPlanRequest with payment flex AK

        Returns:
            CancelInstallmentPlanResponse: Response with operation result

        Example:
            >>> request = CancelInstallmentPlanRequest(payment_flex_ak="FLEX123")
            >>> response = service.cancel_installment(request)
            >>> if response.error.is_success:
            ...     print(f"Cancelled: {response.payment_flex_ak}")
        """
        payload = {
            "urn:CancelInstallment": {"CANCELINSTALLMENTPLANREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return CancelInstallmentPlanResponse.from_dict(
            response["CancelInstallmentResponse"]["return"]
        )

    def void_installment_plan(
        self, request: VoidInstallmentPlanRequest
    ) -> VoidInstallmentPlanResponse:
        """Void installment plan.

        Args:
            request: VoidInstallmentPlanRequest with payment flex AK

        Returns:
            VoidInstallmentPlanResponse: Response with operation result

        Example:
            >>> request = VoidInstallmentPlanRequest(
            ...     payment_flex_ak="FLEX123",
            ...     void_fee=False
            ... )
            >>> response = service.void_installment_plan(request)
            >>> if response.error.is_success:
            ...     print(f"Voided: {response.payment_flex_ak}")
        """
        payload = {
            "urn:VoidInstallmentPlan": {"VOIDINSTALLMENTPLANREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return VoidInstallmentPlanResponse.from_dict(
            response["VoidInstallmentPlanResponse"]["return"]
        )
