"""
Shop Cart Validation service for the BOS API.

This service provides methods for shopcart validation operations.
"""

from ..base_service import BaseService
from ..types.shopcartvalidation import (
    SearchShopcartValidationRequest,
    SearchShopcartValidationResponse,
)


class ShopCartValidationService(BaseService):
    """Service for BOS shopcart validation operations.

    This service provides methods for shopcart validation in the BOS system.
    All complex data structures use typed classes instead of dictionaries for
    better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIShopCartValidation")

    Example:
        >>> service = ShopCartValidationService(bos_api, "IWsAPIShopCartValidation")
        >>> request = SearchShopcartValidationRequest()
        >>> response = service.search_shopcart_validation(request)
        >>> if response.error.is_success:
        ...     print("Validations found")
    """

    def search_shopcart_validation(
        self, request: SearchShopcartValidationRequest
    ) -> SearchShopcartValidationResponse:
        """Search shopcart validations.

        Args:
            request: SearchShopcartValidationRequest with search criteria

        Returns:
            SearchShopcartValidationResponse: Response containing validations

        Example:
            >>> from ..types.common import PageRequest
            >>> request = SearchShopcartValidationRequest(
            ...     page_req=PageRequest(page_index=1, page_size=10)
            ... )
            >>> response = service.search_shopcart_validation(request)
            >>> if response.error.is_success:
            ...     print("Validations found")
        """
        payload = {
            "urn:SearchShopcartValidation": {
                "SEARCHSHOPCARTVALIDATIONREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return SearchShopcartValidationResponse.from_dict(
            response["SearchShopcartValidationResponse"]["return"]
        )
