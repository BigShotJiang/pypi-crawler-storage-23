"""
Product service for the BOS API.

This service provides methods for product operations including product search,
import, update, activation, and warehouse management.
"""

from ..base_service import BaseService
from ..types.productenquiry import (
    FindAllProductsResponse,
    ReadProductByAKResponse,
    ReadProductByIDResponse,
    FindAllStatisticalGroupResponse,
    FindB2BAccountProductResponse,
    ReadProductDimensionByAKResponse,
    ImportProductRequest,
    ImportProductResponse,
    UpdateProductRequest,
    UpdateProductResponse,
    ActivateProductByAKResponse,
    DeactivateProductByAKResponse,
    FindAllProductByStatGroupRequest,
    FindAllProductByStatGroupResponse,
    ReadStatisticalGroupByCodeResponse,
    FindAccountProductRequest,
    FindAccountProductResponse,
    SearchProductRequest,
    SearchProductResponse,
    SearchPriceByDateProductRequest,
    SearchPriceByDateProductResponse,
    GetAttributeByComponentCodeRequest,
    GetAttributeByComponentCodeResponse,
    ProductTransferRequest,
    ProductTransferResponse,
    ProductTransferApprovalRequest,
    ProductTransferApprovalResponse,
    SearchWarehouseMovementRequest,
    SearchWarehouseMovementResponse,
    ProductInventoryUpdateRequest,
    ProductInventoryUpdateResponse,
)
from ..types.common import BaseDateFilter, PageRequest


class ProductService(BaseService):
    """Service for BOS product operations with improved developer ergonomics.

    This service provides methods for product management, search, import, update,
    and warehouse operations in the BOS system. All complex data structures use
    typed classes instead of dictionaries for better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIProduct")

    Example:
        >>> service = ProductService(bos_api, "IWsAPIProduct")
        >>> response = service.find_all_products()
        >>> if response.error.is_success:
        ...     for product in response.product_list:
        ...         print(f"{product.name}: {product.code}")
    """

    def find_all_products(self) -> FindAllProductsResponse:
        """Find all products associated to the logged in workstation.

        Returns:
            FindAllProductsResponse: Response containing list of products

        Example:
            >>> response = service.find_all_products()
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.product_list)} products")
        """
        payload = {"urn:FindAllProducts": None}
        response = self.send_request(payload)
        return FindAllProductsResponse.from_dict(
            response["FindAllProductsResponse"]["return"]
        )

    def read_product_by_ak(self, product_ak: str) -> ReadProductByAKResponse:
        """Read product details by product AK.

        Args:
            product_ak: Product AK identifier

        Returns:
            ReadProductByAKResponse: Response containing product details

        Example:
            >>> response = service.read_product_by_ak("PROD123")
            >>> if response.error.is_success:
            ...     print(f"Product: {response.product.name}")
        """
        payload = {"urn:ReadProductByAK": {"AProductAK": product_ak}}
        response = self.send_request(payload)
        return ReadProductByAKResponse.from_dict(
            response["ReadProductByAKResponse"]["return"]
        )

    def read_product_by_id(self, product_id: int) -> ReadProductByIDResponse:
        """Read product details by product ID.

        Args:
            product_id: Product ID

        Returns:
            ReadProductByIDResponse: Response containing product details

        Example:
            >>> response = service.read_product_by_id(12345)
            >>> if response.error.is_success:
            ...     print(f"Product: {response.product.name}")
        """
        payload = {"urn:ReadProductByID": {"AProductId": product_id}}
        response = self.send_request(payload)
        return ReadProductByIDResponse.from_dict(
            response["ReadProductByIDResponse"]["return"]
        )

    def find_all_statistical_group(self) -> FindAllStatisticalGroupResponse:
        """Find all statistical groups.

        Returns:
            FindAllStatisticalGroupResponse: Response containing list of statistical groups

        Example:
            >>> response = service.find_all_statistical_group()
            >>> if response.error.is_success:
            ...     for group in response.statistical_group_list:
            ...         print(f"Group: {group.get('CODE')}")
        """
        payload = {"urn:FindAllStatisticalGroup": None}
        response = self.send_request(payload)
        return FindAllStatisticalGroupResponse.from_dict(
            response["FindAllStatisticalGroupResponse"]["return"]
        )

    def find_b2b_account_product(
        self, account_ak: str
    ) -> FindB2BAccountProductResponse:
        """Find B2B account products.

        Args:
            account_ak: Account AK identifier

        Returns:
            FindB2BAccountProductResponse: Response containing list of products

        Example:
            >>> response = service.find_b2b_account_product("ACC123")
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.product_list)} products")
        """
        payload = {"urn:FindB2BAccountProduct": {"AAccountAK": account_ak}}
        response = self.send_request(payload)
        return FindB2BAccountProductResponse.from_dict(
            response["FindB2BAccountProductResponse"]["return"]
        )

    def read_product_dimension_by_ak(
        self, product_ak: str
    ) -> ReadProductDimensionByAKResponse:
        """Read product dimension by product AK.

        Args:
            product_ak: Product AK identifier

        Returns:
            ReadProductDimensionByAKResponse: Response containing product dimensions

        Example:
            >>> response = service.read_product_dimension_by_ak("PROD123")
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.dimension_list)} dimensions")
        """
        payload = {"urn:ReadProductDimensionByAK": {"AProductAK": product_ak}}
        response = self.send_request(payload)
        return ReadProductDimensionByAKResponse.from_dict(
            response["ReadProductDimensionByAkResponse"]["return"]
        )

    def import_product(self, request: ImportProductRequest) -> ImportProductResponse:
        """Import a new product.

        Args:
            request: ImportProductRequest with product data

        Returns:
            ImportProductResponse: Response containing created product AK

        Example:
            >>> request = ImportProductRequest(
            ...     product_name="New Product",
            ...     description="Product description",
            ...     matrix_sheet_ak="SHEET123",
            ...     product_code="PROD001",
            ...     price_list_ak="PRICE123",
            ...     sku="SKU001",
            ...     barcode_list=["123456789"],
            ...     um_ak="UM001",
            ...     price_type=1,
            ...     sell_price=10.0,
            ...     printed_price=10.0,
            ...     stock_product_category_ak="CAT123",
            ...     status=True,
            ...     tax_type=1,
            ...     tax_package_ak="TAX123"
            ... )
            >>> response = service.import_product(request)
            >>> if response.error.is_success:
            ...     print(f"Product created: {response.product_ak}")
        """
        payload = {"urn:ImportProduct": request.to_dict()}
        response = self.send_request(payload)
        return ImportProductResponse.from_dict(
            response["ImportProductResponse"]["return"]
        )

    def update_product(self, request: UpdateProductRequest) -> UpdateProductResponse:
        """Update an existing product.

        Args:
            request: UpdateProductRequest with update data

        Returns:
            UpdateProductResponse: Response containing updated product AK

        Example:
            >>> request = UpdateProductRequest(
            ...     matrix_cell_ak="CELL123",
            ...     update_product_name=True,
            ...     update_description=False,
            ...     update_additional_description=False,
            ...     update_product_code=False,
            ...     update_price=True,
            ...     update_status=False,
            ...     update_taxes=False,
            ...     update_receipt_info=False,
            ...     update_not_refundable=False,
            ...     update_supervisor_approval=False,
            ...     update_marketing_survey=False,
            ...     update_additional_info_mask=False,
            ...     update_product={"PRODUCTNAME": "Updated Name", "SELLPRICE": 15.0}
            ... )
            >>> response = service.update_product(request)
            >>> if response.error.is_success:
            ...     print(f"Product updated: {response.product_ak}")
        """
        payload = {"urn:UpdateProduct": request.to_dict()}
        response = self.send_request(payload)
        return UpdateProductResponse.from_dict(
            response["UpdateProductResponse"]["return"]
        )

    def deactivate_product_by_ak(
        self, matrix_cell_ak: str
    ) -> DeactivateProductByAKResponse:
        """Deactivate a product by matrix cell AK.

        Args:
            matrix_cell_ak: Matrix cell AK identifier

        Returns:
            DeactivateProductByAKResponse: Response with operation result

        Example:
            >>> response = service.deactivate_product_by_ak("CELL123")
            >>> if response.error.is_success:
            ...     print("Product deactivated")
        """
        payload = {"urn:DeactivateProductByAK": {"AMatrixCellAK": matrix_cell_ak}}
        response = self.send_request(payload)
        return DeactivateProductByAKResponse.from_dict(
            response["DeactivateProductByAKResponse"]["return"]
        )

    def activate_product_by_ak(
        self, matrix_cell_ak: str
    ) -> ActivateProductByAKResponse:
        """Activate a product by matrix cell AK.

        Args:
            matrix_cell_ak: Matrix cell AK identifier

        Returns:
            ActivateProductByAKResponse: Response with operation result

        Example:
            >>> response = service.activate_product_by_ak("CELL123")
            >>> if response.error.is_success:
            ...     print("Product activated")
        """
        payload = {"urn:ActivateProductByAK": {"AMatrixCellAK": matrix_cell_ak}}
        response = self.send_request(payload)
        return ActivateProductByAKResponse.from_dict(
            response["ActivateProductByAKResponse"]["return"]
        )

    def find_all_product_by_stat_group(
        self, request: FindAllProductByStatGroupRequest
    ) -> FindAllProductByStatGroupResponse:
        """Find all products by statistical group.

        Args:
            request: FindAllProductByStatGroupRequest with statistical group list

        Returns:
            FindAllProductByStatGroupResponse: Response containing list of products

        Example:
            >>> request = FindAllProductByStatGroupRequest(
            ...     stat_group_list=[{"CODE": "GROUP1"}]
            ... )
            >>> response = service.find_all_product_by_stat_group(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.product_list)} products")
        """
        payload = {"urn:FindAllProductByStatGroup": request.to_dict()}
        response = self.send_request(payload)
        return FindAllProductByStatGroupResponse.from_dict(
            response["FindAllProductByStatGroupResponse"]["return"]
        )

    def read_statistical_group_by_code(
        self, statistical_group_code: str
    ) -> ReadStatisticalGroupByCodeResponse:
        """Read statistical group by code.

        Args:
            statistical_group_code: Statistical group code

        Returns:
            ReadStatisticalGroupByCodeResponse: Response containing statistical group

        Example:
            >>> response = service.read_statistical_group_by_code("GROUP1")
            >>> if response.error.is_success:
            ...     print(f"Group: {response.statistical_group.get('CODE')}")
        """
        payload = {
            "urn:ReadStatisticalGroupByCode": {
                "AStatisticalGroupCode": statistical_group_code
            }
        }
        response = self.send_request(payload)
        return ReadStatisticalGroupByCodeResponse.from_dict(
            response["ReadStatisticalGroupByCodeResponse"]["return"]
        )

    def find_account_product(
        self, request: FindAccountProductRequest
    ) -> FindAccountProductResponse:
        """Find account products.

        Args:
            request: FindAccountProductRequest with account AK

        Returns:
            FindAccountProductResponse: Response containing list of account products

        Example:
            >>> request = FindAccountProductRequest(account_ak="ACC123")
            >>> response = service.find_account_product(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.account_product_list)} products")
        """
        payload = {"urn:FindAccountProduct": request.to_dict()}
        response = self.send_request(payload)
        return FindAccountProductResponse.from_dict(
            response["FindAccountProductResponse"]["return"]
        )

    def search_product(self, request: SearchProductRequest) -> SearchProductResponse:
        """Search for products with various filters.

        Args:
            request: SearchProductRequest with search criteria

        Returns:
            SearchProductResponse: Response containing list of products

        Example:
            >>> request = SearchProductRequest(
            ...     product_type=1,
            ...     page_req=PageRequest(page_index=1, page_size=10)
            ... )
            >>> response = service.search_product(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.product_list)} products")
        """
        payload = {"urn:SearchProduct": {"SEARCHPRODUCTREQ": request.to_dict()}}
        response = self.send_request(payload)
        return SearchProductResponse.from_dict(
            response["SearchProductResponse"]["return"]
        )

    def search_price_by_date_product(
        self, request: SearchPriceByDateProductRequest
    ) -> SearchPriceByDateProductResponse:
        """Search product prices by date range.

        Args:
            request: SearchPriceByDateProductRequest with date range and filters

        Returns:
            SearchPriceByDateProductResponse: Response containing products with prices by date

        Example:
            >>> from ..types.common import BaseDateFilter
            >>> request = SearchPriceByDateProductRequest(
            ...     date=BaseDateFilter(from_date="2024-01-01", to_date="2024-12-31"),
            ...     matrix_cell_ak_list=["CELL123"]
            ... )
            >>> response = service.search_price_by_date_product(request)
            >>> if response.error.is_success:
            ...     for product in response.product_list:
            ...         print(f"Product: {product.get('AK')}")
        """
        payload = {
            "urn:SearchPriceByDateProduct": {
                "SEARCHPRICEBYDATEPRODUCTREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return SearchPriceByDateProductResponse.from_dict(
            response["SearchPriceByDateProductResponse"]["return"]
        )

    def get_price_by_day_price(
        self, matrix_cell_ak: str, from_date: str, to_date: str
    ) -> float:
        """Get price by day for a product (legacy method for backward compatibility).

        Args:
            matrix_cell_ak: Matrix cell AK identifier
            from_date: Start date (YYYY-MM-DD format)
            to_date: End date (YYYY-MM-DD format)

        Returns:
            float: Total price for the date range

        Example:
            >>> price = service.get_price_by_day_price("CELL123", "2024-01-01", "2024-12-31")
            >>> print(f"Total price: {price}")
        """
        request = SearchPriceByDateProductRequest(
            date=BaseDateFilter(from_date=from_date, to_date=to_date),
            matrix_cell_ak_list=[matrix_cell_ak],
        )
        response = self.search_price_by_date_product(request)
        if response.error.is_success and response.product_list:
            product = response.product_list[0]
            return product.get("TOTALPRICE", 0.0)
        return 0.0

    def get_attribute_by_component_code(
        self, request: GetAttributeByComponentCodeRequest
    ) -> GetAttributeByComponentCodeResponse:
        """Get attribute by component code.

        Args:
            request: GetAttributeByComponentCodeRequest with component code

        Returns:
            GetAttributeByComponentCodeResponse: Response containing dimension list

        Example:
            >>> request = GetAttributeByComponentCodeRequest(component_code="COMP001")
            >>> response = service.get_attribute_by_component_code(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.dimension_list)} dimensions")
        """
        payload = {
            "urn:GetAttributeByComponentCode": {
                "GETATTRIBUTEBYCOMPONENTCODEREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return GetAttributeByComponentCodeResponse.from_dict(
            response["GetAttributeByComponentCodeResponse"]["return"]
        )

    def product_warehouse_change(
        self, request: ProductTransferRequest
    ) -> ProductTransferResponse:
        """Transfer product between warehouses.

        Args:
            request: ProductTransferRequest with transfer details

        Returns:
            ProductTransferResponse: Response containing transfer result

        Example:
            >>> request = ProductTransferRequest(
            ...     product_filter={"PRODUCTAK": "PROD123"},
            ...     request_id="REQ001",
            ...     approval_status=0,
            ...     warehouse_id_source=1,
            ...     warehouse_id_destination=2,
            ...     quantity=10,
            ...     um_ak="UM001",
            ...     value=100.0
            ... )
            >>> response = service.product_warehouse_change(request)
            >>> if response.error.is_success:
            ...     print(f"Transfer created: {response.request_id}")
        """
        payload = {
            "urn:ProductWarehouseChange": {
                "PRODUCTTRANSFERREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ProductTransferResponse.from_dict(
            response["ProductTransferResponse"]["return"]
        )

    def product_warehouse_change_approval(
        self, request: ProductTransferApprovalRequest
    ) -> ProductTransferApprovalResponse:
        """Approve or reject a product warehouse transfer.

        Args:
            request: ProductTransferApprovalRequest with approval details

        Returns:
            ProductTransferApprovalResponse: Response containing approval result

        Example:
            >>> request = ProductTransferApprovalRequest(
            ...     request_id="REQ001",
            ...     approval_status=1  # 1 = Approved, 2 = Rejected
            ... )
            >>> response = service.product_warehouse_change_approval(request)
            >>> if response.error.is_success:
            ...     print(f"Transfer {response.approval_status}")
        """
        payload = {
            "urn:ProductWarehouseChangeApproval": {
                "PRODUCTTRANSFERAPPROVALREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ProductTransferApprovalResponse.from_dict(
            response["ProductTransferApprovalResponse"]["return"]
        )

    def search_warehouse_movement(
        self, request: SearchWarehouseMovementRequest
    ) -> SearchWarehouseMovementResponse:
        """Search warehouse movements.

        Args:
            request: SearchWarehouseMovementRequest with search criteria

        Returns:
            SearchWarehouseMovementResponse: Response containing list of movements

        Example:
            >>> from ..types.common import BaseDateFilter, PageRequest
            >>> request = SearchWarehouseMovementRequest(
            ...     page_req=PageRequest(page_index=1, page_size=10),
            ...     movement_date=BaseDateFilter(from_date="2024-01-01", to_date="2024-12-31")
            ... )
            >>> response = service.search_warehouse_movement(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.movement_list)} movements")
        """
        payload = {
            "urn:SearchWarehouseMovement": {
                "SEARCHWAREHOUSEMOVEMENTREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return SearchWarehouseMovementResponse.from_dict(
            response["SearchWarehouseMovementResponse"]["return"]
        )

    def product_inventory_update(
        self, request: ProductInventoryUpdateRequest
    ) -> ProductInventoryUpdateResponse:
        """Update product inventory.

        Args:
            request: ProductInventoryUpdateRequest with update details

        Returns:
            ProductInventoryUpdateResponse: Response containing update result

        Example:
            >>> request = ProductInventoryUpdateRequest(
            ...     product_filter={"PRODUCTAK": "PROD123"},
            ...     movement_type=1,  # 1 = Incoming, 2 = OutGoing, 10 = AdjustQuantity
            ...     warehouse_id=1,
            ...     quantity=10,
            ...     um_ak="UM001",
            ...     value=100.0
            ... )
            >>> response = service.product_inventory_update(request)
            >>> if response.error.is_success:
            ...     print(f"Inventory updated for: {response.product_ak}")
        """
        payload = {
            "urn:ProductInventoryUpdate": {
                "PRODUCTINVENTORYUPDATEREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ProductInventoryUpdateResponse.from_dict(
            response["ProductInventoryUpdateResponse"]["return"]
        )
