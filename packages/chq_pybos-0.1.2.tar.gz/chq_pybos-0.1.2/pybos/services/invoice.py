"""
Invoice service for the BOS API.

This service provides methods for invoice operations.
"""

from ..base_service import BaseService
from ..types.invoice import GetShift4InvoiceNoResponse


class InvoiceService(BaseService):
    """Service for BOS invoice operations.

    This service provides methods for invoice management in the BOS system.
    All complex data structures use typed classes instead of dictionaries for
    better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIInvoice")

    Example:
        >>> service = InvoiceService(bos_api, "IWsAPIInvoice")
        >>> response = service.get_shift4_invoice_no()
        >>> if response.error.is_success:
        ...     print(f"Invoice number: {response.invoice}")
    """

    def get_shift4_invoice_no(self) -> GetShift4InvoiceNoResponse:
        """Get Shift4 invoice number.

        Returns:
            GetShift4InvoiceNoResponse: Response containing invoice number

        Example:
            >>> response = service.get_shift4_invoice_no()
            >>> if response.error.is_success:
            ...     print(f"Invoice number: {response.invoice}")
        """
        payload = {"urn:GetShift4InvoiceNo": None}
        response = self.send_request(payload)
        return GetShift4InvoiceNoResponse.from_dict(
            response["GetShift4InvoiceNoResponse"]["return"]
        )
