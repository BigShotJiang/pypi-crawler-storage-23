"""
Event service for the BOS API.

This service provides methods for event operations including event search,
creation, update, and retrieval.
"""

from ..base_service import BaseService
from ..types.eventenquiry import (
    FindAllEventsResponse,
    ReadEventByCodeResponse,
    ReadEventByAKResponse,
    FindAllEventCategoryResponse,
    FindEventsByAccountAKResponse,
    SearchEventRequest,
    SearchEventResponse,
    CreateEventRequest,
    CreateEventResponse,
    UpdateEventRequest,
    UpdateEventResponse,
    Category,
)


class EventService(BaseService):
    """Service for BOS event operations with improved developer ergonomics.

    This service provides methods for event management, search, creation, and
    update in the BOS system. All complex data structures use typed classes
    instead of dictionaries for better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIEvent")

    Example:
        >>> service = EventService(bos_api, "IWsAPIEvent")
        >>> response = service.find_all_events()
        >>> if response.error.is_success:
        ...     for event in response.event_list:
        ...         print(f"{event.name}: {event.code}")
    """

    def find_all_events(self) -> FindAllEventsResponse:
        """Find all events associated to the logged in workstation.

        Returns:
            FindAllEventsResponse: Response containing list of events

        Example:
            >>> response = service.find_all_events()
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.event_list)} events")
        """
        payload = {"urn:FindAllEvents": None}
        response = self.send_request(payload)
        return FindAllEventsResponse.from_dict(
            response["FindAllEventsResponse"]["return"]
        )

    def read_event_by_code(self, event_code: str) -> ReadEventByCodeResponse:
        """Read event details by event code.

        Args:
            event_code: Event code identifier

        Returns:
            ReadEventByCodeResponse: Response containing event details

        Example:
            >>> response = service.read_event_by_code("EVT001")
            >>> if response.error.is_success:
            ...     print(f"Event: {response.event.name}")
        """
        payload = {"urn:ReadEventByCode": {"AEventCode": event_code}}
        response = self.send_request(payload)
        return ReadEventByCodeResponse.from_dict(
            response["ReadEventByCodeResponse"]["return"]
        )

    def read_event_by_ak(self, event_ak: str) -> ReadEventByAKResponse:
        """Read event details by event AK.

        Args:
            event_ak: Event AK identifier

        Returns:
            ReadEventByAKResponse: Response containing event details

        Example:
            >>> response = service.read_event_by_ak("EVT123")
            >>> if response.error.is_success:
            ...     print(f"Event: {response.event.name}")
        """
        payload = {"urn:ReadEventByAK": {"AEventAK": event_ak}}
        response = self.send_request(payload)
        return ReadEventByAKResponse.from_dict(
            response["ReadEventByAKResponse"]["return"]
        )

    def find_all_event_category(self) -> FindAllEventCategoryResponse:
        """Find all event categories.

        Returns:
            FindAllEventCategoryResponse: Response containing list of categories

        Example:
            >>> response = service.find_all_event_category()
            >>> if response.error.is_success:
            ...     for category in response.category_list:
            ...         print(f"Category: {category.get('CODE')}")
        """
        payload = {"urn:FindAllEventCategory": None}
        response = self.send_request(payload)
        return FindAllEventCategoryResponse.from_dict(
            response["FindAllEventCategoryResponse"]["return"]
        )

    def find_events_by_account_ak(
        self, account_ak: str
    ) -> FindEventsByAccountAKResponse:
        """Find events by account AK.

        Args:
            account_ak: Account AK identifier

        Returns:
            FindEventsByAccountAKResponse: Response containing list of events

        Example:
            >>> response = service.find_events_by_account_ak("ACC123")
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.event_list)} events")
        """
        payload = {"urn:FindEventsByAccountAK": {"AAccountAK": account_ak}}
        response = self.send_request(payload)
        return FindEventsByAccountAKResponse.from_dict(
            response["FindEventsByAccountAKResponse"]["return"]
        )

    def search_event(self, request: SearchEventRequest) -> SearchEventResponse:
        """Search for events with various filters.

        Args:
            request: SearchEventRequest with search criteria

        Returns:
            SearchEventResponse: Response containing list of events

        Example:
            >>> from ..types.common import BaseDateFilter
            >>> request = SearchEventRequest(
            ...     date=BaseDateFilter(from_date="2024-01-01", to_date="2024-12-31"),
            ...     page_req=PageRequest(page_index=1, page_size=10)
            ... )
            >>> response = service.search_event(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.event_list)} events")
        """
        payload = {"urn:SearchEvent": {"SEARCHEVENTREQ": request.to_dict()}}
        response = self.send_request(payload)
        return SearchEventResponse.from_dict(
            response["SearchEventResponse"]["return"]
        )

    def create_event(self, request: CreateEventRequest) -> CreateEventResponse:
        """Create a new event.

        Args:
            request: CreateEventRequest with event data

        Returns:
            CreateEventResponse: Response containing created event AK

        Example:
            >>> from ..types.eventenquiry import Category
            >>> request = CreateEventRequest(
            ...     code="EVT001",
            ...     title="New Event",
            ...     store_ak="STORE123",
            ...     start_date="2024-01-01",
            ...     end_date="2024-12-31",
            ...     event_category_list=[Category(code="CAT1")]
            ... )
            >>> response = service.create_event(request)
            >>> if response.error.is_success:
            ...     print(f"Event created: {response.event_ak}")
        """
        payload = {"urn:CreateEvent": {"CREATEEVENTREQ": request.to_dict()}}
        response = self.send_request(payload)
        return CreateEventResponse.from_dict(
            response["CreateEventResponse"]["return"]
        )

    def update_event(self, request: UpdateEventRequest) -> UpdateEventResponse:
        """Update an existing event.

        Args:
            request: UpdateEventRequest with update data

        Returns:
            UpdateEventResponse: Response containing updated event AK

        Example:
            >>> request = UpdateEventRequest(
            ...     event_ak="EVT123",
            ...     title="Updated Event Title",
            ...     description="Updated description"
            ... )
            >>> response = service.update_event(request)
            >>> if response.error.is_success:
            ...     print(f"Event updated: {response.event_ak}")
        """
        payload = {"urn:UpdateEvent": {"UPDATEEVENTREQ": request.to_dict()}}
        response = self.send_request(payload)
        return UpdateEventResponse.from_dict(
            response["UpdateEventResponse"]["return"]
        )

    def set_event_status(self, event_ak: str, status: int) -> UpdateEventResponse:
        """Update an event status (legacy method for backward compatibility).

        Args:
            event_ak: Event AK identifier
            status: Event status (0: Closed, 1: OnSale, 2: Suspended, 3: Informative, 4: Waiting)

        Returns:
            UpdateEventResponse: Response containing updated event AK

        Example:
            >>> response = service.set_event_status("EVT123", 1)
            >>> if response.error.is_success:
            ...     print(f"Event status updated: {response.event_ak}")
        """
        request = UpdateEventRequest(event_ak=event_ak, status=status)
        return self.update_event(request)
