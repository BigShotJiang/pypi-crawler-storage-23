from ..base_service import BaseService
from ..types.admission import (
    # Request types
    ScanMediaCodeRequest,
    ScanAccountAkRequest,
    ScanMultipleMediaCodeRequest,
    # Response types
    ScanMediaCodeResponse,
    ScanMediaCodeFullResponse,
    ScanAccountAkResponse,
    ScanMultipleMediaCodeResponse,
)


class AdmissionService(BaseService):
    """Service for managing admissions and media code scanning operations.

    This service provides comprehensive methods for scanning media codes,
    validating admissions, and managing access control in the BOS system.
    All complex data structures use typed classes instead of tuples
    for better IDE support and type safety.

    The service supports the following operations:

    Media Code Scanning:
        - ScanMediaCode: Scan a ticket for admission
        - TryScanMediaCode: Try scanning a ticket for admission
        - ScanMediaCodeFull: Scan a ticket for admission and retrieve additional info
          about ticket, ticket holder and reservation owner
        - ScanMultipleMediaCode: Scan multiple tickets for admission
        - TryScanMultipleMediaCode: Try scanning multiple tickets for admission

    Account Scanning:
        - ScanAccountAK: Scan a ticket for admission using the AccountAK
        - TryScanAccountAK: Try scanning a ticket for admission using the AccountAK

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            service_name: Name of the WSDL service (e.g., "IWsAPIAdmission")

    Example:
        >>> service = AdmissionService(bos_api, "IWsAPIAdmission")
        >>> request = ScanMediaCodeRequest(
        ...     media_code="ABC123",
        ...     access_point_ak="ACCESS001"
        ... )
        >>> result = service.scan_media_code(request)
        >>> if result.scan_result.is_success():
        ...     print(f"Admission successful: {result.scan_result.get_result_description()}")
        ... else:
        ...     print(f"Admission failed: {result.scan_result.get_result_description()}")
    """

    def scan_media_code(self, request: ScanMediaCodeRequest) -> ScanMediaCodeResponse:
        """Scan a media code for admission.

        Args:
            request: ScanMediaCodeRequest object with media code details

        Returns:
            ScanMediaCodeResponse: Response containing scan results and validation info
        """
        payload = {"urn:ScanMediaCode": {"SCANMEDIACODEREQ": request.to_dict()}}
        response = self.send_request(payload)
        return ScanMediaCodeResponse.from_dict(
            response["ScanMediaCodeResponse"]["return"]
        )

    def try_scan_media_code(
        self, request: ScanMediaCodeRequest
    ) -> ScanMediaCodeResponse:
        """Try to scan a media code without committing the scan.

        Args:
            request: ScanMediaCodeRequest object with media code details

        Returns:
            ScanMediaCodeResponse: Response containing scan results and validation info
        """
        payload = {"urn:TryScanMediaCode": {"TRYSCANMEDIACODEREQ": request.to_dict()}}
        response = self.send_request(payload)
        return ScanMediaCodeResponse.from_dict(
            response["TryScanMediaCodeResponse"]["return"]
        )

    def scan_account_ak(self, request: ScanAccountAkRequest) -> ScanAccountAkResponse:
        """Scan an account AK for admission.

        Args:
            request: ScanAccountAkRequest object with account AK details

        Returns:
            ScanAccountAkResponse: Response containing scan results and validation info
        """
        payload = {"urn:ScanAccountAK": {"SCANACCOUNTAKREQ": request.to_dict()}}
        response = self.send_request(payload)
        return ScanAccountAkResponse.from_dict(
            response["ScanAccountAKResponse"]["return"]
        )

    def try_scan_account_ak(
        self, request: ScanAccountAkRequest
    ) -> ScanAccountAkResponse:
        """Try to scan an account AK without committing the scan.

        Args:
            request: ScanAccountAkRequest object with account AK details

        Returns:
            ScanAccountAkResponse: Response containing scan results and validation info
        """
        payload = {"urn:TryScanAccountAK": {"TRYSCANACCOUNTAKREQ": request.to_dict()}}
        response = self.send_request(payload)
        return ScanAccountAkResponse.from_dict(
            response["TryScanAccountAKResponse"]["return"]
        )

    def scan_media_code_full(
        self, request: ScanMediaCodeRequest
    ) -> ScanMediaCodeFullResponse:
        """Scan a media code with full information including customer details.

        Args:
            request: ScanMediaCodeRequest object with media code details

        Returns:
            ScanMediaCodeFullResponse: Response containing full scan results and customer info
        """
        payload = {"urn:ScanMediaCodeFull": {"SCANMEDIACODEFULLREQ": request.to_dict()}}
        response = self.send_request(payload)
        return ScanMediaCodeFullResponse.from_dict(
            response["ScanMediaCodeFullResponse"]["return"]
        )

    def scan_multiple_media_code(
        self, request: ScanMultipleMediaCodeRequest
    ) -> ScanMultipleMediaCodeResponse:
        """Scan multiple media codes at once.

        Args:
            request: ScanMultipleMediaCodeRequest object with multiple media codes

        Returns:
            ScanMultipleMediaCodeResponse: Response containing scan results for all media codes
        """
        payload = {
            "urn:ScanMultipleMediaCode": {"SCANMULTIPLEMEDIACODEREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return ScanMultipleMediaCodeResponse.from_dict(
            response["ScanMultipleMediaCodeResponse"]["return"]
        )

    def try_scan_multiple_media_code(
        self, request: ScanMultipleMediaCodeRequest
    ) -> ScanMultipleMediaCodeResponse:
        """Try to scan multiple media codes without committing the scans.

        Args:
            request: ScanMultipleMediaCodeRequest object with multiple media codes

        Returns:
            ScanMultipleMediaCodeResponse: Response containing scan results for all media codes
        """
        payload = {
            "urn:TryScanMultipleMediaCode": {
                "TRYSCANMULTIPLEMEDIACODEREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ScanMultipleMediaCodeResponse.from_dict(
            response["TryScanMultipleMediaCodeResponse"]["return"]
        )
