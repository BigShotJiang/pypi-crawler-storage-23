from ..base_service import BaseService
from ..types.orderenquiry import (
    ReadOrderByAKResponse,
    ReadOrderByAK_V2Response,
    FindSaleByExternalMediaResponse,
    CheckOutRequest,
    CheckOutResponse,
    CheckOut2Request,
    CheckOutMixedRequest,
    CheckBasketRequest,
    CheckBasketResponse,
    CheckBasketMixedRequest,
    CloseOrderRequest,
    CloseOrderResponse,
    CloseBulkOrderRequest,
    CloseBulkOrderResponse,
    CloseMultipleOrderRequest,
    CloseMultipleOrderResponse,
    CloseMultipleOrder2Request,
    RenewRequest,
    RenewResponse,
    TryRenewRequest,
    TryRenewResponse,
    UpgradeRequest,
    UpgradeResponse,
    TryUpgradeRequest,
    TryUpgradeResponse,
    MoneyCardRechargeRequest,
    MoneyCardRechargeResponse,
    MoneyCardCashOutRequest,
    MoneyCardCashOutResponse,
    DeleteReservationRequest,
    DeleteReservationResponse,
    DepositOnReservationRequest,
    DepositOnReservationResponse,
    AddSaleNoteRequest,
    AddSaleNoteResponse,
    AddPackageRequest,
    AddPackageResponse,
    AddExternalPackageRequest,
    ValidatePackageRequest,
    ValidatePackageResponse,
    ValidateExternalPackageRequest,
    ActivateTicketPackageRequest,
    ActivateTicketPackageResponse,
    PreSaleRequest,
    ApproveAccountTicketRequest,
    ApproveAccountTicketResponse,
    VoidTicketRequest,
    VoidTicketResponse,
    CheckSuggestiveSellRequest,
    CheckSuggestiveSellResponse,
    CheckSuggestiveSellAndAvailabilityRequest,
    CheckSuggestiveSellAndAvailabilityResponse,
    ReadTransactionBySaleRequest,
    ReadTransactionBySaleResponse,
    TransferPerformanceRequest,
    TransferPerformanceResponse,
    TryTransferPerformanceRequest,
    TryTransferPerformanceResponse,
    GenerateReferralCodeRequest,
    GenerateReferralCodeResponse,
    ChangeRedeemProductQuantityRequest,
    ChangeRedeemProductQuantityResponse,
    ChangePerformanceCheckOutRequest,
    ChangePerformanceCheckOutResponse,
    UpdateExternalReservationCodeRequest,
    UpdateExternalReservationCodeResponse,
    DeleteReservationCreditResponse,
    TryDeleteReservationCreditResponse,
    AbortSaleResponse,
)


class OrderService(BaseService):
    """Calls related to the Order Service"""

    def check_out(self, external_code: str, account_ak: str, item_list: list[tuple]):
        items = [
            {
                "ITEM": [
                    {
                        "AK": i[0],
                        "QTY": i[1],
                        "TICKETHOLDERLIST": [{"TICKETHOLDER": {"AK": i[2]}}],
                        "ACTIVEFROM": i[3],
                        "ACTIVETO": i[4],
                        "SELLPRICE": {"VALUE": i[5]},
                    }
                    for i in item_list
                ]
            }
        ]

        # Unset Sellprice if it is None
        for item in items[0]["ITEM"]:
            if item["SELLPRICE"]["VALUE"] is None:
                del item["SELLPRICE"]

        payload = {
            "urn:CheckOut": {
                "CHECKOUTREQ": {
                    "SHOPCART": {
                        "ITEMLIST": items,
                        "FLAG": {
                            "APPROVED": "true",
                            "PAID": "false",
                            "ENCODED": "false",
                            "VALIDATED": "false",
                            "COMPLETED": "false",
                        },
                        "RESERVATION": {
                            "EXTERNALCODE": external_code,
                            "RESERVATIONOWNER": {
                                "AK": account_ak,
                            },
                        },
                    },
                }
            }
        }

        response = self.send_request(payload)
        return response["CheckOutResponse"]["return"]

    def checkout_update(self, sale_ak: str):
        payload = {
            "urn:CheckOut": {
                "CHECKOUTREQ": {
                    "SALEAK": sale_ak,
                    "SHOPCART": {"FLAG": {"APPROVED": "true"}},
                }
            }
        }
        response = self.send_request(payload)
        return response["CheckOutResponse"]["return"]

    def close_order(self, order_ak: str):
        payload = {"urn:CloseOrder": {"CLOSEORDERREQ": {"AK": order_ak}}}
        response = self.send_request(payload)
        return response["CloseOrderResponse"]["return"]

    def read_order_by_ak(self, order_ak: str) -> ReadOrderByAKResponse:
        """Read order by AK."""
        payload = {
            "urn:ReadOrderByAK": {
                "AOrderAK": order_ak
            }
        }
        response = self.send_request(payload)
        return ReadOrderByAKResponse.from_dict(response["ReadOrderByAKResponse"]["return"])

    def read_order_by_ak_v2(self, order_ak: str) -> ReadOrderByAK_V2Response:
        """Read order by AK (V2)."""
        payload = {
            "urn:ReadOrderByAK_V2": {
                "AOrderAK": order_ak
            }
        }
        response = self.send_request(payload)
        return ReadOrderByAK_V2Response.from_dict(response["ReadOrderByAK_V2Response"]["return"])

    def find_sale_by_external_media(self, external_media_code: str) -> FindSaleByExternalMediaResponse:
        """Find sale by external media code."""
        payload = {
            "urn:FindSaleByExternalMedia": {
                "AExtMediaCode": external_media_code
            }
        }
        response = self.send_request(payload)
        return FindSaleByExternalMediaResponse.from_dict(response["FindSaleByExternalMediaResponse"]["return"])

    def check_out2(self, request: CheckOut2Request) -> CheckOutResponse:
        """Check out (V2)."""
        payload = {
            "urn:CheckOut2": {
                "CHECKOUT2REQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return CheckOutResponse.from_dict(response["CheckOut2Response"]["return"])

    def check_out_mixed(self, request: CheckOutMixedRequest) -> CheckOutResponse:
        """Check out mixed (with renew/upgrade)."""
        payload = {
            "urn:CheckOutMixed": {
                "CHECKOUTMIXEDREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return CheckOutResponse.from_dict(response["CheckOutMixedResponse"]["return"])

    def check_basket(self, request: CheckBasketRequest) -> CheckBasketResponse:
        """Check basket."""
        payload = {
            "urn:CheckBasket": {
                "CHECKBASKETREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return CheckBasketResponse.from_dict(response["CheckBasketResponse"]["return"])

    def check_basket_mixed(self, request: CheckBasketMixedRequest) -> CheckBasketResponse:
        """Check basket mixed (with renew/upgrade)."""
        payload = {
            "urn:CheckBasketMixed": {
                "CHECKBASKETMIXEDREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return CheckBasketResponse.from_dict(response["CheckBasketMixedResponse"]["return"])

    def close_bulk_order(self, request: CloseBulkOrderRequest) -> CloseBulkOrderResponse:
        """Close bulk order."""
        payload = {
            "urn:CloseBulkOrder": {
                "CLOSEBULKORDERREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return CloseBulkOrderResponse.from_dict(response["CloseBulkOrderResponse"]["return"])

    def close_multiple_order(self, request: CloseMultipleOrderRequest) -> CloseMultipleOrderResponse:
        """Close multiple orders."""
        payload = {
            "urn:CloseMultipleOrder": {
                "CLOSEMULTIPLEORDERREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return CloseMultipleOrderResponse.from_dict(response["CloseMultipleOrderResponse"]["return"])

    def close_multiple_order2(self, request: CloseMultipleOrder2Request) -> CloseMultipleOrderResponse:
        """Close multiple orders (V2)."""
        payload = {
            "urn:CloseMultipleOrder2": {
                "CLOSEMULTIPLEORDER2REQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return CloseMultipleOrderResponse.from_dict(response["CloseMultipleOrder2Response"]["return"])

    def renew(self, request: RenewRequest) -> RenewResponse:
        """Renew tickets."""
        payload = {
            "urn:Renew": {
                "RenewReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return RenewResponse.from_dict(response["RenewResponse"]["return"])

    def try_renew(self, request: TryRenewRequest) -> TryRenewResponse:
        """Try renew tickets."""
        payload = {
            "urn:TryRenew": {
                "TryRenewReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return TryRenewResponse.from_dict(response["TryRenewResponse"]["return"])

    def upgrade(self, request: UpgradeRequest) -> UpgradeResponse:
        """Upgrade tickets."""
        payload = {
            "urn:Upgrade": {
                "UpgradeReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return UpgradeResponse.from_dict(response["UpgradeResponse"]["return"])

    def try_upgrade(self, request: TryUpgradeRequest) -> TryUpgradeResponse:
        """Try upgrade tickets."""
        payload = {
            "urn:TryUpgrade": {
                "TryUpgradeReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return TryUpgradeResponse.from_dict(response["TryUpgradeResponse"]["return"])

    def money_card_recharge(self, request: MoneyCardRechargeRequest) -> MoneyCardRechargeResponse:
        """Recharge money card."""
        payload = {
            "urn:MoneyCardRecharge": {
                "MoneyCardRechargeReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return MoneyCardRechargeResponse.from_dict(response["MoneyCardRechargeResponse"]["return"])

    def money_card_cash_out(self, request: MoneyCardCashOutRequest) -> MoneyCardCashOutResponse:
        """Cash out money card."""
        payload = {
            "urn:MoneyCardCashOut": {
                "MoneyCardCashoutReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return MoneyCardCashOutResponse.from_dict(response["MoneyCardCashOutResponse"]["return"])

    def delete_reservation_credit(self, reservation_ak: str) -> DeleteReservationCreditResponse:
        """Delete reservation credit."""
        payload = {
            "urn:DeleteReservationCredit": {
                "AReservationAk": reservation_ak
            }
        }
        response = self.send_request(payload)
        return DeleteReservationCreditResponse.from_dict(response["DeleteReservationCreditResponse"]["return"])

    def try_delete_reservation_credit(self, reservation_ak: str) -> TryDeleteReservationCreditResponse:
        """Try delete reservation credit."""
        payload = {
            "urn:TryDeleteReservationCredit": {
                "AReservationAk": reservation_ak
            }
        }
        response = self.send_request(payload)
        return TryDeleteReservationCreditResponse.from_dict(response["TryDeleteReservationCreditResponse"]["return"])

    def delete_reservation(self, request: DeleteReservationRequest) -> DeleteReservationResponse:
        """Delete reservation."""
        payload = {
            "urn:DeleteReservation": {
                "DeleteReservationReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return DeleteReservationResponse.from_dict(response["DeleteReservationResponse"]["return"])

    def try_delete_reservation(self, request: DeleteReservationRequest) -> DeleteReservationResponse:
        """Try delete reservation."""
        payload = {
            "urn:TryDeleteReservation": {
                "DeleteReservationReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return DeleteReservationResponse.from_dict(response["TryDeleteReservationResponse"]["return"])

    def deposit_on_reservation(self, request: DepositOnReservationRequest) -> DepositOnReservationResponse:
        """Deposit on reservation."""
        payload = {
            "urn:DepositOnReservation": {
                "DepositOnReservationReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return DepositOnReservationResponse.from_dict(response["DepositOnReservationResponse"]["return"])

    def add_order_note(self, request: AddSaleNoteRequest) -> AddSaleNoteResponse:
        """Add order note."""
        payload = {
            "urn:AddOrderNote": {
                "AddSaleNoteReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return AddSaleNoteResponse.from_dict(response["AddOrderNoteResponse"]["return"])

    def add_package(self, request: AddPackageRequest) -> AddPackageResponse:
        """Add package."""
        payload = {
            "urn:AddPackage": {
                "APackageSerial": request.package_serial
            }
        }
        response = self.send_request(payload)
        return AddPackageResponse.from_dict(response["AddPackageResponse"]["return"])

    def add_external_package(self, request: AddExternalPackageRequest) -> AddPackageResponse:
        """Add external package."""
        payload = {
            "urn:AddExternalPackage": {
                "APackageSerial": request.package_serial,
                "APromotionCode": request.promotion_code
            }
        }
        response = self.send_request(payload)
        return AddPackageResponse.from_dict(response["AddExternalPackageResponse"]["return"])

    def validate_package(self, request: ValidatePackageRequest) -> ValidatePackageResponse:
        """Validate package."""
        payload = {
            "urn:ValidatePackage": {
                "APackageSerial": request.package_serial
            }
        }
        response = self.send_request(payload)
        return ValidatePackageResponse.from_dict(response["ValidatePackageResponse"]["return"])

    def validate_external_package(self, request: ValidateExternalPackageRequest) -> ValidatePackageResponse:
        """Validate external package."""
        payload = {
            "urn:ValidateExternalPackage": {
                "APackageSerial": request.package_serial,
                "APromotionCode": request.promotion_code
            }
        }
        response = self.send_request(payload)
        return ValidatePackageResponse.from_dict(response["ValidateExternalPackageResponse"]["return"])

    def abort_sale(self, order_ak: str) -> AbortSaleResponse:
        """Abort sale."""
        payload = {
            "urn:AbortSale": {
                "AOrderAK": order_ak
            }
        }
        response = self.send_request(payload)
        return AbortSaleResponse.from_dict(response["AbortSaleResponse"]["return"])

    def activate_ticket_package(self, request: ActivateTicketPackageRequest) -> ActivateTicketPackageResponse:
        """Activate ticket package."""
        payload = {
            "urn:ActivateTicketPackage": {
                "ActivateTicketPackageReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ActivateTicketPackageResponse.from_dict(response["ActivateTicketPackageResponse"]["return"])

    def pre_sale(self, request: PreSaleRequest) -> CheckBasketResponse:
        """Pre sale."""
        payload = {
            "urn:PreSale": {
                "PreSaleReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return CheckBasketResponse.from_dict(response["PreSaleResponse"]["return"])

    def approve_account_ticket(self, request: ApproveAccountTicketRequest) -> ApproveAccountTicketResponse:
        """Approve account ticket."""
        payload = {
            "urn:ApproveAccountTicket": {
                "AAccountAK": request.account_ak,
                "APaymentCode": request.payment_code,
                "ALanguageAK": request.language_ak
            }
        }
        response = self.send_request(payload)
        return ApproveAccountTicketResponse.from_dict(response["ApproveAccountTicketResponse"]["return"])

    def void_ticket(self, request: VoidTicketRequest) -> VoidTicketResponse:
        """Void ticket."""
        payload = {
            "urn:VoidTicket": {
                "VoidTicketReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return VoidTicketResponse.from_dict(response["VoidTicketResponse"]["return"])

    def check_suggestive_sell(self, request: CheckSuggestiveSellRequest) -> CheckSuggestiveSellResponse:
        """Check suggestive sell."""
        payload = {
            "urn:CheckSuggestiveSell": {
                "CheckSuggestiveSellReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return CheckSuggestiveSellResponse.from_dict(response["CheckSuggestiveSellResponse"]["return"])

    def check_suggestive_sell_and_availability(self, request: CheckSuggestiveSellAndAvailabilityRequest) -> CheckSuggestiveSellAndAvailabilityResponse:
        """Check suggestive sell and availability."""
        payload = {
            "urn:CheckSuggestiveSellAndAvailability": {
                "CheckSuggestiveSellAndAvailabilityReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return CheckSuggestiveSellAndAvailabilityResponse.from_dict(response["CheckSuggestiveSellAndAvailabilityResponse"]["return"])

    def read_transaction_by_sale(self, request: ReadTransactionBySaleRequest) -> ReadTransactionBySaleResponse:
        """Read transaction by sale."""
        payload = {
            "urn:ReadTransactionBySale": {
                "ASaleAK": request.sale_ak
            }
        }
        response = self.send_request(payload)
        return ReadTransactionBySaleResponse.from_dict(response["ReadTransactionBySaleResponse"]["return"])

    def transfer_performance(self, request: TransferPerformanceRequest) -> TransferPerformanceResponse:
        """Transfer performance."""
        payload = {
            "urn:TransferPerformance": {
                "TransferPerformanceReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return TransferPerformanceResponse.from_dict(response["TransferPerformanceResponse"]["return"])

    def try_transfer_performance(self, request: TryTransferPerformanceRequest) -> TryTransferPerformanceResponse:
        """Try transfer performance."""
        payload = {
            "urn:TryTransferPerformance": {
                "TryTransferPerformanceReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return TryTransferPerformanceResponse.from_dict(response["TryTransferPerformanceResponse"]["return"])

    def generate_referral_code(self, request: GenerateReferralCodeRequest) -> GenerateReferralCodeResponse:
        """Generate referral code."""
        payload = {
            "urn:GenerateReferralCode": {
                "AMediaCode": request.media_code
            }
        }
        response = self.send_request(payload)
        return GenerateReferralCodeResponse.from_dict(response["GenerateReferralCodeResponse"]["return"])

    def change_redeem_product_quantity(self, request: ChangeRedeemProductQuantityRequest) -> ChangeRedeemProductQuantityResponse:
        """Change redeem product quantity."""
        payload = {
            "urn:ChangeRedeemProductQuantity": {
                "CHANGEREDEEMABLEQUANTITYREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ChangeRedeemProductQuantityResponse.from_dict(response["ChangeRedeemProductQuantityResponse"]["return"])

    def change_performance_check_out(self, request: ChangePerformanceCheckOutRequest) -> ChangePerformanceCheckOutResponse:
        """Change performance check out."""
        payload = {
            "urn:ChangePerformanceCheckOut": {
                "CHANGEPERFCHECKOUTREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ChangePerformanceCheckOutResponse.from_dict(response["ChangePerformanceCheckOutResponse"]["return"])

    def update_external_reservation_code(self, request: UpdateExternalReservationCodeRequest) -> UpdateExternalReservationCodeResponse:
        """Update external reservation code."""
        payload = {
            "urn:UpdateExternalReservationCode": {
                "UPDATEEXTERNALRESERVATIONCODEREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return UpdateExternalReservationCodeResponse.from_dict(response["UpdateExternalReservationCodeResponse"]["return"])
