"""
External reservation service for the BOS API.

This service provides methods for external reservation operations including
Hilton PMS integration, booking creation, modification, and cancellation.
"""

from ..base_service import BaseService
from ..types.externalreservationenquiry import (
    HiltonPMSIntegrationRequest,
    CreateBookingRequest,
    ModifyBookingValidityRequest,
    CancelBookingRequest,
    BookingResponse,
)


class ExternalReservationService(BaseService):
    """Service for BOS external reservation operations with improved developer ergonomics.

    This service provides methods for external reservation management, including
    Hilton PMS integration, booking operations, and validity management in the BOS system.
    All complex data structures use typed classes instead of dictionaries for better
    IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIExternalReservation")

    Example:
        >>> service = ExternalReservationService(bos_api, "IWsAPIExternalReservation")
        >>> request = CreateBookingRequest(
        ...     creation_type="1",
        ...     xml_data="<booking>...</booking>"
        ... )
        >>> response = service.create_booking(request)
        >>> if response.error.is_success:
        ...     print(f"Booking created: {response.reference}")
    """

    def hilton_pms_integration(
        self, request: HiltonPMSIntegrationRequest
    ) -> BookingResponse:
        """Hilton PMS integration operation.

        Args:
            request: HiltonPMSIntegrationRequest with integration data

        Returns:
            BookingResponse: Response containing booking reference

        Example:
            >>> from ..types.externalreservationenquiry import HiltonObj
            >>> request = HiltonPMSIntegrationRequest(
            ...     item=HiltonObj(internal_code="CODE123", json_data='{"key": "value"}')
            ... )
            >>> response = service.hilton_pms_integration(request)
            >>> if response.error.is_success:
            ...     print(f"Integration successful: {response.reference}")
        """
        payload = {"urn:HiltonPMSIntegration": {"HILTONPMSINTEGRATIONREQ": request.to_dict()}}
        response = self.send_request(payload)
        return BookingResponse.from_dict(response["HiltonPMSIntegrationResponse"]["return"])

    def create_booking(self, request: CreateBookingRequest) -> BookingResponse:
        """Create a booking.

        Args:
            request: CreateBookingRequest with booking data

        Returns:
            BookingResponse: Response containing booking reference

        Example:
            >>> request = CreateBookingRequest(
            ...     creation_type="1",
            ...     xml_data="<booking>...</booking>"
            ... )
            >>> response = service.create_booking(request)
            >>> if response.error.is_success:
            ...     print(f"Booking created: {response.reference}")
        """
        payload = {"urn:CreateBooking": {"CREATEBOOKINGREQ": request.to_dict()}}
        response = self.send_request(payload)
        return BookingResponse.from_dict(response["CreateBookingResponse"]["return"])

    def modify_booking_validity(
        self, request: ModifyBookingValidityRequest
    ) -> BookingResponse:
        """Modify booking validity.

        Args:
            request: ModifyBookingValidityRequest with validity data

        Returns:
            BookingResponse: Response containing booking reference

        Example:
            >>> from ..types.common import BaseDateFilter
            >>> request = ModifyBookingValidityRequest(
            ...     reference="REF123",
            ...     validity=BaseDateFilter(from_date="2024-01-01", to_date="2024-12-31")
            ... )
            >>> response = service.modify_booking_validity(request)
            >>> if response.error.is_success:
            ...     print(f"Validity modified: {response.reference}")
        """
        payload = {
            "urn:ModifyBookingValidity": {"MODIFYBOOKINGVALIDITYREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return BookingResponse.from_dict(
            response["ModifyBookingValidityResponse"]["return"]
        )

    def cancel_booking(self, request: CancelBookingRequest) -> BookingResponse:
        """Cancel a booking.

        Args:
            request: CancelBookingRequest with booking reference

        Returns:
            BookingResponse: Response containing booking reference

        Example:
            >>> request = CancelBookingRequest(reference="REF123")
            >>> response = service.cancel_booking(request)
            >>> if response.error.is_success:
            ...     print(f"Booking cancelled: {response.reference}")
        """
        payload = {"urn:CancelBooking": {"CANCELBOOKINGREQ": request.to_dict()}}
        response = self.send_request(payload)
        return BookingResponse.from_dict(response["CancelBookingResponse"]["return"])
