"""OpenClaw Memory — record and search AI chat history."""

__version__ = "1.0.1"
