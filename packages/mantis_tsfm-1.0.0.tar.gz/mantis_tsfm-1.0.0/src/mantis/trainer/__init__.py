"""Init file for trainer.""" 

from .trainer import MantisTrainer


__all__ = ['MantisTrainer']
