"""Init file for architecture.""" 

from .version1 import MantisV1, Mantis8M
from .version2 import MantisV2

__all__ = ["MantisV1", "Mantis8M", "MantisV2"]
