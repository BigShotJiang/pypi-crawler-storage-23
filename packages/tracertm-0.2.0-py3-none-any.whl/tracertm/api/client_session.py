"""Client session management for TracerTM API.

Provides utilities for managing HTTP sessions with the TracerTM API.
"""
