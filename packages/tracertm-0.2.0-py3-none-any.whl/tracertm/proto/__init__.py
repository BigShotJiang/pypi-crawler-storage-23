"""Generated protobuf and gRPC code for TraceRTM services."""

from tracertm.proto.tracertm.v1 import tracertm_pb2, tracertm_pb2_grpc

__all__ = ["tracertm_pb2", "tracertm_pb2_grpc"]
