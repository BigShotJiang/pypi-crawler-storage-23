"""Compatibility shim for generated gRPC Python modules."""

from tracertm.proto.tracertm.v1 import tracertm_pb2, tracertm_pb2_grpc

__all__ = ["tracertm_pb2", "tracertm_pb2_grpc"]
