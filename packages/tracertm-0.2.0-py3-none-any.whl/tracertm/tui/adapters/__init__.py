"""TUI adapters for integrating storage and sync systems."""

from tracertm.tui.adapters.storage_adapter import StorageAdapter

__all__ = ["StorageAdapter"]
