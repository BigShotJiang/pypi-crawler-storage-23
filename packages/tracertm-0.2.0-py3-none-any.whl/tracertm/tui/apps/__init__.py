"""TUI applications."""

from tracertm.tui.apps.browser import BrowserApp
from tracertm.tui.apps.dashboard import DashboardApp
from tracertm.tui.apps.graph import GraphApp

__all__ = ["BrowserApp", "DashboardApp", "GraphApp"]
