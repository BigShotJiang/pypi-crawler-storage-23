"""Compatibility module for the enhanced dashboard app."""

from __future__ import annotations

from tracertm.tui.apps.dashboard import DashboardApp as EnhancedDashboardApp

__all__ = ["EnhancedDashboardApp"]
