"""gRPC server wiring for TraceRTM services."""
