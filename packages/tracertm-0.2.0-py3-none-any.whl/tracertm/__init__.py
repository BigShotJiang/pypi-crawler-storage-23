"""TraceRTM - Agent-native, multi-view requirements traceability system.

Version: 0.1.0
"""

from tracertm._version import __author__, __version__

__all__ = ["__author__", "__version__"]
