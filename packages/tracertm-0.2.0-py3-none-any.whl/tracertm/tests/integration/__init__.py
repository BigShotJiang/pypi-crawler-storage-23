"""Integration tests for TraceRTM."""
