"""
Thermal, Power & IPMI diagnostics.

Collects CPU/board thermals via lm-sensors and BMC-level data via ipmitool
(sensor readings, system event log).
"""

import re
from dataclasses import asdict
from datetime import datetime
from typing import List
import json

from ..core.executor import Executor
from .models import (
    SensorReading,
    IPMISensor,
    IPMISELEntry,
    ThermalDiagnosticsResult,
)


class ThermalDiagnostics:
    """
    Thermal, Power & IPMI diagnostics.

    Collects:
    - CPU/board/VRM thermals via lm-sensors (sensors -A)
    - IPMI sensor readings (ipmitool sensor list)
    - IPMI System Event Log (ipmitool sel elist)
    """

    def __init__(self):
        self.executor = Executor()
        self.sensors_path = self.executor.find_binary("sensors")
        self.ipmitool_path = self.executor.find_binary("ipmitool")

    async def get_lm_sensors(self) -> List[SensorReading]:
        """Run sensors -A and parse readings."""
        if not self.sensors_path:
            return []

        output = await self.executor.execute(
            f"{self.sensors_path} -A", allow_nonzero=True
        )
        if not output:
            return []

        readings = []
        current_chip = None

        for line in output.splitlines():
            if not line.strip():
                continue

            if not line[0].isspace() and ":" not in line:
                current_chip = line.strip()
                continue

            if ":" in line:
                parts = line.split(":", 1)
                name = parts[0].strip()
                value = parts[1].strip() if len(parts) > 1 else ""
                if name and value:
                    readings.append(SensorReading(
                        name=name,
                        value=value,
                        chip=current_chip,
                    ))

        return readings

    async def get_ipmi_sensors(self) -> List[IPMISensor]:
        """Run ipmitool sensor list and parse readings."""
        if not self.ipmitool_path:
            return []

        output = await self.executor.execute(
            f"sudo {self.ipmitool_path} sensor list", allow_nonzero=True
        )
        if not output:
            return []

        sensors = []
        for line in output.splitlines():
            fields = [f.strip() for f in line.split("|")]
            if len(fields) < 5:
                continue

            name = fields[0]
            value = fields[1] if fields[1] != "na" else None
            units = fields[2] if len(fields) > 2 and fields[2] != "na" else None
            status = fields[3] if len(fields) > 3 and fields[3] != "na" else None

            lower_crit = None
            upper_crit = None
            if len(fields) > 8:
                lower_crit = fields[6] if fields[6] != "na" else None
                upper_crit = fields[8] if fields[8] != "na" else None

            sensors.append(IPMISensor(
                name=name,
                value=value,
                units=units,
                status=status,
                lower_critical=lower_crit,
                upper_critical=upper_crit,
            ))

        return sensors

    async def get_ipmi_sel(self) -> List[IPMISELEntry]:
        """Run ipmitool sel elist and parse entries."""
        if not self.ipmitool_path:
            return []

        output = await self.executor.execute(
            f"sudo {self.ipmitool_path} sel elist", allow_nonzero=True
        )
        if not output:
            return []

        entries = []
        for line in output.splitlines():
            fields = [f.strip() for f in line.split("|")]
            entry = IPMISELEntry(raw=line.strip())

            if len(fields) >= 1:
                entry.id = fields[0]
            if len(fields) >= 3:
                entry.timestamp = f"{fields[1]} {fields[2]}"
            if len(fields) >= 4:
                entry.sensor = fields[3]
            if len(fields) >= 5:
                entry.event = " | ".join(fields[4:])

            entries.append(entry)

        return entries

    async def run_all_checks(self) -> ThermalDiagnosticsResult:
        """Run all thermal & IPMI checks."""
        result = ThermalDiagnosticsResult(timestamp=datetime.now())

        try:
            result.sensors = await self.get_lm_sensors()
        except Exception as e:
            result.warnings.append(f"Failed to collect lm-sensors data: {e}")

        if not self.sensors_path:
            result.warnings.append("lm-sensors not installed")

        try:
            result.ipmi_sensors = await self.get_ipmi_sensors()
        except Exception as e:
            result.warnings.append(f"Failed to collect IPMI sensor data: {e}")

        try:
            result.ipmi_sel = await self.get_ipmi_sel()
            result.ipmi_sel_count = len(result.ipmi_sel)
        except Exception as e:
            result.warnings.append(f"Failed to collect IPMI SEL: {e}")

        if not self.ipmitool_path:
            result.warnings.append("ipmitool not installed")

        if result.ipmi_sel_count > 0:
            result.warnings.append(
                f"IPMI SEL contains {result.ipmi_sel_count} event(s) — review for hardware faults"
            )

        _BAD_STATUSES = {"cr", "nr", "lnr", "unr", "lcr", "ucr"}
        for sensor in result.ipmi_sensors:
            if sensor.status and sensor.status.lower() in _BAD_STATUSES:
                result.errors.append(f"IPMI sensor {sensor.name}: {sensor.status} (value: {sensor.value} {sensor.units or ''})")

        return result

    def format_report(self, result: ThermalDiagnosticsResult) -> str:
        """Format results as a JSON report."""
        result_dict = asdict(result)
        result_dict.pop("warnings", None)
        for entry in result_dict.get("ipmi_sel", []):
            entry.pop("raw", None)
        return json.dumps(result_dict, indent=4, default=str)


async def run_thermal_diagnostics():
    """Run thermal & IPMI diagnostics and return the JSON report."""
    diagnostics = ThermalDiagnostics()
    result = await diagnostics.run_all_checks()
    return diagnostics.format_report(result)
