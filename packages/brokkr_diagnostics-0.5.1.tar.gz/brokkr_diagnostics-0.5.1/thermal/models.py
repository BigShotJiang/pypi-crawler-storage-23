"""Thermal & IPMI diagnostics data models."""

from typing import Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class SensorReading:
    """A single sensor reading from lm-sensors"""

    name: str
    value: str
    chip: Optional[str] = None


@dataclass
class IPMISensor:
    """A single IPMI sensor reading"""

    name: str
    value: Optional[str] = None
    units: Optional[str] = None
    status: Optional[str] = None
    lower_critical: Optional[str] = None
    upper_critical: Optional[str] = None


@dataclass
class IPMISELEntry:
    """A single IPMI System Event Log entry"""

    id: Optional[str] = None
    timestamp: Optional[str] = None
    sensor: Optional[str] = None
    event: Optional[str] = None
    raw: Optional[str] = None


@dataclass
class ThermalDiagnosticsResult:
    """Results from thermal & IPMI diagnostics"""

    timestamp: datetime
    sensors: List[SensorReading] = field(default_factory=list)
    ipmi_sensors: List[IPMISensor] = field(default_factory=list)
    ipmi_sel: List[IPMISELEntry] = field(default_factory=list)
    ipmi_sel_count: int = 0
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
