"""Thermal, power & IPMI diagnostics module"""

from .diagnostics import ThermalDiagnostics, run_thermal_diagnostics

__all__ = ["ThermalDiagnostics", "run_thermal_diagnostics"]
