"""
Storage & NVMe Health diagnostics.

Collects block device inventory, NVMe SMART data and error logs,
MD RAID status, LVM layout, and filesystem read-only detection.
"""

import re
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import List, Optional
import json

from ..core.executor import Executor
from .models import (
    BlockDevice,
    NVMeSMART,
    NVMeErrorLog,
    NVMeSmartLog,
    RAIDStatus,
    LVMStatus,
    FilesystemStatus,
    StorageDiagnosticsResult,
)


class StorageDiagnostics:
    """
    Storage & NVMe Health diagnostics.

    Collects:
    - Block device listing (lsblk)
    - NVMe SMART data (smartctl -a)
    - NVMe error logs and smart logs (nvme-cli)
    - MD RAID status (/proc/mdstat, mdadm)
    - LVM layout (pvs, vgs, lvs)
    - Filesystem mount status and read-only detection
    """

    def __init__(self):
        self.executor = Executor()
        self.lsblk_path = self.executor.find_binary("lsblk")
        self.smartctl_path = self.executor.find_binary("smartctl")
        self.nvme_path = self.executor.find_binary("nvme")
        self.mdadm_path = self.executor.find_binary("mdadm")
        self.pvs_path = self.executor.find_binary("pvs")

    async def get_block_devices(self) -> List[BlockDevice]:
        """Enumerate block devices via lsblk."""
        if not self.lsblk_path:
            return []

        result = await self.executor.execute(
            f"{self.lsblk_path} -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT,MODEL,SERIAL,STATE,ROTA,TRAN -P"
        )
        if not result:
            return []

        devices = []
        for line in result.splitlines():
            fields = dict(re.findall(r'(\w+)="([^"]*)"', line))
            if not fields.get("NAME"):
                continue
            devices.append(BlockDevice(
                name=fields.get("NAME", ""),
                size=fields.get("SIZE") or None,
                device_type=fields.get("TYPE") or None,
                fstype=fields.get("FSTYPE") or None,
                mountpoint=fields.get("MOUNTPOINT") or None,
                model=fields.get("MODEL") or None,
                serial=fields.get("SERIAL") or None,
                state=fields.get("STATE") or None,
                rotational=fields.get("ROTA") or None,
                transport=fields.get("TRAN") or None,
            ))

        return devices

    def _find_nvme_block_devices(self) -> List[str]:
        """Find NVMe namespace block devices in /dev."""
        devs = sorted(
            str(p) for p in Path("/dev").glob("nvme[0-9]*n1")
            if p.is_block_device()
        )
        return devs

    def _find_nvme_char_devices(self) -> List[str]:
        """Find NVMe controller character devices in /dev."""
        devs = sorted(
            str(p) for p in Path("/dev").glob("nvme[0-9]*")
            if p.is_char_device()
        )
        return devs

    async def get_nvme_smart(self) -> List[NVMeSMART]:
        """Run smartctl -a on each NVMe namespace device."""
        if not self.smartctl_path:
            return []

        results = []
        for dev in self._find_nvme_block_devices():
            smart = NVMeSMART(device=dev)
            output = await self.executor.execute(
                f"sudo {self.smartctl_path} -a {dev}", allow_nonzero=True
            )
            if not output:
                smart.error = "smartctl returned no output"
                smart.healthy = False
                results.append(smart)
                continue

            smart.raw_output = output
            self._parse_smartctl(smart, output)
            results.append(smart)

        return results

    @staticmethod
    def _parse_smartctl(smart: NVMeSMART, output: str) -> None:
        """Extract key fields from smartctl output."""
        for line in output.splitlines():
            lower = line.lower().strip()

            if lower.startswith("critical warning:"):
                val = line.split(":", 1)[1].strip()
                smart.critical_warning = val
                if val != "0x00":
                    smart.healthy = False

            elif lower.startswith("temperature:"):
                smart.temperature = line.split(":", 1)[1].strip()

            elif lower.startswith("available spare:"):
                smart.available_spare = line.split(":", 1)[1].strip()

            elif lower.startswith("available spare threshold:"):
                smart.available_spare_threshold = line.split(":", 1)[1].strip()

            elif lower.startswith("percentage used:"):
                smart.percentage_used = line.split(":", 1)[1].strip()

            elif lower.startswith("data units read:"):
                smart.data_units_read = line.split(":", 1)[1].strip()

            elif lower.startswith("data units written:"):
                smart.data_units_written = line.split(":", 1)[1].strip()

            elif lower.startswith("media and data integrity errors:") or lower.startswith("media errors:"):
                try:
                    smart.media_errors = int(line.split(":", 1)[1].strip().replace(",", ""))
                except ValueError:
                    pass
                if smart.media_errors and smart.media_errors > 0:
                    smart.healthy = False

            elif lower.startswith("num of error log entries:") or lower.startswith("error information log entries:"):
                try:
                    smart.num_err_log_entries = int(line.split(":", 1)[1].strip().replace(",", ""))
                except ValueError:
                    pass

            elif lower.startswith("power on hours:"):
                smart.power_on_hours = line.split(":", 1)[1].strip()

    async def get_nvme_error_logs(self) -> List[NVMeErrorLog]:
        """Run nvme error-log on each NVMe controller."""
        if not self.nvme_path:
            return []

        results = []
        for dev in self._find_nvme_char_devices():
            entry = NVMeErrorLog(device=dev)
            output = await self.executor.execute(
                f"sudo {self.nvme_path} error-log {dev}", allow_nonzero=True
            )
            if output:
                entry.raw_output = output
                entry.error_count = output.lower().count("error count")
            else:
                entry.error = f"nvme error-log failed for {dev}"
            results.append(entry)

        return results

    async def get_nvme_smart_logs(self) -> List[NVMeSmartLog]:
        """Run nvme smart-log on each NVMe namespace device."""
        if not self.nvme_path:
            return []

        results = []
        for dev in self._find_nvme_block_devices():
            entry = NVMeSmartLog(device=dev)
            output = await self.executor.execute(
                f"sudo {self.nvme_path} smart-log {dev}", allow_nonzero=True
            )
            if output:
                entry.raw_output = output
            else:
                entry.error = f"nvme smart-log failed for {dev}"
            results.append(entry)

        return results

    async def get_raid_status(self) -> Optional[RAIDStatus]:
        """Read MD RAID status from /proc/mdstat and mdadm."""
        mdstat_path = Path("/proc/mdstat")
        if not mdstat_path.exists():
            return None

        if not mdstat_path.read_text().strip():
            return None

        status = RAIDStatus()
        if self.mdadm_path:
            for md in sorted(Path("/dev").glob("md*")):
                if not md.is_block_device():
                    continue
                detail = await self.executor.execute(
                    f"sudo {self.mdadm_path} --detail {md}", allow_nonzero=True
                )
                if detail:
                    status.arrays[str(md)] = detail

        return status

    async def get_lvm_status(self) -> Optional[LVMStatus]:
        """Collect LVM layout (pvs, vgs, lvs)."""
        if not self.pvs_path:
            return None

        status = LVMStatus()
        status.pvs = await self.executor.execute("sudo pvs -a", allow_nonzero=True)
        status.vgs = await self.executor.execute("sudo vgs -a", allow_nonzero=True)
        status.lvs = await self.executor.execute("sudo lvs -a -o +devices", allow_nonzero=True)

        return status

    _RO_SKIP_FSTYPES = {"squashfs", "tmpfs", "nsfs", "proc", "sysfs", "devpts", "efivarfs"}

    async def get_filesystem_status(self) -> FilesystemStatus:
        """Check mount status and detect read-only filesystems."""
        fs = FilesystemStatus()

        mount_output = await self.executor.execute("mount")
        if mount_output:
            for line in mount_output.splitlines():
                fstype_match = re.search(r"\btype\s+(\S+)", line)
                fstype = fstype_match.group(1) if fstype_match else ""
                if fstype in self._RO_SKIP_FSTYPES:
                    continue
                opts_match = re.search(r"\(([^)]+)\)", line)
                if not opts_match:
                    continue
                opts = [o.strip() for o in opts_match.group(1).split(",")]
                if "ro" in opts:
                    fs.readonly_filesystems.append(line.strip())

        return fs

    async def run_all_checks(self) -> StorageDiagnosticsResult:
        """Run all storage health checks."""
        result = StorageDiagnosticsResult(timestamp=datetime.now())

        try:
            result.block_devices = await self.get_block_devices()
        except Exception as e:
            result.errors.append(f"Failed to enumerate block devices: {e}")

        try:
            result.nvme_smart = await self.get_nvme_smart()
            for smart in result.nvme_smart:
                if not smart.healthy:
                    if smart.critical_warning and smart.critical_warning != "0x00":
                        result.errors.append(
                            f"{smart.device}: NVMe critical warning {smart.critical_warning}"
                        )
                    if smart.media_errors and smart.media_errors > 0:
                        result.errors.append(
                            f"{smart.device}: {smart.media_errors} media/data integrity errors"
                        )
        except Exception as e:
            result.errors.append(f"Failed to collect NVMe SMART data: {e}")

        try:
            result.nvme_error_logs = await self.get_nvme_error_logs()
        except Exception as e:
            result.warnings.append(f"Failed to collect NVMe error logs: {e}")

        try:
            result.nvme_smart_logs = await self.get_nvme_smart_logs()
        except Exception as e:
            result.warnings.append(f"Failed to collect NVMe smart logs: {e}")

        try:
            result.raid_status = await self.get_raid_status()
        except Exception as e:
            result.warnings.append(f"Failed to check RAID status: {e}")

        try:
            result.lvm_status = await self.get_lvm_status()
        except Exception as e:
            result.warnings.append(f"Failed to check LVM status: {e}")

        try:
            result.filesystem_status = await self.get_filesystem_status()
            if result.filesystem_status.readonly_filesystems:
                for ro_fs in result.filesystem_status.readonly_filesystems:
                    result.errors.append(f"Read-only filesystem detected: {ro_fs}")
        except Exception as e:
            result.errors.append(f"Failed to check filesystem status: {e}")

        if not result.block_devices:
            result.warnings.append("No block devices found")
        if not result.nvme_smart and not self.smartctl_path:
            result.warnings.append("smartctl not available — NVMe SMART data not collected")
        if not result.nvme_error_logs and not self.nvme_path:
            result.warnings.append("nvme-cli not available — NVMe error logs not collected")

        return result

    def format_report(self, result: StorageDiagnosticsResult) -> str:
        """Format results as a JSON report."""
        result_dict = asdict(result)
        result_dict.pop("warnings", None)

        for smart in result_dict.get("nvme_smart", []):
            smart.pop("raw_output", None)
        for elog in result_dict.get("nvme_error_logs", []):
            elog.pop("raw_output", None)
        for slog in result_dict.get("nvme_smart_logs", []):
            slog.pop("raw_output", None)

        if result_dict.get("lvm_status"):
            lvm = result_dict["lvm_status"]
            lvm["pvs"] = self._table_to_dicts(lvm.get("pvs"))
            lvm["vgs"] = self._table_to_dicts(lvm.get("vgs"))
            lvm["lvs"] = self._table_to_dicts(lvm.get("lvs"))

        return json.dumps(result_dict, indent=4, default=str)

    @staticmethod
    def _table_to_dicts(text: Optional[str]) -> Optional[list[dict[str, str]]]:
        """Parse whitespace-aligned CLI table output into a list of dicts."""
        if not text:
            return None
        lines = [l for l in text.strip().splitlines() if l.strip()]
        if len(lines) < 2:
            return None
        headers = lines[0].split()
        rows = []
        for line in lines[1:]:
            vals = line.split()
            row = {h: v for h, v in zip(headers, vals)}
            rows.append(row)
        return rows or None


async def run_storage_diagnostics():
    """Run storage diagnostics and return the JSON report."""
    diagnostics = StorageDiagnostics()
    result = await diagnostics.run_all_checks()
    return diagnostics.format_report(result)
