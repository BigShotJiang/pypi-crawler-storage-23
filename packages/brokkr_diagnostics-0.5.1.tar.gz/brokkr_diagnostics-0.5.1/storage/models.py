"""Storage diagnostics data models and configuration."""

from typing import Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class BlockDevice:
    """A block device from lsblk"""

    name: str
    size: Optional[str] = None
    device_type: Optional[str] = None
    fstype: Optional[str] = None
    mountpoint: Optional[str] = None
    model: Optional[str] = None
    serial: Optional[str] = None
    state: Optional[str] = None
    rotational: Optional[str] = None
    transport: Optional[str] = None


@dataclass
class NVMeSMART:
    """SMART data for a single NVMe device"""

    device: str
    healthy: bool = True
    critical_warning: Optional[str] = None
    temperature: Optional[str] = None
    available_spare: Optional[str] = None
    available_spare_threshold: Optional[str] = None
    percentage_used: Optional[str] = None
    data_units_read: Optional[str] = None
    data_units_written: Optional[str] = None
    media_errors: Optional[int] = None
    num_err_log_entries: Optional[int] = None
    power_on_hours: Optional[str] = None
    raw_output: Optional[str] = None
    error: Optional[str] = None


@dataclass
class NVMeErrorLog:
    """Error log for an NVMe controller"""

    device: str
    error_count: int = 0
    raw_output: Optional[str] = None
    error: Optional[str] = None


@dataclass
class NVMeSmartLog:
    """Smart log from nvme-cli for an NVMe namespace"""

    device: str
    raw_output: Optional[str] = None
    error: Optional[str] = None


@dataclass
class RAIDStatus:
    """MD RAID array status"""

    arrays: Dict[str, str] = field(default_factory=dict)


@dataclass
class LVMStatus:
    """LVM volume status"""

    pvs: Optional[str] = None
    vgs: Optional[str] = None
    lvs: Optional[str] = None


@dataclass
class FilesystemStatus:
    """Filesystem mount and health status"""

    readonly_filesystems: List[str] = field(default_factory=list)


@dataclass
class StorageDiagnosticsResult:
    """Results from storage diagnostics"""

    timestamp: datetime
    block_devices: List[BlockDevice] = field(default_factory=list)
    nvme_smart: List[NVMeSMART] = field(default_factory=list)
    nvme_error_logs: List[NVMeErrorLog] = field(default_factory=list)
    nvme_smart_logs: List[NVMeSmartLog] = field(default_factory=list)
    raid_status: Optional[RAIDStatus] = None
    lvm_status: Optional[LVMStatus] = None
    filesystem_status: Optional[FilesystemStatus] = None
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
