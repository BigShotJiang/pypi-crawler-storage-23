"""
Mixin providing NVML lifecycle management and safe call wrappers.

Shared by GPUHardwareDiagnostics, NVLinkDiagnostics, and any future
diagnostics class that needs pynvml access.
"""

import pynvml


class NVMLMixin:
    """Mixin for NVML init/shutdown lifecycle and safe call helpers."""

    def __init__(self):
        self._nvml_initialized = False

    def _init_nvml(self) -> bool:
        if self._nvml_initialized:
            return True
        try:
            pynvml.nvmlInit()
            self._nvml_initialized = True
            return True
        except pynvml.NVMLError:
            return False

    def _shutdown_nvml(self):
        if self._nvml_initialized:
            try:
                pynvml.nvmlShutdown()
            except pynvml.NVMLError:
                pass
            self._nvml_initialized = False

    def _safe_nvml_call(self, func, *args, default=None):
        """Call an NVML function, returning default on any error."""
        try:
            return func(*args)
        except pynvml.NVMLError:
            return default
