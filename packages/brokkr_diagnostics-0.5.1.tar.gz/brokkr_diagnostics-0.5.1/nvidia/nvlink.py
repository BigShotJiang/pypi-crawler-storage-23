"""
NVLink and NVSwitch diagnostics.
Uses pynvml for NVLink state enumeration, topology discovery, and error counters.
All link counts, versions, and topologies are discovered dynamically.
"""

from typing import Dict, List, Optional
from dataclasses import dataclass, field, asdict
from datetime import datetime
import json
import pynvml
from .nvml_mixin import NVMLMixin


# ---------------------------------------------------------------------------
# Dataclass models
# ---------------------------------------------------------------------------

@dataclass
class NVLinkInfo:
    """Information about a single NVLink link on a GPU."""
    link_id: int
    state: str  # "active" or "inactive"
    version: Optional[int] = None
    remote_device_type: str = "UNKNOWN"  # GPU, IBMNPU, SWITCH, UNKNOWN
    remote_pci_bus_id: Optional[str] = None
    errors: Dict[str, int] = field(default_factory=dict)


@dataclass
class GPUNVLinkStatus:
    """NVLink status for a single GPU."""
    gpu_index: int
    gpu_name: str
    pci_bus_id: Optional[str] = None
    total_links: int = 0
    active_links: int = 0
    nvlink_version: Optional[int] = None
    links: List[NVLinkInfo] = field(default_factory=list)


@dataclass
class NVLinkTopologyEntry:
    """Topology relationship between a pair of GPUs."""
    gpu_a: int
    gpu_b: int
    connection_type: str  # e.g. NVLINK, SINGLE, MULTIPLE, HOSTBRIDGE, NODE, SYSTEM


@dataclass
class NVLinkDiagnosticsResult:
    """Aggregate result from NVLink diagnostics."""
    timestamp: datetime = field(default_factory=datetime.now)
    gpu_count: int = 0
    gpu_nvlink_status: List[GPUNVLinkStatus] = field(default_factory=list)
    topology: List[NVLinkTopologyEntry] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Topology level mapping
# ---------------------------------------------------------------------------

TOPOLOGY_LEVEL_MAP: Dict[int, str] = {
    1: "INTERNAL",
    2: "SINGLE",
    3: "MULTIPLE",
    4: "HOSTBRIDGE",
    5: "NODE",
    6: "SYSTEM",
}

# Newer NVML versions expose named constants that may differ from the
# integer values above.  Attempt to build a supplemental mapping from
# whatever constants are available in the installed pynvml.
_TOPOLOGY_CONST_NAMES = {
    "NVML_TOPOLOGY_INTERNAL":   "INTERNAL",
    "NVML_TOPOLOGY_SINGLE":     "SINGLE",
    "NVML_TOPOLOGY_MULTIPLE":   "MULTIPLE",
    "NVML_TOPOLOGY_HOSTBRIDGE": "HOSTBRIDGE",
    "NVML_TOPOLOGY_NODE":       "NODE",
    "NVML_TOPOLOGY_SYSTEM":     "SYSTEM",
}
for _const_name, _label in _TOPOLOGY_CONST_NAMES.items():
    _val = getattr(pynvml, _const_name, None)
    if _val is not None and _val not in TOPOLOGY_LEVEL_MAP:
        TOPOLOGY_LEVEL_MAP[_val] = _label


REMOTE_DEVICE_TYPE_MAP: Dict[int, str] = {
    0: "GPU",
    1: "IBMNPU",
    2: "SWITCH",
    3: "UNKNOWN",
}


# ---------------------------------------------------------------------------
# Maximum link index to probe.  NVLink counts vary per GPU generation
# (e.g. 6 on V100, 12 on A100, 18 on H100/B200).  We probe up to this
# ceiling; the loop stops early when NVML returns an error for a link index.
# ---------------------------------------------------------------------------

_MAX_NVLINK_PROBE = 24


class NVLinkDiagnostics(NVMLMixin):
    """
    NVLink and NVSwitch diagnostics.

    Collects:
    - Per-GPU NVLink link state, version, remote device info, error counters
    - GPU-pair topology (common ancestor)
    """

    def __init__(self):
        super().__init__()

    # ------------------------------------------------------------------
    # Per-GPU NVLink status
    # ------------------------------------------------------------------

    def get_gpu_nvlink_status(self, handle, gpu_index: int) -> GPUNVLinkStatus:
        """Discover NVLink links for a single GPU and collect their status."""
        gpu_name = self._safe_nvml_call(pynvml.nvmlDeviceGetName, handle, default="Unknown")
        pci_info = self._safe_nvml_call(pynvml.nvmlDeviceGetPciInfo, handle)
        pci_bus_id = pci_info.busId if pci_info else None

        status = GPUNVLinkStatus(
            gpu_index=gpu_index,
            gpu_name=gpu_name,
            pci_bus_id=pci_bus_id,
        )

        discovered_version: Optional[int] = None

        for link in range(_MAX_NVLINK_PROBE):
            # Probe link state; an NVMLError means we have exhausted the
            # available links on this GPU.
            link_state = self._safe_nvml_call(
                pynvml.nvmlDeviceGetNvLinkState, handle, link
            )
            if link_state is None:
                break

            state_str = "active" if link_state == 1 else "inactive"

            # Version
            version = self._safe_nvml_call(
                pynvml.nvmlDeviceGetNvLinkVersion, handle, link
            )
            if version is not None and discovered_version is None:
                discovered_version = version

            # Remote device type
            remote_type_int = self._safe_nvml_call(
                pynvml.nvmlDeviceGetNvLinkRemoteDeviceType, handle, link
            )
            remote_device_type = REMOTE_DEVICE_TYPE_MAP.get(
                remote_type_int, "UNKNOWN"
            ) if remote_type_int is not None else "UNKNOWN"

            # Remote PCI info
            remote_pci = self._safe_nvml_call(
                pynvml.nvmlDeviceGetNvLinkRemotePciInfo, handle, link
            )
            remote_pci_bus_id = remote_pci.busId if remote_pci else None

            # Error counters
            error_counters: Dict[str, int] = {}
            error_types = {
                "CRC_FLIT": getattr(pynvml, "NVML_NVLINK_ERROR_DL_CRC_FLIT", None),
                "CRC_DATA": getattr(pynvml, "NVML_NVLINK_ERROR_DL_CRC_DATA", None),
                "REPLAY":   getattr(pynvml, "NVML_NVLINK_ERROR_DL_REPLAY", None),
                "RECOVERY": getattr(pynvml, "NVML_NVLINK_ERROR_DL_RECOVERY", None),
            }
            for err_name, err_const in error_types.items():
                if err_const is None:
                    continue
                count = self._safe_nvml_call(
                    pynvml.nvmlDeviceGetNvLinkErrorCounter, handle, link, err_const
                )
                if count is not None:
                    error_counters[err_name] = count

            link_info = NVLinkInfo(
                link_id=link,
                state=state_str,
                version=version,
                remote_device_type=remote_device_type,
                remote_pci_bus_id=remote_pci_bus_id,
                errors=error_counters,
            )
            status.links.append(link_info)

        status.total_links = len(status.links)
        status.active_links = sum(1 for l in status.links if l.state == "active")
        status.nvlink_version = discovered_version

        return status

    # ------------------------------------------------------------------
    # Topology
    # ------------------------------------------------------------------

    def _topology_level_to_str(self, level: int) -> str:
        """Map an NVML topology level integer to a human-readable string."""
        return TOPOLOGY_LEVEL_MAP.get(level, f"UNKNOWN({level})")

    def get_topology(self) -> List[NVLinkTopologyEntry]:
        """Build a topology matrix for every unique GPU pair."""
        gpu_count = self._safe_nvml_call(pynvml.nvmlDeviceGetCount, default=0)
        if gpu_count < 2:
            return []

        handles: List = []
        for i in range(gpu_count):
            h = self._safe_nvml_call(pynvml.nvmlDeviceGetHandleByIndex, i)
            handles.append(h)

        entries: List[NVLinkTopologyEntry] = []
        for i in range(gpu_count):
            if handles[i] is None:
                continue
            for j in range(i + 1, gpu_count):
                if handles[j] is None:
                    continue
                ancestor = self._safe_nvml_call(
                    pynvml.nvmlDeviceGetTopologyCommonAncestor,
                    handles[i], handles[j],
                )
                if ancestor is not None:
                    connection_type = self._topology_level_to_str(ancestor)
                else:
                    connection_type = "UNKNOWN"

                entries.append(NVLinkTopologyEntry(
                    gpu_a=i,
                    gpu_b=j,
                    connection_type=connection_type,
                ))

        return entries

    # ------------------------------------------------------------------
    # Run all checks
    # ------------------------------------------------------------------

    async def run_all_checks(self) -> NVLinkDiagnosticsResult:
        """Enumerate all GPUs, collect NVLink status and topology."""
        result = NVLinkDiagnosticsResult(timestamp=datetime.now())

        if not self._init_nvml():
            result.errors.append("Failed to initialize NVML")
            return result

        try:
            gpu_count = self._safe_nvml_call(pynvml.nvmlDeviceGetCount, default=0)
            result.gpu_count = gpu_count

            if gpu_count == 0:
                result.errors.append("No GPUs detected")
                return result

            # Per-GPU NVLink status
            for i in range(gpu_count):
                handle = self._safe_nvml_call(pynvml.nvmlDeviceGetHandleByIndex, i)
                if handle is None:
                    result.errors.append(f"Could not get handle for GPU {i}")
                    continue

                status = self.get_gpu_nvlink_status(handle, i)
                result.gpu_nvlink_status.append(status)

                # Flag inactive links
                for link in status.links:
                    if link.state == "inactive":
                        result.warnings.append(
                            f"GPU {i} ({status.gpu_name}): NVLink {link.link_id} is inactive"
                        )

                    # Flag non-zero error counters
                    for err_name, count in link.errors.items():
                        if count > 0:
                            result.warnings.append(
                                f"GPU {i} ({status.gpu_name}): NVLink {link.link_id} "
                                f"has {count} {err_name} errors"
                            )

                if status.total_links == 0:
                    result.warnings.append(
                        f"GPU {i} ({status.gpu_name}): No NVLink links detected"
                    )

            # Topology
            result.topology = self.get_topology()

        except Exception as e:
            result.errors.append(f"Unexpected error during NVLink diagnostics: {e}")
        finally:
            self._shutdown_nvml()

        return result

    # ------------------------------------------------------------------
    # Report formatting
    # ------------------------------------------------------------------

    def format_report(self, result: NVLinkDiagnosticsResult) -> str:
        """Format results as a JSON report."""
        result_dict = asdict(result)
        result_dict.pop("warnings", None)
        return json.dumps(result_dict, indent=4, default=str)


# ---------------------------------------------------------------------------
# Module entry point
# ---------------------------------------------------------------------------

async def run_nvlink_diagnostics():
    """Run NVLink diagnostics and return the JSON report."""
    diagnostics = NVLinkDiagnostics()
    result = await diagnostics.run_all_checks()
    return diagnostics.format_report(result)
