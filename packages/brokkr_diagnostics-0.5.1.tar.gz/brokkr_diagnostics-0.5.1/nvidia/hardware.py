"""
GPU Hardware State & Identification diagnostics.
Uses pynvml for GPU enumeration and metrics, sysfs/proc for kernel-level detail.
"""

from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import asdict
from datetime import datetime
import json
import pynvml
from .models import GPUDevice, GPUHardwareResult, GPUProcess
from .nvml_mixin import NVMLMixin

_CLOCKS_THROTTLE_REASON_HW_SLOWDOWN = getattr(
    pynvml, "nvmlClocksThrottleReasonHwSlowdown", 0x0000000000000008
)


class GPUHardwareDiagnostics(NVMLMixin):
    """
    GPU Hardware State & Identification diagnostics.

    Collects:
    - GPU enumeration via pynvml (NVML)
    - GPU properties (name, VBIOS, memory, serial, UUID, ECC, thermals, PCIe)
    - Per-GPU power state from /proc/driver/nvidia/gpus/<BUS_ID>/power
    - Per-GPU sysfs power management info
    """

    PROC_DRIVER_GPUS_PATH = Path("/proc/driver/nvidia/gpus")

    def __init__(self):
        super().__init__()

    def normalize_pci_bus_id(self, pci_bus_id: str) -> str:
        if pci_bus_id.count(":") >= 2:
            domain, rest = pci_bus_id.split(":", 1)
            return f"{domain[-4:]}:{rest}".lower()
        return pci_bus_id.lower()

    def _string_or_none(self, value: int | float | str | bool | None) -> Optional[str]:
        if isinstance(value,  str):
            return value if value is not None else None
        return str(value) if value is not None else None


    
    def _memory_info_to_mib(self, bytes_value: Optional[int]) -> Optional[str]:
        return f"{bytes_value // (1024 * 1024)} MiB" if bytes_value is not None else None

    def _format_watts(self, milliwatts: Optional[int]) -> Optional[str]:
        return f"{milliwatts / 1000:.1f} W" if milliwatts is not None else None

    def _format_mhz(self, mhz: Optional[int]) -> Optional[str]:
        return f"{mhz} MHz" if mhz is not None else None
    
    def _len_to_string(self, value: list | tuple ) -> str:
        try:
            return str(len(value)) if value is not None else None
        except Exception:
            return None

        

    def enumerate_gpus(self) -> List[GPUDevice]:
        """Enumerate GPUs with full metrics via pynvml."""
        if not self._init_nvml():
            return []

        driver_version = self._safe_nvml_call(pynvml.nvmlSystemGetDriverVersion)
        gpu_count = self._safe_nvml_call(pynvml.nvmlDeviceGetCount, default=0)

        gpus = []
        for i in range(gpu_count):
            handle = self._safe_nvml_call(pynvml.nvmlDeviceGetHandleByIndex, i)
            if handle is None:
                continue

            pci_info = self._safe_nvml_call(pynvml.nvmlDeviceGetPciInfo, handle)
            bus_id = pci_info.busId if pci_info else None

            # Memory
            mem_info = self._safe_nvml_call(pynvml.nvmlDeviceGetMemoryInfo, handle)
            mem_total_mib = self._memory_info_to_mib(mem_info.total if mem_info else None)
            mem_used_mib = self._memory_info_to_mib(mem_info.used if mem_info else None)
            mem_free_mib = self._memory_info_to_mib(mem_info.free if mem_info else None)

            # Power
            power_usage_mw = self._safe_nvml_call(pynvml.nvmlDeviceGetPowerUsage, handle)
            power_limit_mw = self._safe_nvml_call(pynvml.nvmlDeviceGetPowerManagementLimit, handle)

            # Clocks
            clock_graphics = self._safe_nvml_call(
                pynvml.nvmlDeviceGetClockInfo, handle, pynvml.NVML_CLOCK_GRAPHICS
            )
            clock_sm = self._safe_nvml_call(
                pynvml.nvmlDeviceGetClockInfo, handle, pynvml.NVML_CLOCK_SM
            )
            clock_mem = self._safe_nvml_call(
                pynvml.nvmlDeviceGetClockInfo, handle, pynvml.NVML_CLOCK_MEM
            )
            clock_max_graphics = self._safe_nvml_call(
                pynvml.nvmlDeviceGetMaxClockInfo, handle, pynvml.NVML_CLOCK_GRAPHICS
            )
            clock_max_mem = self._safe_nvml_call(
                pynvml.nvmlDeviceGetMaxClockInfo, handle, pynvml.NVML_CLOCK_MEM
            )

            # Persistence mode
            persistence_mode = self._safe_nvml_call(pynvml.nvmlDeviceGetPersistenceMode, handle)

            # ECC mode
            ecc_mode_result = self._safe_nvml_call(pynvml.nvmlDeviceGetEccMode, handle)

            # Compute mode
            compute_mode_raw = self._safe_nvml_call(pynvml.nvmlDeviceGetComputeMode, handle)
            compute_mode_map = {
                0: "Default",
                1: "Exclusive Thread",
                2: "Prohibited",
                3: "Exclusive Process",
            }

            # ECC errors
            ecc_corr_vol = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTotalEccErrors, handle,
                pynvml.NVML_MEMORY_ERROR_TYPE_CORRECTED, pynvml.NVML_VOLATILE_ECC
            )
            ecc_corr_agg = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTotalEccErrors, handle,
                pynvml.NVML_MEMORY_ERROR_TYPE_CORRECTED, pynvml.NVML_AGGREGATE_ECC
            )
            ecc_uncorr_vol = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTotalEccErrors, handle,
                pynvml.NVML_MEMORY_ERROR_TYPE_UNCORRECTED, pynvml.NVML_VOLATILE_ECC
            )
            ecc_uncorr_agg = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTotalEccErrors, handle,
                pynvml.NVML_MEMORY_ERROR_TYPE_UNCORRECTED, pynvml.NVML_AGGREGATE_ECC
            )

            # Retired pages
            retired_sbe = self._safe_nvml_call(
                pynvml.nvmlDeviceGetRetiredPages, handle,
                pynvml.NVML_PAGE_RETIREMENT_CAUSE_MULTIPLE_SINGLE_BIT_ECC_ERRORS
            )
            retired_dbe = self._safe_nvml_call(
                pynvml.nvmlDeviceGetRetiredPages, handle,
                pynvml.NVML_PAGE_RETIREMENT_CAUSE_DOUBLE_BIT_ECC_ERROR
            )
            retired_pending = self._safe_nvml_call(
                pynvml.nvmlDeviceGetRetiredPagesPendingStatus, handle
            )

            # Throttle reasons
            throttle_reasons = self._safe_nvml_call(
                pynvml.nvmlDeviceGetCurrentClocksThrottleReasons, handle
            )

            # Temperature
            temp_gpu = self._safe_nvml_call(
                pynvml.nvmlDeviceGetTemperature, handle, pynvml.NVML_TEMPERATURE_GPU
            )

            # PCIe link info
            pcie_gen_cur = self._safe_nvml_call(pynvml.nvmlDeviceGetCurrPcieLinkGeneration, handle)
            pcie_gen_max = self._safe_nvml_call(pynvml.nvmlDeviceGetMaxPcieLinkGeneration, handle)
            pcie_width_cur = self._safe_nvml_call(pynvml.nvmlDeviceGetCurrPcieLinkWidth, handle)
            pcie_width_max = self._safe_nvml_call(pynvml.nvmlDeviceGetMaxPcieLinkWidth, handle)

            # Remapped rows
            remapped = self._safe_nvml_call(pynvml.nvmlDeviceGetRemappedRows, handle)
            remapped_corr = remapped[0] if remapped else None
            remapped_uncorr = remapped[1] if remapped else None
            remapped_pending = remapped[2] if remapped else None
            remapped_failure = remapped[3] if remapped else None

            # Memory temperature (HBM)
            temp_mem = None
            nvml_fi_mem_temp = getattr(pynvml, "NVML_FI_DEV_MEMORY_TEMP", None)
            if nvml_fi_mem_temp is not None:
                field_val = self._safe_nvml_call(
                    pynvml.nvmlDeviceGetFieldValues, handle, [nvml_fi_mem_temp]
                )
                if field_val and len(field_val) > 0:
                    val = field_val[0]
                    # nvmlReturn_t == 0 means success
                    if hasattr(val, "nvmlReturn") and val.nvmlReturn == 0:
                        temp_mem = val.value.uiVal if hasattr(val.value, "uiVal") else val.value

            # Enforced power limit and hardware constraints
            enforced_power_mw = self._safe_nvml_call(pynvml.nvmlDeviceGetEnforcedPowerLimit, handle)
            power_constraints = self._safe_nvml_call(
                pynvml.nvmlDeviceGetPowerManagementLimitConstraints, handle
            )
            power_min_mw = power_constraints[0] if power_constraints else None
            power_max_mw = power_constraints[1] if power_constraints else None

            # Running processes
            processes = []
            compute_procs = self._safe_nvml_call(
                pynvml.nvmlDeviceGetComputeRunningProcesses, handle
            ) or []
            graphics_procs = self._safe_nvml_call(
                pynvml.nvmlDeviceGetGraphicsRunningProcesses, handle
            ) or []
            for proc in compute_procs + graphics_procs:
                proc_name = self._safe_nvml_call(
                    pynvml.nvmlSystemGetProcessName, proc.pid
                )
                used_mem = getattr(proc, "usedGpuMemory", None)
                processes.append(GPUProcess(
                    pid=proc.pid,
                    name=proc_name,
                    used_gpu_memory=self._memory_info_to_mib(used_mem),
                ))

            gpu = GPUDevice(
                index=i,
                name=self._safe_nvml_call(pynvml.nvmlDeviceGetName, handle, default="Unknown"),
                pci_bus_id=bus_id,
                driver_version=driver_version,
                vbios_version=self._safe_nvml_call(pynvml.nvmlDeviceGetVbiosVersion, handle),
                serial=self._safe_nvml_call(pynvml.nvmlDeviceGetSerial, handle),
                uuid=self._safe_nvml_call(pynvml.nvmlDeviceGetUUID, handle),
                memory_total=mem_total_mib,
                memory_used=mem_used_mib,
                memory_free=mem_free_mib,
                # Power
                power_draw=self._format_watts(power_usage_mw),
                power_limit=self._format_watts(power_limit_mw),
                power_limit_enforced=self._format_watts(enforced_power_mw),
                power_limit_max=self._format_watts(power_max_mw),
                power_limit_min=self._format_watts(power_min_mw),
                # Clocks
                clock_graphics=self._format_mhz(clock_graphics),
                clock_sm=self._format_mhz(clock_sm),
                clock_memory=self._format_mhz(clock_mem),
                clock_max_graphics=self._format_mhz(clock_max_graphics),
                clock_max_memory=self._format_mhz(clock_max_mem),
                # Modes
                persistence_mode="Enabled" if persistence_mode == pynvml.NVML_FEATURE_ENABLED else "Disabled" if persistence_mode is not None else None,
                ecc_mode="Enabled" if ecc_mode_result and ecc_mode_result[0] == pynvml.NVML_FEATURE_ENABLED else "Disabled" if ecc_mode_result is not None else None,
                compute_mode=compute_mode_map.get(compute_mode_raw) if compute_mode_raw is not None else None,
                # ECC
                ecc_errors_corrected_volatile=self._string_or_none(ecc_corr_vol),
                ecc_errors_corrected_aggregate=self._string_or_none(ecc_corr_agg),
                ecc_errors_uncorrected_volatile=self._string_or_none(ecc_uncorr_vol),
                ecc_errors_uncorrected_aggregate=self._string_or_none(ecc_uncorr_agg),
                # Retired pages
                retired_pages_single_bit_ecc=self._len_to_string(retired_sbe),
                retired_pages_double_bit=self._len_to_string(retired_dbe),
                retired_pages_pending=self._string_or_none(retired_pending),
                # Remapped rows
                remapped_rows_correctable=remapped_corr,
                remapped_rows_uncorrectable=remapped_uncorr,
                remapped_rows_pending=bool(remapped_pending) if remapped_pending is not None else None,
                remapped_rows_failure=bool(remapped_failure) if remapped_failure is not None else None,
                # Temperature
                temperature_gpu=self._string_or_none(temp_gpu),
                temperature_memory=self._string_or_none(temp_mem),
                # Throttle
                clocks_throttle_reasons_active=hex(throttle_reasons) if throttle_reasons is not None else None,
                clocks_throttle_reasons_hw_slowdown=str(
                    bool(throttle_reasons & _CLOCKS_THROTTLE_REASON_HW_SLOWDOWN)
                ) if throttle_reasons is not None else None,
                # PCIe
                pcie_link_gen_current=self._string_or_none(pcie_gen_cur),
                pcie_link_gen_max=self._string_or_none(pcie_gen_max),
                pcie_link_width_current=self._string_or_none(pcie_width_cur),
                pcie_link_width_max=self._string_or_none(pcie_width_max),
                # Processes
                processes=processes,
            )
            gpus.append(gpu)

        return gpus

    async def get_sysfs_power_info(self, pci_bus_id: str) -> Dict[str, Optional[str]]:
        """Read sysfs power management settings for GPU."""
        if not pci_bus_id:
            return {}

        normalized_bus_id = self.normalize_pci_bus_id(pci_bus_id)
        device_path = Path(f"/sys/bus/pci/devices/{normalized_bus_id}")

        power_info = {}
        for attr in ["control", "runtime_status", "runtime_usage"]:
            attr_path = device_path / "power" / attr
            try:
                if attr_path.exists():
                    power_info[attr] = attr_path.read_text().strip()
                else:
                    power_info[attr] = None
            except Exception:
                power_info[attr] = None

        return power_info

    async def list_proc_gpus(self) -> List[str]:
        """List all GPU directories in /proc/driver/nvidia/gpus/"""
        if not self.PROC_DRIVER_GPUS_PATH.exists():
            return []

        try:
            return [d.name for d in self.PROC_DRIVER_GPUS_PATH.iterdir() if d.is_dir()]
        except Exception:
            return []

    async def run_all_checks(self) -> GPUHardwareResult:
        """Run all GPU hardware identification checks."""
        result = GPUHardwareResult(timestamp=datetime.now())

        try:
            result.gpus = self.enumerate_gpus()
        except Exception as e:
            result.errors.append(f"Failed to enumerate GPUs: {e}")
            return result
        finally:
            self._shutdown_nvml()

        result.total_gpus = len(result.gpus)

        if result.total_gpus == 0:
            result.errors.append("No GPUs detected")
            return result

        # Get sysfs power management detail for each GPU
        for gpu in result.gpus:
            if gpu.pci_bus_id:
                sysfs_power = await self.get_sysfs_power_info(gpu.pci_bus_id)
                gpu.sysfs_power_control = sysfs_power.get("control")
                gpu.sysfs_runtime_status = sysfs_power.get("runtime_status")
                gpu.sysfs_runtime_usage = sysfs_power.get("runtime_usage")

            (
                ecc_error_message,
                retired_pages_message,
                remapped_rows_message,
                clocks_throttle_message,
                pcie_link_message,
                pcie_link_width_message,
            ) = gpu.check_all_errors()

            if ecc_error_message:
                result.errors.append(ecc_error_message)
            if retired_pages_message:
                result.warnings.append(retired_pages_message)
            if remapped_rows_message:
                result.errors.append(remapped_rows_message)
            if clocks_throttle_message:
                result.warnings.append(clocks_throttle_message)
            if pcie_link_message:
                result.warnings.append(pcie_link_message)
            if pcie_link_width_message:
                result.warnings.append(pcie_link_width_message)

        proc_gpus = await self.list_proc_gpus()
        nvml_bus_ids = {self.normalize_pci_bus_id(gpu.pci_bus_id) for gpu in result.gpus if gpu.pci_bus_id}

        for proc_gpu in proc_gpus:
            if proc_gpu.lower() not in nvml_bus_ids:
                result.warnings.append(f"GPU {proc_gpu} found in /proc but not reported by NVML")

        return result

    def format_report(self, result: GPUHardwareResult) -> str:
        """Format results as a JSON report."""
        result_dict = asdict(result)
        result_dict.pop("warnings", None)
        return json.dumps(result_dict, indent=4, default=str)


async def run_gpu_hardware_diagnostics():
    """Run GPU hardware diagnostics and return the JSON report."""
    diagnostics = GPUHardwareDiagnostics()
    result = await diagnostics.run_all_checks()
    return diagnostics.format_report(result)
