"""
CUDA GPU Functionality Tests
Tests GPU memory allocation, host<->device copies, and multi-GPU P2P communication
"""

import ctypes
import os
import time
import json
from datetime import datetime
from dataclasses import asdict

from ..core.cuda import CUDAInterface
from ..core.models import GPUTest, P2PTest, CUDATestResult


class CUDADiagnostics:
    """
    CUDA functionality diagnostics
    Tests GPU memory, host<->device copies, and multi-GPU P2P
    """

    def __init__(self):
        self.cuda = None
        try:
            self.cuda = CUDAInterface()
        except Exception:
            raise RuntimeError("CUDA not available")

    def _make_test_buffer(self, size_bytes: int):
        """Create a ctypes buffer filled with random data"""
        buf = (ctypes.c_byte * size_bytes)()
        ctypes.memmove(buf, os.urandom(size_bytes), size_bytes)
        return buf

    def test_single_gpu(self, gpu_id: int, size_mb: int = 100) -> GPUTest:
        """Test basic GPU functionality"""
        size_bytes = size_mb * 1024 * 1024
        data = self._make_test_buffer(size_bytes)

        gpu_ptr = None
        try:
            self.cuda.set_device(gpu_id)
            gpu_ptr = self.cuda.malloc(size_bytes)
            self.cuda.memcpy_h2d(gpu_ptr, data, size_bytes)

            result = (ctypes.c_byte * size_bytes)()
            self.cuda.memcpy_d2h(result, gpu_ptr, size_bytes)

            success = bytes(data) == bytes(result)
            error = None if success else "Data mismatch after copy"

            return GPUTest(gpu_id=gpu_id, success=success, error=error, test_size_mb=size_mb)

        except Exception as e:
            return GPUTest(gpu_id=gpu_id, success=False, error=str(e), test_size_mb=size_mb)
        finally:
            if gpu_ptr is not None:
                try:
                    self.cuda.free(gpu_ptr)
                except Exception:
                    pass

    def test_p2p_pair(self, src_gpu: int, dst_gpu: int, size_mb: int = 100) -> P2PTest:
        """Test P2P between two GPUs with bandwidth measurement"""
        size_bytes = size_mb * 1024 * 1024
        data = self._make_test_buffer(size_bytes)

        gpu_ptr_src = None
        gpu_ptr_dst = None

        try:
            # Check P2P support
            p2p_supported = self.cuda.can_access_peer(src_gpu, dst_gpu)

            # Allocate on source GPU
            self.cuda.set_device(src_gpu)
            gpu_ptr_src = self.cuda.malloc(size_bytes)
            self.cuda.memcpy_h2d(gpu_ptr_src, data, size_bytes)

            # Allocate on destination GPU
            self.cuda.set_device(dst_gpu)
            gpu_ptr_dst = self.cuda.malloc(size_bytes)

            # Enable P2P if supported
            if p2p_supported:
                self.cuda.set_device(src_gpu)
                self.cuda.enable_peer_access(dst_gpu)
                self.cuda.set_device(dst_gpu)
                self.cuda.enable_peer_access(src_gpu)

            # Timed P2P copy
            self.cuda.set_device(src_gpu)
            start = time.time()
            self.cuda.memcpy_d2d(gpu_ptr_dst, gpu_ptr_src, size_bytes)
            self.cuda.device_synchronize()
            elapsed = time.time() - start

            # Verify data
            self.cuda.set_device(dst_gpu)
            verify = (ctypes.c_byte * size_bytes)()
            self.cuda.memcpy_d2h(verify, gpu_ptr_dst, size_bytes)

            if bytes(data) != bytes(verify):
                return P2PTest(
                    src_gpu=src_gpu,
                    dst_gpu=dst_gpu,
                    p2p_supported=p2p_supported,
                    success=False,
                    error="Data mismatch after P2P copy",
                )

            bandwidth_gbps = (size_bytes / 1e9) / elapsed

            return P2PTest(
                src_gpu=src_gpu,
                dst_gpu=dst_gpu,
                p2p_supported=p2p_supported,
                success=True,
                bandwidth_gbps=bandwidth_gbps,
            )

        except Exception as e:
            return P2PTest(src_gpu=src_gpu, dst_gpu=dst_gpu, p2p_supported=False, success=False, error=str(e))
        finally:
            if gpu_ptr_src is not None:
                try:
                    self.cuda.set_device(src_gpu)
                    self.cuda.free(gpu_ptr_src)
                except Exception:
                    pass
            if gpu_ptr_dst is not None:
                try:
                    self.cuda.set_device(dst_gpu)
                    self.cuda.free(gpu_ptr_dst)
                except Exception:
                    pass

    def run_all_tests(self) -> CUDATestResult:
        """Run comprehensive CUDA functionality tests"""
        result = CUDATestResult(timestamp=datetime.now(), cuda_available=self.cuda is not None, num_gpus=0)

        if not self.cuda:
            result.errors.append("CUDA not available - libcudart.so not found")
            return result

        try:
            result.num_gpus = self.cuda.get_device_count()
        except Exception as e:
            result.errors.append(f"Failed to get GPU count: {e}")
            return result

        if result.num_gpus == 0:
            result.warnings.append("No CUDA GPUs detected")
            return result

        # Test individual GPUs
        for gpu_id in range(result.num_gpus):
            gpu_test = self.test_single_gpu(gpu_id)
            result.individual_gpu_tests.append(gpu_test)
            if not gpu_test.success:
                result.errors.append(f"GPU {gpu_id}: {gpu_test.error}")

        # Test P2P between all GPU pairs
        for src in range(result.num_gpus):
            for dst in range(src + 1, result.num_gpus):
                p2p_test = self.test_p2p_pair(src, dst)
                result.p2p_tests.append(p2p_test)

                if not p2p_test.success:
                    result.errors.append(f"P2P GPU {src} -> GPU {dst}: {p2p_test.error}")
                elif not p2p_test.p2p_supported:
                    result.warnings.append(f"P2P not supported: GPU {src} -> GPU {dst}")

        # Check for slow P2P links
        if result.p2p_tests:
            successful_p2p = [t for t in result.p2p_tests if t.success]
            if successful_p2p:
                bandwidths = [t.bandwidth_gbps for t in successful_p2p]
                avg_bw = sum(bandwidths) / len(bandwidths)

                for test in successful_p2p:
                    if test.bandwidth_gbps < avg_bw * 0.5:
                        result.warnings.append(
                            f"Slow P2P link GPU {test.src_gpu} -> GPU {test.dst_gpu}: "
                            f"{test.bandwidth_gbps:.1f} GB/s (avg: {avg_bw:.1f} GB/s)"
                        )

        return result

    def format_report(self, result: CUDATestResult) -> str:
        """Format results as a JSON report."""
        result_dict = asdict(result)
        result_dict.pop("warnings", None)
        return json.dumps(result_dict, indent=4, default=str)


async def run_cuda_diagnostics():
    """Run CUDA diagnostics and return the JSON report."""
    diagnostics = CUDADiagnostics()
    result = diagnostics.run_all_tests()
    return diagnostics.format_report(result)


