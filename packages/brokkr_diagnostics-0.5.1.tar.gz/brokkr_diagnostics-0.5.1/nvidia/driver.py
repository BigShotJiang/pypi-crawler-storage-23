"""
NVIDIA Driver version and installation diagnostic module.
Replicates driver checks from nvidia-bug-report.sh lines 427-446, 985-993, 1329-1360.
"""

from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import asdict
from datetime import datetime
import json
import pynvml
from ..core.executor import Executor
from .driver_models import ModuleInfo, DriverInstallation, DriverVersionResult
from .nvml_mixin import NVMLMixin


class DriverVersionDiagnostics(NVMLMixin):
    """
    NVIDIA Driver version and installation diagnostics.

    Checks:
    - Driver version via NVML and /proc
    - Module version magic (vermagic) for ABI compatibility
    - Installation/uninstallation logs
    - DKMS compilation logs
    - Loaded modules status
    - Module parameters
    """

    # NVIDIA kernel modules to check
    NVIDIA_MODULES = ["nvidia", "nvidia_drm", "nvidia_modeset", "nvidia_uvm", "nvidia_peermem"]

    PROC_DRIVER_PATH = Path("/proc/driver/nvidia")
    DKMS_PATH = Path("/var/lib/dkms/nvidia")

    def __init__(self):
        super().__init__()
        self.executor = Executor()
        self.modinfo_path = self.executor.find_binary("modinfo")

    def vbios_version_match(self, vbios_versions: List[str]) -> bool:
        return len(set(vbios_versions)) == 1

    def get_driver_and_vbios_versions(self) -> tuple[Optional[str], List[str]]:
        """Get driver version and per-GPU VBIOS versions via pynvml."""
        if not self._init_nvml():
            return None, []

        try:
            driver_version = self._safe_nvml_call(pynvml.nvmlSystemGetDriverVersion)
            if driver_version is None:
                return None, []

            gpu_count = self._safe_nvml_call(pynvml.nvmlDeviceGetCount, default=0)

            vbios_versions = []
            for i in range(gpu_count):
                handle = self._safe_nvml_call(pynvml.nvmlDeviceGetHandleByIndex, i)
                if handle is not None:
                    version = self._safe_nvml_call(pynvml.nvmlDeviceGetVbiosVersion, handle, default="N/A")
                    vbios_versions.append(version)
                else:
                    vbios_versions.append("N/A")

            return driver_version, vbios_versions
        finally:
            self._shutdown_nvml()

    async def read_proc_driver_version(self) -> Optional[str]:
        """
        Read driver version from /proc/driver/nvidia/version (line 1554)
        """
        version_file = self.PROC_DRIVER_PATH / "version"
        if not version_file.exists():
            return None

        try:
            return version_file.read_text().strip()
        except Exception:
            return None

    async def read_proc_driver_params(self) -> Dict[str, str]:
        """
        Read driver parameters from /proc/driver/nvidia/params (line 1555)
        """
        params_file = self.PROC_DRIVER_PATH / "params"
        params = {}

        if not params_file.exists():
            return params

        try:
            content = params_file.read_text()
            for line in content.split("\n"):
                if ":" in line:
                    key, value = line.split(":", 1)
                    params[key.strip()] = value.strip()
        except Exception:
            pass

        return params

    async def read_proc_driver_registry(self) -> Optional[str]:
        """
        Read driver registry from /proc/driver/nvidia/registry (line 1556)
        """
        registry_file = self.PROC_DRIVER_PATH / "registry"
        if not registry_file.exists():
            return None

        try:
            return registry_file.read_text().strip()
        except Exception:
            return None

    async def get_module_info(self, module_name: str) -> ModuleInfo:
        """
        Get module information including vermagic (lines 1329-1348)
        """
        info = ModuleInfo(name=module_name)

        if not self.modinfo_path:
            return info

        # Get modinfo output
        result = await self.executor.execute(f"{self.modinfo_path} {module_name}")

        if result:
            for line in result.split("\n"):
                line = line.strip()
                if line.startswith("vermagic:"):
                    info.vermagic = line.split(":", 1)[1].strip()
                elif line.startswith("version:"):
                    info.version = line.split(":", 1)[1].strip()
                elif line.startswith("filename:"):
                    info.filename = line.split(":", 1)[1].strip()

        return info

    async def check_module_loaded(self, module_name: str) -> bool:
        """
        Check if module is loaded via /proc/modules (line 1548)
        """
        modules_file = Path("/proc/modules")
        if not modules_file.exists():
            return False

        try:
            content = modules_file.read_text()
            return any(line.startswith(module_name + " ") for line in content.split("\n"))
        except Exception:
            return False

    async def get_module_parameters(self, module_name: str) -> Dict[str, str]:
        """
        Get module parameters from /sys/module/*/parameters/ (lines 1350-1360)
        """
        params = {}
        params_path = Path(f"/sys/module/{module_name}/parameters")

        if not params_path.exists():
            return params

        try:
            for param_file in params_path.iterdir():
                if param_file.is_file():
                    try:
                        value = param_file.read_text().strip()
                        params[param_file.name] = value
                    except Exception:
                        params[param_file.name] = "<unreadable>"
        except Exception:
            pass

        return params

    async def read_installation_logs(self) -> DriverInstallation:
        """
        Read installation and uninstallation logs (lines 985-993)
        """
        installation = DriverInstallation()

        # nvidia-installer.log
        installer_log = Path("/var/log/nvidia-installer.log")
        if installer_log.exists():
            try:
                installation.installer_log = installer_log.read_text()
            except Exception as e:
                installation.errors.append(f"Could not read installer log: {e}")

        # nvidia-uninstall.log
        uninstall_log = Path("/var/log/nvidia-uninstall.log")
        if uninstall_log.exists():
            try:
                installation.uninstaller_log = uninstall_log.read_text()
            except Exception as e:
                installation.errors.append(f"Could not read uninstall log: {e}")

        # DKMS make.log files
        if self.DKMS_PATH.exists():
            try:
                for make_log in self.DKMS_PATH.rglob("make.log"):
                    try:
                        content = make_log.read_text()
                        installation.dkms_logs[str(make_log)] = content
                    except Exception as e:
                        installation.errors.append(f"Could not read DKMS log {make_log}: {e}")
            except Exception as e:
                installation.errors.append(f"Could not scan DKMS directory: {e}")

        return installation

    async def run_all_checks(self) -> DriverVersionResult:
        """
        Run all driver version and installation checks
        """
        result = DriverVersionResult(timestamp=datetime.now())

        # Get driver and VBIOS versions via pynvml
        driver_ver, vbios_vers = self.get_driver_and_vbios_versions()
        result.driver_version = driver_ver
        result.vbios_versions = vbios_vers

        if not result.driver_version:
            result.errors.append("Could not determine driver version - NVML not available")

        # Get /proc driver info
        result.proc_driver_version = await self.read_proc_driver_version()
        result.proc_params = await self.read_proc_driver_params()
        result.proc_registry = await self.read_proc_driver_registry()

        if not result.proc_driver_version:
            result.errors.append("/proc/driver/nvidia/version not readable - driver may not be loaded")

        # Check each NVIDIA module
        for module_name in self.NVIDIA_MODULES:
            module_info = await self.get_module_info(module_name)
            module_info.loaded = await self.check_module_loaded(module_name)

            if module_info.loaded:
                module_info.parameters = await self.get_module_parameters(module_name)

            result.modules[module_name] = module_info

            # Warnings for important modules
            if module_name == "nvidia" and not module_info.loaded:
                result.errors.append("Main nvidia module is not loaded")
            elif not module_info.loaded:
                result.warnings.append(f"Module {module_name} is not loaded")

            if module_info.loaded and not module_info.vermagic:
                result.warnings.append(f"Could not get vermagic for loaded module {module_name}")

        # Read installation logs
        result.installation = await self.read_installation_logs()

        # Check version consistency
        if result.driver_version and result.proc_driver_version:
            if result.driver_version not in result.proc_driver_version:
                result.warnings.append(
                    f"Version mismatch: NVML reports {result.driver_version}, "
                    f"but /proc reports {result.proc_driver_version}"
                )

        return result

    def format_report(self, result: DriverVersionResult) -> str:
        """Format results as a JSON report."""
        result_dict = asdict(result)
        result_dict.pop("warnings", None)
        return json.dumps(result_dict, indent=4, default=str)


async def run_driver_diagnostics():
    """Run driver diagnostics and return the JSON report."""
    diagnostics = DriverVersionDiagnostics()
    result = await diagnostics.run_all_checks()
    return diagnostics.format_report(result)



