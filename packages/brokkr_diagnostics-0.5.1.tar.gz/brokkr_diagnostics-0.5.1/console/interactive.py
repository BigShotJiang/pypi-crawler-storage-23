"""Interactive REPL mode — diagnostics only"""

import os
import asyncio
from termcolor import cprint
from prompt_toolkit import PromptSession
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.styles import Style
from prompt_toolkit.formatted_text import HTML

from .commands import COMMANDS, resolve_command
from .ui import print_help


def _build_completions() -> list:
    """Build tab-completion list from diagnostic commands + aliases."""
    commands = []
    for name, config in COMMANDS.items():
        commands.append(name)
        commands.extend(config.get("aliases", []))
    commands.extend(["all", "help", "clear", "quit", "exit"])
    return commands


def _run_diagnostic(name: str, func):
    """Run a single async diagnostic and print the result."""
    cprint(f"\n{'=' * 80}", "cyan")
    cprint(f"Running: {name}", "yellow", attrs=["bold"])
    cprint("=" * 80, "cyan")
    try:
        result = asyncio.run(func())
        if result:
            cprint(result, "green")
    except Exception as e:
        cprint(f"\nERROR running {name}: {e}", "red", attrs=["bold"])


def _run_all():
    """Run all diagnostic modules."""
    for _, config in COMMANDS.items():
        if config.get("requires_root") or not config.get("async"):
            continue
        _run_diagnostic(config["description"], config["func"])


def run_interactive():
    """Run interactive REPL mode"""
    print_help()

    session = PromptSession(
        completer=WordCompleter(_build_completions(), ignore_case=True, sentence=True),
        style=Style.from_dict({"prompt": "#00aa00 bold"}),
        complete_while_typing=True,
    )

    while True:
        try:
            choice = session.prompt(HTML("<prompt>brokkr> </prompt>")).strip().lower()
            if not choice:
                continue

            match choice:
                case "quit" | "exit" | "q":
                    break
                case "help" | "h" | "?":
                    print_help()
                case "clear":
                    os.system("clear")
                case "all":
                    _run_all()
                case _:
                    resolved = resolve_command(choice)
                    if not resolved:
                        cprint(f"Unknown command: '{choice}'", "red")
                        continue
                    config = COMMANDS[resolved]
                    if config.get("requires_root") and os.geteuid() != 0:
                        cprint(f"Error: '{choice}' requires root", "red")
                        continue
                    _run_diagnostic(config["description"], config["func"])

        except (KeyboardInterrupt, EOFError):
            break

    cprint("\nExiting Brokkr Diagnostics...", "red")
