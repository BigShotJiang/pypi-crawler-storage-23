"""Command definitions and execution for diagnostic CLI"""

import asyncio
import os
from termcolor import cprint

from brokkr_diagnostics.nvidia import (
    run_driver_diagnostics,
    run_gpu_hardware_diagnostics,
    run_cuda_diagnostics,
    run_gpu_reset,
    run_nvlink_diagnostics,
    
)
from brokkr_diagnostics.pcie import run_lspci_diagnostics
from brokkr_diagnostics.kernel import (
    run_nvidia_services_diagnostics,
    run_kernel_logs_diagnostics,
    run_proc_diagnostics,
)

from brokkr_diagnostics.infiniband import run_ib_diagnostics
from brokkr_diagnostics.storage import run_storage_diagnostics
from brokkr_diagnostics.thermal import run_thermal_diagnostics
from brokkr_diagnostics.confidential_compute import toggle_cc_mode


# Diagnostic command registry — only diagnostics + admin actions
# Interactive-only commands (help, clear, quit) are handled in interactive.py
COMMANDS = {
    "driver": {
        "func": run_driver_diagnostics,
        "async": True,
        "description": "NVIDIA driver version & installation checks",
    },
    "gpu": {
        "func": run_gpu_hardware_diagnostics,
        "async": True,
        "description": "GPU hardware state & identification",
    },
    "nvlink": {
        "func": run_nvlink_diagnostics,
        "async": True,
        "description": "NVLink diagnostics",
    },
    "lspci": {
        "func": run_lspci_diagnostics,
        "async": True,
        "description": "PCIe bus topology & link status",
        "aliases": ["pcie"],
    },
    "services": {
        "func": run_nvidia_services_diagnostics,
        "async": True,
        "description": "SystemD service status",
    },
    "kernel": {
        "func": run_kernel_logs_diagnostics,
        "async": True,
        "description": "Kernel messages & error detection",
        "aliases": ["logs"],
    },
    "system": {
        "func": run_proc_diagnostics,
        "async": True,
        "description": "System information (/proc files, NUMA)",
        "aliases": ["proc"],
    },
    "ib": {
        "func": run_ib_diagnostics,
        "async": True,
        "description": "InfiniBand diagnostics",
    },
    "storage": {
        "func": run_storage_diagnostics,
        "async": True,
        "description": "Storage & NVMe health (SMART, error logs, RAID, filesystem)",
        "aliases": ["nvme", "disk"],
    },
    "thermal": {
        "func": run_thermal_diagnostics,
        "async": True,
        "description": "CPU/board thermals (lm-sensors) & IPMI/BMC sensors + SEL",
        "aliases": ["ipmi", "sensors"],
    },
    "cuda": {
        "func": run_cuda_diagnostics,
        "async": True,
        "description": "CUDA diagnostics",
        "aliases": ["cuda-tests"],
    },
    "reset": {
        "func": run_gpu_reset,
        "async": True,
        "description": "Reset all GPUs",
        "requires_root": True,
    },
}


def handle_cc_command(mode: str) -> int:
    """Handle CC mode toggle command"""
    if os.geteuid() != 0:
        cprint("Error: cc command requires root", "red")
        return 1

    mode = mode.lower()
    if mode in ["on", "off"]:
        toggle_cc_mode(mode)
        return 0
    else:
        cprint(f"Invalid CC mode: '{mode}'. Valid modes: on, off", "red")
        return 1


def resolve_command(cmd: str) -> str | None:
    """Resolve command name including aliases"""
    if cmd in COMMANDS:
        return cmd

    for name, config in COMMANDS.items():
        if cmd in config.get("aliases", []):
            return name

    return None


def run_command(cmd: str) -> int:
    """Run a single command non-interactively (used by --run flag)"""
    cmd = cmd.strip().lower()

    # Handle "cc on" / "cc off" as admin actions
    if cmd.startswith("cc "):
        parts = cmd.split()
        if len(parts) == 2:
            return handle_cc_command(parts[1])
        else:
            cprint("Usage: cc <mode>", "red")
            return 1

    resolved = resolve_command(cmd)
    if not resolved:
        cprint(f"Unknown command: '{cmd}'", "red")
        return 1

    config = COMMANDS[resolved]

    if config.get("requires_root") and os.geteuid() != 0:
        cprint(f"Error: '{cmd}' requires root", "red")
        return 1

    try:
        if config["async"]:
            result = asyncio.run(config["func"]())
        else:
            result = config["func"]()
        if result:
            cprint(result, "green")
        return 0
    except Exception as e:
        cprint(f"Error running '{cmd}': {e}", "red")
        return 1
