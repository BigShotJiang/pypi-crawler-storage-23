"""UI elements for interactive mode"""

from termcolor import cprint
from .commands import COMMANDS


def print_help():
    """Print available commands for interactive mode"""
    cprint("\nAvailable Commands:", "cyan", attrs=["bold"])
    cprint("-" * 60, "cyan")

    max_name = max(len(name) for name in COMMANDS)
    for name, config in COMMANDS.items():
        padding = " " * (max_name - len(name) + 4)
        cprint(f"  {name}{padding}- {config['description']}", "white")

    cprint(f"  {'all':<{max_name + 4}}- Run all diagnostics", "white")
    cprint(f"  {'help':<{max_name + 4}}- Show this help message", "white")
    cprint(f"  {'clear':<{max_name + 4}}- Clear the screen", "white")
    cprint(f"  {'quit':<{max_name + 4}}- Exit", "white")
    cprint("-" * 60, "cyan")
