import json
import re
import subprocess
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

from ..core.executor import Executor
from .config import (
    CRITICAL_UE_FLAGS,
    BENIGN_UE_FLAGS,
    CRITICAL_CE_FLAGS,
    BENIGN_CE_FLAGS,
    AERCounters,
    PCIeDevice,
    LspciCheckResult,
    ACSDevice,
    ACSStatus,
    GPUIommuGroup,
    IOMMUStatus,
)


class LspciDiagnostics:
    """
    Runs comprehensive PCIe diagnostics matching nvidia-bug-report.sh checks.

    Executes:
    - lspci -nntv: Tree view with vendor:device IDs
    - lspci -nn: Device list with class and vendor IDs
    - lspci -nnDvvvxxxx: Full verbose dump with config space
    - Fallback to sysfs if lspci unavailable
    - Special focus on NVIDIA devices (vendor 0x10de)
    """

    NVIDIA_VENDOR_ID = "10de"
    SYSFS_PCI_PATH = Path("/sys/bus/pci/devices")

    def __init__(self):
        self.executor = Executor()
        self.lspci_path = self.executor.find_binary("lspci")

    async def _run_command(self, cmd: Union[List[str], str], timeout: int = 30) -> Tuple[bool, str, str]:
        """
        Run command and return (success, stdout, stderr)
        """
        try:
            cmd_string = " ".join(cmd) if isinstance(cmd, list) else cmd
            result = await self.executor.execute(cmd_string, timeout)
            return (result is not None, result, None)
        except subprocess.TimeoutExpired:
            return (False, "", f"Command timed out after {timeout}s")
        except Exception as e:
            return (False, "", str(e))

    async def run_lspci_tree_view(self) -> Optional[str]:
        """
        Run: lspci -nntv
        Shows all devices in tree format with vendor:device IDs
        """
        if not self.lspci_path:
            return None

        success, stdout, stderr = await self._run_command([self.lspci_path, "-nntv"])
        if success:
            return stdout
        return None

    async def run_lspci_basic(self) -> Optional[str]:
        """
        Run: lspci -nn
        Lists all devices with class names and vendor:device IDs
        """
        if not self.lspci_path:
            return None

        success, stdout, stderr = await self._run_command([self.lspci_path, "-nn"])
        if success:
            return stdout
        return None

    async def run_lspci_verbose(self) -> Optional[str]:
        """
        Run: lspci -nnDvvvxxxx
        Most comprehensive - verbose info with full config space hex dump
        This is the CRITICAL check that reveals:
        - PCIe link speed/width capabilities and current values
        - Correctable/uncorrectable error registers
        - AER capability data
        - Device control/status registers
        - BAR addresses
        """
        if not self.lspci_path:
            return None

        success, stdout, stderr = await self._run_command(
            [self.lspci_path, "-nnDvvvxxxx"],
            timeout=60,  # Can be slow on systems with many devices
        )
        if success:
            return stdout
        return None

    async def _read_sysfs_device_info(self, device_path: Path) -> Optional[PCIeDevice]:
        """Read PCIe device info from sysfs"""
        try:
            bus_id = device_path.name

            # Read vendor, device, class, revision
            vendor_id = (device_path / "vendor").read_text().strip().replace("0x", "")
            device_id = (device_path / "device").read_text().strip().replace("0x", "")
            class_id = (device_path / "class").read_text().strip().replace("0x", "")
            revision_id = (device_path / "revision").read_text().strip().replace("0x", "")

            # Read config space
            config_path = device_path / "config"
            config_space = None
            if config_path.exists():
                try:
                    config_space = config_path.read_bytes()
                except Exception:
                    pass

            # Try to read subsystem IDs if available
            subsystem_vendor = None
            subsystem_device = None
            try:
                if (device_path / "subsystem_vendor").exists():
                    subsystem_vendor = (device_path / "subsystem_vendor").read_text().strip().replace("0x", "")
                if (device_path / "subsystem_device").exists():
                    subsystem_device = (device_path / "subsystem_device").read_text().strip().replace("0x", "")
            except Exception:
                pass

            return PCIeDevice(
                bus_id=bus_id,
                vendor_id=vendor_id,
                device_id=device_id,
                class_id=class_id,
                revision_id=revision_id,
                subsystem_vendor=subsystem_vendor,
                subsystem_device=subsystem_device,
                config_space=config_space,
            )

        except Exception as e:
            return None

    def _format_config_space_hex(self, config_space: bytes) -> str:
        """Format config space bytes as hex dump matching lspci format"""
        lines = []
        for i in range(0, len(config_space), 16):
            chunk = config_space[i : i + 16]
            hex_bytes = " ".join(f"{b:02x}" for b in chunk)
            lines.append(f"{i:02x}: {hex_bytes}")
        return "\n".join(lines)

    async def read_sysfs_fallback(self) -> str:
        """
        Fallback: Read config space from sysfs (lines 1202-1237 in script)
        Used when lspci is not available
        """
        output_lines = ["PCI devices configuration space dump using sysfs", ""]

        if not self.SYSFS_PCI_PATH.exists():
            return "Error: /sys/bus/pci/devices not found"

        for device_path in sorted(self.SYSFS_PCI_PATH.iterdir()):
            if not device_path.is_dir():
                continue

            device = await self._read_sysfs_device_info(device_path)
            if not device:
                continue

            # Print device header
            output_lines.append("")
            output_lines.append(
                f"{device.bus_id} {device.class_id}: "
                f"Vendor {device.vendor_id} Device {device.device_id} "
                f"(rev {device.revision_id})"
            )

            # Print config space hex dump
            if device.config_space:
                output_lines.append(self._format_config_space_hex(device.config_space))

        return "\n".join(output_lines)

    def parse_lspci_verbose_for_errors(self, verbose_output: str) -> Tuple[List[str], List[str]]:
        """
        Parse lspci verbose output for PCIe errors and warnings.

        Returns:
            Tuple of (errors, warnings)

        Errors: Fatal/uncorrectable errors with data corruption risk
        Warnings: Correctable errors, benign flags, link degradation
        """
        errors, warnings = [], []
        if not verbose_output:
            return errors, warnings

        current_device = None
        for line in verbose_output.split("\n"):
            if line and not line.startswith("\t"):
                current_device = line.split()[0] if line.split() else None
                continue

            line_stripped = line.strip()
            active_flags = {f for f in line_stripped.split() if f.endswith("+")}

            if line_stripped.startswith("UESta:"):
                self._classify_flags(
                    current_device, "UESta", active_flags, CRITICAL_UE_FLAGS, BENIGN_UE_FLAGS, errors, warnings
                )

            elif line_stripped.startswith("CESta:"):
                self._classify_flags(
                    current_device, "CESta", active_flags, CRITICAL_CE_FLAGS, BENIGN_CE_FLAGS, errors, warnings
                )

            elif line_stripped.startswith("DevSta:"):
                if "FatalErr+" in active_flags or "NonFatalErr+" in active_flags:
                    errors.append(f"{current_device}: DevSta - {line_stripped}")
                elif active_flags & {"CorrErr+", "UnsupReq+"}:
                    warnings.append(f"{current_device}: DevSta - {line_stripped}")

            elif line_stripped.startswith("RootSta:"):
                critical_root = {"UERcvd+", "MultUERcvd+", "FirstFatal+", "FatalMsg+"}
                if active_flags & critical_root:
                    errors.append(f"{current_device}: RootSta - {line_stripped}")
                elif active_flags & {"CERcvd+", "MultCERcvd+", "NonFatalMsg+"}:
                    warnings.append(f"{current_device}: RootSta - {line_stripped}")

            elif line_stripped.startswith("LnkSta:") and "(downgraded)" in line_stripped.lower():
                warnings.append(f"{current_device}: Link degraded - {line_stripped}")

        return errors, warnings

    def _classify_flags(
        self,
        device: str,
        status_type: str,
        active_flags: set,
        critical: set,
        benign: set,
        errors: List[str],
        warnings: List[str],
    ):
        """Classify active flags into errors or warnings."""
        critical_found = active_flags & critical
        benign_found = active_flags & benign

        if critical_found:
            errors.append(f"{device}: {status_type} - {', '.join(sorted(critical_found))}")
        if benign_found:
            warnings.append(f"{device}: {status_type} - {', '.join(sorted(benign_found))}")

    async def get_nvidia_devices_from_sysfs(self) -> List[PCIeDevice]:
        """Get all NVIDIA devices from sysfs"""
        nvidia_devices = []

        if not self.SYSFS_PCI_PATH.exists():
            return nvidia_devices

        for device_path in self.SYSFS_PCI_PATH.iterdir():
            if not device_path.is_dir():
                continue

            try:
                vendor_file = device_path / "vendor"
                if vendor_file.exists():
                    vendor_id = vendor_file.read_text().strip().replace("0x", "")
                    if vendor_id.lower() == self.NVIDIA_VENDOR_ID:
                        device = await self._read_sysfs_device_info(device_path)
                        if device:
                            nvidia_devices.append(device)
            except Exception:
                continue

        return nvidia_devices

    def check_pcie_link_status(self, device: PCIeDevice) -> Dict[str, str]:
        """
        Check PCIe link status from sysfs for a device
        Returns current and max link speed/width
        """
        status = {}
        device_path = self.SYSFS_PCI_PATH / device.bus_id

        try:
            current_speed_path = device_path / "current_link_speed"
            current_width_path = device_path / "current_link_width"

            if current_speed_path.exists():
                status["current_speed"] = current_speed_path.read_text().strip()

            if current_width_path.exists():
                status["current_width"] = current_width_path.read_text().strip()

            max_speed_path = device_path / "max_link_speed"
            max_width_path = device_path / "max_link_width"

            if max_speed_path.exists():
                status["max_speed"] = max_speed_path.read_text().strip()

            if max_width_path.exists():
                status["max_width"] = max_width_path.read_text().strip()

        except Exception as e:
            status["error"] = str(e)

        return status

    @staticmethod
    def _parse_aer_file(path: Path) -> Optional[dict[str, int]]:
        """Parse an AER sysfs file into {error_type: count}. Returns None if unreadable."""
        if not path.exists():
            return None
        try:
            text = path.read_text().strip()
            if not text:
                return None
            counts: dict[str, int] = {}
            for line in text.splitlines():
                parts = line.split()
                if len(parts) == 2:
                    counts[parts[0]] = int(parts[1])
            return counts
        except (PermissionError, OSError, ValueError):
            return None

    def read_aer_counters(self, device: PCIeDevice) -> AERCounters:
        """Read accumulated AER error counts from sysfs for a device."""
        device_path = self.SYSFS_PCI_PATH / device.bus_id
        return AERCounters(
            correctable=self._parse_aer_file(device_path / "aer_dev_correctable"),
            fatal=self._parse_aer_file(device_path / "aer_dev_fatal"),
            nonfatal=self._parse_aer_file(device_path / "aer_dev_nonfatal"),
        )

    def _parse_acs_from_verbose(self, verbose_output: str) -> List[ACSDevice]:
        """
        Parse lspci verbose output for devices with ACS enabled.

        Looks for ACSCtl lines within PCIe bridge/switch device blocks where
        ACS control bits (SrcValid, ReqRedir, CmpltRedir, UpFwd, etc.) are
        enabled with '+'.
        """
        devices_with_acs = []
        if not verbose_output:
            return devices_with_acs

        current_bdf = None
        current_description = ""
        is_bridge_or_switch = False

        for line in verbose_output.split("\n"):
            # Device header line: starts at column 0 with BDF
            if line and not line[0].isspace():
                parts = line.split(None, 1)
                if parts:
                    current_bdf = parts[0]
                    current_description = parts[1] if len(parts) > 1 else ""
                    # PCIe bridges have class 0604, switches are also bridges
                    is_bridge_or_switch = any(
                        kw in current_description.lower()
                        for kw in ["pci bridge", "pcie switch", "bridge [0604]"]
                    )
                continue

            line_stripped = line.strip()

            # Look for ACSCtl (ACS Control register) on bridge devices
            if line_stripped.startswith("ACSCtl:") and current_bdf and is_bridge_or_switch:
                # Extract enabled flags (those ending with '+')
                enabled_flags = [
                    f.rstrip("+") for f in line_stripped.split()
                    if f.endswith("+")
                ]
                if enabled_flags:
                    devices_with_acs.append(
                        ACSDevice(
                            bus_id=current_bdf,
                            device_description=current_description,
                            acs_enabled_flags=enabled_flags,
                        )
                    )

        return devices_with_acs

    async def _check_acs_via_sysfs(self) -> List[ACSDevice]:
        """
        Check ACS status via sysfs as a fallback when lspci verbose output
        is not available. Reads /sys/bus/pci/devices/*/acs_enabled if present.
        """
        devices_with_acs = []
        if not self.SYSFS_PCI_PATH.exists():
            return devices_with_acs

        for device_path in sorted(self.SYSFS_PCI_PATH.iterdir()):
            if not device_path.is_dir():
                continue

            acs_file = device_path / "acs_enabled"
            if not acs_file.exists():
                continue

            try:
                acs_val = acs_file.read_text().strip()
                if acs_val == "1":
                    bus_id = device_path.name
                    # Read class to check if it's a bridge
                    class_file = device_path / "class"
                    class_id = ""
                    if class_file.exists():
                        class_id = class_file.read_text().strip().replace("0x", "")
                    # Class 0604xx = PCI bridge
                    if class_id.startswith("0604"):
                        devices_with_acs.append(
                            ACSDevice(
                                bus_id=bus_id,
                                device_description=f"PCI bridge (class {class_id})",
                                acs_enabled_flags=["sysfs_acs_enabled"],
                            )
                        )
            except (PermissionError, OSError):
                continue

        return devices_with_acs

    def _find_upstream_bridges(self, gpu_bdf: str) -> List[str]:
        """
        Walk the sysfs topology to find all upstream PCIe bridges for a GPU.
        Returns list of BDFs for all parent bridges.
        """
        bridges = []
        device_path = self.SYSFS_PCI_PATH / gpu_bdf
        if not device_path.exists():
            return bridges

        try:
            # Walk up the device tree via symlinks
            current = device_path.resolve()
            while True:
                parent = current.parent
                # Stop when we leave the PCI device tree
                if not parent or "pci" not in str(parent):
                    break
                # Check if parent directory name looks like a BDF
                parent_name = parent.name
                if re.match(r"^[0-9a-fA-F]{4}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}\.[0-9a-fA-F]$", parent_name):
                    bridges.append(parent_name)
                current = parent
        except (OSError, ValueError):
            pass

        return bridges

    async def check_acs_status(self) -> ACSStatus:
        """
        Check ACS (Access Control Services) status on PCIe bridges/switches.

        ACS on upstream bridges can block direct P2P DMA between GPUs, forcing
        traffic through the CPU and severely degrading GPU-to-GPU bandwidth.

        Returns ACSStatus with list of devices that have ACS enabled and
        whether ACS may block P2P between GPUs.
        """
        status = ACSStatus()

        # Prefer parsing lspci verbose output if available
        if self.lspci_path:
            success, stdout, _ = await self._run_command(
                [self.lspci_path, "-vvv"],
                timeout=60,
            )
            if success and stdout:
                status.devices_with_acs = self._parse_acs_from_verbose(stdout)

        # Fallback or supplement with sysfs
        if not status.devices_with_acs:
            status.devices_with_acs = await self._check_acs_via_sysfs()

        # Determine if ACS may block P2P between GPUs
        # Build set of BDFs with ACS enabled
        if status.devices_with_acs:
            acs_bdfs = {dev.bus_id for dev in status.devices_with_acs}

            # Check if any GPU's upstream path goes through an ACS-enabled bridge
            nvidia_devices = await self.get_nvidia_devices_from_sysfs()
            for gpu in nvidia_devices:
                upstream_bridges = self._find_upstream_bridges(gpu.bus_id)
                for bridge_bdf in upstream_bridges:
                    if bridge_bdf in acs_bdfs:
                        status.acs_may_block_p2p = True
                        break
                if status.acs_may_block_p2p:
                    break

            # If we have ACS-enabled bridges but couldn't walk the topology,
            # still flag it as potentially blocking
            if not status.acs_may_block_p2p and status.devices_with_acs:
                status.acs_may_block_p2p = True

        return status

    async def check_iommu_status(self) -> IOMMUStatus:
        """
        Check IOMMU/VT-d status.

        IOMMU being enabled can interfere with GPU P2P and GPUDirect RDMA.
        Passthrough mode (iommu=pt) is generally acceptable.

        Checks:
        - Kernel cmdline for intel_iommu, amd_iommu, iommu parameters
        - /sys/kernel/iommu_groups/ for active IOMMU groups
        - /sys/firmware/acpi/tables/DMAR for Intel VT-d DMAR table presence
        - Which GPUs are in which IOMMU groups
        """
        status = IOMMUStatus()

        # 1. Parse kernel command line for IOMMU parameters
        cmdline_path = Path("/proc/cmdline")
        if cmdline_path.exists():
            try:
                cmdline = cmdline_path.read_text().strip()
                # Extract all iommu-related parameters
                for param in cmdline.split():
                    param_lower = param.lower()
                    if "iommu" in param_lower:
                        status.kernel_cmdline_iommu_params.append(param)
                        if param_lower in ("intel_iommu=on", "amd_iommu=on", "amd_iommu=force"):
                            status.enabled = True
                        if param_lower == "iommu=pt":
                            status.passthrough = True
                    # iommu=off explicitly disables
                    if param_lower in ("intel_iommu=off", "amd_iommu=off"):
                        status.enabled = False
            except (PermissionError, OSError):
                pass

        # 2. Check for DMAR table (Intel VT-d)
        dmar_path = Path("/sys/firmware/acpi/tables/DMAR")
        status.dmar_table_present = dmar_path.exists()

        # 3. Check IOMMU groups
        iommu_groups_path = Path("/sys/kernel/iommu_groups")
        if iommu_groups_path.exists():
            try:
                groups = [
                    d for d in iommu_groups_path.iterdir()
                    if d.is_dir() and d.name.isdigit()
                ]
                status.groups_count = len(groups)

                # If there are IOMMU groups, IOMMU is active regardless of
                # what the cmdline says (could be enabled by BIOS/UEFI)
                if status.groups_count > 0:
                    status.enabled = True
            except (PermissionError, OSError):
                pass

        # 4. Find which IOMMU groups contain NVIDIA GPUs
        if status.groups_count > 0:
            nvidia_devices = await self.get_nvidia_devices_from_sysfs()
            nvidia_bdfs = {dev.bus_id for dev in nvidia_devices}

            for device_path in sorted(self.SYSFS_PCI_PATH.iterdir()):
                if not device_path.is_dir():
                    continue
                bdf = device_path.name
                if bdf not in nvidia_bdfs:
                    continue

                # Read the iommu_group symlink
                iommu_group_link = device_path / "iommu_group"
                if not iommu_group_link.exists():
                    continue

                try:
                    group_path = iommu_group_link.resolve()
                    group_num_str = group_path.name
                    if not group_num_str.isdigit():
                        continue
                    group_num = int(group_num_str)

                    # Find other devices in the same IOMMU group
                    other_devices = []
                    devices_dir = group_path / "devices"
                    if devices_dir.exists():
                        for peer in sorted(devices_dir.iterdir()):
                            peer_bdf = peer.name
                            if peer_bdf != bdf:
                                other_devices.append(peer_bdf)

                    status.gpu_groups.append(
                        GPUIommuGroup(
                            bus_id=bdf,
                            iommu_group=group_num,
                            other_devices_in_group=other_devices,
                        )
                    )
                except (OSError, ValueError):
                    continue

        return status

    async def run_all_checks(self) -> LspciCheckResult:
        """
        Run all lspci checks matching nvidia-bug-report.sh
        Returns comprehensive result object
        """
        result = LspciCheckResult(timestamp=datetime.now(), lspci_available=self.lspci_path is not None)

        if self.lspci_path:
            # Run all lspci variants
            result.tree_view = await self.run_lspci_tree_view()
            result.devices_list = await self.run_lspci_basic()
            result.verbose_dump = await self.run_lspci_verbose()

            if not result.tree_view:
                result.warnings.append("lspci -nntv failed or returned no output")
            if not result.devices_list:
                result.warnings.append("lspci -nn failed or returned no output")
            if not result.verbose_dump:
                result.warnings.append("lspci -nnDvvvxxxx failed or returned no output")

            # Parse for errors and warnings
            if result.verbose_dump:
                pcie_errors, pcie_warnings = self.parse_lspci_verbose_for_errors(result.verbose_dump)
                result.errors.extend(pcie_errors)
                result.warnings.extend(pcie_warnings)
        else:
            # Fallback to sysfs
            result.warnings.append("lspci not available, using sysfs fallback")
            result.verbose_dump = await self.read_sysfs_fallback()

        # Get NVIDIA devices specifically
        result.nvidia_devices = await self.get_nvidia_devices_from_sysfs()

        if not result.nvidia_devices:
            result.warnings.append("No NVIDIA devices found")

        for device in result.nvidia_devices:
            link_status = self.check_pcie_link_status(device)
            device.link_speed = link_status.get("current_speed")
            device.link_width = link_status.get("current_width")
            try:
                device.aer_counters = self.read_aer_counters(device)
            except Exception:
                result.warnings.append(f"{device.bus_id}: Failed to read AER counters")

            # Check for link degradation
            if "current_speed" in link_status and "max_speed" in link_status:
                if link_status["current_speed"] != link_status["max_speed"]:
                    result.warnings.append(
                        f"{device.bus_id}: PCIe link speed degraded - "
                        f"Running at {link_status['current_speed']}, "
                        f"capable of {link_status['max_speed']}"
                    )

            if "current_width" in link_status and "max_width" in link_status:
                if link_status["current_width"] != link_status["max_width"]:
                    result.warnings.append(
                        f"{device.bus_id}: PCIe link width degraded - "
                        f"Running at x{link_status['current_width']}, "
                        f"capable of x{link_status['max_width']}"
                    )

            if device.aer_counters:
                for label, counts in [
                    ("AER fatal", device.aer_counters.fatal),
                    ("AER nonfatal", device.aer_counters.nonfatal),
                    ("AER correctable", device.aer_counters.correctable),
                ]:
                    if not counts:
                        continue
                    nonzero = {k: v for k, v in counts.items() if v > 0}
                    if nonzero:
                        summary = ", ".join(f"{k}={v}" for k, v in nonzero.items())
                        if "fatal" in label and label != "AER nonfatal":
                            result.errors.append(f"{device.bus_id}: {label} — {summary}")
                        else:
                            result.warnings.append(f"{device.bus_id}: {label} — {summary}")

        # Run ACS and IOMMU checks (P2P readiness)
        try:
            result.acs_status = await self.check_acs_status()
            if result.acs_status.acs_may_block_p2p:
                result.warnings.append(
                    "ACS is enabled on upstream PCIe bridge(s) - "
                    "this may block GPU P2P direct memory access"
                )
        except Exception:
            result.warnings.append("Failed to check ACS status")

        try:
            result.iommu_status = await self.check_iommu_status()
            if result.iommu_status.enabled and not result.iommu_status.passthrough:
                result.warnings.append(
                    "IOMMU is enabled without passthrough mode (iommu=pt) - "
                    "this may interfere with GPU P2P and GPUDirect RDMA"
                )
        except Exception:
            result.warnings.append("Failed to check IOMMU status")

        return result

    def format_report(self, result: LspciCheckResult) -> str:
        """
        Format results as a JSON report.
        ACS and IOMMU status are preserved as diagnostic data.
        """
        result_dict = asdict(result)
        keys_to_remove = ["tree_view", "devices_list", "verbose_dump", "warnings"]
        for key in keys_to_remove:
            result_dict.pop(key, None)
        for device in result_dict.get("nvidia_devices", []):
            device.pop("config_space", None)
        # acs_status and iommu_status are intentionally kept in the output
        return json.dumps(result_dict, indent=4, default=str)


async def run_lspci_diagnostics():
    """Run PCIe diagnostics and return the JSON report."""
    diagnostics = LspciDiagnostics()
    result = await diagnostics.run_all_checks()
    return diagnostics.format_report(result)


