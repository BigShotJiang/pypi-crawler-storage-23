"""
Entry point for brokkr-diagnostics binary
"""

import asyncio
import json
import argparse
from brokkr_diagnostics.runner import run_diagnostics
from brokkr_diagnostics.console import run_command, run_interactive
from brokkr_diagnostics.core.config import get_api_key, set_api_key, get_api_url


# def setup_api_key():
#     """Prompt user for API key and save to config."""
#     current = get_api_key()
#     if current:
#         masked = current[:8] + "..." + current[-4:] if len(current) > 12 else "***"
#         print(f"Current API key: {masked}")
#         confirm = input("Replace it? [y/N]: ").strip().lower()
#         if confirm != "y":
#             print("Keeping existing key.")
#             return

#     key = input("Enter your HydraHost API key: ").strip()
#     if not key:
#         print("No key provided, aborting.")
#         return

#     set_api_key(key)
#     print("API key saved to ~/.config/brokkr/config.json")


def send_diagnostics():
    """Run diagnostics and send results to HydraHost."""
    api_key = get_api_key()
    pass


def main():
    parser = argparse.ArgumentParser(description="NVIDIA GPU Diagnostics Toolkit")
    parser.add_argument("--run", "-r", metavar="COMMAND", help="Run a specific diagnostic")
    parser.add_argument("--interactive", "-i", action="store_true", default=False, help="Launch interactive console")
    # parser.add_argument("--setup", action="store_true", help="Configure HydraHost API key")
    parser.add_argument("--send", "-s", action="store_true", help="Run diagnostics and send to HydraHost")

    args = parser.parse_args()

    match True:
        # case _ if args.setup:
        #     setup_api_key()
        case _ if args.send:
            send_diagnostics()
        case _ if args.run:
            exit(run_command(args.run))
        case _ if args.interactive:
            run_interactive()
        case _:
            print("No arguments provided, use --help for available options.")


if __name__ == "__main__":
    main()

