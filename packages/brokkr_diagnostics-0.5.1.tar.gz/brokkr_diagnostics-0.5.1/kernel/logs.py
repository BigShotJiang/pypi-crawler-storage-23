"""
Kernel Messages & Error Detection diagnostics.

Scans dmesg, journalctl, and log files for error patterns across domains:
NVIDIA GPU, NVSwitch/NVLink, storage/NVMe, IOMMU, memory pressure, and
system stability (hung tasks, lockups).
"""

from typing import List, Optional
from dataclasses import asdict
from datetime import datetime
import re
import json
from ..core.executor import Executor
from ..nvidia.xid import lookup_xid
from .models import (
    KernelError,
    KernelLogsResult,
    LOG_FILES,
    DMESG_PATTERNS,
    CRITICAL_PATTERNS,
    GREP_PATTERNS,
)


class KernelLogsDiagnostics:
    """
    Kernel Messages & Error Detection diagnostics.

    Scans:
    - /var/log/messages, /var/log/kern.log, /var/log/kernel.log, /var/log/dmesg
    - journalctl (current and 2 previous boots)
    - Full dmesg output

    Detects issues across domains:
    - nvidia:   XID errors, GPU fallen off bus, driver failures
    - nvswitch: SXid errors, NVLink failures, version mismatches
    - storage:  NVMe errors, I/O failures, filesystem remount RO
    - iommu:    AMD-Vi / Intel VT-d page faults, DMAR errors
    - memory:   OOM kills, memory cgroup pressure
    - system:   Hung tasks, soft/hard lockups, RCU stalls
    """

    def __init__(self):
        self.executor = Executor()
        self.journalctl_path = self.executor.find_binary("journalctl")
        self.dmesg_path = self.executor.find_binary("dmesg")

    async def read_log_file(self, log_path) -> Optional[str]:
        """Read a log file if it exists and is readable"""
        if not log_path.exists():
            return None

        try:
            return log_path.read_text()
        except Exception:
            return None

    def _match_category(self, line: str) -> Optional[str]:
        """Return the first matching domain category for a log line."""
        for category, patterns in DMESG_PATTERNS.items():
            for pattern in patterns:
                if pattern.search(line):
                    return category
        return None

    async def search_log_file(self, log_path) -> List[tuple[str, str]]:
        """Search log file for all domain patterns. Returns (line, category) pairs."""
        content = await self.read_log_file(log_path)
        if not content:
            return []

        matches = []
        for line in content.split("\n"):
            category = self._match_category(line)
            if category:
                matches.append((line, category))

        return matches

    async def get_dmesg_output(self) -> Optional[list]:
        """Get full dmesg output."""
        if not self.dmesg_path:
            return None

        result = await self.executor.execute(f"sudo {self.dmesg_path} --json --decode")
        if not result:
            return None

        parsed = self._parse_dmesg_json(result)
        if parsed is not None:
            return parsed

        raw = await self.executor.execute(f"sudo {self.dmesg_path} --decode")
        if raw:
            return [{"msg": line} for line in raw.splitlines() if line.strip()]
        return None

    @staticmethod
    def _parse_dmesg_json(text: str) -> Optional[list]:
        """Try to extract structured entries from dmesg JSON output.

        Handles the standard util-linux format (``{"dmesg": [...]}``) as well
        as a bare JSON array or JSON-Lines (one object per line).
        """
        try:
            parsed = json.loads(text)
            if isinstance(parsed, dict):
                if "dmesg" in parsed:
                    return parsed["dmesg"]
                for value in parsed.values():
                    if isinstance(value, list):
                        return value
            if isinstance(parsed, list):
                return parsed
        except json.JSONDecodeError:
            pass

        entries = []
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return entries or None

    async def get_journalctl_messages(self, boot_offset: int = 0) -> Optional[str]:
        """
        Get messages matching any domain pattern from journalctl for a specific boot.
        boot_offset: 0 = current, -1 = previous, -2 = 2 boots ago
        """
        if not self.journalctl_path:
            return None

        boot_arg = f"-{abs(boot_offset)}" if boot_offset != 0 else "-0"

        grep_pattern = "|".join(GREP_PATTERNS)

        cmd = f"sudo {self.journalctl_path} -b {boot_arg} | grep -iE '{grep_pattern}'"
        result = await self.executor.execute(cmd)

        return result if result else None

    def classify_error(self, message: str, category: Optional[str] = None) -> tuple[str, Optional[str]]:
        """
        Classify error severity and type.
        Returns: (severity, error_type)
        """
        message_lower = message.lower()

        if CRITICAL_PATTERNS["fallen_off_bus"].search(message) or CRITICAL_PATTERNS["gpu_lost"].search(message):
            return ("critical", "fallen_off_bus")

        xid_match = CRITICAL_PATTERNS["xid"].search(message)
        if xid_match:
            xid_code = int(xid_match.group(1))
            xid_info = lookup_xid(xid_code)
            return (xid_info.severity, f"xid_{xid_code}: {xid_info.name} - {xid_info.description} (action: {xid_info.action})")

        sxid_match = CRITICAL_PATTERNS["sxid"].search(message)
        if sxid_match:
            return ("critical", f"sxid_{sxid_match.group(1)}")

        if CRITICAL_PATTERNS["oom_kill"].search(message):
            return ("critical", "oom_kill")

        if CRITICAL_PATTERNS["fs_readonly"].search(message):
            return ("critical", "fs_readonly")

        if CRITICAL_PATTERNS["lockup"].search(message):
            return ("critical", "lockup")

        for error_type, pattern in CRITICAL_PATTERNS.items():
            if error_type in ("xid", "sxid", "fallen_off_bus", "oom_kill", "fs_readonly", "lockup"):
                continue
            if pattern.search(message):
                return ("error", error_type)

        if "error" in message_lower or "fail" in message_lower:
            return ("error", None)
        elif "warning" in message_lower or "warn" in message_lower:
            return ("warning", None)
        else:
            return ("info", None)

    def parse_timestamp(self, line: str) -> Optional[str]:
        """Extract timestamp from log line if present"""
        kernel_ts = re.match(r"^\[(\s*\d+\.\d+)\]", line)
        if kernel_ts:
            return kernel_ts.group(1).strip()

        syslog_ts = re.match(r"^(\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})", line)
        if syslog_ts:
            return syslog_ts.group(1)

        iso_ts = re.match(r"^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})", line)
        if iso_ts:
            return iso_ts.group(1)

        return None

    async def analyze_messages(
        self, messages: List[tuple[str, str]], source: str
    ) -> List[KernelError]:
        """Analyze (message, category) pairs and create KernelError objects."""
        errors = []
        for message, category in messages:
            timestamp = self.parse_timestamp(message)
            severity, error_type = self.classify_error(message, category)
            errors.append(KernelError(
                timestamp=timestamp,
                message=message.strip(),
                source=source,
                severity=severity,
                error_type=error_type,
                category=category,
            ))
        return errors

    async def run_all_checks(self) -> KernelLogsResult:
        """Run all kernel log checks."""
        result = KernelLogsResult(timestamp=datetime.now())

        result.dmesg_output = await self.get_dmesg_output()
        if not result.dmesg_output:
            result.warnings.append("Could not retrieve dmesg output")

        for log_file in LOG_FILES:
            result.sources_checked.append(str(log_file))

            matches = await self.search_log_file(log_file)
            if matches:
                result.sources_found.append(str(log_file))
                result.nvidia_messages.extend(
                    msg for msg, cat in matches if cat in ("nvidia", "nvswitch")
                )
                file_errors = await self.analyze_messages(matches, str(log_file))
                result.errors.extend(file_errors)

        if self.journalctl_path:
            for boot_offset in [0, -1, -2]:
                boot_label = f"journalctl boot {boot_offset}"
                result.sources_checked.append(boot_label)

                raw = await self.get_journalctl_messages(boot_offset)
                if raw:
                    result.sources_found.append(boot_label)
                    tagged: List[tuple[str, str]] = []
                    for line in raw.split("\n"):
                        cat = self._match_category(line)
                        if cat:
                            tagged.append((line, cat))
                            if cat in ("nvidia", "nvswitch"):
                                result.nvidia_messages.append(line)
                    journal_errors = await self.analyze_messages(tagged, boot_label)
                    result.errors.extend(journal_errors)
        else:
            result.warnings.append("journalctl not available")

        _category_buckets = {
            "storage": result.storage_errors,
            "iommu": result.iommu_errors,
            "memory": result.oom_events,
            "system": result.hung_tasks,
            "nvswitch": result.nvswitch_errors,
        }
        for error in result.errors:
            if error.severity == "critical":
                result.critical_errors.append(error)
            if error.error_type and error.error_type.startswith("xid_"):
                result.xid_errors.append(error)
            bucket = _category_buckets.get(error.category)
            if bucket is not None:
                bucket.append(error)

        if not result.sources_found:
            result.warnings.append("No matching messages found in any log source")
        if result.xid_errors:
            result.warnings.append(f"Found {len(result.xid_errors)} XID errors (GPU hardware errors)")
        if result.critical_errors:
            result.warnings.append(f"Found {len(result.critical_errors)} critical errors")
        if result.storage_errors:
            result.warnings.append(f"Found {len(result.storage_errors)} storage/NVMe errors")
        if result.iommu_errors:
            result.warnings.append(f"Found {len(result.iommu_errors)} IOMMU faults")
        if result.oom_events:
            result.warnings.append(f"Found {len(result.oom_events)} OOM events")
        if result.hung_tasks:
            result.warnings.append(f"Found {len(result.hung_tasks)} hung task / lockup warnings")
        if result.nvswitch_errors:
            result.warnings.append(f"Found {len(result.nvswitch_errors)} NVSwitch/SXid errors")

        return result

    def format_report(self, result: KernelLogsResult) -> str:
        """Format results as a JSON report."""
        result_dict = asdict(result)
        result_dict.pop("warnings", None)
        return json.dumps(result_dict, indent=4, default=str)


async def run_kernel_logs_diagnostics():
    """Run kernel logs diagnostics and return the JSON report."""
    diagnostics = KernelLogsDiagnostics()
    result = await diagnostics.run_all_checks()
    return diagnostics.format_report(result)
