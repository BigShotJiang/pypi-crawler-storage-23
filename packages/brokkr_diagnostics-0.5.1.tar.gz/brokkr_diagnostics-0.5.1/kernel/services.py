"""
NVIDIA SystemD Services Diagnostics.
Replicates systemd service checks from nvidia-bug-report.sh lines 995-1009.
"""

from typing import Dict, List, Optional
from dataclasses import dataclass, field, asdict
from datetime import datetime
import json
from ..core.executor import Executor


@dataclass
class ServiceStatus:
    """Status of a single systemd service"""

    name: str
    exists: bool
    active: bool
    status: Optional[str] = None
    error_message: Optional[str] = None
    full_output: Optional[str] = None


@dataclass
class NvidiaServicesResult:
    """Results from NVIDIA service diagnostics"""

    timestamp: datetime
    services: Dict[str, ServiceStatus] = field(default_factory=dict)
    systemctl_available: bool = True
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


class NvidiaServicesDiagnostics:
    NVIDIA_SERVICES = [
        "nvidia-suspend.service",
        "nvidia-hibernate.service",
        "nvidia-resume.service",
        "nvidia-powerd.service",
        "nvidia-persistenced.service",
        "nvidia-fabricmanager.service",
    ]

    def __init__(self):
        self.executor = Executor()
        self.systemctl_path = self.executor.find_binary("systemctl")

    async def get_service_status(self, service_name: str) -> ServiceStatus:
        """
        Get status of a single systemd service

        Returns parsed service status including whether it's active, failed, or not found
        """
        service = ServiceStatus(name=service_name, exists=False, active=False)

        if not self.systemctl_path:
            service.error_message = "systemctl not available"
            return service

        # Run systemctl status
        cmd = f"sudo {self.systemctl_path} status {service_name}"
        output = await self.executor.execute(cmd, timeout=10, allow_nonzero=True)

        if output:
            service.full_output = output
            service.exists = True

            # Parse status from output
            for line in output.split("\n"):
                line_lower = line.lower()

                # Look for Active: line
                if "active:" in line_lower:
                    if "active (running)" in line_lower:
                        service.status = "active"
                        service.active = True
                    elif "active (exited)" in line_lower:
                        service.status = "active (exited)"
                        service.active = True
                    elif "inactive" in line_lower:
                        service.status = "inactive"
                    elif "failed" in line_lower:
                        service.status = "failed"
                        service.error_message = "Service failed"
                    elif "activating" in line_lower:
                        service.status = "activating"
                    break
        else:
            service.exists = False
            service.status = "not-found"
            service.error_message = "Service not found or not loaded"

        return service

    async def run_all_checks(self) -> NvidiaServicesResult:
        """Check all NVIDIA services"""
        result = NvidiaServicesResult(timestamp=datetime.now())

        if not self.systemctl_path:
            result.systemctl_available = False
            result.errors.append("systemctl not available - cannot check services")
            return result

        # Check each service
        for service_name in self.NVIDIA_SERVICES:
            service_status = await self.get_service_status(service_name)
            result.services[service_name] = service_status

            # Add warnings for problematic services
            if service_status.status == "failed":
                result.warnings.append(f"{service_name} is in failed state")
            elif not service_status.exists and service_name in [
                "nvidia-persistenced.service",
                "nvidia-fabricmanager.service",
            ]:
                # These services are optional but good to note
                result.warnings.append(f"{service_name} is not installed (may be optional)")

        return result

    def format_report(self, result: NvidiaServicesResult) -> str:
        """Format results as a JSON report."""
        result_dict = asdict(result)
        result_dict.pop("warnings", None)
        return json.dumps(result_dict, indent=4, default=str)


async def run_nvidia_services_diagnostics():
    """Run NVIDIA services diagnostics and return the JSON report."""
    diagnostics = NvidiaServicesDiagnostics()
    result = await diagnostics.run_all_checks()
    return diagnostics.format_report(result)


