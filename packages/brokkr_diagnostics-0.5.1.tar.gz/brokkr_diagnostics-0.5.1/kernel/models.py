"""Kernel diagnostics data models, patterns, and configuration."""

import re
from pathlib import Path
from typing import List, Optional
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class KernelError:
    """Represents a kernel error message"""

    timestamp: Optional[str]
    message: str
    source: str  # Which log file/source
    severity: str  # 'critical', 'error', 'warning', 'info'
    error_type: Optional[str] = None  # 'xid', 'fallen_off_bus', 'irq', 'dma', etc.
    category: Optional[str] = None  # 'nvidia', 'nvswitch', 'storage', 'iommu', 'memory', 'system'


@dataclass
class KernelLogsResult:
    """Results from kernel log diagnostics"""

    timestamp: datetime
    dmesg_output: Optional[list] = None
    nvidia_messages: List[str] = field(default_factory=list)
    errors: List[KernelError] = field(default_factory=list)
    xid_errors: List[KernelError] = field(default_factory=list)
    critical_errors: List[KernelError] = field(default_factory=list)
    storage_errors: List[KernelError] = field(default_factory=list)
    iommu_errors: List[KernelError] = field(default_factory=list)
    oom_events: List[KernelError] = field(default_factory=list)
    hung_tasks: List[KernelError] = field(default_factory=list)
    nvswitch_errors: List[KernelError] = field(default_factory=list)
    sources_checked: List[str] = field(default_factory=list)
    sources_found: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


LOG_FILES = [
    Path("/var/log/messages"),
    Path("/var/log/kern.log"),
    Path("/var/log/kernel.log"),
    Path("/var/log/dmesg"),
]

DMESG_PATTERNS: dict[str, list[re.Pattern]] = {
    "nvidia": [
        re.compile(r"NVRM", re.IGNORECASE),
        re.compile(r"nvidia-"),
        re.compile(r"nvrm-nvlog"),
        re.compile(r"nvidia-powerd"),
    ],
    "nvswitch": [
        re.compile(r"(?<!open)\bnvswitch\b", re.IGNORECASE),
        re.compile(r"\bnv_switch\b", re.IGNORECASE),
        re.compile(r"\bSXid\b"),
        re.compile(r"\bnv-fabricmanager\b", re.IGNORECASE),
    ],
    "storage": [
        re.compile(r"\bnvme\b", re.IGNORECASE),
        re.compile(r"blk_update_request", re.IGNORECASE),
        re.compile(r"Buffer I/O error", re.IGNORECASE),
        re.compile(r"EXT4-fs error", re.IGNORECASE),
        re.compile(r"aborting journal", re.IGNORECASE),
        re.compile(r"\bJBD2\b"),
        re.compile(r"md/raid", re.IGNORECASE),
        re.compile(r"disk failure", re.IGNORECASE),
    ],
    "iommu": [
        re.compile(r"\bAMD-Vi\b"),
        re.compile(r"\bDMAR\b"),
        re.compile(r"IO_PAGE_FAULT"),
    ],
    "memory": [
        re.compile(r"out of memory", re.IGNORECASE),
        re.compile(r"invoked oom-killer", re.IGNORECASE),
        re.compile(r"killed process", re.IGNORECASE),
        re.compile(r"memory cgroup", re.IGNORECASE),
    ],
    "system": [
        re.compile(r"blocked for more than", re.IGNORECASE),
        re.compile(r"soft lockup", re.IGNORECASE),
        re.compile(r"hard lockup", re.IGNORECASE),
        re.compile(r"RCU.*stall", re.IGNORECASE),
        re.compile(r"watchdog.*hard LOCKUP", re.IGNORECASE),
    ],
}

CRITICAL_PATTERNS = {
    "xid": re.compile(r"NVRM:.*Xid.*:\s*(\d+)", re.IGNORECASE),
    "sxid": re.compile(r"SXid.*:\s*(\d+)", re.IGNORECASE),
    "fallen_off_bus": re.compile(r"fallen off.*bus", re.IGNORECASE),
    "gpu_lost": re.compile(r"GPU.*has been lost", re.IGNORECASE),
    "irq": re.compile(r"(IRQ|interrupt).*fail", re.IGNORECASE),
    "dma": re.compile(r"DMA.*error|mapping.*fail", re.IGNORECASE),
    "timeout": re.compile(r"timeout|timed out", re.IGNORECASE),
    "hung": re.compile(r"hung|hang", re.IGNORECASE),
    "failed": re.compile(r"failed to (initialize|allocate|map)", re.IGNORECASE),
    "io_error": re.compile(r"Buffer I/O error|blk_update_request.*error", re.IGNORECASE),
    "fs_readonly": re.compile(r"remounting.*read.only|EXT4-fs error", re.IGNORECASE),
    "oom_kill": re.compile(r"out of memory.*killed process|invoked oom-killer", re.IGNORECASE),
    "iommu_fault": re.compile(r"IO_PAGE_FAULT|AMD-Vi.*event|DMAR.*fault", re.IGNORECASE),
    "lockup": re.compile(r"soft lockup|hard lockup|RCU.*stall", re.IGNORECASE),
}

GREP_PATTERNS = [
    "NVRM", "nvidia-", "nvrm-nvlog", "nvidia-powerd",
    "nvswitch", "nv_switch", "SXid", "nv-fabricmanager",
    "nvme", "blk_update_request", "Buffer I/O error",
    "EXT4-fs error", "aborting journal", "JBD2",
    "md/raid", "disk failure",
    "AMD-Vi", "DMAR", "IO_PAGE_FAULT",
    "out of memory", "invoked oom-killer", "killed process", "memory cgroup",
    "blocked for more than", "soft lockup", "hard lockup",
    "RCU.*stall", "watchdog.*hard LOCKUP",
]
