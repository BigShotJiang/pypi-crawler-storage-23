"""Configuration management for brokkr-diagnostics."""

import json
from pathlib import Path
from typing import Optional

CONFIG_DIR = Path.home() / ".config" / "brokkr"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_API_URL = "https://api.hydrahost.com/v1/diagnostics"


def _load_config() -> dict:
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except (json.JSONDecodeError, PermissionError):
            return {}
    return {}


def _save_config(config: dict):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2))


def get_api_key() -> Optional[str]:
    return _load_config().get("api_key")


def set_api_key(key: str):
    config = _load_config()
    config["api_key"] = key
    _save_config(config)


def get_api_url() -> str:
    return _load_config().get("api_url", DEFAULT_API_URL)


def set_api_url(url: str):
    config = _load_config()
    config["api_url"] = url
    _save_config(config)
