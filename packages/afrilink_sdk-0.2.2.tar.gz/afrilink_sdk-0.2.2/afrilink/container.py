"""
AfriLink Container Module

Handles Docker container creation and Singularity image conversion for
HPC job execution. Bundles Python environment, dependencies, model weights,
and datasets into portable containers.

Key Features:
- Dockerfile generation for finetune environments
- Singularity image conversion (Docker -> SIF)
- HuggingFace model pre-downloading for offline use
- CINECA-compatible: no internet required at runtime
"""

import os
import sys
import json
import subprocess
import tempfile
import shutil
from pathlib import Path
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, field


@dataclass
class ContainerSpec:
    """Specification for building a container"""
    name: str
    python_version: str = "3.10"
    base_image: str = "nvidia/cuda:12.1.0-cudnn8-devel-ubuntu22.04"

    # Core SDK dependencies
    sdk_dependencies: List[str] = field(default_factory=lambda: [
        "requests>=2.28.0",
        "psutil>=5.9.0",
    ])

    # ML/Training dependencies
    training_dependencies: List[str] = field(default_factory=lambda: [
        "torch>=2.1.0",
        "transformers>=4.36.0",
        "datasets>=2.16.0",
        "accelerate>=0.25.0",
        "peft>=0.7.0",
        "bitsandbytes>=0.41.0",
        "safetensors>=0.4.0",
        "tqdm>=4.66.0",
        "wandb>=0.16.0",
        "sentencepiece>=0.1.99",
        "tokenizers>=0.15.0",
        "huggingface_hub>=0.20.0",
    ])

    # User-specified additional dependencies
    extra_dependencies: List[str] = field(default_factory=list)

    # HuggingFace model configuration (replaces git repos)
    # These are HF repo IDs that will be pre-downloaded into the container
    hf_models: List[str] = field(default_factory=list)
    hf_datasets: List[str] = field(default_factory=list)

    # AfriLink aggregated repos (default sources)
    use_aggregated_repo: bool = True
    aggregated_models_org: str = "dataspires"

    # HuggingFace authentication for private repos
    # Token is passed as build arg, NOT baked into image
    hf_token_required: bool = False  # Set True for private repos

    # Build options
    use_flash_attention: bool = True
    use_deepspeed: bool = False
    cuda_version: str = "12.1"

    # Output paths
    output_dir: Optional[str] = None


class ContainerBuilder:
    """
    Builds Docker containers and converts them to Singularity images
    for HPC deployment.

    Models are pre-downloaded from HuggingFace into the container
    for offline operation on CINECA compute nodes.
    """

    # Template for Dockerfile with HuggingFace model pre-download
    DOCKERFILE_TEMPLATE = '''
# AfriLink Finetune Container
# Generated automatically - do not edit manually

FROM {base_image}

# Set environment variables
ENV PYTHONDONTWRITEBYTECODE=1
ENV PYTHONUNBUFFERED=1
ENV DEBIAN_FRONTEND=noninteractive
ENV HF_HOME=/workspace/.cache/huggingface
ENV HF_HUB_OFFLINE=1
ENV TRANSFORMERS_OFFLINE=1
ENV TRANSFORMERS_CACHE=/workspace/.cache/transformers
ENV TORCH_HOME=/workspace/.cache/torch

# Install system dependencies
RUN apt-get update && apt-get install -y --no-install-recommends \\
    python{python_version} \\
    python{python_version}-pip \\
    python{python_version}-dev \\
    python3-venv \\
    git \\
    git-lfs \\
    wget \\
    curl \\
    vim \\
    openssh-client \\
    && rm -rf /var/lib/apt/lists/*

# Set Python aliases
RUN ln -sf /usr/bin/python{python_version} /usr/bin/python && \\
    ln -sf /usr/bin/python{python_version} /usr/bin/python3 && \\
    ln -sf /usr/bin/pip3 /usr/bin/pip

# Upgrade pip
RUN pip install --upgrade pip setuptools wheel

# Create workspace directory
WORKDIR /workspace

# Install PyTorch with CUDA support
RUN pip install --no-cache-dir \\
    torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu{cuda_version_short}

{flash_attention_install}

{deepspeed_install}

# Install SDK dependencies
RUN pip install --no-cache-dir \\
{sdk_deps}

# Install training dependencies
RUN pip install --no-cache-dir \\
{training_deps}

# Install extra dependencies
{extra_deps_install}

# Pre-download HuggingFace models for offline use
{hf_model_downloads}

# Pre-download HuggingFace datasets for offline use
{hf_dataset_downloads}

# Copy entrypoint script
COPY entrypoint.sh /workspace/entrypoint.sh
RUN chmod +x /workspace/entrypoint.sh

# Copy training scripts
COPY train/ /workspace/train/

# Set entrypoint
ENTRYPOINT ["/workspace/entrypoint.sh"]
'''

    ENTRYPOINT_TEMPLATE = '''#!/bin/bash
# AfriLink Container Entrypoint
# Handles distributed training setup and job execution

set -e

echo "================================================"
echo "AfriLink Finetune Container"
echo "================================================"

# Ensure offline mode for HuggingFace
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export HF_HOME=/workspace/.cache/huggingface
export TRANSFORMERS_CACHE=/workspace/.cache/transformers

# Show GPU info
if command -v nvidia-smi &> /dev/null; then
    echo ""
    echo "GPU Configuration:"
    nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv
    echo ""
fi

# Set up distributed training environment variables if needed
if [ -n "$SLURM_JOB_ID" ]; then
    echo "Running under SLURM (Job ID: $SLURM_JOB_ID)"

    # SLURM distributed setup
    export MASTER_ADDR=$(scontrol show hostnames $SLURM_JOB_NODELIST | head -n 1)
    export MASTER_PORT=${MASTER_PORT:-29500}
    export WORLD_SIZE=${SLURM_NTASKS:-1}
    export RANK=${SLURM_PROCID:-0}
    export LOCAL_RANK=${SLURM_LOCALID:-0}

    echo "Distributed Config:"
    echo "  MASTER_ADDR: $MASTER_ADDR"
    echo "  MASTER_PORT: $MASTER_PORT"
    echo "  WORLD_SIZE: $WORLD_SIZE"
    echo "  RANK: $RANK"
    echo "  LOCAL_RANK: $LOCAL_RANK"
fi

# Execute the provided command or default training script
if [ $# -eq 0 ]; then
    echo "No command provided, running default training..."
    python /workspace/train/finetune.py
else
    echo "Executing: $@"
    exec "$@"
fi
'''

    # Script to pre-download HF models during container build
    # Uses HF_TOKEN build arg for private repos (token not baked into final image)
    HF_DOWNLOAD_SCRIPT = '''
# Download {model_id} from HuggingFace
RUN --mount=type=secret,id=hf_token,target=/run/secrets/hf_token \\
    HF_TOKEN=$(cat /run/secrets/hf_token 2>/dev/null || echo "") && \\
    python -c "import os; from huggingface_hub import snapshot_download; \\
    snapshot_download('{hf_repo}', local_dir='/workspace/models/{model_id}', \\
    local_dir_use_symlinks=False, token=os.environ.get('HF_TOKEN') or None)"
'''

    # Alternative download script for builds without secrets support
    HF_DOWNLOAD_SCRIPT_SIMPLE = '''
# Download {model_id} from HuggingFace
# For private repos, set HF_TOKEN env var before build
RUN python -c "import os; from huggingface_hub import snapshot_download; \\
    snapshot_download('{hf_repo}', local_dir='/workspace/models/{model_id}', \\
    local_dir_use_symlinks=False, token=os.environ.get('HF_TOKEN') or None)"
'''

    HF_DATASET_DOWNLOAD_SCRIPT = '''
# Download dataset {dataset_id} from HuggingFace
RUN --mount=type=secret,id=hf_token,target=/run/secrets/hf_token \\
    HF_TOKEN=$(cat /run/secrets/hf_token 2>/dev/null || echo "") && \\
    python -c "import os; from huggingface_hub import snapshot_download; \\
    snapshot_download('{hf_repo}', repo_type='dataset', \\
    local_dir='/workspace/datasets/{dataset_id}', local_dir_use_symlinks=False, \\
    token=os.environ.get('HF_TOKEN') or None)"
'''

    HF_DATASET_DOWNLOAD_SCRIPT_SIMPLE = '''
# Download dataset {dataset_id} from HuggingFace
RUN python -c "import os; from huggingface_hub import snapshot_download; \\
    snapshot_download('{hf_repo}', repo_type='dataset', \\
    local_dir='/workspace/datasets/{dataset_id}', local_dir_use_symlinks=False, \\
    token=os.environ.get('HF_TOKEN') or None)"
'''

    def __init__(self, spec: ContainerSpec):
        """
        Initialize container builder.

        Args:
            spec: ContainerSpec with build configuration
        """
        self.spec = spec
        self.build_dir = None

    def _format_deps_list(self, deps: List[str], indent: int = 4) -> str:
        """Format a list of dependencies for Dockerfile"""
        if not deps:
            return ""
        prefix = " " * indent
        return " \\\n".join(f"{prefix}{dep}" for dep in deps)

    def _generate_hf_downloads(self, use_secrets: bool = True) -> str:
        """Generate HuggingFace model download commands"""
        if not self.spec.hf_models:
            return "# No HuggingFace models specified"

        # Use secrets-based download for private repos, simple for public
        template = self.HF_DOWNLOAD_SCRIPT if use_secrets else self.HF_DOWNLOAD_SCRIPT_SIMPLE

        downloads = []
        for model_spec in self.spec.hf_models:
            # model_spec can be "model_id" or "model_id:hf_repo_id"
            if ":" in model_spec:
                model_id, hf_repo = model_spec.split(":", 1)
            else:
                model_id = model_spec
                # Use aggregated repo if enabled
                if self.spec.use_aggregated_repo:
                    hf_repo = f"{self.spec.aggregated_models_org}/afrilink-{model_id}"
                else:
                    hf_repo = model_spec

            downloads.append(
                template.format(
                    model_id=model_id,
                    hf_repo=hf_repo,
                )
            )

        return "\n".join(downloads)

    def _generate_hf_dataset_downloads(self, use_secrets: bool = True) -> str:
        """Generate HuggingFace dataset download commands"""
        if not self.spec.hf_datasets:
            return "# No HuggingFace datasets specified"

        template = self.HF_DATASET_DOWNLOAD_SCRIPT if use_secrets else self.HF_DATASET_DOWNLOAD_SCRIPT_SIMPLE

        downloads = []
        for dataset_spec in self.spec.hf_datasets:
            if ":" in dataset_spec:
                dataset_id, hf_repo = dataset_spec.split(":", 1)
            else:
                dataset_id = dataset_spec
                if self.spec.use_aggregated_repo:
                    hf_repo = f"{self.spec.aggregated_models_org}/afrilink-dataset-{dataset_id}"
                else:
                    hf_repo = dataset_spec

            downloads.append(
                template.format(
                    dataset_id=dataset_id,
                    hf_repo=hf_repo,
                )
            )

        return "\n".join(downloads)

    def generate_dockerfile(self) -> str:
        """Generate Dockerfile content from spec"""
        # Format CUDA version for PyTorch URL (e.g., "12.1" -> "121")
        cuda_short = self.spec.cuda_version.replace(".", "")

        # Flash attention install
        flash_install = ""
        if self.spec.use_flash_attention:
            flash_install = "# Install Flash Attention 2\nRUN pip install --no-cache-dir flash-attn --no-build-isolation"

        # DeepSpeed install
        deepspeed_install = ""
        if self.spec.use_deepspeed:
            deepspeed_install = "# Install DeepSpeed\nRUN pip install --no-cache-dir deepspeed"

        # Extra dependencies
        extra_install = ""
        if self.spec.extra_dependencies:
            extra_deps = self._format_deps_list(self.spec.extra_dependencies)
            extra_install = f"RUN pip install --no-cache-dir \\\n{extra_deps}"

        # Use secrets-based download for private repos
        use_secrets = self.spec.hf_token_required

        return self.DOCKERFILE_TEMPLATE.format(
            base_image=self.spec.base_image,
            python_version=self.spec.python_version,
            cuda_version_short=cuda_short,
            flash_attention_install=flash_install,
            deepspeed_install=deepspeed_install,
            sdk_deps=self._format_deps_list(self.spec.sdk_dependencies),
            training_deps=self._format_deps_list(self.spec.training_dependencies),
            extra_deps_install=extra_install,
            hf_model_downloads=self._generate_hf_downloads(use_secrets),
            hf_dataset_downloads=self._generate_hf_dataset_downloads(use_secrets),
        )

    def generate_entrypoint(self) -> str:
        """Generate entrypoint script"""
        return self.ENTRYPOINT_TEMPLATE

    def generate_training_script(self) -> str:
        """Generate default training script"""
        return '''#!/usr/bin/env python3
"""
AfriLink Default Finetuning Script

This script is executed inside the Singularity container on CINECA.
It loads model/data from local paths (pre-downloaded into container).
"""

import os
import sys
import json
import torch
from pathlib import Path

# Ensure offline mode
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"

from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling,
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from datasets import load_from_disk

def main():
    # Load job config from environment or file
    config_path = os.environ.get("JOB_CONFIG", "/workspace/job_config.json")

    if os.path.exists(config_path):
        with open(config_path) as f:
            config = json.load(f)
    else:
        # Default config
        config = {
            "model_path": "/workspace/models/qwen2.5-0.5b",
            "dataset_path": "/workspace/datasets/alpaca",
            "output_dir": os.environ.get("OUTPUT_DIR", "/workspace/output"),
            "lora_r": 8,
            "lora_alpha": 16,
            "batch_size": 2,
            "gradient_accumulation_steps": 8,
            "num_epochs": 3,
            "learning_rate": 2e-4,
        }

    print(f"Job Configuration:")
    print(json.dumps(config, indent=2))

    # Load tokenizer and model from local path
    model_path = config["model_path"]
    print(f"\\nLoading model from: {model_path}")

    tokenizer = AutoTokenizer.from_pretrained(
        model_path,
        trust_remote_code=True,
        local_files_only=True,
    )

    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        torch_dtype=torch.bfloat16,
        device_map="auto",
        trust_remote_code=True,
        local_files_only=True,
    )

    # Apply LoRA
    lora_config = LoraConfig(
        r=config.get("lora_r", 8),
        lora_alpha=config.get("lora_alpha", 16),
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM",
    )

    model = prepare_model_for_kbit_training(model)
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    # Load dataset from local path
    dataset_path = config["dataset_path"]
    print(f"\\nLoading dataset from: {dataset_path}")

    if os.path.isdir(dataset_path):
        dataset = load_from_disk(dataset_path)
    else:
        from datasets import load_dataset
        dataset = load_dataset("json", data_files=dataset_path, split="train")

    # Tokenize
    def tokenize(example):
        return tokenizer(
            example.get("text", example.get("instruction", "")),
            truncation=True,
            max_length=1024,
            padding="max_length",
        )

    tokenized = dataset.map(tokenize, batched=True, remove_columns=dataset.column_names)

    # Training arguments
    output_dir = config["output_dir"]
    training_args = TrainingArguments(
        output_dir=output_dir,
        num_train_epochs=config.get("num_epochs", 3),
        per_device_train_batch_size=config.get("batch_size", 2),
        gradient_accumulation_steps=config.get("gradient_accumulation_steps", 8),
        learning_rate=config.get("learning_rate", 2e-4),
        warmup_ratio=0.03,
        logging_steps=10,
        save_steps=100,
        save_total_limit=2,
        bf16=True,
        gradient_checkpointing=True,
        report_to="none",
    )

    # Trainer
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized,
        data_collator=DataCollatorForLanguageModeling(tokenizer, mlm=False),
    )

    # Train
    print("\\nStarting training...")
    trainer.train()

    # Save
    print(f"\\nSaving model to: {output_dir}")
    trainer.save_model(output_dir)
    tokenizer.save_pretrained(output_dir)

    print("\\nTraining complete!")

if __name__ == "__main__":
    main()
'''

    def setup_build_directory(self, output_dir: str = None) -> Path:
        """
        Set up build directory with Dockerfile and scripts.

        Args:
            output_dir: Output directory (default: temp dir)

        Returns:
            Path to build directory
        """
        if output_dir:
            self.build_dir = Path(output_dir)
            self.build_dir.mkdir(parents=True, exist_ok=True)
        else:
            self.build_dir = Path(tempfile.mkdtemp(prefix="afrilink_"))

        # Write Dockerfile
        dockerfile_path = self.build_dir / "Dockerfile"
        dockerfile_path.write_text(self.generate_dockerfile())
        print(f"Generated Dockerfile: {dockerfile_path}")

        # Write entrypoint
        entrypoint_path = self.build_dir / "entrypoint.sh"
        entrypoint_path.write_text(self.generate_entrypoint())
        print(f"Generated entrypoint: {entrypoint_path}")

        # Create train directory with default script
        train_dir = self.build_dir / "train"
        train_dir.mkdir(exist_ok=True)

        train_script = train_dir / "finetune.py"
        train_script.write_text(self.generate_training_script())
        print(f"Generated training script: {train_script}")

        return self.build_dir

    def build_docker_image(self, tag: Optional[str] = None, hf_token: Optional[str] = None) -> bool:
        """
        Build Docker image from the generated Dockerfile.

        Args:
            tag: Docker image tag (default: afrilink-{spec.name})
            hf_token: HuggingFace token for private repos (passed securely via --secret)

        Returns:
            True if build succeeded

        For private HuggingFace repos, pass your HF token:
            builder.build_docker_image(hf_token="hf_xxxx")

        Or set HF_TOKEN environment variable before calling.
        The token is NOT baked into the final image.
        """
        if not self.build_dir:
            raise RuntimeError("Call setup_build_directory() first")

        tag = tag or f"afrilink-{self.spec.name}"

        print(f"Building Docker image: {tag}")
        print(f"Build context: {self.build_dir}")

        # Get HF token from parameter or environment
        hf_token = hf_token or os.environ.get("HF_TOKEN", "")

        # Build command
        cmd = ["docker", "build", "-t", tag]

        # For private repos, use Docker BuildKit secrets
        if self.spec.hf_token_required and hf_token:
            # Create a temporary file for the secret
            secret_file = self.build_dir / ".hf_token"
            secret_file.write_text(hf_token)

            # Enable BuildKit and use secret mount
            env = os.environ.copy()
            env["DOCKER_BUILDKIT"] = "1"

            cmd.extend(["--secret", f"id=hf_token,src={secret_file}"])
            print("Using HF token for private repo access (token not stored in image)")
        else:
            env = None

        cmd.append(".")

        result = subprocess.run(
            cmd,
            cwd=self.build_dir,
            capture_output=True,
            text=True,
            env=env,
        )

        # Clean up secret file
        secret_file = self.build_dir / ".hf_token"
        if secret_file.exists():
            secret_file.unlink()

        if result.returncode != 0:
            print(f"Docker build failed:\n{result.stderr}")
            return False

        print(f"Docker image built: {tag}")
        return True

    def convert_to_singularity(
        self,
        docker_tag: str,
        sif_path: str = None,
    ) -> Optional[str]:
        """
        Convert Docker image to Singularity SIF format.

        Args:
            docker_tag: Docker image tag to convert
            sif_path: Output SIF file path

        Returns:
            Path to SIF file or None if failed
        """
        sif_path = sif_path or f"{self.spec.name}.sif"

        print(f"Converting to Singularity: {docker_tag} -> {sif_path}")

        # Check if singularity is available
        result = subprocess.run(
            ["which", "singularity"],
            capture_output=True,
            text=True,
        )

        if result.returncode != 0:
            print("Singularity not available locally.")
            print("To convert on CINECA login node, run:")
            print(f"  singularity build {sif_path} docker://{docker_tag}")
            return None

        # Build Singularity image from Docker
        result = subprocess.run(
            ["singularity", "build", sif_path, f"docker://{docker_tag}"],
            capture_output=True,
            text=True,
        )

        if result.returncode != 0:
            print(f"Singularity conversion failed:\n{result.stderr}")
            return None

        print(f"Singularity image created: {sif_path}")
        return sif_path


def detect_runtime_dependencies() -> List[str]:
    """
    Detect installed packages in the current Python environment.
    Useful for capturing Colab runtime state.

    Returns:
        List of package specifications (name==version)
    """
    try:
        import pkg_resources
        return [
            f"{pkg.key}=={pkg.version}"
            for pkg in pkg_resources.working_set
        ]
    except ImportError:
        # Fallback to pip freeze
        result = subprocess.run(
            [sys.executable, "-m", "pip", "freeze"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            return result.stdout.strip().split("\n")
        return []


def create_finetune_container(
    name: str = "finetune",
    models: Optional[List[str]] = None,
    datasets: Optional[List[str]] = None,
    extra_deps: Optional[List[str]] = None,
    output_dir: Optional[str] = None,
    use_aggregated: bool = True,
    private_repo: bool = False,
) -> ContainerBuilder:
    """
    Convenience function to create a finetune container.

    Args:
        name: Container name
        models: List of model IDs to include (from registry)
        datasets: List of dataset IDs to include
        extra_deps: Additional pip dependencies
        output_dir: Output directory for build files
        use_aggregated: Use AfriLink aggregated HF repos
        private_repo: Set True if using private HuggingFace repos (requires HF_TOKEN)

    Returns:
        Configured ContainerBuilder

    Example for public repos:
        builder = create_finetune_container(
            name="my-finetune",
            models=["qwen2.5-0.5b", "llama-3.2-1b"],
            datasets=["alpaca"],
        )
        builder.setup_build_directory("./container")
        builder.build_docker_image()

    Example for private repos:
        builder = create_finetune_container(
            name="my-finetune",
            models=["qwen2.5-0.5b"],
            private_repo=True,  # Enable HF token auth
        )
        builder.setup_build_directory("./container")
        builder.build_docker_image(hf_token="hf_xxxx")  # Pass token securely
    """
    spec = ContainerSpec(
        name=name,
        hf_models=models or [],
        hf_datasets=datasets or [],
        extra_dependencies=extra_deps or [],
        output_dir=output_dir,
        use_aggregated_repo=use_aggregated,
        hf_token_required=private_repo,
    )

    return ContainerBuilder(spec)
