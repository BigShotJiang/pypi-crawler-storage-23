"""
AfriLink Progress Bar Utility

Provides a simple green progress bar for notebook/terminal output.
No external dependencies.
"""

import sys
import time


class ProgressBar:
    """
    Simple progress bar that works in Colab, Jupyter, and terminals.

    Usage:
        bar = ProgressBar("Authenticating", steps=4)
        bar.update(1, "Launching browser")
        bar.update(2, "Logging in")
        bar.update(3, "Generating certificate")
        bar.update(4, "Connected")
        bar.finish("Authentication complete!")
    """

    # ANSI green
    GREEN = "\033[92m"
    RESET = "\033[0m"
    BOLD = "\033[1m"

    def __init__(self, label: str, steps: int):
        self.label = label
        self.steps = steps
        self.current = 0
        self._finished = False

    def _render(self, detail: str = ""):
        """Render the progress bar to stdout."""
        pct = int((self.current / self.steps) * 100)
        filled = int((self.current / self.steps) * 30)
        bar = "\u2588" * filled + "\u2591" * (30 - filled)

        line = f"\r{self.GREEN}{self.label} [{bar}] {pct}%{self.RESET}"
        if detail:
            line += f"  {detail}"

        # Pad to overwrite previous longer lines
        sys.stdout.write(f"{line:<100}")
        sys.stdout.flush()

    def update(self, step: int, detail: str = ""):
        """Update progress to a specific step."""
        self.current = min(step, self.steps)
        self._render(detail)

    def finish(self, message: str = ""):
        """Complete the progress bar with a final message."""
        self.current = self.steps
        self._render()
        # Move to new line after bar completes
        print()
        if message:
            print(f"{self.GREEN}{self.BOLD}{message}{self.RESET}")
        self._finished = True
