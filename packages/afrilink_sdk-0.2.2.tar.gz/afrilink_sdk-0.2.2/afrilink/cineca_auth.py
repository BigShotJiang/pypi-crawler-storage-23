"""
CINECA Direct Authentication Module

Handles Smallstep SSH certificate acquisition directly from Colab/Jupyter
without requiring an external SSH proxy for the authentication step.

This module provides multiple authentication strategies:
1. Headless browser automation (Selenium/Playwright)
2. Manual browser flow with code paste
3. Pre-existing certificate detection

Once authenticated, SSH commands can run directly from the notebook.
"""

import os
import re
import sys
import time
import subprocess
import tempfile
import shutil
from pathlib import Path
from typing import Optional, Tuple, Dict, Any
from dataclasses import dataclass

# Import TOTP generator from auth module
from .auth import TOTPGenerator
from .progress import ProgressBar

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


@dataclass
class CinecaAuthResult:
    """Result of CINECA authentication attempt"""
    success: bool
    cert_path: Optional[str] = None
    key_path: Optional[str] = None
    expires_at: Optional[str] = None
    username: Optional[str] = None
    error: Optional[str] = None


class CinecaDirectAuth:
    """
    Direct CINECA authentication from Colab/Jupyter notebooks.

    This class handles the complete Smallstep SSH certificate flow
    without requiring an external proxy service.
    """

    # CINECA Smallstep CA configuration
    STEP_CA_URL = "https://sshproxy.hpc.cineca.it"
    STEP_CA_FINGERPRINT = "2ae1543202304d3f434bdc1a2c92eff2cd2b02110206ef06317e70c1c1735ecd"
    STEP_PROVISIONER = "cineca-hpc"

    # CINECA login node
    CINECA_HOST = "login.leonardo.cineca.it"

    def __init__(
        self,
        username: str = "iomunga0",
        email: str = None,
        password: str = None,
        totp_seed: str = None,
        step_path: str = None,
    ):
        """
        Initialize CINECA auth client.

        Args:
            username: CINECA username (e.g., "iomunga0")
            email: CINECA SSO email
            password: CINECA SSO password
            totp_seed: Base32 TOTP seed for 2FA
            step_path: Path to step CLI (auto-detected if not provided)
        """
        self.username = username
        self.email = email
        self.password = password
        self.totp_seed = totp_seed
        self.step_path = step_path

        # Paths for certificates
        self.step_dir = Path.home() / ".step"
        self.ssh_dir = self.step_dir / "ssh"
        self.cert_path = self.ssh_dir / "id_ecdsa-cert.pub"
        self.key_path = self.ssh_dir / "id_ecdsa"

        self._totp = TOTPGenerator(totp_seed) if totp_seed else None

    def _run_command(self, cmd: list, timeout: int = 60, capture: bool = True) -> Tuple[int, str, str]:
        """Run a shell command and return (returncode, stdout, stderr)"""
        try:
            result = subprocess.run(
                cmd,
                capture_output=capture,
                text=True,
                timeout=timeout,
            )
            return result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            return -1, "", "Command timed out"
        except Exception as e:
            return -1, "", str(e)

    def _check_step_installed(self) -> bool:
        """Check if step CLI is installed"""
        if self.step_path and Path(self.step_path).exists():
            return True

        # Try to find step in PATH
        code, stdout, _ = self._run_command(["which", "step"])
        if code == 0 and stdout.strip():
            self.step_path = stdout.strip()
            return True

        return False

    def install_step_cli(self) -> bool:
        """
        Install Smallstep CLI in the current environment.
        Works in Colab/Jupyter.
        """
        print("Installing Smallstep CLI...")

        # Detect platform
        import platform
        system = platform.system().lower()
        machine = platform.machine().lower()

        if system == "linux":
            if "x86_64" in machine or "amd64" in machine:
                arch = "amd64"
            elif "aarch64" in machine or "arm64" in machine:
                arch = "arm64"
            else:
                print(f"Unsupported architecture: {machine}")
                return False

            # Download and install
            version = "0.25.0"
            url = f"https://github.com/smallstep/cli/releases/download/v{version}/step_linux_{version}_{arch}.tar.gz"

            install_dir = Path.home() / ".local" / "bin"
            install_dir.mkdir(parents=True, exist_ok=True)

            with tempfile.TemporaryDirectory() as tmpdir:
                tarball = Path(tmpdir) / "step.tar.gz"

                # Download
                print(f"Downloading from {url}...")
                if HAS_REQUESTS:
                    import requests
                    resp = requests.get(url, stream=True)
                    with open(tarball, 'wb') as f:
                        for chunk in resp.iter_content(chunk_size=8192):
                            f.write(chunk)
                else:
                    import urllib.request
                    urllib.request.urlretrieve(url, tarball)

                # Extract
                print("Extracting...")
                import tarfile
                with tarfile.open(tarball, 'r:gz') as tar:
                    tar.extractall(tmpdir)

                # Find and move step binary
                for root, dirs, files in os.walk(tmpdir):
                    if "step" in files:
                        src = Path(root) / "step"
                        dst = install_dir / "step"
                        shutil.copy2(src, dst)
                        os.chmod(dst, 0o755)
                        self.step_path = str(dst)
                        print(f"Installed to {dst}")

                        # Add to PATH for this session
                        os.environ["PATH"] = f"{install_dir}:{os.environ.get('PATH', '')}"
                        return True

            print("Failed to find step binary in archive")
            return False
        else:
            print(f"Unsupported platform: {system}")
            return False

    def bootstrap_ca(self) -> bool:
        """Bootstrap the Smallstep CA configuration"""
        print("Bootstrapping Smallstep CA...")

        step = self.step_path or "step"
        code, stdout, stderr = self._run_command([
            step, "ca", "bootstrap",
            "--ca-url", self.STEP_CA_URL,
            "--fingerprint", self.STEP_CA_FINGERPRINT,
            "--install",
        ])

        if code != 0:
            print(f"Bootstrap failed: {stderr}")
            return False

        print("CA bootstrapped successfully")
        return True

    def check_cert_valid(self) -> Tuple[bool, Optional[str]]:
        """
        Check if existing SSH certificate is valid.

        Returns:
            Tuple of (is_valid, expiry_time)
        """
        if not self.cert_path.exists():
            return False, None

        step = self.step_path or "step"
        code, stdout, stderr = self._run_command([
            step, "ssh", "inspect", str(self.cert_path),
        ])

        if code != 0:
            return False, None

        # Parse expiry from output
        match = re.search(r'Valid:\s+.*to\s+(\d{4}-\d{2}-\d{2}T[\d:]+)', stdout)
        if match:
            expiry_str = match.group(1)
            from datetime import datetime
            try:
                expiry = datetime.fromisoformat(expiry_str.replace('Z', '+00:00'))
                now = datetime.now(expiry.tzinfo) if expiry.tzinfo else datetime.now()

                if expiry > now:
                    return True, expiry_str
            except Exception:
                pass

        return False, None

    def authenticate_headless(self) -> CinecaAuthResult:
        """
        Authenticate using headless browser automation with CONCURRENT execution.

        CRITICAL INSIGHT: step's OAuth has a hardcoded ~60s timeout. The only way
        to beat it is to run the browser automation CONCURRENTLY in a separate thread
        that starts IMMEDIATELY when the URL is captured. We use threading to ensure
        the browser starts navigating within milliseconds of getting the URL.

        Flow:
        1. Pre-launch browser and warm it up
        2. Start step ssh login
        3. Capture auth URL from stderr
        4. IMMEDIATELY start browser thread to complete OAuth
        5. Browser completes flow, redirects to localhost:10000
        6. step receives callback and generates cert
        """
        import threading
        import queue

        if not self.email or not self.password or not self.totp_seed:
            return CinecaAuthResult(
                success=False,
                error="Email, password, and TOTP seed required for headless auth"
            )

        # Check if we already have a valid cert
        valid, expiry = self.check_cert_valid()
        if valid:
            print(f"Existing certificate valid until {expiry}")
            return CinecaAuthResult(
                success=True,
                cert_path=str(self.cert_path),
                key_path=str(self.key_path),
                expires_at=expiry,
                username=self.username,
            )

        _bar = ProgressBar("Authenticating", steps=8)
        _bar.update(0, "Starting...")

        # Ensure step is installed
        if not self._check_step_installed():
            if not self.install_step_cli():
                return CinecaAuthResult(success=False, error="Failed to install step CLI")

        # Bootstrap CA if needed
        if not (self.step_dir / "certs" / "root_ca.crt").exists():
            if not self.bootstrap_ca():
                return CinecaAuthResult(success=False, error="Failed to bootstrap CA")

        # Install Selenium if needed
        try:
            from selenium import webdriver
            from selenium.webdriver.common.by import By
            from selenium.webdriver.support.ui import WebDriverWait
            from selenium.webdriver.support import expected_conditions as EC
            from selenium.webdriver.chrome.options import Options
            from selenium.webdriver.chrome.service import Service
        except ImportError:
            print("Installing Selenium...")
            subprocess.run([sys.executable, "-m", "pip", "install", "-q", "selenium"], check=True)
            from selenium import webdriver
            from selenium.webdriver.common.by import By
            from selenium.webdriver.support.ui import WebDriverWait
            from selenium.webdriver.support import expected_conditions as EC
            from selenium.webdriver.chrome.options import Options
            from selenium.webdriver.chrome.service import Service

        # Check for Chrome/Chromium - prefer Google Chrome (Chromium requires snap in newer Ubuntu)
        chrome_paths = [
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
            "/opt/google/chrome/google-chrome",
            "/usr/bin/chromium-browser",
            "/usr/bin/chromium",
        ]
        chrome_path = None
        for path in chrome_paths:
            if Path(path).exists():
                # Verify it's not a snap wrapper
                try:
                    result = subprocess.run([path, "--version"], capture_output=True, text=True, timeout=5)
                    if result.returncode == 0 and "snap" not in result.stderr.lower():
                        chrome_path = path
                        break
                except Exception:
                    continue

        if not chrome_path:
            # Install Google Chrome (not Chromium - snap doesn't work in Colab)
            print("Installing Google Chrome...")
            subprocess.run(["wget", "-q", "-O", "/tmp/chrome.deb",
                          "https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb"], check=False)
            subprocess.run(["apt-get", "install", "-y", "-qq", "/tmp/chrome.deb"], check=False)
            subprocess.run(["apt-get", "install", "-f", "-y", "-qq"], check=False)  # Fix dependencies

            # Find the installed Chrome
            for path in ["/usr/bin/google-chrome", "/usr/bin/google-chrome-stable", "/opt/google/chrome/google-chrome"]:
                if Path(path).exists():
                    chrome_path = path
                    break

            if not chrome_path:
                return CinecaAuthResult(success=False, error="Failed to install Google Chrome")

        # Install chromedriver
        try:
            from webdriver_manager.chrome import ChromeDriverManager
        except ImportError:
            subprocess.run([sys.executable, "-m", "pip", "install", "-q", "webdriver-manager"], check=True)
            from webdriver_manager.chrome import ChromeDriverManager

        # ══════════════════════════════════════════════════════════════════════
        # PHASE 1: Pre-launch browser
        # ══════════════════════════════════════════════════════════════════════

        _bar.update(1, "Launching browser")
        chrome_options = Options()
        # Minimal flags for Colab - too many flags can cause crashes
        chrome_options.add_argument("--headless=new")  # New headless mode
        chrome_options.add_argument("--no-sandbox")  # Required in containers
        chrome_options.add_argument("--disable-dev-shm-usage")  # Use /tmp instead of /dev/shm
        chrome_options.add_argument("--disable-gpu")  # No GPU in Colab
        chrome_options.binary_location = chrome_path

        try:
            # Use regular ChromeDriver for Google Chrome
            service = Service(ChromeDriverManager().install())
            driver = webdriver.Chrome(service=service, options=chrome_options)
            driver.get("about:blank")  # Warm up
            _bar.update(2, "Browser ready")
        except Exception as e:
            return CinecaAuthResult(success=False, error=f"Failed to setup ChromeDriver: {e}")

        # ══════════════════════════════════════════════════════════════════════
        # PHASE 2: Setup SSH agent
        # ══════════════════════════════════════════════════════════════════════

        step = self.step_path or "step"

        agent_output = subprocess.run(["ssh-agent", "-s"], capture_output=True, text=True)
        for line in agent_output.stdout.split('\n'):
            if 'SSH_AUTH_SOCK' in line:
                match = re.search(r'SSH_AUTH_SOCK=([^;]+)', line)
                if match:
                    os.environ['SSH_AUTH_SOCK'] = match.group(1)
            elif 'SSH_AGENT_PID' in line:
                match = re.search(r'SSH_AGENT_PID=(\d+)', line)
                if match:
                    os.environ['SSH_AGENT_PID'] = match.group(1)

        # ══════════════════════════════════════════════════════════════════════
        # PHASE 3: Define browser automation function for concurrent execution
        # ══════════════════════════════════════════════════════════════════════

        result_queue = queue.Queue()

        def browser_oauth_flow(auth_url: str):
            """Run OAuth flow in browser - executed in separate thread"""
            try:
                _bar.update(4, "Navigating to auth")
                driver.get(auth_url)

                # Fill login form
                _bar.update(5, "Filling credentials")
                username_field = WebDriverWait(driver, 15).until(
                    EC.presence_of_element_located((By.ID, "username"))
                )
                username_field.clear()
                username_field.send_keys(self.email)

                password_field = driver.find_element(By.ID, "password")
                password_field.clear()
                password_field.send_keys(self.password)

                login_button = driver.find_element(By.ID, "kc-login")
                login_button.click()

                # Wait for OTP page - need to wait for URL to change or new element
                _bar.update(6, "Waiting for OTP")
                otp_field = WebDriverWait(driver, 20).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, "input[name='otp'], input[name='totp'], input#otp"))
                )

                # Check for login error before proceeding
                try:
                    error_elem = driver.find_element(By.CSS_SELECTOR, ".alert-error, .kc-feedback-text, #input-error")
                    error_text = error_elem.text.strip()
                    if error_text:
                        result_queue.put(("error", f"Login failed: {error_text}"))
                        return
                except Exception:
                    pass  # No error found, continue

                # OTP retry loop - try up to 2 times with different codes
                max_otp_attempts = 2
                for otp_attempt in range(max_otp_attempts):
                    # Wait until we're at least 3 seconds into a fresh 30-second window
                    # This gives us ~27 seconds of validity
                    current_pos = int(time.time()) % 30
                    if current_pos < 3 or current_pos > 27:
                        wait_time = (30 - current_pos + 3) % 30
                        if wait_time > 0:
                            time.sleep(wait_time)

                    # Generate OTP right before entering it
                    if self._totp is None:
                        result_queue.put(("error", "TOTP generator not initialized"))
                        return
                    otp = self._totp.generate()

                    # Clear and enter OTP
                    otp_field.clear()
                    time.sleep(0.1)
                    otp_field.send_keys(otp)

                    # Find submit button
                    submit = None
                    for selector in ["input[type='submit']", "button[type='submit']", "#kc-login", ".btn-primary"]:
                        try:
                            submit = driver.find_element(By.CSS_SELECTOR, selector)
                            if submit.is_displayed() and submit.is_enabled():
                                break
                        except Exception:
                            continue

                    if not submit:
                        result_queue.put(("error", "Could not find submit button"))
                        return

                    _bar.update(7, "Submitting OTP")
                    submit.click()

                    # Wait for response
                    time.sleep(1.5)

                    # Check if we've been redirected (success)
                    if "127.0.0.1" in driver.current_url or "localhost" in driver.current_url:
                        result_queue.put(("success", None))
                        return

                    # Check for OTP error
                    otp_error = None
                    try:
                        error_elem = driver.find_element(By.CSS_SELECTOR, ".alert-error, .kc-feedback-text, #input-error, .pf-m-error")
                        otp_error = error_elem.text.strip()
                    except Exception:
                        pass

                    if otp_error and "invalid" in otp_error.lower():
                        if otp_attempt < max_otp_attempts - 1:
                            # Wait for next TOTP window
                            current_pos = int(time.time()) % 30
                            wait_for_next = 30 - current_pos + 3
                            time.sleep(wait_for_next)
                            # Re-find the OTP field (page may have refreshed)
                            try:
                                otp_field = driver.find_element(By.CSS_SELECTOR, "input[name='otp'], input[name='totp'], input#otp")
                            except Exception:
                                result_queue.put(("error", f"OTP field not found after retry: {otp_error}"))
                                return
                            continue
                        else:
                            result_queue.put(("error", f"OTP failed after {max_otp_attempts} attempts: {otp_error}"))
                            return
                    elif otp_error:
                        result_queue.put(("error", f"OTP error: {otp_error}"))
                        return

                    # No error found, might be processing - break and wait for redirect
                    break

                # Wait for redirect to localhost (step's callback server)
                try:
                    WebDriverWait(driver, 30).until(
                        lambda d: "127.0.0.1" in d.current_url or "localhost" in d.current_url
                    )
                    result_queue.put(("success", None))
                except Exception as timeout_err:
                    # Get current URL and page state for debugging
                    current_url = driver.current_url
                    page_title = driver.title
                    # Check if we're still on SSO page
                    if "sso.hpc.cineca.it" in current_url:
                        # Try to find any error message
                        try:
                            body_text = driver.find_element(By.TAG_NAME, "body").text[:500]
                        except Exception:
                            body_text = "N/A"
                        result_queue.put(("error", f"OAuth redirect timeout. Still on: {current_url}\nTitle: {page_title}\nBody: {body_text}"))
                    else:
                        result_queue.put(("error", f"Unexpected URL: {current_url}"))

            except Exception as e:
                try:
                    current_url = driver.current_url
                    page_title = driver.title
                    page_snippet = driver.page_source[:500]
                except Exception:
                    current_url = "N/A"
                    page_title = "N/A"
                    page_snippet = "N/A"
                result_queue.put(("error", f"{e}\nURL: {current_url}\nTitle: {page_title}\nPage: {page_snippet}"))

        # ══════════════════════════════════════════════════════════════════════
        # PHASE 4: Start step and browser CONCURRENTLY
        # ══════════════════════════════════════════════════════════════════════

        _bar.update(3, "Starting SSH login")

        # CRITICAL: step outputs status to stderr but URL to stdout!
        # Merge both streams so we can capture everything
        step_proc = subprocess.Popen(
            [step, "ssh", "login", self.email, "--provisioner", self.STEP_PROVISIONER],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,  # Merge stderr into stdout
            text=True,
            bufsize=1,  # Line buffered
        )

        # Read merged output to find auth URL
        # The URL appears on a line by itself AFTER "Your default web browser has been opened to visit:"
        auth_url = None
        output_lines = []
        start_time = time.time()

        def read_output_thread():
            """Read stdout (merged with stderr) in a thread"""
            nonlocal auth_url
            try:
                if step_proc.stdout is None:
                    return
                while time.time() - start_time < 15:
                    line = step_proc.stdout.readline()
                    if not line:
                        if step_proc.poll() is not None:
                            break
                        continue

                    output_lines.append(line)
                    stripped = line.strip()

                    # Look for URL - it starts with https://
                    if stripped.startswith('https://'):
                        auth_url = stripped
                        break

                    # Also check for sso.hpc.cineca.it anywhere in line
                    if 'sso.hpc.cineca.it' in line:
                        # Extract URL from line
                        url_match = re.search(r'(https://[^\s]+)', line)
                        if url_match:
                            auth_url = url_match.group(1)
                            break

                    # Stop if we found the URL
                    if auth_url:
                        break
            except Exception as e:
                print(f"      [reader error] {e}")

        # Run output reading in thread
        reader_thread = threading.Thread(target=read_output_thread, daemon=True)
        reader_thread.start()
        reader_thread.join(timeout=15)

        if not auth_url:
            step_proc.kill()
            driver.quit()
            full_output = ''.join(output_lines)
            if 'timed out' in full_output.lower():
                return CinecaAuthResult(
                    success=False,
                    error="step oauth timed out before we could capture the URL. Try running the cell again."
                )
            return CinecaAuthResult(
                success=False,
                error=f"Failed to capture auth URL. Output: {full_output}"
            )

        # ═══ CRITICAL: Start browser thread IMMEDIATELY ═══
        browser_thread = threading.Thread(target=browser_oauth_flow, args=(auth_url,))
        browser_thread.start()

        # Wait for browser to complete
        browser_thread.join(timeout=90)  # 90s max for entire browser flow

        if browser_thread.is_alive():
            driver.quit()
            step_proc.kill()
            return CinecaAuthResult(success=False, error="Browser automation timed out after 90s")

        # Check browser result
        try:
            status, error = result_queue.get_nowait()
            if status == "error":
                driver.quit()
                step_proc.kill()
                return CinecaAuthResult(success=False, error=f"Browser error: {error}")
        except queue.Empty:
            pass

        driver.quit()

        # ══════════════════════════════════════════════════════════════════════
        # PHASE 5: Wait for step to generate certificate
        # ══════════════════════════════════════════════════════════════════════

        _bar.update(8, "Generating certificate")
        try:
            step_proc.wait(timeout=30)
        except subprocess.TimeoutExpired:
            step_proc.kill()
            return CinecaAuthResult(success=False, error="step timed out after OAuth - callback may have failed")

        # Read any remaining output (stderr is merged into stdout)
        remaining_output = ""
        if step_proc.stdout:
            remaining_output = step_proc.stdout.read()

        if step_proc.returncode != 0:
            return CinecaAuthResult(
                success=False,
                error=f"step failed (exit {step_proc.returncode}): {remaining_output}"
            )

        # Verify certificate was created - check multiple possible locations
        valid, expiry = self.check_cert_valid()
        if valid:
            _bar.finish()
            # Clear any stale host keys now that we have fresh credentials
            self._clear_stale_host_keys()
            return CinecaAuthResult(
                success=True,
                cert_path=str(self.cert_path),
                key_path=str(self.key_path),
                expires_at=expiry,
                username=self.username,
            )

        # Certificate might be in SSH agent only (step adds it there by default)
        # Check if SSH agent has the key loaded
        agent_check = subprocess.run(
            ["ssh-add", "-l"],
            capture_output=True,
            text=True,
        )

        if agent_check.returncode == 0 and agent_check.stdout.strip():
            _bar.finish()

            # Clear any stale host keys now that we have fresh credentials
            self._clear_stale_host_keys()

            # The key is in the agent, so SSH will work even without disk files
            # Mark as success - SSH commands will work via the agent
            return CinecaAuthResult(
                success=True,
                cert_path="ssh-agent",  # Key is in agent, not on disk
                key_path="ssh-agent",
                expires_at=None,  # Can't easily get expiry from agent
                username=self.username,
            )

        # Also check common alternate paths
        alt_paths = [
            (Path.home() / ".step" / "ssh" / "id_ecdsa-cert.pub", Path.home() / ".step" / "ssh" / "id_ecdsa"),
            (Path.home() / ".ssh" / "id_ecdsa-cert.pub", Path.home() / ".ssh" / "id_ecdsa"),
            (Path.home() / ".step" / "ssh" / "id_ed25519-cert.pub", Path.home() / ".step" / "ssh" / "id_ed25519"),
        ]

        for cert_p, key_p in alt_paths:
            if cert_p.exists():
                self.cert_path = cert_p
                self.key_path = key_p
                valid, expiry = self.check_cert_valid()
                if valid:
                    _bar.finish()
                    # Clear any stale host keys now that we have fresh credentials
                    self._clear_stale_host_keys()
                    return CinecaAuthResult(
                        success=True,
                        cert_path=str(cert_p),
                        key_path=str(key_p),
                        expires_at=expiry,
                        username=self.username,
                    )

        return CinecaAuthResult(success=False, error="Certificate not found after auth")

    def _clear_stale_host_keys(self):
        """
        Clear any stale host keys for CINECA from known_hosts.

        This prevents "REMOTE HOST IDENTIFICATION HAS CHANGED" errors
        when CINECA updates their server keys or when Colab reuses
        a known_hosts file from a previous session.
        """
        known_hosts = Path.home() / ".ssh" / "known_hosts"
        if known_hosts.exists():
            # Remove old host key entries for CINECA
            try:
                subprocess.run(
                    ["ssh-keygen", "-R", self.CINECA_HOST],
                    capture_output=True,
                    timeout=5,
                )
            except Exception:
                pass  # Ignore errors - file might not have the entry

    def _build_ssh_command(self, remote_command: str) -> list:
        """Build SSH command with appropriate options based on key location"""
        ssh_cmd = [
            "ssh",
            "-o", "StrictHostKeyChecking=accept-new",
            "-o", "BatchMode=yes",
            "-o", "ConnectTimeout=10",
        ]

        # If we have a key file on disk, use it explicitly
        # Otherwise, SSH will use the agent automatically
        if isinstance(self.key_path, Path) and self.key_path.exists():
            ssh_cmd.extend(["-i", str(self.key_path)])

        ssh_cmd.append(f"{self.username}@{self.CINECA_HOST}")
        ssh_cmd.append(remote_command)

        return ssh_cmd

    def test_ssh_connection(self) -> Tuple[bool, str]:
        """
        Test SSH connection to CINECA.

        Returns:
            Tuple of (success, output_or_error)
        """
        # Check if we have either a key file or an agent with keys
        has_key_file = isinstance(self.key_path, Path) and self.key_path.exists()
        has_agent_key = False

        if not has_key_file:
            # Check SSH agent
            agent_check = subprocess.run(["ssh-add", "-l"], capture_output=True, text=True)
            has_agent_key = agent_check.returncode == 0 and agent_check.stdout.strip()

        if not has_key_file and not has_agent_key:
            return False, "No SSH certificate found. Run authenticate_headless() first."

        # Clear any stale host keys to prevent "HOST IDENTIFICATION HAS CHANGED" errors
        self._clear_stale_host_keys()

        # Test connection with a simple command
        ssh_cmd = self._build_ssh_command("hostname")
        code, stdout, stderr = self._run_command(ssh_cmd, timeout=30)

        if code == 0:
            return True, stdout.strip()
        else:
            return False, stderr

    def run_ssh_command(self, command: str, timeout: int = 60) -> Tuple[int, str, str]:
        """
        Run a command on CINECA via SSH.

        Args:
            command: Shell command to execute
            timeout: Timeout in seconds

        Returns:
            Tuple of (returncode, stdout, stderr)
        """
        # Check if we have either a key file or an agent with keys
        has_key_file = isinstance(self.key_path, Path) and self.key_path.exists()
        has_agent_key = False

        if not has_key_file:
            # Check SSH agent
            agent_check = subprocess.run(["ssh-add", "-l"], capture_output=True, text=True)
            has_agent_key = agent_check.returncode == 0 and agent_check.stdout.strip()

        if not has_key_file and not has_agent_key:
            return -1, "", "No SSH certificate. Run authenticate_headless() first."

        # Clear any stale host keys to prevent "HOST IDENTIFICATION HAS CHANGED" errors
        self._clear_stale_host_keys()

        ssh_cmd = self._build_ssh_command(command)
        return self._run_command(ssh_cmd, timeout=timeout)


def authenticate_cineca(
    email: str = None,
    password: str = None,
    totp_seed: str = None,
    username: str = "iomunga0",
) -> CinecaDirectAuth:
    """
    Convenience function to authenticate with CINECA directly.

    Usage in Colab:
        from afrilink.cineca_auth import authenticate_cineca

        cineca = authenticate_cineca(
            email="user@example.com",
            password="...",
            totp_seed="...",
        )

        # Run commands directly
        code, out, err = cineca.run_ssh_command("squeue -u $USER")
        print(out)
    """
    auth = CinecaDirectAuth(
        username=username,
        email=email,
        password=password,
        totp_seed=totp_seed,
    )

    result = auth.authenticate_headless()

    if not result.success:
        raise Exception(f"CINECA auth failed: {result.error}")

    # Test connection (silent)
    auth.test_ssh_connection()

    return auth
