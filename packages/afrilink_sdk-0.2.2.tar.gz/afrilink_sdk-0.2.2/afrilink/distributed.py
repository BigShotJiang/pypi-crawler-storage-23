"""
AfriLink Distributed Training Module

Provides training strategies for scaling across multiple GPUs using:
- PyTorch DistributedDataParallel (DDP)
- Fully Sharded Data Parallel (FSDP)
- DeepSpeed ZeRO stages

Designed to bootstrap from single GPU and scale to multi-GPU seamlessly.
"""

import os
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from enum import Enum


class DistributedStrategy(Enum):
    """Available distributed training strategies"""
    NONE = "none"           # Single GPU, no distribution
    DDP = "ddp"            # PyTorch DistributedDataParallel
    FSDP = "fsdp"          # Fully Sharded Data Parallel
    DEEPSPEED_Z2 = "ds_z2"  # DeepSpeed ZeRO Stage 2
    DEEPSPEED_Z3 = "ds_z3"  # DeepSpeed ZeRO Stage 3


@dataclass
class DDPConfig:
    """DistributedDataParallel configuration"""
    find_unused_parameters: bool = False
    gradient_as_bucket_view: bool = True
    static_graph: bool = False


@dataclass
class FSDPConfig:
    """Fully Sharded Data Parallel configuration"""
    sharding_strategy: str = "FULL_SHARD"  # FULL_SHARD, SHARD_GRAD_OP, NO_SHARD
    cpu_offload: bool = False
    backward_prefetch: str = "BACKWARD_PRE"
    mixed_precision: bool = True
    use_orig_params: bool = True


@dataclass
class DeepSpeedConfig:
    """DeepSpeed configuration"""
    stage: int = 2  # ZeRO stage (1, 2, or 3)
    offload_optimizer: bool = False
    offload_param: bool = False  # Only for stage 3
    pin_memory: bool = True
    overlap_comm: bool = True
    contiguous_gradients: bool = True
    reduce_bucket_size: int = 5e8
    stage3_prefetch_bucket_size: int = 5e8
    stage3_param_persistence_threshold: int = 1e6

    def to_dict(self) -> Dict[str, Any]:
        """Convert to DeepSpeed config dict format"""
        config = {
            "zero_optimization": {
                "stage": self.stage,
                "overlap_comm": self.overlap_comm,
                "contiguous_gradients": self.contiguous_gradients,
                "reduce_bucket_size": self.reduce_bucket_size,
            },
            "bf16": {
                "enabled": True,
            },
            "gradient_accumulation_steps": "auto",
            "gradient_clipping": "auto",
            "train_batch_size": "auto",
            "train_micro_batch_size_per_gpu": "auto",
        }

        if self.offload_optimizer:
            config["zero_optimization"]["offload_optimizer"] = {
                "device": "cpu",
                "pin_memory": self.pin_memory,
            }

        if self.stage == 3:
            config["zero_optimization"]["stage3_prefetch_bucket_size"] = self.stage3_prefetch_bucket_size
            config["zero_optimization"]["stage3_param_persistence_threshold"] = self.stage3_param_persistence_threshold

            if self.offload_param:
                config["zero_optimization"]["offload_param"] = {
                    "device": "cpu",
                    "pin_memory": self.pin_memory,
                }

        return config


@dataclass
class DistributedConfig:
    """
    Complete distributed training configuration.

    Combines strategy selection with strategy-specific configs.
    """
    strategy: DistributedStrategy = DistributedStrategy.NONE
    num_gpus: int = 1
    num_nodes: int = 1
    gpus_per_node: int = 4

    # Strategy-specific configs
    ddp_config: DDPConfig = field(default_factory=DDPConfig)
    fsdp_config: FSDPConfig = field(default_factory=FSDPConfig)
    deepspeed_config: DeepSpeedConfig = field(default_factory=DeepSpeedConfig)

    # Mixed precision
    mixed_precision: str = "bf16"  # bf16, fp16, or no

    # Communication
    backend: str = "nccl"  # nccl or gloo
    init_method: str = "env://"

    @classmethod
    def auto(cls, num_gpus: int, model_size_b: float = 7.0) -> "DistributedConfig":
        """
        Automatically select optimal strategy based on resources.

        Args:
            num_gpus: Total number of GPUs
            model_size_b: Model size in billions of parameters

        Returns:
            Optimally configured DistributedConfig
        """
        config = cls(num_gpus=num_gpus)

        if num_gpus == 1:
            # Single GPU - no distribution needed
            config.strategy = DistributedStrategy.NONE
        elif num_gpus <= 4 and model_size_b <= 13:
            # Small cluster, medium model - DDP works well
            config.strategy = DistributedStrategy.DDP
        elif num_gpus <= 8 and model_size_b <= 30:
            # Medium cluster - FSDP for memory efficiency
            config.strategy = DistributedStrategy.FSDP
        else:
            # Large scale - DeepSpeed ZeRO-3
            config.strategy = DistributedStrategy.DEEPSPEED_Z3
            config.deepspeed_config.stage = 3

        return config


class TrainingScriptGenerator:
    """
    Generates training scripts with proper distributed setup.
    """

    TRAIN_SCRIPT_TEMPLATE = '''#!/usr/bin/env python3
"""
AfriLink Finetune Training Script
Generated automatically for distributed training.

Strategy: {strategy}
GPUs: {num_gpus}
"""

import os
import sys
import json
import torch
from pathlib import Path

# Distributed imports
{distributed_imports}

# Training imports
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling,
)
from datasets import load_dataset, Dataset
from peft import (
    LoraConfig,
    get_peft_model,
    prepare_model_for_kbit_training,
    TaskType,
)

{quantization_imports}


def setup_distributed():
    """Initialize distributed training environment"""
{distributed_setup}


def load_model_and_tokenizer(model_path: str, config: dict):
    """Load model with appropriate configuration"""
    print(f"Loading model from: {{model_path}}")

    tokenizer = AutoTokenizer.from_pretrained(
        model_path,
        trust_remote_code=True,
        padding_side="right",
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

{model_loading}

    return model, tokenizer


def load_training_data(data_path: str, tokenizer, max_seq_length: int):
    """Load and preprocess training data"""
    print(f"Loading data from: {{data_path}}")

    # Support multiple formats
    if data_path.endswith('.jsonl'):
        dataset = load_dataset('json', data_files=data_path, split='train')
    elif data_path.endswith('.parquet'):
        dataset = load_dataset('parquet', data_files=data_path, split='train')
    elif data_path.endswith('.csv'):
        dataset = load_dataset('csv', data_files=data_path, split='train')
    else:
        # Assume HuggingFace dataset
        dataset = load_dataset(data_path, split='train')

    # Tokenize
    def tokenize(example):
        # Handle different column names
        text = example.get('text') or example.get('content') or example.get('instruction', '')
        return tokenizer(
            text,
            truncation=True,
            max_length=max_seq_length,
            padding=False,
        )

    dataset = dataset.map(tokenize, remove_columns=dataset.column_names)
    return dataset


def main():
    # Configuration from environment or defaults
    config = {{
        "model_path": os.environ.get("MODEL_PATH", "{model_path}"),
        "data_path": os.environ.get("DATA_PATH", "{data_path}"),
        "output_dir": os.environ.get("OUTPUT_DIR", "{output_dir}"),
        "num_epochs": {num_epochs},
        "batch_size": {batch_size},
        "learning_rate": {learning_rate},
        "max_seq_length": {max_seq_length},
        "gradient_accumulation_steps": {gradient_accumulation_steps},
        "use_lora": {use_lora},
        "lora_r": {lora_r},
        "lora_alpha": {lora_alpha},
        "use_quantization": {use_quantization},
        "quantization_bits": {quantization_bits},
    }}

    # Setup distributed
    local_rank = setup_distributed()

    # Load model and tokenizer
    model, tokenizer = load_model_and_tokenizer(config["model_path"], config)

    # Load data
    train_dataset = load_training_data(
        config["data_path"],
        tokenizer,
        config["max_seq_length"],
    )

    # Training arguments
{training_args}

    # Data collator
    data_collator = DataCollatorForLanguageModeling(
        tokenizer=tokenizer,
        mlm=False,
    )

    # Trainer
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        data_collator=data_collator,
    )

    # Train
    print("Starting training...")
    trainer.train()

    # Save final model
    print(f"Saving model to {{config['output_dir']}}")
    trainer.save_model()
    tokenizer.save_pretrained(config["output_dir"])

    print("Training complete!")


if __name__ == "__main__":
    main()
'''

    def __init__(self, dist_config: DistributedConfig):
        """
        Initialize script generator.

        Args:
            dist_config: Distributed training configuration
        """
        self.config = dist_config

    def _get_distributed_imports(self) -> str:
        """Get import statements for distributed training"""
        if self.config.strategy == DistributedStrategy.NONE:
            return "# Single GPU - no distributed imports needed"
        elif self.config.strategy == DistributedStrategy.DDP:
            return """import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data.distributed import DistributedSampler"""
        elif self.config.strategy == DistributedStrategy.FSDP:
            return """import torch.distributed as dist
from torch.distributed.fsdp import (
    FullyShardedDataParallel as FSDP,
    MixedPrecision,
    ShardingStrategy,
)
from torch.distributed.fsdp.wrap import transformer_auto_wrap_policy"""
        else:  # DeepSpeed
            return """import deepspeed
from deepspeed import DeepSpeedEngine"""

    def _get_distributed_setup(self) -> str:
        """Get distributed initialization code"""
        if self.config.strategy == DistributedStrategy.NONE:
            return """    # Single GPU mode
    if torch.cuda.is_available():
        torch.cuda.set_device(0)
    return 0"""

        if self.config.strategy in [DistributedStrategy.DDP, DistributedStrategy.FSDP]:
            return """    # Initialize distributed process group
    local_rank = int(os.environ.get("LOCAL_RANK", 0))
    world_size = int(os.environ.get("WORLD_SIZE", 1))
    rank = int(os.environ.get("RANK", 0))

    if world_size > 1:
        dist.init_process_group(
            backend="nccl",
            init_method="env://",
            world_size=world_size,
            rank=rank,
        )
        torch.cuda.set_device(local_rank)

    print(f"Initialized rank {rank}/{world_size}, local_rank={local_rank}")
    return local_rank"""

        # DeepSpeed
        return """    # DeepSpeed handles initialization
    local_rank = int(os.environ.get("LOCAL_RANK", 0))
    deepspeed.init_distributed()
    torch.cuda.set_device(local_rank)
    return local_rank"""

    def _get_quantization_imports(self, use_quantization: bool) -> str:
        """Get quantization imports"""
        if not use_quantization:
            return "# No quantization"

        return """from transformers import BitsAndBytesConfig"""

    def _get_model_loading(self, training_config) -> str:
        """Get model loading code"""
        if training_config.use_quantization:
            bits = training_config.quantization_bits
            return f'''    # Quantization config
    bnb_config = BitsAndBytesConfig(
        load_in_{"4bit" if bits == 4 else "8bit"}=True,
        {"bnb_4bit_quant_type='nf4'," if bits == 4 else ""}
        {"bnb_4bit_compute_dtype=torch.bfloat16," if bits == 4 else ""}
        {"bnb_4bit_use_double_quant=True," if bits == 4 else ""}
    )

    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        quantization_config=bnb_config,
        device_map="auto",
        trust_remote_code=True,
        torch_dtype=torch.bfloat16,
    )

    # Prepare for k-bit training
    model = prepare_model_for_kbit_training(model)

    # Apply LoRA
    if config.get("use_lora", True):
        lora_config = LoraConfig(
            r=config.get("lora_r", 16),
            lora_alpha=config.get("lora_alpha", 32),
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            lora_dropout=0.05,
            bias="none",
            task_type=TaskType.CAUSAL_LM,
        )
        model = get_peft_model(model, lora_config)
        model.print_trainable_parameters()'''
        else:
            return '''    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        torch_dtype=torch.bfloat16,
        device_map=None if {ddp} else "auto",
        trust_remote_code=True,
    )

    # Apply LoRA if configured
    if config.get("use_lora", True):
        lora_config = LoraConfig(
            r=config.get("lora_r", 16),
            lora_alpha=config.get("lora_alpha", 32),
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            lora_dropout=0.05,
            bias="none",
            task_type=TaskType.CAUSAL_LM,
        )
        model = get_peft_model(model, lora_config)
        model.print_trainable_parameters()'''.format(ddp=self.config.strategy == DistributedStrategy.DDP)

    def _get_training_args(self, training_config) -> str:
        """Get TrainingArguments code"""
        strategy_args = ""

        if self.config.strategy == DistributedStrategy.FSDP:
            strategy_args = '''
        fsdp="full_shard auto_wrap",
        fsdp_config={
            "transformer_layer_cls_to_wrap": ["LlamaDecoderLayer", "MistralDecoderLayer"],
        },'''
        elif self.config.strategy in [DistributedStrategy.DEEPSPEED_Z2, DistributedStrategy.DEEPSPEED_Z3]:
            stage = 3 if self.config.strategy == DistributedStrategy.DEEPSPEED_Z3 else 2
            strategy_args = f'''
        deepspeed="ds_config.json",  # Generated separately'''

        return f'''    training_args = TrainingArguments(
        output_dir=config["output_dir"],
        num_train_epochs=config["num_epochs"],
        per_device_train_batch_size=config["batch_size"],
        gradient_accumulation_steps=config["gradient_accumulation_steps"],
        learning_rate=config["learning_rate"],
        bf16=True,
        logging_steps=10,
        save_steps=100,
        save_total_limit=3,
        warmup_ratio=0.03,
        lr_scheduler_type="cosine",
        gradient_checkpointing=True,
        optim="adamw_torch",
        report_to="none",{strategy_args}
    )'''

    def generate(self, training_config, job_spec) -> str:
        """
        Generate complete training script.

        Args:
            training_config: TrainingConfig instance
            job_spec: FinetuneJobSpec instance

        Returns:
            Complete training script as string
        """
        return self.TRAIN_SCRIPT_TEMPLATE.format(
            strategy=self.config.strategy.value,
            num_gpus=self.config.num_gpus,
            distributed_imports=self._get_distributed_imports(),
            distributed_setup=self._get_distributed_setup(),
            quantization_imports=self._get_quantization_imports(training_config.use_quantization),
            model_loading=self._get_model_loading(training_config),
            training_args=self._get_training_args(training_config),
            model_path=job_spec.model_path or f"/workspace/models/{job_spec.model}",
            data_path=job_spec.dataset_path or "/workspace/data/train.jsonl",
            output_dir=job_spec.output_dir,
            num_epochs=training_config.num_epochs,
            batch_size=training_config.batch_size,
            learning_rate=training_config.learning_rate,
            max_seq_length=training_config.max_seq_length,
            gradient_accumulation_steps=training_config.gradient_accumulation_steps,
            use_lora=str(training_config.use_lora),
            lora_r=training_config.lora_r,
            lora_alpha=training_config.lora_alpha,
            use_quantization=str(training_config.use_quantization),
            quantization_bits=training_config.quantization_bits,
        )


def get_optimal_strategy(num_gpus: int, model_size_b: float = 7.0) -> DistributedConfig:
    """
    Get optimal distributed training strategy for given resources.

    Args:
        num_gpus: Number of GPUs available
        model_size_b: Model size in billions of parameters

    Returns:
        Configured DistributedConfig

    Example:
        config = get_optimal_strategy(num_gpus=4, model_size_b=7.0)
        print(f"Recommended strategy: {config.strategy.value}")
    """
    return DistributedConfig.auto(num_gpus, model_size_b)
