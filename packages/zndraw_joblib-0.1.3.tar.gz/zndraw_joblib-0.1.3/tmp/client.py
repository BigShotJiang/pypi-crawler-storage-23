# tmp/client.py
"""Example: How to register and run jobs via the client SDK."""

import time

import httpx

from zndraw_joblib import JobManager
from tasks import Rotate, SelectByElement, Translate


# 1. Create an API adapter (this connects to your server)
class MyApi:
    """Simple API adapter for JobManager."""

    def __init__(self, base_url: str, token: str):
        self._base_url = base_url
        self._token = token
        self.http = httpx.Client()

    @property
    def base_url(self) -> str:
        return self._base_url

    def get_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._token}"}


# 2. Create manager and register jobs (extensions defined in tasks.py)
api = MyApi(base_url="http://localhost:8000", token="my-worker-token")
manager = JobManager(api)

# 3. Create a worker first (gets a UUID from server)
# This links the worker to the authenticated user
worker_id = manager.create_worker()
print(f"Created worker: {worker_id}")

# 4. Register jobs (the worker_id is automatically included)
manager.register(Rotate)
manager.register(SelectByElement)
manager.register(Translate)

# For room-specific jobs:
# manager.register(Rotate, room="my_room_id")


# 5. Process tasks
def run_worker():
    """Main worker loop."""
    print(f"Worker ID: {manager.worker_id}")
    print(f"Registered jobs: {list(manager)}")
    print("Listening for tasks...")

    for task in manager.listen(polling_interval=1.0):
        print(f"Claimed task {task.task_id} for {task.job_name}")
        print(f"  Room: {task.room_id}")
        print(f"  Extension: {task.extension}")
        manager.start(task)
        # Call the extension's run method
        try:
            task.extension.run()
            time.sleep(2)  # Simulate work

            # Mark complete
            manager.complete(task)
        except Exception as e:
            # Mark failed
            manager.fail(task, error=str(e))

        # Send heartbeat periodically to keep worker alive
        manager.heartbeat()


# Alternative: claim one task at a time
def process_single_task():
    """Process just one task (or None if queue empty)."""
    task = manager.claim()
    if task is None:
        print("No tasks available")
        return

    print(f"Got task: {task.extension}")
    # ... process ...


if __name__ == "__main__":
    run_worker()
