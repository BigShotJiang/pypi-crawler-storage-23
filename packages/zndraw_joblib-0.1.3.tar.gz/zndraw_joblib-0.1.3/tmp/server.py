# tmp/server.py
"""Example server using zndraw-auth for authentication."""

import asyncio
from contextlib import asynccontextmanager
from unittest.mock import MagicMock
import uuid

from fastapi import FastAPI
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.pool import StaticPool

from zndraw_auth import (
    Base,
    User,
    current_active_user,
    current_superuser,
)
from zndraw_joblib.router import router
from zndraw_joblib.dependencies import get_async_session_maker
from zndraw_joblib.sweeper import run_sweeper
from zndraw_joblib.settings import JobLibSettings
from zndraw_joblib.exceptions import ProblemException, problem_exception_handler


# Create async engine for in-memory SQLite
async_engine = create_async_engine(
    "sqlite+aiosqlite://",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)

AsyncSessionLocal = async_sessionmaker(
    async_engine, class_=AsyncSession, expire_on_commit=False
)


def create_mock_user(user_id: str) -> User:
    """Create a mock user for testing/development."""
    # Convert bearer token to UUID (using namespace for consistency)
    if user_id == "anonymous":
        uid = uuid.UUID("00000000-0000-0000-0000-000000000000")
    else:
        uid = uuid.uuid5(uuid.NAMESPACE_DNS, user_id)

    user = MagicMock(spec=User)
    user.id = uid
    user.email = f"{user_id}@example.com"
    user.is_active = True
    user.is_superuser = True
    user.is_verified = True
    return user


async def get_sweeper_session():
    """Async session generator for the sweeper (non-DI context)."""
    async with AsyncSessionLocal() as session:
        yield session


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for startup/shutdown events."""
    # Startup: create tables and start sweeper
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    app.state.db_lock = asyncio.Lock()

    settings = JobLibSettings()
    sweeper_task = asyncio.create_task(run_sweeper(get_sweeper_session, settings))
    yield
    # Shutdown: cancel sweeper
    sweeper_task.cancel()
    try:
        await sweeper_task
    except asyncio.CancelledError:
        pass


def create_app() -> FastAPI:
    """Create a FastAPI app with dependency overrides for development."""
    from fastapi import Request

    async def get_user_from_bearer(request: Request) -> User:
        """Extract user from Authorization: Bearer <token> header."""
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            token = auth[7:]
            return create_mock_user(token)
        return create_mock_user("anonymous")

    app = FastAPI(lifespan=lifespan, title="ZnDraw JobLib Dev Server")
    app.include_router(router)
    app.add_exception_handler(ProblemException, problem_exception_handler)

    # Override dependencies — single session maker drives all DB access
    app.dependency_overrides[get_async_session_maker] = lambda: AsyncSessionLocal
    app.dependency_overrides[current_active_user] = get_user_from_bearer
    app.dependency_overrides[current_superuser] = get_user_from_bearer

    return app


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(create_app(), host="0.0.0.0", port=8000)
