import json
import setuptools

kwargs = json.loads(
    """
{
    "name": "cdktn-provider-azuread",
    "version": "15.1.0",
    "description": "Prebuilt azuread Provider for CDK Terrain (cdktn)",
    "license": "MPL-2.0",
    "url": "https://github.com/cdktn-io/cdktn-provider-azuread.git",
    "long_description_content_type": "text/markdown",
    "author": "CDK Terrain Maintainers",
    "bdist_wheel": {
        "universal": true
    },
    "project_urls": {
        "Source": "https://github.com/cdktn-io/cdktn-provider-azuread.git"
    },
    "package_dir": {
        "": "src"
    },
    "packages": [
        "cdktn_provider_azuread",
        "cdktn_provider_azuread._jsii",
        "cdktn_provider_azuread.access_package",
        "cdktn_provider_azuread.access_package_assignment_policy",
        "cdktn_provider_azuread.access_package_catalog",
        "cdktn_provider_azuread.access_package_catalog_role_assignment",
        "cdktn_provider_azuread.access_package_resource_catalog_association",
        "cdktn_provider_azuread.access_package_resource_package_association",
        "cdktn_provider_azuread.administrative_unit",
        "cdktn_provider_azuread.administrative_unit_member",
        "cdktn_provider_azuread.administrative_unit_role_member",
        "cdktn_provider_azuread.app_role_assignment",
        "cdktn_provider_azuread.application",
        "cdktn_provider_azuread.application_api_access",
        "cdktn_provider_azuread.application_app_role",
        "cdktn_provider_azuread.application_certificate",
        "cdktn_provider_azuread.application_fallback_public_client",
        "cdktn_provider_azuread.application_federated_identity_credential",
        "cdktn_provider_azuread.application_flexible_federated_identity_credential",
        "cdktn_provider_azuread.application_from_template",
        "cdktn_provider_azuread.application_identifier_uri",
        "cdktn_provider_azuread.application_known_clients",
        "cdktn_provider_azuread.application_optional_claims",
        "cdktn_provider_azuread.application_owner",
        "cdktn_provider_azuread.application_password",
        "cdktn_provider_azuread.application_permission_scope",
        "cdktn_provider_azuread.application_pre_authorized",
        "cdktn_provider_azuread.application_redirect_uris",
        "cdktn_provider_azuread.application_registration",
        "cdktn_provider_azuread.authentication_strength_policy",
        "cdktn_provider_azuread.claims_mapping_policy",
        "cdktn_provider_azuread.conditional_access_policy",
        "cdktn_provider_azuread.custom_directory_role",
        "cdktn_provider_azuread.data_azuread_access_package",
        "cdktn_provider_azuread.data_azuread_access_package_catalog",
        "cdktn_provider_azuread.data_azuread_access_package_catalog_role",
        "cdktn_provider_azuread.data_azuread_administrative_unit",
        "cdktn_provider_azuread.data_azuread_application",
        "cdktn_provider_azuread.data_azuread_application_published_app_ids",
        "cdktn_provider_azuread.data_azuread_application_template",
        "cdktn_provider_azuread.data_azuread_client_config",
        "cdktn_provider_azuread.data_azuread_directory_object",
        "cdktn_provider_azuread.data_azuread_directory_role_templates",
        "cdktn_provider_azuread.data_azuread_directory_roles",
        "cdktn_provider_azuread.data_azuread_domains",
        "cdktn_provider_azuread.data_azuread_group",
        "cdktn_provider_azuread.data_azuread_group_role_management_policy",
        "cdktn_provider_azuread.data_azuread_groups",
        "cdktn_provider_azuread.data_azuread_named_location",
        "cdktn_provider_azuread.data_azuread_service_principal",
        "cdktn_provider_azuread.data_azuread_service_principals",
        "cdktn_provider_azuread.data_azuread_user",
        "cdktn_provider_azuread.data_azuread_users",
        "cdktn_provider_azuread.directory_role",
        "cdktn_provider_azuread.directory_role_assignment",
        "cdktn_provider_azuread.directory_role_eligibility_schedule_request",
        "cdktn_provider_azuread.directory_role_member",
        "cdktn_provider_azuread.group",
        "cdktn_provider_azuread.group_member",
        "cdktn_provider_azuread.group_role_management_policy",
        "cdktn_provider_azuread.group_without_members",
        "cdktn_provider_azuread.invitation",
        "cdktn_provider_azuread.named_location",
        "cdktn_provider_azuread.privileged_access_group_assignment_schedule",
        "cdktn_provider_azuread.privileged_access_group_eligibility_schedule",
        "cdktn_provider_azuread.provider",
        "cdktn_provider_azuread.service_principal",
        "cdktn_provider_azuread.service_principal_certificate",
        "cdktn_provider_azuread.service_principal_claims_mapping_policy_assignment",
        "cdktn_provider_azuread.service_principal_delegated_permission_grant",
        "cdktn_provider_azuread.service_principal_password",
        "cdktn_provider_azuread.service_principal_token_signing_certificate",
        "cdktn_provider_azuread.synchronization_job",
        "cdktn_provider_azuread.synchronization_job_provision_on_demand",
        "cdktn_provider_azuread.synchronization_secret",
        "cdktn_provider_azuread.user",
        "cdktn_provider_azuread.user_flow_attribute"
    ],
    "package_data": {
        "cdktn_provider_azuread._jsii": [
            "provider-azuread@15.1.0.jsii.tgz"
        ],
        "cdktn_provider_azuread": [
            "py.typed"
        ]
    },
    "python_requires": "~=3.9",
    "install_requires": [
        "cdktn>=0.22.0, <0.23.0",
        "constructs>=10.4.2, <11.0.0",
        "jsii>=1.119.0, <2.0.0",
        "publication>=0.0.3",
        "typeguard>=2.13.3,<4.3.0"
    ],
    "classifiers": [
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: JavaScript",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Typing :: Typed",
        "Development Status :: 5 - Production/Stable",
        "License :: OSI Approved"
    ],
    "scripts": []
}
"""
)

with open("README.md", encoding="utf8") as fp:
    kwargs["long_description"] = fp.read()


setuptools.setup(**kwargs)
