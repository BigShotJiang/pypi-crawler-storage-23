r'''
# `azuread_group_role_management_policy`

Refer to the Terraform Registry for docs: [`azuread_group_role_management_policy`](https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class GroupRoleManagementPolicy(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicy",
):
    '''Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy azuread_group_role_management_policy}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id_: builtins.str,
        *,
        group_id: builtins.str,
        role_id: builtins.str,
        activation_rules: typing.Optional[typing.Union["GroupRoleManagementPolicyActivationRules", typing.Dict[builtins.str, typing.Any]]] = None,
        active_assignment_rules: typing.Optional[typing.Union["GroupRoleManagementPolicyActiveAssignmentRules", typing.Dict[builtins.str, typing.Any]]] = None,
        eligible_assignment_rules: typing.Optional[typing.Union["GroupRoleManagementPolicyEligibleAssignmentRules", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
        notification_rules: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRules", typing.Dict[builtins.str, typing.Any]]] = None,
        timeouts: typing.Optional[typing.Union["GroupRoleManagementPolicyTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy azuread_group_role_management_policy} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param group_id: ID of the group to which this policy is assigned. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#group_id GroupRoleManagementPolicy#group_id}
        :param role_id: The ID of the role of this policy to the group. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#role_id GroupRoleManagementPolicy#role_id}
        :param activation_rules: activation_rules block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#activation_rules GroupRoleManagementPolicy#activation_rules}
        :param active_assignment_rules: active_assignment_rules block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#active_assignment_rules GroupRoleManagementPolicy#active_assignment_rules}
        :param eligible_assignment_rules: eligible_assignment_rules block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#eligible_assignment_rules GroupRoleManagementPolicy#eligible_assignment_rules}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#id GroupRoleManagementPolicy#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param notification_rules: notification_rules block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_rules GroupRoleManagementPolicy#notification_rules}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#timeouts GroupRoleManagementPolicy#timeouts}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f81b873916540f075ad52a8d601d009c8fbe7b1fc77886585b992a350abd0894)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = GroupRoleManagementPolicyConfig(
            group_id=group_id,
            role_id=role_id,
            activation_rules=activation_rules,
            active_assignment_rules=active_assignment_rules,
            eligible_assignment_rules=eligible_assignment_rules,
            id=id,
            notification_rules=notification_rules,
            timeouts=timeouts,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    ) -> _cdktn_78ede62e.ImportableResource:
        '''Generates CDKTN code for importing a GroupRoleManagementPolicy resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the GroupRoleManagementPolicy to import.
        :param import_from_id: The id of the existing GroupRoleManagementPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the GroupRoleManagementPolicy to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__858365afa1ee05d6dbc3ee39c54e9cd7a7a81bce6d1b2e96a1927873108abb6c)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktn_78ede62e.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putActivationRules")
    def put_activation_rules(
        self,
        *,
        approval_stage: typing.Optional[typing.Union["GroupRoleManagementPolicyActivationRulesApprovalStage", typing.Dict[builtins.str, typing.Any]]] = None,
        maximum_duration: typing.Optional[builtins.str] = None,
        require_approval: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        required_conditional_access_authentication_context: typing.Optional[builtins.str] = None,
        require_justification: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        require_multifactor_authentication: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        require_ticket_info: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param approval_stage: approval_stage block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#approval_stage GroupRoleManagementPolicy#approval_stage}
        :param maximum_duration: The time after which the an activation can be valid for. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#maximum_duration GroupRoleManagementPolicy#maximum_duration}
        :param require_approval: Whether an approval is required for activation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_approval GroupRoleManagementPolicy#require_approval}
        :param required_conditional_access_authentication_context: Whether a conditional access context is required during activation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#required_conditional_access_authentication_context GroupRoleManagementPolicy#required_conditional_access_authentication_context}
        :param require_justification: Whether a justification is required during activation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_justification GroupRoleManagementPolicy#require_justification}
        :param require_multifactor_authentication: Whether multi-factor authentication is required during activation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_multifactor_authentication GroupRoleManagementPolicy#require_multifactor_authentication}
        :param require_ticket_info: Whether ticket information is required during activation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_ticket_info GroupRoleManagementPolicy#require_ticket_info}
        '''
        value = GroupRoleManagementPolicyActivationRules(
            approval_stage=approval_stage,
            maximum_duration=maximum_duration,
            require_approval=require_approval,
            required_conditional_access_authentication_context=required_conditional_access_authentication_context,
            require_justification=require_justification,
            require_multifactor_authentication=require_multifactor_authentication,
            require_ticket_info=require_ticket_info,
        )

        return typing.cast(None, jsii.invoke(self, "putActivationRules", [value]))

    @jsii.member(jsii_name="putActiveAssignmentRules")
    def put_active_assignment_rules(
        self,
        *,
        expiration_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        expire_after: typing.Optional[builtins.str] = None,
        require_justification: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        require_multifactor_authentication: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        require_ticket_info: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param expiration_required: Must the assignment have an expiry date. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#expiration_required GroupRoleManagementPolicy#expiration_required}
        :param expire_after: The duration after which assignments expire. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#expire_after GroupRoleManagementPolicy#expire_after}
        :param require_justification: Whether a justification is required to make an assignment. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_justification GroupRoleManagementPolicy#require_justification}
        :param require_multifactor_authentication: Whether multi-factor authentication is required to make an assignment. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_multifactor_authentication GroupRoleManagementPolicy#require_multifactor_authentication}
        :param require_ticket_info: Whether ticket information is required to make an assignment. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_ticket_info GroupRoleManagementPolicy#require_ticket_info}
        '''
        value = GroupRoleManagementPolicyActiveAssignmentRules(
            expiration_required=expiration_required,
            expire_after=expire_after,
            require_justification=require_justification,
            require_multifactor_authentication=require_multifactor_authentication,
            require_ticket_info=require_ticket_info,
        )

        return typing.cast(None, jsii.invoke(self, "putActiveAssignmentRules", [value]))

    @jsii.member(jsii_name="putEligibleAssignmentRules")
    def put_eligible_assignment_rules(
        self,
        *,
        expiration_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        expire_after: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param expiration_required: Must the assignment have an expiry date. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#expiration_required GroupRoleManagementPolicy#expiration_required}
        :param expire_after: The duration after which assignments expire. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#expire_after GroupRoleManagementPolicy#expire_after}
        '''
        value = GroupRoleManagementPolicyEligibleAssignmentRules(
            expiration_required=expiration_required, expire_after=expire_after
        )

        return typing.cast(None, jsii.invoke(self, "putEligibleAssignmentRules", [value]))

    @jsii.member(jsii_name="putNotificationRules")
    def put_notification_rules(
        self,
        *,
        active_assignments: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRulesActiveAssignments", typing.Dict[builtins.str, typing.Any]]] = None,
        eligible_activations: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRulesEligibleActivations", typing.Dict[builtins.str, typing.Any]]] = None,
        eligible_assignments: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRulesEligibleAssignments", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param active_assignments: active_assignments block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#active_assignments GroupRoleManagementPolicy#active_assignments}
        :param eligible_activations: eligible_activations block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#eligible_activations GroupRoleManagementPolicy#eligible_activations}
        :param eligible_assignments: eligible_assignments block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#eligible_assignments GroupRoleManagementPolicy#eligible_assignments}
        '''
        value = GroupRoleManagementPolicyNotificationRules(
            active_assignments=active_assignments,
            eligible_activations=eligible_activations,
            eligible_assignments=eligible_assignments,
        )

        return typing.cast(None, jsii.invoke(self, "putNotificationRules", [value]))

    @jsii.member(jsii_name="putTimeouts")
    def put_timeouts(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#create GroupRoleManagementPolicy#create}.
        :param delete: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#delete GroupRoleManagementPolicy#delete}.
        :param read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#read GroupRoleManagementPolicy#read}.
        :param update: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#update GroupRoleManagementPolicy#update}.
        '''
        value = GroupRoleManagementPolicyTimeouts(
            create=create, delete=delete, read=read, update=update
        )

        return typing.cast(None, jsii.invoke(self, "putTimeouts", [value]))

    @jsii.member(jsii_name="resetActivationRules")
    def reset_activation_rules(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetActivationRules", []))

    @jsii.member(jsii_name="resetActiveAssignmentRules")
    def reset_active_assignment_rules(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetActiveAssignmentRules", []))

    @jsii.member(jsii_name="resetEligibleAssignmentRules")
    def reset_eligible_assignment_rules(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEligibleAssignmentRules", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetNotificationRules")
    def reset_notification_rules(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNotificationRules", []))

    @jsii.member(jsii_name="resetTimeouts")
    def reset_timeouts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeouts", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="activationRules")
    def activation_rules(
        self,
    ) -> "GroupRoleManagementPolicyActivationRulesOutputReference":
        return typing.cast("GroupRoleManagementPolicyActivationRulesOutputReference", jsii.get(self, "activationRules"))

    @builtins.property
    @jsii.member(jsii_name="activeAssignmentRules")
    def active_assignment_rules(
        self,
    ) -> "GroupRoleManagementPolicyActiveAssignmentRulesOutputReference":
        return typing.cast("GroupRoleManagementPolicyActiveAssignmentRulesOutputReference", jsii.get(self, "activeAssignmentRules"))

    @builtins.property
    @jsii.member(jsii_name="description")
    def description(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "description"))

    @builtins.property
    @jsii.member(jsii_name="displayName")
    def display_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "displayName"))

    @builtins.property
    @jsii.member(jsii_name="eligibleAssignmentRules")
    def eligible_assignment_rules(
        self,
    ) -> "GroupRoleManagementPolicyEligibleAssignmentRulesOutputReference":
        return typing.cast("GroupRoleManagementPolicyEligibleAssignmentRulesOutputReference", jsii.get(self, "eligibleAssignmentRules"))

    @builtins.property
    @jsii.member(jsii_name="notificationRules")
    def notification_rules(
        self,
    ) -> "GroupRoleManagementPolicyNotificationRulesOutputReference":
        return typing.cast("GroupRoleManagementPolicyNotificationRulesOutputReference", jsii.get(self, "notificationRules"))

    @builtins.property
    @jsii.member(jsii_name="timeouts")
    def timeouts(self) -> "GroupRoleManagementPolicyTimeoutsOutputReference":
        return typing.cast("GroupRoleManagementPolicyTimeoutsOutputReference", jsii.get(self, "timeouts"))

    @builtins.property
    @jsii.member(jsii_name="activationRulesInput")
    def activation_rules_input(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyActivationRules"]:
        return typing.cast(typing.Optional["GroupRoleManagementPolicyActivationRules"], jsii.get(self, "activationRulesInput"))

    @builtins.property
    @jsii.member(jsii_name="activeAssignmentRulesInput")
    def active_assignment_rules_input(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyActiveAssignmentRules"]:
        return typing.cast(typing.Optional["GroupRoleManagementPolicyActiveAssignmentRules"], jsii.get(self, "activeAssignmentRulesInput"))

    @builtins.property
    @jsii.member(jsii_name="eligibleAssignmentRulesInput")
    def eligible_assignment_rules_input(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyEligibleAssignmentRules"]:
        return typing.cast(typing.Optional["GroupRoleManagementPolicyEligibleAssignmentRules"], jsii.get(self, "eligibleAssignmentRulesInput"))

    @builtins.property
    @jsii.member(jsii_name="groupIdInput")
    def group_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "groupIdInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="notificationRulesInput")
    def notification_rules_input(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyNotificationRules"]:
        return typing.cast(typing.Optional["GroupRoleManagementPolicyNotificationRules"], jsii.get(self, "notificationRulesInput"))

    @builtins.property
    @jsii.member(jsii_name="roleIdInput")
    def role_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "roleIdInput"))

    @builtins.property
    @jsii.member(jsii_name="timeoutsInput")
    def timeouts_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "GroupRoleManagementPolicyTimeouts"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "GroupRoleManagementPolicyTimeouts"]], jsii.get(self, "timeoutsInput"))

    @builtins.property
    @jsii.member(jsii_name="groupId")
    def group_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "groupId"))

    @group_id.setter
    def group_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__db8be80b239e46747d91be85314fb238e4c4acbf12d4656c647c508d53e2e6da)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "groupId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0e52b77b94735ac0cada409c1299e06f42f56acc169d8a8aad87881ee6b50267)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="roleId")
    def role_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "roleId"))

    @role_id.setter
    def role_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d956be5f6972a2cb95944eb3dd8485fad23d62bc8ad73db63598ef9ab6afb4fe)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "roleId", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyActivationRules",
    jsii_struct_bases=[],
    name_mapping={
        "approval_stage": "approvalStage",
        "maximum_duration": "maximumDuration",
        "require_approval": "requireApproval",
        "required_conditional_access_authentication_context": "requiredConditionalAccessAuthenticationContext",
        "require_justification": "requireJustification",
        "require_multifactor_authentication": "requireMultifactorAuthentication",
        "require_ticket_info": "requireTicketInfo",
    },
)
class GroupRoleManagementPolicyActivationRules:
    def __init__(
        self,
        *,
        approval_stage: typing.Optional[typing.Union["GroupRoleManagementPolicyActivationRulesApprovalStage", typing.Dict[builtins.str, typing.Any]]] = None,
        maximum_duration: typing.Optional[builtins.str] = None,
        require_approval: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        required_conditional_access_authentication_context: typing.Optional[builtins.str] = None,
        require_justification: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        require_multifactor_authentication: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        require_ticket_info: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param approval_stage: approval_stage block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#approval_stage GroupRoleManagementPolicy#approval_stage}
        :param maximum_duration: The time after which the an activation can be valid for. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#maximum_duration GroupRoleManagementPolicy#maximum_duration}
        :param require_approval: Whether an approval is required for activation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_approval GroupRoleManagementPolicy#require_approval}
        :param required_conditional_access_authentication_context: Whether a conditional access context is required during activation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#required_conditional_access_authentication_context GroupRoleManagementPolicy#required_conditional_access_authentication_context}
        :param require_justification: Whether a justification is required during activation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_justification GroupRoleManagementPolicy#require_justification}
        :param require_multifactor_authentication: Whether multi-factor authentication is required during activation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_multifactor_authentication GroupRoleManagementPolicy#require_multifactor_authentication}
        :param require_ticket_info: Whether ticket information is required during activation. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_ticket_info GroupRoleManagementPolicy#require_ticket_info}
        '''
        if isinstance(approval_stage, dict):
            approval_stage = GroupRoleManagementPolicyActivationRulesApprovalStage(**approval_stage)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6aab3147b51ebb389517b364527fe502e431a104b89b93abd0b703b13a297096)
            check_type(argname="argument approval_stage", value=approval_stage, expected_type=type_hints["approval_stage"])
            check_type(argname="argument maximum_duration", value=maximum_duration, expected_type=type_hints["maximum_duration"])
            check_type(argname="argument require_approval", value=require_approval, expected_type=type_hints["require_approval"])
            check_type(argname="argument required_conditional_access_authentication_context", value=required_conditional_access_authentication_context, expected_type=type_hints["required_conditional_access_authentication_context"])
            check_type(argname="argument require_justification", value=require_justification, expected_type=type_hints["require_justification"])
            check_type(argname="argument require_multifactor_authentication", value=require_multifactor_authentication, expected_type=type_hints["require_multifactor_authentication"])
            check_type(argname="argument require_ticket_info", value=require_ticket_info, expected_type=type_hints["require_ticket_info"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if approval_stage is not None:
            self._values["approval_stage"] = approval_stage
        if maximum_duration is not None:
            self._values["maximum_duration"] = maximum_duration
        if require_approval is not None:
            self._values["require_approval"] = require_approval
        if required_conditional_access_authentication_context is not None:
            self._values["required_conditional_access_authentication_context"] = required_conditional_access_authentication_context
        if require_justification is not None:
            self._values["require_justification"] = require_justification
        if require_multifactor_authentication is not None:
            self._values["require_multifactor_authentication"] = require_multifactor_authentication
        if require_ticket_info is not None:
            self._values["require_ticket_info"] = require_ticket_info

    @builtins.property
    def approval_stage(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyActivationRulesApprovalStage"]:
        '''approval_stage block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#approval_stage GroupRoleManagementPolicy#approval_stage}
        '''
        result = self._values.get("approval_stage")
        return typing.cast(typing.Optional["GroupRoleManagementPolicyActivationRulesApprovalStage"], result)

    @builtins.property
    def maximum_duration(self) -> typing.Optional[builtins.str]:
        '''The time after which the an activation can be valid for.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#maximum_duration GroupRoleManagementPolicy#maximum_duration}
        '''
        result = self._values.get("maximum_duration")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def require_approval(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether an approval is required for activation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_approval GroupRoleManagementPolicy#require_approval}
        '''
        result = self._values.get("require_approval")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def required_conditional_access_authentication_context(
        self,
    ) -> typing.Optional[builtins.str]:
        '''Whether a conditional access context is required during activation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#required_conditional_access_authentication_context GroupRoleManagementPolicy#required_conditional_access_authentication_context}
        '''
        result = self._values.get("required_conditional_access_authentication_context")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def require_justification(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether a justification is required during activation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_justification GroupRoleManagementPolicy#require_justification}
        '''
        result = self._values.get("require_justification")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def require_multifactor_authentication(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether multi-factor authentication is required during activation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_multifactor_authentication GroupRoleManagementPolicy#require_multifactor_authentication}
        '''
        result = self._values.get("require_multifactor_authentication")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def require_ticket_info(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether ticket information is required during activation.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_ticket_info GroupRoleManagementPolicy#require_ticket_info}
        '''
        result = self._values.get("require_ticket_info")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyActivationRules(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyActivationRulesApprovalStage",
    jsii_struct_bases=[],
    name_mapping={"primary_approver": "primaryApprover"},
)
class GroupRoleManagementPolicyActivationRulesApprovalStage:
    def __init__(
        self,
        *,
        primary_approver: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param primary_approver: primary_approver block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#primary_approver GroupRoleManagementPolicy#primary_approver}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ce3fc026b3a566020641b3959083cb59ac837d8bac47d9cd482914f46a3f697b)
            check_type(argname="argument primary_approver", value=primary_approver, expected_type=type_hints["primary_approver"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "primary_approver": primary_approver,
        }

    @builtins.property
    def primary_approver(
        self,
    ) -> typing.Union[_cdktn_78ede62e.IResolvable, typing.List["GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover"]]:
        '''primary_approver block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#primary_approver GroupRoleManagementPolicy#primary_approver}
        '''
        result = self._values.get("primary_approver")
        assert result is not None, "Required property 'primary_approver' is missing"
        return typing.cast(typing.Union[_cdktn_78ede62e.IResolvable, typing.List["GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyActivationRulesApprovalStage(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class GroupRoleManagementPolicyActivationRulesApprovalStageOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyActivationRulesApprovalStageOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__39f100fbb0cae41263ffc16a6958921cec182488973a99c7a4d2e778ce508ced)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putPrimaryApprover")
    def put_primary_approver(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__63d0eaf95e535ec6e686fd7508906bd7756edc91b4c5ed22d0c36f077c87f371)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putPrimaryApprover", [value]))

    @builtins.property
    @jsii.member(jsii_name="primaryApprover")
    def primary_approver(
        self,
    ) -> "GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApproverList":
        return typing.cast("GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApproverList", jsii.get(self, "primaryApprover"))

    @builtins.property
    @jsii.member(jsii_name="primaryApproverInput")
    def primary_approver_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover"]]], jsii.get(self, "primaryApproverInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyActivationRulesApprovalStage]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyActivationRulesApprovalStage], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyActivationRulesApprovalStage],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cf9f8343a04098d69c96370ae7fcabd1a121c448b0076ba65b50244cda4f16fd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover",
    jsii_struct_bases=[],
    name_mapping={"object_id": "objectId", "type": "type"},
)
class GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover:
    def __init__(
        self,
        *,
        object_id: builtins.str,
        type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param object_id: The ID of the object to act as an approver. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#object_id GroupRoleManagementPolicy#object_id}
        :param type: The type of object acting as an approver. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#type GroupRoleManagementPolicy#type}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cf95f28704a56ca0012622d0acd71509197151a5fd144113721da3816a095190)
            check_type(argname="argument object_id", value=object_id, expected_type=type_hints["object_id"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "object_id": object_id,
        }
        if type is not None:
            self._values["type"] = type

    @builtins.property
    def object_id(self) -> builtins.str:
        '''The ID of the object to act as an approver.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#object_id GroupRoleManagementPolicy#object_id}
        '''
        result = self._values.get("object_id")
        assert result is not None, "Required property 'object_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def type(self) -> typing.Optional[builtins.str]:
        '''The type of object acting as an approver.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#type GroupRoleManagementPolicy#type}
        '''
        result = self._values.get("type")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApproverList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApproverList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0a248805f08958b30b392abff22cce7174585dfe418cde93366955b1738d13a6)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApproverOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e248f9d415695ba12273abba0c71e2746cf4af96b2793c7044ba6b778f866514)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApproverOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__766ad44a06ba37dcc10e20e5706468c571a020b0c661fc78b0a167db35dc0116)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9583814e81743fac93ed2c8f2e2182736147c6f37581453d9b19de10882a6036)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9158b74fb650f1cc59c40abb20b0707d50b3e16e867e168c4ad418fc2609507d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__774e1bd6a19fa79b4dd2e15d58ca93b22a848f0b2b2c0350e0df59700a196b99)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApproverOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApproverOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__654d858decde76f00da2aa0c1dad780afb76c1a1956770fe6610dd7510763b67)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetType")
    def reset_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetType", []))

    @builtins.property
    @jsii.member(jsii_name="objectIdInput")
    def object_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "objectIdInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="objectId")
    def object_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "objectId"))

    @object_id.setter
    def object_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cccf0857111803b2a9dfef72cb87c3c2e427567e9d36e1a459cd169a877de380)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "objectId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dd677a413977bb05896a815a9e956efff8249b45765faf962dfd426ed8c1f0e1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__823d244ef211f455a2a3c3854a7e9d2e328cde143f1a3087bf9af9d6ccc03ac8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class GroupRoleManagementPolicyActivationRulesOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyActivationRulesOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__21ccc9a1ef98df8e2d73194e9f40ffa2e5c86806c29a6289a3349cc0e816d66c)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putApprovalStage")
    def put_approval_stage(
        self,
        *,
        primary_approver: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover, typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param primary_approver: primary_approver block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#primary_approver GroupRoleManagementPolicy#primary_approver}
        '''
        value = GroupRoleManagementPolicyActivationRulesApprovalStage(
            primary_approver=primary_approver
        )

        return typing.cast(None, jsii.invoke(self, "putApprovalStage", [value]))

    @jsii.member(jsii_name="resetApprovalStage")
    def reset_approval_stage(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetApprovalStage", []))

    @jsii.member(jsii_name="resetMaximumDuration")
    def reset_maximum_duration(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetMaximumDuration", []))

    @jsii.member(jsii_name="resetRequireApproval")
    def reset_require_approval(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequireApproval", []))

    @jsii.member(jsii_name="resetRequiredConditionalAccessAuthenticationContext")
    def reset_required_conditional_access_authentication_context(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequiredConditionalAccessAuthenticationContext", []))

    @jsii.member(jsii_name="resetRequireJustification")
    def reset_require_justification(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequireJustification", []))

    @jsii.member(jsii_name="resetRequireMultifactorAuthentication")
    def reset_require_multifactor_authentication(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequireMultifactorAuthentication", []))

    @jsii.member(jsii_name="resetRequireTicketInfo")
    def reset_require_ticket_info(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequireTicketInfo", []))

    @builtins.property
    @jsii.member(jsii_name="approvalStage")
    def approval_stage(
        self,
    ) -> GroupRoleManagementPolicyActivationRulesApprovalStageOutputReference:
        return typing.cast(GroupRoleManagementPolicyActivationRulesApprovalStageOutputReference, jsii.get(self, "approvalStage"))

    @builtins.property
    @jsii.member(jsii_name="approvalStageInput")
    def approval_stage_input(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyActivationRulesApprovalStage]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyActivationRulesApprovalStage], jsii.get(self, "approvalStageInput"))

    @builtins.property
    @jsii.member(jsii_name="maximumDurationInput")
    def maximum_duration_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "maximumDurationInput"))

    @builtins.property
    @jsii.member(jsii_name="requireApprovalInput")
    def require_approval_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "requireApprovalInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredConditionalAccessAuthenticationContextInput")
    def required_conditional_access_authentication_context_input(
        self,
    ) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "requiredConditionalAccessAuthenticationContextInput"))

    @builtins.property
    @jsii.member(jsii_name="requireJustificationInput")
    def require_justification_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "requireJustificationInput"))

    @builtins.property
    @jsii.member(jsii_name="requireMultifactorAuthenticationInput")
    def require_multifactor_authentication_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "requireMultifactorAuthenticationInput"))

    @builtins.property
    @jsii.member(jsii_name="requireTicketInfoInput")
    def require_ticket_info_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "requireTicketInfoInput"))

    @builtins.property
    @jsii.member(jsii_name="maximumDuration")
    def maximum_duration(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "maximumDuration"))

    @maximum_duration.setter
    def maximum_duration(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__09fd8a49b73186ff1edd54277d5a4bb4386826464ec52ca5d4d7a14440587a02)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "maximumDuration", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requireApproval")
    def require_approval(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "requireApproval"))

    @require_approval.setter
    def require_approval(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__252d130551d796782efca98062a80fdb4c0c2d922a95fe02cbbf0ce9419c5331)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requireApproval", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requiredConditionalAccessAuthenticationContext")
    def required_conditional_access_authentication_context(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "requiredConditionalAccessAuthenticationContext"))

    @required_conditional_access_authentication_context.setter
    def required_conditional_access_authentication_context(
        self,
        value: builtins.str,
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9df3f05bcbc08bdde2f42881d4783250927158bd26e88f091ebaa6c35242e083)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requiredConditionalAccessAuthenticationContext", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requireJustification")
    def require_justification(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "requireJustification"))

    @require_justification.setter
    def require_justification(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ce1c4eb197ccd4664ae9c06eb22f8e13e168e9f0ec0d7f8006d63ba99036344f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requireJustification", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requireMultifactorAuthentication")
    def require_multifactor_authentication(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "requireMultifactorAuthentication"))

    @require_multifactor_authentication.setter
    def require_multifactor_authentication(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ddbbd5c567fe27d317db63120d9c6bd356dde75c1fe29ac0a5d4fad1e55c2684)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requireMultifactorAuthentication", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requireTicketInfo")
    def require_ticket_info(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "requireTicketInfo"))

    @require_ticket_info.setter
    def require_ticket_info(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d04bad79cc0b8f52fe1e5fe9ac8d3c22079ed1bffbc2d75f4be517632a015657)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requireTicketInfo", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyActivationRules]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyActivationRules], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyActivationRules],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d9c1dab84a5fd74748040be8e028c382fa6a81ce28d514aeee48ea9805a4d277)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyActiveAssignmentRules",
    jsii_struct_bases=[],
    name_mapping={
        "expiration_required": "expirationRequired",
        "expire_after": "expireAfter",
        "require_justification": "requireJustification",
        "require_multifactor_authentication": "requireMultifactorAuthentication",
        "require_ticket_info": "requireTicketInfo",
    },
)
class GroupRoleManagementPolicyActiveAssignmentRules:
    def __init__(
        self,
        *,
        expiration_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        expire_after: typing.Optional[builtins.str] = None,
        require_justification: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        require_multifactor_authentication: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        require_ticket_info: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param expiration_required: Must the assignment have an expiry date. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#expiration_required GroupRoleManagementPolicy#expiration_required}
        :param expire_after: The duration after which assignments expire. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#expire_after GroupRoleManagementPolicy#expire_after}
        :param require_justification: Whether a justification is required to make an assignment. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_justification GroupRoleManagementPolicy#require_justification}
        :param require_multifactor_authentication: Whether multi-factor authentication is required to make an assignment. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_multifactor_authentication GroupRoleManagementPolicy#require_multifactor_authentication}
        :param require_ticket_info: Whether ticket information is required to make an assignment. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_ticket_info GroupRoleManagementPolicy#require_ticket_info}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__336f6c87dee6b2c30868943deb80c7dfb7130f7e64f8f8523024b244f3839ec8)
            check_type(argname="argument expiration_required", value=expiration_required, expected_type=type_hints["expiration_required"])
            check_type(argname="argument expire_after", value=expire_after, expected_type=type_hints["expire_after"])
            check_type(argname="argument require_justification", value=require_justification, expected_type=type_hints["require_justification"])
            check_type(argname="argument require_multifactor_authentication", value=require_multifactor_authentication, expected_type=type_hints["require_multifactor_authentication"])
            check_type(argname="argument require_ticket_info", value=require_ticket_info, expected_type=type_hints["require_ticket_info"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if expiration_required is not None:
            self._values["expiration_required"] = expiration_required
        if expire_after is not None:
            self._values["expire_after"] = expire_after
        if require_justification is not None:
            self._values["require_justification"] = require_justification
        if require_multifactor_authentication is not None:
            self._values["require_multifactor_authentication"] = require_multifactor_authentication
        if require_ticket_info is not None:
            self._values["require_ticket_info"] = require_ticket_info

    @builtins.property
    def expiration_required(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Must the assignment have an expiry date.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#expiration_required GroupRoleManagementPolicy#expiration_required}
        '''
        result = self._values.get("expiration_required")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def expire_after(self) -> typing.Optional[builtins.str]:
        '''The duration after which assignments expire.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#expire_after GroupRoleManagementPolicy#expire_after}
        '''
        result = self._values.get("expire_after")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def require_justification(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether a justification is required to make an assignment.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_justification GroupRoleManagementPolicy#require_justification}
        '''
        result = self._values.get("require_justification")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def require_multifactor_authentication(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether multi-factor authentication is required to make an assignment.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_multifactor_authentication GroupRoleManagementPolicy#require_multifactor_authentication}
        '''
        result = self._values.get("require_multifactor_authentication")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def require_ticket_info(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether ticket information is required to make an assignment.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#require_ticket_info GroupRoleManagementPolicy#require_ticket_info}
        '''
        result = self._values.get("require_ticket_info")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyActiveAssignmentRules(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class GroupRoleManagementPolicyActiveAssignmentRulesOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyActiveAssignmentRulesOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e11fe4e023d0d2b466264b4752ad29d084607c4380deeb51d624d40d437f1fe8)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetExpirationRequired")
    def reset_expiration_required(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExpirationRequired", []))

    @jsii.member(jsii_name="resetExpireAfter")
    def reset_expire_after(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExpireAfter", []))

    @jsii.member(jsii_name="resetRequireJustification")
    def reset_require_justification(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequireJustification", []))

    @jsii.member(jsii_name="resetRequireMultifactorAuthentication")
    def reset_require_multifactor_authentication(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequireMultifactorAuthentication", []))

    @jsii.member(jsii_name="resetRequireTicketInfo")
    def reset_require_ticket_info(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequireTicketInfo", []))

    @builtins.property
    @jsii.member(jsii_name="expirationRequiredInput")
    def expiration_required_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "expirationRequiredInput"))

    @builtins.property
    @jsii.member(jsii_name="expireAfterInput")
    def expire_after_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "expireAfterInput"))

    @builtins.property
    @jsii.member(jsii_name="requireJustificationInput")
    def require_justification_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "requireJustificationInput"))

    @builtins.property
    @jsii.member(jsii_name="requireMultifactorAuthenticationInput")
    def require_multifactor_authentication_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "requireMultifactorAuthenticationInput"))

    @builtins.property
    @jsii.member(jsii_name="requireTicketInfoInput")
    def require_ticket_info_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "requireTicketInfoInput"))

    @builtins.property
    @jsii.member(jsii_name="expirationRequired")
    def expiration_required(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "expirationRequired"))

    @expiration_required.setter
    def expiration_required(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9944010d1064f954793f4acc892259172b4b8b1c134d0c7e23fab912d5f86466)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "expirationRequired", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="expireAfter")
    def expire_after(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "expireAfter"))

    @expire_after.setter
    def expire_after(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__12cd889f4e1e5a7b86fec565f62ffc20a63990c4b78656c9a27f4c13cc98ef25)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "expireAfter", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requireJustification")
    def require_justification(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "requireJustification"))

    @require_justification.setter
    def require_justification(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4b3fa39cb1a5ee9d60cabc5e90292502bb53a82a4b493a50da0b65ab23293d93)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requireJustification", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requireMultifactorAuthentication")
    def require_multifactor_authentication(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "requireMultifactorAuthentication"))

    @require_multifactor_authentication.setter
    def require_multifactor_authentication(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cb23e60f0b8af07233c51a3abed6a4fbf205491109cff0e3b0103b0d42eb5085)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requireMultifactorAuthentication", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requireTicketInfo")
    def require_ticket_info(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "requireTicketInfo"))

    @require_ticket_info.setter
    def require_ticket_info(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7b4e0c7d3a9e2b82df6485a086bf9102b24365cbb5bca2f26a9bd6b1985b8865)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requireTicketInfo", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyActiveAssignmentRules]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyActiveAssignmentRules], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyActiveAssignmentRules],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c581292c87130cfe6098c6c537de641fc6276c319887c22e85ad57fbea84b4a8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "group_id": "groupId",
        "role_id": "roleId",
        "activation_rules": "activationRules",
        "active_assignment_rules": "activeAssignmentRules",
        "eligible_assignment_rules": "eligibleAssignmentRules",
        "id": "id",
        "notification_rules": "notificationRules",
        "timeouts": "timeouts",
    },
)
class GroupRoleManagementPolicyConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        group_id: builtins.str,
        role_id: builtins.str,
        activation_rules: typing.Optional[typing.Union[GroupRoleManagementPolicyActivationRules, typing.Dict[builtins.str, typing.Any]]] = None,
        active_assignment_rules: typing.Optional[typing.Union[GroupRoleManagementPolicyActiveAssignmentRules, typing.Dict[builtins.str, typing.Any]]] = None,
        eligible_assignment_rules: typing.Optional[typing.Union["GroupRoleManagementPolicyEligibleAssignmentRules", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[builtins.str] = None,
        notification_rules: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRules", typing.Dict[builtins.str, typing.Any]]] = None,
        timeouts: typing.Optional[typing.Union["GroupRoleManagementPolicyTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param group_id: ID of the group to which this policy is assigned. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#group_id GroupRoleManagementPolicy#group_id}
        :param role_id: The ID of the role of this policy to the group. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#role_id GroupRoleManagementPolicy#role_id}
        :param activation_rules: activation_rules block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#activation_rules GroupRoleManagementPolicy#activation_rules}
        :param active_assignment_rules: active_assignment_rules block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#active_assignment_rules GroupRoleManagementPolicy#active_assignment_rules}
        :param eligible_assignment_rules: eligible_assignment_rules block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#eligible_assignment_rules GroupRoleManagementPolicy#eligible_assignment_rules}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#id GroupRoleManagementPolicy#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param notification_rules: notification_rules block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_rules GroupRoleManagementPolicy#notification_rules}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#timeouts GroupRoleManagementPolicy#timeouts}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(activation_rules, dict):
            activation_rules = GroupRoleManagementPolicyActivationRules(**activation_rules)
        if isinstance(active_assignment_rules, dict):
            active_assignment_rules = GroupRoleManagementPolicyActiveAssignmentRules(**active_assignment_rules)
        if isinstance(eligible_assignment_rules, dict):
            eligible_assignment_rules = GroupRoleManagementPolicyEligibleAssignmentRules(**eligible_assignment_rules)
        if isinstance(notification_rules, dict):
            notification_rules = GroupRoleManagementPolicyNotificationRules(**notification_rules)
        if isinstance(timeouts, dict):
            timeouts = GroupRoleManagementPolicyTimeouts(**timeouts)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__314cef4dedb20ac983962eb27f99698871810092c017c74ac5e46993b12d23ad)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument group_id", value=group_id, expected_type=type_hints["group_id"])
            check_type(argname="argument role_id", value=role_id, expected_type=type_hints["role_id"])
            check_type(argname="argument activation_rules", value=activation_rules, expected_type=type_hints["activation_rules"])
            check_type(argname="argument active_assignment_rules", value=active_assignment_rules, expected_type=type_hints["active_assignment_rules"])
            check_type(argname="argument eligible_assignment_rules", value=eligible_assignment_rules, expected_type=type_hints["eligible_assignment_rules"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument notification_rules", value=notification_rules, expected_type=type_hints["notification_rules"])
            check_type(argname="argument timeouts", value=timeouts, expected_type=type_hints["timeouts"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "group_id": group_id,
            "role_id": role_id,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if activation_rules is not None:
            self._values["activation_rules"] = activation_rules
        if active_assignment_rules is not None:
            self._values["active_assignment_rules"] = active_assignment_rules
        if eligible_assignment_rules is not None:
            self._values["eligible_assignment_rules"] = eligible_assignment_rules
        if id is not None:
            self._values["id"] = id
        if notification_rules is not None:
            self._values["notification_rules"] = notification_rules
        if timeouts is not None:
            self._values["timeouts"] = timeouts

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktn_78ede62e.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktn_78ede62e.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktn_78ede62e.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]], result)

    @builtins.property
    def group_id(self) -> builtins.str:
        '''ID of the group to which this policy is assigned.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#group_id GroupRoleManagementPolicy#group_id}
        '''
        result = self._values.get("group_id")
        assert result is not None, "Required property 'group_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def role_id(self) -> builtins.str:
        '''The ID of the role of this policy to the group.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#role_id GroupRoleManagementPolicy#role_id}
        '''
        result = self._values.get("role_id")
        assert result is not None, "Required property 'role_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def activation_rules(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyActivationRules]:
        '''activation_rules block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#activation_rules GroupRoleManagementPolicy#activation_rules}
        '''
        result = self._values.get("activation_rules")
        return typing.cast(typing.Optional[GroupRoleManagementPolicyActivationRules], result)

    @builtins.property
    def active_assignment_rules(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyActiveAssignmentRules]:
        '''active_assignment_rules block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#active_assignment_rules GroupRoleManagementPolicy#active_assignment_rules}
        '''
        result = self._values.get("active_assignment_rules")
        return typing.cast(typing.Optional[GroupRoleManagementPolicyActiveAssignmentRules], result)

    @builtins.property
    def eligible_assignment_rules(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyEligibleAssignmentRules"]:
        '''eligible_assignment_rules block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#eligible_assignment_rules GroupRoleManagementPolicy#eligible_assignment_rules}
        '''
        result = self._values.get("eligible_assignment_rules")
        return typing.cast(typing.Optional["GroupRoleManagementPolicyEligibleAssignmentRules"], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#id GroupRoleManagementPolicy#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def notification_rules(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyNotificationRules"]:
        '''notification_rules block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_rules GroupRoleManagementPolicy#notification_rules}
        '''
        result = self._values.get("notification_rules")
        return typing.cast(typing.Optional["GroupRoleManagementPolicyNotificationRules"], result)

    @builtins.property
    def timeouts(self) -> typing.Optional["GroupRoleManagementPolicyTimeouts"]:
        '''timeouts block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#timeouts GroupRoleManagementPolicy#timeouts}
        '''
        result = self._values.get("timeouts")
        return typing.cast(typing.Optional["GroupRoleManagementPolicyTimeouts"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyEligibleAssignmentRules",
    jsii_struct_bases=[],
    name_mapping={
        "expiration_required": "expirationRequired",
        "expire_after": "expireAfter",
    },
)
class GroupRoleManagementPolicyEligibleAssignmentRules:
    def __init__(
        self,
        *,
        expiration_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        expire_after: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param expiration_required: Must the assignment have an expiry date. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#expiration_required GroupRoleManagementPolicy#expiration_required}
        :param expire_after: The duration after which assignments expire. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#expire_after GroupRoleManagementPolicy#expire_after}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5463e5106148d7b4d099856a6fab68ecae1fe1ed71f715c1b5866d7dc699a800)
            check_type(argname="argument expiration_required", value=expiration_required, expected_type=type_hints["expiration_required"])
            check_type(argname="argument expire_after", value=expire_after, expected_type=type_hints["expire_after"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if expiration_required is not None:
            self._values["expiration_required"] = expiration_required
        if expire_after is not None:
            self._values["expire_after"] = expire_after

    @builtins.property
    def expiration_required(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Must the assignment have an expiry date.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#expiration_required GroupRoleManagementPolicy#expiration_required}
        '''
        result = self._values.get("expiration_required")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def expire_after(self) -> typing.Optional[builtins.str]:
        '''The duration after which assignments expire.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#expire_after GroupRoleManagementPolicy#expire_after}
        '''
        result = self._values.get("expire_after")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyEligibleAssignmentRules(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class GroupRoleManagementPolicyEligibleAssignmentRulesOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyEligibleAssignmentRulesOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__81062b57b753308379d96dc0dec999bb80fb776ff97082e67e3a33c3cf4e2d46)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetExpirationRequired")
    def reset_expiration_required(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExpirationRequired", []))

    @jsii.member(jsii_name="resetExpireAfter")
    def reset_expire_after(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExpireAfter", []))

    @builtins.property
    @jsii.member(jsii_name="expirationRequiredInput")
    def expiration_required_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "expirationRequiredInput"))

    @builtins.property
    @jsii.member(jsii_name="expireAfterInput")
    def expire_after_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "expireAfterInput"))

    @builtins.property
    @jsii.member(jsii_name="expirationRequired")
    def expiration_required(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "expirationRequired"))

    @expiration_required.setter
    def expiration_required(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08a0ac5c96ade902ce5cff514f91509942f8c6eb92384a60359d0b60af98da9e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "expirationRequired", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="expireAfter")
    def expire_after(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "expireAfter"))

    @expire_after.setter
    def expire_after(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e850d8f00707832d1a948538d05d460ed964571369757f9322256c1fabd9cd69)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "expireAfter", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyEligibleAssignmentRules]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyEligibleAssignmentRules], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyEligibleAssignmentRules],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dbf030f3ece8f8bf669d8ef1f71118cbead30057d1f44a1650f563eb037ef73b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRules",
    jsii_struct_bases=[],
    name_mapping={
        "active_assignments": "activeAssignments",
        "eligible_activations": "eligibleActivations",
        "eligible_assignments": "eligibleAssignments",
    },
)
class GroupRoleManagementPolicyNotificationRules:
    def __init__(
        self,
        *,
        active_assignments: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRulesActiveAssignments", typing.Dict[builtins.str, typing.Any]]] = None,
        eligible_activations: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRulesEligibleActivations", typing.Dict[builtins.str, typing.Any]]] = None,
        eligible_assignments: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRulesEligibleAssignments", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param active_assignments: active_assignments block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#active_assignments GroupRoleManagementPolicy#active_assignments}
        :param eligible_activations: eligible_activations block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#eligible_activations GroupRoleManagementPolicy#eligible_activations}
        :param eligible_assignments: eligible_assignments block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#eligible_assignments GroupRoleManagementPolicy#eligible_assignments}
        '''
        if isinstance(active_assignments, dict):
            active_assignments = GroupRoleManagementPolicyNotificationRulesActiveAssignments(**active_assignments)
        if isinstance(eligible_activations, dict):
            eligible_activations = GroupRoleManagementPolicyNotificationRulesEligibleActivations(**eligible_activations)
        if isinstance(eligible_assignments, dict):
            eligible_assignments = GroupRoleManagementPolicyNotificationRulesEligibleAssignments(**eligible_assignments)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__68deefbfe14e6d585da329fc5fe49d007e576571a57df674e50db0ba3750bc61)
            check_type(argname="argument active_assignments", value=active_assignments, expected_type=type_hints["active_assignments"])
            check_type(argname="argument eligible_activations", value=eligible_activations, expected_type=type_hints["eligible_activations"])
            check_type(argname="argument eligible_assignments", value=eligible_assignments, expected_type=type_hints["eligible_assignments"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if active_assignments is not None:
            self._values["active_assignments"] = active_assignments
        if eligible_activations is not None:
            self._values["eligible_activations"] = eligible_activations
        if eligible_assignments is not None:
            self._values["eligible_assignments"] = eligible_assignments

    @builtins.property
    def active_assignments(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyNotificationRulesActiveAssignments"]:
        '''active_assignments block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#active_assignments GroupRoleManagementPolicy#active_assignments}
        '''
        result = self._values.get("active_assignments")
        return typing.cast(typing.Optional["GroupRoleManagementPolicyNotificationRulesActiveAssignments"], result)

    @builtins.property
    def eligible_activations(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyNotificationRulesEligibleActivations"]:
        '''eligible_activations block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#eligible_activations GroupRoleManagementPolicy#eligible_activations}
        '''
        result = self._values.get("eligible_activations")
        return typing.cast(typing.Optional["GroupRoleManagementPolicyNotificationRulesEligibleActivations"], result)

    @builtins.property
    def eligible_assignments(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyNotificationRulesEligibleAssignments"]:
        '''eligible_assignments block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#eligible_assignments GroupRoleManagementPolicy#eligible_assignments}
        '''
        result = self._values.get("eligible_assignments")
        return typing.cast(typing.Optional["GroupRoleManagementPolicyNotificationRulesEligibleAssignments"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyNotificationRules(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesActiveAssignments",
    jsii_struct_bases=[],
    name_mapping={
        "admin_notifications": "adminNotifications",
        "approver_notifications": "approverNotifications",
        "assignee_notifications": "assigneeNotifications",
    },
)
class GroupRoleManagementPolicyNotificationRulesActiveAssignments:
    def __init__(
        self,
        *,
        admin_notifications: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications", typing.Dict[builtins.str, typing.Any]]] = None,
        approver_notifications: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications", typing.Dict[builtins.str, typing.Any]]] = None,
        assignee_notifications: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param admin_notifications: admin_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#admin_notifications GroupRoleManagementPolicy#admin_notifications}
        :param approver_notifications: approver_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#approver_notifications GroupRoleManagementPolicy#approver_notifications}
        :param assignee_notifications: assignee_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#assignee_notifications GroupRoleManagementPolicy#assignee_notifications}
        '''
        if isinstance(admin_notifications, dict):
            admin_notifications = GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications(**admin_notifications)
        if isinstance(approver_notifications, dict):
            approver_notifications = GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications(**approver_notifications)
        if isinstance(assignee_notifications, dict):
            assignee_notifications = GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications(**assignee_notifications)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e9db2ca6f7516f369a5c53c8dde59dd98e876168f249681ca91213c3effcd071)
            check_type(argname="argument admin_notifications", value=admin_notifications, expected_type=type_hints["admin_notifications"])
            check_type(argname="argument approver_notifications", value=approver_notifications, expected_type=type_hints["approver_notifications"])
            check_type(argname="argument assignee_notifications", value=assignee_notifications, expected_type=type_hints["assignee_notifications"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if admin_notifications is not None:
            self._values["admin_notifications"] = admin_notifications
        if approver_notifications is not None:
            self._values["approver_notifications"] = approver_notifications
        if assignee_notifications is not None:
            self._values["assignee_notifications"] = assignee_notifications

    @builtins.property
    def admin_notifications(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications"]:
        '''admin_notifications block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#admin_notifications GroupRoleManagementPolicy#admin_notifications}
        '''
        result = self._values.get("admin_notifications")
        return typing.cast(typing.Optional["GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications"], result)

    @builtins.property
    def approver_notifications(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications"]:
        '''approver_notifications block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#approver_notifications GroupRoleManagementPolicy#approver_notifications}
        '''
        result = self._values.get("approver_notifications")
        return typing.cast(typing.Optional["GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications"], result)

    @builtins.property
    def assignee_notifications(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications"]:
        '''assignee_notifications block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#assignee_notifications GroupRoleManagementPolicy#assignee_notifications}
        '''
        result = self._values.get("assignee_notifications")
        return typing.cast(typing.Optional["GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyNotificationRulesActiveAssignments(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications",
    jsii_struct_bases=[],
    name_mapping={
        "default_recipients": "defaultRecipients",
        "notification_level": "notificationLevel",
        "additional_recipients": "additionalRecipients",
    },
)
class GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications:
    def __init__(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fb51cc8a5fed25efa5f9f3d1a5e35fbb8b0ae1af6578b7de3a0775e9783c5239)
            check_type(argname="argument default_recipients", value=default_recipients, expected_type=type_hints["default_recipients"])
            check_type(argname="argument notification_level", value=notification_level, expected_type=type_hints["notification_level"])
            check_type(argname="argument additional_recipients", value=additional_recipients, expected_type=type_hints["additional_recipients"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "default_recipients": default_recipients,
            "notification_level": notification_level,
        }
        if additional_recipients is not None:
            self._values["additional_recipients"] = additional_recipients

    @builtins.property
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        '''Whether the default recipients are notified.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        '''
        result = self._values.get("default_recipients")
        assert result is not None, "Required property 'default_recipients' is missing"
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], result)

    @builtins.property
    def notification_level(self) -> builtins.str:
        '''What level of notifications are sent.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        '''
        result = self._values.get("notification_level")
        assert result is not None, "Required property 'notification_level' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def additional_recipients(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The additional recipients to notify.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        result = self._values.get("additional_recipients")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotificationsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotificationsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__005ed74ef0cb3a4f391da6ad930ff96b54c56fe7e7d2fd2c0d47a8ebd44d4aa5)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAdditionalRecipients")
    def reset_additional_recipients(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAdditionalRecipients", []))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipientsInput")
    def additional_recipients_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "additionalRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="defaultRecipientsInput")
    def default_recipients_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "defaultRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="notificationLevelInput")
    def notification_level_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "notificationLevelInput"))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipients")
    def additional_recipients(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "additionalRecipients"))

    @additional_recipients.setter
    def additional_recipients(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f437717e577c4ed8e4a17abfe816c65b667c9dc207921ce2a1921c3981009ede)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "additionalRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="defaultRecipients")
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "defaultRecipients"))

    @default_recipients.setter
    def default_recipients(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dea767b638bcd5c1a091e143a70257dbde98a1d8118dcbd8b0591a0c2329a0d8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "defaultRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="notificationLevel")
    def notification_level(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "notificationLevel"))

    @notification_level.setter
    def notification_level(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__495d6d3e17f87cbe7967941bf825db9a793af6f719cebd2c2f00466ad610f054)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "notificationLevel", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__23c793789beb056e0cec5b3c88be74437e156cae84731df337489996484f6c02)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications",
    jsii_struct_bases=[],
    name_mapping={
        "default_recipients": "defaultRecipients",
        "notification_level": "notificationLevel",
        "additional_recipients": "additionalRecipients",
    },
)
class GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications:
    def __init__(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__403634859979fe359604127d6a41924aaa5f318bb71bb67ae881a7adbab7206e)
            check_type(argname="argument default_recipients", value=default_recipients, expected_type=type_hints["default_recipients"])
            check_type(argname="argument notification_level", value=notification_level, expected_type=type_hints["notification_level"])
            check_type(argname="argument additional_recipients", value=additional_recipients, expected_type=type_hints["additional_recipients"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "default_recipients": default_recipients,
            "notification_level": notification_level,
        }
        if additional_recipients is not None:
            self._values["additional_recipients"] = additional_recipients

    @builtins.property
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        '''Whether the default recipients are notified.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        '''
        result = self._values.get("default_recipients")
        assert result is not None, "Required property 'default_recipients' is missing"
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], result)

    @builtins.property
    def notification_level(self) -> builtins.str:
        '''What level of notifications are sent.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        '''
        result = self._values.get("notification_level")
        assert result is not None, "Required property 'notification_level' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def additional_recipients(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The additional recipients to notify.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        result = self._values.get("additional_recipients")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotificationsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotificationsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__418662a47d3715d18225d272c1a2a3156900e4a2528e052c2fa53c92aec3238c)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAdditionalRecipients")
    def reset_additional_recipients(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAdditionalRecipients", []))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipientsInput")
    def additional_recipients_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "additionalRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="defaultRecipientsInput")
    def default_recipients_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "defaultRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="notificationLevelInput")
    def notification_level_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "notificationLevelInput"))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipients")
    def additional_recipients(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "additionalRecipients"))

    @additional_recipients.setter
    def additional_recipients(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b8d7914ee043af3e37c0163880508b955e898c4b2ae1db36cbca7d8c4afe6249)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "additionalRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="defaultRecipients")
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "defaultRecipients"))

    @default_recipients.setter
    def default_recipients(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e3a0c9a2f2b63ac3a19f6420a81ad34b8f0d317cca487e7ee51289dcc07c7664)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "defaultRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="notificationLevel")
    def notification_level(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "notificationLevel"))

    @notification_level.setter
    def notification_level(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__844985a0e925ceb20dc1abe00fe63bb6be5f71425f67e1e24edb546b8bc16e0d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "notificationLevel", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5c64f339594bbbcdb1ce9c1931af8bfe84c1f1dedc3373ab9e62f612676ec2c1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications",
    jsii_struct_bases=[],
    name_mapping={
        "default_recipients": "defaultRecipients",
        "notification_level": "notificationLevel",
        "additional_recipients": "additionalRecipients",
    },
)
class GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications:
    def __init__(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__475f942b5f0314845eed11f8f963caa1c6023e391bc55e7afcb25430fc591959)
            check_type(argname="argument default_recipients", value=default_recipients, expected_type=type_hints["default_recipients"])
            check_type(argname="argument notification_level", value=notification_level, expected_type=type_hints["notification_level"])
            check_type(argname="argument additional_recipients", value=additional_recipients, expected_type=type_hints["additional_recipients"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "default_recipients": default_recipients,
            "notification_level": notification_level,
        }
        if additional_recipients is not None:
            self._values["additional_recipients"] = additional_recipients

    @builtins.property
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        '''Whether the default recipients are notified.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        '''
        result = self._values.get("default_recipients")
        assert result is not None, "Required property 'default_recipients' is missing"
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], result)

    @builtins.property
    def notification_level(self) -> builtins.str:
        '''What level of notifications are sent.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        '''
        result = self._values.get("notification_level")
        assert result is not None, "Required property 'notification_level' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def additional_recipients(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The additional recipients to notify.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        result = self._values.get("additional_recipients")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotificationsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotificationsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9b5fd69c7d7e3c884b54051f5417b9bfec2522fbbdd3f5409a860c1b3d68ce68)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAdditionalRecipients")
    def reset_additional_recipients(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAdditionalRecipients", []))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipientsInput")
    def additional_recipients_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "additionalRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="defaultRecipientsInput")
    def default_recipients_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "defaultRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="notificationLevelInput")
    def notification_level_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "notificationLevelInput"))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipients")
    def additional_recipients(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "additionalRecipients"))

    @additional_recipients.setter
    def additional_recipients(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c39df3b163c38dd1edd1d000360ce849ab0405690d157467b50ec50851ad90d2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "additionalRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="defaultRecipients")
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "defaultRecipients"))

    @default_recipients.setter
    def default_recipients(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0378be35294334633e2c81bb1f5325419eda0059035ef52d56c83a031600580f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "defaultRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="notificationLevel")
    def notification_level(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "notificationLevel"))

    @notification_level.setter
    def notification_level(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e74096807d9876ec61e719149f601d0de7b80623447fc6c900b60f275ccc7859)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "notificationLevel", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__826e1f433ba935ce04f613b1fdeaf41aa87207fb2c39de5d46b7462a7aa96b82)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class GroupRoleManagementPolicyNotificationRulesActiveAssignmentsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesActiveAssignmentsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__22c3898425bb8ab5143e534b0da848671ae1b9edb0d75366fd227ffc033c3686)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putAdminNotifications")
    def put_admin_notifications(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        value = GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications(
            default_recipients=default_recipients,
            notification_level=notification_level,
            additional_recipients=additional_recipients,
        )

        return typing.cast(None, jsii.invoke(self, "putAdminNotifications", [value]))

    @jsii.member(jsii_name="putApproverNotifications")
    def put_approver_notifications(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        value = GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications(
            default_recipients=default_recipients,
            notification_level=notification_level,
            additional_recipients=additional_recipients,
        )

        return typing.cast(None, jsii.invoke(self, "putApproverNotifications", [value]))

    @jsii.member(jsii_name="putAssigneeNotifications")
    def put_assignee_notifications(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        value = GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications(
            default_recipients=default_recipients,
            notification_level=notification_level,
            additional_recipients=additional_recipients,
        )

        return typing.cast(None, jsii.invoke(self, "putAssigneeNotifications", [value]))

    @jsii.member(jsii_name="resetAdminNotifications")
    def reset_admin_notifications(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAdminNotifications", []))

    @jsii.member(jsii_name="resetApproverNotifications")
    def reset_approver_notifications(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetApproverNotifications", []))

    @jsii.member(jsii_name="resetAssigneeNotifications")
    def reset_assignee_notifications(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAssigneeNotifications", []))

    @builtins.property
    @jsii.member(jsii_name="adminNotifications")
    def admin_notifications(
        self,
    ) -> GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotificationsOutputReference:
        return typing.cast(GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotificationsOutputReference, jsii.get(self, "adminNotifications"))

    @builtins.property
    @jsii.member(jsii_name="approverNotifications")
    def approver_notifications(
        self,
    ) -> GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotificationsOutputReference:
        return typing.cast(GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotificationsOutputReference, jsii.get(self, "approverNotifications"))

    @builtins.property
    @jsii.member(jsii_name="assigneeNotifications")
    def assignee_notifications(
        self,
    ) -> GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotificationsOutputReference:
        return typing.cast(GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotificationsOutputReference, jsii.get(self, "assigneeNotifications"))

    @builtins.property
    @jsii.member(jsii_name="adminNotificationsInput")
    def admin_notifications_input(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications], jsii.get(self, "adminNotificationsInput"))

    @builtins.property
    @jsii.member(jsii_name="approverNotificationsInput")
    def approver_notifications_input(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications], jsii.get(self, "approverNotificationsInput"))

    @builtins.property
    @jsii.member(jsii_name="assigneeNotificationsInput")
    def assignee_notifications_input(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications], jsii.get(self, "assigneeNotificationsInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignments]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignments], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignments],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6065851a5e3b946a4662b20fbb268b752e3c18ad422dc7f1376f3fe0716c967b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesEligibleActivations",
    jsii_struct_bases=[],
    name_mapping={
        "admin_notifications": "adminNotifications",
        "approver_notifications": "approverNotifications",
        "assignee_notifications": "assigneeNotifications",
    },
)
class GroupRoleManagementPolicyNotificationRulesEligibleActivations:
    def __init__(
        self,
        *,
        admin_notifications: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications", typing.Dict[builtins.str, typing.Any]]] = None,
        approver_notifications: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications", typing.Dict[builtins.str, typing.Any]]] = None,
        assignee_notifications: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param admin_notifications: admin_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#admin_notifications GroupRoleManagementPolicy#admin_notifications}
        :param approver_notifications: approver_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#approver_notifications GroupRoleManagementPolicy#approver_notifications}
        :param assignee_notifications: assignee_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#assignee_notifications GroupRoleManagementPolicy#assignee_notifications}
        '''
        if isinstance(admin_notifications, dict):
            admin_notifications = GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications(**admin_notifications)
        if isinstance(approver_notifications, dict):
            approver_notifications = GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications(**approver_notifications)
        if isinstance(assignee_notifications, dict):
            assignee_notifications = GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications(**assignee_notifications)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__36f74813e98133317216fbfe238fac3c55419a429fa44cc7d27ecfcb84db9a77)
            check_type(argname="argument admin_notifications", value=admin_notifications, expected_type=type_hints["admin_notifications"])
            check_type(argname="argument approver_notifications", value=approver_notifications, expected_type=type_hints["approver_notifications"])
            check_type(argname="argument assignee_notifications", value=assignee_notifications, expected_type=type_hints["assignee_notifications"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if admin_notifications is not None:
            self._values["admin_notifications"] = admin_notifications
        if approver_notifications is not None:
            self._values["approver_notifications"] = approver_notifications
        if assignee_notifications is not None:
            self._values["assignee_notifications"] = assignee_notifications

    @builtins.property
    def admin_notifications(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications"]:
        '''admin_notifications block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#admin_notifications GroupRoleManagementPolicy#admin_notifications}
        '''
        result = self._values.get("admin_notifications")
        return typing.cast(typing.Optional["GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications"], result)

    @builtins.property
    def approver_notifications(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications"]:
        '''approver_notifications block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#approver_notifications GroupRoleManagementPolicy#approver_notifications}
        '''
        result = self._values.get("approver_notifications")
        return typing.cast(typing.Optional["GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications"], result)

    @builtins.property
    def assignee_notifications(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications"]:
        '''assignee_notifications block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#assignee_notifications GroupRoleManagementPolicy#assignee_notifications}
        '''
        result = self._values.get("assignee_notifications")
        return typing.cast(typing.Optional["GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyNotificationRulesEligibleActivations(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications",
    jsii_struct_bases=[],
    name_mapping={
        "default_recipients": "defaultRecipients",
        "notification_level": "notificationLevel",
        "additional_recipients": "additionalRecipients",
    },
)
class GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications:
    def __init__(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a3b208898d67074155eb8e56a410cdf0035d238110499cfaf4df00cba037cb0d)
            check_type(argname="argument default_recipients", value=default_recipients, expected_type=type_hints["default_recipients"])
            check_type(argname="argument notification_level", value=notification_level, expected_type=type_hints["notification_level"])
            check_type(argname="argument additional_recipients", value=additional_recipients, expected_type=type_hints["additional_recipients"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "default_recipients": default_recipients,
            "notification_level": notification_level,
        }
        if additional_recipients is not None:
            self._values["additional_recipients"] = additional_recipients

    @builtins.property
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        '''Whether the default recipients are notified.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        '''
        result = self._values.get("default_recipients")
        assert result is not None, "Required property 'default_recipients' is missing"
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], result)

    @builtins.property
    def notification_level(self) -> builtins.str:
        '''What level of notifications are sent.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        '''
        result = self._values.get("notification_level")
        assert result is not None, "Required property 'notification_level' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def additional_recipients(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The additional recipients to notify.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        result = self._values.get("additional_recipients")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotificationsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotificationsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__032672bd343d7dee951c33f5118ed21bbccdea100dd5ca800ee737aa750e211c)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAdditionalRecipients")
    def reset_additional_recipients(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAdditionalRecipients", []))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipientsInput")
    def additional_recipients_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "additionalRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="defaultRecipientsInput")
    def default_recipients_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "defaultRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="notificationLevelInput")
    def notification_level_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "notificationLevelInput"))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipients")
    def additional_recipients(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "additionalRecipients"))

    @additional_recipients.setter
    def additional_recipients(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3c05a27ea92d07b48427e495e576bcd35fdaad132d5d5c5a055951303ecd0508)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "additionalRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="defaultRecipients")
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "defaultRecipients"))

    @default_recipients.setter
    def default_recipients(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__343add1131974981d01005b9ec6c5c862598c059cee91231ec87941ac4e99e48)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "defaultRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="notificationLevel")
    def notification_level(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "notificationLevel"))

    @notification_level.setter
    def notification_level(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4431fe13ffe4a923baa2ad6da1be06eaebb2b19687010df5656a289da3ba38ea)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "notificationLevel", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3893edb4ce5b391e38440dbf1392e6afd5f6e99a073dffad4135a5a74075f301)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications",
    jsii_struct_bases=[],
    name_mapping={
        "default_recipients": "defaultRecipients",
        "notification_level": "notificationLevel",
        "additional_recipients": "additionalRecipients",
    },
)
class GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications:
    def __init__(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__718dfb027045d577d7f9b91fbad20f9bce0b98528c7f29820cc2a9960d180788)
            check_type(argname="argument default_recipients", value=default_recipients, expected_type=type_hints["default_recipients"])
            check_type(argname="argument notification_level", value=notification_level, expected_type=type_hints["notification_level"])
            check_type(argname="argument additional_recipients", value=additional_recipients, expected_type=type_hints["additional_recipients"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "default_recipients": default_recipients,
            "notification_level": notification_level,
        }
        if additional_recipients is not None:
            self._values["additional_recipients"] = additional_recipients

    @builtins.property
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        '''Whether the default recipients are notified.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        '''
        result = self._values.get("default_recipients")
        assert result is not None, "Required property 'default_recipients' is missing"
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], result)

    @builtins.property
    def notification_level(self) -> builtins.str:
        '''What level of notifications are sent.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        '''
        result = self._values.get("notification_level")
        assert result is not None, "Required property 'notification_level' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def additional_recipients(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The additional recipients to notify.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        result = self._values.get("additional_recipients")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotificationsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotificationsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cf35651b2e5be2b71f9c5f78df22151d81f37ff580f79d465adccb679f3e4b62)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAdditionalRecipients")
    def reset_additional_recipients(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAdditionalRecipients", []))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipientsInput")
    def additional_recipients_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "additionalRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="defaultRecipientsInput")
    def default_recipients_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "defaultRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="notificationLevelInput")
    def notification_level_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "notificationLevelInput"))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipients")
    def additional_recipients(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "additionalRecipients"))

    @additional_recipients.setter
    def additional_recipients(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4083125aeb16af8e3e4e64b9292deb57ae83cf9e021c5341235bab4d33e3f682)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "additionalRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="defaultRecipients")
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "defaultRecipients"))

    @default_recipients.setter
    def default_recipients(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fb44d9e20f130d297deea3632380e37c96a2c1eb8de9e2b5982879b7476c44d2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "defaultRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="notificationLevel")
    def notification_level(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "notificationLevel"))

    @notification_level.setter
    def notification_level(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8a6271f5806b3eb4ee2c01a46a124ea47d1ec8832bcdb88b09d5145c6970d407)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "notificationLevel", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7bcb56f5eec2accd48026ec329accb0bb64ee14c408bc11200ed4c7431d3d864)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications",
    jsii_struct_bases=[],
    name_mapping={
        "default_recipients": "defaultRecipients",
        "notification_level": "notificationLevel",
        "additional_recipients": "additionalRecipients",
    },
)
class GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications:
    def __init__(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3f19081ff8769aa882f485155158b604529a6e05d3e247a5081bb710d4b0da9c)
            check_type(argname="argument default_recipients", value=default_recipients, expected_type=type_hints["default_recipients"])
            check_type(argname="argument notification_level", value=notification_level, expected_type=type_hints["notification_level"])
            check_type(argname="argument additional_recipients", value=additional_recipients, expected_type=type_hints["additional_recipients"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "default_recipients": default_recipients,
            "notification_level": notification_level,
        }
        if additional_recipients is not None:
            self._values["additional_recipients"] = additional_recipients

    @builtins.property
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        '''Whether the default recipients are notified.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        '''
        result = self._values.get("default_recipients")
        assert result is not None, "Required property 'default_recipients' is missing"
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], result)

    @builtins.property
    def notification_level(self) -> builtins.str:
        '''What level of notifications are sent.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        '''
        result = self._values.get("notification_level")
        assert result is not None, "Required property 'notification_level' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def additional_recipients(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The additional recipients to notify.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        result = self._values.get("additional_recipients")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotificationsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotificationsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__52f3f557aa2d35d8eb2b04fafeeddfb25386a70c59106cb88fd19897b57000be)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAdditionalRecipients")
    def reset_additional_recipients(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAdditionalRecipients", []))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipientsInput")
    def additional_recipients_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "additionalRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="defaultRecipientsInput")
    def default_recipients_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "defaultRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="notificationLevelInput")
    def notification_level_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "notificationLevelInput"))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipients")
    def additional_recipients(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "additionalRecipients"))

    @additional_recipients.setter
    def additional_recipients(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__59d2155840e1daa4d7470d928ed7e4a485ab37ce8982aa561e1b6f32833d29af)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "additionalRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="defaultRecipients")
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "defaultRecipients"))

    @default_recipients.setter
    def default_recipients(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f83cc20e65454ac480db08f1735579ce5da338e942667ffe518e1dbd8d2955e9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "defaultRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="notificationLevel")
    def notification_level(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "notificationLevel"))

    @notification_level.setter
    def notification_level(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b431d5881aed4e05119affb08e50713ac3e16ee0b8ec4c3335e2cb609bfb134e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "notificationLevel", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cc8a47a1b064581897f895d9286f615c287284284ede19ada5b39699cbd100ad)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class GroupRoleManagementPolicyNotificationRulesEligibleActivationsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesEligibleActivationsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__55ff1a9547a00ebdc696711f2473d829294354244843f1e8cefd547f2e2a4476)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putAdminNotifications")
    def put_admin_notifications(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        value = GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications(
            default_recipients=default_recipients,
            notification_level=notification_level,
            additional_recipients=additional_recipients,
        )

        return typing.cast(None, jsii.invoke(self, "putAdminNotifications", [value]))

    @jsii.member(jsii_name="putApproverNotifications")
    def put_approver_notifications(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        value = GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications(
            default_recipients=default_recipients,
            notification_level=notification_level,
            additional_recipients=additional_recipients,
        )

        return typing.cast(None, jsii.invoke(self, "putApproverNotifications", [value]))

    @jsii.member(jsii_name="putAssigneeNotifications")
    def put_assignee_notifications(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        value = GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications(
            default_recipients=default_recipients,
            notification_level=notification_level,
            additional_recipients=additional_recipients,
        )

        return typing.cast(None, jsii.invoke(self, "putAssigneeNotifications", [value]))

    @jsii.member(jsii_name="resetAdminNotifications")
    def reset_admin_notifications(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAdminNotifications", []))

    @jsii.member(jsii_name="resetApproverNotifications")
    def reset_approver_notifications(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetApproverNotifications", []))

    @jsii.member(jsii_name="resetAssigneeNotifications")
    def reset_assignee_notifications(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAssigneeNotifications", []))

    @builtins.property
    @jsii.member(jsii_name="adminNotifications")
    def admin_notifications(
        self,
    ) -> GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotificationsOutputReference:
        return typing.cast(GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotificationsOutputReference, jsii.get(self, "adminNotifications"))

    @builtins.property
    @jsii.member(jsii_name="approverNotifications")
    def approver_notifications(
        self,
    ) -> GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotificationsOutputReference:
        return typing.cast(GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotificationsOutputReference, jsii.get(self, "approverNotifications"))

    @builtins.property
    @jsii.member(jsii_name="assigneeNotifications")
    def assignee_notifications(
        self,
    ) -> GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotificationsOutputReference:
        return typing.cast(GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotificationsOutputReference, jsii.get(self, "assigneeNotifications"))

    @builtins.property
    @jsii.member(jsii_name="adminNotificationsInput")
    def admin_notifications_input(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications], jsii.get(self, "adminNotificationsInput"))

    @builtins.property
    @jsii.member(jsii_name="approverNotificationsInput")
    def approver_notifications_input(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications], jsii.get(self, "approverNotificationsInput"))

    @builtins.property
    @jsii.member(jsii_name="assigneeNotificationsInput")
    def assignee_notifications_input(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications], jsii.get(self, "assigneeNotificationsInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivations]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivations], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivations],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f997b44b05fb39973df6b0726b790c7f91e267ed566e3d727f8ad6fc37b12966)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesEligibleAssignments",
    jsii_struct_bases=[],
    name_mapping={
        "admin_notifications": "adminNotifications",
        "approver_notifications": "approverNotifications",
        "assignee_notifications": "assigneeNotifications",
    },
)
class GroupRoleManagementPolicyNotificationRulesEligibleAssignments:
    def __init__(
        self,
        *,
        admin_notifications: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications", typing.Dict[builtins.str, typing.Any]]] = None,
        approver_notifications: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications", typing.Dict[builtins.str, typing.Any]]] = None,
        assignee_notifications: typing.Optional[typing.Union["GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param admin_notifications: admin_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#admin_notifications GroupRoleManagementPolicy#admin_notifications}
        :param approver_notifications: approver_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#approver_notifications GroupRoleManagementPolicy#approver_notifications}
        :param assignee_notifications: assignee_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#assignee_notifications GroupRoleManagementPolicy#assignee_notifications}
        '''
        if isinstance(admin_notifications, dict):
            admin_notifications = GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications(**admin_notifications)
        if isinstance(approver_notifications, dict):
            approver_notifications = GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications(**approver_notifications)
        if isinstance(assignee_notifications, dict):
            assignee_notifications = GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications(**assignee_notifications)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__af10ed99f6cf7cc3288cecd1c71cf130de62c7709cc16a18c2f3bacb1eb4daf2)
            check_type(argname="argument admin_notifications", value=admin_notifications, expected_type=type_hints["admin_notifications"])
            check_type(argname="argument approver_notifications", value=approver_notifications, expected_type=type_hints["approver_notifications"])
            check_type(argname="argument assignee_notifications", value=assignee_notifications, expected_type=type_hints["assignee_notifications"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if admin_notifications is not None:
            self._values["admin_notifications"] = admin_notifications
        if approver_notifications is not None:
            self._values["approver_notifications"] = approver_notifications
        if assignee_notifications is not None:
            self._values["assignee_notifications"] = assignee_notifications

    @builtins.property
    def admin_notifications(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications"]:
        '''admin_notifications block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#admin_notifications GroupRoleManagementPolicy#admin_notifications}
        '''
        result = self._values.get("admin_notifications")
        return typing.cast(typing.Optional["GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications"], result)

    @builtins.property
    def approver_notifications(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications"]:
        '''approver_notifications block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#approver_notifications GroupRoleManagementPolicy#approver_notifications}
        '''
        result = self._values.get("approver_notifications")
        return typing.cast(typing.Optional["GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications"], result)

    @builtins.property
    def assignee_notifications(
        self,
    ) -> typing.Optional["GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications"]:
        '''assignee_notifications block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#assignee_notifications GroupRoleManagementPolicy#assignee_notifications}
        '''
        result = self._values.get("assignee_notifications")
        return typing.cast(typing.Optional["GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyNotificationRulesEligibleAssignments(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications",
    jsii_struct_bases=[],
    name_mapping={
        "default_recipients": "defaultRecipients",
        "notification_level": "notificationLevel",
        "additional_recipients": "additionalRecipients",
    },
)
class GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications:
    def __init__(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b71372f8033e1327db2efc054290c12fdbaea7b4ff53d6657f5416e54149fb51)
            check_type(argname="argument default_recipients", value=default_recipients, expected_type=type_hints["default_recipients"])
            check_type(argname="argument notification_level", value=notification_level, expected_type=type_hints["notification_level"])
            check_type(argname="argument additional_recipients", value=additional_recipients, expected_type=type_hints["additional_recipients"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "default_recipients": default_recipients,
            "notification_level": notification_level,
        }
        if additional_recipients is not None:
            self._values["additional_recipients"] = additional_recipients

    @builtins.property
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        '''Whether the default recipients are notified.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        '''
        result = self._values.get("default_recipients")
        assert result is not None, "Required property 'default_recipients' is missing"
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], result)

    @builtins.property
    def notification_level(self) -> builtins.str:
        '''What level of notifications are sent.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        '''
        result = self._values.get("notification_level")
        assert result is not None, "Required property 'notification_level' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def additional_recipients(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The additional recipients to notify.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        result = self._values.get("additional_recipients")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotificationsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotificationsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__83bc7219cb1f8ab4a017775da0668a93f010a51015ae0aaa8a5eb07aa7b6cfef)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAdditionalRecipients")
    def reset_additional_recipients(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAdditionalRecipients", []))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipientsInput")
    def additional_recipients_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "additionalRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="defaultRecipientsInput")
    def default_recipients_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "defaultRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="notificationLevelInput")
    def notification_level_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "notificationLevelInput"))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipients")
    def additional_recipients(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "additionalRecipients"))

    @additional_recipients.setter
    def additional_recipients(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__be10c624961cc911146fa2bf147d4f02cdad9ebf2b6b2ac8ff5c5952ab376702)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "additionalRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="defaultRecipients")
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "defaultRecipients"))

    @default_recipients.setter
    def default_recipients(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__26cf3a9d82e406242b5d26a561cce60e05aa01d375d8ef44e474fc62a383a9fa)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "defaultRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="notificationLevel")
    def notification_level(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "notificationLevel"))

    @notification_level.setter
    def notification_level(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e3efd28edc67922bce51a0d2e381ee2b24315a33a2e2662038803c7146af4fb0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "notificationLevel", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fc3a317e0e1ac5c2771443dffdaf7ad1cede17fce672daa066a81eeb3d1d0202)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications",
    jsii_struct_bases=[],
    name_mapping={
        "default_recipients": "defaultRecipients",
        "notification_level": "notificationLevel",
        "additional_recipients": "additionalRecipients",
    },
)
class GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications:
    def __init__(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c953633046f41a8adb4eaab4223f4fee4755fcae262fc43d0840616680d20f3b)
            check_type(argname="argument default_recipients", value=default_recipients, expected_type=type_hints["default_recipients"])
            check_type(argname="argument notification_level", value=notification_level, expected_type=type_hints["notification_level"])
            check_type(argname="argument additional_recipients", value=additional_recipients, expected_type=type_hints["additional_recipients"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "default_recipients": default_recipients,
            "notification_level": notification_level,
        }
        if additional_recipients is not None:
            self._values["additional_recipients"] = additional_recipients

    @builtins.property
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        '''Whether the default recipients are notified.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        '''
        result = self._values.get("default_recipients")
        assert result is not None, "Required property 'default_recipients' is missing"
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], result)

    @builtins.property
    def notification_level(self) -> builtins.str:
        '''What level of notifications are sent.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        '''
        result = self._values.get("notification_level")
        assert result is not None, "Required property 'notification_level' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def additional_recipients(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The additional recipients to notify.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        result = self._values.get("additional_recipients")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotificationsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotificationsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__36708e26e3d826f26aa63f4255aeeccf1ee614aae15528a74b41acde1cd15aca)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAdditionalRecipients")
    def reset_additional_recipients(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAdditionalRecipients", []))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipientsInput")
    def additional_recipients_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "additionalRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="defaultRecipientsInput")
    def default_recipients_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "defaultRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="notificationLevelInput")
    def notification_level_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "notificationLevelInput"))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipients")
    def additional_recipients(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "additionalRecipients"))

    @additional_recipients.setter
    def additional_recipients(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d9dd1dd8f638eed377bea30284728307b446968069c10a21b338e262d73c54f1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "additionalRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="defaultRecipients")
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "defaultRecipients"))

    @default_recipients.setter
    def default_recipients(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f26ca33cee9359d3a0a5c48a56e12dfb81ced85f5b5f8b8b6682d7ae9716839)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "defaultRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="notificationLevel")
    def notification_level(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "notificationLevel"))

    @notification_level.setter
    def notification_level(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__35d9b864f0fc974010792d555009ba4483e41a0dbd19352fd275591bdbfffc27)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "notificationLevel", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c25b148c89164d0ac2b51806d887b80a870cfe5f118b898efecd3bf17af54865)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications",
    jsii_struct_bases=[],
    name_mapping={
        "default_recipients": "defaultRecipients",
        "notification_level": "notificationLevel",
        "additional_recipients": "additionalRecipients",
    },
)
class GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications:
    def __init__(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d004085b3d9d09b399cef8debab6b2f7b6ec0025eeeea1cc2f5e24470130d5ac)
            check_type(argname="argument default_recipients", value=default_recipients, expected_type=type_hints["default_recipients"])
            check_type(argname="argument notification_level", value=notification_level, expected_type=type_hints["notification_level"])
            check_type(argname="argument additional_recipients", value=additional_recipients, expected_type=type_hints["additional_recipients"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "default_recipients": default_recipients,
            "notification_level": notification_level,
        }
        if additional_recipients is not None:
            self._values["additional_recipients"] = additional_recipients

    @builtins.property
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        '''Whether the default recipients are notified.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        '''
        result = self._values.get("default_recipients")
        assert result is not None, "Required property 'default_recipients' is missing"
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], result)

    @builtins.property
    def notification_level(self) -> builtins.str:
        '''What level of notifications are sent.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        '''
        result = self._values.get("notification_level")
        assert result is not None, "Required property 'notification_level' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def additional_recipients(self) -> typing.Optional[typing.List[builtins.str]]:
        '''The additional recipients to notify.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        result = self._values.get("additional_recipients")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotificationsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotificationsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__60c0bfe2b2c9ddfd3233a388eed1d7cb93dd2d09740672f454d243eed9be3f69)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetAdditionalRecipients")
    def reset_additional_recipients(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAdditionalRecipients", []))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipientsInput")
    def additional_recipients_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "additionalRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="defaultRecipientsInput")
    def default_recipients_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "defaultRecipientsInput"))

    @builtins.property
    @jsii.member(jsii_name="notificationLevelInput")
    def notification_level_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "notificationLevelInput"))

    @builtins.property
    @jsii.member(jsii_name="additionalRecipients")
    def additional_recipients(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "additionalRecipients"))

    @additional_recipients.setter
    def additional_recipients(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__28b3b95f275fba4dcfa498aee8cdacdc62c58a27d8ca5cf57195e2d4bcc9fb64)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "additionalRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="defaultRecipients")
    def default_recipients(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "defaultRecipients"))

    @default_recipients.setter
    def default_recipients(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__60e3ec77278442b0de93173e8d3b21de97321e154fcff536ee5dd1e6f3a0ca78)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "defaultRecipients", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="notificationLevel")
    def notification_level(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "notificationLevel"))

    @notification_level.setter
    def notification_level(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4e57730b8175f134fc9ac4213e4987aa426e5d06af706cd22e1b7661fae5f147)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "notificationLevel", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cd5b95924ba04a888a0c2d0d7864670b8092833f03985112c134f46e5df936c9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a239bbaac0ab5d24e3b9cd558e5588f363f823d149c1a6b29484cd9478466758)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putAdminNotifications")
    def put_admin_notifications(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        value = GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications(
            default_recipients=default_recipients,
            notification_level=notification_level,
            additional_recipients=additional_recipients,
        )

        return typing.cast(None, jsii.invoke(self, "putAdminNotifications", [value]))

    @jsii.member(jsii_name="putApproverNotifications")
    def put_approver_notifications(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        value = GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications(
            default_recipients=default_recipients,
            notification_level=notification_level,
            additional_recipients=additional_recipients,
        )

        return typing.cast(None, jsii.invoke(self, "putApproverNotifications", [value]))

    @jsii.member(jsii_name="putAssigneeNotifications")
    def put_assignee_notifications(
        self,
        *,
        default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
        notification_level: builtins.str,
        additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param default_recipients: Whether the default recipients are notified. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
        :param notification_level: What level of notifications are sent. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
        :param additional_recipients: The additional recipients to notify. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
        '''
        value = GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications(
            default_recipients=default_recipients,
            notification_level=notification_level,
            additional_recipients=additional_recipients,
        )

        return typing.cast(None, jsii.invoke(self, "putAssigneeNotifications", [value]))

    @jsii.member(jsii_name="resetAdminNotifications")
    def reset_admin_notifications(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAdminNotifications", []))

    @jsii.member(jsii_name="resetApproverNotifications")
    def reset_approver_notifications(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetApproverNotifications", []))

    @jsii.member(jsii_name="resetAssigneeNotifications")
    def reset_assignee_notifications(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAssigneeNotifications", []))

    @builtins.property
    @jsii.member(jsii_name="adminNotifications")
    def admin_notifications(
        self,
    ) -> GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotificationsOutputReference:
        return typing.cast(GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotificationsOutputReference, jsii.get(self, "adminNotifications"))

    @builtins.property
    @jsii.member(jsii_name="approverNotifications")
    def approver_notifications(
        self,
    ) -> GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotificationsOutputReference:
        return typing.cast(GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotificationsOutputReference, jsii.get(self, "approverNotifications"))

    @builtins.property
    @jsii.member(jsii_name="assigneeNotifications")
    def assignee_notifications(
        self,
    ) -> GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotificationsOutputReference:
        return typing.cast(GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotificationsOutputReference, jsii.get(self, "assigneeNotifications"))

    @builtins.property
    @jsii.member(jsii_name="adminNotificationsInput")
    def admin_notifications_input(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications], jsii.get(self, "adminNotificationsInput"))

    @builtins.property
    @jsii.member(jsii_name="approverNotificationsInput")
    def approver_notifications_input(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications], jsii.get(self, "approverNotificationsInput"))

    @builtins.property
    @jsii.member(jsii_name="assigneeNotificationsInput")
    def assignee_notifications_input(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications], jsii.get(self, "assigneeNotificationsInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignments]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignments], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignments],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__72e25eb0bf9abfa33e4fa5a95dc71deb61e39ddb79a90a05a00b3ec6eec829fd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class GroupRoleManagementPolicyNotificationRulesOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyNotificationRulesOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cb37042caebfce36f08015fc371b5e844560bccdebb6abfaaa8156b856896de3)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putActiveAssignments")
    def put_active_assignments(
        self,
        *,
        admin_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
        approver_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
        assignee_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param admin_notifications: admin_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#admin_notifications GroupRoleManagementPolicy#admin_notifications}
        :param approver_notifications: approver_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#approver_notifications GroupRoleManagementPolicy#approver_notifications}
        :param assignee_notifications: assignee_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#assignee_notifications GroupRoleManagementPolicy#assignee_notifications}
        '''
        value = GroupRoleManagementPolicyNotificationRulesActiveAssignments(
            admin_notifications=admin_notifications,
            approver_notifications=approver_notifications,
            assignee_notifications=assignee_notifications,
        )

        return typing.cast(None, jsii.invoke(self, "putActiveAssignments", [value]))

    @jsii.member(jsii_name="putEligibleActivations")
    def put_eligible_activations(
        self,
        *,
        admin_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
        approver_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
        assignee_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param admin_notifications: admin_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#admin_notifications GroupRoleManagementPolicy#admin_notifications}
        :param approver_notifications: approver_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#approver_notifications GroupRoleManagementPolicy#approver_notifications}
        :param assignee_notifications: assignee_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#assignee_notifications GroupRoleManagementPolicy#assignee_notifications}
        '''
        value = GroupRoleManagementPolicyNotificationRulesEligibleActivations(
            admin_notifications=admin_notifications,
            approver_notifications=approver_notifications,
            assignee_notifications=assignee_notifications,
        )

        return typing.cast(None, jsii.invoke(self, "putEligibleActivations", [value]))

    @jsii.member(jsii_name="putEligibleAssignments")
    def put_eligible_assignments(
        self,
        *,
        admin_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
        approver_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
        assignee_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param admin_notifications: admin_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#admin_notifications GroupRoleManagementPolicy#admin_notifications}
        :param approver_notifications: approver_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#approver_notifications GroupRoleManagementPolicy#approver_notifications}
        :param assignee_notifications: assignee_notifications block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#assignee_notifications GroupRoleManagementPolicy#assignee_notifications}
        '''
        value = GroupRoleManagementPolicyNotificationRulesEligibleAssignments(
            admin_notifications=admin_notifications,
            approver_notifications=approver_notifications,
            assignee_notifications=assignee_notifications,
        )

        return typing.cast(None, jsii.invoke(self, "putEligibleAssignments", [value]))

    @jsii.member(jsii_name="resetActiveAssignments")
    def reset_active_assignments(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetActiveAssignments", []))

    @jsii.member(jsii_name="resetEligibleActivations")
    def reset_eligible_activations(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEligibleActivations", []))

    @jsii.member(jsii_name="resetEligibleAssignments")
    def reset_eligible_assignments(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEligibleAssignments", []))

    @builtins.property
    @jsii.member(jsii_name="activeAssignments")
    def active_assignments(
        self,
    ) -> GroupRoleManagementPolicyNotificationRulesActiveAssignmentsOutputReference:
        return typing.cast(GroupRoleManagementPolicyNotificationRulesActiveAssignmentsOutputReference, jsii.get(self, "activeAssignments"))

    @builtins.property
    @jsii.member(jsii_name="eligibleActivations")
    def eligible_activations(
        self,
    ) -> GroupRoleManagementPolicyNotificationRulesEligibleActivationsOutputReference:
        return typing.cast(GroupRoleManagementPolicyNotificationRulesEligibleActivationsOutputReference, jsii.get(self, "eligibleActivations"))

    @builtins.property
    @jsii.member(jsii_name="eligibleAssignments")
    def eligible_assignments(
        self,
    ) -> GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsOutputReference:
        return typing.cast(GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsOutputReference, jsii.get(self, "eligibleAssignments"))

    @builtins.property
    @jsii.member(jsii_name="activeAssignmentsInput")
    def active_assignments_input(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignments]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignments], jsii.get(self, "activeAssignmentsInput"))

    @builtins.property
    @jsii.member(jsii_name="eligibleActivationsInput")
    def eligible_activations_input(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivations]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivations], jsii.get(self, "eligibleActivationsInput"))

    @builtins.property
    @jsii.member(jsii_name="eligibleAssignmentsInput")
    def eligible_assignments_input(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignments]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignments], jsii.get(self, "eligibleAssignmentsInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[GroupRoleManagementPolicyNotificationRules]:
        return typing.cast(typing.Optional[GroupRoleManagementPolicyNotificationRules], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[GroupRoleManagementPolicyNotificationRules],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__edad60abd372d64017fe6c6d35fbab2a366361a783858f9c3525ffa33587d998)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyTimeouts",
    jsii_struct_bases=[],
    name_mapping={
        "create": "create",
        "delete": "delete",
        "read": "read",
        "update": "update",
    },
)
class GroupRoleManagementPolicyTimeouts:
    def __init__(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#create GroupRoleManagementPolicy#create}.
        :param delete: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#delete GroupRoleManagementPolicy#delete}.
        :param read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#read GroupRoleManagementPolicy#read}.
        :param update: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#update GroupRoleManagementPolicy#update}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4c425dd1e82ffe9f75d3c0a56fd917ee3fcfab4bfeaf2d52f2eed517b093e209)
            check_type(argname="argument create", value=create, expected_type=type_hints["create"])
            check_type(argname="argument delete", value=delete, expected_type=type_hints["delete"])
            check_type(argname="argument read", value=read, expected_type=type_hints["read"])
            check_type(argname="argument update", value=update, expected_type=type_hints["update"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if create is not None:
            self._values["create"] = create
        if delete is not None:
            self._values["delete"] = delete
        if read is not None:
            self._values["read"] = read
        if update is not None:
            self._values["update"] = update

    @builtins.property
    def create(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#create GroupRoleManagementPolicy#create}.'''
        result = self._values.get("create")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def delete(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#delete GroupRoleManagementPolicy#delete}.'''
        result = self._values.get("delete")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def read(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#read GroupRoleManagementPolicy#read}.'''
        result = self._values.get("read")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def update(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/group_role_management_policy#update GroupRoleManagementPolicy#update}.'''
        result = self._values.get("update")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "GroupRoleManagementPolicyTimeouts(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class GroupRoleManagementPolicyTimeoutsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.groupRoleManagementPolicy.GroupRoleManagementPolicyTimeoutsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9d2fca51860d0a0531f287a61c1ecf222a4f50bcae8d11b0ccfce92563f2d2ec)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCreate")
    def reset_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreate", []))

    @jsii.member(jsii_name="resetDelete")
    def reset_delete(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDelete", []))

    @jsii.member(jsii_name="resetRead")
    def reset_read(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRead", []))

    @jsii.member(jsii_name="resetUpdate")
    def reset_update(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdate", []))

    @builtins.property
    @jsii.member(jsii_name="createInput")
    def create_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createInput"))

    @builtins.property
    @jsii.member(jsii_name="deleteInput")
    def delete_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "deleteInput"))

    @builtins.property
    @jsii.member(jsii_name="readInput")
    def read_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "readInput"))

    @builtins.property
    @jsii.member(jsii_name="updateInput")
    def update_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "updateInput"))

    @builtins.property
    @jsii.member(jsii_name="create")
    def create(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "create"))

    @create.setter
    def create(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__55d393b438b5b440650df0bb79aad60295c68ebf316725f397d046ea4c30dfb7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "create", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="delete")
    def delete(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "delete"))

    @delete.setter
    def delete(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2cf71a26183fdf6a6597b307d72077edeff2c85c99b81dba0a4420e7545f20e8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "delete", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="read")
    def read(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "read"))

    @read.setter
    def read(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__deaf5399d51b31685f4592e3928e41ccf6327bf70244b1031b6aa55e98270d5b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "read", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="update")
    def update(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "update"))

    @update.setter
    def update(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fffeaef7b17673b41d4f0fed0fd72f8090aba3113f8e7b93068fe84a1246d044)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "update", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, GroupRoleManagementPolicyTimeouts]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, GroupRoleManagementPolicyTimeouts]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, GroupRoleManagementPolicyTimeouts]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__479eebdaac5331adf9a7d4ad7fc1c2f4805f852bc5afea5f868ebcf54266fad8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "GroupRoleManagementPolicy",
    "GroupRoleManagementPolicyActivationRules",
    "GroupRoleManagementPolicyActivationRulesApprovalStage",
    "GroupRoleManagementPolicyActivationRulesApprovalStageOutputReference",
    "GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover",
    "GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApproverList",
    "GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApproverOutputReference",
    "GroupRoleManagementPolicyActivationRulesOutputReference",
    "GroupRoleManagementPolicyActiveAssignmentRules",
    "GroupRoleManagementPolicyActiveAssignmentRulesOutputReference",
    "GroupRoleManagementPolicyConfig",
    "GroupRoleManagementPolicyEligibleAssignmentRules",
    "GroupRoleManagementPolicyEligibleAssignmentRulesOutputReference",
    "GroupRoleManagementPolicyNotificationRules",
    "GroupRoleManagementPolicyNotificationRulesActiveAssignments",
    "GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications",
    "GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotificationsOutputReference",
    "GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications",
    "GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotificationsOutputReference",
    "GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications",
    "GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotificationsOutputReference",
    "GroupRoleManagementPolicyNotificationRulesActiveAssignmentsOutputReference",
    "GroupRoleManagementPolicyNotificationRulesEligibleActivations",
    "GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications",
    "GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotificationsOutputReference",
    "GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications",
    "GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotificationsOutputReference",
    "GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications",
    "GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotificationsOutputReference",
    "GroupRoleManagementPolicyNotificationRulesEligibleActivationsOutputReference",
    "GroupRoleManagementPolicyNotificationRulesEligibleAssignments",
    "GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications",
    "GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotificationsOutputReference",
    "GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications",
    "GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotificationsOutputReference",
    "GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications",
    "GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotificationsOutputReference",
    "GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsOutputReference",
    "GroupRoleManagementPolicyNotificationRulesOutputReference",
    "GroupRoleManagementPolicyTimeouts",
    "GroupRoleManagementPolicyTimeoutsOutputReference",
]

publication.publish()

def _typecheckingstub__f81b873916540f075ad52a8d601d009c8fbe7b1fc77886585b992a350abd0894(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    group_id: builtins.str,
    role_id: builtins.str,
    activation_rules: typing.Optional[typing.Union[GroupRoleManagementPolicyActivationRules, typing.Dict[builtins.str, typing.Any]]] = None,
    active_assignment_rules: typing.Optional[typing.Union[GroupRoleManagementPolicyActiveAssignmentRules, typing.Dict[builtins.str, typing.Any]]] = None,
    eligible_assignment_rules: typing.Optional[typing.Union[GroupRoleManagementPolicyEligibleAssignmentRules, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
    notification_rules: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRules, typing.Dict[builtins.str, typing.Any]]] = None,
    timeouts: typing.Optional[typing.Union[GroupRoleManagementPolicyTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__858365afa1ee05d6dbc3ee39c54e9cd7a7a81bce6d1b2e96a1927873108abb6c(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__db8be80b239e46747d91be85314fb238e4c4acbf12d4656c647c508d53e2e6da(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0e52b77b94735ac0cada409c1299e06f42f56acc169d8a8aad87881ee6b50267(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d956be5f6972a2cb95944eb3dd8485fad23d62bc8ad73db63598ef9ab6afb4fe(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6aab3147b51ebb389517b364527fe502e431a104b89b93abd0b703b13a297096(
    *,
    approval_stage: typing.Optional[typing.Union[GroupRoleManagementPolicyActivationRulesApprovalStage, typing.Dict[builtins.str, typing.Any]]] = None,
    maximum_duration: typing.Optional[builtins.str] = None,
    require_approval: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    required_conditional_access_authentication_context: typing.Optional[builtins.str] = None,
    require_justification: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    require_multifactor_authentication: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    require_ticket_info: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ce3fc026b3a566020641b3959083cb59ac837d8bac47d9cd482914f46a3f697b(
    *,
    primary_approver: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__39f100fbb0cae41263ffc16a6958921cec182488973a99c7a4d2e778ce508ced(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__63d0eaf95e535ec6e686fd7508906bd7756edc91b4c5ed22d0c36f077c87f371(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cf9f8343a04098d69c96370ae7fcabd1a121c448b0076ba65b50244cda4f16fd(
    value: typing.Optional[GroupRoleManagementPolicyActivationRulesApprovalStage],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cf95f28704a56ca0012622d0acd71509197151a5fd144113721da3816a095190(
    *,
    object_id: builtins.str,
    type: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a248805f08958b30b392abff22cce7174585dfe418cde93366955b1738d13a6(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e248f9d415695ba12273abba0c71e2746cf4af96b2793c7044ba6b778f866514(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__766ad44a06ba37dcc10e20e5706468c571a020b0c661fc78b0a167db35dc0116(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9583814e81743fac93ed2c8f2e2182736147c6f37581453d9b19de10882a6036(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9158b74fb650f1cc59c40abb20b0707d50b3e16e867e168c4ad418fc2609507d(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__774e1bd6a19fa79b4dd2e15d58ca93b22a848f0b2b2c0350e0df59700a196b99(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__654d858decde76f00da2aa0c1dad780afb76c1a1956770fe6610dd7510763b67(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cccf0857111803b2a9dfef72cb87c3c2e427567e9d36e1a459cd169a877de380(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dd677a413977bb05896a815a9e956efff8249b45765faf962dfd426ed8c1f0e1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__823d244ef211f455a2a3c3854a7e9d2e328cde143f1a3087bf9af9d6ccc03ac8(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__21ccc9a1ef98df8e2d73194e9f40ffa2e5c86806c29a6289a3349cc0e816d66c(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__09fd8a49b73186ff1edd54277d5a4bb4386826464ec52ca5d4d7a14440587a02(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__252d130551d796782efca98062a80fdb4c0c2d922a95fe02cbbf0ce9419c5331(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9df3f05bcbc08bdde2f42881d4783250927158bd26e88f091ebaa6c35242e083(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ce1c4eb197ccd4664ae9c06eb22f8e13e168e9f0ec0d7f8006d63ba99036344f(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ddbbd5c567fe27d317db63120d9c6bd356dde75c1fe29ac0a5d4fad1e55c2684(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d04bad79cc0b8f52fe1e5fe9ac8d3c22079ed1bffbc2d75f4be517632a015657(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d9c1dab84a5fd74748040be8e028c382fa6a81ce28d514aeee48ea9805a4d277(
    value: typing.Optional[GroupRoleManagementPolicyActivationRules],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__336f6c87dee6b2c30868943deb80c7dfb7130f7e64f8f8523024b244f3839ec8(
    *,
    expiration_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    expire_after: typing.Optional[builtins.str] = None,
    require_justification: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    require_multifactor_authentication: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    require_ticket_info: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e11fe4e023d0d2b466264b4752ad29d084607c4380deeb51d624d40d437f1fe8(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9944010d1064f954793f4acc892259172b4b8b1c134d0c7e23fab912d5f86466(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__12cd889f4e1e5a7b86fec565f62ffc20a63990c4b78656c9a27f4c13cc98ef25(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4b3fa39cb1a5ee9d60cabc5e90292502bb53a82a4b493a50da0b65ab23293d93(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cb23e60f0b8af07233c51a3abed6a4fbf205491109cff0e3b0103b0d42eb5085(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7b4e0c7d3a9e2b82df6485a086bf9102b24365cbb5bca2f26a9bd6b1985b8865(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c581292c87130cfe6098c6c537de641fc6276c319887c22e85ad57fbea84b4a8(
    value: typing.Optional[GroupRoleManagementPolicyActiveAssignmentRules],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__314cef4dedb20ac983962eb27f99698871810092c017c74ac5e46993b12d23ad(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    group_id: builtins.str,
    role_id: builtins.str,
    activation_rules: typing.Optional[typing.Union[GroupRoleManagementPolicyActivationRules, typing.Dict[builtins.str, typing.Any]]] = None,
    active_assignment_rules: typing.Optional[typing.Union[GroupRoleManagementPolicyActiveAssignmentRules, typing.Dict[builtins.str, typing.Any]]] = None,
    eligible_assignment_rules: typing.Optional[typing.Union[GroupRoleManagementPolicyEligibleAssignmentRules, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[builtins.str] = None,
    notification_rules: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRules, typing.Dict[builtins.str, typing.Any]]] = None,
    timeouts: typing.Optional[typing.Union[GroupRoleManagementPolicyTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5463e5106148d7b4d099856a6fab68ecae1fe1ed71f715c1b5866d7dc699a800(
    *,
    expiration_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    expire_after: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__81062b57b753308379d96dc0dec999bb80fb776ff97082e67e3a33c3cf4e2d46(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08a0ac5c96ade902ce5cff514f91509942f8c6eb92384a60359d0b60af98da9e(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e850d8f00707832d1a948538d05d460ed964571369757f9322256c1fabd9cd69(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dbf030f3ece8f8bf669d8ef1f71118cbead30057d1f44a1650f563eb037ef73b(
    value: typing.Optional[GroupRoleManagementPolicyEligibleAssignmentRules],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__68deefbfe14e6d585da329fc5fe49d007e576571a57df674e50db0ba3750bc61(
    *,
    active_assignments: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesActiveAssignments, typing.Dict[builtins.str, typing.Any]]] = None,
    eligible_activations: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesEligibleActivations, typing.Dict[builtins.str, typing.Any]]] = None,
    eligible_assignments: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesEligibleAssignments, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e9db2ca6f7516f369a5c53c8dde59dd98e876168f249681ca91213c3effcd071(
    *,
    admin_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
    approver_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
    assignee_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fb51cc8a5fed25efa5f9f3d1a5e35fbb8b0ae1af6578b7de3a0775e9783c5239(
    *,
    default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    notification_level: builtins.str,
    additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__005ed74ef0cb3a4f391da6ad930ff96b54c56fe7e7d2fd2c0d47a8ebd44d4aa5(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f437717e577c4ed8e4a17abfe816c65b667c9dc207921ce2a1921c3981009ede(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dea767b638bcd5c1a091e143a70257dbde98a1d8118dcbd8b0591a0c2329a0d8(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__495d6d3e17f87cbe7967941bf825db9a793af6f719cebd2c2f00466ad610f054(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__23c793789beb056e0cec5b3c88be74437e156cae84731df337489996484f6c02(
    value: typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__403634859979fe359604127d6a41924aaa5f318bb71bb67ae881a7adbab7206e(
    *,
    default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    notification_level: builtins.str,
    additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__418662a47d3715d18225d272c1a2a3156900e4a2528e052c2fa53c92aec3238c(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b8d7914ee043af3e37c0163880508b955e898c4b2ae1db36cbca7d8c4afe6249(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e3a0c9a2f2b63ac3a19f6420a81ad34b8f0d317cca487e7ee51289dcc07c7664(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__844985a0e925ceb20dc1abe00fe63bb6be5f71425f67e1e24edb546b8bc16e0d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5c64f339594bbbcdb1ce9c1931af8bfe84c1f1dedc3373ab9e62f612676ec2c1(
    value: typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__475f942b5f0314845eed11f8f963caa1c6023e391bc55e7afcb25430fc591959(
    *,
    default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    notification_level: builtins.str,
    additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9b5fd69c7d7e3c884b54051f5417b9bfec2522fbbdd3f5409a860c1b3d68ce68(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c39df3b163c38dd1edd1d000360ce849ab0405690d157467b50ec50851ad90d2(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0378be35294334633e2c81bb1f5325419eda0059035ef52d56c83a031600580f(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e74096807d9876ec61e719149f601d0de7b80623447fc6c900b60f275ccc7859(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__826e1f433ba935ce04f613b1fdeaf41aa87207fb2c39de5d46b7462a7aa96b82(
    value: typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__22c3898425bb8ab5143e534b0da848671ae1b9edb0d75366fd227ffc033c3686(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6065851a5e3b946a4662b20fbb268b752e3c18ad422dc7f1376f3fe0716c967b(
    value: typing.Optional[GroupRoleManagementPolicyNotificationRulesActiveAssignments],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__36f74813e98133317216fbfe238fac3c55419a429fa44cc7d27ecfcb84db9a77(
    *,
    admin_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
    approver_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
    assignee_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a3b208898d67074155eb8e56a410cdf0035d238110499cfaf4df00cba037cb0d(
    *,
    default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    notification_level: builtins.str,
    additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__032672bd343d7dee951c33f5118ed21bbccdea100dd5ca800ee737aa750e211c(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3c05a27ea92d07b48427e495e576bcd35fdaad132d5d5c5a055951303ecd0508(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__343add1131974981d01005b9ec6c5c862598c059cee91231ec87941ac4e99e48(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4431fe13ffe4a923baa2ad6da1be06eaebb2b19687010df5656a289da3ba38ea(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3893edb4ce5b391e38440dbf1392e6afd5f6e99a073dffad4135a5a74075f301(
    value: typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__718dfb027045d577d7f9b91fbad20f9bce0b98528c7f29820cc2a9960d180788(
    *,
    default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    notification_level: builtins.str,
    additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cf35651b2e5be2b71f9c5f78df22151d81f37ff580f79d465adccb679f3e4b62(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4083125aeb16af8e3e4e64b9292deb57ae83cf9e021c5341235bab4d33e3f682(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fb44d9e20f130d297deea3632380e37c96a2c1eb8de9e2b5982879b7476c44d2(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8a6271f5806b3eb4ee2c01a46a124ea47d1ec8832bcdb88b09d5145c6970d407(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7bcb56f5eec2accd48026ec329accb0bb64ee14c408bc11200ed4c7431d3d864(
    value: typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3f19081ff8769aa882f485155158b604529a6e05d3e247a5081bb710d4b0da9c(
    *,
    default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    notification_level: builtins.str,
    additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__52f3f557aa2d35d8eb2b04fafeeddfb25386a70c59106cb88fd19897b57000be(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__59d2155840e1daa4d7470d928ed7e4a485ab37ce8982aa561e1b6f32833d29af(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f83cc20e65454ac480db08f1735579ce5da338e942667ffe518e1dbd8d2955e9(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b431d5881aed4e05119affb08e50713ac3e16ee0b8ec4c3335e2cb609bfb134e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cc8a47a1b064581897f895d9286f615c287284284ede19ada5b39699cbd100ad(
    value: typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__55ff1a9547a00ebdc696711f2473d829294354244843f1e8cefd547f2e2a4476(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f997b44b05fb39973df6b0726b790c7f91e267ed566e3d727f8ad6fc37b12966(
    value: typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleActivations],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__af10ed99f6cf7cc3288cecd1c71cf130de62c7709cc16a18c2f3bacb1eb4daf2(
    *,
    admin_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
    approver_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
    assignee_notifications: typing.Optional[typing.Union[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b71372f8033e1327db2efc054290c12fdbaea7b4ff53d6657f5416e54149fb51(
    *,
    default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    notification_level: builtins.str,
    additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__83bc7219cb1f8ab4a017775da0668a93f010a51015ae0aaa8a5eb07aa7b6cfef(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__be10c624961cc911146fa2bf147d4f02cdad9ebf2b6b2ac8ff5c5952ab376702(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__26cf3a9d82e406242b5d26a561cce60e05aa01d375d8ef44e474fc62a383a9fa(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e3efd28edc67922bce51a0d2e381ee2b24315a33a2e2662038803c7146af4fb0(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fc3a317e0e1ac5c2771443dffdaf7ad1cede17fce672daa066a81eeb3d1d0202(
    value: typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c953633046f41a8adb4eaab4223f4fee4755fcae262fc43d0840616680d20f3b(
    *,
    default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    notification_level: builtins.str,
    additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__36708e26e3d826f26aa63f4255aeeccf1ee614aae15528a74b41acde1cd15aca(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d9dd1dd8f638eed377bea30284728307b446968069c10a21b338e262d73c54f1(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f26ca33cee9359d3a0a5c48a56e12dfb81ced85f5b5f8b8b6682d7ae9716839(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__35d9b864f0fc974010792d555009ba4483e41a0dbd19352fd275591bdbfffc27(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c25b148c89164d0ac2b51806d887b80a870cfe5f118b898efecd3bf17af54865(
    value: typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d004085b3d9d09b399cef8debab6b2f7b6ec0025eeeea1cc2f5e24470130d5ac(
    *,
    default_recipients: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    notification_level: builtins.str,
    additional_recipients: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60c0bfe2b2c9ddfd3233a388eed1d7cb93dd2d09740672f454d243eed9be3f69(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__28b3b95f275fba4dcfa498aee8cdacdc62c58a27d8ca5cf57195e2d4bcc9fb64(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60e3ec77278442b0de93173e8d3b21de97321e154fcff536ee5dd1e6f3a0ca78(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4e57730b8175f134fc9ac4213e4987aa426e5d06af706cd22e1b7661fae5f147(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cd5b95924ba04a888a0c2d0d7864670b8092833f03985112c134f46e5df936c9(
    value: typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a239bbaac0ab5d24e3b9cd558e5588f363f823d149c1a6b29484cd9478466758(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__72e25eb0bf9abfa33e4fa5a95dc71deb61e39ddb79a90a05a00b3ec6eec829fd(
    value: typing.Optional[GroupRoleManagementPolicyNotificationRulesEligibleAssignments],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cb37042caebfce36f08015fc371b5e844560bccdebb6abfaaa8156b856896de3(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__edad60abd372d64017fe6c6d35fbab2a366361a783858f9c3525ffa33587d998(
    value: typing.Optional[GroupRoleManagementPolicyNotificationRules],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4c425dd1e82ffe9f75d3c0a56fd917ee3fcfab4bfeaf2d52f2eed517b093e209(
    *,
    create: typing.Optional[builtins.str] = None,
    delete: typing.Optional[builtins.str] = None,
    read: typing.Optional[builtins.str] = None,
    update: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9d2fca51860d0a0531f287a61c1ecf222a4f50bcae8d11b0ccfce92563f2d2ec(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__55d393b438b5b440650df0bb79aad60295c68ebf316725f397d046ea4c30dfb7(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2cf71a26183fdf6a6597b307d72077edeff2c85c99b81dba0a4420e7545f20e8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__deaf5399d51b31685f4592e3928e41ccf6327bf70244b1031b6aa55e98270d5b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fffeaef7b17673b41d4f0fed0fd72f8090aba3113f8e7b93068fe84a1246d044(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__479eebdaac5331adf9a7d4ad7fc1c2f4805f852bc5afea5f868ebcf54266fad8(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, GroupRoleManagementPolicyTimeouts]],
) -> None:
    """Type checking stubs"""
    pass
