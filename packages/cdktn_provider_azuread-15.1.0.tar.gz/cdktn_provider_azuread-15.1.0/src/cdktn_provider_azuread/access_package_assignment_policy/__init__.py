r'''
# `azuread_access_package_assignment_policy`

Refer to the Terraform Registry for docs: [`azuread_access_package_assignment_policy`](https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class AccessPackageAssignmentPolicy(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicy",
):
    '''Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy azuread_access_package_assignment_policy}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id_: builtins.str,
        *,
        access_package_id: builtins.str,
        description: builtins.str,
        display_name: builtins.str,
        approval_settings: typing.Optional[typing.Union["AccessPackageAssignmentPolicyApprovalSettings", typing.Dict[builtins.str, typing.Any]]] = None,
        assignment_review_settings: typing.Optional[typing.Union["AccessPackageAssignmentPolicyAssignmentReviewSettings", typing.Dict[builtins.str, typing.Any]]] = None,
        duration_in_days: typing.Optional[jsii.Number] = None,
        expiration_date: typing.Optional[builtins.str] = None,
        extension_enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        id: typing.Optional[builtins.str] = None,
        question: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyQuestion", typing.Dict[builtins.str, typing.Any]]]]] = None,
        requestor_settings: typing.Optional[typing.Union["AccessPackageAssignmentPolicyRequestorSettings", typing.Dict[builtins.str, typing.Any]]] = None,
        timeouts: typing.Optional[typing.Union["AccessPackageAssignmentPolicyTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy azuread_access_package_assignment_policy} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param access_package_id: The ID of the access package that will contain the policy. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#access_package_id AccessPackageAssignmentPolicy#access_package_id}
        :param description: The description of the policy. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#description AccessPackageAssignmentPolicy#description}
        :param display_name: The display name of the policy. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#display_name AccessPackageAssignmentPolicy#display_name}
        :param approval_settings: approval_settings block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approval_settings AccessPackageAssignmentPolicy#approval_settings}
        :param assignment_review_settings: assignment_review_settings block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#assignment_review_settings AccessPackageAssignmentPolicy#assignment_review_settings}
        :param duration_in_days: How many days this assignment is valid for. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#duration_in_days AccessPackageAssignmentPolicy#duration_in_days}
        :param expiration_date: The date that this assignment expires, formatted as an RFC3339 date string in UTC (e.g. 2018-01-01T01:02:03Z). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#expiration_date AccessPackageAssignmentPolicy#expiration_date}
        :param extension_enabled: When enabled, users will be able to request extension of their access to this package before their access expires. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#extension_enabled AccessPackageAssignmentPolicy#extension_enabled}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#id AccessPackageAssignmentPolicy#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param question: question block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#question AccessPackageAssignmentPolicy#question}
        :param requestor_settings: requestor_settings block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#requestor_settings AccessPackageAssignmentPolicy#requestor_settings}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#timeouts AccessPackageAssignmentPolicy#timeouts}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1fea9352b15a07fce47c90be772a5268410bf494be86c12ab2e819dcc247f279)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = AccessPackageAssignmentPolicyConfig(
            access_package_id=access_package_id,
            description=description,
            display_name=display_name,
            approval_settings=approval_settings,
            assignment_review_settings=assignment_review_settings,
            duration_in_days=duration_in_days,
            expiration_date=expiration_date,
            extension_enabled=extension_enabled,
            id=id,
            question=question,
            requestor_settings=requestor_settings,
            timeouts=timeouts,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    ) -> _cdktn_78ede62e.ImportableResource:
        '''Generates CDKTN code for importing a AccessPackageAssignmentPolicy resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the AccessPackageAssignmentPolicy to import.
        :param import_from_id: The id of the existing AccessPackageAssignmentPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the AccessPackageAssignmentPolicy to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0580d4f0f9f7447f46f8295aa17075e7fee70380b2221da16ec24ec9d09ea166)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktn_78ede62e.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putApprovalSettings")
    def put_approval_settings(
        self,
        *,
        approval_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        approval_required_for_extension: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        approval_stage: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyApprovalSettingsApprovalStage", typing.Dict[builtins.str, typing.Any]]]]] = None,
        requestor_justification_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param approval_required: Whether an approval is required. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approval_required AccessPackageAssignmentPolicy#approval_required}
        :param approval_required_for_extension: Whether an approval is required to grant extension. Same approval settings used to approve initial access will apply. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approval_required_for_extension AccessPackageAssignmentPolicy#approval_required_for_extension}
        :param approval_stage: approval_stage block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approval_stage AccessPackageAssignmentPolicy#approval_stage}
        :param requestor_justification_required: Whether requestor are required to provide a justification to request an access package. Justification is visible to other approvers and the requestor Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#requestor_justification_required AccessPackageAssignmentPolicy#requestor_justification_required}
        '''
        value = AccessPackageAssignmentPolicyApprovalSettings(
            approval_required=approval_required,
            approval_required_for_extension=approval_required_for_extension,
            approval_stage=approval_stage,
            requestor_justification_required=requestor_justification_required,
        )

        return typing.cast(None, jsii.invoke(self, "putApprovalSettings", [value]))

    @jsii.member(jsii_name="putAssignmentReviewSettings")
    def put_assignment_review_settings(
        self,
        *,
        access_recommendation_enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        access_review_timeout_behavior: typing.Optional[builtins.str] = None,
        approver_justification_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        duration_in_days: typing.Optional[jsii.Number] = None,
        enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        reviewer: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer", typing.Dict[builtins.str, typing.Any]]]]] = None,
        review_frequency: typing.Optional[builtins.str] = None,
        review_type: typing.Optional[builtins.str] = None,
        starting_on: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param access_recommendation_enabled: Whether to show Show reviewer decision helpers. If enabled, system recommendations based on users' access information will be shown to the reviewers. The reviewer will be recommended to approve the review if the user has signed-in at least once during the last 30 days. The reviewer will be recommended to deny the review if the user has not signed-in during the last 30 days Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#access_recommendation_enabled AccessPackageAssignmentPolicy#access_recommendation_enabled}
        :param access_review_timeout_behavior: What actions the system takes if reviewers don't respond in time. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#access_review_timeout_behavior AccessPackageAssignmentPolicy#access_review_timeout_behavior}
        :param approver_justification_required: Whether a reviewer need provide a justification for their decision. Justification is visible to other reviewers and the requestor. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approver_justification_required AccessPackageAssignmentPolicy#approver_justification_required}
        :param duration_in_days: How many days each occurrence of the access review series will run. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#duration_in_days AccessPackageAssignmentPolicy#duration_in_days}
        :param enabled: Whether to enable assignment review. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#enabled AccessPackageAssignmentPolicy#enabled}
        :param reviewer: reviewer block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#reviewer AccessPackageAssignmentPolicy#reviewer}
        :param review_frequency: This will determine how often the access review campaign runs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#review_frequency AccessPackageAssignmentPolicy#review_frequency}
        :param review_type: Self review or specific reviewers. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#review_type AccessPackageAssignmentPolicy#review_type}
        :param starting_on: This is the date the access review campaign will start on, formatted as an RFC3339 date string in UTC(e.g. 2018-01-01T01:02:03Z), default is now. Once an access review has been created, you cannot update its start date. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#starting_on AccessPackageAssignmentPolicy#starting_on}
        '''
        value = AccessPackageAssignmentPolicyAssignmentReviewSettings(
            access_recommendation_enabled=access_recommendation_enabled,
            access_review_timeout_behavior=access_review_timeout_behavior,
            approver_justification_required=approver_justification_required,
            duration_in_days=duration_in_days,
            enabled=enabled,
            reviewer=reviewer,
            review_frequency=review_frequency,
            review_type=review_type,
            starting_on=starting_on,
        )

        return typing.cast(None, jsii.invoke(self, "putAssignmentReviewSettings", [value]))

    @jsii.member(jsii_name="putQuestion")
    def put_question(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyQuestion", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__19ad8e89fd8be64d1f5997fea045e34b35b663a6dfdc42a1664dee1b8449e822)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putQuestion", [value]))

    @jsii.member(jsii_name="putRequestorSettings")
    def put_requestor_settings(
        self,
        *,
        requestor: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyRequestorSettingsRequestor", typing.Dict[builtins.str, typing.Any]]]]] = None,
        requests_accepted: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        scope_type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param requestor: requestor block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#requestor AccessPackageAssignmentPolicy#requestor}
        :param requests_accepted: Whether to accept requests now, when disabled, no new requests can be made using this policy. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#requests_accepted AccessPackageAssignmentPolicy#requests_accepted}
        :param scope_type: Specify the scopes of the requestors. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#scope_type AccessPackageAssignmentPolicy#scope_type}
        '''
        value = AccessPackageAssignmentPolicyRequestorSettings(
            requestor=requestor,
            requests_accepted=requests_accepted,
            scope_type=scope_type,
        )

        return typing.cast(None, jsii.invoke(self, "putRequestorSettings", [value]))

    @jsii.member(jsii_name="putTimeouts")
    def put_timeouts(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#create AccessPackageAssignmentPolicy#create}.
        :param delete: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#delete AccessPackageAssignmentPolicy#delete}.
        :param read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#read AccessPackageAssignmentPolicy#read}.
        :param update: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#update AccessPackageAssignmentPolicy#update}.
        '''
        value = AccessPackageAssignmentPolicyTimeouts(
            create=create, delete=delete, read=read, update=update
        )

        return typing.cast(None, jsii.invoke(self, "putTimeouts", [value]))

    @jsii.member(jsii_name="resetApprovalSettings")
    def reset_approval_settings(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetApprovalSettings", []))

    @jsii.member(jsii_name="resetAssignmentReviewSettings")
    def reset_assignment_review_settings(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAssignmentReviewSettings", []))

    @jsii.member(jsii_name="resetDurationInDays")
    def reset_duration_in_days(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDurationInDays", []))

    @jsii.member(jsii_name="resetExpirationDate")
    def reset_expiration_date(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExpirationDate", []))

    @jsii.member(jsii_name="resetExtensionEnabled")
    def reset_extension_enabled(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetExtensionEnabled", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetQuestion")
    def reset_question(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetQuestion", []))

    @jsii.member(jsii_name="resetRequestorSettings")
    def reset_requestor_settings(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequestorSettings", []))

    @jsii.member(jsii_name="resetTimeouts")
    def reset_timeouts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeouts", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="approvalSettings")
    def approval_settings(
        self,
    ) -> "AccessPackageAssignmentPolicyApprovalSettingsOutputReference":
        return typing.cast("AccessPackageAssignmentPolicyApprovalSettingsOutputReference", jsii.get(self, "approvalSettings"))

    @builtins.property
    @jsii.member(jsii_name="assignmentReviewSettings")
    def assignment_review_settings(
        self,
    ) -> "AccessPackageAssignmentPolicyAssignmentReviewSettingsOutputReference":
        return typing.cast("AccessPackageAssignmentPolicyAssignmentReviewSettingsOutputReference", jsii.get(self, "assignmentReviewSettings"))

    @builtins.property
    @jsii.member(jsii_name="question")
    def question(self) -> "AccessPackageAssignmentPolicyQuestionList":
        return typing.cast("AccessPackageAssignmentPolicyQuestionList", jsii.get(self, "question"))

    @builtins.property
    @jsii.member(jsii_name="requestorSettings")
    def requestor_settings(
        self,
    ) -> "AccessPackageAssignmentPolicyRequestorSettingsOutputReference":
        return typing.cast("AccessPackageAssignmentPolicyRequestorSettingsOutputReference", jsii.get(self, "requestorSettings"))

    @builtins.property
    @jsii.member(jsii_name="timeouts")
    def timeouts(self) -> "AccessPackageAssignmentPolicyTimeoutsOutputReference":
        return typing.cast("AccessPackageAssignmentPolicyTimeoutsOutputReference", jsii.get(self, "timeouts"))

    @builtins.property
    @jsii.member(jsii_name="accessPackageIdInput")
    def access_package_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "accessPackageIdInput"))

    @builtins.property
    @jsii.member(jsii_name="approvalSettingsInput")
    def approval_settings_input(
        self,
    ) -> typing.Optional["AccessPackageAssignmentPolicyApprovalSettings"]:
        return typing.cast(typing.Optional["AccessPackageAssignmentPolicyApprovalSettings"], jsii.get(self, "approvalSettingsInput"))

    @builtins.property
    @jsii.member(jsii_name="assignmentReviewSettingsInput")
    def assignment_review_settings_input(
        self,
    ) -> typing.Optional["AccessPackageAssignmentPolicyAssignmentReviewSettings"]:
        return typing.cast(typing.Optional["AccessPackageAssignmentPolicyAssignmentReviewSettings"], jsii.get(self, "assignmentReviewSettingsInput"))

    @builtins.property
    @jsii.member(jsii_name="descriptionInput")
    def description_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "descriptionInput"))

    @builtins.property
    @jsii.member(jsii_name="displayNameInput")
    def display_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "displayNameInput"))

    @builtins.property
    @jsii.member(jsii_name="durationInDaysInput")
    def duration_in_days_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "durationInDaysInput"))

    @builtins.property
    @jsii.member(jsii_name="expirationDateInput")
    def expiration_date_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "expirationDateInput"))

    @builtins.property
    @jsii.member(jsii_name="extensionEnabledInput")
    def extension_enabled_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "extensionEnabledInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="questionInput")
    def question_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyQuestion"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyQuestion"]]], jsii.get(self, "questionInput"))

    @builtins.property
    @jsii.member(jsii_name="requestorSettingsInput")
    def requestor_settings_input(
        self,
    ) -> typing.Optional["AccessPackageAssignmentPolicyRequestorSettings"]:
        return typing.cast(typing.Optional["AccessPackageAssignmentPolicyRequestorSettings"], jsii.get(self, "requestorSettingsInput"))

    @builtins.property
    @jsii.member(jsii_name="timeoutsInput")
    def timeouts_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "AccessPackageAssignmentPolicyTimeouts"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "AccessPackageAssignmentPolicyTimeouts"]], jsii.get(self, "timeoutsInput"))

    @builtins.property
    @jsii.member(jsii_name="accessPackageId")
    def access_package_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "accessPackageId"))

    @access_package_id.setter
    def access_package_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0ef25319137a4b80d352e19dfe4858d656108b01c14cd3696cac2e4078c5df66)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "accessPackageId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="description")
    def description(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "description"))

    @description.setter
    def description(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b385ed5527c92a6a990f764a7fd1c068fa63b73325e2a4d7800e032e387cc2c0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "description", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="displayName")
    def display_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "displayName"))

    @display_name.setter
    def display_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e80f138b585352e4d79ebbdb6c1ff887d25256dac79a34408296c02ff21b62e8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "displayName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="durationInDays")
    def duration_in_days(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "durationInDays"))

    @duration_in_days.setter
    def duration_in_days(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6ae0f5274e4a9dd434a9113273e19c88d6f4d88282f41fb716f15e2c90ddaeb3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "durationInDays", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="expirationDate")
    def expiration_date(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "expirationDate"))

    @expiration_date.setter
    def expiration_date(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f33979de26d9fcfb458afdd9ea445b59fa126677401dceb703e5f43901f8187f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "expirationDate", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="extensionEnabled")
    def extension_enabled(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "extensionEnabled"))

    @extension_enabled.setter
    def extension_enabled(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__764381778310ed9a99c43146b86cea0f951c232621f839240ff3a209a7c13365)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "extensionEnabled", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7844766f82bbf9ef7938abf30a6297a14532a571349e9653e107ce66b7017305)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyApprovalSettings",
    jsii_struct_bases=[],
    name_mapping={
        "approval_required": "approvalRequired",
        "approval_required_for_extension": "approvalRequiredForExtension",
        "approval_stage": "approvalStage",
        "requestor_justification_required": "requestorJustificationRequired",
    },
)
class AccessPackageAssignmentPolicyApprovalSettings:
    def __init__(
        self,
        *,
        approval_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        approval_required_for_extension: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        approval_stage: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyApprovalSettingsApprovalStage", typing.Dict[builtins.str, typing.Any]]]]] = None,
        requestor_justification_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param approval_required: Whether an approval is required. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approval_required AccessPackageAssignmentPolicy#approval_required}
        :param approval_required_for_extension: Whether an approval is required to grant extension. Same approval settings used to approve initial access will apply. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approval_required_for_extension AccessPackageAssignmentPolicy#approval_required_for_extension}
        :param approval_stage: approval_stage block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approval_stage AccessPackageAssignmentPolicy#approval_stage}
        :param requestor_justification_required: Whether requestor are required to provide a justification to request an access package. Justification is visible to other approvers and the requestor Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#requestor_justification_required AccessPackageAssignmentPolicy#requestor_justification_required}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__42b4e1124b42501a8240e9583d116c2a39cac96b8648f01982e40aec754c9f59)
            check_type(argname="argument approval_required", value=approval_required, expected_type=type_hints["approval_required"])
            check_type(argname="argument approval_required_for_extension", value=approval_required_for_extension, expected_type=type_hints["approval_required_for_extension"])
            check_type(argname="argument approval_stage", value=approval_stage, expected_type=type_hints["approval_stage"])
            check_type(argname="argument requestor_justification_required", value=requestor_justification_required, expected_type=type_hints["requestor_justification_required"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if approval_required is not None:
            self._values["approval_required"] = approval_required
        if approval_required_for_extension is not None:
            self._values["approval_required_for_extension"] = approval_required_for_extension
        if approval_stage is not None:
            self._values["approval_stage"] = approval_stage
        if requestor_justification_required is not None:
            self._values["requestor_justification_required"] = requestor_justification_required

    @builtins.property
    def approval_required(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether an approval is required.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approval_required AccessPackageAssignmentPolicy#approval_required}
        '''
        result = self._values.get("approval_required")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def approval_required_for_extension(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether an approval is required to grant extension. Same approval settings used to approve initial access will apply.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approval_required_for_extension AccessPackageAssignmentPolicy#approval_required_for_extension}
        '''
        result = self._values.get("approval_required_for_extension")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def approval_stage(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyApprovalSettingsApprovalStage"]]]:
        '''approval_stage block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approval_stage AccessPackageAssignmentPolicy#approval_stage}
        '''
        result = self._values.get("approval_stage")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyApprovalSettingsApprovalStage"]]], result)

    @builtins.property
    def requestor_justification_required(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether requestor are required to provide a justification to request an access package.

        Justification is visible to other approvers and the requestor

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#requestor_justification_required AccessPackageAssignmentPolicy#requestor_justification_required}
        '''
        result = self._values.get("requestor_justification_required")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AccessPackageAssignmentPolicyApprovalSettings(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyApprovalSettingsApprovalStage",
    jsii_struct_bases=[],
    name_mapping={
        "approval_timeout_in_days": "approvalTimeoutInDays",
        "alternative_approval_enabled": "alternativeApprovalEnabled",
        "alternative_approver": "alternativeApprover",
        "approver_justification_required": "approverJustificationRequired",
        "enable_alternative_approval_in_days": "enableAlternativeApprovalInDays",
        "primary_approver": "primaryApprover",
    },
)
class AccessPackageAssignmentPolicyApprovalSettingsApprovalStage:
    def __init__(
        self,
        *,
        approval_timeout_in_days: jsii.Number,
        alternative_approval_enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        alternative_approver: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover", typing.Dict[builtins.str, typing.Any]]]]] = None,
        approver_justification_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        enable_alternative_approval_in_days: typing.Optional[jsii.Number] = None,
        primary_approver: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''
        :param approval_timeout_in_days: Decision must be made in how many days? If a request is not approved within this time period after it is made, it will be automatically rejected Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approval_timeout_in_days AccessPackageAssignmentPolicy#approval_timeout_in_days}
        :param alternative_approval_enabled: If no action taken, forward to alternate approvers? Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#alternative_approval_enabled AccessPackageAssignmentPolicy#alternative_approval_enabled}
        :param alternative_approver: alternative_approver block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#alternative_approver AccessPackageAssignmentPolicy#alternative_approver}
        :param approver_justification_required: Whether an approver must provide a justification for their decision. Justification is visible to other approvers and the requestor. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approver_justification_required AccessPackageAssignmentPolicy#approver_justification_required}
        :param enable_alternative_approval_in_days: Forward to alternate approver(s) after how many days? Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#enable_alternative_approval_in_days AccessPackageAssignmentPolicy#enable_alternative_approval_in_days}
        :param primary_approver: primary_approver block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#primary_approver AccessPackageAssignmentPolicy#primary_approver}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__582406fc6e414fbce54dc207b3f454298afcec2c6c1c3990354bc09a2d9025aa)
            check_type(argname="argument approval_timeout_in_days", value=approval_timeout_in_days, expected_type=type_hints["approval_timeout_in_days"])
            check_type(argname="argument alternative_approval_enabled", value=alternative_approval_enabled, expected_type=type_hints["alternative_approval_enabled"])
            check_type(argname="argument alternative_approver", value=alternative_approver, expected_type=type_hints["alternative_approver"])
            check_type(argname="argument approver_justification_required", value=approver_justification_required, expected_type=type_hints["approver_justification_required"])
            check_type(argname="argument enable_alternative_approval_in_days", value=enable_alternative_approval_in_days, expected_type=type_hints["enable_alternative_approval_in_days"])
            check_type(argname="argument primary_approver", value=primary_approver, expected_type=type_hints["primary_approver"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "approval_timeout_in_days": approval_timeout_in_days,
        }
        if alternative_approval_enabled is not None:
            self._values["alternative_approval_enabled"] = alternative_approval_enabled
        if alternative_approver is not None:
            self._values["alternative_approver"] = alternative_approver
        if approver_justification_required is not None:
            self._values["approver_justification_required"] = approver_justification_required
        if enable_alternative_approval_in_days is not None:
            self._values["enable_alternative_approval_in_days"] = enable_alternative_approval_in_days
        if primary_approver is not None:
            self._values["primary_approver"] = primary_approver

    @builtins.property
    def approval_timeout_in_days(self) -> jsii.Number:
        '''Decision must be made in how many days?

        If a request is not approved within this time period after it is made, it will be automatically rejected

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approval_timeout_in_days AccessPackageAssignmentPolicy#approval_timeout_in_days}
        '''
        result = self._values.get("approval_timeout_in_days")
        assert result is not None, "Required property 'approval_timeout_in_days' is missing"
        return typing.cast(jsii.Number, result)

    @builtins.property
    def alternative_approval_enabled(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''If no action taken, forward to alternate approvers?

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#alternative_approval_enabled AccessPackageAssignmentPolicy#alternative_approval_enabled}
        '''
        result = self._values.get("alternative_approval_enabled")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def alternative_approver(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover"]]]:
        '''alternative_approver block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#alternative_approver AccessPackageAssignmentPolicy#alternative_approver}
        '''
        result = self._values.get("alternative_approver")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover"]]], result)

    @builtins.property
    def approver_justification_required(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether an approver must provide a justification for their decision. Justification is visible to other approvers and the requestor.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approver_justification_required AccessPackageAssignmentPolicy#approver_justification_required}
        '''
        result = self._values.get("approver_justification_required")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def enable_alternative_approval_in_days(self) -> typing.Optional[jsii.Number]:
        '''Forward to alternate approver(s) after how many days?

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#enable_alternative_approval_in_days AccessPackageAssignmentPolicy#enable_alternative_approval_in_days}
        '''
        result = self._values.get("enable_alternative_approval_in_days")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def primary_approver(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover"]]]:
        '''primary_approver block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#primary_approver AccessPackageAssignmentPolicy#primary_approver}
        '''
        result = self._values.get("primary_approver")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover"]]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AccessPackageAssignmentPolicyApprovalSettingsApprovalStage(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover",
    jsii_struct_bases=[],
    name_mapping={
        "subject_type": "subjectType",
        "backup": "backup",
        "object_id": "objectId",
    },
)
class AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover:
    def __init__(
        self,
        *,
        subject_type: builtins.str,
        backup: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        object_id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param subject_type: Type of users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#subject_type AccessPackageAssignmentPolicy#subject_type}
        :param backup: For a user in an approval stage, this property indicates whether the user is a backup fallback approver. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#backup AccessPackageAssignmentPolicy#backup}
        :param object_id: The object ID of the subject. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#object_id AccessPackageAssignmentPolicy#object_id}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f026e230bce8bb225396ad0dd598500929282852cfd23ecaf8f4bc63c563b8db)
            check_type(argname="argument subject_type", value=subject_type, expected_type=type_hints["subject_type"])
            check_type(argname="argument backup", value=backup, expected_type=type_hints["backup"])
            check_type(argname="argument object_id", value=object_id, expected_type=type_hints["object_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "subject_type": subject_type,
        }
        if backup is not None:
            self._values["backup"] = backup
        if object_id is not None:
            self._values["object_id"] = object_id

    @builtins.property
    def subject_type(self) -> builtins.str:
        '''Type of users.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#subject_type AccessPackageAssignmentPolicy#subject_type}
        '''
        result = self._values.get("subject_type")
        assert result is not None, "Required property 'subject_type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def backup(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''For a user in an approval stage, this property indicates whether the user is a backup fallback approver.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#backup AccessPackageAssignmentPolicy#backup}
        '''
        result = self._values.get("backup")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def object_id(self) -> typing.Optional[builtins.str]:
        '''The object ID of the subject.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#object_id AccessPackageAssignmentPolicy#object_id}
        '''
        result = self._values.get("object_id")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApproverList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApproverList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__32621f10f032403f35a930a3b58517e16b34bf610122a13ad97ab08c1de8e8f1)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApproverOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eed7e1dfafde7397ef673fe8c3e030b3c233a069856c923c66104e144d409388)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApproverOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__56bd89f3521253f5eb26ac5dd235dd2c72f5e132b5085bde460bd9a9ce800123)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7555c9b2cd66487b66919d80349be4e25a1a148c7612eb694648075ef1ce0b6b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__55e4338c4e19c610eb46a68be1175e6ba16f4d585c73ef02f917bd9bf00803a2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6f354e71a2738eccf4af7b73f8a95a8e7c0b4b03e59942af57360c0df75f41c1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApproverOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApproverOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a188a2c72a44ad699483288b8b710efa4cd9b091d1f4cd2facc3e9bf52e5cd46)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetBackup")
    def reset_backup(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBackup", []))

    @jsii.member(jsii_name="resetObjectId")
    def reset_object_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetObjectId", []))

    @builtins.property
    @jsii.member(jsii_name="backupInput")
    def backup_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "backupInput"))

    @builtins.property
    @jsii.member(jsii_name="objectIdInput")
    def object_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "objectIdInput"))

    @builtins.property
    @jsii.member(jsii_name="subjectTypeInput")
    def subject_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "subjectTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="backup")
    def backup(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "backup"))

    @backup.setter
    def backup(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a4b4f8e186c10b04eb9a844749ef377e0ca0e8de0c966a499c0de7901d635031)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "backup", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="objectId")
    def object_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "objectId"))

    @object_id.setter
    def object_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__208a5928c9c95c2dffa3642d6d40bbdb355802203ecd4674c07aa0dd2f8d3d54)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "objectId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="subjectType")
    def subject_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "subjectType"))

    @subject_type.setter
    def subject_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d9bab26ce2e7295d341d9fba3215ffe4341a4f768a23de363a3d6e21aec11481)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "subjectType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aee58b0d5452c983d4f4749af4eb54fe1d26b5d4458606fbe8c26c7e89ca5222)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class AccessPackageAssignmentPolicyApprovalSettingsApprovalStageList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyApprovalSettingsApprovalStageList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9f476bde9da36d58a8b7d52c3167c7e1fdce52f6adc4cb0e074e62f9b20c9a37)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "AccessPackageAssignmentPolicyApprovalSettingsApprovalStageOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1aedb9370891f2843660dca33fcf734f0c03414be09f74b85cb1e74bd363d6cc)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("AccessPackageAssignmentPolicyApprovalSettingsApprovalStageOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b311f8f9231963113c221800e0cba6479d666610534f8f878d4677276ba57e5d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f53a50baf2afba248ef56bc13d59c6c85332bac0d416a61172817904630ee295)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d04c4fa98d2742db3b33571945c4fc3a0a6d8baf3fbb8dbbfd1770aa0867453f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyApprovalSettingsApprovalStage]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyApprovalSettingsApprovalStage]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyApprovalSettingsApprovalStage]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3ce9dc0e9f1a95b9fec9c9b42b139d4edfa69486bc55fac86d71e12c42b33f10)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class AccessPackageAssignmentPolicyApprovalSettingsApprovalStageOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyApprovalSettingsApprovalStageOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7335cbd4a19b6c9da41ac2384b178c6502e02f5e7476d890abc7493ae6a00064)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putAlternativeApprover")
    def put_alternative_approver(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover, typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e9463b09e50e8386d707049fc481b2a99e03e392a346845c4b1b988d9f59a9e3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putAlternativeApprover", [value]))

    @jsii.member(jsii_name="putPrimaryApprover")
    def put_primary_approver(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__14b1b6be3b425d5f50c26c5e5e20d2a4eca239509917d2b1133e41e153dc7c2e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putPrimaryApprover", [value]))

    @jsii.member(jsii_name="resetAlternativeApprovalEnabled")
    def reset_alternative_approval_enabled(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAlternativeApprovalEnabled", []))

    @jsii.member(jsii_name="resetAlternativeApprover")
    def reset_alternative_approver(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAlternativeApprover", []))

    @jsii.member(jsii_name="resetApproverJustificationRequired")
    def reset_approver_justification_required(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetApproverJustificationRequired", []))

    @jsii.member(jsii_name="resetEnableAlternativeApprovalInDays")
    def reset_enable_alternative_approval_in_days(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEnableAlternativeApprovalInDays", []))

    @jsii.member(jsii_name="resetPrimaryApprover")
    def reset_primary_approver(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPrimaryApprover", []))

    @builtins.property
    @jsii.member(jsii_name="alternativeApprover")
    def alternative_approver(
        self,
    ) -> AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApproverList:
        return typing.cast(AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApproverList, jsii.get(self, "alternativeApprover"))

    @builtins.property
    @jsii.member(jsii_name="primaryApprover")
    def primary_approver(
        self,
    ) -> "AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApproverList":
        return typing.cast("AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApproverList", jsii.get(self, "primaryApprover"))

    @builtins.property
    @jsii.member(jsii_name="alternativeApprovalEnabledInput")
    def alternative_approval_enabled_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "alternativeApprovalEnabledInput"))

    @builtins.property
    @jsii.member(jsii_name="alternativeApproverInput")
    def alternative_approver_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover]]], jsii.get(self, "alternativeApproverInput"))

    @builtins.property
    @jsii.member(jsii_name="approvalTimeoutInDaysInput")
    def approval_timeout_in_days_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "approvalTimeoutInDaysInput"))

    @builtins.property
    @jsii.member(jsii_name="approverJustificationRequiredInput")
    def approver_justification_required_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "approverJustificationRequiredInput"))

    @builtins.property
    @jsii.member(jsii_name="enableAlternativeApprovalInDaysInput")
    def enable_alternative_approval_in_days_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "enableAlternativeApprovalInDaysInput"))

    @builtins.property
    @jsii.member(jsii_name="primaryApproverInput")
    def primary_approver_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover"]]], jsii.get(self, "primaryApproverInput"))

    @builtins.property
    @jsii.member(jsii_name="alternativeApprovalEnabled")
    def alternative_approval_enabled(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "alternativeApprovalEnabled"))

    @alternative_approval_enabled.setter
    def alternative_approval_enabled(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7d0b0d8f9d5a4a9aa81122a7843560e2d756e792168edcf96846e7ff443ae668)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "alternativeApprovalEnabled", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="approvalTimeoutInDays")
    def approval_timeout_in_days(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "approvalTimeoutInDays"))

    @approval_timeout_in_days.setter
    def approval_timeout_in_days(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__839b6d2cab89a6dc45a7842544030573ac13c12e5dd25af932468fb3be419903)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "approvalTimeoutInDays", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="approverJustificationRequired")
    def approver_justification_required(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "approverJustificationRequired"))

    @approver_justification_required.setter
    def approver_justification_required(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d487c3e3ccd9a26a6833bc8b7d63e18e0a386ae8cef9d2d533ccb2dd7a595927)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "approverJustificationRequired", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enableAlternativeApprovalInDays")
    def enable_alternative_approval_in_days(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "enableAlternativeApprovalInDays"))

    @enable_alternative_approval_in_days.setter
    def enable_alternative_approval_in_days(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bbd8579ff588506665001c0daa031c97315ea7adf51a41809b13532d0efa861a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enableAlternativeApprovalInDays", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyApprovalSettingsApprovalStage]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyApprovalSettingsApprovalStage]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyApprovalSettingsApprovalStage]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c9458e1c6b3d096d99c50b8751b44de2fdd957ece1636603b1afdc31328c872b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover",
    jsii_struct_bases=[],
    name_mapping={
        "subject_type": "subjectType",
        "backup": "backup",
        "object_id": "objectId",
    },
)
class AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover:
    def __init__(
        self,
        *,
        subject_type: builtins.str,
        backup: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        object_id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param subject_type: Type of users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#subject_type AccessPackageAssignmentPolicy#subject_type}
        :param backup: For a user in an approval stage, this property indicates whether the user is a backup fallback approver. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#backup AccessPackageAssignmentPolicy#backup}
        :param object_id: The object ID of the subject. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#object_id AccessPackageAssignmentPolicy#object_id}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fcfe116adde1e4b97a199752340c1754bcd7da22b1bed88ae1adb8eb5e9916ec)
            check_type(argname="argument subject_type", value=subject_type, expected_type=type_hints["subject_type"])
            check_type(argname="argument backup", value=backup, expected_type=type_hints["backup"])
            check_type(argname="argument object_id", value=object_id, expected_type=type_hints["object_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "subject_type": subject_type,
        }
        if backup is not None:
            self._values["backup"] = backup
        if object_id is not None:
            self._values["object_id"] = object_id

    @builtins.property
    def subject_type(self) -> builtins.str:
        '''Type of users.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#subject_type AccessPackageAssignmentPolicy#subject_type}
        '''
        result = self._values.get("subject_type")
        assert result is not None, "Required property 'subject_type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def backup(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''For a user in an approval stage, this property indicates whether the user is a backup fallback approver.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#backup AccessPackageAssignmentPolicy#backup}
        '''
        result = self._values.get("backup")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def object_id(self) -> typing.Optional[builtins.str]:
        '''The object ID of the subject.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#object_id AccessPackageAssignmentPolicy#object_id}
        '''
        result = self._values.get("object_id")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApproverList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApproverList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e8484497f4324a2f34f87554a477d402e8acfc1fb67fb2526bef62879d50647c)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApproverOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8e9feb436249c0eb517749d0bc0964e13268c6b15a35e27ebfa79e82a259d1dd)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApproverOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fc126ca52a032d9bccbe2ba2d1cf4a6e395f15b3bfd7009fe26b9a1c436ed61d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7eb36bfed8d2a7e86e772774602187db6a6af27a099330b88fe5b93a92a42c77)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d35ff054d9677226cd913b1f94188c4d09494fea429b702540cf958cd19b714a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2e356d54a1086ee74aaa2245899e178cc33f0b6014413422ff585b163bb5ce00)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApproverOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApproverOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c20915024caa37e4171b1405ea7efcc397d052fca874105a9d32ca0f5d18ed89)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetBackup")
    def reset_backup(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBackup", []))

    @jsii.member(jsii_name="resetObjectId")
    def reset_object_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetObjectId", []))

    @builtins.property
    @jsii.member(jsii_name="backupInput")
    def backup_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "backupInput"))

    @builtins.property
    @jsii.member(jsii_name="objectIdInput")
    def object_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "objectIdInput"))

    @builtins.property
    @jsii.member(jsii_name="subjectTypeInput")
    def subject_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "subjectTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="backup")
    def backup(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "backup"))

    @backup.setter
    def backup(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1ac06d959a9c11a8078243603192aa9bbb14312247bea57233acb2c97f274cd3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "backup", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="objectId")
    def object_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "objectId"))

    @object_id.setter
    def object_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1bfc63ff9c5c50e7c1abe477a2d3e46dc70f8b669a0c9a56b7cb6f296bdc2f10)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "objectId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="subjectType")
    def subject_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "subjectType"))

    @subject_type.setter
    def subject_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4ce3c8c6396931e2ca6f54647ed8494a5924ab63aea5d59b521c346ddd4def45)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "subjectType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0831b608a010d616c78b3947b8952376bad76c62b074c286a81fba3c9863c617)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class AccessPackageAssignmentPolicyApprovalSettingsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyApprovalSettingsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4dc68093c23851d125f54b055d1e254f21e12c4aef5eb15720d818d4db16f02e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putApprovalStage")
    def put_approval_stage(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyApprovalSettingsApprovalStage, typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__986d624411aa7df398f7b251fca648b590d6c219b6cfa69433731d91c825d87a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putApprovalStage", [value]))

    @jsii.member(jsii_name="resetApprovalRequired")
    def reset_approval_required(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetApprovalRequired", []))

    @jsii.member(jsii_name="resetApprovalRequiredForExtension")
    def reset_approval_required_for_extension(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetApprovalRequiredForExtension", []))

    @jsii.member(jsii_name="resetApprovalStage")
    def reset_approval_stage(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetApprovalStage", []))

    @jsii.member(jsii_name="resetRequestorJustificationRequired")
    def reset_requestor_justification_required(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequestorJustificationRequired", []))

    @builtins.property
    @jsii.member(jsii_name="approvalStage")
    def approval_stage(
        self,
    ) -> AccessPackageAssignmentPolicyApprovalSettingsApprovalStageList:
        return typing.cast(AccessPackageAssignmentPolicyApprovalSettingsApprovalStageList, jsii.get(self, "approvalStage"))

    @builtins.property
    @jsii.member(jsii_name="approvalRequiredForExtensionInput")
    def approval_required_for_extension_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "approvalRequiredForExtensionInput"))

    @builtins.property
    @jsii.member(jsii_name="approvalRequiredInput")
    def approval_required_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "approvalRequiredInput"))

    @builtins.property
    @jsii.member(jsii_name="approvalStageInput")
    def approval_stage_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyApprovalSettingsApprovalStage]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyApprovalSettingsApprovalStage]]], jsii.get(self, "approvalStageInput"))

    @builtins.property
    @jsii.member(jsii_name="requestorJustificationRequiredInput")
    def requestor_justification_required_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "requestorJustificationRequiredInput"))

    @builtins.property
    @jsii.member(jsii_name="approvalRequired")
    def approval_required(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "approvalRequired"))

    @approval_required.setter
    def approval_required(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__05a6b20fb66870044bc7ad5a02aea44123d9899be65d1c63bc181a04651b6da1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "approvalRequired", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="approvalRequiredForExtension")
    def approval_required_for_extension(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "approvalRequiredForExtension"))

    @approval_required_for_extension.setter
    def approval_required_for_extension(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a7fc0dbffcabd4f4c5484271001429dc6e53ef7c01c164bb11bfcfce2b783d09)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "approvalRequiredForExtension", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="requestorJustificationRequired")
    def requestor_justification_required(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "requestorJustificationRequired"))

    @requestor_justification_required.setter
    def requestor_justification_required(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__54f76d0bb8dba84c19d3561fde628aedd5a5774607806eb01c7618fff9ca4e47)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requestorJustificationRequired", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[AccessPackageAssignmentPolicyApprovalSettings]:
        return typing.cast(typing.Optional[AccessPackageAssignmentPolicyApprovalSettings], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[AccessPackageAssignmentPolicyApprovalSettings],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__986f750424643957506620b1630c376c1c2efa51260d977c7e37e572c3e2c49a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyAssignmentReviewSettings",
    jsii_struct_bases=[],
    name_mapping={
        "access_recommendation_enabled": "accessRecommendationEnabled",
        "access_review_timeout_behavior": "accessReviewTimeoutBehavior",
        "approver_justification_required": "approverJustificationRequired",
        "duration_in_days": "durationInDays",
        "enabled": "enabled",
        "reviewer": "reviewer",
        "review_frequency": "reviewFrequency",
        "review_type": "reviewType",
        "starting_on": "startingOn",
    },
)
class AccessPackageAssignmentPolicyAssignmentReviewSettings:
    def __init__(
        self,
        *,
        access_recommendation_enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        access_review_timeout_behavior: typing.Optional[builtins.str] = None,
        approver_justification_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        duration_in_days: typing.Optional[jsii.Number] = None,
        enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        reviewer: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer", typing.Dict[builtins.str, typing.Any]]]]] = None,
        review_frequency: typing.Optional[builtins.str] = None,
        review_type: typing.Optional[builtins.str] = None,
        starting_on: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param access_recommendation_enabled: Whether to show Show reviewer decision helpers. If enabled, system recommendations based on users' access information will be shown to the reviewers. The reviewer will be recommended to approve the review if the user has signed-in at least once during the last 30 days. The reviewer will be recommended to deny the review if the user has not signed-in during the last 30 days Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#access_recommendation_enabled AccessPackageAssignmentPolicy#access_recommendation_enabled}
        :param access_review_timeout_behavior: What actions the system takes if reviewers don't respond in time. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#access_review_timeout_behavior AccessPackageAssignmentPolicy#access_review_timeout_behavior}
        :param approver_justification_required: Whether a reviewer need provide a justification for their decision. Justification is visible to other reviewers and the requestor. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approver_justification_required AccessPackageAssignmentPolicy#approver_justification_required}
        :param duration_in_days: How many days each occurrence of the access review series will run. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#duration_in_days AccessPackageAssignmentPolicy#duration_in_days}
        :param enabled: Whether to enable assignment review. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#enabled AccessPackageAssignmentPolicy#enabled}
        :param reviewer: reviewer block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#reviewer AccessPackageAssignmentPolicy#reviewer}
        :param review_frequency: This will determine how often the access review campaign runs. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#review_frequency AccessPackageAssignmentPolicy#review_frequency}
        :param review_type: Self review or specific reviewers. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#review_type AccessPackageAssignmentPolicy#review_type}
        :param starting_on: This is the date the access review campaign will start on, formatted as an RFC3339 date string in UTC(e.g. 2018-01-01T01:02:03Z), default is now. Once an access review has been created, you cannot update its start date. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#starting_on AccessPackageAssignmentPolicy#starting_on}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9206a30173670372b3aef89e3a526ce87331b7c38615bedaa15389d04bb02f89)
            check_type(argname="argument access_recommendation_enabled", value=access_recommendation_enabled, expected_type=type_hints["access_recommendation_enabled"])
            check_type(argname="argument access_review_timeout_behavior", value=access_review_timeout_behavior, expected_type=type_hints["access_review_timeout_behavior"])
            check_type(argname="argument approver_justification_required", value=approver_justification_required, expected_type=type_hints["approver_justification_required"])
            check_type(argname="argument duration_in_days", value=duration_in_days, expected_type=type_hints["duration_in_days"])
            check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
            check_type(argname="argument reviewer", value=reviewer, expected_type=type_hints["reviewer"])
            check_type(argname="argument review_frequency", value=review_frequency, expected_type=type_hints["review_frequency"])
            check_type(argname="argument review_type", value=review_type, expected_type=type_hints["review_type"])
            check_type(argname="argument starting_on", value=starting_on, expected_type=type_hints["starting_on"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if access_recommendation_enabled is not None:
            self._values["access_recommendation_enabled"] = access_recommendation_enabled
        if access_review_timeout_behavior is not None:
            self._values["access_review_timeout_behavior"] = access_review_timeout_behavior
        if approver_justification_required is not None:
            self._values["approver_justification_required"] = approver_justification_required
        if duration_in_days is not None:
            self._values["duration_in_days"] = duration_in_days
        if enabled is not None:
            self._values["enabled"] = enabled
        if reviewer is not None:
            self._values["reviewer"] = reviewer
        if review_frequency is not None:
            self._values["review_frequency"] = review_frequency
        if review_type is not None:
            self._values["review_type"] = review_type
        if starting_on is not None:
            self._values["starting_on"] = starting_on

    @builtins.property
    def access_recommendation_enabled(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether to show Show reviewer decision helpers.

        If enabled, system recommendations based on users' access information will be shown to the reviewers. The reviewer will be recommended to approve the review if the user has signed-in at least once during the last 30 days. The reviewer will be recommended to deny the review if the user has not signed-in during the last 30 days

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#access_recommendation_enabled AccessPackageAssignmentPolicy#access_recommendation_enabled}
        '''
        result = self._values.get("access_recommendation_enabled")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def access_review_timeout_behavior(self) -> typing.Optional[builtins.str]:
        '''What actions the system takes if reviewers don't respond in time.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#access_review_timeout_behavior AccessPackageAssignmentPolicy#access_review_timeout_behavior}
        '''
        result = self._values.get("access_review_timeout_behavior")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def approver_justification_required(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether a reviewer need provide a justification for their decision. Justification is visible to other reviewers and the requestor.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approver_justification_required AccessPackageAssignmentPolicy#approver_justification_required}
        '''
        result = self._values.get("approver_justification_required")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def duration_in_days(self) -> typing.Optional[jsii.Number]:
        '''How many days each occurrence of the access review series will run.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#duration_in_days AccessPackageAssignmentPolicy#duration_in_days}
        '''
        result = self._values.get("duration_in_days")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def enabled(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether to enable assignment review.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#enabled AccessPackageAssignmentPolicy#enabled}
        '''
        result = self._values.get("enabled")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def reviewer(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer"]]]:
        '''reviewer block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#reviewer AccessPackageAssignmentPolicy#reviewer}
        '''
        result = self._values.get("reviewer")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer"]]], result)

    @builtins.property
    def review_frequency(self) -> typing.Optional[builtins.str]:
        '''This will determine how often the access review campaign runs.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#review_frequency AccessPackageAssignmentPolicy#review_frequency}
        '''
        result = self._values.get("review_frequency")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def review_type(self) -> typing.Optional[builtins.str]:
        '''Self review or specific reviewers.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#review_type AccessPackageAssignmentPolicy#review_type}
        '''
        result = self._values.get("review_type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def starting_on(self) -> typing.Optional[builtins.str]:
        '''This is the date the access review campaign will start on, formatted as an RFC3339 date string in UTC(e.g. 2018-01-01T01:02:03Z), default is now. Once an access review has been created, you cannot update its start date.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#starting_on AccessPackageAssignmentPolicy#starting_on}
        '''
        result = self._values.get("starting_on")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AccessPackageAssignmentPolicyAssignmentReviewSettings(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class AccessPackageAssignmentPolicyAssignmentReviewSettingsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyAssignmentReviewSettingsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7bb8e253ae0247e44a35f16f8abfba3537d4f502135e04d490974de37692e2ed)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putReviewer")
    def put_reviewer(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ff83deae0dac178980afc18860c27d126d76224e31022a321f37ff49fca733dd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putReviewer", [value]))

    @jsii.member(jsii_name="resetAccessRecommendationEnabled")
    def reset_access_recommendation_enabled(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAccessRecommendationEnabled", []))

    @jsii.member(jsii_name="resetAccessReviewTimeoutBehavior")
    def reset_access_review_timeout_behavior(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAccessReviewTimeoutBehavior", []))

    @jsii.member(jsii_name="resetApproverJustificationRequired")
    def reset_approver_justification_required(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetApproverJustificationRequired", []))

    @jsii.member(jsii_name="resetDurationInDays")
    def reset_duration_in_days(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDurationInDays", []))

    @jsii.member(jsii_name="resetEnabled")
    def reset_enabled(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEnabled", []))

    @jsii.member(jsii_name="resetReviewer")
    def reset_reviewer(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReviewer", []))

    @jsii.member(jsii_name="resetReviewFrequency")
    def reset_review_frequency(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReviewFrequency", []))

    @jsii.member(jsii_name="resetReviewType")
    def reset_review_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetReviewType", []))

    @jsii.member(jsii_name="resetStartingOn")
    def reset_starting_on(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStartingOn", []))

    @builtins.property
    @jsii.member(jsii_name="reviewer")
    def reviewer(
        self,
    ) -> "AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewerList":
        return typing.cast("AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewerList", jsii.get(self, "reviewer"))

    @builtins.property
    @jsii.member(jsii_name="accessRecommendationEnabledInput")
    def access_recommendation_enabled_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "accessRecommendationEnabledInput"))

    @builtins.property
    @jsii.member(jsii_name="accessReviewTimeoutBehaviorInput")
    def access_review_timeout_behavior_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "accessReviewTimeoutBehaviorInput"))

    @builtins.property
    @jsii.member(jsii_name="approverJustificationRequiredInput")
    def approver_justification_required_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "approverJustificationRequiredInput"))

    @builtins.property
    @jsii.member(jsii_name="durationInDaysInput")
    def duration_in_days_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "durationInDaysInput"))

    @builtins.property
    @jsii.member(jsii_name="enabledInput")
    def enabled_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "enabledInput"))

    @builtins.property
    @jsii.member(jsii_name="reviewerInput")
    def reviewer_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer"]]], jsii.get(self, "reviewerInput"))

    @builtins.property
    @jsii.member(jsii_name="reviewFrequencyInput")
    def review_frequency_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "reviewFrequencyInput"))

    @builtins.property
    @jsii.member(jsii_name="reviewTypeInput")
    def review_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "reviewTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="startingOnInput")
    def starting_on_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "startingOnInput"))

    @builtins.property
    @jsii.member(jsii_name="accessRecommendationEnabled")
    def access_recommendation_enabled(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "accessRecommendationEnabled"))

    @access_recommendation_enabled.setter
    def access_recommendation_enabled(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0325206b62b7cabd2e4002c19a5d38b32d36499c2f4fa54d3408b1eda9394caa)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "accessRecommendationEnabled", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="accessReviewTimeoutBehavior")
    def access_review_timeout_behavior(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "accessReviewTimeoutBehavior"))

    @access_review_timeout_behavior.setter
    def access_review_timeout_behavior(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__71e275d612ce56089ada112d66891ce3bc8bf0a644794b214509b1331e1f9dd9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "accessReviewTimeoutBehavior", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="approverJustificationRequired")
    def approver_justification_required(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "approverJustificationRequired"))

    @approver_justification_required.setter
    def approver_justification_required(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1e3541a02e0b8050f92a517900ee9879b20aa4b36d3adc5787245001f85cd38b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "approverJustificationRequired", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="durationInDays")
    def duration_in_days(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "durationInDays"))

    @duration_in_days.setter
    def duration_in_days(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__733900417c95ec076df316a368c98f9ef939ff5355becec441971fd1f34a39ee)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "durationInDays", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enabled")
    def enabled(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "enabled"))

    @enabled.setter
    def enabled(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__35bfb7f51db50e5212065fbdcdd435fcc9393834d63fc880d7d9577a466987c2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enabled", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="reviewFrequency")
    def review_frequency(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "reviewFrequency"))

    @review_frequency.setter
    def review_frequency(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e4ffbe38c429a2da5e5a19dcb0c12efcda0c3c872b41ad84f20931fe2992b9a4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "reviewFrequency", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="reviewType")
    def review_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "reviewType"))

    @review_type.setter
    def review_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c8a771a47f4d0e71a3f6c30d0df691b242ad46f21d1b722ef20cdc20be176801)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "reviewType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="startingOn")
    def starting_on(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "startingOn"))

    @starting_on.setter
    def starting_on(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a9e65b3fb99ee75d3e74d8e71121d8e0c884ec7d2d1cd49992d89cdd84f93002)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "startingOn", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[AccessPackageAssignmentPolicyAssignmentReviewSettings]:
        return typing.cast(typing.Optional[AccessPackageAssignmentPolicyAssignmentReviewSettings], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[AccessPackageAssignmentPolicyAssignmentReviewSettings],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4018c0dfa31fd761d6f66c4ec7378c1d9a607ed51b756afc6c3b54118ab39623)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer",
    jsii_struct_bases=[],
    name_mapping={
        "subject_type": "subjectType",
        "backup": "backup",
        "object_id": "objectId",
    },
)
class AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer:
    def __init__(
        self,
        *,
        subject_type: builtins.str,
        backup: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        object_id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param subject_type: Type of users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#subject_type AccessPackageAssignmentPolicy#subject_type}
        :param backup: For a user in an approval stage, this property indicates whether the user is a backup fallback approver. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#backup AccessPackageAssignmentPolicy#backup}
        :param object_id: The object ID of the subject. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#object_id AccessPackageAssignmentPolicy#object_id}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__64958ba19a932c265750ea0cb6523e66973aa9fca2ed7a427b2a7d6a7665654b)
            check_type(argname="argument subject_type", value=subject_type, expected_type=type_hints["subject_type"])
            check_type(argname="argument backup", value=backup, expected_type=type_hints["backup"])
            check_type(argname="argument object_id", value=object_id, expected_type=type_hints["object_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "subject_type": subject_type,
        }
        if backup is not None:
            self._values["backup"] = backup
        if object_id is not None:
            self._values["object_id"] = object_id

    @builtins.property
    def subject_type(self) -> builtins.str:
        '''Type of users.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#subject_type AccessPackageAssignmentPolicy#subject_type}
        '''
        result = self._values.get("subject_type")
        assert result is not None, "Required property 'subject_type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def backup(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''For a user in an approval stage, this property indicates whether the user is a backup fallback approver.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#backup AccessPackageAssignmentPolicy#backup}
        '''
        result = self._values.get("backup")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def object_id(self) -> typing.Optional[builtins.str]:
        '''The object ID of the subject.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#object_id AccessPackageAssignmentPolicy#object_id}
        '''
        result = self._values.get("object_id")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewerList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewerList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__33a7ce625e2b99c4abd6b61f16cb6844fc6bb327665b02b05e994a4bdac9690d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewerOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__97e17f9a4b2361bcf2d62d4d324a3ccaa7a8038509f85a16f0d00d162df3c899)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewerOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c422eab35d1bfb5d46ce2bef26b29dc8e4f4d2ade5bad21b89ac4509a21c2339)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aca382110f606e82315a22a1dbdb1a58d085f7db7bf2b5d377b6a7b0ec7bc40a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4bf9738f5b3f8f4445362b677de4fd4eca6b7995e85235b26b21f28f0d216efb)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__54256e1c3e678a04e80f468071627cda15afabeaabbbd2fe8056c3e41161a031)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewerOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewerOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0bbdf2cb8b7101a5fc46fbbbe7113f6790f290192ca6a54e0ed3ab6e62efdbc0)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetBackup")
    def reset_backup(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBackup", []))

    @jsii.member(jsii_name="resetObjectId")
    def reset_object_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetObjectId", []))

    @builtins.property
    @jsii.member(jsii_name="backupInput")
    def backup_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "backupInput"))

    @builtins.property
    @jsii.member(jsii_name="objectIdInput")
    def object_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "objectIdInput"))

    @builtins.property
    @jsii.member(jsii_name="subjectTypeInput")
    def subject_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "subjectTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="backup")
    def backup(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "backup"))

    @backup.setter
    def backup(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bc08cf6b6dadce141962cae21a0433c14a44aa33226b7b1b3e2e8d019da1c13d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "backup", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="objectId")
    def object_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "objectId"))

    @object_id.setter
    def object_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__20b098703d4e271085468578593238fcf60558ae350e6f27318b3148da9e4b47)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "objectId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="subjectType")
    def subject_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "subjectType"))

    @subject_type.setter
    def subject_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6de55d1c94d27be8863e74cdf03920027f9f4b5dd0716719a9c8fe931f75b181)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "subjectType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__835b1ee4dc5b9dee0108b7b893f1048c92fcedf33fef11dea7df7f991dd3a765)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "access_package_id": "accessPackageId",
        "description": "description",
        "display_name": "displayName",
        "approval_settings": "approvalSettings",
        "assignment_review_settings": "assignmentReviewSettings",
        "duration_in_days": "durationInDays",
        "expiration_date": "expirationDate",
        "extension_enabled": "extensionEnabled",
        "id": "id",
        "question": "question",
        "requestor_settings": "requestorSettings",
        "timeouts": "timeouts",
    },
)
class AccessPackageAssignmentPolicyConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        access_package_id: builtins.str,
        description: builtins.str,
        display_name: builtins.str,
        approval_settings: typing.Optional[typing.Union[AccessPackageAssignmentPolicyApprovalSettings, typing.Dict[builtins.str, typing.Any]]] = None,
        assignment_review_settings: typing.Optional[typing.Union[AccessPackageAssignmentPolicyAssignmentReviewSettings, typing.Dict[builtins.str, typing.Any]]] = None,
        duration_in_days: typing.Optional[jsii.Number] = None,
        expiration_date: typing.Optional[builtins.str] = None,
        extension_enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        id: typing.Optional[builtins.str] = None,
        question: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyQuestion", typing.Dict[builtins.str, typing.Any]]]]] = None,
        requestor_settings: typing.Optional[typing.Union["AccessPackageAssignmentPolicyRequestorSettings", typing.Dict[builtins.str, typing.Any]]] = None,
        timeouts: typing.Optional[typing.Union["AccessPackageAssignmentPolicyTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param access_package_id: The ID of the access package that will contain the policy. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#access_package_id AccessPackageAssignmentPolicy#access_package_id}
        :param description: The description of the policy. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#description AccessPackageAssignmentPolicy#description}
        :param display_name: The display name of the policy. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#display_name AccessPackageAssignmentPolicy#display_name}
        :param approval_settings: approval_settings block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approval_settings AccessPackageAssignmentPolicy#approval_settings}
        :param assignment_review_settings: assignment_review_settings block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#assignment_review_settings AccessPackageAssignmentPolicy#assignment_review_settings}
        :param duration_in_days: How many days this assignment is valid for. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#duration_in_days AccessPackageAssignmentPolicy#duration_in_days}
        :param expiration_date: The date that this assignment expires, formatted as an RFC3339 date string in UTC (e.g. 2018-01-01T01:02:03Z). Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#expiration_date AccessPackageAssignmentPolicy#expiration_date}
        :param extension_enabled: When enabled, users will be able to request extension of their access to this package before their access expires. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#extension_enabled AccessPackageAssignmentPolicy#extension_enabled}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#id AccessPackageAssignmentPolicy#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param question: question block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#question AccessPackageAssignmentPolicy#question}
        :param requestor_settings: requestor_settings block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#requestor_settings AccessPackageAssignmentPolicy#requestor_settings}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#timeouts AccessPackageAssignmentPolicy#timeouts}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(approval_settings, dict):
            approval_settings = AccessPackageAssignmentPolicyApprovalSettings(**approval_settings)
        if isinstance(assignment_review_settings, dict):
            assignment_review_settings = AccessPackageAssignmentPolicyAssignmentReviewSettings(**assignment_review_settings)
        if isinstance(requestor_settings, dict):
            requestor_settings = AccessPackageAssignmentPolicyRequestorSettings(**requestor_settings)
        if isinstance(timeouts, dict):
            timeouts = AccessPackageAssignmentPolicyTimeouts(**timeouts)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d09a6cc732fc319ce159256fefac84b064b372ff8b06b5f074231bd48fba461a)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument access_package_id", value=access_package_id, expected_type=type_hints["access_package_id"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument display_name", value=display_name, expected_type=type_hints["display_name"])
            check_type(argname="argument approval_settings", value=approval_settings, expected_type=type_hints["approval_settings"])
            check_type(argname="argument assignment_review_settings", value=assignment_review_settings, expected_type=type_hints["assignment_review_settings"])
            check_type(argname="argument duration_in_days", value=duration_in_days, expected_type=type_hints["duration_in_days"])
            check_type(argname="argument expiration_date", value=expiration_date, expected_type=type_hints["expiration_date"])
            check_type(argname="argument extension_enabled", value=extension_enabled, expected_type=type_hints["extension_enabled"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument question", value=question, expected_type=type_hints["question"])
            check_type(argname="argument requestor_settings", value=requestor_settings, expected_type=type_hints["requestor_settings"])
            check_type(argname="argument timeouts", value=timeouts, expected_type=type_hints["timeouts"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "access_package_id": access_package_id,
            "description": description,
            "display_name": display_name,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if approval_settings is not None:
            self._values["approval_settings"] = approval_settings
        if assignment_review_settings is not None:
            self._values["assignment_review_settings"] = assignment_review_settings
        if duration_in_days is not None:
            self._values["duration_in_days"] = duration_in_days
        if expiration_date is not None:
            self._values["expiration_date"] = expiration_date
        if extension_enabled is not None:
            self._values["extension_enabled"] = extension_enabled
        if id is not None:
            self._values["id"] = id
        if question is not None:
            self._values["question"] = question
        if requestor_settings is not None:
            self._values["requestor_settings"] = requestor_settings
        if timeouts is not None:
            self._values["timeouts"] = timeouts

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktn_78ede62e.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktn_78ede62e.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktn_78ede62e.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]], result)

    @builtins.property
    def access_package_id(self) -> builtins.str:
        '''The ID of the access package that will contain the policy.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#access_package_id AccessPackageAssignmentPolicy#access_package_id}
        '''
        result = self._values.get("access_package_id")
        assert result is not None, "Required property 'access_package_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def description(self) -> builtins.str:
        '''The description of the policy.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#description AccessPackageAssignmentPolicy#description}
        '''
        result = self._values.get("description")
        assert result is not None, "Required property 'description' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def display_name(self) -> builtins.str:
        '''The display name of the policy.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#display_name AccessPackageAssignmentPolicy#display_name}
        '''
        result = self._values.get("display_name")
        assert result is not None, "Required property 'display_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def approval_settings(
        self,
    ) -> typing.Optional[AccessPackageAssignmentPolicyApprovalSettings]:
        '''approval_settings block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#approval_settings AccessPackageAssignmentPolicy#approval_settings}
        '''
        result = self._values.get("approval_settings")
        return typing.cast(typing.Optional[AccessPackageAssignmentPolicyApprovalSettings], result)

    @builtins.property
    def assignment_review_settings(
        self,
    ) -> typing.Optional[AccessPackageAssignmentPolicyAssignmentReviewSettings]:
        '''assignment_review_settings block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#assignment_review_settings AccessPackageAssignmentPolicy#assignment_review_settings}
        '''
        result = self._values.get("assignment_review_settings")
        return typing.cast(typing.Optional[AccessPackageAssignmentPolicyAssignmentReviewSettings], result)

    @builtins.property
    def duration_in_days(self) -> typing.Optional[jsii.Number]:
        '''How many days this assignment is valid for.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#duration_in_days AccessPackageAssignmentPolicy#duration_in_days}
        '''
        result = self._values.get("duration_in_days")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def expiration_date(self) -> typing.Optional[builtins.str]:
        '''The date that this assignment expires, formatted as an RFC3339 date string in UTC (e.g. 2018-01-01T01:02:03Z).

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#expiration_date AccessPackageAssignmentPolicy#expiration_date}
        '''
        result = self._values.get("expiration_date")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def extension_enabled(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''When enabled, users will be able to request extension of their access to this package before their access expires.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#extension_enabled AccessPackageAssignmentPolicy#extension_enabled}
        '''
        result = self._values.get("extension_enabled")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#id AccessPackageAssignmentPolicy#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def question(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyQuestion"]]]:
        '''question block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#question AccessPackageAssignmentPolicy#question}
        '''
        result = self._values.get("question")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyQuestion"]]], result)

    @builtins.property
    def requestor_settings(
        self,
    ) -> typing.Optional["AccessPackageAssignmentPolicyRequestorSettings"]:
        '''requestor_settings block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#requestor_settings AccessPackageAssignmentPolicy#requestor_settings}
        '''
        result = self._values.get("requestor_settings")
        return typing.cast(typing.Optional["AccessPackageAssignmentPolicyRequestorSettings"], result)

    @builtins.property
    def timeouts(self) -> typing.Optional["AccessPackageAssignmentPolicyTimeouts"]:
        '''timeouts block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#timeouts AccessPackageAssignmentPolicy#timeouts}
        '''
        result = self._values.get("timeouts")
        return typing.cast(typing.Optional["AccessPackageAssignmentPolicyTimeouts"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AccessPackageAssignmentPolicyConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyQuestion",
    jsii_struct_bases=[],
    name_mapping={
        "text": "text",
        "choice": "choice",
        "required": "required",
        "sequence": "sequence",
    },
)
class AccessPackageAssignmentPolicyQuestion:
    def __init__(
        self,
        *,
        text: typing.Union["AccessPackageAssignmentPolicyQuestionText", typing.Dict[builtins.str, typing.Any]],
        choice: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyQuestionChoice", typing.Dict[builtins.str, typing.Any]]]]] = None,
        required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        sequence: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''
        :param text: text block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#text AccessPackageAssignmentPolicy#text}
        :param choice: choice block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#choice AccessPackageAssignmentPolicy#choice}
        :param required: Whether this question is required. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#required AccessPackageAssignmentPolicy#required}
        :param sequence: The sequence number of this question. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#sequence AccessPackageAssignmentPolicy#sequence}
        '''
        if isinstance(text, dict):
            text = AccessPackageAssignmentPolicyQuestionText(**text)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__586b386a0e1f76b825092fd8982f1eed36be0514f5a487b777f31beb24833dfd)
            check_type(argname="argument text", value=text, expected_type=type_hints["text"])
            check_type(argname="argument choice", value=choice, expected_type=type_hints["choice"])
            check_type(argname="argument required", value=required, expected_type=type_hints["required"])
            check_type(argname="argument sequence", value=sequence, expected_type=type_hints["sequence"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "text": text,
        }
        if choice is not None:
            self._values["choice"] = choice
        if required is not None:
            self._values["required"] = required
        if sequence is not None:
            self._values["sequence"] = sequence

    @builtins.property
    def text(self) -> "AccessPackageAssignmentPolicyQuestionText":
        '''text block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#text AccessPackageAssignmentPolicy#text}
        '''
        result = self._values.get("text")
        assert result is not None, "Required property 'text' is missing"
        return typing.cast("AccessPackageAssignmentPolicyQuestionText", result)

    @builtins.property
    def choice(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyQuestionChoice"]]]:
        '''choice block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#choice AccessPackageAssignmentPolicy#choice}
        '''
        result = self._values.get("choice")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyQuestionChoice"]]], result)

    @builtins.property
    def required(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether this question is required.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#required AccessPackageAssignmentPolicy#required}
        '''
        result = self._values.get("required")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def sequence(self) -> typing.Optional[jsii.Number]:
        '''The sequence number of this question.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#sequence AccessPackageAssignmentPolicy#sequence}
        '''
        result = self._values.get("sequence")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AccessPackageAssignmentPolicyQuestion(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyQuestionChoice",
    jsii_struct_bases=[],
    name_mapping={"actual_value": "actualValue", "display_value": "displayValue"},
)
class AccessPackageAssignmentPolicyQuestionChoice:
    def __init__(
        self,
        *,
        actual_value: builtins.str,
        display_value: typing.Union["AccessPackageAssignmentPolicyQuestionChoiceDisplayValue", typing.Dict[builtins.str, typing.Any]],
    ) -> None:
        '''
        :param actual_value: The actual value of this choice. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#actual_value AccessPackageAssignmentPolicy#actual_value}
        :param display_value: display_value block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#display_value AccessPackageAssignmentPolicy#display_value}
        '''
        if isinstance(display_value, dict):
            display_value = AccessPackageAssignmentPolicyQuestionChoiceDisplayValue(**display_value)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__25e9b1939804eb9f32f72504bfe0333255fcc598a24dbe64ecd82519d4ba3406)
            check_type(argname="argument actual_value", value=actual_value, expected_type=type_hints["actual_value"])
            check_type(argname="argument display_value", value=display_value, expected_type=type_hints["display_value"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "actual_value": actual_value,
            "display_value": display_value,
        }

    @builtins.property
    def actual_value(self) -> builtins.str:
        '''The actual value of this choice.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#actual_value AccessPackageAssignmentPolicy#actual_value}
        '''
        result = self._values.get("actual_value")
        assert result is not None, "Required property 'actual_value' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def display_value(
        self,
    ) -> "AccessPackageAssignmentPolicyQuestionChoiceDisplayValue":
        '''display_value block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#display_value AccessPackageAssignmentPolicy#display_value}
        '''
        result = self._values.get("display_value")
        assert result is not None, "Required property 'display_value' is missing"
        return typing.cast("AccessPackageAssignmentPolicyQuestionChoiceDisplayValue", result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AccessPackageAssignmentPolicyQuestionChoice(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyQuestionChoiceDisplayValue",
    jsii_struct_bases=[],
    name_mapping={"default_text": "defaultText", "localized_text": "localizedText"},
)
class AccessPackageAssignmentPolicyQuestionChoiceDisplayValue:
    def __init__(
        self,
        *,
        default_text: builtins.str,
        localized_text: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''
        :param default_text: The default text of this question. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#default_text AccessPackageAssignmentPolicy#default_text}
        :param localized_text: localized_text block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#localized_text AccessPackageAssignmentPolicy#localized_text}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__16ba8d047c20587bc5858151189fad466a3ee419284fa36128227366d57e5cbf)
            check_type(argname="argument default_text", value=default_text, expected_type=type_hints["default_text"])
            check_type(argname="argument localized_text", value=localized_text, expected_type=type_hints["localized_text"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "default_text": default_text,
        }
        if localized_text is not None:
            self._values["localized_text"] = localized_text

    @builtins.property
    def default_text(self) -> builtins.str:
        '''The default text of this question.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#default_text AccessPackageAssignmentPolicy#default_text}
        '''
        result = self._values.get("default_text")
        assert result is not None, "Required property 'default_text' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def localized_text(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText"]]]:
        '''localized_text block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#localized_text AccessPackageAssignmentPolicy#localized_text}
        '''
        result = self._values.get("localized_text")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText"]]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AccessPackageAssignmentPolicyQuestionChoiceDisplayValue(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText",
    jsii_struct_bases=[],
    name_mapping={"content": "content", "language_code": "languageCode"},
)
class AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText:
    def __init__(self, *, content: builtins.str, language_code: builtins.str) -> None:
        '''
        :param content: The localized content of this question. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#content AccessPackageAssignmentPolicy#content}
        :param language_code: The language code of this question content. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#language_code AccessPackageAssignmentPolicy#language_code}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__897fa6d46649d48358ac10a698b3a3e3f1bff403ef523afdfb9696fdb4ba87ae)
            check_type(argname="argument content", value=content, expected_type=type_hints["content"])
            check_type(argname="argument language_code", value=language_code, expected_type=type_hints["language_code"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "content": content,
            "language_code": language_code,
        }

    @builtins.property
    def content(self) -> builtins.str:
        '''The localized content of this question.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#content AccessPackageAssignmentPolicy#content}
        '''
        result = self._values.get("content")
        assert result is not None, "Required property 'content' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def language_code(self) -> builtins.str:
        '''The language code of this question content.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#language_code AccessPackageAssignmentPolicy#language_code}
        '''
        result = self._values.get("language_code")
        assert result is not None, "Required property 'language_code' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedTextList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedTextList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a625ec60840b5f58881292bdeda1504a6aad70f3ea3f9247d98f9f72f6ff6571)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedTextOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9f2985957f16fe7614b12d5eb464e7cb12947704a782b33104a4ff639851788b)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedTextOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a4053b8dcbe888a3d3d251c25746b170335fe8eb6bddbcfe4960e1d502be6da0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c2d6a70577ef5a24c8a7b9804182a5655b4e9ee87740437181d56db7cedcb4b3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f34041c13f0a6699837270b714cd6d44b9abdf2ddbd8ab124d85a2d360bfa1e6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d43e39a7efead5c93b2d9e226b4d60b9df4b6d399fb3b00b61dfe0ec197fbc4b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedTextOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedTextOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7ed2d61b1d00da4820aa8991b9f6575d7dc62e7497bb18de28c4e5c6a81b9ab0)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="contentInput")
    def content_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "contentInput"))

    @builtins.property
    @jsii.member(jsii_name="languageCodeInput")
    def language_code_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "languageCodeInput"))

    @builtins.property
    @jsii.member(jsii_name="content")
    def content(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "content"))

    @content.setter
    def content(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__edb589d30af33608752a9f1ea8d2445906802df7efbe4e27fa5a73078e7998b0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "content", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="languageCode")
    def language_code(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "languageCode"))

    @language_code.setter
    def language_code(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b37359690cd969f0a67acb0c72c490aa01b419ffe2c83fec9886d6010b47e528)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "languageCode", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2eb7b64de990f95d179f9b5d22655248f0cbafa06de455500522e56b2ec4ef4b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class AccessPackageAssignmentPolicyQuestionChoiceDisplayValueOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyQuestionChoiceDisplayValueOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__431b19c82cc7a8a58293ed66e6010cbe17878d227fc359f692c781bef4d3c752)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putLocalizedText")
    def put_localized_text(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText, typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8f1dff6aeeb0cbbdab0b94349c41fe067a1818a27b3a397ad02706bed7d9c9a0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putLocalizedText", [value]))

    @jsii.member(jsii_name="resetLocalizedText")
    def reset_localized_text(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetLocalizedText", []))

    @builtins.property
    @jsii.member(jsii_name="localizedText")
    def localized_text(
        self,
    ) -> AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedTextList:
        return typing.cast(AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedTextList, jsii.get(self, "localizedText"))

    @builtins.property
    @jsii.member(jsii_name="defaultTextInput")
    def default_text_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "defaultTextInput"))

    @builtins.property
    @jsii.member(jsii_name="localizedTextInput")
    def localized_text_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText]]], jsii.get(self, "localizedTextInput"))

    @builtins.property
    @jsii.member(jsii_name="defaultText")
    def default_text(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "defaultText"))

    @default_text.setter
    def default_text(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4420533d7cc21eaa187c922e61314705f934983cf3f49a3592faed5a4bea60ec)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "defaultText", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[AccessPackageAssignmentPolicyQuestionChoiceDisplayValue]:
        return typing.cast(typing.Optional[AccessPackageAssignmentPolicyQuestionChoiceDisplayValue], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[AccessPackageAssignmentPolicyQuestionChoiceDisplayValue],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__63eceb3e474299ba713f86ccf71cee79f8f25aefd1b742ffbe40832867307f2b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class AccessPackageAssignmentPolicyQuestionChoiceList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyQuestionChoiceList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__74a05ae6675a2dbb7429f74c81b6c660f7395ff2017f128fe8dd528550da858f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "AccessPackageAssignmentPolicyQuestionChoiceOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3df0a4e6f798263c2967ad389216bd20b1dd6bae38bcdd5fc8d3d027201dc4b6)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("AccessPackageAssignmentPolicyQuestionChoiceOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6168d34142a43d6a50a3dffb15170f83d88357fdf5eec3c3944ff1d09169b08e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__efd6756441624790d5ef6c1a1bb6c6b4e6d9d77a0e124f343c28f4e4076a4a3d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7bfd1e477d128e8b14deeb338b0aa8192b8093e6689b363226f8ee4a918495dd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionChoice]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionChoice]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionChoice]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d8dbdf3eb64d912eea753a53696b56eef8fb961fc10e64d45ac06cde7c88ba61)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class AccessPackageAssignmentPolicyQuestionChoiceOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyQuestionChoiceOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cc6bba23de218729d917fe95c8f1025b89099710834f576aa957a47032122cb8)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putDisplayValue")
    def put_display_value(
        self,
        *,
        default_text: builtins.str,
        localized_text: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''
        :param default_text: The default text of this question. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#default_text AccessPackageAssignmentPolicy#default_text}
        :param localized_text: localized_text block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#localized_text AccessPackageAssignmentPolicy#localized_text}
        '''
        value = AccessPackageAssignmentPolicyQuestionChoiceDisplayValue(
            default_text=default_text, localized_text=localized_text
        )

        return typing.cast(None, jsii.invoke(self, "putDisplayValue", [value]))

    @builtins.property
    @jsii.member(jsii_name="displayValue")
    def display_value(
        self,
    ) -> AccessPackageAssignmentPolicyQuestionChoiceDisplayValueOutputReference:
        return typing.cast(AccessPackageAssignmentPolicyQuestionChoiceDisplayValueOutputReference, jsii.get(self, "displayValue"))

    @builtins.property
    @jsii.member(jsii_name="actualValueInput")
    def actual_value_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "actualValueInput"))

    @builtins.property
    @jsii.member(jsii_name="displayValueInput")
    def display_value_input(
        self,
    ) -> typing.Optional[AccessPackageAssignmentPolicyQuestionChoiceDisplayValue]:
        return typing.cast(typing.Optional[AccessPackageAssignmentPolicyQuestionChoiceDisplayValue], jsii.get(self, "displayValueInput"))

    @builtins.property
    @jsii.member(jsii_name="actualValue")
    def actual_value(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "actualValue"))

    @actual_value.setter
    def actual_value(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e5060483c924ee4630505011e0c2a46f16fd28acc4ebbd233201f458862a3226)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "actualValue", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyQuestionChoice]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyQuestionChoice]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyQuestionChoice]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__05209d5ebcd9126a72d1aaaed6553ef4a013ccb5683399bfbecff96bba196fd6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class AccessPackageAssignmentPolicyQuestionList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyQuestionList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ccf87e095a5d575687717608ed4a1215b51a8d461c891983a63329443eac485a)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "AccessPackageAssignmentPolicyQuestionOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1962d9d3dd9156ab61e45291401ec26e074b0e718cfdaf30e671944deeedf19b)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("AccessPackageAssignmentPolicyQuestionOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8829bc870f5dd3b224443dead93b28dd05f7a5e4a4698fee04d2b5d6a692ba68)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__85bec212494ecc33c80e0be0953bd296fcf2b4aa66534bfcd60d6f1f99a2fda7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2c74c1f2e3144eb0fc8377a28dcf8b9f4f2e3c8efc3974e3e9b4c1343d29cf5c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestion]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestion]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestion]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4291228963cf0ad300ae16c8f22a6df1ee645733e1075f2d9cecc1dfd191bf92)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class AccessPackageAssignmentPolicyQuestionOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyQuestionOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__185efce734ff103d7d0733386210459a57c86f895d2696f5febd54e90f2a9c5d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="putChoice")
    def put_choice(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyQuestionChoice, typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__09a73fb859e4f55d15c16aba93a06f8ef84c26dceea47d92add58da2f56aa00f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putChoice", [value]))

    @jsii.member(jsii_name="putText")
    def put_text(
        self,
        *,
        default_text: builtins.str,
        localized_text: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyQuestionTextLocalizedText", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''
        :param default_text: The default text of this question. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#default_text AccessPackageAssignmentPolicy#default_text}
        :param localized_text: localized_text block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#localized_text AccessPackageAssignmentPolicy#localized_text}
        '''
        value = AccessPackageAssignmentPolicyQuestionText(
            default_text=default_text, localized_text=localized_text
        )

        return typing.cast(None, jsii.invoke(self, "putText", [value]))

    @jsii.member(jsii_name="resetChoice")
    def reset_choice(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetChoice", []))

    @jsii.member(jsii_name="resetRequired")
    def reset_required(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequired", []))

    @jsii.member(jsii_name="resetSequence")
    def reset_sequence(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSequence", []))

    @builtins.property
    @jsii.member(jsii_name="choice")
    def choice(self) -> AccessPackageAssignmentPolicyQuestionChoiceList:
        return typing.cast(AccessPackageAssignmentPolicyQuestionChoiceList, jsii.get(self, "choice"))

    @builtins.property
    @jsii.member(jsii_name="text")
    def text(self) -> "AccessPackageAssignmentPolicyQuestionTextOutputReference":
        return typing.cast("AccessPackageAssignmentPolicyQuestionTextOutputReference", jsii.get(self, "text"))

    @builtins.property
    @jsii.member(jsii_name="choiceInput")
    def choice_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionChoice]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionChoice]]], jsii.get(self, "choiceInput"))

    @builtins.property
    @jsii.member(jsii_name="requiredInput")
    def required_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "requiredInput"))

    @builtins.property
    @jsii.member(jsii_name="sequenceInput")
    def sequence_input(self) -> typing.Optional[jsii.Number]:
        return typing.cast(typing.Optional[jsii.Number], jsii.get(self, "sequenceInput"))

    @builtins.property
    @jsii.member(jsii_name="textInput")
    def text_input(
        self,
    ) -> typing.Optional["AccessPackageAssignmentPolicyQuestionText"]:
        return typing.cast(typing.Optional["AccessPackageAssignmentPolicyQuestionText"], jsii.get(self, "textInput"))

    @builtins.property
    @jsii.member(jsii_name="required")
    def required(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "required"))

    @required.setter
    def required(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__667db43057db148edfbc4c480061b07ee870a6985ca272045cd206b63610d133)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "required", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="sequence")
    def sequence(self) -> jsii.Number:
        return typing.cast(jsii.Number, jsii.get(self, "sequence"))

    @sequence.setter
    def sequence(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9240afba7d7dd9b298c13916fb73679cae632104f6a3e9dc053929966156604f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sequence", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyQuestion]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyQuestion]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyQuestion]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8fcf382fbbbb7ecca1cfed65f5d1471bd03fbec5079c5a6f4f393a65dd42b615)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyQuestionText",
    jsii_struct_bases=[],
    name_mapping={"default_text": "defaultText", "localized_text": "localizedText"},
)
class AccessPackageAssignmentPolicyQuestionText:
    def __init__(
        self,
        *,
        default_text: builtins.str,
        localized_text: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyQuestionTextLocalizedText", typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''
        :param default_text: The default text of this question. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#default_text AccessPackageAssignmentPolicy#default_text}
        :param localized_text: localized_text block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#localized_text AccessPackageAssignmentPolicy#localized_text}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7ebae4b01d5ec5f8df1c27e9e5848bf5fcf9568f34db57fc15fbae9354f63921)
            check_type(argname="argument default_text", value=default_text, expected_type=type_hints["default_text"])
            check_type(argname="argument localized_text", value=localized_text, expected_type=type_hints["localized_text"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "default_text": default_text,
        }
        if localized_text is not None:
            self._values["localized_text"] = localized_text

    @builtins.property
    def default_text(self) -> builtins.str:
        '''The default text of this question.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#default_text AccessPackageAssignmentPolicy#default_text}
        '''
        result = self._values.get("default_text")
        assert result is not None, "Required property 'default_text' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def localized_text(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyQuestionTextLocalizedText"]]]:
        '''localized_text block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#localized_text AccessPackageAssignmentPolicy#localized_text}
        '''
        result = self._values.get("localized_text")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyQuestionTextLocalizedText"]]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AccessPackageAssignmentPolicyQuestionText(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyQuestionTextLocalizedText",
    jsii_struct_bases=[],
    name_mapping={"content": "content", "language_code": "languageCode"},
)
class AccessPackageAssignmentPolicyQuestionTextLocalizedText:
    def __init__(self, *, content: builtins.str, language_code: builtins.str) -> None:
        '''
        :param content: The localized content of this question. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#content AccessPackageAssignmentPolicy#content}
        :param language_code: The language code of this question content. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#language_code AccessPackageAssignmentPolicy#language_code}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6a5c2565edf4896b6eb800908a6650fe473d65e722324d21117a85dbe1a259c9)
            check_type(argname="argument content", value=content, expected_type=type_hints["content"])
            check_type(argname="argument language_code", value=language_code, expected_type=type_hints["language_code"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "content": content,
            "language_code": language_code,
        }

    @builtins.property
    def content(self) -> builtins.str:
        '''The localized content of this question.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#content AccessPackageAssignmentPolicy#content}
        '''
        result = self._values.get("content")
        assert result is not None, "Required property 'content' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def language_code(self) -> builtins.str:
        '''The language code of this question content.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#language_code AccessPackageAssignmentPolicy#language_code}
        '''
        result = self._values.get("language_code")
        assert result is not None, "Required property 'language_code' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AccessPackageAssignmentPolicyQuestionTextLocalizedText(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class AccessPackageAssignmentPolicyQuestionTextLocalizedTextList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyQuestionTextLocalizedTextList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a2d98ce63c2e27ecb05021e7d6ab6377f959b46442320ed23890b1bdaee5b023)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "AccessPackageAssignmentPolicyQuestionTextLocalizedTextOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__56ede9b1b411e7e44050738663a02886ee21c08d4f52c50dc78b3e6972daef29)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("AccessPackageAssignmentPolicyQuestionTextLocalizedTextOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d7b5c0068c5d85123c98e008af91ed4da6b7d5c6ca768d792d77c403b1724f8e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6175ec58be5b79fc07f265bc27656d626249f0fed77b9ba426208b49c52f35cf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__26363038ddc3658d9589348f6a1ee2d1e39c0ea6fca648c4a8dae0ae0e84fd13)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionTextLocalizedText]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionTextLocalizedText]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionTextLocalizedText]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aedeecc4e4d3a82e07f99bbc10b3a74f251c155e7991835ef6900d00063bdbf8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class AccessPackageAssignmentPolicyQuestionTextLocalizedTextOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyQuestionTextLocalizedTextOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d1d1a374d7b08c6f4fdf65116dc4cdf7f758cc51483089df2129d190f7772a71)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="contentInput")
    def content_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "contentInput"))

    @builtins.property
    @jsii.member(jsii_name="languageCodeInput")
    def language_code_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "languageCodeInput"))

    @builtins.property
    @jsii.member(jsii_name="content")
    def content(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "content"))

    @content.setter
    def content(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4c5e6f42c73ae9c0da507219fb43fbcbd54f321a11537b5b71a6ffe86dbc66f7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "content", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="languageCode")
    def language_code(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "languageCode"))

    @language_code.setter
    def language_code(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__77ea57838415e166384a8f0e4d4734a9d6beaf00c6069e0f42170a01b0d1f8de)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "languageCode", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyQuestionTextLocalizedText]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyQuestionTextLocalizedText]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyQuestionTextLocalizedText]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e2aabf106009b38b3082258530ed9eb3341202978978e8aa7c99297b26c39a3b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class AccessPackageAssignmentPolicyQuestionTextOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyQuestionTextOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__104177e488e94771781c15722497a6903ead2b05f6a743efdea7f38063759aa7)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putLocalizedText")
    def put_localized_text(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyQuestionTextLocalizedText, typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bea58f08ff0594ded9fbcd40a60adcc1060f7df03206e9fa5e8af66673e90f90)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putLocalizedText", [value]))

    @jsii.member(jsii_name="resetLocalizedText")
    def reset_localized_text(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetLocalizedText", []))

    @builtins.property
    @jsii.member(jsii_name="localizedText")
    def localized_text(
        self,
    ) -> AccessPackageAssignmentPolicyQuestionTextLocalizedTextList:
        return typing.cast(AccessPackageAssignmentPolicyQuestionTextLocalizedTextList, jsii.get(self, "localizedText"))

    @builtins.property
    @jsii.member(jsii_name="defaultTextInput")
    def default_text_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "defaultTextInput"))

    @builtins.property
    @jsii.member(jsii_name="localizedTextInput")
    def localized_text_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionTextLocalizedText]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionTextLocalizedText]]], jsii.get(self, "localizedTextInput"))

    @builtins.property
    @jsii.member(jsii_name="defaultText")
    def default_text(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "defaultText"))

    @default_text.setter
    def default_text(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ae5cf02f731c3cbc237443e71660f1be9042e520f03165580ba7accac68bd295)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "defaultText", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[AccessPackageAssignmentPolicyQuestionText]:
        return typing.cast(typing.Optional[AccessPackageAssignmentPolicyQuestionText], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[AccessPackageAssignmentPolicyQuestionText],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__27f63f5b015889c66f0331e8858ee4b754af08afd44b3b22bdd28b1a4b0e824f)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyRequestorSettings",
    jsii_struct_bases=[],
    name_mapping={
        "requestor": "requestor",
        "requests_accepted": "requestsAccepted",
        "scope_type": "scopeType",
    },
)
class AccessPackageAssignmentPolicyRequestorSettings:
    def __init__(
        self,
        *,
        requestor: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyRequestorSettingsRequestor", typing.Dict[builtins.str, typing.Any]]]]] = None,
        requests_accepted: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        scope_type: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param requestor: requestor block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#requestor AccessPackageAssignmentPolicy#requestor}
        :param requests_accepted: Whether to accept requests now, when disabled, no new requests can be made using this policy. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#requests_accepted AccessPackageAssignmentPolicy#requests_accepted}
        :param scope_type: Specify the scopes of the requestors. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#scope_type AccessPackageAssignmentPolicy#scope_type}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__54d75ebc85cd950a25c4c47f5e489689592929f5a1b4d37636c7f523964b93fe)
            check_type(argname="argument requestor", value=requestor, expected_type=type_hints["requestor"])
            check_type(argname="argument requests_accepted", value=requests_accepted, expected_type=type_hints["requests_accepted"])
            check_type(argname="argument scope_type", value=scope_type, expected_type=type_hints["scope_type"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if requestor is not None:
            self._values["requestor"] = requestor
        if requests_accepted is not None:
            self._values["requests_accepted"] = requests_accepted
        if scope_type is not None:
            self._values["scope_type"] = scope_type

    @builtins.property
    def requestor(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyRequestorSettingsRequestor"]]]:
        '''requestor block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#requestor AccessPackageAssignmentPolicy#requestor}
        '''
        result = self._values.get("requestor")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyRequestorSettingsRequestor"]]], result)

    @builtins.property
    def requests_accepted(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether to accept requests now, when disabled, no new requests can be made using this policy.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#requests_accepted AccessPackageAssignmentPolicy#requests_accepted}
        '''
        result = self._values.get("requests_accepted")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def scope_type(self) -> typing.Optional[builtins.str]:
        '''Specify the scopes of the requestors.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#scope_type AccessPackageAssignmentPolicy#scope_type}
        '''
        result = self._values.get("scope_type")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AccessPackageAssignmentPolicyRequestorSettings(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class AccessPackageAssignmentPolicyRequestorSettingsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyRequestorSettingsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__54497a36408aabbe37603f65d947ec7b8f3abf9389e72f81e869048f6a3538d0)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putRequestor")
    def put_requestor(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["AccessPackageAssignmentPolicyRequestorSettingsRequestor", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1b63ea4657a228ab9b092ae5d8cbde9a0dab3bcb247b19e6227a27b65d13c3c7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putRequestor", [value]))

    @jsii.member(jsii_name="resetRequestor")
    def reset_requestor(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequestor", []))

    @jsii.member(jsii_name="resetRequestsAccepted")
    def reset_requests_accepted(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRequestsAccepted", []))

    @jsii.member(jsii_name="resetScopeType")
    def reset_scope_type(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetScopeType", []))

    @builtins.property
    @jsii.member(jsii_name="requestor")
    def requestor(
        self,
    ) -> "AccessPackageAssignmentPolicyRequestorSettingsRequestorList":
        return typing.cast("AccessPackageAssignmentPolicyRequestorSettingsRequestorList", jsii.get(self, "requestor"))

    @builtins.property
    @jsii.member(jsii_name="requestorInput")
    def requestor_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyRequestorSettingsRequestor"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["AccessPackageAssignmentPolicyRequestorSettingsRequestor"]]], jsii.get(self, "requestorInput"))

    @builtins.property
    @jsii.member(jsii_name="requestsAcceptedInput")
    def requests_accepted_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "requestsAcceptedInput"))

    @builtins.property
    @jsii.member(jsii_name="scopeTypeInput")
    def scope_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "scopeTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="requestsAccepted")
    def requests_accepted(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "requestsAccepted"))

    @requests_accepted.setter
    def requests_accepted(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eedb49d24b7b6b4f25dbd5ff382ef4b951084cfa43661ae6dbf5f548e8af0b82)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "requestsAccepted", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="scopeType")
    def scope_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "scopeType"))

    @scope_type.setter
    def scope_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ebbec9622c91b3da66b3fc1c00cbf590a35888e72de86a04ecd1733e876e82ce)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "scopeType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[AccessPackageAssignmentPolicyRequestorSettings]:
        return typing.cast(typing.Optional[AccessPackageAssignmentPolicyRequestorSettings], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[AccessPackageAssignmentPolicyRequestorSettings],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__934ab3c86567debe72921c4cf6f470a5329f05221b32b6202c1658d79ecfaee4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyRequestorSettingsRequestor",
    jsii_struct_bases=[],
    name_mapping={
        "subject_type": "subjectType",
        "backup": "backup",
        "object_id": "objectId",
    },
)
class AccessPackageAssignmentPolicyRequestorSettingsRequestor:
    def __init__(
        self,
        *,
        subject_type: builtins.str,
        backup: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        object_id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param subject_type: Type of users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#subject_type AccessPackageAssignmentPolicy#subject_type}
        :param backup: For a user in an approval stage, this property indicates whether the user is a backup fallback approver. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#backup AccessPackageAssignmentPolicy#backup}
        :param object_id: The object ID of the subject. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#object_id AccessPackageAssignmentPolicy#object_id}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__59d0973397873a8868a4ab5150427a2aaa139310df4a007458e5604b1276f9bf)
            check_type(argname="argument subject_type", value=subject_type, expected_type=type_hints["subject_type"])
            check_type(argname="argument backup", value=backup, expected_type=type_hints["backup"])
            check_type(argname="argument object_id", value=object_id, expected_type=type_hints["object_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "subject_type": subject_type,
        }
        if backup is not None:
            self._values["backup"] = backup
        if object_id is not None:
            self._values["object_id"] = object_id

    @builtins.property
    def subject_type(self) -> builtins.str:
        '''Type of users.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#subject_type AccessPackageAssignmentPolicy#subject_type}
        '''
        result = self._values.get("subject_type")
        assert result is not None, "Required property 'subject_type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def backup(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''For a user in an approval stage, this property indicates whether the user is a backup fallback approver.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#backup AccessPackageAssignmentPolicy#backup}
        '''
        result = self._values.get("backup")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def object_id(self) -> typing.Optional[builtins.str]:
        '''The object ID of the subject.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#object_id AccessPackageAssignmentPolicy#object_id}
        '''
        result = self._values.get("object_id")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AccessPackageAssignmentPolicyRequestorSettingsRequestor(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class AccessPackageAssignmentPolicyRequestorSettingsRequestorList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyRequestorSettingsRequestorList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0a4a2b554dd57d28c89fe02e47056406e24f8b519251d2cfa239e98137535e6b)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "AccessPackageAssignmentPolicyRequestorSettingsRequestorOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__11106a16b8c7c1198e10672eb4fde94b24682aa4bf301947c7c2ffad5890da5b)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("AccessPackageAssignmentPolicyRequestorSettingsRequestorOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__674acb49559e407e1e5503d97a9ebffabeef77bd3d189b296e22727776c10b61)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__72d5359e5b71fde5c4170f75aa22b6dc3a112e82fcd5c54010605a21dc709cd2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__94c9b8bdb928acee898565189767f1a560e9a2735e31bb1793bbcac86de8fe85)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyRequestorSettingsRequestor]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyRequestorSettingsRequestor]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyRequestorSettingsRequestor]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8d0db1e71c1273694de85dba6c9f28b5beceb7e376c19e8b402f3901bdfbbdac)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class AccessPackageAssignmentPolicyRequestorSettingsRequestorOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyRequestorSettingsRequestorOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__22bd6d42e8248c0262b579c5764bb45bd6e9e4d24e09754fa70028653a8f84db)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetBackup")
    def reset_backup(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetBackup", []))

    @jsii.member(jsii_name="resetObjectId")
    def reset_object_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetObjectId", []))

    @builtins.property
    @jsii.member(jsii_name="backupInput")
    def backup_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "backupInput"))

    @builtins.property
    @jsii.member(jsii_name="objectIdInput")
    def object_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "objectIdInput"))

    @builtins.property
    @jsii.member(jsii_name="subjectTypeInput")
    def subject_type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "subjectTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="backup")
    def backup(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "backup"))

    @backup.setter
    def backup(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1dfdeca80159af2b4f269c64f6da9b358869a25d71d3afb1034424048543a5c0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "backup", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="objectId")
    def object_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "objectId"))

    @object_id.setter
    def object_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b879634e6a4ba17aba89ad1eb0b810b77debdb290ac123c75df08afecf6f550a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "objectId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="subjectType")
    def subject_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "subjectType"))

    @subject_type.setter
    def subject_type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6cfa5cae5e9efebef757527b057a20fa7a62a6446d21dd74ffe2d841782179fa)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "subjectType", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyRequestorSettingsRequestor]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyRequestorSettingsRequestor]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyRequestorSettingsRequestor]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d03afee9929ba0fd00746cc2fea4b674e57eaa774a0f9ae157a85b79ffbd519b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyTimeouts",
    jsii_struct_bases=[],
    name_mapping={
        "create": "create",
        "delete": "delete",
        "read": "read",
        "update": "update",
    },
)
class AccessPackageAssignmentPolicyTimeouts:
    def __init__(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#create AccessPackageAssignmentPolicy#create}.
        :param delete: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#delete AccessPackageAssignmentPolicy#delete}.
        :param read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#read AccessPackageAssignmentPolicy#read}.
        :param update: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#update AccessPackageAssignmentPolicy#update}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__04d9119e79250508136777f74dae38b2354da381646a10538ad60be07364e0c6)
            check_type(argname="argument create", value=create, expected_type=type_hints["create"])
            check_type(argname="argument delete", value=delete, expected_type=type_hints["delete"])
            check_type(argname="argument read", value=read, expected_type=type_hints["read"])
            check_type(argname="argument update", value=update, expected_type=type_hints["update"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if create is not None:
            self._values["create"] = create
        if delete is not None:
            self._values["delete"] = delete
        if read is not None:
            self._values["read"] = read
        if update is not None:
            self._values["update"] = update

    @builtins.property
    def create(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#create AccessPackageAssignmentPolicy#create}.'''
        result = self._values.get("create")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def delete(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#delete AccessPackageAssignmentPolicy#delete}.'''
        result = self._values.get("delete")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def read(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#read AccessPackageAssignmentPolicy#read}.'''
        result = self._values.get("read")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def update(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_assignment_policy#update AccessPackageAssignmentPolicy#update}.'''
        result = self._values.get("update")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AccessPackageAssignmentPolicyTimeouts(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class AccessPackageAssignmentPolicyTimeoutsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.accessPackageAssignmentPolicy.AccessPackageAssignmentPolicyTimeoutsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9c4eab44329f7d2788563f585dafe02ca2acacc158799d9837ca010b8372f753)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCreate")
    def reset_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreate", []))

    @jsii.member(jsii_name="resetDelete")
    def reset_delete(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDelete", []))

    @jsii.member(jsii_name="resetRead")
    def reset_read(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRead", []))

    @jsii.member(jsii_name="resetUpdate")
    def reset_update(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdate", []))

    @builtins.property
    @jsii.member(jsii_name="createInput")
    def create_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createInput"))

    @builtins.property
    @jsii.member(jsii_name="deleteInput")
    def delete_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "deleteInput"))

    @builtins.property
    @jsii.member(jsii_name="readInput")
    def read_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "readInput"))

    @builtins.property
    @jsii.member(jsii_name="updateInput")
    def update_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "updateInput"))

    @builtins.property
    @jsii.member(jsii_name="create")
    def create(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "create"))

    @create.setter
    def create(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__91a21777e63668a6d679c5818b34964c0d5ff249fa409573f79146d57212f954)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "create", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="delete")
    def delete(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "delete"))

    @delete.setter
    def delete(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f6fe5e6fd7899199f15fa5a3058264c252bbb7de047b21b926fe3bfcd80845a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "delete", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="read")
    def read(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "read"))

    @read.setter
    def read(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8d86264919046cb9545c85056ba769d25aa45ea4ab5b2ec755bbb0e7ecb26e60)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "read", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="update")
    def update(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "update"))

    @update.setter
    def update(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__925781695caa0828c67a476547524642b64a648cd5ee65bd335d5f2c5e3ca23e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "update", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyTimeouts]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyTimeouts]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyTimeouts]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__174bbd78c090e6de6d8e28b6d7d2b538b407c5e7fbe44226602b00170ce32bf5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "AccessPackageAssignmentPolicy",
    "AccessPackageAssignmentPolicyApprovalSettings",
    "AccessPackageAssignmentPolicyApprovalSettingsApprovalStage",
    "AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover",
    "AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApproverList",
    "AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApproverOutputReference",
    "AccessPackageAssignmentPolicyApprovalSettingsApprovalStageList",
    "AccessPackageAssignmentPolicyApprovalSettingsApprovalStageOutputReference",
    "AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover",
    "AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApproverList",
    "AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApproverOutputReference",
    "AccessPackageAssignmentPolicyApprovalSettingsOutputReference",
    "AccessPackageAssignmentPolicyAssignmentReviewSettings",
    "AccessPackageAssignmentPolicyAssignmentReviewSettingsOutputReference",
    "AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer",
    "AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewerList",
    "AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewerOutputReference",
    "AccessPackageAssignmentPolicyConfig",
    "AccessPackageAssignmentPolicyQuestion",
    "AccessPackageAssignmentPolicyQuestionChoice",
    "AccessPackageAssignmentPolicyQuestionChoiceDisplayValue",
    "AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText",
    "AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedTextList",
    "AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedTextOutputReference",
    "AccessPackageAssignmentPolicyQuestionChoiceDisplayValueOutputReference",
    "AccessPackageAssignmentPolicyQuestionChoiceList",
    "AccessPackageAssignmentPolicyQuestionChoiceOutputReference",
    "AccessPackageAssignmentPolicyQuestionList",
    "AccessPackageAssignmentPolicyQuestionOutputReference",
    "AccessPackageAssignmentPolicyQuestionText",
    "AccessPackageAssignmentPolicyQuestionTextLocalizedText",
    "AccessPackageAssignmentPolicyQuestionTextLocalizedTextList",
    "AccessPackageAssignmentPolicyQuestionTextLocalizedTextOutputReference",
    "AccessPackageAssignmentPolicyQuestionTextOutputReference",
    "AccessPackageAssignmentPolicyRequestorSettings",
    "AccessPackageAssignmentPolicyRequestorSettingsOutputReference",
    "AccessPackageAssignmentPolicyRequestorSettingsRequestor",
    "AccessPackageAssignmentPolicyRequestorSettingsRequestorList",
    "AccessPackageAssignmentPolicyRequestorSettingsRequestorOutputReference",
    "AccessPackageAssignmentPolicyTimeouts",
    "AccessPackageAssignmentPolicyTimeoutsOutputReference",
]

publication.publish()

def _typecheckingstub__1fea9352b15a07fce47c90be772a5268410bf494be86c12ab2e819dcc247f279(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    access_package_id: builtins.str,
    description: builtins.str,
    display_name: builtins.str,
    approval_settings: typing.Optional[typing.Union[AccessPackageAssignmentPolicyApprovalSettings, typing.Dict[builtins.str, typing.Any]]] = None,
    assignment_review_settings: typing.Optional[typing.Union[AccessPackageAssignmentPolicyAssignmentReviewSettings, typing.Dict[builtins.str, typing.Any]]] = None,
    duration_in_days: typing.Optional[jsii.Number] = None,
    expiration_date: typing.Optional[builtins.str] = None,
    extension_enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    id: typing.Optional[builtins.str] = None,
    question: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyQuestion, typing.Dict[builtins.str, typing.Any]]]]] = None,
    requestor_settings: typing.Optional[typing.Union[AccessPackageAssignmentPolicyRequestorSettings, typing.Dict[builtins.str, typing.Any]]] = None,
    timeouts: typing.Optional[typing.Union[AccessPackageAssignmentPolicyTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0580d4f0f9f7447f46f8295aa17075e7fee70380b2221da16ec24ec9d09ea166(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__19ad8e89fd8be64d1f5997fea045e34b35b663a6dfdc42a1664dee1b8449e822(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyQuestion, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0ef25319137a4b80d352e19dfe4858d656108b01c14cd3696cac2e4078c5df66(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b385ed5527c92a6a990f764a7fd1c068fa63b73325e2a4d7800e032e387cc2c0(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e80f138b585352e4d79ebbdb6c1ff887d25256dac79a34408296c02ff21b62e8(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6ae0f5274e4a9dd434a9113273e19c88d6f4d88282f41fb716f15e2c90ddaeb3(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f33979de26d9fcfb458afdd9ea445b59fa126677401dceb703e5f43901f8187f(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__764381778310ed9a99c43146b86cea0f951c232621f839240ff3a209a7c13365(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7844766f82bbf9ef7938abf30a6297a14532a571349e9653e107ce66b7017305(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__42b4e1124b42501a8240e9583d116c2a39cac96b8648f01982e40aec754c9f59(
    *,
    approval_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    approval_required_for_extension: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    approval_stage: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyApprovalSettingsApprovalStage, typing.Dict[builtins.str, typing.Any]]]]] = None,
    requestor_justification_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__582406fc6e414fbce54dc207b3f454298afcec2c6c1c3990354bc09a2d9025aa(
    *,
    approval_timeout_in_days: jsii.Number,
    alternative_approval_enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    alternative_approver: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover, typing.Dict[builtins.str, typing.Any]]]]] = None,
    approver_justification_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    enable_alternative_approval_in_days: typing.Optional[jsii.Number] = None,
    primary_approver: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f026e230bce8bb225396ad0dd598500929282852cfd23ecaf8f4bc63c563b8db(
    *,
    subject_type: builtins.str,
    backup: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    object_id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__32621f10f032403f35a930a3b58517e16b34bf610122a13ad97ab08c1de8e8f1(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eed7e1dfafde7397ef673fe8c3e030b3c233a069856c923c66104e144d409388(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__56bd89f3521253f5eb26ac5dd235dd2c72f5e132b5085bde460bd9a9ce800123(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7555c9b2cd66487b66919d80349be4e25a1a148c7612eb694648075ef1ce0b6b(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__55e4338c4e19c610eb46a68be1175e6ba16f4d585c73ef02f917bd9bf00803a2(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6f354e71a2738eccf4af7b73f8a95a8e7c0b4b03e59942af57360c0df75f41c1(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a188a2c72a44ad699483288b8b710efa4cd9b091d1f4cd2facc3e9bf52e5cd46(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a4b4f8e186c10b04eb9a844749ef377e0ca0e8de0c966a499c0de7901d635031(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__208a5928c9c95c2dffa3642d6d40bbdb355802203ecd4674c07aa0dd2f8d3d54(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d9bab26ce2e7295d341d9fba3215ffe4341a4f768a23de363a3d6e21aec11481(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aee58b0d5452c983d4f4749af4eb54fe1d26b5d4458606fbe8c26c7e89ca5222(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9f476bde9da36d58a8b7d52c3167c7e1fdce52f6adc4cb0e074e62f9b20c9a37(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1aedb9370891f2843660dca33fcf734f0c03414be09f74b85cb1e74bd363d6cc(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b311f8f9231963113c221800e0cba6479d666610534f8f878d4677276ba57e5d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f53a50baf2afba248ef56bc13d59c6c85332bac0d416a61172817904630ee295(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d04c4fa98d2742db3b33571945c4fc3a0a6d8baf3fbb8dbbfd1770aa0867453f(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3ce9dc0e9f1a95b9fec9c9b42b139d4edfa69486bc55fac86d71e12c42b33f10(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyApprovalSettingsApprovalStage]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7335cbd4a19b6c9da41ac2384b178c6502e02f5e7476d890abc7493ae6a00064(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e9463b09e50e8386d707049fc481b2a99e03e392a346845c4b1b988d9f59a9e3(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__14b1b6be3b425d5f50c26c5e5e20d2a4eca239509917d2b1133e41e153dc7c2e(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7d0b0d8f9d5a4a9aa81122a7843560e2d756e792168edcf96846e7ff443ae668(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__839b6d2cab89a6dc45a7842544030573ac13c12e5dd25af932468fb3be419903(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d487c3e3ccd9a26a6833bc8b7d63e18e0a386ae8cef9d2d533ccb2dd7a595927(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bbd8579ff588506665001c0daa031c97315ea7adf51a41809b13532d0efa861a(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c9458e1c6b3d096d99c50b8751b44de2fdd957ece1636603b1afdc31328c872b(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyApprovalSettingsApprovalStage]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fcfe116adde1e4b97a199752340c1754bcd7da22b1bed88ae1adb8eb5e9916ec(
    *,
    subject_type: builtins.str,
    backup: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    object_id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e8484497f4324a2f34f87554a477d402e8acfc1fb67fb2526bef62879d50647c(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8e9feb436249c0eb517749d0bc0964e13268c6b15a35e27ebfa79e82a259d1dd(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fc126ca52a032d9bccbe2ba2d1cf4a6e395f15b3bfd7009fe26b9a1c436ed61d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7eb36bfed8d2a7e86e772774602187db6a6af27a099330b88fe5b93a92a42c77(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d35ff054d9677226cd913b1f94188c4d09494fea429b702540cf958cd19b714a(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2e356d54a1086ee74aaa2245899e178cc33f0b6014413422ff585b163bb5ce00(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c20915024caa37e4171b1405ea7efcc397d052fca874105a9d32ca0f5d18ed89(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1ac06d959a9c11a8078243603192aa9bbb14312247bea57233acb2c97f274cd3(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1bfc63ff9c5c50e7c1abe477a2d3e46dc70f8b669a0c9a56b7cb6f296bdc2f10(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4ce3c8c6396931e2ca6f54647ed8494a5924ab63aea5d59b521c346ddd4def45(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0831b608a010d616c78b3947b8952376bad76c62b074c286a81fba3c9863c617(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4dc68093c23851d125f54b055d1e254f21e12c4aef5eb15720d818d4db16f02e(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__986d624411aa7df398f7b251fca648b590d6c219b6cfa69433731d91c825d87a(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyApprovalSettingsApprovalStage, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__05a6b20fb66870044bc7ad5a02aea44123d9899be65d1c63bc181a04651b6da1(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a7fc0dbffcabd4f4c5484271001429dc6e53ef7c01c164bb11bfcfce2b783d09(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__54f76d0bb8dba84c19d3561fde628aedd5a5774607806eb01c7618fff9ca4e47(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__986f750424643957506620b1630c376c1c2efa51260d977c7e37e572c3e2c49a(
    value: typing.Optional[AccessPackageAssignmentPolicyApprovalSettings],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9206a30173670372b3aef89e3a526ce87331b7c38615bedaa15389d04bb02f89(
    *,
    access_recommendation_enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    access_review_timeout_behavior: typing.Optional[builtins.str] = None,
    approver_justification_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    duration_in_days: typing.Optional[jsii.Number] = None,
    enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    reviewer: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer, typing.Dict[builtins.str, typing.Any]]]]] = None,
    review_frequency: typing.Optional[builtins.str] = None,
    review_type: typing.Optional[builtins.str] = None,
    starting_on: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7bb8e253ae0247e44a35f16f8abfba3537d4f502135e04d490974de37692e2ed(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ff83deae0dac178980afc18860c27d126d76224e31022a321f37ff49fca733dd(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0325206b62b7cabd2e4002c19a5d38b32d36499c2f4fa54d3408b1eda9394caa(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__71e275d612ce56089ada112d66891ce3bc8bf0a644794b214509b1331e1f9dd9(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1e3541a02e0b8050f92a517900ee9879b20aa4b36d3adc5787245001f85cd38b(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__733900417c95ec076df316a368c98f9ef939ff5355becec441971fd1f34a39ee(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__35bfb7f51db50e5212065fbdcdd435fcc9393834d63fc880d7d9577a466987c2(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e4ffbe38c429a2da5e5a19dcb0c12efcda0c3c872b41ad84f20931fe2992b9a4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c8a771a47f4d0e71a3f6c30d0df691b242ad46f21d1b722ef20cdc20be176801(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a9e65b3fb99ee75d3e74d8e71121d8e0c884ec7d2d1cd49992d89cdd84f93002(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4018c0dfa31fd761d6f66c4ec7378c1d9a607ed51b756afc6c3b54118ab39623(
    value: typing.Optional[AccessPackageAssignmentPolicyAssignmentReviewSettings],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__64958ba19a932c265750ea0cb6523e66973aa9fca2ed7a427b2a7d6a7665654b(
    *,
    subject_type: builtins.str,
    backup: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    object_id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__33a7ce625e2b99c4abd6b61f16cb6844fc6bb327665b02b05e994a4bdac9690d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__97e17f9a4b2361bcf2d62d4d324a3ccaa7a8038509f85a16f0d00d162df3c899(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c422eab35d1bfb5d46ce2bef26b29dc8e4f4d2ade5bad21b89ac4509a21c2339(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aca382110f606e82315a22a1dbdb1a58d085f7db7bf2b5d377b6a7b0ec7bc40a(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4bf9738f5b3f8f4445362b677de4fd4eca6b7995e85235b26b21f28f0d216efb(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__54256e1c3e678a04e80f468071627cda15afabeaabbbd2fe8056c3e41161a031(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0bbdf2cb8b7101a5fc46fbbbe7113f6790f290192ca6a54e0ed3ab6e62efdbc0(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bc08cf6b6dadce141962cae21a0433c14a44aa33226b7b1b3e2e8d019da1c13d(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__20b098703d4e271085468578593238fcf60558ae350e6f27318b3148da9e4b47(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6de55d1c94d27be8863e74cdf03920027f9f4b5dd0716719a9c8fe931f75b181(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__835b1ee4dc5b9dee0108b7b893f1048c92fcedf33fef11dea7df7f991dd3a765(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d09a6cc732fc319ce159256fefac84b064b372ff8b06b5f074231bd48fba461a(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    access_package_id: builtins.str,
    description: builtins.str,
    display_name: builtins.str,
    approval_settings: typing.Optional[typing.Union[AccessPackageAssignmentPolicyApprovalSettings, typing.Dict[builtins.str, typing.Any]]] = None,
    assignment_review_settings: typing.Optional[typing.Union[AccessPackageAssignmentPolicyAssignmentReviewSettings, typing.Dict[builtins.str, typing.Any]]] = None,
    duration_in_days: typing.Optional[jsii.Number] = None,
    expiration_date: typing.Optional[builtins.str] = None,
    extension_enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    id: typing.Optional[builtins.str] = None,
    question: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyQuestion, typing.Dict[builtins.str, typing.Any]]]]] = None,
    requestor_settings: typing.Optional[typing.Union[AccessPackageAssignmentPolicyRequestorSettings, typing.Dict[builtins.str, typing.Any]]] = None,
    timeouts: typing.Optional[typing.Union[AccessPackageAssignmentPolicyTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__586b386a0e1f76b825092fd8982f1eed36be0514f5a487b777f31beb24833dfd(
    *,
    text: typing.Union[AccessPackageAssignmentPolicyQuestionText, typing.Dict[builtins.str, typing.Any]],
    choice: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyQuestionChoice, typing.Dict[builtins.str, typing.Any]]]]] = None,
    required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    sequence: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__25e9b1939804eb9f32f72504bfe0333255fcc598a24dbe64ecd82519d4ba3406(
    *,
    actual_value: builtins.str,
    display_value: typing.Union[AccessPackageAssignmentPolicyQuestionChoiceDisplayValue, typing.Dict[builtins.str, typing.Any]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__16ba8d047c20587bc5858151189fad466a3ee419284fa36128227366d57e5cbf(
    *,
    default_text: builtins.str,
    localized_text: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__897fa6d46649d48358ac10a698b3a3e3f1bff403ef523afdfb9696fdb4ba87ae(
    *,
    content: builtins.str,
    language_code: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a625ec60840b5f58881292bdeda1504a6aad70f3ea3f9247d98f9f72f6ff6571(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9f2985957f16fe7614b12d5eb464e7cb12947704a782b33104a4ff639851788b(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a4053b8dcbe888a3d3d251c25746b170335fe8eb6bddbcfe4960e1d502be6da0(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c2d6a70577ef5a24c8a7b9804182a5655b4e9ee87740437181d56db7cedcb4b3(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f34041c13f0a6699837270b714cd6d44b9abdf2ddbd8ab124d85a2d360bfa1e6(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d43e39a7efead5c93b2d9e226b4d60b9df4b6d399fb3b00b61dfe0ec197fbc4b(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7ed2d61b1d00da4820aa8991b9f6575d7dc62e7497bb18de28c4e5c6a81b9ab0(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__edb589d30af33608752a9f1ea8d2445906802df7efbe4e27fa5a73078e7998b0(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b37359690cd969f0a67acb0c72c490aa01b419ffe2c83fec9886d6010b47e528(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2eb7b64de990f95d179f9b5d22655248f0cbafa06de455500522e56b2ec4ef4b(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__431b19c82cc7a8a58293ed66e6010cbe17878d227fc359f692c781bef4d3c752(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8f1dff6aeeb0cbbdab0b94349c41fe067a1818a27b3a397ad02706bed7d9c9a0(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4420533d7cc21eaa187c922e61314705f934983cf3f49a3592faed5a4bea60ec(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__63eceb3e474299ba713f86ccf71cee79f8f25aefd1b742ffbe40832867307f2b(
    value: typing.Optional[AccessPackageAssignmentPolicyQuestionChoiceDisplayValue],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__74a05ae6675a2dbb7429f74c81b6c660f7395ff2017f128fe8dd528550da858f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3df0a4e6f798263c2967ad389216bd20b1dd6bae38bcdd5fc8d3d027201dc4b6(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6168d34142a43d6a50a3dffb15170f83d88357fdf5eec3c3944ff1d09169b08e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__efd6756441624790d5ef6c1a1bb6c6b4e6d9d77a0e124f343c28f4e4076a4a3d(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7bfd1e477d128e8b14deeb338b0aa8192b8093e6689b363226f8ee4a918495dd(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d8dbdf3eb64d912eea753a53696b56eef8fb961fc10e64d45ac06cde7c88ba61(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionChoice]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cc6bba23de218729d917fe95c8f1025b89099710834f576aa957a47032122cb8(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e5060483c924ee4630505011e0c2a46f16fd28acc4ebbd233201f458862a3226(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__05209d5ebcd9126a72d1aaaed6553ef4a013ccb5683399bfbecff96bba196fd6(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyQuestionChoice]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ccf87e095a5d575687717608ed4a1215b51a8d461c891983a63329443eac485a(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1962d9d3dd9156ab61e45291401ec26e074b0e718cfdaf30e671944deeedf19b(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8829bc870f5dd3b224443dead93b28dd05f7a5e4a4698fee04d2b5d6a692ba68(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__85bec212494ecc33c80e0be0953bd296fcf2b4aa66534bfcd60d6f1f99a2fda7(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2c74c1f2e3144eb0fc8377a28dcf8b9f4f2e3c8efc3974e3e9b4c1343d29cf5c(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4291228963cf0ad300ae16c8f22a6df1ee645733e1075f2d9cecc1dfd191bf92(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestion]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__185efce734ff103d7d0733386210459a57c86f895d2696f5febd54e90f2a9c5d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__09a73fb859e4f55d15c16aba93a06f8ef84c26dceea47d92add58da2f56aa00f(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyQuestionChoice, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__667db43057db148edfbc4c480061b07ee870a6985ca272045cd206b63610d133(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9240afba7d7dd9b298c13916fb73679cae632104f6a3e9dc053929966156604f(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8fcf382fbbbb7ecca1cfed65f5d1471bd03fbec5079c5a6f4f393a65dd42b615(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyQuestion]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7ebae4b01d5ec5f8df1c27e9e5848bf5fcf9568f34db57fc15fbae9354f63921(
    *,
    default_text: builtins.str,
    localized_text: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyQuestionTextLocalizedText, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a5c2565edf4896b6eb800908a6650fe473d65e722324d21117a85dbe1a259c9(
    *,
    content: builtins.str,
    language_code: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a2d98ce63c2e27ecb05021e7d6ab6377f959b46442320ed23890b1bdaee5b023(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__56ede9b1b411e7e44050738663a02886ee21c08d4f52c50dc78b3e6972daef29(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d7b5c0068c5d85123c98e008af91ed4da6b7d5c6ca768d792d77c403b1724f8e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6175ec58be5b79fc07f265bc27656d626249f0fed77b9ba426208b49c52f35cf(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__26363038ddc3658d9589348f6a1ee2d1e39c0ea6fca648c4a8dae0ae0e84fd13(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aedeecc4e4d3a82e07f99bbc10b3a74f251c155e7991835ef6900d00063bdbf8(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyQuestionTextLocalizedText]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d1d1a374d7b08c6f4fdf65116dc4cdf7f758cc51483089df2129d190f7772a71(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4c5e6f42c73ae9c0da507219fb43fbcbd54f321a11537b5b71a6ffe86dbc66f7(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__77ea57838415e166384a8f0e4d4734a9d6beaf00c6069e0f42170a01b0d1f8de(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e2aabf106009b38b3082258530ed9eb3341202978978e8aa7c99297b26c39a3b(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyQuestionTextLocalizedText]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__104177e488e94771781c15722497a6903ead2b05f6a743efdea7f38063759aa7(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bea58f08ff0594ded9fbcd40a60adcc1060f7df03206e9fa5e8af66673e90f90(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyQuestionTextLocalizedText, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ae5cf02f731c3cbc237443e71660f1be9042e520f03165580ba7accac68bd295(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__27f63f5b015889c66f0331e8858ee4b754af08afd44b3b22bdd28b1a4b0e824f(
    value: typing.Optional[AccessPackageAssignmentPolicyQuestionText],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__54d75ebc85cd950a25c4c47f5e489689592929f5a1b4d37636c7f523964b93fe(
    *,
    requestor: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyRequestorSettingsRequestor, typing.Dict[builtins.str, typing.Any]]]]] = None,
    requests_accepted: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    scope_type: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__54497a36408aabbe37603f65d947ec7b8f3abf9389e72f81e869048f6a3538d0(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1b63ea4657a228ab9b092ae5d8cbde9a0dab3bcb247b19e6227a27b65d13c3c7(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[AccessPackageAssignmentPolicyRequestorSettingsRequestor, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eedb49d24b7b6b4f25dbd5ff382ef4b951084cfa43661ae6dbf5f548e8af0b82(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ebbec9622c91b3da66b3fc1c00cbf590a35888e72de86a04ecd1733e876e82ce(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__934ab3c86567debe72921c4cf6f470a5329f05221b32b6202c1658d79ecfaee4(
    value: typing.Optional[AccessPackageAssignmentPolicyRequestorSettings],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__59d0973397873a8868a4ab5150427a2aaa139310df4a007458e5604b1276f9bf(
    *,
    subject_type: builtins.str,
    backup: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    object_id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a4a2b554dd57d28c89fe02e47056406e24f8b519251d2cfa239e98137535e6b(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__11106a16b8c7c1198e10672eb4fde94b24682aa4bf301947c7c2ffad5890da5b(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__674acb49559e407e1e5503d97a9ebffabeef77bd3d189b296e22727776c10b61(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__72d5359e5b71fde5c4170f75aa22b6dc3a112e82fcd5c54010605a21dc709cd2(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__94c9b8bdb928acee898565189767f1a560e9a2735e31bb1793bbcac86de8fe85(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8d0db1e71c1273694de85dba6c9f28b5beceb7e376c19e8b402f3901bdfbbdac(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[AccessPackageAssignmentPolicyRequestorSettingsRequestor]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__22bd6d42e8248c0262b579c5764bb45bd6e9e4d24e09754fa70028653a8f84db(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1dfdeca80159af2b4f269c64f6da9b358869a25d71d3afb1034424048543a5c0(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b879634e6a4ba17aba89ad1eb0b810b77debdb290ac123c75df08afecf6f550a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6cfa5cae5e9efebef757527b057a20fa7a62a6446d21dd74ffe2d841782179fa(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d03afee9929ba0fd00746cc2fea4b674e57eaa774a0f9ae157a85b79ffbd519b(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyRequestorSettingsRequestor]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__04d9119e79250508136777f74dae38b2354da381646a10538ad60be07364e0c6(
    *,
    create: typing.Optional[builtins.str] = None,
    delete: typing.Optional[builtins.str] = None,
    read: typing.Optional[builtins.str] = None,
    update: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9c4eab44329f7d2788563f585dafe02ca2acacc158799d9837ca010b8372f753(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__91a21777e63668a6d679c5818b34964c0d5ff249fa409573f79146d57212f954(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f6fe5e6fd7899199f15fa5a3058264c252bbb7de047b21b926fe3bfcd80845a(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8d86264919046cb9545c85056ba769d25aa45ea4ab5b2ec755bbb0e7ecb26e60(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__925781695caa0828c67a476547524642b64a648cd5ee65bd335d5f2c5e3ca23e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__174bbd78c090e6de6d8e28b6d7d2b538b407c5e7fbe44226602b00170ce32bf5(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, AccessPackageAssignmentPolicyTimeouts]],
) -> None:
    """Type checking stubs"""
    pass
