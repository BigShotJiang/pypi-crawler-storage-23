r'''
# `azuread_service_principal`

Refer to the Terraform Registry for docs: [`azuread_service_principal`](https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class ServicePrincipal(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipal",
):
    '''Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal azuread_service_principal}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id_: builtins.str,
        *,
        client_id: builtins.str,
        account_enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        alternative_names: typing.Optional[typing.Sequence[builtins.str]] = None,
        app_role_assignment_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        description: typing.Optional[builtins.str] = None,
        features: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["ServicePrincipalFeatures", typing.Dict[builtins.str, typing.Any]]]]] = None,
        feature_tags: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["ServicePrincipalFeatureTags", typing.Dict[builtins.str, typing.Any]]]]] = None,
        id: typing.Optional[builtins.str] = None,
        login_url: typing.Optional[builtins.str] = None,
        notes: typing.Optional[builtins.str] = None,
        notification_email_addresses: typing.Optional[typing.Sequence[builtins.str]] = None,
        owners: typing.Optional[typing.Sequence[builtins.str]] = None,
        preferred_single_sign_on_mode: typing.Optional[builtins.str] = None,
        saml_single_sign_on: typing.Optional[typing.Union["ServicePrincipalSamlSingleSignOn", typing.Dict[builtins.str, typing.Any]]] = None,
        tags: typing.Optional[typing.Sequence[builtins.str]] = None,
        timeouts: typing.Optional[typing.Union["ServicePrincipalTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        use_existing: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal azuread_service_principal} Resource.

        :param scope: The scope in which to define this construct.
        :param id_: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param client_id: The client ID of the application for which to create a service principal. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#client_id ServicePrincipal#client_id}
        :param account_enabled: Whether or not the service principal account is enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#account_enabled ServicePrincipal#account_enabled}
        :param alternative_names: A list of alternative names, used to retrieve service principals by subscription, identify resource group and full resource ids for managed identities. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#alternative_names ServicePrincipal#alternative_names}
        :param app_role_assignment_required: Whether this service principal requires an app role assignment to a user or group before Azure AD will issue a user or access token to the application. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#app_role_assignment_required ServicePrincipal#app_role_assignment_required}
        :param description: Description of the service principal provided for internal end-users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#description ServicePrincipal#description}
        :param features: features block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#features ServicePrincipal#features}
        :param feature_tags: feature_tags block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#feature_tags ServicePrincipal#feature_tags}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#id ServicePrincipal#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param login_url: The URL where the service provider redirects the user to Azure AD to authenticate. Azure AD uses the URL to launch the application from Microsoft 365 or the Azure AD My Apps. When blank, Azure AD performs IdP-initiated sign-on for applications configured with SAML-based single sign-on Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#login_url ServicePrincipal#login_url}
        :param notes: Free text field to capture information about the service principal, typically used for operational purposes. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#notes ServicePrincipal#notes}
        :param notification_email_addresses: List of email addresses where Azure AD sends a notification when the active certificate is near the expiration date. This is only for the certificates used to sign the SAML token issued for Azure AD Gallery applications Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#notification_email_addresses ServicePrincipal#notification_email_addresses}
        :param owners: A list of object IDs of principals that will be granted ownership of the service principal. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#owners ServicePrincipal#owners}
        :param preferred_single_sign_on_mode: The single sign-on mode configured for this application. Azure AD uses the preferred single sign-on mode to launch the application from Microsoft 365 or the Azure AD My Apps Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#preferred_single_sign_on_mode ServicePrincipal#preferred_single_sign_on_mode}
        :param saml_single_sign_on: saml_single_sign_on block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#saml_single_sign_on ServicePrincipal#saml_single_sign_on}
        :param tags: A set of tags to apply to the service principal. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#tags ServicePrincipal#tags}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#timeouts ServicePrincipal#timeouts}
        :param use_existing: When true, the resource will return an existing service principal instead of failing with an error. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#use_existing ServicePrincipal#use_existing}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__66d1913c5b7c9cd43758c6413d57b8595119b4a6603859314359aa33f7367a91)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id_", value=id_, expected_type=type_hints["id_"])
        config = ServicePrincipalConfig(
            client_id=client_id,
            account_enabled=account_enabled,
            alternative_names=alternative_names,
            app_role_assignment_required=app_role_assignment_required,
            description=description,
            features=features,
            feature_tags=feature_tags,
            id=id,
            login_url=login_url,
            notes=notes,
            notification_email_addresses=notification_email_addresses,
            owners=owners,
            preferred_single_sign_on_mode=preferred_single_sign_on_mode,
            saml_single_sign_on=saml_single_sign_on,
            tags=tags,
            timeouts=timeouts,
            use_existing=use_existing,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id_, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    ) -> _cdktn_78ede62e.ImportableResource:
        '''Generates CDKTN code for importing a ServicePrincipal resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the ServicePrincipal to import.
        :param import_from_id: The id of the existing ServicePrincipal that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the ServicePrincipal to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9f83f0a72bde2f2f611172e5d31b3cb4dbd792276d3ee1e6b54a61c47dfaa463)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktn_78ede62e.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putFeatures")
    def put_features(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["ServicePrincipalFeatures", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__23123abcc382cd9c7dd26c07703ec23c9b62c94a58fa7eca5e62fbe68c2177b6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putFeatures", [value]))

    @jsii.member(jsii_name="putFeatureTags")
    def put_feature_tags(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["ServicePrincipalFeatureTags", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__03756bd254da634731de551d97de3d723154728e230e65cb8e547d27cb2f6ede)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putFeatureTags", [value]))

    @jsii.member(jsii_name="putSamlSingleSignOn")
    def put_saml_single_sign_on(
        self,
        *,
        relay_state: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param relay_state: The relative URI the service provider would redirect to after completion of the single sign-on flow. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#relay_state ServicePrincipal#relay_state}
        '''
        value = ServicePrincipalSamlSingleSignOn(relay_state=relay_state)

        return typing.cast(None, jsii.invoke(self, "putSamlSingleSignOn", [value]))

    @jsii.member(jsii_name="putTimeouts")
    def put_timeouts(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#create ServicePrincipal#create}.
        :param delete: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#delete ServicePrincipal#delete}.
        :param read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#read ServicePrincipal#read}.
        :param update: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#update ServicePrincipal#update}.
        '''
        value = ServicePrincipalTimeouts(
            create=create, delete=delete, read=read, update=update
        )

        return typing.cast(None, jsii.invoke(self, "putTimeouts", [value]))

    @jsii.member(jsii_name="resetAccountEnabled")
    def reset_account_enabled(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAccountEnabled", []))

    @jsii.member(jsii_name="resetAlternativeNames")
    def reset_alternative_names(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAlternativeNames", []))

    @jsii.member(jsii_name="resetAppRoleAssignmentRequired")
    def reset_app_role_assignment_required(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAppRoleAssignmentRequired", []))

    @jsii.member(jsii_name="resetDescription")
    def reset_description(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDescription", []))

    @jsii.member(jsii_name="resetFeatures")
    def reset_features(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFeatures", []))

    @jsii.member(jsii_name="resetFeatureTags")
    def reset_feature_tags(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetFeatureTags", []))

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetLoginUrl")
    def reset_login_url(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetLoginUrl", []))

    @jsii.member(jsii_name="resetNotes")
    def reset_notes(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNotes", []))

    @jsii.member(jsii_name="resetNotificationEmailAddresses")
    def reset_notification_email_addresses(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetNotificationEmailAddresses", []))

    @jsii.member(jsii_name="resetOwners")
    def reset_owners(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetOwners", []))

    @jsii.member(jsii_name="resetPreferredSingleSignOnMode")
    def reset_preferred_single_sign_on_mode(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPreferredSingleSignOnMode", []))

    @jsii.member(jsii_name="resetSamlSingleSignOn")
    def reset_saml_single_sign_on(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSamlSingleSignOn", []))

    @jsii.member(jsii_name="resetTags")
    def reset_tags(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTags", []))

    @jsii.member(jsii_name="resetTimeouts")
    def reset_timeouts(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetTimeouts", []))

    @jsii.member(jsii_name="resetUseExisting")
    def reset_use_existing(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUseExisting", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="applicationTenantId")
    def application_tenant_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "applicationTenantId"))

    @builtins.property
    @jsii.member(jsii_name="appRoleIds")
    def app_role_ids(self) -> _cdktn_78ede62e.StringMap:
        return typing.cast(_cdktn_78ede62e.StringMap, jsii.get(self, "appRoleIds"))

    @builtins.property
    @jsii.member(jsii_name="appRoles")
    def app_roles(self) -> "ServicePrincipalAppRolesList":
        return typing.cast("ServicePrincipalAppRolesList", jsii.get(self, "appRoles"))

    @builtins.property
    @jsii.member(jsii_name="displayName")
    def display_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "displayName"))

    @builtins.property
    @jsii.member(jsii_name="features")
    def features(self) -> "ServicePrincipalFeaturesList":
        return typing.cast("ServicePrincipalFeaturesList", jsii.get(self, "features"))

    @builtins.property
    @jsii.member(jsii_name="featureTags")
    def feature_tags(self) -> "ServicePrincipalFeatureTagsList":
        return typing.cast("ServicePrincipalFeatureTagsList", jsii.get(self, "featureTags"))

    @builtins.property
    @jsii.member(jsii_name="homepageUrl")
    def homepage_url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "homepageUrl"))

    @builtins.property
    @jsii.member(jsii_name="logoutUrl")
    def logout_url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logoutUrl"))

    @builtins.property
    @jsii.member(jsii_name="oauth2PermissionScopeIds")
    def oauth2_permission_scope_ids(self) -> _cdktn_78ede62e.StringMap:
        return typing.cast(_cdktn_78ede62e.StringMap, jsii.get(self, "oauth2PermissionScopeIds"))

    @builtins.property
    @jsii.member(jsii_name="oauth2PermissionScopes")
    def oauth2_permission_scopes(self) -> "ServicePrincipalOauth2PermissionScopesList":
        return typing.cast("ServicePrincipalOauth2PermissionScopesList", jsii.get(self, "oauth2PermissionScopes"))

    @builtins.property
    @jsii.member(jsii_name="objectId")
    def object_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "objectId"))

    @builtins.property
    @jsii.member(jsii_name="redirectUris")
    def redirect_uris(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "redirectUris"))

    @builtins.property
    @jsii.member(jsii_name="samlMetadataUrl")
    def saml_metadata_url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "samlMetadataUrl"))

    @builtins.property
    @jsii.member(jsii_name="samlSingleSignOn")
    def saml_single_sign_on(self) -> "ServicePrincipalSamlSingleSignOnOutputReference":
        return typing.cast("ServicePrincipalSamlSingleSignOnOutputReference", jsii.get(self, "samlSingleSignOn"))

    @builtins.property
    @jsii.member(jsii_name="servicePrincipalNames")
    def service_principal_names(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "servicePrincipalNames"))

    @builtins.property
    @jsii.member(jsii_name="signInAudience")
    def sign_in_audience(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "signInAudience"))

    @builtins.property
    @jsii.member(jsii_name="timeouts")
    def timeouts(self) -> "ServicePrincipalTimeoutsOutputReference":
        return typing.cast("ServicePrincipalTimeoutsOutputReference", jsii.get(self, "timeouts"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="accountEnabledInput")
    def account_enabled_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "accountEnabledInput"))

    @builtins.property
    @jsii.member(jsii_name="alternativeNamesInput")
    def alternative_names_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "alternativeNamesInput"))

    @builtins.property
    @jsii.member(jsii_name="appRoleAssignmentRequiredInput")
    def app_role_assignment_required_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "appRoleAssignmentRequiredInput"))

    @builtins.property
    @jsii.member(jsii_name="clientIdInput")
    def client_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "clientIdInput"))

    @builtins.property
    @jsii.member(jsii_name="descriptionInput")
    def description_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "descriptionInput"))

    @builtins.property
    @jsii.member(jsii_name="featuresInput")
    def features_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ServicePrincipalFeatures"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ServicePrincipalFeatures"]]], jsii.get(self, "featuresInput"))

    @builtins.property
    @jsii.member(jsii_name="featureTagsInput")
    def feature_tags_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ServicePrincipalFeatureTags"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ServicePrincipalFeatureTags"]]], jsii.get(self, "featureTagsInput"))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="loginUrlInput")
    def login_url_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "loginUrlInput"))

    @builtins.property
    @jsii.member(jsii_name="notesInput")
    def notes_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "notesInput"))

    @builtins.property
    @jsii.member(jsii_name="notificationEmailAddressesInput")
    def notification_email_addresses_input(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "notificationEmailAddressesInput"))

    @builtins.property
    @jsii.member(jsii_name="ownersInput")
    def owners_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "ownersInput"))

    @builtins.property
    @jsii.member(jsii_name="preferredSingleSignOnModeInput")
    def preferred_single_sign_on_mode_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "preferredSingleSignOnModeInput"))

    @builtins.property
    @jsii.member(jsii_name="samlSingleSignOnInput")
    def saml_single_sign_on_input(
        self,
    ) -> typing.Optional["ServicePrincipalSamlSingleSignOn"]:
        return typing.cast(typing.Optional["ServicePrincipalSamlSingleSignOn"], jsii.get(self, "samlSingleSignOnInput"))

    @builtins.property
    @jsii.member(jsii_name="tagsInput")
    def tags_input(self) -> typing.Optional[typing.List[builtins.str]]:
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "tagsInput"))

    @builtins.property
    @jsii.member(jsii_name="timeoutsInput")
    def timeouts_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "ServicePrincipalTimeouts"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "ServicePrincipalTimeouts"]], jsii.get(self, "timeoutsInput"))

    @builtins.property
    @jsii.member(jsii_name="useExistingInput")
    def use_existing_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "useExistingInput"))

    @builtins.property
    @jsii.member(jsii_name="accountEnabled")
    def account_enabled(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "accountEnabled"))

    @account_enabled.setter
    def account_enabled(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__55625eb6824d68207802eb916d23f8ddd4cb079ce68f76bee5042b064ca4c2d7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "accountEnabled", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="alternativeNames")
    def alternative_names(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "alternativeNames"))

    @alternative_names.setter
    def alternative_names(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f8b086e915296ac15e457a6c7c2394955fa11d9f0d862617a6338aefa6aa6231)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "alternativeNames", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="appRoleAssignmentRequired")
    def app_role_assignment_required(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "appRoleAssignmentRequired"))

    @app_role_assignment_required.setter
    def app_role_assignment_required(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eb3af046c22234b4eaa04f5c32cc5b3a359f323a3ba42cc1cdecb7ba5ca6a90d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "appRoleAssignmentRequired", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="clientId")
    def client_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "clientId"))

    @client_id.setter
    def client_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2260d90c9c90ffd6032cb70fbaf24ae13e861879784183f4d7c75fb6f326a44c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "clientId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="description")
    def description(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "description"))

    @description.setter
    def description(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__32bb44b020ee4fc697fbc40499fa575e2b3c3e2083b83d489c56210572dbc525)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "description", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1a658083f7edadbed3136b2e96db7358d440d8137c60dcdaa3e2365daec27863)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="loginUrl")
    def login_url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "loginUrl"))

    @login_url.setter
    def login_url(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ef6d4c4234903c23c6ee6f2985695d1b481d190e7d7271bd93278e7a08d1d15b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "loginUrl", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="notes")
    def notes(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "notes"))

    @notes.setter
    def notes(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ee831a82e5401ceb7245d6e38e3860a2d923cece69f6d8646356d53c2e90a2de)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "notes", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="notificationEmailAddresses")
    def notification_email_addresses(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "notificationEmailAddresses"))

    @notification_email_addresses.setter
    def notification_email_addresses(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f66f05ee0cdd12c44db6e8f5893cb39e07504861c30fe27c0be0d1e8cfe1eb34)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "notificationEmailAddresses", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="owners")
    def owners(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "owners"))

    @owners.setter
    def owners(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__641137562630ade66057bedb4f7b0b7c8b66d7f15687afa1cf2a85e3524392d7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "owners", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="preferredSingleSignOnMode")
    def preferred_single_sign_on_mode(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "preferredSingleSignOnMode"))

    @preferred_single_sign_on_mode.setter
    def preferred_single_sign_on_mode(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0dee900f58427497aae44f4c0035f644e086f9116332e5e6bbb51db3ce199191)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "preferredSingleSignOnMode", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="tags")
    def tags(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "tags"))

    @tags.setter
    def tags(self, value: typing.List[builtins.str]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3e23ff40b515dc4990068b9d75ef7afa1f77a685238476f05b4cb65e2519b595)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tags", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="useExisting")
    def use_existing(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "useExisting"))

    @use_existing.setter
    def use_existing(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9fe089c2e7c889c17f7904585c208026558d52931c3daa7427e6bda67c624886)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "useExisting", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalAppRoles",
    jsii_struct_bases=[],
    name_mapping={},
)
class ServicePrincipalAppRoles:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServicePrincipalAppRoles(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServicePrincipalAppRolesList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalAppRolesList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1515148252dec2a0ef049b9269a0dbff7908df61f1b871a4e5b0eacdb6b53264)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "ServicePrincipalAppRolesOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5c6658d5428c717d911ec9c702ccae2f4446e23ebd7fd32d39f607c5244ecc03)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("ServicePrincipalAppRolesOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2a815b85358ca75af558eac1003a67b81d589fbeddabca597db3c736561d0377)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a9c8e50ec33496b613f43401a3214682d1db567cd387cd8f67de60bd89abe874)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5aba6ec81568f1481071b12374e6d32506cdf5912025c7acfef71dbc01c823ac)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class ServicePrincipalAppRolesOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalAppRolesOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3e8254225e8b7c15629fa472cd2f6204e6a87ed5802eab0f1091cd8ef5a30f5f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="allowedMemberTypes")
    def allowed_member_types(self) -> typing.List[builtins.str]:
        return typing.cast(typing.List[builtins.str], jsii.get(self, "allowedMemberTypes"))

    @builtins.property
    @jsii.member(jsii_name="description")
    def description(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "description"))

    @builtins.property
    @jsii.member(jsii_name="displayName")
    def display_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "displayName"))

    @builtins.property
    @jsii.member(jsii_name="enabled")
    def enabled(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "enabled"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @builtins.property
    @jsii.member(jsii_name="value")
    def value(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "value"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[ServicePrincipalAppRoles]:
        return typing.cast(typing.Optional[ServicePrincipalAppRoles], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(self, value: typing.Optional[ServicePrincipalAppRoles]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__88b0986da5fa4ecd924189310d2badbdb97186c1e09d12b67f7f8af9f3414376)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "client_id": "clientId",
        "account_enabled": "accountEnabled",
        "alternative_names": "alternativeNames",
        "app_role_assignment_required": "appRoleAssignmentRequired",
        "description": "description",
        "features": "features",
        "feature_tags": "featureTags",
        "id": "id",
        "login_url": "loginUrl",
        "notes": "notes",
        "notification_email_addresses": "notificationEmailAddresses",
        "owners": "owners",
        "preferred_single_sign_on_mode": "preferredSingleSignOnMode",
        "saml_single_sign_on": "samlSingleSignOn",
        "tags": "tags",
        "timeouts": "timeouts",
        "use_existing": "useExisting",
    },
)
class ServicePrincipalConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        client_id: builtins.str,
        account_enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        alternative_names: typing.Optional[typing.Sequence[builtins.str]] = None,
        app_role_assignment_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        description: typing.Optional[builtins.str] = None,
        features: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["ServicePrincipalFeatures", typing.Dict[builtins.str, typing.Any]]]]] = None,
        feature_tags: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["ServicePrincipalFeatureTags", typing.Dict[builtins.str, typing.Any]]]]] = None,
        id: typing.Optional[builtins.str] = None,
        login_url: typing.Optional[builtins.str] = None,
        notes: typing.Optional[builtins.str] = None,
        notification_email_addresses: typing.Optional[typing.Sequence[builtins.str]] = None,
        owners: typing.Optional[typing.Sequence[builtins.str]] = None,
        preferred_single_sign_on_mode: typing.Optional[builtins.str] = None,
        saml_single_sign_on: typing.Optional[typing.Union["ServicePrincipalSamlSingleSignOn", typing.Dict[builtins.str, typing.Any]]] = None,
        tags: typing.Optional[typing.Sequence[builtins.str]] = None,
        timeouts: typing.Optional[typing.Union["ServicePrincipalTimeouts", typing.Dict[builtins.str, typing.Any]]] = None,
        use_existing: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param client_id: The client ID of the application for which to create a service principal. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#client_id ServicePrincipal#client_id}
        :param account_enabled: Whether or not the service principal account is enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#account_enabled ServicePrincipal#account_enabled}
        :param alternative_names: A list of alternative names, used to retrieve service principals by subscription, identify resource group and full resource ids for managed identities. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#alternative_names ServicePrincipal#alternative_names}
        :param app_role_assignment_required: Whether this service principal requires an app role assignment to a user or group before Azure AD will issue a user or access token to the application. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#app_role_assignment_required ServicePrincipal#app_role_assignment_required}
        :param description: Description of the service principal provided for internal end-users. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#description ServicePrincipal#description}
        :param features: features block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#features ServicePrincipal#features}
        :param feature_tags: feature_tags block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#feature_tags ServicePrincipal#feature_tags}
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#id ServicePrincipal#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param login_url: The URL where the service provider redirects the user to Azure AD to authenticate. Azure AD uses the URL to launch the application from Microsoft 365 or the Azure AD My Apps. When blank, Azure AD performs IdP-initiated sign-on for applications configured with SAML-based single sign-on Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#login_url ServicePrincipal#login_url}
        :param notes: Free text field to capture information about the service principal, typically used for operational purposes. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#notes ServicePrincipal#notes}
        :param notification_email_addresses: List of email addresses where Azure AD sends a notification when the active certificate is near the expiration date. This is only for the certificates used to sign the SAML token issued for Azure AD Gallery applications Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#notification_email_addresses ServicePrincipal#notification_email_addresses}
        :param owners: A list of object IDs of principals that will be granted ownership of the service principal. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#owners ServicePrincipal#owners}
        :param preferred_single_sign_on_mode: The single sign-on mode configured for this application. Azure AD uses the preferred single sign-on mode to launch the application from Microsoft 365 or the Azure AD My Apps Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#preferred_single_sign_on_mode ServicePrincipal#preferred_single_sign_on_mode}
        :param saml_single_sign_on: saml_single_sign_on block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#saml_single_sign_on ServicePrincipal#saml_single_sign_on}
        :param tags: A set of tags to apply to the service principal. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#tags ServicePrincipal#tags}
        :param timeouts: timeouts block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#timeouts ServicePrincipal#timeouts}
        :param use_existing: When true, the resource will return an existing service principal instead of failing with an error. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#use_existing ServicePrincipal#use_existing}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(saml_single_sign_on, dict):
            saml_single_sign_on = ServicePrincipalSamlSingleSignOn(**saml_single_sign_on)
        if isinstance(timeouts, dict):
            timeouts = ServicePrincipalTimeouts(**timeouts)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d52d04273b7e7eaf8388b0ab90592045a089b5dda62754779ac7363f606d0b3a)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument client_id", value=client_id, expected_type=type_hints["client_id"])
            check_type(argname="argument account_enabled", value=account_enabled, expected_type=type_hints["account_enabled"])
            check_type(argname="argument alternative_names", value=alternative_names, expected_type=type_hints["alternative_names"])
            check_type(argname="argument app_role_assignment_required", value=app_role_assignment_required, expected_type=type_hints["app_role_assignment_required"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument features", value=features, expected_type=type_hints["features"])
            check_type(argname="argument feature_tags", value=feature_tags, expected_type=type_hints["feature_tags"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument login_url", value=login_url, expected_type=type_hints["login_url"])
            check_type(argname="argument notes", value=notes, expected_type=type_hints["notes"])
            check_type(argname="argument notification_email_addresses", value=notification_email_addresses, expected_type=type_hints["notification_email_addresses"])
            check_type(argname="argument owners", value=owners, expected_type=type_hints["owners"])
            check_type(argname="argument preferred_single_sign_on_mode", value=preferred_single_sign_on_mode, expected_type=type_hints["preferred_single_sign_on_mode"])
            check_type(argname="argument saml_single_sign_on", value=saml_single_sign_on, expected_type=type_hints["saml_single_sign_on"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            check_type(argname="argument timeouts", value=timeouts, expected_type=type_hints["timeouts"])
            check_type(argname="argument use_existing", value=use_existing, expected_type=type_hints["use_existing"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "client_id": client_id,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if account_enabled is not None:
            self._values["account_enabled"] = account_enabled
        if alternative_names is not None:
            self._values["alternative_names"] = alternative_names
        if app_role_assignment_required is not None:
            self._values["app_role_assignment_required"] = app_role_assignment_required
        if description is not None:
            self._values["description"] = description
        if features is not None:
            self._values["features"] = features
        if feature_tags is not None:
            self._values["feature_tags"] = feature_tags
        if id is not None:
            self._values["id"] = id
        if login_url is not None:
            self._values["login_url"] = login_url
        if notes is not None:
            self._values["notes"] = notes
        if notification_email_addresses is not None:
            self._values["notification_email_addresses"] = notification_email_addresses
        if owners is not None:
            self._values["owners"] = owners
        if preferred_single_sign_on_mode is not None:
            self._values["preferred_single_sign_on_mode"] = preferred_single_sign_on_mode
        if saml_single_sign_on is not None:
            self._values["saml_single_sign_on"] = saml_single_sign_on
        if tags is not None:
            self._values["tags"] = tags
        if timeouts is not None:
            self._values["timeouts"] = timeouts
        if use_existing is not None:
            self._values["use_existing"] = use_existing

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktn_78ede62e.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktn_78ede62e.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktn_78ede62e.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]], result)

    @builtins.property
    def client_id(self) -> builtins.str:
        '''The client ID of the application for which to create a service principal.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#client_id ServicePrincipal#client_id}
        '''
        result = self._values.get("client_id")
        assert result is not None, "Required property 'client_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def account_enabled(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether or not the service principal account is enabled.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#account_enabled ServicePrincipal#account_enabled}
        '''
        result = self._values.get("account_enabled")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def alternative_names(self) -> typing.Optional[typing.List[builtins.str]]:
        '''A list of alternative names, used to retrieve service principals by subscription, identify resource group and full resource ids for managed identities.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#alternative_names ServicePrincipal#alternative_names}
        '''
        result = self._values.get("alternative_names")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def app_role_assignment_required(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether this service principal requires an app role assignment to a user or group before Azure AD will issue a user or access token to the application.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#app_role_assignment_required ServicePrincipal#app_role_assignment_required}
        '''
        result = self._values.get("app_role_assignment_required")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''Description of the service principal provided for internal end-users.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#description ServicePrincipal#description}
        '''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def features(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ServicePrincipalFeatures"]]]:
        '''features block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#features ServicePrincipal#features}
        '''
        result = self._values.get("features")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ServicePrincipalFeatures"]]], result)

    @builtins.property
    def feature_tags(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ServicePrincipalFeatureTags"]]]:
        '''feature_tags block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#feature_tags ServicePrincipal#feature_tags}
        '''
        result = self._values.get("feature_tags")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["ServicePrincipalFeatureTags"]]], result)

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#id ServicePrincipal#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def login_url(self) -> typing.Optional[builtins.str]:
        '''The URL where the service provider redirects the user to Azure AD to authenticate.

        Azure AD uses the URL to launch the application from Microsoft 365 or the Azure AD My Apps. When blank, Azure AD performs IdP-initiated sign-on for applications configured with SAML-based single sign-on

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#login_url ServicePrincipal#login_url}
        '''
        result = self._values.get("login_url")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def notes(self) -> typing.Optional[builtins.str]:
        '''Free text field to capture information about the service principal, typically used for operational purposes.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#notes ServicePrincipal#notes}
        '''
        result = self._values.get("notes")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def notification_email_addresses(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        '''List of email addresses where Azure AD sends a notification when the active certificate is near the expiration date.

        This is only for the certificates used to sign the SAML token issued for Azure AD Gallery applications

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#notification_email_addresses ServicePrincipal#notification_email_addresses}
        '''
        result = self._values.get("notification_email_addresses")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def owners(self) -> typing.Optional[typing.List[builtins.str]]:
        '''A list of object IDs of principals that will be granted ownership of the service principal.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#owners ServicePrincipal#owners}
        '''
        result = self._values.get("owners")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def preferred_single_sign_on_mode(self) -> typing.Optional[builtins.str]:
        '''The single sign-on mode configured for this application.

        Azure AD uses the preferred single sign-on mode to launch the application from Microsoft 365 or the Azure AD My Apps

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#preferred_single_sign_on_mode ServicePrincipal#preferred_single_sign_on_mode}
        '''
        result = self._values.get("preferred_single_sign_on_mode")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def saml_single_sign_on(
        self,
    ) -> typing.Optional["ServicePrincipalSamlSingleSignOn"]:
        '''saml_single_sign_on block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#saml_single_sign_on ServicePrincipal#saml_single_sign_on}
        '''
        result = self._values.get("saml_single_sign_on")
        return typing.cast(typing.Optional["ServicePrincipalSamlSingleSignOn"], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.List[builtins.str]]:
        '''A set of tags to apply to the service principal.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#tags ServicePrincipal#tags}
        '''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def timeouts(self) -> typing.Optional["ServicePrincipalTimeouts"]:
        '''timeouts block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#timeouts ServicePrincipal#timeouts}
        '''
        result = self._values.get("timeouts")
        return typing.cast(typing.Optional["ServicePrincipalTimeouts"], result)

    @builtins.property
    def use_existing(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''When true, the resource will return an existing service principal instead of failing with an error.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#use_existing ServicePrincipal#use_existing}
        '''
        result = self._values.get("use_existing")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServicePrincipalConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalFeatureTags",
    jsii_struct_bases=[],
    name_mapping={
        "custom_single_sign_on": "customSingleSignOn",
        "enterprise": "enterprise",
        "gallery": "gallery",
        "hide": "hide",
    },
)
class ServicePrincipalFeatureTags:
    def __init__(
        self,
        *,
        custom_single_sign_on: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        enterprise: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        gallery: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        hide: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param custom_single_sign_on: Whether this service principal represents a custom SAML application. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#custom_single_sign_on ServicePrincipal#custom_single_sign_on}
        :param enterprise: Whether this service principal represents an Enterprise Application. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#enterprise ServicePrincipal#enterprise}
        :param gallery: Whether this service principal represents a gallery application. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#gallery ServicePrincipal#gallery}
        :param hide: Whether this app is invisible to users in My Apps and Office 365 Launcher. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#hide ServicePrincipal#hide}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bf2803222239f92536a2332593347ad8f7b69014f992d61440d58791c7c31fcd)
            check_type(argname="argument custom_single_sign_on", value=custom_single_sign_on, expected_type=type_hints["custom_single_sign_on"])
            check_type(argname="argument enterprise", value=enterprise, expected_type=type_hints["enterprise"])
            check_type(argname="argument gallery", value=gallery, expected_type=type_hints["gallery"])
            check_type(argname="argument hide", value=hide, expected_type=type_hints["hide"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if custom_single_sign_on is not None:
            self._values["custom_single_sign_on"] = custom_single_sign_on
        if enterprise is not None:
            self._values["enterprise"] = enterprise
        if gallery is not None:
            self._values["gallery"] = gallery
        if hide is not None:
            self._values["hide"] = hide

    @builtins.property
    def custom_single_sign_on(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether this service principal represents a custom SAML application.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#custom_single_sign_on ServicePrincipal#custom_single_sign_on}
        '''
        result = self._values.get("custom_single_sign_on")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def enterprise(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether this service principal represents an Enterprise Application.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#enterprise ServicePrincipal#enterprise}
        '''
        result = self._values.get("enterprise")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def gallery(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether this service principal represents a gallery application.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#gallery ServicePrincipal#gallery}
        '''
        result = self._values.get("gallery")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def hide(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether this app is invisible to users in My Apps and Office 365 Launcher.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#hide ServicePrincipal#hide}
        '''
        result = self._values.get("hide")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServicePrincipalFeatureTags(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServicePrincipalFeatureTagsList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalFeatureTagsList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__40729c7da37b71d49b3ce0728eaafa291dcbccf51b801878b9e9f649056f5918)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "ServicePrincipalFeatureTagsOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fd66c3cbb655344dce44ec605549f94668f4ded5743f4cb0728a761e4fb5ab81)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("ServicePrincipalFeatureTagsOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8c49580e65629fde9dc36163c07d02b228b7e67aae9c2d19ccf3fbdfaece5999)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__89c0d308f6e7a5f3ec12de50f6203f4d97a7cbab41768e23be7e360ae7e069bd)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d6941c5f2d713ef5858624076115baf67ec3c8819a0169b2070d7026ebf30560)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ServicePrincipalFeatureTags]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ServicePrincipalFeatureTags]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ServicePrincipalFeatureTags]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__42e11bd5b56acc1cb4d7aa43d6fd461e9aee82cde40cc4c37b0cacebec9ce581)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ServicePrincipalFeatureTagsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalFeatureTagsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__335fbcc11659ddbd127932bb5aecd94a5078e7c25993257a58c0fff2db73ac3f)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetCustomSingleSignOn")
    def reset_custom_single_sign_on(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCustomSingleSignOn", []))

    @jsii.member(jsii_name="resetEnterprise")
    def reset_enterprise(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEnterprise", []))

    @jsii.member(jsii_name="resetGallery")
    def reset_gallery(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetGallery", []))

    @jsii.member(jsii_name="resetHide")
    def reset_hide(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetHide", []))

    @builtins.property
    @jsii.member(jsii_name="customSingleSignOnInput")
    def custom_single_sign_on_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "customSingleSignOnInput"))

    @builtins.property
    @jsii.member(jsii_name="enterpriseInput")
    def enterprise_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "enterpriseInput"))

    @builtins.property
    @jsii.member(jsii_name="galleryInput")
    def gallery_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "galleryInput"))

    @builtins.property
    @jsii.member(jsii_name="hideInput")
    def hide_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "hideInput"))

    @builtins.property
    @jsii.member(jsii_name="customSingleSignOn")
    def custom_single_sign_on(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "customSingleSignOn"))

    @custom_single_sign_on.setter
    def custom_single_sign_on(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__86f6e0faf8edbc941412110a287460b4b5b750aee345c8ba4caad7534ef8fbde)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "customSingleSignOn", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enterprise")
    def enterprise(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "enterprise"))

    @enterprise.setter
    def enterprise(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fc229770af04f28f161d940b602696d6a3f32d7628c1a652da81e8291add010b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enterprise", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="gallery")
    def gallery(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "gallery"))

    @gallery.setter
    def gallery(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__afe76b17047736e31e7bbc894764b3ce1a89ced467880a1d9ae00876a4d02e58)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "gallery", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="hide")
    def hide(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "hide"))

    @hide.setter
    def hide(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__074225952fcd66df1e981f83e6518a331098b98ace169313e744c98162294966)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "hide", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServicePrincipalFeatureTags]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServicePrincipalFeatureTags]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServicePrincipalFeatureTags]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__76a01003c72058418d697be881211bc299a41499f08e1300964c6bc50bf1fc52)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalFeatures",
    jsii_struct_bases=[],
    name_mapping={
        "custom_single_sign_on_app": "customSingleSignOnApp",
        "enterprise_application": "enterpriseApplication",
        "gallery_application": "galleryApplication",
        "visible_to_users": "visibleToUsers",
    },
)
class ServicePrincipalFeatures:
    def __init__(
        self,
        *,
        custom_single_sign_on_app: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        enterprise_application: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        gallery_application: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        visible_to_users: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param custom_single_sign_on_app: Whether this service principal represents a custom SAML application. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#custom_single_sign_on_app ServicePrincipal#custom_single_sign_on_app}
        :param enterprise_application: Whether this service principal represents an Enterprise Application. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#enterprise_application ServicePrincipal#enterprise_application}
        :param gallery_application: Whether this service principal represents a gallery application. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#gallery_application ServicePrincipal#gallery_application}
        :param visible_to_users: Whether this app is visible to users in My Apps and Office 365 Launcher. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#visible_to_users ServicePrincipal#visible_to_users}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6e72b6c5eccbfab143830849f8046d1d56803164aa67e4658c10ce8ad107a774)
            check_type(argname="argument custom_single_sign_on_app", value=custom_single_sign_on_app, expected_type=type_hints["custom_single_sign_on_app"])
            check_type(argname="argument enterprise_application", value=enterprise_application, expected_type=type_hints["enterprise_application"])
            check_type(argname="argument gallery_application", value=gallery_application, expected_type=type_hints["gallery_application"])
            check_type(argname="argument visible_to_users", value=visible_to_users, expected_type=type_hints["visible_to_users"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if custom_single_sign_on_app is not None:
            self._values["custom_single_sign_on_app"] = custom_single_sign_on_app
        if enterprise_application is not None:
            self._values["enterprise_application"] = enterprise_application
        if gallery_application is not None:
            self._values["gallery_application"] = gallery_application
        if visible_to_users is not None:
            self._values["visible_to_users"] = visible_to_users

    @builtins.property
    def custom_single_sign_on_app(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether this service principal represents a custom SAML application.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#custom_single_sign_on_app ServicePrincipal#custom_single_sign_on_app}
        '''
        result = self._values.get("custom_single_sign_on_app")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def enterprise_application(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether this service principal represents an Enterprise Application.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#enterprise_application ServicePrincipal#enterprise_application}
        '''
        result = self._values.get("enterprise_application")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def gallery_application(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether this service principal represents a gallery application.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#gallery_application ServicePrincipal#gallery_application}
        '''
        result = self._values.get("gallery_application")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def visible_to_users(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Whether this app is visible to users in My Apps and Office 365 Launcher.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#visible_to_users ServicePrincipal#visible_to_users}
        '''
        result = self._values.get("visible_to_users")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServicePrincipalFeatures(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServicePrincipalFeaturesList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalFeaturesList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6970c250414088de2c52b0664ae26c3bd553e626c912d3a402b813e572f2935c)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(self, index: jsii.Number) -> "ServicePrincipalFeaturesOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bc6ae6263d0498601e73a4bb27490f77ac6df314754ed2f8778a82a764c30a84)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("ServicePrincipalFeaturesOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e8d201190c3d4d8bd9e0f30af4ac5f554bb527c04e243e8fdbafa67838d7eb3b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9695c9db849a734ab9de98847859a4e234b799fc357ad17cb3b281bb4140c555)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__22f70ac5fdc193380e22ce85595474a6539708b1012ba6a0d1e04952879623b5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ServicePrincipalFeatures]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ServicePrincipalFeatures]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ServicePrincipalFeatures]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3f6c00ea87406ab4a782f7d2e2e5b05fee6e38826359391f0d37070fef35f241)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class ServicePrincipalFeaturesOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalFeaturesOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7af1cded2075982ba4ea07757f3268e446e1ebf146db913715926801d426b4b3)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetCustomSingleSignOnApp")
    def reset_custom_single_sign_on_app(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCustomSingleSignOnApp", []))

    @jsii.member(jsii_name="resetEnterpriseApplication")
    def reset_enterprise_application(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEnterpriseApplication", []))

    @jsii.member(jsii_name="resetGalleryApplication")
    def reset_gallery_application(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetGalleryApplication", []))

    @jsii.member(jsii_name="resetVisibleToUsers")
    def reset_visible_to_users(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetVisibleToUsers", []))

    @builtins.property
    @jsii.member(jsii_name="customSingleSignOnAppInput")
    def custom_single_sign_on_app_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "customSingleSignOnAppInput"))

    @builtins.property
    @jsii.member(jsii_name="enterpriseApplicationInput")
    def enterprise_application_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "enterpriseApplicationInput"))

    @builtins.property
    @jsii.member(jsii_name="galleryApplicationInput")
    def gallery_application_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "galleryApplicationInput"))

    @builtins.property
    @jsii.member(jsii_name="visibleToUsersInput")
    def visible_to_users_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "visibleToUsersInput"))

    @builtins.property
    @jsii.member(jsii_name="customSingleSignOnApp")
    def custom_single_sign_on_app(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "customSingleSignOnApp"))

    @custom_single_sign_on_app.setter
    def custom_single_sign_on_app(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e421dbc5247efa4f8985294709c1d94f9f8d4eac839e515ad7dadb2f9dc969cf)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "customSingleSignOnApp", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enterpriseApplication")
    def enterprise_application(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "enterpriseApplication"))

    @enterprise_application.setter
    def enterprise_application(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aff4223e6b9d021f0333fb0c9de785daeafc0d37a56e6f3c3d93e5a339b34660)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enterpriseApplication", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="galleryApplication")
    def gallery_application(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "galleryApplication"))

    @gallery_application.setter
    def gallery_application(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3858d98ccd65129cc357bb79ec1ed76a90aec821deb75869c2c20fcc04a6620a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "galleryApplication", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="visibleToUsers")
    def visible_to_users(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "visibleToUsers"))

    @visible_to_users.setter
    def visible_to_users(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cd45844fd12df01e2b7d3d682cb1789ae05d0966f735e5160e73efcb9b3dd0d3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "visibleToUsers", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServicePrincipalFeatures]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServicePrincipalFeatures]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServicePrincipalFeatures]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b91081094a6c7e002d3a03bf8be378950e36b7834b1984308b2788a6724a7922)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalOauth2PermissionScopes",
    jsii_struct_bases=[],
    name_mapping={},
)
class ServicePrincipalOauth2PermissionScopes:
    def __init__(self) -> None:
        self._values: typing.Dict[builtins.str, typing.Any] = {}

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServicePrincipalOauth2PermissionScopes(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServicePrincipalOauth2PermissionScopesList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalOauth2PermissionScopesList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d0eb2b4c064dbee29f68b15d307cf400aa7e244908190b7e58a1d7c3210cbacf)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "ServicePrincipalOauth2PermissionScopesOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3e8d0877cba9207a60b46f39d17468fff77ac8d0a451478d0b368ccbbdd13336)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("ServicePrincipalOauth2PermissionScopesOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ef575d46b765af1b1df74943b4a12c0a5685bfa4e50577cbd2378a5076c8dbf6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b9340d5265b848928a06555256528f6211fb51e49543a3bf30f11bdb2a622ec7)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dda4d306ab54994d873f7828474805afa45a798033423779623955ff30c0746c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]


class ServicePrincipalOauth2PermissionScopesOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalOauth2PermissionScopesOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6e0e4f2c6de2543475a6e10881596668269fa3c1c6bd247b2319e3bfc8962a66)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="adminConsentDescription")
    def admin_consent_description(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "adminConsentDescription"))

    @builtins.property
    @jsii.member(jsii_name="adminConsentDisplayName")
    def admin_consent_display_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "adminConsentDisplayName"))

    @builtins.property
    @jsii.member(jsii_name="enabled")
    def enabled(self) -> _cdktn_78ede62e.IResolvable:
        return typing.cast(_cdktn_78ede62e.IResolvable, jsii.get(self, "enabled"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @builtins.property
    @jsii.member(jsii_name="userConsentDescription")
    def user_consent_description(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "userConsentDescription"))

    @builtins.property
    @jsii.member(jsii_name="userConsentDisplayName")
    def user_consent_display_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "userConsentDisplayName"))

    @builtins.property
    @jsii.member(jsii_name="value")
    def value(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "value"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[ServicePrincipalOauth2PermissionScopes]:
        return typing.cast(typing.Optional[ServicePrincipalOauth2PermissionScopes], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[ServicePrincipalOauth2PermissionScopes],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__679506468784b8635b398867d62a08c72798148952ea62c50d3af3217923fe63)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalSamlSingleSignOn",
    jsii_struct_bases=[],
    name_mapping={"relay_state": "relayState"},
)
class ServicePrincipalSamlSingleSignOn:
    def __init__(self, *, relay_state: typing.Optional[builtins.str] = None) -> None:
        '''
        :param relay_state: The relative URI the service provider would redirect to after completion of the single sign-on flow. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#relay_state ServicePrincipal#relay_state}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4ebbb469bbfbd09514b72afc43a3be5c35dd24a455e0b85f9e4afb62e56d9648)
            check_type(argname="argument relay_state", value=relay_state, expected_type=type_hints["relay_state"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if relay_state is not None:
            self._values["relay_state"] = relay_state

    @builtins.property
    def relay_state(self) -> typing.Optional[builtins.str]:
        '''The relative URI the service provider would redirect to after completion of the single sign-on flow.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#relay_state ServicePrincipal#relay_state}
        '''
        result = self._values.get("relay_state")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServicePrincipalSamlSingleSignOn(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServicePrincipalSamlSingleSignOnOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalSamlSingleSignOnOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0cfa60d56b2b8c182b7c006f1aed6313eb6e9459db0ffc8aef1c6eb44f663f6d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetRelayState")
    def reset_relay_state(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRelayState", []))

    @builtins.property
    @jsii.member(jsii_name="relayStateInput")
    def relay_state_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "relayStateInput"))

    @builtins.property
    @jsii.member(jsii_name="relayState")
    def relay_state(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "relayState"))

    @relay_state.setter
    def relay_state(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d5537476aa33f9a09bf7cfc920ca87734399414b56bfcc7b44d7c9084ca2e5c4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "relayState", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(self) -> typing.Optional[ServicePrincipalSamlSingleSignOn]:
        return typing.cast(typing.Optional[ServicePrincipalSamlSingleSignOn], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[ServicePrincipalSamlSingleSignOn],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4051adc430157c9add84d4ddf2a2e0b7382d7690827ba2b62f58e6aec100dc58)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalTimeouts",
    jsii_struct_bases=[],
    name_mapping={
        "create": "create",
        "delete": "delete",
        "read": "read",
        "update": "update",
    },
)
class ServicePrincipalTimeouts:
    def __init__(
        self,
        *,
        create: typing.Optional[builtins.str] = None,
        delete: typing.Optional[builtins.str] = None,
        read: typing.Optional[builtins.str] = None,
        update: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param create: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#create ServicePrincipal#create}.
        :param delete: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#delete ServicePrincipal#delete}.
        :param read: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#read ServicePrincipal#read}.
        :param update: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#update ServicePrincipal#update}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__579de0374f0cbf2a11a79e6690fdf056d18c8f95b45eaa4ceca10f9badd45aeb)
            check_type(argname="argument create", value=create, expected_type=type_hints["create"])
            check_type(argname="argument delete", value=delete, expected_type=type_hints["delete"])
            check_type(argname="argument read", value=read, expected_type=type_hints["read"])
            check_type(argname="argument update", value=update, expected_type=type_hints["update"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if create is not None:
            self._values["create"] = create
        if delete is not None:
            self._values["delete"] = delete
        if read is not None:
            self._values["read"] = read
        if update is not None:
            self._values["update"] = update

    @builtins.property
    def create(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#create ServicePrincipal#create}.'''
        result = self._values.get("create")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def delete(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#delete ServicePrincipal#delete}.'''
        result = self._values.get("delete")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def read(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#read ServicePrincipal#read}.'''
        result = self._values.get("read")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def update(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal#update ServicePrincipal#update}.'''
        result = self._values.get("update")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ServicePrincipalTimeouts(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ServicePrincipalTimeoutsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-azuread.servicePrincipal.ServicePrincipalTimeoutsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e08c644b329dda7ef08e230e5374bf28ed206af0121652225c926bdd119d137c)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetCreate")
    def reset_create(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreate", []))

    @jsii.member(jsii_name="resetDelete")
    def reset_delete(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetDelete", []))

    @jsii.member(jsii_name="resetRead")
    def reset_read(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetRead", []))

    @jsii.member(jsii_name="resetUpdate")
    def reset_update(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetUpdate", []))

    @builtins.property
    @jsii.member(jsii_name="createInput")
    def create_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createInput"))

    @builtins.property
    @jsii.member(jsii_name="deleteInput")
    def delete_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "deleteInput"))

    @builtins.property
    @jsii.member(jsii_name="readInput")
    def read_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "readInput"))

    @builtins.property
    @jsii.member(jsii_name="updateInput")
    def update_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "updateInput"))

    @builtins.property
    @jsii.member(jsii_name="create")
    def create(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "create"))

    @create.setter
    def create(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a57a28b54817b5cb861ec3aebcb6495d884421fb5a2c5dd57b850d5d90bbf067)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "create", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="delete")
    def delete(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "delete"))

    @delete.setter
    def delete(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__19c011988690e5afa665e7a6016ad72592c29ec5ba4c8340877461c575887265)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "delete", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="read")
    def read(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "read"))

    @read.setter
    def read(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__80867209296d94e1fab95b242c8065d49c3728d717034d72f073884469181646)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "read", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="update")
    def update(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "update"))

    @update.setter
    def update(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d5296bf671d0c242ed45d939cec49405517c0c0de876a0e33942827943ef3f70)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "update", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServicePrincipalTimeouts]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServicePrincipalTimeouts]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServicePrincipalTimeouts]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__396fdf0255d9e8ccf06b961a7fd16e875550f23df0f57a0e62b308e24dc32fd2)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "ServicePrincipal",
    "ServicePrincipalAppRoles",
    "ServicePrincipalAppRolesList",
    "ServicePrincipalAppRolesOutputReference",
    "ServicePrincipalConfig",
    "ServicePrincipalFeatureTags",
    "ServicePrincipalFeatureTagsList",
    "ServicePrincipalFeatureTagsOutputReference",
    "ServicePrincipalFeatures",
    "ServicePrincipalFeaturesList",
    "ServicePrincipalFeaturesOutputReference",
    "ServicePrincipalOauth2PermissionScopes",
    "ServicePrincipalOauth2PermissionScopesList",
    "ServicePrincipalOauth2PermissionScopesOutputReference",
    "ServicePrincipalSamlSingleSignOn",
    "ServicePrincipalSamlSingleSignOnOutputReference",
    "ServicePrincipalTimeouts",
    "ServicePrincipalTimeoutsOutputReference",
]

publication.publish()

def _typecheckingstub__66d1913c5b7c9cd43758c6413d57b8595119b4a6603859314359aa33f7367a91(
    scope: _constructs_77d1e7e8.Construct,
    id_: builtins.str,
    *,
    client_id: builtins.str,
    account_enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    alternative_names: typing.Optional[typing.Sequence[builtins.str]] = None,
    app_role_assignment_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    description: typing.Optional[builtins.str] = None,
    features: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServicePrincipalFeatures, typing.Dict[builtins.str, typing.Any]]]]] = None,
    feature_tags: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServicePrincipalFeatureTags, typing.Dict[builtins.str, typing.Any]]]]] = None,
    id: typing.Optional[builtins.str] = None,
    login_url: typing.Optional[builtins.str] = None,
    notes: typing.Optional[builtins.str] = None,
    notification_email_addresses: typing.Optional[typing.Sequence[builtins.str]] = None,
    owners: typing.Optional[typing.Sequence[builtins.str]] = None,
    preferred_single_sign_on_mode: typing.Optional[builtins.str] = None,
    saml_single_sign_on: typing.Optional[typing.Union[ServicePrincipalSamlSingleSignOn, typing.Dict[builtins.str, typing.Any]]] = None,
    tags: typing.Optional[typing.Sequence[builtins.str]] = None,
    timeouts: typing.Optional[typing.Union[ServicePrincipalTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    use_existing: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9f83f0a72bde2f2f611172e5d31b3cb4dbd792276d3ee1e6b54a61c47dfaa463(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__23123abcc382cd9c7dd26c07703ec23c9b62c94a58fa7eca5e62fbe68c2177b6(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServicePrincipalFeatures, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__03756bd254da634731de551d97de3d723154728e230e65cb8e547d27cb2f6ede(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServicePrincipalFeatureTags, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__55625eb6824d68207802eb916d23f8ddd4cb079ce68f76bee5042b064ca4c2d7(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f8b086e915296ac15e457a6c7c2394955fa11d9f0d862617a6338aefa6aa6231(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eb3af046c22234b4eaa04f5c32cc5b3a359f323a3ba42cc1cdecb7ba5ca6a90d(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2260d90c9c90ffd6032cb70fbaf24ae13e861879784183f4d7c75fb6f326a44c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__32bb44b020ee4fc697fbc40499fa575e2b3c3e2083b83d489c56210572dbc525(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1a658083f7edadbed3136b2e96db7358d440d8137c60dcdaa3e2365daec27863(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ef6d4c4234903c23c6ee6f2985695d1b481d190e7d7271bd93278e7a08d1d15b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ee831a82e5401ceb7245d6e38e3860a2d923cece69f6d8646356d53c2e90a2de(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f66f05ee0cdd12c44db6e8f5893cb39e07504861c30fe27c0be0d1e8cfe1eb34(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__641137562630ade66057bedb4f7b0b7c8b66d7f15687afa1cf2a85e3524392d7(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0dee900f58427497aae44f4c0035f644e086f9116332e5e6bbb51db3ce199191(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3e23ff40b515dc4990068b9d75ef7afa1f77a685238476f05b4cb65e2519b595(
    value: typing.List[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9fe089c2e7c889c17f7904585c208026558d52931c3daa7427e6bda67c624886(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1515148252dec2a0ef049b9269a0dbff7908df61f1b871a4e5b0eacdb6b53264(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5c6658d5428c717d911ec9c702ccae2f4446e23ebd7fd32d39f607c5244ecc03(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2a815b85358ca75af558eac1003a67b81d589fbeddabca597db3c736561d0377(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a9c8e50ec33496b613f43401a3214682d1db567cd387cd8f67de60bd89abe874(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5aba6ec81568f1481071b12374e6d32506cdf5912025c7acfef71dbc01c823ac(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3e8254225e8b7c15629fa472cd2f6204e6a87ed5802eab0f1091cd8ef5a30f5f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__88b0986da5fa4ecd924189310d2badbdb97186c1e09d12b67f7f8af9f3414376(
    value: typing.Optional[ServicePrincipalAppRoles],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d52d04273b7e7eaf8388b0ab90592045a089b5dda62754779ac7363f606d0b3a(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    client_id: builtins.str,
    account_enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    alternative_names: typing.Optional[typing.Sequence[builtins.str]] = None,
    app_role_assignment_required: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    description: typing.Optional[builtins.str] = None,
    features: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServicePrincipalFeatures, typing.Dict[builtins.str, typing.Any]]]]] = None,
    feature_tags: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[ServicePrincipalFeatureTags, typing.Dict[builtins.str, typing.Any]]]]] = None,
    id: typing.Optional[builtins.str] = None,
    login_url: typing.Optional[builtins.str] = None,
    notes: typing.Optional[builtins.str] = None,
    notification_email_addresses: typing.Optional[typing.Sequence[builtins.str]] = None,
    owners: typing.Optional[typing.Sequence[builtins.str]] = None,
    preferred_single_sign_on_mode: typing.Optional[builtins.str] = None,
    saml_single_sign_on: typing.Optional[typing.Union[ServicePrincipalSamlSingleSignOn, typing.Dict[builtins.str, typing.Any]]] = None,
    tags: typing.Optional[typing.Sequence[builtins.str]] = None,
    timeouts: typing.Optional[typing.Union[ServicePrincipalTimeouts, typing.Dict[builtins.str, typing.Any]]] = None,
    use_existing: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bf2803222239f92536a2332593347ad8f7b69014f992d61440d58791c7c31fcd(
    *,
    custom_single_sign_on: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    enterprise: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    gallery: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    hide: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40729c7da37b71d49b3ce0728eaafa291dcbccf51b801878b9e9f649056f5918(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fd66c3cbb655344dce44ec605549f94668f4ded5743f4cb0728a761e4fb5ab81(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8c49580e65629fde9dc36163c07d02b228b7e67aae9c2d19ccf3fbdfaece5999(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__89c0d308f6e7a5f3ec12de50f6203f4d97a7cbab41768e23be7e360ae7e069bd(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d6941c5f2d713ef5858624076115baf67ec3c8819a0169b2070d7026ebf30560(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__42e11bd5b56acc1cb4d7aa43d6fd461e9aee82cde40cc4c37b0cacebec9ce581(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ServicePrincipalFeatureTags]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__335fbcc11659ddbd127932bb5aecd94a5078e7c25993257a58c0fff2db73ac3f(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__86f6e0faf8edbc941412110a287460b4b5b750aee345c8ba4caad7534ef8fbde(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fc229770af04f28f161d940b602696d6a3f32d7628c1a652da81e8291add010b(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__afe76b17047736e31e7bbc894764b3ce1a89ced467880a1d9ae00876a4d02e58(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__074225952fcd66df1e981f83e6518a331098b98ace169313e744c98162294966(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__76a01003c72058418d697be881211bc299a41499f08e1300964c6bc50bf1fc52(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServicePrincipalFeatureTags]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6e72b6c5eccbfab143830849f8046d1d56803164aa67e4658c10ce8ad107a774(
    *,
    custom_single_sign_on_app: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    enterprise_application: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    gallery_application: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    visible_to_users: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6970c250414088de2c52b0664ae26c3bd553e626c912d3a402b813e572f2935c(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bc6ae6263d0498601e73a4bb27490f77ac6df314754ed2f8778a82a764c30a84(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e8d201190c3d4d8bd9e0f30af4ac5f554bb527c04e243e8fdbafa67838d7eb3b(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9695c9db849a734ab9de98847859a4e234b799fc357ad17cb3b281bb4140c555(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__22f70ac5fdc193380e22ce85595474a6539708b1012ba6a0d1e04952879623b5(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3f6c00ea87406ab4a782f7d2e2e5b05fee6e38826359391f0d37070fef35f241(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[ServicePrincipalFeatures]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7af1cded2075982ba4ea07757f3268e446e1ebf146db913715926801d426b4b3(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e421dbc5247efa4f8985294709c1d94f9f8d4eac839e515ad7dadb2f9dc969cf(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aff4223e6b9d021f0333fb0c9de785daeafc0d37a56e6f3c3d93e5a339b34660(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3858d98ccd65129cc357bb79ec1ed76a90aec821deb75869c2c20fcc04a6620a(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cd45844fd12df01e2b7d3d682cb1789ae05d0966f735e5160e73efcb9b3dd0d3(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b91081094a6c7e002d3a03bf8be378950e36b7834b1984308b2788a6724a7922(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServicePrincipalFeatures]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d0eb2b4c064dbee29f68b15d307cf400aa7e244908190b7e58a1d7c3210cbacf(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3e8d0877cba9207a60b46f39d17468fff77ac8d0a451478d0b368ccbbdd13336(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ef575d46b765af1b1df74943b4a12c0a5685bfa4e50577cbd2378a5076c8dbf6(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b9340d5265b848928a06555256528f6211fb51e49543a3bf30f11bdb2a622ec7(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dda4d306ab54994d873f7828474805afa45a798033423779623955ff30c0746c(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6e0e4f2c6de2543475a6e10881596668269fa3c1c6bd247b2319e3bfc8962a66(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__679506468784b8635b398867d62a08c72798148952ea62c50d3af3217923fe63(
    value: typing.Optional[ServicePrincipalOauth2PermissionScopes],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4ebbb469bbfbd09514b72afc43a3be5c35dd24a455e0b85f9e4afb62e56d9648(
    *,
    relay_state: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0cfa60d56b2b8c182b7c006f1aed6313eb6e9459db0ffc8aef1c6eb44f663f6d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d5537476aa33f9a09bf7cfc920ca87734399414b56bfcc7b44d7c9084ca2e5c4(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4051adc430157c9add84d4ddf2a2e0b7382d7690827ba2b62f58e6aec100dc58(
    value: typing.Optional[ServicePrincipalSamlSingleSignOn],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__579de0374f0cbf2a11a79e6690fdf056d18c8f95b45eaa4ceca10f9badd45aeb(
    *,
    create: typing.Optional[builtins.str] = None,
    delete: typing.Optional[builtins.str] = None,
    read: typing.Optional[builtins.str] = None,
    update: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e08c644b329dda7ef08e230e5374bf28ed206af0121652225c926bdd119d137c(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a57a28b54817b5cb861ec3aebcb6495d884421fb5a2c5dd57b850d5d90bbf067(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__19c011988690e5afa665e7a6016ad72592c29ec5ba4c8340877461c575887265(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__80867209296d94e1fab95b242c8065d49c3728d717034d72f073884469181646(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d5296bf671d0c242ed45d939cec49405517c0c0de876a0e33942827943ef3f70(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__396fdf0255d9e8ccf06b961a7fd16e875550f23df0f57a0e62b308e24dc32fd2(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, ServicePrincipalTimeouts]],
) -> None:
    """Type checking stubs"""
    pass
