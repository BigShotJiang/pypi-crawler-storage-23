### Overview

Phantom's telemetry module provides internal tracing for scan runs (agent creation, tool executions, vulnerability reports, and run metadata). All data stays local in the `phantom_runs/` directory. No external analytics or data collection is performed.
