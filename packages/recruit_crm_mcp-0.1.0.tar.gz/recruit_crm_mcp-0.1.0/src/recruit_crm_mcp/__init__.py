"""MCP server for Recruit CRM."""
