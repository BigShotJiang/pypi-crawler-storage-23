"""Tests for LoggingHelper."""

import logging
import os
import tempfile

from brinkhaustools.common.logging import LoggingHelper, RingbufferHandler


def test_ring_buffer_handler():
    h = RingbufferHandler(max_lines=5)
    h.setFormatter(logging.Formatter("%(message)s"))
    for i in range(10):
        record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="", lineno=0,
            msg=f"line-{i}", args=(), exc_info=None,
        )
        h.emit(record)
    text = h.get()
    # Should only have last 5
    assert "line-5" in text
    assert "line-9" in text
    assert "line-0" not in text


def test_logging_helper_creates_directory():
    with tempfile.TemporaryDirectory() as tmpdir:
        log_dir = os.path.join(tmpdir, "subdir", "logs")
        lh = LoggingHelper(log_dir=log_dir)
        assert os.path.isdir(log_dir)
        logger = lh.get_logger("test")
        logger.info("test message")
        buf = lh.get_ring_buffer()
        assert "test message" in buf
