# F1 — Semantic Decay Scoring

## 1. PRD (Product Manager)

### Problem

Lore's search (`recall`) ranks memories by cosine similarity with a crude global time decay (`exp(-0.005 * age_days)` applied multiplicatively). This treats all memory types identically — a coding convention recorded 60 days ago decays the same as a debugging note from 60 days ago. In practice, conventions stay relevant far longer than ephemeral notes. Users get stale results ranked too high and fresh results ranked too low.

### Solution

Replace the current decay model with **type-specific half-life decay** using a weighted additive formula:

```
final_score = (semantic_weight * cosine_similarity) + (temporal_weight * temporal_score)
temporal_score = 0.5 ^ (age_in_days / half_life_days)
```

Default half-lives by memory type:
| Type | Half-life |
|------|-----------|
| `code` | 14 days |
| `note` | 21 days |
| `lesson` | 30 days |
| `convention` | 60 days |
| *(other)* | 21 days |

Default weights: `semantic_weight=0.7`, `temporal_weight=0.3`.

### User Value

- **More relevant recall**: Recent debugging notes surface above month-old notes; long-lived conventions persist.
- **Zero-config improvement**: Defaults work well out of the box.
- **Power-user control**: Advanced users can tune half-lives and weights.

### Success Metrics

- Memories of type `convention` aged 30 days score higher than `note` memories aged 30 days (given equal cosine similarity).
- A 0-day-old memory scores ~30% higher than the same memory aged 1 half-life (at equal cosine).
- No performance regression on search (decay is a trivial arithmetic operation on already-fetched results).
- All existing tests pass (backward compatible — only scoring changes).

---

## 2. Architecture (Architect)

### Current State

`src/lore/memory_store/sqlite.py:92-165` — the `search()` method:
1. Fetches candidate rows from SQLite (filtered by project/type, ordered by `created_at DESC`).
2. Filters expired memories and those without embeddings.
3. Computes cosine similarity via numpy.
4. Applies `score = cosine * exp(-0.005 * age_days)` — a multiplicative global decay.
5. Sorts by score, returns top `limit`.

### Proposed Changes

#### 2.1 Decay Configuration — `src/lore/memory_store/sqlite.py`

Add a module-level config dict and constants (replaces `_DECAY_LAMBDA`):

```python
# Replace _DECAY_LAMBDA with:
_DEFAULT_HALF_LIVES: Dict[str, float] = {
    "code": 14.0,
    "note": 21.0,
    "lesson": 30.0,
    "convention": 60.0,
}
_DEFAULT_HALF_LIFE = 21.0  # fallback for unknown types
_SEMANTIC_WEIGHT = 0.7
_TEMPORAL_WEIGHT = 0.3
```

No new config file or schema changes needed. `created_at` already exists. The `type` field already exists on every memory.

#### 2.2 Scoring Formula — `src/lore/memory_store/sqlite.py:search()`

Replace lines 156-162 (the scoring loop) with:

```python
for i, m in enumerate(candidates):
    age_days = (
        now - datetime.fromisoformat(m.created_at).replace(tzinfo=timezone.utc)
    ).total_seconds() / 86400.0
    half_life = _DEFAULT_HALF_LIVES.get(m.type, _DEFAULT_HALF_LIFE)
    temporal_score = 0.5 ** (age_days / half_life)
    score = (_SEMANTIC_WEIGHT * float(cosine_scores[i])) + (_TEMPORAL_WEIGHT * temporal_score)
    results.append(SearchResult(memory=m, score=round(max(score, 0.0), 6)))
```

#### 2.3 Store Interface — No Changes

The `Store` abstract base class (`src/lore/memory_store/base.py`) `search()` signature is unchanged. Decay is an internal implementation detail of `SqliteStore`.

#### 2.4 Lore SDK — No Changes

`src/lore/lore.py` `recall()` delegates to `store.search()` — no changes needed.

#### 2.5 Types — No Changes

`SearchResult.score` remains a float. No new fields needed.

#### 2.6 Schema — No Changes

`created_at` and `type` are already stored. No migration needed.

#### 2.7 Dependencies — None

`math.pow` or `**` operator — no new dependencies. Remove unused `math` import if `math.exp` is no longer called.

### Design Decisions

| Decision | Rationale |
|----------|-----------|
| Additive weighted (not multiplicative) | Ensures temporal signal has consistent influence regardless of cosine magnitude. A multiplicative approach lets high-cosine results dominate even when stale. |
| Module-level constants (not constructor params) | Keeps the change minimal. Future story can add constructor/config overrides. |
| Half-life model (not linear/exponential lambda) | More intuitive — "this type of memory is half as relevant after N days" is easier to reason about than lambda values. |
| Fallback half-life of 21 days | Matches `note` — the most common type. Conservative default. |

---

## 3. Stories (Scrum Master)

### Story 1: Replace Global Decay with Half-Life Model

**Summary**: Replace `_DECAY_LAMBDA` multiplicative decay with type-specific half-life additive decay in `SqliteStore.search()`.

**Files to modify**:
- `src/lore/memory_store/sqlite.py`

**Changes**:
1. Remove `_DECAY_LAMBDA` constant (line 38).
2. Add `_DEFAULT_HALF_LIVES` dict, `_DEFAULT_HALF_LIFE`, `_SEMANTIC_WEIGHT`, `_TEMPORAL_WEIGHT` constants.
3. Update scoring loop in `search()` (lines 156-162) to use new formula.
4. Remove `import math` if no longer needed (currently used for `math.exp` on line 160).

**Acceptance Criteria**:
- [ ] `_DECAY_LAMBDA` is removed.
- [ ] New constants are defined with correct default values (code=14, note=21, lesson=30, convention=60).
- [ ] `search()` uses `final_score = 0.7 * cosine + 0.3 * (0.5 ** (age / half_life))`.
- [ ] Half-life is looked up by `memory.type`, falling back to 21 days for unknown types.
- [ ] Existing tests in `tests/test_lore_sqlite_store.py` still pass.

---

### Story 2: Unit Tests for Decay Scoring

**Summary**: Add targeted tests that validate the decay scoring formula and type-specific behavior.

**Files to create/modify**:
- `tests/test_decay_scoring.py` (new file)

**Tests to write**:

1. **`test_newer_memory_scores_higher`**: Two memories with identical embeddings and type, one created today and one 30 days ago. The newer one should have a higher score.

2. **`test_type_specific_half_lives`**: Two memories with identical embeddings, same age (30 days), but different types (`code` half-life=14d vs `convention` half-life=60d). The `convention` memory should score higher because it has decayed less.

3. **`test_half_life_score_at_one_half_life`**: A memory aged exactly 1 half-life should have `temporal_score ≈ 0.5`. Verify the final score is approximately `0.7 * cosine + 0.3 * 0.5`.

4. **`test_zero_age_temporal_score`**: A memory created just now should have `temporal_score ≈ 1.0`. Final score ≈ `0.7 * cosine + 0.3 * 1.0`.

5. **`test_unknown_type_uses_default_half_life`**: A memory with `type="custom_thing"` should use the 21-day default half-life.

6. **`test_score_never_negative`**: Even with very old memories, score should be >= 0.

**Acceptance Criteria**:
- [ ] All 6 tests pass.
- [ ] Tests use controlled timestamps (not `datetime.now()`) for deterministic results.
- [ ] Tests create memories with known embeddings and verify score ordering and approximate values.

---

### Story 3: Update Existing Search Tests

**Summary**: Existing search tests in `test_lore_sqlite_store.py` may have score assertions affected by the formula change. Review and update.

**Files to modify**:
- `tests/test_lore_sqlite_store.py`

**Changes**:
1. Review `TestSqliteStoreSearch` — current tests check `score >= 0` and result counts, which should still pass.
2. If any tests assert specific score values, update them to match the new formula.

**Acceptance Criteria**:
- [ ] All tests in `tests/test_lore_sqlite_store.py` pass with the new decay model.
- [ ] No test is deleted — only updated if score values changed.

---

### Story 4: Integration Test — Decay in Recall Flow

**Summary**: End-to-end test through `Lore.recall()` proving that decay scoring works through the full SDK path.

**Files to modify**:
- `tests/test_lore_sdk_memory.py` or `tests/test_e2e_integration.py` (add test)

**Test**:
1. Create a `Lore` instance with a temp DB.
2. `remember()` two memories of different types with backdated `created_at` (may require direct store manipulation).
3. `recall()` and verify the expected ordering reflects type-specific decay.

**Acceptance Criteria**:
- [ ] Test passes and demonstrates decay-aware ranking through the SDK.
- [ ] Test is self-contained (temp DB, no side effects).

---

### Implementation Order

```
Story 1 (core change) → Story 2 (new tests) → Story 3 (fix existing tests) → Story 4 (integration)
```

Stories 2 and 3 can be parallelized after Story 1 is complete.
