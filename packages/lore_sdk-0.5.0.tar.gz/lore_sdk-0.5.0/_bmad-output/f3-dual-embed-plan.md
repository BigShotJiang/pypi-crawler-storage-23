# F3 — Dual Embedding Routing

## 1. PRD

### Problem Statement

Lore uses a single embedding model (`all-MiniLM-L6-v2`, 384-dim) for all content. Code snippets and prose text have fundamentally different semantic properties — variable names, syntax patterns, and structural relationships in code are poorly captured by a general-purpose sentence embeddings model. This leads to suboptimal recall when searching for code-related memories.

### Goal

Route content to the optimal embedding model automatically based on content analysis:
- **Prose content** → current `all-MiniLM-L6-v2` (general-purpose sentence transformer)
- **Code content** → a code-optimized ONNX model (e.g., `all-MiniLM-L6-v2` fine-tuned for code, or a dedicated code search model)

Detection is automatic — no user action required. The system analyzes content at store time and selects the appropriate model.

### Success Metrics

- Code-related recall queries return more relevant results (10-30% improvement in retrieval accuracy for code memories)
- No regression in prose recall quality
- Content detection accuracy ≥ 90% on mixed code/prose workloads
- Embedding latency increase ≤ 10ms per operation (model is pre-loaded)
- Zero breaking changes to existing memories

### Scope

**In scope:**
- Content type detection (code vs prose) via heuristics
- Dual ONNX model loading and routing
- Model tracking per memory (which model produced the embedding)
- Search routing: query embedded with both models, results merged
- Migration strategy for existing memories (re-embedding optional, not required)
- Local mode (SQLite + `LocalEmbedder`)
- Server mode (`ServerEmbedder` + Postgres/pgvector)

**Out of scope:**
- API-based embedding models (all models must be local ONNX)
- User-selectable model override (future enhancement)
- More than two model categories (e.g., no separate "math" model)
- Automatic re-embedding of existing memories (can be a follow-up)

### User Stories Summary

| # | Story | Priority |
|---|-------|----------|
| 1 | Content type detector | P0 |
| 2 | Model registry and dual model loading | P0 |
| 3 | Embedding routing at store time | P0 |
| 4 | Search routing and result merging | P0 |
| 5 | Schema migration (embed_model tracking) | P0 |
| 6 | Server-side dual embedding support | P1 |

---

## 2. Architecture

### Current State

```
Content → LocalEmbedder.embed() → all-MiniLM-L6-v2 (384-dim) → BLOB/vector(384)
                                                                      ↓
Query   → LocalEmbedder.embed() → all-MiniLM-L6-v2 (384-dim) → cosine similarity search
```

**Key files:**
- `src/lore/embed/base.py` — `Embedder` ABC: `embed(text) → List[float]`, `embed_batch(texts) → List[List[float]]`
- `src/lore/embed/local.py` — `LocalEmbedder`: ONNX inference, downloads model to `~/.lore/models/all-MiniLM-L6-v2/`
- `src/lore/embed/__init__.py` — exports `Embedder`, `LocalEmbedder`
- `src/lore/server/embed.py` — `ServerEmbedder`: singleton ONNX embedder for server mode
- `src/lore/lore.py` — `Lore` class: calls `self._embedder.embed(content)` at store time and search time
- `src/lore/mcp/server.py` — MCP server: uses `LocalEmbedder` for local mode, `RemoteStore` for remote
- `src/lore/memory_store/sqlite.py` — `SqliteStore`: embedding stored as BLOB, cosine similarity search in Python
- `src/lore/server/store.py` — `ServerStore`: Postgres with `vector(384)` column, pgvector cosine search
- `src/lore/types.py` — `Memory` dataclass: `embedding: Optional[bytes]`

**Embedding dimension:** 384 (hardcoded as `_EMBEDDING_DIM` in multiple files)

**Storage format:**
- SQLite: `embedding BLOB` — serialized `float32` array, dimension-agnostic
- Postgres: `embedding vector(384)` — fixed dimension, requires migration for variable dims

### Target State

```
Content → ContentDetector.detect(text) → "code" | "prose"
                                              ↓
        → EmbeddingRouter.embed(text) → selects model → embed → store with embed_model tag
                                                                      ↓
Query   → EmbeddingRouter.embed_for_search(query) → embed with BOTH models
        → search code-embedded memories with code query vector
        → search prose-embedded memories with prose query vector
        → merge and rank results
```

### Design Decisions

#### D1: Embedding Dimension Strategy — Same Dimension (384)

**Decision:** Constrain both models to 384 dimensions.

**Rationale:**
- Postgres `vector(384)` column works unchanged — no schema migration for dimension
- SQLite BLOB is already dimension-agnostic, but consistent dimensions simplify search
- `all-MiniLM-L6-v2` is already 384-dim for prose
- For code: use a 384-dim code model (e.g., `sentence-transformers/all-MiniLM-L6-v2` retrained on code, or a custom ONNX model projected to 384-dim)
- Avoids needing separate vector columns or variable-dimension support in pgvector

**Fallback:** If no suitable 384-dim code model exists, we can:
1. Use a 768-dim model and add a linear projection layer to 384
2. Add a second `embedding_code vector(768)` column to Postgres (more complex)

#### D2: Model Tracking — `embed_model` in Memory metadata

**Decision:** Store the model identifier in `memory.metadata["embed_model"]` rather than adding a new DB column.

**Rationale:**
- `metadata` is already a JSONB/JSON field in both SQLite and Postgres
- No schema migration needed
- Existing memories without this field are implicitly `"prose"` (current model)
- Easy to query: `metadata->>'embed_model'` in Postgres, JSON parse in SQLite

**Values:** `"prose"` (default/legacy), `"code"`

#### D3: Search Strategy — Dual Query with Merged Results

**Decision:** At search time, embed the query with both models, search each subset, merge by normalized score.

**Rationale:**
- Search queries are typically natural language ("how to implement binary search"), even when looking for code
- Code-trained models often support natural-language-to-code search (asymmetric)
- Searching both spaces ensures no memories are missed
- Score normalization ensures fair ranking across model spaces

**Algorithm:**
1. Embed query with prose model → `q_prose`
2. Embed query with code model → `q_code`
3. Search memories where `embed_model = "prose"` using `q_prose`
4. Search memories where `embed_model = "code"` using `q_code`
5. Merge results, sort by score, return top-k

#### D4: Content Detection — Heuristic Scoring

**Decision:** Use a weighted heuristic scoring system, not ML-based classification.

**Rationale:**
- No additional model dependency
- Fast (< 1ms)
- Transparent and debuggable
- Sufficient accuracy for the code-vs-prose binary distinction

**Heuristics (scored 0-1, weighted sum):**

| Signal | Weight | Detection |
|--------|--------|-----------|
| Code fence markers | 0.30 | Content contains triple backticks or is wrapped in code fences |
| Bracket/brace density | 0.20 | Ratio of `{}()[]<>` to total characters exceeds threshold |
| Code keyword presence | 0.20 | Contains `def `, `class `, `function `, `const `, `import `, `return `, `=>`, `->` etc. |
| Indentation pattern | 0.15 | Consistent 2/4-space or tab indentation on ≥3 lines |
| Line-ending patterns | 0.10 | Semicolons, braces at line ends |
| Special char ratio | 0.05 | Ratio of `=`, `;`, `{`, `}`, `(`, `)` to alphanumeric |

**Threshold:** Score ≥ 0.40 → classified as code

### New/Modified Components

#### New: `src/lore/embed/detector.py` — ContentDetector

```python
class ContentDetector:
    """Detect whether content is code or prose."""

    def detect(self, text: str) -> str:
        """Returns 'code' or 'prose'."""
```

Pure function, no state. Heuristic scoring as described in D4.

#### New: `src/lore/embed/router.py` — EmbeddingRouter

```python
class EmbeddingRouter(Embedder):
    """Routes content to the appropriate embedding model."""

    def __init__(self, prose_embedder: Embedder, code_embedder: Embedder,
                 detector: ContentDetector):
        ...

    def embed(self, text: str) -> List[float]:
        """Detect content type and embed with appropriate model."""

    def embed_with_model(self, text: str) -> tuple[List[float], str]:
        """Returns (embedding, model_name) for store-time tracking."""

    def embed_for_search(self, query: str) -> dict[str, List[float]]:
        """Returns {"prose": [...], "code": [...]} for search routing."""
```

Implements `Embedder` interface for backward compatibility. Also exposes `embed_with_model()` for callers that need to track which model was used.

#### Modified: `src/lore/embed/local.py` — LocalEmbedder

Add support for configurable model name/path. The current class is already parameterized by `model_dir`, but the model name is hardcoded. Generalize to accept model name and HuggingFace URL.

```python
class LocalEmbedder(Embedder):
    def __init__(self, model_name: str = "all-MiniLM-L6-v2",
                 model_dir: Optional[str] = None):
```

#### Modified: `src/lore/lore.py` — Lore class

- Use `EmbeddingRouter` instead of plain `LocalEmbedder` (when no custom embedder is provided)
- At store time: call `embed_with_model()`, save `embed_model` in metadata
- At search time: call `embed_for_search()`, run dual search, merge results

#### Modified: `src/lore/mcp/server.py` — MCP server

- Initialize `EmbeddingRouter` in `_get_embedder()`
- In `remember()`: use `embed_with_model()`, store model name in metadata
- In `recall()`: use `embed_for_search()`, run dual searches, merge

#### Modified: `src/lore/memory_store/sqlite.py` — SqliteStore

- Add `embed_model` filter to `search()` to search only matching memories
- New signature: `search(embedding, embed_model=None, ...)`

#### Modified: `src/lore/server/embed.py` — ServerEmbedder

- Support dual model loading (prose + code)
- Expose `embed_with_model()` and `embed_for_search()` methods

#### Modified: `src/lore/server/store.py` — ServerStore

- Add `embed_model` filter to search query (filter on `metadata->>'embed_model'`)

### Model Selection

**Prose model:** `sentence-transformers/all-MiniLM-L6-v2` (current, 384-dim, ~90MB ONNX)

**Code model candidates (384-dim, ONNX-exportable):**

| Model | Dim | Notes |
|-------|-----|-------|
| `sentence-transformers/all-MiniLM-L6-v2` | 384 | Same model, baseline — no improvement but validates routing |
| `flax-sentence-embeddings/all_datasets_v4_MiniLM-L6` | 384 | Trained on more diverse data including code |
| Custom fine-tune of MiniLM-L6-v2 on CodeSearchNet | 384 | Best option if we invest in training |

**Recommendation:** Start with `all_datasets_v4_MiniLM-L6` as the code model. If retrieval improvement is insufficient, invest in a CodeSearchNet fine-tune of MiniLM-L6. The architecture supports swapping models without code changes.

**Environment variable:** `LORE_CODE_MODEL` to override the default code model name.

### Data Flow: Remember (Store)

```
1. User calls remember(content="def fibonacci(n): ...")
2. Lore.__init__ has created EmbeddingRouter with prose + code embedders
3. EmbeddingRouter.embed_with_model(content):
   a. ContentDetector.detect(content) → "code"
   b. code_embedder.embed(content) → [0.12, -0.34, ...]
   c. return (embedding, "code")
4. Lore stores memory with metadata={"embed_model": "code"} + embedding bytes
5. SqliteStore.save() persists as usual
```

### Data Flow: Recall (Search)

```
1. User calls recall(query="fibonacci implementation")
2. EmbeddingRouter.embed_for_search(query):
   a. prose_embedder.embed(query) → q_prose
   b. code_embedder.embed(query) → q_code
   c. return {"prose": q_prose, "code": q_code}
3. SqliteStore.search(q_prose, embed_model="prose", limit=limit) → prose_results
4. SqliteStore.search(q_code, embed_model="code", limit=limit) → code_results
5. Merge prose_results + code_results, sort by score, return top-k
```

### Backward Compatibility

- **Existing memories** (no `embed_model` in metadata): treated as `"prose"` — searched with prose model query vector
- **Custom embedder users** (`embedding_fn` or `embedder` param in Lore): bypass routing entirely, behave as today
- **Remote mode** (`LORE_STORE=remote`): embedding happens server-side; routing is handled by `ServerEmbedder`
- **Embedder ABC**: `EmbeddingRouter` implements `Embedder`, so any code using the interface works unchanged

### Risks

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| No good 384-dim code model exists | Medium | High | Use same model initially; add projection layer later |
| Code detection false positives (prose classified as code) | Low | Medium | Conservative threshold (0.40); test with real Lore memories |
| Search latency doubles (2x embed calls) | Medium | Low | Both models are small (~90MB); parallel embed possible |
| Existing memories return lower scores | Low | High | Legacy memories are searched with prose model (unchanged behavior) |

---

## 3. Stories with Acceptance Criteria

### Story 1: Content Type Detector

**As a** Lore developer,
**I want** a content type detector that classifies text as "code" or "prose",
**so that** the system can route content to the appropriate embedding model.

#### Acceptance Criteria

- [ ] **AC1.1**: `ContentDetector` class exists in `src/lore/embed/detector.py`
- [ ] **AC1.2**: `detect(text: str) -> str` returns `"code"` or `"prose"`
- [ ] **AC1.3**: Correctly classifies Python function definitions as code (e.g., `def foo(): return 42`)
- [ ] **AC1.4**: Correctly classifies JavaScript/TypeScript code as code (e.g., `const x = () => {}`)
- [ ] **AC1.5**: Correctly classifies natural language text as prose (e.g., `"The API rate limit is 100 req/min"`)
- [ ] **AC1.6**: Correctly classifies markdown with code fences — the code block content is "code", surrounding text is "prose" (for mixed content, classify by dominant type)
- [ ] **AC1.7**: Empty string and very short strings (< 10 chars) default to `"prose"`
- [ ] **AC1.8**: Detection completes in < 1ms for typical content (< 5KB)
- [ ] **AC1.9**: Unit tests cover ≥ 15 diverse content samples (Python, JS, Go, Rust, SQL, shell, plain English, markdown, mixed)
- [ ] **AC1.10**: Accuracy ≥ 90% on test corpus

**Estimate:** S (small)

---

### Story 2: Generalize LocalEmbedder for Multiple Models

**As a** Lore developer,
**I want** `LocalEmbedder` to support configurable model names,
**so that** different ONNX models can be loaded for code vs. prose embedding.

#### Acceptance Criteria

- [ ] **AC2.1**: `LocalEmbedder.__init__` accepts `model_name: str` parameter (default: `"all-MiniLM-L6-v2"`)
- [ ] **AC2.2**: Model files are downloaded to `~/.lore/models/{model_name}/`
- [ ] **AC2.3**: HuggingFace base URL is configurable or derived from model name
- [ ] **AC2.4**: Two `LocalEmbedder` instances with different models can coexist (no global state conflicts)
- [ ] **AC2.5**: Existing tests pass unchanged (default model name preserves behavior)
- [ ] **AC2.6**: New test: instantiate with a different model name, verify it downloads to the correct directory
- [ ] **AC2.7**: `_EMBEDDING_DIM` is read from model output rather than hardcoded (or validated at load time)

**Estimate:** S (small)

---

### Story 3: Embedding Router

**As a** Lore developer,
**I want** an `EmbeddingRouter` that routes content to the correct embedding model,
**so that** code and prose are embedded with their optimal models.

#### Acceptance Criteria

- [ ] **AC3.1**: `EmbeddingRouter` class exists in `src/lore/embed/router.py`
- [ ] **AC3.2**: Implements `Embedder` interface (`embed()`, `embed_batch()`)
- [ ] **AC3.3**: `embed(text)` uses `ContentDetector` to select the model, returns embedding
- [ ] **AC3.4**: `embed_with_model(text) -> tuple[List[float], str]` returns embedding + model name
- [ ] **AC3.5**: `embed_for_search(query) -> dict[str, List[float]]` returns embeddings from both models
- [ ] **AC3.6**: Constructor accepts `prose_embedder`, `code_embedder`, and `detector`
- [ ] **AC3.7**: If `code_embedder` is `None`, falls back to `prose_embedder` for all content (graceful degradation)
- [ ] **AC3.8**: Unit tests with mock embedders verify routing logic
- [ ] **AC3.9**: `EmbeddingRouter` is exported from `src/lore/embed/__init__.py`

**Estimate:** M (medium)

---

### Story 4: Schema — Track embed_model per Memory

**As a** Lore developer,
**I want** each memory to track which embedding model was used,
**so that** search queries use the matching model for similarity comparison.

#### Acceptance Criteria

- [ ] **AC4.1**: `remember()` in `Lore` class stores `embed_model` in `memory.metadata`
- [ ] **AC4.2**: `remember()` in MCP server stores `embed_model` in metadata
- [ ] **AC4.3**: Memories without `embed_model` in metadata are treated as `"prose"` (backward compat)
- [ ] **AC4.4**: `SqliteStore.search()` accepts optional `embed_model` filter parameter
- [ ] **AC4.5**: When `embed_model` filter is provided, only memories matching that model are searched
- [ ] **AC4.6**: Existing memories (no `embed_model`) match the `"prose"` filter
- [ ] **AC4.7**: Server-side `ServerStore.search()` supports `embed_model` filter via metadata JSONB query
- [ ] **AC4.8**: No database schema migration required (uses existing `metadata` column)

**Estimate:** M (medium)

---

### Story 5: Integrate Dual Embedding into Lore SDK

**As a** Lore SDK user,
**I want** `remember()` and `recall()` to automatically use the best embedding model for my content,
**so that** code memories are more accurately retrieved.

#### Acceptance Criteria

- [ ] **AC5.1**: `Lore()` default constructor creates an `EmbeddingRouter` with prose + code embedders
- [ ] **AC5.2**: `Lore(embedder=custom)` or `Lore(embedding_fn=fn)` bypasses routing (backward compat)
- [ ] **AC5.3**: `remember(content="def foo(): ...")` stores with `metadata.embed_model = "code"`
- [ ] **AC5.4**: `remember(content="The API rate limit is...")` stores with `metadata.embed_model = "prose"`
- [ ] **AC5.5**: `recall(query)` searches both code and prose memory spaces and returns merged results
- [ ] **AC5.6**: Results are sorted by score across both model spaces
- [ ] **AC5.7**: `LORE_CODE_MODEL` env var overrides the default code model name
- [ ] **AC5.8**: If code model fails to download/load, gracefully falls back to prose model only (no crash)
- [ ] **AC5.9**: Integration test: store 5 code memories + 5 prose memories, recall with code query, verify code memories rank higher
- [ ] **AC5.10**: Integration test: store 5 code memories + 5 prose memories, recall with prose query, verify prose memories rank higher

**Estimate:** L (large)

---

### Story 6: Integrate Dual Embedding into MCP Server

**As a** MCP client (Claude Code, etc.),
**I want** the Lore MCP server to automatically route embeddings,
**so that** code snippets saved via MCP are retrieved more accurately.

#### Acceptance Criteria

- [ ] **AC6.1**: `_get_embedder()` in MCP server returns an `EmbeddingRouter`
- [ ] **AC6.2**: `remember` tool stores `embed_model` in memory metadata
- [ ] **AC6.3**: `recall` tool searches both model spaces and merges results
- [ ] **AC6.4**: Existing MCP tool signatures are unchanged (no breaking changes)
- [ ] **AC6.5**: `LORE_CODE_MODEL` env var is respected
- [ ] **AC6.6**: If code model is unavailable, MCP server starts and works with prose model only
- [ ] **AC6.7**: Test: MCP remember + recall round-trip with code content

**Estimate:** M (medium)

---

### Story 7: Server-Side Dual Embedding (ServerEmbedder)

**As a** Lore Cloud operator,
**I want** the server-side `ServerEmbedder` to support dual embedding,
**so that** hosted Lore instances benefit from code-optimized retrieval.

#### Acceptance Criteria

- [ ] **AC7.1**: `ServerEmbedder` loads both prose and code ONNX models
- [ ] **AC7.2**: `embed_with_model(text) -> tuple[Optional[List[float]], str]` routes based on content detection
- [ ] **AC7.3**: `embed_for_search(query) -> dict[str, Optional[List[float]]]` returns both embeddings
- [ ] **AC7.4**: `ServerStore.search()` supports `embed_model` filter via `metadata->>'embed_model'`
- [ ] **AC7.5**: REST API `/memories` POST includes `embed_model` in response
- [ ] **AC7.6**: REST API `/memories/search` performs dual-space search
- [ ] **AC7.7**: Graceful fallback: if code model fails, embed everything with prose model

**Estimate:** M (medium)

---

### Implementation Order

```
Story 1 (Detector) ──→ Story 3 (Router) ──→ Story 5 (SDK Integration)
                                          ↘
Story 2 (LocalEmbedder) ─────────────────→ Story 6 (MCP Integration)
                                          ↘
Story 4 (Schema/Tracking) ───────────────→ Story 7 (Server Integration)
```

Stories 1, 2, and 4 can be developed in parallel. Story 3 depends on 1 and 2. Stories 5, 6, 7 depend on 3 and 4.
