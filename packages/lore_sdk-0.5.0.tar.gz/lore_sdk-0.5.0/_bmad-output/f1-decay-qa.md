# F1 — Semantic Decay Scoring: QA Review

**Verdict: PASS**

**Commit:** ba25478
**Reviewer:** QA-OPUS
**Date:** 2026-03-04

---

## 1. Plan Conformance

### Story 1: Replace Global Decay with Half-Life Model

| Acceptance Criterion | Status | Evidence |
|---|---|---|
| `_DECAY_LAMBDA` removed | PASS | Removed along with `import math` |
| Constants: code=14, note=21, lesson=30, convention=60 | PASS | `sqlite.py:36-42` — `_DEFAULT_HALF_LIVES` dict |
| Default half-life = 21 for unknown types | PASS | `sqlite.py:43` — `_DEFAULT_HALF_LIFE = 21.0` |
| Formula: `0.7 * cosine + 0.3 * (0.5 ^ (age / half_life))` | PASS | `sqlite.py:174` — exact match |
| Weights: semantic=0.7, temporal=0.3 | PASS | `sqlite.py:44-45` — module-level constants |
| Existing tests in `test_lore_sqlite_store.py` pass | PASS | All 21 tests pass |

### Story 2: Unit Tests for Decay Scoring

| Test | Status |
|---|---|
| `test_newer_memory_scores_higher` | PASS |
| `test_type_specific_half_lives` | PASS |
| `test_half_life_score_at_one_half_life` | PASS |
| `test_zero_age_temporal_score` | PASS |
| `test_unknown_type_uses_default_half_life` | PASS |
| `test_score_never_negative` | PASS |

All 6 tests use controlled timestamps (`_ts_ago`) — deterministic. Embeddings are known constant values.

### Story 3: Existing Search Tests

| Criterion | Status |
|---|---|
| All tests in `test_lore_sqlite_store.py` pass | PASS |
| No tests deleted | PASS — file unchanged; assertions use `score >= 0` which remains valid |

### Story 4: Integration Test

| Criterion | Status | Evidence |
|---|---|---|
| Decay ranking through SDK `recall()` | PASS | `test_e2e_integration.py::TestDecayAwareRecall` |
| Self-contained (temp DB, no side effects) | PASS | Uses `local_db` fixture |

---

## 2. Test Results

```
tests/test_decay_scoring.py         6 passed
tests/test_e2e_integration.py      15 passed
tests/test_lore_sqlite_store.py    21 passed
────────────────────────────────────────────
Total F1-relevant:                 42 passed, 0 failed
```

Full suite (excluding pre-existing broken tests from other in-progress features): **408 passed, 15 skipped, 0 F1-related failures**. All 11 failures are from unrelated feature branches (dual_embedding, freshness, mcp_security).

---

## 3. Edge Case Analysis

| Case | Handled? | Notes |
|---|---|---|
| Zero age | YES | `test_zero_age_temporal_score` — `0.5^0 = 1.0`, score ≈ 1.0 |
| Very old (10000 days) | YES | `test_score_never_negative` — temporal→~0, `max(score, 0.0)` guard |
| Unknown types | YES | `test_unknown_type_uses_default_half_life` — falls back to 21d |
| Negative age (future-dated) | NOT TESTED | `0.5 ** (neg/pos)` → temporal > 1.0. Low risk: future-dated memories are not a normal code path. Old formula also misbehaved here — not a regression. |

---

## 4. Code Quality

- Clean diff: +17 lines, −5 removed (net +12 in sqlite.py)
- `import math` correctly removed (was only used for `math.exp`)
- Formula is clear and matches plan exactly
- `max(score, 0.0)` prevents negative scores
- `round(..., 6)` maintains existing precision behavior
- No new dependencies

---

## 5. Observations (Non-blocking)

1. **Future-dated memories**: If `age_days < 0`, temporal_score exceeds 1.0 (e.g., 1 day in future → `0.5^(-1/21) ≈ 1.034`). Low risk, not a regression. Could clamp with `age_days = max(age_days, 0.0)` in a future story.

2. **No explicit `lesson` type test**: Tests cover code, note, convention, and unknown. The `lesson` type uses the same `dict.get()` lookup so is implicitly covered.

3. **Server store divergence**: If a server-side store exists with the old decay model, it would need a separate update. Plan correctly scopes F1 to `SqliteStore` only.

---

## Verdict: PASS

All 4 stories' acceptance criteria are met. All 42 F1-relevant tests pass. No regressions detected. Implementation matches plan exactly.
