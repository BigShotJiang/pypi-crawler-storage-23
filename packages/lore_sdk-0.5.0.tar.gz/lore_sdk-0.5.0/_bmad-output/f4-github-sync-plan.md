# F4 — GitHub Sync

## 1. PRD

### Problem

Developers accumulate valuable context in GitHub — decisions captured in PR descriptions, bug reports in issues, architectural changes in commit messages, and milestone notes in releases. This knowledge is fragmented across GitHub's UI and unsearchable by meaning. When an AI agent needs to know "why did we switch from Redis to PostgreSQL?" or "what broke in the auth system last month?", it can't find the answer even though the information exists in the repo history.

### Solution

Add a `lore github-sync` CLI command that ingests GitHub repository data (PRs, issues, commits, releases) into Lore memories, making them searchable via `lore recall` with semantic similarity.

### User

- Developers using Lore as their AI memory layer who want repository context available to AI agents
- Teams wanting to make institutional knowledge in GitHub searchable by meaning

### Goals

1. **One command to ingest** — `lore github-sync --repo owner/repo` fetches PRs, issues, commits, and releases and stores them as Lore memories
2. **Incremental sync** — re-running the command only fetches new/updated items since last sync
3. **Semantically searchable** — all ingested items are embedded and retrievable via `lore recall`
4. **Filterable by type** — users can search only PRs, only issues, etc. using existing `--type` filters
5. **MCP-accessible** — an MCP tool `github_sync` lets AI agents trigger syncs directly

### Non-Goals (v1)

- Real-time webhooks / streaming sync
- GitHub Actions integration
- Code blob / file content ingestion
- PR diffs or PR review comments (future types)
- Issue comments as separate memories (they're included in issue body context)
- GitHub Enterprise Server support (only github.com via `gh` CLI)
- Write operations (creating issues, commenting)

### Success Metrics

- Sync 1000 items in < 60 seconds (excluding embedding time)
- Incremental sync (no new items) completes in < 5 seconds
- Recall accuracy: searching "authentication bug" finds relevant issues/PRs about auth bugs

### Risks

| Risk | Mitigation |
|------|------------|
| GitHub API rate limiting (5000 req/hr authenticated) | Batch requests, respect rate limit headers, paginate efficiently |
| Large repos with 10k+ items | `--since` flag, `--types` filter, pagination with progress output |
| `gh` CLI not installed or not authenticated | Detect at startup, provide clear error message with install instructions |
| Embedding large volumes is slow | Use `embed_batch()` (already supports batching), show progress |

---

## 2. Architecture

### 2.1 CLI Command

```
lore github-sync --repo owner/repo [--since DATE] [--types pr,issue,commit,release] [--json]
```

| Flag | Default | Description |
|------|---------|-------------|
| `--repo` | required | GitHub repo in `owner/repo` format |
| `--since` | last sync timestamp (or 30 days) | ISO date or relative (e.g. `2024-01-01`, `30d`) |
| `--types` | `pr,issue,commit,release` | Comma-separated content types to sync |
| `--json` | false | JSON output for scripting |

Registered in `cli.py:build_parser()` as a new subcommand, handled by `cmd_github_sync()`.

### 2.2 Module Structure

```
src/lore/
  github/
    __init__.py          # Public API: sync_repo()
    fetcher.py           # GitHub data fetching via `gh` CLI
    formatter.py         # Transforms GitHub objects → memory content strings
    sync.py              # Orchestrator: fetch → deduplicate → format → store
    types.py             # GitHubItem dataclass, SyncState, SyncResult
```

### 2.3 Data Fetching Strategy

Use the `gh` CLI (already required to be installed and authenticated) via `subprocess.run()`:

```python
# PRs (most recent first, paginated)
gh pr list --repo owner/repo --state all --json number,title,body,labels,state,author,url,createdAt,updatedAt,mergedAt --limit 100

# Issues (excluding PRs)
gh issue list --repo owner/repo --state all --json number,title,body,labels,state,author,url,createdAt,updatedAt --limit 100

# Commits
gh api repos/owner/repo/commits --paginate -q '.[] | {sha,message: .commit.message,author: .commit.author.name,date: .commit.author.date,url: .html_url}'

# Releases
gh release list --repo owner/repo --json tagName,name,body,author,createdAt,url,isDraft,isPrerelease
```

**Why `gh` CLI over raw httpx:**
- Already authenticated (no token management)
- Handles pagination with `--paginate`
- JSON output built-in
- Installed prerequisite for most developers

**Fallback:** If `gh` is not available, raise a clear error:
```
Error: GitHub CLI (gh) is required. Install: https://cli.github.com/
Authenticate: gh auth login
```

### 2.4 Memory Schema

Each GitHub item becomes one Lore memory with a structured type and metadata:

| GitHub Type | `memory.type` | `memory.source` | Key Metadata |
|-------------|---------------|------------------|--------------|
| Pull Request | `github_pr` | `github:owner/repo` | `url`, `number`, `state`, `author`, `labels` |
| Issue | `github_issue` | `github:owner/repo` | `url`, `number`, `state`, `author`, `labels` |
| Commit | `github_commit` | `github:owner/repo` | `url`, `sha`, `author` |
| Release | `github_release` | `github:owner/repo` | `url`, `tag`, `author`, `is_prerelease` |

**Content formatting** (what gets embedded):

```python
# PR
f"PR #{number}: {title}\nState: {state}\nLabels: {labels}\n\n{body}"

# Issue
f"Issue #{number}: {title}\nState: {state}\nLabels: {labels}\n\n{body}"

# Commit
f"Commit {sha[:8]}: {message}"

# Release
f"Release {tag}: {name}\n\n{body}"
```

Content is truncated to ~2000 chars to stay within embedding model's effective range (256 tokens ~ 1000 chars, but we keep extra for recall display).

**Tags:** Auto-generated from labels (PRs/issues) + content type tag (e.g., `["github", "pr"]`).

**Project:** Set to `--project` flag value or defaults to `owner/repo` as the project scope.

### 2.5 Incremental Sync

Track sync state in SQLite metadata table (co-located in the same Lore DB):

```sql
CREATE TABLE IF NOT EXISTS github_sync_state (
    repo        TEXT NOT NULL,
    item_type   TEXT NOT NULL,      -- 'pr', 'issue', 'commit', 'release'
    last_synced TEXT NOT NULL,      -- ISO timestamp of last successful sync
    last_id     TEXT,               -- Last item ID/number processed
    PRIMARY KEY (repo, item_type)
);
```

On subsequent syncs:
1. Read `last_synced` for the repo+type
2. Filter API results to `updatedAt > last_synced` (or `since` for commits)
3. Use `INSERT OR REPLACE` to upsert memories (using deterministic IDs like `github:owner/repo:pr:123`)
4. Update `last_synced` after successful sync

**Deterministic memory IDs:** Instead of random ULIDs, generate deterministic IDs for GitHub items so re-syncing the same item updates rather than duplicates:
```python
memory_id = f"gh:{repo}:{type}:{number_or_sha}"
```

### 2.6 MCP Tool

Add a `github_sync` tool to `mcp/server.py`:

```python
@mcp.tool(description="Sync GitHub repository data into Lore memories...")
def github_sync(
    repo: str,               # owner/repo
    types: str = "pr,issue,commit,release",
    since: Optional[str] = None,
) -> str:
    """Sync GitHub repo data into Lore for semantic search."""
```

No separate `github_search` tool needed — the existing `recall` tool with `type="github_pr"` etc. already handles filtered search.

### 2.7 Batch Embedding

For efficiency, embed items in batches using `LocalEmbedder.embed_batch()`:

```python
# Batch size of 32 (MiniLM handles this well)
for batch in chunked(items, 32):
    texts = [item.content for item in batch]
    embeddings = embedder.embed_batch(texts)
    for item, emb in zip(batch, embeddings):
        memory = Memory(id=item.memory_id, content=item.content, embedding=serialize(emb), ...)
        store.save(memory)
```

### 2.8 Dependencies

No new dependencies required:
- `subprocess` (stdlib) for `gh` CLI calls
- `json` (stdlib) for parsing `gh` output
- Existing `Lore` SDK for storage and embedding

### 2.9 Error Handling

- `gh` not installed → `LoreGitHubError("GitHub CLI (gh) not found. Install: https://cli.github.com/")`
- `gh` not authenticated → detect from stderr, raise with `gh auth login` instructions
- API rate limit → parse `gh` error, suggest `--since` to reduce scope
- Network errors → retry once, then fail with clear message
- Individual item failures → log warning, continue with remaining items, report count at end

---

## 3. Stories with Acceptance Criteria

### Epic: GitHub Sync

---

### Story 1: GitHub Data Fetcher

**As a** developer, **I want** a module that fetches PRs, issues, commits, and releases from a GitHub repo via the `gh` CLI, **so that** I can ingest repository data into Lore.

**Files to create/modify:**
- `src/lore/github/__init__.py`
- `src/lore/github/types.py`
- `src/lore/github/fetcher.py`
- `tests/test_github_fetcher.py`

**Acceptance Criteria:**

- [ ] `GitHubItem` dataclass defined with fields: `kind` (pr/issue/commit/release), `number_or_sha`, `title`, `body`, `author`, `url`, `state`, `labels`, `created_at`, `updated_at`
- [ ] `SyncResult` dataclass defined with fields: `synced` (int), `skipped` (int), `errors` (int), `duration_seconds` (float)
- [ ] `fetch_prs(repo, since=None) -> List[GitHubItem]` calls `gh pr list` with JSON output, parses results
- [ ] `fetch_issues(repo, since=None) -> List[GitHubItem]` calls `gh issue list`, excludes PRs
- [ ] `fetch_commits(repo, since=None) -> List[GitHubItem]` calls `gh api` for commits
- [ ] `fetch_releases(repo) -> List[GitHubItem]` calls `gh release list`
- [ ] All fetchers handle pagination (up to 1000 items per type)
- [ ] Raises `LoreGitHubError` if `gh` is not installed (checked via `shutil.which("gh")`)
- [ ] Raises `LoreGitHubError` if `gh` is not authenticated (detected from subprocess stderr)
- [ ] Tests mock `subprocess.run` and verify correct `gh` commands and JSON parsing
- [ ] Tests cover error cases: `gh` not found, auth failure, empty results, malformed JSON

---

### Story 2: Content Formatter

**As a** developer, **I want** GitHub items formatted into rich, searchable text content, **so that** semantic search finds relevant results.

**Files to create/modify:**
- `src/lore/github/formatter.py`
- `tests/test_github_formatter.py`

**Acceptance Criteria:**

- [ ] `format_content(item: GitHubItem) -> str` produces human-readable text for each item type:
  - PR: `"PR #123: Title\nState: merged\nLabels: bug, auth\n\nBody text..."`
  - Issue: `"Issue #456: Title\nState: open\nLabels: enhancement\n\nBody text..."`
  - Commit: `"Commit abc12345: Full commit message"`
  - Release: `"Release v1.2.0: Release Name\n\nRelease body..."`
- [ ] Content truncated to 2000 characters max (with `...` suffix if truncated)
- [ ] `None`/empty body handled gracefully (no `None` in output)
- [ ] `generate_tags(item: GitHubItem) -> List[str]` returns `["github", item.kind]` plus label names
- [ ] `generate_memory_id(repo: str, item: GitHubItem) -> str` returns deterministic ID like `gh:owner/repo:pr:123`
- [ ] `generate_metadata(repo: str, item: GitHubItem) -> Dict` returns structured metadata with url, number/sha, state, author, labels
- [ ] Tests verify all 4 content type formats
- [ ] Tests verify truncation behavior
- [ ] Tests verify deterministic ID generation

---

### Story 3: Sync Orchestrator with Incremental State

**As a** developer, **I want** a sync engine that coordinates fetching, formatting, embedding, and storing GitHub items with incremental state tracking, **so that** re-syncing is fast and doesn't create duplicates.

**Files to create/modify:**
- `src/lore/github/sync.py`
- `src/lore/memory_store/sqlite.py` (add sync state table)
- `tests/test_github_sync.py`

**Acceptance Criteria:**

- [ ] `sync_repo(repo, types=None, since=None, db_path=None, project=None) -> SyncResult` orchestrates the full sync
- [ ] Creates `github_sync_state` table in the Lore SQLite DB on first use
- [ ] Reads last sync timestamp from state table; uses it as `since` if no explicit `--since` given
- [ ] Default `since` for first sync: 30 days ago
- [ ] Calls appropriate fetchers for requested types
- [ ] Formats each item into Memory content using formatter
- [ ] Embeds content in batches of 32 using `LocalEmbedder.embed_batch()`
- [ ] Stores memories with deterministic IDs (upsert via `INSERT OR REPLACE`)
- [ ] Updates `github_sync_state` with new timestamp after successful sync per type
- [ ] Returns `SyncResult` with counts: synced, skipped, errors
- [ ] Logs progress: `"Syncing PRs... 47 items"`, `"Syncing issues... 23 items"`
- [ ] Handles partial failures: if one item fails to embed/store, continues with rest
- [ ] Tests use mocked fetcher and embedder; verify memories are stored correctly
- [ ] Tests verify incremental behavior: second sync with no new items stores nothing new
- [ ] Tests verify deterministic IDs prevent duplicates

---

### Story 4: CLI Command

**As a** developer, **I want** to run `lore github-sync --repo owner/repo` from the terminal, **so that** I can ingest my repository into Lore.

**Files to modify:**
- `src/lore/cli.py`
- `tests/test_cli_github_sync.py`

**Acceptance Criteria:**

- [ ] `github-sync` subcommand registered in `build_parser()` with arguments:
  - `--repo` (required): `owner/repo` format
  - `--since` (optional): ISO date or relative like `30d`, `90d`
  - `--types` (optional, default `pr,issue,commit,release`): comma-separated
  - `--json` (optional): JSON output mode
- [ ] `cmd_github_sync(args)` calls `sync_repo()` and prints results
- [ ] Human-readable output: `"Synced 47 PRs, 23 issues, 156 commits, 5 releases (12.3s)"`
- [ ] JSON output: `{"synced": 231, "skipped": 0, "errors": 0, "duration": 12.3, "by_type": {...}}`
- [ ] `--since` accepts ISO dates (`2024-01-01`) and relative formats (`30d`, `90d`)
- [ ] Validates `--repo` format (must contain exactly one `/`)
- [ ] Shows error and usage hint if `--repo` is missing
- [ ] Global `--db` and `--project` flags work as expected
- [ ] Tests verify argument parsing, output formatting, and error messages
- [ ] Tests mock `sync_repo()` to avoid actual GitHub calls

---

### Story 5: MCP Tool

**As an** AI agent, **I want** an MCP tool to trigger GitHub sync, **so that** I can ingest repository context without the user leaving the chat.

**Files to modify:**
- `src/lore/mcp/server.py`
- `tests/test_lore_mcp.py`

**Acceptance Criteria:**

- [ ] `github_sync` MCP tool registered with description explaining usage
- [ ] Parameters: `repo` (required str), `types` (optional str, default "pr,issue,commit,release"), `since` (optional str)
- [ ] Tool calls `sync_repo()` from `lore.github.sync`
- [ ] Returns human-readable summary: `"Synced 47 items from owner/repo (PRs: 20, Issues: 15, Commits: 10, Releases: 2)"`
- [ ] Returns error message if `gh` CLI not found or not authenticated
- [ ] Handles exceptions gracefully, returns error string (no crashes)
- [ ] Tests mock `sync_repo()` and verify tool registration and output formatting

---

### Story 6: Integration Testing & Documentation

**As a** developer, **I want** end-to-end tests proving the full sync→recall flow works, **so that** I'm confident the feature delivers value.

**Files to create/modify:**
- `tests/test_github_integration.py`
- Update `README.md` usage section (brief mention)

**Acceptance Criteria:**

- [ ] Integration test: mock `gh` CLI output → `github-sync` CLI → `recall` finds relevant memories
- [ ] Test: sync PRs about "authentication", then `recall("auth bugs")` returns those PRs
- [ ] Test: sync with `--types commit` only syncs commits (not PRs/issues/releases)
- [ ] Test: two sequential syncs — second sync is incremental (reads state, fetches only new)
- [ ] Test: memories have correct type, source, tags, and metadata
- [ ] Test: `lore memories --type github_pr` lists only PR memories
- [ ] Test: `lore stats` shows github_pr, github_issue, etc. in type breakdown
- [ ] All tests use `_FakeEmbedder` pattern from existing tests (no real model download)
