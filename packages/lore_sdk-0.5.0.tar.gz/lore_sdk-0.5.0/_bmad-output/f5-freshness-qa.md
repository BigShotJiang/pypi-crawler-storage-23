# F5 — Freshness Detection QA Report

**Commit**: 68f29bf
**Reviewer**: QA-OPUS
**Date**: 2026-03-04
**Verdict**: **PASS**

---

## 1. Plan Compliance

| Story | Status | Notes |
|-------|--------|-------|
| S1: Core freshness module (`src/lore/freshness.py`) | PASS | All functions implemented per spec: `StalenessLevel` enum (4 values), `FreshnessResult` dataclass (6 fields), `_extract_file_ref`, `_count_commits_since`, `_file_exists_in_repo`, `_search_snippet`, `_classify_staleness`, `check_freshness`, `_validate_git_repo` |
| S2: Unit tests (`tests/test_freshness.py`) | PASS | 22 tests covering all functions. Uses `tmp_path` + subprocess for isolated git repos. Deterministic. |
| S3: SDK integration (`src/lore/lore.py`) | PASS | `Lore.freshness_check()` added with lazy import, accepts `repo_path`/`type`/`project`, delegates to `check_freshness()` via `list_memories()`. |
| S4: CLI command (`src/lore/cli.py`) | PASS | `freshness-check` subcommand with `--repo-path`, `--type`, `--json`. Groups output by staleness level. Handles empty results and non-git repo errors. |
| S5: MCP tool (`src/lore/mcp/server.py`) | PASS | `freshness_check` tool registered with descriptive help text. Returns formatted report string. Catches `ValueError` and general `Exception` gracefully. |
| S6: Integration test (`tests/test_freshness_integration.py`) | PASS | End-to-end: creates temp repo + Lore instance, backdates memories, evolves repo, verifies FRESH/AGING/OBSOLETE classification. |

## 2. Acceptance Criteria

### S1 — Core Module
- [x] `StalenessLevel` enum: `fresh`, `aging`, `stale`, `obsolete`
- [x] `FreshnessResult`: `memory`, `level`, `commits_since`, `file_exists`, `snippet_found`, `details`
- [x] `_extract_file_ref()`: checks `metadata["file"]`/`metadata["path"]` first, then `source` with code extension matching
- [x] `_count_commits_since()`: `git log --oneline --since <date> -- <file>`, returns line count
- [x] `_file_exists_in_repo()`: `os.path.isfile(repo_path/file_path)`
- [x] `_search_snippet()`: extracts first meaningful non-comment line, `git grep -F -q`
- [x] `_classify_staleness()`: FRESH <3, AGING 3-10, STALE 11-25, OBSOLETE >25 or deleted
- [x] `check_freshness()` skips memories where `_extract_file_ref()` returns `None` (unless type="code")
- [x] All `subprocess.run()` use `timeout=30`, `capture_output=True`, `cwd=repo_path`
- [x] Non-git repo raises `ValueError` with clear message

### S2 — Tests
- [x] 22 unit tests pass
- [x] Isolated temp git repos via `tmp_path`
- [x] Deterministic, no external dependencies

### S3 — SDK
- [x] `Lore.freshness_check()` returns `List[FreshnessResult]`
- [x] Lazy import of `lore.freshness`
- [x] Delegates to `list_memories()` — works with any store backend

### S4 — CLI
- [x] `lore freshness-check` with `--repo-path`, `--type`, `--json`
- [x] Grouped output (OBSOLETE first, FRESH summary only)
- [x] "No code-related memories found to check." when empty
- [x] Error message on non-git repo

### S5 — MCP
- [x] Tool registered with descriptive help
- [x] Returns human-readable report
- [x] Graceful error handling (returns error string, no crash)

### S6 — Integration
- [x] Isolated temp repo with controlled history
- [x] Backdated timestamps via direct DB update
- [x] Correct classification verified: stable.py=FRESH, changing.py=AGING, doomed.py=OBSOLETE

## 3. Edge Cases

| Case | Handling | Status |
|------|----------|--------|
| No git repo | `_validate_git_repo()` raises `ValueError` — caught by CLI and MCP | PASS |
| Git not installed | `FileNotFoundError` caught in `_validate_git_repo()` → `ValueError` | PASS |
| Deleted files | `_file_exists_in_repo()` returns `False` → OBSOLETE | PASS |
| Empty repo (no files) | `git log` returns empty → 0 commits → FRESH | PASS |
| Binary files | N/A — freshness checks file paths from memory metadata, doesn't read file content | OK |
| Memory with no `created_at` | Handled: `details_parts.append("no creation date, assuming fresh")`, skips commit count | PASS |
| Memory with no source/metadata | Skipped unless `type="code"` (then tries snippet matching) | PASS |
| Snippet too short (<6 chars) | `_search_snippet` returns `False` | PASS |
| Subprocess timeout | Caught in `_count_commits_since` and `_search_snippet`, returns -1 / False | PASS |

## 4. Test Results

```
$ python3 -m pytest tests/test_freshness.py tests/test_freshness_integration.py -x -q
.......................
23 passed in 0.31s
```

## 5. Minor Observations (Non-blocking)

1. **CLI missing `--project` flag**: Plan specifies `--project X` for `freshness-check`, but the parser doesn't add it. The handler uses `getattr(args, "project", None)` which gracefully defaults to `None`. Low impact — freshness check typically runs on all memories.

2. **CLI path validation**: `cmd_freshness_check` catches `ValueError` but not `OSError` for invalid `--repo-path`. The MCP tool catches all exceptions. Minor inconsistency.

## 6. Code Quality

- Clean separation: `freshness.py` is self-contained, no store-layer coupling
- Correct use of subprocess: read-only git commands, timeouts, error handling
- Good heuristics: `_extract_file_ref` checks metadata keys before source field
- `_CODE_EXTENSIONS` frozenset is comprehensive (35+ extensions)
- `_extract_search_line` skips comments and empty lines before searching

---

**VERDICT: PASS**

All 6 stories implemented per plan. 23/23 tests pass. Edge cases handled. Two minor non-blocking observations noted.
