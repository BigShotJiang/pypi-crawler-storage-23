# F2 — Security Pipeline: PII & Secret Scanning

## 1. PRD

### Problem

Lore stores user memories with **zero content filtering**. The existing `RedactionPipeline` at `src/lore/redact/pipeline.py` is instantiated in `Lore.__init__()` (line 88) but **never called** — `remember()` (line 149) saves raw `content` directly. The MCP server (`src/lore/mcp/server.py:166-178`) and REST API (`src/lore/server/routes/memories.py:101-112`) also store raw content.

This means API keys, passwords, SSNs, credit card numbers, and other sensitive data are persisted in plaintext in SQLite/PostgreSQL and served back via recall/list/search — creating a liability for any user or organization running Lore.

### User Value

- **Data protection**: PII (emails, phones, SSNs, credit cards) is automatically masked before storage, reducing exposure risk.
- **Secret leak prevention**: API keys, tokens, passwords, and high-entropy secrets are blocked outright — the memory is rejected with a clear error, preventing accidental persistence of credentials.
- **Compliance readiness**: Masked content with audit metadata supports GDPR/CCPA data minimization requirements.
- **Zero-friction defaults**: Layer 1 (regex) works out of the box with no extra dependencies. Users who install `detect-secrets` or `spacy` get deeper scanning automatically.

### Success Metrics

| Metric | Target |
|--------|--------|
| Regex layer (L1) latency | < 2ms per memory (current test: < 5ms) |
| detect-secrets layer (L2) latency | < 15ms per memory |
| SpaCy NER layer (L3) latency | < 150ms per memory |
| PII detection recall (L1 regex) | > 95% on standard PII test corpus |
| Secret detection precision | > 99% (minimize false blocks) |
| No new required dependencies | 0 — detect-secrets and spacy are optional extras |
| Existing test suite continues to pass | 100% |

---

## 2. Architecture

### 2.1 Pipeline Design

Three scanning layers, each optional and independently configurable. Content flows through all enabled layers in sequence. Any layer can MASK (replace with placeholder) or BLOCK (reject the memory).

```
content
  │
  ▼
┌─────────────────────────────────────┐
│  Layer 1: Regex Patterns            │  Always available (stdlib only)
│  - PII: email, phone, SSN, CC      │  Action: MASK → [REDACTED:type]
│  - Secrets: API keys (prefix-based) │  Action: BLOCK → raise error
│  ~1ms                               │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│  Layer 2: detect-secrets            │  Optional dep: detect-secrets
│  - High-entropy strings             │  Action: BLOCK → raise error
│  - Known secret patterns            │  Graceful skip if not installed
│  ~10ms                              │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│  Layer 3: SpaCy NER                 │  Optional dep: spacy
│  - PERSON, ORG, GPE entities        │  Action: MASK → [REDACTED:person] etc.
│  - Catches PII regex misses         │  Graceful skip if not installed
│  ~50-100ms                          │
└──────────────┬──────────────────────┘
               │
               ▼
         ScanResult {
           cleaned_content: str,
           was_blocked: bool,
           detections: [Detection...],
           original_hash: str
         }
```

### 2.2 Integration Point

The security pipeline runs **inside `remember()`**, before `memory_store.save()`. This is the single chokepoint — all three surfaces (SDK, MCP, REST) ultimately call `save()`.

**SDK** — `src/lore/lore.py:129-161`

Current code at line 149 passes raw `content` to the Memory constructor. The fix:

```python
# After line 141 (expires_at = _parse_ttl(ttl))
if self._redact_enabled and self._scanner:
    result = self._scanner.scan(content)
    if result.was_blocked:
        raise ContentBlockedError(result.detections)
    content = result.cleaned_content
    # Stash redaction metadata
    if result.detections:
        metadata = dict(metadata or {})
        metadata["_redacted"] = True
        metadata["_redaction_count"] = len(result.detections)
```

**MCP server** — `src/lore/mcp/server.py:127-181`

The MCP `remember()` creates memories inline without using the SDK `Lore` class. Two options:
- **(a) Refactor to use `Lore` class**: MCP server delegates to `Lore.remember()` instead of duplicating logic. This gets security for free. **Recommended.**
- **(b) Duplicate scanner call**: Add scanner call in MCP's `remember()` before `store.save()`.

Recommendation: **(a)** — the MCP server already duplicates `_parse_ttl`, `_serialize_embedding`, and memory construction. Consolidation reduces surface area.

**REST API** — `src/lore/server/routes/memories.py:79-114`

The REST API is server-mode (PostgreSQL, multi-tenant). Scanning should run before `store.save()` at line 101. This is a separate integration since the server has its own config (`src/lore/server/config.py`).

### 2.3 Extending the Existing Redact Module

The existing `src/lore/redact/` module is **kept and extended**, not replaced:

| Current file | Change |
|---|---|
| `redact/patterns.py` | Add `SSN` pattern. Categorize patterns as `PII` vs `SECRET`. |
| `redact/pipeline.py` | Rename to internal use. The `RedactionPipeline` class becomes L1 within the new `SecurityScanner`. |
| `redact/__init__.py` | Export new `SecurityScanner` + old `RedactionPipeline` for backward compat. |

New files to add:

| File | Purpose |
|---|---|
| `redact/scanner.py` | `SecurityScanner` — orchestrates L1/L2/L3, returns `ScanResult` |
| `redact/entropy.py` | L2 wrapper: imports `detect_secrets` if available, else no-op |
| `redact/ner.py` | L3 wrapper: imports `spacy` if available, else no-op |
| `redact/types.py` | `ScanResult`, `Detection`, `ScanAction` (mask/block/warn) dataclasses |
| `redact/config.py` | `ScannerConfig` dataclass for layer enable/disable and action settings |

### 2.4 Configuration

```python
@dataclass
class ScannerConfig:
    """Per-layer configuration for the security scanner."""
    # Master switch
    enabled: bool = True

    # Layer 1: regex (always available)
    regex_enabled: bool = True
    pii_action: str = "mask"      # mask | block | warn
    secret_action: str = "block"  # mask | block | warn

    # Layer 2: detect-secrets (optional)
    entropy_enabled: bool = True   # auto-skipped if not installed
    entropy_action: str = "block"

    # Layer 3: SpaCy NER (optional)
    ner_enabled: bool = False      # opt-in (heavier dependency)
    ner_action: str = "mask"
    ner_model: str = "en_core_web_sm"
```

**SDK init** — new `scanner_config` parameter on `Lore.__init__()`:
```python
Lore(scanner_config=ScannerConfig(ner_enabled=True))
```

**MCP server** — environment variables:
```
LORE_SCAN_ENABLED=true          (default: true)
LORE_SCAN_PII_ACTION=mask       (default: mask)
LORE_SCAN_SECRET_ACTION=block   (default: block)
LORE_SCAN_ENTROPY=true          (default: true)
LORE_SCAN_NER=false             (default: false)
```

**REST API server** — add fields to `Settings` dataclass in `src/lore/server/config.py`.

### 2.5 Graceful Degradation

```python
# redact/entropy.py
try:
    from detect_secrets.core.scan import scan_line
    HAS_DETECT_SECRETS = True
except ImportError:
    HAS_DETECT_SECRETS = False

class EntropyScanner:
    def __init__(self):
        if not HAS_DETECT_SECRETS:
            return  # no-op
        # ... init

    def scan(self, text: str) -> List[Detection]:
        if not HAS_DETECT_SECRETS:
            return []
        # ... scan
```

Same pattern for SpaCy in `redact/ner.py`. If the dep is missing and the layer is enabled in config, log a warning once at startup.

### 2.6 Error Handling

When content is **blocked**:
- SDK: raise `ContentBlockedError` (new exception in `src/lore/exceptions.py`)
- MCP server: return `"❌ Memory rejected: content contains secrets (api_key at position 42). Remove sensitive data and retry."`
- REST API: return HTTP 422 with `{"detail": "Content blocked: secret detected", "detections": [...]}`

### 2.7 Dependencies

```toml
# pyproject.toml additions
[project.optional-dependencies]
security = [
    "detect-secrets>=1.4.0",
]
ner = [
    "spacy>=3.5.0",
]
```

No changes to core dependencies. Layer 1 (regex) uses stdlib only.

### 2.8 Backward Compatibility

- `RedactionPipeline` continues to work as-is (existing tests pass unchanged).
- `Lore(redact=True)` still works — it creates the `SecurityScanner` with default config (L1 regex only, PII=mask, secrets=block).
- `Lore(redact=False)` disables all scanning.
- New `Lore(redact=True, scanner_config=...)` allows fine-grained control.
- The `redact_patterns` parameter maps to custom regex patterns in L1.

---

## 3. Stories with Acceptance Criteria

### Epic: F2 — Security Pipeline

---

### Story 1: Core Scanner Framework & Types

**As a** developer,
**I want** a `SecurityScanner` class that orchestrates scanning layers and returns structured results,
**so that** all integration points can use a single API for content scanning.

**Files to create/modify:**
- Create `src/lore/redact/types.py`
- Create `src/lore/redact/config.py`
- Create `src/lore/redact/scanner.py`
- Modify `src/lore/redact/__init__.py` — export new types
- Create `tests/test_scanner.py`

**Acceptance Criteria:**

1. `ScanResult` dataclass has fields: `cleaned_content: str`, `was_blocked: bool`, `detections: List[Detection]`, `original_hash: str`.
2. `Detection` dataclass has fields: `type: str` (e.g. "email", "api_key"), `category: str` ("pii" | "secret"), `position: Tuple[int, int]`, `replacement: str`.
3. `ScannerConfig` dataclass supports all fields from section 2.4.
4. `SecurityScanner.__init__(config)` accepts a `ScannerConfig` and initializes enabled layers.
5. `SecurityScanner.scan(text) -> ScanResult` runs all enabled layers in sequence and returns a combined result.
6. When `was_blocked=True`, `detections` contains at least one detection with category="secret".
7. `SecurityScanner` with default config (no optional deps) returns same results as existing `RedactionPipeline` for PII patterns.
8. All new code has tests. Existing `test_redact.py` tests continue to pass.

---

### Story 2: Categorize Existing Patterns (PII vs Secrets) & Add SSN

**As a** user,
**I want** PII to be masked and secrets to be blocked,
**so that** my memories are safe but not rejected for containing an email address.

**Files to modify:**
- Modify `src/lore/redact/patterns.py` — add SSN, add category metadata
- Modify `src/lore/redact/pipeline.py` — return `Detection` objects (not just replaced text) so scanner can determine action
- Create or update `tests/test_scanner.py` — SSN tests, category-based action tests

**Acceptance Criteria:**

1. `patterns.py` defines `SSN` regex: `\b\d{3}-\d{2}-\d{4}\b` (with word boundaries to avoid false positives).
2. Each pattern has a `category` attribute: `"pii"` for email, phone, SSN, credit card, IP address; `"secret"` for API keys.
3. `RedactionPipeline.run()` still returns a string (backward compat). New method `RedactionPipeline.scan()` returns `List[Detection]` with positions.
4. SSN `123-45-6789` is masked to `[REDACTED:ssn]`.
5. SSN-like strings that are clearly not SSNs (e.g., `000-00-0000`, `999-99-9999`) are not matched (invalid area/group).
6. Existing 20 tests in `test_redact.py` pass unchanged.

---

### Story 3: Layer 2 — detect-secrets Entropy Scanning

**As a** user who installs `detect-secrets`,
**I want** high-entropy strings (random tokens, base64 secrets) detected and blocked,
**so that** secrets without known prefixes are still caught.

**Files to create/modify:**
- Create `src/lore/redact/entropy.py`
- Modify `src/lore/redact/scanner.py` — wire L2 into pipeline
- Add `security` to optional deps in `pyproject.toml`
- Create `tests/test_entropy.py`

**Acceptance Criteria:**

1. `EntropyScanner` class wraps `detect-secrets` library.
2. When `detect-secrets` is not installed, `EntropyScanner.scan()` returns empty list (no error).
3. When `detect-secrets` is not installed and `entropy_enabled=True` in config, a warning is logged once at init.
4. High-entropy strings like `AAAAAABBBBCCCC1234567890abcdef` (base64-like, hex-like) are detected.
5. Normal prose text is not flagged (precision > 99% on 100-sample test set).
6. Detected secrets return `Detection(category="secret")`, triggering block action by default.
7. `pyproject.toml` adds `security = ["detect-secrets>=1.4.0"]` to optional dependencies.
8. Tests work both with and without `detect-secrets` installed (conditional skip).

---

### Story 4: Layer 3 — SpaCy NER Scanning

**As a** user who installs `spacy`,
**I want** person names, organizations, and locations detected and masked,
**so that** PII that regex can't catch is still protected.

**Files to create/modify:**
- Create `src/lore/redact/ner.py`
- Modify `src/lore/redact/scanner.py` — wire L3 into pipeline
- Add `ner` to optional deps in `pyproject.toml`
- Create `tests/test_ner.py`

**Acceptance Criteria:**

1. `NERScanner` class wraps SpaCy's NLP pipeline.
2. When `spacy` is not installed, `NERScanner.scan()` returns empty list (no error).
3. When `spacy` is not installed and `ner_enabled=True`, a warning is logged once at init.
4. Model is loaded lazily on first `scan()` call (not at import time).
5. PERSON entities → `[REDACTED:person]`, ORG → `[REDACTED:org]`, GPE → `[REDACTED:location]`.
6. NER layer is **disabled by default** (`ner_enabled=False`) due to heavier dependency and latency.
7. `pyproject.toml` adds `ner = ["spacy>=3.5.0"]` to optional dependencies.
8. Tests work both with and without `spacy` installed (conditional skip).

---

### Story 5: SDK Integration — Wire Scanner into `Lore.remember()`

**As a** SDK user,
**I want** content automatically scanned before storage,
**so that** PII is masked and secrets are blocked without manual intervention.

**Files to modify:**
- Modify `src/lore/lore.py` — add scanner call in `remember()`, add `scanner_config` param to `__init__`
- Modify `src/lore/exceptions.py` — add `ContentBlockedError`
- Modify `src/lore/redact/__init__.py` — export `ScannerConfig`
- Update `tests/test_lore_sdk_memory.py` — add security integration tests

**Acceptance Criteria:**

1. `Lore.__init__()` accepts optional `scanner_config: ScannerConfig` parameter.
2. `Lore(redact=True)` creates `SecurityScanner` with default config (L1 regex, PII=mask, secrets=block).
3. `Lore(redact=False)` disables all scanning (no `SecurityScanner` created).
4. `Lore(redact=True, redact_patterns=[...])` maps custom patterns to L1 custom layer.
5. `remember("my email is user@test.com")` stores content as `"my email is [REDACTED:email]"`.
6. `remember("key: sk-abc123def456ghi789jkl012")` raises `ContentBlockedError`.
7. `ContentBlockedError` includes the list of detections and a human-readable message.
8. When content is masked, `metadata["_redacted"] = True` and `metadata["_redaction_count"]` is set.
9. Embedding is computed on the **original** content (not redacted), so semantic search still works.
10. Existing SDK tests pass. New integration tests cover mask, block, and disabled scenarios.

---

### Story 6: MCP Server Integration

**As a** MCP user (Claude, Cursor, etc.),
**I want** the MCP `remember` tool to scan content,
**so that** AI agents can't accidentally persist secrets through the MCP interface.

**Files to modify:**
- Modify `src/lore/mcp/server.py` — add scanner initialization, apply scanning in `remember()`
- Update `tests/test_lore_mcp.py` — add security tests

**Acceptance Criteria:**

1. MCP server reads scanner config from environment variables (`LORE_SCAN_ENABLED`, `LORE_SCAN_SECRET_ACTION`, etc.).
2. Scanner is initialized lazily (alongside store and embedder).
3. When content is blocked, `remember()` returns `"❌ Memory rejected: content contains secrets (<type> detected). Remove sensitive data and retry."` (not an exception — MCP tools return strings).
4. When content is masked, `remember()` returns `"✅ Memory saved (ID: ...) — ⚠️ N sensitive item(s) were redacted."`.
5. Scanner is disabled when `LORE_SCAN_ENABLED=false`.
6. Tests cover: PII masking, secret blocking, disabled scanner, missing optional deps.

---

### Story 7: REST API Server Integration

**As a** REST API operator,
**I want** the server to scan content on memory creation,
**so that** multi-tenant deployments are protected.

**Files to modify:**
- Modify `src/lore/server/config.py` — add scanner settings to `Settings`
- Modify `src/lore/server/routes/memories.py` — apply scanning before `store.save()`
- Create or update `tests/test_server_security.py`

**Acceptance Criteria:**

1. `Settings` dataclass in `config.py` gains scanner fields loaded from env vars.
2. Scanner is initialized once at app startup (not per-request).
3. When content is blocked, return HTTP 422: `{"detail": "Content blocked: secret detected", "detections": [...]}`.
4. When content is masked, the response includes `"redacted": true` in the response body.
5. Scanner config is per-deployment (not per-tenant). Tenant-level config is out of scope.
6. Tests cover: mask, block, 422 response format.

---

### Story 8: Documentation & Developer Guide

**As a** developer integrating Lore,
**I want** clear documentation on the security pipeline,
**so that** I know what's scanned, how to configure it, and how to add custom patterns.

**Files to create/modify:**
- Update project README or docs with security pipeline section
- Add docstrings to all new public APIs
- Add inline code examples in docstrings

**Acceptance Criteria:**

1. README/docs explain the 3-layer pipeline with a diagram.
2. Configuration reference lists all env vars and `ScannerConfig` fields.
3. Examples show: default usage, disabling scanning, enabling NER, adding custom patterns.
4. "Graceful degradation" behavior is documented (what happens without optional deps).
5. Error handling is documented (what `ContentBlockedError` looks like, MCP error strings, HTTP 422 format).

---

### Story Priority & Dependencies

```
Story 1 (Framework)
  ├── Story 2 (Pattern Categories + SSN)  ← depends on Story 1 types
  │     └── Story 5 (SDK Integration)     ← depends on Story 2 for categories
  │           ├── Story 6 (MCP)           ← depends on Story 5 pattern
  │           └── Story 7 (REST API)      ← depends on Story 5 pattern
  ├── Story 3 (detect-secrets)            ← depends on Story 1 scanner
  └── Story 4 (SpaCy NER)                ← depends on Story 1 scanner
Story 8 (Docs)                            ← after all above
```

**Recommended sprint order:** 1 → 2 → 5 → 6 → 7 → 3 → 4 → 8

Stories 3 and 4 are independent of each other and can be parallelized. Stories 6 and 7 are independent of each other and can be parallelized.
