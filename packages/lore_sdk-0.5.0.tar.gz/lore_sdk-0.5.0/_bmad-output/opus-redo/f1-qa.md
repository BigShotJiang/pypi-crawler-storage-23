# F1: Semantic Decay Scoring — QA Report

**Commit:** 521320c
**Verdict: CONDITIONAL PASS**

---

## AC Verdicts

| AC | ID | Status | Notes |
|---|---|---|---|
| `DECAY_HALF_LIVES` dict in `types.py` | F1-S1a | PASS | `{"code": 14, "note": 21, "lesson": 30, "convention": 60}` |
| Unknown type defaults to HL=30 | F1-S1b | PASS | Via `_half_life_days` fallback |
| Half-lives overridable via constructor | F1-S1c | PASS | `decay_half_lives` param merges correctly |
| Unit test: each type produces correct HL | F1-S1d | PASS | `test_each_type_produces_correct_half_life` |
| Weighted additive formula in Python | F1-S2a | PASS | `final = 0.7 * (cosine * confidence * vote_factor) + 0.3 * freshness` |
| Weights configurable via constructor | F1-S2b | PASS | `decay_similarity_weight`, `decay_freshness_weight` |
| Python `_recall_local` uses new formula | F1-S2c | PASS | Implemented at lore.py:356-363 |
| TypeScript `query` uses same formula | F1-S2d | PASS | ts/src/lore.ts `recall()` matches |
| Integration test: recent outranks old | F1-S2e | PASS | `test_recent_lesson_outranks_old_same_similarity` |
| `lore publish --type code` sets `meta.type` | F1-S3a | FAIL | `--type` flag absent from `publish` subcommand |
| `save_lesson` MCP accepts optional `type` | F1-S3b | CONDITIONAL | Renamed to `remember`; `remember` MCP tool does accept `type` |
| SDK `publish()` accepts optional `type` | F1-S3c | FAIL | Deprecated `publish()` hardcodes `type="lesson"` |
| Invalid type values rejected | F1-S3d | FAIL | No validation anywhere |
| Default type when omitted: `"lesson"` | F1-S3e | FAIL | `remember` defaults to `"general"`, not `"lesson"` |
| PostgreSQL SQL formula correct | F1-S4a | PASS | Formula and CASE expression match spec |
| Half-life from `meta->>'type'` with default 30 | F1-S4b | PASS | ELSE 30 in CASE |
| Integration test vs test DB confirms parity | F1-S4c | FAIL | No integration test exists |

---

## Critical Issues

### 1. `lore publish --type code` not implemented
**File:** `src/lore/cli.py:253-257`
The `publish` subcommand parser has no `--type` argument. Note: `publish` is deprecated; `remember` does support `--type`.

### 2. Invalid type values not rejected
**Files:** `lore.py:remember()`, `mcp/server.py:remember()`, `cli.py:cmd_remember()`
`lore.remember("x", type="banana")` stores without complaint. No validation exists.

### 3. Default type mismatch
Every entry point defaults to `"general"`, not `"lesson"` as specified in AC. Falls back to HL=30 (same as `"lesson"`), but semantically different.

### 4. Architectural divergence: `Memory.type` vs `meta->>'type'`
Python SDK uses `memory.type` for half-life lookup. Server SQL uses `meta->>'type'`. A lesson stored locally with `type="code"` will score with HL=14 locally but HL=30 on the server (meta type is NULL).

---

## Edge Cases

- **Zero half-life:** `decay_half_lives={"code": 0}` causes `ZeroDivisionError` in Python, `NaN` in TypeScript. No validation.
- **Negative cosine similarity:** The additive formula makes highly-fresh irrelevant memories score >0.3 purely on freshness.
- **`_half_life_days` override surprise:** Passing `decay_half_life_days=7` only affects unknown types, not the four defined types. Undocumented.

---

## Test Coverage

| Area | Coverage |
|---|---|
| Half-life constants | Good — all types, override, fallback |
| Scoring formula | Good — age=0, type-differentiated, configurable weights |
| Integration (recent vs old ranking) | Good |
| Backward compat (votes, clamping) | Good |
| CLI `--type` flag | Missing (feature missing) |
| Type validation | Missing (feature missing) |
| Server-side SQL parity | Missing |

---

## Verdict Rationale

F1-S1 and F1-S2 (the core scoring changes) are fully implemented and well-tested. The mathematical behavior is correct. F1-S3 has 3 FAILs related to deprecated `publish` command, missing validation, and default type mismatch. F1-S4 SQL is correct but lacks the required integration test. **Conditionally acceptable** if: (a) `publish` deprecation makes `--type` unnecessary, (b) open type strings are intentional, (c) integration test gap is tracked.
