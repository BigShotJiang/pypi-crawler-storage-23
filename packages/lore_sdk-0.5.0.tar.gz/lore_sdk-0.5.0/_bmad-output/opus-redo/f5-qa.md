# F5: Freshness Detection — QA Report

**Commit:** Not yet committed (code in `src/lore/freshness/`, tests in `tests/test_freshness*`)
**Verdict: CONDITIONAL PASS**

---

## AC Verdicts

| AC | ID | Status | Notes |
|---|---|---|---|
| `git_log_count(repo, file_path, since) -> int` | F5-S1a | PASS | `git_ops.py:48` |
| `file_exists(repo, file_path) -> bool` | F5-S1b | CONDITIONAL | Uses filesystem check, not git HEAD |
| `file_contains_pattern` | F5-S1c | PASS | `git_ops.py:81-90` |
| Handles file not found, not a git repo, git not installed | F5-S1d | CONDITIONAL | `git_log_count` returns 0 on any error (git missing = "fresh") |
| Timeout 5s default | F5-S1e | FAIL | Default is 30s (`_TIMEOUT = 30`), not 5s |
| Unit tests with temp git repo fixture | F5-S1f | PASS | `test_freshness.py:59-74` |
| `StalenessResult` dataclass with correct fields | F5-S2a | FAIL | Field is `memory_id` not `lesson_id` |
| Thresholds: 0-2=fresh, 3-9=possibly, 10-24=likely, 25+=stale | F5-S2b | PASS | Correct at `detector.py:17-21` |
| No `file_path` → unknown | F5-S2c | PASS | Reason: "no file_path in metadata" (not "meta") |
| Deleted files → stale, confidence=1.0 | F5-S2d | PASS | `detector.py:56-64` |
| Thresholds configurable via constructor/CLI | F5-S2e | CONDITIONAL | Constructor yes, CLI no |
| Unit test for each boundary | F5-S2f | PASS | `test_classify_all_boundaries` |
| `lore freshness --repo` scans all lessons | F5-S3a | PASS | `cli.py:377-434` |
| `--project` flag | F5-S3b | PASS | Filters `list_memories` |
| `--format table\|json` | F5-S3c | PASS | Both implemented |
| `--min-staleness` filter | F5-S3d | CONDITIONAL | Silently drops "unknown" results |
| `--auto-tag` adds "stale" tag | F5-S3e | CONDITIONAL | Tags `stale` AND `likely_stale` (AC says only stale). Uses private `_store` |
| Summary line format matches AC | F5-S3f | FAIL | Underscore labels, omits zero-count categories |
| Exit code: 0=no stale, 1=stale found | F5-S3g | CONDITIONAL | Only `status=="stale"` triggers exit 1 |
| MCP `check_freshness(repo_path, project?)` | F5-S4a | PASS | `mcp/server.py:263-297` |
| Returns markdown-formatted report | F5-S4b | FAIL | Returns plain text with box-drawing chars, not Markdown |
| Actionable summary | F5-S4c | PASS | "Found N stale..." with IDs |
| Graceful handling (not git, no lessons, git missing) | F5-S4d | PASS | `validate_repo()` + exception handling |
| `RecallResult` extended with `staleness` | F5-S5a | PASS | `types.py:37` |
| Opt-in `check_freshness=True, repo_path=` | F5-S5b | PASS | `lore.py:236-237` |
| MCP `recall` supports `repo_path` | F5-S5c | PASS | `mcp/server.py:107-148` |
| Stale lessons shown with warning badge | F5-S5d | CONDITIONAL | All non-fresh get same "POSSIBLY STALE" badge |
| <100ms per lesson | F5-S5e | NOT VERIFIED | No performance test |

---

## Critical Issues

### 1. Timeout is 30s, not 5s
**File:** `src/lore/freshness/git_ops.py:11`
`_TIMEOUT = 30` directly contradicts AC requiring 5s default.

### 2. `git_log_count` returns 0 when git is not installed
**File:** `src/lore/freshness/git_ops.py:59-69`
Any `GitError` (including git not installed) returns 0. This makes all memories appear "fresh" when git is missing — silently wrong.

### 3. `StalenessResult.memory_id` vs AC's `lesson_id`
**File:** `src/lore/freshness/types.py:17`
Field naming doesn't match the AC spec.

### 4. MCP report is plain text, not Markdown
**File:** `src/lore/freshness/detector.py:99-130`
Uses Unicode box-drawing characters. AC requires Markdown formatting.

### 5. `file_exists_in_repo` bypasses git entirely
**File:** `src/lore/freshness/git_ops.py:75-78`
Uses `Path.is_file()` instead of checking git index. A file removed via `git rm` (without physical delete) will appear as existing.

---

## Edge Cases

- **`check_freshness=True, repo_path=None`:** Silently no-ops with no warning. Caller gets no staleness data.
- **`--auto-tag` + `--min-staleness` interaction:** Only filtered results get tagged, which may be surprising.
- **`StalenessResult.file_exists=True` for unknown status:** Misleading — file existence is unknown, not confirmed.
- **`--auto-tag` uses private `lore._store.update()`:** Fragile coupling to internal API.

---

## Test Coverage

| Area | Coverage |
|---|---|
| Threshold boundaries | Good — all values tested |
| `check_many`, `validate_repo` | Good |
| Custom thresholds, deleted files, unknown status | Good |
| Freshness-aware recall | Good — 3 scenarios |
| CLI argument parsing | Good |
| `--auto-tag` | Not tested |
| CLI exit codes | Not tested |
| Summary format | Not tested |
| MCP git-not-installed handling | Not tested |
| `check_freshness=True, repo_path=None` | Not tested |
| Performance <100ms/lesson | Not tested |
| `git not installed` → false "fresh" | Not tested |

---

## Verdict Rationale

The core detection logic is solid: threshold classification, git integration, freshness-aware recall, and MCP tool all work correctly. Tests cover the main paths and all threshold boundaries. The issues preventing full PASS are mostly cosmetic/naming (timeout value, field name, report format, summary format) rather than architectural. **Conditionally acceptable** with fixes to: (1) timeout 30→5, (2) field naming or AC update, (3) Markdown report format, and (4) summary line format.
