# F4: GitHub Sync — QA Report

**Commit:** a984243
**Verdict: CONDITIONAL FAIL**

---

## AC Verdicts

| AC | ID | Status | Notes |
|---|---|---|---|
| Uses `gh api graphql` for paginated data | F4-S1a | FAIL | PRs/issues use `gh pr list`/`gh issue list` (REST), not GraphQL |
| Fetches merged PRs | F4-S1b | PASS | `fetch_merged_prs` |
| Fetches closed issues | F4-S1c | PASS | `fetch_closed_issues` |
| Fetches notable commits | F4-S1d | PASS | `fetch_notable_commits` |
| Fetches published releases | F4-S1e | PASS | `fetch_releases` |
| Pagination handles 1000+ PRs | F4-S1f | FAIL | Hard limit of 100 (`--limit 100`), no pagination |
| Auth via `gh` CLI | F4-S1g | PASS | All calls via `_run_gh` |
| Clear error if `gh` not installed/authenticated | F4-S1h | PASS | `GitHubCLIError` raised |
| PR → Lesson mapping correct | F4-S2a | PASS | Body truncated at 2000 chars |
| Issue → Lesson mapping correct | F4-S2b | PASS | Last comment as resolution |
| Commit → Lesson mapping correct | F4-S2c | PASS | Subject/body split |
| Release → Lesson mapping correct | F4-S2d | PASS | Name/changelog |
| All entities include required meta fields | F4-S2e | FAIL | `gh_synced_at` missing from all transforms |
| Empty body/resolution handled | F4-S2f | PASS | Fallback to title/subject |
| State persisted in `~/.lore/sync_state.json` | F4-S3a | PASS | `state.py:15` |
| State tracks `last_sync` timestamp | F4-S3b | PASS | Written by syncer |
| State tracks `last_pr`/`last_issue` | F4-S3c | FAIL | Fields defined but never written by syncer |
| Incremental sync uses `since` | F4-S3d | PARTIAL | Works for commits/PRs; broken for issues (missing `closedAt` field) |
| Deduplication by type + number | F4-S3e | PARTIAL | Uses `source` string (equivalent) but O(N*M) performance |
| `--full` flag forces re-sync | F4-S3f | PASS | Implemented |
| First sync auto-does full sync | F4-S3g | PASS | No prior state = full fetch |
| `lore github-sync --repo` | F4-S4a | PASS | |
| `--types` filter | F4-S4b | PASS | |
| `--since` override | F4-S4c | PASS | |
| `--dry-run` | F4-S4d | PASS | |
| `--list` shows synced repos | F4-S4e | PASS | |
| Progress output | F4-S4f | FAIL | No per-item progress, only final summary |
| `--project` flag | F4-S4g | PASS | |
| MCP `github_sync` tool | F4-S5a | PASS | |
| Returns summary | F4-S5b | PASS | |
| Graceful error handling | F4-S5c | PASS | |
| Respects sync state | F4-S5d | PASS | |

---

## Critical Issues

### 1. PRs/issues/releases not paginated — hard limit at 100
**File:** `src/lore/github/syncer.py:111-124`
`fetch_merged_prs` uses `--limit 100`. A repo with 500 merged PRs silently returns only 100. AC requires handling 1000+ PRs.

### 2. Issue `closedAt` field not requested
**File:** `src/lore/github/syncer.py:130-139`
`--json` field list includes `number,title,body,labels,url,comments` but not `closedAt`. The `since` filter compares against `closedAt` which is always absent, making incremental sync for issues effectively broken.

### 3. `gh_synced_at` missing from all metadata
**File:** `src/lore/github/transforms.py`
AC requires `gh_synced_at` in meta for every entity. Absent from all four transform functions.

### 4. `_source_exists` is O(N*M) — full table scan per item
**File:** `src/lore/github/syncer.py:301-304`
Calls `lore.list_memories()` (full table load) for each item to check. 500 PRs * 10,000 memories = 5M comparisons. Defeats the <60s success metric.

### 5. `last_pr`/`last_issue` state markers never populated
**File:** `src/lore/github/syncer.py:261`
`update_sync_state` accepts `last_pr`/`last_issue` params but syncer only passes `last_sync`. The test masks this by writing values directly.

---

## Edge Cases

- **Race condition on state file:** Non-atomic `open("w")` write. Concurrent syncs can corrupt state.
- **Release fallback catches all `GitHubCLIError`:** Auth failures trigger retry instead of propagating as clear error.
- **Release with no tag:** Empty `tagName` produces broken dedup key `github:repo:release:`.
- **GraphQL not used:** AC explicitly mandates GraphQL for pagination. Implementation uses REST CLI commands.

---

## Test Coverage

| Area | Coverage |
|---|---|
| All four transform functions | Good — happy path, empty title/body |
| State CRUD | Good |
| `_run_gh` error modes | Good — not found, timeout, auth, generic |
| Full sync, dry run, selective types | Good |
| Dedup | Good |
| CLI `--list`, missing `--repo` | Good |
| MCP tool normal + error | Good |
| Issue `closedAt` field | Not tested (bug masked) |
| Pagination >100 items | Not tested |
| `gh_synced_at` metadata | Not tested |
| `_source_exists` performance | Not tested |
| Concurrent state access | Not tested |

---

## Verdict Rationale

The feature is structurally sound with good CLI, MCP, state management, and transform logic. However, **three blocking gaps** prevent PASS: (1) `gh_synced_at` missing from metadata, (2) PRs/issues hard-limited to 100 with no pagination, and (3) issue incremental sync is broken due to missing `closedAt` field. The `_source_exists` O(N*M) performance will also be a real problem at scale.
