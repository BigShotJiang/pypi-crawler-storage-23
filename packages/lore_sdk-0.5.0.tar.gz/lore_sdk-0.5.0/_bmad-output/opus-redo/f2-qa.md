# F2: Security Pipeline — QA Report

**Commit:** 4aa7da4
**Verdict: FAIL**

---

## AC Verdicts

| AC | ID | Status | Notes |
|---|---|---|---|
| JWT, PEM, AWS secret, entropy patterns added | F2-S1a | PASS | All present in `patterns.py` / `pipeline.py` |
| 3 positive + 3 negative tests per new pattern | F2-S1b | FAIL | AWS secret key: 0 tests. JWT: 1 true negative. Private key: 1 negative. |
| Existing patterns unchanged | F2-S1c | PASS | Backward compatible |
| Benchmark <1ms | F2-S1d | FAIL | Test uses 5ms threshold, not 1ms |
| `ScanResult` with findings + action | F2-S2a | PASS | Correct dataclass |
| Secrets → block | F2-S2b | PASS | api_key, jwt_token, private_key, aws_secret_key → block |
| PII → mask | F2-S2c | PASS | email, phone, credit_card → mask |
| `SecretBlockedError` raised | F2-S2d | PASS | In `lore.py:remember()` |
| MCP user-friendly error | F2-S2e | PASS | Message text is user-friendly |
| CLI shows blocked type (not traceback) | F2-S2f | FAIL | `SecretBlockedError` unhandled in `cmd_remember` — produces traceback |
| detect-secrets optional dependency | F2-S3a | PASS | Guarded by `try/except` |
| L2 auto-activates when available | F2-S3b | PASS | Via lazy init |
| L2 explicitly disableable | F2-S3c | PASS | `security_scan_levels=[1]` |
| L2 graceful degradation | F2-S3d | PASS | Returns `[]` if unavailable |
| Test: base64 key caught by L2 not L1 | F2-S3e | FAIL | Test does not exist |
| SpaCy optional dependency | F2-S4a | PASS | Guarded by `try/except` |
| L3 activates with spacy + model | F2-S4b | PASS | Correct |
| PERSON/GPE/LOC masked, ORG not | F2-S4c | PASS | Explicitly commented in code |
| L3 disableable | F2-S4d | PASS | Via `security_scan_levels` |
| L3 graceful degradation | F2-S4e | PASS | Returns `[]` if unavailable |
| NER sentence test | F2-S4f | FAIL | Test only checks no-crash, not substitution |
| New L1 patterns in TS SDK | F2-S5a | FAIL | JWT, PEM, AWS, entropy all missing from TS |
| Block action in TS SDK | F2-S5b | FAIL | Not implemented |
| Test parity TS/Python | F2-S5c | FAIL | No TS tests for new patterns |
| L2/L3 documented as Python-only in TS README | F2-S5d | FAIL | No TS README exists |

---

## Critical Issues

### 1. TypeScript SDK entirely missing new patterns (F2-S5)
`ts/src/redact.ts` has none of: JWT, PEM private key, AWS secret key, or high-entropy detection. Block action concept is absent. This is a complete miss of the F2-S5 story.

### 2. CLI doesn't handle `SecretBlockedError`
`cmd_remember()` has no exception handling. A blocked secret produces a Python traceback instead of the user-friendly message specified.

### 3. AWS secret key pattern has zero tests
The `AWS_SECRET_KEY` pattern is entirely untested as a distinct detection path.

### 4. L2 position tracking bug
`_scan_l2()` uses `text.find(secret_val, offset)` which can match wrong instances in multiline text. When `secret_value` is `None`, the entire line becomes the finding value, causing over-redaction.

### 5. AWS_SECRET_KEY has no AKIA proximity constraint
Checking `if "AKIA" in text` globally means any 40-char base64 string anywhere in the document triggers if AKIA appears anywhere, even on a different line.

---

## Edge Cases

- **Dedup promotes narrow block over wider mask:** `_deduplicate_findings` can replace a wider mask finding with a narrower block finding, leaving unredacted text.
- **`_scan_entropy` misses base64 with `+/=`:** Regex `\b[A-Za-z0-9]{20,}\b` doesn't match base64 special chars.
- **L2 `secret_value or line` fallback:** When detect-secrets can't recover the secret value, the entire line is replaced.
- **Log level inconsistency:** Init uses `logger.info` for missing libraries; AC says "log warning".

---

## Test Coverage

| Area | Coverage | Gap |
|---|---|---|
| JWT detection | 3 positive, 1 negative | Needs 2 more negatives |
| Private key | 4 positive, 1 negative | Needs 2 more negatives |
| AWS secret key | 0 positive, 0 negative | Entirely untested |
| High-entropy | 1 positive, 2 negative | Needs 2 more positives |
| L2 specific detection | None | AC-required test missing |
| L3 NER substitution | None | AC-required test missing |
| CLI block handling | None | Feature missing |
| TS new patterns | None | Features missing |
| TS block action | None | Feature missing |

---

## Verdict Rationale

The Python L1+L2+L3 layer is well-implemented. `ScanResult`/`Finding` dataclasses, `SecretBlockedError`, and `lore.remember()` block integration are correct. However, **F2-S5 (TypeScript parity) is entirely unimplemented**, the CLI doesn't handle the new exception, multiple AC-mandated test cases are absent, and the benchmark threshold is wrong. These are not minor gaps — F2-S5 is a complete miss.
