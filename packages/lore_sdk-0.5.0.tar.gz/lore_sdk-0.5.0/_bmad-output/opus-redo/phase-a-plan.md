# Phase A — Core Pivot: Lessons → Universal Memory

## 1. PRD

### Problem

Lore is currently locked into a "lessons learned" metaphor — every piece of stored knowledge must be forced into a `problem` + `resolution` pair. This makes it unsuitable as a general-purpose AI memory layer where agents need to store arbitrary knowledge: facts, preferences, decisions, context snippets, conversation summaries, and yes, also lessons.

The rigid two-field model creates friction for MCP tool consumers (Claude Code, Cursor, etc.) who want to simply "remember X" and "recall Y" without inventing artificial problem/resolution splits.

### Value

- **Broader adoption**: A universal `remember/recall/forget` API is the natural interface every AI agent expects. Lower barrier to entry.
- **Simpler DX**: One `content` field instead of forced `problem`+`resolution`. Type-tagging (`lesson`, `fact`, `preference`, `context`) gives structure without rigidity.
- **Future-proof**: The Memory model accommodates TTL, metadata, and typed recall — the building blocks for context windows, agent personas, and knowledge graphs.

### Success Metrics

| Metric | Target |
|--------|--------|
| All existing tests replaced with equivalent Memory-based tests | 344+ tests passing |
| Zero references to `Lesson`, `problem`, `resolution` in `src/lore/` | Clean grep |
| MCP tools: `remember`, `recall`, `forget`, `list_memories`, `stats` | Functional via `lore mcp` |
| CLI: `lore remember`, `lore recall`, `lore forget`, `lore memories`, `lore stats` | Functional |
| SDK API: `lore.remember()`, `lore.recall()`, `lore.forget()` | Functional with tests |
| SQLite migration: old `lessons` table → `memories` table | Automatic on first use |
| No breaking server/ changes in Phase A | Server pivot deferred to Phase B |

---

## 2. Architecture

### 2.1 New Data Model — `Memory`

**File:** `src/lore/types.py` (replace `Lesson` and `QueryResult`)

```python
@dataclass
class Memory:
    id: str                              # ULID
    content: str                         # The memory itself (free-form text)
    type: str = "general"                # "lesson", "fact", "preference", "context", "general"
    tags: List[str] = field(default_factory=list)
    metadata: Optional[Dict[str, Any]] = None  # Replaces 'meta', structured key-value
    source: Optional[str] = None         # Who/what created this memory
    project: Optional[str] = None        # Project scope
    embedding: Optional[bytes] = None    # float32 blob (384-dim)
    created_at: str = ""                 # ISO 8601
    updated_at: str = ""                 # ISO 8601
    ttl: Optional[int] = None            # Seconds until expiry (replaces expires_at)
    expires_at: Optional[str] = None     # Computed from ttl at creation time
    confidence: float = 1.0              # Default 1.0 (was 0.5 — memories are trusted by default)
    upvotes: int = 0
    downvotes: int = 0

@dataclass
class RecallResult:
    memory: Memory
    score: float
```

**Key changes from `Lesson`:**
- `problem` + `resolution` → single `content` field
- `context` removed (fold into `content` or `metadata`)
- `meta` → `metadata` (clearer name)
- `type` field added for categorization
- `ttl` added (seconds), `expires_at` computed from it
- `confidence` default changed from 0.5 → 1.0
- `QueryResult` → `RecallResult`

**Backward compatibility for lessons:**
- A `type="lesson"` memory can store `{"problem": "...", "resolution": "..."}` in `metadata`
- The MCP `remember` tool detects `problem`/`resolution` kwargs and auto-sets `type="lesson"`, storing them in `metadata` and composing `content` as `"Problem: {p}\nResolution: {r}"`

### 2.2 Store Layer

**File:** `src/lore/store/base.py` — new `Store` ABC

```python
class Store(ABC):
    def save(self, memory: Memory) -> None
    def get(self, memory_id: str) -> Optional[Memory]
    def list(self, project: Optional[str] = None, type: Optional[str] = None,
             limit: Optional[int] = None) -> List[Memory]
    def update(self, memory: Memory) -> bool
    def delete(self, memory_id: str) -> bool
    def count(self, project: Optional[str] = None, type: Optional[str] = None) -> int
```

**File:** `src/lore/store/sqlite.py` — new schema

```sql
CREATE TABLE IF NOT EXISTS memories (
    id          TEXT PRIMARY KEY,
    content     TEXT NOT NULL,
    type        TEXT DEFAULT 'general',
    tags        TEXT,            -- JSON array
    metadata    TEXT,            -- JSON object
    source      TEXT,
    project     TEXT,
    embedding   BLOB,
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL,
    ttl         INTEGER,
    expires_at  TEXT,
    confidence  REAL DEFAULT 1.0,
    upvotes     INTEGER DEFAULT 0,
    downvotes   INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_memories_project ON memories(project);
CREATE INDEX IF NOT EXISTS idx_memories_type ON memories(type);
CREATE INDEX IF NOT EXISTS idx_memories_created ON memories(created_at);
```

**Migration strategy:** On `SqliteStore.__init__`, detect if `lessons` table exists and `memories` does not. If so, run:
```sql
CREATE TABLE memories AS SELECT
    id, (problem || '\n' || resolution) AS content,
    'lesson' AS type, tags,
    meta AS metadata, source, project, embedding,
    created_at, updated_at, NULL AS ttl, expires_at,
    confidence, upvotes, downvotes
FROM lessons;
DROP TABLE lessons;
```

**File:** `src/lore/store/memory.py` — update in-memory store to use `Memory`

### 2.3 Main SDK Class — `Lore`

**File:** `src/lore/lore.py`

New public API:

```python
class Lore:
    def remember(self, content: str, *, type: str = "general",
                 tags: List[str] = None, metadata: Dict = None,
                 source: str = None, project: str = None,
                 ttl: int = None, confidence: float = 1.0) -> str:
        """Store a memory. Returns memory ID (ULID)."""

    def recall(self, query: str, *, tags: List[str] = None,
               type: str = None, limit: int = 5,
               min_confidence: float = 0.0) -> List[RecallResult]:
        """Semantic search for memories."""

    def forget(self, memory_id: str) -> bool:
        """Delete a memory by ID."""

    def get(self, memory_id: str) -> Optional[Memory]:
        """Get a memory by ID."""

    def list_memories(self, *, project: str = None, type: str = None,
                      limit: int = None) -> List[Memory]:
        """List memories with optional filters."""

    def stats(self, project: str = None) -> Dict[str, Any]:
        """Return memory statistics (count by type, total, oldest, newest)."""

    def upvote(self, memory_id: str) -> None
    def downvote(self, memory_id: str) -> None
```

**Removed methods:** `publish()`, `query()`, `list()`, `export_lessons()`, `import_lessons()`, `as_prompt()`

**Internal changes:**
- `_query_local` → `_recall_local` (same cosine + decay logic, operates on `Memory`)
- `_query_remote` → `_recall_remote`
- Embedding text: just `content` (simpler than concatenating problem+resolution+context)
- Redaction still applied to `content` before embedding/storage

### 2.4 MCP Server

**File:** `src/lore/mcp/server.py`

New tools:

| Tool | Description |
|------|-------------|
| `remember(content, type?, tags?, metadata?, source?, project?, ttl?)` | Store a memory |
| `recall(query, tags?, type?, limit?)` | Semantic search |
| `forget(memory_id)` | Delete a memory |
| `list_memories(type?, project?, limit?)` | List memories |
| `stats(project?)` | Memory statistics |
| `upvote_memory(memory_id)` | Boost ranking |
| `downvote_memory(memory_id)` | Lower ranking |

**Removed tools:** `save_lesson`, `recall_lessons`, `upvote_lesson`, `downvote_lesson`

### 2.5 CLI

**File:** `src/lore/cli.py`

New commands:

| Command | Maps to |
|---------|---------|
| `lore remember "content" [--type] [--tags] [--ttl] [--source]` | `lore.remember()` |
| `lore recall "query" [--type] [--limit]` | `lore.recall()` |
| `lore forget <id>` | `lore.forget()` |
| `lore memories [--type] [--limit]` | `lore.list_memories()` |
| `lore stats` | `lore.stats()` |
| `lore mcp` | Start MCP server (kept) |
| `lore keys ...` | API key management (kept) |

**Removed commands:** `publish`, `query`, `list`, `export`, `import`

### 2.6 Exceptions

**File:** `src/lore/exceptions.py`

- `LessonNotFoundError` → `MemoryNotFoundError` (same shape, new name)
- Keep `LoreConnectionError`, `LoreAuthError` unchanged

### 2.7 Public API

**File:** `src/lore/__init__.py`

```python
from lore.types import Memory, RecallResult
from lore.lore import Lore
from lore.exceptions import MemoryNotFoundError

__all__ = ["Lore", "Memory", "RecallResult", "MemoryNotFoundError"]
```

**Removed exports:** `Lesson`, `QueryResult`, `LessonNotFoundError`, `as_prompt`, `LoreClient`

### 2.8 Files to Delete

| File | Reason |
|------|--------|
| `src/lore/prompt.py` | `as_prompt` is lesson-specific; recall results are self-sufficient |
| `src/lore/client.py` | Async client tightly coupled to lesson API; rebuild in Phase B |
| `src/lore/store/remote.py` | Tightly coupled to lesson API; rebuild in Phase B |

### 2.9 Files NOT Changed in Phase A

| File/Dir | Reason |
|----------|--------|
| `src/lore/embed/` | Embedding layer is model-agnostic, works as-is |
| `src/lore/redact/` | Redaction pipeline is content-agnostic, works as-is |
| `src/lore/server/` | Server pivot (PG schema, routes, models) deferred to Phase B |
| `migrations/` | PG migrations deferred to Phase B |

### 2.10 Test Strategy

All 14 test files in `tests/` must be rewritten to use `Memory`/`remember`/`recall`/`forget` instead of `Lesson`/`publish`/`query`/`delete`. The test _logic_ (what's being verified) stays the same — only the API surface changes.

Server tests (`tests/server/`) are untouched in Phase A.

---

## 3. Stories

### Story 1: New Data Model
**Replace `Lesson`/`QueryResult` with `Memory`/`RecallResult` in `types.py` and `exceptions.py`**

Acceptance Criteria:
- [ ] `Memory` dataclass with fields: id, content, type, tags, metadata, source, project, embedding, created_at, updated_at, ttl, expires_at, confidence, upvotes, downvotes
- [ ] `RecallResult` dataclass with fields: memory, score
- [ ] `MemoryNotFoundError` exception replaces `LessonNotFoundError`
- [ ] `Lesson`, `QueryResult`, `LessonNotFoundError` no longer exist
- [ ] Unit tests for Memory creation, defaults, serialization

### Story 2: Store Layer Pivot
**Update `Store` ABC, `SqliteStore`, and `MemoryStore` to use `Memory`**

Acceptance Criteria:
- [ ] `Store` ABC methods operate on `Memory` instead of `Lesson`
- [ ] `Store.count(project?, type?)` method added
- [ ] `SqliteStore` creates `memories` table with new schema
- [ ] `SqliteStore` auto-migrates `lessons` → `memories` on init (if `lessons` table exists)
- [ ] `MemoryStore` (in-memory) updated to use `Memory`
- [ ] `Store.list()` accepts optional `type` filter
- [ ] Tests: CRUD, migration from lessons table, type filtering, count

### Story 3: Core SDK Pivot
**Rewrite `Lore` class with `remember/recall/forget/list_memories/stats` API**

Acceptance Criteria:
- [ ] `Lore.remember()` stores a Memory with ULID, redaction, embedding
- [ ] `Lore.recall()` performs semantic search with cosine similarity + decay + vote scoring
- [ ] `Lore.forget()` deletes by ID, returns bool
- [ ] `Lore.list_memories()` lists with project/type/limit filters
- [ ] `Lore.stats()` returns `{total, by_type: {type: count}, oldest, newest}`
- [ ] `Lore.upvote()` / `Lore.downvote()` work on memory IDs
- [ ] TTL: if `ttl` provided, `expires_at` computed at creation; expired memories excluded from recall
- [ ] `publish()`, `query()`, `as_prompt()`, `export_lessons()`, `import_lessons()` removed
- [ ] Tests: remember/recall round-trip, TTL expiry, type filtering, stats, decay, voting

### Story 4: Delete Legacy Code
**Remove `prompt.py`, `client.py`, `store/remote.py`, and all legacy references**

Acceptance Criteria:
- [ ] `src/lore/prompt.py` deleted
- [ ] `src/lore/client.py` deleted
- [ ] `src/lore/store/remote.py` deleted
- [ ] `src/lore/__init__.py` exports only: `Lore`, `Memory`, `RecallResult`, `MemoryNotFoundError`
- [ ] No import of `Lesson`, `QueryResult`, `LessonNotFoundError`, `as_prompt`, `LoreClient` anywhere in `src/lore/`
- [ ] `grep -r "Lesson\|problem.*resolution\|publish\|query_result" src/lore/` returns zero hits (excluding comments explaining migration)
- [ ] All legacy test files deleted or rewritten (no `test_lesson.py`, `test_prompt.py`, `test_remote_store.py`, `test_client.py` referencing old types)

### Story 5: MCP Server Pivot
**Replace lesson MCP tools with memory tools**

Acceptance Criteria:
- [ ] `remember` tool: stores memory via `lore.remember()`
- [ ] `recall` tool: semantic search via `lore.recall()`, formatted output
- [ ] `forget` tool: deletes memory via `lore.forget()`
- [ ] `list_memories` tool: lists via `lore.list_memories()`
- [ ] `stats` tool: returns `lore.stats()` formatted
- [ ] `upvote_memory` / `downvote_memory` tools
- [ ] `save_lesson`, `recall_lessons`, `upvote_lesson`, `downvote_lesson` removed
- [ ] MCP server instructions updated to reflect memory-centric language
- [ ] Tool descriptions guide agents on when/how to use each tool
- [ ] Smoke test: start MCP server, call each tool

### Story 6: CLI Pivot
**Replace lesson CLI commands with memory commands**

Acceptance Criteria:
- [ ] `lore remember "content" [--type TYPE] [--tags t1,t2] [--ttl SECS] [--source SRC]` — prints memory ID
- [ ] `lore recall "query" [--type TYPE] [--limit N]` — prints scored results
- [ ] `lore forget <id>` — prints confirmation
- [ ] `lore memories [--type TYPE] [--limit N]` — prints table
- [ ] `lore stats` — prints statistics
- [ ] `lore mcp` — still works
- [ ] `lore keys ...` — still works
- [ ] `publish`, `query`, `list`, `export`, `import` commands removed
- [ ] `--db` global flag still works
- [ ] CLI tests updated

### Story 7: Test Suite Overhaul
**Rewrite all SDK tests for the Memory model**

Acceptance Criteria:
- [ ] `test_memory.py` — Memory dataclass, defaults, type field
- [ ] `test_stores.py` — MemoryStore + SqliteStore with Memory, migration test
- [ ] `test_recall.py` — semantic recall, tag/type filtering, decay, performance (1000 memories < 500ms)
- [ ] `test_redact.py` — unchanged (redaction is content-agnostic)
- [ ] `test_redact_integration.py` — redaction in `remember()` flow
- [ ] `test_decay_voting.py` — upvote/downvote, time decay on memories
- [ ] `test_edge_cases.py` — unicode, long text, SQL injection, empty DB with memory API
- [ ] `test_embedder.py` — unchanged (embedder is model-agnostic)
- [ ] `test_cli.py` — CLI commands: remember, recall, forget, memories, stats
- [ ] `test_mcp.py` — MCP tool tests (new file or extend existing)
- [ ] All 344+ tests passing
- [ ] `test_prompt.py` deleted
- [ ] `test_remote_store.py` deleted
- [ ] `test_client.py` deleted
- [ ] `test_export_import.py` deleted (export/import deferred)
- [ ] `test_lesson.py` deleted

### Story 8: Integration Verification
**End-to-end verification that the pivot is clean**

Acceptance Criteria:
- [ ] `grep -rn "Lesson\b" src/lore/` returns zero hits
- [ ] `grep -rn "problem.*resolution" src/lore/` returns zero hits (in code, not comments)
- [ ] `grep -rn "publish\b" src/lore/` returns zero hits (as method name)
- [ ] `python -c "from lore import Lore, Memory, RecallResult, MemoryNotFoundError"` succeeds
- [ ] `python -c "from lore import Lesson"` raises ImportError
- [ ] `pytest tests/ -x` passes all tests
- [ ] `ruff check src/lore/` passes
- [ ] `lore remember "test" && lore recall "test" && lore stats` works end-to-end
- [ ] `lore mcp` starts without errors

---

## Implementation Order

```
Story 1 (types) → Story 2 (store) → Story 3 (SDK) → Story 4 (cleanup) → Story 5 (MCP) → Story 6 (CLI) → Story 7 (tests) → Story 8 (verify)
```

Stories 1-3 form the core pivot. Story 4 removes dead code. Stories 5-6 update the interfaces. Story 7 ensures coverage. Story 8 is the final gate.

**Note:** Story 7 (tests) should be developed incrementally alongside Stories 1-6, not as a big-bang at the end. Each story should include its own tests. Story 7 is listed separately to track the full test suite overhaul as a deliverable.
