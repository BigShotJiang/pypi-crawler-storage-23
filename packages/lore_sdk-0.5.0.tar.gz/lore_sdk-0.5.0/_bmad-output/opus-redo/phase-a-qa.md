# Phase A QA Report

**Reviewer:** QA-OPUS-4.6
**Date:** 2026-03-04
**Commit under review:** 47efff2
**Base plan:** `_bmad-output/opus-redo/phase-a-plan.md`

## Verdict: CONDITIONAL

Phase A is functionally complete and all tests pass. However, there are several deviations from the plan that need acknowledgment or correction: deprecated aliases are still exported (plan says "no longer exist"), deprecated methods are kept (plan says "removed"), a `context` field was added that the plan explicitly removed, and `stats()` returns a `MemoryStats` dataclass instead of `Dict[str, Any]`. These are mostly conservative deviations (backward-compatible), but they contradict specific acceptance criteria.

## Test Results

```
327 passed, 7 skipped in 6.49s
```

The 7 skips are in `tests/integration/test_remote.py` (2 skips) and `tests/server/test_rate_limit.py` (5 skips) -- both expected. Ruff passes cleanly. No failures.

The plan targeted 344+ tests. The actual count is 327 because legacy test files (test_prompt.py, test_client.py, test_remote_store.py, test_export_import.py, test_lesson.py) were deleted without 1:1 replacement -- the removed functionality has no equivalent in the new API. This is acceptable.

## Story-by-Story Review

### Story 1: New Data Model
**Status: CONDITIONAL**

All planned fields are present with correct defaults. `RecallResult` is correctly defined. `MemoryNotFoundError` replaces `LessonNotFoundError`. Unit tests cover creation, defaults, full fields, and RecallResult.

**Issues:**
1. **`context` field added (deviation):** The plan says "`context` removed (fold into `content` or `metadata`)" but `Memory` has `context: Optional[str] = None` at line 16 of `types.py`. This is an undocumented addition.
2. **Deprecated aliases retained:** `types.py:51` has `Lesson = Memory` and `types.py:52` has `QueryResult = RecallResult`. The plan (Story 1 AC) says "Lesson, QueryResult, LessonNotFoundError no longer exist." Similarly `exceptions.py:21` has `LessonNotFoundError = MemoryNotFoundError`.
3. **`MemoryStats` dataclass added (deviation):** `types.py:40-47` defines a `MemoryStats` dataclass not in the plan. The plan says `stats()` returns `Dict[str, Any]`. This is a reasonable improvement but a deviation.

### Story 2: Store Layer Pivot
**Status: PASS**

- `Store` ABC operates on `Memory` with all 6 planned methods (save, get, list, update, delete, count) plus `cleanup_expired` (a good addition for TTL support).
- `Store.count(project?, type?)` is present.
- `SqliteStore` creates `memories` table with correct schema, 3 indexes.
- `SqliteStore._maybe_migrate()` auto-migrates `lessons` -> `memories` with correct SQL (problem+resolution -> content, type='lesson', meta -> metadata).
- `SqliteStore._maybe_add_context_column()` handles schema evolution for the `context` column.
- `MemoryStore` updated to use `Memory` with type/project filtering and count.
- `Store.list()` accepts optional `type` filter.
- Tests: `test_stores.py` has 55 tests (parameterized across both stores) covering CRUD, migration, type filtering, count, TTL roundtrip.

### Story 3: Core SDK Pivot
**Status: CONDITIONAL**

All core methods are implemented correctly:
- `remember()` stores Memory with ULID, redaction, embedding, TTL -> expires_at computation, confidence validation.
- `recall()` performs semantic search with cosine similarity + time decay + vote scoring + tag/type/min_confidence filters.
- `forget()` deletes by ID, returns bool.
- `list_memories()` lists with project/type/limit filters, excludes expired memories.
- `stats()` returns correct aggregate data (total, by_type, oldest, newest).
- `upvote()`/`downvote()` work on memory IDs, raise MemoryNotFoundError for missing.
- TTL: `expires_at` computed from `ttl` at creation; expired memories excluded from recall and list_memories.
- Lazy cleanup: `_maybe_cleanup_expired()` runs at most every 60s during recall.

**Issues:**
4. **Deprecated methods NOT removed (deviation):** The plan (Story 3 AC) says `publish()`, `query()`, `as_prompt()`, `export_lessons()`, `import_lessons()` should be **removed**. Instead, `publish()`, `query()`, `export_lessons()`, `import_lessons()`, and `delete()` are all kept as deprecated wrappers (lines 371-470 of `lore.py`). Only `as_prompt()` was actually removed.
5. **`stats()` returns `MemoryStats` instead of `Dict[str, Any]`:** Plan says the return type is `Dict[str, Any]` with `{total, by_type, oldest, newest}`. The implementation returns a `MemoryStats` dataclass. This is arguably better for type safety but deviates from the spec.

### Story 4: Delete Legacy Code
**Status: FAIL**

- `src/lore/prompt.py` -- deleted. Confirmed.
- `src/lore/client.py` -- deleted. Confirmed.
- `src/lore/store/remote.py` -- deleted. Confirmed.

**Issues:**
6. **`__init__.py` exports deprecated aliases:** The plan says exports should be ONLY `Lore`, `Memory`, `RecallResult`, `MemoryNotFoundError`. The actual `__init__.py` also exports `Lesson`, `QueryResult`, `LessonNotFoundError`, and `MemoryStats`. This directly violates Story 4 AC: "No import of Lesson, QueryResult, LessonNotFoundError, as_prompt, LoreClient anywhere in src/lore/".
7. **`grep -r "Lesson" src/lore/` does NOT return zero hits:** The plan specifically requires zero hits (excluding comments). Actual results include:
   - `types.py:51: Lesson = Memory`
   - `__init__.py:5: from lore.types import Lesson, ...`
   - `__init__.py:14: "Lesson",`
   - `exceptions.py:21: LessonNotFoundError = MemoryNotFoundError`
   - Plus all `server/` references (which are expected per plan)
8. **`grep -r "publish" src/lore/` does NOT return zero hits:** The plan requires zero hits for `publish` as a method name. Actual results include `lore.py:371: def publish(...)` and multiple CLI references. The plan said "removed" not "deprecated".
9. **`from lore import Lesson` succeeds instead of raising ImportError:** Story 8 AC explicitly requires this to fail. It does not fail.

### Story 5: MCP Server Pivot
**Status: PASS**

All 7 MCP tools implemented correctly: `remember`, `recall`, `forget`, `list_memories`, `stats`, `upvote_memory`, `downvote_memory`. Old tools (`save_lesson`, `recall_lessons`, etc.) are gone. Server instructions are memory-centric. Tool descriptions provide clear agent guidance. Tests cover all 7 tools (10 tests in `test_mcp.py`). No references to legacy API in the MCP layer.

### Story 6: CLI Pivot
**Status: CONDITIONAL**

New commands all work correctly:
- `lore remember "content" [--type] [--tags] [--ttl] [--source] [--confidence]` -- prints memory ID
- `lore recall "query" [--type] [--tags] [--limit]` -- prints scored results
- `lore forget <id>` -- prints confirmation
- `lore memories [--type] [--limit]` -- prints table
- `lore stats` -- prints statistics
- `lore mcp` -- preserved
- `lore keys ...` -- preserved
- `--db` global flag works

**Issues:**
10. **Deprecated CLI commands retained:** The plan says `publish`, `query`, `list`, `export`, `import` commands should be **removed**. Instead, `publish` and `query` are kept as deprecated commands (lines 94-123, 253-260 of `cli.py`). `list`, `export`, `import` do appear to be removed, which is partial compliance.
11. **`--context` flag added:** The CLI `remember` command has a `--context` flag (line 228) which was not in the plan. Consistent with the `context` field deviation noted in Story 1.

### Story 7: Test Suite Overhaul
**Status: PASS**

All required test files exist and pass:
- `test_memory.py` -- 5 tests (Memory dataclass, defaults, type, RecallResult)
- `test_stores.py` -- 55 tests (both stores, CRUD, migration, type filtering, count, TTL)
- `test_recall.py` -- 11 tests (semantic recall, tag/type filtering, performance 1000 memories < 500ms)
- `test_redact.py` -- 30 tests (unchanged, content-agnostic)
- `test_redact_integration.py` -- 5 tests (redaction in remember() flow)
- `test_decay_voting.py` -- 15 tests (upvote/downvote, time decay, TTL/expires_at, configurable half-life, vote factor clamping)
- `test_edge_cases.py` -- 25 tests (unicode, long text, SQL injection, empty DB, confidence boundaries, special chars)
- `test_embedder.py` -- 9 tests (unchanged, model-agnostic)
- `test_cli.py` -- 14 tests (parsing + integration for all commands)
- `test_mcp.py` -- 10 tests (all 7 MCP tools)

All legacy test files deleted: test_prompt.py, test_remote_store.py, test_client.py, test_export_import.py, test_lesson.py. Confirmed none exist.

### Story 8: Integration Verification
**Status: FAIL**

| Check | Expected | Actual | Status |
|-------|----------|--------|--------|
| `grep -rn "Lesson\b" src/lore/` zero hits | Zero | 4 hits (aliases in types.py, __init__.py, exceptions.py) + server/ hits | FAIL |
| `grep -rn "problem.*resolution" src/lore/` zero in code | Zero (excl. migration SQL) | 1 hit in lore.py:384 (deprecated publish wrapper), 1 in migration SQL | CONDITIONAL |
| `grep -rn "publish\b" src/lore/` zero as method name | Zero | 6 hits (deprecated method + CLI wrapper) | FAIL |
| `from lore import Lore, Memory, RecallResult, MemoryNotFoundError` succeeds | OK | OK | PASS |
| `from lore import Lesson` raises ImportError | ImportError | Succeeds (alias) | FAIL |
| `pytest tests/ -x` passes all tests | All pass | 327 passed, 7 skipped | PASS |
| `ruff check src/lore/` passes | Pass | All checks passed | PASS |

## Issues Found

1. **`context` field added to Memory (deviation from plan):** Plan explicitly says "context removed (fold into content or metadata)." Implementation adds `context: Optional[str] = None` to Memory, adds it to SqliteStore schema, CLI, and remember(). This is a functional addition not in the spec.

2. **Deprecated aliases exported (`Lesson`, `QueryResult`, `LessonNotFoundError`):** Plan says these should "no longer exist." They are present as aliases in types.py and exceptions.py and exported from `__init__.py`. This violates Stories 1, 4, and 8 acceptance criteria.

3. **Deprecated methods retained (`publish()`, `query()`, `delete()`, `export_lessons()`, `import_lessons()`):** Plan says these should be "removed." They are kept as deprecated wrappers with DeprecationWarning. Only `as_prompt()` was actually deleted.

4. **`stats()` returns `MemoryStats` dataclass instead of `Dict[str, Any]`:** Minor deviation. The MemoryStats dataclass is arguably better than a plain dict, but it was not in the plan.

5. **Deprecated CLI commands `publish` and `query` retained:** Plan says these should be removed. They emit deprecation warnings but still function.

6. **Test count 327 < 344 target:** Acceptable -- the gap is explained by deletion of legacy test files with no 1:1 replacement needed.

## Edge Cases

Well-covered. The test suite tests:
- Unicode (CJK, emoji, Arabic, mixed scripts)
- SQL injection attempts
- Null bytes, special characters, newlines/tabs
- Very long text (100K chars)
- Empty DB operations (recall, list, stats, get, forget)
- Confidence boundary validation (0.0, 1.0, negative, >1.0)
- Vote factor clamping at 0.1 with massive downvotes
- TTL/expires_at computation and exclusion
- Performance (1000 memories recall < 500ms)

**Not tested:**
- TTL=0 (immediate expiry) -- minor, works implicitly
- Concurrent access to SqliteStore -- out of scope for Phase A
- Very large number of tags -- minor

## Code Quality

- Clean separation: types.py, store/base.py, store/sqlite.py, store/memory.py, lore.py, mcp/server.py, cli.py
- Good use of parameterized fixtures in test_stores.py to test both store backends
- Vectorized cosine similarity with numpy is efficient
- Redaction pipeline properly wired into remember() with configurable patterns
- Context manager support (with statement) on Lore and SqliteStore
- MCP tool error handling wraps all calls in try/except
- Ruff passes cleanly
- The deprecated method wrappers, while deviating from the plan, are well-implemented with proper DeprecationWarning and stacklevel=2

**Minor observations:**
- `list_memories()` fetches ALL memories then filters expired in Python (line 306: `limit=None`). For large databases, this could be inefficient. The expired filtering should ideally happen in SQL.
- `recall()` similarly loads all memories and filters in Python. Acceptable for local SQLite but worth noting.
- The `_maybe_add_context_column()` migration is a good defensive pattern for schema evolution.

## Summary

Phase A successfully pivots the core data model from Lesson to Memory, with all major functionality working correctly: remember/recall/forget/list/stats, MCP tools, CLI commands, store layer with migration, embedding, redaction, TTL support, and decay/voting. All 327 tests pass and ruff is clean.

However, the implementation deviates from the plan in one significant way: it retains backward-compatible deprecated aliases and methods that the plan explicitly said should be removed. This is a reasonable engineering choice for smooth upgrades but fails 3 of the 8 stories' acceptance criteria as written. The `context` field addition is also undocumented. Verdict is CONDITIONAL pending a decision on whether the deprecated wrappers should be removed to match the plan, or the plan should be amended to reflect the chosen backward-compatibility strategy.
