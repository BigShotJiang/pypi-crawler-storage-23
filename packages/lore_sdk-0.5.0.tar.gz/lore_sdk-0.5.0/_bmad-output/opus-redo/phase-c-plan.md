# Phase C — Advanced Features Plan

> **Status:** Draft | **Date:** 2026-03-04
> **Scope:** 5 differentiating features (F1–F5) for Lore post-Phase A+B

---

## 1. PRD — Product Requirements Document

### Vision

Phase C transforms Lore from a reliable memory layer into an **intelligent, self-maintaining knowledge system**. These five features address the core problems teams face with growing knowledge bases: information rot (F1, F5), security exposure (F2), embedding quality (F3), siloed knowledge (F4), and stale guidance (F5).

### Target Users

| Persona | Pain Point | Features |
|---------|-----------|----------|
| Solo developer | Memories accumulate, old ones pollute results | F1, F5 |
| Security-conscious team | Accidental PII/secret leakage into memory | F2 |
| Mixed codebase team | Code snippets poorly matched by prose embeddings | F3 |
| OSS maintainers | Tribal knowledge trapped in GitHub, not searchable | F4 |
| AI agent builders | Agent acts on stale code patterns | F1, F5 |

### Success Metrics

| Feature | Metric | Target |
|---------|--------|--------|
| F1 Semantic Decay | Recall@5 improvement for recent lessons | +15% vs flat ranking |
| F2 Security Pipeline | PII/secret detection rate | >95% for L1+L2 patterns |
| F3 Dual Embedding | Code-query recall@5 | +20% vs single model |
| F4 GitHub Sync | Time to searchable knowledge from PR merge | <60s incremental |
| F5 Freshness Detection | Stale memory identification accuracy | >80% precision |

### Non-Goals (Phase C)

- Real-time streaming sync (F4 uses polling/CLI-triggered)
- Custom user-trained embedding models (F3 uses pre-trained only)
- Auto-remediation of stale memories (F5 flags only, user decides)
- Paid PII scanning services (F2 uses local-only tooling)

### Dependencies & Constraints

| Feature | Hard Dependencies | Optional Dependencies |
|---------|------------------|----------------------|
| F1 | None (extends existing decay) | None |
| F2 | None (L1 regex always available) | `detect-secrets` (L2), `spacy` (L3) |
| F3 | ONNX Runtime (already required) | None |
| F4 | `gh` CLI installed & authenticated | None |
| F5 | `git` CLI, lessons with `meta.file_path` | None |

### Rollout Strategy

All features are **opt-in** with sensible defaults:
- F1: Enabled by default (backward-compatible scoring change)
- F2: L1 enabled by default (already exists), L2/L3 opt-in
- F3: Disabled by default, enable via `dual_embedding=True`
- F4: CLI command, no background process
- F5: CLI command + MCP tool, on-demand only

---

## 2. Architecture

### F1: Semantic Decay Scoring

#### Current State

The existing scoring formula is:
```
score = cosine_similarity * confidence * time_decay * vote_factor
```
Where `time_decay = 0.5 ^ (age_days / half_life_days)` with a single `half_life_days=30` for all memory types.

#### Target State

Replace the multiplicative blend with a **weighted additive** formula that separates semantic relevance from freshness, and introduces **type-specific half-lives**:

```
final_score = 0.7 * similarity + 0.3 * freshness
```

Where:
```
similarity  = cosine_similarity * confidence * vote_factor
freshness   = 0.5 ^ (age_days / half_life)
half_life   = HALF_LIVES.get(lesson.meta.get("type"), 30)
```

**Type-specific half-lives (days):**

| Type | Half-Life | Rationale |
|------|-----------|-----------|
| `code` | 14 | Code patterns change frequently |
| `note` | 21 | General notes moderate decay |
| `lesson` | 30 | Lessons from experience are durable (default) |
| `convention` | 60 | Conventions change slowly |

#### Data Model Changes

- `Lesson.meta["type"]` — optional string field, one of `code | note | lesson | convention`
- No schema migration needed (uses existing `meta` JSON column)

#### Files Modified

| File | Change |
|------|--------|
| `src/lore/lore.py` | New `_compute_score()` with weighted additive formula |
| `src/lore/types.py` | Add `DECAY_HALF_LIVES` constant dict |
| `src/lore/cli.py` | Add `--type` flag to `publish` command |
| `src/lore/mcp/server.py` | Add optional `type` param to `save_lesson` tool |
| `ts/src/embed.ts` | Mirror scoring formula change |
| `ts/src/lore.ts` | Mirror scoring formula change |
| `src/lore/server/routes/lessons.py` | Update SQL scoring formula |

#### Backward Compatibility

- Lessons without `meta.type` default to half-life=30 (current behavior)
- The 0.7/0.3 weights produce similar rankings to the old formula for typical age distributions
- Constructor parameter `decay_half_life_days` still works as a global override

---

### F2: Security Pipeline (PII & Secret Scanning)

#### Current State

Lore already has a 6-pattern regex-based `RedactionPipeline` in `src/lore/redact/`:
- API keys, emails, phones, IPs, credit cards, custom patterns
- Masks detected PII with `[REDACTED:type]`
- Enabled by default (`redact=True`)

#### Target State

Extend to a **3-layer pipeline** with escalating detection capability:

```
Input text
    ↓
┌─────────────────────┐
│ L1: Regex Patterns   │  ← Always active (existing + expanded)
│ (fast, ~0.1ms)       │
└─────────┬───────────┘
          ↓
┌─────────────────────┐
│ L2: detect-secrets   │  ← Optional dependency
│ (entropy analysis)   │
└─────────┬───────────┘
          ↓
┌─────────────────────┐
│ L3: SpaCy NER        │  ← Optional dependency
│ (named entities)     │
└─────────┬───────────┘
          ↓
Scan Result {findings: [...], action: "mask" | "block"}
```

**Action Rules:**
- PII (names, emails, phones, addresses) → **mask** with `[REDACTED:type]` and store
- Secrets (API keys, tokens, private keys) → **block** storage entirely, return error
- Configurable: users can override action per pattern type

#### Layer Details

**L1 (Regex — always active):**
- Extend existing `patterns.py` with:
  - AWS secret keys (`(?<![A-Za-z0-9/+=])[A-Za-z0-9/+=]{40}(?![A-Za-z0-9/+=])` near `AKIA`)
  - Private key blocks (`-----BEGIN .* PRIVATE KEY-----`)
  - JWT tokens (`eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+`)
  - Generic high-entropy strings (>4.5 Shannon entropy, 20+ chars)

**L2 (detect-secrets — optional):**
- Import: `from detect_secrets.core.scan import scan_line`
- Catches: hex-encoded secrets, base64 keys, keyword-value pairs
- Graceful skip if not installed

**L3 (SpaCy NER — optional):**
- Model: `en_core_web_sm` (~12MB)
- Entities: `PERSON`, `ORG`, `GPE`, `LOC` → mask
- Graceful skip if not installed

#### Files Modified/Created

| File | Change |
|------|--------|
| `src/lore/redact/patterns.py` | Add new L1 patterns (JWT, private keys, entropy) |
| `src/lore/redact/pipeline.py` | Refactor to 3-layer architecture, add block action |
| `src/lore/redact/detect_secrets_layer.py` | **New** — L2 wrapper |
| `src/lore/redact/ner_layer.py` | **New** — L3 SpaCy wrapper |
| `src/lore/exceptions.py` | Add `SecretBlockedError` |
| `src/lore/lore.py` | Handle block action (raise or return error) |
| `ts/src/redact.ts` | Mirror L1 pattern additions (L2/L3 Python-only) |
| `pyproject.toml` | Add optional deps: `detect-secrets`, `spacy` |

#### Configuration

```python
Lore(
    redact=True,                    # existing
    redact_patterns=[...],          # existing custom patterns
    security_scan_levels=[1, 2, 3], # NEW: which layers to enable (default [1])
    security_action_overrides={     # NEW: override per type
        "email": "mask",            # default
        "api_key": "block",         # default
    },
)
```

---

### F3: Dual Embedding Routing

#### Current State

Single embedding model: `all-MiniLM-L6-v2` (384-dim, general-purpose, prose-optimized).

#### Target State

**Two specialized models**, auto-routed by content type:

| Model | Purpose | Dimensions | Size |
|-------|---------|------------|------|
| `all-MiniLM-L6-v2` | Prose/natural language | 384 | ~80MB |
| `all-MiniLM-L6-v2-code` (or `codebert-base-mlm` distilled to 384) | Code/technical content | 384 | ~80MB |

> **Fallback:** If code model unavailable, use prose model for everything (graceful degradation).

#### Content Detection

Heuristic classifier to route content:

```python
def detect_content_type(text: str) -> Literal["code", "prose"]:
    """Classify text as code or prose using lightweight heuristics."""
    indicators = 0
    # Code indicators
    if re.search(r'[{};()]\s*$', text, re.MULTILINE):  indicators += 2
    if re.search(r'(def |function |class |import |from |const |let |var )', text): indicators += 2
    if re.search(r'(=>|->|::|\.\.)', text):             indicators += 1
    if text.count('\n') > 0 and text.count('  ') / text.count('\n') > 0.5: indicators += 1
    if re.search(r'```', text):                          indicators += 2

    return "code" if indicators >= 3 else "prose"
```

#### Embedding Model Tracking

Store which model embedded each lesson in `meta`:

```python
lesson.meta["embed_model"] = "prose"  # or "code"
```

**Search-time behavior:**
- Query is embedded with **both** models
- Each lesson is compared against its **matching** model's query embedding
- This ensures code lessons use code embeddings and prose lessons use prose embeddings

#### Architecture

```
publish("def foo(): ...")
    ↓
detect_content_type() → "code"
    ↓
code_embedder.embed() → [384-dim vector]
    ↓
store(embedding=vec, meta={"embed_model": "code"})

query("how to handle rate limiting")
    ↓
prose_embedder.embed() → query_vec_prose
code_embedder.embed()  → query_vec_code
    ↓
for each lesson:
    if lesson.meta.embed_model == "code":
        score = cosine(lesson.embedding, query_vec_code)
    else:
        score = cosine(lesson.embedding, query_vec_prose)
```

#### Files Modified/Created

| File | Change |
|------|--------|
| `src/lore/embed/local.py` | Add `CodeEmbedder` class, model download logic |
| `src/lore/embed/router.py` | **New** — `EmbeddingRouter` with content detection |
| `src/lore/embed/base.py` | Update `Embedder` protocol if needed |
| `src/lore/lore.py` | Use router when `dual_embedding=True` |
| `src/lore/types.py` | Document `meta.embed_model` convention |
| `ts/src/embed.ts` | Mirror content detection heuristic |
| `ts/src/lore.ts` | Support dual embedding fn option |

#### Migration

- Existing lessons without `meta.embed_model` are treated as `"prose"` (current model)
- No re-embedding required; new lessons get tagged automatically
- Optional CLI command: `lore reindex --dual` to re-embed old lessons

---

### F4: GitHub Sync

#### Overview

Ingest GitHub repository metadata (PRs, issues, commits, releases) as searchable Lore memories. Uses the `gh` CLI for authentication and API access.

#### Data Mapping

| GitHub Entity | Lore Lesson Fields |
|--------------|-------------------|
| PR (merged) | problem=title, resolution=body+review summary, tags=[`github`, `pr`, labels...], meta={`gh_type`: `pr`, `gh_number`: N, `gh_repo`: owner/repo, `gh_url`: url, `gh_merged_at`: ts} |
| Issue (closed) | problem=title+body, resolution=closing comment or linked PR, tags=[`github`, `issue`, labels...], meta={`gh_type`: `issue`, `gh_number`: N, ...} |
| Commit (notable) | problem=commit subject, resolution=commit body, tags=[`github`, `commit`], meta={`gh_type`: `commit`, `gh_sha`: sha, ...} |
| Release | problem=release name, resolution=release body/changelog, tags=[`github`, `release`, tag], meta={`gh_type`: `release`, `gh_tag`: tag, ...} |

#### Incremental Sync

Track sync state in `meta` or a dedicated sync-state table:

```json
// Stored in ~/.lore/sync_state.json
{
  "owner/repo": {
    "last_sync": "2026-03-04T12:00:00Z",
    "last_pr": 142,
    "last_issue": 89,
    "last_release": "v2.1.0"
  }
}
```

On subsequent runs, only fetch entities created/updated after `last_sync`.

#### CLI Interface

```bash
# Full sync (first time)
lore github-sync --repo owner/repo

# Incremental sync (subsequent)
lore github-sync --repo owner/repo  # auto-detects last sync point

# Selective sync
lore github-sync --repo owner/repo --types prs,issues
lore github-sync --repo owner/repo --since 2026-01-01

# Dry run
lore github-sync --repo owner/repo --dry-run

# List synced repos
lore github-sync --list
```

#### Architecture

```
CLI: lore github-sync --repo owner/repo
    ↓
GitHubSyncer(repo, store, embedder)
    ↓
┌────────────────┐
│ gh api graphql  │ ← paginated queries
│ (PRs, Issues,   │
│  Commits, etc.) │
└───────┬────────┘
        ↓
    Transform to Lesson[]
        ↓
    Deduplicate (by meta.gh_type + meta.gh_number)
        ↓
    Embed + Store (batch)
        ↓
    Update sync_state.json
```

#### Files Created

| File | Purpose |
|------|---------|
| `src/lore/github/__init__.py` | Package init |
| `src/lore/github/syncer.py` | `GitHubSyncer` class — orchestrates sync |
| `src/lore/github/transforms.py` | GitHub API response → Lesson transforms |
| `src/lore/github/state.py` | Sync state persistence (~/.lore/sync_state.json) |
| `src/lore/cli.py` | Add `github-sync` subcommand |
| `src/lore/mcp/server.py` | Add `github_sync` tool (optional) |

#### Error Handling

- `gh` CLI not found → clear error: "Install GitHub CLI: https://cli.github.com"
- Auth failure → "Run `gh auth login` first"
- Rate limiting → exponential backoff with `gh api` built-in retry
- Partial failure → save what succeeded, report what failed, resume on next sync

---

### F5: Freshness Detection

#### Overview

Compare code-pattern memories against the current git state to detect stale lessons. Uses commit history analysis to determine if files/patterns referenced in a lesson have changed significantly since the lesson was created.

#### Staleness Algorithm

```python
def compute_staleness(lesson: Lesson, repo_path: str) -> StalenessResult:
    """
    Check if a lesson's referenced code has changed since lesson creation.
    """
    file_path = lesson.meta.get("file_path")
    if not file_path:
        return StalenessResult(status="unknown", reason="no file_path in meta")

    # Count commits to file since lesson creation
    commits_since = git_log_count(
        repo_path, file_path, since=lesson.created_at
    )

    if commits_since >= 25:
        return StalenessResult(status="stale", confidence=0.9, commits=commits_since)
    elif commits_since >= 10:
        return StalenessResult(status="likely_stale", confidence=0.6, commits=commits_since)
    elif commits_since >= 3:
        return StalenessResult(status="possibly_stale", confidence=0.3, commits=commits_since)
    else:
        return StalenessResult(status="fresh", confidence=0.1, commits=commits_since)
```

**Commit Thresholds:**

| Commits Since Lesson | Status | Confidence |
|---------------------|--------|------------|
| 0–2 | `fresh` | 0.1 |
| 3–9 | `possibly_stale` | 0.3 |
| 10–24 | `likely_stale` | 0.6 |
| 25+ | `stale` | 0.9 |

#### Enhanced Detection (Optional)

Beyond commit count, optionally check:
- **Content diff:** Did the specific code pattern from `lesson.problem` disappear from the file?
- **Function existence:** If lesson references a function name, does it still exist?
- **File existence:** Has the file been deleted or moved?

#### Data Model

```python
@dataclass
class StalenessResult:
    lesson_id: str
    status: Literal["fresh", "possibly_stale", "likely_stale", "stale", "unknown"]
    confidence: float        # 0.0–1.0
    commits_since: int       # commits to referenced file since lesson creation
    file_exists: bool        # does the referenced file still exist?
    reason: str              # human-readable explanation
```

#### CLI Interface

```bash
# Check all lessons for staleness
lore freshness --repo /path/to/repo

# Check specific project's lessons
lore freshness --repo . --project my-agent

# Output formats
lore freshness --repo . --format table    # default
lore freshness --repo . --format json

# Filter by staleness level
lore freshness --repo . --min-staleness likely_stale

# Auto-tag stale lessons (adds "stale" tag)
lore freshness --repo . --auto-tag
```

**Example Output:**
```
Freshness Report for /home/user/my-project
───────────────────────────────────────────
ID              Status          Commits  File              Problem
01HXYZ...       stale (0.9)     32       src/auth.py       JWT validation pattern
01HABC...       likely_stale    12       src/api/routes.py Rate limiting approach
01HDEF...       fresh (0.1)     1        src/models.py     User schema validation

Summary: 1 stale, 1 likely stale, 1 fresh (3 total, 2 unknown/no file_path)
```

#### MCP Tool

```python
@mcp.tool()
def check_freshness(repo_path: str, project: str = None) -> str:
    """Check if stored lessons are still fresh against current git state."""
    # Returns formatted markdown report
```

#### Files Created/Modified

| File | Purpose |
|------|---------|
| `src/lore/freshness/__init__.py` | Package init |
| `src/lore/freshness/detector.py` | `FreshnessDetector` class |
| `src/lore/freshness/git_ops.py` | Git CLI wrapper (commit counting, file existence) |
| `src/lore/freshness/types.py` | `StalenessResult` dataclass |
| `src/lore/cli.py` | Add `freshness` subcommand |
| `src/lore/mcp/server.py` | Add `check_freshness` tool |

---

### Cross-Feature Architecture Diagram

```
                    ┌──────────────┐
                    │   CLI / MCP   │
                    │   / SDK API   │
                    └──────┬───────┘
                           │
          ┌────────────────┼────────────────┐
          │                │                │
    ┌─────▼─────┐   ┌─────▼─────┐   ┌─────▼──────┐
    │ F4: GitHub │   │   Lore    │   │ F5: Fresh- │
    │   Syncer   │   │   Core    │   │   ness Det │
    └─────┬─────┘   └─────┬─────┘   └─────┬──────┘
          │                │                │
          │          ┌─────▼─────┐          │
          │          │ F2: Secur │          │
          │          │ Pipeline  │          │
          │          │ L1→L2→L3  │          │
          │          └─────┬─────┘          │
          │                │                │
          │          ┌─────▼─────┐          │
          │          │ F3: Dual  │          │
          │          │ Embed Rtr │          │
          │          └─────┬─────┘          │
          │                │                │
          │          ┌─────▼─────┐          │
          └─────────►│  Store    │◄─────────┘
                     │ (SQLite/  │
                     │  Remote)  │
                     └─────┬─────┘
                           │
                     ┌─────▼─────┐
                     │ F1: Decay │
                     │ Scoring   │
                     │ (query)   │
                     └───────────┘
```

---

## 3. Stories with Acceptance Criteria

---

### F1: Semantic Decay Scoring

#### F1-S1: Type-specific half-life constants

**As a** developer configuring Lore,
**I want** different memory types to decay at different rates,
**So that** code patterns decay faster than conventions.

**ACs:**
- [ ] `DECAY_HALF_LIVES` dict defined in `types.py`: `{"code": 14, "note": 21, "lesson": 30, "convention": 60}`
- [ ] Lessons without a `type` in `meta` default to half-life=30
- [ ] Half-life values are overridable via constructor: `Lore(decay_half_lives={"code": 7})`
- [ ] Unit test: each type produces correct half-life lookup

#### F1-S2: Weighted additive scoring formula

**As a** user querying Lore,
**I want** search results ranked by a blend of semantic relevance and freshness,
**So that** recent relevant memories surface above old ones without drowning out highly relevant older memories.

**ACs:**
- [ ] Score formula: `final = 0.7 * (cosine * confidence * vote_factor) + 0.3 * (0.5 ^ (age / half_life))`
- [ ] Weights (0.7, 0.3) are configurable via constructor
- [ ] Python `_query_local` uses new formula
- [ ] TypeScript `query` uses same formula
- [ ] Integration test: a 1-day-old lesson with 0.6 similarity outranks a 60-day-old lesson with 0.65 similarity (for type=code, half_life=14)

#### F1-S3: CLI and MCP `type` parameter

**As a** user publishing memories,
**I want** to specify a memory type (code/note/lesson/convention),
**So that** the decay rate matches the content's expected lifetime.

**ACs:**
- [ ] `lore publish --type code` sets `meta.type`
- [ ] `save_lesson` MCP tool accepts optional `type` parameter
- [ ] SDK `publish()` accepts optional `type` parameter
- [ ] Invalid type values rejected with clear error message
- [ ] Default type when omitted: `"lesson"`

#### F1-S4: Server-side scoring update

**As a** Lore Cloud user,
**I want** the server to use the same weighted scoring formula,
**So that** remote and local queries produce consistent rankings.

**ACs:**
- [ ] PostgreSQL scoring SQL updated to: `0.7 * (cosine * confidence * vote_factor) + 0.3 * power(0.5, age_days / half_life)`
- [ ] Half-life resolved from `meta->>'type'` with COALESCE default of 30
- [ ] Integration test against test database confirms ranking parity with local

---

### F2: Security Pipeline (PII & Secret Scanning)

#### F2-S1: Expand L1 regex patterns

**As a** security-conscious user,
**I want** Lore to catch common secret formats before storing them,
**So that** secrets aren't accidentally persisted in the memory store.

**ACs:**
- [ ] New patterns added: JWT tokens, PEM private key blocks, AWS secret keys, generic high-entropy strings (>4.5 Shannon entropy, 20+ hex/base64 chars)
- [ ] Each new pattern has at least 3 positive and 3 negative test cases
- [ ] Existing patterns unchanged (backward compatible)
- [ ] Pattern matching completes in <1ms for typical input (benchmark test)

#### F2-S2: Block action for secrets

**As a** user,
**I want** Lore to block storage when secrets are detected (not just mask them),
**So that** secrets never reach the store even in masked form.

**ACs:**
- [ ] `ScanResult` dataclass with `findings: List[Finding]` and `action: "mask" | "block"`
- [ ] Secrets (API keys, private keys, tokens) → action=block
- [ ] PII (emails, names, phones) → action=mask (existing behavior)
- [ ] `SecretBlockedError` raised when block triggered
- [ ] MCP tool returns user-friendly error: "Blocked: content contains a secret (API key detected). Remove the secret and retry."
- [ ] CLI shows the blocked finding type but NOT the secret value

#### F2-S3: L2 detect-secrets integration

**As a** team with strict security requirements,
**I want** entropy-based secret detection using detect-secrets,
**So that** non-obvious secrets (base64 keys, hex tokens) are caught.

**ACs:**
- [ ] `detect-secrets` is an optional dependency (`pip install lore[security]`)
- [ ] L2 scanning activates automatically when detect-secrets is importable
- [ ] L2 can be explicitly disabled: `Lore(security_scan_levels=[1])`
- [ ] Graceful degradation: if detect-secrets fails, log warning and continue with L1 only
- [ ] Test: base64-encoded API key caught by L2 but missed by L1

#### F2-S4: L3 SpaCy NER integration

**As a** compliance-focused team,
**I want** named entity recognition to catch person names and locations,
**So that** personally identifiable information is masked before storage.

**ACs:**
- [ ] `spacy` is an optional dependency (`pip install lore[ner]`)
- [ ] L3 activates when spacy and `en_core_web_sm` model are available
- [ ] Entities masked: PERSON → `[REDACTED:person]`, GPE/LOC → `[REDACTED:location]`
- [ ] ORG entities are NOT masked (often needed in technical context)
- [ ] L3 can be explicitly disabled: `Lore(security_scan_levels=[1, 2])`
- [ ] Graceful degradation: if spacy/model unavailable, log warning and skip L3
- [ ] Test: "John Smith from New York fixed the bug" → "[REDACTED:person] from [REDACTED:location] fixed the bug"

#### F2-S5: TypeScript L1 pattern parity

**As a** TypeScript SDK user,
**I want** the same L1 regex patterns available in the TS SDK,
**So that** security scanning works consistently across languages.

**ACs:**
- [ ] All new L1 patterns from F2-S1 ported to `ts/src/redact.ts`
- [ ] Block action supported in TS SDK
- [ ] Test parity: same test cases pass in both Python and TypeScript
- [ ] L2/L3 are Python-only (documented in TS SDK README)

---

### F3: Dual Embedding Routing

#### F3-S1: Content type detection heuristic

**As a** developer publishing memories,
**I want** Lore to automatically detect if my content is code or prose,
**So that** it uses the right embedding model without manual configuration.

**ACs:**
- [ ] `detect_content_type(text) -> "code" | "prose"` function implemented
- [ ] Heuristics: syntax characters (`{}();`), keywords (`def`, `function`, `class`, `import`), indentation patterns, code fences
- [ ] Accuracy >90% on a test set of 50 code + 50 prose snippets
- [ ] Function executes in <0.1ms (no ML, pure regex/string ops)
- [ ] Exposed in both Python and TypeScript SDKs

#### F3-S2: Code embedding model

**As a** user with code-heavy memories,
**I want** code content embedded with a code-specialized model,
**So that** code search quality improves.

**ACs:**
- [ ] Code embedder uses a 384-dim code-specialized model (e.g., `flax-sentence-embeddings/st-codesearch-distilroberta-base` quantized, or equivalent ONNX model)
- [ ] Same ONNX runtime infrastructure as existing prose embedder
- [ ] Model auto-downloaded on first use to `~/.lore/models/`
- [ ] Embedding output is L2-normalized (same as prose embedder)
- [ ] Fallback to prose model if code model download fails

#### F3-S3: Embedding router

**As a** developer,
**I want** a router that dispatches content to the right embedder,
**So that** the dual-model system is transparent to the rest of the codebase.

**ACs:**
- [ ] `EmbeddingRouter` class implements `Embedder` protocol
- [ ] `embed(text)` → detects content type → delegates to correct embedder
- [ ] `embed_batch(texts)` → groups by type → batch-embeds each group → returns in original order
- [ ] Stores model name in result metadata: `{"embed_model": "code" | "prose"}`
- [ ] Enabled via `Lore(dual_embedding=True)`
- [ ] Disabled by default (single model remains default)

#### F3-S4: Dual-model query matching

**As a** user searching memories,
**I want** queries matched against each lesson using the model that embedded it,
**So that** cross-model comparisons don't degrade search quality.

**ACs:**
- [ ] Query embedded with both models at search time
- [ ] Each lesson compared against matching model's query vector (based on `meta.embed_model`)
- [ ] Lessons without `embed_model` metadata compared against prose query vector
- [ ] Performance: dual query embedding adds <50ms overhead vs single model
- [ ] Integration test: code query finds code lesson that single model misses

#### F3-S5: Re-indexing command

**As a** user enabling dual embedding on an existing database,
**I want** to re-embed old lessons with the appropriate model,
**So that** all lessons benefit from the dual model system.

**ACs:**
- [ ] `lore reindex --dual` CLI command
- [ ] Processes all lessons: detect type → re-embed → update embedding + meta.embed_model
- [ ] Progress bar shown during re-indexing
- [ ] Idempotent: running twice produces same result
- [ ] `--dry-run` flag shows what would change without modifying data

---

### F4: GitHub Sync

#### F4-S1: GitHub API data fetching

**As a** developer,
**I want** Lore to fetch PRs, issues, commits, and releases from a GitHub repo,
**So that** repository knowledge is available for ingestion.

**ACs:**
- [ ] Uses `gh api graphql` for paginated data fetching
- [ ] Fetches: merged PRs, closed issues with resolutions, notable commits (merge commits, tagged), published releases
- [ ] Pagination handles repos with 1000+ PRs
- [ ] Auth via `gh` CLI (no separate token management)
- [ ] Clear error if `gh` CLI not installed or not authenticated

#### F4-S2: GitHub-to-Lesson transformation

**As a** developer,
**I want** GitHub entities transformed into meaningful Lore lessons,
**So that** the knowledge is searchable and useful.

**ACs:**
- [ ] PR → Lesson: problem=title, resolution=body (truncated to 2000 chars) + merge summary, tags from labels + `["github", "pr"]`
- [ ] Issue → Lesson: problem=title+body, resolution=closing comment or linked PR body, tags from labels + `["github", "issue"]`
- [ ] Commit → Lesson: problem=subject line, resolution=body, tags=`["github", "commit"]`
- [ ] Release → Lesson: problem=release name, resolution=changelog/body, tags=`["github", "release", tag_name]`
- [ ] All entities include `meta` with: `gh_type`, `gh_number`/`gh_sha`/`gh_tag`, `gh_repo`, `gh_url`, `gh_synced_at`
- [ ] Empty body/resolution handled gracefully (skip or use title as fallback)

#### F4-S3: Incremental sync with state tracking

**As a** developer running periodic syncs,
**I want** only new/updated entities fetched on subsequent runs,
**So that** sync is fast and doesn't create duplicates.

**ACs:**
- [ ] Sync state persisted in `~/.lore/sync_state.json`
- [ ] State tracks: `last_sync` timestamp, `last_pr` number, `last_issue` number per repo
- [ ] Incremental sync uses `since` parameter in GitHub API queries
- [ ] Deduplication by `meta.gh_type` + `meta.gh_number` (upsert, not duplicate)
- [ ] `--full` flag forces complete re-sync ignoring state
- [ ] First sync on a new repo automatically does full sync

#### F4-S4: CLI github-sync command

**As a** developer,
**I want** a `lore github-sync` CLI command,
**So that** I can ingest GitHub knowledge from the command line.

**ACs:**
- [ ] `lore github-sync --repo owner/repo` performs sync
- [ ] `--types prs,issues,commits,releases` filters entity types (default: all)
- [ ] `--since 2026-01-01` overrides start date
- [ ] `--dry-run` shows what would be synced without storing
- [ ] `--list` shows all synced repos with last sync time
- [ ] Progress output: "Syncing owner/repo... 42 PRs, 18 issues, 3 releases → 63 lessons saved"
- [ ] `--project` flag to scope synced lessons to a project namespace

#### F4-S5: MCP github-sync tool

**As an** AI agent,
**I want** to trigger GitHub sync via MCP,
**So that** I can ingest repository knowledge without CLI access.

**ACs:**
- [ ] `github_sync(repo, types?, since?)` MCP tool
- [ ] Returns summary: "Synced 42 lessons from owner/repo (15 PRs, 12 issues, 10 commits, 5 releases)"
- [ ] Graceful error handling (gh not found, auth failure, etc.)
- [ ] Respects existing sync state for incremental sync

---

### F5: Freshness Detection

#### F5-S1: Git operations wrapper

**As a** developer,
**I want** a reliable Git CLI wrapper for commit counting and file checks,
**So that** freshness detection has accurate git state information.

**ACs:**
- [ ] `git_log_count(repo, file_path, since) -> int` counts commits to file since date
- [ ] `file_exists(repo, file_path) -> bool` checks current HEAD
- [ ] `file_contains_pattern(repo, file_path, pattern) -> bool` searches file content
- [ ] All functions handle: file not found, not a git repo, git not installed
- [ ] Subprocess calls use timeout (5s default) to prevent hangs
- [ ] Unit tests with a temporary git repo fixture

#### F5-S2: Staleness scoring algorithm

**As a** developer,
**I want** lessons scored for staleness based on commit activity,
**So that** I can identify which memories may be outdated.

**ACs:**
- [ ] `StalenessResult` dataclass: `lesson_id, status, confidence, commits_since, file_exists, reason`
- [ ] Thresholds: 0-2=fresh, 3-9=possibly_stale, 10-24=likely_stale, 25+=stale
- [ ] Lessons without `meta.file_path` → status="unknown", reason="no file_path in meta"
- [ ] Deleted files → status="stale", confidence=1.0, reason="file no longer exists"
- [ ] Thresholds configurable via constructor/CLI args
- [ ] Unit test for each threshold boundary

#### F5-S3: CLI freshness command

**As a** developer,
**I want** a `lore freshness` CLI command,
**So that** I can audit my memory store for stale entries.

**ACs:**
- [ ] `lore freshness --repo /path/to/repo` scans all lessons
- [ ] `--project` flag filters to specific project
- [ ] `--format table|json` output formats (table default)
- [ ] `--min-staleness possibly_stale|likely_stale|stale` filters output
- [ ] `--auto-tag` adds `"stale"` tag to stale lessons
- [ ] Summary line: "N stale, N likely stale, N fresh (N total, N unknown)"
- [ ] Exit code: 0 if no stale, 1 if any stale found (for CI integration)

#### F5-S4: MCP freshness tool

**As an** AI agent,
**I want** to check memory freshness via MCP,
**So that** I can warn users about potentially outdated advice.

**ACs:**
- [ ] `check_freshness(repo_path, project?)` MCP tool
- [ ] Returns markdown-formatted report
- [ ] Includes actionable summary: "Found 3 stale lessons. Consider reviewing: [links/IDs]"
- [ ] Graceful handling: not a git repo, no lessons with file_path, git not installed

#### F5-S5: Freshness-aware search integration

**As a** user querying Lore,
**I want** stale lessons flagged in search results,
**So that** I know to verify before acting on them.

**ACs:**
- [ ] `QueryResult` extended with optional `staleness: StalenessResult`
- [ ] Staleness check is opt-in at query time: `lore.query("...", check_freshness=True, repo_path=".")`
- [ ] MCP `recall_lessons` supports optional `repo_path` parameter to enable freshness check
- [ ] Stale lessons shown with warning badge in formatted output: `[POSSIBLY STALE - 12 commits since lesson]`
- [ ] Staleness check adds <100ms per lesson (parallelized git calls)

---

## Appendix: Implementation Order

Recommended sequencing based on dependencies and value:

```
Sprint 1: F1 (Semantic Decay) — foundation for smarter ranking
Sprint 2: F2 (Security Pipeline) — critical for enterprise adoption
Sprint 3: F3 (Dual Embedding) — search quality improvement
Sprint 4: F4 (GitHub Sync) — knowledge ingestion
Sprint 5: F5 (Freshness Detection) — requires lessons with file_path meta (benefits from F4)
```

F1 and F2 are fully independent and could be parallelized. F5 benefits from F4 (GitHub-synced lessons often have file paths), but doesn't strictly require it.
