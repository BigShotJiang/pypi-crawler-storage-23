# Phase B — SDK & CLI: Generalized Memory Interface

## 1. PRD

### 1.1 Vision

Phase B transforms Lore from a "lesson-learned" tool into a **general-purpose cross-agent memory system**. The core abstraction shifts from `Lesson` (problem + resolution) to `Memory` (content + type + metadata), enabling agents to store notes, conventions, code snippets, and lessons through a unified API.

### 1.2 Target Users

| Persona | Need |
|---------|------|
| **Agent developer** (Python) | `from lore import Lore; store = Lore(); store.remember('content', type='note')` |
| **Agent developer** (TypeScript) | `const lore = new Lore(); await lore.remember('content', { type: 'note' })` |
| **CLI user** | `lore remember 'content' --type note --tags t1,t2` |
| **MCP consumer** (Claude Desktop, Cursor, Windsurf) | 5 tools: remember, recall, forget, list_memories, stats |
| **Package consumer** | `pip install lore-sdk` / `npm install @agentkitai/lore` |

### 1.3 Success Criteria

- SC-1: Python SDK passes all existing tests rewritten against new API
- SC-2: CLI exercises all 5 commands end-to-end
- SC-3: MCP server works with Claude Desktop config from README
- SC-4: TypeScript SDK mirrors Python SDK 1:1 (remember/recall/forget/list/stats)
- SC-5: TTL-based expiration auto-cleans expired memories on recall
- SC-6: PyPI publish succeeds (`pip install lore-sdk==0.3.0`)
- SC-7: npm publish succeeds (`npm install @agentkitai/lore@0.3.0`)

### 1.4 Non-Goals

- Server-side changes (FastAPI routes stay lesson-based; server migration is Phase C)
- Breaking changes to the remote store protocol (RemoteStore adapts client-side)
- New embedding models or dual-embedding (Phase A feature)
- GitHub sync, freshness index (Phase A features)

### 1.5 Data Model: Memory

The new `Memory` dataclass replaces `Lesson`. It generalizes `problem`+`resolution` into `content` and adds a `type` discriminator.

```python
@dataclass
class Memory:
    id: str
    content: str              # The memory content (free-form text)
    type: str = "note"        # note | lesson | convention | code
    context: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    confidence: float = 0.5
    source: Optional[str] = None
    project: Optional[str] = None
    embedding: Optional[bytes] = None
    created_at: str = ""
    updated_at: str = ""
    expires_at: Optional[str] = None
    ttl_seconds: Optional[int] = None  # Optional TTL; sets expires_at on save
    upvotes: int = 0
    downvotes: int = 0
    meta: Optional[Dict[str, Any]] = None
```

**Backward Compatibility**: `Lesson` stays as a deprecated alias. The SQLite schema adds a `content` column and a `type` column via migration. Existing rows get `content = problem + '\n\n' + resolution`, `type = 'lesson'`.

### 1.6 API Surface

#### Python SDK (`Lore` class)

| Method | Signature | Notes |
|--------|-----------|-------|
| `remember()` | `(content, type='note', context=None, tags=None, confidence=0.5, source=None, project=None, ttl=None) → str` | Returns memory ID |
| `recall()` | `(query, tags=None, type=None, limit=5, min_confidence=0.0) → List[RecallResult]` | Semantic search with optional type filter |
| `forget()` | `(memory_id) → bool` | Delete by ID |
| `list_memories()` | `(project=None, type=None, limit=None) → List[Memory]` | List with optional filters |
| `stats()` | `(project=None) → MemoryStats` | Counts by type, total, oldest/newest |

Deprecated methods (`publish`, `query`, `upvote`, `downvote`, `get`, `list`, `delete`, `export_lessons`, `import_lessons`) emit `DeprecationWarning` and delegate to new methods.

#### CLI

```
lore remember 'content' [--type note] [--tags t1,t2] [--context '...'] [--ttl 3600]
lore recall 'query' [--type lesson] [--tags t1] [--limit 5]
lore forget <memory-id>
lore memories [--type note] [--limit 20]
lore stats
lore mcp                     # unchanged
lore keys create|list|revoke # unchanged
```

#### MCP Tools

| Tool | Parameters | Returns |
|------|-----------|---------|
| `remember` | content, type?, context?, tags?, project?, ttl? | "Saved (ID: ...)" |
| `recall` | query, tags?, type?, limit? | Formatted results |
| `forget` | memory_id | "Forgotten" / error |
| `list_memories` | type?, project?, limit? | Formatted list |
| `stats` | project? | Formatted stats |

#### TypeScript SDK

```typescript
class Lore {
  async remember(content: string, opts?: RememberOptions): Promise<string>
  async recall(query: string, opts?: RecallOptions): Promise<RecallResult[]>
  async forget(memoryId: string): Promise<boolean>
  async listMemories(opts?: ListOptions): Promise<Memory[]>
  async stats(opts?: StatsOptions): Promise<MemoryStats>
  async close(): Promise<void>
}
```

### 1.7 TTL / Expiration

- `remember(..., ttl=3600)` sets `expires_at = now + 3600s`
- On `recall()` and `list_memories()`, expired memories are filtered out
- Background cleanup: `Lore._cleanup_expired()` called lazily on `recall()` — deletes rows where `expires_at < now`. Runs at most once per 60 seconds (debounced).
- No separate cleanup daemon; keep it simple.

### 1.8 Publish Preparation

| Artifact | Content |
|----------|---------|
| `pyproject.toml` | Bump to 0.3.0, update description, add `Changelog` URL |
| `ts/package.json` | Bump to 0.3.0, update description |
| `CHANGELOG.md` | v0.3.0 section with breaking changes noted |
| `CONTRIBUTING.md` | Dev setup, testing, PR process |
| `README.md` | Updated quickstart for remember/recall/forget API |
| MCP setup guides | Claude Desktop, Cursor, Windsurf, Docker snippets in README |

---

## 2. Architecture

### 2.1 Module Map (Changed/New Files)

```
src/lore/
├── __init__.py          # MODIFY: export Memory, RecallResult, MemoryStats; deprecate Lesson, QueryResult
├── types.py             # MODIFY: add Memory, RecallResult, MemoryStats; keep Lesson as alias
├── lore.py              # MODIFY: add remember/recall/forget/list_memories/stats; deprecate old methods
├── cli.py               # MODIFY: replace commands with remember/recall/forget/memories/stats
├── exceptions.py        # MODIFY: add MemoryNotFoundError (alias LessonNotFoundError)
├── prompt.py            # MODIFY: accept RecallResult
├── mcp/
│   └── server.py        # REWRITE: 5 new tools
├── store/
│   ├── base.py          # MODIFY: Store operates on Memory instead of Lesson
│   ├── sqlite.py        # MODIFY: schema migration, Memory support
│   ├── remote.py        # MODIFY: adapt to Memory (client-side mapping)
│   └── memory.py        # MODIFY: in-memory store uses Memory
└── _migration.py        # NEW: SQLite schema migration helper

ts/src/
├── types.ts             # MODIFY: Memory, RememberOptions, RecallResult, MemoryStats
├── lore.ts              # MODIFY: remember/recall/forget/listMemories/stats
├── store/
│   ├── base.ts          # MODIFY: Store<Memory>
│   ├── sqlite.ts        # MODIFY: schema migration
│   ├── remote.ts        # MODIFY: adapt
│   └── memory.ts        # MODIFY: in-memory
├── prompt.ts            # MODIFY: accept RecallResult
└── errors.ts            # MODIFY: MemoryNotFoundError

Root:
├── CHANGELOG.md         # NEW
├── CONTRIBUTING.md      # NEW
├── README.md            # MODIFY: new API examples, MCP setup guides
└── pyproject.toml       # MODIFY: version bump, metadata
```

### 2.2 SQLite Schema Migration

Current `lessons` table stays. A migration adds columns and preserves data:

```sql
-- Migration 001: Generalize to memories
ALTER TABLE lessons ADD COLUMN content TEXT;
ALTER TABLE lessons ADD COLUMN type TEXT DEFAULT 'lesson';

-- Backfill content from problem + resolution
UPDATE lessons SET content = problem || char(10) || char(10) || resolution
  WHERE content IS NULL;

-- Create index on type
CREATE INDEX IF NOT EXISTS idx_lessons_type ON lessons(type);
```

The table name stays `lessons` for backward compatibility. The `Store` abstraction hides this.

### 2.3 Deprecation Strategy

All old methods delegate to new ones with `warnings.warn(..., DeprecationWarning, stacklevel=2)`:

```python
def publish(self, problem, resolution, **kw) -> str:
    warnings.warn("publish() is deprecated, use remember()", DeprecationWarning, stacklevel=2)
    content = f"{problem}\n\n{resolution}"
    return self.remember(content, type="lesson", **kw)
```

Old types (`Lesson`, `QueryResult`) become aliases for `Memory` and `RecallResult`.

### 2.4 Store Interface Change

```python
class Store(ABC):
    def save(self, memory: Memory) -> None: ...
    def get(self, memory_id: str) -> Optional[Memory]: ...
    def list(self, project=None, type=None, limit=None) -> List[Memory]: ...
    def update(self, memory: Memory) -> bool: ...
    def delete(self, memory_id: str) -> bool: ...
    def count(self, project=None, type=None) -> int: ...        # NEW
    def cleanup_expired(self) -> int: ...                         # NEW
```

### 2.5 Stats Model

```python
@dataclass
class MemoryStats:
    total: int
    by_type: Dict[str, int]     # {"note": 5, "lesson": 12, ...}
    oldest: Optional[str]       # ISO timestamp
    newest: Optional[str]       # ISO timestamp
    expired_cleaned: int        # count removed in last cleanup
```

### 2.6 Dependency Changes

None. All new functionality uses existing dependencies (ulid, numpy, sqlite3, argparse). MCP extra still requires `mcp>=1.0.0`.

---

## 3. Stories with Acceptance Criteria

### Story B-1: Memory Data Model & Types

**As a** SDK developer
**I want** a generalized `Memory` type with content + type fields
**So that** agents can store any kind of memory, not just problem/resolution pairs

**ACs:**
1. `Memory` dataclass in `types.py` with fields: id, content, type, context, tags, confidence, source, project, embedding, created_at, updated_at, expires_at, ttl_seconds, upvotes, downvotes, meta
2. `type` defaults to `"note"` and accepts `"note" | "lesson" | "convention" | "code"` (no enum enforcement — free-form string for extensibility)
3. `RecallResult` dataclass: `memory: Memory`, `score: float`
4. `MemoryStats` dataclass: `total`, `by_type`, `oldest`, `newest`, `expired_cleaned`
5. `Lesson` is a deprecated alias for `Memory`; `QueryResult` is a deprecated alias for `RecallResult`
6. `MemoryNotFoundError` added to `exceptions.py` (alias for `LessonNotFoundError`)
7. `__init__.py` exports: `Lore, Memory, RecallResult, MemoryStats, MemoryNotFoundError, as_prompt` plus deprecated `Lesson, QueryResult, LessonNotFoundError`

**Estimate:** S (< 1 hour)

---

### Story B-2: Store Layer Migration

**As a** SDK developer
**I want** the Store interface and SQLite backend to support Memory
**So that** the new API has persistence

**ACs:**
1. `Store` ABC updated: all methods operate on `Memory`; `list()` accepts optional `type` filter; `count()` and `cleanup_expired()` added
2. `SqliteStore` migration: on init, detects missing `content`/`type` columns and runs ALTER TABLE + backfill (idempotent)
3. `SqliteStore.save()` persists `content`, `type`, `ttl_seconds`; if `ttl_seconds` is set and `expires_at` is None, computes `expires_at = now + ttl_seconds`
4. `SqliteStore.list()` supports `type` filter
5. `SqliteStore.count()` returns count with optional project/type filters
6. `SqliteStore.cleanup_expired()` deletes rows where `expires_at < now`, returns count deleted
7. `MemoryStore` (in-memory) updated to match
8. `RemoteStore` maps Memory ↔ Lesson for server compatibility (content → problem+resolution, type preserved in meta)
9. All existing tests adapted and passing
10. New test: round-trip Memory with TTL → verify expires_at computed, verify cleanup_expired removes it after expiry

**Estimate:** M (2-3 hours)

---

### Story B-3: Python SDK — remember/recall/forget/list_memories/stats

**As an** agent developer
**I want** `store.remember('content')`, `store.recall('query')`, `store.forget(id)`, `store.list_memories()`, `store.stats()`
**So that** I have a clean, intuitive API for agent memory

**ACs:**
1. `Lore.remember(content, type='note', context=None, tags=None, confidence=0.5, source=None, project=None, ttl=None) → str` — redacts, embeds, saves, returns ID
2. `Lore.recall(query, tags=None, type=None, limit=5, min_confidence=0.0) → List[RecallResult]` — embeds query, semantic search, filters by type, applies decay, returns sorted results. Triggers lazy `_cleanup_expired()`.
3. `Lore.forget(memory_id) → bool` — deletes by ID
4. `Lore.list_memories(project=None, type=None, limit=None) → List[Memory]` — lists with filters, excludes expired
5. `Lore.stats(project=None) → MemoryStats` — aggregates counts, finds oldest/newest
6. Deprecated methods (`publish`, `query`, `upvote`, `downvote`, `get`, `list`, `delete`) delegate with `DeprecationWarning`
7. `_cleanup_expired()` runs at most once per 60s (instance-level timestamp)
8. `export_lessons()` / `import_lessons()` still work (deprecated) for backward compat
9. Tests: unit tests for each new method, deprecation warning tests, TTL lifecycle test

**Estimate:** M (2-3 hours)

---

### Story B-4: CLI — remember/recall/forget/memories/stats

**As a** CLI user
**I want** `lore remember 'content'`, `lore recall 'query'`, `lore forget <id>`, `lore memories`, `lore stats`
**So that** I can manage agent memory from the terminal

**ACs:**
1. `lore remember 'content'` — positional content arg, flags: `--type`, `--tags` (comma-sep), `--context`, `--confidence`, `--source`, `--ttl` (seconds), `--db`; prints memory ID
2. `lore recall 'query'` — positional query arg, flags: `--type`, `--tags`, `--limit`, `--db`; prints formatted results with scores
3. `lore forget <memory-id>` — positional ID, `--db`; prints confirmation or error
4. `lore memories` — flags: `--type`, `--limit`, `--db`; prints table (ID, type, content preview, created_at)
5. `lore stats` — `--db`; prints total, by-type breakdown, oldest, newest
6. Old commands (`publish`, `query`, `list`, `export`, `import`) still work, print deprecation notice to stderr
7. `lore mcp` and `lore keys` unchanged
8. `--help` shows new commands prominently, old commands in "Legacy" section
9. Tests: CLI integration tests using `main(argv=[...])` with captured stdout

**Estimate:** M (2-3 hours)

---

### Story B-5: MCP Server — 5 Generalized Tools

**As an** MCP consumer (Claude Desktop, Cursor, Windsurf)
**I want** remember/recall/forget/list_memories/stats tools
**So that** agents can use Lore memory through the MCP protocol

**ACs:**
1. `remember` tool: params (content, type?, context?, tags?, project?, ttl?); returns "Saved (ID: ...)"
2. `recall` tool: params (query, tags?, type?, limit?); returns formatted results with scores, IDs, types
3. `forget` tool: params (memory_id); returns "Forgotten" or error
4. `list_memories` tool: params (type?, project?, limit?); returns formatted list
5. `stats` tool: params (project?); returns formatted stats
6. Tool descriptions include USE THIS WHEN guidance (matching current style)
7. Server `instructions` updated to say "memory system" instead of "lesson system"
8. Old tool names (`save_lesson`, `recall_lessons`, `upvote_lesson`, `downvote_lesson`) removed
9. Env vars unchanged: `LORE_STORE`, `LORE_PROJECT`, `LORE_API_URL`, `LORE_API_KEY`
10. Test: MCP tool function unit tests

**Estimate:** S (1-2 hours)

---

### Story B-6: TypeScript SDK — Generalized API

**As a** TypeScript agent developer
**I want** `lore.remember()`, `lore.recall()`, `lore.forget()`, `lore.listMemories()`, `lore.stats()`
**So that** the TS SDK matches the Python SDK 1:1

**ACs:**
1. `Memory` interface in `types.ts`: id, content, type, context, tags, confidence, source, project, embedding, createdAt, updatedAt, expiresAt, ttlSeconds, upvotes, downvotes, meta
2. `RememberOptions`: type?, context?, tags?, confidence?, source?, project?, ttl?
3. `RecallOptions`: tags?, type?, limit?, minConfidence?
4. `RecallResult`: memory + score
5. `MemoryStats`: total, byType, oldest, newest, expiredCleaned
6. `Lore.remember(content, opts?)` — redacts, embeds, saves, returns ID
7. `Lore.recall(query, opts?)` — semantic search with type filter
8. `Lore.forget(memoryId)` — delete
9. `Lore.listMemories(opts?)` — list with type filter
10. `Lore.stats(opts?)` — aggregate stats
11. `SqliteStore` schema migration (same as Python)
12. Old methods (`publish`, `query`, `upvote`, `downvote`, `get`, `list`, `delete`) marked `@deprecated` in JSDoc, delegate to new methods
13. All existing vitest tests updated and passing
14. `ts/package.json` version bumped to 0.3.0

**Estimate:** L (3-4 hours)

---

### Story B-7: TTL & Expiration

**As an** agent developer
**I want** to set TTL on memories so they auto-expire
**So that** temporary context doesn't pollute long-term memory

**ACs:**
1. `remember(..., ttl=3600)` sets `expires_at = now + ttl` (both Python and TS)
2. `recall()` filters out expired memories before scoring
3. `list_memories()` excludes expired by default
4. `_cleanup_expired()` physically deletes expired rows; debounced to run at most once per 60s
5. `stats()` includes `expired_cleaned` count from last cleanup
6. CLI: `--ttl 3600` on `lore remember`
7. MCP: `ttl` parameter on `remember` tool
8. Test: create memory with TTL=1s, wait 2s, verify recall returns empty, verify cleanup deletes row

**Estimate:** S (1 hour) — mostly integrated into B-2 and B-3

---

### Story B-8: Publish Preparation

**As a** package maintainer
**I want** updated metadata, changelog, and setup guides
**So that** users can install and configure Lore 0.3.0

**ACs:**
1. `pyproject.toml`: version → 0.3.0, description → "Cross-agent memory SDK", add `Changelog` URL
2. `ts/package.json`: version → 0.3.0, description updated
3. `CHANGELOG.md` created with v0.3.0 section documenting: new API (remember/recall/forget/list_memories/stats), Memory model, TTL support, deprecated methods, breaking MCP tool changes
4. `CONTRIBUTING.md` created with: dev setup (Python + TS), running tests, linting, PR process
5. `README.md` updated: new quickstart examples for Python, TS, CLI; MCP configuration snippets for Claude Desktop (`claude_desktop_config.json`), Cursor (`.cursor/mcp.json`), Windsurf, Docker
6. `README.md` includes migration guide from 0.2.x → 0.3.0
7. PyPI test publish succeeds (`pip install --index-url https://test.pypi.org/simple/ lore-sdk==0.3.0`)

**Estimate:** M (2-3 hours)

---

### Implementation Order

```
B-1 (Types) ──→ B-2 (Store) ──→ B-3 (Python SDK) ──→ B-4 (CLI)
                     │                    │
                     └──→ B-7 (TTL) ──────┘
                                          │
                              B-5 (MCP) ──┘
                              B-6 (TS SDK) ─── (parallel with B-4/B-5)
                                          │
                              B-8 (Publish) ── (after all above)
```

B-1 → B-2 → B-3 is the critical path. B-4, B-5, B-6 can proceed in parallel after B-3. B-7 (TTL) is woven into B-2 and B-3. B-8 is last.

**Total estimate:** ~15-18 hours of implementation work across 8 stories.
