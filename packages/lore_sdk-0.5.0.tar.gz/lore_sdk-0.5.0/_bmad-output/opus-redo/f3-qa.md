# F3: Dual Embedding Routing — QA Report

**Commit:** c318443
**Verdict: FAIL**

---

## AC Verdicts

| AC | ID | Status | Notes |
|---|---|---|---|
| `detect_content_type` function | F3-S1a | PASS | Implemented in `embed/router.py:14` |
| Heuristics cover syntax, keywords, etc. | F3-S1b | PASS | 6 heuristic checks |
| >90% accuracy on 50+50 test set | F3-S1c | FAIL | Only 8+8 test cases, not 50+50 |
| <0.1ms execution | F3-S1d | FAIL | Performance test has measurement bug (`per_call_ms = elapsed_ms` stores wrong value) |
| Exposed in TypeScript SDK | F3-S1e | FAIL | No `detectContentType` in TS |
| Code model is 384-dim | F3-S2a | FAIL | Selected model produces 768-dim embeddings |
| Same ONNX infrastructure | F3-S2b | FAIL | `token_type_ids` incompatible with DistilRoBERTa |
| Model auto-downloaded | F3-S2c | FAIL | ONNX file likely doesn't exist at assumed HF path |
| Output L2-normalized | F3-S2d | PASS | Same normalization as prose embedder |
| Fallback to prose on failure | F3-S2e | PASS | `make_code_embedder` catches and warns |
| `EmbeddingRouter` implements `Embedder` | F3-S3a | PASS | Correct |
| `embed()` routes by content type | F3-S3b | PASS | Delegates correctly |
| `embed_batch()` groups and reassembles | F3-S3c | PASS | Preserves order |
| Stores `embed_model` in metadata | F3-S3d | PASS | Set in `lore.py:197` |
| Enabled via `dual_embedding=True` | F3-S3e | PASS | Default disabled |
| Query with both models | F3-S4a | PASS | `embed_query_dual()` |
| Matching by `embed_model` metadata | F3-S4b | PASS | Correct selection in `_recall_local` |
| Legacy memories default to prose | F3-S4c | PASS | `metadata.get("embed_model", "prose")` |
| <50ms overhead benchmark | F3-S4d | FAIL | No performance test exists |
| Integration test: dual beats single | F3-S4e | FAIL | No such test exists |
| `lore reindex --dual` CLI | F3-S5a | PASS | Implemented |
| Idempotent reindex | F3-S5b | PASS | Tested |
| Progress bar | F3-S5c | CONDITIONAL | Only renders in TTY environments |
| `--dry-run` flag | F3-S5d | PASS | Implemented |

---

## Critical Issues

### 1. Code model dimension mismatch (BLOCKER)
**File:** `src/lore/embed/local.py:42-46`
The selected model `flax-sentence-embeddings/st-codesearch-distilroberta-base` produces **768-dim** embeddings, not 384. The `_ModelSpec.dim` field is declared as 384 but never validated. Comparing 768-dim code embeddings against 384-dim prose query vectors will crash or produce garbage results.

### 2. ONNX file likely doesn't exist at assumed path
**File:** `src/lore/embed/local.py:42-46`
The model repo has no pre-built ONNX at `onnx/model.onnx`. Download will 404, silently falling back to prose model. Dual embedding never actually activates.

### 3. `token_type_ids` incompatible with DistilRoBERTa
**File:** `src/lore/embed/local.py:215-224`
`token_type_ids` is unconditionally passed to ONNX session. DistilRoBERTa doesn't use this input. Will likely cause inference error.

### 4. TypeScript `detect_content_type` missing entirely
No content type detection function exists in the TypeScript SDK. Plan explicitly requires it in `ts/src/embed.ts`.

---

## Edge Cases

- **Thread safety:** `_last_embed_model` is not thread-safe. Concurrent `embed()` calls corrupt metadata.
- **`embed_batch()` doesn't update `_last_embed_model`:** After batch embed, property reflects stale state.
- **Single-line code:** `def foo(): return 42` scores indicators=2, classified as prose (below threshold=3).
- **`if ` keyword false positive:** Prose like "if you look at this" matches keyword heuristic.
- **Reindex count mismatch:** CLI `total_memories` (excludes expired) vs `reindex()` internal count (includes expired).

---

## Test Coverage

| Area | Tests | Quality |
|---|---|---|
| `detect_content_type` code | 8 parametrized | Insufficient (needs 50) |
| `detect_content_type` prose | 8 parametrized | Insufficient (needs 50) |
| Performance <0.1ms | 1 test | Flawed assertion |
| Router `embed` routing | 2 tests | Adequate |
| Router `embed_batch` | 1 test | Adequate |
| Router `embed_query_dual` | 1 test | Adequate |
| Fallback (no code embedder) | 1 test | Adequate |
| Metadata `embed_model` tracking | 2 tests | Adequate |
| Reindex (update, dry-run, idempotent) | 3 tests | Adequate |
| Dual beats single model (integration) | 0 tests | **Missing** |
| Dual query overhead <50ms | 0 tests | **Missing** |
| Code model dimensions validated | 0 tests | **Missing** |

---

## Verdict Rationale

The router architecture (F3-S3) and query matching logic (F3-S4) are well-designed and correctly implemented. However, **the code embedding model itself is fundamentally broken**: wrong dimensions (768 vs 384), likely missing ONNX file, and incompatible `token_type_ids`. In practice, `dual_embedding=True` silently degrades to single-model mode via the fallback path. The core value proposition of F3 — improved code search — cannot be realized with the current model selection. TypeScript detection is also entirely absent. The feature needs a correct 384-dim code model before it can pass.
