# F5 — Freshness Detection

## 1. PRD (Product Manager)

### Problem

Lore stores memories about code patterns, project conventions, and technical decisions. These memories reference specific files, functions, and architectural choices. When a codebase evolves — a framework migration, a renamed module, a deleted file — memories referencing the old state become stale. An agent relying on a stale memory like "we use Express for routing" after the project migrated to Hono will make wrong decisions.

Today, Lore has no way to detect this. Memories persist at full confidence regardless of whether the code they describe still exists. The existing time-based decay (F1) addresses *age* but not *relevance to current code state*. A 60-day-old convention memory that still matches the codebase is more valuable than a 2-day-old code snippet whose source file was deleted.

### Solution

Add **git-based freshness detection** that compares stored memories against the current state of a git repository. For memories that reference source files or contain code snippets, check whether those references are still valid by inspecting git history.

**CLI command**: `lore freshness-check [--repo-path .] [--type code]`
**MCP tool**: `freshness_check` — returns stale memories with staleness scores
**SDK method**: `Lore.freshness_check()` — programmatic access

**Staleness levels** (commits since memory creation):
| Level | Commits Changed | Meaning |
|-------|----------------|---------|
| `fresh` | <3 | File barely changed since memory was created |
| `aging` | 3–10 | File has seen moderate changes |
| `stale` | 10–25 | File has changed significantly |
| `obsolete` | >25 | File has been heavily modified or deleted |

**Detection strategies**:
1. **Source-file tracking**: Memories with a `source` field pointing to a file path (e.g., `src/lore/cli.py`) — check `git log --oneline <file>` since memory `created_at` to count commits touching that file.
2. **Snippet matching**: Memories of type `code` containing code snippets — search the codebase for the snippet (fuzzy substring match). If not found, mark as stale.
3. **File existence**: If the referenced file no longer exists in the repo, mark as `obsolete`.

### User Value

- **Trustworthy recall**: Agents can filter out or deprioritize stale memories automatically.
- **Memory hygiene**: Developers can run `lore freshness-check` periodically to prune outdated memories.
- **Integration with decay**: Stale memories can be penalized during `recall` scoring, combining git-based freshness with F1's temporal decay for the most relevant results.

### What's NOT in scope

| Feature | Why it's out |
|---------|-------------|
| Auto-deletion of stale memories | Too aggressive — users should decide. Report, don't delete. |
| Cross-repo tracking | One repo at a time. Multi-repo is a future feature. |
| Non-git VCS (Mercurial, SVN) | Git only. Covers 95%+ of users. |
| Real-time monitoring / webhooks | Batch check on-demand. No daemon. |
| Semantic diff analysis | Counting commits is sufficient. Analyzing *what* changed in each diff is expensive and fragile. |

### Success Metrics

- `freshness-check` correctly identifies memories referencing deleted files as `obsolete`.
- Memories referencing files with >25 commits since creation are flagged `obsolete`.
- Memories referencing unchanged files are marked `fresh`.
- Snippet-based memories whose code no longer exists anywhere in the repo are flagged `stale` or `obsolete`.
- No performance regression on `recall` when freshness integration is disabled (opt-in).
- `freshness-check` completes in <5s for a repo with 1000 memories and typical git history.

---

## 2. Architecture (Architect)

### Current State

- **Memory dataclass** (`src/lore/types.py:10-23`): Has `source` (optional string), `metadata` (dict), `created_at` (ISO timestamp), and `type` (string). The `source` field can already hold a file path. The `metadata` dict can store arbitrary data.
- **Store interface** (`src/lore/memory_store/base.py`): Abstract `list()` returns memories with filters. `search()` returns `SearchResult` with score.
- **SqliteStore** (`src/lore/memory_store/sqlite.py`): `search()` computes cosine similarity with time decay. The scoring loop (lines 156-162) is where freshness could integrate.
- **CLI** (`src/lore/cli.py`): Uses argparse with subcommands. Adding `freshness-check` follows the existing pattern.
- **MCP server** (`src/lore/mcp/server.py`): Tools registered via `@mcp.tool()` decorator. Adding `freshness_check` follows the existing pattern.
- **Lore SDK** (`src/lore/lore.py`): `Lore` class with `recall()`, `remember()`, etc. New `freshness_check()` method goes here.

### Proposed Changes

#### 2.1 New Module — `src/lore/freshness.py`

Core freshness detection logic, isolated from the store layer. Responsible for:
- Running git commands via `subprocess.run()`
- Counting commits touching a file since a given date
- Checking if a file exists in the repo
- Searching the repo for a code snippet (using `git grep`)
- Computing staleness level from commit count

```python
"""Git-based freshness detection for Lore memories."""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional

from lore.types import Memory


class StalenessLevel(str, Enum):
    FRESH = "fresh"        # <3 commits
    AGING = "aging"        # 3-10 commits
    STALE = "stale"        # 10-25 commits
    OBSOLETE = "obsolete"  # >25 commits or file deleted


@dataclass
class FreshnessResult:
    memory: Memory
    level: StalenessLevel
    commits_since: int
    file_exists: bool
    snippet_found: Optional[bool]  # None if not a snippet-type memory
    details: str  # Human-readable explanation


def check_freshness(
    memories: List[Memory],
    repo_path: str = ".",
) -> List[FreshnessResult]:
    """Check freshness of memories against a git repository."""
    ...


def _count_commits_since(
    file_path: str,
    since_date: str,
    repo_path: str,
) -> int:
    """Count commits touching a file since a date."""
    result = subprocess.run(
        ["git", "log", "--oneline", "--since", since_date, "--", file_path],
        capture_output=True, text=True, cwd=repo_path, timeout=30,
    )
    if result.returncode != 0:
        return -1  # error indicator
    return len(result.stdout.strip().splitlines()) if result.stdout.strip() else 0


def _file_exists_in_repo(file_path: str, repo_path: str) -> bool:
    """Check if a file exists in the git repo working tree."""
    ...


def _search_snippet(snippet: str, repo_path: str) -> bool:
    """Search for a code snippet in the repo using git grep."""
    # Use first meaningful line of snippet as search term
    ...


def _classify_staleness(commits: int, file_exists: bool) -> StalenessLevel:
    if not file_exists:
        return StalenessLevel.OBSOLETE
    if commits > 25:
        return StalenessLevel.OBSOLETE
    if commits > 10:
        return StalenessLevel.STALE
    if commits >= 3:
        return StalenessLevel.AGING
    return StalenessLevel.FRESH
```

#### 2.2 Memory Source Detection Heuristic

Not all memories reference files. The freshness module needs to determine *which* memories are checkable:

1. **`source` field contains a file path**: If `memory.source` matches a pattern like `src/...`, `lib/...`, or ends in a code extension (`.py`, `.ts`, `.js`, `.rs`, etc.), treat it as a file reference.
2. **`metadata` contains a `file` or `path` key**: Explicit file path in metadata.
3. **`type == "code"` and content contains code**: Extract the snippet for git-grep matching.
4. **Otherwise**: Skip — not a code-related memory, freshness check doesn't apply.

This heuristic is implemented in `freshness.py` as `_extract_file_ref(memory)` returning `Optional[str]`.

#### 2.3 SDK Integration — `src/lore/lore.py`

Add a `freshness_check()` method to the `Lore` class:

```python
def freshness_check(
    self,
    repo_path: str = ".",
    type: Optional[str] = None,
    project: Optional[str] = None,
) -> List[FreshnessResult]:
    """Check freshness of stored memories against git state."""
    from lore.freshness import check_freshness
    memories, _ = self.list_memories(type=type, project=project, limit=10000)
    return check_freshness(memories, repo_path=repo_path)
```

#### 2.4 CLI Command — `src/lore/cli.py`

Add `freshness-check` subcommand:

```
lore freshness-check [--repo-path .] [--type code] [--project X] [--json]
```

Output (human-readable):
```
Freshness Report (42 memories checked, repo: .):

  OBSOLETE  3 memories
    01JABC... (code) "Express routing middleware" — file deleted: src/routes/express.ts
    01JDEF... (code) "Jest test config" — 32 commits since creation
    01JGHI... (note) "API auth flow" — file deleted: src/auth/passport.js

  STALE     5 memories
    01JKLM... (code) "Database connection pooling" — 18 commits since creation
    ...

  AGING     12 memories
    ...

  FRESH     22 memories (not shown)

Summary: 3 obsolete, 5 stale, 12 aging, 22 fresh
```

#### 2.5 MCP Tool — `src/lore/mcp/server.py`

Add `freshness_check` tool:

```python
@mcp.tool(
    description=(
        "Check freshness of stored memories against the current git repository. "
        "USE THIS WHEN: you want to identify stale or obsolete memories that may "
        "no longer reflect the current codebase. Returns memories grouped by "
        "staleness level (fresh, aging, stale, obsolete)."
    ),
)
def freshness_check(
    repo_path: str = ".",
    type: Optional[str] = None,
    project: Optional[str] = None,
) -> str:
    ...
```

#### 2.6 Optional Recall Integration

Add an optional `freshness_penalty` parameter to `recall()` that penalizes stale memories in search ranking. This builds on F1's decay scoring:

```python
# In SqliteStore.search() scoring loop:
if freshness_penalty and freshness_results:
    penalty = {
        StalenessLevel.FRESH: 1.0,
        StalenessLevel.AGING: 0.9,
        StalenessLevel.STALE: 0.6,
        StalenessLevel.OBSOLETE: 0.2,
    }
    score *= penalty.get(staleness, 1.0)
```

**This is opt-in** and deferred to a later story. The core freshness check is standalone first.

#### 2.7 Git Operations — Safety

All git operations use `subprocess.run()` with:
- `timeout=30` seconds per command (prevents hanging on large repos)
- `capture_output=True` (no terminal interaction)
- `cwd=repo_path` (explicit working directory)
- Read-only commands only (`git log`, `git grep`, `git ls-files`) — never modifies the repo
- Graceful failure: if git is not available or repo is not a git repo, return an error message, don't crash

#### 2.8 Dependencies — None

`subprocess` is stdlib. No new dependencies.

#### 2.9 Schema — No Changes

No database schema changes. `source`, `metadata`, `type`, and `created_at` already exist.
The `FreshnessResult` is computed at check time, not stored.

### Design Decisions

| Decision | Rationale |
|----------|-----------|
| Commit count, not diff analysis | Counting commits is O(1) per file via `git log`. Analyzing diffs would require parsing patch output — complex, slow, fragile. Commit count is a good-enough proxy for "how much has this area changed." |
| `subprocess` not `gitpython` | Zero new dependencies. `gitpython` is 10MB+ and overkill for 3 read-only commands. |
| Separate module, not in store | Freshness is git-specific. The store layer is storage-backend-agnostic. Mixing git logic into `SqliteStore` would violate the abstraction. |
| Report-only, no auto-delete | Destructive actions should be explicit. Users run `freshness-check`, see the report, then `forget` specific memories. |
| Snippet search via `git grep` | Faster than `grep -r` because git grep uses the index. Falls back gracefully if the snippet is too short or ambiguous. |
| Staleness thresholds from AI-Memory | 3/10/25 commit thresholds are proven heuristics from the AI-Memory project. No need to reinvent. |

---

## 3. Stories (Scrum Master)

### Story 1: Core Freshness Detection Module

**Summary**: Create `src/lore/freshness.py` with git-based freshness detection logic.

**Files to create**:
- `src/lore/freshness.py`

**Implementation**:
1. Define `StalenessLevel` enum (FRESH, AGING, STALE, OBSOLETE).
2. Define `FreshnessResult` dataclass (memory, level, commits_since, file_exists, snippet_found, details).
3. Implement `_extract_file_ref(memory)` — heuristic to extract a file path from `memory.source` or `memory.metadata`.
4. Implement `_count_commits_since(file_path, since_date, repo_path)` — runs `git log --oneline --since <date> -- <file>` and counts output lines.
5. Implement `_file_exists_in_repo(file_path, repo_path)` — runs `git ls-files <file>` or checks filesystem.
6. Implement `_search_snippet(snippet, repo_path)` — extracts first meaningful line from content, runs `git grep -F <line>`.
7. Implement `_classify_staleness(commits, file_exists)` — maps commit count to staleness level.
8. Implement `check_freshness(memories, repo_path)` — orchestrates the above for a list of memories. Skips memories without file references.

**Acceptance Criteria**:
- [ ] `StalenessLevel` enum has 4 values: `fresh`, `aging`, `stale`, `obsolete`.
- [ ] `FreshnessResult` dataclass contains: `memory`, `level`, `commits_since`, `file_exists`, `snippet_found`, `details`.
- [ ] `_extract_file_ref()` returns a file path from `memory.source` if it looks like a path (contains `/` and ends in a code extension), or from `memory.metadata["file"]` / `memory.metadata["path"]` if present. Returns `None` otherwise.
- [ ] `_count_commits_since()` correctly counts commits touching a file since a given ISO date using `git log`.
- [ ] `_file_exists_in_repo()` returns `False` for deleted files, `True` for existing files.
- [ ] `_search_snippet()` extracts a non-empty, non-comment line from the memory content and searches via `git grep -F`. Returns `True`/`False`.
- [ ] `_classify_staleness()` returns FRESH for <3 commits, AGING for 3-10, STALE for 10-25, OBSOLETE for >25 or file deleted.
- [ ] `check_freshness()` skips memories where `_extract_file_ref()` returns `None`.
- [ ] All `subprocess.run()` calls use `timeout=30`, `capture_output=True`, `cwd=repo_path`.
- [ ] If `git` is not available or `repo_path` is not a git repo, `check_freshness()` raises `LoreError` with a clear message.

---

### Story 2: Unit Tests for Freshness Module

**Summary**: Test all freshness detection functions using a temporary git repository.

**Files to create**:
- `tests/test_freshness.py`

**Tests to write**:

1. **`test_classify_staleness_levels`**: Verify `_classify_staleness()` returns correct levels for commit counts 0, 2, 3, 10, 11, 25, 26, and for `file_exists=False`.

2. **`test_extract_file_ref_from_source`**: Memory with `source="src/lore/cli.py"` returns `"src/lore/cli.py"`. Memory with `source="agent-123"` (not a path) returns `None`.

3. **`test_extract_file_ref_from_metadata`**: Memory with `metadata={"file": "src/app.py"}` returns `"src/app.py"`.

4. **`test_count_commits_since`**: Create a temp git repo, add a file, make 5 commits touching it. Verify `_count_commits_since()` returns 5 when `since_date` is before all commits.

5. **`test_file_exists_in_repo`**: Temp git repo with a file. Returns `True`. Delete the file and commit. Returns `False`.

6. **`test_search_snippet_found`**: Temp git repo with a file containing `def calculate_total(items):`. Memory content includes that line. `_search_snippet()` returns `True`.

7. **`test_search_snippet_not_found`**: Memory content includes code not present in repo. Returns `False`.

8. **`test_check_freshness_skips_non_code_memories`**: Memory with `source=None` and `type="note"` without file references is skipped (not in results).

9. **`test_check_freshness_deleted_file_is_obsolete`**: Memory referencing a deleted file is classified as OBSOLETE.

10. **`test_check_freshness_end_to_end`**: Create a temp repo, add memories referencing files with various commit counts, run `check_freshness()`, verify correct staleness levels.

**Acceptance Criteria**:
- [ ] All 10 tests pass.
- [ ] Tests use `tmp_path` fixture and `subprocess` to create isolated temp git repos (not the real Lore repo).
- [ ] Tests are deterministic — no dependency on system time or external state.
- [ ] Tests clean up after themselves (pytest tmp_path handles this).

---

### Story 3: SDK Integration — `Lore.freshness_check()`

**Summary**: Add `freshness_check()` method to the `Lore` class.

**Files to modify**:
- `src/lore/lore.py`

**Implementation**:
1. Add `freshness_check(repo_path=".", type=None, project=None)` method.
2. Internally calls `self.list_memories()` with the given filters (high limit to get all).
3. Passes memories to `check_freshness()` from the freshness module.
4. Returns `List[FreshnessResult]`.

**Acceptance Criteria**:
- [ ] `Lore.freshness_check()` returns a list of `FreshnessResult` objects.
- [ ] Accepts `repo_path`, `type`, and `project` parameters.
- [ ] Only checks memories that have file references (delegates filtering to `check_freshness()`).
- [ ] Import of `freshness` module is lazy (inside the method body) to avoid import-time dependency on git.
- [ ] Works with both SqliteStore and RemoteStore (it only reads memories via `list_memories()`).

---

### Story 4: CLI Command — `lore freshness-check`

**Summary**: Add `freshness-check` subcommand to the CLI.

**Files to modify**:
- `src/lore/cli.py`

**Implementation**:
1. Add `freshness-check` subparser with arguments: `--repo-path` (default `.`), `--type`, `--project`, `--json`.
2. Implement `cmd_freshness_check(args)` handler.
3. Human-readable output: group results by staleness level, show memory ID (truncated), type, content preview, and reason.
4. JSON output: list of objects with `id`, `level`, `commits_since`, `file_exists`, `snippet_found`, `details`.
5. Summary line: count per level.
6. Register handler in `handlers` dict and `build_parser()`.

**Acceptance Criteria**:
- [ ] `lore freshness-check` runs and prints a staleness report.
- [ ] `lore freshness-check --repo-path /path/to/repo` uses the specified repo.
- [ ] `lore freshness-check --type code` filters to only code-type memories.
- [ ] `lore freshness-check --json` outputs valid JSON with the expected structure.
- [ ] Results are grouped by staleness level (OBSOLETE first, FRESH last or hidden).
- [ ] Summary line shows count per level.
- [ ] If no memories have file references, prints "No code-related memories found to check."
- [ ] If not in a git repo and no `--repo-path` given, prints a clear error.

---

### Story 5: MCP Tool — `freshness_check`

**Summary**: Expose freshness detection as an MCP tool.

**Files to modify**:
- `src/lore/mcp/server.py`

**Implementation**:
1. Add `freshness_check` tool with `@mcp.tool()` decorator.
2. Parameters: `repo_path` (str, default "."), `type` (optional), `project` (optional).
3. Uses the same `check_freshness()` function from `lore.freshness`.
4. Returns formatted string grouped by staleness level (same format as CLI human-readable output).
5. Tool description guides LLMs on when to use it.

**Acceptance Criteria**:
- [ ] `freshness_check` tool is registered and callable.
- [ ] Returns human-readable staleness report as a string.
- [ ] Handles errors gracefully (not a git repo, git not installed) — returns error string, doesn't crash.
- [ ] Tool description mentions: checking for stale memories, git repository, code patterns.
- [ ] Works with both local and remote store modes (reads memories from whichever store is configured).

---

### Story 6: Integration Test — Full Freshness Flow

**Summary**: End-to-end test through `Lore.freshness_check()` with a real temp git repo and memories.

**Files to create**:
- `tests/test_freshness_integration.py`

**Test scenario**:
1. Create a temp directory, init git repo, create files, make initial commits.
2. Create a `Lore` instance with a temp DB.
3. `remember()` memories with `source` pointing to files in the temp repo (backdate `created_at` via direct store manipulation).
4. Make additional commits to some files (changing them).
5. Delete one file and commit.
6. Run `lore.freshness_check(repo_path=temp_repo)`.
7. Verify: unchanged file → FRESH, moderately changed file → AGING/STALE, heavily changed file → OBSOLETE, deleted file → OBSOLETE.

**Acceptance Criteria**:
- [ ] Test creates an isolated git repo with controlled commit history.
- [ ] Memories are created with backdated timestamps.
- [ ] `freshness_check()` correctly classifies each memory.
- [ ] Test is self-contained (temp dirs, temp DB, no side effects).
- [ ] Test passes in CI (no dependency on a specific repo state).

---

### Implementation Order

```
Story 1 (core module) → Story 2 (unit tests) → Story 3 (SDK method) → Story 4 (CLI) + Story 5 (MCP) → Story 6 (integration test)
```

Stories 4 and 5 can be parallelized after Story 3 is complete.
