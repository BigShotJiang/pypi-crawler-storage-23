"""Shared utilities for async and sync clients."""
