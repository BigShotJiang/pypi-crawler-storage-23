# Atomic Writes

Atomic writes and overwrite semantics.

```python
--8<-- "examples/atomic_writes.py"
```
