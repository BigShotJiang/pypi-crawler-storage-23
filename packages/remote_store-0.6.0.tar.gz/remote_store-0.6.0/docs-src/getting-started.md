# Getting Started

{%
   include-markdown "../README.md"
   start="## Installation"
   end="## Contributing"
%}
