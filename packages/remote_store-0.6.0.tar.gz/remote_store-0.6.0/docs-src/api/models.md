# Models

::: remote_store.FileInfo

::: remote_store.FolderInfo

::: remote_store.RemoteFile

::: remote_store.RemoteFolder
