# Registry

::: remote_store.Registry

::: remote_store.register_backend
