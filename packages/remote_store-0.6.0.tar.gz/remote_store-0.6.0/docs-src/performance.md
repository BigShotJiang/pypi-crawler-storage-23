{%
   include-markdown "../guides/performance.md"
%}
