"""Benchmark targets — unified interface for comparing remote-store vs raw SDKs vs fsspec."""

from benchmarks.targets._protocol import BenchTarget

__all__ = ["BenchTarget"]
