# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Licensed under the MIT License - see LICENSE file for details

"""Tests: PII detection defaults to off, HIPAA force-enables it."""

import pytest

from familiar.core.guardrails import (
    GuardrailConfig,
    Guardrails,
    PIIAction,
)


class TestPIIDefault:
    """PII detection should be opt-in (default off)."""

    def test_guardrail_config_default_off(self):
        """GuardrailConfig.enable_pii_detection defaults to False."""
        cfg = GuardrailConfig()
        assert cfg.enable_pii_detection is False

    def test_agent_config_default_off(self):
        """AgentConfig.enable_pii_detection defaults to False."""
        from familiar.core.config import AgentConfig

        assert AgentConfig().enable_pii_detection is False

    def test_no_detector_when_off(self):
        """Guardrails should not create a PII detector when disabled."""
        cfg = GuardrailConfig(enable_pii_detection=False)
        g = Guardrails(cfg)
        assert g._pii_detector is None

    def test_detector_created_when_on(self):
        """Guardrails should create a PII detector when enabled."""
        cfg = GuardrailConfig(enable_pii_detection=True)
        g = Guardrails(cfg)
        assert g._pii_detector is not None

    def test_hipaa_forces_pii_on(self):
        """HIPAA compliance mode force-enables PII detection even when default is off."""
        cfg = GuardrailConfig(enable_pii_detection=False)
        g = Guardrails(cfg)
        assert g._pii_detector is None

        g.set_compliance_mode("hipaa")

        assert g._pii_detector is not None
        assert g._pii_detector.config.action == PIIAction.BLOCK

    def test_hipaa_upgrades_existing_detector_to_block(self):
        """HIPAA mode upgrades an existing REDACT detector to BLOCK."""
        cfg = GuardrailConfig(enable_pii_detection=True)
        g = Guardrails(cfg)
        assert g._pii_detector is not None
        assert g._pii_detector.config.action == PIIAction.REDACT

        g.set_compliance_mode("hipaa")

        assert g._pii_detector.config.action == PIIAction.BLOCK

    def test_process_with_pii_noop_when_off(self):
        """When PII detection is off, process_with_pii returns text unchanged."""
        cfg = GuardrailConfig(enable_pii_detection=False)
        g = Guardrails(cfg)
        text = "My SSN is 123-45-6789 and email is test@example.com"
        result, findings, blocked = g.process_with_pii(text)
        assert result == text
        assert findings == []
        assert blocked is False

    def test_set_compliance_mode_none_is_noop(self):
        """set_compliance_mode(None) does nothing."""
        cfg = GuardrailConfig(enable_pii_detection=False)
        g = Guardrails(cfg)
        g.set_compliance_mode(None)
        assert g._pii_detector is None

    def test_set_compliance_mode_non_hipaa_is_noop(self):
        """Non-HIPAA compliance modes don't force-enable PII."""
        cfg = GuardrailConfig(enable_pii_detection=False)
        g = Guardrails(cfg)
        g.set_compliance_mode("soc2")
        assert g._pii_detector is None
