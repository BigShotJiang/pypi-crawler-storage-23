# Task Management Skill

Track tasks, to-dos, and deadlines for nonprofit administration.

## Usage

Use this skill when the user wants to:
- Add tasks or to-dos
- Check what's due
- Mark tasks complete
- Track project progress
- Manage deadlines

## Nonprofit Context

Common task categories:
- **Grants**: Application deadlines, reporting requirements
- **Donors**: Thank you letters, follow-ups, acknowledgments  
- **Board**: Meeting prep, minutes, action items
- **Events**: Planning, coordination, follow-up
- **Compliance**: Filings, renewals, audits
- **Programs**: Service delivery, volunteer coordination

## Priority Levels

- 🔴 **Urgent**: Due within 48 hours or critical
- 🟡 **High**: Due within a week
- 🟢 **Normal**: Standard priority
- ⚪ **Low**: Nice to do when time permits
