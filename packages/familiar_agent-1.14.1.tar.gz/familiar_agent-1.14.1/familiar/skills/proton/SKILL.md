# Proton Services Skill

Monitor Proton Mail Bridge health and control Proton VPN.

## Usage

Use this skill when the user asks about Proton services — checking if Bridge is running, connecting/disconnecting VPN, or checking VPN status. This covers Proton Mail Bridge health monitoring and Proton VPN control.

## Examples

- "Is Proton Bridge running?"
- "Connect to a Swiss VPN server"
- "Disconnect from VPN"
- "What's my VPN status?"
- "Check Proton services health"
- "Connect to the fastest VPN server"

## Important

- Bridge must be running for Proton email to work via IMAP/SMTP — use `proton_status` to verify.
- VPN connect/disconnect changes network routing for the entire system.
- VPN uses `protonvpn-cli` under the hood — it must be installed and logged in.

## Disambiguation

- This is **NOT** for sending or reading email — use email tools (`send_email`, `check_email`) for that. Bridge just provides the IMAP/SMTP connection.
- This is **NOT** for DNS blocking or ad blocking — use Pi-hole (`pihole_*`) for that.
- This is **NOT** for other VPN providers (WireGuard, OpenVPN, etc.) — only Proton VPN.

## Proton Mail Bridge

Proton Mail Bridge exposes IMAP/SMTP on localhost for use with standard
email clients. Default ports:

- IMAP: `127.0.0.1:1143` (STARTTLS)
- SMTP: `127.0.0.1:1025` (STARTTLS)

### Setup

1. Install Proton Mail Bridge from https://proton.me/mail/bridge
2. Log in and leave Bridge running
3. Configure Familiar email with the Bridge password (not your Proton password):
   ```
   /connect email user@proton.me <bridge-password>
   ```
   Ports are auto-detected for proton.me / protonmail.com / pm.me domains.

## Proton VPN

VPN control uses `protonvpn-cli` (official Linux CLI).

### Setup

1. Install: https://protonvpn.com/support/linux-vpn-setup/
2. Log in: `protonvpn-cli login <username>`
3. Use the `proton_vpn_connect` / `proton_vpn_disconnect` tools

## Tools

- `proton_status` — Health check for Bridge ports, email config, and VPN
- `proton_vpn_connect` — Connect to VPN (fastest or by country code)
- `proton_vpn_disconnect` — Disconnect from VPN
- `proton_vpn_status` — Detailed VPN connection info

## Environment Overrides

If your Bridge uses non-default ports:

```
PROTON_BRIDGE_HOST=127.0.0.1
PROTON_BRIDGE_IMAP_PORT=1143
PROTON_BRIDGE_SMTP_PORT=1025
```
