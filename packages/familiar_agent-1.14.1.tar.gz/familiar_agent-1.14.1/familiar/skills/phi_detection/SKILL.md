# PHI Detection Middleware

Scan text and data for Protected Health Information (PHI) before it
leaves the system. Auto-redact, classify, and enforce safe mode.

## HIPAA PHI Identifiers (18 categories)

1. Names  2. Geographic data  3. Dates (except year)
4. Phone numbers  5. Fax numbers  6. Email addresses
7. SSN  8. Medical record numbers  9. Health plan beneficiary numbers
10. Account numbers  11. Certificate/license numbers
12. Vehicle identifiers  13. Device identifiers  14. URLs
15. IP addresses  16. Biometric identifiers  17. Photos
18. Any other unique identifying characteristic

## Cross-Skill Integration

- Middleware hook: scan all outbound data before email, export, or display
- Integrates with audit skill to log PHI access events
- Integrates with encryption skill for PHI-at-rest protection
