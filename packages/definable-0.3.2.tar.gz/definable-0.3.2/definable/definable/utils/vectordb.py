"""Backward compatibility — enums moved to definable.vectordb."""

from definable.vectordb.distance import Distance  # noqa: F401
from definable.vectordb.search import SearchType  # noqa: F401
