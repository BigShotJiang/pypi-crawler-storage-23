"""
agentic-devtools: AI assistant helper commands for the Dragonfly platform.

This package provides simple CLI commands that can be easily auto-approved
by VS Code AI assistants.
"""

from agentic_devtools._version import __version__
