"""
Shared fixtures for Azure DevOps tests.
"""

from unittest.mock import patch

import pytest


@pytest.fixture
def mock_azure_devops_env():
    """Set up environment variables for Azure DevOps API calls."""
    with patch.dict(
        "os.environ",
        {"AZURE_DEV_OPS_COPILOT_PAT": "test-pat"},
    ):
        yield


@pytest.fixture(autouse=True)
def mock_git_remote_detection(request, monkeypatch):
    """
    Auto-mock git remote detection for all Azure DevOps tests except
    tests in TestRepositoryDetection class which specifically test that function.

    This prevents the git remote detection from interfering with test mocks
    by making it always return None (which causes fallback to DEFAULT_REPOSITORY).
    """
    # Skip this fixture for tests in TestRepositoryDetection class
    if "TestRepositoryDetection" in request.node.nodeid:
        yield
        return

    from agentic_devtools.cli.azure_devops import config

    monkeypatch.setattr(config, "get_repository_name_from_git_remote", lambda: None)
    yield
