"""Kunlun XPU kernels module.

Provides optimized kernels for Baidu Kunlun XPU devices:
- GEMM/MatMul operations
- Fused operations
- Attention kernels
- Normalization kernels
"""

from __future__ import annotations

from sagellm_backend.kernels.kunlun.gemm import KunlunGEMM
from sagellm_backend.kernels.kunlun.matmul import KunlunMatMul

__all__ = [
    "KunlunGEMM",
    "KunlunMatMul",
]
