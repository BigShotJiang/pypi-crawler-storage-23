import{t as ge,f as Me,p as Ee,h as Je,r as We,q as Ke,o as Ge,i as S,a as He,k as Ye,s as Qe,l as Xe,m as Ze,n as en,j as nn}from"./utils-C9_ekjJI.js";import{B as we,h as sn,R as an,O as $e,j as on,r as tn,J as ln,o as c,e as y,w as X,c as k,m as _,a as O,d as H,H as rn,f as un,g as U,K as cn,T as dn,u as mn,au as pn,q as v,ax as gn,E as vn,t as A,b as C,l as ve,F as fe,G as ye,av as fn,C as V,aw as Y,y as yn,M as Q,k as x}from"./index-npYuX9gz.js";import{b as bn,s as hn}from"./index-CtiXyRra.js";var kn=`
    .p-message {
        display: grid;
        grid-template-rows: 1fr;
        border-radius: dt('message.border.radius');
        outline-width: dt('message.border.width');
        outline-style: solid;
    }

    .p-message-content-wrapper {
        min-height: 0;
    }

    .p-message-content {
        display: flex;
        align-items: center;
        padding: dt('message.content.padding');
        gap: dt('message.content.gap');
    }

    .p-message-icon {
        flex-shrink: 0;
    }

    .p-message-close-button {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        margin-inline-start: auto;
        overflow: hidden;
        position: relative;
        width: dt('message.close.button.width');
        height: dt('message.close.button.height');
        border-radius: dt('message.close.button.border.radius');
        background: transparent;
        transition:
            background dt('message.transition.duration'),
            color dt('message.transition.duration'),
            outline-color dt('message.transition.duration'),
            box-shadow dt('message.transition.duration'),
            opacity 0.3s;
        outline-color: transparent;
        color: inherit;
        padding: 0;
        border: none;
        cursor: pointer;
        user-select: none;
    }

    .p-message-close-icon {
        font-size: dt('message.close.icon.size');
        width: dt('message.close.icon.size');
        height: dt('message.close.icon.size');
    }

    .p-message-close-button:focus-visible {
        outline-width: dt('message.close.button.focus.ring.width');
        outline-style: dt('message.close.button.focus.ring.style');
        outline-offset: dt('message.close.button.focus.ring.offset');
    }

    .p-message-info {
        background: dt('message.info.background');
        outline-color: dt('message.info.border.color');
        color: dt('message.info.color');
        box-shadow: dt('message.info.shadow');
    }

    .p-message-info .p-message-close-button:focus-visible {
        outline-color: dt('message.info.close.button.focus.ring.color');
        box-shadow: dt('message.info.close.button.focus.ring.shadow');
    }

    .p-message-info .p-message-close-button:hover {
        background: dt('message.info.close.button.hover.background');
    }

    .p-message-info.p-message-outlined {
        color: dt('message.info.outlined.color');
        outline-color: dt('message.info.outlined.border.color');
    }

    .p-message-info.p-message-simple {
        color: dt('message.info.simple.color');
    }

    .p-message-success {
        background: dt('message.success.background');
        outline-color: dt('message.success.border.color');
        color: dt('message.success.color');
        box-shadow: dt('message.success.shadow');
    }

    .p-message-success .p-message-close-button:focus-visible {
        outline-color: dt('message.success.close.button.focus.ring.color');
        box-shadow: dt('message.success.close.button.focus.ring.shadow');
    }

    .p-message-success .p-message-close-button:hover {
        background: dt('message.success.close.button.hover.background');
    }

    .p-message-success.p-message-outlined {
        color: dt('message.success.outlined.color');
        outline-color: dt('message.success.outlined.border.color');
    }

    .p-message-success.p-message-simple {
        color: dt('message.success.simple.color');
    }

    .p-message-warn {
        background: dt('message.warn.background');
        outline-color: dt('message.warn.border.color');
        color: dt('message.warn.color');
        box-shadow: dt('message.warn.shadow');
    }

    .p-message-warn .p-message-close-button:focus-visible {
        outline-color: dt('message.warn.close.button.focus.ring.color');
        box-shadow: dt('message.warn.close.button.focus.ring.shadow');
    }

    .p-message-warn .p-message-close-button:hover {
        background: dt('message.warn.close.button.hover.background');
    }

    .p-message-warn.p-message-outlined {
        color: dt('message.warn.outlined.color');
        outline-color: dt('message.warn.outlined.border.color');
    }

    .p-message-warn.p-message-simple {
        color: dt('message.warn.simple.color');
    }

    .p-message-error {
        background: dt('message.error.background');
        outline-color: dt('message.error.border.color');
        color: dt('message.error.color');
        box-shadow: dt('message.error.shadow');
    }

    .p-message-error .p-message-close-button:focus-visible {
        outline-color: dt('message.error.close.button.focus.ring.color');
        box-shadow: dt('message.error.close.button.focus.ring.shadow');
    }

    .p-message-error .p-message-close-button:hover {
        background: dt('message.error.close.button.hover.background');
    }

    .p-message-error.p-message-outlined {
        color: dt('message.error.outlined.color');
        outline-color: dt('message.error.outlined.border.color');
    }

    .p-message-error.p-message-simple {
        color: dt('message.error.simple.color');
    }

    .p-message-secondary {
        background: dt('message.secondary.background');
        outline-color: dt('message.secondary.border.color');
        color: dt('message.secondary.color');
        box-shadow: dt('message.secondary.shadow');
    }

    .p-message-secondary .p-message-close-button:focus-visible {
        outline-color: dt('message.secondary.close.button.focus.ring.color');
        box-shadow: dt('message.secondary.close.button.focus.ring.shadow');
    }

    .p-message-secondary .p-message-close-button:hover {
        background: dt('message.secondary.close.button.hover.background');
    }

    .p-message-secondary.p-message-outlined {
        color: dt('message.secondary.outlined.color');
        outline-color: dt('message.secondary.outlined.border.color');
    }

    .p-message-secondary.p-message-simple {
        color: dt('message.secondary.simple.color');
    }

    .p-message-contrast {
        background: dt('message.contrast.background');
        outline-color: dt('message.contrast.border.color');
        color: dt('message.contrast.color');
        box-shadow: dt('message.contrast.shadow');
    }

    .p-message-contrast .p-message-close-button:focus-visible {
        outline-color: dt('message.contrast.close.button.focus.ring.color');
        box-shadow: dt('message.contrast.close.button.focus.ring.shadow');
    }

    .p-message-contrast .p-message-close-button:hover {
        background: dt('message.contrast.close.button.hover.background');
    }

    .p-message-contrast.p-message-outlined {
        color: dt('message.contrast.outlined.color');
        outline-color: dt('message.contrast.outlined.border.color');
    }

    .p-message-contrast.p-message-simple {
        color: dt('message.contrast.simple.color');
    }

    .p-message-text {
        font-size: dt('message.text.font.size');
        font-weight: dt('message.text.font.weight');
    }

    .p-message-icon {
        font-size: dt('message.icon.size');
        width: dt('message.icon.size');
        height: dt('message.icon.size');
    }

    .p-message-sm .p-message-content {
        padding: dt('message.content.sm.padding');
    }

    .p-message-sm .p-message-text {
        font-size: dt('message.text.sm.font.size');
    }

    .p-message-sm .p-message-icon {
        font-size: dt('message.icon.sm.size');
        width: dt('message.icon.sm.size');
        height: dt('message.icon.sm.size');
    }

    .p-message-sm .p-message-close-icon {
        font-size: dt('message.close.icon.sm.size');
        width: dt('message.close.icon.sm.size');
        height: dt('message.close.icon.sm.size');
    }

    .p-message-lg .p-message-content {
        padding: dt('message.content.lg.padding');
    }

    .p-message-lg .p-message-text {
        font-size: dt('message.text.lg.font.size');
    }

    .p-message-lg .p-message-icon {
        font-size: dt('message.icon.lg.size');
        width: dt('message.icon.lg.size');
        height: dt('message.icon.lg.size');
    }

    .p-message-lg .p-message-close-icon {
        font-size: dt('message.close.icon.lg.size');
        width: dt('message.close.icon.lg.size');
        height: dt('message.close.icon.lg.size');
    }

    .p-message-outlined {
        background: transparent;
        outline-width: dt('message.outlined.border.width');
    }

    .p-message-simple {
        background: transparent;
        outline-color: transparent;
        box-shadow: none;
    }

    .p-message-simple .p-message-content {
        padding: dt('message.simple.content.padding');
    }

    .p-message-outlined .p-message-close-button:hover,
    .p-message-simple .p-message-close-button:hover {
        background: transparent;
    }

    .p-message-enter-active {
        animation: p-animate-message-enter 0.3s ease-out forwards;
        overflow: hidden;
    }

    .p-message-leave-active {
        animation: p-animate-message-leave 0.15s ease-in forwards;
        overflow: hidden;
    }

    @keyframes p-animate-message-enter {
        from {
            opacity: 0;
            grid-template-rows: 0fr;
        }
        to {
            opacity: 1;
            grid-template-rows: 1fr;
        }
    }

    @keyframes p-animate-message-leave {
        from {
            opacity: 1;
            grid-template-rows: 1fr;
        }
        to {
            opacity: 0;
            margin: 0;
            grid-template-rows: 0fr;
        }
    }
`,wn={root:function(s){var i=s.props;return["p-message p-component p-message-"+i.severity,{"p-message-outlined":i.variant==="outlined","p-message-simple":i.variant==="simple","p-message-sm":i.size==="small","p-message-lg":i.size==="large"}]},contentWrapper:"p-message-content-wrapper",content:"p-message-content",icon:"p-message-icon",text:"p-message-text",closeButton:"p-message-close-button",closeIcon:"p-message-close-icon"},$n=we.extend({name:"message",style:kn,classes:wn}),Vn={name:"BaseMessage",extends:$e,props:{severity:{type:String,default:"info"},closable:{type:Boolean,default:!1},life:{type:Number,default:null},icon:{type:String,default:void 0},closeIcon:{type:String,default:void 0},closeButtonProps:{type:null,default:null},size:{type:String,default:null},variant:{type:String,default:null}},style:$n,provide:function(){return{$pcMessage:this,$parentInstance:this}}};function N(n){"@babel/helpers - typeof";return N=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(s){return typeof s}:function(s){return s&&typeof Symbol=="function"&&s.constructor===Symbol&&s!==Symbol.prototype?"symbol":typeof s},N(n)}function be(n,s,i){return(s=Sn(s))in n?Object.defineProperty(n,s,{value:i,enumerable:!0,configurable:!0,writable:!0}):n[s]=i,n}function Sn(n){var s=xn(n,"string");return N(s)=="symbol"?s:s+""}function xn(n,s){if(N(n)!="object"||!n)return n;var i=n[Symbol.toPrimitive];if(i!==void 0){var f=i.call(n,s);if(N(f)!="object")return f;throw new TypeError("@@toPrimitive must return a primitive value.")}return(s==="string"?String:Number)(n)}var Ve={name:"Message",extends:Vn,inheritAttrs:!1,emits:["close","life-end"],timeout:null,data:function(){return{visible:!0}},mounted:function(){var s=this;this.life&&setTimeout(function(){s.visible=!1,s.$emit("life-end")},this.life)},methods:{close:function(s){this.visible=!1,this.$emit("close",s)}},computed:{closeAriaLabel:function(){return this.$primevue.config.locale.aria?this.$primevue.config.locale.aria.close:void 0},dataP:function(){return on(be(be({outlined:this.variant==="outlined",simple:this.variant==="simple"},this.severity,this.severity),this.size,this.size))}},directives:{ripple:an},components:{TimesIcon:sn}};function q(n){"@babel/helpers - typeof";return q=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(s){return typeof s}:function(s){return s&&typeof Symbol=="function"&&s.constructor===Symbol&&s!==Symbol.prototype?"symbol":typeof s},q(n)}function he(n,s){var i=Object.keys(n);if(Object.getOwnPropertySymbols){var f=Object.getOwnPropertySymbols(n);s&&(f=f.filter(function(B){return Object.getOwnPropertyDescriptor(n,B).enumerable})),i.push.apply(i,f)}return i}function ke(n){for(var s=1;s<arguments.length;s++){var i=arguments[s]!=null?arguments[s]:{};s%2?he(Object(i),!0).forEach(function(f){Pn(n,f,i[f])}):Object.getOwnPropertyDescriptors?Object.defineProperties(n,Object.getOwnPropertyDescriptors(i)):he(Object(i)).forEach(function(f){Object.defineProperty(n,f,Object.getOwnPropertyDescriptor(i,f))})}return n}function Pn(n,s,i){return(s=jn(s))in n?Object.defineProperty(n,s,{value:i,enumerable:!0,configurable:!0,writable:!0}):n[s]=i,n}function jn(n){var s=_n(n,"string");return q(s)=="symbol"?s:s+""}function _n(n,s){if(q(n)!="object"||!n)return n;var i=n[Symbol.toPrimitive];if(i!==void 0){var f=i.call(n,s);if(q(f)!="object")return f;throw new TypeError("@@toPrimitive must return a primitive value.")}return(s==="string"?String:Number)(n)}var zn=["data-p"],Cn=["data-p"],On=["data-p"],Rn=["aria-label","data-p"],Fn=["data-p"];function Un(n,s,i,f,B,p){var T=tn("TimesIcon"),$=ln("ripple");return c(),y(dn,_({name:"p-message",appear:""},n.ptmi("transition")),{default:X(function(){return[B.visible?(c(),k("div",_({key:0,class:n.cx("root"),role:"alert","aria-live":"assertive","aria-atomic":"true","data-p":p.dataP},n.ptm("root")),[O("div",_({class:n.cx("contentWrapper")},n.ptm("contentWrapper")),[n.$slots.container?H(n.$slots,"container",{key:0,closeCallback:p.close}):(c(),k("div",_({key:1,class:n.cx("content"),"data-p":p.dataP},n.ptm("content")),[H(n.$slots,"icon",{class:rn(n.cx("icon"))},function(){return[(c(),y(un(n.icon?"span":null),_({class:[n.cx("icon"),n.icon],"data-p":p.dataP},n.ptm("icon")),null,16,["class","data-p"]))]}),n.$slots.default?(c(),k("div",_({key:0,class:n.cx("text"),"data-p":p.dataP},n.ptm("text")),[H(n.$slots,"default")],16,On)):U("",!0),n.closable?cn((c(),k("button",_({key:1,class:n.cx("closeButton"),"aria-label":p.closeAriaLabel,type:"button",onClick:s[0]||(s[0]=function(F){return p.close(F)}),"data-p":p.dataP},ke(ke({},n.closeButtonProps),n.ptm("closeButton"))),[H(n.$slots,"closeicon",{},function(){return[n.closeIcon?(c(),k("i",_({key:0,class:[n.cx("closeIcon"),n.closeIcon],"data-p":p.dataP},n.ptm("closeIcon")),null,16,Fn)):(c(),y(T,_({key:1,class:[n.cx("closeIcon"),n.closeIcon],"data-p":p.dataP},n.ptm("closeIcon")),null,16,["class","data-p"]))]})],16,Rn)),[[$]]):U("",!0)],16,Cn))],16)],16,zn)):U("",!0)]}),_:3},16)}Ve.render=Un;var Tn=`
    .p-progressspinner {
        position: relative;
        margin: 0 auto;
        width: 100px;
        height: 100px;
        display: inline-block;
    }

    .p-progressspinner::before {
        content: '';
        display: block;
        padding-top: 100%;
    }

    .p-progressspinner-spin {
        height: 100%;
        transform-origin: center center;
        width: 100%;
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
        animation: p-progressspinner-rotate 2s linear infinite;
    }

    .p-progressspinner-circle {
        stroke-dasharray: 89, 200;
        stroke-dashoffset: 0;
        stroke: dt('progressspinner.colorOne');
        animation:
            p-progressspinner-dash 1.5s ease-in-out infinite,
            p-progressspinner-color 6s ease-in-out infinite;
        stroke-linecap: round;
    }

    @keyframes p-progressspinner-rotate {
        100% {
            transform: rotate(360deg);
        }
    }
    @keyframes p-progressspinner-dash {
        0% {
            stroke-dasharray: 1, 200;
            stroke-dashoffset: 0;
        }
        50% {
            stroke-dasharray: 89, 200;
            stroke-dashoffset: -35px;
        }
        100% {
            stroke-dasharray: 89, 200;
            stroke-dashoffset: -124px;
        }
    }
    @keyframes p-progressspinner-color {
        100%,
        0% {
            stroke: dt('progressspinner.color.one');
        }
        40% {
            stroke: dt('progressspinner.color.two');
        }
        66% {
            stroke: dt('progressspinner.color.three');
        }
        80%,
        90% {
            stroke: dt('progressspinner.color.four');
        }
    }
`,Dn={root:"p-progressspinner",spin:"p-progressspinner-spin",circle:"p-progressspinner-circle"},In=we.extend({name:"progressspinner",style:Tn,classes:Dn}),Bn={name:"BaseProgressSpinner",extends:$e,props:{strokeWidth:{type:String,default:"2"},fill:{type:String,default:"none"},animationDuration:{type:String,default:"2s"}},style:In,provide:function(){return{$pcProgressSpinner:this,$parentInstance:this}}},Se={name:"ProgressSpinner",extends:Bn,inheritAttrs:!1,computed:{svgStyle:function(){return{"animation-duration":this.animationDuration}}}},An=["fill","stroke-width"];function Ln(n,s,i,f,B,p){return c(),k("div",_({class:n.cx("root"),role:"progressbar"},n.ptmi("root")),[(c(),k("svg",_({class:n.cx("spin"),viewBox:"25 25 50 50",style:p.svgStyle},n.ptm("spin")),[O("circle",_({class:n.cx("circle"),cx:"50",cy:"50",r:"20",fill:n.fill,"stroke-width":n.strokeWidth,strokeMiterlimit:"10"},n.ptm("circle")),null,16,An)],16))],16)}Se.render=Ln;const Nn={class:"grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-6 items-start"},qn={class:"card"},Mn={class:"flex justify-between items-center mb-4"},En={class:"text-xl font-semibold"},Jn={key:0,class:"flex justify-center p-8"},Wn=["for"],Kn={key:0,class:"text-red-500"},Gn={key:1,class:"flex gap-2 items-center"},Hn={class:"card lg:sticky lg:top-24"},Yn={class:"flex flex-col gap-3"},Qn=["for"],Xn={key:0,class:"text-red-500"},Zn={class:"flex justify-end gap-2 mt-2"},as={__name:"ModelDetail",setup(n){const s=fn(),i=yn(),f=mn(),B=pn(),p=v(s.params.model),T=v(s.params.pk),$=Y(()=>!T.value),F=v(null),R=v([]),m=v({}),M=v(null),z=v({}),D=v({}),le=v({}),re=v([]),Z=v(!1),E=v(!1),ee=v(!1),L=v(!1),ne=v(null),J=v(null),I=v([]),h=v({}),P=v({}),se=v({}),W=v(!1);function ie(l,a,o){const r=l.properties||{},t=new Set(l.required||[]),d=new Set(o||[]),w=Ee(l),j=[];for(const[g,b]of Object.entries(r)){if(b["x-db-m2m"]){j.push({name:g,label:a&&a[g]||b.title||g,type:"array",format:null,dbType:null,isPk:!1,isReadonly:d.has(g),isRequired:!1,default:[],maxLength:null,fk:null,m2m:{target:b["x-db-target"],through:b["x-db-through"]}});continue}if(Je(b))continue;const G=w[g]||null;j.push({name:g,label:a&&a[g]||b.title||g,type:Ke(b),format:We(b),dbType:b["x-db-type"]||null,isPk:!!b["x-db-primary-key"],isReadonly:!!b["x-db-readonly"]||d.has(g),isRequired:t.has(g),default:b.default??null,maxLength:b.maxLength||b["x-db-max-length"]||null,fk:G,m2m:null})}return j}const xe=Y(()=>R.value.filter(l=>!(l.isPk&&$.value))),ae=Y(()=>$.value?!0:M.value?JSON.stringify(m.value)!==JSON.stringify(M.value):!1),Pe=Y(()=>I.value.filter(l=>!l.isPk));function oe(l,a){const o={};for(const r of l){let t=a?a[r.name]??r.default:r.default;r.m2m&&Array.isArray(t)?t=t.map(d=>typeof d!="object"?d:d.value??d.id??Object.values(d)[0]).filter(d=>d!=null):t&&(r.format==="date-time"||r.format==="date")&&(t=new Date(t)),o[r.name]=t}return o}function ue(l,a){const o={};for(const r of l)if(r.isRequired&&!r.isPk&&!r.isReadonly){const t=a[r.name];(t==null||t==="")&&(o[r.name]="This field is required")}return o}function je(){const l={};for(const a of R.value){if(a.isReadonly||a.isPk&&$.value)continue;let o=m.value[a.name];if(a.m2m){l[a.name]=Array.isArray(o)?o:[];continue}o instanceof Date&&(o=Ge(o,a.format)),l[a.name]=o}return l}async function _e(){const[l,a]=await Promise.all([V(`/api/${p.value}/schema`),V("/api/models")]);F.value=await l.json();const r=(await a.json()).find(t=>t.name===p.value);le.value=r?.column_labels||{},re.value=r?.readonly_fields||[],R.value=ie(F.value,le.value,re.value)}async function ze(){const l=R.value.filter(t=>t.fk),a=R.value.filter(t=>t.m2m),o=l.map(async t=>{let d=`/api/${t.fk.model}/options`;const w=m.value?.[t.name];w!=null&&(d+=`?include=${encodeURIComponent(w)}`);const j=await V(d);D.value[t.name]=await j.json()}),r=a.map(async t=>{let d=`/api/${t.m2m.target}/options`;const w=m.value?.[t.name];if(Array.isArray(w)&&w.length>0){const g=w.map(b=>`include=${encodeURIComponent(b)}`).join("&");d+=`?${g}`}const j=await V(d);D.value[t.name]=await j.json()});await Promise.all([...o,...r])}let ce=null;function Ce(l,a){clearTimeout(ce);const o=a.value;ce=setTimeout(async()=>{const r=o?`/api/${l.fk.model}/options?search=${encodeURIComponent(o)}`:`/api/${l.fk.model}/options`,t=await V(r);D.value[l.name]=await t.json()},300)}let de=null;function Oe(l,a){clearTimeout(de);const o=a.value;de=setTimeout(async()=>{const r=o?`/api/${l.m2m.target}/options?search=${encodeURIComponent(o)}`:`/api/${l.m2m.target}/options`,t=await V(r);D.value[l.name]=await t.json()},300)}async function Re(){Z.value=!0;try{const l=await V(`/api/${p.value}/${T.value}`);m.value=oe(R.value,await l.json()),M.value=JSON.parse(JSON.stringify(m.value))}finally{Z.value=!1}}async function te(l=!1){const a=ue(R.value,m.value);if(Object.keys(a).length>0){z.value=a;return}E.value=!0,z.value={};try{const o=$.value?`/api/${p.value}`:`/api/${p.value}/${T.value}`,t=await(await V(o,{method:$.value?"POST":"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify(je())})).json();if(f.add({severity:"success",summary:"Saved",detail:`${F.value.title} saved`,life:3e3}),K.value=!0,$.value){const d=ge(t,R.value);d!==null&&(l?i.replace(`/${p.value}/${d}`):i.push(`/${p.value}`))}else l?(M.value=JSON.parse(JSON.stringify(m.value)),K.value=!1):i.push(`/${p.value}`)}catch(o){o.status===422&&Te(await o.response.json())}finally{E.value=!1}}function Fe(){B.require({message:`Are you sure you want to delete this ${F.value?.title||"record"}?`,header:"Confirm Delete",icon:"pi pi-exclamation-triangle",rejectLabel:"Cancel",rejectProps:{severity:"secondary",text:!0},acceptLabel:"Delete",acceptProps:{severity:"danger"},accept:Ue})}async function Ue(){ee.value=!0;try{await V(`/api/${p.value}/${T.value}`,{method:"DELETE"}),f.add({severity:"success",summary:"Deleted",detail:`${F.value.title} deleted`,life:3e3}),K.value=!0,i.push(`/${p.value}`)}catch{}finally{ee.value=!1}}function Te(l){if(!Array.isArray(l.detail))return;const a={};for(const o of l.detail){const r=o.loc||[],t=r[r.length-1];t&&(a[t]=o.msg)}z.value=a}function De(){window.history.state?.back?i.back():i.push(`/${p.value}`)}function Ie(l){i.push(`/${l.fk.model}/${m.value[l.name]}`)}async function Be(l){ne.value=l,P.value={},W.value=!1;const a=await V(`/api/${l.fk.model}/schema`);J.value=await a.json(),I.value=ie(J.value),h.value=oe(I.value,null);const o=I.value.filter(t=>t.fk),r={};await Promise.all(o.map(async t=>{const d=await V(`/api/${t.fk.model}/options`);r[t.name]=await d.json()})),se.value=r,L.value=!0}let me=null;function Ae(l,a){clearTimeout(me);const o=a.value;me=setTimeout(async()=>{const r=o?`/api/${l.fk.model}/options?search=${encodeURIComponent(o)}`:`/api/${l.fk.model}/options`,t=await V(r);se.value[l.name]=await t.json()},300)}async function Le(){const l=ue(I.value,h.value);if(Object.keys(l).length>0){P.value=l;return}W.value=!0,P.value={};try{const a=ne.value.fk.model,o={};for(const g of I.value)g.isReadonly||g.isPk||(o[g.name]=h.value[g.name]);const t=await(await V(`/api/${a}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(o)})).json();f.add({severity:"success",summary:"Created",detail:`${J.value.title} created`,life:3e3});const d=ge(t,I.value),w=ne.value,j=await V(`/api/${w.fk.model}/options`);D.value[w.name]=await j.json(),m.value[w.name]=d,L.value=!1}catch(a){if(a.status===422){const o=await a.response.json();if(Array.isArray(o.detail)){const r={};for(const t of o.detail){const d=t.loc||[];r[d[d.length-1]]=t.msg}P.value=r}}}finally{W.value=!1}}const K=v(!1);return gn(()=>K.value||!ae.value||$.value?!0:window.confirm("You have unsaved changes. Leave this page?")),vn(async()=>{await _e(),$.value?m.value=oe(R.value,null):await Re(),await ze()}),(l,a)=>{const o=bn,r=Se,t=nn,d=He,w=Ye,j=Qe,g=Xe,b=Ze,G=hn,pe=Ve,Ne=Me,qe=en;return c(),k("div",Nn,[O("div",qn,[O("div",Mn,[O("div",En,A(F.value?.title||p.value)+" "+A($.value?"Create":`#${T.value}`),1),C(o,{label:"Back",icon:"pi pi-arrow-left",text:"",onClick:De})]),Z.value?(c(),k("div",Jn,[C(r)])):(c(),k("form",{key:1,onSubmit:a[0]||(a[0]=ve(e=>te(!1),["prevent"])),class:"flex flex-col gap-4"},[(c(!0),k(fe,null,ye(xe.value,e=>(c(),k("div",{key:e.name,class:"flex flex-col gap-1"},[O("label",{for:e.name,class:"font-semibold"},[Q(A(e.label)+" ",1),e.isRequired?(c(),k("span",Kn,"*")):U("",!0)],8,Wn),x(S)(e)==="multiselect"?(c(),y(t,{key:0,id:e.name,modelValue:m.value[e.name],"onUpdate:modelValue":u=>m.value[e.name]=u,options:D.value[e.name]||[],optionLabel:"label",optionValue:"value",disabled:e.isReadonly,display:"chip",filter:"",onFilter:u=>Oe(e,u),placeholder:"Select...",fluid:""},null,8,["id","modelValue","onUpdate:modelValue","options","disabled","onFilter"])):x(S)(e)==="select"?(c(),k("div",Gn,[C(d,{id:e.name,modelValue:m.value[e.name],"onUpdate:modelValue":u=>m.value[e.name]=u,options:D.value[e.name]||[],optionLabel:"label",optionValue:"value",showClear:!e.isRequired,placeholder:"Select...",filter:"",onFilter:u=>Ce(e,u),invalid:!!z.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","options","showClear","onFilter","invalid"]),C(o,{icon:"pi pi-arrow-up-right",severity:"secondary",text:"",size:"small",disabled:m.value[e.name]==null,onClick:u=>Ie(e),"aria-label":"Open record"},null,8,["disabled","onClick"]),C(o,{icon:"pi pi-plus",severity:"secondary",text:"",size:"small",onClick:u=>Be(e),"aria-label":"Create new"},null,8,["onClick"])])):x(S)(e)==="boolean"?(c(),y(w,{key:2,id:e.name,modelValue:m.value[e.name],"onUpdate:modelValue":u=>m.value[e.name]=u,disabled:e.isReadonly},null,8,["id","modelValue","onUpdate:modelValue","disabled"])):x(S)(e)==="number"?(c(),y(j,{key:3,id:e.name,modelValue:m.value[e.name],"onUpdate:modelValue":u=>m.value[e.name]=u,disabled:e.isReadonly,useGrouping:!1,invalid:!!z.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","disabled","invalid"])):x(S)(e)==="datetime"?(c(),y(g,{key:4,id:e.name,modelValue:m.value[e.name],"onUpdate:modelValue":u=>m.value[e.name]=u,disabled:e.isReadonly,showTime:"",hourFormat:"24",dateFormat:"yy-mm-dd",invalid:!!z.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","disabled","invalid"])):x(S)(e)==="date"?(c(),y(g,{key:5,id:e.name,modelValue:m.value[e.name],"onUpdate:modelValue":u=>m.value[e.name]=u,disabled:e.isReadonly,dateFormat:"yy-mm-dd",invalid:!!z.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","disabled","invalid"])):x(S)(e)==="textarea"?(c(),y(b,{key:6,id:e.name,modelValue:m.value[e.name],"onUpdate:modelValue":u=>m.value[e.name]=u,disabled:e.isReadonly,invalid:!!z.value[e.name],rows:"5",autoResize:"",fluid:""},null,8,["id","modelValue","onUpdate:modelValue","disabled","invalid"])):(c(),y(G,{key:7,id:e.name,modelValue:m.value[e.name],"onUpdate:modelValue":u=>m.value[e.name]=u,disabled:e.isReadonly,maxlength:e.maxLength,invalid:!!z.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","disabled","maxlength","invalid"])),z.value[e.name]?(c(),y(pe,{key:8,severity:"error",size:"small",variant:"simple"},{default:X(()=>[Q(A(z.value[e.name]),1)]),_:2},1024)):U("",!0)]))),128))],32))]),O("div",Hn,[O("div",Yn,[C(o,{label:$.value?"Create":"Save",icon:"pi pi-check",loading:E.value,disabled:!ae.value,onClick:a[1]||(a[1]=e=>te(!1))},null,8,["label","loading","disabled"]),C(o,{label:$.value?"Create & continue":"Save & continue",icon:"pi pi-save",severity:"secondary",loading:E.value,disabled:!ae.value,onClick:a[2]||(a[2]=e=>te(!0))},null,8,["label","loading","disabled"]),$.value?U("",!0):(c(),y(o,{key:0,label:"Delete",icon:"pi pi-trash",severity:"danger",outlined:"",loading:ee.value,onClick:Fe},null,8,["loading"]))])]),C(Ne,{visible:L.value,"onUpdate:visible":a[4]||(a[4]=e=>L.value=e),header:"Create "+(J.value?.title||""),modal:"",style:{width:"32rem"}},{default:X(()=>[O("form",{onSubmit:ve(Le,["prevent"]),class:"flex flex-col gap-4"},[(c(!0),k(fe,null,ye(Pe.value,e=>(c(),k("div",{key:e.name,class:"flex flex-col gap-1"},[O("label",{for:"dlg-"+e.name,class:"font-semibold"},[Q(A(e.label)+" ",1),e.isRequired?(c(),k("span",Xn,"*")):U("",!0)],8,Qn),x(S)(e)==="select"?(c(),y(d,{key:0,id:"dlg-"+e.name,modelValue:h.value[e.name],"onUpdate:modelValue":u=>h.value[e.name]=u,options:se.value[e.name]||[],optionLabel:"label",optionValue:"value",showClear:!e.isRequired,placeholder:"Select...",filter:"",onFilter:u=>Ae(e,u),invalid:!!P.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","options","showClear","onFilter","invalid"])):x(S)(e)==="boolean"?(c(),y(w,{key:1,id:"dlg-"+e.name,modelValue:h.value[e.name],"onUpdate:modelValue":u=>h.value[e.name]=u},null,8,["id","modelValue","onUpdate:modelValue"])):x(S)(e)==="number"?(c(),y(j,{key:2,id:"dlg-"+e.name,modelValue:h.value[e.name],"onUpdate:modelValue":u=>h.value[e.name]=u,useGrouping:!1,invalid:!!P.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","invalid"])):x(S)(e)==="datetime"?(c(),y(g,{key:3,id:"dlg-"+e.name,modelValue:h.value[e.name],"onUpdate:modelValue":u=>h.value[e.name]=u,showTime:"",hourFormat:"24",dateFormat:"yy-mm-dd",invalid:!!P.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","invalid"])):x(S)(e)==="date"?(c(),y(g,{key:4,id:"dlg-"+e.name,modelValue:h.value[e.name],"onUpdate:modelValue":u=>h.value[e.name]=u,dateFormat:"yy-mm-dd",invalid:!!P.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","invalid"])):x(S)(e)==="textarea"?(c(),y(b,{key:5,id:"dlg-"+e.name,modelValue:h.value[e.name],"onUpdate:modelValue":u=>h.value[e.name]=u,invalid:!!P.value[e.name],rows:"5",autoResize:"",fluid:""},null,8,["id","modelValue","onUpdate:modelValue","invalid"])):(c(),y(G,{key:6,id:"dlg-"+e.name,modelValue:h.value[e.name],"onUpdate:modelValue":u=>h.value[e.name]=u,maxlength:e.maxLength,invalid:!!P.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","maxlength","invalid"])),P.value[e.name]?(c(),y(pe,{key:7,severity:"error",size:"small",variant:"simple"},{default:X(()=>[Q(A(P.value[e.name]),1)]),_:2},1024)):U("",!0)]))),128)),O("div",Zn,[C(o,{label:"Cancel",severity:"secondary",text:"",onClick:a[3]||(a[3]=e=>L.value=!1)}),C(o,{type:"submit",label:"Create",icon:"pi pi-check",loading:W.value},null,8,["loading"])])],32)]),_:1},8,["visible","header"]),C(qe)])}}};export{as as default};
