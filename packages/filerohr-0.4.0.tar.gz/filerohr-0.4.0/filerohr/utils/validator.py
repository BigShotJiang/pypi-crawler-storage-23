def cast_bool(value: str | None | bool | int) -> bool:
    if value is None:
        return False
    if isinstance(value, bool):
        return value
    return str(value).lower() in ("true", "t", "1", "on", "enabled", "yes", "y")
