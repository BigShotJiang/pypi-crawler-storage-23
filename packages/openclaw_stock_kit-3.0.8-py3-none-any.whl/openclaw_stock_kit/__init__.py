"""StockClaw Kit — Korean stock market data & trading toolkit.

Usage:
    pip install openclaw-stock-kit             # install
    openclaw-stock-kit                         # start settings server
    openclaw-stock-kit call list               # list available tools
    openclaw-stock-kit call gateway_status     # direct CLI call
"""

__version__ = "3.0.8"
