# 네이버 뉴스 검색 (news-naver)

네이버 뉴스 API를 통해 키워드 검색 및 종목별 뉴스를 수집한다.

## 기본 호출 형식

```bash
openclaw-stock-kit call <tool_name> '<JSON>' 2>/dev/null
```

환경 및 API 키 상태 확인:

```bash
openclaw-stock-kit call news_get_env_info '{}' 2>/dev/null
```

---

## 도구 1: news_search — 키워드 뉴스 검색

네이버 뉴스 API로 특정 키워드의 뉴스를 검색한다.

### 파라미터

| 파라미터 | 타입 | 필수 | 기본값 | 설명 |
|----------|------|------|--------|------|
| `query` | string | 필수 | — | 검색어 (예: "삼성전자", "반도체 수출") |
| `display` | integer | 선택 | 10 | 결과 수 (1~100) |
| `sort` | string | 선택 | "date" | `"date"` = 최신순, `"sim"` = 정확도순 |

### 반환 필드

| 필드 | 설명 |
|------|------|
| `title` | 기사 제목 (HTML 태그 제거됨) |
| `description` | 기사 요약 (HTML 태그 제거됨) |
| `link` | 기사 URL |
| `pubDate` | 발행일시 (RFC 2822 형식) |

### CLI 예시

```bash
# 최신 뉴스 5건
openclaw-stock-kit call news_search '{"query":"반도체 수출","display":5,"sort":"date"}' 2>/dev/null

# 정확도순 테마 뉴스
openclaw-stock-kit call news_search '{"query":"2차전지 양극재","display":10,"sort":"sim"}' 2>/dev/null

# 거시경제 뉴스 (기본값 사용)
openclaw-stock-kit call news_search '{"query":"금리 인하 환율"}' 2>/dev/null
```

---

## 도구 2: news_search_stock — 종목별 뉴스 검색

종목명 기반으로 뉴스를 검색한다. 종목명과 연관 키워드를 조합해 복수 검색을 수행하고,
날짜 필터 적용, 중복 URL 제거, HTML 태그 제거를 자동 처리하여 결과를 반환한다.

### 파라미터

| 파라미터 | 타입 | 필수 | 기본값 | 설명 |
|----------|------|------|--------|------|
| `stock_name` | string | 필수 | — | 종목명 (예: "삼성전자", "SK하이닉스") |
| `days` | integer | 선택 | 7 | 최근 N일 이내 기사만 수집 |

### 반환 필드

`news_search`와 동일: title, description, link, pubDate

### CLI 예시

```bash
# 최근 3일 삼성전자 뉴스
openclaw-stock-kit call news_search_stock '{"stock_name":"삼성전자","days":3}' 2>/dev/null

# 최근 2주 카카오 뉴스
openclaw-stock-kit call news_search_stock '{"stock_name":"카카오","days":14}' 2>/dev/null

# 기본값(7일) 사용
openclaw-stock-kit call news_search_stock '{"stock_name":"POSCO홀딩스"}' 2>/dev/null
```

---

## 인증 설정

네이버 개발자 센터(https://developers.naver.com/)에서 애플리케이션을 등록한 후,
사용 API로 **검색 > 뉴스**를 선택한다.

| 환경변수 | 설명 |
|----------|------|
| `NAVER_CLIENT_ID` | 네이버 앱 클라이언트 ID |
| `NAVER_CLIENT_SECRET` | 네이버 앱 클라이언트 시크릿 |

### 멀티키 로테이션 (선택)

API 호출 한도 초과 방지를 위해 최대 10개 키를 순환 사용할 수 있다.

```
NAVER_NEWS_API_KEY_1_ID / NAVER_NEWS_API_KEY_1_SECRET
NAVER_NEWS_API_KEY_2_ID / NAVER_NEWS_API_KEY_2_SECRET
...
NAVER_NEWS_API_KEY_10_ID / NAVER_NEWS_API_KEY_10_SECRET
```

키가 여러 개 설정된 경우 쿼터 소진 시 다음 키로 자동 전환된다.
