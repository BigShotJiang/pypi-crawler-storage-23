# 텔레그램 채널 뉴스 수집 (news-telegram)

텔레그램 채널/그룹에서 실시간 뉴스 및 정보를 수집한다.
Telethon 라이브러리 기반 인증 세션과 공개 채널 웹 스크래핑 두 가지 방식을 지원한다.

## 기본 호출 형식

```bash
openclaw-stock-kit call <tool_name> '<JSON>' 2>/dev/null
```

환경 및 API 키 상태 확인:

```bash
openclaw-stock-kit call news_get_env_info '{}' 2>/dev/null
```

---

## 도구 1: telegram_auth — 텔레그램 인증 관리

Telethon 세션 인증을 단계별로 처리한다. 최초 1회 인증 후 세션이 저장되므로 이후 재인증 불필요.

### 파라미터

| action 값 | 설명 | 추가 파라미터 |
|-----------|------|--------------|
| `"status"` | 현재 인증 상태 확인 | 없음 |
| `"send_code"` | SMS 인증 코드 발송 | 없음 |
| `"verify"` | SMS 코드로 인증 | `"code": "12345"` |

### CLI 예시

```bash
# 인증 상태 확인
openclaw-stock-kit call telegram_auth '{"action":"status"}' 2>/dev/null

# SMS 코드 발송
openclaw-stock-kit call telegram_auth '{"action":"send_code"}' 2>/dev/null

# 코드 입력하여 인증 완료
openclaw-stock-kit call telegram_auth '{"action":"verify","code":"12345"}' 2>/dev/null
```

---

## 도구 2: telegram_get_channels — 구독 채널/그룹 목록 조회

현재 인증된 계정이 구독 중인 채널과 그룹 목록을 반환한다.

### 파라미터

없음 (빈 JSON 객체 전달)

### 반환 필드

| 필드 | 설명 |
|------|------|
| `channel_id` | 채널 고유 ID (숫자) |
| `title` | 채널 또는 그룹 이름 |
| `username` | 채널 username (공개 채널만 존재) |
| `type` | 구분: `"channel"` 또는 `"group"` |
| `members_count` | 구성원 수 |

### CLI 예시

```bash
openclaw-stock-kit call telegram_get_channels '{}' 2>/dev/null
```

---

## 도구 3: telegram_get_messages — 채널 메시지 조회

지정한 채널에서 최근 메시지를 수집한다. 4단계 광고 필터링이 자동 적용된다.
공개 채널은 Telethon 없이도 웹 스크래핑으로 수집할 수 있다.

### 파라미터

| 파라미터 | 타입 | 필수 | 기본값 | 설명 |
|----------|------|------|--------|------|
| `channel` | string | 조건부 | — | 채널 username (@ 없이, 예: `"stocknews"`) |
| `channel_id` | integer | 조건부 | — | 채널 고유 ID (channel과 둘 중 하나 필수) |
| `limit` | integer | 선택 | 20 | 가져올 메시지 수 |

### CLI 예시

```bash
# username으로 메시지 수집
openclaw-stock-kit call telegram_get_messages '{"channel":"stocknews","limit":20}' 2>/dev/null

# channel_id로 수집
openclaw-stock-kit call telegram_get_messages '{"channel_id":1234567890,"limit":30}' 2>/dev/null

# 더 많은 메시지 수집
openclaw-stock-kit call telegram_get_messages '{"channel":"stocknews","limit":50}' 2>/dev/null
```

### 광고 필터링 4단계 (자동 적용)

1. **Top Priority**: 명백한 광고 패턴 우선 차단 (URL 포함 홍보성 문구 등)
2. **화이트리스트**: 뉴스성 콘텐츠로 판단되는 경우 필터 예외 처리
3. **확정 광고**: 광고 확정 키워드 포함 시 제거
4. **의심 키워드**: 의심 키워드 2개 이상 포함 시 광고로 분류

---

## 인증 설정

https://my.telegram.org/ 에서 API 발급 후 환경변수를 설정한다.

| 환경변수 | 설명 |
|----------|------|
| `TELEGRAM_API_ID` | 텔레그램 앱 API ID |
| `TELEGRAM_API_HASH` | 텔레그램 앱 API Hash |
| `TELEGRAM_PHONE` | 인증 전화번호 (국가코드 포함, 예: +821012345678) |

공개 채널 웹 스크래핑은 인증 없이도 사용 가능하다.

## 사용 순서 (최초 인증)

```bash
# 1. 현재 상태 확인
openclaw-stock-kit call telegram_auth '{"action":"status"}' 2>/dev/null

# 2. 미인증 상태이면 SMS 코드 발송
openclaw-stock-kit call telegram_auth '{"action":"send_code"}' 2>/dev/null

# 3. 받은 코드로 인증 완료
openclaw-stock-kit call telegram_auth '{"action":"verify","code":"12345"}' 2>/dev/null

# 4. 구독 채널 목록 확인
openclaw-stock-kit call telegram_get_channels '{}' 2>/dev/null

# 5. 채널 메시지 수집
openclaw-stock-kit call telegram_get_messages '{"channel":"stocknews","limit":30}' 2>/dev/null
```
