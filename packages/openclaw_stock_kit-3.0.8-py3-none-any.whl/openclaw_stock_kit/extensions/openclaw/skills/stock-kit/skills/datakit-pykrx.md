# DataKit — PyKRX 주식 데이터 (무료, API 키 불필요)

데이터 출처: KRX 한국거래소. API 키 없이 무료 사용 가능.
종목코드를 모를 때는 `search_stock`을 먼저 호출한다.

**기본 CLI 패턴:**
```bash
openclaw-stock-kit call datakit_call '{"function":"FUNC","params_json":"{...}"}' 2>/dev/null
```

> `params_json` 값은 **이스케이프된 JSON 문자열**로 전달한다 (예: `"{\"key\":\"value\"}"`)

---

## 공통 주의사항

- `ticker`는 6자리 숫자 코드 (예: `005930` = 삼성전자)
- 날짜 형식: `YYYYMMDD` (예: `20260101`)
- `days`와 `start`/`end`는 동시에 사용하지 않는다

---

## 1. search_stock — 종목 검색

종목명 또는 코드 키워드로 검색. 최대 20건 반환.

```bash
openclaw-stock-kit call datakit_call '{"function":"search_stock","params_json":"{\"keyword\":\"삼성전자\"}"}' 2>/dev/null
openclaw-stock-kit call datakit_call '{"function":"search_stock","params_json":"{\"keyword\":\"005930\"}"}' 2>/dev/null
```

반환값: `[{"ticker": "005930", "name": "삼성전자"}, ...]`

---

## 2. get_price — 일별 종가 + 변동률

날짜별 종가와 전일 대비 변동률 반환. `start`/`end` 생략 시 최근 거래일 종가 1건만 반환.

```bash
# 최근 종가 1건
openclaw-stock-kit call datakit_call '{"function":"get_price","params_json":"{\"ticker\":\"005930\"}"}' 2>/dev/null

# 기간 지정
openclaw-stock-kit call datakit_call '{"function":"get_price","params_json":"{\"ticker\":\"005930\",\"start\":\"20260101\",\"end\":\"20260219\"}"}' 2>/dev/null
```

---

## 3. get_ohlcv — 일봉 OHLCV

시가·고가·저가·종가·거래량 일봉 데이터. `days` 또는 `start`/`end` 중 택1.

```bash
# 최근 N일
openclaw-stock-kit call datakit_call '{"function":"get_ohlcv","params_json":"{\"ticker\":\"005930\",\"days\":\"10\"}"}' 2>/dev/null

# 기간 지정
openclaw-stock-kit call datakit_call '{"function":"get_ohlcv","params_json":"{\"ticker\":\"005930\",\"start\":\"20260101\",\"end\":\"20260219\"}"}' 2>/dev/null
```

---

## 4. get_supply — 투자자별 순매수

기관·외국인·개인의 순매수 수량 반환. 매수 주체 파악에 사용.

```bash
openclaw-stock-kit call datakit_call '{"function":"get_supply","params_json":"{\"ticker\":\"005930\",\"days\":\"10\"}"}' 2>/dev/null
```

반환값: 날짜별 기관순매수, 외국인순매수, 개인순매수 (단위: 주)

---

## 5. get_market_cap — 시가총액 + 밸류에이션

시가총액, PER, PBR, 배당수익률(DIV), 주당배당금(DPS) 반환.

```bash
openclaw-stock-kit call datakit_call '{"function":"get_market_cap","params_json":"{\"ticker\":\"005930\"}"}' 2>/dev/null

# 기간 지정
openclaw-stock-kit call datakit_call '{"function":"get_market_cap","params_json":"{\"ticker\":\"005930\",\"start\":\"20260101\",\"end\":\"20260219\"}"}' 2>/dev/null
```

---

## 6. get_index — 시장 지수 데이터

코스피/코스닥/코스피200/KRX100 지수 일봉 반환.

지원 값: `코스피` / `코스닥` / `코스피200` / `KRX100`

```bash
openclaw-stock-kit call datakit_call '{"function":"get_index","params_json":"{\"index_name\":\"코스피\",\"days\":\"10\"}"}' 2>/dev/null
openclaw-stock-kit call datakit_call '{"function":"get_index","params_json":"{\"index_name\":\"코스닥\",\"days\":\"5\"}"}' 2>/dev/null
```

---

## 헬퍼 명령어

```bash
# 사용 가능한 DataKit 함수 목록
openclaw-stock-kit call datakit_list_functions 2>/dev/null

# API 키 상태 및 환경 확인
openclaw-stock-kit call datakit_get_env_info 2>/dev/null
```
