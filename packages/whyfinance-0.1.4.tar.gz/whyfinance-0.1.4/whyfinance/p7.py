P7_CONTENT = '''
# 7 Aim : Perform Technical Analysis using RSI & MACD in Excel

Step 1: Relative Strength Index (RSI)
RSI is a momentum indicator that measures overbought and oversold conditions of a stock.
• RSI Range: 0 to 100
• RSI > 70 → Overbought
• RSI < 30 → Oversold
Procedure in Excel:
1. Enter Data
• Column A → Date
• Column B → Closing Price

2. Calculate Daily Change
1. Price Change (Daily Change)
=C12-C11
2. Gain (Only Positive Change)
 =IF(D11>0,D11,0)
3. Loss (Only Negative Change, Positive Form)
 =IF(D12<0,ABS(D12),0)

3. Separate Gain and Loss
 Average Gain =AVERAGE(E11:E14)
 Average Loss =AVERAGE(F11:F14)

4. Calculate Relative Strength (RS)
RS = Average Gain / Average Loss

6. Calculate RSI
RSI = 100-(100/(1+RS))

Step 2: Moving Average Convergence Divergence (MACD)
MACD identifies trend direction and momentum.
MACD = 12-day EMA – 26-day EMA
Signal Line = 9-day EMA of MACD

Procedure in Excel:
1. Calculate 12-day EMA
Smoothing factor:
 =2/(12+1)
EMA Formula:
 =(Current Price - Previous EMA)*α + Previous EMA

2. Calculate 26-day EMA
Smoothing factor:
=2/(26+1)

3. Calculate MACD Line
=12-day EMA - 26-day EMA

4. Calculate Signal Line (9-day EMA of MACD)
=2/(9+1)

5. Histogram & Action
Histogram Formula
=MACD - Signal Line

Example:
=E27-F27

Action Formula
=IF(E27>F27,"Buy Signal",
IF(E27<F27,"Sell Signal","No Signal"))

Interpretation Table
Histogram Value   Action
Positive          Buy Signal
Negative          Sell Signal
Zero / Near 0     No Signal
'''

def main():
    # print("")
    print(P7_CONTENT)

if __name__ == "__main__":
    main()
