P4_CODE = '''
# 4 Aim: Visualize Stock Market Data using Python

!pip install yfinance
import yfinance as yf
import pandas as pd
import matplotlib.pyplot as plt

ticker = 'AAPL'

data = yf.download(ticker, period='6mo', auto_adjust=True)

plt.figure(figsize=(8, 4))
plt.plot(data['Close'])
plt.title(f"{ticker} Stock Price Trend (Last 6 Months)")
plt.xlabel("Date")
plt.ylabel("Closing Price")
plt.grid(True)
plt.show()
'''

def main():
    # print("")
    print(P4_CODE)

if __name__ == "__main__":
    main()
