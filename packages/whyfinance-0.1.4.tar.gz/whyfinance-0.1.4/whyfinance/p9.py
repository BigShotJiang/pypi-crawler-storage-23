P9_CONTENT = '''
# 9 Aim : Analyze Credit Risk using Decision Trees in Python

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.preprocessing import LabelEncoder
from sklearn.datasets import fetch_openml

credit_data = fetch_openml(name='credit-g', version=1, as_frame=True)
df = credit_data.frame

le = LabelEncoder()
for column in df.select_dtypes(include=['object', 'category']).columns:
    df[column] = le.fit_transform(df[column])

X = df.drop("class", axis=1)
y = df["class"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)

model = DecisionTreeClassifier(
    criterion='gini',
    max_depth=5,
    random_state=42
)

model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("Model Evaluation Results\n")
print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nConfusion Matrix:\n")
print(confusion_matrix(y_test, y_pred))
print("\nClassification Report:\n")
print(classification_report(y_test, y_pred))

plt.figure(figsize=(20,10))
plot_tree(
    model,
    feature_names=X.columns,
    class_names=["High Risk", "Low Risk"],
    filled=True
)
plt.title("Decision Tree for Credit Risk Classification")
plt.show()
'''

def main():
    # print("")
    print(P9_CONTENT)

if __name__ == "__main__":
    main()
