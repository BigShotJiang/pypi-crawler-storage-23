P2_CODE = '''
# 2 Aim: Calculate NPV & IRR for a Capital Budgeting Decision in Excel

Step 1: Enter the Cash Flow Data

Year Cash Flow
0     -100000
1     30000
2     35000
3     40000
4     45000
5     50000

Year 0 = money invested (cash outflow)
Years 1–4 = money received (cash inflows)

Step 2: Enter Discount Rate
Discount Rate = 10%
Discount rate = required rate of return / cost of capital.

Step 3: Calculate Net Present Value
Net Present Value = ( Discount rate, Present value of all future cash inflows ) + Initial
investment
 = (0.1, 30000 + 35000 + 40000 + 45000 + 50000) + (-100000)
 = ₹ 48,032.61

Step 4: Interpret NPV
If NPV > 0 → ACCEPT project
If NPV < 0 → REJECT project
Here, NPV > 0
Project is acceptable.

Step 5: Calculate Internal Rate of Return
IRR = IRR(Initial investment + Cash inflows of All Years)
 = 26%

Step 6: Interpret IRR
Compare IRR with Discount Rate:
If IRR > Discount Rate → ACCEPT
If IRR < Discount Rate → REJECT
Here, 26% > 10%
Project is acceptable.

Step 7: Final Decision (optional formula)
The Net Present Value is positive and Internal Rate of Return is greater than the discount
rate. Therefore, the project is financially feasible and accepted.

Formulas:
NPV =NPV(0.1,B3:B8)+B2
IRR =IRR(B2:B7)
'''

def main():
    # print("")
    print(P2_CODE)

if __name__ == "__main__":
    main()
