P8_CONTENT = '''
# 8 Aim : Predict Future Stock Prices using Machine Learning in Python.

import yfinance as yf
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

stock = yf.download("AAPL", start="2020-01-01", end="2024-01-01", auto_adjust=True)

data = stock[['Close']].copy()

for i in range(1, 6):
    data[f'Lag_{i}'] = data['Close'].shift(i)

data.dropna(inplace=True)

X = data.drop('Close', axis=1)
y = data['Close']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, shuffle=False
)

model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, y_pred)

print("Model Evaluation:")
print("Mean Squared Error:", mse)
print("Root Mean Squared Error:", rmse)
print("R2 Score:", r2)

plt.figure(figsize=(10,5))
plt.plot(y_test.values, label="Actual Price")
plt.plot(y_pred, label="Predicted Price")
plt.title("Actual vs Predicted Stock Prices (Linear Regression)")
plt.xlabel("Days")
plt.ylabel("Stock Price")
plt.legend()
plt.show()

last_5_days = data.tail(5)['Close'].values
input_data = np.array(last_5_days[::-1]).reshape(1, -1)
future_price = model.predict(input_data)

print("Predicted Next Day Price:", future_price[0])
'''

def main():
    # print("")
    print(P8_CONTENT)

if __name__ == "__main__":
    main()