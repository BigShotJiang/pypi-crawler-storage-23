P5_CONTENT = '''
# 5 Aim: Compute Moving Averages for Stock Prices using Excel

Step 1: Enter the Stock Price Data
Create the following columns in Excel:
Column A: Date
Column B: Closing Price
Enter the stock prices date-wise.

Step 2: Calculate Simple Moving Average (SMA – 5 Days)
5 Days SMA = Sum of last 5 Days Closing price / 5

Step 3: Select Data for Graph
Select the Date column (A).
Hold Ctrl and select the SMA column (C).
Do not select empty cells at the top.

Step 4: Insert SMA Line Graph
Go to the Insert tab.
Click on Line Chart.
Choose 2-D Line Chart.

Formula
5 Day SMA =AVERAGE(B2:B6)
Exponential Moving Average (EMA)

Step 1: Enter the Stock Price Data
Column A: Date
Column B: Closing Price
This is the original stock price data used for EMA calculation.

Step 2: Decide the EMA Period
EMA period taken = 5 Days
EMA gives more weight to recent prices, so it reacts faster than SMA.

Step 3: Calculate the Smoothing Factor (α)
The smoothing factor determines how much weight is given to the latest price.
Formula:
 α = 2 / 5 + 1
 = 0.3333

Step 4: Calculate the First EMA Value
The first EMA value is taken as the first SMA value.
First 5-Day SMA = 102.2
This value is placed as the first EMA.

Step 5: Apply the EMA Formula
EMA = (Today's Price - Yesterday's EMA)*α + Yesterday's EMA
Formula
EMA =(B6-D5)*$E$3+D5
'''

def main():
    # print("")
    print(P5_CONTENT)

if __name__ == "__main__":
    main()
