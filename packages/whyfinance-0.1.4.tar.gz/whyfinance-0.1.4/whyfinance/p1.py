P1_CODE = '''
# 1 Aim: Perform Cash Flow Analysis using Excel.

Step 1: List all cash transactions

Cash coming in (Inflows):
Sales Revenue – ₹1,20,000
Loan Received – ₹50,000

Cash going out (Outflows):
Rent Paid – ₹20,000
Salaries – ₹30,000
Purchase of Raw Materials – ₹25,000
Electricity Bill – ₹5,000
Miscellaneous Expenses – ₹3,000

Step 2: Separate inflows and outflows
Cash Inflows → money received
Cash Outflows → money paid

Step 3: Calculate Total Cash Inflows
Sales Revenue = 1,20,000
Loan Received = 50,000
Total Inflows = 1,20,000 + 50,000 = ₹1,70,000

Step 4: Calculate Total Cash Outflows
Total Outflows = 20,000 + 30,000 + 25,000 + 5,000 + 3,000
               = ₹83,000
Step 5: Find Net Cash Flow
Net Cash Flow = Total Inflows – Total Outflows
 = 1,70,000 – 83,000
 = ₹87,000

Step 6: Analyze the result
If Net Cash Flow is positive → Business has profit
If Net Cash Flow is negative → Business is running in loss

Here:
₹87,000 is positive
So, The business is running in profit.

Formula:
Cash inflow =SUM(B2:B3)
Cash Outflow =SUM(C4:C8)
Net Cash Flow =B9-C9
'''

def main():
    # print("")
    print(P1_CODE)

if __name__ == "__main__":
    main()