P10_CONTENT = '''
# 10 Aim : Implement Black-Scholes Option Pricing Model in Excel/Python.

import numpy as np
from scipy.stats import norm

def black_scholes_call(S, K, r, T, sigma):
    d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)
    call_price = S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
    return call_price

S = float(input("Enter Current Stock Price (S): "))
K = float(input("Enter Strike Price (K): "))
r = float(input("Enter Risk-Free Rate (r) (in %): ")) / 100
T = float(input("Enter Time to Expiration (T in years): "))
sigma = float(input("Enter Volatility (sigma) (in %): ")) / 100

call_option_price = black_scholes_call(S, K, r, T, sigma)
print("European Call Option Price:", round(call_option_price, 4))
'''

def main():
    # print("")
    print(P10_CONTENT)

if __name__ == "__main__":
    main()
