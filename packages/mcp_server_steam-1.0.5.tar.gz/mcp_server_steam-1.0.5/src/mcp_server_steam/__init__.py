"""mcp-server-steam - MCP Server for Steam Web API."""

__version__ = "1.0.5"

from mcp_server_steam.server import main

__all__ = ["main", "__version__"]
