"""Tool: signals — View buying signals, signal reports, and strategy insights.

Thin dispatcher that routes to existing run_* functions based on the action parameter.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


async def run_signals(
    action: str = "show",
    campaign_id: str = "",
    signal_type: str = "",
    status: str = "",
    limit: int = 20,
    days: int = 30,
) -> str:
    """View and analyze buying signals from LinkedIn.

    Actions:
      show     — Display detected buying signals (keyword mentions, job changes, etc.)
      report   — Signal analytics report with trends and ROI
      strategy — Show strategy engine insights, patterns, and autonomous actions

    Args:
        action: What to do: 'show', 'report', 'strategy'.
        campaign_id: Filter by campaign. Shows all if empty.
        signal_type: Filter by signal type, e.g. 'keyword_mention', 'job_change' (for 'show').
        status: Filter by status: 'new', 'classified', 'actioned' (for 'show').
        limit: Max signals to show (for 'show'). Default 20.
        days: Lookback window in days (for 'report'). Default 30.
    """
    action = action.lower().strip()

    if action == "show":
        from .show_signals import run_show_signals
        return await run_show_signals(
            signal_type=signal_type,
            campaign_id=campaign_id,
            status=status,
            limit=limit,
        )

    if action == "report":
        from .signal_report import run_signal_report
        return await run_signal_report(days=days, campaign_id=campaign_id)

    if action == "strategy":
        from .show_strategy import run_show_strategy
        return await run_show_strategy(campaign_id=campaign_id)

    return f"Unknown action: '{action}'. Use 'show', 'report', or 'strategy'."
