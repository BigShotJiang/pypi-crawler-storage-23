// mtp-common components required by all staff apps
import {CookieBanner} from './components/cookie-banner';

export function initStaffDefaults () {
  CookieBanner.init();
}
