# -*- coding: utf-8 -*-
# Quasarr
# Project by https://github.com/rix1337
