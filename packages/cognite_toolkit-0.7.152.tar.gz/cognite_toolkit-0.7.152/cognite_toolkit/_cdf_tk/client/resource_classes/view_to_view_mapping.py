from typing import Any

from pydantic import Field, field_serializer

from cognite_toolkit._cdf_tk.client._resource_base import BaseModelObject
from cognite_toolkit._cdf_tk.client.identifiers import ViewId


class ViewToViewMapping(BaseModelObject):
    external_id: str
    source_view: ViewId
    destination_view: ViewId
    map_identical_id_properties: bool = Field(
        default=False,
        description="Whether to automatically map properties with identical ID. Note this is a shorthand, "
        "you can achieve the same by including the properties in the property_mapping with identical "
        " and destination IDs.",
    )
    property_mapping: dict[str, str]

    @field_serializer("source_view", "destination_view", mode="plain")
    def serialize_view_id(self, view_id: ViewId) -> dict[str, Any]:
        return {**view_id.dump(), "type": "view"}

    def get_destination_property(self, source_property: str) -> str | None:
        dest_prop_id = self.property_mapping.get(source_property)
        if not dest_prop_id and self.map_identical_id_properties:
            return source_property
        return dest_prop_id
