"""Allow running easybib as `python -m easybib`."""

from easybib.cli import main

main()
