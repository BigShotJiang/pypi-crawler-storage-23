from __future__ import annotations

from worai.core import wordlift


class _FakeResponse:
    status_code = 200

    @staticmethod
    def json():
        return {"data": {"ok": True}}


def test_graphql_request_sets_private_header_when_enabled(monkeypatch) -> None:
    seen: dict[str, str] = {}

    def _stub_post(_endpoint, headers=None, data=None, timeout=60):
        seen.update(headers or {})
        return _FakeResponse()

    monkeypatch.setattr(wordlift.requests, "post", _stub_post)
    wordlift.graphql_request(
        "https://api.wordlift.io/graphql",
        "wl_123",
        "query { entities { iri } }",
        include_private=True,
    )

    assert seen["X-include-Private"] == "true"


def test_graphql_request_skips_private_header_by_default(monkeypatch) -> None:
    seen: dict[str, str] = {}

    def _stub_post(_endpoint, headers=None, data=None, timeout=60):
        seen.update(headers or {})
        return _FakeResponse()

    monkeypatch.setattr(wordlift.requests, "post", _stub_post)
    wordlift.graphql_request(
        "https://api.wordlift.io/graphql",
        "wl_123",
        "query { entities { iri } }",
    )

    assert "X-include-Private" not in seen
