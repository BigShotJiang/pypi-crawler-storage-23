from __future__ import annotations

import re

from typer.testing import CliRunner

from worai.cli import app as root_app


def test_structured_data_subcommands_include_help_descriptions() -> None:
    runner = CliRunner()
    result = runner.invoke(root_app, ["structured-data", "--help"])

    assert result.exit_code == 0
    assert "create" in result.output
    assert "Create YARRRML and JSON-LD for a webpage." in result.output
    assert "generate" in result.output
    assert "Generate RDF from YARRRML over URL inputs." in result.output
    assert "inventory" in result.output
    assert "Create a structured-data inventory from discovered URLs." in result.output


def test_structured_data_validate_page_includes_help_description() -> None:
    runner = CliRunner()
    result = runner.invoke(root_app, ["structured-data", "validate", "--help"])

    assert result.exit_code == 0
    assert "page" in result.output
    assert "Validate JSON-LD extracted from a webpage." in result.output


def test_graph_sync_subcommands_include_help_descriptions() -> None:
    runner = CliRunner()
    result = runner.invoke(root_app, ["graph", "--help"])

    assert result.exit_code == 0
    assert "sync" in result.output
    assert "Run graph sync workflows." in result.output
    assert "property" in result.output
    assert "Bulk predicate operations on the graph." in result.output


def test_graph_property_subcommands_include_help_descriptions() -> None:
    runner = CliRunner()
    result = runner.invoke(root_app, ["graph", "property", "--help"])

    assert result.exit_code == 0
    assert "delete" in result.output
    assert "Delete one predicate from all matching entities in the graph." in result.output


def test_validate_jsonld_subcommand_includes_help_description() -> None:
    runner = CliRunner()
    result = runner.invoke(root_app, ["validate", "--help"])

    assert result.exit_code == 0
    assert "jsonld" in result.output
    assert "Validate JSON-LD from a file path or URL." in result.output


def test_root_commands_include_consistent_descriptions() -> None:
    runner = CliRunner()
    result = runner.invoke(root_app, ["--help"])
    output = re.sub(r"\s+", " ", result.output)

    assert result.exit_code == 0
    assert "Run SEO checks for sitemap URLs" in output
    assert "Generate an SEO performance report." in output
    assert "Export Google Search Console data as CSV." in output
    assert "Select canonical targets for duplicate pages." in output
    assert "Find and patch FAQPage typing issues." in output
    assert "Build or apply internal link groups." in output
    assert "Patch entities from RDF (Turtle or JSON-LD)." in output
    assert "Manage worai CLI updates." in output
    assert "List entities outside the account dataset." in output
    assert "Validate JSON-LD with SHACL shapes." in output
