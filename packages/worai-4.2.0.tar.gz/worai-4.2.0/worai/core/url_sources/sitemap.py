from __future__ import annotations

import requests

from worai.core.sitemap import parse_sitemap_urls


def load_urls_from_sitemap(source: str, *, timeout: float) -> list[str]:
    with requests.Session() as session:
        return parse_sitemap_urls(
            source,
            session=session,
            timeout=timeout,
            fetch_mode="requests",
        )
