from unique_toolkit._common.exception import CommonException


class EvaluatorException(CommonException):
    pass
