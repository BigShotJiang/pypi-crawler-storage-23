$Env:PYSPARK_DRIVER_PYTHON="python"
$Env:PYSPARK_PYTHON="python"
spark-submit --master local[2] --conf spark.driver.extraJavaOptions=-Dlog4j.configuration=file:log4j.properties "main.py"