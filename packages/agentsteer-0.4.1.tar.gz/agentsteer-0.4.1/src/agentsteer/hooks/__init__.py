"""Framework hooks for agentsteer.

pretooluse: Unified PreToolUse hook for Claude Code and OpenHands v1 SDK.
  Command: python3 -m agentsteer.hooks.pretooluse

openclaw: OpenClaw tool-based hook (Python dict interface).
"""
