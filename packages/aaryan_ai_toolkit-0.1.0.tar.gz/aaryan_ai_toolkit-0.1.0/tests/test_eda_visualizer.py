"""Tests for ai_toolkit.eda.visualizer — minimal smoke tests (no display, optional save)."""

import numpy as np
import pandas as pd
import pytest

from ai_toolkit.eda import (
    initial_inspection,
    plot_bar,
    plot_class_distribution,
    plot_confusion_matrix,
    plot_heatmap,
    plot_histogram,
    plot_line,
    plot_model_comparison,
    plot_ngram_frequency,
    plot_roc_curves,
    plot_scatter,
    plot_text_length_distribution,
    plot_wordcloud,
)


@pytest.fixture
def sample_df():
    n = 50
    return pd.DataFrame({
        "text": ["hello world foo bar " * 2 for _ in range(n)],
        "label": np.random.choice(["A", "B", "C"], size=n),
        "x": np.random.randn(n).cumsum(),
        "y": np.random.randn(n) * 2,
    })


def test_initial_inspection_returns_dict(sample_df):
    out = initial_inspection(sample_df, sample_n=2, return_dict=True)
    assert out is not None
    assert out["shape"] == sample_df.shape
    assert "sample" in out


def test_initial_inspection_prints(sample_df, capsys):
    initial_inspection(sample_df, sample_n=1, return_dict=False)
    captured = capsys.readouterr()
    assert "Shape:" in captured.out


def test_plot_bar_dict():
    fig, ax = plot_bar({"X": 10, "Y": 20, "Z": 15}, show=False)
    assert fig is not None
    assert ax is not None


def test_plot_bar_dataframe(sample_df):
    fig, ax = plot_bar(sample_df, x_col="label", show=False)
    assert fig is not None
    assert ax is not None


def test_plot_histogram(sample_df):
    fig, ax = plot_histogram(sample_df, column="x", n_bins=10, show=False)
    assert fig is not None
    assert ax is not None


def test_plot_heatmap():
    fig, ax = plot_heatmap(np.eye(3), show=False)
    assert fig is not None
    assert ax is not None


def test_plot_line(sample_df):
    df = sample_df.head(10)[["x", "y"]].reset_index(drop=True)
    df = df.rename(columns={"x": "t", "y": "v"})
    fig, ax = plot_line(df, x_col="t", y_col="v", show=False)
    assert fig is not None
    assert ax is not None


def test_plot_scatter(sample_df):
    fig, ax = plot_scatter(sample_df, x_col="x", y_col="y", show=False)
    assert fig is not None
    assert ax is not None


def test_plot_class_distribution(sample_df):
    fig, ax = plot_class_distribution(sample_df, target_col="label", show=False)
    assert fig is not None
    assert ax is not None


def test_plot_text_length_distribution(sample_df):
    fig, ax = plot_text_length_distribution(
        sample_df, text_col="text", kind="word", n_bins=10, show=False
    )
    assert fig is not None
    assert ax is not None


def test_plot_ngram_frequency():
    texts = ["a b c", "a b", "b c a"]
    result = plot_ngram_frequency(texts, n=1, top_k=5, show=False)
    assert result is not None
    fig, ax = result
    assert fig is not None
    assert ax is not None


def test_plot_wordcloud():
    texts = ["good product", "great quality", "good value"] * 10
    fig, ax = plot_wordcloud(texts, label="Positive", max_words=20, show=False)
    assert fig is not None
    assert ax is not None


def test_plot_confusion_matrix():
    y_true = [0, 1, 1, 0]
    y_pred = [0, 1, 0, 0]
    fig, ax = plot_confusion_matrix(y_true, y_pred, show=False)
    assert fig is not None
    assert ax is not None


def test_plot_roc_curves():
    y_true = [0, 1, 1, 0, 1]
    scores = {"M1": [0.1, 0.9, 0.4, 0.2, 0.8]}
    fig, ax = plot_roc_curves(y_true, scores, show=False)
    assert fig is not None
    assert ax is not None


def test_plot_model_comparison():
    results = {"A": {"acc": 0.8, "f1": 0.79}, "B": {"acc": 0.85, "f1": 0.84}}
    result = plot_model_comparison(results, show=False)
    assert result is not None
    fig, ax = result
    assert fig is not None
    assert ax is not None
