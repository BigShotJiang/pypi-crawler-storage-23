# ai_toolkit

Reusable NLP, EDA, ML, and DL utilities for text and tabular workflows.

## Install

```bash
# Core (light)
pip install ai_toolkit

# With EDA/viz extras (wordcloud, plotly)
pip install ai_toolkit[viz]

# Full (torch, transformers, sentence-transformers, etc.)
pip install ai_toolkit[full]

# Run all tests (no skips): install test + dev extras
pip install -e ".[test,dev]"
pytest tests/ -v
```

## Subpackages

- **eda** — Exploratory data analysis and visualization ([README](ai_toolkit/eda/README.md))
- **nlp** — Text preprocessing and embeddings ([README](ai_toolkit/nlp/README.md))
- **ml** — Training and evaluation ([README](ai_toolkit/ml/README.md))
- **dl** — LSTM, attention, BERT utilities ([README](ai_toolkit/dl/README.md))
- **utils** — Configuration and shared helpers

Every public function is documented in the subpackage README with arguments and examples.
