"""Configuration and shared utilities."""
