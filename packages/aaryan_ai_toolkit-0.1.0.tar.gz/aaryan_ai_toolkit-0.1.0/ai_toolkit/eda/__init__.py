"""EDA module — exploratory data analysis and visualization."""

from ai_toolkit.eda.visualizer import (
    initial_inspection,
    plot_bar,
    plot_class_distribution,
    plot_confusion_matrix,
    plot_heatmap,
    plot_histogram,
    plot_line,
    plot_model_comparison,
    plot_ngram_frequency,
    plot_roc_curves,
    plot_scatter,
    plot_text_length_distribution,
    plot_wordcloud,
)

__all__ = [
    "initial_inspection",
    "plot_bar",
    "plot_class_distribution",
    "plot_confusion_matrix",
    "plot_heatmap",
    "plot_histogram",
    "plot_line",
    "plot_model_comparison",
    "plot_ngram_frequency",
    "plot_roc_curves",
    "plot_scatter",
    "plot_text_length_distribution",
    "plot_wordcloud",
]
