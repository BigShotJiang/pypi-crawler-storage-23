"""ML module — training and evaluation utilities."""

from ai_toolkit.ml.evaluator import error_analysis, full_classification_report
from ai_toolkit.ml.trainer import (
    build_classification_pipeline,
    build_results_table,
    encode_labels,
    scale_features,
    train_and_evaluate,
)

__all__ = [
    "build_classification_pipeline",
    "build_results_table",
    "encode_labels",
    "error_analysis",
    "full_classification_report",
    "scale_features",
    "train_and_evaluate",
]
