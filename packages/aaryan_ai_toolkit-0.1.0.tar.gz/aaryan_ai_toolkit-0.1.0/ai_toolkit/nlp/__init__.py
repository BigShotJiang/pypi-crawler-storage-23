"""NLP module — text preprocessing and embeddings."""

from ai_toolkit.nlp.embeddings import (
    build_bow,
    build_tfidf,
    extract_text_stats,
    get_sbert_embeddings,
)
from ai_toolkit.nlp.preprocessor import (
    clean_pipeline,
    create_sentiment_label,
    expand_contractions,
    handle_nulls,
    normalize_text,
    remove_html,
    remove_noise,
)

__all__ = [
    "build_bow",
    "build_tfidf",
    "clean_pipeline",
    "create_sentiment_label",
    "expand_contractions",
    "extract_text_stats",
    "get_sbert_embeddings",
    "handle_nulls",
    "normalize_text",
    "remove_html",
    "remove_noise",
]
