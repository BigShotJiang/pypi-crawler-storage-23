"""ai_toolkit: Reusable NLP, EDA, ML, and DL utilities for text and tabular workflows."""

__version__ = "0.1.0"
