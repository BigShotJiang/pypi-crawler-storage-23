# from typing_extensions import AsyncIterable, Sequence
# from dataclasses import dataclass, replace
# from decimal import Decimal
# from collections import defaultdict
# from datetime import datetime, timezone

# from web3 import Web3

# from trading_sdk.reporting import (
#   Transactions as TransactionsTDK, Transaction,
#   EthereumTransaction, ERC20Transfer,
# )

# from ethereum.sdk.core import EtherscanMixin
# from ethereum.etherscan import tx_value, tx_fee, token_value
# from ethereum.etherscan.transactions import Transaction as NativeTransaction
# from ethereum.etherscan.token_transactions import TokenTransaction

# def parse_native_transaction(tx: NativeTransaction, address: str, *, chain_id: int) -> Transaction:
#   assert Web3.is_checksum_address(address), f'{address} is not a checksum address'
#   value = tx_value(tx)
#   fee = tx_fee(tx)
#   time = datetime.fromtimestamp(int(tx['timeStamp']))
#   to_addr = Web3.to_checksum_address(tx['to'])
#   from_addr = Web3.to_checksum_address(tx['from'])
#   assert address in (to_addr, from_addr), f'{address} not in transaction {tx}'
#   s = 1 if to_addr == address else -1
#   postings: list[Posting] = []
#   if address == from_addr:
#     postings.append(Posting(
#       time=time,
#       asset='ETH',
#       change=-fee,
#       kind='currency',
#       type='fee',
#       details=tx
#     ))
#   if value > 0:
#     postings.append(Posting(
#       time=time,
#       asset='ETH',
#       change=s*value,
#       kind='currency',
#       type='ethereum_transfer',
#       details=tx
#     ))
#   transaction = Transaction(
#     operation=EthereumTransaction(
#       id=f"{chain_id};native;{tx['hash']}",
#       time=time,
#       tx_hash=tx['hash'],
#       from_address=from_addr,
#       to_address=to_addr,
#       value=value,
#       fee=fee,
#       chain_id=chain_id,
#       details=tx
#     ),
#     postings=postings
#   )
#   return transaction

# async def native_transactions(
#   self: EtherscanMixin, *, start: datetime, end: datetime
# ) -> AsyncIterable[Sequence[Transaction]]:
#   kwargs = {}
#   if start is not None:
#     kwargs['start_block'] = await self.client.block_by_time(start, self.chain_id, closest='after')
#   if end is not None:
#     end = min(end, datetime.now())
#     kwargs['end_block'] = await self.client.block_by_time(end, self.chain_id, closest='before')
#   async for chunk in self.client.transactions_paged(self.address, self.chain_id, **kwargs):
#     yield [parse_native_transaction(tx, self.address, chain_id=self.chain_id) for tx in chunk]


# def parse_token_transaction(tx: TokenTransaction, address: str, *, chain_id: int, idx: int) -> Transaction:
#   assert Web3.is_checksum_address(address), f'{address} is not a checksum address'
#   value = token_value(tx)
#   time = datetime.fromtimestamp(int(tx['timeStamp']))
#   to_addr = Web3.to_checksum_address(tx['to'])
#   from_addr = Web3.to_checksum_address(tx['from'])
#   assert address in (to_addr, from_addr), f'{address} not in transaction {tx}'
#   s = 1 if to_addr == address else -1
#   contract_addr = Web3.to_checksum_address(tx['contractAddress'])
#   return Transaction(
#     operation=ERC20Transfer(
#       id=f"{chain_id};erc20;{tx['hash']};{idx}",
#       time=time,
#       tx_hash=tx['hash'],
#       from_address=from_addr,
#       recipient_address=to_addr,
#       contract_address=contract_addr,
#       value=value,
#       chain_id=chain_id,
#       details=tx,
#     ),
#     postings=[Posting(
#       time=time,
#       asset=contract_addr,
#       change=s*value,
#       kind='currency',
#       type='erc20_transfer',
#       details=tx
#     )]
#   )

# async def token_transactions(
#   self: EtherscanMixin, *, start: datetime, end: datetime,
#   ignore_zero_value: bool = True
# ) -> AsyncIterable[Sequence[Transaction]]:
#   kwargs = {}
#   if start is not None:
#     kwargs['start_block'] = await self.client.block_by_time(start, self.chain_id, closest='after')
#   if end is not None:
#     end = min(end, datetime.now())
#     kwargs['end_block'] = await self.client.block_by_time(end, self.chain_id, closest='before')
#   transactions = await self.client.token_transactions_paged_sync(self.address, self.chain_id, **kwargs)
#   groups = defaultdict[str, list[TokenTransaction]](list)
#   for tx in transactions:
#     if not ignore_zero_value or Decimal(tx['value']) > 0:
#       groups[tx['hash']].append(tx)

#   for group in groups.values():
#     yield [
#       parse_token_transaction(tx, self.address, chain_id=self.chain_id, idx=i)
#       for i, tx in enumerate(group)
#     ]

# class AutoDetect:
#   ...

# AUTO_DETECT = AutoDetect()

# @dataclass
# class Transactions(EtherscanMixin, TransactionsTDK):
#   tz: timezone | AutoDetect = AUTO_DETECT
#   """Timezone of the API times (defaults to the local timezone)."""

#   @property
#   def timezone(self) -> timezone:
#     if isinstance(self.tz, AutoDetect):
#       return datetime.now().astimezone().tzinfo # type: ignore
#     else:
#       return self.tz

#   def add_tz(self, tx: Transaction) -> Transaction:
#     op = replace(tx.operation, time=tx.operation.time.replace(tzinfo=self.timezone))
#     return replace(tx, operation=op, postings=[replace(p, time=p.time.replace(tzinfo=self.timezone)) for p in tx.postings])

#   async def transactions(
#     self, start: datetime, end: datetime
#   ) -> AsyncIterable[Sequence[Transaction]]:
#     async for chunk in native_transactions(self, start=start, end=end):
#       yield [self.add_tz(tx) for tx in chunk]
#     async for chunk in token_transactions(self, start=start, end=end, ignore_zero_value=self.ignore_zero_value):
#       yield [self.add_tz(tx) for tx in chunk]