"""Event dict builder."""

import uuid
from datetime import datetime, timezone


def build_event(context_data, response_data, latency_ms, caller_info):
    """Build an event dict ready for transport.

    Parameters
    ----------
    context_data : dict or None
        Trace context info (trace_id, span_id, parent_span_id, tags).
    response_data : dict
        Provider-parsed response (provider, model, input_tokens, output_tokens, status).
    latency_ms : int
        Wall-clock latency of the LLM call.
    caller_info : dict
        Caller file/function/line from _caller.get_caller_info().
    """
    event = {
        "event_id": str(uuid.uuid4()),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "latency_ms": latency_ms,
        "sdk_version": "2.0.0",
        "sdk_language": "python",
    }

    event.update(response_data)
    event.update(caller_info)

    if context_data:
        if context_data.get("trace_id"):
            event["trace_id"] = context_data["trace_id"]
        if context_data.get("span_id"):
            event["span_id"] = context_data["span_id"]
        if context_data.get("parent_span_id"):
            event["parent_span_id"] = context_data["parent_span_id"]
        if context_data.get("tags"):
            event["tags"] = context_data["tags"]

    return event
