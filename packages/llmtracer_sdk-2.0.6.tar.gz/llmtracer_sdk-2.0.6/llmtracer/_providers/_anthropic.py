"""Anthropic-specific: patch targets, response parsing, stream wrapping."""

from .. import _config
from .._wrapper import _build_and_enqueue

# ── Patch targets ─────────────────────────────────────────────────────────────

SYNC_TARGET = ("anthropic.resources.messages", "Messages", "create")
ASYNC_TARGET = ("anthropic.resources.messages", "AsyncMessages", "create")


# ── Response parsing ──────────────────────────────────────────────────────────


def parse_response(result):
    """Extract provider/model/tokens from an Anthropic Message."""
    usage = getattr(result, "usage", None)
    return {
        "provider": "anthropic",
        "model": getattr(result, "model", None) or "unknown",
        "input_tokens": getattr(usage, "input_tokens", 0) if usage else 0,
        "output_tokens": getattr(usage, "output_tokens", 0) if usage else 0,
        "status": "success" if getattr(result, "stop_reason", None) else "error",
    }


# ── Sync stream wrapper ──────────────────────────────────────────────────────


class _WrappedStream:
    """Transparent wrapper for Anthropic streaming responses.

    Anthropic's stream=True returns an iterable of MessageStreamEvent objects.
    We watch for message_start (input tokens), message_delta (output tokens),
    and message_stop to record the event.
    """

    def __init__(self, original_stream, context, start_elapsed_ms, kwargs):
        self._stream = original_stream
        self._context = context
        self._elapsed_ms = start_elapsed_ms
        self._kwargs = kwargs
        self._model = kwargs.get("model", "unknown")
        self._input_tokens = 0
        self._output_tokens = 0

    def __iter__(self):
        return self

    def __next__(self):
        try:
            event = next(self._stream)
            self._extract(event)
            return event
        except StopIteration:
            try:
                self._record()
            except Exception:
                pass
            raise

    def _extract(self, event):
        """Extract token counts from stream events."""
        event_type = getattr(event, "type", None)

        if event_type == "message_start":
            msg = getattr(event, "message", None)
            if msg:
                self._model = getattr(msg, "model", self._model)
                usage = getattr(msg, "usage", None)
                if usage:
                    self._input_tokens = getattr(usage, "input_tokens", 0) or 0

        elif event_type == "message_delta":
            usage = getattr(event, "usage", None)
            if usage:
                self._output_tokens = getattr(usage, "output_tokens", 0) or 0

    def _record(self):
        response_data = {
            "provider": "anthropic",
            "model": self._model,
            "input_tokens": self._input_tokens,
            "output_tokens": self._output_tokens,
            "status": "success",
        }
        _build_and_enqueue(self._context, response_data, self._elapsed_ms)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        if hasattr(self._stream, "__exit__"):
            return self._stream.__exit__(*exc)
        return False

    def close(self):
        if hasattr(self._stream, "close"):
            self._stream.close()


def wrap_stream(result, context, elapsed_ms, kwargs):
    """Wrap a sync Anthropic stream."""
    return _WrappedStream(result, context, elapsed_ms, kwargs)


# ── Async stream wrapper ─────────────────────────────────────────────────────


class _WrappedAsyncStream:
    """Async transparent wrapper for Anthropic streaming."""

    def __init__(self, original_stream, context, start_elapsed_ms, kwargs):
        self._stream = original_stream
        self._context = context
        self._elapsed_ms = start_elapsed_ms
        self._kwargs = kwargs
        self._model = kwargs.get("model", "unknown")
        self._input_tokens = 0
        self._output_tokens = 0

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            event = await self._stream.__anext__()
            self._extract(event)
            return event
        except StopAsyncIteration:
            try:
                self._record()
            except Exception:
                pass
            raise

    def _extract(self, event):
        event_type = getattr(event, "type", None)

        if event_type == "message_start":
            msg = getattr(event, "message", None)
            if msg:
                self._model = getattr(msg, "model", self._model)
                usage = getattr(msg, "usage", None)
                if usage:
                    self._input_tokens = getattr(usage, "input_tokens", 0) or 0

        elif event_type == "message_delta":
            usage = getattr(event, "usage", None)
            if usage:
                self._output_tokens = getattr(usage, "output_tokens", 0) or 0

    def _record(self):
        response_data = {
            "provider": "anthropic",
            "model": self._model,
            "input_tokens": self._input_tokens,
            "output_tokens": self._output_tokens,
            "status": "success",
        }
        _build_and_enqueue(self._context, response_data, self._elapsed_ms)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        if hasattr(self._stream, "__aexit__"):
            return await self._stream.__aexit__(*exc)
        return False


def wrap_async_stream(result, context, elapsed_ms, kwargs):
    """Wrap an async Anthropic stream."""
    return _WrappedAsyncStream(result, context, elapsed_ms, kwargs)
