"""OpenAI-specific: patch targets, response parsing, stream wrapping."""

from .. import _config
from .._wrapper import _build_and_enqueue

# ── Patch targets ─────────────────────────────────────────────────────────────

SYNC_TARGET = ("openai.resources.chat.completions", "Completions", "create")
ASYNC_TARGET = ("openai.resources.chat.completions", "AsyncCompletions", "create")


# ── Response parsing ──────────────────────────────────────────────────────────


def parse_response(result):
    """Extract provider/model/tokens from an OpenAI ChatCompletion."""
    # LangChain may wrap response in LegacyAPIResponse / APIResponse
    # Unwrap to get the actual ChatCompletion object
    inner = result
    if hasattr(result, "parse"):
        try:
            inner = result.parse()
        except Exception:
            pass
    elif hasattr(result, "_parsed"):
        inner = getattr(result, "_parsed", result)

    return {
        "provider": "openai",
        "model": getattr(inner, "model", None) or "unknown",
        "input_tokens": getattr(inner.usage, "prompt_tokens", 0)
        if getattr(inner, "usage", None)
        else 0,
        "output_tokens": getattr(inner.usage, "completion_tokens", 0)
        if getattr(inner, "usage", None)
        else 0,
        "status": "success",
    }


# ── Sync stream wrapper ──────────────────────────────────────────────────────


class _WrappedStream:
    """Transparent wrapper that passes through chunks and records on completion."""

    def __init__(self, original_stream, context, start_elapsed_ms, kwargs):
        self._stream = original_stream
        self._context = context
        self._elapsed_ms = start_elapsed_ms
        self._kwargs = kwargs
        self._chunks = []

    def __iter__(self):
        return self

    def __next__(self):
        try:
            chunk = next(self._stream)
            self._chunks.append(chunk)
            return chunk
        except StopIteration:
            try:
                self._record()
            except Exception:
                pass
            raise

    def _record(self):
        """Extract usage from accumulated chunks and record event."""
        model = self._kwargs.get("model", "unknown")
        input_tokens = 0
        output_tokens = 0

        # OpenAI includes usage in the final chunk when
        # stream_options={"include_usage": True}
        for chunk in reversed(self._chunks):
            usage = getattr(chunk, "usage", None)
            if usage:
                input_tokens = getattr(usage, "prompt_tokens", 0) or 0
                output_tokens = getattr(usage, "completion_tokens", 0) or 0
                break

        if getattr(self._chunks[0] if self._chunks else None, "model", None):
            model = self._chunks[0].model

        response_data = {
            "provider": "openai",
            "model": model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "status": "success",
        }
        _build_and_enqueue(self._context, response_data, self._elapsed_ms)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        if hasattr(self._stream, "__exit__"):
            return self._stream.__exit__(*exc)
        return False

    def close(self):
        if hasattr(self._stream, "close"):
            self._stream.close()


def wrap_stream(result, context, elapsed_ms, kwargs):
    """Wrap a sync OpenAI stream."""
    return _WrappedStream(result, context, elapsed_ms, kwargs)


# ── Async stream wrapper ─────────────────────────────────────────────────────


class _WrappedAsyncStream:
    """Async transparent wrapper for OpenAI streaming."""

    def __init__(self, original_stream, context, start_elapsed_ms, kwargs):
        self._stream = original_stream
        self._context = context
        self._elapsed_ms = start_elapsed_ms
        self._kwargs = kwargs
        self._chunks = []

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            chunk = await self._stream.__anext__()
            self._chunks.append(chunk)
            return chunk
        except StopAsyncIteration:
            try:
                self._record()
            except Exception:
                pass
            raise

    def _record(self):
        model = self._kwargs.get("model", "unknown")
        input_tokens = 0
        output_tokens = 0

        for chunk in reversed(self._chunks):
            usage = getattr(chunk, "usage", None)
            if usage:
                input_tokens = getattr(usage, "prompt_tokens", 0) or 0
                output_tokens = getattr(usage, "completion_tokens", 0) or 0
                break

        if getattr(self._chunks[0] if self._chunks else None, "model", None):
            model = self._chunks[0].model

        response_data = {
            "provider": "openai",
            "model": model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "status": "success",
        }
        _build_and_enqueue(self._context, response_data, self._elapsed_ms)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        if hasattr(self._stream, "__aexit__"):
            return await self._stream.__aexit__(*exc)
        return False


def wrap_async_stream(result, context, elapsed_ms, kwargs):
    """Wrap an async OpenAI stream."""
    return _WrappedAsyncStream(result, context, elapsed_ms, kwargs)
