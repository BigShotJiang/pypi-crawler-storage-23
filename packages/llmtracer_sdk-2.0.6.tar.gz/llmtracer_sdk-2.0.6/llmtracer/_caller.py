"""Caller capture via sys._getframe().

~2-5us per call vs 50-200us for inspect.stack().
Falls back gracefully on non-CPython.
"""

import sys


def get_caller_info(depth=3):
    """Get caller file/function/line from the call stack.

    *depth* must point at the USER's code, not our wrapper internals.
    Call stack from this function:
        0: get_caller_info
        1: _build_context
        2: wrapper
        3: user code  <-- target
    """
    try:
        frame = sys._getframe(depth)
        return {
            "caller_file": frame.f_code.co_filename,
            "caller_function": frame.f_code.co_qualname,
            "caller_line": frame.f_lineno,
        }
    except (AttributeError, ValueError):
        return {}
