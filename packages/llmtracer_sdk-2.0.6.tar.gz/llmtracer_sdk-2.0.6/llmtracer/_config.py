"""Global configuration state for LLM Tracer."""


api_key: str = ""
endpoint: str = "https://us-central1-llmtracer-alt.cloudfunctions.net/v1Events"
debug: bool = False
enabled: bool = False
