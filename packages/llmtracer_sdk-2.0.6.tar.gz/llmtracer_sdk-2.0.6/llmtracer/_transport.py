"""Background thread batching + HTTP delivery via stdlib urllib."""

import json
import queue
import threading
import urllib.request

from . import _config

_event_queue: queue.Queue = queue.Queue()
_flush_thread: threading.Thread = None  # type: ignore[assignment]
_started = False
_lock = threading.Lock()
_stop_event = threading.Event()

# How long to wait between flushes after the first batch
_FLUSH_INTERVAL = 5.0
# Max events to re-queue on failure (prevent memory leak)
_MAX_REQUEUE = 100


def start():
    """Start background flush thread (idempotent)."""
    global _flush_thread, _started
    with _lock:
        if _started:
            return
        _stop_event.clear()
        _started = True
        _flush_thread = threading.Thread(target=_flush_loop, daemon=True)
        _flush_thread.start()


def stop():
    """Stop the background thread. Used in tests."""
    global _started, _flush_thread
    with _lock:
        if not _started:
            return
        _started = False
        _stop_event.set()
    # Wait for the thread to finish (briefly)
    if _flush_thread is not None:
        _flush_thread.join(timeout=2.0)
        _flush_thread = None


def enqueue(event):
    """Add event to send queue."""
    _event_queue.put(event)


def flush():
    """Force flush all queued events (blocking)."""
    _do_flush()


def _flush_loop():
    """Background loop: wait for events, then flush on interval."""
    first_batch = True
    while not _stop_event.is_set():
        if first_batch:
            # Wait briefly for the first event, then flush immediately
            try:
                event = _event_queue.get(timeout=0.5)
                # Got one — put it back so _do_flush picks it up
                _event_queue.put(event)
            except queue.Empty:
                continue
            _do_flush()
            first_batch = False
        else:
            # Normal interval — wake up early if stop is requested
            _stop_event.wait(_FLUSH_INTERVAL)
            if not _stop_event.is_set():
                _do_flush()


def _do_flush():
    """Send all queued events in one HTTP request."""
    events = []
    while True:
        try:
            events.append(_event_queue.get_nowait())
        except queue.Empty:
            break

    if not events:
        return

    try:
        payload = json.dumps({"schema_version": "1.0", "events": events}).encode("utf-8")
        req = urllib.request.Request(
            _config.endpoint,
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {_config.api_key}",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            if _config.debug:
                print(f"[llmtracer] Flushed {len(events)} events \u2192 {resp.status}")
    except Exception as e:
        if _config.debug:
            print(f"[llmtracer] Flush failed: {e}")
        # Re-queue events for retry (with limit to prevent memory leak)
        for event in events[:_MAX_REQUEUE]:
            _event_queue.put(event)


def _reset():
    """Reset transport state. Used in tests."""
    global _event_queue
    stop()
    # Replace the queue entirely so any lingering thread
    # from a previous test cannot consume events from the new queue
    _event_queue = queue.Queue()
