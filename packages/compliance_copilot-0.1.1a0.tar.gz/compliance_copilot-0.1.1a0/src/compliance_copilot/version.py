"""Version information."""
__version__ = "0.1.1-alpha"  # Changed from 0.1.0a0

def get_version():
    return __version__
