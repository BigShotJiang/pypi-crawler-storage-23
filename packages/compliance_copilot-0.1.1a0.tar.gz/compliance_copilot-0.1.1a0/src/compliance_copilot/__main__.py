"""Main entry point for running the package directly."""

from .cli import main

if __name__ == "__main__":
    main()
