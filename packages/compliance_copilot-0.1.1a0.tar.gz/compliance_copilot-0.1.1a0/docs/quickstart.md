# Quick Start Guide

## Installation

```bash
pip install compliance-copilot
cat > filename << 'EOF'
line 1
line 2
line 3
