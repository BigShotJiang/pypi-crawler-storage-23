"""
Test suite for GitFlow Analytics.

This package contains comprehensive tests for all components of the GitFlow Analytics system.
Tests are organized to mirror the source code structure for easy navigation.
"""
