# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).


## [0.1.0-alpha.4] - 2026-02-23

This **minor release** includes 8 commits.


### Documentation
- Update README.md  ([#19](https://github.com/stateful-y/sklearn-wrap/pull/19) and [#21](https://github.com/stateful-y/sklearn-wrap/pull/21)) by @gtauzin
- Export examples as both static HTML and interactive WASM  ([#24](https://github.com/stateful-y/sklearn-wrap/pull/24)) by @gtauzin
- Reformulate docs text  ([#27](https://github.com/stateful-y/sklearn-wrap/pull/27)) by @gtauzin

### Miscellaneous Tasks
- Update from copier template  ([#22](https://github.com/stateful-y/sklearn-wrap/pull/22), [#25](https://github.com/stateful-y/sklearn-wrap/pull/25), and [#28](https://github.com/stateful-y/sklearn-wrap/pull/28)) by @gtauzin
- Align notebook examples with contributing guidelines  ([#25](https://github.com/stateful-y/sklearn-wrap/pull/25)) by @gtauzin
- Guard codecov steps when token is unavailable  ([#26](https://github.com/stateful-y/sklearn-wrap/pull/26)) by @gtauzin

### Contributors

Thanks to all contributors for this release:
- @gtauzin

## [0.1.0-alpha.3] - 2026-02-10

This **minor release** includes 1 commit.


### Bug Fixes
- Add pyodide package install cells to marimo notebooks  ([#17](https://github.com/stateful-y/sklearn-wrap/pull/17)) by @gtauzin

### Contributors

Thanks to all contributors for this release:
- @gtauzin

## [0.1.0-alpha.2] - 2026-02-09

This **minor release** includes 4 commits.


### Documentation
- Update README with theme-aware logo and stateful-y branding  ([#12](https://github.com/stateful-y/sklearn-wrap/pull/12)) by @gtauzin

### Refactoring
- Enforce `_estimator_name` as constructor keyword  ([#13](https://github.com/stateful-y/sklearn-wrap/pull/13)) by @gtauzin

### Miscellaneous Tasks
- Update GitHub Actions to latest versions  ([#11](https://github.com/stateful-y/sklearn-wrap/pull/11)) by @gtauzin
- Replace template placeholders with actual project values  ([#14](https://github.com/stateful-y/sklearn-wrap/pull/14)) by @gtauzin

### Contributors

Thanks to all contributors for this release:
- @gtauzin

## [0.1.0-alpha.1] - 2026-02-07

This **minor release** includes 1 commit.

- Initial commit

### Contributors

Thanks to all contributors for this release:
- @gtauzin

## [Unreleased]

### Added
- Initial project setup
