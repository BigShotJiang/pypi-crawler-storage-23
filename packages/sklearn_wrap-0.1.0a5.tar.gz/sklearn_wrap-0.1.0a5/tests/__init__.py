# Authors: Guillaume Tauzin
# License: BSD 3 clause
