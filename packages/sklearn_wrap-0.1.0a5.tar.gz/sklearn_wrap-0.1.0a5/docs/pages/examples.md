# Examples

Explore Sklearn-Wrap through focused, interactive examples. Each notebook demonstrates one core concept in 5–15 minutes.

<!-- GALLERY -->

## Running Examples Locally

- Run interactively: `just example <name>`
- Execute as a script: `python examples/<name>.py`
- Deploy as an app: `marimo run examples/<name>.py`

## Next Steps

- **[User Guide](user-guide.md)** – Deep dive into core concepts and architecture
- **[API Reference](api-reference.md)** – Complete BaseClassWrapper documentation
- **[Contributing](contributing.md)** – Add your own examples or improve existing ones
