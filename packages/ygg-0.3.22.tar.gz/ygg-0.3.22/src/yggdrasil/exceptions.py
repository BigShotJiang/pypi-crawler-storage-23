__all__ = [
    "YGGException"
]


class YGGException(Exception):
    pass
