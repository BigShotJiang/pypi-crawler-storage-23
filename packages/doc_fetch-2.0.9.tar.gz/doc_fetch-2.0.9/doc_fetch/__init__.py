"""
DocFetch - Dynamic documentation fetching CLI for AI/LLM consumption.

This package provides a Python wrapper around the Go-based DocFetch binary,
enabling easy installation and usage via pip.
"""