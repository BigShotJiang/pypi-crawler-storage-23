def maybe_show_nowfy_welcome_sheet(plugin):
    try:
        import time

        mod = None
        try:
            import nowfy as nowfy_mod

            mod = nowfy_mod
        except Exception:
            mod = None
        if mod is None:
            return False
        run_on_ui_thread = getattr(mod, "run_on_ui_thread", None)
        BulletinHelper = getattr(mod, "BulletinHelper", None)
        if not (callable(run_on_ui_thread) and BulletinHelper):
            return False

        version = ""
        try:
            version = str(getattr(plugin, "__version__", "") or "").strip()
        except Exception:
            version = ""
        if not version:
            version = "1.0.0"
        seen_key = f"nowfy_welcome_sheet_seen_{version}"
        try:
            if bool(plugin.get_setting(seen_key, False)):
                return False
        except Exception:
            pass
        try:
            plugin.set_setting(seen_key, True)
            plugin.set_setting("nowfy_welcome_last_seen_ts", int(time.time()))
        except Exception:
            pass

        def _show():
            try:
                BulletinHelper.show_success("Nowfy initialized!")
            except Exception:
                pass

        run_on_ui_thread(_show)
        return True
    except Exception:
        return False
