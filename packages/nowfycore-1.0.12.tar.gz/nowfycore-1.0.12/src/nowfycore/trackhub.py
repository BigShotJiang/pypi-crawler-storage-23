def _tr(plugin, key, fallback):
    try:
        fn = getattr(plugin, "tr", None)
        if callable(fn):
            val = str(fn(key) or "").strip()
            if val and val != key:
                return val
    except Exception:
        pass
    return fallback


def append_track_hub_style_selector(plugin, items):
    try:
        from ui.settings import Selector
        items.append(
            Selector(
                key="track_hub_style",
                text="Style",
                default=int(plugin.get_setting("track_hub_style", 0) or 0),
                items=["Default", "Box"],
                icon="msg_theme",
                on_change=lambda v: (
                    plugin.set_setting("track_hub_style", int(v)),
                    plugin.reload_settings(),
                ),
                link_alias="nowfy_extended_track_hub_style",
            )
        )
    except Exception:
        pass


def build_track_hub_subfragment_items(plugin):
    try:
        from ui.settings import Divider, Switch, Selector
        enabled = bool(plugin.get_setting("track_hub_enabled", False))
        items = [
            Divider(text=_tr(plugin, "track_hub_intro", "Track Hub publishes now-playing payload for profile widgets.")),
            Switch(
                key="track_hub_enabled",
                text=_tr(plugin, "track_hub_enable", "Enable Track Hub"),
                subtext=_tr(plugin, "track_hub_enable_sub", "Update profile module with current track source."),
                default=enabled,
                icon="msg_openprofile",
                on_change=lambda v: (
                    plugin.set_setting("track_hub_enabled", bool(v)),
                    (plugin._setup_track_hub_profile_hooks() if bool(v) else None),
                    (plugin._start_track_hub_worker() if bool(v) else plugin._stop_track_hub_worker()),
                    plugin.reload_settings(),
                ),
                link_alias="nowfy_extended_track_hub_enabled",
            ),
        ]
        if enabled:
            append_track_hub_style_selector(plugin, items)
            items.append(Divider(text=_tr(plugin, "track_hub_source_section", "Source")))
            srcs, labels = plugin._track_hub_get_source_options()
            if len(labels) > 1:
                idx = int(plugin.get_setting("track_hub_source_idx", 0) or 0)
                if idx < 0 or idx >= len(labels):
                    idx = 0
                items.append(
                    Selector(
                        key="track_hub_source_idx",
                        text=_tr(plugin, "track_hub_source_label", "Active Source"),
                        default=idx,
                        items=labels,
                        icon="header_goinline_solar",
                        on_change=lambda v: (
                            plugin.set_setting("track_hub_source_idx", int(v)),
                            plugin._track_hub_publish_payload(),
                            plugin.reload_settings(),
                        ),
                        link_alias="nowfy_extended_track_hub_source",
                    )
                )
            else:
                items.append(Divider(text=_tr(plugin, "track_hub_source_auto", "Source selected automatically.")))
        return items
    except Exception:
        return []
