def on_panel_drawer_toggle(plugin, enabled):
    try:
        if bool(enabled):
            fn = getattr(plugin, "_ensure_nowfy_drawer_item", None)
            if callable(fn):
                fn()
        else:
            fn = getattr(plugin, "_remove_nowfy_drawer_item", None)
            if callable(fn):
                fn()
        rs = getattr(plugin, "reload_settings", None)
        if callable(rs):
            rs()
        return True
    except Exception:
        return False


def on_panel_disable_logs_toggle(plugin, enabled, set_log_muted=None, set_print_muted=None, apply_log_wrapper=None, apply_print_wrapper=None):
    try:
        muted = bool(enabled)
        try:
            plugin.set_setting("disable_logs", muted)
        except Exception:
            pass
        try:
            if callable(set_log_muted):
                set_log_muted(muted)
            if callable(set_print_muted):
                set_print_muted(muted)
            if callable(apply_log_wrapper):
                apply_log_wrapper(True)
            if callable(apply_print_wrapper):
                apply_print_wrapper(True)
        except Exception:
            pass
        try:
            plugin.reload_settings()
        except Exception:
            pass
        return True
    except Exception:
        return False


def on_lab_nowplaying_pill_toggle(plugin, enabled):
    try:
        plugin.set_setting("nowplaying_pill_enabled", bool(enabled))
        if bool(enabled):
            fn = getattr(plugin, "_start_nowplaying_pill_worker", None)
            if callable(fn):
                fn()
        else:
            fn = getattr(plugin, "_stop_nowplaying_pill_worker", None)
            if callable(fn):
                fn()
        try:
            plugin.reload_settings()
        except Exception:
            pass
        return True
    except Exception:
        return False


def on_lab_send_haptic_toggle(plugin, enabled):
    try:
        plugin.set_setting("send_haptic_enabled", bool(enabled))
        if bool(enabled):
            fn = getattr(plugin, "_vibrate_feedback", None)
            if callable(fn):
                fn(35, 85)
        try:
            plugin.reload_settings()
        except Exception:
            pass
        return True
    except Exception:
        return False
