class CoreState:
    """Small state facade for staged migration.

    Uses plugin settings when a plugin instance is provided, and keeps
    an in-memory fallback store for package-only operations.
    """

    def __init__(self):
        self._store = {}

    def get(self, key, default=None, plugin=None):
        k = str(key)
        try:
            if plugin is not None and hasattr(plugin, "get_setting"):
                return plugin.get_setting(k, self._store.get(k, default))
        except Exception:
            pass
        return self._store.get(k, default)

    def set(self, key, value, plugin=None):
        k = str(key)
        self._store[k] = value
        try:
            if plugin is not None and hasattr(plugin, "set_setting"):
                plugin.set_setting(k, value)
        except Exception:
            pass
        return True

    def export(self):
        try:
            return dict(self._store)
        except Exception:
            return {}

    def import_settings(self, data, plugin=None):
        if not isinstance(data, dict):
            return 0
        applied = 0
        for key, value in data.items():
            self.set(str(key), value, plugin=plugin)
            applied += 1
        return applied
