def _rt():
    try:
        import nowfy as nowfy_mod

        return nowfy_mod
    except Exception:
        return None


def _uitem_cls():
    mod = _rt()
    if mod is not None:
        u = getattr(mod, "UItem", None)
        if u is not None:
            return u
    try:
        from org.telegram.ui.Components import UItem as _UItem

        return _UItem
    except Exception:
        return None


def _add_slide(labels, current, callback):
    try:
        mod = _rt()
        if mod is None:
            return None
        Utilities = getattr(mod, "Utilities", None)
        dynamic_proxy = getattr(mod, "dynamic_proxy", None)
        jarray = getattr(mod, "jarray", None)
        jclass = getattr(mod, "jclass", None)
        UItem = _uitem_cls()
        if not (Utilities and dynamic_proxy and jarray and jclass and UItem):
            return None
        String = jclass("java.lang.String")
        CallbackInterface = Utilities.Callback

        class _Cb(dynamic_proxy(CallbackInterface)):
            def run(self, value):
                try:
                    callback(value)
                except Exception:
                    pass

        slide_items = jarray(String)(labels)
        return UItem.asSlideView(slide_items, int(current), _Cb())
    except Exception:
        return None


def _safe_get_key(plugin, item):
    try:
        if hasattr(plugin, "_get_uitem_setting_key"):
            return str(plugin._get_uitem_setting_key(item) or "")
    except Exception:
        pass
    return ""


def get_nowtab_control_style(plugin):
    try:
        v = int(plugin.get_setting("nowfy_control_style", 0) or 0)
    except Exception:
        v = 0
    return 1 if v == 1 else 0


def apply_nowtab_control_modern_ui(
    plugin,
    context,
    controls_row,
    control_container,
    title_row,
    premium_notice_bg,
    btn_back,
    btn_play_pause,
    btn_play_pause_icon,
    btn_play_pause_fallback,
    btn_skip,
    btn_search,
    btn_search_icon,
    btn_search_fallback,
    lp_back,
    lp_pp,
    lp_skip,
    lp_search,
):
    try:
        mod = _rt()
        if mod is None:
            return False
        Theme = getattr(mod, "Theme", None)
        AndroidUtilities = getattr(mod, "AndroidUtilities", None)
        GradientDrawable = getattr(mod, "GradientDrawable", None)
        Color = getattr(mod, "Color", None)
        LinearLayout = getattr(mod, "LinearLayout", None)
        if not (Theme and AndroidUtilities and GradientDrawable and Color):
            return False

        try:
            bg_base = int(Theme.getColor(Theme.key_windowBackgroundWhite))
        except Exception:
            bg_base = 0xFFFFFFFF
        try:
            r = (bg_base >> 16) & 0xFF
            g = (bg_base >> 8) & 0xFF
            b = bg_base & 0xFF
            lum = (0.299 * r) + (0.587 * g) + (0.114 * b)
            is_light = lum > 150
        except Exception:
            is_light = False
        accent_bg = Color.parseColor("#4D63AE") if is_light else Color.parseColor("#2C3F78")
        accent_bg_soft = Color.parseColor("#41579B") if is_light else Color.parseColor("#24386D")
        chip_bg = Color.parseColor("#F2F5FF") if is_light else Color.parseColor("#FFFFFF")
        chip_fg = Color.parseColor("#111111")

        try:
            controls_row.setPadding(AndroidUtilities.dp(4), AndroidUtilities.dp(4), AndroidUtilities.dp(4), AndroidUtilities.dp(4))
        except Exception:
            pass
        try:
            if premium_notice_bg is not None:
                premium_notice_bg.setColor(accent_bg_soft)
        except Exception:
            pass

        for btn in (btn_back, btn_skip, btn_search):
            try:
                bg = GradientDrawable()
                bg.setColor(accent_bg)
                bg.setCornerRadius(AndroidUtilities.dp(42 if btn is not btn_search else 12))
                btn.setBackground(bg)
            except Exception:
                pass
        try:
            bg_pp = GradientDrawable()
            bg_pp.setColor(chip_bg)
            bg_pp.setCornerRadius(AndroidUtilities.dp(42))
            btn_play_pause.setBackground(bg_pp)
            btn_play_pause_fallback.setTextColor(chip_fg)
            try:
                btn_play_pause_icon.setColorFilter(chip_fg)
            except Exception:
                pass
        except Exception:
            pass

        try:
            lp_back.width = AndroidUtilities.dp(84)
            lp_back.height = AndroidUtilities.dp(84)
            lp_back.weight = 0.0
            lp_back.setMargins(AndroidUtilities.dp(4), 0, AndroidUtilities.dp(4), 0)
        except Exception:
            pass
        try:
            lp_pp.width = 0
            lp_pp.height = AndroidUtilities.dp(84)
            lp_pp.weight = 1.0
            lp_pp.setMargins(AndroidUtilities.dp(4), 0, AndroidUtilities.dp(4), 0)
        except Exception:
            pass
        try:
            lp_skip.width = AndroidUtilities.dp(84)
            lp_skip.height = AndroidUtilities.dp(84)
            lp_skip.weight = 0.0
            lp_skip.setMargins(AndroidUtilities.dp(4), 0, AndroidUtilities.dp(4), 0)
        except Exception:
            pass
        try:
            lp_search.width = AndroidUtilities.dp(34)
            lp_search.height = AndroidUtilities.dp(34)
            lp_search.weight = 0.0
            lp_search.setMargins(AndroidUtilities.dp(6), 0, 0, 0)
        except Exception:
            pass

        try:
            s_icon_lp = btn_search_icon.getLayoutParams()
            s_icon_lp.width = AndroidUtilities.dp(16)
            s_icon_lp.height = AndroidUtilities.dp(16)
            btn_search_icon.setLayoutParams(s_icon_lp)
        except Exception:
            pass
        try:
            btn_search_fallback.setText("")
        except Exception:
            pass
        try:
            if LinearLayout is not None:
                lp_search_top = LinearLayout.LayoutParams(AndroidUtilities.dp(34), AndroidUtilities.dp(34))
                lp_search_top.setMargins(AndroidUtilities.dp(6), 0, 0, 0)
                title_row.addView(btn_search, lp_search_top)
        except Exception:
            pass
        return False
    except Exception:
        return False


def update_nowtab_control_modern_state(plugin, is_playing):
    try:
        lbl = getattr(plugin, "_nowtab_control_modern_play_label", None)
        icn = getattr(plugin, "_nowtab_control_modern_play_icon", None)
        fb = getattr(plugin, "_nowtab_control_modern_play_fallback", None)
        if lbl is not None:
            lbl.setText("Pause" if bool(is_playing) else "Play")
        if fb is not None:
            fb.setText("||" if bool(is_playing) else ">")
        if icn is not None:
            try:
                icn.setTranslationX(float(0))
            except Exception:
                pass
        return True
    except Exception:
        return False


def inject_track_hub_source_slide(plugin, activity, items):
    try:
        if not bool(plugin.get_setting("track_hub_enabled", False)):
            return False
        sources, labels = plugin._track_hub_get_source_options()
        if len(labels) <= 1:
            return False
        insert_idx = -1
        remove_indices = []
        for i in range(items.size()):
            try:
                it = items.get(i)
                key = _safe_get_key(plugin, it)
                if key == "track_hub_source_idx":
                    remove_indices.append(i)
                    if insert_idx < 0:
                        insert_idx = i
            except Exception:
                pass
        if insert_idx < 0:
            return False
        for idx in reversed(remove_indices):
            try:
                items.remove(idx)
            except Exception:
                pass
        try:
            current = int(plugin.get_setting("track_hub_source_idx", 0) or 0)
        except Exception:
            current = 0
        current = max(0, min(len(labels) - 1, current))

        def _cb(v):
            try:
                v = max(0, min(len(labels) - 1, int(v)))
            except Exception:
                v = 0
            try:
                plugin.set_setting("track_hub_source_idx", v)
                plugin._track_hub_publish_payload()
            except Exception:
                pass

        slide = _add_slide(labels, current, _cb)
        if slide is None:
            return False
        UItem = _uitem_cls()
        items.add(insert_idx, slide)
        try:
            items.add(insert_idx + 1, UItem.asShadow())
        except Exception:
            pass
        return True
    except Exception:
        return False


def inject_nowtab_control_style_slide(plugin, activity, items):
    try:
        insert_idx = -1
        remove_indices = []
        for i in range(items.size()):
            try:
                it = items.get(i)
                marker = str(getattr(it, "object2", "") or "")
                if marker == "__nowtab_control_style_info__":
                    remove_indices.append(i)
                    continue
                key = _safe_get_key(plugin, it)
                if key == "nowfy_control_style":
                    remove_indices.append(i)
                    if insert_idx < 0:
                        insert_idx = i
            except Exception:
                pass
        if insert_idx < 0:
            return False
        for idx in reversed(remove_indices):
            try:
                items.remove(idx)
            except Exception:
                pass
        labels = ["Control", "Modern"]
        current = get_nowtab_control_style(plugin)

        def _cb(v):
            try:
                vv = 1 if int(v) == 1 else 0
            except Exception:
                vv = 0
            try:
                plugin.set_setting("nowfy_control_style", vv)
            except Exception:
                pass

        slide = _add_slide(labels, current, _cb)
        if slide is None:
            return False
        UItem = _uitem_cls()
        items.add(insert_idx, slide)
        try:
            items.add(insert_idx + 1, UItem.asShadow())
        except Exception:
            pass
        return True
    except Exception:
        return False


def inject_vinify_logo_position_radios(plugin, activity, items):
    try:
        UItem = _uitem_cls()
        if UItem is None:
            return False
        insert_idx = -1
        remove_indices = []
        for i in range(items.size()):
            try:
                it = items.get(i)
                key = _safe_get_key(plugin, it)
                if key == "vinify_logo_position":
                    remove_indices.append(i)
                    if insert_idx < 0:
                        insert_idx = i
            except Exception:
                pass
        if insert_idx < 0:
            return False
        for idx in reversed(remove_indices):
            try:
                items.remove(idx)
            except Exception:
                pass
        try:
            current = int(plugin.get_setting("vinify_logo_position", 0) or 0)
        except Exception:
            current = 0
        current = 0 if current != 1 else 1
        items.add(insert_idx, UItem.asHeader("Logo Position"))
        top_radio = UItem.asRadio(hash("vinify_logo_position_top") & 0x7FFFFFFF, "Top", None)
        top_radio.object2 = "__vinify_logo_position_top__"
        top_radio.setChecked(current == 0)
        items.add(insert_idx + 1, top_radio)
        bottom_radio = UItem.asRadio(hash("vinify_logo_position_bottom") & 0x7FFFFFFF, "Bottom", None)
        bottom_radio.object2 = "__vinify_logo_position_bottom__"
        bottom_radio.setChecked(current == 1)
        items.add(insert_idx + 2, bottom_radio)
        try:
            items.add(insert_idx + 3, UItem.asShadow())
        except Exception:
            pass
        return True
    except Exception:
        return False


def inject_vinify_cover_shape_slide(plugin, activity, items):
    try:
        insert_idx = -1
        remove_indices = []
        for i in range(items.size()):
            try:
                it = items.get(i)
                key = _safe_get_key(plugin, it)
                if key == "vinify_cover_shape":
                    remove_indices.append(i)
                    if insert_idx < 0:
                        insert_idx = i
            except Exception:
                pass
        if insert_idx < 0:
            return False
        for idx in reversed(remove_indices):
            try:
                items.remove(idx)
            except Exception:
                pass
        labels = ["Default", "Circle"]
        try:
            current = int(plugin.get_setting("vinify_cover_shape", 0) or 0)
        except Exception:
            current = 0
        current = 0 if current != 1 else 1

        def _cb(v):
            try:
                vv = 0 if int(v) != 1 else 1
            except Exception:
                vv = 0
            try:
                plugin.set_setting("vinify_cover_shape", vv)
            except Exception:
                pass

        slide = _add_slide(labels, current, _cb)
        if slide is None:
            return False
        UItem = _uitem_cls()
        items.add(insert_idx, slide)
        try:
            items.add(insert_idx + 1, UItem.asShadow())
        except Exception:
            pass
        return True
    except Exception:
        return False


def inject_nowfy_pulse_style_slide(plugin, activity, items):
    try:
        if not bool(plugin.get_setting("nowplaying_pill_enabled", False)):
            return False
        insert_idx = -1
        remove_indices = []
        for i in range(items.size()):
            try:
                it = items.get(i)
                key = _safe_get_key(plugin, it)
                if key == "nowplaying_pill_style":
                    remove_indices.append(i)
                    if insert_idx < 0:
                        insert_idx = i
            except Exception:
                pass
        if insert_idx < 0:
            return False
        for idx in reversed(remove_indices):
            try:
                items.remove(idx)
            except Exception:
                pass
        labels = ["Pill", "Applefy"]
        try:
            current = int(plugin.get_setting("nowplaying_pill_style", 0) or 0)
        except Exception:
            current = 0
        current = 1 if current == 1 else 0

        def _cb(v):
            try:
                vv = 1 if int(v) == 1 else 0
            except Exception:
                vv = 0
            try:
                plugin.set_setting("nowplaying_pill_style", vv)
            except Exception:
                pass
            try:
                plugin._nowplaying_pill_last_key = ""
                plugin._nowplaying_pill_last_ts = 0.0
            except Exception:
                pass
            try:
                plugin.reload_settings()
            except Exception:
                pass

        slide = _add_slide(labels, current, _cb)
        if slide is None:
            return False
        UItem = _uitem_cls()
        items.add(insert_idx, slide)
        try:
            items.add(insert_idx + 1, UItem.asShadow())
        except Exception:
            pass
        return True
    except Exception:
        return False


def inject_custom_cover_selector(plugin, activity, items):
    try:
        insert_idx = -1
        remove_indices = []
        for i in range(items.size()):
            try:
                it = items.get(i)
                key = _safe_get_key(plugin, it)
                if key == "custom_cover_selection":
                    remove_indices.append(i)
                    if insert_idx < 0:
                        insert_idx = i
            except Exception:
                pass
        if insert_idx < 0:
            return False
        for idx in reversed(remove_indices):
            try:
                items.remove(idx)
            except Exception:
                pass
        user_label = plugin._get_custom_cover_label() if hasattr(plugin, "_get_custom_cover_label") else "User Cover"
        labels = ["Nowfy", user_label]
        try:
            current = int(plugin.get_setting("custom_cover_selection", 0) or 0)
        except Exception:
            current = 0
        current = 1 if current == 1 else 0

        def _cb(v):
            on_custom_cover_select(plugin, v)
            try:
                plugin.reload_settings()
            except Exception:
                pass

        slide = _add_slide(labels, current, _cb)
        if slide is None:
            return False
        UItem = _uitem_cls()
        items.add(insert_idx, slide)
        try:
            items.add(insert_idx + 1, UItem.asShadow())
        except Exception:
            pass
        return True
    except Exception:
        return False


def on_custom_cover_select(plugin, value):
    try:
        v = 1 if int(str(value)) == 1 else 0
    except Exception:
        v = 0
    try:
        if hasattr(plugin, "set_setting"):
            plugin.set_setting("custom_cover_selection", v)
        if hasattr(plugin, "_apply_header_cover_settings_consistency"):
            plugin._apply_header_cover_settings_consistency()
        return True
    except Exception:
        return False


def on_custom_cover_toggle(plugin, enabled_value):
    try:
        enabled = bool(int(str(enabled_value)))
    except Exception:
        enabled = bool(enabled_value)
    try:
        if hasattr(plugin, "set_setting"):
            plugin.set_setting("custom_cover_unlocked", enabled)
            if not enabled:
                plugin.set_setting("custom_cover_selection", 0)
        if hasattr(plugin, "_apply_header_cover_settings_consistency"):
            plugin._apply_header_cover_settings_consistency()
        return True
    except Exception:
        return False
