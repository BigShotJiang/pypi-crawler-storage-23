from __future__ import annotations

from .mac import CommandMac

__all__ = ["CommandMac"]
