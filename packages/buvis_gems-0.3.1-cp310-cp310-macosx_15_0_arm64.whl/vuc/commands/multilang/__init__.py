from __future__ import annotations

from vuc.commands.multilang.multilang import CommandMultilang

__all__ = ["CommandMultilang"]
