from __future__ import annotations

from .multilang.multilang import CommandMultilang

__all__ = ["CommandMultilang"]
