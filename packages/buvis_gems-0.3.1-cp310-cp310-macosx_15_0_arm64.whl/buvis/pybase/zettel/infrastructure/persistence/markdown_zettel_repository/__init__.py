from __future__ import annotations

from .markdown_zettel_repository import MarkdownZettelRepository

__all__ = ["MarkdownZettelRepository"]
