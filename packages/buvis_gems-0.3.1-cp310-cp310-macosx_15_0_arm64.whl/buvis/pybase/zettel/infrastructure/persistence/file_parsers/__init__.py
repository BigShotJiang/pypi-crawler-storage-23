from __future__ import annotations

from .zettel_file_parser import ZettelFileParser

__all__ = ["ZettelFileParser"]
