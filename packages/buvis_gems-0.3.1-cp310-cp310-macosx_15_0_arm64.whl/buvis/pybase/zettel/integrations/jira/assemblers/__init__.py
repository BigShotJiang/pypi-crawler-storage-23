from __future__ import annotations

from .project_zettel_jira_issue import ProjectZettelJiraIssueDTOAssembler

__all__ = ["ProjectZettelJiraIssueDTOAssembler"]
