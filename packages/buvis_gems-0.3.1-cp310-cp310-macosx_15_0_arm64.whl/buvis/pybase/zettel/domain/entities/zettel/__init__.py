from __future__ import annotations

from .zettel import Zettel

__all__ = ["Zettel"]
