from __future__ import annotations

from .zettel_factory import ZettelFactory

__all__ = ["ZettelFactory"]
