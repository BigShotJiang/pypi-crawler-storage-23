from __future__ import annotations

from bim.params.path_params import PathParams


class ShowNoteParams(PathParams):
    """Parameters for the show-note command."""
