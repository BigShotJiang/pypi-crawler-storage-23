from __future__ import annotations

__all__ = ["query_paths", "query_presentation"]
