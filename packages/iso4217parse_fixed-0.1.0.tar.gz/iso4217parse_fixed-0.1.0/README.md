## About this Fork

This is a maintained fork of the original `iso4217parse`. 

### Key Improvements:
*  We keep the data.json file up-to date only with active and official currencies.
