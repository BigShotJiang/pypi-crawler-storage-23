"""Project Repositories Local Profile."""

__version__ = "0.0.2"
