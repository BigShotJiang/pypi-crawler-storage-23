from hestia_earth.schema import COMPLETENESS_MAPPING


def blank_node_completeness_key(
    blank_node: dict, primary_product: dict, site: dict
) -> str:
    """
    Get the Cycle completeness key associated with the blank node.

    Parameters
    ----------
    blank_node : dict
        The blank node (e.g., Input, Product).
    primary_product : dict
        The cycle primary product. Optional - some completeness depend on the `termType`.
    site : dict
        The site related to the Cycle. Optional - some completeness depend on the `siteType`.

    Returns
    -------
    str
        The completeness key, from the Completeness blank node.
    """
    blank_node_type = blank_node.get("@type") or blank_node.get("type")
    term_type = blank_node.get("term", {}).get("termType")
    product_term_type = (primary_product or {}).get("term", {}).get("termType")
    site_type = (site or {}).get("siteType")
    return (
        COMPLETENESS_MAPPING.get("siteType", {})
        .get(site_type, {})
        .get(blank_node_type, {})
        .get(term_type)
        or COMPLETENESS_MAPPING.get("product.term.termType", {})
        .get(product_term_type, {})
        .get(blank_node_type, {})
        .get(term_type)
        or COMPLETENESS_MAPPING.get(blank_node_type, {}).get(term_type)
    )
