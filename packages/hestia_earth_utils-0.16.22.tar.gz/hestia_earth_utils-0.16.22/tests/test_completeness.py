import pytest

from hestia_earth.utils.completeness import blank_node_completeness_key


@pytest.mark.parametrize(
    "blank_node,product,site,expected",
    [
        (
            {"@type": "Input", "term": {"@type": "Term", "termType": "crop"}},
            {"term": {"@type": "Term", "termType": "processedFood"}},
            {"siteType": "agri-food processor"},
            "ingredient",
        ),
        (
            {"@type": "Input", "term": {"@type": "Term", "termType": "seed"}},
            {"term": {"@type": "Term", "termType": "processedFood"}},
            {"siteType": "agri-food processor"},
            "seed",
        ),
        (
            {"@type": "Product", "term": {"@type": "Term", "termType": "crop"}},
            None,
            None,
            "product",
        ),
    ],
)
def test_blank_node_completeness_key(
    blank_node: dict, product: dict, site: dict, expected: str
):
    assert blank_node_completeness_key(blank_node, product, site) == expected
