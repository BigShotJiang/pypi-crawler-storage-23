API Documentation
=================

This reference is generated from docstrings for the public API exposed in
``ipywidgets_jsonschema/__init__.py``.

.. currentmodule:: ipywidgets_jsonschema

.. autoclass:: Form
   :members:
   :show-inheritance:
   :member-order: bysource

.. autoclass:: PydanticEditorMixin
   :members:
   :show-inheritance:
   :member-order: bysource
