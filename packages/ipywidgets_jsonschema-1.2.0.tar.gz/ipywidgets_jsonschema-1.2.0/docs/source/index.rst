ipywidgets-jsonschema
=====================

Build interactive Jupyter forms directly from JSON Schema or Pydantic models.

.. toctree::
   :maxdepth: 2
   :caption: Contents

   installation
   usage-guide
   api
