Installation
============

Install from PyPI:

.. code-block:: bash

   python -m pip install ipywidgets-jsonschema

Or install from conda-forge:

.. code-block:: bash

   conda install -c conda-forge ipywidgets-jsonschema

Requirements
------------

- Python 3.8+
- Jupyter Notebook or JupyterLab
