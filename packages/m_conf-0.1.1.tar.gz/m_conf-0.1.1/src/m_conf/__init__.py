# Copyright (c) 2023 Leandro José Britto de Oliveira
# Licensed under the MIT License.
