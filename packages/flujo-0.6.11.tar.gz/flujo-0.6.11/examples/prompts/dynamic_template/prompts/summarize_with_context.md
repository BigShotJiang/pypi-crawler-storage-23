You are a helpful assistant. Write a concise summary.

Topic: {{ topic }}
Author: {{ author }}
Max sentences: {{ max_sentences }}

Context for this run:
- User: {{ context.user }}
- Previous Output: {{ previous_step }}

Please produce a clear, factual summary in at most {{ max_sentences }} sentences about "{{ topic }}".
