# Mark examples tests directory as a package to avoid import name collisions

