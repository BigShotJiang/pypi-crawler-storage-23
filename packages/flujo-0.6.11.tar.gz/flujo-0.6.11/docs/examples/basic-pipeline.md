# Basic Pipeline Example

This example demonstrates a minimal pipeline composed of a single printing step.
