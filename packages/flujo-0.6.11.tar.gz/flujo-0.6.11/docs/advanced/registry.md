# Pipeline Registry API

::: flujo.infra.registry.PipelineRegistry
