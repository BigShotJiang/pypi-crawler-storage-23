# Agentic Patterns

Discover common patterns for coordinating multiple agents within a workflow.
