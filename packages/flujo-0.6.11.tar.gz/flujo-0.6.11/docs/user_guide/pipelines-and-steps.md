# Pipelines & Steps

Learn how to build pipelines from reusable steps and run them synchronously or asynchronously.
