# minions-notes

Freeform annotations and observations attachable to any Minion

## Installation

```bash
pip install minions-notes
```

## Usage

```python
from minions_notes import create_client

client = create_client()
```

## License

[MIT](../../LICENSE)
