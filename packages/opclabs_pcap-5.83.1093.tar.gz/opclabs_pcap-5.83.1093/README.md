OpcLabs.Pcap (NuGet) / opclabs_pcap (Python)
===========================================

The OpcLabs.Pcap (NuGet) or opclabs_pcap (Python) package provides Ethernet 
(and UDP) communication features, using the PacketDotNet and SharpPcap 
libraries. Its current use is with the OpcLabs.QuickOpc / opclabs_quickopc 
package for OPC UA PubSub transport protocol mappings based on Ethernet, or 
for work with Ethernet or UDP capture files.
