"""Audit logging enums for categorizing audit events."""

from strenum import StrEnum


class AuditAction(StrEnum):
    """Actions that can be audited."""

    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    EXECUTE = "execute"
    LOGIN = "login"
    LOGOUT = "logout"
    ACCESS_DENIED = "access_denied"
    EXPORT = "export"
    IMPORT = "import"
    PARSE = "parse"
    TRAIN = "train"
    UPLOAD = "upload"
    DOWNLOAD = "download"
    RESET = "reset"
    SHARE = "share"
    AUTH = "auth"
    CLONE = "clone"
    ADD = "add"


class AuditResource(StrEnum):
    """Resource types that can be audited."""

    AGENT = "agent"
    API = "api"
    VOICE_AGENT = "voice_agent"
    TOOL = "tool"
    PROVIDER = "provider"
    SESSION = "session"
    MESSAGE = "message"
    KNOWLEDGE_BASE = "knowledge_base"
    KNOWLEDGE_BASE_CREDENTIAL = "knowledge_base_credential"
    KNOWLEDGE_GRAPH = "knowledge_graph"
    SEMANTIC_DATA_MODEL = "semantic_data_model"
    MEMORY = "memory"
    ARTIFACT = "artifact"
    WORKFLOW = "workflow"
    CREDENTIAL = "credential"
    USER = "user"
    ORGANIZATION = "organization"
    API_KEY = "api_key"
    INFERENCE = "inference"
    GUARDRAIL = "guardrail"
    RAI_POLICY = "rai_policy"
    HM_POLICY = "hm_policy"
    FOLDER = "folder"
    CONTEXT = "context"
    BLUEPRINT = "blueprint"

    # Simulation Engine specific resource types
    ENVIRONMENT = "environment"
    PERSONA = "persona"
    SCENARIO = "scenario"
    SIMULATION = "simulation"
    JOB = "job"
    EVALUATION = "evaluation"


class AuditResult(StrEnum):
    """Result of an audited action."""

    SUCCESS = "success"
    FAILURE = "failure"
    BLOCKED = "blocked"
    PARTIAL = "partial"


class AuditSeverity(StrEnum):
    """Severity level of audit events."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


# Legacy enums for backwards compatibility
class LogLevel(StrEnum):
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


class LogStatus(StrEnum):
    IN_PROGRESS = "in_progress"
    SUCCESS = "success"
    ERROR = "error"
