"""
DML Stream - Enterprise-Level Terminal-Based Video Download Solution

A production-ready, scalable, and modular YouTube downloader with advanced features
including scheduled downloads, batch processing, and real-time process monitoring.

Version 2.5.0 - 35+ CLI Commands, Enhanced Storage Management, Developer Tools

Author: DML Labs
Lead Engineer: @devmayank-official
Version: 2.5.0
License: Apache-2.0
"""

__version__ = "2.5.0"
__author__ = "DML Labs"
__email__ = "devmayank.inbox@gmail.com"
__license__ = "Apache-2.0"

# Import main components for easy access
from dml_stream.config.settings import Config
from dml_stream.core.exceptions import (
    DownloadError,
    FFmpegNotFoundError,
    InvalidURLError,
    NoStreamsFoundError,
    YouTubeDownloaderError,
)

__all__ = [
    "__version__",
    "YouTubeDownloaderError",
    "InvalidURLError",
    "DownloadError",
    "FFmpegNotFoundError",
    "NoStreamsFoundError",
    "Config",
]
