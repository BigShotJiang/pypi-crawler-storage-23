#Predict Future Stock Prices using Machine Learning

import yfinance as yf
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

data = yf.download("AAPL", start="2020-01-01", end="2024-01-01", auto_adjust=True)[['Close']]

for i in range(1, 6):
    data[f'Lag_{i}'] = data['Close'].shift(i)

data.dropna(inplace=True)

X = data.drop('Close', axis=1)
y = data['Close']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

model = LinearRegression().fit(X_train, y_train)
y_pred = model.predict(X_test)

mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, y_pred)

print("MSE:", mse)
print("RMSE:", rmse)
print("R2:", r2)

plt.figure(figsize=(10,5))
plt.plot(y_test.values)
plt.plot(y_pred)
plt.title("Actual vs Predicted")
plt.legend(["Actual", "Predicted"])
plt.show()