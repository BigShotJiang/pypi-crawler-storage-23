#Cash Flow Analysis

Formula:  
Cash inflow  =SUM(B2:B3) 
Cash Outflow  =SUM(C4:C8) 
Net Cash Flow  =B9-C9