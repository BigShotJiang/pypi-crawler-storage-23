# 1. Price Change (Daily Change)
   
=C12-C11 

#2. Gain (Only Positive Change) 

     =IF(D11>0,D11,0) 

#3. Loss (Only Negative Change, Positive Form)
 
      =IF(D12<0,ABS(D12),0)


#3. Separate Gain and Loss 

    Average Gain =AVERAGE(E11:E14) 
    Average Loss =AVERAGE(F11:F14)

# 4. Calculate Relative Strength (RS) 

RS = Average Gain / Average Loss

#6. Calculate RSI 

RSI = 100-(100/(1+RS))

