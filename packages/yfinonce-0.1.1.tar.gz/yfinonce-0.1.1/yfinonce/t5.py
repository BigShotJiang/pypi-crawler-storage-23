# SMA
#Moving Average (5 Days)
=AVERAGE(B2:B6)


#SMA (5 Days) Formula 

# In C6:
=AVERAGE(B2:B6)

# Step 2: EMA Formula (Row 7 onward)

# In D7:

=(B7-D6)*(2/(5+1))+D6