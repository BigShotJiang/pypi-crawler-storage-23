import os
from langchain.chat_models import init_chat_model
from langchain_core.prompts import PromptTemplate

os.environ["GOOGLE_API_KEY"] = "KEY"

prompt_template = PromptTemplate(
    input_variables=["pet", "color"],
    template="Suggest one name for a pet. The pet is a {color} {pet}. Give only one name.")

model = init_chat_model("google_genai:gemini-2.5-flash-lite")

chain = prompt_template | model

topic = {"pet": "dog", "color": "black"}
response = chain.invoke(topic)
formatted_prompt = prompt_template.format(**topic)

print(f"User Input: {formatted_prompt}")
print(f"AI Response: {response.content}")
