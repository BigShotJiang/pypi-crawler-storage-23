mkdir myproject
cd myproject
echo print("Hello World") > main.py

git init
git config --global user.name "Yourname"
git config --global user.email "your email"

git add .
git commit -m "first commit"
git branch -M main
git remote add origin Repo URL
git push -u origin main

echo print("Second Line Added") >> main.py

git add main.py
git commit -m "Appended new line to main.py"
git push

echo # My Project > README.md
echo. >> README.md
echo This project From python >> README.md

git add README.md
git commit -m "Add README file"
git push origin main