#  NPV & IRR

Formulas: 
NPV  =NPV(0.1,B3:B8)+B2  
IRR   =IRR(B2:B7)