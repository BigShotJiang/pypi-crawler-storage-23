# Break even Analysis

fixed_cost = float(input("Enter Fixed Cost: "))
variable_cost = float(input("Enter Variable Cost per Unit: "))
selling_price = float(input("Enter Selling Price per Unit:- "))

if selling_price <= variable_cost:
    print("Error: Selling price must be greater than variable cost to calculate break even.")
else:
    break_even_units = fixed_cost / (selling_price - variable_cost)
    print(f"\nBreak even Point: {break_even_units:.2f} units")