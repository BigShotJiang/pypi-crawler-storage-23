# Optimize an Investment Portfolio using Python (Markowitz Model) 

import numpy as np
import yfinance as yf
import matplotlib.pyplot as plt
from scipy.optimize import minimize

stocks = ['AAPL', 'MSFT', 'GOOGL', 'AMZN']
data = yf.download(stocks, start='2022-01-01', end='2024-01-01', auto_adjust=True)['Close']
returns = data.pct_change().dropna()

mu = returns.mean() * 252
cov = returns.cov() * 252
rf = 0.02
n = len(stocks)

def performance(w):
    r = np.dot(w, mu)
    s = np.sqrt(np.dot(w.T, np.dot(cov, w)))
    return r, s

def min_var(w):
    return performance(w)[1]

def neg_sharpe(w):
    r, s = performance(w)
    return -(r - rf) / s

cons = {'type': 'eq', 'fun': lambda w: np.sum(w) - 1}
bounds = [(0, 1)] * n
w0 = [1/n] * n

min_var_res = minimize(min_var, w0, bounds=bounds, constraints=cons)
max_sharpe_res = minimize(neg_sharpe, w0, bounds=bounds, constraints=cons)

print("Min Variance:", dict(zip(stocks, min_var_res.x.round(4))))
print("Max Sharpe:", dict(zip(stocks, max_sharpe_res.x.round(4))))

results = []
for _ in range(3000):
    w = np.random.random(n)
    w /= np.sum(w)
    r, s = performance(w)
    results.append([s, r])

results = np.array(results)

plt.scatter(results[:,0], results[:,1], c=results[:,1]/results[:,0], cmap='viridis')
plt.xlabel("Risk")
plt.ylabel("Return")
plt.title("Efficient Frontier")
plt.show()