import asyncio
import logging
import os
import threading
from typing import Optional

import langchain_gigachat.embeddings.gigachat
from langchain_gigachat import GigaChatEmbeddings
from langchain_gigachat.chat_models import GigaChat
from pydantic import PrivateAttr

from agent_lab_sdk.core.settings import settings
from agent_lab_sdk.llm.limiting import Limiting
from agent_lab_sdk.llm.managers.ags_token_manager import AgsTokenManager

logger = logging.getLogger(__name__)

langchain_gigachat.embeddings.gigachat.MAX_BATCH_SIZE_PARTS=int(os.getenv("EMBEDDINGS_MAX_BATCH_SIZE_PARTS", "90"))

MAX_CHAT_CONCURRENCY = int(os.getenv("MAX_CHAT_CONCURRENCY", "100000"))
MAX_EMBED_CONCURRENCY = int(os.getenv("MAX_EMBED_CONCURRENCY", "100000"))


from agent_lab_sdk.metrics import get_metric
from agent_lab_sdk.llm.gigachat_token_manager import GigaChatTokenManager
from agent_lab_sdk.llm.token_manager_utils import build_token_manager_kwargs
from agent_lab_sdk.llm.retry_utils import (
    RetryConfig,
    maybe_retry_async,
    maybe_retry_sync,
    normalize_retry_config,
)

def create_metrics(prefix: str):
    in_use = get_metric(
        metric_type = "gauge", name = f"{prefix}_slots_in_use",
        documentation = f"Number of {prefix} slots currently in use"
    )
    waiting = get_metric(
        metric_type = "gauge", name = f"{prefix}_waiting_tasks",
        documentation = f"Number of tasks waiting for {prefix}"
    )
    wait_time = get_metric(
        metric_type = "histogram", name = f"{prefix}_wait_time_seconds",
        documentation = f"Time tasks wait for {prefix}",
        buckets = [3, 5, 10, 15, 30, 60, 120, 240, 480, 960, 1920, float("inf")]
    )

    return in_use, waiting, wait_time

chat_in_use, chat_waiting, chat_wait_hist = create_metrics("chat")
embed_in_use, embed_waiting, embed_wait_hist = create_metrics("embed")

def _resolve_token_kwargs(model, credential_id, use_ags, kwargs, token_manager_kwargs) -> dict:
    new_kwargs = dict(kwargs)
    if use_ags:
        ags_info = AgsTokenManager.get_token_by_env(model, credential_id)
        new_kwargs["base_url"] = ags_info.metadata["baseUrl"]
        new_kwargs["scope"] = ags_info.metadata["scope"]
        new_kwargs["access_token"] = ags_info.token
    else:
        token = GigaChatTokenManager.get_token(**token_manager_kwargs)
        new_kwargs["access_token"] = token
    return new_kwargs

class UnifiedSemaphore:
    """Threading-based семафор + sync/async API + metrics + контекстники."""
    def __init__(self, limit):
        self._sem       = threading.Semaphore(limit)
        self._limit     = limit

    # ——— синхронный API ———
    def acquire(self):
        self._sem.acquire()

    def release(self):
        self._sem.release()

    # ——— асинхронный API ———
    async def acquire_async(self):
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self._sem.acquire)

    async def release_async(self):
        # release очень быстрый
        self._sem.release()

# Semaphores for chat and embeddings
_semaphores = {
    "chat": Limiting(UnifiedSemaphore(MAX_CHAT_CONCURRENCY), "chat", chat_in_use, chat_waiting, chat_wait_hist),
    "embed": Limiting(UnifiedSemaphore(MAX_EMBED_CONCURRENCY), "embed", embed_in_use, embed_waiting, embed_wait_hist),
}

class ThrottledGigaChatEmbeddings(GigaChatEmbeddings):
    _manage_access_token: bool = PrivateAttr(default=True)
    _retry_enabled: bool = PrivateAttr(default=False)
    _base_kwargs: dict = PrivateAttr(default={})
    _token_manager_kwargs: dict = PrivateAttr(default={})
    _retry_config: Optional[RetryConfig] = PrivateAttr(default=None)

    def __init__(
        self,
        *args,
        manage_access_token=True,
        retry=False,
        token_manager_kwargs=None,
        retry_attempts_count=None,
        retry_config=None,
        credential_id=None,
        **kwargs,
    ):
        if retry and retry_config is None and retry_attempts_count is None:
            retry_attempts_count = 3
        token_manager_kwargs = build_token_manager_kwargs(kwargs, token_manager_kwargs)
        gigachat_credential_id = credential_id if credential_id is not None else settings.GIGACHAT_CREDENTIAL_ID
        model = kwargs.get("model") or settings.GIGACHAT_MODEL
        use_token_provider_ags = token_manager_kwargs.get("use_ags_token") or settings.USE_TOKEN_PROVIDER_AGS

        if manage_access_token and "access_token" not in kwargs:
            new_kwargs = _resolve_token_kwargs(
                model, gigachat_credential_id, use_token_provider_ags, kwargs, token_manager_kwargs
            )
            super().__init__(**new_kwargs)
        else:
            super().__init__(**kwargs)

        self._manage_access_token = manage_access_token
        self._retry_enabled = bool(retry)
        self._base_kwargs = dict(kwargs)
        self._token_manager_kwargs = dict(token_manager_kwargs)
        self._retry_config = (
            normalize_retry_config(retry_config, retry_attempts_count) if retry else None
        )
        self._gigachat_credential_id = gigachat_credential_id
        self._model = model
        self._use_token_provider_ags = use_token_provider_ags


    def _fresh(self) -> GigaChatEmbeddings:
        if self._manage_access_token:
            new_kwargs = _resolve_token_kwargs(
                self._model,
                self._gigachat_credential_id,
                self._use_token_provider_ags,
                self._base_kwargs,
                self._token_manager_kwargs
            )
            return GigaChatEmbeddings(**new_kwargs)
        else:    
            # возвращаем proxy объект чтобы не ломать цепочку наследования
            return super(ThrottledGigaChatEmbeddings, self)


    def embed_documents(self, *args, **kwargs):
        with _semaphores["embed"].acquire(self._model, self._gigachat_credential_id):
            return maybe_retry_sync(
                self._retry_enabled,
                self._retry_config,
                lambda: self._fresh().embed_documents(*args, **kwargs),
            )

    def embed_query(self, *args, **kwargs):
        with _semaphores["embed"].acquire(self._model, self._gigachat_credential_id):
            return maybe_retry_sync(
                self._retry_enabled,
                self._retry_config,
                lambda: self._fresh().embed_query(*args, **kwargs),
            )

    async def aembed_documents(self, *args, **kwargs):
        async with _semaphores["embed"].acquire_async(self._model, self._gigachat_credential_id):
            return await maybe_retry_async(
                self._retry_enabled,
                self._retry_config,
                lambda: self._fresh().aembed_documents(*args, **kwargs),
            )

    async def aembed_query(self, *args, **kwargs):
        async with _semaphores["embed"].acquire_async(self._model, self._gigachat_credential_id):
            return await maybe_retry_async(
                self._retry_enabled,
                self._retry_config,
                lambda: self._fresh().aembed_query(*args, **kwargs),
            )

class ThrottledGigaChat(GigaChat):
    _manage_access_token: bool = PrivateAttr(default=True)
    _retry_enabled: bool = PrivateAttr(default=False)
    _base_kwargs: dict = PrivateAttr(default={})
    _token_manager_kwargs: dict = PrivateAttr(default={})
    _retry_config: Optional[RetryConfig] = PrivateAttr(default=None)

    def __init__(
        self,
        *args,
        manage_access_token=True,
        retry=False,
        token_manager_kwargs=None,
        retry_attempts_count=None,
        retry_config=None,
        credential_id=None,
        **kwargs,
    ):
        if retry and retry_config is None and retry_attempts_count is None:
            retry_attempts_count = 3
        token_manager_kwargs = build_token_manager_kwargs(kwargs, token_manager_kwargs)
        gigachat_credential_id = credential_id if credential_id is not None else settings.GIGACHAT_CREDENTIAL_ID
        model = kwargs.get("model") or settings.GIGACHAT_MODEL
        use_token_provider_ags = token_manager_kwargs.get("use_ags_token") or settings.USE_TOKEN_PROVIDER_AGS

        if manage_access_token and "access_token" not in kwargs:
            new_kwargs = _resolve_token_kwargs(
                model, gigachat_credential_id, use_token_provider_ags, kwargs, token_manager_kwargs
            )
            super().__init__(**new_kwargs)
        else:
            super().__init__(**kwargs)

        self._manage_access_token = manage_access_token
        self._retry_enabled = bool(retry)
        self._base_kwargs = dict(kwargs)
        self._token_manager_kwargs = dict(token_manager_kwargs)
        self._retry_config = (
            normalize_retry_config(retry_config, retry_attempts_count) if retry else None
        )
        self._gigachat_credential_id = gigachat_credential_id
        self._model = model
        self._use_token_provider_ags = use_token_provider_ags

    def _fresh(self) -> GigaChat:
        if self._manage_access_token:
            new_kwargs = _resolve_token_kwargs(
                self._model,
                self._gigachat_credential_id,
                self._use_token_provider_ags,
                self._base_kwargs,
                self._token_manager_kwargs
            )
            new_gigachat = GigaChat(**new_kwargs)
            # это поле которое управляется классом BaseChatModel, по другому его пока никак не прокинуть
            new_gigachat.disable_streaming = self.disable_streaming
            return new_gigachat
        else:    
            # возвращаем proxy объект чтобы не ломать цепочку наследования
            return super(ThrottledGigaChat, self)

    def invoke(self, *args, **kwargs):
        with _semaphores["chat"].acquire(self._model, self._gigachat_credential_id):
            return maybe_retry_sync(
                self._retry_enabled,
                self._retry_config,
                lambda: self._fresh().invoke(*args, **kwargs),
            )

    async def ainvoke(self, *args, **kwargs):
        async with _semaphores["chat"].acquire_async(self._model, self._gigachat_credential_id):
            return await maybe_retry_async(
                self._retry_enabled,
                self._retry_config,
                lambda: self._fresh().ainvoke(*args, **kwargs),
            )

    def stream(self, *args, **kwargs):
        with _semaphores["chat"].acquire(self._model, self._gigachat_credential_id):
            for chunk in self._fresh().stream(*args, **kwargs):
                yield chunk

    async def astream(self, *args, **kwargs):
        async with _semaphores["chat"].acquire_async(self._model, self._gigachat_credential_id):
            async for chunk in self._fresh().astream(*args, **kwargs):
                yield chunk

    async def astream_events(self, *args, **kwargs):
        async with _semaphores["chat"].acquire_async(self._model, self._gigachat_credential_id):
            async for ev in self._fresh().astream_events(*args, **kwargs):
                yield ev

    def batch(self, *args, **kwargs):
        with _semaphores["chat"].acquire(self._model, self._gigachat_credential_id):
            return maybe_retry_sync(
                self._retry_enabled,
                self._retry_config,
                lambda: self._fresh().batch(*args, **kwargs),
            )

    async def abatch(self, *args, **kwargs):
        async with _semaphores["chat"].acquire_async(self._model, self._gigachat_credential_id):
            return await maybe_retry_async(
                self._retry_enabled,
                self._retry_config,
                lambda: self._fresh().abatch(*args, **kwargs),
            )
        
    def upload_file(self, *args, **kwargs):
        with _semaphores["chat"].acquire(self._model, self._gigachat_credential_id):
            return maybe_retry_sync(
                self._retry_enabled,
                self._retry_config,
                lambda: self._fresh().upload_file(*args, **kwargs),
            )

    async def aupload_file(self, *args, **kwargs):
        async with _semaphores["chat"].acquire_async(self._model, self._gigachat_credential_id):
            return await maybe_retry_async(
                self._retry_enabled,
                self._retry_config,
                lambda: self._fresh().aupload_file(*args, **kwargs),
            )

    def batch_as_completed(self, *args, **kwargs):
        with _semaphores["chat"].acquire(self._model, self._gigachat_credential_id):
            for item in self._fresh().batch_as_completed(*args, **kwargs):
                yield item

    async def abatch_as_completed(self, *args, **kwargs):
        async with _semaphores["chat"].acquire_async(self._model, self._gigachat_credential_id):
            async for item in self._fresh().abatch_as_completed(*args, **kwargs):
                yield item
