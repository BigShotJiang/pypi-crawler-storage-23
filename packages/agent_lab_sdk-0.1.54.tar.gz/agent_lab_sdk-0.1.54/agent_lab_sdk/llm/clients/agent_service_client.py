import logging
from urllib.parse import urljoin

import httpx
from httpx import HTTPTransport

from agent_lab_sdk.core.settings import settings, ENV_PREFIX

logger = logging.getLogger(__name__)


class AgentServiceClient:
    def __init__(self):
        self._client = None
        self.base_url = settings.AGENT_SERVICE_URL
        self.timeout = settings.AGENT_SERVICE_TIMEOUT
        self.retry_attempts = settings.AGENT_SERVICE_RETRY_ATTEMPTS
        self.version_prefix = settings.AGENT_SERVICE_VERSION_PREFIX

    def _get_client(self) -> httpx.Client:
        if not settings.AGENT_SERVICE_ENABLED:
            raise RuntimeError(f"{ENV_PREFIX}AGENT_SERVICE_ENABLED set to false")
        if self._client is None:
            transport = HTTPTransport(retries=self.retry_attempts)
            self._client = httpx.Client(
                timeout=httpx.Timeout(self.timeout),
                follow_redirects=True,
                transport=transport,
            )
        return self._client

    def close(self):
        if self._client is not None:
            self._client.close()
            self._client = None

    def get_token(self, agent_id: str, credential_id: str) -> dict | None:
        if settings.AGENT_SERVICE_TOKEN is None:
            raise ValueError(f"Переменная окружения {ENV_PREFIX}AGENT_SERVICE_TOKEN не установлена.")
        try:
            client = self._get_client()
            url = urljoin(self.base_url, f"{self.version_prefix}/token-manager/token")
            body = {
                "agentServiceName": agent_id,
                "credentialId": credential_id,
            }
            headers = {
                "Authorization": f"Bearer {settings.AGENT_SERVICE_TOKEN}"
            }
            try:
                response = client.post(url, headers=headers, json=body)
                response.raise_for_status()
            except httpx.HTTPStatusError as exc:
                logger.exception(f"resp body: {exc.response.text}")
                raise
            return response.json()
        except Exception:
            logger.exception(f"Failed to get token info agent_id={agent_id}, credential_id={credential_id}")
            raise

agent_service_client = AgentServiceClient()
