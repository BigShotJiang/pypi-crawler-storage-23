# cctext

[![PyPI version](https://badge.fury.io/py/cctext.svg)](https://badge.fury.io/py/cctext)

Python library for russian natural language. Allows inflecting complex terms and resolving special syntax references to other entities.
Based on [pymorphy3](https://github.com/no-plagiarism/pymorphy3)

This library lacks user documentation. Example use cases can be found in tests folder.
