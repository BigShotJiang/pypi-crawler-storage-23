#!/usr/bin/env python3
import os
import requests
import argparse
from rich import print
# ------------------ RISK ENGINE ------------------
def classify_risk(malicious_count):
    if malicious_count == 0:
        return "SAFE"
    elif 1 <= malicious_count <= 2:
        return "LOW RISK"
    elif 3 <= malicious_count <= 5:
        return "SUSPICIOUS"
    else:
        return "HIGH RISK"

# ------------------ URL SCANNER ------------------
def scan_url(url, api_key):
    if not api_key:
        print("[red]Error:[/red] VT_API_KEY not set.")
        return

    print(f"[cyan]Scanning URL:[/cyan] {url}")

    # submit URL
    resp = requests.post(
        "https://www.virustotal.com/api/v3/urls",
        headers={"x-apikey": api_key},
        data={"url": url}
    )

    if resp.status_code != 200:
        print(f"[red]Error submitting URL: {resp.text}[/red]")
        return

    analysis_id = resp.json()["data"]["id"]

    # get report
    report = requests.get(
        f"https://www.virustotal.com/api/v3/analyses/{analysis_id}",
        headers={"x-apikey": api_key}
    )

    if report.status_code != 200:
        print(f"[red]Error fetching report: {report.text}[/red]")
        return

    stats = report.json()["data"]["attributes"]["stats"]
    risk = classify_risk(stats.get("malicious", 0))
    print(f"[bold]Malicious:[/bold] {stats.get('malicious',0)} | Risk: {risk}")

# ------------------ FILE SCANNER ------------------
def scan_file(filepath, api_key):
    if not api_key:
        print("[red]Error:[/red] VT_API_KEY not set.")
        return
    if not os.path.exists(filepath):
        print(f"[red]Error:[/red] File not found: {filepath}")
        return

    print(f"[cyan]Scanning File:[/cyan] {filepath}")

    with open(filepath, "rb") as f:
        files = {"file": f}
        resp = requests.post(
            "https://www.virustotal.com/api/v3/files",
            headers={"x-apikey": api_key},
            files=files
        )

    if resp.status_code != 200:
        print(f"[red]Error uploading file: {resp.text}[/red]")
        return

    analysis_id = resp.json()["data"]["id"]

    report = requests.get(
        f"https://www.virustotal.com/api/v3/analyses/{analysis_id}",
        headers={"x-apikey": api_key}
    )

    if report.status_code != 200:
        print(f"[red]Error fetching report: {report.text}[/red]")
        return

    stats = report.json()["data"]["attributes"]["stats"]
    risk = classify_risk(stats.get("malicious", 0))
    print(f"[bold]Malicious:[/bold] {stats.get('malicious',0)} | Risk: {risk}")

# ------------------ MAIN CLI ------------------
def main():
    parser = argparse.ArgumentParser(description="VirusTotal URL/File Scanner")
    parser.add_argument("--url", help="Scan a URL for phishing/malware")
    parser.add_argument("--file", help="Scan a file for malware")
    args = parser.parse_args()

    api_key = "5ca6f006544e46c5dd85b10def7d5fc0bb5dd0c91e02e01b43c77894dc0ad6e7"

    if args.url:
        scan_url(args.url, api_key)
    elif args.file:
        scan_file(args.file, api_key)
    else:
        print("⚠ Please provide --url or --file to scan.")

if __name__ == "__main__":
    main()