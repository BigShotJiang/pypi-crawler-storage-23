# SAMBA_ilum Copyright (C) 2025-2026
# GNU GPL-3.0 license

import os
import re

if os.path.exists('magmom.txt'):
    #---------------------
    new_magmom_line = None
    with open('magmom.txt', 'r') as f:
        for line in f:
            if re.match(r'^\s*MAGMOM\s*=', line):
                new_magmom_line = line.strip()
                break
    #------------------
    if new_magmom_line:
        new_elements = new_magmom_line.replace("=", " = ").split()
        new_count = len(new_elements[new_elements.index('=') + 1:])
        #--------------------------
        if os.path.exists('INCAR'):
            with open('INCAR', 'r') as f: incar_lines = f.readlines()
            #-------------------------
            updated_incar_content = []
            should_write = False
            #----------------------
            for line in incar_lines:
                stripped_line = line.strip()
                if stripped_line == "# MAGNETIC" or stripped_line.replace(" ", "").upper() == "NUPDOWN=0":
                    updated_incar_content.append(new_magmom_line + '\n')
                    should_write = True
                #--------------------------------------                
                elif re.match(r'^\s*MAGMOM\s*=', line):
                    existing_line = line.strip().replace("=", " = ")
                    existing_elements = existing_line.split()
                    #----------------------------------------
                    try:
                        eq_index = existing_elements.index('=')
                        existing_count = len(existing_elements[eq_index + 1:])
                        #-----------------------------------------------------
                        if existing_count == new_count:
                            updated_incar_content.append(new_magmom_line + '\n')
                            should_write = True
                        else: updated_incar_content.append(line)
                    except ValueError: updated_incar_content.append(line)
                #--------------------------------------------------------
                else: updated_incar_content.append(line)
            #---------------
            if should_write:
                with open('INCAR', 'w') as f: f.writelines(updated_incar_content)
