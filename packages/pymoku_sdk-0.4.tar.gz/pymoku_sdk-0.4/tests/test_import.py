
def test_import():
    """ Absolute bare minimum: can we import without error """
    from pymoku import sdk  # noqa
