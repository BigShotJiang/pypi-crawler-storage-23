import jsonrpcserver as rpc


@rpc.method
def get_reg0({{name.lower()}}):
    return {{name.lower()}}.reg0


@rpc.method
def get_reg1({{name.lower()}}):
    return {{name.lower()}}.reg1
