from pymoku.applets.default import DefaultFrame


class {{name}}Frame(DefaultFrame):
    def add_widgets(self, moku, slot_inst):
        super().add_widgets(moku, slot_inst)

