from pymoku import Slot


class {{top_entity}}(Slot):
    def init_regs(self, **kwargs):
        self.reg0 = self.reg_unsg(0)
        self.reg1 = self.reg_unsg(1)
