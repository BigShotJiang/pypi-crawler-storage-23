import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge
from {{name}} import {{top_entity}}


CLK_FREQ = 312.5e6


async def init(dut):
    """ Ideally this would be a test fixture hidden away in lib/
    """
    cocotb.start_soon(Clock(dut.Clk, round(1e9 / CLK_FREQ), units='ns').start())
    dut.Reset.value = 1
    await ClockCycles(dut.Clk, 10)
    await RisingEdge(dut.Clk)
    dut.Reset.value = 0

    return {{top_entity}}(dut)


@cocotb.test(timeout_time=100, timeout_unit='us')
async def test_one(dut):
    {{name}}_inst = await init(dut)

    {{name}}_inst.reg0 = 0xDEADBEEF
    {{name}}_inst.reg1 = 0xCAFEBABE
    await {{name}}_inst.apply()  # async wait for the SPI bus

    await ClockCycles(dut.Clk, 100)
