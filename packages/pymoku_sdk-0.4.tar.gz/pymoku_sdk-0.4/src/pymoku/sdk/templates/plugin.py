from .{{name.lower()}} import {{top_entity}}
try:
    from .applet import {{name}}Frame
except ImportError:
    # the plugin should still work without all the GUI dependencies
    # note that we can't defer imports in a plugin
    pass


class Plugin:
    def get_name(self, _id):
        """ An identifiable name for this slot based on it's id
        """
        if len(_id.split(':')) > 2:
            return f"{{name}} {_id.split(':')[-1].title()}"

        return f"{{name}}"

    def attach(self, moku, manifest):
        """ Create an instance of this slot, attached to the given slot and moku
        """
        return {{top_entity}}(moku, manifest['slot'])

    def applet_frame(self):
        """ Create a DefaultFrame instance for this slot
        """
        return {{name}}Frame
