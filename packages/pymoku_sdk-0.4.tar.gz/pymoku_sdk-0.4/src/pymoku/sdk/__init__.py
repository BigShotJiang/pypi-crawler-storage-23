try:
    import setuptools_scm
    SCM_VERSION = setuptools_scm.get_version()
except ImportError:
    SCM_VERSION = ''

FIRMWARE_VERSION = 616


from .vivado import *  # noqa
from .manifests import *  # noqa
from .barfile import *  # noqa
from .cocotb import *  # noqa
from .checkpoints import *  # noqa


def generate_slot_bitstreams(platform, synth,
                             constraints='support-slot-constraints',
                             route_tcl='support-slot-route-tcl',
                             bitstream_tcl='support-slot-bitstream-tcl',
                             reports_tcl='support-slot-reports-tcl'):
    """
    There is a distinction between arbitrary RMs and Slot RMs, in that Slot RMs are
    expected to be implemented within the group of Slots defined as "Instruments",
    whereas any RM can be implemented within any Slot as long as it meets the
    interface.

    This API simply provides a shortcut to the common case of "Instruments".
    """

    routes = [RMRoute(synth, shell, route_tcl=route_tcl, constraints=constraints) for shell in platform.slot_shells()]
    rms = [RMInstance(route, bitstream_tcl=bitstream_tcl, reports_tcl=reports_tcl) for route in routes]
    return rms


def generate_slot_manifests(platform, synth, manifest_id,
                            constraints='support-slot-constraints',
                            route_tcl='support-slot-route-tcl',
                            bitstream_tcl='support-slot-bitstream-tcl',
                            reports_tcl='support-slot-reports-tcl'):
    rms = generate_slot_bitstreams(platform, synth,
                                   constraints=constraints,
                                   route_tcl=route_tcl,
                                   bitstream_tcl=bitstream_tcl,
                                   reports_tcl=reports_tcl)
    manifests = [Manifest(manifest_id, rm) for rm in rms]
    return manifests


def include_support():
    import pymoku.sdk  # noqa
    import shutil  # noqa
    from pymoku.parts import include, ConfigGlobals  # noqa
    from importlib import resources  # noqa

    support_path = ConfigGlobals.build_path / 'support'
    if not support_path.exists():
        with resources.path(pymoku.sdk, 'support') as support_res:
            print(support_res, support_path)
            shutil.copytree(support_res, support_path)
    include(support_path, prefix='support')
