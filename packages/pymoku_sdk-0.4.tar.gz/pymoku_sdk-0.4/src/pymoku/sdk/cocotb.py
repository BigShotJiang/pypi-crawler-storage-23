from pymoku.parts import DockerStep, link


class CocoTB(DockerStep):
    def __init__(self, name, top, sources, python, generics={}, *args, **kwargs):
        generics_str = ' '.join([f'{k}={str(v).lower()}' for k, v in generics.items()])

        extra_env = dict(
            TEST_TOP=top.lower(),
            TEST_MODULE=python,
            TEST_GENERICS=generics_str,
        )

        super().__init__('li-cocotb-pymoku',
                         name=name,
                         extra_env=extra_env,
                         **kwargs)
        self.depends_on(link('support-sim-python', self.workdir))
        self.depends_on(link('support-slot-vhdl', self.workdir / 'support-vhdl'))
        self.depends_on(link(sources, self.workdir))
        self.creates('wave.ghw')

    def command(self):
        return 'pytest -vs cocotb_test.py'


class CocoTBLib(DockerStep):
    def __init__(self, name, sources):
        super().__init__('li-cocotb-pymoku', name=name)
        self.depends_on(link(sources, self.workdir))
        self.creates(f'{self.name}-obj08.cf')
        self.creates(s.path.name for s in sources)
        self.sources = sources

    def command(self):
        cmd = f"ghdl -a --work={self.name} "
        cmd += "--std=08 --ieee=synopsys -frelaxed-rules -P/unisim "
        cmd += " ".join(s.path.name for s in self.sources)
        return cmd
