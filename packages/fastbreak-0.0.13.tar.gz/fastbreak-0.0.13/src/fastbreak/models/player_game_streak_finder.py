"""Models for the Player Game Streak Finder endpoint response."""

from pydantic import BaseModel, Field, model_validator

from fastbreak.models.common.dataframe import PandasMixin, PolarsMixin
from fastbreak.models.common.response import FrozenResponse
from fastbreak.models.common.result_set import named_result_sets_validator


class PlayerGameStreak(PandasMixin, PolarsMixin, BaseModel):
    """A player's consecutive game streak information.

    Contains details about the longest or current game streak.
    """

    player_name: str = Field(alias="PLAYER_NAME_LAST_FIRST")
    player_id: int = Field(alias="PLAYER_ID")
    game_streak: int = Field(alias="GAMESTREAK")
    start_date: str = Field(alias="STARTDATE")
    end_date: str = Field(alias="ENDDATE")
    active_streak: int = Field(alias="ACTIVESTREAK")
    num_seasons: int = Field(alias="NUMSEASONS")
    last_season: str = Field(alias="LASTSEASON")
    first_season: str = Field(alias="FIRSTSEASON")


class PlayerGameStreakFinderResponse(FrozenResponse):
    """Response from the player game streak finder endpoint.

    Contains game streak information for a player.
    """

    streaks: list[PlayerGameStreak] = Field(default_factory=list)

    from_result_sets = model_validator(mode="before")(
        named_result_sets_validator({"streaks": "PlayerGameStreakFinderResults"})
    )
