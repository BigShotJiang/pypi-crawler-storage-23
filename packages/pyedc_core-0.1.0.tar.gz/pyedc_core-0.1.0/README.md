# pyedc-core

Reusable JSON-LD helpers, middleware, API clients, and FastAPI app factory utilities shared across the EDC data plane services.

## Components

- `pyedc_core.middleware.JsonLDMiddleware`: transparently expands inbound JSON-LD requests and compacts outbound responses for FastAPI/Starlette apps.
- `pyedc_core.services.JsonLdApiClient`: lightweight HTTP client built on `httpx` that compacts outgoing JSON-LD payloads (so APIs receive the compacted form they expect) and expands responses back into canonical JSON-LD structures.
- `pyedc_core.services.VaultClient`: helper around `hvac.Client` with convenience methods needed by the orchestrator module.
