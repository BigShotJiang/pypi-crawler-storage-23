#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

import hvac
from typing import Dict, List, Optional
from hvac import exceptions as hvac_exceptions


class VaultClient:
    """Thin wrapper around `hvac.Client` with convenience helpers."""

    def __init__(self, url: str, token: Optional[str] = None, verify: bool = True):
        self._url = url
        self._verify = verify
        self._client = hvac.Client(url=url, token=token, verify=verify)

    @property
    def token(self) -> Optional[str]:
        return self._client.token

    def with_token(self, token: str) -> "VaultClient":
        return VaultClient(url=self._url, token=token, verify=self._verify)

    def is_initialized(self) -> bool:
        return self._client.sys.is_initialized()

    def is_sealed(self) -> bool:
        status = self._client.sys.read_seal_status()
        return bool(status.get("sealed", False))

    def operator_init(self, shares: int, threshold: int) -> Dict[str, List[str]]:
        return self._client.sys.initialize(secret_shares=shares, secret_threshold=threshold)

    def operator_unseal(self, key: str) -> Dict[str, str]:
        return self._client.sys.submit_unseal_key(key)

    def ensure_policy(self, name: str, rules: str) -> None:
        self._client.sys.create_or_update_policy(name=name, policy=rules)

    def ensure_kv_engine(self, mount_point: str, version: int = 2, description: Optional[str] = None) -> None:
        mounts = self._client.sys.list_mounted_secrets_engines()["data"]  # type: ignore[index]
        mount = f"{mount_point}/"
        if mount in mounts:
            return
        tune = {"version": str(version)} if version else None
        self._client.sys.enable_secrets_engine(  # type: ignore[attr-defined]
            backend_type="kv",
            path=mount_point,
            description=description,
            options=tune,
        )

    def read_secret(self, mount_point: str, path: str) -> Optional[Dict[str, str]]:
        try:
            response = self._client.secrets.kv.v2.read_secret_version(  # type: ignore[attr-defined]
                path=path,
                mount_point=mount_point,
            )
            return response["data"]["data"]  # type: ignore[index]
        except hvac_exceptions.InvalidPath:
            return None

    def write_secret(self, mount_point: str, path: str, data: Dict[str, str]) -> None:
        self._client.secrets.kv.v2.create_or_update_secret(  # type: ignore[attr-defined]
            mount_point=mount_point,
            path=path,
            secret=data,
        )

    def create_token(
        self,
        policies: List[str],
        ttl: Optional[str] = None,
        renewable: bool = False,
    ) -> str:
        response = self._client.auth.token.create(
            policies=policies,
            ttl=ttl,
            renewable=renewable,
        )
        return response["auth"]["client_token"]  # type: ignore[index]
