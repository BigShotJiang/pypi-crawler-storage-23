#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, MutableMapping, Optional, Union

import httpx

from pyedc_core.utils.json_ld_transformer import JsonLdTransformer


JsonContext = Union[Dict[str, Any], list[Any], None]


@dataclass
class JsonLdApiResponse:
    """Wrapper around an HTTP response that also exposes JSON/JSON-LD bodies."""

    response: httpx.Response
    json_body: Any
    jsonld_body: Any

    @property
    def status_code(self) -> int:
        return self.response.status_code

    @property
    def headers(self) -> httpx.Headers:
        return self.response.headers

    def raise_for_status(self) -> "JsonLdApiResponse":
        self.response.raise_for_status()
        return self


class JsonLdApiClient:
    """HTTP client wrapper that compacts outbound and expands inbound JSON-LD payloads."""

    def __init__(
        self,
        *,
        base_url: Optional[str] = None,
        client: Optional[httpx.Client] = None,
        transformer: Optional[JsonLdTransformer] = None,
        scope: str = JsonLdTransformer.DEFAULT_SCOPE,
        default_headers: Optional[Mapping[str, str]] = None,
    ):
        if not client and not base_url:
            raise ValueError("Provide either an httpx.Client or a base_url.")
        self._client = client or httpx.Client(base_url=base_url)
        self._owns_client = client is None
        self.transformer = transformer or JsonLdTransformer()
        self.scope = scope
        self.default_headers: Dict[str, str] = dict(default_headers or {})

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> "JsonLdApiClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def request(
        self,
        method: str,
        url: str,
        *,
        jsonld: Optional[Dict[str, Any]] = None,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
        scope: Optional[str] = None,
        context_override: JsonContext = None,
        expand_response: bool = True,
        raise_for_status: bool = True,
        **kwargs: Any,
    ) -> JsonLdApiResponse:
        """Send an HTTP request, automatically compacting/expanding JSON-LD payloads."""
        payload = None
        if jsonld is not None:
            payload = self.transformer.compact(
                jsonld,
                scope=scope or self.scope,
                context_override=context_override,
            )
        merged_headers = self._merge_headers(headers, has_json_payload=payload is not None)
        response = self._client.request(
            method=method,
            url=url,
            params=params,
            json=payload,
            headers=merged_headers,
            **kwargs,
        )
        if raise_for_status:
            response.raise_for_status()
        json_body: Any = None
        expanded: Any = None
        try:
            json_body = response.json()
        except ValueError:
            return JsonLdApiResponse(response=response, json_body=None, jsonld_body=None)
        if expand_response:
            if isinstance(json_body, MutableMapping):
                expanded = self.transformer.expand(json_body)
            elif isinstance(json_body, list):
                expanded = [
                    self.transformer.expand(item) if isinstance(item, MutableMapping) else item
                    for item in json_body
                ]
        return JsonLdApiResponse(response=response, json_body=json_body, jsonld_body=expanded)

    def _merge_headers(self, headers: Optional[Mapping[str, str]], *, has_json_payload: bool) -> Dict[str, str]:
        merged = dict(self.default_headers)
        if headers:
            merged.update(headers)
        if has_json_payload and "content-type" not in {key.lower() for key in merged}:
            merged.setdefault("Content-Type", "application/json")
        return merged
