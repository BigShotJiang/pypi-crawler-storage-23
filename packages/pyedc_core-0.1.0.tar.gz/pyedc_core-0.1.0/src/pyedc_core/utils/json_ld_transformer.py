#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

from __future__ import annotations

import json
import logging
import re
import urllib.request
import zipfile
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, MutableMapping, Optional, Sequence, Union
from urllib.parse import urlsplit

from pyld import jsonld
from pyld.jsonld import JsonLdError

from pyedc_core.utils.constants import CoreConstants

class JsonLdKeywords:
    CONTEXT = "@context"
    VOCAB = "@vocab"


@dataclass
class JsonLdConfiguration:
    """
    JsonLd Transformer config

    Attributes:
        check_prefixes: If True, prefix usage inside the JSON structure is validated.
        avoid_vocab: If True, `@vocab` is never auto-registered as a namespace alias.
        http_enabled/https_enabled/file_enabled/jar_enabled: Toggle which URI schemes
            may be dereferenced by the document loader.
        document_loader_timeout: Timeout (seconds) passed to urllib when fetching HTTP(S) contexts.
    """

    check_prefixes: bool = False
    avoid_vocab: bool = False
    http_enabled: bool = True
    https_enabled: bool = True
    file_enabled: bool = True
    jar_enabled: bool = True
    document_loader_timeout: int = 10


class PrefixValidationError(Exception):
    """Raised when unknown prefixes are found during validation."""


class JsonLdTransformer:
    """
    High-level helper for expanding/compacting JSON-LD documents with EDC defaults.


    """

    DEFAULT_SCOPE = "*"
    _PREFIX_PATTERN = re.compile(r"^([^:@]+):")

    def __init__(self, monitor: Optional[logging.Logger] = None, configuration: Optional[JsonLdConfiguration] = None):
        self.monitor = monitor or logging.getLogger(__name__)
        self.configuration = configuration or JsonLdConfiguration()
        self.document_loader = CachedDocumentLoader(self.configuration, self.monitor)
        self.should_check_prefixes = self.configuration.check_prefixes
        self.avoid_vocab = self.configuration.avoid_vocab
        self.scoped_namespaces: Dict[str, OrderedDict[str, str]] = {}
        self.scoped_contexts: Dict[str, OrderedDict[str, None]] = {}

    def expand(self, json_object: Dict[str, Any]) -> Dict[str, Any]:
        """
        Expands the provided JSON-LD document using pyld.

        Returns:
            The first expanded node.
        Raises:
            JsonLdError if expansion fails or no expanded nodes are produced.
        """
        try:
            document = self._inject_vocab(json_object)
            expanded = jsonld.expand(document, options={"documentLoader": self.document_loader.load})
            if not expanded:
                raise JsonLdError(
                    "expansion error",
                    "Error expanding JSON-LD structure: result was empty, it could be caused by missing '@context'",
                )
            first = expanded[0]
            if self.should_check_prefixes:
                self._validate_prefixes(first)
            return first
        except (JsonLdError, PrefixValidationError) as exc:
            self.monitor.warning("Error expanding JSON-LD structure: %s", exc)
            raise

    def compact(
        self,
        json_object: Dict[str, Any],
        scope: str = DEFAULT_SCOPE,
        context_override: Union[Dict[str, Any], List[Any], None] = None,
    ) -> Dict[str, Any]:
        """
        Compacts the provided JSON-LD document using the context for the given scope.

        Returns:
            The compacted JSON-LD document.
        Raises:
            JsonLdError if compaction fails.
        """
        try:
            # Determine the context to compact with.
            # Either get the context from the scope mapping or use an explicit override.
            context = context_override or self._create_context(scope)
            compacted = jsonld.compact(
                json_object,
                context,
                options={"documentLoader": self.document_loader.load},
            )
            return compacted
        except JsonLdError as exc:
            self.monitor.warning("Error compacting JSON-LD structure: %s", exc)
            raise

    def register_namespace(self, prefix: str, context_iri: str, scope: str = DEFAULT_SCOPE) -> None:
        if self.avoid_vocab and prefix == JsonLdKeywords.VOCAB:
            return
        namespaces = self.scoped_namespaces.setdefault(scope, OrderedDict())
        namespaces[prefix] = context_iri

    def register_context(self, context_iri: str, scope: str = DEFAULT_SCOPE) -> None:
        contexts = self.scoped_contexts.setdefault(scope, OrderedDict())
        contexts[context_iri] = None

    def register_cached_document(self, context_url: str, uri: Union[str, Path]) -> None:
        self.document_loader.register(context_url, uri)

    # -------------------------------------------------------------------------
    # Helpers
    # -------------------------------------------------------------------------

    def _inject_vocab(self, json_object: Dict[str, Any]) -> Dict[str, Any]:
        result = dict(json_object)
        context = result.get(JsonLdKeywords.CONTEXT)
        if isinstance(context, MutableMapping):
            context_dict = dict(context)
            if JsonLdKeywords.VOCAB not in context_dict:
                context_dict[JsonLdKeywords.VOCAB] = CoreConstants.EDC_NAMESPACE
                result[JsonLdKeywords.CONTEXT] = context_dict
        return result

    def _create_context(self, scope: str) -> Union[Dict[str, str], List[Any]]:
        namespace_object: Dict[str, str] = {}
        for prefix, iri in self._namespaces_for_scope(self.DEFAULT_SCOPE):
            namespace_object[prefix] = iri
        if scope != self.DEFAULT_SCOPE:
            for prefix, iri in self._namespaces_for_scope(scope):
                namespace_object[prefix] = iri

        contexts: List[str] = []
        contexts.extend(self._contexts_for_scope(self.DEFAULT_SCOPE))
        if scope != self.DEFAULT_SCOPE:
            contexts.extend(self._contexts_for_scope(scope))

        if contexts:
            deduped = list(OrderedDict((iri, None) for iri in contexts).keys())
            array: List[Any] = deduped.copy()
            if namespace_object:
                array.append(namespace_object)
            return array
        return namespace_object

    def _namespaces_for_scope(self, scope: str) -> Iterable[tuple[str, str]]:
        return self.scoped_namespaces.get(scope, {}).items()

    def _contexts_for_scope(self, scope: str) -> Sequence[str]:
        return list(self.scoped_contexts.get(scope, {}).keys())

    def _validate_prefixes(self, json_object: Any) -> None:
        known = self.get_all_prefixes()
        missing: set[str] = set()

        def _walk(value: Any) -> None:
            if isinstance(value, dict):
                for key, child in value.items():
                    if isinstance(key, str) and not key.startswith("@"):
                        match = self._PREFIX_PATTERN.match(key)
                        if match and match.group(1) not in known:
                            missing.add(match.group(1))
                    _walk(child)
            elif isinstance(value, list):
                for item in value:
                    _walk(item)

        _walk(json_object)
        if missing:
            raise PrefixValidationError("Missing prefix definitions: %s" % ", ".join(sorted(missing)))

    def get_all_prefixes(self) -> set[str]:
        prefixes: set[str] = set()
        for namespaces in self.scoped_namespaces.values():
            prefixes.update(namespaces.keys())
        return prefixes


class CachedDocumentLoader:
    """
    Replacement for the Titanium SchemeRouter/FileLoader/JarLoader combo.
    """

    def __init__(self, configuration: JsonLdConfiguration, monitor: logging.Logger):
        self.configuration = configuration
        self.monitor = monitor
        self.uri_cache: Dict[str, str] = {}
        self.document_cache: Dict[str, Dict[str, Any]] = {}

    def register(self, context_url: str, uri: Union[str, Path]) -> None:
        uri_str = str(uri)
        self.uri_cache[context_url] = uri_str
        try:
            self.document_cache[uri_str] = self._fetch_document(uri_str)
        except JsonLdError as exc:
            self.monitor.warning(
                "Error caching context URL '%s' for URI '%s'. Subsequent attempts may fail: %s",
                context_url,
                uri_str,
                exc,
            )

    def load(self, url: str, options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        resolved = self.uri_cache.get(url, url)
        if resolved in self.document_cache:
            return self.document_cache[resolved]
        document = self._fetch_document(resolved)
        self.document_cache[resolved] = document
        return document

    # ------------------------------------------------------------------
    # Fetch helpers
    # ------------------------------------------------------------------

    def _fetch_document(self, url: str) -> Dict[str, Any]:
        if url.startswith("jar:"):
            if not self.configuration.jar_enabled:
                raise JsonLdError("loading document failed", "JAR scheme is disabled", code="loading document failed")
            content = self._load_from_jar(url)
        else:
            parsed = urlsplit(url)
            scheme = parsed.scheme or "file"
            if scheme in ("http", "https"):
                if not getattr(self.configuration, f"{scheme}_enabled"):
                    raise JsonLdError("loading document failed", f"{scheme.upper()} scheme is disabled")
                content = self._load_from_http(url)
            elif scheme == "file":
                if not self.configuration.file_enabled:
                    raise JsonLdError("loading document failed", "FILE scheme is disabled")
                content = self._load_from_file(parsed)
            else:
                raise JsonLdError("loading document failed", f"Unsupported scheme '{scheme}'")
        return {
            "contextUrl": None,
            "documentUrl": url,
            "document": json.loads(content),
        }

    def _load_from_http(self, url: str) -> str:
        request = urllib.request.Request(url, headers={"Accept": "application/ld+json, application/json"})
        with urllib.request.urlopen(request, timeout=self.configuration.document_loader_timeout) as response:
            return response.read().decode(response.headers.get_content_charset() or "utf-8")

    def _load_from_file(self, parsed) -> str:
        path = Path(urllib.request.url2pathname(parsed.path))
        with path.open("r", encoding="utf-8") as fp:
            return fp.read()

    def _load_from_jar(self, url: str) -> str:
        without_scheme = url[len("jar:") :]
        outer, _, inner = without_scheme.partition("!")
        if not outer or not inner:
            raise JsonLdError("loading document failed", f"Malformed jar URI '{url}'")
        outer_path = outer
        if outer_path.startswith("file:"):
            parsed_outer = urlsplit(outer_path)
            outer_path = urllib.request.url2pathname(parsed_outer.path)
        inner_entry = inner.lstrip("/")
        with zipfile.ZipFile(outer_path, "r") as jar_file:
            with jar_file.open(inner_entry) as fp:
                return fp.read().decode("utf-8")
