#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

from __future__ import annotations

from typing import Mapping, Sequence

from fastapi import FastAPI

from pyedc_core.middleware.jsonld_middleware import JsonLDMiddleware
from pyedc_core.utils.json_ld_transformer import JsonLdTransformer


def create_app(**fastapi_kwargs) -> FastAPI:
    """Create a plain FastAPI application with no JSON-LD bindings."""
    return FastAPI(**fastapi_kwargs)


def create_namespaced_app(
    *,
    title: str,
    scope: str,
    routers: Sequence,
    namespaces: Mapping[str, str] | None = None,
    default_context: dict | None = None,
) -> FastAPI:
    """Builds a FastAPI application configured for a specific JSON-LD scope."""
    transformer = JsonLdTransformer()
    _register_transformer(transformer, scope, namespaces, default_context)

    app = FastAPI(title=title)
    app.add_middleware(
        JsonLDMiddleware,
        transformer=transformer,
        scope=scope,
        default_context=default_context,
    )

    for router in routers:
        app.include_router(router)

    return app


def _register_transformer(
    transformer: JsonLdTransformer,
    scope: str,
    namespaces: Mapping[str, str] | None,
    default_context: dict | None,
) -> None:
    for prefix, iri in (namespaces or {}).items():
        transformer.register_namespace(prefix, iri, scope=scope)

    if default_context:
        for key, value in default_context.items():
            if key.startswith("@"):
                continue
            if isinstance(value, str):
                transformer.register_namespace(key, value, scope=scope)
