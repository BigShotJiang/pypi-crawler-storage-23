#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

"""Utilities for transparently handling JSON-LD payloads at the FastAPI boundary."""

import json
import logging
from typing import Awaitable, Callable, Optional

from starlette.datastructures import MutableHeaders
from starlette.responses import JSONResponse

from pyedc_core.utils.json_ld_transformer import JsonLdTransformer
from pyld.jsonld import JsonLdError

Receive = Callable[[], Awaitable[dict]]
Send = Callable[[dict], Awaitable[None]]


class JsonLDMiddleware:
    """Expand inbound JSON-LD requests and compact outbound responses."""

    def __init__(
        self,
        app,
        transformer: Optional[JsonLdTransformer] = None,
        scope: str = JsonLdTransformer.DEFAULT_SCOPE,
        default_context: Optional[dict] = None,
    ):
        """Create the middleware.

        Incoming jsonld payload is assumed to be compacted. The internals expect the payload to be expanded
        This middleware makes sure incoming jsonld is expanded and any outgoing jsonld is compacted again
        Args:
            app: Downstream ASGI application.
            transformer: Optional custom JsonLdTransformer for expansion/compaction.
            scope: JsonLdTransformer scope name used when compacting responses.
            default_context: Context inserted when the downstream response omits one.
        """
        self.app = app
        self.transformer = transformer or JsonLdTransformer()
        self.logger = logging.getLogger(__name__)
        self.scope = scope
        self.default_context = default_context

    async def __call__(self, scope, receive: Receive, send: Send):
        """ASGI entrypoint that wraps the receive/send call chain."""
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        method = scope.get("method", "").upper()
        body = await self._consume_body(receive)
        expanded_receive = self._build_receive(body)

        response_start: dict | None = None
        response_status: int | None = None

        async def send_wrapper(message):
            nonlocal response_start, response_status
            message_type = message["type"]

            if message_type == "http.response.start":
                response_start = message
                response_status = message.get("status")
                return

            if message_type == "http.response.body":
                should_compact = (
                    response_status is None or 200 <= response_status < 300
                )
                if should_compact:
                    message = await self._compact_response(message)
                if response_start is not None:
                    start_message = response_start
                    response_start = None
                    headers = MutableHeaders(raw=list(start_message.get("headers", [])))
                    body_bytes = message.get("body", b"")
                    if isinstance(body_bytes, memoryview):
                        body_bytes = body_bytes.tobytes()
                    headers["content-length"] = str(len(body_bytes or b""))
                    start_message["headers"] = headers.raw
                    await send(start_message)
                await send(message)
                return

            await send(message)

        if method in {"POST", "PUT", "PATCH"} and body:
            payload = self._parse_json(body)
            if isinstance(payload, dict):
                expanded = await self._expand_payload(payload, scope, send)
                if expanded is None:
                    return
                expanded_receive = self._build_receive(json.dumps(expanded).encode("utf-8"))

        await self.app(scope, expanded_receive, send_wrapper)

    async def _compact_response(self, message: dict) -> dict:
        """Compact JSON-LD bodies when the downstream response succeeds."""
        body = message.get("body", b"")
        if not body:
            return message

        payload = self._parse_json(body)
        if not isinstance(payload, dict):
            return message

        try:
            compacted = self.transformer.compact(
                payload,
                scope=self.scope,
                context_override=self.default_context,
            )
            if "@context" not in compacted and self.default_context:
                compacted["@context"] = self.default_context
        except JsonLdError as exc:
            self.logger.warning("JSON-LD compaction failed: %s", exc)
            return message
        except Exception:
            self.logger.exception("Unexpected error during JSON-LD compaction")
            return message

        new_body = json.dumps(compacted).encode("utf-8")
        return {
            **message,
            "body": new_body,
            "more_body": False,
        }

    async def _expand_payload(self, payload: dict, scope, send) -> Optional[dict]:
        """Expand incoming JSON-LD payloads or emit an error response."""
        try:
            return self.transformer.expand(payload)
        except JsonLdError as exc:
            self.logger.warning("JSON-LD expansion failed: %s", exc)
            response = JSONResponse(
                status_code=400,
                content={"detail": "Invalid JSON-LD payload"},
            )
            await response(scope, self._empty_receive, send)
            return None
        except Exception:
            self.logger.exception("Unexpected error in JsonLDMiddleware")
            response = JSONResponse(
                status_code=500,
                content={"detail": "Internal JSON-LD middleware error"},
            )
            await response(scope, self._empty_receive, send)
            return None

    @staticmethod
    async def _empty_receive():
        return {"type": "http.request", "body": b"", "more_body": False}

    async def _consume_body(self, receive: Receive) -> bytes:
        """Drain the ASGI receive channel into a single bytes object."""
        body = b""
        more_body = True
        while more_body:
            message = await receive()
            body += message.get("body", b"")
            more_body = message.get("more_body", False)
        return body

    def _build_receive(self, body: bytes) -> Receive:
        """Construct a receive callable that replays the provided body exactly once."""
        done = False

        async def _receive():
            nonlocal done
            if done:
                return {"type": "http.request", "body": b"", "more_body": False}
            done = True
            return {"type": "http.request", "body": body, "more_body": False}

        return _receive

    @staticmethod
    def _parse_json(body: bytes):
        """Parse a JSON document or gracefully return None when invalid."""
        try:
            return json.loads(body)
        except json.JSONDecodeError:
            return None
