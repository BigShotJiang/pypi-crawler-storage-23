#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient

from pyedc_core.middleware import JsonLDMiddleware


class RecordingTransformer:
    DEFAULT_SCOPE = "default"

    def __init__(self):
        self.compact_calls = []

    def expand(self, json_object):
        return json_object

    def compact(self, json_object, scope=None, context_override=None):
        self.compact_calls.append((json_object, scope, context_override))
        return {"wrapped": json_object}


def _build_app(transformer):
    app = FastAPI()
    app.add_middleware(JsonLDMiddleware, transformer=transformer, scope="custom")

    @app.get("/ok")
    def ok():
        return {"message": "hi"}

    @app.get("/fail")
    def fail():
        raise HTTPException(status_code=409, detail="not allowed")

    return app


def test_compacts_successful_responses():
    transformer = RecordingTransformer()
    app = _build_app(transformer)
    client = TestClient(app)

    response = client.get("/ok")

    assert response.status_code == 200
    assert response.json() == {"wrapped": {"message": "hi"}}
    assert transformer.compact_calls == [({"message": "hi"}, "custom", None)]
    client.close()


def test_leaves_error_responses_untouched():
    transformer = RecordingTransformer()
    app = _build_app(transformer)
    client = TestClient(app)

    response = client.get("/fail")

    assert response.status_code == 409
    assert response.json() == {"detail": "not allowed"}
    assert transformer.compact_calls == []
    client.close()
