#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

import json
import httpx

from pyedc_core.services.jsonld_api_client import JsonLdApiClient


class RecordingTransformer:
    DEFAULT_SCOPE = "default"

    def __init__(self):
        self.compact_calls = []
        self.expand_calls = []

    def compact(self, json_object, scope=None, context_override=None):
        self.compact_calls.append((json_object, scope, context_override))
        return {"wrapped": json_object}

    def expand(self, json_object):
        self.expand_calls.append(json_object)
        return {"expanded": json_object}


def test_request_compacts_payload_and_expands_response():
    captured = {}

    def handler(request):
        captured["path"] = request.url.path
        captured["body"] = json.loads(request.content.decode())
        captured["headers"] = {k.lower(): v for k, v in request.headers.items()}
        return httpx.Response(200, json={"ok": True})

    transport = httpx.MockTransport(handler)
    httpx_client = httpx.Client(transport=transport, base_url="https://example.test")
    transformer = RecordingTransformer()
    client = JsonLdApiClient(
        client=httpx_client,
        transformer=transformer,
        scope="custom-scope",
        default_headers={"X-Client": "core"},
    )

    response = client.request(
        "POST",
        "/items",
        jsonld={"hello": "world"},
        headers={"X-Request": "abc"},
    )

    assert captured["path"] == "/items"
    assert captured["body"] == {"wrapped": {"hello": "world"}}
    assert captured["headers"]["x-client"] == "core"
    assert captured["headers"]["x-request"] == "abc"
    assert captured["headers"]["content-type"] == "application/json"
    assert transformer.compact_calls == [({"hello": "world"}, "custom-scope", None)]
    assert transformer.expand_calls == [{"ok": True}]
    assert response.jsonld_body == {"expanded": {"ok": True}}

    httpx_client.close()


def test_request_skips_expansion_for_non_json_response():
    def handler(request):
        return httpx.Response(200, content=b"plain text")

    transport = httpx.MockTransport(handler)
    httpx_client = httpx.Client(transport=transport, base_url="https://example.test")
    transformer = RecordingTransformer()
    client = JsonLdApiClient(client=httpx_client, transformer=transformer)

    response = client.request("GET", "/text", jsonld=None)

    assert response.json_body is None
    assert response.jsonld_body is None
    assert transformer.expand_calls == []

    httpx_client.close()


def test_request_can_skip_response_expansion():
    def handler(request):
        return httpx.Response(200, json={"foo": "bar"})

    transport = httpx.MockTransport(handler)
    httpx_client = httpx.Client(transport=transport, base_url="https://example.test")
    transformer = RecordingTransformer()
    client = JsonLdApiClient(client=httpx_client, transformer=transformer)

    response = client.request("GET", "/json", expand_response=False)

    assert response.json_body == {"foo": "bar"}
    assert response.jsonld_body is None
    assert transformer.expand_calls == []

    httpx_client.close()
