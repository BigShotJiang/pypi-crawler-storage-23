from django.apps import AppConfig


class FormsAppConfig(AppConfig):
    name = 'wagtailnhsukfrontend.forms'
    label = 'wagtailnhsukfrontendforms'
    verbose_name = "Wagtail NHSUK Frontend Forms"
