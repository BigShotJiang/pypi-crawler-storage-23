# ────────────────────────────────────────────────────────────────────────────────────────
#   converter.py
#   ────────────
#
#   Core conversion logic for converting RAR archives to ZIP format.
#   Preserves internal file timestamps and copies the RAR file's filesystem
#   timestamp to the resulting ZIP file.
#
#   (c) 2026 WaterJuice — Unlicense; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import os
import zipfile
from pathlib import Path
from unrar.cffi.rarfile import RarFile  # pyright: ignore[reportMissingTypeStubs]
from unrar.cffi.rarfile import RarInfo  # pyright: ignore[reportMissingTypeStubs]

# ────────────────────────────────────────────────────────────────────────────────────────
#   Functions
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def find_rar_files(directory: Path) -> list[Path]:
    """
    Recursively find all RAR files under a directory.

    Parameters:
        directory: Root directory to scan.

    Returns:
        Sorted list of paths to .rar files.
    """
    rar_files: list[Path] = []
    for root, _dirs, files in os.walk(directory):
        for filename in files:
            if filename.lower().endswith(".rar"):
                rar_files.append(Path(root) / filename)
    rar_files.sort()
    return rar_files


# ────────────────────────────────────────────────────────────────────────────────────────
def convert_rar_to_zip(rar_path: Path) -> Path:
    """
    Convert a single RAR archive to ZIP format.

    The ZIP file is created in the same directory as the RAR file with the same
    base name. Internal file timestamps are preserved, and the ZIP file's
    filesystem timestamp is set to match the original RAR file.

    Parameters:
        rar_path: Path to the RAR file to convert.

    Returns:
        Path to the created ZIP file.

    Raises:
        FileNotFoundError: If the RAR file does not exist.
        RuntimeError: If the RAR file cannot be read.
    """
    if not rar_path.exists():
        msg = f"RAR file not found: {rar_path}"
        raise FileNotFoundError(msg)

    zip_path = rar_path.with_suffix(".zip")

    rf: RarFile = RarFile(str(rar_path))  # pyright: ignore[reportUnknownVariableType]
    entries: list[RarInfo] = rf.infolist()  # pyright: ignore[reportUnknownMemberType,reportUnknownVariableType]

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for entry in entries:  # pyright: ignore[reportUnknownVariableType]
            filename = str(entry.filename)  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]
            date_time: tuple[int, ...] = tuple(int(x) for x in entry.date_time)  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType,reportUnknownVariableType]

            if entry.is_dir():  # pyright: ignore[reportUnknownMemberType]
                if not filename.endswith("/"):
                    filename += "/"
                info = zipfile.ZipInfo(filename=filename, date_time=date_time)  # pyright: ignore[reportArgumentType]
                info.external_attr = 0o40755 << 16
                zf.writestr(info, b"")
            else:
                data = bytes(rf.read(entry))  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]
                info = zipfile.ZipInfo(filename=filename, date_time=date_time)  # pyright: ignore[reportArgumentType]
                info.compress_type = zipfile.ZIP_DEFLATED
                zf.writestr(info, data)

    # Copy the RAR file's filesystem timestamps to the ZIP file
    rar_stat = rar_path.stat()
    os.utime(zip_path, (rar_stat.st_atime, rar_stat.st_mtime))

    return zip_path
