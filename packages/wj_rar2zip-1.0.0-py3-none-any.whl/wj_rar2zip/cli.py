# ────────────────────────────────────────────────────────────────────────────────────────
#   cli.py
#   ──────
#
#   CLI entry point for wj-rar2zip. Parses arguments and converts RAR files to ZIP.
#
#   (c) 2026 WaterJuice — Unlicense; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────
# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import argparse
import sys
import traceback
from pathlib import Path
from wj_rar2zip.converter import convert_rar_to_zip
from wj_rar2zip.converter import find_rar_files
from wj_rar2zip.version import VERSION_STR

# ────────────────────────────────────────────────────────────────────────────────────────
#   Descriptions
# ────────────────────────────────────────────────────────────────────────────────────────

DESCRIPTION = """\
Convert RAR archives to ZIP format, preserving all file timestamps.

Recursively scans a directory for .rar files and converts each one to a .zip
file in the same location. Internal file timestamps are preserved, and the
resulting ZIP file's filesystem timestamp matches the original RAR file.

Examples:
  wj-rar2zip /path/to/archives       # Convert all RAR files under the directory
  wj-rar2zip --dry-run /path         # List what would be converted
  wj-rar2zip --delete /path          # Convert and delete original RAR files
"""

# ────────────────────────────────────────────────────────────────────────────────────────
#   Argument Parsing
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def create_parser() -> argparse.ArgumentParser:
    """Create the argument parser."""
    parser = argparse.ArgumentParser(
        prog="wj-rar2zip",
        description=DESCRIPTION,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    parser.add_argument(
        "directory",
        help="Root directory to scan for RAR files",
    )
    parser.add_argument(
        "--delete",
        action="store_true",
        dest="delete",
        help="Delete original RAR files after successful conversion",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        dest="dry_run",
        help="List RAR files that would be converted without converting them",
    )
    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"wj-rar2zip {VERSION_STR}",
    )

    return parser


# ────────────────────────────────────────────────────────────────────────────────────────
#   Main Entry Point
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def main(argv: list[str] | None = None) -> int:
    """
    Main entry point for wj-rar2zip CLI.

    Parameters:
        argv: Command line arguments (without program name). If None, uses sys.argv[1:].

    Returns:
        Exit code (0 for success, non-zero for error).
    """
    if argv is None:
        argv = sys.argv[1:]

    try:
        return _main_inner(argv)
    except SystemExit:
        raise
    except BaseException as e:
        t = "-----------------------------------------------------------------------------\n"
        t += "UNHANDLED EXCEPTION OCCURRED!!\n"
        t += "\n"
        t += traceback.format_exc()
        t += "\n"
        t += f"EXCEPTION: {type(e)} {e}\n"
        t += "-----------------------------------------------------------------------------\n"
        t += "\n"
        print(t, file=sys.stderr)
        return 1


# ────────────────────────────────────────────────────────────────────────────────────────
def _main_inner(argv: list[str]) -> int:
    """Inner main function that does the actual work."""
    parser = create_parser()
    args = parser.parse_args(argv)

    directory = Path(args.directory)
    if not directory.is_dir():
        print(f"Error: not a directory: {directory}", file=sys.stderr)
        return 1

    rar_files = find_rar_files(directory)
    if not rar_files:
        print("No RAR files found.")
        return 0

    if args.dry_run:
        return _do_dry_run(rar_files, directory)

    return _do_convert(rar_files, directory, delete=args.delete)


# ────────────────────────────────────────────────────────────────────────────────────────
def _do_dry_run(rar_files: list[Path], base_dir: Path) -> int:
    """List RAR files that would be converted."""
    for rar_path in rar_files:
        relative = _relative_path(rar_path, base_dir)
        print(f"  {relative}")

    print(f"\n{len(rar_files)} file(s) would be converted.")
    return 0


# ────────────────────────────────────────────────────────────────────────────────────────
def _do_convert(rar_files: list[Path], base_dir: Path, *, delete: bool) -> int:
    """Convert RAR files to ZIP format."""
    converted = 0
    errors = 0

    for i, rar_path in enumerate(rar_files, 1):
        relative = _relative_path(rar_path, base_dir)
        print(f"[{i}/{len(rar_files)}] {relative}...", end="", flush=True)

        try:
            convert_rar_to_zip(rar_path)
            if delete:
                rar_path.unlink()
            print(" done.")
            converted += 1
        except Exception as e:
            print(f" ERROR: {e}", file=sys.stderr)
            errors += 1

    print(f"\nConverted {converted} of {len(rar_files)} file(s).", end="")
    if errors:
        print(f" ({errors} error(s))", end="")
    print()

    return 1 if errors else 0


# ────────────────────────────────────────────────────────────────────────────────────────
def _relative_path(path: Path, base: Path) -> str:
    """Return a relative path string, falling back to the full path on error."""
    try:
        return str(path.relative_to(base))
    except ValueError:
        return str(path)
