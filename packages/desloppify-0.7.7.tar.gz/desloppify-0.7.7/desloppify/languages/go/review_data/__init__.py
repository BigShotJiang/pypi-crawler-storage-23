"""Review data package for Go subjective dimensions."""
