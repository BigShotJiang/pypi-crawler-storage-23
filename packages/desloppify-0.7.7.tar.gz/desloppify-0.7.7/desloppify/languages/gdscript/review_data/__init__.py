"""Review data package for GDScript subjective dimensions."""
