"""C# dependency command/fallback helpers."""

