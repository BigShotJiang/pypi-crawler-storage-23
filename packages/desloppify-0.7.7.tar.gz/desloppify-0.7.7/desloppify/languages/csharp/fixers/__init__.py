"""C# fixers package.

No auto-fixers are implemented in the MVP scaffold.
"""
