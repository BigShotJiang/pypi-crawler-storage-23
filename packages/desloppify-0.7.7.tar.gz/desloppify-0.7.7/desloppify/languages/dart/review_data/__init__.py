"""Review data package for Dart subjective dimensions."""
