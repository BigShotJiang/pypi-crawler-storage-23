"""Compatibility wrapper for next render helpers.

Canonical implementation now lives in `desloppify.app.commands.next_parts.render`.
"""

from desloppify.app.commands.next_parts.render import *  # noqa: F401,F403
