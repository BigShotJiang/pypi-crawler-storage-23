"""Structured helpers for the `next` command."""

from desloppify.app.commands.next_parts.output import *  # noqa: F401,F403
from desloppify.app.commands.next_parts.render import *  # noqa: F401,F403
