"""Focused helper modules for command-layer dependencies."""
