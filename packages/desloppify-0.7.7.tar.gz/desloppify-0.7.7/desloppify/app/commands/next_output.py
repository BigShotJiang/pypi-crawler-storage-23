"""Compatibility wrapper for next output helpers.

Canonical implementation now lives in `desloppify.app.commands.next_parts.output`.
"""

from desloppify.app.commands.next_parts.output import *  # noqa: F401,F403
