"""Batch runner helpers and orchestration for review command."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

from desloppify.app.commands.helpers.query import write_query
from desloppify.app.commands.review import batch_core as batch_core_mod
from desloppify.app.commands.review import batches as review_batches_mod
from desloppify.app.commands.review import runner_helpers as runner_helpers_mod
from desloppify.core._internal.text_utils import PROJECT_ROOT
from desloppify.core.fallbacks import print_error
from desloppify.file_discovery import safe_write_text
from desloppify.intelligence import narrative as narrative_mod
from desloppify.intelligence import review as review_mod
from desloppify.intelligence.review.feedback_contract import (
    max_batch_findings_for_dimension_count,
)
from desloppify.utils import colorize, log

from .import_cmd import do_import as _do_import
from .runtime import setup_lang_concrete as _setup_lang

REVIEW_PACKET_DIR = PROJECT_ROOT / ".desloppify" / "review_packets"
SUBAGENT_RUNS_DIR = PROJECT_ROOT / ".desloppify" / "subagents" / "runs"
CODEX_BATCH_TIMEOUT_SECONDS = 20 * 60
CODEX_BATCH_STALL_KILL_SECONDS = 120
FOLLOWUP_SCAN_TIMEOUT_SECONDS = 45 * 60
ABSTRACTION_SUB_AXES = (
    "abstraction_leverage",
    "indirection_cost",
    "interface_honesty",
)
ABSTRACTION_COMPONENT_NAMES = {
    "abstraction_leverage": "Abstraction Leverage",
    "indirection_cost": "Indirection Cost",
    "interface_honesty": "Interface Honesty",
}
DEFAULT_REVIEW_BATCH_MAX_FILES = 80


def _coerce_review_batch_file_limit(config: dict | None) -> int | None:
    """Resolve per-batch file cap from config (0/negative => unlimited)."""
    raw = (config or {}).get("review_batch_max_files", DEFAULT_REVIEW_BATCH_MAX_FILES)
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return DEFAULT_REVIEW_BATCH_MAX_FILES
    return value if value > 0 else None


def _coerce_positive_int(value: object, *, default: int, minimum: int = 1) -> int:
    """Parse positive integer CLI/config inputs with safe defaults."""
    if value is None:
        return default
    if not isinstance(value, int | float | str):
        return default
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return default
    return parsed if parsed >= minimum else default


def _coerce_non_negative_float(value: object, *, default: float) -> float:
    """Parse non-negative float CLI/config inputs with safe defaults."""
    if value is None:
        return default
    if not isinstance(value, int | float | str):
        return default
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return default
    return parsed if parsed >= 0.0 else default


def _coerce_non_negative_int(value: object, *, default: int) -> int:
    """Parse non-negative integer CLI/config inputs with safe defaults."""
    if value is None:
        return default
    if not isinstance(value, int | float | str):
        return default
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return default
    return parsed if parsed >= 0 else default


def _merge_batch_results(batch_results: list[object]) -> dict[str, object]:
    """Deterministically merge assessments/findings across batch outputs."""
    normalized_results: list[dict] = []
    for result in batch_results:
        if hasattr(result, "to_dict") and callable(result.to_dict):
            payload = result.to_dict()
            if isinstance(payload, dict):
                normalized_results.append(payload)
                continue
        if isinstance(result, dict):
            normalized_results.append(result)
    return batch_core_mod.merge_batch_results(
        normalized_results,
        abstraction_sub_axes=ABSTRACTION_SUB_AXES,
        abstraction_component_names=ABSTRACTION_COMPONENT_NAMES,
    )


def _load_or_prepare_packet(
    args,
    *,
    state: dict,
    lang,
    config: dict,
    stamp: str,
) -> tuple[dict, Path, Path]:
    """Load packet override or prepare a fresh packet snapshot."""
    packet_override = getattr(args, "packet", None)
    if packet_override:
        packet_path = Path(packet_override)
        if not packet_path.exists():
            print_error(f"packet not found: {packet_override}")
            sys.exit(1)
        try:
            packet = json.loads(packet_path.read_text())
        except (OSError, json.JSONDecodeError) as exc:
            print_error(f"reading packet: {exc}")
            sys.exit(1)
        blind_path = PROJECT_ROOT / ".desloppify" / "review_packet_blind.json"
        blind_packet = runner_helpers_mod.build_blind_packet(packet)
        safe_write_text(blind_path, json.dumps(blind_packet, indent=2) + "\n")
        print(colorize(f"  Immutable packet: {packet_path}", "dim"))
        print(colorize(f"  Blind packet: {blind_path}", "dim"))
        return packet, packet_path, blind_path

    path = Path(args.path)
    dims_str = getattr(args, "dimensions", None)
    dimensions = dims_str.split(",") if dims_str else None
    retrospective = bool(getattr(args, "retrospective", False))
    retrospective_max_issues = _coerce_positive_int(
        getattr(args, "retrospective_max_issues", None),
        default=30,
        minimum=1,
    )
    retrospective_max_batch_items = _coerce_positive_int(
        getattr(args, "retrospective_max_batch_items", None),
        default=20,
        minimum=1,
    )
    lang_run, found_files = _setup_lang(lang, path, config)
    lang_name = lang_run.name
    narrative = narrative_mod.compute_narrative(
        state,
        context=narrative_mod.NarrativeContext(lang=lang_name, command="review"),
    )

    blind_path = PROJECT_ROOT / ".desloppify" / "review_packet_blind.json"
    packet = review_mod.prepare_holistic_review(
        path,
        lang_run,
        state,
        options=review_mod.HolisticReviewPrepareOptions(
            dimensions=dimensions,
            files=found_files or None,
            max_files_per_batch=_coerce_review_batch_file_limit(config),
            include_issue_history=retrospective,
            issue_history_max_issues=retrospective_max_issues,
            issue_history_max_batch_items=retrospective_max_batch_items,
        ),
    )
    packet["narrative"] = narrative
    next_command = "desloppify review --run-batches --runner codex --parallel"
    if retrospective:
        next_command += (
            " --retrospective"
            f" --retrospective-max-issues {retrospective_max_issues}"
            f" --retrospective-max-batch-items {retrospective_max_batch_items}"
        )
    packet["next_command"] = next_command
    write_query(packet)
    packet_path, blind_saved = runner_helpers_mod.write_packet_snapshot(
        packet,
        stamp=stamp,
        review_packet_dir=REVIEW_PACKET_DIR,
        blind_path=blind_path,
        safe_write_text_fn=safe_write_text,
    )
    print(colorize(f"  Immutable packet: {packet_path}", "dim"))
    print(colorize(f"  Blind packet: {blind_saved}", "dim"))
    return packet, packet_path, blind_saved


def _do_run_batches(args, state, lang, state_file, config: dict | None = None) -> None:
    """Run holistic investigation batches with a local subagent runner."""
    batch_timeout_seconds = _coerce_positive_int(
        getattr(args, "batch_timeout_seconds", None),
        default=CODEX_BATCH_TIMEOUT_SECONDS,
        minimum=1,
    )
    batch_max_retries = _coerce_positive_int(
        getattr(args, "batch_max_retries", None),
        default=1,
        minimum=0,
    )
    batch_retry_backoff_seconds = _coerce_non_negative_float(
        getattr(args, "batch_retry_backoff_seconds", None),
        default=2.0,
    )
    batch_heartbeat_seconds = _coerce_non_negative_float(
        getattr(args, "batch_heartbeat_seconds", None),
        default=15.0,
    )
    batch_live_log_interval_seconds = (
        max(1.0, min(batch_heartbeat_seconds, 10.0))
        if batch_heartbeat_seconds > 0
        else 5.0
    )
    batch_stall_kill_seconds = _coerce_non_negative_int(
        getattr(args, "batch_stall_kill_seconds", None),
        default=CODEX_BATCH_STALL_KILL_SECONDS,
    )

    def _prepare_run_artifacts(*, stamp, selected_indexes, batches, packet_path, run_root, repo_root):
        return runner_helpers_mod.prepare_run_artifacts(
            stamp=stamp,
            selected_indexes=selected_indexes,
            batches=batches,
            packet_path=packet_path,
            run_root=run_root,
            repo_root=repo_root,
            build_prompt_fn=batch_core_mod.build_batch_prompt,
            safe_write_text_fn=safe_write_text,
            colorize_fn=colorize,
        )

    def _collect_batch_results(*, selected_indexes, failures, output_files, allowed_dims):
        return runner_helpers_mod.collect_batch_results(
            selected_indexes=selected_indexes,
            failures=failures,
            output_files=output_files,
            allowed_dims=allowed_dims,
            extract_payload_fn=lambda raw: batch_core_mod.extract_json_payload(raw, log_fn=log),
            normalize_result_fn=lambda payload, dims: batch_core_mod.normalize_batch_result(
                payload,
                dims,
                max_batch_findings=max_batch_findings_for_dimension_count(
                    len(dims)
                ),
                abstraction_sub_axes=ABSTRACTION_SUB_AXES,
            ),
        )

    return review_batches_mod.do_run_batches(
        args,
        state,
        lang,
        state_file,
        config=config,
        run_stamp_fn=runner_helpers_mod.run_stamp,
        load_or_prepare_packet_fn=_load_or_prepare_packet,
        selected_batch_indexes_fn=lambda args, *, batch_count: runner_helpers_mod.selected_batch_indexes(
            raw_selection=getattr(args, "only_batches", None),
            batch_count=batch_count,
            parse_fn=batch_core_mod.parse_batch_selection,
            colorize_fn=colorize,
        ),
        prepare_run_artifacts_fn=_prepare_run_artifacts,
        run_codex_batch_fn=lambda *, prompt, repo_root, output_file, log_file: runner_helpers_mod.run_codex_batch(
            prompt=prompt,
            repo_root=repo_root,
            output_file=output_file,
            log_file=log_file,
            deps=runner_helpers_mod.CodexBatchRunnerDeps(
                timeout_seconds=batch_timeout_seconds,
                subprocess_run=subprocess.run,
                timeout_error=subprocess.TimeoutExpired,
                safe_write_text_fn=safe_write_text,
                use_popen_runner=(getattr(subprocess.run, "__module__", "") == "subprocess"),
                subprocess_popen=subprocess.Popen,
                live_log_interval_seconds=batch_live_log_interval_seconds,
                stall_after_output_seconds=batch_stall_kill_seconds,
                max_retries=batch_max_retries,
                retry_backoff_seconds=batch_retry_backoff_seconds,
            ),
        ),
        execute_batches_fn=runner_helpers_mod.execute_batches,
        collect_batch_results_fn=_collect_batch_results,
        print_failures_fn=runner_helpers_mod.print_failures,
        print_failures_and_exit_fn=runner_helpers_mod.print_failures_and_exit,
        merge_batch_results_fn=_merge_batch_results,
        build_import_provenance_fn=runner_helpers_mod.build_batch_import_provenance,
        do_import_fn=_do_import,
        run_followup_scan_fn=lambda *, lang_name, scan_path: runner_helpers_mod.run_followup_scan(
            lang_name=lang_name,
            scan_path=scan_path,
            deps=runner_helpers_mod.FollowupScanDeps(
                project_root=PROJECT_ROOT,
                timeout_seconds=FOLLOWUP_SCAN_TIMEOUT_SECONDS,
                python_executable=sys.executable,
                subprocess_run=subprocess.run,
                timeout_error=subprocess.TimeoutExpired,
                colorize_fn=colorize,
            ),
        ),
        safe_write_text_fn=safe_write_text,
        colorize_fn=colorize,
        project_root=PROJECT_ROOT,
        subagent_runs_dir=SUBAGENT_RUNS_DIR,
    )
