"""Compatibility wrapper for status command.

Canonical implementation now lives in `desloppify.app.commands.status_cmd`.
"""

from desloppify.app.commands.status_cmd import *  # noqa: F401,F403
