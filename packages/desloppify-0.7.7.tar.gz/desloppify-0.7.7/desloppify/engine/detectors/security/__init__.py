"""Security detector package."""

from .detector import detect_security_issues

__all__ = ["detect_security_issues"]
