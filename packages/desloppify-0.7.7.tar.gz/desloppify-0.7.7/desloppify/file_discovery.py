"""File discovery: source file finding, exclusion matching, and traversal caching."""

from __future__ import annotations

import os
from pathlib import Path

from desloppify.core._internal.text_utils import get_project_root
from desloppify.core.file_paths import (
    matches_exclusion,
    rel,
    resolve_path,
    safe_write_text,
)
from desloppify.core.file_paths import (
    normalize_path_separators as _normalize_path_separators,
)
from desloppify.core.file_paths import (
    safe_relpath as _safe_relpath,
)
from desloppify.core.runtime_state import current_runtime_context

__all__ = [
    "DEFAULT_EXCLUSIONS",
    "set_exclusions",
    "get_exclusions",
    "matches_exclusion",
    "rel",
    "resolve_path",
    "safe_write_text",
    "enable_file_cache",
    "disable_file_cache",
    "is_file_cache_enabled",
    "read_file_text",
    "find_source_files",
    "find_ts_files",
    "find_tsx_files",
    "find_py_files",
]


# Directories that are never useful to scan — always pruned during traversal.
DEFAULT_EXCLUSIONS = frozenset(
    {
        "node_modules",
        ".git",
        "__pycache__",
        ".venv*",
        "venv",
        ".env",
        "dist",
        "build",
        ".next",
        ".nuxt",
        ".output",
        ".tox",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        ".eggs",
        "*.egg-info",
        ".svn",
        ".hg",
    }
)


def set_exclusions(patterns: list[str]):
    """Set global exclusion patterns (called once from CLI at startup)."""
    runtime = current_runtime_context()
    runtime.exclusions = tuple(patterns)
    runtime.source_file_cache.clear()


def get_exclusions() -> tuple[str, ...]:
    """Return current extra exclusion patterns."""
    return current_runtime_context().exclusions


# ── File content cache & reading ──────────────────────────────


def enable_file_cache():
    """Enable scan-scoped file content cache."""
    runtime = current_runtime_context()
    runtime.file_text_cache.enable()
    runtime.cache_enabled = True


def disable_file_cache():
    """Disable file content cache and free memory."""
    runtime = current_runtime_context()
    runtime.file_text_cache.disable()
    runtime.cache_enabled = False


def is_file_cache_enabled() -> bool:
    """Return whether scan-scoped file cache is currently enabled."""
    return current_runtime_context().cache_enabled


def read_file_text(filepath: str) -> str | None:
    """Read a file as text, with optional caching."""
    return current_runtime_context().file_text_cache.read(filepath)


def _is_excluded_dir(name: str, rel_path: str, extra: tuple[str, ...]) -> bool:
    in_default_exclusions = name in DEFAULT_EXCLUSIONS or name.endswith(".egg-info")
    is_virtualenv_dir = name.startswith(".venv") or name.startswith("venv")
    matches_extra_exclusion = bool(
        extra
        and any(
            matches_exclusion(rel_path, exclusion) or exclusion == name
            for exclusion in extra
        )
    )
    return in_default_exclusions or is_virtualenv_dir or matches_extra_exclusion


def _clear_source_file_cache() -> None:
    current_runtime_context().source_file_cache.clear()


def _find_source_files_cached(
    path: str,
    extensions: tuple[str, ...],
    exclusions: tuple[str, ...] | None = None,
    extra_exclusions: tuple[str, ...] = (),
) -> tuple[str, ...]:
    """Cached file discovery using os.walk — cross-platform, prunes during traversal."""
    cache_key = (path, extensions, exclusions, extra_exclusions)
    cache = current_runtime_context().source_file_cache
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    project_root = get_project_root()
    root = Path(path)
    if not root.is_absolute():
        root = project_root / root
    all_exclusions = (exclusions or ()) + extra_exclusions
    ext_set = set(extensions)
    files: list[str] = []
    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = _normalize_path_separators(_safe_relpath(dirpath, project_root))
        dirnames[:] = sorted(
            d
            for d in dirnames
            if not _is_excluded_dir(d, rel_dir + "/" + d, all_exclusions)
        )
        for fname in filenames:
            if any(fname.endswith(ext) for ext in ext_set):
                full = os.path.join(dirpath, fname)
                rel_file = _normalize_path_separators(_safe_relpath(full, project_root))
                if all_exclusions and any(
                    matches_exclusion(rel_file, ex) for ex in all_exclusions
                ):
                    continue
                files.append(rel_file)
    result = tuple(sorted(files))
    cache.put(cache_key, result)
    return result



def find_source_files(
    path: str | Path, extensions: list[str], exclusions: list[str] | None = None
) -> list[str]:
    """Find all files with given extensions under a path, excluding patterns."""
    return list(
        _find_source_files_cached(
            str(path),
            tuple(extensions),
            tuple(exclusions) if exclusions else None,
            get_exclusions(),
        )
    )


def find_ts_files(path: str | Path) -> list[str]:
    return find_source_files(path, [".ts", ".tsx"])


def find_tsx_files(path: str | Path) -> list[str]:
    return find_source_files(path, [".tsx"])


def find_py_files(path: str | Path) -> list[str]:
    return find_source_files(path, [".py"])
