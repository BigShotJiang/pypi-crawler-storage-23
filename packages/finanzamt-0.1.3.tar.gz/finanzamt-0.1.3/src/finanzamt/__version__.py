"""Version information for finanzamt package."""

from importlib.metadata import version

__version__ = version("finanzamt")