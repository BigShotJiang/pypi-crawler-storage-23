"""
This script will contain functions used to sample from the posterior distribution of the Magma(Clust) model.
"""

# TODO