"""
This script will feature the code needed to perform Laplace matching (handling of non-Gaussian likelihoods,
pseudo-inputs, ...) in MagmaClustPy.
"""

# TODO