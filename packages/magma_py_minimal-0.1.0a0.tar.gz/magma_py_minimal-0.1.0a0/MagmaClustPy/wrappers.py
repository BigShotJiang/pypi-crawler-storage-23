"""
This script will contain the wrappers to perform a whole training pipeline with minimual inputs
from the user and maximum checks on the data. It's designed to allow the user to perform "5 min experiments"
and get a feel of the model without having to worry about the details of the training process.
"""

# TODO