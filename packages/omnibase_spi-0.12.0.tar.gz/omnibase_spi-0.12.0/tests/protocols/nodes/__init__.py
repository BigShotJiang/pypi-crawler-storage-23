"""Tests for omnibase-spi node protocols."""
