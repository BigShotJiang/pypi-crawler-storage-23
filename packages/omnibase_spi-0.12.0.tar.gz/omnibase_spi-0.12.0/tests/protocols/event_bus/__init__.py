"""Tests for event bus protocols."""
