"""Unit tests for factory protocols and implementations."""
