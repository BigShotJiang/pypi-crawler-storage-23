"""Unit tests for intelligence protocol definitions."""
