"""Pytest fixtures for intelligence protocol tests."""
