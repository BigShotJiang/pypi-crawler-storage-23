"""Unit tests for storage protocols."""
