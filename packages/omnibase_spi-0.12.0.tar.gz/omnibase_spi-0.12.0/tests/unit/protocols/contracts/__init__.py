"""Unit tests for contract protocols."""
