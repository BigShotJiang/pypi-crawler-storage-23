"""Unit tests for projection protocols."""
