"""Unit tests for contract protocols and implementations."""
