# Reports / Export Skill

Generate formatted data exports and reports from existing skill data.
Board packets, donor summaries, financial snapshots, grant status reports.

## Usage

Use this skill when the user wants to:
- Generate a donor summary report (totals by tier, period)
- Create a grant pipeline status report
- Produce a financial snapshot (income/expense summary)
- Export data (donors, tasks, grants, contacts) to CSV or XLSX
- Build a complete board meeting packet

## Cross-Skill Integration

- **nonprofit**: Donor and grant data for reports
- **bookkeeping**: Financial data for snapshots and board packets
- **contacts**: Contact data for exports
- **documents**: All reports can output as DOCX/PDF via documents skill
- **tasks**: Task data for board packet action items

## Output Formats

- **CSV**: Universal, lightweight
- **XLSX**: Formatted Excel with headers, totals, and styling
- **DOCX/PDF**: Via documents skill integration
