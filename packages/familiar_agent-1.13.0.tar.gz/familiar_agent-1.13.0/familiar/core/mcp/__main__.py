# Familiar MCP Server CLI entry point
# Usage: python -m familiar.core.mcp --skill nonprofit
if __name__ == "__main__":
    from familiar.core.mcp.server import main

    main()
