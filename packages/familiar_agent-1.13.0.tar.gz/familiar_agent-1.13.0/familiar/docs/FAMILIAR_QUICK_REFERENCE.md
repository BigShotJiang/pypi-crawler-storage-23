# Familiar Deployment Quick Reference

## One-Page Deployment Card

---

## 🚀 Quick Start Commands

```bash
# Install (production)
curl -sSL https://install.familiar.ai | sudo bash

# Configure
sudo nano /opt/familiar/.familiar/.env      # Add API keys
sudo nano /opt/familiar/.familiar/config.yaml  # Configure channels

# Start
sudo systemctl start familiar
sudo systemctl enable familiar

# Verify
sudo systemctl status familiar
curl http://localhost:8080/health
```

---

## ✅ Pre-Flight Checklist

### Must Have (Launch Blockers)
```
[ ] API key configured (ANTHROPIC_API_KEY or OPENAI_API_KEY)
[ ] Encryption key generated and backed up
[ ] Running as non-root user (familiar)
[ ] Firewall enabled
[ ] At least one channel configured
```

### Should Have (Production Ready)
```
[ ] TLS/HTTPS enabled
[ ] Backup schedule configured
[ ] Monitoring/alerts configured
[ ] Log rotation configured
[ ] Rate limits configured
```

### Nice to Have (Enterprise)
```
[ ] HA/multi-node deployment
[ ] Cross-region DR
[ ] Secrets in Vault
[ ] Compliance profile enabled
```

---

## 🔧 Common Operations

### Service Management
```bash
sudo systemctl start familiar     # Start
sudo systemctl stop familiar      # Stop
sudo systemctl restart familiar   # Restart
sudo systemctl status familiar    # Status
```

### Logs
```bash
sudo journalctl -u familiar -f              # Live logs
sudo journalctl -u familiar --since "1h"    # Last hour
sudo journalctl -u familiar -p err          # Errors only
```

### Backup
```bash
# Manual backup
sudo /opt/familiar/venv/bin/python -m familiar.core.backup create

# Restore
sudo /opt/familiar/venv/bin/python -m familiar.core.backup restore <backup-id>

# List backups
sudo /opt/familiar/venv/bin/python -m familiar.core.backup list
```

### Health Check
```bash
curl -s http://localhost:8080/health | jq .
```

---

## 🐳 Docker Commands

```bash
# Start stack
docker compose -f docker-compose.production.yml up -d

# View logs
docker compose logs -f familiar

# Scale
docker compose up -d --scale familiar=3

# Update
docker compose pull && docker compose up -d

# Health
docker compose ps
```

---

## ☸️ Kubernetes Commands

```bash
# Deploy
helm upgrade --install familiar ./helm/familiar -n familiar -f values-prod.yaml

# Status
kubectl get pods -n familiar
kubectl rollout status deployment/familiar -n familiar

# Logs
kubectl logs -f -l app=familiar -n familiar

# Scale
kubectl scale deployment familiar --replicas=5 -n familiar

# Rollback
kubectl rollout undo deployment/familiar -n familiar
```

---

## 🚨 Troubleshooting

| Symptom | Check | Fix |
|---------|-------|-----|
| Won't start | `journalctl -u familiar` | Check API keys in .env |
| High latency | `/metrics` endpoint | Scale up or check LLM provider |
| Out of memory | `docker stats` | Increase memory limit |
| Connection refused | Firewall rules | `ufw allow 8080` |
| Auth failures | Audit logs | Check trust levels |

### Emergency Contacts
```
On-call: [YOUR PagerDuty/OpsGenie]
Anthropic Status: status.anthropic.com
OpenAI Status: status.openai.com
```

---

## 📊 Key Metrics to Monitor

| Metric | Warning | Critical |
|--------|---------|----------|
| Error rate | >1% | >5% |
| P99 latency | >5s | >30s |
| Memory usage | >80% | >95% |
| LLM cost/hour | >$5 | >$20 |
| Active sessions | Varies | Varies |

---

## 🔐 Security Quick Checks

```bash
# Verify non-root
ps aux | grep familiar | grep -v root

# Verify file permissions
ls -la /opt/familiar/.familiar/.env  # Should be 600

# Verify no secrets in config
grep -i "sk-\|api_key.*=" /opt/familiar/.familiar/config.yaml

# Verify firewall
sudo ufw status

# Verify encryption enabled
grep "encrypt_sessions: true" /opt/familiar/.familiar/config.yaml
```

---

## 📁 Important Paths

| Path | Purpose |
|------|---------|
| `/opt/familiar/` | Application home |
| `/opt/familiar/.familiar/config.yaml` | Configuration |
| `/opt/familiar/.familiar/.env` | Secrets (600 perms!) |
| `/var/lib/familiar/` | Data directory |
| `/var/log/familiar/` | Log files |
| `/var/backups/familiar/` | Backups |

---

## 🆘 Disaster Recovery

### If Primary Goes Down:

1. **Assess**: Check primary region status
2. **Decide**: Manual failover or wait for recovery?
3. **Execute**: Run `disaster-recovery.sh`
4. **Verify**: Health checks pass
5. **Notify**: Update status page, notify users
6. **Document**: Post-incident report

### RTO/RPO Targets:
- **Personal**: 24h / 24h
- **Team**: 4h / 1h  
- **Business**: 1h / 15m
- **Enterprise**: 15m / 5m

---

*Print this. Laminate it. Keep it by your keyboard.*

*Familiar v2.0.0 — Quick Reference Card*
