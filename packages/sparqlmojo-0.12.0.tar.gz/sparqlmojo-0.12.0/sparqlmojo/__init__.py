"""
SPARQLMojo - A minimal SQLAlchemy-like ORM for SPARQL endpoints.

Top-level package exposing Model, Field types, Session, and Query components.
"""

from importlib.metadata import PackageNotFoundError, version

from .engine import QueryMethod, Session
from .exc import (
    ConfigurationError,
    ConnectionError,
    FieldError,
    IRIError,
    ModelError,
    QueryError,
    RequiredFieldError,
    SPARQLMojoError,
    SessionError,
    SPARQLSyntaxError,
    UnknownFieldError,
    ValidationError,
)
from .orm.security import (
    InvalidIRIError,
    InvalidOperatorError,
    SPARQLInjectionError,
    SPARQLSecurityError,
)
from .orm import (
    Condition,
    IRI,
    IRIField,
    IRIList,
    InverseField,
    LangLiteral,
    LangString,
    LangStringList,
    Literal,
    LiteralField,
    LiteralList,
    Model,
    MultiLangString,
    ObjectPropertyField,
    PropertyInfo,
    PropertyPath,
    Query,
    RDF_TYPE,
    RDFFieldInfo,
    SchemaRegistry,
    SchemaValidationConfig,
    SPARQLCompiler,
    SubjectField,
    TypedLiteral,
    TypedLiteralList,
    XSD,
    XSD_BOOLEAN,
    XSD_DATE,
    XSD_DATETIME,
    XSD_DECIMAL,
    XSD_DOUBLE,
    XSD_FLOAT,
    XSD_INTEGER,
    XSD_STRING,
    clear_global_registry,
    get_global_registry,
    is_collection_field,
    validate_model_against_schema,
)


def _get_version() -> str:
    """Get package version from installed package metadata.

    Version is set in pyproject.toml and can be updated via `poetry version`.
    When package is not installed, returns development fallback.
    """
    try:
        return version("sparqlmojo")
    except PackageNotFoundError:
        return "0.0.0.dev0"


__version__: str = _get_version()
__author__: str = "oliver"
__license__: str = "MIT"

__all__ = [
    "__version__",
    "__author__",
    "__license__",
    # Exceptions
    "SPARQLMojoError",
    "ConfigurationError",
    "ValidationError",
    "ModelError",
    "FieldError",
    "UnknownFieldError",
    "RequiredFieldError",
    "SessionError",
    "ConnectionError",
    "QueryError",
    "SPARQLSyntaxError",
    "IRIError",
    # Security Exceptions
    "SPARQLSecurityError",
    "SPARQLInjectionError",
    "InvalidIRIError",
    "InvalidOperatorError",
    # ORM Components
    "Model",
    "RDFFieldInfo",
    "LiteralField",
    "IRIField",
    "InverseField",
    "ObjectPropertyField",
    "SubjectField",
    "RDF_TYPE",
    "LangString",
    "MultiLangString",
    "PropertyPath",
    "QueryMethod",
    "Session",
    "SPARQLCompiler",
    "Query",
    "Condition",
    # Schema Registry
    "SchemaRegistry",
    "PropertyInfo",
    # Schema Validation
    "SchemaValidationConfig",
    "get_global_registry",
    "clear_global_registry",
    "validate_model_against_schema",
    # Value types (RDF objects)
    "IRI",
    "Literal",
    "LangLiteral",
    "TypedLiteral",
    # Collection field types
    "LiteralList",
    "LangStringList",
    "IRIList",
    "TypedLiteralList",
    "is_collection_field",
    # XSD datatype enum and constants
    "XSD",
    "XSD_STRING",
    "XSD_INTEGER",
    "XSD_DECIMAL",
    "XSD_FLOAT",
    "XSD_DOUBLE",
    "XSD_BOOLEAN",
    "XSD_DATE",
    "XSD_DATETIME",
]
