"""
Engine layer for SPARQLMojo.

Provides SPARQL endpoint session management and query execution.
"""

from .session import QueryMethod, Session

__all__ = ["QueryMethod", "Session"]
