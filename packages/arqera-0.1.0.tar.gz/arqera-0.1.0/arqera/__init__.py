"""ARQERA Python SDK — AI governance that learns.

Usage:
    from arqera import ArqeraClient

    client = ArqeraClient(api_key="ak_...")

    # Evaluate an action against governance laws
    result = client.governance.evaluate(
        action="email.send",
        description="Send quarterly report to investors",
        context={"risk_level": "medium"},
    )

    print(result.verdict)  # "proceed", "escalate", or "block"
"""

from arqera.client import ArqeraClient
from arqera.models import (
    GovernanceResult,
    GovernanceVerdict,
    LawEvaluation,
    LawCheckResult,
    EvidenceArtifact,
    AraAction,
    AraActionStatus,
)

__version__ = "0.1.0"
__all__ = [
    "ArqeraClient",
    "GovernanceResult",
    "GovernanceVerdict",
    "LawEvaluation",
    "LawCheckResult",
    "EvidenceArtifact",
    "AraAction",
    "AraActionStatus",
]
