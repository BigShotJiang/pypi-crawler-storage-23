# ARQERA Python SDK

AI governance that learns. Evaluate actions, enforce compliance, and maintain complete audit trails.

## Installation

```bash
pip install arqera
```

## Quick Start

```python
from arqera import ArqeraClient

client = ArqeraClient(api_key="ak_...")

# Evaluate an action against governance laws
result = client.governance.evaluate(
    "email.send",
    description="Send quarterly report to investors",
    context={"risk_level": "medium"},
)

print(result.verdict)  # "proceed", "escalate", or "block"

if result.passed:
    print("Action allowed")
elif result.needs_approval:
    print("Requires human approval")
elif result.blocked:
    print(f"Blocked: {result.explanation}")
```

## Features

- **Governance Evaluation** -- Evaluate any action against 7 governance laws
- **Ara Actions** -- Execute actions with built-in governance checks
- **Evidence Chain** -- Complete audit trail for compliance (EU AI Act, SOC 2)
- **Human-in-the-Loop** -- Automatic escalation for high-risk actions

## Governance

```python
# Evaluate an action
result = client.governance.evaluate(
    "data.delete",
    description="Delete user records older than 2 years",
    context={"record_count": 1500, "contains_pii": True},
)

# Check per-law results
for law in result.evaluations:
    print(f"Law {law.law_id} ({law.law_name}): {law.result}")
```

## Ara Actions

```python
# Execute with governance
action = client.ara.execute(
    "email.send",
    description="Send quarterly report",
)

# If escalated, approve or reject
if action.status == "pending":
    client.ara.approve(action.id)
    # or: client.ara.reject(action.id, reason="Not ready")

# List pending actions
pending = client.ara.pending()
```

## Evidence

```python
# List evidence artifacts
artifacts = client.evidence.list(artifact_type="governance_evaluation")

# Export for compliance audit
export = client.evidence.export(
    artifact_types=["governance_evaluation"],
    start_date="2026-01-01",
    end_date="2026-03-01",
    export_format="json",
)
```

## Requirements

- Python 3.10+
- `httpx` (installed automatically)

## Links

- [Documentation](https://docs.arqera.io)
- [API Reference](https://docs.arqera.io/api)
- [Website](https://arqera.io)
