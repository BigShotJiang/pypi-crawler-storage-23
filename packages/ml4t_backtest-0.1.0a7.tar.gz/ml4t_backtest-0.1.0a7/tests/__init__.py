"""ml4t.backtest test suite."""
