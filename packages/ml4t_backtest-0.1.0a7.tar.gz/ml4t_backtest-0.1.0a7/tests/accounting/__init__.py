"""Tests for the accounting package."""
