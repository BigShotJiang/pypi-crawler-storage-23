"""Tests for risk management modules."""
