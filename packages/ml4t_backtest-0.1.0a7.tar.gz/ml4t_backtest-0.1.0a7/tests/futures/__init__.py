"""Futures validation test suite.

Validates ML4T-backtest futures calculations against PySystemTrade formulas.
"""
