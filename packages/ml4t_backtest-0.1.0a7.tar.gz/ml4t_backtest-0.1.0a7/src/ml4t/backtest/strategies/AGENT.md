# strategies/ - 438 Lines

Strategy templates and examples.

## Modules

| File | Purpose |
|------|---------|
| templates.py | Reusable strategy patterns |

## Key

`SignalStrategy`, `RebalanceStrategy`, `MomentumTemplate`
