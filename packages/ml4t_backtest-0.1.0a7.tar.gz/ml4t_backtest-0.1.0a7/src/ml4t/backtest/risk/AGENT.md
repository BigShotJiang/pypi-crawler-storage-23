# risk/ - 1.9k Lines

Position sizing and risk management.

## Subpackages

| Directory | Lines | Purpose |
|-----------|-------|---------|
| position/ | 864 | Position sizers |
| portfolio/ | 858 | Portfolio limits |

## Modules

| File | Purpose |
|------|---------|
| types.py | Risk types |

## Key

`PositionSizer`, `PortfolioLimits`, `RiskManager`
