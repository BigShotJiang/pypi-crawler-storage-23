## [0.2.2](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.2.1...v0.2.2) (2026-02-18)


### Bug Fixes

* naming scheme ([c8b7e8d](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/c8b7e8d4af98f9673dc696769c6466426ace0a63))

## [0.2.1](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.2.0...v0.2.1) (2026-02-18)


### Bug Fixes

* banner and naming scheme ([f3d8ece](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/f3d8ece8beb47e8e2dca838b4f37e8c4be406726))

## [0.2.0](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/4e6605fcb156eda11500f4c874149db10c4f7d95...v0.2.0) (2026-02-18)


### Features

* clean commit ([4e6605f](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/4e6605fcb156eda11500f4c874149db10c4f7d95))

