TASKS_JSON = r"""{
    // See https://go.microsoft.com/fwlink/?LinkId=733558
    // for the documentation about the tasks.json format
    "version": "2.0.0",
    "tasks": [
        {
            "label": "Make sphinx docs with taskipy in folder './docs/sphinx'",
            "type": "shell",
            "command": "uv run task docs",
        },
        {
            "label": "Run pytest with taskipy in folder './tests'",
            "type": "shell",
            "command": "uv run task test",
        },
        {
            "label": "Open docs with taskipy in folder './docs/sphinx/build/html'",
            "type": "shell",
            "command": "uv run task open",
        },
        {
            "label": "Update version of package with uv",
            "type": "shell",
            "command": "uv version --bump ${input:semver}",
        },
        {
            "label": "Build package with taskipy in root folder",
            "type": "shell",
            "command": "uv run task build",
        },
        {
            "label": "Publish package with uv using taskipy and pyprj",
            "type": "shell",
            "command": "uv run task publish",
        }
    ],
    "inputs": [
        {
            "id": "semver",
            "type": "pickString",
            "options": [
                "major",
                "minor",
                "patch"
            ],
            "description": "Semantic version part",
            "default": "minor"
        }
    ]
}"""
