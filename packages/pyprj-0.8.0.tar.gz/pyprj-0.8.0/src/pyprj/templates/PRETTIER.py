PRETTIER_JSON: str = """{
    "overrides": [
        {
            "files": "*.md",
            "options": {
                "proseWrap": "always",
                "printWidth": 80,
                "endOfLine": "auto"
            }
        }
    ]
}"""
