from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy
from flask import Blueprint

# =========================
# Objets globaux du module
# =========================
db = SQLAlchemy()
login_manager = LoginManager()
auth_bp = Blueprint("auth", __name__)

# =========================
# Initialisation du module
# =========================
def init_auth(app):
    """
    Initialise le module log_auth sur l'application Flask.
    - Initialise la DB et Flask-Login
    - Enregistre le blueprint
    - Configure le user_loader pour Flask-Login
    """

    # Init DB et login
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    # Importer le modèle User uniquement après init_app pour éviter les circular imports
    from .models import User
    from . import routes  # routes.py doit utiliser auth_bp

    # user_loader pour Flask-Login
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # Enregistrer le blueprint
    app.register_blueprint(auth_bp)

# =========================
# Optionnel : helper pour créer la DB facilement
# =========================
def create_db(app):
    """
    Crée toutes les tables de la DB si elles n'existent pas.
    À appeler après init_auth(app)
    """
    with app.app_context():
        db.create_all()
