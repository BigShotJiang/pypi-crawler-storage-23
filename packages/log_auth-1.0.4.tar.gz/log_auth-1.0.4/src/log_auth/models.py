from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from flask import current_app
from . import db


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

    # =========================
    # PASSWORD MANAGEMENT
    # =========================

    def set_password(self, password: str) -> None:
        """Hash and store the user's password."""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        """Verify the user's password."""
        return check_password_hash(self.password_hash, password)

    # =========================
    # PASSWORD RESET SYSTEM
    # =========================

    def generate_reset_token(self, expires_sec: int = 3600) -> str:
        """
        Generate a timed reset token.
        Default expiration: 1 hour (3600 seconds).
        """
        serializer = URLSafeTimedSerializer(current_app.config["SECRET_KEY"])
        return serializer.dumps(self.id, salt="password-reset-salt")

    @staticmethod
    def verify_reset_token(token: str, max_age: int = 3600):
        """
        Verify reset token.
        Returns the user if valid, otherwise None.
        """
        serializer = URLSafeTimedSerializer(current_app.config["SECRET_KEY"])

        try:
            user_id = serializer.loads(
                token,
                salt="password-reset-salt",
                max_age=max_age
            )
        except SignatureExpired:
            return None
        except BadSignature:
            return None

        return User.query.get(user_id)

    # =========================
    # UPDATE ACCOUNT
    # =========================

    def update_username(self, new_username: str) -> None:
        """Update username safely."""
        self.username = new_username

    def update_password(self, new_password: str) -> None:
        """Update password securely."""
        self.set_password(new_password)
