from .models import db, User


# =========================
# USER CREATION
# =========================

def create_user(username: str, password: str):
    """
    Create a new user.
    Returns (user, None) if success
    Returns (None, error_message) if failure
    """
    if not username or not password:
        return None, "Username and password are required"

    if User.query.filter_by(username=username).first():
        return None, "Username already exists"

    user = User(username=username)
    user.set_password(password)

    db.session.add(user)
    db.session.commit()

    return user, None


# =========================
# AUTHENTICATION
# =========================

def authenticate_user(username: str, password: str):
    """
    Authenticate user credentials.
    Returns user if valid, otherwise None.
    """
    if not username or not password:
        return None

    user = User.query.filter_by(username=username).first()

    if user and user.check_password(password):
        return user

    return None


# =========================
# PASSWORD RESET
# =========================

def request_password_reset(username: str):
    """
    Generate reset token for a user.
    Returns token or None.
    """
    user = User.query.filter_by(username=username).first()
    if not user:
        return None

    return user.generate_reset_token()


def reset_password(token: str, new_password: str):
    """
    Reset user password using token.
    Returns True if success, False otherwise.
    """
    if not token or not new_password:
        return False

    user = User.verify_reset_token(token)
    if not user:
        return False

    user.set_password(new_password)
    db.session.commit()

    return True


# =========================
# ACCOUNT UPDATE
# =========================

def update_user(user: User, new_username: str = None, new_password: str = None):
    """
    Update username and/or password.
    Returns (True, None) if success
    Returns (False, error_message) if failure
    """
    if new_username:
        # Check if username already taken
        existing = User.query.filter_by(username=new_username).first()
        if existing and existing.id != user.id:
            return False, "Username already taken"

        user.update_username(new_username)

    if new_password:
        user.update_password(new_password)

    db.session.commit()
    return True, None
