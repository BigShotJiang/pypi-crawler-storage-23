### Configure Frontend

The `frontend` directory organizes your application themes. Each theme uses jinja template logic to generate data into
HTML. Theme templates are stored in `frontend/themes/{THEME_NAME}/layouts` directory.

### Configure Static Assets
...