title: I'm a demo page
menu.group: primary
content: hi