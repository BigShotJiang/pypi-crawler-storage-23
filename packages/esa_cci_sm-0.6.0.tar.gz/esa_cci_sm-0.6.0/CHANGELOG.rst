=========
Changelog
=========

Unreleased changes (master)
===========================
-

Version v0.6.0
==============
- Added support for subdaily (12-hourly) product
- Set `ignore_meta` to `True` by default during time series conversion
- Update for cci v9 (FT and RZSM support added).

Version v0.5.0
==============
- Update for v9
- Metadata is not included by default anymore
- CI, docs and dependency list updated

Version v0.4.0
==============
- Update for cci v8
- Uses the new smecv_grid now (with latitudes sorted from - to +)

Version v0.3.0
==============
- Update for cci v7

Version v0.2.0
==============
- Update for cci v6

Version v0.1.1
==============
- Update time series reader class
- Unmask smecv grid
- Separate libnetcdf version for python3

Version v0.1
==============

- pypi release
- Homogenize classes for past ESA CCI SM versions
- Update Readme and Documentation
- Change submodule with testdata

Version v0.0.2
==============
- Changing point of origin of gpis to bottom left corner

Version v0.0.1
==============
- Initial version
- Add CCI reshuffle function
- Add CCI readers
