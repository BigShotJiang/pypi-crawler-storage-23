"""py_microservice - FastAPI microservice package."""

from .main import create_app

__all__ = ["create_app"]
