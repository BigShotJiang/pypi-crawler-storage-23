"""Auth service module."""

from . import permission_service

__all__ = [
  "permission_service",
]
