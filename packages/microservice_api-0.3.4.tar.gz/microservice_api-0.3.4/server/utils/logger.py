"""Logger configuration with picologging and JSON formatting."""

import copy
import json
import logging
import sys
from datetime import datetime
from pathlib import Path

import picologging

from .env import LOG_DATE_FORMAT, LOG_LEVEL


def _log_format(record: logging.LogRecord) -> str:
  """Format log record as JSON string."""
  log_record = {
    "t": datetime.fromtimestamp(record.created).strftime(LOG_DATE_FORMAT),
    "l": record.levelname,
    "n": record.name,
    "m": record.getMessage(),
  }

  # Add extra fields if they exist (for uvicorn access logs)
  if hasattr(record, "status_code"):
    log_record["s"] = record.status_code
  if hasattr(record, "client_addr"):
    log_record["c"] = record.client_addr
  if hasattr(record, "method"):
    log_record["fn"] = record.method
  if hasattr(record, "path"):
    log_record["p"] = record.path

  if record.exc_info:
    log_record["e"] = logging.Formatter().formatException(record.exc_info)
  return json.dumps(log_record)


class JsonFormatter(logging.Formatter):
  """Custom JSON formatter for standard logging (uvicorn)."""

  def format(self, record):
    return _log_format(record)


class PicologgingJsonFormatter(picologging.Formatter):
  """Custom JSON formatter for picologging."""

  def format(self, record):
    return _log_format(record)


# Configure picologging root logger with JSON formatter
_handler = picologging.StreamHandler(sys.stdout)
_handler.setFormatter(PicologgingJsonFormatter(datefmt=LOG_DATE_FORMAT))
_root_logger = picologging.getLogger()
_root_logger.addHandler(_handler)
_root_logger.setLevel(getattr(picologging, LOG_LEVEL.upper(), picologging.INFO))

_LOGGING_CONFIG_PATH = Path(__file__).with_name("logging_config.json")


def load_logging_config() -> dict:
  """Load default logging config from logging_config.json."""
  with _LOGGING_CONFIG_PATH.open("r", encoding="utf-8") as handle:
    config = json.load(handle)

  formatter = config.get("formatters", {}).get("json")
  if isinstance(formatter, dict) and formatter.get("()"):
    formatter["()"] = JsonFormatter

  return config


DEFAULT_LOGGING_CONFIG = load_logging_config()


def get_logger(name: str):
  """Get a logger instance with the given name."""
  logger = picologging.getLogger(name)
  logger.setLevel(getattr(picologging, LOG_LEVEL.upper(), picologging.INFO))
  return logger


def get_logging_config() -> dict:
  """Return a copy of the default logging config."""
  return copy.deepcopy(DEFAULT_LOGGING_CONFIG)
