from typing import Any, Optional

from pydantic import BaseModel as PydanticBaseModel
from tortoise import Model, fields


class Response(PydanticBaseModel):
  ok: bool = True
  error: Optional[str] = None
  data: Any


class BaseModel(Model):
  id = fields.IntField(primary_key=True)
  created_at = fields.DatetimeField(auto_now_add=True)
  updated_at = fields.DatetimeField(auto_now=True)
  deleted_at = fields.DatetimeField(null=True)

  class Meta:
    abstract = True


class BaseModelWithAudit(BaseModel):
  created_by = fields.IntField(null=True)
  updated_by = fields.IntField(null=True)

  class Meta:
    abstract = True


class Pagination(PydanticBaseModel):
  page: int
  limit: int
  total: int
  totalPages: int
  
  @classmethod
  def set(cls, page: int, limit: int, total: int) -> "Pagination":
    total_pages = (total + limit - 1) // limit
    return cls(
      page=page,
      limit=limit,
      total=total,
      totalPages=total_pages,
    )
  