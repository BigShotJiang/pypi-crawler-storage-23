from datetime import datetime, timezone
from typing import List, Optional

from tortoise import fields
from tortoise.expressions import Q

from ..schema import BaseModelWithAudit


class User(BaseModelWithAudit):
  """User model representing the users table."""
  email = fields.CharField(max_length=255, unique=True)
  phone = fields.CharField(max_length=50, null=True)
  name = fields.CharField(max_length=255)
  password_hash = fields.CharField(max_length=255, null=True)
  google_id = fields.CharField(max_length=255, unique=True, null=True)
  google_avatar_url = fields.CharField(max_length=2048, null=True)
  google_token_expiry = fields.DatetimeField(null=True)

  # Relationships
  groups: fields.ManyToManyRelation["Group"] = fields.ManyToManyField(
    "models.Group", related_name="users", through="user_groups", forward_key="user_id", backward_key="group_id"
  )
  permissions: fields.ReverseRelation["Permission"]

  class Meta:
    table = "users"
    indexes = [("email",), ("google_id",)]

  class PydanticMeta:
    exclude = ["password_hash"]

  def __str__(self) -> str:
    return f"<User(id={self.id}, email='{self.email}', name='{self.name}')>"

  # CRUD Operations
  @classmethod
  async def create_user(
    cls,
    email: str,
    name: str,
    password_hash: Optional[str] = None,
    phone: Optional[str] = None,
    google_id: Optional[str] = None,
    google_avatar_url: Optional[str] = None,
    google_token_expiry: Optional[str] = None,
    created_by: Optional[int] = None,
  ) -> "User":
    """Create a new user."""
    return await cls.create(
      email=email,
      name=name,
      password_hash=password_hash,
      phone=phone,
      google_id=google_id,
      google_avatar_url=google_avatar_url,
      google_token_expiry=google_token_expiry,
      created_by=created_by,
    )

  @classmethod
  async def get_by_id(cls, user_id: int) -> Optional["User"]:
    """Get a user by ID."""
    return await cls.filter(id=user_id, deleted_at=None).first()

  @classmethod
  async def get_by_email(cls, email: str) -> Optional["User"]:
    """Get a user by email."""
    return await cls.filter(email=email, deleted_at=None).first()

  @classmethod
  async def get_by_google_id(cls, google_id: str) -> Optional["User"]:
    """Get a user by Google ID."""
    return await cls.filter(google_id=google_id, deleted_at=None).first()

  @classmethod
  async def get_all(cls, skip: int = 0, limit: int = 100) -> List["User"]:
    """Get all users with pagination."""
    return await cls.filter(deleted_at=None).offset(skip).limit(limit)

  @classmethod
  async def search_by_name_or_email(
    cls,
    search: str,
    skip: int = 0,
    limit: int = 100,
  ) -> List["User"]:
    """Search users by name or email with pagination.

    Results are ordered by name to make search results deterministic and to
    ensure that exact matches (or lexicographically earlier names) appear
    first. This helps tests that expect a particular ordering such as
    returning "Test User" before "Test User Root".
    """
    return (
      await cls.filter((Q(name__icontains=search) | Q(email__icontains=search)) & Q(deleted_at=None))
      .order_by("name")
      .offset(skip)
      .limit(limit)
      .all()
    )

  async def update_user(self, **kwargs) -> "User":
    """Update user fields."""
    # Optional fields that can be set to None (to clear them)
    optional_fields = {"phone", "google_id", "google_avatar_url", "google_token_expiry", "updated_by"}
    for key, value in kwargs.items():
      if hasattr(self, key):
        # Allow None values for optional fields to clear them, skip None for required fields
        if value is not None or key in optional_fields:
          setattr(self, key, value)
    await self.save()
    return self

  async def delete_user(self) -> None:
    """Delete the user."""
    self.deleted_at = datetime.now(timezone.utc)
    await self.save()

  @classmethod
  async def delete_by_id(cls, user_id: int) -> bool:
    """Delete a user by ID. Returns True if deleted."""
    deleted_count = await cls.filter(id=user_id, deleted_at=None).update(deleted_at=datetime.now(timezone.utc))
    return deleted_count > 0

  @classmethod
  async def count(cls) -> int:
    """Count total users."""
    return await cls.filter(deleted_at=None).count()


# Import at bottom to avoid circular imports
from .group import Group
from .permission import Permission
