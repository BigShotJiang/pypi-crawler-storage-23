"""Middleware module for FastAPI application."""

import time
import uuid
from typing import Callable

import jwt
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from tortoise.context import TortoiseContext, _current_context

from ..models.auth import Permission, User
from ..utils.env import SERVICE_API_PREFIX, SERVICE_CORS, AUTH_JWT_ALGORITHM, AUTH_JWT_SECRET, SERVICE_ENABLE_AUTH, SERVICE_PUBLIC_PATHS, SERVICE_ENABLE_DB
from ..utils.logger import get_logger

logger = get_logger(__name__)

# Paths to ignore for middleware
IGNORE_PATHS = {
  "/api/v1/health",
  "/static",
}

# Paths that don't require authorization
PUBLIC_PATHS = {
  f"{SERVICE_API_PREFIX}/health",
  f"{SERVICE_API_PREFIX}/auth/oauth/google",
  f"{SERVICE_API_PREFIX}/auth/login",
  f"{SERVICE_API_PREFIX}/auth/logout",
  f"{SERVICE_API_PREFIX}/auth/verify",
  "/docs",
  "/redoc",
  "/openapi.json",
}

PUBLIC_PATHS = PUBLIC_PATHS.union(set(SERVICE_PUBLIC_PATHS))


def _map_http_method_to_permission(method: str) -> str:
  """Map HTTP method to permission type."""
  method_map = {
    "GET": "r",  # read
    "HEAD": "r",  # read
    "OPTIONS": "r",  # read
    "POST": "w",  # write
    "PUT": "w",  # write
    "PATCH": "w",  # write
    "DELETE": "d",  # delete
  }
  return method_map.get(method.upper(), "r")


async def _get_user_permitted_resources(user_id: int, permission_type: str) -> set[str]:
  """Get all resource paths the user has permission for (direct + group level).

  Permission hierarchy: delete (d) > write (w) > read (r)
  - If user has 'd' permission, they also have 'w' and 'r'
  - If user has 'w' permission, they also have 'r'

  Args:
      user_id: The user ID to check permissions for
      permission_type: The permission type ('r', 'w', 'd')

  Returns:
      Set of sorted resource paths the user has the specified permission for
  """
  from tortoise.expressions import Q

  permitted_paths = set()

  # Build permission filter based on hierarchy
  # d implies w and r, w implies r
  if permission_type == "r":
    # Read access: any of r, w, or d grants read
    perm_filter = Q(type="r") | Q(type="w") | Q(type="d")
  elif permission_type == "w":
    # Write access: w or d grants write
    perm_filter = Q(type="w") | Q(type="d")
  else:
    # Delete access: only d grants delete
    perm_filter = Q(type="d")

  # Get direct user permissions with the required permission type
  user_permissions = await Permission.filter(Q(entity_type="user", entity_id=user_id) & perm_filter).prefetch_related(
    "resource"
  )

  for perm in user_permissions:
    if perm.resource:
      permitted_paths.add(perm.resource.path)

  # Get group permissions
  user = await User.get_by_id(user_id)
  if user:
    await user.fetch_related("groups")
    for group in user.groups:
      group_permissions = await Permission.filter(
        Q(entity_type="group", entity_id=group.id) & perm_filter
      ).prefetch_related("resource")

      for perm in group_permissions:
        if perm.resource:
          permitted_paths.add(perm.resource.path)

  return sorted(permitted_paths, key=len)


def _path_matches_resource(resource_path: str, permitted_paths: set[str]) -> bool:
  """Check if a resource path matches any permitted path pattern.

  Args:
      resource_path: The path being accessed (e.g., /auth/groups/1)
      permitted_paths: Set of permitted path patterns (e.g., {/auth/groups/*, /auth/*, *})

  Returns:
      True if the resource_path matches any permitted_path pattern
  """

  # Split resource path into segments for matching
  resource_segments = resource_path.strip("/").split("/")

  for permitted_path in permitted_paths:
    # Root wildcard "*" matches everything
    if permitted_path == "*":
      return True

    # Exact match
    if resource_path == permitted_path:
      return True

    # Wildcard match (e.g., /auth/groups/* matches /auth/groups and /auth/groups/1)
    if permitted_path.endswith("/*"):
      base_path = permitted_path[:-2]  # Remove /*
      permitted_segments = base_path.strip("/").split("/")

      # Check if resource path starts with permitted segments
      if len(resource_segments) >= len(permitted_segments):
        if resource_segments[: len(permitted_segments)] == permitted_segments:
          return True

  return False


async def _check_user_permission(user_id: int, resource_path: str, permission_type: str) -> bool:
  """Check if user has permission to access resource.

  Args:
      user_id: The user ID to check
      resource_path: The resource path being accessed
      permission_type: The permission type required ('r', 'w', 'd')

  Returns:
      True if user has the required permission
  """
  # Get all resources user has permission for
  permitted_paths = await _get_user_permitted_resources(user_id, permission_type)

  # Check if any permitted path matches the requested resource
  return _path_matches_resource(resource_path, permitted_paths)


async def _get_user_accessible_resources(user_id: int, current_path: str) -> list[str]:
  """Get resource paths the user has access to, filtered by current request path."""
  # Reuse _get_user_permitted_resources with 'r' (read) permission
  # Since read is the lowest level, this returns all resources the user can access
  accessible_paths = await _get_user_permitted_resources(user_id, "r")

  # If user has root "*" access, return wildcard for current path
  if "*" in accessible_paths:
    # Extract base path from current request (e.g., /auth/groups from /auth/groups/1)
    path_parts = current_path.strip("/").split("/")
    base_path = "/" + "/".join(path_parts[:2]) if len(path_parts) >= 2 else current_path
    return [base_path + "/*"]

  # Filter resources based on current path
  # Extract base path from current request (e.g., /auth/groups from /auth/groups/1)
  path_parts = current_path.strip("/").split("/")
  # Take first 2-3 segments as base path
  base_path = "/" + "/".join(path_parts[:2]) if len(path_parts) >= 2 else current_path

  # Filter accessible paths that match the base path
  # Delegate matching (including wildcards and segment boundaries) to _path_matches_resource
  filtered_paths = [path for path in accessible_paths if _path_matches_resource(base_path, path)]

  # If there's a wildcard path, only return wildcard paths (they cover specific resources)
  wildcard_paths = [path for path in filtered_paths if path.endswith("/*")]
  if wildcard_paths:
    return wildcard_paths

  return filtered_paths


async def authorize_middleware(request: Request, call_next):
  """Middleware to authorize user access to resources."""
  path = request.url.path

  # Skip authorization for public paths
  if path in PUBLIC_PATHS or path.startswith("/static"):
    return await call_next(request)
  # Skip authorization for OPTIONS requests (CORS preflight)
  if request.method == "OPTIONS":
    return await call_next(request)

  # Get user_id from request state (set by request_middleware)
  user_id = getattr(request.state, "user_id", None)

  # If no user_id, deny access (except for public paths)
  if not user_id:
    logger.warning(f"Unauthorized access attempt to {path}")
    return JSONResponse(
      status_code=401,
      content={"ok": False, "error": "Unauthorized - Authentication required", "data": None},
    )

  # Determine required permission type based on HTTP method
  required_permission = _map_http_method_to_permission(request.method)

  # Remove /api/v1 prefix for permission checking (resources are stored without it)
  resource_path = path.removeprefix("/api/v1") if path.startswith("/api/v1") else path

  # Check if user has permission
  has_permission = await _check_user_permission(user_id, resource_path, required_permission)

  if not has_permission:
    logger.warning(f"Access denied for user {user_id} to {path} " f"(required: {required_permission})")
    return JSONResponse(
      status_code=403,
      content={
        "ok": False,
        "error": "Forbidden - Insufficient permissions",
        "data": None,
      },
    )

  # Get accessible resources for the user filtered by current path
  accessible_resources = await _get_user_accessible_resources(user_id, resource_path)
  request.state.accessible_resources = accessible_resources

  # User has permission, proceed
  return await call_next(request)


async def request_middleware(request: Request, call_next):
  """Middleware to add request ID, extract user ID from JWT, and log requests."""
  if request.url.path in IGNORE_PATHS:
    return await call_next(request)

  start_time = time.perf_counter()

  # Generate a unique request ID
  request_id = str(uuid.uuid4())
  request.state.request_id = request_id

  # Extract user ID from JWT if present
  user_id = None
  auth_header = request.headers.get("Authorization")
  if auth_header and auth_header.startswith("Bearer "):
    token = auth_header[7:]  # Remove "Bearer " prefix
    try:
      payload = jwt.decode(token, AUTH_JWT_SECRET, algorithms=[AUTH_JWT_ALGORITHM])
      user_id = payload.get("sub") or payload.get("user_id")
      request.state.user_id = user_id
    except jwt.PyJWTError:
      pass  # Invalid token, user_id remains None
  try:
    response = await call_next(request)
  except Exception as e:
    # Log the exception with request context
    logger.error(
      f"Exception during request processing: {e} - request_id={request_id} user_id={user_id}",
      exc_info=True,
    )
    raise e
  # Calculate processing time
  process_time = (time.perf_counter() - start_time) * 1000  # Convert to milliseconds

  # Log request with context
  log = logger.info
  if response.status_code >= 500:
    log = logger.error
  log(
    f"{request.method} {request.url.path} - {response.status_code} - "
    f"{process_time:.2f}ms - request_id={request_id} user_id={user_id}"
  )

  # Add headers to response
  response.headers["X-Request-ID"] = request_id
  response.headers["X-Process-Time"] = f"{process_time:.2f}ms"

  return response


async def tortoise_context_middleware(request: Request, call_next: Callable):
  """Inject the server-level TortoiseContext into each request's async task.

  Required because _enable_global_fallback=False: contextvars are not inherited
  by request handler tasks spawned by uvicorn after lifespan startup.
  """
  ctx: TortoiseContext | None = getattr(request.app.state, "db_ctx", None)
  if ctx is not None:
    token = _current_context.set(ctx)
    try:
      return await call_next(request)
    finally:
      _current_context.reset(token)
  return await call_next(request)


def register_middlewares(app: FastAPI):
  """Register all middlewares with the FastAPI application."""

  # If Auth is enabled only then add the authorize middleware
  if SERVICE_ENABLE_AUTH:
    app.middleware("http")(authorize_middleware)
    
  # Inject TortoiseContext into each request task when DB is enabled
  if SERVICE_ENABLE_DB:
    app.middleware("http")(tortoise_context_middleware)

  app.middleware("http")(request_middleware)
  app.add_middleware(
    CORSMiddleware,
    allow_origins=SERVICE_CORS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-Request-ID", "X-Process-Time"],
  )
