from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials

from ...models.auth import User
from ...models.auth.schemas import (
  LoginRequest,
  LoginResponse,
  LogoutResponse,
  OAuthLoginRequest,
  OAuthLoginResponse,
  Response,
)
from ...utils.env import AUTH_JWT_EXPIRATION_HOURS
from ...utils.logger import get_logger

from .helper import (
  create_access_token,
  security,
  token_blacklist,
  user_to_response,
  verify_password,
)
from .oauth_helpers import get_oauth_user_info

logger = get_logger(__name__)


async def login(request: LoginRequest):
  """Authenticate a user and return an access token."""
  user = await User.get_by_email(request.email)

  if not user or not verify_password(request.password, user.password_hash):
    raise HTTPException(status_code=401, detail="Invalid email or password")

  token = create_access_token(user.id, user.email)
  user_response = await user_to_response(user)

  return Response(
    data=LoginResponse(
      token=token,
      expiresIn=AUTH_JWT_EXPIRATION_HOURS * 3600,
      user=user_response,
    )
  )


async def logout(credentials: HTTPAuthorizationCredentials = Depends(security)):
  """Invalidate the current user session."""
  token = credentials.credentials
  token_blacklist.add(token)

  return Response(data=LogoutResponse(message="Successfully logged out"))


async def oauth_login(request: OAuthLoginRequest):
  """Authenticate a user via OAuth provider and return an access token."""
  provider = request.provider.value
  logger.info("Starting OAuth login via provider '%s'", provider)

  # Get user info from OAuth provider
  try:
    oauth_info = await get_oauth_user_info(
      provider=provider, code=request.code, code_verifier=request.codeVerifier, redirect_uri=request.redirectUri
    )
  except HTTPException as exc:
    logger.warning("OAuth provider '%s' rejected authorization code: %s", provider, exc.detail)
    raise HTTPException(status_code=400, detail="Invalid authorization code") from exc
  except Exception as exc:
    logger.exception("Unexpected error while retrieving OAuth info from provider '%s'", provider)
    raise HTTPException(status_code=500, detail="Failed to retrieve user information from OAuth provider") from exc

  is_new_user = False
  user = None

  # Check if user exists by provider-specific ID (currently only Google has this field)
  if oauth_info.provider == "google":
    user = await User.get_by_google_id(oauth_info.provider_user_id)
  else:
    # TODO: Implement for other providers as needed
    logger.error("OAuth login attempted for unsupported provider '%s'", oauth_info.provider)
    raise HTTPException(status_code=400, detail="OAuth provider not supported")

  # If not found by provider ID, try to find by email
  if not user:
    user = await User.get_by_email(oauth_info.email)

  # If user exists, update OAuth tokens if it's a Google login
  if user:
    if oauth_info.provider == "google":
      await user.update_user(
        google_id=oauth_info.provider_user_id,
        google_avatar_url=oauth_info.avatar_url,
      )
  else:
    # Create new user
    is_new_user = True
    user_data = {
      "email": oauth_info.email,
      "name": oauth_info.name,
    }

    # Add Google-specific fields if applicable
    if oauth_info.provider == "google":
      user_data.update(
        {
          "google_id": oauth_info.provider_user_id,
          "google_avatar_url": oauth_info.avatar_url,
        }
      )

    user = await User.create_user(**user_data)

  # Generate JWT token
  token = create_access_token(user.id, user.email)
  user_response = await user_to_response(user)

  return Response(
    data=OAuthLoginResponse(
      token=token,
      expiresIn=AUTH_JWT_EXPIRATION_HOURS * 3600,
      user=user_response,
      isNewUser=is_new_user,
    )
  )
