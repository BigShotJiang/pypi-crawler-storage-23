# microservice-api

Lightweight FastAPI microservice for identity and access management, built with asyncpg and Tortoise ORM.

## Features

- FastAPI endpoints for auth, users, groups, and permissions
- Async Postgres stack with Tortoise ORM and asyncpg
- JWT-based auth helpers and middleware
- Background worker scaffolding

## Installation

```bash
pip install microservice-api
```

## Quickstart

```bash
uvicorn microservice.main:create_app --factory --reload
```

## Example

Run the minimal example (no DB/auth/worker) from the repo:

```bash
make install
make run
```

Or run it directly:

```bash
./.venv/bin/python examples/run.py
```

## Configuration

Set environment variables in a `.env` file or your shell. Common values include database connection info and JWT secrets.

## Development

```bash
pip install -e .[dev]
pytest
```
