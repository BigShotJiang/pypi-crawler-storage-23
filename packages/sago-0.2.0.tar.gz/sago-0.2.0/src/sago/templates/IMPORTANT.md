# Important

When working on this project:

1. **Always reference PLAN.md** to stay focused on atomic tasks
2. **Update STATE.md** after each session
3. **Use the XML schema** strictly - it forces better task decomposition
4. **Verify completion** using the `<verify>` commands
