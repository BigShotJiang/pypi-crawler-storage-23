from __future__ import annotations
import os as _o, struct as _s, time as _t, base64 as _b64, hashlib as _h, hmac as _hm
import ctypes as _c, sys as _sys

# ─── load openssl ─────────────────────────────────────────────────────────────

def _load_lib() -> _c.CDLL:
    if _sys.platform == "win32":
        for n in ("libcrypto-3-x64.dll","libcrypto-3.dll","libcrypto.dll"):
            try: return _c.CDLL(n)
            except OSError: continue
        raise OSError("OpenSSL not found. Install from https://slproweb.com/products/Win32OpenSSL.html")
    elif _sys.platform == "darwin":
        for n in ("libcrypto.3.dylib","libcrypto.dylib","/opt/homebrew/lib/libcrypto.3.dylib","/usr/local/lib/libcrypto.3.dylib"):
            try: return _c.CDLL(n)
            except OSError: continue
        raise OSError("OpenSSL not found. Install via: brew install openssl")
    else:
        for n in ("libcrypto.so.3","libcrypto.so"):
            try: return _c.CDLL(n)
            except OSError: continue
        raise OSError("OpenSSL not found. Install via: apt install libssl-dev")

_lib = _load_lib()
_ci  = _c.c_int
_cv  = _c.c_void_p
_cc  = _c.c_char_p

# ─── openssl bindings ────────────────────────────────────────────────────────

_lib.EVP_CIPHER_CTX_new.restype          = _cv
_lib.EVP_aes_256_gcm.restype             = _cv
_lib.EVP_aes_256_cbc.restype             = _cv
_lib.EVP_chacha20_poly1305.restype       = _cv
_lib.EVP_EncryptInit_ex.argtypes         = [_cv,_cv,_cv,_cc,_cc]; _lib.EVP_EncryptInit_ex.restype  = _ci
_lib.EVP_DecryptInit_ex.argtypes         = [_cv,_cv,_cv,_cc,_cc]; _lib.EVP_DecryptInit_ex.restype  = _ci
_lib.EVP_CIPHER_CTX_ctrl.argtypes        = [_cv,_ci,_ci,_cv];     _lib.EVP_CIPHER_CTX_ctrl.restype = _ci
_lib.EVP_EncryptUpdate.argtypes          = [_cv,_cc,_c.POINTER(_ci),_cc,_ci]; _lib.EVP_EncryptUpdate.restype  = _ci
_lib.EVP_DecryptUpdate.argtypes          = [_cv,_cc,_c.POINTER(_ci),_cc,_ci]; _lib.EVP_DecryptUpdate.restype  = _ci
_lib.EVP_EncryptFinal_ex.argtypes        = [_cv,_cc,_c.POINTER(_ci)]; _lib.EVP_EncryptFinal_ex.restype = _ci
_lib.EVP_DecryptFinal_ex.argtypes        = [_cv,_cc,_c.POINTER(_ci)]; _lib.EVP_DecryptFinal_ex.restype = _ci
_lib.EVP_CIPHER_CTX_free.argtypes        = [_cv]
_lib.EVP_CIPHER_CTX_set_padding.argtypes = [_cv,_ci]; _lib.EVP_CIPHER_CTX_set_padding.restype = _ci

_GCM_SIVLEN = 0x9
_GCM_GTAG   = 0x10
_GCM_STAG   = 0x11

# ─── prefixes ────────────────────────────────────────────────────────────────
# full
_PX1 = b"secry:v1:"
_PX2 = b"secry:v2:"
_PX3 = b"secry:v3:"
# compact
_CPX1 = b"sec:v1:"
_CPX2 = b"sec:v2:"
_CPX3 = b"sec:v3:"
# legacy rwn64 (read-only compat)
_LPX1 = b"rwn64:v1:"
_LPX2 = b"rwn64:v2:"
_LPX3 = b"rwn64:v3:"

# sizes
_SL   = 16   # salt full
_SL_C = 8    # salt compact
_NL   = 12   # nonce v1/v2 full
_NL3  = 16   # nonce v3 full
_NL_C = 8    # nonce compact (all versions)
_TL   = 16   # tag
_KL   = 32   # key
_N,_R,_P = 16384,8,1

# ─── encoding detection ──────────────────────────────────────────────────────

def _detect_encoding(data: bytes) -> str:
    if data[:3] == b"\xef\xbb\xbf": return "utf-8-sig"
    if data[:2] in (b"\xff\xfe", b"\xfe\xff"): return "utf-16"
    try: data.decode("utf-8"); return "utf-8"
    except UnicodeDecodeError: pass
    for enc in ("latin-1", "cp1252", "iso-8859-1"):
        try: data.decode(enc); return enc
        except UnicodeDecodeError: continue
    return "latin-1"

def decode_auto(data: bytes) -> tuple[str, str]:
    enc = _detect_encoding(data)
    return data.decode(enc), enc

# ─── kdf ─────────────────────────────────────────────────────────────────────

def _kdf(pw: bytes, salt: bytes) -> bytes:
    return _h.scrypt(pw, salt=salt, n=_N, r=_R, p=_P, dklen=_KL)

# ─── v1 — AES-256-GCM ────────────────────────────────────────────────────────

def _enc_v1(key: bytes, nonce: bytes, pt: bytes) -> tuple[bytes, bytes]:
    x = _lib.EVP_CIPHER_CTX_new()
    _lib.EVP_EncryptInit_ex(x, _lib.EVP_aes_256_gcm(), None, None, None)
    _lib.EVP_CIPHER_CTX_ctrl(x, _GCM_SIVLEN, len(nonce), None)
    _lib.EVP_EncryptInit_ex(x, None, None, key, nonce)
    buf = _c.create_string_buffer(len(pt)+16); l = _ci(0)
    _lib.EVP_EncryptUpdate(x, buf, _c.byref(l), pt, len(pt))
    ct = buf.raw[:l.value]
    _lib.EVP_EncryptFinal_ex(x, buf, _c.byref(l))
    tag = _c.create_string_buffer(16)
    _lib.EVP_CIPHER_CTX_ctrl(x, _GCM_GTAG, 16, tag)
    _lib.EVP_CIPHER_CTX_free(x)
    return ct, tag.raw

def _dec_v1(key: bytes, nonce: bytes, ct: bytes, tag: bytes) -> bytes:
    x = _lib.EVP_CIPHER_CTX_new()
    _lib.EVP_DecryptInit_ex(x, _lib.EVP_aes_256_gcm(), None, None, None)
    _lib.EVP_CIPHER_CTX_ctrl(x, _GCM_SIVLEN, len(nonce), None)
    _lib.EVP_DecryptInit_ex(x, None, None, key, nonce)
    buf = _c.create_string_buffer(len(ct)+16); l = _ci(0)
    _lib.EVP_DecryptUpdate(x, buf, _c.byref(l), ct, len(ct))
    pt = buf.raw[:l.value]
    _lib.EVP_CIPHER_CTX_ctrl(x, _GCM_STAG, 16, _c.c_char_p(tag))
    fin = _c.create_string_buffer(16)
    ok = _lib.EVP_DecryptFinal_ex(x, fin, _c.byref(l))
    _lib.EVP_CIPHER_CTX_free(x)
    if ok <= 0: raise ValueError("wrong password or corrupted token")
    return pt

# ─── v2 — ChaCha20-Poly1305 ──────────────────────────────────────────────────

def _enc_v2(key: bytes, nonce: bytes, pt: bytes) -> tuple[bytes, bytes]:
    x = _lib.EVP_CIPHER_CTX_new()
    _lib.EVP_EncryptInit_ex(x, _lib.EVP_chacha20_poly1305(), None, None, None)
    _lib.EVP_CIPHER_CTX_ctrl(x, _GCM_SIVLEN, len(nonce), None)
    _lib.EVP_EncryptInit_ex(x, None, None, key, nonce)
    buf = _c.create_string_buffer(len(pt)+16); l = _ci(0)
    _lib.EVP_EncryptUpdate(x, buf, _c.byref(l), pt, len(pt))
    ct = buf.raw[:l.value]
    _lib.EVP_EncryptFinal_ex(x, buf, _c.byref(l))
    tag = _c.create_string_buffer(16)
    _lib.EVP_CIPHER_CTX_ctrl(x, _GCM_GTAG, 16, tag)
    _lib.EVP_CIPHER_CTX_free(x)
    return ct, tag.raw

def _dec_v2(key: bytes, nonce: bytes, ct: bytes, tag: bytes) -> bytes:
    x = _lib.EVP_CIPHER_CTX_new()
    _lib.EVP_DecryptInit_ex(x, _lib.EVP_chacha20_poly1305(), None, None, None)
    _lib.EVP_CIPHER_CTX_ctrl(x, _GCM_SIVLEN, len(nonce), None)
    _lib.EVP_DecryptInit_ex(x, None, None, key, nonce)
    buf = _c.create_string_buffer(len(ct)+16); l = _ci(0)
    _lib.EVP_DecryptUpdate(x, buf, _c.byref(l), ct, len(ct))
    pt = buf.raw[:l.value]
    _lib.EVP_CIPHER_CTX_ctrl(x, _GCM_STAG, 16, _c.c_char_p(tag))
    fin = _c.create_string_buffer(16)
    ok = _lib.EVP_DecryptFinal_ex(x, fin, _c.byref(l))
    _lib.EVP_CIPHER_CTX_free(x)
    if ok <= 0: raise ValueError("wrong password or corrupted token")
    return pt

# ─── v3 — AES-256-CBC ────────────────────────────────────────────────────────

def _pad(data: bytes) -> bytes:
    pad_len = 16 - len(data) % 16
    return data + bytes([pad_len] * pad_len)

def _unpad(data: bytes) -> bytes:
    return data[:-data[-1]]

def _enc_v3(key: bytes, iv: bytes, pt: bytes) -> bytes:
    x = _lib.EVP_CIPHER_CTX_new()
    _lib.EVP_EncryptInit_ex(x, _lib.EVP_aes_256_cbc(), None, key, iv)
    _lib.EVP_CIPHER_CTX_set_padding(x, 0)
    padded = _pad(pt)
    buf = _c.create_string_buffer(len(padded)+16); l = _ci(0)
    _lib.EVP_EncryptUpdate(x, buf, _c.byref(l), padded, len(padded))
    ct = buf.raw[:l.value]
    _lib.EVP_EncryptFinal_ex(x, buf, _c.byref(l))
    _lib.EVP_CIPHER_CTX_free(x)
    return ct

def _dec_v3(key: bytes, iv: bytes, ct: bytes) -> bytes:
    x = _lib.EVP_CIPHER_CTX_new()
    _lib.EVP_DecryptInit_ex(x, _lib.EVP_aes_256_cbc(), None, key, iv)
    _lib.EVP_CIPHER_CTX_set_padding(x, 0)
    buf = _c.create_string_buffer(len(ct)+16); l = _ci(0)
    _lib.EVP_DecryptUpdate(x, buf, _c.byref(l), ct, len(ct))
    pt = buf.raw[:l.value]
    _lib.EVP_DecryptFinal_ex(x, buf, _c.byref(l))
    _lib.EVP_CIPHER_CTX_free(x)
    return _unpad(pt)

# ─── helpers ─────────────────────────────────────────────────────────────────

def _b64e(b: bytes) -> bytes: return _b64.urlsafe_b64encode(b).rstrip(b"=")
def _b64d(b: bytes) -> bytes:
    p = 4 - len(b) % 4
    return _b64.urlsafe_b64decode(b + (b"=" * p if p != 4 else b""))

def _eexp(ms: int) -> bytes: return _s.pack(">II", ms >> 32, ms & 0xFFFFFFFF)
def _dexp(b: bytes) -> int:
    hi, lo = _s.unpack(">II", b); return (hi << 32) | lo

def _build_inner(plaintext: str | bytes, expires_ms: int | None) -> bytes:
    if isinstance(plaintext, bytes):
        plaintext, _ = decode_auto(plaintext)
    hx = expires_ms is not None
    return (b"\x01" + _eexp(expires_ms) if hx else b"\x00") + plaintext.encode("utf-8")

def _parse_inner(inner: bytes) -> tuple[str, int | None]:
    if inner[0] == 1:
        exp = _dexp(inner[1:9])
        if int(_t.time() * 1000) > exp:
            raise ValueError(f"token expired at {exp}")
        return inner[9:].decode("utf-8"), exp
    return inner[1:].decode("utf-8"), None

# ─── detect token ────────────────────────────────────────────────────────────

def _detect(tb: bytes):
    """Returns (prefix, version_int, nonce_len, salt_len, compact, is_legacy)"""
    checks = [
        (_PX1,  1, _NL,   _SL,   False, False),
        (_PX2,  2, _NL,   _SL,   False, False),
        (_PX3,  3, _NL3,  _SL,   False, False),
        (_CPX1, 1, _NL_C, _SL_C, True,  False),
        (_CPX2, 2, _NL_C, _SL_C, True,  False),
        (_CPX3, 3, _NL_C, _SL_C, True,  False),
        (_LPX1, 1, _NL,   _SL,   False, True),
        (_LPX2, 2, _NL,   _SL,   False, True),
        (_LPX3, 3, _NL3,  _SL,   False, True),
    ]
    for pfx, ver, nl, sl, compact, legacy in checks:
        if tb.startswith(pfx):
            return pfx, ver, nl, sl, compact, legacy
    raise ValueError("invalid token format")

# ─── nonce helpers for compact mode ──────────────────────────────────────────

def _pad_nonce(n: bytes, target: int) -> bytes:
    """Pad or truncate nonce to target length."""
    if len(n) >= target:
        return n[:target]
    return n + b"\x00" * (target - len(n))

# ─── public api ──────────────────────────────────────────────────────────────

def encrypt(plaintext: str | bytes, password: str, *, expires_ms: int | None = None, version: int = 2, compact: bool = False) -> str:
    sl    = _SL_C if compact else _SL
    nl    = _NL_C if compact else (_NL3 if version == 3 else _NL)
    salt  = _o.urandom(sl)
    nonce = _o.urandom(nl)
    key   = _kdf(password.encode(), salt)
    inner = _build_inner(plaintext, expires_ms)

    if compact:
        pfx = {1: _CPX1, 2: _CPX2, 3: _CPX3}[version]
        # pad nonce to required cipher length
        nonce_full = _pad_nonce(nonce, 12 if version in (1, 2) else 16)
        if version == 1:
            ct, tag = _enc_v1(key, nonce_full, inner)
            return (pfx + _b64e(salt + nonce + tag + ct)).decode()
        elif version == 3:
            ct = _enc_v3(key, nonce_full, inner)
            return (pfx + _b64e(salt + nonce + ct)).decode()
        else:
            ct, tag = _enc_v2(key, nonce_full, inner)
            return (pfx + _b64e(salt + nonce + tag + ct)).decode()
    else:
        pfx = {1: _PX1, 2: _PX2, 3: _PX3}[version]
        if version == 1:
            ct, tag = _enc_v1(key, nonce, inner)
            return (pfx + _b64e(salt + nonce + tag + ct)).decode()
        elif version == 3:
            ct = _enc_v3(key, nonce, inner)
            return (pfx + _b64e(salt + nonce + ct)).decode()
        else:
            ct, tag = _enc_v2(key, nonce, inner)
            return (pfx + _b64e(salt + nonce + tag + ct)).decode()

def decrypt(token: str, password: str) -> tuple[str, int | None]:
    tb = token.encode()
    pfx, ver, nl, sl, compact, _ = _detect(tb)

    raw   = _b64d(tb[len(pfx):])
    salt  = raw[:sl]
    nonce_raw = raw[sl:sl+nl]
    key   = _kdf(password.encode(), salt)

    if compact:
        nonce_full = _pad_nonce(nonce_raw, 12 if ver in (1, 2) else 16)
    else:
        nonce_full = nonce_raw

    if ver == 3:
        ct    = raw[sl+nl:]
        inner = _dec_v3(key, nonce_full, ct)
    else:
        tag   = raw[sl+nl:sl+nl+_TL]
        ct    = raw[sl+nl+_TL:]
        inner = _dec_v1(key, nonce_full, ct, tag) if ver == 1 else _dec_v2(key, nonce_full, ct, tag)

    return _parse_inner(inner)
