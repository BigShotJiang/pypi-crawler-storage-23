from __future__ import annotations
import base64 as _b,hashlib as _h,hmac as _m,os as _o,re as _r,time as _t

def _b64e(b:bytes)->bytes: return _b.urlsafe_b64encode(b).rstrip(b"=")
def _b64d(b:bytes)->bytes:
    p=4-len(b)%4; return _b.urlsafe_b64decode(b+(b"="*p if p!=4 else b""))

def fingerprint(text:str,secret:str)->str:
    return _m.new(secret.encode(),text.encode(),_h.sha256).hexdigest()[:16]

def generate(nbytes:int=24)->str:
    return _b64e(_o.urandom(nbytes)).decode()

def parse_expiry(raw:str)->int:
    m=_r.fullmatch(r"(\d+)(s|m|h|d)",raw.strip())
    if not m: raise ValueError(f'invalid expiry: "{raw}" — use 30s 5m 2h 7d')
    return int(_t.time()*1000)+int(m.group(1))*{"s":1000,"m":60000,"h":3600000,"d":86400000}[m.group(2)]

def inspect(token:str)->dict:
    from ._crypto import _b64d, _detect
    tb = token.encode()
    pfx, ver, nl, sl, compact, legacy = _detect(tb)
    raw = _b64d(tb[len(pfx):])
    algo_map = {1: "AES-256-GCM", 2: "ChaCha20-Poly1305", 3: "AES-256-CBC"}
    return {
        "prefix":        pfx.decode(),
        "version":       f"v{ver}",
        "algo":          algo_map[ver],
        "compact":       compact,
        "legacy":        legacy,
        "kdf":           "scrypt (N=16384,r=8,p=1)",
        "salt_hex":      raw[:sl].hex(),
        "nonce_hex":     raw[sl:sl+nl].hex(),
        "payload_bytes": len(raw),
    }
