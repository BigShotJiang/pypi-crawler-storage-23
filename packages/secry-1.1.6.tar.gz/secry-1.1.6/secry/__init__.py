from __future__ import annotations
import os as _os
from importlib.metadata import version as _ver, PackageNotFoundError as _PNF
from ._crypto import encrypt as _enc, decrypt as _dec
from ._util   import fingerprint as _fp, parse_expiry, inspect as _ins

try:
    __version__ = _ver("secry")
except _PNF:
    __version__ = "dev"

__all__ = ["encrypt","decrypt","verify","fingerprint","generate","inspect","parse_expiry"]

TOKEN_PREFIX = "secry:v2:"

def encrypt(text: str, password: str, *, expires: str | None = None, expires_ms: int | None = None, version: int = 2, compact: bool = False) -> str:
    if not password: raise TypeError("password must be non-empty")
    exp = parse_expiry(expires) if expires else expires_ms
    return _enc(text, password, expires_ms=exp, version=version, compact=compact)

def decrypt(token: str, password: str) -> str:
    if not token:    raise TypeError("token must be non-empty")
    if not password: raise TypeError("password must be non-empty")
    return _dec(token, password)[0]

def verify(token: str, password: str) -> bool:
    try: _dec(token, password); return True
    except: return False

def fingerprint(text: str, secret: str) -> str: return _fp(text, secret)

def inspect(token: str) -> dict: return _ins(token)

def generate(nbytes: int = 24, *, upper: bool = False, count: int = 1) -> str | list[str]:
    if not (8 <= nbytes <= 256): raise ValueError("nbytes must be between 8 and 256")
    if not (1 <= count <= 20):   raise ValueError("count must be between 1 and 20")
    _CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
    def _gen() -> str:
        raw = _os.urandom(nbytes)
        pw  = "".join(_CHARS[b % 64] for b in raw)
        if upper and not any(c.isupper() for c in pw):
            i  = _os.urandom(1)[0] % len(pw)
            pw = pw[:i] + pw[i].upper() + pw[i+1:]
        return pw
    pws = [_gen() for _ in range(count)]
    return pws if count > 1 else pws[0]

def example() -> None:
    from ._example import show
    show()
