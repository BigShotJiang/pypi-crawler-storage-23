import sys,os,time
sys.path.insert(0,os.path.join(os.path.dirname(__file__),".."))
import secry

_G="\x1b[32m✔\x1b[0m"; _R="\x1b[31m✘\x1b[0m"
_H="\x1b[1m\x1b[38;5;252m"; _D="\x1b[38;5;245m"; _E="\x1b[0m"
_p=_f=0

def _head(t): print(f"\n{_H}{t}{_E}")
def _assert(c,m="assertion failed"):
    if not c: raise AssertionError(m)

def test(label,fn):
    global _p,_f
    try:    fn(); print(f"  {_G}  {label}"); _p+=1
    except Exception as e: print(f"  {_R}  {label}\n     {_D}{e}{_E}"); _f+=1

# ── encrypt / decrypt ─────────────────────────────────────────────────────────

_head("encrypt / decrypt")
test("returns secry:v2: token",          lambda:_assert(secry.encrypt("hi","pw").startswith("secry:v2:")))
test("roundtrip plaintext",              lambda:_assert(secry.decrypt(secry.encrypt("secret","pw"),"pw")=="secret"))
test("unique tokens per call",           lambda:_assert(secry.encrypt("x","pw")!=secry.encrypt("x","pw")))
test("unicode roundtrip",                lambda:_assert(secry.decrypt(secry.encrypt("日本語 ñ @#$","pw"),"pw")=="日本語 ñ @#$"))
test("10 KB roundtrip",                  lambda:_assert(secry.decrypt(secry.encrypt("x"*10240,"pw"),"pw")=="x"*10240))
test("version=1 roundtrip",             lambda:_assert(secry.decrypt(secry.encrypt("hi","pw",version=1),"pw")=="hi"))
test("version=3 roundtrip",             lambda:_assert(secry.decrypt(secry.encrypt("hi","pw",version=3),"pw")=="hi"))

# ── compact mode ──────────────────────────────────────────────────────────────

_head("compact mode")
test("compact returns sec:v2: token",    lambda:_assert(secry.encrypt("hi","pw",compact=True).startswith("sec:v2:")))
test("compact v1 returns sec:v1:",       lambda:_assert(secry.encrypt("hi","pw",version=1,compact=True).startswith("sec:v1:")))
test("compact v3 returns sec:v3:",       lambda:_assert(secry.encrypt("hi","pw",version=3,compact=True).startswith("sec:v3:")))
test("compact roundtrip",               lambda:_assert(secry.decrypt(secry.encrypt("secret","pw",compact=True),"pw")=="secret"))
test("compact token shorter than full", lambda:_assert(len(secry.encrypt("hi","pw",compact=True))<len(secry.encrypt("hi","pw"))))
test("compact unicode roundtrip",       lambda:_assert(secry.decrypt(secry.encrypt("日本語","pw",compact=True),"pw")=="日本語"))

# ── wrong password / tampered ─────────────────────────────────────────────────

_head("wrong password / tampered")
def _t6():
    tok=secry.encrypt("secret","correct")
    try: secry.decrypt(tok,"wrong"); raise AssertionError("should raise")
    except ValueError: pass
test("wrong password raises",_t6)

def _t7():
    tok=secry.encrypt("secret","pw")
    try: secry.decrypt(tok[:-6]+"AAAAAA","pw"); raise AssertionError("should raise")
    except Exception: pass
test("tampered token raises",_t7)

def _t8():
    try: secry.decrypt("notatoken","pw"); raise AssertionError("should raise")
    except Exception: pass
test("invalid format raises",_t8)

# ── verify ────────────────────────────────────────────────────────────────────

_head("verify")
test("valid token → True",    lambda:_assert(secry.verify(secry.encrypt("x","pw"),"pw") is True))
test("wrong password → False", lambda:_assert(secry.verify(secry.encrypt("x","pw"),"bad") is False))
test("garbage → False",        lambda:_assert(secry.verify("garbage","pw") is False))
test("compact valid → True",   lambda:_assert(secry.verify(secry.encrypt("x","pw",compact=True),"pw") is True))

# ── expiry ────────────────────────────────────────────────────────────────────

_head("expiry")
test("no expiry decrypts",     lambda:_assert(secry.decrypt(secry.encrypt("x","pw"),"pw")=="x"))
test("future expiry decrypts", lambda:_assert(secry.decrypt(secry.encrypt("x","pw",expires_ms=int(time.time()*1000)+60000),"pw")=="x"))
test("expires= string (1h)",   lambda:_assert(secry.decrypt(secry.encrypt("x","pw",expires="1h"),"pw")=="x"))

def _t13():
    tok=secry.encrypt("x","pw",expires_ms=int(time.time()*1000)+100)
    time.sleep(0.2)
    try: secry.decrypt(tok,"pw"); raise AssertionError("should raise")
    except ValueError as e: _assert("expired" in str(e).lower())
test("expired token raises",_t13)

# ── fingerprint ───────────────────────────────────────────────────────────────

_head("fingerprint")
test("deterministic",          lambda:_assert(secry.fingerprint("hi","s")==secry.fingerprint("hi","s")))
test("different input differs", lambda:_assert(secry.fingerprint("a","s")!=secry.fingerprint("b","s")))
test("16 hex chars",           lambda:_assert(len(secry.fingerprint("x","s"))==16))

# ── generate ──────────────────────────────────────────────────────────────────

_head("generate")
test("non-empty string",       lambda:_assert(isinstance(secry.generate(),str) and len(secry.generate())>0))
test("unique values",          lambda:_assert(secry.generate()!=secry.generate()))

# ── inspect ───────────────────────────────────────────────────────────────────

_head("inspect")
def _t_ins():
    m=secry.inspect(secry.encrypt("x","pw"))
    _assert(m["version"]=="v2")
    _assert(m["algo"]=="ChaCha20-Poly1305")
    _assert(m["prefix"]=="secry:v2:")
    _assert(m["compact"] is False)
    _assert(m["legacy"] is False)
test("inspect full token",_t_ins)

def _t_ins_c():
    m=secry.inspect(secry.encrypt("x","pw",compact=True))
    _assert(m["compact"] is True)
    _assert(m["prefix"]=="sec:v2:")
test("inspect compact token",_t_ins_c)

# ── legacy rwn64 compat ───────────────────────────────────────────────────────

_head("legacy rwn64 compat")
_TOK  = "rwn64:v1:IaQVjP7tITZRERd-MWZBpxGMdo432gsidiGNlK9vZFSt-Vqhs2ioZt4dFykhmciisVa9a07VY0M"
_PASS = "minhasenha"
_TXT  = "old v1 text"
test("decrypt rwn64:v1: token",  lambda:_assert(secry.decrypt(_TOK,_PASS)==_TXT))
test("inspect rwn64 token legacy flag", lambda:_assert(secry.inspect(_TOK)["legacy"] is True))

# ── summary ───────────────────────────────────────────────────────────────────

total=_p+_f
print(f"\n{_D}{'─'*48}{_E}\n")
print(f"  total   {total}")
print(f"  \x1b[32mpassed  {_p}\x1b[0m")
if _f: print(f"  \x1b[31mfailed  {_f}\x1b[0m")
print()
if not _f: print(f"  \x1b[32m\x1b[1mall tests passed\x1b[0m\n")
else:      print(f"  \x1b[31m\x1b[1m{_f} test(s) failed\x1b[0m\n"); sys.exit(1)
