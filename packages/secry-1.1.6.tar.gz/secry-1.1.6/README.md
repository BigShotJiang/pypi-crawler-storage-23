# secry

AES-256-GCM token encryption for Python. Zero dependencies. Tokens are fully interoperable with the [Node.js secry package](https://www.npmjs.com/package/secry).

```sh
pip install secry
```

---

## Usage

```python
import secry

token = secry.encrypt("my secret", "mypassword")
text  = secry.decrypt(token, "mypassword")
ok    = secry.verify(token, "mypassword")
fp    = secry.fingerprint("hello", "secret")
pw    = secry.generate(32)
meta  = secry.inspect(token)
```

## Compact mode

Use `compact=True` to get shorter tokens with the `sec:` prefix:

```python
token = secry.encrypt("my secret", "mypassword", compact=True)
# → sec:v2:...  (shorter token)

# decrypt works the same way — prefix is detected automatically
text = secry.decrypt(token, "mypassword")
```

## Expiry

```python
token = secry.encrypt("temporary", "mypassword", expires="1h")
token = secry.encrypt("temporary", "mypassword", expires="30m")
token = secry.encrypt("temporary", "mypassword", expires="7d")
```

## Token prefixes

```
secry:v1:   AES-256-GCM        (full)
secry:v2:   ChaCha20-Poly1305  (full)
secry:v3:   AES-256-CBC        (full)

sec:v1:     AES-256-GCM        (compact)
sec:v2:     ChaCha20-Poly1305  (compact)
sec:v3:     AES-256-CBC        (compact)

rwn64:v*:   legacy — still accepted by decrypt/verify/inspect
```

## Inspect

```python
meta = secry.inspect(token)
# {
#   "prefix": "secry:v2:",
#   "version": "v2",
#   "algo": "ChaCha20-Poly1305",
#   "compact": False,
#   "legacy": False,
#   "kdf": "scrypt (N=16384,r=8,p=1)",
#   "salt_hex": "...",
#   "nonce_hex": "...",
#   "payload_bytes": 64
# }
```

## Security

- AES-256-GCM / ChaCha20-Poly1305 authenticated encryption
- scrypt key derivation (N=16384, r=8, p=1)
- Random salt + nonce per token
- Auth tag detects tampering before decryption
- Zero external dependencies

## License

MIT
