import os
import platform
import sys
from datetime import datetime


def get_app_path(relative_path):
    """
    获取资源绝对路径（兼容 Dev 和 Frozen 环境）
    
    在 PyInstaller --onedir 模式下，macOS .app 的结构通常是：
    OperatorRuntime.app/
        Contents/
            MacOS/
                OperatorRuntime (可执行文件)
                assets/       (如果 spec 中配置在同级)
            Resources/        (标准 Mac 资源目录)
            
    我们现在的 spec 配置是将 assets 放在可执行文件同级目录。
    """
    if getattr(sys, 'frozen', False):
        # 打包后的环境
        bundle_dir = os.path.dirname(sys.executable)
        return os.path.join(bundle_dir, relative_path)
    else:
        # 开发环境
        return os.path.join(os.path.abspath("."), relative_path)


def get_system_chrome_path():
    """
    获取系统已安装的 Chrome/Edge 路径，避免打包几百兆的浏览器。
    优先查找 Chrome，其次 Edge。
    """
    system = platform.system()
    paths = []

    if system == "Darwin":  # macOS
        paths = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
            # 用户可能安装在用户目录下
            os.path.expanduser("~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
        ]
    elif system == "Windows":
        paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        ]

    for p in paths:
        if os.path.exists(p):
            return p

    return None


def timestamp_to_str(ts, fmt='%Y-%m-%d %H:%M:%S', tz=None):
    """
    自动识别10位或13位时间戳并转为日期字符串
    """
    if not ts: return ts

    # 如果是字符串类型的输入，先转为数字
    try:
        ts = int(ts)
    except Exception:
        return ts

    # 核心逻辑：如果数值大于 1e11 (即 100,000,000,000)，通常被认为是毫秒级
    # 10位时间戳最大到 2286年 (9999999999)
    if ts > 10000000000:
        ts = ts / 1000

    return datetime.fromtimestamp(ts, tz=tz).strftime(fmt)
