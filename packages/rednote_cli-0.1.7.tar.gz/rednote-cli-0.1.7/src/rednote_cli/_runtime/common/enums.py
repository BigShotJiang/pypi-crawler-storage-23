from enum import Enum


class Platform(Enum):
    REDNOTE = "Rednote"
    DOUYIN = "Douyin"
    TIKTOK = "TikTok"


class XsecSource(Enum):
    PC_FEED = "pc_feed"  # 发现页 → 笔记；发现页 → 达人
    PC_SEARCH = "pc_search"  # 搜索页 → 笔记；搜索页 → 达人
    PC_COLLECT = "pc_collect"  # 达人-收藏页 → 笔记；达人-收藏页 → 达人
    PC_LIKE = "pc_like"  # 达人-点赞页 → 笔记；达人-点赞页 → 达人
    PC_USER = "pc_user"  # 达人-笔记页 → 笔记
    PC_NOTE = "pc_note"  # 笔记页 → 达人

