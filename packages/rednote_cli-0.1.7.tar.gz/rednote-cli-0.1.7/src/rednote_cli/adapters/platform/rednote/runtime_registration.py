from __future__ import annotations

from rednote_cli._runtime.common.enums import Platform
from rednote_cli._runtime.platforms.factory import PlatformFactory, PlatformLoginProfile
from rednote_cli.adapters.platform.rednote.runtime_extractor import RednoteExtractor


def register_rednote_runtime() -> None:
    PlatformFactory.register_platform(
        Platform.REDNOTE,
        extractor_cls=RednoteExtractor,
        login_profile=PlatformLoginProfile(
            login_url="https://www.xiaohongshu.com/explore",
            login_selector=".main-container .user .link-wrapper .channel",
            qr_selector=".login-container .qrcode-img",
            account_id_field="red_id",
            nickname_field="nickname",
            guest_field="guest",
        ),
    )
