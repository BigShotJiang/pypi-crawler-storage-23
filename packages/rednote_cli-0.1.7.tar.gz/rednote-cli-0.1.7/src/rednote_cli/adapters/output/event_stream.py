from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from rednote_cli.adapters.output.writer import write_error


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def emit_event(
    *,
    command: str,
    event: str,
    data: dict[str, Any] | None = None,
    trace_id: str | None = None,
) -> None:
    payload = {
        "type": "event",
        "command": command,
        "event": event,
        "timestamp": _now_iso(),
        "trace_id": trace_id,
        "data": data or {},
    }
    write_error(json.dumps(payload, ensure_ascii=False, separators=(",", ":")))
