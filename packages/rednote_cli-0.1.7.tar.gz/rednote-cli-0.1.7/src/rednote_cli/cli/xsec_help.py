from __future__ import annotations

NOTE_XSEC_SOURCE_HELP = (
    "xsec 来源；发现页拿到的笔记传 pc_feed，搜索页拿到的笔记传 pc_search，"
    "达人收藏页拿到的笔记传 pc_collect，达人点赞页拿到的笔记传 pc_like，"
    "达人笔记页拿到的笔记传 pc_user；与 xsec_token 配套传入"
)

USER_XSEC_SOURCE_HELP = (
    "xsec 来源；发现页拿到的达人传 pc_feed，搜索页拿到的达人传 pc_search，"
    "达人收藏页拿到的达人传 pc_collect，达人点赞页拿到的达人传 pc_like，"
    "笔记页拿到的达人传 pc_note；与 xsec_token 配套传入"
)

NOTE_XSEC_SOURCE_DOC = (
    "xsec_source 用于标识笔记来源：发现页拿到的笔记传 pc_feed，搜索页拿到的笔记传 pc_search，"
    "达人收藏页拿到的笔记传 pc_collect，达人点赞页拿到的笔记传 pc_like，"
    "达人笔记页拿到的笔记传 pc_user。"
)

USER_XSEC_SOURCE_DOC = (
    "xsec_source 用于标识达人来源：发现页拿到的达人传 pc_feed，搜索页拿到的达人传 pc_search，"
    "达人收藏页拿到的达人传 pc_collect，达人点赞页拿到的达人传 pc_like，"
    "笔记页拿到的达人传 pc_note。"
)

NOTE_COMMAND_DOC = (
    "获取单条笔记详情与评论。\n\n"
    "如上游已拿到 xsec_token，默认应优先携带并继续向下传递。\n"
    f"{NOTE_XSEC_SOURCE_DOC}\n"
    "参数优先级：显式 CLI 参数 > --input JSON > 默认值。"
)

USER_COMMAND_DOC = (
    "获取单个用户主页详情。\n\n"
    "如上游已拿到 xsec_token，默认应优先携带并继续向下传递。\n"
    f"{USER_XSEC_SOURCE_DOC}\n"
    "参数优先级：显式 CLI 参数 > --input JSON > 默认值。"
)

NOTE_INPUT_HELP = (
    "JSON 输入文件路径或 '-'，字段示例：note_id,xsec_token,xsec_source,comment_size,sub_comment_size,account_uid；"
    "其中 xsec_source 表示笔记来源：发现页笔记=pc_feed，搜索页笔记=pc_search，"
    "达人收藏页笔记=pc_collect，达人点赞页笔记=pc_like，达人笔记页笔记=pc_user"
)

USER_INPUT_HELP = (
    "JSON 输入文件路径或 '-'，字段示例：user_id,xsec_token,xsec_source,account_uid；"
    "其中 xsec_source 表示达人来源：发现页达人=pc_feed，搜索页达人=pc_search，"
    "达人收藏页达人=pc_collect，达人点赞页达人=pc_like，笔记页达人=pc_note"
)
