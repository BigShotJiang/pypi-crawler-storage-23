from __future__ import annotations

from rednote_cli.adapters.platform.rednote.extractor import RednoteExtractorAdapter


async def execute_note_search(
    keyword: str,
    size: int = 20,
    sort_by: str | None = None,
    note_type: str | None = None,
    publish_time: str | None = None,
    search_scope: str | None = None,
    location: str | None = None,
    account_uid: str | None = None,
) -> list[dict]:
    adapter = RednoteExtractorAdapter()
    return await adapter.search_notes(
        keyword=keyword,
        size=size,
        sort_by=sort_by,
        note_type=note_type,
        publish_time=publish_time,
        search_scope=search_scope,
        location=location,
        account_uid=account_uid,
    )
