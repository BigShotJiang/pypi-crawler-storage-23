from __future__ import annotations

from rednote_cli._runtime.core.database.manager import init_db
from rednote_cli.infra.paths import APP_HOME, LOG_DIR, OUTPUT_DIR, configure_legacy_data_paths, ensure_runtime_dirs


def execute_runtime_init() -> dict:
    ensure_runtime_dirs()
    configure_legacy_data_paths()
    init_db()
    return {
        "app_home": str(APP_HOME),
        "log_dir": str(LOG_DIR),
        "output_dir": str(OUTPUT_DIR),
        "accounts_dir": str(APP_HOME / "accounts"),
        "settings_file": str(APP_HOME / "settings.json"),
        "task_schedules_file": str(APP_HOME / "task_schedules.json"),
        "storage_mode": "file_primary",
        "store_initialized": True,
    }
