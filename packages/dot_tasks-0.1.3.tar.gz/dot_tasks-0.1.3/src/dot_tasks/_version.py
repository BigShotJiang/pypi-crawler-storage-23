"""Version definition for dot-tasks."""

__version__ = "0.1.3"
