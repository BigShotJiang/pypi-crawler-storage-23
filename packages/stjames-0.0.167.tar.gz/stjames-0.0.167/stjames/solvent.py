from .base import Base, LowercaseStrEnum


class Solvent(LowercaseStrEnum):
    """Implicit solvent."""

    WATER = "water"
    NITROMETHANE = "nitromethane"
    NITROBENZENE = "nitrobenzene"
    TOLUENE = "toluene"
    BENZENE = "benzene"
    CHLOROBENZENE = "chlorobenzene"
    CARBONTETRACHLORIDE = "carbontetrachloride"
    DICHLOROETHANE = "dichloroethane"
    DICHLOROMETHANE = "dichloromethane"
    CHLOROFORM = "chloroform"
    DIETHYLETHER = "diethylether"
    DIISOPROPYLETHER = "diisopropylether"
    DIMETHYLSULFOXIDE = "dimethylsulfoxide"
    TETRAHYDROFURAN = "tetrahydrofuran"
    CYCLOHEXANE = "cyclohexane"
    ACETICACID = "aceticacid"
    HEXANE = "hexane"
    OCTANE = "octane"
    DECANE = "decane"
    ETHYLACETATE = "ethylacetate"
    ACETONE = "acetone"
    ACETONITRILE = "acetonitrile"
    METHANOL = "methanol"
    ETHANOL = "ethanol"
    ISOPROPANOL = "isopropanol"
    OCTANOL = "octanol"
    DIMETHYLACETAMIDE = "dimethylacetamide"
    DIMETHYLFORMAMIDE = "dimethylformamide"
    N_METHYLPYRROLIDONE = "n_methylpyrrolidone"
    ETHYLENE_GLYCOL = "ethylene_glycol"


class SolventModel(LowercaseStrEnum):
    """Implicit solvation model."""

    PCM = "pcm"
    CPCM = "cpcm"
    ALPB = "alpb"
    COSMO = "cosmo"
    GBSA = "gbsa"
    CPCMX = "cpcmx"
    SMD = "SMD"


class SolventSettings(Base):
    """
    Implicit solvation settings.

    :param solvent: solvent to use
    :param model: solvation model
    """

    solvent: Solvent
    model: SolventModel
