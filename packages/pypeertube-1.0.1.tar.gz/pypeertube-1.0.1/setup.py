# SPDX-FileCopyrightText: 2025 CaramelConnoisseur
#
# SPDX-License-Identifier: GPL-3.0-only

"""Setup file for PyPeertube"""

from setuptools import setup

if __name__ == "__main__":
    setup(install_requires=["urllib3>=2.6.3"])
