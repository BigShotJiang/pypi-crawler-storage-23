import gnssrefl.refraction as r

def main():
    """
    no inputs. checks for the feared pickle file

    """
    r.look_for_pickle_file()

if __name__ == "__main__":
    main()

