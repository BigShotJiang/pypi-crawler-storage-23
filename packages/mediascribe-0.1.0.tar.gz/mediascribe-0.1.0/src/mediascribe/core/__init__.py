"""Core abstractions — config, jobs, pipeline orchestration, events."""
