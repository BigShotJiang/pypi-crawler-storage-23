"""TUI screens — welcome, setup, picker, config, run, results."""
