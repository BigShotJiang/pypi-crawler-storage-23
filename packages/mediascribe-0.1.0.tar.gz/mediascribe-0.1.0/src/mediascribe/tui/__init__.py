"""Textual TUI application for mediascribe."""
