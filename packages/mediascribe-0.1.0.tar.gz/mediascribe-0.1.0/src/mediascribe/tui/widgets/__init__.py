"""TUI widgets — reusable components for the mediascribe TUI."""
