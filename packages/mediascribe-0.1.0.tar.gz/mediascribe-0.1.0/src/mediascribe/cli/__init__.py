"""CLI interface — Typer-based command-line tool."""
