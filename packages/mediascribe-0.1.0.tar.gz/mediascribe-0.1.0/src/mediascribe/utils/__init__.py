"""Utility modules — FFmpeg, paths, logging."""
