"""Pipeline steps — each step is an independent, composable processing unit."""
