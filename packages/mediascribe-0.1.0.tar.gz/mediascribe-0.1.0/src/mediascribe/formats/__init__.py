"""Output format handlers — SRT, VTT, plain text, JSON."""
