"""mediascribe — Transcribe, translate, and analyze audio/video media."""

__version__ = "0.1.0"
