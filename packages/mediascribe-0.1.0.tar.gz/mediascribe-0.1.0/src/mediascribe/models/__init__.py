"""AI model management — Whisper (local/API), OpenAI chat, prompt templates."""
