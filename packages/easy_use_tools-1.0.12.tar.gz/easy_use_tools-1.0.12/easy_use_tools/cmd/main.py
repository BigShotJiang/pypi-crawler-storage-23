# coding=utf-8
import argparse
from easy_use_tools.utils.common.gui import ScreenshotsEntity
from easy_use_tools.utils.common.web.flask import run_flask_server
def run_flask():
    run_flask_server()

def screen_check():
    parser = argparse.ArgumentParser(description='截图检测工具')
    # 添加参数
    parser.add_argument('--img_path', '-i', type=str, default=None,help='图片路径')
    parser.add_argument('--time_gap', '-c', type=int,default=0, help='循环检测次数间隔')

    # 解析参数
    args = parser.parse_args()

    se = ScreenshotsEntity()
    # 循环检测
    if args.time_gap != 0:
        se.loop_check(args.time_gap,args.img_path)
    # 单次检测
    else:
        se.check(args.img_path)