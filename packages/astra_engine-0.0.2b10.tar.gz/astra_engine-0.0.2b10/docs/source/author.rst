.. _author:

Author
======

Astra Engine is created and maintained by **Aman Kumar Pandey**.

- **GitHub**: `paman7647 <https://github.com/paman7647>`_

.. important::
 GitHub is the primary and only official source for updates, support, and
 contact. Please do not use any other personal contact methods (email, social
 media) for project-related inquiries.

Contributing
------------

Contributions are welcome! Please see the :doc:`developer_guide` for setup
instructions and coding guidelines.

To contribute:

1. Fork the `repository <https://github.com/paman7647/Astra>`_.
2. Create a feature branch.
3. Make your changes with tests.
4. Submit a pull request.

Acknowledgments
---------------

Astra is built on top of:

- `Playwright <https://playwright.dev/python/>`_ -- browser automation
- `WhatsApp Web <https://web.whatsapp.com>`_ -- the official web client
- Python ``asyncio`` -- async runtime
