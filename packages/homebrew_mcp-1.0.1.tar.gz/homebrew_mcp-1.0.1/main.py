"""Homebrew MCP Server - Manage Homebrew packages, casks, taps, and services."""

from mcp.server.fastmcp import FastMCP

import brew_commands

mcp = FastMCP("homebrew")


# --- Search & Info ---

@mcp.tool()
def search(query: str, cask: bool = False) -> list[str]:
    """Search for Homebrew formulae or casks.

    Args:
        query: Search term
        cask: If True, search casks (GUI apps) instead of formulae
    """
    return brew_commands.search(query, cask=cask)


@mcp.tool()
def info(package: str, cask: bool = False) -> dict:
    """Get detailed info about a formula or cask.

    Args:
        package: Package name
        cask: If True, look up a cask instead of a formula
    """
    return brew_commands.info(package, cask=cask)


@mcp.tool()
def list_installed(cask: bool = False) -> list[str]:
    """List installed formulae or casks.

    Args:
        cask: If True, list installed casks instead of formulae
    """
    return brew_commands.list_installed(cask=cask)


@mcp.tool()
def list_outdated(cask: bool = False) -> list[dict]:
    """List outdated formulae or casks that have newer versions available.

    Args:
        cask: If True, list outdated casks instead of formulae
    """
    return brew_commands.list_outdated(cask=cask)


@mcp.tool()
def deps(package: str) -> str:
    """Show dependency tree for a package.

    Args:
        package: Package name to show dependencies for
    """
    return brew_commands.deps(package)


# --- Install/Manage ---

@mcp.tool()
def install(package: str, cask: bool = False) -> str:
    """Install a formula or cask.

    Args:
        package: Package name to install
        cask: If True, install a cask (GUI app) instead of a formula
    """
    return brew_commands.install(package, cask=cask)


@mcp.tool()
def uninstall(package: str, cask: bool = False) -> str:
    """Uninstall a formula or cask.

    Args:
        package: Package name to uninstall
        cask: If True, uninstall a cask instead of a formula
    """
    return brew_commands.uninstall(package, cask=cask)


@mcp.tool()
def upgrade(package: str, cask: bool = False) -> str:
    """Upgrade a specific formula or cask to the latest version.

    Args:
        package: Package name to upgrade
        cask: If True, upgrade a cask instead of a formula
    """
    return brew_commands.upgrade(package, cask=cask)


@mcp.tool()
def upgrade_all() -> str:
    """Upgrade all installed formulae and casks to their latest versions."""
    return brew_commands.upgrade_all()


@mcp.tool()
def cleanup(dry_run: bool = False) -> str:
    """Remove stale lock files, old downloads, and outdated versions.

    Args:
        dry_run: If True, show what would be removed without actually removing
    """
    return brew_commands.cleanup(dry_run=dry_run)


# --- Taps ---

@mcp.tool()
def tap(name: str) -> str:
    """Add a third-party repository (tap).

    Args:
        name: Tap name in format 'user/repo'
    """
    return brew_commands.tap(name)


@mcp.tool()
def untap(name: str) -> str:
    """Remove a third-party repository (tap).

    Args:
        name: Tap name in format 'user/repo'
    """
    return brew_commands.untap(name)


@mcp.tool()
def list_taps() -> list[str]:
    """List all currently tapped repositories."""
    return brew_commands.list_taps()


# --- Services ---

@mcp.tool()
def list_services() -> list[dict]:
    """List all managed background services and their status."""
    return brew_commands.list_services()


@mcp.tool()
def start_service(name: str) -> str:
    """Start a background service.

    Args:
        name: Service name (e.g., 'postgresql', 'redis')
    """
    return brew_commands.start_service(name)


@mcp.tool()
def stop_service(name: str) -> str:
    """Stop a background service.

    Args:
        name: Service name (e.g., 'postgresql', 'redis')
    """
    return brew_commands.stop_service(name)


@mcp.tool()
def restart_service(name: str) -> str:
    """Restart a background service.

    Args:
        name: Service name (e.g., 'postgresql', 'redis')
    """
    return brew_commands.restart_service(name)


# --- System ---

@mcp.tool()
def doctor() -> str:
    """Run Homebrew diagnostics to check for potential issues."""
    return brew_commands.doctor()


@mcp.tool()
def update() -> str:
    """Update Homebrew and all formulae/cask definitions (does not upgrade installed packages)."""
    return brew_commands.update()


def main():
    mcp.run()


if __name__ == "__main__":
    main()
