from .flync_general import FLYNCGeneralConfig

__all__ = [
    "FLYNCGeneralConfig",
]
