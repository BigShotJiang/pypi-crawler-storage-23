"""
This package provides the core functionality for interacting \
with the FLYNC core modules, including utilities for workspace managment.
It exposes a clean, Pythonic API for developers to integrate FLYNC \
capabilities into their applications.
"""
