"""
Workspace package for FLYNC SDK.

Provides classes and functions to manage workspace operations.
"""
