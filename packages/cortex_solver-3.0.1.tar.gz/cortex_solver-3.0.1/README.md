# cortex-solver

cortex-solver is an MCP server that enforces a rigorous build methodology for LLMs constructing 3D objects and scenes. It provides a structured pipeline to decompose subjects, validate research, solve geometric constraints, and verify the final output.

## Installation

Run directly using uvx:

```bash
uvx cortex-solver
```

Or install permanently:

```bash
uv pip install cortex-solver
```

## MCP Configuration

To use cortex-solver with an MCP client, add it to your configuration file:

```json
{
  "mcpServers": {
    "cortex": {
      "command": "uvx",
      "args": ["cortex-solver"]
    }
  }
}
```

## Build Pipeline

The server enforces a linear workflow for constructing 3D objects:

1. Decompose: Break the subject into a part hierarchy.
2. Research: Validate that all necessary research data is present.
3. Validate: Check the structural integrity and logic of the recipe.
4. Solve: Compute precise 3D positions based on constraints.
5. Verify: Confirm the built object matches the solver output.
6. Solve Scene: Arrange multiple objects within a larger scene.

## Tools

### decompose
Breaks a subject into a hierarchical part/object tree and generates research checklists.
- subject (string): The name of the object to decompose.
- variant (string, optional): Specific version or style of the subject.
- scope (string, optional): Scope of the decomposition.
- detail_level (string, optional): Level of granularity for the hierarchy.

### research
Validates the completeness of research data and identifies missing information.
- hierarchy (object): The part hierarchy from the decompose tool.
- filled_data (object, optional): The current research data to validate.

### validate
Checks the recipe schema, references, cycles, and constraint validity.
- recipe (object): The complete build recipe for the object.

### solve
Computes part positions via constraint resolution. Returns positions, build order, and any conflicts.
- recipe (object): The validated build recipe.

### solve_scene
Computes placements for multiple objects in a scene. Returns positions, rotations, and scales.
- scene_recipe (object): The recipe defining the scene and its constraints.

### verify
Verifies a built object against the solver output, checking mesh health, transforms, and dimensions.
- object_name (string): Name of the object to verify.
- object_data (object): Data from the constructed object.
- expected (object): The expected values from the solver.

## Constraints

### Part Constraints
Used during the object build phase:
- STACKED
- CENTERED
- FLUSH
- OFFSET
- COAXIAL
- INSIDE
- ALIGNED
- SYMMETRIC

### Scene Constraints
Used during the scene arrangement phase:
- GRID
- ALONG_PATH
- RADIAL
- FACING
- DISTANCE
- AGAINST_EDGE
- RANDOM_SCATTER
- STACK_VERTICAL
- MIRROR_SCENE

## Project Structure

```
cortex/
├── __init__.py
├── __main__.py
├── server.py
├── types.py
├── core/
│   ├── solver.py
│   ├── scene_solver.py
│   ├── validator.py
│   ├── verifier.py
│   └── decomposer.py
└── tools/
    ├── decompose.py
    ├── research.py
    ├── validate.py
    ├── solve.py
    ├── solve_scene.py
    └── verify.py
```

## Development

Set up the environment and run tests:

```bash
uv sync --extra dev
uv run pytest
```

## License

MIT