"""Tool handler for the ``solve_scene`` MCP tool."""

from __future__ import annotations

from typing import Any

from cortex.core.scene_solver import solve_scene
from cortex.types import (
    Dimensions,
    PartSpec,
    SceneConstraint,
    SceneRecipe,
    _to_dict,
)


def _parse_scene_recipe(raw: dict[str, Any]) -> SceneRecipe:
    """Convert a raw JSON dict into a typed SceneRecipe."""
    objects: dict[str, PartSpec] = {}
    for name, spec in raw.get("objects", {}).items():
        dims = spec.get("dimensions", {})
        objects[name] = PartSpec(
            name=name,
            dimensions=Dimensions(
                width=float(dims.get("w", dims.get("width", 0))),
                depth=float(dims.get("d", dims.get("depth", 0))),
                height=float(dims.get("h", dims.get("height", 0))),
            ),
            type=spec.get("type", ""),
            params=spec.get("params", {}),
            metadata=spec.get("metadata", {}),
        )

    constraints: list[SceneConstraint] = []
    for c in raw.get("constraints", []):
        constraints.append(
            SceneConstraint(
                type=c["type"],
                object=c.get("object", c.get("objects", "")),
                params=c.get("params", {}),
            )
        )

    return SceneRecipe(
        name=raw.get("name", ""),
        bounds=raw.get("bounds", {"min": [0, 0, 0], "max": [10, 10, 10]}),
        objects=objects,
        zones=raw.get("zones", {}),
        constraints=constraints,
    )


def handle_solve_scene(arguments: dict[str, Any]) -> dict[str, Any]:
    """Parse input and delegate to the scene solver."""
    recipe = _parse_scene_recipe(arguments["scene_recipe"])
    result = solve_scene(recipe)
    return _to_dict(result)
