"""Tool handler for the ``validate`` MCP tool."""

from __future__ import annotations

from typing import Any

from cortex.core.validator import validate
from cortex.types import (
    Constraint,
    Dimensions,
    Mirror,
    PartRecipe,
    PartSpec,
    _to_dict,
)


def _parse_recipe(raw: dict[str, Any]) -> PartRecipe:
    """Convert a raw JSON dict into a typed PartRecipe."""
    parts: dict[str, PartSpec] = {}
    for name, spec in raw.get("parts", {}).items():
        dims = spec.get("dimensions", {})
        parts[name] = PartSpec(
            name=name,
            dimensions=Dimensions(
                width=float(dims.get("w", dims.get("width", 0))),
                depth=float(dims.get("d", dims.get("depth", 0))),
                height=float(dims.get("h", dims.get("height", 0))),
            ),
            type=spec.get("type", ""),
            params=spec.get("params", {}),
            metadata=spec.get("metadata", {}),
        )

    constraints: list[Constraint] = []
    for c in raw.get("constraints", []):
        constraints.append(
            Constraint(
                type=c["type"],
                part_a=c["part_a"],
                part_b=c["part_b"],
                axis=c.get("axis", ""),
                face_a=c.get("face_a", ""),
                face_b=c.get("face_b", ""),
                offset=float(c.get("offset", 0)),
                reference=c.get("reference", ""),
            )
        )

    mirrors: list[Mirror] = []
    for m in raw.get("mirrors", []):
        mirrors.append(
            Mirror(
                source=m["source"],
                target=m["target"],
                axis=m["axis"],
            )
        )

    return PartRecipe(
        name=raw.get("name", ""),
        anchor=raw.get("anchor", ""),
        anchor_position=[float(v) for v in raw.get("anchor_position", [0, 0, 0])],
        parts=parts,
        constraints=constraints,
        mirrors=mirrors,
        collections=raw.get("collections", {}),
    )


def handle_validate(arguments: dict[str, Any]) -> dict[str, Any]:
    """Parse input and delegate to the validator."""
    recipe = _parse_recipe(arguments["recipe"])
    result = validate(recipe)
    return _to_dict(result)
