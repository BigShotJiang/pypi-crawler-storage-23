"""Tool handler for the ``verify`` MCP tool."""

from __future__ import annotations

from typing import Any

from cortex.core.verifier import verify
from cortex.types import _to_dict


def handle_verify(arguments: dict[str, Any]) -> dict[str, Any]:
    """Parse input and delegate to the verifier."""
    object_name: str = arguments["object_name"]
    object_data: dict = arguments["object_data"]
    expected: dict = arguments["expected"]

    result = verify(
        object_name=object_name,
        object_data=object_data,
        expected=expected,
    )
    return _to_dict(result)
