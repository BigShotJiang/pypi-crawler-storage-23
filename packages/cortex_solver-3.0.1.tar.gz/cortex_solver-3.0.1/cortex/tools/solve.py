"""Tool handler for the ``solve`` MCP tool."""

from __future__ import annotations

from typing import Any

from cortex.core.solver import solve
from cortex.tools.validate import _parse_recipe
from cortex.types import _to_dict


def handle_solve(arguments: dict[str, Any]) -> dict[str, Any]:
    """Parse input and delegate to the solver."""
    recipe = _parse_recipe(arguments["recipe"])
    result = solve(recipe)
    return _to_dict(result)
