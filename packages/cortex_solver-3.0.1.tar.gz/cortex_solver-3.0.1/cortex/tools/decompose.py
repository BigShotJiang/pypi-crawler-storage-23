"""Tool handler for the ``decompose`` MCP tool."""

from __future__ import annotations

from typing import Any

from cortex.core.decomposer import decompose
from cortex.types import _to_dict


def handle_decompose(arguments: dict[str, Any]) -> dict[str, Any]:
    """Parse input and delegate to the decomposer."""
    subject: str = arguments["subject"]
    variant: str = arguments.get("variant", "")
    scope: str = arguments.get("scope", "object")
    detail_level: str = arguments.get("detail_level", "detailed")

    result = decompose(
        subject=subject,
        variant=variant,
        scope=scope,
        detail_level=detail_level,
    )
    return _to_dict(result)
