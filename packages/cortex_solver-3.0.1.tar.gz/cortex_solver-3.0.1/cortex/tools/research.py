"""Tool handler for the ``research`` MCP tool."""

from __future__ import annotations

from typing import Any

from cortex.core.decomposer import research
from cortex.types import _to_dict


def handle_research(arguments: dict[str, Any]) -> dict[str, Any]:
    """Parse input and delegate to the research checker."""
    hierarchy: dict = arguments["hierarchy"]
    filled_data: dict | None = arguments.get("filled_data")

    result = research(hierarchy=hierarchy, filled_data=filled_data)
    return _to_dict(result)
