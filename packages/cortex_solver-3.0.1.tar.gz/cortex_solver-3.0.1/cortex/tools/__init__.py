"""MCP tool handlers for Cortex."""
