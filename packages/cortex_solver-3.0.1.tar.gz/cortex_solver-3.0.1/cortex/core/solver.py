"""Constraint solver for part recipes."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Iterable

from cortex.types import (
    Constraint,
    Dimensions,
    Mirror,
    PartRecipe,
    PartSpec,
    SolveResult,
)

AXIS_INDEX = {"X": 0, "Y": 1, "Z": 2}
DIMENSION_INDEX = {0: "width", 1: "depth", 2: "height"}
TOLERANCE = 0.0001


@dataclass(slots=True)
class _AxisAssignment:
    axis: int
    value: float
    constraint: Constraint


@dataclass(slots=True)
class _AxisSetResult:
    position: list[float]
    conflicts: list[dict[str, object]]


def solve(recipe: PartRecipe) -> SolveResult:
    """Solve all part positions for a recipe."""

    if recipe.anchor not in recipe.parts:
        return SolveResult(
            success=False,
            error="Anchor part is missing from recipe parts.",
        )

    part_names = set(recipe.parts.keys())
    constraints = list(recipe.constraints or [])
    dependencies: dict[str, set[str]] = {name: set() for name in part_names}
    dependents: dict[str, set[str]] = {name: set() for name in part_names}

    for constraint in constraints:
        if constraint.part_a in part_names and constraint.part_b in part_names:
            dependencies[constraint.part_a].add(constraint.part_b)
            dependents[constraint.part_b].add(constraint.part_a)

    in_degree = {name: len(dependencies[name]) for name in part_names}
    zero_degree = sorted(
        name for name, degree in in_degree.items() if degree == 0 and name != recipe.anchor
    )
    queue = deque(
        [recipe.anchor, *zero_degree] if in_degree.get(recipe.anchor, 0) == 0 else []
    )
    build_order: list[str] = []

    while queue:
        current = queue.popleft()
        build_order.append(current)
        for dependent in sorted(dependents.get(current, [])):
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)

    if len(build_order) < len(part_names):
        return SolveResult(
            success=False,
            error="Circular dependency detected in recipe constraints.",
            build_order=build_order,
        )

    positions: dict[str, dict[str, list[float]]] = {}
    conflicts: list[dict[str, object]] = []

    anchor_position = list(recipe.anchor_position)
    anchor_spec = recipe.parts[recipe.anchor]
    positions[recipe.anchor] = _make_position(anchor_position, anchor_spec)

    if len(part_names) == 1:
        return SolveResult(
            success=True,
            positions=positions,
            build_order=build_order,
            conflicts=conflicts,
        )

    constraints_by_target: dict[str, list[Constraint]] = {
        name: [] for name in part_names
    }
    for constraint in constraints:
        if constraint.part_a in part_names:
            constraints_by_target[constraint.part_a].append(constraint)

    for part_name in build_order:
        if part_name == recipe.anchor:
            continue
        part_spec = recipe.parts[part_name]
        axis_set = _solve_part_axes(
            part_name,
            part_spec,
            constraints_by_target.get(part_name, []),
            recipe.parts,
            positions,
            anchor_position,
        )
        positions[part_name] = _make_position(axis_set.position, part_spec)
        conflicts.extend(axis_set.conflicts)

    for mirror in recipe.mirrors:
        if mirror.source not in positions:
            continue
        mirrored = _apply_mirror(
            mirror, positions[mirror.source]["location"], anchor_position
        )
        positions[mirror.target] = {
            "location": list(mirrored),
            "dimensions": list(positions[mirror.source]["dimensions"]),
        }

    return SolveResult(
        success=True,
        positions=positions,
        build_order=build_order,
        conflicts=conflicts,
    )


def _solve_part_axes(
    part_name: str,
    part_spec: PartSpec,
    constraints: Iterable[Constraint],
    parts: dict[str, PartSpec],
    positions: dict[str, dict[str, list[float]]],
    anchor_position: list[float],
) -> _AxisSetResult:
    axis_values = list(anchor_position)
    axis_locked = [False, False, False]
    conflicts: list[dict[str, object]] = []

    for constraint in constraints:
        if constraint.part_b not in positions:
            continue
        target_assignments = _resolve_constraint(
            constraint,
            part_spec,
            parts[constraint.part_b],
            positions[constraint.part_b]["location"],
            anchor_position,
        )
        for assignment in target_assignments:
            conflicts = _apply_axis_assignment(
                part_name,
                axis_values,
                axis_locked,
                assignment,
                conflicts,
            )

    return _AxisSetResult(position=axis_values, conflicts=conflicts)


def _resolve_constraint(
    constraint: Constraint,
    part_a: PartSpec,
    part_b: PartSpec,
    b_position: list[float],
    anchor_position: list[float],
) -> list[_AxisAssignment]:
    constraint_type = constraint.type
    axis_index = AXIS_INDEX.get(constraint.axis)
    if axis_index is None:
        return []

    a_dim = _dimension_for_axis(part_a.dimensions, axis_index)
    b_dim = _dimension_for_axis(part_b.dimensions, axis_index)
    a_half = a_dim / 2.0
    b_half = b_dim / 2.0

    if constraint_type == "STACKED":
        if constraint.reference == "top":
            value = b_position[axis_index] + b_half + a_half
        else:
            value = b_position[axis_index] - b_half - a_half
        return [_AxisAssignment(axis=axis_index, value=value, constraint=constraint)]

    if constraint_type == "CENTERED":
        return [
            _AxisAssignment(
                axis=axis_index, value=b_position[axis_index], constraint=constraint
            )
        ]

    if constraint_type == "FLUSH":
        b_face = _face_position(b_position[axis_index], b_half, constraint.face_b)
        a_center = _face_center(b_face, a_half, constraint.face_a)
        return [_AxisAssignment(axis=axis_index, value=a_center, constraint=constraint)]

    if constraint_type == "OFFSET":
        b_face = _face_position(b_position[axis_index], b_half, constraint.face_b)
        a_center = _face_center(b_face, a_half, constraint.face_a) + constraint.offset
        return [_AxisAssignment(axis=axis_index, value=a_center, constraint=constraint)]

    if constraint_type == "COAXIAL":
        assignments = []
        for other_axis in range(3):
            if other_axis == axis_index:
                continue
            assignments.append(
                _AxisAssignment(
                    axis=other_axis,
                    value=b_position[other_axis],
                    constraint=constraint,
                )
            )
        return assignments

    if constraint_type == "INSIDE":
        return [
            _AxisAssignment(
                axis=axis_index, value=b_position[axis_index], constraint=constraint
            )
        ]

    if constraint_type == "ALIGNED":
        return [
            _AxisAssignment(
                axis=axis_index, value=b_position[axis_index], constraint=constraint
            )
        ]

    if constraint_type == "SYMMETRIC":
        mirrored = [b_position[0], b_position[1], b_position[2]]
        mirrored[axis_index] = 2 * anchor_position[axis_index] - b_position[axis_index]
        return [
            _AxisAssignment(axis=0, value=mirrored[0], constraint=constraint),
            _AxisAssignment(axis=1, value=mirrored[1], constraint=constraint),
            _AxisAssignment(axis=2, value=mirrored[2], constraint=constraint),
        ]

    return []


def _apply_axis_assignment(
    part_name: str,
    axis_values: list[float],
    axis_locked: list[bool],
    assignment: _AxisAssignment,
    conflicts: list[dict[str, object]],
) -> list[dict[str, object]]:
    axis = assignment.axis
    if axis_locked[axis]:
        if abs(axis_values[axis] - assignment.value) > TOLERANCE:
            conflicts.append(
                {
                    "part": part_name,
                    "axis": axis,
                    "value": axis_values[axis],
                    "conflict": assignment.value,
                    "constraint": assignment.constraint,
                }
            )
        return conflicts

    axis_values[axis] = assignment.value
    axis_locked[axis] = True
    return conflicts


def _dimension_for_axis(dimensions: Dimensions, axis_index: int) -> float:
    return getattr(dimensions, DIMENSION_INDEX[axis_index])


def _face_position(center_value: float, half: float, face: str) -> float:
    if face == "+":
        return center_value + half
    return center_value - half


def _face_center(face_value: float, half: float, face: str) -> float:
    if face == "+":
        return face_value - half
    return face_value + half


def _apply_mirror(
    mirror: Mirror, source_position: list[float], anchor_position: list[float]
) -> list[float]:
    axis_index = AXIS_INDEX.get(mirror.axis)
    if axis_index is None:
        return list(source_position)
    mirrored = list(source_position)
    mirrored[axis_index] = 2 * anchor_position[axis_index] - source_position[axis_index]
    return mirrored


def _make_position(position: list[float], spec: PartSpec) -> dict[str, list[float]]:
    return {"location": list(position), "dimensions": spec.dimensions.as_list()}
