"""Post-build verification for 3D objects."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from cortex.types import VerifyCheck, VerifyResult


@dataclass(frozen=True, slots=True)
class AxisDeviation:
    axis: str
    actual: float
    expected: float
    delta: float


def _get_list(value: object, length: int) -> list[float] | None:
    if not isinstance(value, (list, tuple)):
        return None
    if len(value) != length:
        return None
    try:
        return [float(item) for item in value]
    except (TypeError, ValueError):
        return None


def _axis_deviations(
    actual: list[float], expected: list[float], axes: Iterable[str]
) -> list[AxisDeviation]:
    deviations: list[AxisDeviation] = []
    for axis, actual_value, expected_value in zip(axes, actual, expected):
        delta = actual_value - expected_value
        deviations.append(
            AxisDeviation(
                axis=axis,
                actual=actual_value,
                expected=expected_value,
                delta=delta,
            )
        )
    return deviations


def _format_axis_details(
    label: str, deviations: list[AxisDeviation], tolerance: float
) -> str:
    failures = []
    for deviation in deviations:
        if abs(deviation.delta) > tolerance:
            failures.append(
                f"{label}.{deviation.axis}: actual={deviation.actual:.4f}, "
                f"expected={deviation.expected:.4f}, delta={deviation.delta:.4f}"
            )
    if not failures:
        return f"{label} within tolerance"
    return "; ".join(failures)


def _missing_details(field: str) -> str:
    return f"Missing required field: {field}"


def _mesh_health_check(object_data: dict) -> VerifyCheck:
    missing_fields = [
        name
        for name in (
            "has_ngons",
            "has_non_manifold",
            "has_loose_vertices",
            "normals_consistent",
        )
        if name not in object_data
    ]
    if missing_fields:
        details = "; ".join(_missing_details(name) for name in missing_fields)
        return VerifyCheck(
            name="mesh_health",
            passed=False,
            details=details,
            severity="critical",
        )

    has_non_manifold = bool(object_data.get("has_non_manifold"))
    warnings = []
    if object_data.get("has_ngons"):
        warnings.append("Object has N-gons")
    if object_data.get("has_loose_vertices"):
        warnings.append("Loose vertices found")
    if not object_data.get("normals_consistent"):
        warnings.append("Inconsistent normals")
    if has_non_manifold:
        warnings.append("Non-manifold geometry detected")

    passed = not has_non_manifold
    details = "OK" if not warnings else "; ".join(warnings)
    return VerifyCheck(
        name="mesh_health",
        passed=passed,
        details=details,
        severity="critical",
    )


def _identity_check(object_data: dict, expected: dict) -> VerifyCheck:
    scale = _get_list(object_data.get("scale"), 3)
    if scale is None:
        return VerifyCheck(
            name="identity",
            passed=False,
            details=_missing_details("scale"),
            severity="critical",
        )

    expected_collection = expected.get("collection")
    actual_collection = object_data.get("collection")
    if expected_collection is not None and actual_collection is None:
        return VerifyCheck(
            name="identity",
            passed=False,
            details=_missing_details("collection"),
            severity="critical",
        )

    tolerance = 0.001
    scale_ok = all(abs(value - 1.0) <= tolerance for value in scale)
    collection_ok = (
        expected_collection is None or actual_collection == expected_collection
    )

    failures = []
    if not scale_ok:
        deviations = _axis_deviations(scale, [1.0, 1.0, 1.0], ("x", "y", "z"))
        failures.append(_format_axis_details("scale", deviations, tolerance))
    if not collection_ok:
        failures.append(
            f"collection mismatch: actual={actual_collection!r}, expected={expected_collection!r}"
        )

    passed = scale_ok and collection_ok
    details = "OK" if passed else "; ".join(failures)
    return VerifyCheck(
        name="identity",
        passed=passed,
        details=details,
        severity="critical",
    )


def _placement_check(object_data: dict, expected: dict) -> VerifyCheck:
    actual_location = _get_list(object_data.get("location"), 3)
    expected_location = _get_list(expected.get("location"), 3)
    if actual_location is None:
        return VerifyCheck(
            name="placement",
            passed=False,
            details=_missing_details("location"),
            severity="critical",
        )
    if expected_location is None:
        return VerifyCheck(
            name="placement",
            passed=False,
            details=_missing_details("expected.location"),
            severity="critical",
        )

    tolerance = 0.001
    deviations = _axis_deviations(actual_location, expected_location, ("x", "y", "z"))
    passed = all(abs(dev.delta) <= tolerance for dev in deviations)
    details = _format_axis_details("location", deviations, tolerance)
    return VerifyCheck(
        name="placement",
        passed=passed,
        details=details,
        severity="critical",
    )


def _neighbors_lookup(neighbors: object) -> dict[str, dict]:
    if not isinstance(neighbors, list):
        return {}
    lookup: dict[str, dict] = {}
    for neighbor in neighbors:
        if isinstance(neighbor, dict) and "name" in neighbor:
            lookup[str(neighbor["name"])] = neighbor
    return lookup


def _connection_check(object_data: dict, expected: dict) -> VerifyCheck:
    expected_neighbors = expected.get("neighbors")
    if expected_neighbors is None:
        return VerifyCheck(
            name="connection",
            passed=True,
            details="No neighbor expectations",
            severity="warning",
        )
    if not isinstance(expected_neighbors, list):
        return VerifyCheck(
            name="connection",
            passed=False,
            details=_missing_details("expected.neighbors"),
            severity="warning",
        )

    actual_lookup = _neighbors_lookup(object_data.get("neighbors"))
    tolerance = 0.002
    failures: list[str] = []
    for neighbor in expected_neighbors:
        if not isinstance(neighbor, dict) or "name" not in neighbor:
            failures.append("Invalid expected neighbor entry")
            continue
        name = str(neighbor.get("name"))
        expected_distance = neighbor.get("min_distance")
        if expected_distance is None:
            failures.append(f"Missing expected min_distance for {name}")
            continue
        actual_neighbor = actual_lookup.get(name)
        if actual_neighbor is None:
            failures.append(f"Missing neighbor: {name}")
            continue
        actual_distance = actual_neighbor.get("closest_distance")
        if actual_distance is None:
            failures.append(f"Missing closest_distance for {name}")
            continue
        try:
            actual_distance_value = float(actual_distance)
            expected_distance_value = float(expected_distance)
        except (TypeError, ValueError):
            failures.append(f"Invalid distance data for {name}")
            continue
        delta = actual_distance_value - expected_distance_value
        if abs(delta) > tolerance:
            failures.append(
                f"{name}: actual={actual_distance_value:.4f}, expected={expected_distance_value:.4f}, "
                f"delta={delta:.4f}"
            )

    passed = not failures
    details = "All connections within tolerance" if passed else "; ".join(failures)
    return VerifyCheck(
        name="connection",
        passed=passed,
        details=details,
        severity="warning",
    )


def _dimensions_check(object_data: dict, expected: dict) -> VerifyCheck:
    actual_dimensions = _get_list(object_data.get("dimensions"), 3)
    expected_dimensions = _get_list(expected.get("dimensions"), 3)
    if actual_dimensions is None:
        return VerifyCheck(
            name="dimensions",
            passed=False,
            details=_missing_details("dimensions"),
            severity="warning",
        )
    if expected_dimensions is None:
        return VerifyCheck(
            name="dimensions",
            passed=False,
            details=_missing_details("expected.dimensions"),
            severity="warning",
        )

    tolerance = 0.005
    deviations = _axis_deviations(
        actual_dimensions, expected_dimensions, ("x", "y", "z")
    )
    passed = all(abs(dev.delta) <= tolerance for dev in deviations)
    details = _format_axis_details("dimensions", deviations, tolerance)
    return VerifyCheck(
        name="dimensions",
        passed=passed,
        details=details,
        severity="warning",
    )


def _summarize(checks: list[VerifyCheck]) -> str:
    failed = [check.name for check in checks if not check.passed]
    if not failed:
        return "All checks passed"
    return f"{len(failed)} of {len(checks)} checks failed: {', '.join(failed)}"


def verify(object_name: str, object_data: dict, expected: dict) -> VerifyResult:
    """Verify a post-build object against expected values."""
    checks = [
        _mesh_health_check(object_data),
        _identity_check(object_data, expected),
        _placement_check(object_data, expected),
        _connection_check(object_data, expected),
        _dimensions_check(object_data, expected),
    ]
    passed = all(check.passed for check in checks if check.severity == "critical")
    summary = _summarize(checks)
    return VerifyResult(
        object_name=object_name,
        passed=passed,
        checks=checks,
        summary=summary,
    )
