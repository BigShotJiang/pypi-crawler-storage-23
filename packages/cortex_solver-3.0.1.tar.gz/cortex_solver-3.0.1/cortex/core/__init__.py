"""Core business logic for Cortex."""
