"""Cortex — MCP build-methodology server."""

from cortex.server import main

__all__ = ["main"]
