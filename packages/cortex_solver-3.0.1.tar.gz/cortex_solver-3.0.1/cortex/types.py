"""Cortex type definitions — all dataclasses for the MCP build-methodology server."""

from __future__ import annotations

from dataclasses import dataclass, field, fields as _dc_fields
from enum import Enum
from typing import Any


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class ConstraintType(str, Enum):
    """Part-level constraint types."""

    STACKED = "STACKED"
    CENTERED = "CENTERED"
    FLUSH = "FLUSH"
    OFFSET = "OFFSET"
    COAXIAL = "COAXIAL"
    INSIDE = "INSIDE"
    ALIGNED = "ALIGNED"
    SYMMETRIC = "SYMMETRIC"


class SceneConstraintType(str, Enum):
    """Scene-level constraint types."""

    GRID = "GRID"
    ALONG_PATH = "ALONG_PATH"
    RADIAL = "RADIAL"
    FACING = "FACING"
    DISTANCE = "DISTANCE"
    AGAINST_EDGE = "AGAINST_EDGE"
    RANDOM_SCATTER = "RANDOM_SCATTER"
    STACK_VERTICAL = "STACK_VERTICAL"
    MIRROR_SCENE = "MIRROR_SCENE"


class Scope(str, Enum):
    OBJECT = "object"
    SCENE = "scene"


class DetailLevel(str, Enum):
    BASIC = "basic"
    DETAILED = "detailed"
    EXHAUSTIVE = "exhaustive"


class Severity(str, Enum):
    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"


# ---------------------------------------------------------------------------
# Core geometry
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Dimensions:
    """Width (X), depth (Y), height (Z)."""

    width: float
    depth: float
    height: float

    def as_list(self) -> list[float]:
        return [self.width, self.depth, self.height]


# ---------------------------------------------------------------------------
# Part recipe types
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class PartSpec:
    """Specification for a single part."""

    name: str
    dimensions: Dimensions
    type: str = ""
    params: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class Constraint:
    """A single constraint between two parts."""

    type: str
    part_a: str
    part_b: str
    axis: str
    face_a: str = ""
    face_b: str = ""
    offset: float = 0.0
    reference: str = ""


@dataclass(frozen=True, slots=True)
class Mirror:
    """Mirror definition — clone *source* to *target* across *axis*."""

    source: str
    target: str
    axis: str


@dataclass(slots=True)
class PartRecipe:
    """Full recipe describing an object's parts and their relationships."""

    name: str
    anchor: str
    anchor_position: list[float]
    parts: dict[str, PartSpec]
    constraints: list[Constraint]
    mirrors: list[Mirror] = field(default_factory=list)
    collections: dict[str, list[str]] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Scene recipe types
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class SceneConstraint:
    """A single scene-level constraint."""

    type: str
    object: str | list[str]
    params: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class SceneRecipe:
    """Full recipe describing a scene layout."""

    name: str
    bounds: dict[str, list[float]]
    objects: dict[str, PartSpec]
    zones: dict[str, Any] = field(default_factory=dict)
    constraints: list[SceneConstraint] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class SolveResult:
    """Result of constraint solving."""

    success: bool
    positions: dict[str, dict[str, list[float]]] = field(default_factory=dict)
    build_order: list[str] = field(default_factory=list)
    conflicts: list[dict[str, Any]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    error: str = ""


@dataclass(frozen=True, slots=True)
class VerifyCheck:
    """Result of a single verification check."""

    name: str
    passed: bool
    details: str
    severity: str


@dataclass(slots=True)
class VerifyResult:
    """Aggregated verification result for one object."""

    object_name: str
    passed: bool
    checks: list[VerifyCheck]
    summary: str


# ---------------------------------------------------------------------------
# Decomposition result types
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class HierarchyNode:
    """Single node in a decomposition hierarchy."""

    name: str
    parent: str | None = None
    connection: str = ""
    children: list[str] = field(default_factory=list)


@dataclass(slots=True)
class ResearchItem:
    """What research is needed for a specific part."""

    part: str
    needed: list[str] = field(default_factory=list)


@dataclass(slots=True)
class DecomposeResult:
    """Full output from the decompose tool."""

    subject: str
    hierarchy: dict[str, HierarchyNode]
    research_required: list[ResearchItem]
    total_parts: int
    build_order: list[str]


@dataclass(slots=True)
class ResearchWarning:
    """Warning about a researched value."""

    part: str
    field: str
    value: Any
    concern: str


@dataclass(slots=True)
class MissingField:
    """A missing research field."""

    part: str
    field: str
    hint: str = ""


@dataclass(slots=True)
class ResearchResult:
    """Full output from the research tool."""

    complete: bool
    missing: list[MissingField]
    warnings: list[ResearchWarning]
    ready_for_recipe: bool


@dataclass(slots=True)
class ValidationError:
    """A single validation error."""

    type: str
    message: str
    location: str = ""


@dataclass(slots=True)
class ValidationWarning:
    """A single validation warning."""

    type: str
    message: str


@dataclass(slots=True)
class ValidationResult:
    """Full output from the validate tool."""

    valid: bool
    errors: list[ValidationError]
    warnings: list[ValidationWarning]


# ---------------------------------------------------------------------------
# Serialisation helpers
# ---------------------------------------------------------------------------


def _to_dict(obj: Any) -> Any:
    """Recursively convert dataclasses / enums to plain dicts for JSON."""
    if isinstance(obj, dict):
        return {k: _to_dict(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_dict(v) for v in obj]
    if isinstance(obj, Enum):
        return obj.value
    if hasattr(obj, "__dataclass_fields__"):
        return {
            f.name: _to_dict(getattr(obj, f.name))
            for f in _dc_fields(obj)
            if not f.name.startswith("_")
        }
    return obj
