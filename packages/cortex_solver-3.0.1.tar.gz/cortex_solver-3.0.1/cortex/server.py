"""Cortex MCP server — tool registration and stdio transport."""

from __future__ import annotations

import json
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from cortex.tools.decompose import handle_decompose
from cortex.tools.research import handle_research
from cortex.tools.validate import handle_validate
from cortex.tools.solve import handle_solve
from cortex.tools.solve_scene import handle_solve_scene
from cortex.tools.verify import handle_verify

# ---------------------------------------------------------------------------
# Server instance
# ---------------------------------------------------------------------------

server = Server("cortex")

# ---------------------------------------------------------------------------
# Tool definitions
# ---------------------------------------------------------------------------

TOOLS: list[Tool] = [
    Tool(
        name="decompose",
        description=(
            "Decompose a subject into a hierarchical part/object tree with "
            "research checklists. First step in the build pipeline."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "subject": {
                    "type": "string",
                    "description": "The object or scene to decompose (e.g. 'office chair', 'city block').",
                },
                "variant": {
                    "type": "string",
                    "description": "Optional variant (e.g. 'gaming', 'modern').",
                    "default": "",
                },
                "scope": {
                    "type": "string",
                    "enum": ["object", "scene"],
                    "description": "Whether to decompose as a single object or a scene of objects.",
                    "default": "object",
                },
                "detail_level": {
                    "type": "string",
                    "enum": ["basic", "detailed", "exhaustive"],
                    "description": "How deep to decompose.",
                    "default": "detailed",
                },
            },
            "required": ["subject"],
        },
    ),
    Tool(
        name="research",
        description=(
            "Validate research data completeness and sanity-check dimensions. "
            "Tells the LLM what data is still missing before recipe creation."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "hierarchy": {
                    "type": "object",
                    "description": "Hierarchy from decompose output.",
                },
                "filled_data": {
                    "type": "object",
                    "description": "Partial research data: {part_name: {dimensions: {w,d,h}, ...}}.",
                    "default": None,
                },
            },
            "required": ["hierarchy"],
        },
    ),
    Tool(
        name="validate",
        description=(
            "Validate a part recipe for structural correctness before solving. "
            "Checks schema, references, cycles, and constraint validity."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "recipe": {
                    "type": "object",
                    "description": "The part recipe to validate.",
                },
            },
            "required": ["recipe"],
        },
    ),
    Tool(
        name="solve",
        description=(
            "Solve part positions from a validated recipe using constraint resolution. "
            "Returns absolute positions, build order, and any conflicts."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "recipe": {
                    "type": "object",
                    "description": "A validated part recipe.",
                },
            },
            "required": ["recipe"],
        },
    ),
    Tool(
        name="solve_scene",
        description=(
            "Solve object placements in a scene from scene-level constraints. "
            "Returns positions, rotations, and scales for each object."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "scene_recipe": {
                    "type": "object",
                    "description": "A scene recipe with objects, zones, and constraints.",
                },
            },
            "required": ["scene_recipe"],
        },
    ),
    Tool(
        name="verify",
        description=(
            "Verify a built object against expected solver output. "
            "Checks mesh health, transforms, placement, connections, and dimensions."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "object_name": {
                    "type": "string",
                    "description": "Name of the object to verify.",
                },
                "object_data": {
                    "type": "object",
                    "description": "Actual measured data from the 3D engine.",
                },
                "expected": {
                    "type": "object",
                    "description": "Expected values from solver output.",
                },
            },
            "required": ["object_name", "object_data", "expected"],
        },
    ),
]


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------


@server.list_tools()
async def list_tools() -> list[Tool]:
    return TOOLS


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Route tool calls to the appropriate handler."""
    handlers = {
        "decompose": handle_decompose,
        "research": handle_research,
        "validate": handle_validate,
        "solve": handle_solve,
        "solve_scene": handle_solve_scene,
        "verify": handle_verify,
    }

    handler = handlers.get(name)
    if handler is None:
        return [
            TextContent(
                type="text", text=json.dumps({"error": f"Unknown tool: {name}"})
            )
        ]

    try:
        result = handler(arguments)
        return [TextContent(type="text", text=json.dumps(result, default=str))]
    except Exception as exc:
        return [
            TextContent(
                type="text",
                text=json.dumps({"error": str(exc), "tool": name}),
            )
        ]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


async def _run() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream, write_stream, server.create_initialization_options()
        )


def main() -> None:
    import asyncio

    asyncio.run(_run())


if __name__ == "__main__":
    main()
