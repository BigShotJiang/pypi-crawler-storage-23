"""Allow running as ``python -m cortex``."""

from cortex.server import main

main()
