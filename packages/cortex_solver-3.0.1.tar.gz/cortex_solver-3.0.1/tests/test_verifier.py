import pytest

from cortex.core.verifier import verify


def make_object_data(**overrides):
    data = {
        "has_ngons": False,
        "has_non_manifold": False,
        "has_loose_vertices": False,
        "normals_consistent": True,
        "scale": [1.0, 1.0, 1.0],
        "collection": "Assets",
        "location": [0.0, 0.0, 0.0],
        "neighbors": [
            {"name": "Neighbor", "closest_distance": 2.0},
        ],
        "dimensions": [1.0, 2.0, 3.0],
    }
    data.update(overrides)
    return data


def make_expected(**overrides):
    expected = {
        "collection": "Assets",
        "location": [0.0, 0.0, 0.0],
        "neighbors": [
            {"name": "Neighbor", "min_distance": 2.0},
        ],
        "dimensions": [1.0, 2.0, 3.0],
    }
    expected.update(overrides)
    return expected


def _check(result, name: str):
    return next(check for check in result.checks if check.name == name)


def test_all_checks_pass():
    result = verify("Cube", make_object_data(), make_expected())
    assert result.passed is True
    assert all(check.passed for check in result.checks)
    assert len(result.checks) == 5


def test_mesh_health_non_manifold():
    data = make_object_data(has_non_manifold=True)
    result = verify("Cube", data, make_expected())
    mesh_check = _check(result, "mesh_health")
    assert mesh_check.passed is False
    assert mesh_check.severity == "critical"


def test_mesh_health_ngons_warning():
    data = make_object_data(has_ngons=True)
    result = verify("Cube", data, make_expected())
    mesh_check = _check(result, "mesh_health")
    assert mesh_check.passed is True
    assert "N-gons" in mesh_check.details


def test_mesh_health_loose_vertices():
    data = make_object_data(has_loose_vertices=True)
    result = verify("Cube", data, make_expected())
    mesh_check = _check(result, "mesh_health")
    assert mesh_check.passed is True
    assert "Loose vertices" in mesh_check.details


def test_identity_bad_scale():
    data = make_object_data(scale=[1.1, 1.0, 1.0])
    result = verify("Cube", data, make_expected())
    identity_check = _check(result, "identity")
    assert identity_check.passed is False
    assert "scale" in identity_check.details


def test_identity_wrong_collection():
    data = make_object_data(collection="Wrong")
    result = verify("Cube", data, make_expected())
    identity_check = _check(result, "identity")
    assert identity_check.passed is False
    assert "collection mismatch" in identity_check.details


def test_placement_exact():
    data = make_object_data(location=[1.0, 2.0, 3.0])
    expected = make_expected(location=[1.0, 2.0, 3.0])
    result = verify("Cube", data, expected)
    placement_check = _check(result, "placement")
    assert placement_check.passed is True


def test_placement_within_tolerance():
    data = make_object_data(location=[0.0005, 0.0, 0.0])
    expected = make_expected(location=[0.0, 0.0, 0.0])
    result = verify("Cube", data, expected)
    placement_check = _check(result, "placement")
    assert placement_check.passed is True


def test_placement_outside_tolerance():
    data = make_object_data(location=[0.01, 0.0, 0.0])
    expected = make_expected(location=[0.0, 0.0, 0.0])
    result = verify("Cube", data, expected)
    placement_check = _check(result, "placement")
    assert placement_check.passed is False


def test_connection_pass():
    data = make_object_data(neighbors=[{"name": "Neighbor", "closest_distance": 2.0}])
    expected = make_expected(neighbors=[{"name": "Neighbor", "min_distance": 2.0}])
    result = verify("Cube", data, expected)
    connection_check = _check(result, "connection")
    assert connection_check.passed is True


def test_connection_fail():
    data = make_object_data(neighbors=[{"name": "Neighbor", "closest_distance": 2.05}])
    expected = make_expected(neighbors=[{"name": "Neighbor", "min_distance": 2.0}])
    result = verify("Cube", data, expected)
    connection_check = _check(result, "connection")
    assert connection_check.passed is False
    assert connection_check.severity == "warning"


def test_dimensions_pass():
    data = make_object_data(dimensions=[1.0, 2.0, 3.0])
    expected = make_expected(dimensions=[1.0, 2.0, 3.0])
    result = verify("Cube", data, expected)
    dimensions_check = _check(result, "dimensions")
    assert dimensions_check.passed is True


def test_dimensions_fail():
    data = make_object_data(dimensions=[1.0, 2.0, 3.02])
    expected = make_expected(dimensions=[1.0, 2.0, 3.0])
    result = verify("Cube", data, expected)
    dimensions_check = _check(result, "dimensions")
    assert dimensions_check.passed is False


def test_missing_object_data_field():
    data = make_object_data()
    data.pop("location")
    result = verify("Cube", data, make_expected())
    placement_check = _check(result, "placement")
    assert placement_check.passed is False
    assert "Missing required field" in placement_check.details


def test_critical_fail_means_overall_fail():
    data = make_object_data(scale=[2.0, 1.0, 1.0])
    result = verify("Cube", data, make_expected())
    assert result.passed is False
    assert _check(result, "identity").passed is False
