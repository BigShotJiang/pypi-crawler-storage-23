"""Integration tests for the MCP tool handlers."""

from __future__ import annotations

import json
import pathlib

import pytest

from cortex.tools.decompose import handle_decompose
from cortex.tools.research import handle_research
from cortex.tools.validate import handle_validate
from cortex.tools.solve import handle_solve
from cortex.tools.solve_scene import handle_solve_scene
from cortex.tools.verify import handle_verify

FIXTURES = pathlib.Path(__file__).parent / "fixtures"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _load_fixture(name: str) -> dict:
    return json.loads((FIXTURES / name).read_text(encoding="utf-8"))


def _make_simple_recipe() -> dict:
    """Minimal valid recipe for quick tests."""
    return {
        "name": "test_box",
        "anchor": "base",
        "anchor_position": [0, 0, 0],
        "parts": {
            "base": {"dimensions": {"w": 1.0, "d": 1.0, "h": 0.5}},
            "top": {"dimensions": {"w": 1.0, "d": 1.0, "h": 0.5}},
        },
        "constraints": [
            {
                "type": "STACKED",
                "part_a": "top",
                "part_b": "base",
                "axis": "Z",
                "reference": "top",
            },
        ],
    }


# ---------------------------------------------------------------------------
# decompose tool
# ---------------------------------------------------------------------------


class TestDecomposeTool:
    def test_basic_decompose(self):
        result = handle_decompose({"subject": "chair"})
        assert "subject" in result
        assert "hierarchy" in result
        assert "total_parts" in result
        assert result["total_parts"] > 0

    def test_decompose_with_variant(self):
        result = handle_decompose({"subject": "chair", "variant": "gaming"})
        assert result["subject"] == "chair"
        assert result["total_parts"] > 0

    def test_decompose_scene_scope(self):
        result = handle_decompose({"subject": "office", "scope": "scene"})
        assert result["total_parts"] > 0


# ---------------------------------------------------------------------------
# validate tool
# ---------------------------------------------------------------------------


class TestValidateTool:
    def test_validate_simple_recipe(self):
        result = handle_validate({"recipe": _make_simple_recipe()})
        assert result["valid"] is True
        assert result["errors"] == []

    def test_validate_fixture_bench(self):
        recipe = _load_fixture("bench_recipe.json")
        result = handle_validate({"recipe": recipe})
        assert result["valid"] is True

    def test_validate_fixture_headphone(self):
        recipe = _load_fixture("headphone_recipe.json")
        result = handle_validate({"recipe": recipe})
        assert result["valid"] is True

    def test_validate_bad_recipe(self):
        result = handle_validate(
            {
                "recipe": {
                    "name": "",
                    "anchor": "missing",
                    "anchor_position": [0, 0, 0],
                    "parts": {},
                    "constraints": [],
                }
            }
        )
        assert result["valid"] is False
        assert len(result["errors"]) > 0


# ---------------------------------------------------------------------------
# solve tool
# ---------------------------------------------------------------------------


class TestSolveTool:
    def test_solve_simple(self):
        result = handle_solve({"recipe": _make_simple_recipe()})
        assert result["success"] is True
        assert "base" in result["positions"]
        assert "top" in result["positions"]
        # top should be on top of base: base_z(0) + 0.25 + 0.25 = 0.5
        top_z = result["positions"]["top"]["location"][2]
        assert top_z == pytest.approx(0.5, abs=0.001)

    def test_solve_bench_fixture(self):
        recipe = _load_fixture("bench_recipe.json")
        result = handle_solve({"recipe": recipe})
        assert result["success"] is True
        assert len(result["positions"]) > 0
        assert len(result["build_order"]) > 0

    def test_solve_headphone_fixture(self):
        recipe = _load_fixture("headphone_recipe.json")
        result = handle_solve({"recipe": recipe})
        assert result["success"] is True
        # Should have all original parts + mirrored parts
        assert len(result["positions"]) >= 10


# ---------------------------------------------------------------------------
# solve_scene tool
# ---------------------------------------------------------------------------


class TestSolveSceneTool:
    def test_solve_simple_scene(self):
        scene = {
            "name": "test_scene",
            "bounds": {"min": [0, 0, 0], "max": [10, 10, 10]},
            "objects": {
                "box_a": {"dimensions": {"w": 1, "d": 1, "h": 1}},
                "box_b": {"dimensions": {"w": 1, "d": 1, "h": 1}},
            },
            "constraints": [],
        }
        result = handle_solve_scene({"scene_recipe": scene})
        assert result["success"] is True
        assert "box_a" in result["positions"]

    def test_solve_city_fixture(self):
        scene = _load_fixture("city_scene_recipe.json")
        result = handle_solve_scene({"scene_recipe": scene})
        assert result["success"] is True
        assert len(result["positions"]) > 0


# ---------------------------------------------------------------------------
# verify tool
# ---------------------------------------------------------------------------


class TestVerifyTool:
    def test_verify_passing(self):
        result = handle_verify(
            {
                "object_name": "test_box",
                "object_data": {
                    "location": [1.0, 2.0, 3.0],
                    "dimensions": [1.0, 1.0, 0.5],
                    "scale": [1.0, 1.0, 1.0],
                    "vertex_count": 8,
                    "face_count": 6,
                    "has_ngons": False,
                    "has_non_manifold": False,
                    "has_loose_vertices": False,
                    "normals_consistent": True,
                    "collection": "Parts",
                    "neighbors": [],
                },
                "expected": {
                    "location": [1.0, 2.0, 3.0],
                    "dimensions": [1.0, 1.0, 0.5],
                    "collection": "Parts",
                    "neighbors": [],
                },
            }
        )
        assert result["passed"] is True

    def test_verify_placement_fail(self):
        result = handle_verify(
            {
                "object_name": "test_box",
                "object_data": {
                    "location": [1.5, 2.0, 3.0],  # off by 0.5
                    "dimensions": [1.0, 1.0, 0.5],
                    "scale": [1.0, 1.0, 1.0],
                    "vertex_count": 8,
                    "face_count": 6,
                    "has_ngons": False,
                    "has_non_manifold": False,
                    "has_loose_vertices": False,
                    "normals_consistent": True,
                    "collection": "Parts",
                    "neighbors": [],
                },
                "expected": {
                    "location": [1.0, 2.0, 3.0],
                    "dimensions": [1.0, 1.0, 0.5],
                    "collection": "Parts",
                    "neighbors": [],
                },
            }
        )
        assert result["passed"] is False


# ---------------------------------------------------------------------------
# Pipeline integration — decompose → validate → solve
# ---------------------------------------------------------------------------


class TestPipeline:
    def test_full_pipeline_bench(self):
        """Full pipeline: validate bench recipe → solve → verify a part."""
        recipe = _load_fixture("bench_recipe.json")

        # Step 1: Validate
        val_result = handle_validate({"recipe": recipe})
        assert val_result["valid"] is True

        # Step 2: Solve
        solve_result = handle_solve({"recipe": recipe})
        assert solve_result["success"] is True
        assert "seat" in solve_result["positions"]

        # Step 3: Verify the anchor (seat)
        seat_pos = solve_result["positions"]["seat"]
        verify_result = handle_verify(
            {
                "object_name": "seat",
                "object_data": {
                    "location": seat_pos["location"],
                    "dimensions": seat_pos["dimensions"],
                    "scale": [1.0, 1.0, 1.0],
                    "vertex_count": 8,
                    "face_count": 6,
                    "has_ngons": False,
                    "has_non_manifold": False,
                    "has_loose_vertices": False,
                    "normals_consistent": True,
                    "collection": "Seat",
                    "neighbors": [],
                },
                "expected": {
                    "location": seat_pos["location"],
                    "dimensions": seat_pos["dimensions"],
                    "collection": "Seat",
                    "neighbors": [],
                },
            }
        )
        assert verify_result["passed"] is True
