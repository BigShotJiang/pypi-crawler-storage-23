"""Tests for the decomposer module."""

from __future__ import annotations

import pytest

from cortex.core.decomposer import decompose, research


# ---------------------------------------------------------------------------
# decompose — template matching
# ---------------------------------------------------------------------------


class TestDecomposeTemplateMatching:
    def test_exact_match_chair(self):
        result = decompose("chair")
        assert result.subject == "chair"
        assert result.total_parts > 0
        assert "seat" in result.hierarchy

    def test_exact_match_table(self):
        result = decompose("table")
        assert "tabletop" in result.hierarchy
        assert result.total_parts >= 5  # tabletop + 4 legs

    def test_case_insensitive(self):
        result = decompose("Chair")
        assert "seat" in result.hierarchy

    def test_plural_match(self):
        result = decompose("chairs")
        assert "seat" in result.hierarchy

    def test_substring_match(self):
        result = decompose("office chair")
        assert result.total_parts > 0

    def test_unknown_subject_generic(self):
        result = decompose("alien_artifact_xyz")
        assert result.total_parts > 0
        assert len(result.hierarchy) > 0
        # Should have a generic hierarchy
        root_key = "alien_artifact_xyz"
        assert root_key in result.hierarchy


# ---------------------------------------------------------------------------
# decompose — detail levels
# ---------------------------------------------------------------------------


class TestDecomposeDetailLevels:
    def test_basic_fewer_parts(self):
        basic = decompose("chair", detail_level="basic")
        detailed = decompose("chair", detail_level="detailed")
        # basic should have same or fewer parts (depth limited)
        assert basic.total_parts <= detailed.total_parts

    def test_exhaustive_more_parts(self):
        detailed = decompose("chair", detail_level="detailed")
        exhaustive = decompose("chair", detail_level="exhaustive")
        assert exhaustive.total_parts >= detailed.total_parts

    def test_research_required_matches_detail(self):
        result = decompose("chair", detail_level="basic")
        for item in result.research_required:
            assert "dimensions" in item.needed


# ---------------------------------------------------------------------------
# decompose — variants
# ---------------------------------------------------------------------------


class TestDecomposeVariants:
    def test_gaming_variant_adds_parts(self):
        base = decompose("chair")
        gaming = decompose("chair", variant="gaming")
        assert gaming.total_parts >= base.total_parts

    def test_unknown_variant_no_crash(self):
        result = decompose("chair", variant="steampunk")
        assert result.total_parts > 0


# ---------------------------------------------------------------------------
# decompose — scene scope
# ---------------------------------------------------------------------------


class TestDecomposeScene:
    def test_scene_scope(self):
        result = decompose("office", scope="scene")
        assert result.total_parts > 0
        assert "ground_plane" in result.hierarchy

    def test_scene_build_order(self):
        result = decompose("office", scope="scene")
        assert len(result.build_order) == result.total_parts


# ---------------------------------------------------------------------------
# decompose — build order
# ---------------------------------------------------------------------------


class TestDecomposeBuildOrder:
    def test_build_order_is_topological(self):
        result = decompose("chair")
        order = result.build_order
        seen: set[str] = set()
        for name in order:
            node = result.hierarchy[name]
            if node.parent is not None and node.parent in result.hierarchy:
                assert node.parent in seen, f"{node.parent} should appear before {name}"
            seen.add(name)

    def test_build_order_covers_all_parts(self):
        result = decompose("table")
        assert set(result.build_order) == set(result.hierarchy.keys())


# ---------------------------------------------------------------------------
# research — completeness checking
# ---------------------------------------------------------------------------


class TestResearchCompleteness:
    def test_empty_data_not_complete(self):
        hierarchy = {"seat": {}, "backrest": {}}
        result = research(hierarchy, filled_data=None)
        assert result.complete is False
        assert result.ready_for_recipe is False
        assert len(result.missing) > 0

    def test_all_data_provided(self):
        hierarchy = {"seat": {}, "leg": {}}
        filled = {
            "seat": {
                "dimensions": {"w": 0.5, "d": 0.5, "h": 0.05},
                "material": "wood",
                "thickness": 0.05,
            },
            "leg": {
                "dimensions": {"w": 0.05, "d": 0.05, "h": 0.4},
                "material": "metal",
                "thickness": 0.003,
            },
        }
        result = research(hierarchy, filled_data=filled)
        assert result.complete is True
        assert result.ready_for_recipe is True

    def test_partial_data_dims_only(self):
        hierarchy = {"seat": {}}
        filled = {
            "seat": {"dimensions": {"w": 0.5, "d": 0.5, "h": 0.05}},
        }
        result = research(hierarchy, filled_data=filled)
        # Has dimensions but missing material/thickness
        assert result.ready_for_recipe is True  # dims are enough
        assert result.complete is False  # material/thickness missing

    def test_missing_one_dim_axis(self):
        hierarchy = {"part": {}}
        filled = {
            "part": {
                "dimensions": {"w": 0.5, "d": 0.5},
                "material": "wood",
                "thickness": 0.01,
            },
        }
        result = research(hierarchy, filled_data=filled)
        assert result.ready_for_recipe is False  # missing height


# ---------------------------------------------------------------------------
# research — sanity checks
# ---------------------------------------------------------------------------


class TestResearchSanity:
    def test_dimension_out_of_range_warning(self):
        hierarchy = {"seat": {}}
        filled = {
            "seat": {
                "dimensions": {"w": 50.0, "d": 0.5, "h": 0.05},
                "material": "wood",
                "thickness": 0.05,
            },
        }
        result = research(hierarchy, filled_data=filled)
        # 50m width for furniture should trigger a warning
        assert len(result.warnings) > 0
        assert any("outside expected range" in w.concern for w in result.warnings)

    def test_zero_dimension_warning(self):
        hierarchy = {"part": {}}
        filled = {
            "part": {
                "dimensions": {"w": 0, "d": 0.5, "h": 0.5},
                "material": "x",
                "thickness": 0.01,
            },
        }
        result = research(hierarchy, filled_data=filled)
        assert any("positive" in w.concern for w in result.warnings)

    def test_electronics_range(self):
        hierarchy = {"chip": {}}
        filled = {
            "chip": {
                "dimensions": {"w": 0.02, "d": 0.02, "h": 0.005},
                "material": "silicon",
                "thickness": 0.001,
            },
        }
        result = research(hierarchy, filled_data=filled)
        # Should fit electronics range — no out-of-range warnings
        range_warnings = [
            w for w in result.warnings if "outside expected range" in w.concern
        ]
        assert len(range_warnings) == 0
