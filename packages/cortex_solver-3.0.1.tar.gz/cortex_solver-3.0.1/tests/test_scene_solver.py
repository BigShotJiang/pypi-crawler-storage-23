import math

import pytest

from cortex.core.scene_solver import solve_scene
from cortex.types import (
    Dimensions,
    PartSpec,
    SceneConstraint,
    SceneConstraintType,
    SceneRecipe,
)


def make_part(name: str, dims=(1.0, 1.0, 1.0)) -> PartSpec:
    return PartSpec(name=name, dimensions=Dimensions(*dims))


def make_recipe(
    *,
    objects: dict[str, PartSpec],
    constraints: list[SceneConstraint] | None = None,
    zones: dict[str, dict] | None = None,
) -> SceneRecipe:
    if constraints is None:
        constraints = []
    if zones is None:
        zones = {}
    return SceneRecipe(
        name="Scene",
        bounds={"min": [0.0, 0.0, 0.0], "max": [10.0, 10.0, 10.0]},
        objects=objects,
        zones=zones,
        constraints=constraints,
    )


def _location(result, name: str):
    return result.positions[name]["location"]


def _rotation(result, name: str):
    return result.positions[name]["rotation"]


def test_grid_placement():
    objects = {name: make_part(name) for name in ["A", "B", "C", "D"]}
    constraints = [
        SceneConstraint(
            type=SceneConstraintType.GRID,
            object=["A", "B", "C", "D"],
            params={
                "origin": [0.0, 0.0, 0.0],
                "rows": 2,
                "cols": 2,
                "spacing_x": 1.0,
                "spacing_y": 2.0,
            },
        )
    ]
    result = solve_scene(make_recipe(objects=objects, constraints=constraints))
    assert _location(result, "A") == pytest.approx([0.0, 0.0, 0.0])
    assert _location(result, "B") == pytest.approx([1.0, 0.0, 0.0])
    assert _location(result, "C") == pytest.approx([0.0, 2.0, 0.0])
    assert _location(result, "D") == pytest.approx([1.0, 2.0, 0.0])


def test_along_path_simple():
    objects = {name: make_part(name) for name in ["A", "B", "C"]}
    constraints = [
        SceneConstraint(
            type=SceneConstraintType.ALONG_PATH,
            object=["A", "B", "C"],
            params={"start": [0.0, 0.0, 0.0], "end": [2.0, 0.0, 0.0], "spacing": 1.0},
        )
    ]
    result = solve_scene(make_recipe(objects=objects, constraints=constraints))
    assert _location(result, "A") == pytest.approx([0.0, 0.0, 0.0])
    assert _location(result, "B") == pytest.approx([1.0, 0.0, 0.0])
    assert _location(result, "C") == pytest.approx([2.0, 0.0, 0.0])


def test_along_path_with_offset():
    objects = {name: make_part(name) for name in ["A", "B", "C"]}
    constraints = [
        SceneConstraint(
            type=SceneConstraintType.ALONG_PATH,
            object=["A", "B", "C"],
            params={
                "start": [0.0, 0.0, 0.0],
                "end": [2.0, 0.0, 0.0],
                "spacing": 1.0,
                "offset_lateral": 1.5,
            },
        )
    ]
    result = solve_scene(make_recipe(objects=objects, constraints=constraints))
    assert _location(result, "A") == pytest.approx([0.0, 1.5, 0.0])
    assert _location(result, "B") == pytest.approx([1.0, 1.5, 0.0])
    assert _location(result, "C") == pytest.approx([2.0, 1.5, 0.0])


def test_radial_placement():
    objects = {name: make_part(name) for name in ["A", "B", "C", "D"]}
    constraints = [
        SceneConstraint(
            type=SceneConstraintType.RADIAL,
            object=["A", "B", "C", "D"],
            params={"center": [0.0, 0.0, 0.0], "radius": 2.0, "count": 4},
        )
    ]
    result = solve_scene(make_recipe(objects=objects, constraints=constraints))
    assert _location(result, "A") == pytest.approx([2.0, 0.0, 0.0])
    assert _location(result, "B") == pytest.approx([0.0, 2.0, 0.0])
    assert _location(result, "C") == pytest.approx([-2.0, 0.0, 0.0])
    assert _location(result, "D") == pytest.approx([0.0, -2.0, 0.0])


def test_radial_facing_center():
    objects = {name: make_part(name) for name in ["A", "B", "C", "D"]}
    constraints = [
        SceneConstraint(
            type=SceneConstraintType.RADIAL,
            object=["A", "B", "C", "D"],
            params={
                "center": [0.0, 0.0, 0.0],
                "radius": 2.0,
                "count": 4,
                "face_center": True,
            },
        )
    ]
    result = solve_scene(make_recipe(objects=objects, constraints=constraints))
    assert _rotation(result, "A")[2] == pytest.approx(180.0)
    assert _rotation(result, "B")[2] == pytest.approx(-90.0)
    assert _rotation(result, "C")[2] == pytest.approx(0.0)
    assert _rotation(result, "D")[2] == pytest.approx(90.0)


def test_facing_constraint():
    objects = {name: make_part(name) for name in ["A", "B"]}
    constraints = [
        SceneConstraint(
            type=SceneConstraintType.GRID,
            object=["A", "B"],
            params={
                "origin": [0.0, 0.0, 0.0],
                "rows": 1,
                "cols": 2,
                "spacing_x": 2.0,
                "spacing_y": 0.0,
            },
        ),
        SceneConstraint(
            type=SceneConstraintType.FACING,
            object="A",
            params={"target": "B"},
        ),
    ]
    result = solve_scene(make_recipe(objects=objects, constraints=constraints))
    assert _rotation(result, "A")[2] == pytest.approx(0.0)


def test_distance_warning():
    objects = {name: make_part(name) for name in ["A", "B"]}
    constraints = [
        SceneConstraint(
            type=SceneConstraintType.GRID,
            object=["A", "B"],
            params={
                "origin": [0.0, 0.0, 0.0],
                "rows": 1,
                "cols": 2,
                "spacing_x": 0.4,
                "spacing_y": 0.0,
            },
        ),
        SceneConstraint(
            type=SceneConstraintType.DISTANCE,
            object=["A", "B"],
            params={"min_distance": 1.0},
        ),
    ]
    result = solve_scene(make_recipe(objects=objects, constraints=constraints))
    assert any("DISTANCE constraint violated" in warning for warning in result.warnings)


def test_against_edge_north():
    objects = {"A": make_part("A")}
    zones = {
        "main": {"bounds": {"min": [0.0, 0.0, 0.0], "max": [10.0, 5.0, 0.0]}},
    }
    constraints = [
        SceneConstraint(
            type=SceneConstraintType.AGAINST_EDGE,
            object="A",
            params={"edge": "north", "zone": "main", "position_along": 0.5},
        )
    ]
    result = solve_scene(
        make_recipe(objects=objects, constraints=constraints, zones=zones)
    )
    assert _location(result, "A") == pytest.approx([5.0, 5.0, 0.0])


def test_against_edge_east():
    objects = {"A": make_part("A")}
    zones = {
        "main": {"bounds": {"min": [0.0, 0.0, 0.0], "max": [10.0, 5.0, 0.0]}},
    }
    constraints = [
        SceneConstraint(
            type=SceneConstraintType.AGAINST_EDGE,
            object="A",
            params={"edge": "east", "zone": "main", "position_along": 0.2},
        )
    ]
    result = solve_scene(
        make_recipe(objects=objects, constraints=constraints, zones=zones)
    )
    assert _location(result, "A") == pytest.approx([10.0, 1.0, 0.0])


def test_random_scatter_deterministic():
    objects = {name: make_part(name) for name in ["A", "B", "C"]}
    zones = {
        "main": {"bounds": {"min": [0.0, 0.0, 0.0], "max": [1.0, 1.0, 0.0]}},
    }
    constraints = [
        SceneConstraint(
            type=SceneConstraintType.RANDOM_SCATTER,
            object=["A", "B", "C"],
            params={"zone": "main", "seed": 42},
        )
    ]
    result_a = solve_scene(
        make_recipe(objects=objects, constraints=constraints, zones=zones)
    )
    result_b = solve_scene(
        make_recipe(objects=objects, constraints=constraints, zones=zones)
    )
    assert _location(result_a, "A") == pytest.approx(_location(result_b, "A"))
    assert _location(result_a, "B") == pytest.approx(_location(result_b, "B"))
    assert _location(result_a, "C") == pytest.approx(_location(result_b, "C"))


def test_stack_vertical():
    objects = {
        "A": make_part("A", dims=(1.0, 1.0, 2.0)),
        "B": make_part("B", dims=(1.0, 1.0, 1.0)),
        "C": make_part("C", dims=(1.0, 1.0, 3.0)),
    }
    constraints = [
        SceneConstraint(
            type=SceneConstraintType.STACK_VERTICAL,
            object=["A", "B", "C"],
            params={"base_position": [0.0, 0.0, 0.0], "gap": 0.5},
        )
    ]
    result = solve_scene(make_recipe(objects=objects, constraints=constraints))
    assert _location(result, "A") == pytest.approx([0.0, 0.0, 0.0])
    assert _location(result, "B") == pytest.approx([0.0, 0.0, 2.0])
    assert _location(result, "C") == pytest.approx([0.0, 0.0, 4.5])


def test_mirror_scene():
    objects = {"A": make_part("A")}
    constraints = [
        SceneConstraint(
            type=SceneConstraintType.GRID,
            object="A",
            params={
                "origin": [1.0, 0.0, 0.0],
                "rows": 1,
                "cols": 1,
                "spacing_x": 0.0,
                "spacing_y": 0.0,
            },
        ),
        SceneConstraint(
            type=SceneConstraintType.MIRROR_SCENE,
            object="A",
            params={"axis": "x", "center": 0.0},
        ),
    ]
    result = solve_scene(make_recipe(objects=objects, constraints=constraints))
    assert _location(result, "A") == pytest.approx([1.0, 0.0, 0.0])
    assert _location(result, "A_mirrored") == pytest.approx([-1.0, 0.0, 0.0])


def test_empty_scene():
    objects = {"A": make_part("A"), "B": make_part("B")}
    result = solve_scene(make_recipe(objects=objects, constraints=[]))
    assert _location(result, "A") == pytest.approx([0.0, 0.0, 0.0])
    assert _location(result, "B") == pytest.approx([0.0, 0.0, 0.0])


def test_multiple_constraints():
    objects = {"A": make_part("A"), "B": make_part("B"), "C": make_part("C")}
    zones = {"main": {"bounds": {"min": [0.0, 0.0, 0.0], "max": [2.0, 2.0, 0.0]}}}
    constraints = [
        SceneConstraint(
            type=SceneConstraintType.GRID,
            object=["A", "B", "C"],
            params={
                "origin": [0.0, 0.0, 0.0],
                "rows": 1,
                "cols": 3,
                "spacing_x": 1.0,
                "spacing_y": 0.0,
            },
        ),
        SceneConstraint(
            type=SceneConstraintType.FACING,
            object="B",
            params={"target": "A"},
        ),
        SceneConstraint(
            type=SceneConstraintType.AGAINST_EDGE,
            object="C",
            params={"edge": "north", "zone": "main", "position_along": 1.0},
        ),
    ]
    result = solve_scene(
        make_recipe(objects=objects, constraints=constraints, zones=zones)
    )
    assert _location(result, "A") == pytest.approx([0.0, 0.0, 0.0])
    assert _location(result, "B") == pytest.approx([1.0, 0.0, 0.0])
    assert _rotation(result, "B")[2] == pytest.approx(180.0)
    assert _location(result, "C") == pytest.approx([2.0, 2.0, 0.0])


def test_single_object():
    objects = {"A": make_part("A")}
    result = solve_scene(make_recipe(objects=objects, constraints=[]))
    assert _location(result, "A") == pytest.approx([0.0, 0.0, 0.0])
