import pytest

from cortex.core.solver import solve
from cortex.types import Constraint, Dimensions, Mirror, PartRecipe, PartSpec


def make_dimensions(width=2.0, depth=2.0, height=2.0):
    return Dimensions(width=width, depth=depth, height=height)


def make_part(name, width=2.0, depth=2.0, height=2.0):
    return PartSpec(name=name, dimensions=make_dimensions(width, depth, height))


def make_recipe(
    anchor="anchor",
    parts=None,
    constraints=None,
    mirrors=None,
    anchor_position=None,
    name="test-recipe",
):
    parts = {} if parts is None else dict(parts)
    if anchor not in parts:
        parts[anchor] = make_part(anchor)
    constraints = [] if constraints is None else list(constraints)
    mirrors = [] if mirrors is None else list(mirrors)
    anchor_position = (
        [0.0, 0.0, 0.0] if anchor_position is None else list(anchor_position)
    )
    return PartRecipe(
        name=name,
        anchor=anchor,
        anchor_position=anchor_position,
        parts=parts,
        constraints=constraints,
        mirrors=mirrors,
    )


def assert_location(result, part_name, expected):
    assert result.positions[part_name]["location"] == pytest.approx(expected)


# Group 1: Individual Constraints (8 tests)


def test_stacked_top():
    parts = {"anchor": make_part("anchor"), "part": make_part("part")}
    constraints = [
        Constraint(
            type="STACKED",
            part_a="part",
            part_b="anchor",
            axis="Z",
            reference="top",
        )
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.0, 0.0, 2.0])


def test_stacked_bottom():
    parts = {"anchor": make_part("anchor"), "part": make_part("part")}
    constraints = [
        Constraint(
            type="STACKED",
            part_a="part",
            part_b="anchor",
            axis="Z",
            reference="bottom",
        )
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.0, 0.0, -2.0])


def test_centered():
    parts = {"anchor": make_part("anchor"), "part": make_part("part")}
    constraints = [
        Constraint(
            type="CENTERED",
            part_a="part",
            part_b="anchor",
            axis="X",
        )
    ]
    recipe = make_recipe(
        parts=parts,
        constraints=constraints,
        anchor_position=[1.0, -1.0, 0.5],
    )

    result = solve(recipe)

    assert_location(result, "part", [1.0, -1.0, 0.5])


def test_flush_positive():
    parts = {
        "anchor": make_part("anchor", width=2.0, depth=2.0, height=2.0),
        "part": make_part("part", width=1.0, depth=1.0, height=1.0),
    }
    constraints = [
        Constraint(
            type="FLUSH",
            part_a="part",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
        )
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.5, 0.0, 0.0])


def test_flush_negative():
    parts = {
        "anchor": make_part("anchor", width=2.0, depth=2.0, height=2.0),
        "part": make_part("part", width=1.0, depth=1.0, height=1.0),
    }
    constraints = [
        Constraint(
            type="FLUSH",
            part_a="part",
            part_b="anchor",
            axis="Y",
            face_a="-",
            face_b="-",
        )
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.0, -0.5, 0.0])


def test_offset():
    parts = {
        "anchor": make_part("anchor", width=2.0, depth=2.0, height=2.0),
        "part": make_part("part", width=1.0, depth=1.0, height=1.0),
    }
    constraints = [
        Constraint(
            type="OFFSET",
            part_a="part",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
            offset=0.25,
        )
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.75, 0.0, 0.0])


def test_coaxial():
    parts = {
        "anchor": make_part("anchor"),
        "source": make_part("source"),
        "part": make_part("part"),
    }
    constraints = [
        Constraint(
            type="OFFSET",
            part_a="source",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
            offset=1.0,
        ),
        Constraint(
            type="OFFSET",
            part_a="source",
            part_b="anchor",
            axis="Y",
            face_a="+",
            face_b="+",
            offset=2.0,
        ),
        Constraint(
            type="COAXIAL",
            part_a="part",
            part_b="source",
            axis="Z",
        ),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [1.0, 2.0, 0.0])


def test_symmetric():
    parts = {
        "anchor": make_part("anchor"),
        "source": make_part("source"),
        "part": make_part("part"),
    }
    constraints = [
        Constraint(
            type="OFFSET",
            part_a="source",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
            offset=2.0,
        ),
        Constraint(
            type="OFFSET",
            part_a="source",
            part_b="anchor",
            axis="Y",
            face_a="+",
            face_b="+",
            offset=1.0,
        ),
        Constraint(
            type="OFFSET",
            part_a="source",
            part_b="anchor",
            axis="Z",
            face_a="+",
            face_b="+",
            offset=-1.0,
        ),
        Constraint(
            type="SYMMETRIC",
            part_a="part",
            part_b="source",
            axis="X",
        ),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [-2.0, 1.0, -1.0])


# Group 2: Multi-Constraint Combinations (10 tests)


def test_two_constraints_xy():
    parts = {"anchor": make_part("anchor"), "part": make_part("part")}
    constraints = [
        Constraint(type="CENTERED", part_a="part", part_b="anchor", axis="X"),
        Constraint(
            type="STACKED",
            part_a="part",
            part_b="anchor",
            axis="Z",
            reference="top",
        ),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.0, 0.0, 2.0])


def test_three_constraints_xyz():
    parts = {"anchor": make_part("anchor"), "part": make_part("part")}
    constraints = [
        Constraint(type="CENTERED", part_a="part", part_b="anchor", axis="X"),
        Constraint(
            type="FLUSH",
            part_a="part",
            part_b="anchor",
            axis="Y",
            face_a="-",
            face_b="+",
        ),
        Constraint(
            type="STACKED",
            part_a="part",
            part_b="anchor",
            axis="Z",
            reference="top",
        ),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.0, 2.0, 2.0])


def test_chain_three_parts():
    parts = {
        "anchor": make_part("anchor"),
        "part_b": make_part("part_b"),
        "part_c": make_part("part_c"),
    }
    constraints = [
        Constraint(
            type="STACKED",
            part_a="part_b",
            part_b="anchor",
            axis="Z",
            reference="top",
        ),
        Constraint(
            type="STACKED",
            part_a="part_c",
            part_b="part_b",
            axis="Z",
            reference="top",
        ),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part_b", [0.0, 0.0, 2.0])
    assert_location(result, "part_c", [0.0, 0.0, 4.0])


def test_chain_five_parts():
    parts = {"anchor": make_part("anchor")}
    constraints = []
    previous = "anchor"
    for idx in range(1, 6):
        name = f"part_{idx}"
        parts[name] = make_part(name)
        constraints.append(
            Constraint(
                type="STACKED",
                part_a=name,
                part_b=previous,
                axis="Z",
                reference="top",
            )
        )
        previous = name
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part_5", [0.0, 0.0, 10.0])


def test_fan_from_anchor():
    parts = {
        "anchor": make_part("anchor"),
        "top": make_part("top"),
        "bottom": make_part("bottom"),
        "right": make_part("right", width=1.0, depth=1.0, height=1.0),
        "left": make_part("left", width=1.0, depth=1.0, height=1.0),
    }
    constraints = [
        Constraint(
            type="STACKED",
            part_a="top",
            part_b="anchor",
            axis="Z",
            reference="top",
        ),
        Constraint(
            type="STACKED",
            part_a="bottom",
            part_b="anchor",
            axis="Z",
            reference="bottom",
        ),
        Constraint(
            type="FLUSH",
            part_a="right",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
        ),
        Constraint(
            type="FLUSH",
            part_a="left",
            part_b="anchor",
            axis="Y",
            face_a="-",
            face_b="-",
        ),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "top", [0.0, 0.0, 2.0])
    assert_location(result, "bottom", [0.0, 0.0, -2.0])
    assert_location(result, "right", [0.5, 0.0, 0.0])
    assert_location(result, "left", [0.0, -0.5, 0.0])


def test_mixed_flush_and_centered():
    parts = {
        "anchor": make_part("anchor"),
        "part": make_part("part", width=1.0, depth=1.0, height=1.0),
    }
    constraints = [
        Constraint(
            type="FLUSH",
            part_a="part",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
        ),
        Constraint(
            type="CENTERED",
            part_a="part",
            part_b="anchor",
            axis="Y",
        ),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.5, 0.0, 0.0])


def test_inside_and_stacked():
    parts = {"anchor": make_part("anchor"), "part": make_part("part")}
    constraints = [
        Constraint(type="INSIDE", part_a="part", part_b="anchor", axis="X"),
        Constraint(
            type="STACKED",
            part_a="part",
            part_b="anchor",
            axis="Z",
            reference="top",
        ),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.0, 0.0, 2.0])


def test_aligned_and_offset():
    parts = {"anchor": make_part("anchor"), "part": make_part("part")}
    constraints = [
        Constraint(type="ALIGNED", part_a="part", part_b="anchor", axis="Y"),
        Constraint(
            type="OFFSET",
            part_a="part",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
            offset=0.5,
        ),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.5, 0.0, 0.0])


def test_complex_10_parts():
    parts = {"anchor": make_part("anchor", width=2.0, depth=2.0, height=2.0)}
    for name in ["b", "c", "d", "e", "f", "g", "h", "i", "j"]:
        parts[name] = make_part(name, width=1.0, depth=1.0, height=1.0)
    constraints = [
        Constraint(
            type="STACKED",
            part_a="b",
            part_b="anchor",
            axis="Z",
            reference="top",
        ),
        Constraint(
            type="STACKED",
            part_a="c",
            part_b="anchor",
            axis="Z",
            reference="bottom",
        ),
        Constraint(
            type="FLUSH",
            part_a="d",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
        ),
        Constraint(
            type="FLUSH",
            part_a="e",
            part_b="anchor",
            axis="Y",
            face_a="-",
            face_b="-",
        ),
        Constraint(
            type="OFFSET",
            part_a="f",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
            offset=1.0,
        ),
        Constraint(
            type="COAXIAL",
            part_a="g",
            part_b="d",
            axis="Z",
        ),
        Constraint(
            type="INSIDE",
            part_a="h",
            part_b="e",
            axis="Y",
        ),
        Constraint(
            type="ALIGNED",
            part_a="i",
            part_b="b",
            axis="Z",
        ),
        Constraint(
            type="SYMMETRIC",
            part_a="j",
            part_b="d",
            axis="X",
        ),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "b", [0.0, 0.0, 1.5])
    assert_location(result, "c", [0.0, 0.0, -1.5])
    assert_location(result, "d", [0.5, 0.0, 0.0])
    assert_location(result, "e", [0.0, -0.5, 0.0])
    assert_location(result, "f", [1.5, 0.0, 0.0])
    assert_location(result, "g", [0.5, 0.0, 0.0])
    assert_location(result, "h", [0.0, -0.5, 0.0])
    assert_location(result, "i", [0.0, 0.0, 1.5])
    assert_location(result, "j", [-0.5, 0.0, 0.0])


def test_stress_50_parts():
    parts = {"anchor": make_part("anchor", width=2.0, depth=2.0, height=2.0)}
    constraints = []
    previous = "anchor"
    for idx in range(1, 51):
        name = f"part_{idx}"
        parts[name] = make_part(name, width=1.0, depth=1.0, height=1.0)
        constraints.append(
            Constraint(
                type="STACKED",
                part_a=name,
                part_b=previous,
                axis="Z",
                reference="top",
            )
        )
        previous = name
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part_1", [0.0, 0.0, 1.5])
    assert_location(result, "part_50", [0.0, 0.0, 50.5])


# Group 3: Mirror Tests (5 tests)


def test_single_mirror_x():
    parts = {
        "anchor": make_part("anchor"),
        "source": make_part("source", width=1.0, depth=1.0, height=1.0),
        "mirror": make_part("mirror", width=1.0, depth=1.0, height=1.0),
    }
    constraints = [
        Constraint(
            type="OFFSET",
            part_a="source",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
            offset=1.5,
        )
    ]
    mirrors = [Mirror(source="source", target="mirror", axis="X")]
    recipe = make_recipe(parts=parts, constraints=constraints, mirrors=mirrors)

    result = solve(recipe)

    assert_location(result, "source", [2.0, 0.0, 0.0])
    assert_location(result, "mirror", [-2.0, 0.0, 0.0])


def test_single_mirror_y():
    parts = {
        "anchor": make_part("anchor"),
        "source": make_part("source", width=1.0, depth=1.0, height=1.0),
        "mirror": make_part("mirror", width=1.0, depth=1.0, height=1.0),
    }
    constraints = [
        Constraint(
            type="OFFSET",
            part_a="source",
            part_b="anchor",
            axis="Y",
            face_a="+",
            face_b="+",
            offset=1.0,
        )
    ]
    mirrors = [Mirror(source="source", target="mirror", axis="Y")]
    recipe = make_recipe(parts=parts, constraints=constraints, mirrors=mirrors)

    result = solve(recipe)

    assert_location(result, "source", [0.0, 1.5, 0.0])
    assert_location(result, "mirror", [0.0, -1.5, 0.0])


def test_multiple_mirrors():
    parts = {
        "anchor": make_part("anchor"),
        "source_x": make_part("source_x", width=1.0, depth=1.0, height=1.0),
        "source_y": make_part("source_y", width=1.0, depth=1.0, height=1.0),
        "source_z": make_part("source_z", width=1.0, depth=1.0, height=1.0),
        "mirror_x": make_part("mirror_x", width=1.0, depth=1.0, height=1.0),
        "mirror_y": make_part("mirror_y", width=1.0, depth=1.0, height=1.0),
        "mirror_z": make_part("mirror_z", width=1.0, depth=1.0, height=1.0),
    }
    constraints = [
        Constraint(
            type="OFFSET",
            part_a="source_x",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
            offset=1.5,
        ),
        Constraint(
            type="OFFSET",
            part_a="source_y",
            part_b="anchor",
            axis="Y",
            face_a="+",
            face_b="+",
            offset=1.0,
        ),
        Constraint(
            type="STACKED",
            part_a="source_z",
            part_b="anchor",
            axis="Z",
            reference="top",
        ),
    ]
    mirrors = [
        Mirror(source="source_x", target="mirror_x", axis="X"),
        Mirror(source="source_y", target="mirror_y", axis="Y"),
        Mirror(source="source_z", target="mirror_z", axis="Z"),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints, mirrors=mirrors)

    result = solve(recipe)

    assert_location(result, "mirror_x", [-2.0, 0.0, 0.0])
    assert_location(result, "mirror_y", [0.0, -1.5, 0.0])
    assert_location(result, "mirror_z", [0.0, 0.0, -1.5])


def test_mirror_chain():
    parts = {
        "anchor": make_part("anchor"),
        "source": make_part("source", width=1.0, depth=1.0, height=1.0),
        "mirror": make_part("mirror", width=1.0, depth=1.0, height=1.0),
    }
    constraints = [
        Constraint(
            type="OFFSET",
            part_a="source",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
            offset=1.5,
        )
    ]
    mirrors = [Mirror(source="source", target="mirror", axis="X")]
    recipe = make_recipe(parts=parts, constraints=constraints, mirrors=mirrors)

    result = solve(recipe)

    assert_location(result, "source", [2.0, 0.0, 0.0])
    assert_location(result, "mirror", [-2.0, 0.0, 0.0])


def test_mirror_preserves_dimensions():
    parts = {
        "anchor": make_part("anchor"),
        "source": make_part("source", width=1.0, depth=2.0, height=3.0),
        "mirror": make_part("mirror", width=1.0, depth=2.0, height=3.0),
    }
    constraints = [
        Constraint(
            type="STACKED",
            part_a="source",
            part_b="anchor",
            axis="Z",
            reference="top",
        )
    ]
    mirrors = [Mirror(source="source", target="mirror", axis="Z")]
    recipe = make_recipe(parts=parts, constraints=constraints, mirrors=mirrors)

    result = solve(recipe)

    assert result.positions["mirror"]["dimensions"] == pytest.approx([1.0, 2.0, 3.0])


# Group 4: Conflict Detection (5 tests)


def test_no_conflicts():
    parts = {"anchor": make_part("anchor"), "part": make_part("part")}
    constraints = [
        Constraint(type="CENTERED", part_a="part", part_b="anchor", axis="X")
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.0, 0.0, 0.0])
    assert result.conflicts == []


def test_single_conflict():
    parts = {"anchor": make_part("anchor"), "part": make_part("part")}
    constraints = [
        Constraint(
            type="STACKED",
            part_a="part",
            part_b="anchor",
            axis="Z",
            reference="top",
        ),
        Constraint(
            type="STACKED",
            part_a="part",
            part_b="anchor",
            axis="Z",
            reference="bottom",
        ),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.0, 0.0, 2.0])
    assert len(result.conflicts) == 1
    assert result.conflicts[0]["axis"] == 2


def test_conflict_uses_first_value():
    parts = {
        "anchor": make_part("anchor"),
        "part": make_part("part", width=1.0, depth=1.0, height=1.0),
    }
    constraints = [
        Constraint(
            type="FLUSH",
            part_a="part",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
        ),
        Constraint(
            type="OFFSET",
            part_a="part",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
            offset=1.0,
        ),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.5, 0.0, 0.0])
    assert result.conflicts[0]["value"] == pytest.approx(0.5)
    assert result.conflicts[0]["conflict"] == pytest.approx(1.5)


def test_multiple_conflicts():
    parts = {
        "anchor": make_part("anchor"),
        "part": make_part("part", width=1.0, depth=1.0, height=1.0),
    }
    constraints = [
        Constraint(type="CENTERED", part_a="part", part_b="anchor", axis="X"),
        Constraint(
            type="OFFSET",
            part_a="part",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
            offset=1.0,
        ),
        Constraint(type="CENTERED", part_a="part", part_b="anchor", axis="Y"),
        Constraint(
            type="OFFSET",
            part_a="part",
            part_b="anchor",
            axis="Y",
            face_a="+",
            face_b="+",
            offset=1.0,
        ),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.0, 0.0, 0.0])
    assert {conflict["axis"] for conflict in result.conflicts} == {0, 1}


def test_near_miss_no_conflict():
    parts = {"anchor": make_part("anchor"), "part": make_part("part")}
    constraints = [
        Constraint(
            type="OFFSET",
            part_a="part",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
            offset=0.0,
        ),
        Constraint(
            type="OFFSET",
            part_a="part",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
            offset=0.00005,
        ),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.0, 0.0, 0.0])
    assert result.conflicts == []


# Group 5: Cycle Detection (4 tests)


def test_no_cycle():
    parts = {
        "anchor": make_part("anchor"),
        "part_b": make_part("part_b"),
        "part_c": make_part("part_c"),
    }
    constraints = [
        Constraint(
            type="STACKED",
            part_a="part_b",
            part_b="anchor",
            axis="Z",
            reference="top",
        ),
        Constraint(
            type="STACKED",
            part_a="part_c",
            part_b="part_b",
            axis="Z",
            reference="top",
        ),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert result.success is True
    assert_location(result, "part_c", [0.0, 0.0, 4.0])


def test_simple_cycle():
    parts = {"anchor": make_part("anchor"), "part": make_part("part")}
    constraints = [
        Constraint(type="CENTERED", part_a="anchor", part_b="part", axis="X"),
        Constraint(type="CENTERED", part_a="part", part_b="anchor", axis="X"),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert result.success is False
    assert result.error == "Circular dependency detected in recipe constraints."


def test_three_part_cycle():
    parts = {
        "anchor": make_part("anchor"),
        "part_b": make_part("part_b"),
        "part_c": make_part("part_c"),
    }
    constraints = [
        Constraint(type="CENTERED", part_a="anchor", part_b="part_b", axis="X"),
        Constraint(type="CENTERED", part_a="part_b", part_b="part_c", axis="X"),
        Constraint(type="CENTERED", part_a="part_c", part_b="anchor", axis="X"),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert result.success is False
    assert result.error == "Circular dependency detected in recipe constraints."


def test_cycle_with_valid_parts():
    parts = {
        "anchor": make_part("anchor"),
        "valid": make_part("valid"),
        "cycle_a": make_part("cycle_a"),
        "cycle_b": make_part("cycle_b"),
    }
    constraints = [
        Constraint(type="CENTERED", part_a="valid", part_b="anchor", axis="X"),
        Constraint(type="CENTERED", part_a="cycle_a", part_b="cycle_b", axis="X"),
        Constraint(type="CENTERED", part_a="cycle_b", part_b="cycle_a", axis="X"),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert result.success is False
    assert result.build_order == ["anchor", "valid"]


# Group 6: Edge Cases (5 tests)


def test_empty_constraints():
    parts = {"anchor": make_part("anchor"), "part": make_part("part")}
    recipe = make_recipe(parts=parts, anchor_position=[1.0, 2.0, 3.0])

    result = solve(recipe)

    assert_location(result, "part", [1.0, 2.0, 3.0])


def test_single_part():
    recipe = make_recipe(parts={"anchor": make_part("anchor")})

    result = solve(recipe)

    assert result.success is True
    assert result.positions["anchor"]["location"] == pytest.approx([0.0, 0.0, 0.0])


def test_zero_offset():
    parts = {
        "anchor": make_part("anchor"),
        "part": make_part("part", width=1.0, depth=1.0, height=1.0),
    }
    constraints = [
        Constraint(
            type="OFFSET",
            part_a="part",
            part_b="anchor",
            axis="X",
            face_a="+",
            face_b="+",
            offset=0.0,
        )
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.5, 0.0, 0.0])


def test_large_dimensions():
    parts = {
        "anchor": make_part("anchor", width=100.0, depth=100.0, height=100.0),
        "part": make_part("part", width=100.0, depth=100.0, height=100.0),
    }
    constraints = [
        Constraint(
            type="STACKED",
            part_a="part",
            part_b="anchor",
            axis="Z",
            reference="top",
        )
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.0, 0.0, 100.0])


def test_tiny_dimensions():
    parts = {
        "anchor": make_part("anchor", width=0.001, depth=0.001, height=0.001),
        "part": make_part("part", width=0.001, depth=0.001, height=0.001),
    }
    constraints = [
        Constraint(
            type="STACKED",
            part_a="part",
            part_b="anchor",
            axis="Z",
            reference="top",
        )
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)

    result = solve(recipe)

    assert_location(result, "part", [0.0, 0.0, 0.001])
