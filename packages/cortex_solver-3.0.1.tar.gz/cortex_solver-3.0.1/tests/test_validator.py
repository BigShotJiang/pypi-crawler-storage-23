import pytest

from cortex.core.validator import validate
from cortex.types import (
    Constraint,
    ConstraintType,
    Dimensions,
    Mirror,
    PartRecipe,
    PartSpec,
)


def make_part(name: str, dims=(1.0, 1.0, 1.0)) -> PartSpec:
    return PartSpec(name=name, dimensions=Dimensions(*dims))


def make_recipe(
    *,
    name="Widget",
    anchor="base",
    anchor_position=None,
    parts=None,
    constraints=None,
    mirrors=None,
) -> PartRecipe:
    if anchor_position is None:
        anchor_position = [0.0, 0.0, 0.0]
    if parts is None:
        parts = {"base": make_part("base")}
    if constraints is None:
        constraints = []
    if mirrors is None:
        mirrors = []
    return PartRecipe(
        name=name,
        anchor=anchor,
        anchor_position=anchor_position,
        parts=parts,
        constraints=constraints,
        mirrors=mirrors,
    )


def _has_error(result, error_type: str) -> bool:
    return any(error.type == error_type for error in result.errors)


def test_valid_simple_recipe():
    recipe = make_recipe()
    result = validate(recipe)
    assert result.valid is True
    assert result.errors == []


def test_missing_name():
    recipe = make_recipe(name="")
    result = validate(recipe)
    assert result.valid is False
    assert _has_error(result, "missing_field")


def test_missing_anchor():
    parts = {"base": make_part("base"), "side": make_part("side")}
    constraints = [
        Constraint(
            type=ConstraintType.CENTERED.value,
            part_a="base",
            part_b="side",
            axis="X",
        )
    ]
    recipe = make_recipe(anchor="missing", parts=parts, constraints=constraints)
    result = validate(recipe)
    assert _has_error(result, "missing_part")
    assert any(error.location == "anchor" for error in result.errors)


def test_missing_anchor_position():
    recipe = make_recipe(anchor_position=["a", 0.0, 0.0])
    result = validate(recipe)
    assert _has_error(result, "type_error")
    assert any(error.location == "anchor_position" for error in result.errors)


def test_constraint_unknown_part():
    parts = {"base": make_part("base")}
    constraints = [
        Constraint(
            type=ConstraintType.CENTERED.value,
            part_a="missing",
            part_b="base",
            axis="X",
        )
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)
    result = validate(recipe)
    assert _has_error(result, "missing_part")
    assert any("part_a" in error.location for error in result.errors)


def test_invalid_constraint_type():
    parts = {"base": make_part("base"), "side": make_part("side")}
    constraints = [Constraint(type="BAD", part_a="base", part_b="side", axis="X")]
    recipe = make_recipe(parts=parts, constraints=constraints)
    result = validate(recipe)
    assert _has_error(result, "invalid_constraint")


def test_invalid_axis():
    parts = {"base": make_part("base"), "side": make_part("side")}
    constraints = [
        Constraint(
            type=ConstraintType.CENTERED.value,
            part_a="base",
            part_b="side",
            axis="Q",
        )
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)
    result = validate(recipe)
    assert _has_error(result, "invalid_constraint")


def test_stacked_missing_reference():
    parts = {"base": make_part("base"), "top": make_part("top")}
    constraints = [
        Constraint(
            type=ConstraintType.STACKED.value,
            part_a="base",
            part_b="top",
            axis="Z",
            reference="",
        )
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)
    result = validate(recipe)
    assert _has_error(result, "invalid_constraint")


def test_flush_missing_faces():
    parts = {"base": make_part("base"), "side": make_part("side")}
    constraints = [
        Constraint(
            type=ConstraintType.FLUSH.value,
            part_a="base",
            part_b="side",
            axis="X",
        )
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)
    result = validate(recipe)
    assert _has_error(result, "invalid_constraint")


def test_orphan_part():
    parts = {"base": make_part("base"), "orphan": make_part("orphan")}
    recipe = make_recipe(parts=parts, constraints=[])
    result = validate(recipe)
    assert _has_error(result, "orphan_part")


def test_circular_dependency():
    parts = {"A": make_part("A"), "B": make_part("B")}
    constraints = [
        Constraint(
            type=ConstraintType.CENTERED.value,
            part_a="A",
            part_b="B",
            axis="X",
        ),
        Constraint(
            type=ConstraintType.CENTERED.value,
            part_a="B",
            part_b="A",
            axis="X",
        ),
    ]
    recipe = make_recipe(anchor="A", parts=parts, constraints=constraints)
    result = validate(recipe)
    assert _has_error(result, "circular_dependency")
    assert any("A -> B -> A" in error.message for error in result.errors)


def test_zero_dimensions():
    parts = {"base": make_part("base", dims=(0.0, 1.0, 1.0))}
    recipe = make_recipe(parts=parts)
    result = validate(recipe)
    assert _has_error(result, "missing_field")
    assert any("dimensions" in error.location for error in result.errors)


def test_mirror_invalid_source():
    parts = {"base": make_part("base"), "right": make_part("right")}
    mirrors = [Mirror(source="left", target="right", axis="X")]
    recipe = make_recipe(parts=parts, mirrors=mirrors)
    result = validate(recipe)
    assert _has_error(result, "missing_part")
    assert any("mirrors" in error.location for error in result.errors)


def test_constraint_conflict_warning():
    parts = {
        "base": make_part("base"),
        "side": make_part("side"),
        "top": make_part("top"),
    }
    constraints = [
        Constraint(
            type=ConstraintType.CENTERED.value,
            part_a="base",
            part_b="side",
            axis="X",
        ),
        Constraint(
            type=ConstraintType.CENTERED.value,
            part_a="base",
            part_b="top",
            axis="X",
        ),
    ]
    recipe = make_recipe(parts=parts, constraints=constraints)
    result = validate(recipe)
    assert result.valid is True
    assert any(warning.type == "constraint_conflict" for warning in result.warnings)


def test_valid_with_mirrors():
    parts = {
        "base": make_part("base"),
        "left": make_part("left"),
        "right": make_part("right"),
    }
    mirrors = [Mirror(source="left", target="right", axis="X")]
    recipe = make_recipe(parts=parts, mirrors=mirrors)
    result = validate(recipe)
    assert result.valid is True
    assert result.errors == []
