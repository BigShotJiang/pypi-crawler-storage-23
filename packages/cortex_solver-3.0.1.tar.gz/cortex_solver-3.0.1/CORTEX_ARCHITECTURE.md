# Cortex — Universal Build Intelligence for LLMs

> Version 3.0.0 — Lean Core
> Methodology enforcer. Not a database. Not engine-specific.

---

## 1. What is Cortex

Cortex is a standalone MCP server that changes HOW an LLM builds things.

Without cortex, an LLM asked to "build a headphone" will:
- Skip parts (forget hinges, screws, cushion rings)
- Guess dimensions (earcup "about 7cm" when it's actually 9cm)
- Miscalculate positions (parts floating, overlapping, misaligned)
- Self-judge quality ("looks good" when it's broken)
- Produce "boxes stacked into a shape"

With cortex, the LLM is **forced** through a methodology:
- Decompose EVERY part before building anything
- Research REAL data before designing
- Validate the plan before executing
- Let a SOLVER calculate exact positions (math, not guessing)
- VERIFY results with code (proof, not judgment)

Cortex doesn't know what a headphone looks like. Cortex doesn't store dimensions. Cortex doesn't build anything. **Cortex makes the LLM do these things correctly.**

Think of it like `sequential-thinking` MCP — that tool doesn't think FOR you, it forces you to think STEP BY STEP. Cortex doesn't build for you, it forces you to build STEP BY STEP WITH PROOF.

### 1.1 What Cortex IS

- A methodology enforced through tools
- A constraint solver (math engine for positioning)
- A verification system (code-based proof, not vibes)
- Universal — works with any engine (Blender, Unity, Roblox, Three.js, Godot, anything)
- Universal — works with any domain (3D models, UI layouts, architecture, game levels, anything assembled from parts in space)

### 1.2 What Cortex is NOT

- Not a knowledge database (LLM has its own knowledge + web search)
- Not a material library (LLM knows materials)
- Not an engine adapter (LLM talks to engines directly via their own MCPs/APIs)
- Not a shape generator (LLM builds geometry in the engine)
- Not limited to 3D (anything with parts + spatial relationships + measurable output)

### 1.3 Where Cortex Works

Cortex works anywhere the task involves **assembling parts in space**:

| Domain | Example |
|--------|---------|
| 3D Modeling | Headphone, furniture, vehicle, building |
| Scene Layout | City block, game level, room interior |
| UI/UX | Dashboard layout, component positioning |
| Architecture | Floor plan, room adjacency |
| Game Design | Level layout, spawn placement, item distribution |
| Hardware | PCB layout, robot assembly |

The pattern: **decomposable into parts** + **parts have spatial relationships** + **result is measurable**.

---

## 2. The Pipeline

Every build follows this exact flow. No shortcuts. No skipping steps.

```
┌─────────┐     ┌──────────┐     ┌──────────┐     ┌───────┐     ┌───────┐     ┌────────┐
│DECOMPOSE│ ──→ │ RESEARCH │ ──→ │ VALIDATE │ ──→ │ SOLVE │ ──→ │ BUILD │ ──→ │ VERIFY │
│ cortex  │     │   LLM    │     │  cortex  │     │cortex │     │  LLM  │     │ cortex │
└─────────┘     └──────────┘     └──────────┘     └───────┘     └───────┘     └────────┘
                                                                      │              │
                                                                      │    ❌ FAIL   │
                                                                      │◄─────────────┘
                                                                      │  fix & rebuild
                                                                      │  ONLY failed part
                                                                      │              │
                                                                      └──→ re-VERIFY─┘
```

### Who does what:

| Step | Who | What happens |
|------|-----|-------------|
| **DECOMPOSE** | Cortex tool | Returns structured hierarchy template. Forces LLM to identify every part, sub-part, connection. |
| **RESEARCH** | Cortex tool → LLM executes | Returns checklist of required data per part. LLM MUST fill in from web search / image search / knowledge. Gate: can't proceed without data. |
| **VALIDATE** | Cortex tool | Checks recipe for structural correctness. Missing fields, invalid constraints, circular deps, referenced parts exist. |
| **SOLVE** | Cortex tool | Takes validated recipe → outputs exact XYZ positions for every part. Pure math. No guessing. |
| **BUILD** | LLM (in engine) | LLM uses engine tools/MCP to create geometry at solved positions. Cortex not involved. |
| **VERIFY** | Cortex tool | LLM passes built object data → Cortex runs 5 mathematical checks → PASS/FAIL with exact numbers. |

### Fix Loop:

When VERIFY fails:
1. Cortex tells exactly WHAT failed (which part, which check, expected vs actual)
2. LLM fixes ONLY the failed part
3. LLM re-runs VERIFY on ONLY the fixed part
4. Repeat until PASS
5. NEVER proceed to next part while current part fails

---

## 3. MCP Tools

Cortex exposes exactly **6 tools** via MCP (Model Context Protocol).

Transport: `stdio`
Protocol: MCP standard (JSON-RPC 2.0)

### 3.1 `decompose`

**Purpose:** Force structured breakdown of any object/scene into parts hierarchy.

**Why it exists:** LLMs skip parts when freestyling. Decompose forces exhaustive enumeration with a consistent structure every time.

**Input Schema:**
```json
{
  "type": "object",
  "required": ["subject"],
  "properties": {
    "subject": {
      "type": "string",
      "description": "What to decompose. Examples: 'studio headphone', 'park bench', 'city block', 'dashboard UI'"
    },
    "variant": {
      "type": "string",
      "description": "Specific variant. Examples: 'ATH-M50x', 'cast iron garden bench', 'Japanese style'"
    },
    "scope": {
      "type": "string",
      "enum": ["object", "scene"],
      "default": "object",
      "description": "'object' = single item decomposition. 'scene' = multi-object environment."
    },
    "detail_level": {
      "type": "string",
      "enum": ["basic", "detailed", "exhaustive"],
      "default": "detailed",
      "description": "How deep to decompose. 'basic' = major parts only. 'detailed' = sub-parts + connections. 'exhaustive' = every screw, seam, chamfer."
    }
  }
}
```

**Output Schema:**
```json
{
  "type": "object",
  "properties": {
    "subject": { "type": "string" },
    "hierarchy": {
      "type": "object",
      "description": "Nested part tree. Each node has: name, children[], parent, connection_to_parent",
      "additionalProperties": {
        "type": "object",
        "properties": {
          "name": { "type": "string" },
          "parent": { "type": "string", "nullable": true },
          "connection": {
            "type": "string",
            "description": "How this part connects to parent: flush, stacked, hinged, socketed, welded, snapped, etc."
          },
          "children": {
            "type": "array",
            "items": { "type": "string" }
          }
        }
      }
    },
    "research_required": {
      "type": "array",
      "description": "List of data the LLM must gather before proceeding",
      "items": {
        "type": "object",
        "properties": {
          "part": { "type": "string" },
          "needed": {
            "type": "array",
            "items": {
              "type": "string",
              "enum": ["dimensions", "edge_treatment", "material", "thickness", "construction_method", "reference_image"]
            }
          }
        }
      }
    },
    "total_parts": { "type": "integer" },
    "build_order": {
      "type": "array",
      "items": { "type": "string" },
      "description": "Suggested order to build parts (anchor first, then dependents)"
    }
  }
}
```

**Behavior:**
- Cortex uses its knowledge of common object anatomy to generate the hierarchy
- The hierarchy is a TEMPLATE — LLM can add/remove parts based on research
- `research_required` is the critical output — it's the checklist that prevents skipping
- For `scope: "scene"`, returns zone-level decomposition (ground, buildings zone, furniture zone, etc.) — each zone then gets its own object-level decompose

**Example:**
```
Input:  { "subject": "park bench", "detail_level": "detailed" }
Output: {
  "subject": "park bench",
  "hierarchy": {
    "bench": {
      "name": "bench", "parent": null, "connection": null,
      "children": ["seat", "backrest", "leg_left", "leg_right", "armrest_left", "armrest_right"]
    },
    "seat": {
      "name": "seat", "parent": "bench", "connection": "anchor (root part)",
      "children": ["seat_planks", "seat_frame"]
    },
    "seat_planks": {
      "name": "seat_planks", "parent": "seat", "connection": "mounted on frame",
      "children": []
    },
    "seat_frame": {
      "name": "seat_frame", "parent": "seat", "connection": "structural base",
      "children": []
    },
    "backrest": {
      "name": "backrest", "parent": "bench", "connection": "stacked on seat rear edge",
      "children": ["backrest_planks", "backrest_frame"]
    },
    "leg_left": {
      "name": "leg_left", "parent": "bench", "connection": "stacked below seat, flush left",
      "children": []
    },
    "leg_right": {
      "name": "leg_right", "parent": "bench", "connection": "stacked below seat, flush right",
      "children": []
    },
    "armrest_left": {
      "name": "armrest_left", "parent": "bench", "connection": "mounted on leg_left top",
      "children": []
    },
    "armrest_right": {
      "name": "armrest_right", "parent": "bench", "connection": "mounted on leg_right top",
      "children": []
    }
  },
  "research_required": [
    { "part": "seat_planks", "needed": ["dimensions", "edge_treatment", "material", "thickness"] },
    { "part": "backrest_planks", "needed": ["dimensions", "edge_treatment", "material", "thickness"] },
    { "part": "leg_left", "needed": ["dimensions", "material", "construction_method"] },
    { "part": "armrest_left", "needed": ["dimensions", "material", "thickness"] },
    { "part": "seat_frame", "needed": ["dimensions", "material", "construction_method"] }
  ],
  "total_parts": 9,
  "build_order": ["seat_frame", "seat_planks", "backrest_frame", "backrest_planks", "leg_left", "leg_right", "armrest_left", "armrest_right"]
}
```

---

### 3.2 `research`

**Purpose:** Gate that forces LLM to gather real data before proceeding to recipe design.

**Why it exists:** LLMs guess dimensions and skip research. This tool takes a decompose output and returns a STRUCTURED CHECKLIST that the LLM must complete using web search, image search, or its own knowledge. The checklist is validated — empty fields block progress.

**Input Schema:**
```json
{
  "type": "object",
  "required": ["hierarchy"],
  "properties": {
    "hierarchy": {
      "type": "object",
      "description": "The hierarchy output from decompose tool"
    },
    "filled_data": {
      "type": "object",
      "description": "Data the LLM has gathered so far. Map of part_name → researched properties.",
      "additionalProperties": {
        "type": "object",
        "properties": {
          "dimensions": {
            "type": "object",
            "properties": {
              "width": { "type": "number", "description": "X-axis size in meters" },
              "depth": { "type": "number", "description": "Y-axis size in meters" },
              "height": { "type": "number", "description": "Z-axis size in meters" }
            }
          },
          "edge_treatment": {
            "type": "string",
            "description": "Bevel/chamfer/fillet radius description. e.g., '2mm bevel', 'sharp', '5mm fillet'"
          },
          "material": {
            "type": "string",
            "description": "Material description. e.g., 'cast iron, dark gray', 'oak wood, natural finish'"
          },
          "thickness": {
            "type": "number",
            "description": "Wall/shell thickness in meters (for non-solid parts)"
          },
          "construction_method": {
            "type": "string",
            "description": "How this part is made/shaped. e.g., 'bent tube', 'cast single piece', 'welded plates'"
          },
          "source": {
            "type": "string",
            "description": "Where this data came from. e.g., 'manufacturer spec', 'web search', 'estimated from reference image'"
          }
        }
      }
    }
  }
}
```

**Output Schema:**
```json
{
  "type": "object",
  "properties": {
    "complete": {
      "type": "boolean",
      "description": "true if ALL required fields are filled. false = cannot proceed."
    },
    "missing": {
      "type": "array",
      "description": "What's still missing",
      "items": {
        "type": "object",
        "properties": {
          "part": { "type": "string" },
          "field": { "type": "string" },
          "hint": { "type": "string", "description": "Suggestion for where to find this data" }
        }
      }
    },
    "warnings": {
      "type": "array",
      "description": "Suspicious values that might be wrong",
      "items": {
        "type": "object",
        "properties": {
          "part": { "type": "string" },
          "field": { "type": "string" },
          "value": { "type": "number" },
          "concern": { "type": "string", "description": "Why this looks wrong. e.g., 'bench seat 3m wide seems too large'" }
        }
      }
    },
    "ready_for_recipe": {
      "type": "boolean",
      "description": "true only when complete=true AND no critical warnings"
    }
  }
}
```

**Behavior:**
- First call: LLM passes hierarchy with no filled_data → gets full checklist of everything needed
- LLM goes and researches (web search, image search, etc.)
- Second call: LLM passes hierarchy + filled_data → Cortex checks completeness
- Cortex also does SANITY CHECKS on values:
  - Dimensions within reasonable range for object type (bench seat not 10m wide)
  - Thickness not larger than smallest dimension
  - All dimensions in meters (catches if someone puts cm values in meter fields)
- Repeat until `ready_for_recipe: true`

**Sanity check ranges (built-in, approximate):**
```
furniture: 0.1m - 3m per axis
electronics: 0.01m - 1m per axis
architecture: 1m - 100m per axis
vehicle: 1m - 20m per axis
small_props: 0.005m - 0.5m per axis
```
These are SOFT warnings, not hard blocks. LLM can override with justification.

---

### 3.3 `validate`

**Purpose:** Check a recipe for structural correctness BEFORE solving.

**Why it exists:** Catches errors early — missing parts, invalid constraints, circular dependencies, impossible configurations. Cheaper than solving and getting garbage output.

**Input Schema:**
```json
{
  "type": "object",
  "required": ["recipe"],
  "properties": {
    "recipe": {
      "type": "object",
      "description": "A part recipe or scene recipe (see Section 4 for format)"
    }
  }
}
```

**Output Schema:**
```json
{
  "type": "object",
  "properties": {
    "valid": { "type": "boolean" },
    "errors": {
      "type": "array",
      "description": "Blocking issues — must fix before solving",
      "items": {
        "type": "object",
        "properties": {
          "type": { "type": "string", "enum": ["missing_part", "invalid_constraint", "circular_dependency", "missing_field", "type_error", "orphan_part"] },
          "message": { "type": "string" },
          "location": { "type": "string", "description": "Where in the recipe the error is" }
        }
      }
    },
    "warnings": {
      "type": "array",
      "description": "Non-blocking but suspicious",
      "items": {
        "type": "object",
        "properties": {
          "type": { "type": "string" },
          "message": { "type": "string" }
        }
      }
    }
  }
}
```

**Validation checks:**

1. **Schema completeness** — All required fields present (`name`, `anchor`, `parts`, `constraints`)
2. **Part existence** — Every part referenced in constraints exists in `parts` map
3. **Anchor exists** — The designated anchor part exists
4. **Constraint validity** — Each constraint has valid `type`, valid `axis`, valid `face` values
5. **No orphans** — Every non-anchor part is referenced by at least one constraint
6. **No circular deps** — Topological sort succeeds (no cycles in dependency graph)
7. **Dimension presence** — Every part has dimensions (either explicit or derivable from params)
8. **Mirror validity** — Mirror source exists, target exists, axis is valid
9. **Constraint conflicts** — Detect if same axis of same part is constrained by conflicting constraints
10. **Type checking** — Numeric fields are numbers, enum fields are valid values

---

### 3.4 `solve`

**Purpose:** The core engine. Takes a validated recipe → outputs exact XYZ positions for every part.

**Why it exists:** This is THE thing LLMs cannot do reliably. Manual coordinate calculation for multi-part assemblies ALWAYS has errors. The solver uses constraint-based positioning — mathematically correct, every time.

**Input Schema:**
```json
{
  "type": "object",
  "required": ["recipe"],
  "properties": {
    "recipe": {
      "type": "object",
      "description": "A validated part recipe (see Section 4)"
    }
  }
}
```

**Output Schema:**
```json
{
  "type": "object",
  "properties": {
    "success": { "type": "boolean" },
    "positions": {
      "type": "object",
      "description": "Map of part_name → solved position",
      "additionalProperties": {
        "type": "object",
        "properties": {
          "location": {
            "type": "array",
            "items": { "type": "number" },
            "minItems": 3, "maxItems": 3,
            "description": "[x, y, z] world position in meters"
          },
          "dimensions": {
            "type": "array",
            "items": { "type": "number" },
            "minItems": 3, "maxItems": 3,
            "description": "[width, depth, height] in meters"
          }
        }
      }
    },
    "build_order": {
      "type": "array",
      "items": { "type": "string" },
      "description": "Order to build parts (topologically sorted)"
    },
    "conflicts": {
      "type": "array",
      "description": "Constraints that couldn't be fully satisfied",
      "items": {
        "type": "object",
        "properties": {
          "constraint_index": { "type": "integer" },
          "message": { "type": "string" }
        }
      }
    },
    "error": {
      "type": "string",
      "description": "Only present if success=false"
    }
  }
}
```

**Algorithm:** See Section 5 (full solver specification).

---

### 3.5 `solve_scene`

**Purpose:** Position multiple objects within a scene/environment. Like `solve` but for scene-level layout.

**Why it exists:** Same problem as part positioning but at scene scale. "Place 20 benches along a path with 3m spacing, all facing the road" — LLM will miscalculate positions for objects 7+.

**Input Schema:**
```json
{
  "type": "object",
  "required": ["scene_recipe"],
  "properties": {
    "scene_recipe": {
      "type": "object",
      "description": "A scene recipe (see Section 4.2)"
    }
  }
}
```

**Output Schema:**
```json
{
  "type": "object",
  "properties": {
    "success": { "type": "boolean" },
    "placements": {
      "type": "object",
      "description": "Map of object_name → position + rotation",
      "additionalProperties": {
        "type": "object",
        "properties": {
          "location": {
            "type": "array",
            "items": { "type": "number" },
            "minItems": 3, "maxItems": 3
          },
          "rotation": {
            "type": "array",
            "items": { "type": "number" },
            "minItems": 3, "maxItems": 3,
            "description": "[rx, ry, rz] in degrees"
          },
          "scale": {
            "type": "array",
            "items": { "type": "number" },
            "minItems": 3, "maxItems": 3,
            "description": "[sx, sy, sz] — usually [1,1,1]"
          }
        }
      }
    },
    "error": { "type": "string" }
  }
}
```

**Scene constraint types:**

| Type | Description | Example |
|------|-------------|---------|
| `GRID` | Place objects in a grid pattern | 4x4 grid of market stalls, 3m spacing |
| `ALONG_PATH` | Place objects along a line/curve | Benches along sidewalk every 5m |
| `RADIAL` | Place objects in a circle/arc | Chairs around a round table |
| `FACING` | Orient object to face a target | All benches face the fountain |
| `DISTANCE` | Minimum distance between objects | Trees at least 4m apart |
| `AGAINST_EDGE` | Place object flush against boundary | Buildings along road edge |
| `RANDOM_SCATTER` | Distribute within bounds with min spacing | Trees scattered in park area |
| `STACK_VERTICAL` | Stack objects vertically | Floors of a building |
| `MIRROR_SCENE` | Mirror a group of objects across axis | Symmetric street layout |

---

### 3.6 `verify`

**Purpose:** Mathematical proof that built geometry matches the design. No self-judgment. Code checks code.

**Why it exists:** LLMs are unreliable at self-evaluation. "Looks good" means nothing. Verify runs 5 concrete checks with exact numbers and tolerances.

**Input Schema:**
```json
{
  "type": "object",
  "required": ["object_name", "object_data"],
  "properties": {
    "object_name": { "type": "string" },
    "object_data": {
      "type": "object",
      "description": "Actual measurements from the built object (LLM queries engine to get these)",
      "properties": {
        "location": {
          "type": "array", "items": { "type": "number" },
          "minItems": 3, "maxItems": 3,
          "description": "Actual world position [x, y, z]"
        },
        "dimensions": {
          "type": "array", "items": { "type": "number" },
          "minItems": 3, "maxItems": 3,
          "description": "Actual bounding box [width, depth, height]"
        },
        "scale": {
          "type": "array", "items": { "type": "number" },
          "minItems": 3, "maxItems": 3,
          "description": "Applied scale — should be [1, 1, 1]"
        },
        "vertex_count": { "type": "integer" },
        "face_count": { "type": "integer" },
        "has_ngons": { "type": "boolean" },
        "has_non_manifold": { "type": "boolean" },
        "has_loose_vertices": { "type": "boolean" },
        "normals_consistent": { "type": "boolean" },
        "collection": { "type": "string" },
        "neighbors": {
          "type": "array",
          "description": "Names of objects that should be in contact with this one",
          "items": {
            "type": "object",
            "properties": {
              "name": { "type": "string" },
              "closest_distance": {
                "type": "number",
                "description": "Minimum distance between surfaces of this object and the neighbor (meters)"
              }
            }
          }
        }
      }
    },
    "expected": {
      "type": "object",
      "description": "What the solve output said this object should be",
      "properties": {
        "location": { "type": "array", "items": { "type": "number" } },
        "dimensions": { "type": "array", "items": { "type": "number" } }
      }
    }
  }
}
```

**Output Schema:**
```json
{
  "type": "object",
  "properties": {
    "object_name": { "type": "string" },
    "pass": { "type": "boolean", "description": "true only if ALL 5 checks pass" },
    "checks": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "name": { "type": "string", "enum": ["mesh_health", "identity", "placement", "connection", "dimensions"] },
          "pass": { "type": "boolean" },
          "details": { "type": "string" },
          "severity": { "type": "string", "enum": ["critical", "warning", "info"] }
        }
      }
    },
    "summary": { "type": "string", "description": "Human-readable one-line summary" }
  }
}
```

**The 5 checks:**

#### Check 1: Mesh Health
- Non-manifold edges → FAIL (critical)
- Loose vertices → FAIL (critical)
- Inconsistent normals → FAIL (critical)
- Ngons on curved surfaces → WARNING
- Zero-area faces → FAIL (critical)

#### Check 2: Identity
- Scale is [1, 1, 1] → if not, FAIL (critical) — "apply scale before proceeding"
- Object has descriptive name (not "Cube.001") → WARNING if generic
- Object is in correct collection → WARNING if wrong/missing

#### Check 3: Placement
- Actual location vs expected location
- Tolerance: **0.001m** (1mm)
- Per-axis delta reported
- FAIL if any axis delta > tolerance

#### Check 4: Connection
- For each neighbor: closest_distance should be < **0.002m** for flush contacts
- Reports actual distance per neighbor
- FAIL if parts that should touch have gap > tolerance
- This catches "floating parts" — the most common LLM error

#### Check 5: Dimensions
- Actual dimensions vs expected dimensions
- Tolerance: **0.005m** (5mm) per axis
- Per-axis delta reported
- FAIL if any axis delta > tolerance
- This catches wrong scale, wrong parameters

**Verify modes:**

- **Single object**: `verify(object_name, object_data, expected)` — checks one object
- **Batch**: LLM can call verify in a loop for all objects. Cortex doesn't need a separate batch tool — the LLM orchestrates.

---

## 4. Recipe Format

Recipes are the structured input format that the solver consumes. There are two types:
- **Part Recipe** — for assembling parts within a single object/assembly (→ `solve`)
- **Scene Recipe** — for positioning objects within a scene (→ `solve_scene`)

### 4.1 Part Recipe

```json
{
  "name": "string — assembly name",
  "anchor": "string — name of root part (positioned first, everything relative to it)",
  "anchor_position": [0, 0, 0],
  
  "parts": {
    "part_name": {
      "dimensions": {
        "width": 0.0,
        "depth": 0.0,
        "height": 0.0
      },
      "type": "string — optional, for LLM's own tracking (e.g., 'beveled_box', 'cylinder')",
      "params": {},
      "metadata": {}
    }
  },

  "constraints": [
    {
      "type": "CONSTRAINT_TYPE",
      "part_a": "string — the part being positioned",
      "part_b": "string — the reference part (must be already positioned)",
      "axis": "X | Y | Z",
      "face_a": "+X | -X | +Y | -Y | +Z | -Z",
      "face_b": "+X | -X | +Y | -Y | +Z | -Z",
      "offset": 0.0,
      "reference": "top | bottom | center"
    }
  ],

  "mirrors": [
    {
      "source": "string — part to mirror",
      "target": "string — name for mirrored copy",
      "axis": "X | Y | X,Y | X,Z | Y,Z"
    }
  ],

  "collections": {
    "Collection Name": ["part1", "part2"]
  }
}
```

**Field details:**

- `anchor` — The root part. Gets placed at `anchor_position`. ALL other parts are positioned relative to this.
- `parts[name].dimensions` — Bounding box in meters. **REQUIRED.** The solver needs this to calculate face positions.
- `parts[name].type` — Cortex doesn't use this. It's for the LLM to remember what shape to build in the engine.
- `parts[name].params` — Cortex doesn't use this. Engine-specific parameters the LLM needs for building.
- `parts[name].metadata` — Cortex doesn't use this. Material info, notes, whatever the LLM wants to store.
- `constraints` — Spatial relationships. Solver resolves these into positions. See Section 4.3.
- `mirrors` — Copy a solved part's position, mirrored across axis. Only model one side.
- `collections` — Organizational grouping. Solver doesn't use this. LLM uses it for engine organization.

### 4.2 Scene Recipe

```json
{
  "name": "string — scene name",
  "bounds": {
    "min": [0, 0, 0],
    "max": [50, 50, 10]
  },

  "objects": {
    "object_name": {
      "dimensions": { "width": 0.0, "depth": 0.0, "height": 0.0 },
      "type": "string — optional",
      "metadata": {}
    }
  },

  "zones": {
    "zone_name": {
      "bounds": { "min": [0, 0, 0], "max": [20, 20, 5] },
      "objects": ["obj1", "obj2"]
    }
  },

  "constraints": [
    {
      "type": "SCENE_CONSTRAINT_TYPE",
      "object": "string | array — object(s) to position",
      "params": {}
    }
  ]
}
```

**Scene constraint params per type:**

```json
// GRID
{ "type": "GRID", "object": ["stall_1", "stall_2", ...], "params": {
    "origin": [0, 0, 0], "rows": 4, "cols": 4, "spacing_x": 3.0, "spacing_y": 3.0
}}

// ALONG_PATH
{ "type": "ALONG_PATH", "object": ["bench_1", "bench_2", ...], "params": {
    "start": [0, 0, 0], "end": [50, 0, 0], "spacing": 5.0, "offset_lateral": 1.0
}}

// RADIAL
{ "type": "RADIAL", "object": ["chair_1", "chair_2", ...], "params": {
    "center": [5, 5, 0], "radius": 2.0, "count": 8, "start_angle": 0, "face_center": true
}}

// FACING
{ "type": "FACING", "object": "bench_1", "params": {
    "target": [10, 10, 0]
}}

// DISTANCE
{ "type": "DISTANCE", "object": ["tree_1", "tree_2"], "params": {
    "min_distance": 4.0
}}

// AGAINST_EDGE
{ "type": "AGAINST_EDGE", "object": "building_1", "params": {
    "edge": "+X", "zone": "street_zone", "position_along": 0.3
}}

// RANDOM_SCATTER
{ "type": "RANDOM_SCATTER", "object": ["tree_1", "tree_2", ...], "params": {
    "zone": "park_zone", "min_spacing": 3.0, "seed": 42
}}

// STACK_VERTICAL
{ "type": "STACK_VERTICAL", "object": ["floor_1", "floor_2", "floor_3"], "params": {
    "base_position": [0, 0, 0], "gap": 0.0
}}

// MIRROR_SCENE
{ "type": "MIRROR_SCENE", "object": ["bench_left_1", "lamp_left_1"], "params": {
    "targets": ["bench_right_1", "lamp_right_1"], "axis": "X", "center": 25.0
}}
```

### 4.3 Constraint Types (Part-Level)

These are the constraints used in Part Recipes. Each constraint positions ONE axis of `part_a` relative to `part_b`.

**CRITICAL RULE: Each axis of each part should be constrained EXACTLY ONCE.** A part needs constraints for all 3 axes (X, Y, Z) to be fully positioned. Multiple constraints on the same axis = conflict.

| Type | What it does | Required fields | Example |
|------|-------------|-----------------|---------|
| **STACKED** | Place part_a on top or bottom of part_b | axis, reference(top/bottom) | Backrest stacked on seat (Z axis, reference: top) |
| **CENTERED** | Center part_a on part_b along axis | axis | Backrest centered on seat (X axis) |
| **FLUSH** | Align a face of part_a with a face of part_b | axis, face_a, face_b | Backrest flush with rear edge of seat (face_a: -Y, face_b: -Y) |
| **OFFSET** | Like FLUSH but with explicit gap | axis, face_a, face_b, offset | Leg inset 3cm from seat edge (offset: 0.03) |
| **COAXIAL** | Parts share the same central axis | axis | Speaker cone coaxial with driver housing |
| **INSIDE** | Part_a centered inside part_b | axis | Cushion inside earcup shell |
| **ALIGNED** | Part_a's center aligned with part_b's center on axis | axis | Hinge aligned with earcup on Y axis |
| **SYMMETRIC** | Part_b mirrors part_a across midplane of reference | axis | Left earcup symmetric to right earcup on X axis |

**How constraints resolve to coordinates:**

```
STACKED (axis=Z, reference=top):
  part_a.z = part_b.z + part_b.height/2 + part_a.height/2

STACKED (axis=Z, reference=bottom):
  part_a.z = part_b.z - part_b.height/2 - part_a.height/2

CENTERED (axis=X):
  part_a.x = part_b.x

FLUSH (axis=Y, face_a=-Y, face_b=-Y):
  part_a.y = part_b.y - part_b.depth/2 + part_a.depth/2

FLUSH (axis=Y, face_a=+Y, face_b=+Y):
  part_a.y = part_b.y + part_b.depth/2 - part_a.depth/2

OFFSET (axis=X, face_a=+X, face_b=-X, offset=0.03):
  part_a.x = part_b.x - part_b.width/2 + part_a.width/2 + offset

COAXIAL (axis=Z):
  part_a.x = part_b.x
  part_a.y = part_b.y
  (sets TWO axes — X and Y)

INSIDE (axis=X):
  part_a.x = part_b.x
  (centers on specified axis; use multiple INSIDE for multiple axes)

ALIGNED (axis=X):
  part_a.x = part_b.x

SYMMETRIC (axis=X):
  part_a.x = -part_b.x  (mirror across X=0 plane)
  part_a.y = part_b.y
  part_a.z = part_b.z
  (sets ALL 3 axes)
```

**Constraint that sets multiple axes:**
- COAXIAL sets 2 axes (the two perpendicular to the specified axis)
- SYMMETRIC sets 3 axes (all)
- All others set 1 axis

---

## 5. Constraint Solver

This is the core algorithm. Proven with 37/37 tests. Pure math, zero engine dependencies.

### 5.1 Overview

The solver takes a recipe and produces exact [x, y, z] positions for every part.

```
Input:  Recipe (parts with dimensions + constraints + anchor)
Output: Map of part_name → [x, y, z] position
```

### 5.2 Algorithm

```
FUNCTION solve(recipe):
    
    // Step 1: Validate (should already be validated, but double-check)
    errors = validate(recipe)
    if errors: return SolveResult(success=false, error=errors)
    
    // Step 2: Build dependency graph
    graph = {}
    for each constraint in recipe.constraints:
        graph[constraint.part_a] depends on graph[constraint.part_b]
    
    // Step 3: Topological sort
    // Parts must be positioned in order — can't position A relative to B if B isn't positioned yet
    build_order = topological_sort(graph, anchor=recipe.anchor)
    if cycle detected: return SolveResult(success=false, error="circular dependency")
    
    // Step 4: Initialize anchor
    positions = {}
    positions[recipe.anchor] = recipe.anchor_position  // [x, y, z]
    
    // Step 5: Resolve constraints in topological order
    for each part_name in build_order (excluding anchor):
        position = [None, None, None]  // 3 axes to solve
        
        // Find all constraints that position this part
        part_constraints = [c for c in recipe.constraints where c.part_a == part_name]
        
        for each constraint in part_constraints:
            resolved_axes = resolve_constraint(
                constraint,
                part_a_dims = recipe.parts[part_name].dimensions,
                part_b_pos  = positions[constraint.part_b],
                part_b_dims = recipe.parts[constraint.part_b].dimensions
            )
            
            for axis_index, value in resolved_axes:
                if position[axis_index] is not None:
                    // CONFLICT: axis already set by another constraint
                    // Check if values match (within tolerance)
                    if abs(position[axis_index] - value) > 0.0001:
                        record_conflict(part_name, axis_index, position[axis_index], value)
                    // Keep first value (priority = constraint order)
                else:
                    position[axis_index] = value
        
        // Check all 3 axes are resolved
        for axis_index in [0, 1, 2]:
            if position[axis_index] is None:
                // Default: inherit from anchor position on this axis
                position[axis_index] = recipe.anchor_position[axis_index]
                record_warning(f"{part_name} axis {axis_index} unconstrained, defaulting to anchor")
        
        positions[part_name] = position
    
    // Step 6: Process mirrors
    for each mirror in recipe.mirrors:
        source_pos = positions[mirror.source]
        source_dims = recipe.parts[mirror.source].dimensions
        
        if "X" in mirror.axis:
            mirrored_x = 2 * recipe.anchor_position[0] - source_pos[0]
        else:
            mirrored_x = source_pos[0]
            
        if "Y" in mirror.axis:
            mirrored_y = 2 * recipe.anchor_position[1] - source_pos[1]
        else:
            mirrored_y = source_pos[1]
            
        if "Z" in mirror.axis:
            mirrored_z = 2 * recipe.anchor_position[2] - source_pos[2]
        else:
            mirrored_z = source_pos[2]
        
        positions[mirror.target] = [mirrored_x, mirrored_y, mirrored_z]
    
    // Step 7: Return result
    return SolveResult(
        success = true,
        positions = { name: { location: pos, dimensions: recipe.parts[name].dimensions } for name, pos in positions },
        build_order = build_order,
        conflicts = recorded_conflicts
    )
```

### 5.3 Constraint Resolution Functions

Each constraint type has a resolution function that returns `[(axis_index, value), ...]`.

```
FUNCTION resolve_constraint(constraint, part_a_dims, part_b_pos, part_b_dims):
    
    type = constraint.type
    axis = constraint.axis  // "X", "Y", or "Z"
    axis_map = {"X": 0, "Y": 1, "Z": 2}
    dim_map = {"X": "width", "Y": "depth", "Z": "height"}
    
    ai = axis_map[axis]  // axis index (0, 1, or 2)
    
    // Get half-dimensions along the constraint axis
    a_half = get_half_dim(part_a_dims, axis)
    b_half = get_half_dim(part_b_dims, axis)
    b_pos = part_b_pos[ai]  // part_b position on this axis
    
    SWITCH type:
    
    CASE "STACKED":
        if constraint.reference == "top":
            return [(ai, b_pos + b_half + a_half)]
        elif constraint.reference == "bottom":
            return [(ai, b_pos - b_half - a_half)]
    
    CASE "CENTERED":
        return [(ai, b_pos)]
    
    CASE "FLUSH":
        fa = constraint.face_a  // e.g., "-Y"
        fb = constraint.face_b  // e.g., "-Y"
        
        // Determine positions based on face alignment
        // face_b position = part_b center ± part_b half-dim
        b_face_pos = b_pos + (b_half if fb starts with "+" else -b_half)
        
        // part_a center such that face_a aligns with b_face_pos
        if fa starts with "+":
            a_center = b_face_pos - a_half
        else:
            a_center = b_face_pos + a_half
        
        return [(ai, a_center)]
    
    CASE "OFFSET":
        // Same as FLUSH but with offset added
        fa = constraint.face_a
        fb = constraint.face_b
        offset = constraint.offset or 0.0
        
        b_face_pos = b_pos + (b_half if fb starts with "+" else -b_half)
        
        if fa starts with "+":
            a_center = b_face_pos - a_half + offset
        else:
            a_center = b_face_pos + a_half + offset
        
        return [(ai, a_center)]
    
    CASE "COAXIAL":
        // Align on the two axes PERPENDICULAR to the specified axis
        perp_axes = [i for i in [0,1,2] if i != ai]
        return [
            (perp_axes[0], part_b_pos[perp_axes[0]]),
            (perp_axes[1], part_b_pos[perp_axes[1]])
        ]
    
    CASE "INSIDE":
        return [(ai, b_pos)]
    
    CASE "ALIGNED":
        return [(ai, b_pos)]
    
    CASE "SYMMETRIC":
        anchor_pos = recipe.anchor_position  // need access to this
        return [
            (0, 2 * anchor_pos[0] - part_b_pos[0]),  // mirror X
            (1, part_b_pos[1]),                         // keep Y
            (2, part_b_pos[2])                          // keep Z
        ]
        // Note: SYMMETRIC mirrors across the axis specified, keeps other axes
        // The above is for axis=X. Generalize:
        // mirrored axis: 2 * anchor - part_b_pos
        // other axes: same as part_b_pos

FUNCTION get_half_dim(dims, axis):
    if axis == "X": return dims.width / 2
    if axis == "Y": return dims.depth / 2
    if axis == "Z": return dims.height / 2
```

### 5.4 Topological Sort

```
FUNCTION topological_sort(constraints, anchor):
    // Build adjacency: part_a depends on part_b
    deps = defaultdict(set)
    all_parts = set()
    
    for c in constraints:
        deps[c.part_a].add(c.part_b)
        all_parts.add(c.part_a)
        all_parts.add(c.part_b)
    
    // Kahn's algorithm
    in_degree = {p: 0 for p in all_parts}
    for p, dep_set in deps.items():
        in_degree[p] = len(dep_set)
    
    queue = [anchor]  // anchor has no dependencies
    order = []
    
    while queue:
        current = queue.pop(0)
        order.append(current)
        
        // Find parts that depend on current
        for p in all_parts:
            if current in deps[p]:
                deps[p].remove(current)
                in_degree[p] -= 1
                if in_degree[p] == 0:
                    queue.append(p)
    
    if len(order) != len(all_parts):
        // Cycle detected — some parts never reached in_degree 0
        missing = all_parts - set(order)
        raise CycleError(f"Circular dependency involving: {missing}")
    
    return order
```

### 5.5 Solver Test Cases (37 proven)

These tests MUST all pass in any implementation. Grouped by category:

**Individual constraint types (8 tests):**
1. STACKED top — part placed above reference
2. STACKED bottom — part placed below reference
3. CENTERED — part centered on reference
4. FLUSH same face — part aligned to same face
5. FLUSH opposite face — part aligned to opposite face
6. OFFSET — part offset from face
7. COAXIAL — part shares axis with reference (2 axes set)
8. INSIDE — part centered inside reference

**Multi-constraint combinations (10 tests):**
9. STACKED + CENTERED + CENTERED (3-axis full position)
10. STACKED + FLUSH + CENTERED
11. STACKED + FLUSH + FLUSH
12. STACKED + OFFSET + CENTERED
13. Multiple parts, chain dependency (A→B→C)
14. Multiple parts, fan dependency (B→A, C→A, D→A)
15. 5-part assembly with mixed constraints
16. 10-part assembly (stress test)
17. 20-part assembly (stress test)
18. 50-part assembly (stress test — headphone)

**Mirror handling (5 tests):**
19. Mirror on X axis
20. Mirror on Y axis
21. Mirror on X,Y (double mirror)
22. Mirror chain (mirror of mirrored — should fail or handle)
23. Mirror with offset source

**Conflict detection (5 tests):**
24. Same axis constrained twice, same value — OK (redundant)
25. Same axis constrained twice, different value — CONFLICT reported
26. Unconstrained axis — WARNING + default to anchor
27. Over-constrained part (4+ constraints)
28. Conflicting FLUSH values

**Cycle detection (4 tests):**
29. Simple cycle: A→B→A
30. Complex cycle: A→B→C→A
31. Self-reference: A→A
32. Valid DAG (no cycle) — should succeed

**Edge cases (5 tests):**
33. Zero-size part (one dimension = 0)
34. Very small parts (0.001m)
35. Very large parts (100m)
36. Negative anchor position
37. Anchor at origin [0,0,0]

---

## 6. Verification System

### 6.1 The 5 Checks

Every built object must pass ALL 5 checks before proceeding to the next object.

```
CHECK 1: MESH HEALTH
├── Non-manifold edges       → CRITICAL FAIL
├── Loose vertices           → CRITICAL FAIL
├── Inconsistent normals     → CRITICAL FAIL
├── Zero-area faces          → CRITICAL FAIL
└── Ngons on curved surfaces → WARNING

CHECK 2: IDENTITY
├── Scale applied [1,1,1]    → CRITICAL FAIL if not
├── Descriptive name         → WARNING if generic ("Cube.001")
└── Correct collection       → WARNING if wrong

CHECK 3: PLACEMENT
├── X position delta         → FAIL if > 0.001m
├── Y position delta         → FAIL if > 0.001m
└── Z position delta         → FAIL if > 0.001m

CHECK 4: CONNECTION
├── For each expected neighbor:
│   └── Surface distance     → FAIL if > 0.002m (parts should touch)
└── Reports actual distance per neighbor pair

CHECK 5: DIMENSIONS
├── Width delta              → FAIL if > 0.005m
├── Depth delta              → FAIL if > 0.005m
└── Height delta             → FAIL if > 0.005m
```

### 6.2 Tolerances

| Check | Tolerance | Reasoning |
|-------|-----------|-----------|
| Placement | 0.001m (1mm) | Position must be precise |
| Connection | 0.002m (2mm) | Allows for bevel/chamfer at edges |
| Dimensions | 0.005m (5mm) | Allows for bevel/fillet affecting bounding box |

### 6.3 Verification Flow

```
For each object in build_order:
    1. LLM builds object in engine
    2. LLM queries engine for: location, dimensions, scale, vertex_count, 
       face_count, mesh health flags, neighbor distances
    3. LLM calls verify(object_name, object_data, expected)
    4. If ALL PASS → proceed to next object
    5. If ANY FAIL:
       a. Read which check failed and why (exact numbers)
       b. Fix ONLY the failed aspect
       c. Re-query engine for updated data
       d. Re-call verify
       e. Repeat until PASS
       f. NEVER proceed with a failed object
```

### 6.4 Connection Verification Detail

Connection check is the most nuanced. It must verify that parts which SHOULD touch actually DO touch.

**How to determine which parts should touch:**
- From the recipe: any constraint between part_a and part_b implies they should be in contact (except CENTERED-only relationships)
- STACKED → touching on stacking face
- FLUSH → touching on flush face
- COAXIAL → may or may not touch (depends on geometry)
- INSIDE → inner part surface near outer part surface

**How LLM measures distance:**
- In Blender: use `closest_point_on_mesh()` between two objects
- In other engines: equivalent raycasting or distance query
- Report minimum surface-to-surface distance

**Tolerance for connection:**
- STACKED/FLUSH contacts: < 0.002m
- INSIDE contacts: < 0.005m (more tolerance for nesting)
- COAXIAL: no contact check (just axis alignment)

---

## 7. Integration

### 7.1 How LLM Uses Cortex

Complete workflow for building a park bench in Blender:

```
STEP 1: DECOMPOSE
─────────────────
LLM → cortex.decompose({
    subject: "park bench",
    variant: "cast iron garden bench with wood slats",
    detail_level: "detailed"
})

cortex → returns hierarchy + research_required checklist

STEP 2: RESEARCH
────────────────
LLM reads checklist: needs dimensions for seat_plank, backrest_plank, leg_left, armrest

LLM → web_search("garden bench dimensions standard")
LLM → web_search("cast iron bench leg dimensions")
LLM → web_search("park bench wood slat thickness")

LLM gathers:
  seat_plank: 1.5m wide, 0.04m thick, 0.05m deep per slat, 6 slats
  leg: 0.06m wide, 0.42m tall, cast iron
  backrest_plank: 1.4m wide, 0.04m thick, 0.08m deep per slat
  armrest: 0.06m wide, 0.25m long, 0.04m thick

LLM → cortex.research({
    hierarchy: <from step 1>,
    filled_data: { seat_plank: { dimensions: {...}, material: "oak", ... }, ... }
})

cortex → { complete: true, ready_for_recipe: true }

STEP 3: WRITE RECIPE
─────────────────────
LLM constructs recipe JSON using researched dimensions.
(See Section 4.1 for format)

STEP 4: VALIDATE
────────────────
LLM → cortex.validate({ recipe: <recipe> })
cortex → { valid: true }   // or errors to fix

STEP 5: SOLVE
─────────────
LLM → cortex.solve({ recipe: <recipe> })
cortex → {
    success: true,
    positions: {
        "seat_frame": { location: [0, 0, 0.42], dimensions: [1.5, 0.40, 0.04] },
        "backrest_frame": { location: [0, -0.18, 0.68], dimensions: [1.4, 0.03, 0.50] },
        "leg_left": { location: [-0.65, 0, 0.21], dimensions: [0.06, 0.35, 0.42] },
        ...
    },
    build_order: ["seat_frame", "leg_left", "leg_right", "backrest_frame", "armrest_left", "armrest_right"]
}

STEP 6: BUILD (in engine — cortex not involved)
────────────────────────────────────────────────
LLM → blender_mcp.execute("""
    # Build seat_frame at [0, 0, 0.42], size [1.5, 0.40, 0.04]
    bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, 0.42))
    obj = bpy.context.active_object
    obj.name = "seat_frame"
    obj.scale = (1.5, 0.40, 0.04)
    bpy.ops.object.transform_apply(scale=True)
    # ... add bevel, material, etc.
""")

STEP 7: VERIFY
──────────────
LLM → blender_mcp.execute("""
    # Query actual object data
    obj = bpy.data.objects["seat_frame"]
    print(f"location: {list(obj.location)}")
    print(f"dimensions: {list(obj.dimensions)}")
    print(f"scale: {list(obj.scale)}")
    # ... query mesh health, neighbor distances
""")

LLM → cortex.verify({
    object_name: "seat_frame",
    object_data: { location: [0, 0, 0.42], dimensions: [1.5, 0.40, 0.04], ... },
    expected: { location: [0, 0, 0.42], dimensions: [1.5, 0.40, 0.04] }
})

cortex → { pass: true, checks: [all 5 pass] }

LLM proceeds to next part in build_order.
```

### 7.2 Scene-Level Workflow

For multi-object scenes (city block, room interior, game level):

```
STEP 1: Decompose at scene level
LLM → cortex.decompose({ subject: "city block", scope: "scene" })
Returns zones: ground, buildings, street_furniture, underground_venue

STEP 2: For each zone, decompose at object level
LLM → cortex.decompose({ subject: "underground music venue", scope: "object" })
Returns parts: stairs, main_hall, stage, bar_area, walls...

STEP 3: Research all zones

STEP 4: Build individual objects using part recipes (solve per object)

STEP 5: Compose scene using scene recipe (solve_scene for positioning objects)

LLM → cortex.solve_scene({
    scene_recipe: {
        objects: { "bench_1": {...}, "bench_2": {...}, "building_A": {...}, ... },
        constraints: [
            { type: "ALONG_PATH", object: ["bench_1", "bench_2", "bench_3"],
              params: { start: [0,0,0], end: [50,0,0], spacing: 5.0 } },
            { type: "AGAINST_EDGE", object: "building_A",
              params: { edge: "+Y", zone: "street_north" } },
            ...
        ]
    }
})

STEP 6: Verify each object in final scene positions
```

### 7.3 Engine Agnostic

Cortex outputs **positions and data**. It never generates engine code.

```
Same cortex output:
  seat_frame: location [0, 0, 0.42], dimensions [1.5, 0.40, 0.04]

Blender LLM:
  bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0.42))

Unity LLM:
  GameObject.CreatePrimitive(PrimitiveType.Cube).transform.position = new Vector3(0, 0, 0.42f)

Roblox LLM:
  local part = Instance.new("Part")
  part.Position = Vector3.new(0, 0, 0.42)

Three.js LLM:
  const mesh = new THREE.Mesh(geometry, material)
  mesh.position.set(0, 0, 0.42)
```

Cortex doesn't care which engine. LLM translates.

### 7.4 Without Engine

Cortex works even without an engine MCP. Output is pure data.

Use cases:
- Planning/prototyping (get positions, review, iterate before building)
- Documentation (generate assembly instructions with exact measurements)
- Validation (check a design without building it)
- Data export (positions as JSON for any downstream tool)

---

## 8. Implementation

### 8.1 Tech Stack

- **Language:** Python 3.11+
- **MCP SDK:** `mcp` (official Python MCP SDK)
- **Transport:** stdio (standard for MCP servers)
- **Dependencies:** ZERO external deps beyond MCP SDK. Pure Python. No numpy, no engine libs.
- **Testing:** pytest

### 8.2 Project Structure

```
cortex/
├── pyproject.toml            # Package config, entry point
├── README.md                 # User-facing docs
├── src/
│   └── cortex/
│       ├── __init__.py
│       ├── __main__.py       # Entry: python -m cortex
│       ├── server.py         # MCP server setup, tool registration
│       │
│       ├── tools/            # MCP tool handlers (thin wrappers)
│       │   ├── __init__.py
│       │   ├── decompose.py  # decompose tool handler
│       │   ├── research.py   # research tool handler
│       │   ├── validate.py   # validate tool handler
│       │   ├── solve.py      # solve tool handler
│       │   ├── solve_scene.py # solve_scene tool handler
│       │   └── verify.py     # verify tool handler
│       │
│       ├── core/             # Business logic (engine-agnostic)
│       │   ├── __init__.py
│       │   ├── solver.py     # Constraint solver (THE core algorithm)
│       │   ├── scene_solver.py # Scene-level constraint solver
│       │   ├── validator.py  # Recipe validation logic
│       │   ├── verifier.py   # Verification logic (5 checks)
│       │   └── decomposer.py # Decomposition logic + templates
│       │
│       └── types.py          # Shared types: Recipe, Constraint, SolveResult, VerifyResult, etc.
│
└── tests/
    ├── __init__.py
    ├── test_solver.py         # 37 solver tests
    ├── test_scene_solver.py   # Scene solver tests
    ├── test_validator.py      # Validation tests
    ├── test_verifier.py       # Verification tests
    ├── test_decomposer.py     # Decomposition tests
    ├── test_tools.py          # MCP tool integration tests
    └── fixtures/              # Test recipes, expected outputs
        ├── bench_recipe.json
        ├── headphone_recipe.json
        └── city_scene_recipe.json
```

### 8.3 File Responsibilities

#### `server.py` — MCP Server Entry
```python
# Registers 6 tools with MCP server
# Each tool: name, description, input schema, handler function
# Transport: stdio
# No state between calls (stateless server)
```

#### `types.py` — Shared Types
```python
# All dataclasses/TypedDicts used across modules:

@dataclass
class Dimensions:
    width: float   # X-axis (meters)
    depth: float   # Y-axis (meters)
    height: float  # Z-axis (meters)

@dataclass
class PartSpec:
    name: str
    dimensions: Dimensions
    type: str = ""        # optional, for LLM tracking
    params: dict = {}     # optional, engine-specific
    metadata: dict = {}   # optional, LLM notes

@dataclass
class Constraint:
    type: str             # STACKED, CENTERED, FLUSH, OFFSET, COAXIAL, INSIDE, ALIGNED, SYMMETRIC
    part_a: str           # part being positioned
    part_b: str           # reference part
    axis: str             # X, Y, Z
    face_a: str = ""      # +X, -X, +Y, -Y, +Z, -Z
    face_b: str = ""
    offset: float = 0.0
    reference: str = ""   # top, bottom (for STACKED)

@dataclass
class Mirror:
    source: str
    target: str
    axis: str             # X, Y, X,Y etc.

@dataclass
class PartRecipe:
    name: str
    anchor: str
    anchor_position: list[float]  # [x, y, z]
    parts: dict[str, PartSpec]
    constraints: list[Constraint]
    mirrors: list[Mirror] = field(default_factory=list)
    collections: dict[str, list[str]] = field(default_factory=dict)

@dataclass
class SceneConstraint:
    type: str             # GRID, ALONG_PATH, RADIAL, etc.
    object: str | list[str]
    params: dict

@dataclass  
class SceneRecipe:
    name: str
    bounds: dict          # min, max
    objects: dict[str, PartSpec]
    zones: dict = field(default_factory=dict)
    constraints: list[SceneConstraint] = field(default_factory=list)

@dataclass
class SolveResult:
    success: bool
    positions: dict[str, dict] = field(default_factory=dict)   # name → {location, dimensions}
    build_order: list[str] = field(default_factory=list)
    conflicts: list[dict] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    error: str = ""

@dataclass
class VerifyCheck:
    name: str             # mesh_health, identity, placement, connection, dimensions
    passed: bool
    details: str
    severity: str         # critical, warning, info

@dataclass
class VerifyResult:
    object_name: str
    passed: bool          # true only if ALL checks pass
    checks: list[VerifyCheck]
    summary: str
```

#### `core/solver.py` — The Heart
```python
# Implements:
# - solve(recipe: PartRecipe) → SolveResult
# - resolve_constraint(constraint, a_dims, b_pos, b_dims) → list[(axis_index, value)]
# - topological_sort(constraints, anchor) → list[str]
# - get_half_dim(dims, axis) → float
#
# This is the PROVEN algorithm from Section 5.
# 37 tests must pass. Zero tolerance for regression.
#
# ~300-400 lines of Python.
```

#### `core/scene_solver.py` — Scene Positioning
```python
# Implements:
# - solve_scene(scene_recipe: SceneRecipe) → SolveResult
# - resolve_grid(objects, params) → dict[str, position]
# - resolve_along_path(objects, params) → dict[str, position]
# - resolve_radial(objects, params) → dict[str, position]
# - resolve_facing(object, params) → rotation
# - resolve_against_edge(object, params, zone) → position
# - resolve_random_scatter(objects, params, zone) → dict[str, position]
# - resolve_stack_vertical(objects, params) → dict[str, position]
# - resolve_mirror_scene(objects, targets, params) → dict[str, position]
#
# Each scene constraint type has its own resolver.
# Math is simpler than part solver but still must be exact.
#
# ~400-500 lines of Python.
```

#### `core/validator.py` — Recipe Checking
```python
# Implements:
# - validate_recipe(recipe: PartRecipe) → ValidationResult
# - validate_scene_recipe(recipe: SceneRecipe) → ValidationResult
#
# The 10 checks from Section 3.3.
# Returns list of errors (blocking) and warnings (non-blocking).
#
# ~200-300 lines of Python.
```

#### `core/verifier.py` — Build Checking
```python
# Implements:
# - verify(object_name, object_data, expected) → VerifyResult
# - check_mesh_health(object_data) → VerifyCheck
# - check_identity(object_data) → VerifyCheck
# - check_placement(object_data, expected) → VerifyCheck
# - check_connection(object_data) → VerifyCheck
# - check_dimensions(object_data, expected) → VerifyCheck
#
# The 5 checks from Section 6.
# Pure comparison logic — no engine calls.
# LLM provides the actual data, verifier just checks it.
#
# ~200-300 lines of Python.
```

#### `core/decomposer.py` — Structured Thinking
```python
# Implements:
# - decompose(subject, variant, scope, detail_level) → DecomposeResult
#
# This module has TWO strategies:
#
# Strategy 1: Template matching
#   Common objects have decomposition templates:
#   "chair" → seat, backrest, legs, armrests
#   "table" → top, legs, frame
#   "headphone" → headband, earcups, cushions, hinges, cable
#   Templates are STARTING POINTS, not exhaustive databases.
#   ~50-100 common object templates.
#
# Strategy 2: Generic decomposition
#   For objects not in templates, return a FRAMEWORK:
#   "What are the major structural parts?"
#   "What are the connection points?"
#   "What are the surface detail parts?"
#   LLM fills in the framework using its own knowledge.
#
# The key output is research_required — the checklist that gates progress.
#
# ~300-400 lines of Python.
```

### 8.4 MCP Server Configuration

```json
{
  "mcpServers": {
    "cortex": {
      "command": "python",
      "args": ["-m", "cortex"],
      "env": {}
    }
  }
}
```

Or with `uv`:
```json
{
  "mcpServers": {
    "cortex": {
      "command": "uvx",
      "args": ["cortex"]
    }
  }
}
```

### 8.5 Testing Strategy

**Priority 1: Solver tests (37 tests)**
- These are the foundation. If solver is wrong, everything is wrong.
- Test every constraint type individually
- Test combinations, conflicts, cycles, mirrors, edge cases
- EXACT numerical assertions (not "approximately")

**Priority 2: Validator tests (~15 tests)**
- Valid recipe → passes
- Each error type → caught with correct error message
- Circular dependency → detected
- Missing fields → caught

**Priority 3: Verifier tests (~15 tests)**
- All 5 checks: pass case + fail case
- Tolerance boundaries (exactly at tolerance, slightly over)
- Multiple failures in one object
- Connection check with various distances

**Priority 4: Scene solver tests (~15 tests)**
- Each scene constraint type
- Combined constraints
- Edge cases (zero spacing, single object, etc.)

**Priority 5: Decomposer tests (~10 tests)**
- Template objects decompose correctly
- Unknown objects get generic framework
- Research checklist is complete
- Detail levels produce different depths

**Priority 6: Integration tests (~5 tests)**
- Full pipeline: decompose → research → validate → solve → verify
- MCP tool registration works
- JSON-RPC request/response format correct

**Total: ~97 tests**

### 8.6 Implementation Order

Build in this order. Each step must be complete and tested before the next.

```
Phase 1: Types + Solver (core value)
  1. types.py — all dataclasses
  2. core/solver.py — constraint solver
  3. tests/test_solver.py — 37 tests, ALL MUST PASS
  
Phase 2: Validator + Verifier (safety net)
  4. core/validator.py — recipe validation
  5. tests/test_validator.py
  6. core/verifier.py — 5-check verification
  7. tests/test_verifier.py

Phase 3: Scene Solver (scene support)
  8. core/scene_solver.py — scene constraint resolver
  9. tests/test_scene_solver.py

Phase 4: Decomposer (methodology enforcement)
  10. core/decomposer.py — decomposition + research gate
  11. tests/test_decomposer.py

Phase 5: MCP Server (transport layer)
  12. server.py — MCP registration
  13. tools/*.py — tool handlers (thin wrappers)
  14. __main__.py — entry point
  15. tests/test_tools.py — integration tests

Phase 6: Package
  16. pyproject.toml
  17. README.md
```

### 8.7 `pyproject.toml`

```toml
[project]
name = "cortex"
version = "3.0.0"
description = "Universal build intelligence for LLMs — methodology enforcer for spatial assembly"
requires-python = ">=3.11"
dependencies = [
    "mcp",
]

[project.scripts]
cortex = "cortex:main"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/cortex"]

[tool.pytest.ini_options]
testpaths = ["tests"]
```

---

## Appendix A: Full Recipe Example — ATH-M50x Headphone

This recipe was tested end-to-end with the proven solver. 37/37 tests passed. All positions mathematically verified.

```json
{
  "name": "ATH-M50x Studio Headphone",
  "anchor": "headband_frame",
  "anchor_position": [0, 0, 0.18],
  "collections": {
    "Headband": ["headband_frame", "headband_cushion", "headband_cover_L", "headband_cover_R"],
    "Left Ear": ["slider_L", "hinge_L", "earcup_shell_L", "earcup_baffle_L", "cushion_ring_L", "cushion_pad_L", "driver_grille_L"],
    "Right Ear": ["slider_R", "hinge_R", "earcup_shell_R", "earcup_baffle_R", "cushion_ring_R", "cushion_pad_R", "driver_grille_R"],
    "Cable": ["cable_entry", "cable_strain_relief"]
  },
  "parts": {
    "headband_frame": {
      "dimensions": { "width": 0.185, "depth": 0.03, "height": 0.015 },
      "type": "curved_band",
      "metadata": { "material": "steel core, plastic cover", "edge_treatment": "2mm fillet" }
    },
    "headband_cushion": {
      "dimensions": { "width": 0.15, "depth": 0.035, "height": 0.012 },
      "type": "padded_strip",
      "metadata": { "material": "leatherette over foam" }
    },
    "slider_L": {
      "dimensions": { "width": 0.015, "depth": 0.025, "height": 0.06 },
      "type": "rectangular_tube",
      "metadata": { "material": "plastic, matte black" }
    },
    "hinge_L": {
      "dimensions": { "width": 0.03, "depth": 0.02, "height": 0.025 },
      "type": "hinge_block",
      "metadata": { "material": "metal, brushed" }
    },
    "earcup_shell_L": {
      "dimensions": { "width": 0.09, "depth": 0.065, "height": 0.09 },
      "type": "oval_shell",
      "metadata": { "material": "ABS plastic, matte black", "wall_thickness": 0.003 }
    },
    "earcup_baffle_L": {
      "dimensions": { "width": 0.085, "depth": 0.005, "height": 0.085 },
      "type": "flat_disc",
      "metadata": { "material": "ABS plastic" }
    },
    "cushion_ring_L": {
      "dimensions": { "width": 0.095, "depth": 0.025, "height": 0.095 },
      "type": "oval_ring",
      "metadata": { "material": "leatherette, protein leather" }
    },
    "cushion_pad_L": {
      "dimensions": { "width": 0.085, "depth": 0.02, "height": 0.085 },
      "type": "oval_pad",
      "metadata": { "material": "memory foam, leatherette cover" }
    },
    "driver_grille_L": {
      "dimensions": { "width": 0.045, "depth": 0.003, "height": 0.045 },
      "type": "perforated_disc",
      "metadata": { "material": "metal mesh" }
    },
    "cable_entry": {
      "dimensions": { "width": 0.008, "depth": 0.008, "height": 0.015 },
      "type": "cylinder",
      "metadata": { "material": "plastic, strain relief" }
    }
  },
  "constraints": [
    { "type": "STACKED", "part_a": "headband_cushion", "part_b": "headband_frame", "axis": "Z", "reference": "bottom" },
    { "type": "CENTERED", "part_a": "headband_cushion", "part_b": "headband_frame", "axis": "X" },
    { "type": "CENTERED", "part_a": "headband_cushion", "part_b": "headband_frame", "axis": "Y" },

    { "type": "STACKED", "part_a": "slider_L", "part_b": "headband_frame", "axis": "Z", "reference": "bottom" },
    { "type": "FLUSH", "part_a": "slider_L", "part_b": "headband_frame", "axis": "X", "face_a": "+X", "face_b": "-X" },
    { "type": "CENTERED", "part_a": "slider_L", "part_b": "headband_frame", "axis": "Y" },

    { "type": "STACKED", "part_a": "hinge_L", "part_b": "slider_L", "axis": "Z", "reference": "bottom" },
    { "type": "CENTERED", "part_a": "hinge_L", "part_b": "slider_L", "axis": "X" },
    { "type": "CENTERED", "part_a": "hinge_L", "part_b": "slider_L", "axis": "Y" },

    { "type": "STACKED", "part_a": "earcup_shell_L", "part_b": "hinge_L", "axis": "Z", "reference": "bottom" },
    { "type": "CENTERED", "part_a": "earcup_shell_L", "part_b": "hinge_L", "axis": "X" },
    { "type": "CENTERED", "part_a": "earcup_shell_L", "part_b": "hinge_L", "axis": "Y" },

    { "type": "INSIDE", "part_a": "earcup_baffle_L", "part_b": "earcup_shell_L", "axis": "X" },
    { "type": "INSIDE", "part_a": "earcup_baffle_L", "part_b": "earcup_shell_L", "axis": "Z" },
    { "type": "FLUSH", "part_a": "earcup_baffle_L", "part_b": "earcup_shell_L", "axis": "Y", "face_a": "-Y", "face_b": "-Y" },

    { "type": "COAXIAL", "part_a": "cushion_ring_L", "part_b": "earcup_shell_L", "axis": "Y" },
    { "type": "FLUSH", "part_a": "cushion_ring_L", "part_b": "earcup_shell_L", "axis": "Y", "face_a": "+Y", "face_b": "+Y" },

    { "type": "COAXIAL", "part_a": "cushion_pad_L", "part_b": "earcup_shell_L", "axis": "Y" },
    { "type": "FLUSH", "part_a": "cushion_pad_L", "part_b": "cushion_ring_L", "axis": "Y", "face_a": "+Y", "face_b": "+Y" },

    { "type": "COAXIAL", "part_a": "driver_grille_L", "part_b": "earcup_shell_L", "axis": "Y" },
    { "type": "FLUSH", "part_a": "driver_grille_L", "part_b": "earcup_baffle_L", "axis": "Y", "face_a": "+Y", "face_b": "+Y" },

    { "type": "STACKED", "part_a": "cable_entry", "part_b": "earcup_shell_L", "axis": "Z", "reference": "bottom" },
    { "type": "CENTERED", "part_a": "cable_entry", "part_b": "earcup_shell_L", "axis": "X" },
    { "type": "CENTERED", "part_a": "cable_entry", "part_b": "earcup_shell_L", "axis": "Y" }
  ],
  "mirrors": [
    { "source": "slider_L", "target": "slider_R", "axis": "X" },
    { "source": "hinge_L", "target": "hinge_R", "axis": "X" },
    { "source": "earcup_shell_L", "target": "earcup_shell_R", "axis": "X" },
    { "source": "earcup_baffle_L", "target": "earcup_baffle_R", "axis": "X" },
    { "source": "cushion_ring_L", "target": "cushion_ring_R", "axis": "X" },
    { "source": "cushion_pad_L", "target": "cushion_pad_R", "axis": "X" },
    { "source": "driver_grille_L", "target": "driver_grille_R", "axis": "X" }
  ]
}
```

---

## Appendix B: Scene Recipe Example — City Block

```json
{
  "name": "Small City Block",
  "bounds": {
    "min": [-30, -30, 0],
    "max": [30, 30, 20]
  },
  "objects": {
    "ground": { "dimensions": { "width": 60, "depth": 60, "height": 0.1 } },
    "road_NS": { "dimensions": { "width": 8, "depth": 60, "height": 0.05 } },
    "road_EW": { "dimensions": { "width": 60, "depth": 8, "height": 0.05 } },
    "building_A": { "dimensions": { "width": 12, "depth": 10, "height": 15 } },
    "building_B": { "dimensions": { "width": 8, "depth": 12, "height": 10 } },
    "building_C": { "dimensions": { "width": 10, "depth": 10, "height": 12 } },
    "bench_1": { "dimensions": { "width": 1.5, "depth": 0.5, "height": 0.8 } },
    "bench_2": { "dimensions": { "width": 1.5, "depth": 0.5, "height": 0.8 } },
    "bench_3": { "dimensions": { "width": 1.5, "depth": 0.5, "height": 0.8 } },
    "bench_4": { "dimensions": { "width": 1.5, "depth": 0.5, "height": 0.8 } },
    "lamp_1": { "dimensions": { "width": 0.3, "depth": 0.3, "height": 3.5 } },
    "lamp_2": { "dimensions": { "width": 0.3, "depth": 0.3, "height": 3.5 } },
    "lamp_3": { "dimensions": { "width": 0.3, "depth": 0.3, "height": 3.5 } },
    "lamp_4": { "dimensions": { "width": 0.3, "depth": 0.3, "height": 3.5 } },
    "tree_1": { "dimensions": { "width": 4, "depth": 4, "height": 6 } },
    "tree_2": { "dimensions": { "width": 4, "depth": 4, "height": 6 } },
    "tree_3": { "dimensions": { "width": 4, "depth": 4, "height": 6 } },
    "venue_entrance": { "dimensions": { "width": 4, "depth": 3, "height": 3 } }
  },
  "zones": {
    "street_NS": { "bounds": { "min": [-4, -30, 0], "max": [4, 30, 0] } },
    "street_EW": { "bounds": { "min": [-30, -4, 0], "max": [30, 4, 0] } },
    "block_NE": { "bounds": { "min": [5, 5, 0], "max": [28, 28, 20] } },
    "block_NW": { "bounds": { "min": [-28, 5, 0], "max": [-5, 28, 20] } },
    "block_SE": { "bounds": { "min": [5, -28, 0], "max": [28, -5, 20] } },
    "park_center": { "bounds": { "min": [-10, -10, 0], "max": [10, 10, 0] } }
  },
  "constraints": [
    { "type": "GRID", "object": ["building_A", "building_B", "building_C"],
      "params": { "origin": [15, 15, 0], "rows": 1, "cols": 3, "spacing_x": 14, "spacing_y": 0, "align_bottom": true } },

    { "type": "ALONG_PATH", "object": ["bench_1", "bench_2", "bench_3", "bench_4"],
      "params": { "start": [5, 0, 0], "end": [25, 0, 0], "spacing": 6.0, "offset_lateral": 1.5 } },

    { "type": "ALONG_PATH", "object": ["lamp_1", "lamp_2", "lamp_3", "lamp_4"],
      "params": { "start": [5, 0, 0], "end": [25, 0, 0], "spacing": 6.0, "offset_lateral": -1.5 } },

    { "type": "FACING", "object": "bench_1", "params": { "target": [0, 0, 0] } },
    { "type": "FACING", "object": "bench_2", "params": { "target": [0, 0, 0] } },
    { "type": "FACING", "object": "bench_3", "params": { "target": [0, 0, 0] } },
    { "type": "FACING", "object": "bench_4", "params": { "target": [0, 0, 0] } },

    { "type": "RANDOM_SCATTER", "object": ["tree_1", "tree_2", "tree_3"],
      "params": { "zone": "park_center", "min_spacing": 5.0, "seed": 42 } },

    { "type": "STACK_VERTICAL", "object": ["venue_entrance"],
      "params": { "base_position": [0, 0, -3], "gap": 0 } }
  ]
}
```

---

*End of architecture document. This is everything needed to implement Cortex from scratch.*
*6 tools. ~1500-2000 lines of Python. Universal build intelligence.*
