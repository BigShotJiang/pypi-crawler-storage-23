"""
Package to handle data redction at AMOR instrument to be used by __main__.py script.
"""

__version__ = '3.1.0'
__date__    = '2026-02-20'
