function a = clean_function()

a = '';

end
