function invalid_char
#
end
