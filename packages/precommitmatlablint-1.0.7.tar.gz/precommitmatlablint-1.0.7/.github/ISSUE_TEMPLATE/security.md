---
name: "🔒 Security issue"
about: Security issue
title: ''
labels: 'kind: security 🔒'
assignees: ''
---

<!--
    Fill out any relevant fields:
-->

- **Project version:** ...
- **OS/platform:** ...
