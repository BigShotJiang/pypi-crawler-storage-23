---
name: "🐛 Bug"
about: Bug report
title: ''
labels: 'kind: bug'
assignees: ''
---

<!--
    Fill out any relevant fields:
-->

- **Project version:** ...
- **OS/platform:** ...
