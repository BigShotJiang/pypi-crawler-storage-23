---
name: "🐢 Performance"
about: Performance issue
title: ''
labels: 'kind: performance'
assignees: ''
---

<!--
    Fill out any relevant fields:
-->

- **Project version:** ...
- **OS/platform:** ...
