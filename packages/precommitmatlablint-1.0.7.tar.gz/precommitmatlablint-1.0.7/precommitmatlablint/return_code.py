from enum import IntEnum


class ReturnCode(IntEnum):
    OK = 0
    FAIL = 1
