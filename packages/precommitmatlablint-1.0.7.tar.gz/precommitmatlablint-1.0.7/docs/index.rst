Pre-commit-matlab-lint
====================================

.. toctree::
    :maxdepth: 1

Pre-commit-matlab-lint is under the terms of the `MIT License <https://spdx.org/licenses/MIT.html>`_.
