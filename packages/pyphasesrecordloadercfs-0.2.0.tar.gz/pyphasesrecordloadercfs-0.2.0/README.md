# Extension for pyPhasesRecordloader

Extension to load data records from the Multi-Ethnic Study of Atherosclerosis (CFS) database.

The extensions requires a downloaded version of the CFS dataset. The location can be set through the config value `cfs-path`.

## Usage

In a phase you can acess the data through the `RecordLoader`:

Add the plugins and config values to your `project.yaml`:

```yaml
name: MyProject
plugins:
  - pyPhasesML
  - pyPhasesRecordloaderCFS
  - pyPhasesRecordloader

phases:
  - name: MyPhase

config:
  cfs-path: C:/datasets/cfs

```

In a phase (`phases/MyPhase.py`) you can acess the records through the `RecordLoader`:

```python
from pyPhasesRecordloader import RecordLoader
from pyPhases import Phase

class MyPhase(Phase):
    def run(self):
      recordIds = recordLoader.getRecordList()
      for recordId in recordIds:
        record = recordLoader.getRecord(recordId)
```

Run Your project with `python -m phases run MyPhase`