from pyPhasesRecordloader.recordLoaders.CSVMetaLoader import CSVMetaLoader
from pyPhasesRecordloaderSHHS.recordLoaders.RecordLoaderSHHS import RecordLoaderSHHS

from pyPhasesRecordloaderCFS.recordLoaders.CFSAnnotationLoader import CFSAnnotationLoader


class RecordLoaderCFS(RecordLoaderSHHS):
    def getFilePathSignal(self, recordId):
        return f"{self.filePath}/polysomnography/edfs/{recordId}.edf"

    def getFilePathAnnotation(self, recordId):
        return f"{self.filePath}/polysomnography/annotations-events-nsrr/{recordId}-nsrr.xml"

    def getRelevantCols(self):
        return {
            # "gender": "gender1",
            # "age": "sleepage5c",
            "sLatency": "slp_lat5",
            "rLatency": "rem_lat15",
            "waso": "waso",
            "sEfficiency": "slp_eff5",
            # "indexPlms": "avgplm5",
            # "indexPlmsArousal": "avgplma5",
            # for countArousal
            # "arnrembp5": "arnrembp5",
            # "arnremop5": "arnremop5",
            # "arrembp5": "arrembp5",
            # "arremop5": "arremop5",
            # therapy / diagnostics
            # % N1, N2, N3, R
            # not existing
            #"bmi
        }
    
    def getHarmonizedCols(self):
        return {
            "age": "nsrr_age",
            "gender": "nsrr_sex",
            "tst": "nsrr_ttldursp_f1",
            "ahi": "nsrr_ahi_hp4r",
            "indexArousal": "nsrr_phrnumar_f1",
            "race": "nsrr_race",
            "nsrr_bmi": "nsrr_bmi",
            "bp_diastolic": "nsrr_bp_diastolic",
            "bp_systolic": "nsrr_bp_systolic",
            "countPLM": "noplm",
            # "sbp": "nsrr_sbp",
        }
    
    def getMetaData(self, recordName):
        metaData = super().getMetaData(recordName, loadMetadataFromCSV=False)
        metaData["recordId"] = recordName
        harmonizedColumns = self.getHarmonizedCols()
        relevantColumns = self.getRelevantCols()
        csvLoader = CSVMetaLoader(
            f"{self.filePath}/datasets/cfs-visit5-dataset-0.7.0.csv", idColumn="nsrrid", relevantRows=relevantColumns
        )
        csvMetaData = csvLoader.getMetaData(int(recordName[11:]))
        metaData.update(csvMetaData)
        
        csvLoader = CSVMetaLoader(
            f"{self.filePath}/datasets/cfs-visit5-harmonized-dataset-0.7.0.csv", idColumn="nsrrid", relevantRows=harmonizedColumns
        )
        csvMetaData = csvLoader.getMetaData(int(recordName[11:]))
        metaData.update(csvMetaData)

        return metaData

    def getAllMetaData(self):
        harmonizedColumns = self.getHarmonizedCols()
        relevantCols = self.getRelevantCols()

        csvLoader = CSVMetaLoader(
            f"{self.filePath}/datasets/cfs-visit5-dataset-0.7.0.csv", idColumn="nsrrid", relevantRows=relevantCols
        )
        metaData = csvLoader.getAllMetaData()
        csvLoader = CSVMetaLoader(
            f"{self.filePath}/datasets/cfs-visit5-harmonized-dataset-0.7.0.csv", idColumn="nsrrid", relevantRows=harmonizedColumns
        )
        # merge pandas frames
        csvMetaData = csvLoader.getAllMetaData()
        metaData = metaData.merge(csvMetaData, on="recordId")

        #padded record id
        metaData["recordId"] = metaData["recordId"].apply(lambda x: "cfs-sleep-" + str(x).zfill(4))
        return metaData
        
        
    def getEventList(self, recordName, targetFrequency=1):
        metaXML = self.getFilePathAnnotation(recordName)
        xmlLoader = CFSAnnotationLoader()

        eventArray = xmlLoader.loadAnnotation(metaXML)
        self.lightOff = xmlLoader.lightOff
        self.lightOn = xmlLoader.lightOn

        if targetFrequency != 1:
            eventArray = self.updateFrequencyForEventList(eventArray, targetFrequency)

        return eventArray

    def getSubjectId(self, recordId):
        return recordId.split("-")[2]