from pathlib import Path
from pyPhases import PluginAdapter
from pyPhasesRecordloader import RecordLoader


class Plugin(PluginAdapter):
    defaultConfig = "config.yaml"

    def initPlugin(self):
        RecordLoader.registerRecordLoader("RecordLoaderCFS", "pyPhasesRecordloaderCFS.recordLoaders")
        RecordLoader.registerRecordLoader("CFSAnnotationLoader", "pyPhasesRecordloaderCFS.recordLoaders")
        cfsPath = Path(self.getConfig("cfs-path"))

        self.project.setConfig("loader.cfs.filePath", cfsPath.as_posix())
        self.project.setConfig("loader.cfs.dataset.downloader.basePath", cfsPath.as_posix())
        self.project.setConfig(
            "loader.cfs.dataset.downloader.basePathExtensionwise",
            [
                (cfsPath / "polysomnography/edfs/").as_posix(),
                (cfsPath / "polysomnography/annotations-events-nsrr/").as_posix(),
            ],
        )
