from .QTextEditLogger import *
