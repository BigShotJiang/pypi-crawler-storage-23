from .inputDialog import InputDialog
from .window_info_gui import get_window_info
