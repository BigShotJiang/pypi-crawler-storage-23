from abstract_utilities import get_abstract_import
define_defaults = get_abstract_import(
    module='abstract_paths',
    symbol='define_defaults')
get_files_and_dirs = get_abstract_import(
    module='abstract_paths',
    symbol='get_files_and_dirs')


