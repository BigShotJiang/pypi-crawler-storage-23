"""Fetch2Gmail: IMAP to Gmail API import with idempotent state tracking."""

from importlib.metadata import version
__version__ = version("fetch2gmail")
