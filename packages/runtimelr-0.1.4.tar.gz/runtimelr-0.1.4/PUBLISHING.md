# PyPI publishing prep (runtimelr)

## 1) Ensure package name is available

Check https://pypi.org/project/runtimelr/ (or run `pip index versions runtimelr`).

## 2) Configure Trusted Publisher (recommended)

In PyPI:
- Create project `runtimelr` (or claim existing if you own it)
- Go to Project Settings -> Publishing -> Add Publisher
- Provider: GitHub
- Owner: `thb-bici`
- Repository: `runtimelr`
- Workflow name: `publish-pypi.yml`
- Environment name: `pypi`

No API token needed with trusted publishing.

## 3) GitHub repo settings

In GitHub repo `thb-bici/runtimelr`:
- Ensure Actions are enabled
- Create environment `pypi` (optional protection rules if desired)

## 4) Release flow

- Bump `version` in `pyproject.toml` and `src/runtimelr/__init__.py`
- Commit + push to main
- Create a GitHub Release (published)
- Workflow `publish-pypi.yml` builds and uploads to PyPI

## 5) Local verification (optional)

```bash
python -m pip install --upgrade pip
pip install build twine
python -m build
twine check dist/*
```
