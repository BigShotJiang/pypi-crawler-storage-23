from __future__ import annotations

import json
import shutil
import time
import uuid
from pathlib import Path
from typing import Any


class CommandQueue:
    def __init__(self, queue_dir: str | Path):
        self.queue_dir = Path(queue_dir)
        self.processed_dir = self.queue_dir / "processed"
        self.queue_dir.mkdir(parents=True, exist_ok=True)
        self.processed_dir.mkdir(parents=True, exist_ok=True)

    def _command_files(self) -> list[Path]:
        return sorted(
            [p for p in self.queue_dir.glob("*.json") if p.is_file()],
            key=lambda p: p.name,
        )

    def pop_all(self) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        for p in self._command_files():
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    items.append(data)
            finally:
                stamp = int(time.time() * 1000)
                dst = self.processed_dir / f"{stamp}-{uuid.uuid4().hex}-{p.name}"
                try:
                    shutil.move(str(p), str(dst))
                except Exception:
                    try:
                        p.unlink(missing_ok=True)
                    except Exception:
                        pass
        return items


def normalize_command(raw: dict[str, Any]) -> tuple[str, float]:
    if not isinstance(raw, dict):
        raise ValueError("Command must be a JSON object")

    version = raw.get("version", 1)
    if version != 1:
        raise ValueError(f"Unsupported command version: {version}")

    kind = str(raw.get("kind", "")).strip()

    # Required names going forward
    if kind == "set_lr_scale":
        pass
    elif kind in {"mult_lr_scale", "mul_lr_scale"}:
        # support old mul spelling as backward-compatible alias
        kind = "mult_lr_scale"
    else:
        raise ValueError(f"Unsupported command kind: {kind}")

    if "value" not in raw:
        raise ValueError("Missing 'value'")
    value = float(raw["value"])
    return kind, value
