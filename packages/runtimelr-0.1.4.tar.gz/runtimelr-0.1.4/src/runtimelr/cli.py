from __future__ import annotations

import argparse
import json
import time
import uuid
from pathlib import Path


def _emit(run_dir: Path, kind: str, value: float):
    run_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": 1,
        "kind": kind,
        "value": float(value),
    }
    ts = int(time.time() * 1000)
    name = f"{ts:013d}-{uuid.uuid4().hex}.json"
    path = run_dir / name
    path.write_text(json.dumps(payload), encoding="utf-8")
    print(path)


def main():
    parser = argparse.ArgumentParser(prog="runtimelr", description="Emit runtime LR queue commands")
    parser.add_argument("--queue_dir", required=True, help="Queue directory watched by ControlledLambdaLR")

    sub = parser.add_subparsers(dest="cmd", required=True)

    p_set = sub.add_parser("set_lr_scale", help="Set absolute lr scale")
    p_set.add_argument("value", type=float)

    p_mult = sub.add_parser("mult_lr_scale", help="Multiply lr scale")
    p_mult.add_argument("value", type=float)

    args = parser.parse_args()
    queue_dir = Path(args.queue_dir)

    if args.cmd == "set_lr_scale":
        _emit(queue_dir, "set_lr_scale", args.value)
    elif args.cmd == "mult_lr_scale":
        _emit(queue_dir, "mult_lr_scale", args.value)


if __name__ == "__main__":
    main()
