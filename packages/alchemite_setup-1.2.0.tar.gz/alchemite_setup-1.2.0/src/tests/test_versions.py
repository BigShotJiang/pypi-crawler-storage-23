import pytest
import requests

from alchemite_setup.versions import (
    VERSION_SANITIZERS,
    VersionMap,
    fetch_versions,
    load_versions,
    save_versions,
)


@pytest.mark.parametrize("oligo", [True, False])
def test_fetch_latest(oligo) -> None:
    versions = fetch_versions(oligo_enabled=oligo)
    assert len(versions) == len(VERSION_SANITIZERS) + oligo
    for chart, version in versions.items():
        if version.canonical_url == "":
            assert chart == "cert-manager"
        else:
            data = requests.get(version.canonical_url).json()
            assert version == VersionMap(
                app_version=data["imageTag"],
                chart_version=data["helmTag"],
                canonical_url=data["canonicalUrl"],
            )


@pytest.mark.parametrize(
    "version_map",
    [
        pytest.param(
            {
                "alchemite-api": "v0.129.0",
                "alchemite-users": "1.8.1",
                "smiles-extension": "v3.0.1",
                "alchemite-ui": "2025.12.03T10.03.19",
                "alchemite-admin": "2025.12.03T10.03.19",
            },
            id="correct",
        ),
        pytest.param(
            {
                "alchemite-api": "v0.129.0",
                "alchemite-users": "v1.8.1",
                "smiles-extension": "v3.0.1",
                "alchemite-ui": "2025.12.03T10.03.19",
                "alchemite-admin": "2025.12.03T10.03.19",
            },
            id="allv",
        ),
        pytest.param(
            {
                "alchemite-api": "0.129.0",
                "alchemite-users": "1.8.1",
                "smiles-extension": "3.0.1",
                "alchemite-ui": "2025.12.03T10.03.19",
                "alchemite-admin": "2025.12.03T10.03.19",
            },
            id="nov",
        ),
    ],
)
def test_fetch_specific(version_map, testing_versions) -> None:
    versions = fetch_versions(version_map)
    assert len(versions) == len(VERSION_SANITIZERS)
    for chart, version in versions.items():
        assert version == testing_versions[chart]


def test_version_roundtrip(output_path, testing_versions) -> None:
    save_versions(output_path, testing_versions)
    assert load_versions(output_path) == testing_versions
