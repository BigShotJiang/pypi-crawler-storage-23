import shutil
from pathlib import Path

import pytest
from docker import DockerClient
from pyhelm3 import Chart, ChartDependency

from alchemite_setup.helm import ChartMetadataPatched, ChartPatched
from alchemite_setup.images import (
    Image,
    create_pinned_image_values,
    get_image_paths,
    get_pull_secrets,
    migrate_to_repo,
    parse_values_for_images,
)
from alchemite_setup.versions import VersionMap


@pytest.fixture()
def path_info(output_path: Path, data_path: Path) -> dict[str, Path]:
    reference = output_path / "reference"

    shutil.copytree(data_path / "reference", reference)

    return {
        "__root__": reference / "api-values-base.yaml",
        "ingress-nginx": reference
        / "api-values-base_subchart_ingress-nginx.yaml",
        "keycloakx": reference / "api-values-base_subchart_keycloakx.yaml",
        "opensearch": reference / "api-values-base_subchart_opensearch.yaml",
    }


@pytest.fixture()
def testing_helm_charts() -> dict[str, dict[str, ChartPatched]]:
    return {
        "cert-manager": {
            "__root__": ChartPatched(
                _command=None,
                ref="cert-manager",
                repo=None,
                metadata=ChartMetadataPatched(
                    apiVersion="v2",
                    name="cert-manager",
                    version="v1.18.4",
                    kubeVersion=">= 1.22.0-0",
                    description="A Helm chart for cert-manager",
                    type="application",
                    home="https://cert-manager.io/",
                    icon="https://raw.githubusercontent.com/cert-manager/community/4d35a69437d21b76322157e6284be4cd64e6d2b7/logo/logo-small.png",
                    appVersion="v1.18.4",
                    deprecated=False,
                ),
            )
        },
        "alchemite-api": {
            "__root__": ChartPatched(
                _command=None,
                ref="alchemite-api",
                repo=None,
                metadata=ChartMetadataPatched(
                    apiVersion="v2",
                    name="alchemite-api",
                    version="6.9.1-post1",
                    kubeVersion=None,
                    description=None,
                    type="application",
                    home=None,
                    dependencies=[
                        ChartDependency(
                            name="ingress-nginx",
                            version="4.13.3",
                            repository="https://kubernetes.github.io/ingress-nginx",
                            condition="ingress-nginx.enabled",
                            alias=None,
                        ),
                        ChartDependency(
                            name="keycloakx",
                            version="7.1.4",
                            repository="https://codecentric.github.io/helm-charts",
                            condition="keycloak.enabled",
                            alias="keycloak",
                        ),
                        ChartDependency(
                            name="opensearch",
                            version="2.35.1",
                            repository="https://opensearch-project.github.io/helm-charts/",
                            condition="opensearch.enabled",
                            alias=None,
                        ),
                    ],
                    icon="https://intellegens.com/wp-content/uploads/2019/11/cropped-intellegens-icon-logo-1-192x192.png",
                    appVersion=None,
                    deprecated=False,
                ),
            ),
            "ingress-nginx": ChartPatched(
                _command=None,
                ref="ingress-nginx",
                repo=None,
                metadata=ChartMetadataPatched(
                    apiVersion="v2",
                    name="ingress-nginx",
                    version="4.13.3",
                    kubeVersion=">=1.21.0-0",
                    description="Ingress controller for Kubernetes using NGINX as a reverse proxy and load balancer",
                    type="application",
                    home="https://github.com/kubernetes/ingress-nginx",
                    icon="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Nginx_logo.svg/500px-Nginx_logo.svg.png",
                    appVersion="1.13.3",
                    deprecated=False,
                ),
            ),
            "keycloakx": ChartPatched(
                _command=None,
                ref="keycloakx",
                repo=None,
                metadata=ChartMetadataPatched(
                    apiVersion="v2",
                    name="keycloakx",
                    version="7.1.4",
                    kubeVersion=None,
                    description="Keycloak.X - Open Source Identity and Access Management for Modern Applications and Services",
                    type="application",
                    home="https://www.keycloak.org/",
                    icon="https://www.keycloak.org/resources/images/keycloak_logo_200px.svg",
                    appVersion="26.4.0",
                    deprecated=False,
                ),
            ),
            "opensearch": ChartPatched(
                _command=None,
                ref="opensearch",
                repo=None,
                metadata=ChartMetadataPatched(
                    apiVersion="v2",
                    name="opensearch",
                    version="2.35.1",
                    kubeVersion=None,
                    description="A Helm chart for OpenSearch",
                    type="application",
                    home="https://opensearch.org/",
                    icon=None,
                    appVersion="2.19.3",
                    deprecated=False,
                ),
            ),
        },
        "alchemite-users": {
            "__root__": ChartPatched(
                _command=None,
                ref="alchemite-users-chart",
                repo=None,
                metadata=ChartMetadataPatched(
                    apiVersion="v2",
                    name="alchemite-users-chart",
                    version="1.2.12",
                    kubeVersion=None,
                    description="A Helm chart for the Alchemite User Management platform",
                    type="application",
                    home=None,
                    icon=None,
                    appVersion=None,
                    deprecated=False,
                ),
            )
        },
        "smiles-extension": {
            "__root__": ChartPatched(
                _command=None,
                ref="smiles_extension",
                repo=None,
                metadata=ChartMetadataPatched(
                    apiVersion="v2",
                    name="smiles_extension",
                    version="1.2.0",
                    kubeVersion=None,
                    description="A Helm chart to deploy the smiles_extension",
                    type="application",
                    home=None,
                    icon=None,
                    appVersion=None,
                    deprecated=False,
                ),
            )
        },
        "alchemite-ui": {
            "__root__": ChartPatched(
                _command=None,
                ref="alchemite-ui",
                repo=None,
                metadata=ChartMetadataPatched(
                    apiVersion="v2",
                    name="alchemite-ui",
                    version="1.7.0",
                    kubeVersion=None,
                    description="A Helm chart to deploy alchemite-ui",
                    type="application",
                    home=None,
                    icon=None,
                    appVersion=None,
                    deprecated=False,
                ),
            )
        },
        "alchemite-admin": {
            "__root__": ChartPatched(
                _command=None,
                ref="alchemite-admin",
                repo=None,
                metadata=ChartMetadataPatched(
                    apiVersion="v2",
                    name="alchemite-admin",
                    version="1.6.0",
                    kubeVersion=None,
                    description="A Helm chart to deploy alchemite-admin",
                    type="application",
                    home=None,
                    icon=None,
                    appVersion=None,
                    deprecated=False,
                ),
            )
        },
    }


@pytest.fixture()
def testing_images() -> list[Image]:
    return [
        Image(
            repo="docker.io",
            image="intellegensdocker/api-releases",
            tag="v0.129.0",
            sha=None,
        ),
        Image(
            repo="docker.io",
            image="valkey/valkey",
            tag="8.1.4-alpine",
            sha="sha256:e706d1213aaba6896c162bb6a3a9e1894e1a435f28f8f856d14fab2e10aa098b",
        ),
        Image(
            repo="docker.io",
            image="alpine",
            tag="3.22.2",
            sha="sha256:4b7ce07002c69e8f3d704a9c5d6fd3053be500b7f1c69fc0d80990c2ad8dd412",
        ),
        Image(
            repo="docker.io",
            image="intellegensdocker/nfs",
            tag="1.7.1",
            sha="sha256:6243a380385da9f89832f946ab46ff36955b9726b0c24aa1e80e0cd5faaf4dc2",
        ),
        Image(
            repo="docker.io",
            image="instrumentisto/rsync-ssh",
            tag="alpine",
            sha="sha256:19f45502e651157313313b50ef54fc18f5c969f00752189a40d940f079d2d1bf",
        ),
        Image(
            repo="docker.io",
            image="postgres",
            tag="13.22",
            sha="sha256:f8e950624f314c103c9f40d1ba24ee67f1b16b529b342420d851d9b9d52449c3",
        ),
        Image(
            repo="docker.io",
            image="alpine",
            tag="3.22.2",
            sha="sha256:4b7ce07002c69e8f3d704a9c5d6fd3053be500b7f1c69fc0d80990c2ad8dd412",
        ),
        Image(
            repo="gcr.io",
            image="cloud-sql-connectors/cloud-sql-proxy",
            tag="2.18.2-alpine",
            sha="sha256:12fc14dd5bf90f69ed370a5990aff6f18a05d7b427465c621042bc1e2fac662f",
        ),
        Image(
            repo="docker.io",
            image="edoburu/pgbouncer",
            tag="v1.24.1-p1",
            sha="sha256:3db3d7223e93af52b4116f642951a1a5fa44702a88c2a59cf7562cac19320c9e",
        ),
        Image(
            repo="docker.io",
            image="intellegensdocker/keycloak",
            tag="v3.13.0",
            sha=None,
        ),
        Image(
            repo="registry.k8s.io",
            image="ingress-nginx/controller",
            tag="v1.13.3",
            sha="sha256:1b044f6dcac3afbb59e05d98463f1dec6f3d3fb99940bc12ca5d80270358e3bd",
        ),
        Image(
            repo="docker.io",
            image="intellegensdocker/opensearch",
            tag="2.19.3-post2",
            sha=None,
        ),
    ]


def test_parse_values(
    testing_versions: dict[str, VersionMap],
    testing_helm_charts: dict[str, dict[str, Chart]],
    testing_images: list[Image],
    path_info: dict[str, Path],
) -> None:
    paths = get_image_paths(testing_versions, testing_helm_charts)
    images = parse_values_for_images(path_info, paths["alchemite-api"])

    assert set(images) == set(testing_images)


@pytest.mark.parametrize("unpinned", [True, False])
def test_migrate_to_repo(
    local_repo: str, docker_client: DockerClient, unpinned: bool
) -> None:
    old_images = [
        Image(
            repo="docker.io",
            image="intellegensdocker/api-releases",
            tag="v0.129.0",
            sha=None,
        ),
        Image(
            repo="docker.io",
            image="valkey/valkey",
            tag="8.1.4-alpine",
            sha="sha256:e706d1213aaba6896c162bb6a3a9e1894e1a435f28f8f856d14fab2e10aa098b",
        ),
    ]

    new_images = migrate_to_repo(local_repo, old_images, unpinned)

    for new, old in zip(new_images, old_images):
        assert new.repo == local_repo
        assert new.image == old.image
        assert new.tag == old.tag
        # sha can change between pull and push
        if unpinned:
            assert new.sha == ""

    for new_image in new_images:
        docker_client.images.pull(
            repository=new_image.full_repo(), tag=new_image.tag
        )


@pytest.mark.parametrize("unpinned", [True, False])
def test_migrate_to_repo_failure(
    local_repo: str, caplog, unpinned: bool
) -> None:
    old_images = [
        Image(
            repo="docker.io",
            image="intellegensdocker/api-unreleased",
            tag="v0.129.0",
            sha=None,
        ),
    ]

    migrate_to_repo(local_repo, old_images, unpinned)

    assert any(
        "api-unreleased" in r.msg and "image manually" in r.msg
        for r in caplog.records
    )


def test_pinned_image_roundtrip(
    output_path, testing_images, testing_versions, testing_helm_charts
):
    output = output_path / "api-values.yaml"
    empty = output_path / "empty.yaml"
    empty.touch()
    paths = get_image_paths(testing_versions, testing_helm_charts)[
        "alchemite-api"
    ]
    create_pinned_image_values(output, paths, testing_images, "test")
    new_paths = {
        "__root__": output,
        "ingress-nginx": empty,
        "keycloakx": empty,
        "opensearch": empty,
    }
    new_images = parse_values_for_images(new_paths, paths)

    assert testing_images == new_images


@pytest.mark.parametrize("pull_secret", ["test", None])
def test_pull_secret(
    output_path,
    testing_images,
    testing_versions,
    testing_helm_charts,
    pull_secret,
):
    output = output_path / "api-images.yaml"
    paths = get_image_paths(testing_versions, testing_helm_charts)[
        "alchemite-api"
    ]
    create_pinned_image_values(output, paths, testing_images, pull_secret)
    pull_secrets = get_pull_secrets(output_path, {"alchemite-api": paths})

    assert pull_secrets == [i for i in (pull_secret,) if i is not None]
