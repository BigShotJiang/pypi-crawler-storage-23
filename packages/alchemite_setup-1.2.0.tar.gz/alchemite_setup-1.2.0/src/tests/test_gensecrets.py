import bcrypt
import yaml

from alchemite_setup.gensecrets import create_secrets
from alchemite_setup.helm import API_SECRET_PATH, AUM_SECRET_PATH, LICENCE_PATH


def test_secret_generation(monkeypatch, output_path):
    inputs = iter(["{}", "y"])
    monkeypatch.setattr("builtins.input", lambda _: next(inputs))

    create_secrets(output_path)

    for i in [LICENCE_PATH, API_SECRET_PATH, AUM_SECRET_PATH]:
        assert (output_path / i).exists

    with (output_path / LICENCE_PATH).open() as f:
        assert "licence" in yaml.safe_load(f)

    with (output_path / API_SECRET_PATH).open() as f:
        data = yaml.safe_load(f)
        assert "postgresql" in data
        assert "postgresqlPassword" in data["postgresql"]
        psql_pw = data["postgresql"]["postgresqlPassword"]

        assert "keycloak" in data
        assert "username" in data["keycloak"]
        assert "password" in data["keycloak"]
        assert data["keycloak"]["username"] == "intellegensadmin"

        assert "opensearch" in data
        assert "alchemiteSecrets" in data["opensearch"]
        assert "adminPasswordHashed" in data["opensearch"]["alchemiteSecrets"]
        assert (
            "serviceAccountPassword" in data["opensearch"]["alchemiteSecrets"]
        )
        assert (
            "serviceAccountPasswordHashed"
            in data["opensearch"]["alchemiteSecrets"]
        )
        assert bcrypt.checkpw(
            data["opensearch"]["alchemiteSecrets"][
                "serviceAccountPassword"
            ].encode("ascii"),
            data["opensearch"]["alchemiteSecrets"][
                "serviceAccountPasswordHashed"
            ].encode("ascii"),
        )

    with (output_path / AUM_SECRET_PATH).open() as f:
        data = yaml.safe_load(f)
        assert "sql" in data
        assert "aum" in data["sql"]
        assert "password" in data["sql"]["aum"]
        assert data["sql"]["aum"]["password"] == psql_pw

        assert "keycloak" in data
        assert "username" in data["keycloak"]
        assert "password" in data["keycloak"]
        assert data["keycloak"]["username"] == "aum-service-account"
