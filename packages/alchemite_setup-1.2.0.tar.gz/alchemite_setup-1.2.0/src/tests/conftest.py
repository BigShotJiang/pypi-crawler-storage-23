import random
from collections.abc import AsyncGenerator, Generator
from pathlib import Path
from typing import Any

import docker
import pyhelm3
import pytest

from alchemite_setup.helm import RELEASE_NAMESPACES, get_helm_client
from alchemite_setup.versions import VersionMap

BASE_DIR = Path(__file__).parent.absolute()


@pytest.fixture
def output_path(tmp_path: Path) -> Path:
    f = tmp_path / "intellegensconfig"
    f.mkdir()
    return f


@pytest.fixture
def data_path() -> Path:
    return BASE_DIR / "data"


@pytest.fixture(scope="session")
def docker_client() -> docker.client.DockerClient:
    return docker.from_env()


@pytest.fixture(scope="session")
async def helm_client() -> pyhelm3.Client:
    return await get_helm_client()


@pytest.fixture()
async def reset_helm(helm_client) -> AsyncGenerator[None, Any]:
    yield
    await helm_client.uninstall_release(
        "cert-manager", namespace=RELEASE_NAMESPACES["cert-manager"]
    )


@pytest.fixture(scope="session")
def local_repo(
    docker_client: docker.client.DockerClient,
) -> Generator[str, None, None]:
    port = random.randint(5000, 6000)
    container = docker_client.containers.run(
        "registry:3",
        detach=True,
        auto_remove=True,
        ports={"5000": port},
    )
    try:
        yield f"localhost:{port}"
    finally:
        container.stop()


@pytest.fixture()
def testing_versions() -> dict[str, VersionMap]:
    return {
        "cert-manager": VersionMap("", "v1.18.x", ""),
        "alchemite-api": VersionMap(
            "v0.129.0",
            "6.9.1-post1",
            "https://versions.intellegens.ai/alchemite-api/v0.129.0.json",
        ),
        "alchemite-users": VersionMap(
            "1.8.1",
            "1.2.12",
            "https://versions.intellegens.ai/alchemite-users/1.8.1.json",
        ),
        "smiles-extension": VersionMap(
            "v3.0.1",
            "1.2.0",
            "https://versions.intellegens.ai/smiles-extension/v3.0.1.json",
        ),
        "alchemite-ui": VersionMap(
            "2025.12.03T10.03.19",
            "1.7.0",
            "https://versions.intellegens.ai/alchemite-ui/2025.12.03T10.03.19.json",
        ),
        "alchemite-admin": VersionMap(
            "2025.12.03T10.03.19",
            "1.6.0",
            "https://versions.intellegens.ai/alchemite-admin/2025.12.03T10.03.19.json",
        ),
    }
