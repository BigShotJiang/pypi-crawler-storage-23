import asyncio
import json
import logging
import platform
import shutil
import stat
import tarfile
import tempfile
from collections import namedtuple
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any
from urllib.request import urlretrieve

import pyhelm3
import requests
import tqdm
import yaml
from pydantic import DirectoryPath, FilePath
from pyhelm3 import Client, mergeconcat

from alchemite_setup.exception import Abort
from alchemite_setup.manual_steps import (
    InstallMonitor,
    OpensearchMonitor,
    create_aum_service_account,
)
from alchemite_setup.versions import VersionMap

logger = logging.getLogger(__name__)


# Disable chart name validation as some of our charts are named incorrectly
class ChartMetadataPatched(pyhelm3.models.ChartMetadata):
    name: str


class ChartPatched(pyhelm3.models.Chart):
    ref: DirectoryPath | FilePath | str
    metadata: ChartMetadataPatched  # pyright: ignore[reportIncompatibleVariableOverride]


_OChart = pyhelm3.models.Chart
pyhelm3.models.Chart = pyhelm3.client.Chart = ChartPatched  # type: ignore
pyhelm3.models.ChartMetadata = pyhelm3.client.ChartMetadata = (  # type: ignore
    ChartMetadataPatched
)

KNOWN_ARCH = {
    "armv5": "armv5",
    "armv6": "armv6",
    "armv7": "arm",
    "aarch64": "arm64",
    "x86": "386",
    "x86_64": "amd64",
    "i686": "386",
    "i386": "386",
}
KNOWN_OSES = {"linux": "linux", "windows": "windows", "darwin": "darwin"}

Version = namedtuple("Version", ["major", "minor", "patch", "prerelease"])


def parse_version(tag: str) -> Version:
    parts = tag.lstrip("v").split("-")
    segments = parts[0].split(".")
    return Version(*segments, prerelease=len(parts) > 1)


def get_platform_suffix() -> tuple[str, str]:
    uname = platform.uname()
    raw_machine = uname.machine.lower()
    if raw_machine[:3] == "arm":
        arch = KNOWN_ARCH.get(raw_machine[:5])
    else:
        arch = KNOWN_ARCH.get(raw_machine)
    system_raw = uname.system.lower()
    if "mingw" in system_raw or "cygwin" in system_raw:
        osver = "windows"
    else:
        osver = KNOWN_OSES.get(system_raw)
    if arch is None or osver is None:
        raise ValueError(
            "Unable to find helm version compatible with your system"
        )
    return osver, arch


def install_helm() -> Path:
    latest_version = requests.get(
        "https://get.helm.sh/helm3-latest-version",
    ).text.strip()
    osver, arch = get_platform_suffix()

    helm_path = (Path("..") / "helm").absolute()

    with tempfile.TemporaryDirectory() as dir_raw:
        temp_dir = Path(dir_raw).absolute()
        logger.info("Downloading helm")
        urlretrieve(
            f"https://get.helm.sh/helm-{latest_version}-{osver}-{arch}.tar.gz",
            temp_dir / "helm.tar.gz",
        )
        logger.info("Extracting executable")
        with tarfile.open(temp_dir / "helm.tar.gz", "r:gz") as helm_tarfile:
            assert isinstance(helm_tarfile, tarfile.TarFile)
            files = helm_tarfile.getmembers()
            for file in files:
                if "helm" in file.name:
                    file.name = helm_path.name
                    helm_tarfile.extract(file, helm_path.parent)
    assert helm_path.exists()
    helm_path.chmod(stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH | stat.S_IXUSR)
    return helm_path


async def get_helm_client() -> Client:
    helm_path_str = shutil.which("helm")
    if helm_path_str is None:
        helm_path = install_helm()
    else:
        helm_path = Path(helm_path_str).absolute()
    client = Client(executable=str(helm_path))
    version = await client._command.version()
    if version[:3] != "v3.":
        logger.warning(
            f"Helm version {version} is not supported and may not work correctly. Please use Helm v3"
        )
    return client


async def get_current_revisions(helm_client: Client) -> dict[str, str | None]:
    revisions = {}
    for release_name, namespace in RELEASE_NAMESPACES.items():
        try:
            rev = await helm_client.get_current_revision(
                release_name, namespace=namespace
            )
            chart_version = (await rev.chart_metadata()).version
            app_version = helm_client
            revisions[release_name] = (chart_version, app_version)
        except pyhelm3.errors.ReleaseNotFoundError:
            revisions[release_name] = None
    return revisions


RELEASE_NAMESPACES = {
    "cert-manager": "cert-manager",
    "alchemite-api": None,
    "alchemite-users": None,
    "oligo-extension": None,
    "smiles-extension": None,
    "alchemite-ui": None,
    "alchemite-admin": None,
}

HELM_REPOSITORIES = {
    "cert-manager": "oci://quay.io/jetstack/charts/cert-manager",
    "alchemite-api": "oci://registry-1.docker.io/intellegensdocker/alchemite-api",
    "alchemite-users": "oci://registry-1.docker.io/intellegensdocker/alchemite-users-chart",
    "oligo-extension": "oci://registry-1.docker.io/intellegensdocker/oligo_extension",
    "smiles-extension": "oci://registry-1.docker.io/intellegensdocker/smiles_extension",
    "alchemite-ui": "oci://registry-1.docker.io/intellegensdocker/alchemite-ui",
    "alchemite-admin": "oci://registry-1.docker.io/intellegensdocker/alchemite-admin",
}

LICENCE_PATH = "licence-secrets.yaml"
API_SECRET_PATH = "api-secrets.yaml"
AUM_SECRET_PATH = "alchemite-users-secrets.yaml"

VALUES_NAMES: dict[str, tuple[str, ...]] = {
    "cert-manager": (
        "cert-manager-values.yaml",
        "cert-manager-images.yaml",
    ),
    "alchemite-api": (
        "api-values.yaml",
        "api-images.yaml",
        API_SECRET_PATH,
        LICENCE_PATH,
    ),
    "alchemite-users": (
        "alchemite-users-values.yaml",
        "alchemite-users-images.yaml",
        AUM_SECRET_PATH,
        LICENCE_PATH,
    ),
    "oligo-extension": (
        "oligo-values.yaml",
        "oligo-images.yaml",
        LICENCE_PATH,
    ),
    "smiles-extension": (
        "smiles-values.yaml",
        "smiles-images.yaml",
        LICENCE_PATH,
    ),
    "alchemite-ui": (
        "alchemite-ui-values.yaml",
        "alchemite-ui-images.yaml",
    ),
    "alchemite-admin": (
        "alchemite-admin-values.yaml",
        "alchemite-admin-images.yaml",
    ),
}


def get_default_values(domain: str | None) -> dict[str, dict | None]:
    base = {
        "cert-manager": {"installCRDs": True},
        "alchemite-api": {"global": {"useCertManager": True}},
        "alchemite-users": {
            "sql": {"aum": {"user": "usr", "database": "aum"}},
            "postgresql": {"createDatabase": True},
        },
        "oligo-extension": {
            "oligoExtension": {"valkey": {"host": "valkey-master"}}
        },
        "smiles-extension": {
            "smilesExtension": {"valkey": {"host": "valkey-master"}},
            "smilesAverageExtension": {"valkey": {"host": "valkey-master"}},
        },
        "alchemite-ui": None,
        "alchemite-admin": None,
    }

    if domain:
        domain_vals = {
            "cert-manager": None,
            "alchemite-api": {
                "apiServer": {"allowedOrigins": [f"https://{domain}"]},
                "ingressConfig": {"host": domain},
            },
            "alchemite-users": {
                "userApi": {
                    "allowedOrigins": [f"https://{domain}"],
                    "baseDomain": domain,
                },
                "ingressConfig": {"host": domain},
            },
            "oligo-extension": None,
            "smiles-extension": None,
            "alchemite-ui": {
                "alchemiteUI": {"apiBaseUrl": f"https://{domain}/v0"},
                "ingressConfig": {"host": domain},
            },
            "alchemite-admin": {
                "alchemiteAdmin": {
                    "apiBaseUrl": f"https://{domain}/api/aum/v1",
                    "keycloakUrl": f"https://{domain}/",
                },
                "ingressConfig": {"host": domain},
            },
        }
        for chart, val in base.items():
            newval = domain_vals[chart]
            if val is None:
                base[chart] = newval
            elif newval is not None:
                base[chart] = mergeconcat(val, newval)
    return base


INSTALL_MONITORS: dict[str, type[InstallMonitor]] = {
    "cert-manager": InstallMonitor,
    "alchemite-api": OpensearchMonitor,
    "alchemite-users": InstallMonitor,
    "oligo-extension": InstallMonitor,
    "smiles-extension": InstallMonitor,
    "alchemite-ui": InstallMonitor,
    "alchemite-admin": InstallMonitor,
}

FINALIZERS: dict[str, Callable[[Path, str | None], Awaitable[None]] | None] = {
    "cert-manager": None,
    "alchemite-api": create_aum_service_account,
    "alchemite-users": None,
    "oligo-extension": None,
    "smiles-extension": None,
    "alchemite-ui": None,
    "alchemite-admin": None,
}


def transfer_file(from_path: Path, to_path: Path) -> None:
    # Write base values.yaml file, skipping sections that are covered by the secret generator scripts,
    # or irrelevant to self-hosting
    STOP_WRITE_FLAG = "!!BEGIN OMIT!!"  # noqa: N806
    START_WRITE_FLAG = "!!END OMIT!!"  # noqa: N806
    SKIP_FLAG = "!!OMIT!!"  # noqa: N806
    with from_path.open("r") as source, to_path.open("w") as sink:
        sink.write(
            "# DO NOT EDIT THIS FILE\n"
            "# These are the available configuration options.\n"
            "# Please make any changes in the corresponding values.yaml file.\n\n"
        )
        write_mode = True
        for line in source:
            if STOP_WRITE_FLAG in line:
                write_mode = False
            if write_mode and SKIP_FLAG not in line:
                sink.write(line)
            if START_WRITE_FLAG in line:
                write_mode = True


async def download_chart_values(
    output_path: Path,
    helm_client: Client,
    chart_name: str,
    chart: VersionMap,
    domain: str | None,
) -> tuple[tuple[dict[str, ChartPatched], dict[str, Path]] | None, bool]:
    logger.debug(f"Downloading chart value for {chart_name}")
    default_values = get_default_values(domain)
    try:
        if chart is None:
            return None, True

        chart_inner_dict, values_inner_dict = {}, {}

        values = VALUES_NAMES[chart_name][0]
        async with helm_client.pull_chart(  # type: ignore
            HELM_REPOSITORIES[chart_name],
            version=chart.chart_version,
        ) as chart_data:
            dest = output_path / "reference" / values
            destination_path = dest.with_stem(f"{dest.stem}-base")
            values_inner_dict["__root__"] = destination_path
            chart_inner_dict["__root__"] = chart_data

            assert isinstance(chart_data, ChartPatched)
            transfer_file(
                Path(chart_data.ref) / "values.yaml", destination_path
            )
            for subchart in chart_data.metadata.dependencies:
                async with helm_client.pull_chart(  # type: ignore
                    subchart.name,
                    repo=subchart.repository,
                    version=subchart.version,
                ) as subchart_data:
                    assert isinstance(subchart_data, ChartPatched)
                    subchart_path = destination_path.with_stem(
                        f"{destination_path.stem}_subchart_{subchart.name}"
                    )
                    values_inner_dict[subchart.name] = subchart_path
                    chart_inner_dict[subchart.name] = subchart_data

                    transfer_file(
                        Path(subchart_data.ref) / "values.yaml",
                        subchart_path,
                    )

        if not (output_path / values).exists():
            if default_values[chart_name]:
                with (output_path / values).open("w") as f:
                    yaml.safe_dump(default_values[chart_name], f)
            else:
                (output_path / values).touch()
        return (chart_inner_dict, values_inner_dict), False
    except pyhelm3.Error:
        logger.error(
            f"Unable to fetch helm chart for {chart_name} with version {chart.chart_version}"
        )
        return None, True


async def download_charts_values(
    output_path: Path,
    helm_client: Client,
    latest_versions: dict[str, VersionMap],
    domain: str | None,
) -> tuple[dict[str, dict[str, ChartPatched]], dict[str, dict[str, Path]]]:
    logger.debug("Downloading charts values")
    chart_return_dict, values_return_dict = {}, {}
    (output_path / "reference").mkdir(exist_ok=True)
    failed = False
    logger.info("Downloading latest values files")
    for chart_name, chart in tqdm.tqdm(latest_versions.items()):
        val, failure = await download_chart_values(
            output_path,
            helm_client,
            chart_name,
            chart,
            domain,
        )
        if val is not None:
            chart_return_dict[chart_name], values_return_dict[chart_name] = val
        failed |= failure
    if failed:
        raise Abort("Unable to continue without downloading charts.")
    return chart_return_dict, values_return_dict


async def install_or_upgrade_release(
    client: Client,
    release_name: str,
    chart: _OChart,
    *values: dict[str, Any],
    atomic: bool = False,
    cleanup_on_fail: bool = False,
    create_namespace: bool = True,
    description: str | None = None,
    dry_run: bool = False,
    force: bool = False,
    namespace: str | None = None,
    no_hooks: bool = False,
    reset_values: bool = False,
    reuse_values: bool = False,
    skip_crds: bool = False,
    timeout: int | str | None = None,
    wait: bool = False,
) -> None:
    await client._command.install_or_upgrade(
        release_name,
        chart.ref,
        mergeconcat(*values) if values else None,
        atomic=atomic,
        cleanup_on_fail=cleanup_on_fail,
        create_namespace=create_namespace,
        description=description,
        dry_run=dry_run,
        force=force,
        namespace=namespace,
        no_hooks=no_hooks,
        repo=chart.repo,
        reset_values=reset_values,
        reuse_values=reuse_values,
        skip_crds=skip_crds,
        timeout=timeout,
        version=chart.metadata.version,
        wait=wait,
    )


async def diff_upgrade(
    client: Client,
    release_name: str,
    chart_ref: Path | str,
    values: dict[str, Any] | None = None,
    *,
    # The number of lines of context to show around each diff
    context_lines: int | None = None,
    devel: bool = False,
    dry_run: bool = False,
    namespace: str | None = None,
    no_hooks: bool = False,
    repo: str | None = None,
    reset_values: bool = False,
    reuse_values: bool = False,
    # Indicates whether to show secret values in the diff
    show_secrets: bool = True,
    version: str | None = None,
) -> str:
    """
    Returns the diff that would result from rolling back the given release
    to the specified revision.
    """
    command = [
        "diff",
        "upgrade",
        release_name,
        chart_ref,
        "--allow-unreleased",
        "--no-color",
        "--normalize-manifests",
        # Disable OpenAPI validation as we still want the diff to work when CRDs are absent or change
        "--disable-openapi-validation",
        "--disable-validation",
        # We pass the values using stdin
        "--values",
        "-",
    ]
    if context_lines is not None:
        command.extend(["--context", context_lines])
    if devel:
        command.append("--devel")
    if dry_run:
        command.append("--dry-run")
    if namespace:
        command.extend(["--namespace", namespace])
    if no_hooks:
        command.append("--no-hooks")
    if repo:
        command.extend(["--repo", repo])
    if reset_values:
        command.append("--reset-values")
    if reuse_values:
        command.append("--reuse-values")
    if show_secrets:
        command.append("--show-secrets")
    if version:
        command.extend(["--version", version])
    return (
        await client._command.run(command, json.dumps(values or {}).encode())
    ).decode()


def read_values(
    output_path: Path,
    chart_name: str,
) -> list[dict]:
    values = []
    for i in VALUES_NAMES[chart_name]:
        with (output_path / i).open("r") as f:
            values.append(yaml.safe_load(f))
    return values


async def ensure_helm_diff(helm_client: Client) -> None:
    val = (await helm_client._command.run(["plugin", "list"])).decode()
    if "diff" not in val:
        await helm_client._command.run(
            ["plugin", "install", "https://github.com/databus23/helm-diff"]
        )


async def deploy_helm_chart(
    output_path: Path,
    helm_client: Client,
    chart_name: str,
    version: VersionMap,
    dry_run: bool = False,
    namespace: str | None = None,
    atomic: bool = False,
) -> None:
    if dry_run:
        logger.info(f"Diffing {chart_name}")
    else:
        logger.info(f"Installing {chart_name}")
    values = read_values(output_path, chart_name)

    chart = await helm_client.get_chart(
        HELM_REPOSITORIES[chart_name],
        version=version.chart_version,
    )
    target_namespace = (
        RELEASE_NAMESPACES[chart_name]
        if RELEASE_NAMESPACES[chart_name] is not None
        else namespace
    )
    if dry_run:
        await ensure_helm_diff(helm_client)
        upgrade_diff = await diff_upgrade(
            helm_client,
            chart_name,
            chart.ref,
            mergeconcat(*values),
            namespace=target_namespace,
            repo=chart.repo,
            version=chart.metadata.version,
        )
        print(upgrade_diff)
    else:
        monitor = INSTALL_MONITORS[chart_name]()
        callback = monitor.task(target_namespace)

        async def _inner() -> None:
            await install_or_upgrade_release(
                helm_client,
                chart_name,
                chart,
                *values,
                namespace=target_namespace,
                timeout="60m",  # 1 hour
                atomic=atomic,
                wait=True,
            )
            monitor.stop()

        await asyncio.gather(_inner(), callback)
        finalizer = FINALIZERS.get(chart_name)
        if finalizer is not None:
            await finalizer(output_path, target_namespace)


async def deploy_helm_charts(
    output_path: Path,
    helm_client: Client,
    versions: dict[str, VersionMap],
    dry_run: bool = False,
    namespace: str | None = None,
    atomic: bool = False,
) -> None:
    if dry_run:
        logger.info("Diffing helm charts")
    else:
        logger.info("Deploying helm charts")
    for chart_name, version in tqdm.tqdm(versions.items()):
        await deploy_helm_chart(
            output_path,
            helm_client,
            chart_name,
            version,
            dry_run=dry_run,
            namespace=namespace,
            atomic=atomic,
        )
