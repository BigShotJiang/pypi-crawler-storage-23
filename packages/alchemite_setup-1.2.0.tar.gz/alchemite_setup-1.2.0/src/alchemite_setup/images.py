import logging
from collections.abc import Mapping
from pathlib import Path
from typing import Any, Literal, NamedTuple, Self

import docker
import tqdm
import yaml
from pyhelm3 import Chart
from yaml import safe_load

from alchemite_setup.helm import (
    VALUES_NAMES,
)
from alchemite_setup.versions import VersionMap

logger = logging.getLogger(__name__)


class Image(NamedTuple):
    repo: str | None
    image: str | None
    tag: str | None
    sha: str | None

    def full_repo(self) -> str:
        if self.image is None:
            return ""
        if self.repo is None:
            return self.image
        else:
            return f"{self.repo}/{self.image}"

    def full_tag(self) -> str:
        if self.tag is None:
            return "latest"
        elif self.sha is not None and self.sha != "":
            return f"{self.tag}@{self.sha}"
        else:
            return self.tag


class BaseImageLens:
    def __init__(
        self,
        base: str | list[str],
        repo: str | list[str] | None,
        image: str | list[str] | None,
        tag: str | list[str] | None,
        sha: str | list[str] | None,
        pull_secret: str | list[str] | None,
        pull_policy: str | list[str] | None,
    ) -> None:
        self.base: list[str] | None = (
            base.split(".") if isinstance(base, str) else base
        )
        self.repo: list[str] | None = (
            repo.split(".") if isinstance(repo, str) else repo
        )
        self.image: list[str] | None = (
            image.split(".") if isinstance(image, str) else image
        )
        self.tag: list[str] | None = (
            tag.split(".") if isinstance(tag, str) else tag
        )
        self.sha: list[str] | None = (
            sha.split(".") if isinstance(sha, str) else sha
        )
        self.pull_secret: list[str] | None = (
            pull_secret.split(".")
            if isinstance(pull_secret, str)
            else pull_secret
        )
        self.pull_policy: list[str] | None = (
            pull_policy.split(".")
            if isinstance(pull_policy, str)
            else pull_policy
        )
        self._defaults = {}

    def needed_charts(self) -> list[str]:
        return ["__root__"]

    def default(self, **kwargs) -> Self:
        self._defaults.update(
            {
                k: v
                for k, v in kwargs.items()
                if k
                in [
                    "repo",
                    "image",
                    "tag",
                    "sha",
                ]
            }
        )
        return self

    @staticmethod
    def _walk(values: dict, path: list[str] | None) -> Any | None:
        if path is None or len(path) == 0:
            return None
        base_block = values
        for step in path[:-1]:
            base_block = base_block.get(step, {})
        return base_block.get(path[-1])

    @staticmethod
    def _amble(values: dict, path: list[str], value: Any) -> None:
        if len(path) == 0:
            raise ValueError("Path too short to insert value")
        base_block = values
        for step in path[:-1]:
            if step not in base_block:
                base_block[step] = {}
            base_block = base_block[step]
        base_block[path[-1]] = value

    def _find(self, values: list[dict], path: list[str]) -> Any | None:
        for value in values:
            if value is None:
                continue
            val = self._walk(value, path)
            if val is not None:
                return val
        return None

    def __call__(self, values: list[dict]) -> Image:
        base_blocks = []
        for name, v in zip(self.needed_charts(), values):
            if (
                self.base is not None
                and len(self.base) > 0
                and self.base[0] == name
            ):
                w = self._walk(v, self.base[1:])
            else:
                w = self._walk(v, self.base)
            if w is None:
                base_blocks.append(v)
            else:
                base_blocks.append(w)

        repo = image = tag = sha = None
        if self.repo:
            repo = self._find(base_blocks, self.repo)
        if self.image:
            image = self._find(base_blocks, self.image)
        if self.tag:
            tag = self._find(base_blocks, self.tag)
        if self.sha:
            sha = self._find(base_blocks, self.sha)
        val = self.process(repo=repo, image=image, tag=tag, sha=sha)
        if self._defaults:
            val = val._replace(
                **{
                    default_key: default_value
                    for default_key, default_value in self._defaults.items()
                    if not getattr(val, default_key)
                }
            )
        return val

    def read_pull_secret(self, values: list[dict]) -> str | None:
        base_blocks = []
        for name, v in zip(self.needed_charts(), values):
            if (
                self.base is not None
                and len(self.base) > 0
                and self.base[0] == name
            ):
                w = self._walk(v, self.base[1:])
            else:
                w = self._walk(v, self.base)
            if w is None:
                base_blocks.append(v)
            else:
                base_blocks.append(w)

        pull_secret = None
        if self.pull_secret:
            pull_secret = self.process_pull_secret(
                self._find(base_blocks, self.pull_secret)
            )
        if (
            self._defaults
            and "pull_secret" in self._defaults
            and pull_secret is None
        ):
            pull_secret = self._defaults["pull_secret"]
        return pull_secret

    def process(
        self,
        repo: str | None = None,
        image: str | None = None,
        tag: str | None = None,
        sha: str | None = None,
    ) -> Image:
        return Image(repo, image, tag, sha)

    def format(
        self, image: Image
    ) -> tuple[str | None, str | None, str | None, str | None]:
        return image.repo, image.image, image.tag, image.sha

    def format_pull_secret(self, pull_secret: str) -> Any:
        return pull_secret

    def process_pull_secret(self, val: Any) -> str | None:
        if isinstance(val, str):
            return val
        return None

    def insert(
        self,
        image: Image,
        value: dict,
        pull_secret: str | None,
        pull_policy: Literal["Always", "Never", "IfNotPresent"],
    ) -> None:
        if self.base is not None and len(self.base) > 0:
            self._amble(value, self.base, {})
            base_block = self._walk(value, self.base)
        else:
            base_block = value
        assert isinstance(base_block, dict)
        repo, im, tag, sha = self.format(image)
        if repo is not None and self.repo is not None:
            self._amble(base_block, self.repo, repo)
        if im is not None and self.image is not None:
            self._amble(base_block, self.image, im)
        if tag is not None and self.tag is not None:
            self._amble(base_block, self.tag, tag)
        if sha is not None and self.sha is not None:
            self._amble(base_block, self.sha, sha)
        if pull_secret is not None and self.pull_secret is not None:
            self._amble(
                base_block,
                self.pull_secret,
                self.format_pull_secret(pull_secret),
            )
        if pull_policy is not None and self.pull_policy is not None:
            self._amble(
                base_block,
                self.pull_policy,
                pull_policy,
            )


class Separated(BaseImageLens):
    def __init__(
        self,
        base: str | list[str],
        repo: str | list[str],
        image: str | list[str],
        tag: str | list[str],
        sha: str | list[str],
        pull_secret: str | list[str] | None = None,
        pull_policy: str | list[str] | None = None,
    ) -> None:
        super().__init__(base, repo, image, tag, sha, pull_secret, pull_policy)


class OneLine(BaseImageLens):
    def __init__(
        self,
        base: str | list[str],
        image: str | list[str],
        pull_secret: str | list[str] | None = None,
        pull_policy: str | list[str] | None = None,
    ) -> None:
        super().__init__(
            base, None, image, None, None, pull_secret, pull_policy
        )

    def process(
        self,
        repo: str | None = None,
        image: str | None = None,
        tag: str | None = None,
        sha: str | None = None,
    ) -> Image:
        assert image is not None
        shaparts = image.rsplit("@", maxsplit=1)

        if len(shaparts) == 2:
            prepart, sha = shaparts
        else:
            (prepart,), sha = shaparts, None

        tagparts = prepart.rsplit(":", maxsplit=1)
        if len(tagparts) == 2:
            impart, tag = tagparts
        else:
            (impart,), tag = tagparts, None

        imparts = impart.split("/")
        if "." in imparts[0]:
            repo = imparts.pop(0)
        else:
            repo = "docker.io"
        image = "/".join(imparts)

        return Image(repo, image, tag, sha)

    def format(
        self, image: Image
    ) -> tuple[str | None, str | None, str | None, str | None]:
        im = image.image
        if image.repo:
            im = f"{image.repo}/{im}"
        if image.tag:
            im = f"{im}:{image.tag}"
            if image.sha:
                im = f"{im}@{image.sha}"
        return None, im, None, None


class TagSplit(BaseImageLens):
    def __init__(
        self,
        base: str | list[str],
        image: str | list[str],
        tag: str | list[str],
        pull_secret: str | list[str] | None = None,
        pull_policy: str | list[str] | None = None,
    ) -> None:
        super().__init__(base, None, image, tag, None, pull_secret, pull_policy)

    def process(
        self,
        repo: str | None = None,
        image: str | None = None,
        tag: str | None = None,
        sha: str | None = None,
    ) -> Image:
        assert image is not None
        if tag is not None:
            shaparts = tag.rsplit("@", maxsplit=1)

            if len(shaparts) == 2:
                tag, sha = shaparts
            else:
                (tag,), sha = shaparts, None
        else:
            tag, sha = None, None

        imparts = image.split("/")
        if "." in imparts[0]:
            repo = imparts.pop(0)
        else:
            repo = "docker.io"
        image = "/".join(imparts)

        return Image(repo, image, tag, sha)

    def format(
        self, image: Image
    ) -> tuple[str | None, str | None, str | None, str | None]:
        im = image.image
        if image.repo:
            im = f"{image.repo}/{im}"
        tag = None
        if image.tag:
            tag = image.tag
            if image.sha:
                tag = f"{tag}@{image.sha}"
        return None, im, tag, None


class SubchartMixin:
    def __init__(self, subchart: str, *args, **kwargs) -> None:
        self.subchart = subchart
        super().__init__(*args, **kwargs)

    def needed_charts(self) -> list[str]:
        return ["__root__", self.subchart]

    def _find(self, values: list[dict], path: list[str]) -> Any | None:
        for name, value in zip(self.needed_charts(), values):
            if value is None:
                continue
            if path[0] == name:
                result = self._walk(value, path[1:])  # pyright: ignore[reportAttributeAccessIssue]
            else:
                result = self._walk(value, path)  # pyright: ignore[reportAttributeAccessIssue]
            if result is not None:
                return result
        return None


class ImagePullSecretMixin:
    def format_pull_secret(self, pull_secret: str) -> Any:
        return [{"name": pull_secret}]

    def process_pull_secret(self, val: Any) -> str | None:
        if isinstance(val, list) and len(val) > 0:
            elem1 = val[0]
            if isinstance(elem1, dict):
                return elem1.get("name")


class NoShaMixin:
    def format(
        self, image: Image
    ) -> tuple[str | None, str | None, str | None, str | None]:
        return super().format(image._replace(sha=None))  # pyright: ignore[reportAttributeAccessIssue]


class SubchartSeparated(SubchartMixin, ImagePullSecretMixin, Separated):
    pass


class SubchartTagSplit(SubchartMixin, ImagePullSecretMixin, TagSplit):
    pass


class PullListTagSplit(ImagePullSecretMixin, TagSplit):
    pass


class PullListTagSplitNoSha(NoShaMixin, PullListTagSplit):
    pass


class SubchartTagSplitNoSha(NoShaMixin, SubchartTagSplit):
    pass


def get_image_paths(
    versions: Mapping[str, VersionMap],
    helm_charts: Mapping[str, Mapping[str, Chart]] | None,
) -> dict[str, list[BaseImageLens]]:
    return {
        "cert-manager": [
            PullListTagSplit(
                [],
                "image.repository",
                "image.tag",
                "global.imagePullSecrets",
                "image.pullPolicy",
            ).default(
                tag=helm_charts["cert-manager"]["__root__"].metadata.app_version
                if helm_charts
                else None
            ),
            PullListTagSplit(
                "webhook",
                "image.repository",
                "image.tag",
                None,
                "image.pullPolicy",
            ).default(
                tag=helm_charts["cert-manager"]["__root__"].metadata.app_version
                if helm_charts
                else None
            ),
            PullListTagSplit(
                "cainjector",
                "image.repository",
                "image.tag",
                None,
                "image.pullPolicy",
            ).default(
                tag=helm_charts["cert-manager"]["__root__"].metadata.app_version
                if helm_charts
                else None
            ),
            PullListTagSplit(
                "acmesolver",
                "image.repository",
                "image.tag",
                None,
                "image.pullPolicy",
            ).default(
                tag=helm_charts["cert-manager"]["__root__"].metadata.app_version
                if helm_charts
                else None
            ),
            PullListTagSplit(
                "startupapicheck",
                "image.repository",
                "image.tag",
                None,
                "image.pullPolicy",
            ).default(
                tag=helm_charts["cert-manager"]["__root__"].metadata.app_version
                if helm_charts
                else None
            ),
        ],
        "alchemite-api": [
            TagSplit(
                "apiImage", "repository", "tag", "pullSecret", "pullPolicy"
            ).default(tag=versions["alchemite-api"].app_version),
            OneLine("valkey", "image"),
            OneLine("valkey.initContainers.dirsetup", "image"),
            OneLine("storage.gkeNfs", "image"),
            OneLine("storage.migrateJob", "image"),
            OneLine("postgresql", "image"),
            OneLine("postgresql.initContainers.dirsetup", "image"),
            OneLine("global.cloudSql", "image"),
            OneLine("pgBouncer", "image"),
            PullListTagSplitNoSha(
                "keycloak",
                "image.repository",
                "image.tag",
                "imagePullSecrets",
                "image.pullPolicy",
            ),
            SubchartSeparated(
                "ingress-nginx",
                [],
                "global.image.registry",
                "ingress-nginx.controller.image.image",
                "ingress-nginx.controller.image.tag",
                "ingress-nginx.controller.image.digest",
                "ingress-nginx.imagePullSecrets",
                "ingress-nginx.controller.image.pullPolicy",
            ),
            SubchartTagSplitNoSha(
                "opensearch",
                "opensearch",
                "image.repository",
                "image.tag",
                "imagePullSecrets",
                "image.pullPolicy",
            ).default(
                tag=helm_charts["alchemite-api"][
                    "opensearch"
                ].metadata.app_version
                if helm_charts
                else None
            ),
        ],
        "alchemite-users": [
            PullListTagSplit(
                [],
                "userApi.image.repository",
                "userApi.image.tag",
                "imagePullSecrets",
                "userApi.image.pullPolicy",
            ).default(tag=versions["alchemite-users"].app_version),
            OneLine("postgresql", "image"),
            OneLine("cloudSql", "image"),
        ],
        "oligo-extension": [
            TagSplit(
                "appImage", "name", "tag", "pullSecret", "pullPolicy"
            ).default(tag=versions["oligo-extension"].app_version)
        ]
        if "oligo-extension" in versions
        else [],
        "smiles-extension": [
            TagSplit(
                "appImage", "name", "tag", "pullSecret", "pullPolicy"
            ).default(tag=versions["smiles-extension"].app_version)
        ],
        "alchemite-ui": [
            TagSplit(
                "appImage", "name", "tag", "pullSecret", "pullPolicy"
            ).default(tag=versions["alchemite-ui"].app_version)
        ],
        "alchemite-admin": [
            TagSplit(
                "appImage", "name", "tag", "pullSecret", "pullPolicy"
            ).default(tag=versions["alchemite-ui"].app_version)
        ],
    }


def parse_values_for_images(
    paths: Mapping[str, Path], image_locs: list[BaseImageLens]
) -> list[Image]:
    loaded_values = {}
    images = []
    for lens in image_locs:
        charts = lens.needed_charts()
        for chart in charts:
            if chart not in loaded_values:
                with paths[chart].open() as f:
                    loaded_values[chart] = safe_load(f)
        values = [loaded_values[chart] for chart in charts]
        images.append(lens(values))
    return images


def create_pinned_image_values(
    output_path: Path,
    image_locs: list[BaseImageLens],
    image_versions: list[Image],
    pull_secret: str | None,
) -> None:
    value = {}
    for loc, image in zip(image_locs, image_versions):
        loc.insert(image, value, pull_secret, "Always")

    with output_path.open("w") as f:
        yaml.safe_dump(value, f)


def migrate_to_repo(
    repo: str, image_versions: list[Image], unpinned_images: bool
) -> list[Image]:
    logger.debug("Migrating images to delegate repository")
    client = docker.from_env()
    new_image_versions = []
    for image in tqdm.tqdm(image_versions):
        new_image = image._replace(
            repo=repo, sha="" if unpinned_images else None
        )
        try:
            logger.debug(
                f"Pulling {image.full_repo()} with tag {image.full_tag()}"
            )
            d_im = client.images.pull(
                repository=image.full_repo(),
                tag=image.tag,
                platform="linux/amd64",
            )
            d_im.tag(repository=new_image.full_repo(), tag=new_image.tag)
            logger.debug(
                f"Pushing {new_image.full_repo()} with tag {new_image.full_tag()}"
            )
            client.images.push(new_image.full_repo(), new_image.tag)
            registry_data = client.images.get_registry_data(
                f"{new_image.full_repo()}:{new_image.tag}"
            )
            if unpinned_images:
                new_image = new_image._replace(sha="")
            else:
                new_image = new_image._replace(
                    sha=registry_data.attrs.get("Descriptor", {}).get(
                        "digest", ""
                    )
                )
        except Exception:
            logger.error(
                f"Unable to migrate image {image.full_repo()}:{image.tag}. Please migrate this image manually"
            )
        new_image_versions.append(new_image)
    return new_image_versions


def remove_hashes(images: list[Image]) -> list[Image]:
    return [image._replace(sha="") for image in images]


def prepare_images(
    output_path: Path,
    path_infos: Mapping[str, dict[str, Path]],
    image_locs: Mapping[str, list[BaseImageLens]],
    pull_secret: str | None,
    unpinned_images: bool,
    rehost_repo: str | None = None,
) -> None:
    logger.info("Preparing images for deployment")
    if rehost_repo:
        logger.info("This may take a while")
    for chart, image_loc in tqdm.tqdm(image_locs.items()):
        if chart not in path_infos:
            continue
        images = parse_values_for_images(
            path_infos[chart],
            image_locs=image_loc,
        )
        if rehost_repo:
            images = migrate_to_repo(rehost_repo, images, unpinned_images)
        elif unpinned_images:
            images = remove_hashes(images)
        create_pinned_image_values(
            # The image filename is always the second item of VALUES_NAME
            output_path / VALUES_NAMES[chart][1],
            image_loc,
            images,
            pull_secret,
        )


def get_pull_secrets(
    output_path: Path, image_locs: Mapping[str, list[BaseImageLens]]
) -> list[str]:
    pull_secrets = set()
    for chart, files in VALUES_NAMES.items():
        if not (output_path / files[1]).exists():
            continue
        with (output_path / files[1]).open() as f:
            values = yaml.safe_load(f)
            for lens in image_locs[chart]:
                pull_secrets.add(lens.read_pull_secret([values]))

    if None in pull_secrets:
        pull_secrets.remove(None)

    return list(pull_secrets)
