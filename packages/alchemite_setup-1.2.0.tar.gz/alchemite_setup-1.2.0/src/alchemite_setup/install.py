import logging
from collections.abc import Mapping
from pathlib import Path

from alchemite_setup.gensecrets import (
    create_secrets,
    secrets_exist,
)
from alchemite_setup.helm import (
    deploy_helm_charts,
    download_charts_values,
    get_helm_client,
)
from alchemite_setup.images import (
    get_image_paths,
    prepare_images,
)
from alchemite_setup.manual_steps import warn_missing_pull_secret
from alchemite_setup.versions import (
    fetch_versions,
    load_versions,
    save_versions,
)

logger = logging.getLogger(__name__)


async def prepare(
    raw_config_path: str,
    rotate_secrets: bool = False,
    rehost_images: str | None = None,
    unpinned_images: bool = False,
    enable_oligo: bool = False,
    desired_versions: Mapping[str, str] | None = None,
    read_versions: bool = False,
    pull_secret: str | None = None,
    domain: str | None = None,
) -> None:
    config_path = Path(raw_config_path)
    config_path.mkdir(parents=True, exist_ok=True)

    if not secrets_exist(config_path) or rotate_secrets:
        create_secrets(config_path)

    if not read_versions:
        versions = fetch_versions(desired_versions, oligo_enabled=enable_oligo)
        save_versions(config_path, versions)
    else:
        versions = load_versions(config_path)

    helm_client = await get_helm_client()
    chart_infos, path_infos = await download_charts_values(
        config_path, helm_client, versions, domain
    )
    image_locs = get_image_paths(versions, chart_infos)
    prepare_images(
        config_path,
        path_infos,
        image_locs,
        pull_secret,
        unpinned_images,
        rehost_images,
    )


async def deploy(
    raw_config_path: str,
    dry_run: bool = False,
    namespace: str | None = None,
    atomic: bool = False,
) -> None:
    config_path = Path(raw_config_path)
    if not config_path.exists() or not config_path.is_dir():
        raise ValueError("Invalid config path")

    versions = load_versions(config_path)

    helm_client = await get_helm_client()

    await warn_missing_pull_secret(config_path, versions, namespace)

    await deploy_helm_charts(
        config_path, helm_client, versions, dry_run, namespace, atomic
    )
