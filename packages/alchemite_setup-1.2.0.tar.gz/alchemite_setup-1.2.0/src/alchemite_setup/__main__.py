from alchemite_setup.cli import main

main()
