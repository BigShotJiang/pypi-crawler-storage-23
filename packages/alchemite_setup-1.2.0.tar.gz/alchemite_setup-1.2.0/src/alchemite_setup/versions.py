import json
import logging
from collections import namedtuple
from collections.abc import Mapping
from pathlib import Path

import requests

from alchemite_setup.exception import Abort

logger = logging.getLogger(__name__)

BASE_URL = "https://versions.intellegens.ai"


# Fix common typos for version numbers (as we are so inconsistent...)
# These can potentially be expanded in the future to do better validation
def fix_v_semver_version(ver: str) -> str:
    if not ver[0] == "v":
        return f"v{ver}"
    else:
        return ver


def fix_nov_semver_version(ver: str) -> str:
    return ver.lstrip("v")


def fix_date_version(ver: str) -> str:
    return ver


VERSION_SANITIZERS = {
    "alchemite-api": fix_v_semver_version,
    "alchemite-users": fix_nov_semver_version,
    "oligo-extension": fix_v_semver_version,
    "smiles-extension": fix_v_semver_version,
    "alchemite-ui": fix_date_version,
    "alchemite-admin": fix_date_version,
}

VersionMap = namedtuple(
    "VersionMap", ["app_version", "chart_version", "canonical_url"]
)


def fetch_version_info(repo: str, version: str = "latest") -> VersionMap | None:
    logger.debug(
        f"Fetching appropriate version for repo {repo} with version {version}"
    )
    response = requests.get(f"{BASE_URL}/{repo}/{version}.json")
    if response.status_code == 404:
        return None
    response.raise_for_status()
    data = response.json()
    return VersionMap(
        app_version=data["imageTag"],
        chart_version=data["helmTag"],
        canonical_url=data["canonicalUrl"],
    )


def fetch_versions(
    desired_versions: Mapping[str, str] | None = None,
    oligo_enabled: bool = False,
) -> dict[str, VersionMap]:
    logger.debug(f"Fetching appropriate versions: {desired_versions}")
    if desired_versions is None:
        desired_versions = {}

    result = {"cert-manager": VersionMap("", "v1.18.x", "")}
    failed = True
    for repo, sanitizer in VERSION_SANITIZERS.items():
        if repo == "oligo-extension" and not oligo_enabled:
            continue

        if desired_versions.get(repo, "latest").lower() != "latest":
            info = fetch_version_info(repo, sanitizer(desired_versions[repo]))
        else:
            info = fetch_version_info(repo)

        if info is not None:
            result[repo] = info
        else:
            logger.error(
                f"Warning, unable to locate version {desired_versions.get(repo)} for {repo}"
            )
            failed = True
    if not failed:
        raise Abort("Unable to proceed with invalid versions")
    return result


def save_versions(output_path: Path, versions: dict[str, VersionMap]) -> None:
    with (output_path / "versions.json").open("w") as f:
        json.dump(versions, f)


def load_versions(output_path: Path) -> dict[str, VersionMap]:
    with (output_path / "versions.json").open("r") as f:
        data = json.load(f)
        return {k: VersionMap(*v) for k, v in data.items()}


if __name__ == "__main__":
    print(fetch_versions())
