import base64
import json
import secrets
import string
from json import JSONDecodeError
from pathlib import Path

import bcrypt
import yaml

from alchemite_setup.exception import Abort
from alchemite_setup.helm import API_SECRET_PATH, AUM_SECRET_PATH, LICENCE_PATH

DEFAULT_PASSWORD_CHARSET = (
    string.ascii_letters + string.digits + "!#%&'()*+,-./:;<=>?[]^_`{|}~"
)


def generate_password(
    length: int = 30, charset: str = DEFAULT_PASSWORD_CHARSET
) -> str:
    return "".join(secrets.choice(charset) for i in range(length))


def secrets_exist(values_dir: Path) -> bool:
    return all(
        (values_dir / file).exists()
        for file in [LICENCE_PATH, API_SECRET_PATH, AUM_SECRET_PATH]
    )


def validate_licence(licence: str) -> bool:
    # Check that the licence is likely to work once deployed.
    # This does NOT validate the signature, that is left to the application itself
    try:
        data = json.loads(licence)
    except JSONDecodeError:
        data_segments = licence.split(".")
        if len(data_segments) != 3:
            return False
        try:
            data = json.loads(
                base64.urlsafe_b64decode(f"{data_segments[1]}====")
            )
        except JSONDecodeError:
            return False

    if not isinstance(data, dict):
        return False

    for k in ["e", "p", "t", "u", "v", "w"]:
        if k not in data:
            return False

    if data["v"] not in [1, 2]:
        return False

    if "__all__" not in data["p"]:
        if "apiserver" not in data["p"]:
            return False

        # Installs now also require ichnite for the smiles extension
        if "ichnite_beta" not in data["p"]:
            return False

    return True


def create_licence_secret(values_dir: Path) -> None:
    licence = input("Enter Intellegens licence: ")

    if not validate_licence(licence):
        cont = input(
            "Licence looks to be invalid. Are you sure you wish to continue? (y/n)"
        )
        if len(cont) == 0 or cont[0] != "y":
            raise Abort("Abort due to user request")

    with (values_dir / LICENCE_PATH).open("w") as f:
        yaml.dump({"licence": licence}, f, sort_keys=False)


def create_api_secrets(values_dir: Path, postgres_pw: str) -> None:
    keycloak_pw = generate_password()
    opensearch_service_pw = generate_password()
    opensearch_admin_pw = generate_password()
    hashed_opensearch_service_pw = bcrypt.hashpw(
        opensearch_service_pw.encode("ascii"), bcrypt.gensalt(prefix=b"2a")
    ).decode()
    hashed_opensearch_admin_pw = bcrypt.hashpw(
        opensearch_admin_pw.encode("ascii"), bcrypt.gensalt(prefix=b"2a")
    ).decode()
    data = {
        "postgresql": {"postgresqlPassword": postgres_pw},
        "keycloak": {"username": "intellegensadmin", "password": keycloak_pw},
        "opensearch": {
            "alchemiteSecrets": {
                "adminPasswordHashed": hashed_opensearch_admin_pw,
                "serviceAccountPasswordHashed": hashed_opensearch_service_pw,
                "serviceAccountPassword": opensearch_service_pw,
            }
        },
    }

    with (values_dir / API_SECRET_PATH).open("w") as f:
        yaml.dump(data, f, sort_keys=False)


def create_aum_secrets(values_dir: Path, postgres_pw: str) -> None:
    keycloak_pw = generate_password()

    data = {
        "keycloak": {
            "username": "aum-service-account",
            "password": keycloak_pw,
        },
        "sql": {
            "aum": {
                "password": postgres_pw,
            }
        },
    }

    with (values_dir / AUM_SECRET_PATH).open("w") as f:
        yaml.dump(data, f, sort_keys=False)


def create_secrets(config_path: Path) -> None:
    create_licence_secret(config_path)

    postgres_pw = generate_password()
    create_api_secrets(config_path, postgres_pw)
    create_aum_secrets(config_path, postgres_pw)


if __name__ == "__main__":
    output_path = Path("../local/intellegensconfig")
    output_path.mkdir(parents=True, exist_ok=True)

    create_secrets(output_path)
