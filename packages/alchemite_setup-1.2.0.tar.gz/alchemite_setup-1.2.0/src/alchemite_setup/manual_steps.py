import asyncio
import logging
import platform
import random
import shlex
import shutil
import stat
import string
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import TYPE_CHECKING
from urllib.request import urlretrieve
from uuid import UUID

from keycloak import KeycloakAdmin, KeycloakOpenIDConnection, KeycloakPutError
from pyhelm3 import mergeconcat

if TYPE_CHECKING:
    from alchemite_setup.versions import VersionMap

logger = logging.getLogger(__name__)


def get_platform_suffix() -> tuple[str, str]:
    known_arch = {
        "armv5": "armv5",
        "armv6": "armv6",
        "armv7": "arm",
        "aarch64": "arm64",
        "x86_64": "amd64",
    }
    known_oses = {"linux": "linux", "windows": "windows", "darwin": "darwin"}
    uname = platform.uname()
    raw_machine = uname.machine.lower()
    if raw_machine[:3] == "arm":
        arch = known_arch.get(raw_machine[:5])
    else:
        arch = known_arch.get(raw_machine)
    system_raw = uname.system.lower()
    if "mingw" in system_raw or "cygwin" in system_raw:
        osver = "windows"
    else:
        osver = known_oses.get(system_raw)
    if arch is None or osver is None:
        raise ValueError(
            "Unable to find helm version compatible with your system"
        )
    return osver, arch


def install_cmctl() -> Path:
    """
    OS=$(go env GOOS); ARCH=$(go env GOARCH); curl -fsSL -o cmctl https://github.com/cert-manager/cmctl/releases/latest/download/cmctl_${OS}_${ARCH}
    chmod +x cmctl
    sudo mv cmctl /usr/local/bin
    :return:
    """

    osver, arch = get_platform_suffix()

    cmctl_path = (Path("cmctl")).absolute()

    logger.info("Downloading cmctl")
    urlretrieve(
        f"https://github.com/cert-manager/cmctl/releases/latest/download/cmctl_{osver}_{arch}",
        "cmctl",
    )
    assert cmctl_path.exists()
    cmctl_path.chmod(stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH | stat.S_IXUSR)
    return cmctl_path


def get_cmctl() -> Path:
    cmctl_path_str = shutil.which("cmctl")
    if cmctl_path_str is None:
        cmctl_path_str = shutil.which("./cmctl")
        if cmctl_path_str is None:
            cmctl_path = install_cmctl()
        else:
            cmctl_path = Path(cmctl_path_str).absolute()
    else:
        cmctl_path = Path(cmctl_path_str).absolute()
    return cmctl_path


async def fix_opensearch(namespace: str | None) -> None:
    if namespace:
        suffix = ["--namespace", namespace]
    else:
        suffix = []

    logger.info("Detected opensearch initialisation failure. Attempting fix")
    executable = get_cmctl()
    print(executable)
    # Renew cert
    logger.debug("cmctl renew")
    cmctl_proc = await asyncio.create_subprocess_shell(
        shlex.join(
            [
                str(executable),
                "renew",
                "opensearch-cluster-node-certificate",
                *suffix,
            ]
        )
    )
    await cmctl_proc.communicate()
    # Restart all opensearch pods
    logger.debug("Restart pods")
    x = await asyncio.create_subprocess_shell(
        shlex.join(
            [
                "kubectl",
                "delete",
                "pods",
                "-l",
                "app.kubernetes.io/component=opensearch-cluster-master",
                *suffix,
            ]
        )
    )
    await x.communicate()


async def check_pull_secrets(
    namespace: str | None, pull_secrets: Iterable[str]
) -> list[str]:
    missing = []
    for pull_secret in pull_secrets:
        command = ["kubectl", "get", "secret", pull_secret]
        if namespace:
            command.extend(["--namespace", namespace])
        proc = await asyncio.create_subprocess_shell(
            shlex.join(command),
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await proc.communicate()
        if proc.returncode != 0:
            missing.append(pull_secret)
    return missing


async def warn_missing_pull_secret(
    output_path: Path,
    versions: "Mapping[str, VersionMap]",
    namespace: str | None,
) -> None:
    from alchemite_setup.images import (  # noqa: PLC0415
        get_image_paths,
        get_pull_secrets,
    )

    pull_secrets = get_pull_secrets(
        output_path, get_image_paths(versions, None)
    )

    missing = await check_pull_secrets(namespace, pull_secrets)

    if missing:
        logger.warning(
            f"Unable to detect following image pull secrets: {missing}"
        )
        _suffix = f" \\ \n  --namespace {namespace}" if namespace else ""
        if len(missing) > 2:
            logger.warning(
                f"""Please run the following command for each secret:
    kubectl create secret docker-registry {missing[0]} \\
      --docker-server=docker.io \\
      --docker-username=<<username>> \\
      --docker-email=<<email>> \\
      --docker-password=<<password>>"""
                + _suffix
            )
        else:
            logger.warning(
                f"""Please run the following command:
    kubectl create secret docker-registry {missing[0]} \\
      --docker-server=docker.io \\
      --docker-username=<<username>> \\
      --docker-email=<<email>> \\
      --docker-password=<<password>>"""
                + _suffix
            )
        logger.warning("Continue?")
        input()


async def check_opensearch_cert_error(namespace: str | None) -> bool:
    if namespace:
        suffix = ["--namespace", namespace]
    else:
        suffix = []
    proc = await asyncio.create_subprocess_shell(
        shlex.join(
            [
                "kubectl",
                "logs",
                "statefulset/opensearch-cluster-master",
                *suffix,
            ]
        ),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,
    )
    stdout, _stderr = await proc.communicate()
    return b"Insufficient buffer remaining for AEAD cipher fragment" in stdout


class InstallMonitor:
    period = 30

    def __init__(self) -> None:
        self.running = True

    def stop(self) -> None:
        self.running = False

    async def task(self, namespace: str | None) -> None:
        while self.running:
            await asyncio.sleep(self.period)
            await self.act(namespace)

    async def act(self, namespace: str | None) -> None:
        pass


class OpensearchMonitor(InstallMonitor):
    async def act(self, namespace: str | None) -> None:
        if await check_opensearch_cert_error(namespace):
            await fix_opensearch(namespace)


def _construct_q(**kwargs: str | UUID | bool | None) -> str:
    """
    Construct a keycloak query
    Arguments must be named to match the keycloak attribute name
    """

    def escape(val: str) -> str:
        # Replace any characters with special meaning with backslash escaped versions
        escapable = r"""\"':"""
        for i in escapable:
            val = val.replace(i, rf"\{i}")
        # Quote value if any symbols or spaces exist
        if not all(
            x in (string.ascii_letters + string.digits + "_") for x in val
        ):
            val = f'"{val}"'
        return val

    qs = []
    for k, v in kwargs.items():
        if v is None:
            continue
        k_ = escape(str(k))
        if isinstance(v, bool):
            v_ = "true" if v else "false"
        else:
            v_ = escape(str(v))
        qs.append(f"{k_}:{v_}")
    return " ".join(qs)


async def create_aum_service_account(
    output_path: Path, namespace: str | None
) -> None:
    from alchemite_setup.helm import (  # noqa: PLC0415  avoid circular imports
        read_values,
    )

    if namespace:
        suffix = ["--namespace", namespace]
    else:
        suffix = []

    api_values = mergeconcat(*read_values(output_path, "alchemite-api"))
    aum_values = mergeconcat(*read_values(output_path, "alchemite-users"))

    admin_username = api_values.get("keycloak", {}).get(
        "username", "intellegensadmin"
    )
    admin_password = api_values.get("keycloak", {}).get("password")
    service_username = aum_values.get("keycloak", {}).get("username")
    service_password = aum_values.get("keycloak", {}).get("password")

    keycloak_name = api_values.get("keycloak", {}).get(
        "fullnameOverride", "keycloak"
    )
    service_name = f"{keycloak_name}-http"

    port = random.randint(6000, 7000)
    port_forward = await asyncio.create_subprocess_shell(
        shlex.join(
            [
                "kubectl",
                "port-forward",
                f"svc/{service_name}",
                f"{port}:80",
                *suffix,
            ]
        ),
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.DEVNULL,
    )
    await asyncio.sleep(5)

    keycloak_connection = KeycloakOpenIDConnection(
        server_url=f"http://localhost:{port}/v0/auth/",
        username=admin_username,
        password=admin_password,
        realm_name="master",
        verify=False,
    )
    keycloak_admin = KeycloakAdmin(connection=keycloak_connection)
    existing_user = await keycloak_admin.a_get_users(
        {"q": _construct_q(username=service_username), "exact": True}
    )
    new = False

    if len(existing_user) > 0:
        user_id = existing_user[0]["id"]
    else:
        new = True
        user_id = await keycloak_admin.a_create_user(
            {
                "username": service_username,
                "firstName": "AUM",
                "lastName": "Service Account",
                "email": "support#aum@intellegens.com",
                "enabled": True,
            }
        )

    try:
        await keycloak_admin.a_set_user_password(
            user_id, service_password, temporary=False
        )
    except KeycloakPutError:
        # Password unchanged
        pass

    if new:
        await keycloak_admin.a_update_user(
            user_id,
            {
                "requiredActions": [],
            },
        )

    current_roles = await keycloak_admin.a_get_realm_roles_of_user(user_id)
    if "admin" not in [r["id"] for r in current_roles]:
        all_roles = await keycloak_admin.a_get_realm_roles(
            brief_representation=False
        )
        admin_role = next(r for r in all_roles if r["name"] == "admin")

        await keycloak_admin.a_assign_realm_roles(user_id, [admin_role])

    port_forward.terminate()
    await port_forward.communicate(None)


if __name__ == "__main__":
    print(
        asyncio.run(
            create_aum_service_account(
                Path(
                    "/home/anna/Programming/setup_cluster/local/intellegens_config"
                ),
                namespace=None,
            )
        )
    )
