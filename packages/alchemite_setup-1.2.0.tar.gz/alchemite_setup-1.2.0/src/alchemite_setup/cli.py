import asyncio
import logging
import sys
from argparse import ArgumentParser

from alchemite_setup.exception import Abort
from alchemite_setup.install import deploy, prepare
from alchemite_setup.versions import VERSION_SANITIZERS


def generate_cli() -> ArgumentParser:
    parser = ArgumentParser(
        prog="uvx alchemite_setup",
        description="An installation script for self-hosted alchemite installations",
    )
    parser.add_argument(
        "--config-path",
        action="store",
        default="./intellegens_config",
        help="The directory used to store or load the deployment configuration",
    )
    parser.add_argument(
        "--log-level",
        action="store",
        default="INFO",
        help="The log level to use for this script",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
    )

    subparsers = parser.add_subparsers(dest="command")
    # prepare arguments
    prep_parser = subparsers.add_parser(
        "prepare",
        help="Prepare for deployment",
        description="Prepare for new deployment, or update existing configuration for application update",
    )
    prep_parser.add_argument(
        "--rehost-images",
        action="store",
        help="Instructs the script to rehost the images to an alternative repository",
        metavar="repository_name",
    )
    prep_parser.add_argument(
        "--rotate",
        action="store_true",
        help="Rotate the config secret values. This may require additional steps to deploy successfully",
    )

    prep_parser.add_argument(
        "--oligo",
        action="store_true",
        help="Enable oligonucleotide features in the cluster",
    )

    for i in VERSION_SANITIZERS.keys():
        prep_parser.add_argument(
            f"--{i}-version",
            action="store",
            default="latest",
            help=f"Specify the version of {i} to install",
            metavar="VERSION",
        )

    prep_parser.add_argument(
        "--read-versions",
        action="store_true",
        help="Use stored versions instead of latest. This is incompatible with explicit versions",
    )

    prep_parser.add_argument(
        "--pull-secret",
        action="store",
        help="The image pull secret to use when the cluster is starting pods",
    )

    prep_parser.add_argument(
        "--unpinned-images",
        action="store_true",
        help="Ignore image hashes where available",
    )

    prep_parser.add_argument(
        "--domain",
        action="store",
        help="The domain that the application will be hosted on",
    )

    # deploy arguments
    dep_parser = subparsers.add_parser(
        "deploy",
        help="Deploy alchemite",
        description="Use a prepared configuration to deploy a new version of alchemite",
    )

    dep_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print out the diff for a deployment instead of deploying",
    )

    dep_parser.add_argument(
        "--namespace",
        action="store",
        help="The namespace to deploy Alchemite application charts into",
    )

    dep_parser.add_argument(
        "--atomic",
        action="store_true",
        help="Automatically rollback a deployment in the event that it fails",
    )

    return parser


def clean_domain(domain: str | None) -> str | None:
    if domain is None:
        return None
    domain = domain.strip().strip("/")
    if "://" in domain:
        _, domain = domain.rsplit("/", 1)
    return domain


async def amain() -> None:
    parser = generate_cli()
    args = parser.parse_args()
    logging.basicConfig(
        level=args.log_level, stream=sys.stderr, format="%(message)s"
    )

    # Suppress helm command errors
    logging.getLogger("pyhelm3.command").setLevel(logging.ERROR)
    if args.log_level == "INFO":
        # A few httpx logs are at info that I'd prefer be at DEBUG, so suppress
        logging.getLogger("httpx").setLevel(logging.WARNING)

    command = args.command
    if command == "prepare":
        versions = {
            i: getattr(args, f"{i.replace('-', '_')}_version")
            for i in VERSION_SANITIZERS.keys()
        }
        if any(v != "latest" for v in versions.values()) and args.read_versions:
            raise ValueError(
                "read-versions cannot be used with explicit version arguments"
            )
        await prepare(
            raw_config_path=args.config_path,
            rotate_secrets=args.rotate,
            enable_oligo=args.oligo,
            rehost_images=args.rehost_images,
            unpinned_images=args.unpinned_images,
            desired_versions=versions,
            read_versions=args.read_versions,
            pull_secret=args.pull_secret,
            domain=clean_domain(args.domain),
        )
    if command == "deploy":
        await deploy(
            raw_config_path=args.config_path,
            dry_run=args.dry_run,
            namespace=args.namespace,
            atomic=args.atomic,
        )


def main() -> None:
    try:
        asyncio.run(amain())
    except Abort as e:
        logging.error(e)
        logging.shutdown()
        exit(1)


if __name__ == "__main__":
    main()
