import os
import requests
import json
import logging
import asyncio
from typing import Optional, Any
from mcp.server.fastmcp import FastMCP

# Initialize FastMCP Server
mcp = FastMCP("Trgr")

# Trgr Configuration
TRGR_HOST = os.environ.get("TRGR_HOST", "127.0.0.1")
TRGR_PORT = os.environ.get("TRGR_PORT", "9773")
TRGR_TOKEN = os.environ.get("TRGR_TOKEN")
TRGR_URL = f"http://{TRGR_HOST}:{TRGR_PORT}/notify"

def _send_notification(title: str, body: Optional[str] = None, channel: str = "general", priority: str = "normal", url: Optional[str] = None) -> str:
    """Internal helper to hit the Trgr API."""
    if not TRGR_TOKEN:
        return "Error: TRGR_TOKEN environment variable is not set."
        
    payload = {
        "title": title,
        "channel": channel,
        "priority": priority,
    }
    if body:
        payload["body"] = body
    if url:
        payload["url"] = url
        
    headers = {
        "Authorization": f"Bearer {TRGR_TOKEN}",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.post(TRGR_URL, headers=headers, json=payload)
        
        if response.status_code == 401:
            return "Error: Unauthorized. Invalid or missing Trgr API token."
        elif response.status_code == 200:
            data = response.json()
            return f"Success: Notification sent. (ID: {data.get('id')})"
        else:
            return f"Error: Trgr server returned status {response.status_code}. Response: {response.text}"
    except requests.exceptions.ConnectionError:
        return "Error: Could not connect to Trgr server. Is the Trgr app running?"
    except Exception as e:
        return f"Error: {str(e)}"

@mcp.tool()
def send_notification(
    title: str, 
    body: str = "", 
    channel: str = "agent", 
    priority: str = "normal", 
    url: str = ""
) -> str:
    """
    Send a notification to the user's Trgr menu bar app.
    
    Args:
        title: Short headline describing the notification.
        body: Optional supporting detail or message.
        channel: Grouping label (e.g. 'research', 'build', 'general'). Defaults to 'agent'.
        priority: 'low', 'normal', or 'urgent'. 'urgent' triggers a native system popup.
        url: Optional clickable URL that the user can open.
    """
    # The default values for FastMCP don't perfectly map to Optional[] all the time, 
    # so we treat empty string as None going to the API
    _body = body if body != "" else None
    _url = url if url != "" else None
    
    return _send_notification(title, _body, channel, priority, _url)

def main():
    """Main entry point for the CLI."""
    logging.basicConfig(level=logging.INFO)
    if not TRGR_TOKEN:
        logging.warning("TRGR_TOKEN is not set in the environment. Notifications will fail until it is provided.")
        
    mcp.run()

if __name__ == "__main__":
    main()
