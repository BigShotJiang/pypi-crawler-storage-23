# trgr-mcp

An [MCP](https://modelcontextprotocol.io/) server that lets AI agents — Claude Code, Claude Desktop, Cursor, and others — send notifications directly to your [Trgr](https://fractals.sg) macOS menu bar app.

## Quickstart (recommended)

Open the **Trgr** menu bar app → gear icon → **Connect to Claude Code → Copy MCP Config JSON**.

Paste the copied block into your config. Your token and port are pre-filled. Done.

---

## Manual setup

### Claude Desktop / Claude Code

Add to `claude_desktop_config.json`
(usually at `~/Library/Application Support/Claude/claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "trgr": {
      "command": "uvx",
      "args": ["trgr-mcp"],
      "env": {
        "TRGR_TOKEN": "your-trgr-token-here"
      }
    }
  }
}
```

Find your token: click the Trgr icon in your menu bar → gear → **Copy API Token**.

### pip

```bash
pip install trgr-mcp
TRGR_TOKEN="your-token" trgr-mcp
```

---

## Available tools

| Tool | Description |
|---|---|
| `send_notification` | Send a notification to the Trgr app |

**`send_notification` parameters:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `title` | string | required | Short headline |
| `body` | string | `""` | Supporting detail |
| `channel` | string | `"agent"` | Grouping label (e.g. `"claude-code"`, `"build"`) |
| `priority` | string | `"normal"` | `"low"`, `"normal"`, or `"urgent"` — urgent fires a native macOS popup |
| `url` | string | `""` | Optional URL, opened when the user clicks the notification |

---

## Environment variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `TRGR_TOKEN` | Yes | — | Your Trgr API token |
| `TRGR_HOST` | No | `127.0.0.1` | Trgr host |
| `TRGR_PORT` | No | `9773` | Trgr port |
