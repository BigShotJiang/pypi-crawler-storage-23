Xclif
=====

**Xclif** is an opinionated Python framework for building beautiful, scalable CLIs that feature
file-based routing and a decorator-based API.

.. code-block:: bash

   pip install xclif

.. toctree::
   :maxdepth: 2
   :caption: Getting Started

   getting-started
   quickstart

.. toctree::
   :maxdepth: 2
   :caption: Guides

   routing
   commands
   options

.. toctree::
   :maxdepth: 1
   :caption: Reference

   api
   design/option-system

.. toctree::
   :maxdepth: 1
   :caption: Project

   architecture
   manifesto
   changelog
