```{include} ../../docs/option-system-design.md
```
