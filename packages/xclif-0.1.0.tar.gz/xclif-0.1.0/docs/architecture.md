```{include} ../ARCHITECTURE.md
```
