```{include} ../MANIFESTO.md
```
