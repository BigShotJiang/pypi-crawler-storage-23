API Reference
=============

xclif (public API)
------------------

.. automodule:: xclif
   :members:
   :undoc-members:
   :show-inheritance:

xclif.command
-------------

.. automodule:: xclif.command
   :members:
   :undoc-members:
   :show-inheritance:
   :no-index:

xclif.definition
----------------

.. automodule:: xclif.definition
   :members:
   :undoc-members:
   :show-inheritance:

xclif.annotations
-----------------

.. automodule:: xclif.annotations
   :members:
   :undoc-members:
   :show-inheritance:

xclif.errors
------------

.. automodule:: xclif.errors
   :members:
   :undoc-members:
   :show-inheritance:

xclif.parser
------------

.. automodule:: xclif.parser
   :members:
   :undoc-members:
   :show-inheritance:

xclif.importer
--------------

.. automodule:: xclif.importer
   :members:
   :undoc-members:
   :show-inheritance:
