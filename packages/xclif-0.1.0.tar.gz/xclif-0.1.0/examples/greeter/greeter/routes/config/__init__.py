from xclif import command


@command()
def _() -> None:
    """Manage greeter config."""
