from xclif import command


@command()
def greeter() -> None:
    """An over-engineered hello world CLI."""
