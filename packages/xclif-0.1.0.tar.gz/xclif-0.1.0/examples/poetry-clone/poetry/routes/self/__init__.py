from xclif import command


@command()
def _() -> None:
    """Manage the Poetry installation itself."""
