from xclif import command


@command()
def _() -> None:
    """Show information about the Poetry installation."""
