from xclif import command


@command("xclif-greeter")
def _() -> None:
    """Greeter CLI."""
