# Contributing

See [ARCHITECTURE.md](ARCHITECTURE.md) for an overview of the internal code structure.

Run tests with:

```bash
uv run pytest
```
