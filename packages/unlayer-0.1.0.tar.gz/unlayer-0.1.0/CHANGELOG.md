# Changelog

## 0.1.0 (2026-02-24)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/unlayer/unlayer-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** api update ([e247358](https://github.com/unlayer/unlayer-python/commit/e24735806fc790506d1d3b9ee84954809bd02258))
* **api:** api update ([1255c9b](https://github.com/unlayer/unlayer-python/commit/1255c9b3e6bd708eefb21313c022a1018a78fc3e))
* **api:** api update ([3901e44](https://github.com/unlayer/unlayer-python/commit/3901e44ec76d4bdc1ae8055639d1121965f8e6c6))
* **api:** api update ([e90df1d](https://github.com/unlayer/unlayer-python/commit/e90df1d06e53f40707ccc73610d797eaa3c51fa5))
* **api:** api update ([d0bb085](https://github.com/unlayer/unlayer-python/commit/d0bb0855866ba1daf54f700415c01fcf752090f3))
* **api:** api update ([39253ba](https://github.com/unlayer/unlayer-python/commit/39253ba25f6a5da8e18da9d564af41e0c7e4c0e7))
* **api:** api update ([b65e14e](https://github.com/unlayer/unlayer-python/commit/b65e14e7a19564d228e7436bae27b35a9ede6693))
* **api:** api update ([d83034d](https://github.com/unlayer/unlayer-python/commit/d83034df2dbb4dfc3ee96d101bcdce87dc66306f))
* **api:** api update ([93b319e](https://github.com/unlayer/unlayer-python/commit/93b319e21ac5f484c9d3efa4a51fba4269fe6737))
* **api:** api update ([dd927cc](https://github.com/unlayer/unlayer-python/commit/dd927cc54abf0b619091f71e91d778da87323043))
* **api:** api update ([1a2f183](https://github.com/unlayer/unlayer-python/commit/1a2f183e4fd9a9e512a41855aa1b91b4d28d6bdf))
* **api:** api update ([1cf5d8e](https://github.com/unlayer/unlayer-python/commit/1cf5d8e9a10c2b8684838fa628b1b864bbe74209))
* **api:** api update ([35876ba](https://github.com/unlayer/unlayer-python/commit/35876ba78ab506c86a36ae8aead33bf3f04549a6))
* **api:** api update ([eafe372](https://github.com/unlayer/unlayer-python/commit/eafe372ab530d1a516b6f88630060dd1e384a288))
* **api:** api update ([db50139](https://github.com/unlayer/unlayer-python/commit/db5013964e0c7efdc485708d622c12fde20c9420))
* **api:** api update ([37dfa82](https://github.com/unlayer/unlayer-python/commit/37dfa8228ed4158855318afb16b50dc71c78b1bb))
* **api:** api update ([04d7f14](https://github.com/unlayer/unlayer-python/commit/04d7f14ec06f71d777b7624b8898e3594dcb88f0))
* **api:** api update ([7dbfb1a](https://github.com/unlayer/unlayer-python/commit/7dbfb1aa7fa765b1750f6ed5a733f4cf584c9766))
* **api:** api update ([51ce8ef](https://github.com/unlayer/unlayer-python/commit/51ce8ef8927b0824ccd847e0acf61cd57388ae0f))
* **client:** add custom JSON encoder for extended type support ([16d4717](https://github.com/unlayer/unlayer-python/commit/16d4717e1dec685c212a6c7d74e969660cf7e03c))
* **client:** add support for binary request streaming ([191bd18](https://github.com/unlayer/unlayer-python/commit/191bd18a0c2588e3742b49b2bb85c23f31c18367))


### Bug Fixes

* use async_to_httpx_files in patch method ([f9bdb58](https://github.com/unlayer/unlayer-python/commit/f9bdb58b5c218d7310e8c3328fc79d2322bc7d24))


### Chores

* **ci:** upgrade `actions/github-script` ([89356cd](https://github.com/unlayer/unlayer-python/commit/89356cd10af2df4ce00e52b3857e772c2ffdda9f))
* configure new SDK language ([9596a35](https://github.com/unlayer/unlayer-python/commit/9596a35093e7c1a7bfb9c1a9da7319482ed4f9c8))
* format all `api.md` files ([eaab341](https://github.com/unlayer/unlayer-python/commit/eaab341586836de0b5d88ccd15ba91bf5d9fb8a9))
* **internal:** add `--fix` argument to lint script ([3402766](https://github.com/unlayer/unlayer-python/commit/340276634acd12227076b5b3fbc3a1d5a8aaaf2f))
* **internal:** add missing files argument to base client ([011c5b3](https://github.com/unlayer/unlayer-python/commit/011c5b3e1d285ad929aa23fbd18f22ded6e37bc2))
* **internal:** add request options to SSE classes ([8215016](https://github.com/unlayer/unlayer-python/commit/82150166172718373d5c625fcb2abd63b996d1c4))
* **internal:** bump dependencies ([4796143](https://github.com/unlayer/unlayer-python/commit/47961438c81e3263207987628d1f00c04a117189))
* **internal:** codegen related update ([d4e8db7](https://github.com/unlayer/unlayer-python/commit/d4e8db7de852054c9232097b80832e630383da0e))
* **internal:** fix lint error on Python 3.14 ([e825b41](https://github.com/unlayer/unlayer-python/commit/e825b41fa160ab18110a59b28ffdf3c504d63407))
* **internal:** make `test_proxy_environment_variables` more resilient ([17a5609](https://github.com/unlayer/unlayer-python/commit/17a5609325e6661d12910c96b3f41ecde33e5cf1))
* **internal:** update `actions/checkout` version ([942160b](https://github.com/unlayer/unlayer-python/commit/942160b8a331a9d21fe2349fba265fd6fb520034))
* speedup initial import ([a0429e9](https://github.com/unlayer/unlayer-python/commit/a0429e971dcf003df2bbfd2d523bea4aab46db76))
* update mock server docs ([e835dc3](https://github.com/unlayer/unlayer-python/commit/e835dc37eab896b138333888f423ba0aae6f0958))
* update SDK settings ([52e5d05](https://github.com/unlayer/unlayer-python/commit/52e5d054a25723d3798cd8a571cd48bc7625bce9))
* update SDK settings ([63ab6f7](https://github.com/unlayer/unlayer-python/commit/63ab6f7d4fee33593fe9d3dfb6daa615bc00897e))
