```{include} ../../README.md
```

```{toctree}
:maxdepth: 2
:caption: Contents:

api/index
```

## Indices and tables

- {ref}`genindex`
- {ref}`modindex`
