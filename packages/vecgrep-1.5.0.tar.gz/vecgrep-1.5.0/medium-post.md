# Stop Sending Your Entire Codebase to Claude — Meet VecGrep

## The problem every developer hits

You're working on a large codebase and you ask Claude Code something simple:

> *"How does authentication work in this project?"*

Claude reads `auth.py`. Then `middleware.py`. Then `utils.py`. Then `config.py`. Then `models.py`. By the time it answers, it has consumed 25,000 tokens just to find 400 tokens worth of relevant code.

On a big codebase this happens on every question, every session. You burn through your context window before getting anything done. Sound familiar?

This is the problem I built VecGrep to solve.

---

## What Cursor does that Claude Code doesn't

If you've used Cursor IDE, you've seen this done right. Cursor indexes your codebase into a vector store and retrieves only the semantically relevant chunks before sending anything to the model. Instead of reading 50 files, it sends 8 relevant snippets.

Claude Code is powerful but it has no equivalent — until now.

**VecGrep brings Cursor-style semantic code search to Claude Code as an MCP plugin.**

---

## How it works

VecGrep runs as a local MCP server alongside Claude Code. When you ask Claude about your codebase, instead of reading files directly, it calls VecGrep's tools:

**Indexing** — VecGrep walks your project, parses source files with tree-sitter to extract semantic units (functions, classes, methods), embeds each chunk locally using `all-MiniLM-L6-v2` (a 384-dimensional model, ~80MB, runs fully offline), and stores everything in SQLite under `~/.vecgrep/`.

**Searching** — When Claude needs to find code, it embeds your query into the same vector space and does cosine similarity search against all stored chunks. The top 8 most relevant snippets come back — that's it.

```
Without VecGrep:   ~30,000 tokens to answer one question
With VecGrep:      ~1,600 tokens for the same answer
                   → 95% token reduction
```

The math is simple: 8 chunks × ~200 tokens each = ~1,600 tokens vs reading 50 files.

---

## The architecture

```
index_codebase(path)
  → Walk files (respects .gitignore, skips binaries)
  → SHA-256 hash each file (skip unchanged on re-index)
  → tree-sitter AST chunks (functions/classes/methods)
    or sliding-window fallback for unsupported languages
  → Embed with all-MiniLM-L6-v2 locally
  → Store in SQLite + in-memory cache

search_code(query, path, top_k=8)
  → Embed query
  → Cosine similarity against cached embeddings
  → Return top-k chunks with file, line numbers, score
```

Everything runs locally — no API calls, no data leaving your machine. The model is downloaded once and cached.

---

## Getting started in 60 seconds

**Install:**
```bash
pip install vecgrep
# or
uvx vecgrep  # no install needed
```

**Add to Claude Code:**
```bash
claude mcp add vecgrep -- uvx vecgrep
```

Or add to `~/.claude/claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "vecgrep": {
      "command": "uvx",
      "args": ["vecgrep"]
    }
  }
}
```

That's it. Now just talk to Claude naturally:

> *"How does authentication work in /Users/me/myproject?"*

Claude will index your project on first use, then search it semantically on every question. No manual steps.

---

## What makes it production-ready

*This isn't a weekend hack. VecGrep v1.0 ships with:*

- **Atomic updates** — file changes are committed in a single SQLite transaction, no partial writes on crash
- **Orphan cleanup** — deleted files are automatically removed from the index on next run
- **Concurrency safety** — per-path threading locks prevent corruption from parallel indexing
- **In-memory cache** — embeddings load into RAM on first search, no repeated disk reads
- **52 tests** across store, chunker, embedder, and integration layers
- **CI with coverage** via GitHub Actions + Codecov

---

## The bigger picture

VecGrep solves one half of the token problem. The other half — remembering past decisions, architectural context, what was tried and failed — is what tools like `claude-mem` handle. Together they form a complete stack:

| Problem | Solution |
|---|---|
| Re-reading code files every question | VecGrep |
| Re-learning past decisions every session | claude-mem |
| Re-learning project structure on session start | CLAUDE.md |

Claude Code is already powerful. These tools make it token-efficient enough to work on real production codebases.

---

## Try it

```bash
pip install vecgrep
```

Source: [github.com/iamvirul/VecGrep](https://github.com/iamvirul/VecGrep)

If this saves you tokens, drop a star on the repo. If you hit issues, open one — contributions are welcome.
