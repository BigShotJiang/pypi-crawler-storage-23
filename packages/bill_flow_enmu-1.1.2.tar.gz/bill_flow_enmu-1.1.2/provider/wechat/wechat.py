import pandas as pd
import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
from ir.ir import IR
from provider.wechat.wecaht_types import WechatOrder, DealType, TxType
from provider.wechat.converter import convert_to_ir


class Wechat:
    orders: list[WechatOrder]

    def __init__(self):
        self.orders = []

    def translate(self, filename: str) -> IR:
        # 读取文件获取每一行
        try:
            # with open(file=filename, mode="r", encoding="utf-8"):
            df = pd.read_excel(
                "/Users/enmu/code/study/program/python/script/flow/finance-flow/test/a.xlsx",
                skiprows=16,
            )
            for row in df.to_dict("records"):
                self.translate_order(row)

            ir = convert_to_ir(self.orders)

            return ir
        except Exception as e:
            print(e)

    def translate_order(self, row: dict):
        wechat_order = WechatOrder(
            order_id=row["交易单号"],
            mechant_order_id=row["商户单号"],
            pay_time=row["交易时间"].split(" ")[0],
            type=DealType(row["收/支"]),
            type_original=row["收/支"],
            peer=row["交易对方"],
            item=row["商品"],
            money=row["金额(元)"].replace("¥", ""),
            status=row["当前状态"],
            method=row["支付方式"],
            tx_type=TxType(row["交易类型"]),
            tx_type_original=row["交易类型"],
            commision="",
        )

        self.orders.append(wechat_order)
