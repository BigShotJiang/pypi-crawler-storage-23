# NOTICE

This package reassembles the public GGUF file `gemma-3-270m-q4_k_m.gguf` from chunk packages.

Upstream GGUF source:

- https://huggingface.co/hugginllam/gemma-3-270m-Q4_K_M-GGUF

Included metadata files:

- `README.upstream.md` copied from the upstream GGUF repository
- `GEMMA_TERMS.html` fetched from https://ai.google.dev/gemma/terms
- `SHA256SUMS` for the original full GGUF file
