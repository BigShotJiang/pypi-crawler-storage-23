"""Poke MCP callback sugar for long-running tool functions.

Provides ``with_callbacks`` and ``PokeCallbackMiddleware`` so Python MCP
tool authors can send asynchronous progress updates back to Poke, mirroring
the TypeScript ``mcp-callback-sugar.ts`` pattern.

Requires Python 3.10+ (MCP SDK dependency).
"""

from __future__ import annotations

import sys

if sys.version_info < (3, 10):
    raise ImportError(
        "poke.mcp requires Python 3.10 or later. "
        "The base poke package still supports Python 3.8+."
    )

import asyncio
import json
import functools
import urllib.request
import urllib.error
from contextvars import ContextVar, Token
from dataclasses import dataclass
from typing import Any, AsyncGenerator, Callable, Optional, TypeVar

# ---------------------------------------------------------------------------
# Callback context
# ---------------------------------------------------------------------------

@dataclass
class CallbackContext:
    """Holds the callback token and URL extracted from request headers."""

    callback_token: Optional[str]
    callback_url: Optional[str]


_callback_context: ContextVar[Optional[CallbackContext]] = ContextVar(
    "_callback_context", default=None
)


def set_callback_context(ctx: CallbackContext) -> Token[Optional[CallbackContext]]:
    """Manually set the callback context (returns a reset token)."""
    return _callback_context.set(ctx)


def reset_callback_context(token: Token[Optional[CallbackContext]]) -> None:
    """Reset the callback context using the token from ``set_callback_context``."""
    _callback_context.reset(token)


def extract_callback_context(headers: dict[str, str]) -> Optional[CallbackContext]:
    """Build a ``CallbackContext`` from a header dict (case-insensitive keys).

    Returns ``None`` when neither header is present.  Useful for non-ASGI
    servers (e.g. Flask / Django) that expose headers as a plain dict.
    """
    lower = {k.lower(): v for k, v in headers.items()}
    cb_token = lower.get("x-poke-callback-token")
    cb_url = lower.get("x-poke-callback-url")
    if cb_token is None and cb_url is None:
        return None
    return CallbackContext(callback_token=cb_token, callback_url=cb_url)


# ---------------------------------------------------------------------------
# HTTP callback sender (zero-dependency, runs in a thread)
# ---------------------------------------------------------------------------


def _send_callback_sync(
    *,
    url: str,
    token: str,
    content: str,
    has_more: bool,
) -> dict[str, Any]:
    """Blocking HTTP POST — intended to be called via ``asyncio.to_thread``."""
    body = json.dumps({"content": content, "hasMore": has_more}).encode()
    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as exc:
        if exc.code == 429:
            try:
                err_body = json.loads(exc.read().decode())
            except Exception:
                err_body = {}
            return {"_retry": True, "retryAfterMs": err_body.get("retryAfterMs", 60_000)}
        return {"nextToken": None}
    except urllib.error.URLError:
        return {"nextToken": None}


async def _send_callback(
    *,
    url: str,
    token: str,
    content: str,
    has_more: bool,
) -> dict[str, Any]:
    """Send a callback POST, retrying on 429."""
    while True:
        result = await asyncio.to_thread(
            _send_callback_sync,
            url=url,
            token=token,
            content=content,
            has_more=has_more,
        )
        if result.get("_retry"):
            delay_ms = result.get("retryAfterMs", 60_000)
            await asyncio.sleep(delay_ms / 1000)
            continue
        return result


# ---------------------------------------------------------------------------
# with_callbacks decorator
# ---------------------------------------------------------------------------

T = TypeVar("T")


def with_callbacks(
    handler: Callable[..., AsyncGenerator[str, None]],
) -> Callable[..., Any]:
    """Decorator that turns an async-generator MCP tool into a callback-aware tool.

    Usage::

        @mcp.tool()
        @with_callbacks
        async def my_tool(x: int):
            yield "Starting..."
            await do_work()
            yield "All done!"   # last yield sent with hasMore=False

    The **first yield** is returned immediately as the MCP tool result.
    Subsequent yields are POSTed to the Poke callback URL in a background
    task.  The **last yield** is sent with ``hasMore=False``.

    If no callback context is present (i.e. the request didn't include
    ``X-Poke-Callback-Token``/``X-Poke-Callback-Url`` headers), remaining
    yields after the first are silently discarded.
    """

    @functools.wraps(handler)
    async def wrapper(*args: Any, **kwargs: Any) -> list[dict[str, str]]:
        ctx = _callback_context.get()
        callback_token = ctx.callback_token if ctx else None
        callback_url = ctx.callback_url if ctx else None

        gen = handler(*args, **kwargs)
        first = await gen.__anext__()

        if callback_token and callback_url:

            async def _background() -> None:
                current_token: str = callback_token  # type: ignore[assignment]
                # Buffer one value ahead so we can detect the final yield.
                try:
                    buffered = await gen.__anext__()
                except StopAsyncIteration:
                    # Only one yield total — already returned as tool result.
                    return

                while True:
                    try:
                        next_val = await gen.__anext__()
                    except StopAsyncIteration:
                        # `buffered` is the last value — send with hasMore=False
                        await _send_callback(
                            url=callback_url,  # type: ignore[arg-type]
                            token=current_token,
                            content=buffered,
                            has_more=False,
                        )
                        return

                    # `buffered` is intermediate — send with hasMore=True
                    sent = await _send_callback(
                        url=callback_url,  # type: ignore[arg-type]
                        token=current_token,
                        content=buffered,
                        has_more=True,
                    )

                    next_token = sent.get("nextToken")
                    if next_token:
                        current_token = next_token
                    else:
                        # Turn limit reached — close the generator and stop.
                        await gen.aclose()
                        return

                    buffered = next_val

            task = asyncio.create_task(_background())
            task.add_done_callback(_log_task_exception)
        else:
            # No callback context — close the generator to free resources.
            await gen.aclose()

        return [{"type": "text", "text": first}]

    return wrapper


def _log_task_exception(task: asyncio.Task[Any]) -> None:
    if not task.cancelled() and task.exception() is not None:
        import logging

        logging.getLogger("poke.mcp").warning(
            "Background callback loop failed: %s", task.exception()
        )


# ---------------------------------------------------------------------------
# ASGI middleware
# ---------------------------------------------------------------------------


class PokeCallbackMiddleware:
    """ASGI middleware that extracts Poke callback headers into a ContextVar.

    Usage::

        app = PokeCallbackMiddleware(mcp.http_app())
    """

    def __init__(self, app: Any) -> None:
        self.app = app

    async def __call__(self, scope: dict[str, Any], receive: Any, send: Any) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        headers = dict(scope.get("headers", []))
        cb_token = headers.get(b"x-poke-callback-token")
        cb_url = headers.get(b"x-poke-callback-url")

        ctx = CallbackContext(
            callback_token=cb_token.decode() if cb_token else None,
            callback_url=cb_url.decode() if cb_url else None,
        )
        tok = _callback_context.set(ctx)
        try:
            await self.app(scope, receive, send)
        finally:
            _callback_context.reset(tok)
