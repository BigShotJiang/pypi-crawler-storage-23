"""Resolver — resolucao de elementos por tipo+indice, capture, replay, run_json."""
from smartwright.resolver.emergency import EmergencyResolver

__all__ = ["EmergencyResolver"]
