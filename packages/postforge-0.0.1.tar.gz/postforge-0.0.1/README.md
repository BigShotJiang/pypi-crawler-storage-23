# PostForge

A PostScript interpreter written in Python.

**This is a placeholder release to reserve the package name.** The full package is under active development.

See the [GitHub repository](https://github.com/AndyCappDev/postforge) for details.
