# coding=utf-8
#
# file_commands.py
# File-related commands
#

from typing import Optional
from pathlib import Path

from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.patch_stdout import patch_stdout
from rich.prompt import Prompt

from ..top import gede_dir
from .base import CommandBase
from ..chatcore import (
    ExportChat,
    load_private_chats_files,
    load_public_chats_files,
    ChatModel,
)


class PublicChatFileCompleter(Completer):
    def get_completions(self, document, complete_event):
        files = load_public_chats_files()
        text = document.text.lower()
        for one in files:
            if text in one[0].lower():
                yield Completion(
                    text=one[1], start_position=-len(document.text), display=one[0]
                )


class PrivateChatFileCompleter(Completer):
    def get_completions(self, document, complete_event):
        files = load_private_chats_files()
        text = document.text.lower()
        for one in files:
            if text in one.lower():
                yield Completion(one, start_position=-len(document.text))


class SaveCommand(CommandBase):
    async def do_command_async(self) -> bool:
        if self.message == "/save":
            if self.context.current_chat.is_private:
                password = Prompt.ask(
                    "[bold dim]Input password for private chat[/bold dim]",
                    password=True,
                )
                password = password.strip()
                if not password:
                    self.context.notification_display.warning(
                        "Password cannot be empty."
                    )
                    return False
                self.context.current_chat.private_password = password

            await self.context.current_chat.geneate_title()

            # Need to generate filename before saving
            self.context.current_chat.generate_filename()
            filepath = self.context.current_chat.save()
            if filepath:
                self.context.notification_display.success(
                    f"Chat saved successfully in {filepath}. Title: {self.context.current_chat.title}"
                )
            else:
                self.context.notification_display.warning("Not saved")
            return False
        return True

    @property
    def doc_title(self) -> str:
        return "/save\nPersist current chat to disk"

    @property
    def doc_description(self) -> str:
        return "Save the current chat to disk. Public chats auto-save with generated titles. Private chats require a password for encryption and must be manually saved. Files are stored in ~/.gede/chats/."

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/save"


class LoadChatCommand(CommandBase):
    async def pick_file(self) -> Optional[str]:
        completion = PublicChatFileCompleter()
        self.context.notification_display.info(
            "Type to search for chat files, use arrow keys to select."
        )
        try:
            with patch_stdout():
                filename: str = await self.context.prompt_session.prompt_async(
                    "Select Chat: ",
                    completer=completion,
                    complete_while_typing=True,
                    complete_in_thread=False,
                )
                # self.console.print("You selected: " + filename, style="info")
                return filename
        except KeyboardInterrupt:
            return None

    async def do_command_async(self) -> bool:
        cmd = "/load-chat"
        if self.message.startswith(cmd):
            # filename = self.message[len(cmd) :].strip()
            filename = await self.pick_file()
            if not filename:
                self.context.notification_display.warning("Filename cannot be empty.")
                return False
            chat = ChatModel.load_from_file(filename)
            if not chat:
                self.context.notification_display.error(f"Load chat failed: {filename}")
            else:
                self.context.current_chat = chat
                self.context.print_rule(f"LOAD CHAT: {chat.filename}")
                self.context.print_instruction()
                for message in chat.messages:
                    role = message.role
                    content = message.content
                    if role and content:
                        if role == "system":
                            continue
                        else:
                            role_name = "You" if role == "user" else "Assistant"
                            self.console.print(f"[bold]{role_name}: [/bold]{content}")
            return False
        return True

    @property
    def doc_title(self) -> str:
        return "/load-chat \nLoad a public chat from file"

    @property
    def doc_description(self) -> str:
        return """Load a public chat from a specified file. The chat file should be located in the 'chats/public' directory (default: ~/.gede/chats/public). """

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/load-chat"


class LoadPrivateChatCommand(CommandBase):
    async def pick_file(self) -> Optional[str]:
        completion = PrivateChatFileCompleter()
        self.context.notification_display.info(
            "Type to search for chat files, use arrow keys to select."
        )
        try:
            with patch_stdout():
                filename = await self.context.prompt_session.prompt_async(
                    "Select Private Chat: ",
                    completer=completion,
                    complete_while_typing=True,
                    complete_in_thread=False,
                )
                # self.console.print("You selected: " + filename, style="info")
                return filename
        except KeyboardInterrupt:
            return None

    async def do_command_async(self) -> bool:
        cmd = "/load-private-chat"
        if self.message.startswith(cmd):
            # filename = self.message[len(cmd) :].strip()
            filename = await self.pick_file()
            if not filename:
                self.context.notification_display.warning("Filename cannot be empty.")
                return False
            password = Prompt.ask(
                "[bold dim]Input password for private chat[/bold dim]", password=True
            )
            password = password.strip()
            if not password:
                self.context.notification_display.warning("Password cannot be empty.")
            chat = ChatModel.load_from_file(
                filename, is_private=True, private_password=password
            )
            if not chat:
                self.context.notification_display.error(f"Load chat failed: {filename}")
            else:
                self.context.current_chat = chat
                self.context.print_rule(f"LOAD CHAT: {chat.filename}")
                self.context.print_instruction()
                for message in chat.messages:
                    role = message.role
                    content = message.role
                    if role and content:
                        if role == "system":
                            continue
                        else:
                            role_name = (
                                "You (Private)" if role == "user" else "Assistant"
                            )
                            self.console.print(f"[bold]{role_name}: [/bold]{content}\n")
            return False
        return True

    @property
    def doc_title(self) -> str:
        return "/load-private-chat \nLoad a private chat from file"

    @property
    def doc_description(self) -> str:
        return """Load a private chat from a specified file. You will be prompted to enter the password used to encrypt the chat messages. The chat file should be located in the 'chats/private' directory (default: ~/.gede/chats/private). """

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/load-private-chat"


class ExportCommand(CommandBase):
    async def do_command_async(self) -> bool:
        cmd = "/export"
        if self.message.startswith(cmd):
            filepath = self.message[len(cmd) :].strip()
            if not filepath:
                self.context.notification_display.warning(
                    "Please input a valid file path."
                )
                return False
            path = Path(filepath).expanduser()
            if path.is_absolute():
                if not path.parent.exists():
                    self.context.notification_display.warning(
                        "Parent folder not exists."
                    )
                    return False
            else:
                export_dir = Path(gede_dir()) / "chats" / "exports"
                export_dir.mkdir(parents=True, exist_ok=True)
                path = export_dir / path
                path.parent.mkdir(parents=True, exist_ok=True)
            exporter = ExportChat(self.context.current_chat)
            await exporter.export_txt(path)
            self.context.notification_display.success(f"Exported chat to {str(path)}")
            return False
        return True

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/export"

    @property
    def doc_title(self) -> str:
        return "/export <FILEPATH> \nExport the current chat to a specified file"

    @property
    def doc_description(self) -> str:
        return """Export the current chat to a specified file in TXT format. Provide the FILEPATH where you want to save the exported chat. If a relative path is provided, the chat will be saved in the 'chats/exports' directory (default: ~/.gede/chats/exports)."""
