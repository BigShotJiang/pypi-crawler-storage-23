# coding=utf-8
#
# __init__.py
# Commands package
#

from typing import Type, List

from .base import CommandBase, CommandContext
from .common import cleanup_screen

# Import all command classes
from .chat_commands import (
    NewPublicChatCommand,
    NewPrivateChatCommand,
    QuitCommand,
    ChatInfoCommand,
    CloneChatCommand,
)
from .instruction_commands import (
    SetInstructionCommand,
    GetInstructionCommand,
    SelectInstructionCommand,
)
from .model_commands import (
    SelectLLMCommand,
    ManageProviderModelsCommand,
    SetMessageNumCommand,
    SetModelSettingsCommand,
    GetModelSettingsCommand,
    SetModelReasoningCommand,
)
from .file_commands import (
    SaveCommand,
    LoadChatCommand,
    LoadPrivateChatCommand,
    ExportCommand,
)
from .tool_commands import (
    SelectToolsCommand,
    SelectMCPCommand,
)
from .other_commands import (
    CleanupCommand,
    SelectPromptCommand,
    HelpCommand,
)


def get_command_class_list() -> list[Type[CommandBase]]:
    """Get all synchronous command classes"""
    return []


def get_command_class_list_async() -> list[Type[CommandBase]]:
    """Get all asynchronous command classes"""
    return [
        NewPublicChatCommand,
        NewPrivateChatCommand,
        QuitCommand,
        GetInstructionCommand,
        SelectInstructionCommand,
        SelectLLMCommand,
        ManageProviderModelsCommand,
        ChatInfoCommand,
        SetMessageNumCommand,
        CleanupCommand,
        HelpCommand,
        SelectPromptCommand,
        SetModelSettingsCommand,
        GetModelSettingsCommand,
        SetModelReasoningCommand,
        SelectToolsCommand,
        CloneChatCommand,
        ExportCommand,
        SaveCommand,
        LoadChatCommand,
        LoadPrivateChatCommand,
        SetInstructionCommand,
        SelectMCPCommand,
    ]


async def do_command(context: CommandContext) -> bool:
    """
    Execute command
    """

    for one_command in get_command_class_list():
        command_instance = one_command(context)
        if command_instance.do_command():
            continue
        else:
            return False
    for one_command in get_command_class_list_async():
        command_instance = one_command(context)
        if await command_instance.do_command_async():
            continue
        else:
            return False

    if context.message and context.message.startswith("/"):
        context.console.print("Unknown command:" + context.message, style="danger")
        return False
    return True


def get_command_hints() -> List[str]:
    """
    Get all command hints
    Returns: Command hints list
    """
    from rich.console import Console
    from prompt_toolkit import PromptSession

    hints = []
    command_list = get_command_class_list() + get_command_class_list_async()
    context = CommandContext(
        console=Console(),
        message="",
        current_chat=None,  # type: ignore
        prompt_session=PromptSession(),
    )
    for one_command in command_list:
        command_instance = one_command(context)
        hint = command_instance.command_hint
        if hint:
            if isinstance(hint, str):
                hints.append(hint)
            elif isinstance(hint, tuple):
                hints.extend(list(hint))
    return hints


__all__ = [
    "CommandBase",
    "cleanup_screen",
    "do_command",
    "get_command_hints",
    "get_command_class_list",
    "get_command_class_list_async",
    # Export command classes for backward compatibility
    "NewPublicChatCommand",
    "NewPrivateChatCommand",
    "QuitCommand",
    "ChatInfoCommand",
    "CloneChatCommand",
    "SetInstructionCommand",
    "GetInstructionCommand",
    "SelectInstructionCommand",
    "SelectLLMCommand",
    "ManageProviderModelsCommand",
    "SetMessageNumCommand",
    "SetModelSettingsCommand",
    "GetModelSettingsCommand",
    "SetModelReasoningCommand",
    "SaveCommand",
    "LoadChatCommand",
    "LoadPrivateChatCommand",
    "SelectToolsCommand",
    "SelectMCPCommand",
    "CleanupCommand",
    "SelectPromptCommand",
    "HelpCommand",
    "ExportCommand",
]
