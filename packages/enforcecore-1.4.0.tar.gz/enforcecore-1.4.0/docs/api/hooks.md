# Lifecycle Hooks

::: enforcecore.plugins.hooks.HookRegistry

::: enforcecore.plugins.hooks.HookContext

::: enforcecore.plugins.hooks.ViolationHookContext

::: enforcecore.plugins.hooks.RedactionHookContext

## Decorator Shortcuts

::: enforcecore.plugins.hooks.on_pre_call

::: enforcecore.plugins.hooks.on_post_call

::: enforcecore.plugins.hooks.on_violation

::: enforcecore.plugins.hooks.on_redaction
