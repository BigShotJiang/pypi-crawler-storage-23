"""Tests for the setup (enrollment) CLI command."""

import os
import stat
from pathlib import Path
from unittest.mock import MagicMock, patch

import httpx
import yaml
from click.testing import CliRunner

from posture_agent.main import cli, _mask_key


class TestSetupTokenValidation:
    """Test token format validation."""

    def test_invalid_token_prefix_rejected(self):
        """A token not starting with hse_ should be rejected."""
        runner = CliRunner()
        result = runner.invoke(cli, ["setup", "--token", "bad_token_123"])
        assert result.exit_code == 1
        assert "Invalid enrollment token" in result.output
        assert "hse_" in result.output

    def test_empty_token_rejected(self):
        """An empty token should be rejected."""
        runner = CliRunner()
        result = runner.invoke(cli, ["setup", "--token", ""])
        assert result.exit_code == 1
        assert "Invalid enrollment token" in result.output

    def test_token_option_required(self):
        """The --token option is required."""
        runner = CliRunner()
        result = runner.invoke(cli, ["setup"])
        assert result.exit_code != 0
        assert "Missing option '--token'" in result.output


class TestSetupExistingConfig:
    """Test behavior when agent is already configured."""

    def test_existing_config_with_api_key_blocks_setup(self, tmp_path):
        """If agent.yaml already has an api_key, setup should refuse."""
        config_dir = tmp_path / ".config" / "intercept"
        config_dir.mkdir(parents=True)
        config_file = config_dir / "agent.yaml"
        config_file.write_text(yaml.dump({
            "api": {"api_key": "hsk_existing_000", "url": "https://example.com"},
        }))

        runner = CliRunner()
        with patch("posture_agent.main.CONFIG_DIR", config_dir), \
             patch("posture_agent.main.CONFIG_FILE", config_file):
            result = runner.invoke(cli, ["setup", "--token", "hse_validtoken"])

        assert result.exit_code == 1
        assert "already configured" in result.output
        assert "uninstall" in result.output.lower()

    def test_existing_config_without_api_key_allows_setup(self, tmp_path):
        """If agent.yaml exists but has no api_key, setup should proceed."""
        config_dir = tmp_path / ".config" / "intercept"
        logs_dir = config_dir / "logs"
        config_dir.mkdir(parents=True)
        logs_dir.mkdir(parents=True)
        config_file = config_dir / "agent.yaml"
        config_file.write_text(yaml.dump({
            "api": {"url": "http://localhost:8000"},
        }))

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_newkey_000000",
            "tenant_id": "tenant-abc",
        }

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.return_value = mock_response

        runner = CliRunner()
        with patch("posture_agent.main.CONFIG_DIR", config_dir), \
             patch("posture_agent.main.CONFIG_FILE", config_file), \
             patch("posture_agent.main.get_machine_fingerprint", return_value="abcd1234" * 4), \
             patch("httpx.Client", return_value=mock_client), \
             patch("posture_agent.main.get_settings") as mock_settings, \
             patch("posture_agent.main.run_collection"):
            mock_settings.return_value.agent_version = "0.3.8"
            mock_settings.return_value.logging_config = {}
            mock_settings.return_value.debug = False
            mock_settings.cache_clear = MagicMock()
            result = runner.invoke(cli, ["setup", "--token", "hse_validtoken"])

        assert "already configured" not in result.output
        assert "Enrolled successfully" in result.output


def _make_mock_client(response):
    """Create a mock httpx.Client context manager."""
    mock_client = MagicMock()
    mock_client.__enter__ = MagicMock(return_value=mock_client)
    mock_client.__exit__ = MagicMock(return_value=False)
    mock_client.post.return_value = response
    return mock_client


def _make_error_client(error):
    """Create a mock httpx.Client that raises on post."""
    mock_client = MagicMock()
    mock_client.__enter__ = MagicMock(return_value=mock_client)
    mock_client.__exit__ = MagicMock(return_value=False)
    mock_client.post.side_effect = error
    return mock_client


class TestSetupEnrollment:
    """Test the enrollment HTTP call and response handling."""

    def _setup_mocks(self, tmp_path):
        """Set up common mocks for enrollment tests."""
        config_dir = tmp_path / ".config" / "intercept"
        logs_dir = config_dir / "logs"
        config_dir.mkdir(parents=True)
        logs_dir.mkdir(parents=True)
        config_file = config_dir / "agent.yaml"
        return config_dir, config_file

    def _run_setup(self, runner, config_dir, config_file, mock_client, token="hse_test", api_url=None, run_collection_side_effect=None):
        """Helper to run setup with common patches."""
        patches = [
            patch("posture_agent.main.CONFIG_DIR", config_dir),
            patch("posture_agent.main.CONFIG_FILE", config_file),
            patch("posture_agent.main.get_machine_fingerprint", return_value="ff" * 16),
            patch("httpx.Client", return_value=mock_client),
            patch("posture_agent.main.get_settings"),
        ]
        if run_collection_side_effect:
            patches.append(patch("posture_agent.main.run_collection", side_effect=run_collection_side_effect))
        else:
            patches.append(patch("posture_agent.main.run_collection"))

        args = ["setup", "--token", token]
        if api_url:
            args.extend(["--api-url", api_url])

        with patches[0], patches[1], patches[2], patches[3], patches[4] as mock_settings, patches[5]:
            mock_settings.return_value.agent_version = "0.3.8"
            mock_settings.return_value.logging_config = {}
            mock_settings.return_value.debug = False
            mock_settings.cache_clear = MagicMock()
            return runner.invoke(cli, args)

    def test_successful_enrollment(self, tmp_path):
        """A 201 response should write config and succeed."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_enrolled_key_abc",
            "tenant_id": "tenant-123",
        }
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client,
                                  token="hse_enrollment_token", api_url="https://test.example.com")

        assert result.exit_code == 0
        assert "Enrolled successfully" in result.output
        assert f"Configuration saved to {config_file}" in result.output

        # Verify config file content
        assert config_file.exists()
        written_config = yaml.safe_load(config_file.read_text())
        assert written_config["api"]["api_key"] == "hsk_enrolled_key_abc"
        assert written_config["api"]["url"] == "https://test.example.com"
        assert "tenant_id" not in written_config.get("api", {})

    def test_config_file_permissions(self, tmp_path):
        """Config file should have 0600 permissions (owner read/write only)."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_permstest",
            "tenant_id": "t-1",
        }
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 0
        file_mode = stat.S_IMODE(os.stat(config_file).st_mode)
        assert file_mode == 0o600, f"Expected 0600, got {oct(file_mode)}"

    def test_expired_token_410(self, tmp_path):
        """A 410 response should show expiration message."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 410
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 1
        assert "expired" in result.output.lower()
        assert "admin" in result.output.lower()

    def test_already_enrolled_409(self, tmp_path):
        """A 409 response should show the conflict detail."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 409
        mock_response.json.return_value = {"detail": "Machine already enrolled"}
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 1
        assert "already enrolled" in result.output.lower()

    def test_invalid_token_401(self, tmp_path):
        """A 401 response should show invalid token message."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 1
        assert "Invalid enrollment token" in result.output
        assert "admin" in result.output.lower()

    def test_validation_error_422(self, tmp_path):
        """A 422 response should show validation error message."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 422
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 1
        assert "Invalid request" in result.output

    def test_unexpected_error_status(self, tmp_path):
        """An unexpected status code should show the code in the message."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 1
        assert "500" in result.output
        assert "admin" in result.output.lower()

    def test_connection_error(self, tmp_path):
        """A connection error should show a helpful message."""
        config_dir, config_file = self._setup_mocks(tmp_path)
        mock_client = _make_error_client(httpx.ConnectError("Connection refused"))

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 1
        assert "Could not connect" in result.output

    def test_timeout_error(self, tmp_path):
        """A timeout error should show a helpful message."""
        config_dir, config_file = self._setup_mocks(tmp_path)
        mock_client = _make_error_client(httpx.TimeoutException("Timed out"))

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 1
        assert "timed out" in result.output.lower()

    def test_config_yaml_has_no_tenant_id(self, tmp_path):
        """The written config should not contain tenant_id."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_notenant",
            "tenant_id": "tenant-should-not-be-in-config",
        }
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 0
        written_config = yaml.safe_load(config_file.read_text())
        assert "tenant_id" not in written_config.get("api", {})

    def test_default_api_url(self, tmp_path):
        """Without --api-url, the default production URL should be used."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_default_url",
            "tenant_id": "t-1",
        }
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 0
        written_config = yaml.safe_load(config_file.read_text())
        assert "hijacksecurity.com" in written_config["api"]["url"]

    def test_first_collection_failure_does_not_fail_setup(self, tmp_path):
        """If the first collection fails, setup should still succeed."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_first_fail",
            "tenant_id": "t-1",
        }
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client,
                                  run_collection_side_effect=RuntimeError("API down"))

        assert result.exit_code == 0
        assert "enrolled but first report failed" in result.output
        assert "retry automatically" in result.output


class TestSetupHelp:
    """Test the setup command help output."""

    def test_setup_help(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["setup", "--help"])
        assert result.exit_code == 0
        assert "--token" in result.output
        assert "--api-url" in result.output


class TestMaskKey:
    """Test the _mask_key helper."""

    def test_short_key(self):
        assert _mask_key("hsk_") == "hsk_..."

    def test_normal_key(self):
        result = _mask_key("hsk_a8kM12345678")
        assert result == "hsk_a8kM1234..."

    def test_exact_boundary(self):
        # 12 chars = boundary, len<=12 uses the short path (first 4 chars)
        assert _mask_key("hsk_a8kM1234") == "hsk_..."

    def test_longer_key(self):
        result = _mask_key("hsk_a8kM1234567890abcdef")
        assert result == "hsk_a8kM1234..."
        assert len(result) == 15
