"""HTTP reporter for sending posture data to the API."""

import logging

import httpx

from posture_agent.core.config import Settings
from posture_agent.models.report import PostureReportPayload

logger = logging.getLogger(__name__)


async def send_report(payload: PostureReportPayload, settings: Settings) -> dict:
    """Send posture report to the API with retry."""
    url = f"{settings.api.url.rstrip('/')}/api/v1/core/posture/reports"

    last_error: Exception | None = None
    for attempt in range(settings.api.retries):
        try:
            headers = {}
            if settings.api.api_key:
                if settings.api.api_key.startswith("hsk_"):
                    headers["X-API-Key"] = settings.api.api_key
                else:
                    logger.warning(
                        "API key does not start with 'hsk_'. "
                        "Sending request without authentication."
                    )

            data = payload.model_dump(mode="json")
            # Only include tenant_id when NOT using an hsk_ API key
            # (API resolves tenant from the key server-side)
            if settings.api.tenant_id and not (
                settings.api.api_key and settings.api.api_key.startswith("hsk_")
            ):
                data["tenant_id"] = settings.api.tenant_id

            async with httpx.AsyncClient(timeout=settings.api.timeout) as client:
                response = await client.post(
                    url,
                    json=data,
                    headers=headers,
                )
                response.raise_for_status()
                return response.json()
        except (httpx.HTTPError, httpx.TimeoutException) as e:
            last_error = e
            if attempt < settings.api.retries - 1:
                import asyncio
                await asyncio.sleep(2 ** attempt)

    raise RuntimeError(f"Failed to send report after {settings.api.retries} attempts: {last_error}")
