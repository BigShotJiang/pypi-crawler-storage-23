from __future__ import annotations

import asyncio
import json
import time
from datetime import UTC, datetime

import pytest
from shared.domain.jobs import CronSource, Job, JobStatus
from shared.contracts import (
    DispatchReason,
    FunctionConfig,
    FunctionType,
    MissedRunPolicy,
)
from shared.keys import cron_registry_member_key
from shared.keys.workers import FUNCTION_KEY_PREFIX
from upnext.engine.queue.base import DuplicateJobError
from upnext.engine.queue.redis.queue import RedisQueue


@pytest.fixture
def queue(fake_redis):
    return RedisQueue(client=fake_redis, claim_timeout_ms=50, key_prefix="upnext-test")


@pytest.mark.asyncio
async def test_enqueue_duplicate_job_key_raises(queue: RedisQueue) -> None:
    job1 = Job(function="task_fn", function_name="task", key="dup-key")
    job2 = Job(function="task_fn", function_name="task", key="dup-key")

    await queue.enqueue(job1)
    with pytest.raises(DuplicateJobError):
        await queue.enqueue(job2)


@pytest.mark.asyncio
async def test_queue_lifecycle_enqueue_dequeue_finish_persists_terminal_payload(
    queue: RedisQueue,
) -> None:
    job = Job(function="task_fn", function_name="task", key="job-key-1")
    await queue.enqueue(job)

    active = await queue.dequeue(["task_fn"], timeout=0.2)
    assert active is not None
    assert active.id == job.id

    await queue.finish(active, JobStatus.COMPLETE, result={"ok": True})

    client = await queue._ensure_connected()  # noqa: SLF001
    job_data = await client.get(queue._job_key(job))  # noqa: SLF001
    index_data = await client.get(queue._job_index_key(job.id))  # noqa: SLF001
    dedup_exists = await client.sismember(queue._dedup_key(job.function), job.key)  # noqa: SLF001

    assert job_data is not None
    assert index_data is not None
    assert dedup_exists == 0


@pytest.mark.asyncio
async def test_retry_keeps_stream_claim_queue_local_and_requeues_immediately(
    queue: RedisQueue,
) -> None:
    job = Job(function="task_fn", function_name="task", key="retry-key")
    await queue.enqueue(job)

    active = await queue.dequeue(["task_fn"], timeout=0.2)
    assert active is not None
    old_claim = queue._peek_stream_claim(active.id)  # noqa: SLF001
    assert old_claim is not None

    await queue.retry(active, delay=0)

    # Retry should keep stream claim queue-local and put the job back on stream.
    requeued = await queue.dequeue(["task_fn"], timeout=0.2)
    assert requeued is not None
    assert requeued.id == active.id
    new_claim = queue._peek_stream_claim(requeued.id)  # noqa: SLF001
    assert new_claim is not None
    assert new_claim.msg_id != old_claim.msg_id


@pytest.mark.asyncio
async def test_retry_with_delay_goes_to_scheduled_set(queue: RedisQueue) -> None:
    job = Job(function="task_fn", function_name="task", key="retry-delay-key")
    await queue.enqueue(job)
    active = await queue.dequeue(["task_fn"], timeout=0.2)
    assert active is not None

    await queue.retry(active, delay=10)

    client = await queue._ensure_connected()  # noqa: SLF001
    scheduled_score = await client.zscore(queue._scheduled_key(job.function), job.id)  # noqa: SLF001
    assert scheduled_score is not None


@pytest.mark.asyncio
async def test_cancel_non_terminal_job_returns_true(queue: RedisQueue) -> None:
    queued_job = Job(function="task_fn", function_name="task", key="cancel-key")
    await queue.enqueue(queued_job)

    assert await queue.cancel(queued_job.id) is True
    cancelled = await queue.get_job(queued_job.id)
    assert cancelled is not None
    assert cancelled.status == JobStatus.CANCELLED

    # Cancellation should prevent queued jobs from executing.
    candidate = await queue.dequeue(["task_fn"], timeout=0.05)
    assert candidate is None

    # Cancel should release the dedup key so callers can re-submit immediately.
    client = await queue._ensure_connected()  # noqa: SLF001
    assert await client.sismember(queue._dedup_key(queued_job.function), queued_job.key) == 0  # noqa: SLF001


@pytest.mark.asyncio
async def test_record_dispatch_reason_updates_hash_and_stream(queue: RedisQueue) -> None:
    client = await queue._ensure_connected()  # noqa: SLF001

    await queue.record_dispatch_reason(
        "fn.dispatch",
        DispatchReason.PAUSED,
        job_id="job-1",
    )
    await queue.record_dispatch_reason(
        "fn.dispatch",
        DispatchReason.RATE_LIMITED,
        job_id="job-2",
    )

    raw = await client.hgetall(queue._dispatch_reasons_key("fn.dispatch"))  # noqa: SLF001
    paused = raw.get(b"paused") or raw.get("paused")
    rate_limited = raw.get(b"rate_limited") or raw.get("rate_limited")
    assert int(paused) == 1
    assert int(rate_limited) == 1
    ttl = await client.ttl(queue._dispatch_reasons_key("fn.dispatch"))  # noqa: SLF001
    assert ttl is not None
    assert int(ttl) > 0

    events = await client.xrevrange(queue._dispatch_events_stream_key(), count=2)  # noqa: SLF001
    assert len(events) == 2
    latest_payload = events[0][1]
    latest_reason = latest_payload.get(b"reason") or latest_payload.get("reason")
    latest_function = latest_payload.get(b"function") or latest_payload.get("function")
    assert (
        latest_reason.decode() if isinstance(latest_reason, bytes) else latest_reason
    ) == "rate_limited"
    assert (
        latest_function.decode()
        if isinstance(latest_function, bytes)
        else latest_function
    ) == "fn.dispatch"


@pytest.mark.asyncio
async def test_cancel_terminal_job_returns_false(queue: RedisQueue) -> None:
    terminal_job = Job(function="task_fn", function_name="task", key="terminal-key")
    await queue.enqueue(terminal_job)
    active = None
    for _ in range(4):
        candidate = await queue.dequeue(["task_fn"], timeout=0.2)
        if candidate is None:
            continue
        if candidate.id == terminal_job.id:
            active = candidate
            break
    assert active is not None
    await queue.finish(active, JobStatus.COMPLETE)

    assert await queue.cancel(terminal_job.id) is False


@pytest.mark.asyncio
async def test_cancel_does_not_override_existing_terminal_payload(
    queue: RedisQueue,
) -> None:
    job = Job(function="task_fn", function_name="task", key="cancel-race-key")
    await queue.enqueue(job)

    client = await queue._ensure_connected()  # noqa: SLF001
    completed = Job(
        id=job.id,
        function=job.function,
        function_name=job.function_name,
        key=job.key,
    )
    completed.mark_complete({"ok": True})
    await client.setex(
        queue._job_key(job),  # noqa: SLF001
        queue._job_ttl_seconds,  # noqa: SLF001
        completed.to_json().encode(),
    )
    await client.setex(
        queue._job_index_key(job.id),  # noqa: SLF001
        queue._job_ttl_seconds,  # noqa: SLF001
        queue._job_key(job),  # noqa: SLF001
    )

    assert await queue.cancel(job.id) is False

    resolved = await queue.get_job(job.id)
    assert resolved is not None
    assert resolved.status == JobStatus.COMPLETE
    assert resolved.result == {"ok": True}
    assert await queue.is_cancelled(job.id) is False


@pytest.mark.asyncio
async def test_cancel_does_not_clear_existing_cancel_marker_on_race(
    queue: RedisQueue,
) -> None:
    job = Job(function="task_fn", function_name="task", key="cancel-marker-race-key")
    await queue.enqueue(job)

    client = await queue._ensure_connected()  # noqa: SLF001
    await client.setex(
        queue._cancel_marker_key(job.id),  # noqa: SLF001
        queue._job_ttl_seconds,  # noqa: SLF001
        b"1",
    )

    completed = Job(
        id=job.id,
        function=job.function,
        function_name=job.function_name,
        key=job.key,
    )
    completed.mark_complete({"ok": True})
    await client.setex(
        queue._job_key(job),  # noqa: SLF001
        queue._job_ttl_seconds,  # noqa: SLF001
        completed.to_json().encode(),
    )
    await client.setex(
        queue._job_index_key(job.id),  # noqa: SLF001
        queue._job_ttl_seconds,  # noqa: SLF001
        queue._job_key(job),  # noqa: SLF001
    )

    assert await queue.cancel(job.id) is False
    assert await queue.is_cancelled(job.id) is True


@pytest.mark.asyncio
async def test_dequeue_skips_stale_stream_entry_without_active_job_key(
    queue: RedisQueue,
) -> None:
    stale = Job(function="task_fn", function_name="task", key="stale-stream-entry")
    fresh = Job(function="task_fn", function_name="task", key="fresh-stream-entry")
    await queue.enqueue(stale)
    await queue.enqueue(fresh)

    client = await queue._ensure_connected()  # noqa: SLF001
    await client.delete(queue._job_key(stale))  # noqa: SLF001
    await client.delete(queue._job_index_key(stale.id))  # noqa: SLF001

    picked = await queue.dequeue(["task_fn"], timeout=0.2)
    assert picked is not None
    assert picked.id == fresh.id


@pytest.mark.asyncio
async def test_manual_retry_preserves_attempt_counter(queue: RedisQueue) -> None:
    failed = Job(function="task_fn", function_name="task", key="manual-retry-attempts")
    failed.attempts = 3
    failed.mark_failed("boom")

    await queue.manual_retry(failed)

    queued = await queue.get_job(failed.id)
    assert queued is not None
    assert queued.status == JobStatus.QUEUED
    assert queued.attempts == 3


@pytest.mark.asyncio
async def test_dequeue_skips_paused_function_until_resumed(queue: RedisQueue) -> None:
    job = Job(function="task_fn", function_name="task", key="paused-key")
    await queue.enqueue(job)

    client = await queue._ensure_connected()  # noqa: SLF001
    await client.set(
        f"{FUNCTION_KEY_PREFIX}:task_fn",
        b'{"key":"task_fn","name":"task_fn","paused":true}',
    )

    paused_pick = await queue.dequeue(["task_fn"], timeout=0.05)
    assert paused_pick is None
    client = await queue._ensure_connected()  # noqa: SLF001
    paused_counts = await client.hgetall(queue._dispatch_reasons_key("task_fn"))  # noqa: SLF001
    paused_value = paused_counts.get(b"paused") or paused_counts.get("paused")
    assert paused_value is not None
    assert int(paused_value) >= 1

    await client.set(
        f"{FUNCTION_KEY_PREFIX}:task_fn",
        b'{"key":"task_fn","name":"task_fn","paused":false}',
    )
    queue._fn_state.clear()  # noqa: SLF001

    resumed_pick = await queue.dequeue(["task_fn"], timeout=0.2)
    assert resumed_pick is not None
    assert resumed_pick.id == job.id


@pytest.mark.asyncio
async def test_dequeue_records_no_capacity_when_function_saturated(
    queue: RedisQueue,
) -> None:
    client = await queue._ensure_connected()  # noqa: SLF001
    await client.set(
        f"{FUNCTION_KEY_PREFIX}:task_fn",
        FunctionConfig(
            key="task_fn",
            name="task_fn",
            type=FunctionType.TASK,
            max_concurrency=1,
        ).model_dump_json(),
    )

    first = Job(function="task_fn", function_name="task", key="cap-1")
    second = Job(function="task_fn", function_name="task", key="cap-2")
    await queue.enqueue(first)
    await queue.enqueue(second)

    active = await queue.dequeue(["task_fn"], timeout=0.2)
    assert active is not None
    blocked = await queue.dequeue(["task_fn"], timeout=0.05)
    assert blocked is None

    counts = await client.hgetall(queue._dispatch_reasons_key("task_fn"))  # noqa: SLF001
    no_capacity = counts.get(b"no_capacity") or counts.get("no_capacity")
    assert no_capacity is not None
    assert int(no_capacity) >= 1


@pytest.mark.asyncio
async def test_xautoclaim_recovers_stale_message(fake_redis) -> None:
    q1 = RedisQueue(client=fake_redis, claim_timeout_ms=20, key_prefix="upnext-claim")
    q2 = RedisQueue(client=fake_redis, claim_timeout_ms=20, key_prefix="upnext-claim")

    job = Job(function="task_fn", function_name="task", key="claim-key")
    await q1.enqueue(job)

    first = await q1.dequeue(["task_fn"], timeout=0.2)
    assert first is not None

    deadline = time.monotonic() + 1.0
    recovered = None
    while time.monotonic() < deadline:
        recovered = await q2.dequeue(["task_fn"], timeout=0.05)
        if recovered is not None:
            break
        await asyncio.sleep(0.01)

    assert recovered is not None
    assert recovered.id == job.id


@pytest.mark.asyncio
async def test_heartbeat_prevents_reclaim(fake_redis) -> None:
    q1 = RedisQueue(
        client=fake_redis, claim_timeout_ms=200, key_prefix="upnext-heartbeat"
    )
    q2 = RedisQueue(
        client=fake_redis, claim_timeout_ms=200, key_prefix="upnext-heartbeat"
    )

    job = Job(function="task_fn", function_name="task", key="heartbeat-key")
    await q1.enqueue(job)

    first = await q1.dequeue(["task_fn"], timeout=0.2)
    assert first is not None

    await asyncio.sleep(0.05)
    await q1.heartbeat_active_jobs([first])
    await asyncio.sleep(0.05)

    for _ in range(3):
        reclaimed = await q2.dequeue(["task_fn"], timeout=0.02)
        assert reclaimed is None


@pytest.mark.asyncio
async def test_default_stream_maxlen_does_not_trim_unconsumed_jobs(queue: RedisQueue) -> None:
    total = 12
    submitted: list[str] = []
    for idx in range(total):
        job = Job(function="task_fn", function_name="task", key=f"no-trim-{idx}")
        submitted.append(job.id)
        await queue.enqueue(job)

    seen: list[str] = []
    for _ in range(total):
        job = await queue.dequeue(["task_fn"], timeout=0.2)
        assert job is not None
        seen.append(job.id)

    assert seen == submitted


@pytest.mark.asyncio
async def test_failed_job_persists_on_job_key_for_retry(queue: RedisQueue) -> None:
    job = Job(function="task_fn", function_name="task", key="failed-key-1")
    await queue.enqueue(job)

    active = await queue.dequeue(["task_fn"], timeout=0.2)
    assert active is not None
    await queue.finish(active, JobStatus.FAILED, error="poison payload")

    stored = await queue.get_job(job.id)
    assert stored is not None
    assert stored.status == JobStatus.FAILED
    assert stored.error == "poison payload"


@pytest.mark.asyncio
async def test_manual_retry_rejects_duplicate_active_key(queue: RedisQueue) -> None:
    first = Job(function="task_fn", function_name="task", key="retry-dup-key")
    await queue.enqueue(first)
    active = await queue.dequeue(["task_fn"], timeout=0.2)
    assert active is not None
    await queue.finish(active, JobStatus.FAILED, error="failed")

    blocking = Job(function="task_fn", function_name="task", key="retry-dup-key")
    await queue.enqueue(blocking)

    failed = await queue.get_job(first.id)
    assert failed is not None
    with pytest.raises(DuplicateJobError):
        await queue.manual_retry(failed)


@pytest.mark.asyncio
async def test_rate_limit_blocks_dispatch_and_requeues_for_later(queue: RedisQueue) -> None:
    client = await queue._ensure_connected()  # noqa: SLF001
    await client.set(
        f"{FUNCTION_KEY_PREFIX}:task_fn",
        b'{"key":"task_fn","name":"task_fn","paused":false,"rate_limit":"1/h"}',
    )

    first = Job(function="task_fn", function_name="task", key="rate-limit-1")
    second = Job(function="task_fn", function_name="task", key="rate-limit-2")
    await queue.enqueue(first)
    await queue.enqueue(second)

    run_first = await queue.dequeue(["task_fn"], timeout=0.2)
    assert run_first is not None
    assert run_first.id == first.id
    await queue.finish(run_first, JobStatus.COMPLETE)

    # Second dequeue is rate-limited and job is rescheduled for later.
    run_second = await queue.dequeue(["task_fn"], timeout=0.2)
    assert run_second is None

    scheduled_at = await client.zscore(queue._scheduled_key("task_fn"), second.id)  # noqa: SLF001
    assert scheduled_at is not None


@pytest.mark.asyncio
async def test_max_concurrency_blocks_excess_dispatch(queue: RedisQueue) -> None:
    client = await queue._ensure_connected()  # noqa: SLF001
    await client.set(
        f"{FUNCTION_KEY_PREFIX}:task_fn",
        b'{"key":"task_fn","name":"task_fn","paused":false,"max_concurrency":1}',
    )

    first = Job(function="task_fn", function_name="task", key="max-concurrency-1")
    second = Job(function="task_fn", function_name="task", key="max-concurrency-2")
    await queue.enqueue(first)
    await queue.enqueue(second)

    run_first = await queue.dequeue(["task_fn"], timeout=0.2)
    assert run_first is not None
    assert run_first.id == first.id

    run_second = await queue.dequeue(["task_fn"], timeout=0.2)
    assert run_second is None

    scheduled_at = await client.zscore(queue._scheduled_key("task_fn"), second.id)  # noqa: SLF001
    assert scheduled_at is None

    await queue.finish(run_first, JobStatus.COMPLETE)
    unblocked = await queue.dequeue(["task_fn"], timeout=0.2)
    assert unblocked is not None
    assert unblocked.id == second.id


@pytest.mark.asyncio
async def test_dequeue_round_robin_prevents_hot_stream_starvation(queue: RedisQueue) -> None:
    hot = Job(function="hot_fn", function_name="hot", key="hot-1")
    cold = Job(function="cold_fn", function_name="cold", key="cold-1")
    await queue.enqueue(hot)
    await queue.enqueue(cold)

    first = await queue.dequeue(["hot_fn", "cold_fn"], timeout=0.2)
    assert first is not None
    await queue.finish(first, JobStatus.COMPLETE)

    second = await queue.dequeue(["hot_fn", "cold_fn"], timeout=0.2)
    assert second is not None

    assert {first.function, second.function} == {"hot_fn", "cold_fn"}


@pytest.mark.asyncio
async def test_group_concurrency_cap_limits_shared_routing_group(
    queue: RedisQueue,
) -> None:
    client = await queue._ensure_connected()  # noqa: SLF001
    await client.set(
        f"{FUNCTION_KEY_PREFIX}:fn.group.a",
        b'{"key":"fn.group.a","name":"group_a","paused":false,"routing_group":"tenant-a","group_max_concurrency":1}',
    )
    await client.set(
        f"{FUNCTION_KEY_PREFIX}:fn.group.b",
        b'{"key":"fn.group.b","name":"group_b","paused":false,"routing_group":"tenant-a","group_max_concurrency":1}',
    )

    a = Job(function="fn.group.a", function_name="group_a", key="group-a")
    b = Job(function="fn.group.b", function_name="group_b", key="group-b")
    await queue.enqueue(a)
    await queue.enqueue(b)

    first = await queue.dequeue(["fn.group.a", "fn.group.b"], timeout=0.2)
    assert first is not None

    second = await queue.dequeue(["fn.group.a", "fn.group.b"], timeout=0.2)
    assert second is None

    await queue.finish(first, JobStatus.COMPLETE)
    next_job = await queue.dequeue(["fn.group.a", "fn.group.b"], timeout=0.2)
    assert next_job is not None
    assert {first.id, next_job.id} == {a.id, b.id}


@pytest.mark.asyncio
async def test_cron_cursor_persists_next_and_last_completion(queue: RedisQueue) -> None:
    now = time.time()
    cron_job = Job(
        function="cron.fn",
        function_name="cron_fn",
        key=cron_registry_member_key("cron.fn"),
        source=CronSource(schedule="* * * * *"),
    )

    seeded = await queue.seed_cron(cron_job, next_run_at=now + 60)
    assert seeded is True

    client = await queue._ensure_connected()  # noqa: SLF001
    seeded_cursor_raw = await client.hget(queue._cron_cursor_key(), "cron.fn")  # noqa: SLF001
    assert seeded_cursor_raw is not None
    seeded_cursor = json.loads(
        seeded_cursor_raw.decode()
        if isinstance(seeded_cursor_raw, bytes)
        else seeded_cursor_raw
    )
    assert seeded_cursor["function"] == "cron.fn"
    assert seeded_cursor["next_run_at"] is not None
    assert seeded_cursor["last_completed_at"] is None
    seeded_job_index = await client.get(queue._job_index_key(cron_job.id))  # noqa: SLF001
    assert seeded_job_index is not None

    cron_job.completed_at = datetime.now(UTC)
    rescheduled_job_id = await queue.reschedule_cron(cron_job, next_run_at=now + 120)

    cursor_raw = await client.hget(queue._cron_cursor_key(), "cron.fn")  # noqa: SLF001
    assert cursor_raw is not None
    cursor = json.loads(
        cursor_raw.decode() if isinstance(cursor_raw, bytes) else cursor_raw
    )
    assert cursor["next_run_at"] is not None
    assert cursor["last_completed_at"] is not None
    rescheduled_job_index = await client.get(queue._job_index_key(rescheduled_job_id))  # noqa: SLF001
    assert rescheduled_job_index is not None


@pytest.mark.asyncio
async def test_reschedule_cron_same_window_reuses_existing_reservation(
    queue: RedisQueue,
) -> None:
    now = time.time()
    client = await queue._ensure_connected()  # noqa: SLF001
    cron_job = Job(
        function="cron.resv",
        function_name="cron_resv",
        key=cron_registry_member_key("cron.resv"),
        source=CronSource(schedule="* * * * *"),
    )
    cron_job.completed_at = datetime.now(UTC)
    next_run_at = now + 60

    first_id = await queue.reschedule_cron(cron_job, next_run_at=next_run_at)
    second_id = await queue.reschedule_cron(cron_job, next_run_at=next_run_at)

    assert second_id == first_id
    scheduled = await client.zrange(queue._scheduled_key("cron.resv"), 0, -1)  # noqa: SLF001
    assert len(scheduled) == 1
    assert (
        scheduled[0].decode() if isinstance(scheduled[0], bytes) else str(scheduled[0])
    ) == first_id


@pytest.mark.asyncio
async def test_reschedule_cron_reclaims_stale_window_reservation(
    queue: RedisQueue,
) -> None:
    now = time.time()
    client = await queue._ensure_connected()  # noqa: SLF001
    next_run_at = now + 120
    await client.set(
        queue._cron_window_reservation_key("cron.stale", next_run_at),  # noqa: SLF001
        "stale-job-id",
        ex=3600,
    )

    cron_job = Job(
        function="cron.stale",
        function_name="cron_stale",
        key=cron_registry_member_key("cron.stale"),
        source=CronSource(schedule="* * * * *"),
    )
    cron_job.completed_at = datetime.now(UTC)

    job_id = await queue.reschedule_cron(cron_job, next_run_at=next_run_at)
    assert job_id != "stale-job-id"

    job_raw = await client.get(queue._key("job", "cron.stale", job_id))  # noqa: SLF001
    assert job_raw is not None
    score = await client.zscore(queue._scheduled_key("cron.stale"), job_id)  # noqa: SLF001
    assert score is not None


@pytest.mark.asyncio
async def test_cron_startup_reconciliation_defaults_to_latest_only_when_cursor_is_stale(
    queue: RedisQueue,
) -> None:
    now = time.time()
    client = await queue._ensure_connected()  # noqa: SLF001
    stale_next_run = now - 120

    await client.hset(
        queue._cron_cursor_key(),  # noqa: SLF001
        "cron.reconcile",
        json.dumps(
            {
                "function": "cron.reconcile",
                "next_run_at": datetime.fromtimestamp(stale_next_run, UTC).isoformat(),
                "last_completed_at": None,
                "updated_at": datetime.now(UTC).isoformat(),
            }
        ),
    )

    cron_job = Job(
        function="cron.reconcile",
        function_name="cron_reconcile",
        key=cron_registry_member_key("cron.reconcile"),
        source=CronSource(schedule="* * * * *"),
    )

    reconciled = await queue.reconcile_cron_startup(cron_job, now_ts=now)
    assert reconciled is True

    cron_job_id_raw = await client.hget(
        queue._cron_registry_key(),  # noqa: SLF001
        cron_registry_member_key("cron.reconcile"),
    )
    assert cron_job_id_raw is not None
    cron_job_id = (
        cron_job_id_raw.decode()
        if isinstance(cron_job_id_raw, bytes)
        else str(cron_job_id_raw)
    )

    reconciled_job_raw = await client.get(
        queue._key("job", "cron.reconcile", cron_job_id)  # noqa: SLF001
    )
    assert reconciled_job_raw is not None
    reconciled_job = Job.from_json(
        reconciled_job_raw.decode()
        if isinstance(reconciled_job_raw, bytes)
        else reconciled_job_raw
    )
    assert reconciled_job.startup_reconciled is True
    assert reconciled_job.startup_policy == "latest_only"
    reconciled_window = float(reconciled_job.cron_window_at or 0.0)
    assert reconciled_window <= now
    assert reconciled_window > stale_next_run + 60

    cursor_raw = await client.hget(queue._cron_cursor_key(), "cron.reconcile")  # noqa: SLF001
    assert cursor_raw is not None
    cursor = json.loads(
        cursor_raw.decode() if isinstance(cursor_raw, bytes) else cursor_raw
    )
    assert datetime.fromisoformat(cursor["next_run_at"]).timestamp() > reconciled_window


@pytest.mark.asyncio
async def test_cron_startup_reconciliation_reseeds_when_cursor_missing_and_registry_stale(
    queue: RedisQueue,
) -> None:
    now = time.time()
    client = await queue._ensure_connected()  # noqa: SLF001

    await client.hset(
        queue._cron_registry_key(),  # noqa: SLF001
        cron_registry_member_key("cron.reseed"),
        "stale-owner",
    )

    cron_job = Job(
        function="cron.reseed",
        function_name="cron_reseed",
        key=cron_registry_member_key("cron.reseed"),
        source=CronSource(schedule="* * * * *"),
    )

    reconciled = await queue.reconcile_cron_startup(cron_job, now_ts=now)
    assert reconciled is True

    owner_raw = await client.hget(
        queue._cron_registry_key(),
        cron_registry_member_key("cron.reseed"),
    )  # noqa: SLF001
    assert owner_raw is not None
    owner = owner_raw.decode() if isinstance(owner_raw, bytes) else str(owner_raw)
    assert owner != "stale-owner"

    seeded_job_raw = await client.get(queue._key("job", "cron.reseed", owner))  # noqa: SLF001
    assert seeded_job_raw is not None

    scheduled_score = await client.zscore(queue._scheduled_key("cron.reseed"), owner)  # noqa: SLF001
    assert scheduled_score is not None
    assert scheduled_score >= now

    cursor_raw = await client.hget(queue._cron_cursor_key(), "cron.reseed")  # noqa: SLF001
    assert cursor_raw is not None


@pytest.mark.asyncio
async def test_cron_startup_reconciliation_seeds_when_cursor_and_registry_missing(
    queue: RedisQueue,
) -> None:
    now = time.time()
    client = await queue._ensure_connected()  # noqa: SLF001

    cron_job = Job(
        function="cron.seed_missing",
        function_name="cron_seed_missing",
        key=cron_registry_member_key("cron.seed_missing"),
        source=CronSource(schedule="* * * * *"),
    )

    reconciled = await queue.reconcile_cron_startup(cron_job, now_ts=now)
    assert reconciled is True

    owner_raw = await client.hget(
        queue._cron_registry_key(),  # noqa: SLF001
        cron_registry_member_key("cron.seed_missing"),
    )
    assert owner_raw is not None
    owner = owner_raw.decode() if isinstance(owner_raw, bytes) else str(owner_raw)

    seeded_job_raw = await client.get(queue._key("job", "cron.seed_missing", owner))  # noqa: SLF001
    assert seeded_job_raw is not None

    scheduled_score = await client.zscore(queue._scheduled_key("cron.seed_missing"), owner)  # noqa: SLF001
    assert scheduled_score is not None
    assert scheduled_score >= now

    cursor_raw = await client.hget(queue._cron_cursor_key(), "cron.seed_missing")  # noqa: SLF001
    assert cursor_raw is not None


@pytest.mark.asyncio
async def test_cron_startup_reconciliation_latest_only_uses_latest_window(
    queue: RedisQueue,
) -> None:
    now = time.time()
    client = await queue._ensure_connected()  # noqa: SLF001
    await client.set(
        f"{FUNCTION_KEY_PREFIX}:cron.latest",
        FunctionConfig(
            key="cron.latest",
            name="cron_latest",
            type=FunctionType.CRON,
            missed_run_policy=MissedRunPolicy.LATEST_ONLY,
        ).model_dump_json(),
    )
    stale_next_run = now - 360
    await client.hset(
        queue._cron_cursor_key(),  # noqa: SLF001
        "cron.latest",
        json.dumps(
            {
                "function": "cron.latest",
                "next_run_at": datetime.fromtimestamp(stale_next_run, UTC).isoformat(),
                "last_completed_at": None,
                "updated_at": datetime.now(UTC).isoformat(),
            }
        ),
    )

    cron_job = Job(
        function="cron.latest",
        function_name="cron_latest",
        key=cron_registry_member_key("cron.latest"),
        source=CronSource(schedule="* * * * *"),
    )
    reconciled = await queue.reconcile_cron_startup(cron_job, now_ts=now)
    assert reconciled is True

    cron_job_id_raw = await client.hget(
        queue._cron_registry_key(),
        cron_registry_member_key("cron.latest"),
    )  # noqa: SLF001
    assert cron_job_id_raw is not None
    cron_job_id = (
        cron_job_id_raw.decode()
        if isinstance(cron_job_id_raw, bytes)
        else str(cron_job_id_raw)
    )
    reconciled_job_raw = await client.get(queue._key("job", "cron.latest", cron_job_id))  # noqa: SLF001
    assert reconciled_job_raw is not None
    reconciled_job = Job.from_json(
        reconciled_job_raw.decode()
        if isinstance(reconciled_job_raw, bytes)
        else reconciled_job_raw
    )
    assert reconciled_job.startup_policy == "latest_only"
    assert float(reconciled_job.cron_window_at or 0.0) > stale_next_run + 60


@pytest.mark.asyncio
async def test_cron_startup_reconciliation_skip_policy_advances_cursor_without_enqueue(
    queue: RedisQueue,
) -> None:
    now = time.time()
    client = await queue._ensure_connected()  # noqa: SLF001
    await client.set(
        f"{FUNCTION_KEY_PREFIX}:cron.skip",
        FunctionConfig(
            key="cron.skip",
            name="cron_skip",
            type=FunctionType.CRON,
            missed_run_policy=MissedRunPolicy.SKIP,
        ).model_dump_json(),
    )
    await client.hset(
        queue._cron_cursor_key(),  # noqa: SLF001
        "cron.skip",
        json.dumps(
            {
                "function": "cron.skip",
                "next_run_at": datetime.fromtimestamp(now - 300, UTC).isoformat(),
                "last_completed_at": None,
                "updated_at": datetime.now(UTC).isoformat(),
            }
        ),
    )

    cron_job = Job(
        function="cron.skip",
        function_name="cron_skip",
        key=cron_registry_member_key("cron.skip"),
        source=CronSource(schedule="* * * * *"),
    )

    reconciled = await queue.reconcile_cron_startup(cron_job, now_ts=now)
    assert reconciled is False

    cron_job_id = await client.hget(
        queue._cron_registry_key(),
        cron_registry_member_key("cron.skip"),
    )  # noqa: SLF001
    assert cron_job_id is None
    cursor_raw = await client.hget(queue._cron_cursor_key(), "cron.skip")  # noqa: SLF001
    assert cursor_raw is not None
    cursor = json.loads(
        cursor_raw.decode() if isinstance(cursor_raw, bytes) else cursor_raw
    )
    assert datetime.fromisoformat(cursor["next_run_at"]).timestamp() > now


@pytest.mark.asyncio
async def test_cron_startup_reconciliation_catch_up_window_respects_max_seconds(
    queue: RedisQueue,
) -> None:
    now = time.time()
    client = await queue._ensure_connected()  # noqa: SLF001
    await client.set(
        f"{FUNCTION_KEY_PREFIX}:cron.windowed",
        FunctionConfig(
            key="cron.windowed",
            name="cron_windowed",
            type=FunctionType.CRON,
            missed_run_policy=MissedRunPolicy.CATCH_UP,
            max_catch_up_seconds=90,
        ).model_dump_json(),
    )
    stale_next_run = now - 600
    await client.hset(
        queue._cron_cursor_key(),  # noqa: SLF001
        "cron.windowed",
        json.dumps(
            {
                "function": "cron.windowed",
                "next_run_at": datetime.fromtimestamp(stale_next_run, UTC).isoformat(),
                "last_completed_at": None,
                "updated_at": datetime.now(UTC).isoformat(),
            }
        ),
    )

    cron_job = Job(
        function="cron.windowed",
        function_name="cron_windowed",
        key=cron_registry_member_key("cron.windowed"),
        source=CronSource(schedule="* * * * *"),
    )
    reconciled = await queue.reconcile_cron_startup(cron_job, now_ts=now)
    assert reconciled is True

    cron_job_id_raw = await client.hget(
        queue._cron_registry_key(),
        cron_registry_member_key("cron.windowed"),
    )  # noqa: SLF001
    assert cron_job_id_raw is not None
    cron_job_id = (
        cron_job_id_raw.decode()
        if isinstance(cron_job_id_raw, bytes)
        else str(cron_job_id_raw)
    )
    reconciled_job_raw = await client.get(
        queue._key("job", "cron.windowed", cron_job_id)  # noqa: SLF001
    )
    assert reconciled_job_raw is not None
    reconciled_job = Job.from_json(
        reconciled_job_raw.decode()
        if isinstance(reconciled_job_raw, bytes)
        else reconciled_job_raw
    )
    assert reconciled_job.startup_policy == "catch_up"
    assert float(reconciled_job.cron_window_at or 0.0) >= now - 90


# ---------------------------------------------------------------------------
# reschedule_cron: policy-aware skip-ahead for past-due windows
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_reschedule_cron_latest_only_skips_past_due(queue: RedisQueue) -> None:
    """LATEST_ONLY should advance past-due next_run_at to a future window."""
    now = time.time()
    client = await queue._ensure_connected()  # noqa: SLF001
    await client.set(
        f"{FUNCTION_KEY_PREFIX}:cron.lo",
        FunctionConfig(
            key="cron.lo",
            name="cron_lo",
            type=FunctionType.CRON,
            missed_run_policy=MissedRunPolicy.LATEST_ONLY,
        ).model_dump_json(),
    )

    cron_job = Job(
        function="cron.lo",
        function_name="cron_lo",
        key=cron_registry_member_key("cron.lo"),
        source=CronSource(schedule="* * * * *"),
    )
    cron_job.completed_at = datetime.now(UTC)

    past_due = now - 300  # 5 minutes ago
    job_id = await queue.reschedule_cron(cron_job, next_run_at=past_due)

    score = await client.zscore(queue._scheduled_key("cron.lo"), job_id)  # noqa: SLF001
    assert score is not None
    assert score > now, "LATEST_ONLY should schedule in the future, not past-due"


@pytest.mark.asyncio
async def test_reschedule_cron_skip_policy_skips_past_due(queue: RedisQueue) -> None:
    """SKIP should advance past-due next_run_at to a future window."""
    now = time.time()
    client = await queue._ensure_connected()  # noqa: SLF001
    await client.set(
        f"{FUNCTION_KEY_PREFIX}:cron.sk",
        FunctionConfig(
            key="cron.sk",
            name="cron_sk",
            type=FunctionType.CRON,
            missed_run_policy=MissedRunPolicy.SKIP,
        ).model_dump_json(),
    )

    cron_job = Job(
        function="cron.sk",
        function_name="cron_sk",
        key=cron_registry_member_key("cron.sk"),
        source=CronSource(schedule="* * * * *"),
    )
    cron_job.completed_at = datetime.now(UTC)

    past_due = now - 300
    job_id = await queue.reschedule_cron(cron_job, next_run_at=past_due)

    score = await client.zscore(queue._scheduled_key("cron.sk"), job_id)  # noqa: SLF001
    assert score is not None
    assert score > now, "SKIP should schedule in the future, not past-due"


@pytest.mark.asyncio
async def test_reschedule_cron_catch_up_keeps_past_due(queue: RedisQueue) -> None:
    """CATCH_UP (no max) should preserve past-due next_run_at for sequential catch-up."""
    now = time.time()
    client = await queue._ensure_connected()  # noqa: SLF001
    await client.set(
        f"{FUNCTION_KEY_PREFIX}:cron.cu",
        FunctionConfig(
            key="cron.cu",
            name="cron_cu",
            type=FunctionType.CRON,
            missed_run_policy=MissedRunPolicy.CATCH_UP,
        ).model_dump_json(),
    )

    cron_job = Job(
        function="cron.cu",
        function_name="cron_cu",
        key=cron_registry_member_key("cron.cu"),
        source=CronSource(schedule="* * * * *"),
    )
    cron_job.completed_at = datetime.now(UTC)

    past_due = now - 300
    job_id = await queue.reschedule_cron(cron_job, next_run_at=past_due)

    score = await client.zscore(queue._scheduled_key("cron.cu"), job_id)  # noqa: SLF001
    assert score is not None
    assert score < now, "CATCH_UP should preserve the past-due window"


@pytest.mark.asyncio
async def test_reschedule_cron_catch_up_respects_max_seconds(
    queue: RedisQueue,
) -> None:
    """CATCH_UP with max_catch_up_seconds should skip windows older than the horizon."""
    now = time.time()
    client = await queue._ensure_connected()  # noqa: SLF001
    await client.set(
        f"{FUNCTION_KEY_PREFIX}:cron.cuw",
        FunctionConfig(
            key="cron.cuw",
            name="cron_cuw",
            type=FunctionType.CRON,
            missed_run_policy=MissedRunPolicy.CATCH_UP,
            max_catch_up_seconds=90,
        ).model_dump_json(),
    )

    cron_job = Job(
        function="cron.cuw",
        function_name="cron_cuw",
        key=cron_registry_member_key("cron.cuw"),
        source=CronSource(schedule="* * * * *"),
    )
    cron_job.completed_at = datetime.now(UTC)

    past_due = now - 600  # 10 minutes ago, beyond 90s horizon
    job_id = await queue.reschedule_cron(cron_job, next_run_at=past_due)

    score = await client.zscore(queue._scheduled_key("cron.cuw"), job_id)  # noqa: SLF001
    assert score is not None
    assert score >= now - 90, "CATCH_UP should skip windows older than max_catch_up_seconds"
