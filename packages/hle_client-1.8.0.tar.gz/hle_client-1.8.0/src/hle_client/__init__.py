"""HLE Client — Home Lab Everywhere tunnel client."""

__version__ = "1.8.0"
