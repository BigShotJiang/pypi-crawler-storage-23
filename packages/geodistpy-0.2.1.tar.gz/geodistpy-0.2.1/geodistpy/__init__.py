"""geodistpy: Fast geodesic distance calculations on the WGS84 ellipsoid."""

from geodistpy.distance import *
