"""Input widget that validates on blur."""

from __future__ import annotations

from textual.message import Message
from textual.widgets import Input


class ValidateBlurInput(Input):
    """Input that posts validation result when focus is lost."""

    class BlurValidationMessage(Message):
        """Posted when input loses focus with validation result."""

        def __init__(self, input: ValidateBlurInput) -> None:
            super().__init__()
            self.input = input
            self.validation_result = input.validate(input.value)

    def on_blur(self) -> None:
        """Post validation message when losing focus."""
        self.post_message(self.BlurValidationMessage(self))

    def on_mount(self) -> None:
        """Validate initial value if present."""
        if self.value:
            self.validate(self.value)
