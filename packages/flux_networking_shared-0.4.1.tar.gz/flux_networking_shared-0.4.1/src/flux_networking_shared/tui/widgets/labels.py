"""Form validation label widgets."""

from textual.widgets import Label


class InvalidLabel(Label):
    """Label for displaying validation errors."""

    DEFAULT_CSS = """
        InvalidLabel {
            content-align: center top;
            color: $error;
            width: 1fr;
            height: 1;
            column-span: 2;
            border: hidden;
            visibility: hidden;

            &.-show-error {
                visibility: visible;
            }
        }
    """


class WarningLabel(Label):
    """Label for displaying validation warnings."""

    DEFAULT_CSS = """
        WarningLabel {
            content-align: left top;
            text-align: justify;
            color: $warning;
            width: 100%;
            height: auto;
            column-span: 4;
            border: hidden;
            visibility: hidden;
            margin: 0 3 0 0;

            &.-show-warning {
                visibility: visible;
            }
        }
    """
