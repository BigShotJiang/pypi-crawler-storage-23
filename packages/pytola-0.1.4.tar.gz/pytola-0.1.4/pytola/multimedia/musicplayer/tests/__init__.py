"""Test package for music player module."""
