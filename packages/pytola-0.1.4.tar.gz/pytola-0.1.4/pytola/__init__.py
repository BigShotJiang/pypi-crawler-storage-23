"""Top-level package for pytola."""

__version__ = "0.1.4"

from ._logger import _default as logger
from ._logger import get_logger
from ._themes import ThemeManager

__all__ = [
    "ThemeManager",
    "__version__",
    "get_logger",
    "logger",
]
