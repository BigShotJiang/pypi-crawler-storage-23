"""Test suite for LSCSIM application."""
