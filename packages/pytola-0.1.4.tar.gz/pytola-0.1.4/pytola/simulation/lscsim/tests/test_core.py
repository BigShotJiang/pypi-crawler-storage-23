"""Tests for core components."""

from __future__ import annotations

from unittest.mock import Mock, patch

import pytest

from pytola.simulation.lscsim.core.main_controller import AppConfiguration, MainController


class TestAppConfiguration:
    """Tests for application configuration."""

    def test_default_values(self) -> None:
        """Test default configuration values."""
        config = AppConfiguration()
        assert config.database_host == "localhost"
        assert config.database_port == 5432
        assert config.database_name == "lscsim.db"
        assert config.user_level == "normal"

    def test_connection_string(self) -> None:
        """Test connection string generation."""
        config = AppConfiguration()
        expected = "sqlite:///lscsim.db"
        assert config.connection_string == expected


class TestMainController:
    """Tests for main controller functionality."""

    def test_initialization(self) -> None:
        """Test controller initialization."""
        with patch("pytola.simulation.lscsim.core.main_controller.config_manager"):
            controller = MainController()
            assert controller.config is not None
            assert isinstance(controller._components, dict)
            assert isinstance(controller._commands, dict)
            assert isinstance(controller._messages, dict)

    def test_get_component_not_found(self) -> None:
        """Test getting non-existent component."""
        with patch("pytola.simulation.lscsim.core.main_controller.config_manager"):
            controller = MainController()
            component = controller.get_component("nonexistent")
            assert component is None

    def test_execute_unknown_command(self) -> None:
        """Test executing unknown command raises error."""
        with patch("pytola.simulation.lscsim.core.main_controller.config_manager"):
            controller = MainController()
            with pytest.raises(ValueError, match="Unknown command"):
                controller.execute_command("unknown_command")

    def test_set_invalid_user_level(self) -> None:
        """Test setting invalid user level raises error."""
        with patch("pytola.simulation.lscsim.core.main_controller.config_manager"):
            controller = MainController()
            with pytest.raises(ValueError, match="Invalid user level"):
                controller.set_user_level("invalid_level")

    def test_set_valid_user_level(self) -> None:
        """Test setting valid user level."""
        with patch("pytola.simulation.lscsim.core.main_controller.config_manager"):
            controller = MainController()
            # Create a mock for the signal
            mock_signal = Mock()
            controller.user_level_changed = mock_signal

            controller.set_user_level("admin")
            assert controller.config.user_level == "admin"
            mock_signal.emit.assert_called_once_with("admin")
