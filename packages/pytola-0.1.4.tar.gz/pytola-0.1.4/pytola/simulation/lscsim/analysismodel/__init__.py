"""Analysis Model Module."""

from .model import AnalysisComponent

__all__ = ["AnalysisComponent"]
