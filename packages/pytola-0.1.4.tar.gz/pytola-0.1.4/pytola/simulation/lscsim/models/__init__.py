"""Data models for simulation system."""
