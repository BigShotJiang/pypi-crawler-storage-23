"""Main controller interface - equivalent to C++ IMainCtrl."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from .icomponent import IComponent


class IMainCtrl(ABC):
    """Abstract base class for main controller.

    This interface defines the main control center that manages all components,
    equivalent to the C++ IMainCtrl interface.
    """

    @abstractmethod
    def init(self) -> None:
        """Initialize the main controller.

        Sets up the component management system and registers core components.
        """
        pass

    @abstractmethod
    def get_component(self, component_id: str) -> IComponent | None:
        """Get component by ID.

        Args:
            component_id: Component identifier

        Returns
        -------
            IComponent: Component instance or None if not found
        """
        pass

    @abstractmethod
    def execute_command(self, command_id: str, in_param: Any = None, out_param: Any = None) -> bool:
        """Execute a command.

        Routes commands to appropriate components for execution.

        Args:
            command_id: Command identifier
            in_param: Input parameters
            out_param: Output parameters (mutable)

        Returns
        -------
            bool: True if command executed successfully
        """
        pass

    @abstractmethod
    def send_message(self, message: str, value: int = 0, param: Any = None) -> None:
        """Send message to components.

        Broadcasts messages to registered message handlers.

        Args:
            message: Message identifier
            value: Integer value associated with message
            param: Additional parameter data
        """
        pass

    @abstractmethod
    def send_message_to_main(self, message: str, value: int = 0, param: Any = None) -> None:
        """Send message specifically to main window.

        Args:
            message: Message identifier
            value: Integer value
            param: Parameter data
        """
        pass

    @abstractmethod
    def get_interface_ptr(self, interface_id: str) -> Any:
        """Get interface pointer by ID.

        Provides access to specialized interfaces from components.

        Args:
            interface_id: Interface identifier

        Returns
        -------
            Any: Interface implementation or None
        """
        pass

    @abstractmethod
    def set_window_handle(self, handle_id: Any) -> None:
        """Set main window handle.

        Args:
            handle_id: Window handle/reference
        """
        pass

    @abstractmethod
    def quit(self) -> None:
        """Quit the application.

        Performs cleanup and shuts down the system gracefully.
        """
        pass

    @abstractmethod
    def get_window_handle(self) -> int:
        """Get main window handle.

        Returns
        -------
            int: Window handle identifier
        """
        pass

    @abstractmethod
    def add_hit_info(self, hit_info: str) -> None:
        """Add hint/information message.

        Args:
            hit_info: Information message to display
        """
        pass


# Protocol version for type checking
class MainCtrlProtocol(Protocol):
    """Protocol for main controller type checking."""

    def init(self) -> None:
        """Initialize the main controller.

        Sets up the component management system and registers core components.
        """

    def get_component(self, component_id: str) -> IComponent | None:
        """Get component by ID.

        Args:
            component_id: Component identifier

        Returns
        -------
            IComponent: Component instance or None if not found
        """

    def execute_command(self, command_id: str, in_param: Any, out_param: Any) -> bool:
        """Execute a command.

        Args:
            command_id: Command identifier
            in_param: Input parameters
            out_param: Output parameters (mutable)

        Returns
        -------
            bool: True if command executed successfully
        """

    def send_message(self, message: str, value: int, param: Any) -> None:
        """Send message to components.

        Broadcasts messages to registered message handlers.

        Args:
            message: Message identifier
            value: Integer value associated with message
            param: Additional parameter data
        """

    def send_message_to_main(self, message: str, value: int, param: Any) -> None:
        """Send message specifically to main window.

        Args:
            message: Message identifier
            value: Integer value
            param: Parameter data
        """

    def get_interface_ptr(self, interface_id: str) -> Any:
        """Get interface pointer by ID.

        Provides access to specialized interfaces from components.

        Args:
            interface_id: Interface identifier

        Returns
        -------
            Any: Interface implementation or None
        """

    def set_window_handle(self, handle_id: Any) -> None:
        """Set main window handle.

        Args:
            handle_id: Window handle/reference
        """

    def quit(self) -> None:
        """Quit the application.

        Performs cleanup and shuts down the system gracefully.
        """

    def get_window_handle(self) -> int:
        """Get main window handle.

        Returns
        -------
            int: Window handle identifier
        """

    def add_hit_info(self, hit_info: str) -> None:
        """Add hint/information message.

        Args:
            hit_info: Information message to display
        """
