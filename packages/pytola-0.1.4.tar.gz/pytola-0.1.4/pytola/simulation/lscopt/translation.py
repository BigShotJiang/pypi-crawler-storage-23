#!/usr/bin/env python3
"""
Translation system for LSC Optimizer GUI.

Provides internationalization support with English and Chinese translations.
"""

from enum import Enum
from typing import Dict


class Language(Enum):
    """Supported languages."""

    ENGLISH = "en"
    CHINESE = "zh"


class Translator:
    """Translation manager for LSC Optimizer GUI."""

    def __init__(self, default_language: Language = Language.CHINESE):
        """Initialize translator with default language.

        Args:
            default_language: Default language to use
        """
        self.current_language = default_language
        self.translations = self._load_translations()

    def _load_translations(self) -> Dict[str, Dict[str, str]]:
        """Load all translation strings."""
        return {
            "window_title": {
                Language.ENGLISH.value: "LSC Optimizer v0.1.0",
                Language.CHINESE.value: "LSC优化器 v0.1.0",
            },
            "parameters_panel": {Language.ENGLISH.value: "Parameters", Language.CHINESE.value: "参数设置"},
            "calculate_button": {Language.ENGLISH.value: "Calculate", Language.CHINESE.value: "计算"},
            "reset_button": {Language.ENGLISH.value: "Reset to Defaults", Language.CHINESE.value: "重置为默认值"},
            "results_panel": {Language.ENGLISH.value: "Calculation Results", Language.CHINESE.value: "计算结果"},
            "ready_text": {Language.ENGLISH.value: "Ready to calculate...", Language.CHINESE.value: "准备计算..."},
            "calculation_success": {
                Language.ENGLISH.value: "✓ Calculation completed successfully!",
                Language.CHINESE.value: "✓ 计算完成!",
            },
            "solution_norm": {Language.ENGLISH.value: "Solution Vector Norm", Language.CHINESE.value: "解向量范数"},
            "optimization_residual": {
                Language.ENGLISH.value: "Optimization Residual",
                Language.CHINESE.value: "优化残差",
            },
            "about_title": {Language.ENGLISH.value: "About LSC Optimizer", Language.CHINESE.value: "关于LSC优化器"},
            "about_content": {
                Language.ENGLISH.value: (
                    "LSC Optimizer v0.1.0\n\n"
                    "A tool for Least Squares Curve fitting optimization\n\n"
                    "Keyboard shortcuts:\n"
                    "Enter - Calculate\n"
                    "Escape - Reset parameters\n"
                    "Ctrl+R - Reset parameters\n"
                    "Ctrl+Q - Exit"
                ),
                Language.CHINESE.value: (
                    "LSC优化器 v0.1.0\n\n最小二乘曲线拟合优化工具\n\n键盘快捷键: \n"
                    "回车 - 计算\nESC - 重置参数\nCtrl+R - 重置参数\nCtrl+Q - 退出"
                ),
            },
            "parameter_labels": {
                Language.ENGLISH.value: {
                    "m": "First breakpoint (m)",
                    "m1": "Second breakpoint (m1)",
                    "s": "Internal slope (s)",
                    "s1": "External slope (s1)",
                    "H": "Cutting height (H)",
                    "m2": "Specific point (m2)",
                    "H1": "Internal retention height (H1)",
                    "H2": "External retention height (H2)",
                    "J": "Overall angle (J)",
                    "J1": "Internal angle (J1)",
                },
                Language.CHINESE.value: {
                    "m": "第一断点 (m)",
                    "m1": "第二断点 (m1)",
                    "s": "内部斜率 (s)",
                    "s1": "外部斜率 (s1)",
                    "H": "切削高度 (H)",
                    "m2": "特定点 (m2)",
                    "H1": "内部保留高度 (H1)",
                    "H2": "外部保留高度 (H2)",
                    "J": "总角度 (J)",
                    "J1": "内部角度 (J1)",
                },
            },
            "menu_file": {Language.ENGLISH.value: "&File", Language.CHINESE.value: "文件(&F)"},
            "menu_reset": {Language.ENGLISH.value: "&Reset Parameters", Language.CHINESE.value: "重置参数(&R)"},
            "menu_exit": {Language.ENGLISH.value: "E&xit", Language.CHINESE.value: "退出(&X)"},
            "menu_help": {Language.ENGLISH.value: "&Help", Language.CHINESE.value: "帮助(&H)"},
            "menu_about": {Language.ENGLISH.value: "&About", Language.CHINESE.value: "关于(&A)"},
            "error_prefix": {Language.ENGLISH.value: "Error: ", Language.CHINESE.value: "错误: "},
            "ready_status": {Language.ENGLISH.value: "Ready", Language.CHINESE.value: "就绪"},
            "calculation_complete_status": {
                Language.ENGLISH.value: "Calculation completed",
                Language.CHINESE.value: "计算完成",
            },
            "calculation_error_status": {
                Language.ENGLISH.value: "Calculation failed",
                Language.CHINESE.value: "计算失败",
            },
        }

    def set_language(self, language: Language) -> None:
        """Change current language.

        Args:
            language: Language to switch to
        """
        self.current_language = language

    def tr(self, key: str, **kwargs) -> str:
        """Translate a string key to current language.

        Args:
            key: Translation key
            **kwargs: Additional formatting parameters

        Returns
        -------
            Translated string
        """
        if key not in self.translations:
            return key

        translation_dict = self.translations[key]
        current_lang = self.current_language.value

        if current_lang in translation_dict:
            result = translation_dict[current_lang]
            if kwargs:
                result = result.format(**kwargs)
            return result
        # Fallback to English
        if Language.ENGLISH.value in translation_dict:
            result = translation_dict[Language.ENGLISH.value]
            if kwargs:
                result = result.format(**kwargs)
            return result
        return key

    def tr_params(self) -> Dict[str, str]:
        """Get all translated parameter labels.

        Returns
        -------
            Dictionary of all parameter labels in current language
        """
        return self.translations["parameter_labels"][self.current_language.value]


# Global translator instance
translator = Translator()
