# Regex Validator Tool

A PySide2-based graphical user interface application for validating regular expressions against test strings.

## Features

- Real-time regex validation against test strings
- Support for both raw mode and non-raw mode regex patterns
- Configurable regex flags:
  - Case insensitive matching
  - Multiline mode
  - Dotall mode (dot matches newline)
- Detailed match results showing:
  - Match groups
  - Match positions
  - Full match results
  - Findall and finditer results
- Analysis of regex pattern features

## Installation

```bash
pip install -e .
```

## Usage

Run the application:

```bash
python -m pytola.regexvalidate
```

Or if installed as a console script:

```bash
regexval
```

## Interface

1. Enter a regular expression pattern in the "Regular Expression" field
2. Toggle "Raw Mode" to control escape sequence processing:
   - Enabled: Treat regex literally without processing escape sequences
   - Disabled: Process escape sequences normally
3. Enter a test string in the text area
4. Select desired regex flags (case insensitive, multiline, dotall)
5. Click "Validate" to test the regex against the string
6. View detailed results in the output area

## Raw Mode vs Non-Raw Mode

- **Raw Mode**: The regex is treated literally, escape sequences like `\n` are treated as literal backslash followed by 'n'
- **Non-Raw Mode**: Escape sequences are processed, `\n` becomes an actual newline character

## Requirements

- Python 3.8+
- PySide2
- typing-extensions (for Python < 3.10)
