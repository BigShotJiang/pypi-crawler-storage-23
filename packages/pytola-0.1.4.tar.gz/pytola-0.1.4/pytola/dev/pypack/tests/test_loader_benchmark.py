"""Benchmark tests for pyloadergen module."""

from __future__ import annotations

from unittest import mock

import pytest

from ..components import loader


class BenchmarkPrepareCSource:
    """Benchmark C source preparation performance."""

    @pytest.mark.benchmark
    def test_prepare_c_source_debug_mode(self, benchmark):
        """Benchmark C source preparation in debug mode."""
        template = loader._WINDOWS_GUI_TEMPLATE
        result = benchmark(loader.prepare_c_source, template, "test.ent", True)
        assert "${DEBUG_MODE}" not in result
        assert "${ENTRY_FILE}" not in result

    @pytest.mark.benchmark
    def test_prepare_c_source_release_mode(self, benchmark):
        """Benchmark C source preparation in release mode."""
        template = loader._WINDOWS_GUI_TEMPLATE
        result = benchmark(loader.prepare_c_source, template, "test.ent", False)
        assert "${DEBUG_MODE}" not in result
        assert "${ENTRY_FILE}" not in result


class BenchmarkGetCompilerArgs:
    """Benchmark compiler argument retrieval performance."""

    @pytest.mark.benchmark
    @pytest.mark.parametrize("compiler", ["gcc", "clang", "cl"])
    def test_get_compiler_args(self, benchmark, compiler):
        """Benchmark compiler arguments retrieval."""
        args = benchmark(loader.get_compiler_args, compiler)
        assert len(args) > 0


class BenchmarkSelectTemplate:
    """Benchmark template selection performance."""

    @pytest.mark.benchmark
    @pytest.mark.parametrize(
        ("is_windows", "is_macos", "loader_type", "debug"),
        [
            (True, False, "gui", False),
            (True, False, "console", False),
            (False, True, "gui", False),
        ],
    )
    def test_select_c_template(self, benchmark, is_windows, is_macos, loader_type, debug):
        """Benchmark template selection."""
        with mock.patch("pytola.dev.pypack.components.loader.is_windows", is_windows), mock.patch(
            "pytola.dev.pypack.components.loader.is_macos", is_macos
        ):
            template = benchmark(loader.select_c_template, loader_type, debug)
            assert template is not None
