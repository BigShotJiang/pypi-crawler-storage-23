"""Tests for pypack module."""

from __future__ import annotations

from pathlib import Path

import pytest

from ..core.config import (
    LoaderType,
    WorkflowConfig,
)
from ..core.workflow import (
    PackageWorkflow,
    StandardCleaningStrategy,
)


@pytest.fixture
def temp_project_dir(tmp_path: Path) -> Path:
    """Create a temporary project directory with pyproject.toml."""
    project_dir = tmp_path / "test_project"
    project_dir.mkdir()

    # Create pyproject.toml
    pyproject_content = """[project]
name = "test_project"
version = "1.0.0"
description = "Test project"
dependencies = ["requests>=2.0.0"]
"""

    (project_dir / "pyproject.toml").write_text(pyproject_content, encoding="utf-8")

    return project_dir


class TestPackageWorkflow:
    """Tests for PackageWorkflow."""

    def test_workflow_initialization(self, temp_project_dir: Path):
        """Test workflow initialization with valid config."""
        config = WorkflowConfig(
            directory=temp_project_dir,
            project_name="test_project",
            python_version="3.8.10",
            loader_type=LoaderType.CONSOLE,
            generate_loader=True,
            offline=False,
            max_concurrent=4,
        )

        workflow = PackageWorkflow(
            root_dir=temp_project_dir,
            config=config,
            cleaning_strategy=StandardCleaningStrategy(),
        )

        assert workflow.root_dir == temp_project_dir
        assert workflow.config == config

    def test_solution_property(self, temp_project_dir: Path):
        """Test solution property loads correctly."""
        config = WorkflowConfig(directory=temp_project_dir)
        workflow = PackageWorkflow(
            root_dir=temp_project_dir,
            config=config,
            cleaning_strategy=StandardCleaningStrategy(),
        )

        solution = workflow.solution
        assert solution is not None

    def test_projects_property(self, temp_project_dir: Path):
        """Test projects property returns dict."""
        config = WorkflowConfig(directory=temp_project_dir)
        workflow = PackageWorkflow(
            root_dir=temp_project_dir,
            config=config,
            cleaning_strategy=StandardCleaningStrategy(),
        )

        projects = workflow.projects
        assert isinstance(projects, dict)


class TestCleanProject:
    """Tests for clean_project function."""

    def test_clean_empty_directory(self, tmp_path: Path):
        """Test cleaning directory with no artifacts."""
        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(
            root_dir=tmp_path,
            config=config,
            cleaning_strategy=StandardCleaningStrategy(),
        )
        workflow.clean_project()
        # Should complete without errors

    def test_clean_with_build_artifacts(self, tmp_path: Path):
        """Test cleaning directory with build artifacts."""
        # Create build directories
        (tmp_path / "build").mkdir()
        (tmp_path / "dist").mkdir()
        (tmp_path / "__pycache__").mkdir()
        (tmp_path / ".pytest_cache").mkdir()

        # Create projects.json file
        (tmp_path / "projects.json").write_text("{}", encoding="utf-8")

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(
            root_dir=tmp_path,
            config=config,
            cleaning_strategy=StandardCleaningStrategy(),
        )
        workflow.clean_project()

        # Verify artifacts are removed
        assert not (tmp_path / "build").exists()
        assert not (tmp_path / "dist").exists()
        assert not (tmp_path / "__pycache__").exists()
        assert not (tmp_path / "projects.json").exists()

    def test_clean_preserves_protected_directories(self, tmp_path: Path):
        """Test that protected directories are not removed."""
        # Create protected directories
        protected = [".git", ".venv", ".vscode", ".idea", ".qoder"]
        for dirname in protected:
            (tmp_path / dirname).mkdir()

        config = WorkflowConfig(directory=tmp_path)
        workflow = PackageWorkflow(
            root_dir=tmp_path,
            config=config,
            cleaning_strategy=StandardCleaningStrategy(),
        )
        workflow.clean_project()

        # Verify protected directories still exist
        for dirname in protected:
            assert (tmp_path / dirname).exists()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
