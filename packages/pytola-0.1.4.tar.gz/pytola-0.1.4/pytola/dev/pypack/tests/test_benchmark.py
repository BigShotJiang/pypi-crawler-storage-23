"""Benchmark tests for pypack module."""

from __future__ import annotations

from pathlib import Path

import pytest

from ..core.config import LoaderType, WorkflowConfig
from ..core.workflow import PackageWorkflow, StandardCleaningStrategy


@pytest.fixture
def benchmark_project_dir(tmp_path: Path) -> Path:
    """Create a benchmark project directory with pyproject.toml."""
    project_dir = tmp_path / "benchmark_project"
    project_dir.mkdir()

    # Create pyproject.toml
    pyproject_content = """[project]
name = "benchmark_project"
version = "1.0.0"
description = "Benchmark project"
dependencies = ["requests>=2.0.0", "click>=8.0.0"]
"""

    (project_dir / "pyproject.toml").write_text(pyproject_content, encoding="utf-8")

    # Create some build artifacts for cleaning benchmark
    (project_dir / "build").mkdir()
    (project_dir / "dist").mkdir()
    (project_dir / "__pycache__").mkdir()
    for i in range(10):
        (project_dir / "build" / f"file_{i}.txt").write_text("content", encoding="utf-8")
        (project_dir / "dist" / f"package_{i}.whl").write_text("wheel", encoding="utf-8")

    return project_dir


@pytest.mark.benchmark(group="workflow")
def test_workflow_initialization_performance(benchmark, benchmark_project_dir: Path):
    """Benchmark workflow initialization time."""

    def create_workflow():
        config = WorkflowConfig(
            directory=benchmark_project_dir,
            project_name="benchmark_project",
            python_version="3.8.10",
            loader_type=LoaderType.CONSOLE,
            generate_loader=True,
            offline=True,
            max_concurrent=4,
        )
        return PackageWorkflow(
            root_dir=benchmark_project_dir,
            config=config,
            cleaning_strategy=StandardCleaningStrategy(),
        )

    result = benchmark(create_workflow)
    assert result is not None


@pytest.mark.benchmark(group="workflow")
def test_solution_loading_performance(benchmark, benchmark_project_dir: Path):
    """Benchmark solution loading time."""
    config = WorkflowConfig(directory=benchmark_project_dir)
    workflow = PackageWorkflow(
        root_dir=benchmark_project_dir,
        config=config,
        cleaning_strategy=StandardCleaningStrategy(),
    )

    def load_solution():
        return workflow.solution

    result = benchmark(load_solution)
    assert result is not None


@pytest.mark.benchmark(group="clean")
def test_clean_project_performance(benchmark, benchmark_project_dir: Path):
    """Benchmark project cleaning operation."""
    config = WorkflowConfig(directory=benchmark_project_dir)
    workflow = PackageWorkflow(
        root_dir=benchmark_project_dir,
        config=config,
        cleaning_strategy=StandardCleaningStrategy(),
    )

    def clean_operation():
        workflow.clean_project()

    benchmark(clean_operation)

    # Verify cleanup occurred
    assert not (benchmark_project_dir / "build").exists()
    assert not (benchmark_project_dir / "dist").exists()
