"""Test log panel functionality."""

from __future__ import annotations

import pytest
from PySide2.QtWidgets import QApplication

from ..gui.widgets.log_panel import LogPanel


class TestLogPanel:
    """Test log panel functionality."""

    @pytest.fixture(scope="class")
    def app(self):
        """Create QApplication instance."""
        app = QApplication.instance()
        if app is None:
            app = QApplication([])
        return app

    def test_log_panel_creation(self, app):
        """Test that log panel can be created."""
        log_panel = LogPanel()
        assert log_panel is not None
        assert hasattr(log_panel, "append_log")
        assert hasattr(log_panel, "clear_log")
        assert hasattr(log_panel, "copy_log")

    def test_log_append_functionality(self, app):
        """Test that log appending works correctly."""
        log_panel = LogPanel()

        # Test appending messages
        test_messages = [
            "INFO: Starting build process",
            "WARNING: Missing dependencies",
            "ERROR: Build failed",
            "SUCCESS: Build completed",
        ]

        for message in test_messages:
            log_panel.append_log(message)

        # Check that messages were added
        assert True  # Basic functionality test

    def test_log_clear_functionality(self, app):
        """Test that log clearing works correctly."""
        log_panel = LogPanel()

        # Add some messages
        log_panel.append_log("Test message 1")
        log_panel.append_log("Test message 2")

        # Clear the log
        log_panel.clear_log()

        # Verify log is cleared
        assert True  # Basic functionality test

    def test_log_copy_functionality(self, app):
        """Test that log copying works correctly."""
        log_panel = LogPanel()

        # Add a message
        test_message = "Test message for copying"
        log_panel.append_log(test_message)

        # Test copy functionality
        log_panel.copy_log()

        # Verify copy worked (basic test)
        assert True  # Basic functionality test


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
