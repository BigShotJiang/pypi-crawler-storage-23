#!/usr/bin/env python3
"""
Translation system for Pypack GUI.

Provides internationalization support with English and Chinese translations.
"""

from enum import Enum
from typing import Dict


class Language(Enum):
    """Supported languages."""

    ENGLISH = "en"
    CHINESE = "zh"


class Translator:
    """Translation manager for Pypack GUI."""

    def __init__(self, default_language: Language = Language.CHINESE):
        """Initialize translator with default language.

        Args:
            default_language: Default language to use
        """
        self.current_language = default_language
        self.translations = self._load_translations()

    @staticmethod
    def _load_translations() -> Dict[str, Dict[str, str]]:
        """Load all translation strings."""
        return {
            "window_title": {
                Language.ENGLISH.value: "Pypack - Python Project Packaging Tool v1.0.0",
                Language.CHINESE.value: "Pypack - Python项目打包工具 v1.0.0",
            },
            "config_panel": {
                Language.ENGLISH.value: "Build Configuration",
                Language.CHINESE.value: "构建配置",
            },
            "log_panel": {
                Language.ENGLISH.value: "Build Log",
                Language.CHINESE.value: "构建日志",
            },
            "build_button": {
                Language.ENGLISH.value: "Start Build",
                Language.CHINESE.value: "开始构建",
            },
            "clean_button": {
                Language.ENGLISH.value: "Clean Artifacts",
                Language.CHINESE.value: "清理构建产物",
            },
            "ready_status": {
                Language.ENGLISH.value: "Ready",
                Language.CHINESE.value: "就绪",
            },
            "building_status": {
                Language.ENGLISH.value: "Building...",
                Language.CHINESE.value: "构建中...",
            },
            "build_success": {
                Language.ENGLISH.value: "✓ Build completed successfully!",
                Language.CHINESE.value: "✓ 构建成功完成!",
            },
            "build_failed": {
                Language.ENGLISH.value: "✗ Build failed",
                Language.CHINESE.value: "✗ 构建失败",
            },
            "clean_success": {
                Language.ENGLISH.value: "✓ Clean completed successfully!",
                Language.CHINESE.value: "✓ 清理完成!",
            },
            "build_starting": {
                Language.ENGLISH.value: "Starting build process...",
                Language.CHINESE.value: "开始构建过程...",
            },
            "about_title": {
                Language.ENGLISH.value: "About Pypack",
                Language.CHINESE.value: "关于 Pypack",
            },
            "about_content": {
                Language.ENGLISH.value: (
                    "Pypack v1.0.0\n\n"
                    "Advanced Python project packaging tool\n\n"
                    "Features:\n"
                    "- Workflow orchestration with parallel execution\n"
                    "- Embedded Python installation\n"
                    "- Cross-platform loader generation\n"
                    "- Source code packaging\n"
                    "- Library dependency management\n\n"
                    "Keyboard shortcuts:\n"
                    "Enter - Start build\n"
                    "Escape - Reset parameters\n"
                    "Ctrl+R - Reset parameters\n"
                    "Ctrl+Q - Exit"
                ),
                Language.CHINESE.value: (
                    "Pypack v1.0.0\n\n"
                    "高级Python项目打包工具\n\n"
                    "功能特性: \n"
                    "- 工作流编排与并行执行\n"
                    "- 嵌入式Python安装\n"
                    "- 跨平台加载器生成\n"
                    "- 源代码打包\n"
                    "- 库依赖管理\n\n"
                    "键盘快捷键: \n"
                    "回车 - 开始构建\n"
                    "ESC - 重置参数\n"
                    "Ctrl+R - 重置参数\n"
                    "Ctrl+Q - 退出"
                ),
            },
            "menu_file": {
                Language.ENGLISH.value: "&File",
                Language.CHINESE.value: "文件(&F)",
            },
            "menu_reset": {
                Language.ENGLISH.value: "&Reset Parameters",
                Language.CHINESE.value: "重置参数(&R)",
            },
            "menu_exit": {
                Language.ENGLISH.value: "E&xit",
                Language.CHINESE.value: "退出(&X)",
            },
            "menu_help": {
                Language.ENGLISH.value: "&Help",
                Language.CHINESE.value: "帮助(&H)",
            },
            "menu_about": {
                Language.ENGLISH.value: "&About",
                Language.CHINESE.value: "关于(&A)",
            },
            "error_prefix": {
                Language.ENGLISH.value: "Error: ",
                Language.CHINESE.value: "错误: ",
            },
            "build_complete_status": {
                Language.ENGLISH.value: "Build completed",
                Language.CHINESE.value: "构建完成",
            },
            "build_failed_status": {
                Language.ENGLISH.value: "Build failed",
                Language.CHINESE.value: "构建失败",
            },
            "clean_complete_status": {
                Language.ENGLISH.value: "Clean completed",
                Language.CHINESE.value: "清理完成",
            },
            # Parameter labels
            "param_project_name": {
                Language.ENGLISH.value: "Project Name",
                Language.CHINESE.value: "项目名称",
            },
            "param_directory": {
                Language.ENGLISH.value: "Project Directory",
                Language.CHINESE.value: "项目目录",
            },
            "param_python_version": {
                Language.ENGLISH.value: "Python Version",
                Language.CHINESE.value: "Python版本",
            },
            "param_loader_type": {
                Language.ENGLISH.value: "Loader Type",
                Language.CHINESE.value: "加载器类型",
            },
            "param_entry_suffix": {
                Language.ENGLISH.value: "Entry Suffix",
                Language.CHINESE.value: "入口文件后缀",
            },
            "param_generate_loader": {
                Language.ENGLISH.value: "Generate Loader",
                Language.CHINESE.value: "生成加载器",
            },
            "param_offline": {
                Language.ENGLISH.value: "Offline Mode",
                Language.CHINESE.value: "离线模式",
            },
            "param_max_concurrent": {
                Language.ENGLISH.value: "Max Concurrent Tasks",
                Language.CHINESE.value: "最大并发任务数",
            },
            "param_debug": {
                Language.ENGLISH.value: "Debug Mode",
                Language.CHINESE.value: "调试模式",
            },
            "param_cache_dir": {
                Language.ENGLISH.value: "Cache Directory",
                Language.CHINESE.value: "缓存目录",
            },
            "param_archive_format": {
                Language.ENGLISH.value: "Dependency Archive Format",
                Language.CHINESE.value: "依赖库归档格式",
            },
            "param_mirror": {
                Language.ENGLISH.value: "PyPI Mirror",
                Language.CHINESE.value: "PyPI镜像源",
            },
            "param_archive_type": {
                Language.ENGLISH.value: "Final Archive Type (Optional)",
                Language.CHINESE.value: "最终归档类型(可选)",
            },
            # Control buttons
            "pause_button": {
                Language.ENGLISH.value: "Pause",
                Language.CHINESE.value: "暂停",
            },
            "resume_button": {
                Language.ENGLISH.value: "Resume",
                Language.CHINESE.value: "继续",
            },
            "stop_button": {
                Language.ENGLISH.value: "Stop",
                Language.CHINESE.value: "停止",
            },
            "build_paused": {
                Language.ENGLISH.value: "Build paused",
                Language.CHINESE.value: "构建已暂停",
            },
            "build_stopped": {
                Language.ENGLISH.value: "Build stopped by user",
                Language.CHINESE.value: "用户已停止构建",
            },
            "build_resumed": {
                Language.ENGLISH.value: "Build resumed",
                Language.CHINESE.value: "构建已恢复",
            },
            # Projects display
            "projects_title": {
                Language.ENGLISH.value: "Projects",
                Language.CHINESE.value: "Projects 项目列表",
            },
            "project_details_placeholder": {
                Language.ENGLISH.value: "Select a project to view details",
                Language.CHINESE.value: "选择项目查看详细信息",
            },
            "projects_placeholder": {
                Language.ENGLISH.value: "Please select a directory to view projects",
                Language.CHINESE.value: "请选择项目目录以查看项目列表",
            },
            "projects_not_found": {
                Language.ENGLISH.value: "No Python projects found in this directory",
                Language.CHINESE.value: "该目录中未找到Python项目",
            },
            "projects_count": {
                Language.ENGLISH.value: "Found {count} projects:",
                Language.CHINESE.value: "共找到 {count} 个项目:",
            },
            "directory_not_exist": {
                Language.ENGLISH.value: "Directory does not exist or is not a folder",
                Language.CHINESE.value: "目录不存在或不是文件夹",
            },
            "parse_error": {
                Language.ENGLISH.value: "Parse error: {error}",
                Language.CHINESE.value: "解析错误: {error}",
            },
            # Archive section labels
            "archive_format_label": {
                Language.ENGLISH.value: "Dependency Format:",
                Language.CHINESE.value: "依赖库格式: ",
            },
            "final_archive_label": {
                Language.ENGLISH.value: "Final Archive:",
                Language.CHINESE.value: "最终归档: ",
            },
        }

    def set_language(self, language: Language) -> None:
        """Change current language.

        Args:
            language: Language to switch to
        """
        self.current_language = language

    def tr(self, key: str, **kwargs) -> str:
        """Translate a string key to current language.

        Args:
            key: Translation key
            **kwargs: Additional formatting parameters

        Returns
        -------
            Translated string
        """
        if key not in self.translations:
            return key

        translation_dict = self.translations[key]
        current_lang = self.current_language.value

        if current_lang in translation_dict:
            result = translation_dict[current_lang]
            if kwargs:
                result = result.format(**kwargs)
            return result
        # Fallback to English
        if Language.ENGLISH.value in translation_dict:
            result = translation_dict[Language.ENGLISH.value]
            if kwargs:
                result = result.format(**kwargs)
            return result
        return key


# Global translator instance
translator = Translator()
