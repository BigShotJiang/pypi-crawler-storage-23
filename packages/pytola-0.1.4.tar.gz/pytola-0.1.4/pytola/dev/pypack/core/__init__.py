"""Core business logic for pypack."""
