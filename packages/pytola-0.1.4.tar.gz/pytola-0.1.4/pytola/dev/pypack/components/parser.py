"""Parser module for components."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

from ..models.solution import Solution

logger = logging.getLogger(__name__)
CWD = Path.cwd()


def create_parser() -> argparse.ArgumentParser:
    """Create and return an argument parser for the pyproject.toml parser tool.

    Returns
    -------
        Configured ArgumentParser instance with all supported command-line options.
    """
    parser = argparse.ArgumentParser(
        description="Parse pyproject.toml files in a directory and analyze Python projects"
    )
    parser.add_argument(
        "directory",
        type=str,
        nargs="?",
        default=str(CWD),
        help="Directory to scan for pyproject.toml files (default: current directory)",
    )
    parser.add_argument("--debug", "-d", action="store_true", help="Enable debug logging output")
    return parser


def main() -> None:
    """Run main entry point for the pyproject.toml parser tool.

    Parses command line arguments and creates a Solution instance by scanning
    the specified directory for pyproject.toml files. Uses cached data if
    available unless the update flag is set.
    """
    parser = create_parser()
    args = parser.parse_args()

    if args.debug:
        logger.setLevel(logging.DEBUG)

    Solution.from_directory(Path(args.directory))
