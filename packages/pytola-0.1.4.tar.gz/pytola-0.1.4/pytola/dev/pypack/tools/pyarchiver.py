"""Multi-format project archiver with configurable compression."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

from .._logger import logger
from ..components.archiver import ARCHIVE_FORMATS, ArchiveFormat, PyArchiveConfig, PyArchiver


def list_supported_formats() -> str:
    """Generate a formatted list of supported formats with descriptions."""
    format_lines = [f"  {fmt.value:<8} - {fmt.description}" for fmt in ArchiveFormat]
    return "\n".join(format_lines)


def create_parser() -> argparse.ArgumentParser:
    """Create parser for command line arguments."""
    parser = argparse.ArgumentParser(
        description="Archive projects in directory with various compression formats",
        epilog=f"Supported formats:\n{list_supported_formats()}",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "directory",
        type=Path,
        nargs="?",
        default=Path.cwd(),
        help="Directory to archive for projects.",
    )
    parser.add_argument("--debug", "-d", action="store_true", help="Debug mode")
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Verbose output during archiving",
    )
    parser.add_argument(
        "--format",
        "-f",
        type=str,
        default="zip",
        choices=sorted(ARCHIVE_FORMATS),
        help="Archive format (default: zip)",
    )
    parser.add_argument(
        "--compression-level",
        "-c",
        type=int,
        default=6,
        choices=range(10),
        metavar="0-9",
        help="Compression level (0-9, default: 6)",
    )
    parser.add_argument(
        "--preserve-permissions",
        "-P",
        action="store_true",
        help="Preserve file permissions (TAR formats only)",
    )
    parser.add_argument(
        "--project",
        "-p",
        type=str,
        nargs="*",
        help="Specific project(s) to archive (default: all projects)",
    )
    parser.add_argument(
        "--ignore",
        type=str,
        nargs="*",
        help="Additional ignore patterns",
    )
    return parser


def main() -> None:
    """Run entry point for the command-line interface.

    Pyarchiver utility tool

    Examples
    --------
      pyarchiver [options] <arguments>
    """
    parser = create_parser()
    args = parser.parse_args()

    if args.debug:
        logger.setLevel(logging.DEBUG)

    # Create configuration from arguments
    config = PyArchiveConfig(
        compression_level=args.compression_level,
        verbose=args.verbose or args.debug,
        preserve_permissions=args.preserve_permissions,
    )

    # Create archiver instance
    archiver = PyArchiver(root_dir=args.directory, config=config)

    # Archive projects
    archiver.archive_projects(
        format=args.format,
        projects_to_archive=args.project,
        ignore_patterns=set(args.ignore or []),
    )
