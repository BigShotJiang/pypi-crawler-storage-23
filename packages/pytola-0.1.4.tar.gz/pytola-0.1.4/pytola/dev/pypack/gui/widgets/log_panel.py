"""Log panel widget for GUI."""

from __future__ import annotations

from PySide2.QtWidgets import (
    QGroupBox,
    QHBoxLayout,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)


class LogPanel(QWidget):
    """Log panel for displaying build output."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._setup_ui()

    def _setup_ui(self) -> None:
        """Set up the log panel UI."""
        layout = QVBoxLayout(self)

        # Log group
        log_group = QGroupBox("Build Log")
        log_layout = QVBoxLayout(log_group)

        # Log text area
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        # Note: setMaximumBlockCount not available in PySide2, using alternative approach
        log_layout.addWidget(self.log_text)

        # Control buttons
        button_layout = QHBoxLayout()

        self.clear_button = QPushButton("Clear Log")
        self.clear_button.clicked.connect(self._clear_log)
        button_layout.addWidget(self.clear_button)

        self.copy_button = QPushButton("Copy Log")
        self.copy_button.clicked.connect(self._copy_log)
        button_layout.addWidget(self.copy_button)

        button_layout.addStretch()  # Push buttons to the left
        log_layout.addLayout(button_layout)

        layout.addWidget(log_group)

    def append_log(self, message: str) -> None:
        """Append message to log."""
        self.log_text.append(message)
        # Auto-scroll to bottom
        self.log_text.verticalScrollBar().setValue(self.log_text.verticalScrollBar().maximum())

    def clear_log(self) -> None:
        """Clear all log content."""
        self.log_text.clear()

    def copy_log(self) -> None:
        """Copy log content to clipboard."""
        self.log_text.selectAll()
        self.log_text.copy()

    def _clear_log(self) -> None:
        """Clear log handler."""
        self.clear_log()

    def _copy_log(self) -> None:
        """Copy log handler."""
        self.copy_log()

    def set_log_level(self, level: str) -> None:
        """Set log level display filter."""
        # This would require more sophisticated log filtering
        # For now, we display all logs
        pass
