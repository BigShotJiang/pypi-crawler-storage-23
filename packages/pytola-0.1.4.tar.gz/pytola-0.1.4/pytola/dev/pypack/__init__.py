"""PyPack - Python Packaging Tool.

A comprehensive tool for packaging Python projects with workflow orchestration.
"""

from .cli.main import main
from .gui.main import main as gui_main

__version__ = "0.1.4"
__author__ = "Pytola Team"

__all__ = [
    "__author__",
    "__version__",
    "gui_main",
    "main",
]
