"""Core modules for Resource Hacker functionality."""
