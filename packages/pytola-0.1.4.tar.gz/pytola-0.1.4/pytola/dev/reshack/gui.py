"""Graphical user interface for reshack."""

import logging
import sys

from PySide2.QtWidgets import QApplication

from .ui.main_window import MainWindow

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


def main() -> None:
    """Launch the GUI application."""
    if QApplication is None:
        logger.error("GUI dependencies not available")
        logger.error("Error: GUI dependencies not available. Please install PySide2.")
        sys.exit(1)

    try:
        logger.info("Launching Resource Hacker GUI")

        # Create Qt application
        app = QApplication(sys.argv)
        app.setApplicationName("Resource Hacker")
        app.setApplicationVersion("0.1.0")

        # Create and show main window
        window = MainWindow()
        window.show()

        logger.info("GUI application started successfully")

        # Run application
        sys.exit(app.exec_())

    except ImportError as e:
        logger.exception(f"Failed to import GUI dependencies: {e}")
        logger.exception(
            "Error: GUI dependencies not available. Please install PySide2.",
        )
        sys.exit(1)
    except Exception as e:
        logger.exception(f"Failed to launch GUI: {e}")
        logger.exception(f"Error launching GUI: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
