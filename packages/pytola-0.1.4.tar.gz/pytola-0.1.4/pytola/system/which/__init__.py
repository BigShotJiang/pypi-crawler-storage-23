"""Which module - Find executable paths for commands cross-platform."""

from __future__ import annotations

from .cli import WINDOWS_BUILTINS, WindowsBuiltinCommands, find_executable

__all__ = ["WINDOWS_BUILTINS", "WindowsBuiltinCommands", "find_executable"]


def main():
    """Run entry point for the command-line interface.

    Command-line interface for which

    Examples
    --------
      __init__ [options] <arguments>
    """
    from .cli import main as cli_main

    return cli_main()
