"""Benchmark tests for sshcopyid functionality."""

from __future__ import annotations

import contextlib
import tempfile
from pathlib import Path

import pytest

from pytola.system.sshcopyid import SSHCopyIDConfig


@pytest.mark.benchmark(group="sshcopyid")
def test_config_creation_benchmark(benchmark):
    """Benchmark SSHCopyIDConfig creation."""

    def create_config():
        return SSHCopyIDConfig(
            hostname="localhost",
            username="testuser",
            password="testpass",
            port=22,
            public_key_path="~/.ssh/id_rsa.pub",
        )

    result = benchmark(create_config)
    assert isinstance(result, SSHCopyIDConfig)
    assert result.hostname == "localhost"


@pytest.mark.benchmark(group="sshcopyid")
def test_config_property_access_benchmark(benchmark):
    """Benchmark cached property access."""
    config = SSHCopyIDConfig(hostname="localhost", username="testuser", password="testpass")

    # Benchmark property access (this will compute and cache the value)
    result = benchmark(lambda: config.expanded_key_path)
    assert isinstance(result, Path)

    # Verify caching works by accessing again (should be fast)
    cached_result = config.expanded_key_path
    assert isinstance(cached_result, Path)
    assert result == cached_result


@pytest.mark.benchmark(group="sshcopyid")
def test_ssh_command_parts_benchmark(benchmark):
    """Benchmark SSH command parts generation."""
    config = SSHCopyIDConfig(hostname="example.com", username="user", password="pass", port=2222)

    result = benchmark(lambda: config.ssh_command_parts)
    assert isinstance(result, list)
    assert "ssh" in result
    assert "2222" in result
    assert "user@example.com" in result[-1]


@pytest.mark.benchmark(group="sshcopyid-fileops")
def test_temp_file_operations_benchmark(benchmark):
    """Benchmark temporary file operations typical in testing."""

    def file_operations():

        try:
            with tempfile.NamedTemporaryFile(mode="w", suffix=".pub", delete=False) as tmp_file:
                tmp_file.write("ssh-rsa AAAAB3NzaC1yc2E test@example.com")
                tmp_file.flush()

            # Simulate file reading/checking
            path = Path(tmp_file.name)
            content = path.read_text()
            exists = path.exists()

            return content, exists
        finally:
            with contextlib.suppress(BaseException):
                Path(tmp_file.name).unlink(missing_ok=True)

    content, exists = benchmark(file_operations)
    assert "ssh-rsa" in content
    assert exists


@pytest.mark.benchmark(group="sshcopyid-validation")
def test_parameter_validation_benchmark(benchmark):
    """Benchmark parameter validation overhead."""

    def validate_params():
        configs = []
        for i in range(100):
            config = SSHCopyIDConfig(
                hostname=f"host{i}.example.com",
                username=f"user{i}",
                password=f"pass{i}",
                port=22 + i,
            )
            configs.append(config)
        return configs

    configs = benchmark(validate_params)
    assert len(configs) == 100
    assert all(isinstance(c, SSHCopyIDConfig) for c in configs)


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--benchmark-only"])
