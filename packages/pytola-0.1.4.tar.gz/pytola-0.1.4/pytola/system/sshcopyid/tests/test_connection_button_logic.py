"""Test for SSH Copy ID GUI connection button logic."""

from __future__ import annotations

import sys

import pytest
from PySide2.QtWidgets import QApplication

# Import GUI components
try:
    from pytola.system.sshcopyid import SSHCopyIDGUI

    GUI_AVAILABLE = True
except ImportError as e:
    GUI_AVAILABLE = False
    print(f"GUI import failed: {e}")


@pytest.fixture(scope="module")
def app():
    """Create QApplication fixture."""
    if not GUI_AVAILABLE:
        pytest.skip("GUI components not available")

    app_instance = QApplication.instance()
    if app_instance is None:
        app_instance = QApplication(sys.argv)
    return app_instance


@pytest.fixture
def gui_window(app):
    """Create GUI window fixture."""
    if not GUI_AVAILABLE:
        pytest.skip("GUI components not available")

    window = SSHCopyIDGUI()
    yield window
    window.close()


class TestConnectionButtonLogic:
    """Tests for connection button enable/disable logic."""

    @pytest.mark.skipif(not GUI_AVAILABLE, reason="GUI not available")
    def test_button_initially_disabled(self, gui_window):
        """Test that button is initially disabled."""
        assert not gui_window.test_connection_button.isEnabled()
        assert gui_window.connection_status_label.text() == ""

    @pytest.mark.skipif(not GUI_AVAILABLE, reason="GUI not available")
    def test_button_enabled_when_all_fields_filled(self, gui_window):
        """Test that button enables when all required fields are filled."""
        # Fill hostname only - should still be disabled
        gui_window.hostname_input.setText("192.168.1.1")
        assert not gui_window.test_connection_button.isEnabled()

        # Fill username - should still be disabled
        gui_window.username_input.setText("testuser")
        assert not gui_window.test_connection_button.isEnabled()

        # Fill password - should now be enabled
        gui_window.password_input.setText("testpass")
        assert gui_window.test_connection_button.isEnabled()

        # Clear password - should be disabled again
        gui_window.password_input.clear()
        assert not gui_window.test_connection_button.isEnabled()

    @pytest.mark.skipif(not GUI_AVAILABLE, reason="GUI not available")
    def test_button_disables_when_any_field_cleared(self, gui_window):
        """Test that button disables when any required field is cleared."""
        # Fill all fields
        gui_window.hostname_input.setText("192.168.1.1")
        gui_window.username_input.setText("testuser")
        gui_window.password_input.setText("testpass")
        assert gui_window.test_connection_button.isEnabled()

        # Clear hostname
        gui_window.hostname_input.clear()
        assert not gui_window.test_connection_button.isEnabled()

        # Refill hostname
        gui_window.hostname_input.setText("192.168.1.1")
        assert gui_window.test_connection_button.isEnabled()

        # Clear username
        gui_window.username_input.clear()
        assert not gui_window.test_connection_button.isEnabled()

    @pytest.mark.skipif(not GUI_AVAILABLE, reason="GUI not available")
    def test_connection_status_reset_on_incomplete_fields(self, gui_window):
        """Test that connection status resets when fields become incomplete."""
        # Fill all fields and set connection status
        gui_window.hostname_input.setText("192.168.1.1")
        gui_window.username_input.setText("testuser")
        gui_window.password_input.setText("testpass")

        # Simulate successful connection
        gui_window.update_connection_status(True, "Connected")
        assert gui_window.connection_status_label.text() == "✓"

        # Clear one field - status should reset
        gui_window.username_input.clear()
        assert gui_window.connection_status_label.text() == ""

        # Refill and set status again
        gui_window.username_input.setText("testuser")
        gui_window.update_connection_status(False, "Failed")
        assert gui_window.connection_status_label.text() == "✗"

        # Clear hostname - status should reset
        gui_window.hostname_input.clear()
        assert gui_window.connection_status_label.text() == ""


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
