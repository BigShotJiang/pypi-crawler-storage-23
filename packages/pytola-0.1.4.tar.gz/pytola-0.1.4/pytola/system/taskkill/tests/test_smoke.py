"""Smoke test for taskkill module."""

from unittest.mock import patch

from pytola.system.taskkill.cli import ProcessInfo, get_matched_process


def test_basic_functionality():
    """Test basic functionality without subprocess calls."""
    # Test ProcessInfo creation
    process = ProcessInfo(name="test.exe", pid="1234")
    assert process.name == "test.exe"
    assert process.pid == "1234"

    # Test with mocked process list
    sample_processes = [
        ProcessInfo(name="python.exe", pid="1001"),
        ProcessInfo(name="chrome.exe", pid="1002"),
        ProcessInfo(name="notepad.exe", pid="1003"),
    ]

    with patch("pytola.system.taskkill.cli._cached_process_list", sample_processes):
        # Test fuzzy match (default behavior)
        matches = get_matched_process("python")
        assert len(matches) == 1
        assert matches[0].name == "python.exe"

        # Test explicit wildcard match
        matches = get_matched_process("*note*")
        assert len(matches) == 1
        assert matches[0].name == "notepad.exe"

        # Test no match
        matches = get_matched_process("firefox")
        assert len(matches) == 0

    print("All smoke tests passed!")


if __name__ == "__main__":
    test_basic_functionality()
