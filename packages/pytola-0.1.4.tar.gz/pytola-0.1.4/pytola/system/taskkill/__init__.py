"""Taskkill: Cross-platform process termination utility."""

from .cli import main

__all__ = ["main"]
