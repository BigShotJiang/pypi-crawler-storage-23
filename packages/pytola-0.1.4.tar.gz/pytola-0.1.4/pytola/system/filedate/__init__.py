"""File date manipulation utility."""

from .cli import main

__all__ = ["main"]
