# filedate

A file date management tool that normalizes date prefixes in filenames.

## Features

- Automatically detects and removes date prefixes from filenames (format: YYYYMMDD)
- Adds new date prefixes based on the latest file creation or modification time
- Supports multiple date separators: `-`, `_`, `#`, `.`, `~`
- Supports concurrent processing of multiple files for improved efficiency
- Automatically handles filename conflicts (adds UUID suffix)
- Skips files that are already correctly named

## Usage

```bash
# Process a single file
filedate document.txt

# Process multiple files
filedate file1.txt file2.txt file3.txt

# Process wildcard-matched files
filedate *.py
```

## How It Works

1. **Detect date prefix**: Identifies YYYYMMDD format dates in filenames
2. **Get file time**: Reads file creation and modification times, takes the newer one
3. **Remove old prefix**: Recursively removes all date prefixes from filename
4. **Add new prefix**: Uses the latest time as the new date prefix
5. **Handle conflicts**: Automatically adds unique suffix if target file exists

## Example

```bash
# Assuming a file 20200101_notes.txt with actual modification date 2023-12-15
filedate 20200101_notes.txt

# Output:
# Remove date prefix: notes
# Rename: 20200101_notes.txt-> 20231215_notes.txt
# Done in 0.0123s
```
