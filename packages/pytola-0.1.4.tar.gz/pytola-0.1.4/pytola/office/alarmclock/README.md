# Alarm Clock

A digital alarm clock application with a graphical user interface built using PySide2. Features include configurable alarms, digital time display, visual notifications, alarm history, and advanced configuration options.

## Features

- **Digital clock display** with animated border effects and customizable styling
- **Configurable alarm time setting** with precise time selection
- **Quick delay options** (1, 5, 10, 15, 30, 60 minutes) for fast alarm setup
- **Repeat alarm functionality** for daily recurring alarms
- **Snooze feature** with configurable snooze duration and count limits
- **Multiple visual notification effects** including color, opacity, and combined animations

- **Alarm history tracking** with statistics and recent activity
- **High contrast accessibility theme** for improved visibility
- **Professional UI styling** using qtstyles framework
- **Persistent configuration** with automatic saving and loading
- **Advanced settings** including window behavior, logging, and performance options

## Installation

Install the required dependencies:

```bash
pip install -e .
```

## Usage

Run the alarm clock application:

```bash
alarmclk
```

Or directly with Python:

```bash
python -m pytola.alarmclock
```

### Command Line Options

- `-d, --debug`: Enable debug mode with verbose logging
- `-v, --version`: Show version information
- `--config PATH`: Use custom configuration file
- `--reset-config`: Reset configuration to defaults

### Configuration

The application creates configuration files in `~/.pytola/alarmclock/`:

- `config.json`: Main configuration settings
- `history.json`: Alarm history and statistics
- `alarmclock.log`: Application logs

Configuration can be customized through the config file or programmatically.

## Configuration Parameters

The application uses the following configuration parameters:

- **Digital Clock**: Displays current time with animated border colors
- **Alarm Time**: Set specific time for the alarm to trigger
- **Delay Options**: Quick buttons to set alarms for specific intervals
- **Repeat Option**: Enable/disable alarm repetition
- **Visual Notifications**: Alert dialog with blinking effect

## Architecture

The application follows a modular design:

- `AlarmClockConfig`: Configuration dataclass with all application settings
- `DigitalClock`: Widget displaying current time with animation
- `BlinkDialog`: Notification dialog with visual effects
- `AlarmClock`: Main application window with GUI controls

## Testing

The module includes comprehensive tests divided into two categories:

### Core Tests (Non-GUI)

```bash
python -m pytest pytola/alarmclock/tests/test_alarmclock_core.py -v
```

Tests configuration, data classes, enums, and core logic without requiring a GUI environment.

### GUI Tests

```bash
python -m pytest pytola/alarmclock/tests/test_alarmclock_gui.py -v -m qt
```

Tests GUI components using pytest-qt. These tests require a working Qt environment.

### Benchmark Tests

```bash
python -m pytest pytola/alarmclock/tests/test_benchmark.py -v
```

Performance benchmarks for critical operations.

### Run All Tests

```bash
python -m pytest pytola/alarmclock/tests/ -v
```

## Dependencies

- PySide2: GUI framework
- pytola.qtstyles: Professional Qt stylesheet themes
- typing-extensions: Type hinting support for older Python versions
- pytest: Testing framework
- pytest-qt: Qt testing utilities
