"""Image to ICO conversion module.

This module provides functionality to convert various image formats to ICO files.
Includes both command-line and GUI interfaces.
"""

from __future__ import annotations

from .img2ico import ImageToIcoConfig, ImageToIcoRunner, is_valid_image, main, parse_sizes
from .img2ico_gui import main as gui_main

__all__ = [
    "ImageToIcoConfig",
    "ImageToIcoRunner",
    "gui_main",
    "is_valid_image",
    "main",
    "parse_sizes",
]
