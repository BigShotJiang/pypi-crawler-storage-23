"""Benchmark tests for img2ico module."""

from __future__ import annotations

from pathlib import Path

import pytest
from PIL import Image

from pytola.office.img2ico.img2ico import ImageToIcoRunner


class TestImg2IcoBenchmark:
    """Benchmark tests for img2ico conversion."""

    @pytest.mark.benchmark(group="conversion")
    def test_benchmark_single_file_conversion(self, benchmark, tmp_path: Path):
        """Benchmark single file conversion performance."""
        # Create test image
        img_path = tmp_path / "test.png"
        img = Image.new("RGBA", (512, 512), color=(255, 0, 0, 255))
        img.save(img_path)

        output_path = tmp_path / "output.ico"
        runner = ImageToIcoRunner(
            input_path=img_path,
            output_path=output_path,
            sizes={16, 32, 48, 64, 128, 256},
        )

        benchmark(runner.run)

        assert output_path.exists()

    @pytest.mark.benchmark(group="conversion")
    def test_benchmark_large_image_conversion(self, benchmark, tmp_path: Path):
        """Benchmark large image conversion performance."""
        # Create large test image
        img_path = tmp_path / "large.png"
        img = Image.new("RGBA", (2048, 2048), color=(0, 255, 0, 255))
        img.save(img_path)

        output_path = tmp_path / "output.ico"
        runner = ImageToIcoRunner(
            input_path=img_path,
            output_path=output_path,
            sizes={256},
        )

        benchmark(runner.run)

        assert output_path.exists()

    @pytest.mark.benchmark(group="validation")
    def test_benchmark_image_validation(self, benchmark, tmp_path: Path):
        """Benchmark image validation performance."""
        from pytola.office.img2ico.img2ico import is_valid_image

        # Create test image
        img_path = tmp_path / "test.png"
        img = Image.new("RGBA", (256, 256), color=(255, 0, 0, 255))
        img.save(img_path)

        result = benchmark(is_valid_image, img_path)
        assert result is True

    @pytest.mark.benchmark(group="resizing")
    def test_benchmark_resize_for_icon(self, benchmark):
        """Benchmark image resizing performance."""
        runner = ImageToIcoRunner.__new__(ImageToIcoRunner)

        # Create test image
        img = Image.new("RGBA", (1024, 1024), color=(0, 0, 255, 255))

        result = benchmark(runner._resize_for_icon, img, 256)
        assert result.size == (256, 256)
