# img2ico - Image to ICO Converter

Convert various image formats to ICO files with multiple icon sizes.

## Features

- Convert single images or batch process directories
- Generate multiple icon sizes optimized for Windows and macOS:
  - **Windows**: 16, 24, 32, 48, 64, 128, 256 pixels
  - **macOS**: 16, 32, 64, 128, 256, 512, 1024 pixels
- Support for JPG, PNG, GIF, BMP, WebP, TIFF, and SVG formats
- Maintains aspect ratio with transparent background
- Configurable output sizes
- **GUI application** for easy image conversion
- Quality modes: high (default), medium, low

## Installation

```bash
# Basic installation (without SVG and GUI support)
uv pip install -e pytola/img2ico

# Installation with SVG support
uv pip install -e pytola/img2ico[svg]

# Installation with GUI support
uv pip install -e pytola/img2ico[gui]

# Install with all features
uv pip install -e pytola/img2ico[svg,gui]
```

## Usage

### GUI Application

Launch the graphical interface:

```bash
img2ico-gui
```

The GUI provides:
- File and directory browser for input/output
- Visual size selector
- Quality mode selection
- Real-time progress tracking
- Configuration persistence

### Command Line

#### Convert a single image

```bash
img2ico image.png
# Creates image.ico with default sizes

img2ico image.png output.ico
# Creates output.ico with default sizes
```

#### Convert all images in a directory

```bash
img2ico /path/to/images
# Creates ico_output/ directory with all converted icons

img2ico /path/to/images /path/to/output
# Creates icons in specified output directory
```

#### Specify custom icon sizes

```bash
img2ico image.png --sizes 16,32,48,256
# Creates icon with only specified sizes

img2ico image.png -s 32,64
# Short form for sizes option
```

#### Quality modes

```bash
img2ico image.png --quality high
# Use high quality (LANCZOS/BICUBIC resampling with sharpening)

img2ico image.png -q medium
# Use medium quality (BILINEAR resampling)

img2ico image.png -q low
# Use low quality (NEAREST resampling, fastest)
```

## API Usage

```python
from img2ico import ImageToIcoRunner
from pathlib import Path

# Convert single file with default sizes (optimized for Windows/macOS)
runner = ImageToIcoRunner(
    input_path=Path("image.png"),
    output_path=Path("output.ico"),
    # Default: {16, 24, 32, 48, 64, 128, 256, 512, 1024}
)
runner.run()

# Batch convert directory with custom quality
runner = ImageToIcoRunner(
    input_path=Path("/path/to/images"),
    output_path=Path("/path/to/output"),
    quality="high"
)
runner.run()

# Custom sizes
runner = ImageToIcoRunner(
    input_path=Path("image.png"),
    sizes={16, 32, 64, 256}
)
runner.run()
```

## Configuration

Configuration is stored in `~/.pytola/img2ico.json`:

```json
{
    "DEFAULT_SIZES": [16, 24, 32, 48, 64, 128, 256, 512, 1024],
    "EXTENSIONS": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tiff", ".svg"]
}
```

GUI configuration is stored separately in `~/.pytola/img2ico_gui.json`:

```json
{
    "input_path": "/last/used/path",
    "output_path": "/last/output/path",
    "sizes": "16,24,32,48,64,128,256,512,1024",
    "quality": "high",
    "window_width": 900,
    "window_height": 600,
    "recent_input_paths": [],
    "recent_output_paths": []
}
```

## Command Reference

### Command Line Tool

| Option          | Description                             |
| --------------- | --------------------------------------- |
| `input`         | Input image file or directory           |
| `output`        | Output ICO file or directory (optional) |
| `-s, --sizes`   | Comma-separated list of icon sizes      |
| `-q, --quality` | Image resize quality (high/medium/low)  |
| `-h, --help`    | Show help message                       |

### GUI Tool

| Command       | Description                     |
| ------------- | ------------------------------- |
| `img2ico-gui` | Launch graphical user interface |

## Supported Formats

- JPEG/JPG
- PNG
- GIF
- BMP
- WebP
- TIFF
- SVG *(requires cairosvg library)*

**Note**: SVG support requires the `cairosvg` library. Install it with the `[svg]` extra:
```bash
uv pip install -e pytola/img2ico[svg]
```

## Quality Modes

- **high** (default): LANCZOS/BICUBIC resampling with multi-step downscaling for large images and sharpening for upscaling
- **medium**: BILINEAR resampling, balanced between speed and quality
- **low**: NEAREST neighbor resampling, fastest but lowest quality
