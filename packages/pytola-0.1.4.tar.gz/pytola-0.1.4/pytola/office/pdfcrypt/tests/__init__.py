"""Test suite for pdfcrypt module."""
