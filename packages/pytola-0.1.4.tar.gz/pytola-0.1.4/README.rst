=======
Pytola
=======

Pytola: Python Tools and Applications Collection

* Free software: MIT license
* Documentation: https://pytola.readthedocs.io/zh-cn/stable/

项目概述
--------

Pytola 是一个多功能 Python工具集合，包含开发工具、办公应用、系统工具等多个模块。

主要功能模块
------------

* **开发工具** (dev):包管理、版本控制、代码检查等开发辅助工具
* **办公应用** (office): PDF处理、图像转换、文档扫描等办公工具
* **系统工具** (system): 文件管理、系统信息、进程控制等系统工具
* **安全工具** (security): 输入验证、文件路径安全检查等安全工具
* **多媒体工具** (multimedia):音播放、媒体处理等多媒体工具
* **仿真工具** (simulation):科计算、模拟仿真等专业工具

安装方式
--------

从 PyPI安装::

    pip install pytola

或者使用 uv工具安装::

    uv install pytola

或者从源码安装::

    git clone https://gitee.com/gooker_young/pytola.git
    cd pytola
    pip install .

开发安装::

    git clone https://gitee.com/gooker_young/pytola.git
    cd pytola
    pip install -e .

使用示例
--------

基础导入::

    import pytola
    from pytola import logger, ThemeManager

    # 获取版本信息
    print(f"Pytola version: {pytola.__version__}")

    # 使用日志功能
    logger.info("Pytola initialized successfully")

    # 使用主题管理器
    theme_manager = ThemeManager()
    print(f"Available themes: {theme_manager.list_themes()}")

模块使用示例::

    # 开发工具示例
    from pytola.dev.pypack import main as pypack_main
    from pytola.dev.checksum import main as checksum_main

    #办工具示例
    from pytola.office.img2ico import main as img2ico_main
    from pytola.office.pdfcrypt import main as pdfcrypt_main

    #系统工具示例
    from pytola.system.filedate import main as filedate_main

    #安工具工具示例
    from pytola.security import InputValidator
    validator = InputValidator()
    print(f"Valid email: {validator.validate_email('test@example.com')}")

命令行工具
----------

Pytola 提供多个命令行工具：

* ``pypack`` - Python包管理工具
* ``checksum`` - 文件校验工具
* ``img2ico`` - 图像转ICO工具
* ``pdfcrypt`` - PDF加密工具
* ``filedate`` - 文件时间管理工具
* ``llmcli`` - LLM客户端工具

完整工具列表请查看 pyproject.toml 中的 [project.scripts]。

项目结构
--------

项目采用模块化设计，主要目录结构：

* ``pytola/`` -核心模块
* ``pytola/dev/`` - 开发工具
* ``pytola/office/`` -办工具
* ``pytola/system/`` -系统工具
* ``pytola/security.py`` -安全工具
* ``docs/`` - 文档
* ``scripts/`` -辅脚助脚本

构建要求
--------

**要求:**
- Python >= 3.8
- pip
- uv

开发流程
--------

使用 uv工具::

    # 开发模式安装
    uv sync

    #运行测试
    pytest

    #检查代码风格
    uvx prek
