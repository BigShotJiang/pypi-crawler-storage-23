To use a Vertex example, set the following environment variables manually:
```
export GOOGLE_CLOUD_PROJECT=
export GOOGLE_CLOUD_LOCATION=
export GOOGLE_APPLICATION_CREDENTIALS=
```

Using gcloud CLI:
How to setup [Gemini CLI Authentication Setup](https://github.com/google-gemini/gemini-cli/blob/main/docs/get-started/authentication.md)

`profile_name`: Replace default with relevant GCP project name in `.config/gcloud/configurations/your-project-configuration-file`