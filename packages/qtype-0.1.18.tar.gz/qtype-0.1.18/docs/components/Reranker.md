### Reranker

Reranks a list of documents based on relevance to a query using an LLM.

- **type** (`Literal`): (No documentation available.)
