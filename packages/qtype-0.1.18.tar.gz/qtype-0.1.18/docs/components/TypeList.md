### TypeList

Schema for a standalone list of type definitions.

- **root** (`list[CustomType]`): (No documentation available.)
