### CustomType

A simple declaration of a custom data type by the user.

- **id** (`str`): (No documentation available.)
- **description** (`str | None`): (No documentation available.)
- **properties** (`dict[str, str]`): (No documentation available.)
