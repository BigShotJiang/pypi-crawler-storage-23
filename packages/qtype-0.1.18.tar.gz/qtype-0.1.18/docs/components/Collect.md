### Collect

A step that collects all inputs and creates a single list to return.

- **type** (`Literal`): (No documentation available.)
- **batch_config** (`BatchConfig`): Configuration for processing the input stream in batches. If omitted, the step processes items one by one.
