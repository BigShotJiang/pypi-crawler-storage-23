### Explode

A step that takes a list input and produces multiple outputs, one per item in the list.

- **type** (`Literal`): (No documentation available.)
