### Source

Base class for data sources

- **id** (`str`): Unique ID of the data source.
