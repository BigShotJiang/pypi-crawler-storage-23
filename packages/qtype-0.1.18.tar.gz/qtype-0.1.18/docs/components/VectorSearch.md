### VectorSearch

Performs vector similarity search against a vector index.

- **type** (`Literal`): (No documentation available.)
- **index** (`Reference[VectorIndex] | str`): Index to search against (object or ID reference).
