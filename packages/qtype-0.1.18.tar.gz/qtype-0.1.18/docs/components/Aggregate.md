### Aggregate

A step that, after all messages have been processed,
returns a single message containing the counts of successful and failed
messages. Other messages are passed through unchanged.

- **type** (`Literal`): (No documentation available.)
