### AuthorizationProviderList

Schema for a standalone list of authorization providers.

- **root** (`list[APIKeyAuthProvider | BearerTokenAuthProvider | AWSAuthProvider | OAuth2AuthProvider | VertexAuthProvider]`): (No documentation available.)
