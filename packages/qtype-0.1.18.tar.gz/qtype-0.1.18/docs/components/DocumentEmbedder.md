### DocumentEmbedder

Embeds document chunks using a specified embedding model.

- **type** (`Literal`): (No documentation available.)
- **model** (`Reference[EmbeddingModel] | str`): Embedding model to use for vectorization.
