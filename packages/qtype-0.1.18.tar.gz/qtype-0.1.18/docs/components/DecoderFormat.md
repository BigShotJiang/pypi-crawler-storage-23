### DecoderFormat

Defines the format in which the decoder step processes data.

- **json**: Defines the format in which the decoder step processes data.
- **name**: The name of the Enum member.
- **value**: The value of the Enum member.
- **xml**: Defines the format in which the decoder step processes data.
