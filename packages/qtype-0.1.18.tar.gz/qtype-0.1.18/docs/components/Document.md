### Document

Schema for any valid QType document structure.
This allows validation of standalone lists of components, individual components,
or full QType application specs. Supports modular composition and reuse.

- **root** (`Application | AuthorizationProviderList | ModelList | ToolList | TypeList | VariableList`): (No documentation available.)
