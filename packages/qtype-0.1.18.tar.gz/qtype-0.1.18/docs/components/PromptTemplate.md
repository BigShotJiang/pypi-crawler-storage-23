### PromptTemplate

Defines a prompt template with a string format and variable bindings.
This is used to generate prompts dynamically based on input variables.

- **type** (`Literal`): (No documentation available.)
- **template** (`str`): String template for the prompt with variable placeholders.
