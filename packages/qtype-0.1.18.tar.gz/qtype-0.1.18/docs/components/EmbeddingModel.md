### EmbeddingModel

Describes an embedding model configuration, extending the base Model class.

- **type** (`Literal`): (No documentation available.)
- **dimensions** (`int`): Dimensionality of the embedding vectors produced by this model.
