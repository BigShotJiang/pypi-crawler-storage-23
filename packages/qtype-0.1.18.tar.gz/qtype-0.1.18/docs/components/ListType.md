### ListType

Represents a list type with a specific element type.

- **element_type** (`PrimitiveTypeEnum | str`): Type of elements in the list (primitive type or custom type reference)
