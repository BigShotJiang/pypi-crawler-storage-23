### IndexUpsert

No documentation available.

- **type** (`Literal`): (No documentation available.)
- **index** (`Reference[IndexType] | str`): Index to upsert into (object or ID reference).
