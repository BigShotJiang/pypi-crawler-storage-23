### ConstantPath

No documentation available.

- **uri** (`str`): A constant Fsspec URI.
