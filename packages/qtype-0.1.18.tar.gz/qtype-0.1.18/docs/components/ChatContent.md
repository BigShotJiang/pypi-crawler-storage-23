### ChatContent

No documentation available.

- **type** (`PrimitiveTypeEnum`): The type of content, such as 'text', 'image', etc.
- **content** (`Any`): The actual content, which can be a string, image data, etc.
- **mime_type** (`str | None`): The MIME type of the content, if known.
