### Construct

A step that converts variables into an instance of a Custom or Domain Type

- **type** (`Literal`): (No documentation available.)
- **field_bindings** (`dict[str, Reference[Variable] | str]`): Mapping from type field names to flow variable names.
