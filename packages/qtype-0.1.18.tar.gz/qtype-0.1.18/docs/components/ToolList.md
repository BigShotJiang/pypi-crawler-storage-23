### ToolList

Schema for a standalone list of tools.

- **root** (`list[Annotated]`): (No documentation available.)
