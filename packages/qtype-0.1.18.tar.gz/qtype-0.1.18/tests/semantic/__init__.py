"""Tests for the semantic layer."""
