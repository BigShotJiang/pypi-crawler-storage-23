# Changelog for the AWS Autth

## [0.7.0] - 2026-02-22

- Adopted AmazonQ

## [0.6.1] - 2024-09-04

- Fixed cache path

## [0.6.0] - 2022-06-06

- Added Cache Purge

## [0.5.0] - 2022-06-03

- Added update-stack
- Added deploy-stacks

## [0.4.0] - 2022-05-29

- Added delete-stack
- Added list-stacks

## [0.3.0] - 2022-05-29

- Added cfdeploy

## [0.2.2] - 2022-05-28

- syntax bug

## [0.2.1] - 2022-05-28

- Dont fail if bastion profile isn't set

## [0.2.0] - 2022-05-07

- Added list of accounts.
- Added direct assume role writing the config.

## [0.1.0] - 2022-05-07

- added source of account list from SSoT bucket
- added mfa with cache

## [0.0.3] - 2022-02-06

- bug fix requests not needed

## [0.0.2] - 2022-02-06

- bug fix main loading

## [0.0.1] - 2022-02-05

- Initial Commit.
