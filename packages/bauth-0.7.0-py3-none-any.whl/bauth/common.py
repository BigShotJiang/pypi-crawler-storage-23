#!/usr/bin/env python3
"""Manages CloudFormation stacks."""


import json
import logging
from typing import Any


import textwrap
from tabulate import tabulate
from termcolor import colored


LOG = logging.getLogger(__name__)


def display_table(records: list[dict[str, Any]], title: str = 'Resources') -> None:
    """Displays records in a formatted table.

    Args:
        records: List of dictionaries containing record data.
        title: Title to display above the table. Defaults to 'Resources'.
    """
    result = []
    headers = []
    for record in records:
        if not headers:
            headers = record.keys()
        row = []
        for _, value in record.items():
            # Convert to string and check length
            value = str(value)
            if len(value) > 50:
                value = textwrap.fill(value, 50)
            if value in ['CREATE_FAILED']:
                value = colored(value, 'red')
            row += [value]
        result += [row]
    LOG.debug(json.dumps(result, indent=2, default=str))
    print(title)
    print(
        tabulate(
            result,
            headers,
            tablefmt="grid"
        )
    )
