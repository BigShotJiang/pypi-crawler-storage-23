#!/usr/bin/env python3
"""Federated authentication into AWS using a bastion account paradigm."""


# python libraries
import argparse
import configparser
import getpass
import json
import logging
import os
from pathlib import Path
from typing import Any


# external libraries aka not from python
import boto3
import diskcache
from tabulate import tabulate


LOG = logging.getLogger(__name__)
CACHE = diskcache.Cache('~/.bauth')

ACCOUNT_LIST_FILE = 'accounts/AccountsByName.json'
BUCKET = 'botthouse-canonical-us-east-1'


try:
    boto3.setup_default_session(profile_name='bastion')
except Exception as e:
    LOG.debug('Could not set bastion profile: %s', e)


def set_level(verbosity: int = 0) -> None:
    """Sets the logging level based on verbosity.

    Args:
        verbosity: Integer value of 0, 1, or 2.
            0 - informational
            1 - debug logs from authaws
            2 - debug logs including boto3
    """
    level = logging.INFO
    logging.getLogger('botocore').setLevel(logging.ERROR)
    logging.getLogger('urllib3').setLevel(logging.ERROR)
    if verbosity > 1:
        # enable other loggers
        logging.getLogger('botocore').setLevel(logging.DEBUG)
        logging.getLogger('urllib3').setLevel(logging.DEBUG)
    if verbosity == 1:
        logging.getLogger('botocore').setLevel(logging.INFO)
        logging.getLogger('urllib3').setLevel(logging.INFO)
    level -= 10 * verbosity
    LOG.setLevel(level)


def _load_config(filepath: str, filename: str, profile: str) -> configparser.ConfigParser:
    """Ensures the path and file exist, and returns the contents if they do.

    Args:
        filepath: String of the file path, generally ~/.aws
        filename: The filename to review
        profile: The profile we are managing

    Returns:
        The config object with a cleared section for the profile we are adding.
    """
    # init our config object
    config = configparser.ConfigParser()

    # Validate filepath to prevent path traversal
    filepath = os.path.abspath(os.path.expanduser(filepath))

    # if the directory doesn't exist make it.
    if not os.path.exists(filepath):
        LOG.debug('Creating Directory %s', filepath)
        os.makedirs(filepath)
        return config

    # if the file doesn't exist make it.
    config_file = f'{filepath}/{filename}'
    if not os.path.exists(config_file):
        LOG.debug('Config file not found, not loaded')
        return config

    # Load Config
    config.read(config_file)

    # remove new profile section if it exists
    if config.has_section(profile):
        config.remove_section(profile)

    return config


def apply_config(token: dict[str, Any], **kwargs: Any) -> None:
    """Applies the token to the AWS profile configuration.

    Args:
        token: An STS object for the credentials of the session.
        **kwargs: The session configuration, requiring the region and profile keys.
            region: String of the region to configure.
            profile: String of the profile to configure.
    """
    apply = {
        'aws_access_key_id': token['Credentials']['AccessKeyId'],
        'aws_secret_access_key': token['Credentials']['SecretAccessKey'],
        'aws_session_token': token['Credentials']['SessionToken'],
        'region': kwargs['region'],
    }
    LOG.debug('Applying config for profile: %s, region: %s', kwargs['profile'], kwargs['region'])
    profile = kwargs['profile']

    # home_path is either the environment value of 'HOME' or 'USERPROFILE' or ''
    aws_path = f"{Path.home()}/.aws/"

    # Load Configs
    credentials = _load_config(aws_path, 'credentials', profile)
    config = _load_config(aws_path, 'config', profile)
    credentials.add_section(profile)
    config.add_section(profile)

    # list what keys go in config, all others will go in credentials
    config_keys = ['region']
    for key, value in apply.items():

        # the apply dict has both config and credentials key values.
        # the config_keys has the keys which we will store in config,
        # all other values are stored in credentials.
        if key in config_keys:
            config.set(profile, key, value)
        else:
            credentials.set(profile, key, value)

    # write config
    try:
        with open(f'{aws_path}config', 'w', encoding='utf-8') as handler:
            config.write(handler)
    except (IOError, OSError) as e:
        LOG.error('Failed to write config file: %s', e)
        raise

    # write credentials
    try:
        with open(f'{aws_path}credentials', 'w', encoding='utf-8') as handler:
            credentials.write(handler)
    except (IOError, OSError) as e:
        LOG.error('Failed to write credentials file: %s', e)
        raise


def _get_account_list() -> dict[str, Any]:
    """Fetches the account list from the canonical bucket.

    Returns:
        Dict of account list:
            {
                "Sandbox": {
                    "Id": "808140515775",
                },
                "Validator": {
                    "Id": "885220705533",
                },
            }
    """
    try:
        s3_client = boto3.client('s3')
        obj = s3_client.get_object(
            Bucket=BUCKET,
            Key=ACCOUNT_LIST_FILE
        )
        body = obj['Body'].read().decode('utf8')
        accounts = json.loads(body)
        # Normalize keys to lowercase
        return {k.lower(): {ki.lower(): vi for ki, vi in v.items()} for k, v in accounts.items()}
    except Exception as e:
        LOG.error('Failed to fetch account list from S3: %s', e)
        raise


def _parse_args(account_list: dict[str, Any]) -> argparse.Namespace:
    """Provides the argparse option set.

    Args:
        account_list: Dict of the account list:
            {
                "Sandbox": {
                    "Id": "808140515775",
                },
                "Validator": {
                    "Id": "885220705533",
                },
            }

    Returns:
        Argparse parser object.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--profile', '-p',
                        required=False,
                        default='default',
                        help='AWS profile to steward.')
    parser.add_argument('--region',
                        required=False,
                        default='us-east-1',
                        help='Region to configure.  Example: us-east-1')
    parser.add_argument('-v', '--verbose',
                        dest='verbosity',
                        action='count',
                        default=0,
                        help="Use multiple times to increase logging level")
    parser.add_argument('--rolename',
                        required=False,
                        dest='rolename',
                        default='topaz',
                        help="what role to assume")
    parser.add_argument('--list',
                        required=False,
                        dest='list',
                        default=False,
                        action='store_true',
                        help="print a list of account")
    parser.add_argument('--account', '-a',
                        required=False,
                        dest='account',
                        default='',
                        choices=account_list.keys(),
                        help="What account to assume a role in?")
    parser.add_argument('--purge',
                        required=False,
                        dest='purge',
                        action='store_true',
                        default=False,
                        help="Purge Cache?")
    return parser.parse_args()


def _main() -> None:
    """Main logic for the bauth CLI."""
    # By default lets log at info
    logging.basicConfig(level=logging.INFO)
    
    try:
        account_list = _get_account_list()
    except Exception as e:
        LOG.error('Failed to load account list: %s', e)
        return
    
    args = _parse_args(account_list)
    set_level(args.verbosity)

    if args.purge:
        CACHE.clear()

    if args.list:
        result = [['Name', 'AccountId']]
        for key in account_list.keys():
            record = account_list[key]
            new_record = [
                record['name'],
                record['id']
            ]
            result.append(new_record)
        print(tabulate(result, headers='firstrow'))

    elif args.account:
        account_id = account_list[args.account]['id']
        role = f'arn:aws:iam::{account_id}:role/{args.rolename}'

        try:
            client = boto3.client("sts")
            token = client.assume_role(
                RoleArn=role,
                RoleSessionName=getpass.getuser()
            )
            kwargs = {
                'profile': args.profile,
                'region': args.region
            }
            apply_config(token, **kwargs)
        except Exception as e:
            LOG.error('Failed to assume role %s: %s', role, e)
            return

    CACHE.close()


if __name__ == '__main__':
    _main()
