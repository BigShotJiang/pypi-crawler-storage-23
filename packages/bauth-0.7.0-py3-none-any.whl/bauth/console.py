#!/usr/bin/env python3
"""Opens AWS Console in browser using credentials from a profile."""

import argparse
import json
import logging
import urllib.parse
import webbrowser

import boto3

LOG = logging.getLogger(__name__)


def _parse_args() -> argparse.Namespace:
    """Provides the argparse option set.

    Returns:
        Argparse parser object.
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--profile', '-p',
                        required=False,
                        default='default',
                        help='AWS profile to use (default: default)')
    parser.add_argument('--region',
                        required=False,
                        default='us-east-1',
                        help='AWS region for console (default: us-east-1)')
    parser.add_argument('-v', '--verbose',
                        dest='verbosity',
                        action='count',
                        default=0,
                        help="Use multiple times to increase logging level")
    return parser.parse_args()


def get_signin_token(session_credentials: dict) -> str:
    """Gets a sign-in token from AWS federation endpoint.

    Args:
        session_credentials: Dict with AWS credentials

    Returns:
        Sign-in token string
    """
    import requests
    
    session_json = json.dumps({
        'sessionId': session_credentials['AccessKeyId'],
        'sessionKey': session_credentials['SecretAccessKey'],
        'sessionToken': session_credentials['SessionToken']
    })
    
    params = {
        'Action': 'getSigninToken',
        'Session': session_json
    }
    
    url = 'https://signin.aws.amazon.com/federation'
    response = requests.get(url, params=params)
    response.raise_for_status()
    
    return response.json()['SigninToken']


def _main() -> None:
    """Main logic for console opener."""
    args = _parse_args()
    
    log_level = logging.WARNING
    if args.verbosity == 1:
        log_level = logging.INFO
    elif args.verbosity >= 2:
        log_level = logging.DEBUG
    logging.basicConfig(level=log_level)
    
    try:
        session = boto3.Session(profile_name=args.profile)
        credentials = session.get_credentials()
        
        if not credentials:
            LOG.error('No credentials found for profile: %s', args.profile)
            return
        
        frozen_creds = credentials.get_frozen_credentials()
        
        session_creds = {
            'AccessKeyId': frozen_creds.access_key,
            'SecretAccessKey': frozen_creds.secret_key,
            'SessionToken': frozen_creds.token
        }
        
        LOG.info('Getting sign-in token...')
        signin_token = get_signin_token(session_creds)
        
        console_url = f'https://console.aws.amazon.com/console/home?region={args.region}'
        
        params = {
            'Action': 'login',
            'Issuer': '',
            'Destination': console_url,
            'SigninToken': signin_token
        }
        
        login_url = f'https://signin.aws.amazon.com/federation?{urllib.parse.urlencode(params)}'
        
        LOG.info('Opening AWS Console in browser...')
        webbrowser.open(login_url)
        print(f'AWS Console opened for profile: {args.profile}')
        
    except Exception as e:
        LOG.error('Failed to open console: %s', e)
        return


if __name__ == '__main__':
    _main()
