::: asimpy.barrier
