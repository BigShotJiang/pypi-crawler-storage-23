"""Compatibility shim for launcher path helpers.

Canonical implementation: `adscan_core.paths`.
"""

from __future__ import annotations

from adscan_core.paths import *  # noqa: F403
