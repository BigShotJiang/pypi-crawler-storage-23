"""Unit tests for core components."""
