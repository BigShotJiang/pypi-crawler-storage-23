"""Test suite for Context Window Manager."""
