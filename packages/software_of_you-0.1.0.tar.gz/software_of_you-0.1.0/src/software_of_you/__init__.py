"""Software of You — personal data platform as an MCP server."""

__version__ = "0.1.0"
