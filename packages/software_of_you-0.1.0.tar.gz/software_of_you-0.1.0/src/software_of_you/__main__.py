"""Entry point for `python3 -m software_of_you`."""

import sys

from software_of_you.cli import main

if __name__ == "__main__":
    sys.exit(main())
