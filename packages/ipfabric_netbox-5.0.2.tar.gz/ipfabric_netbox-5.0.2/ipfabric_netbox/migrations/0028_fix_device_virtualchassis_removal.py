from django.db import migrations

from ipfabric_netbox.utilities.transform_map import do_change
from ipfabric_netbox.utilities.transform_map import RelationshipRecord
from ipfabric_netbox.utilities.transform_map import TransformMapRecord


TRANSFORM_MAP_CHANGES = (
    TransformMapRecord(
        source_endpoint="/inventory/devices",
        target_model="dcim.device",
        relationships=(
            RelationshipRecord(
                source_model="dcim.virtualchassis",
                target_field="virtual_chassis",
                old_template="{% if object.virtual_chassis %}{% if object.virtual_chassis.master is defined and object.virtual_chassis.master %}{{ dcim.VirtualChassis.objects.filter(name=object.virtual_chassis.master).first().pk }}{% else %}{{ dcim.VirtualChassis.objects.filter(name=object.virtual_chassis.hostname).first().pk }}{% endif %}{% endif %}",
                new_template="{% if object.virtual_chassis %}{% if object.virtual_chassis.master is defined and object.virtual_chassis.master %}{{ dcim.VirtualChassis.objects.filter(name=object.virtual_chassis.master).first().pk }}{% else %}{{ dcim.VirtualChassis.objects.filter(name=object.virtual_chassis.hostname).first().pk }}{% endif %}{% else %}None{% endif %}",
            ),
        ),
    ),
)


def forward_transform_maps_change(apps, schema_editor):
    """Replace old template with updated version."""
    do_change(apps, schema_editor, changes=TRANSFORM_MAP_CHANGES, forward=True)


def revert_transform_maps_change(apps, schema_editor):
    """Revert template back to the previous exact template."""
    do_change(apps, schema_editor, changes=TRANSFORM_MAP_CHANGES, forward=False)


class Migration(migrations.Migration):
    dependencies = [
        ("ipfabric_netbox", "0027_fix_virtualchassis_master_template"),
    ]

    operations = [
        migrations.RunPython(
            forward_transform_maps_change,
            revert_transform_maps_change,
        ),
    ]
