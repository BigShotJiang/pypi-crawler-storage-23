"""nwave-ai: CLI installer for the nWave methodology framework."""

__version__ = "1.3.0"
