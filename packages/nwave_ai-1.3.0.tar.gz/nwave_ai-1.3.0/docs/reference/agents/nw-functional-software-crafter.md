# nw-functional-software-crafter

DELIVER wave - Outside-In TDD with functional paradigm. Pure functions, pipeline composition, types as documentation, property-based testing. Use when the project follows a functional-first approach (F#, Haskell, Scala, Clojure, Elixir, or FP-heavy TypeScript/Python/Kotlin).

**Wave:** DELIVER
**Model:** inherit
**Max turns:** 50
**Tools:** Read, Write, Edit, Bash, Glob, Grep, Task

## Commands

- [`/nw:deliver`](../commands/index.md)
- [`/nw:design`](../commands/index.md)

## Skills

- [collaboration-and-handoffs](../../../nWave/skills/software-crafter/collaboration-and-handoffs.md) — Cross-agent collaboration protocols, workflow handoff patterns, and commit message formats for TDD/Mikado/refactoring workflows
- [fp-algebra-driven-design](../../../nWave/skills/functional-software-crafter/fp-algebra-driven-design.md) — Algebra-driven API design with monoids, semigroups, and interpreters via algebraic equations
- [fp-clojure](../../../nWave/skills/functional-software-crafter/fp-clojure.md) — Clojure language-specific patterns, data-first modeling, REPL-driven development, and spec
- [fp-domain-modeling](../../../nWave/skills/functional-software-crafter/fp-domain-modeling.md) — Domain modeling with algebraic data types, smart constructors, and type-level error handling
- [fp-fsharp](../../../nWave/skills/functional-software-crafter/fp-fsharp.md) — F# language-specific patterns, Railway-Oriented Programming, and Computation Expressions
- [fp-haskell](../../../nWave/skills/functional-software-crafter/fp-haskell.md) — Haskell language-specific patterns, GADTs, type classes, and effect systems
- [fp-hexagonal-architecture](../../../nWave/skills/functional-software-crafter/fp-hexagonal-architecture.md) — Hexagonal architecture patterns with pure core and side-effect shell for functional codebases
- [fp-kotlin](../../../nWave/skills/functional-software-crafter/fp-kotlin.md) — Kotlin language-specific patterns with Arrow, Raise DSL, and coroutine-based effects
- [fp-principles](../../../nWave/skills/functional-software-crafter/fp-principles.md) — Core functional programming thinking patterns and type system foundations, language-agnostic
- [fp-scala](../../../nWave/skills/functional-software-crafter/fp-scala.md) — Scala 3 language-specific patterns with ZIO, Cats Effect, and opaque types
- [fp-usable-design](../../../nWave/skills/functional-software-crafter/fp-usable-design.md) — Naming conventions, API ergonomics, and usability patterns for functional code
- [hexagonal-testing](../../../nWave/skills/software-crafter/hexagonal-testing.md) — 5-layer agent output validation, I/O contract specification, vertical slice development, and test doubles policy with per-layer examples
- [pbt-dotnet](../../../nWave/skills/functional-software-crafter/pbt-dotnet.md) — .NET property-based testing with FsCheck, CsCheck, and fsharp-hedgehog frameworks
- [pbt-erlang-elixir](../../../nWave/skills/functional-software-crafter/pbt-erlang-elixir.md) — Erlang/Elixir property-based testing with PropEr, PropCheck, and StreamData frameworks
- [pbt-fundamentals](../../../nWave/skills/functional-software-crafter/pbt-fundamentals.md) — Property-based testing core concepts, property taxonomy, and strategy selection (language-agnostic)
- [pbt-go](../../../nWave/skills/functional-software-crafter/pbt-go.md) — Go property-based testing with rapid and gopter frameworks
- [pbt-haskell](../../../nWave/skills/functional-software-crafter/pbt-haskell.md) — Haskell property-based testing with QuickCheck and Hedgehog frameworks
- [pbt-jvm](../../../nWave/skills/functional-software-crafter/pbt-jvm.md) — JVM property-based testing with jqwik, ScalaCheck, and ZIO Test frameworks
- [pbt-python](../../../nWave/skills/functional-software-crafter/pbt-python.md) — Python property-based testing with Hypothesis framework, strategies, and pytest integration
- [pbt-rust](../../../nWave/skills/functional-software-crafter/pbt-rust.md) — Rust property-based testing with proptest, quickcheck, and bolero frameworks
- [pbt-stateful](../../../nWave/skills/functional-software-crafter/pbt-stateful.md) — Stateful property-based testing patterns, model-based testing, and anti-patterns
- [pbt-typescript](../../../nWave/skills/functional-software-crafter/pbt-typescript.md) — TypeScript/JavaScript property-based testing with fast-check framework and arbitraries
- [progressive-refactoring](../../../nWave/skills/software-crafter/progressive-refactoring.md) — Progressive L1-L6 refactoring hierarchy, 22 code smell taxonomy, atomic transformations, test code smells, and Fowler refactoring catalog
- [property-based-testing](../../../nWave/skills/software-crafter/property-based-testing.md) — Property-based testing strategies, mutation testing, shrinking, and combined PBT+mutation workflow for test quality validation
- [quality-framework](../../../nWave/skills/software-crafter/quality-framework.md) — Quality gates - 11 commit readiness gates, build/test protocol, validation checkpoints, and quality metrics
- [review-dimensions](../../../nWave/skills/product-owner/review-dimensions.md) — Requirements quality critique dimensions for peer review - confirmation bias detection, completeness validation, clarity checks, testability assessment, and priority validation
- [review-dimensions](../../../nWave/skills/software-crafter/review-dimensions.md) — Reviewer critique dimensions for peer review - implementation bias detection, test quality validation, completeness checks, and priority validation
- [tdd-methodology](../../../nWave/skills/software-crafter/tdd-methodology.md) — Deep knowledge for Outside-In TDD - double-loop architecture, ATDD integration, port-to-port testing, walking skeletons, and test doubles policy
- [test-refactoring-catalog](../../../nWave/skills/software-crafter/test-refactoring-catalog.md) — Detailed refactoring mechanics with step-by-step procedures, and test code smell catalog with detection patterns and before/after examples
- [tlaplus-verification](../../../nWave/skills/functional-software-crafter/tlaplus-verification.md) — TLA+ formal verification for design correctness and PBT pipeline integration
