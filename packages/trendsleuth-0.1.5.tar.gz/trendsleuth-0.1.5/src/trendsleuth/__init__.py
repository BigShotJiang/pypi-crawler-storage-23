"""TrendSleuth - Reddit trend analysis for content creators."""

__version__ = "0.1.0"
