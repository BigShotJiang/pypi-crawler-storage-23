"""./do script is used to run lint, test and various scripts."""
import argparse
import sys
import os
import cProfile
from coverage import Coverage
import argcomplete

import booktest as bt
from booktest.migration.migrate import check_and_migrate

TEST_ROOT_DIR = "books"


MIN_COVERAGE_PERCENT = 25

# Detect tests first
tests = bt.detect_test_suite("test")
bt_setup = bt.detect_setup("test")

# Check and perform automatic migration with test discovery
check_and_migrate(tests=tests)


def coverage(parsed) -> int:

    args = parsed.args

    if len(args) == 0:
        args = ["test", "-p"]

    # remove old main coverage and process coverage files
    if os.path.exists(".coverage"):
        os.remove(".coverage")
    for i in os.listdir("."):
        if i.startswith(".coverage."):
            os.remove(i)

    cov = Coverage()
    cov.start()

    do_args(args)

    cov.stop()
    cov.save()
    cov.combine()

    percent = cov.report()

    cov.xml_report(outfile="coverage.xml")

    print()
    print(f"coverage: {percent:.1f}% / {MIN_COVERAGE_PERCENT}%")
    print()

    if percent >= MIN_COVERAGE_PERCENT:
        return 0
    else:
        return -1


def lint():
    rv = os.system('pycodestyle do.py `find booktest test -name "*.py" `')
    if rv == 0:
        return 0
    else:
        return -1


def test(args, cache={}):
    return tests.exec(TEST_ROOT_DIR, args, cache)


def qa() -> int:
    print("# running lint...")
    if lint() == 0:
        print("ok")
        return test(["-f"])
    else:
        return -1


def autocomplete_script() -> int:
    print('eval "$(register-python-argcomplete do)"')
    return 0


def deploy() -> int:
    return os.system("python setup.py sdist upload -r local")


def sdist() -> int:
    return os.system("python setup.py sdist")


def install() -> int:
    return os.system("python setup.py install")


def uninstall() -> int:
    return os.system("pip uninstall booktest")


def clean() -> int:
    return os.system("rm -r build dist booktest.egg-info")


def docs() -> int:
    """Generate API documentation using lazydocs.

    Runs from /tmp to avoid module shadowing issue with booktest/booktest.py.
    """
    import subprocess
    result = subprocess.run(
        ["lazydocs", "--output-path",
         os.path.abspath("docs/api"),
         "--overview-file", "README.md",
         "booktest"],
        cwd="/tmp"
    )
    if result.returncode == 0:
        print("\nAPI docs generated in docs/api/")
    return result.returncode


def version(parsed) -> int:
    """Read or update the project version in pyproject.toml."""
    import re
    pyproject_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "pyproject.toml"
    )
    with open(pyproject_path, "r") as f:
        content = f.read()

    if parsed.new_version:
        new_content = re.sub(
            r'^version\s*=\s*"[^"]*"',
            f'version = "{parsed.new_version}"',
            content,
            count=1,
            flags=re.MULTILINE
        )
        with open(pyproject_path, "w") as f:
            f.write(new_content)
        print(parsed.new_version)
    else:
        match = re.search(
            r'^version\s*=\s*"([^"]*)"',
            content,
            re.MULTILINE
        )
        if match:
            print(match.group(1))
        else:
            print("error: version not found in pyproject.toml",
                  file=sys.stderr)
            return 1
    return 0


def do(cmd, cache=None):
    if cache is None:
        cache = {}
    do_args(cmd.split(" "), cache)


def setup_subparser(subparsers):
    profile_parser = \
        subparsers.add_parser('profile',
                              help='runs the remaining command in profiler')
    profile_parser.add_argument("args", nargs='*')
    profile_parser.set_defaults(
        exec=lambda parsed:
            cProfile.run(f"do_args({parsed.args})")
    )

    qa_parser = subparsers.add_parser('qa',
                                      help='runs linter and test')
    qa_parser.set_defaults(
        exec=lambda parsed: qa())

    subparsers\
        .add_parser(
            'autocomplete-script',
            help='enables autocomplete with ' +
                 '\'eval "$(./do autocomplete-script)\'') \
        .set_defaults(
            exec=lambda parsed: autocomplete_script())

    coverage_parser = \
        subparsers.add_parser('coverage',
                              help='runs the remaining command in coverage.py')
    coverage_parser.add_argument("args", nargs='*')
    coverage_parser.set_defaults(exec=coverage)

    subparsers\
        .add_parser('lint',
                    help='runs linter') \
        .set_defaults(
            exec=lambda parsed: lint())

    subparsers\
        .add_parser('docs',
                    help='generates API documentation with lazydocs') \
        .set_defaults(
            exec=lambda parsed: docs())

    version_parser = \
        subparsers.add_parser('version',
                              help='read or set project version')
    version_parser.add_argument("new_version", nargs='?', default=None)
    version_parser.set_defaults(exec=version)


def do_args(args, cache={}) -> int:
    parser = argparse.ArgumentParser()

    subparsers = parser.add_subparsers(help='sub-command help')

    setup_subparser(subparsers)

    tests_parser = subparsers.add_parser("test")
    tests.setup_parser(tests_parser)
    tests_parser.set_defaults(
        exec=lambda parsed:
            tests.exec_parsed(TEST_ROOT_DIR,
                              parsed,
                              cache,
                              setup=bt_setup))

    argcomplete.autocomplete(parser)
    parsed = parser.parse_args(args)

    return parsed.exec(parsed)


if __name__ == "__main__":
    ev = do_args(sys.argv[1:], {})
    if ev != 0:
        exit(ev)
