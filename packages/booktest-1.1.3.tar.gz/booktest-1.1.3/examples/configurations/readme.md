# configurations

This is an example project, which demonstrates use of complex configurations.