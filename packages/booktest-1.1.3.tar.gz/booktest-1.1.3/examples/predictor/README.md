# predictor

This is an example project, which demonstrates 'testing' of a simple predictor tool
