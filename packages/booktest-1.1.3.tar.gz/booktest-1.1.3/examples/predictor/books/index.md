# Books overview:

 * book
     * predictor_book.py::PredictorBook
         * [test_predictor](book/predictor_book.py::PredictorBook/test_predictor.md)
         * [test_predict_dog](book/predictor_book.py::PredictorBook/test_predict_dog.md)

