dog is a mammal with probability 0.5,
because most mammals have 4 legs
