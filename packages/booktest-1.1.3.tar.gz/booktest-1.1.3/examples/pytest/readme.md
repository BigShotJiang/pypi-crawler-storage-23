# pytest

This is an example project, which a simple pytest integration. 

In some frameworks (like pants), it's difficult to run 3rd party tests without a specialized plugin. 
The demonstrated light integration makes it possible to run booktest regression testing via pytest. 
