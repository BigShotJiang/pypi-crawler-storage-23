# predictor

This is an example project mainly used to test the failures. 

These tests will fail!