# succeeding test for control:

ok.
