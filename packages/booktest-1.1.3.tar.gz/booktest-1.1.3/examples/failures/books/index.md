# Books overview:

 * book
     * [failing_book.py::test_assert](book/failing_book.py::test_assert.md)
     * [failing_book.py::test_decorated_async_exception](book/failing_book.py::test_decorated_async_exception.md)
     * [failing_book.py::test_decorated_exception](book/failing_book.py::test_decorated_exception.md)
     * [failing_book.py::test_exception](book/failing_book.py::test_exception.md)
     * [failing_book.py::test_fail](book/failing_book.py::test_fail.md)
     * [failing_book.py::test_memory_monitor_exception](book/failing_book.py::test_memory_monitor_exception.md)
     * [failing_book.py::test_success](book/failing_book.py::test_success.md)

