# predictor

This is an example project mainly used to test the timeout

With 1 second timeout the slow test should fail, while fast test succeeds.
