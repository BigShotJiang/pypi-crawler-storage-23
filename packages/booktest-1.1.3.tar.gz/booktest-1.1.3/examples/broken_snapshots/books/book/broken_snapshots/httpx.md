# response:

{
    "status": "OK"
}

# httpx snaphots:

 * https://api.weather.gov/ - 7185541346b850c27b0a566841b088e6e39b146b
