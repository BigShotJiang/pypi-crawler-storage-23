# response:

{
    "status": "OK"
}

# request snaphots:

 * https://api.weather.gov/ - 2e943733fabbffde11ad3f21b9f6d30ae70e4132
