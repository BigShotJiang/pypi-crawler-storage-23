# snapshot:

 * hello: hello world

# function call snapshots:

 * hello_world - d9a4e61c15c0ab5dae7f8f2df37dc2c5961ffb62:
   * 10b1d5dde04cb7165fda604e9c02a88365ede15c
