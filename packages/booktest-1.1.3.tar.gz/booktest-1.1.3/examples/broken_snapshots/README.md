# broken snapshots

Snapshots sometimes break (e.g. because git merges). 

This test verifies the test suite behavior under such circumstances. 
