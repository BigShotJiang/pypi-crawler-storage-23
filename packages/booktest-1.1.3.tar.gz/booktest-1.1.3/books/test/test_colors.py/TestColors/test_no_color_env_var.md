# NO_COLOR Environment Variable Test

Without NO_COLOR: is_color_enabled = True
With NO_COLOR: is_color_enabled = False

✓ NO_COLOR environment variable respected!
