processed data value is -1

## processed data value..

 * MUST equal -1...ok
