# description:

this test verifies that the dependencies will
use correct test instance result value, in case
there are multiple instances of the same test class

# data value:

1
