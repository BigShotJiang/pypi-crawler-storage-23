data value is 1

## data value..

 * MUST equal 1...ok

## processed data value..

 * MUST equal -1...ok
