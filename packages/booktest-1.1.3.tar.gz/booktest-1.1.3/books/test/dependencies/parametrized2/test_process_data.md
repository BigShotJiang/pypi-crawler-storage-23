data value is 2

## data value..

 * MUST equal 2...ok

## processed data value..

 * MUST equal -2...ok
