processed data value is -2

## processed data value..

 * MUST equal -2...ok
