# URLOpsTestBook:

default name: test/test_names/urlops

test book path: test/test_names_test.py::url_ops

