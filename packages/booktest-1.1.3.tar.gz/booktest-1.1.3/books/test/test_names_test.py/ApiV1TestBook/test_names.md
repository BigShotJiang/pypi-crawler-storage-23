# ApiV1TestBook:

default name: test/test_names/api_v1

test book path: test/test_names_test.py::ApiV1TestBook

