# GetURLTestBook:

default name: test/test_names/get_url

test book path: test/test_names_test.py::GetURLTestBook

