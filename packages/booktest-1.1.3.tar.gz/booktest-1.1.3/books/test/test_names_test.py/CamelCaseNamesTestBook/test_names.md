# CamelCaseNamesTestBook:

default name: test/test_names/camel_case_names

test book path: test/test_names_test.py::CamelCaseNamesTestBook

