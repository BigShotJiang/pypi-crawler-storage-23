# tokenize 'cat walks by'

|cat| |walks| |by|

# tokenize 'there is 34 bottles of beer on the wall'

|there| |is| |34| |bottles| |of| |beer| |on| |the| |wall|

# tokenize 'whitespace    and  more    and more'

|whitespace|    |and|  |more|    |and| |more|

# tokenize 'special .+. characters ?¤- get tokenized +&% one-by-one'

|special| |.|+|.| |characters| |?|¤|-| |get| |tokenized| |+|&|%| |one|-|by|-|one|

# tokenize '3435 23.32 23. +2 +'

|3435| |23.32| |23|.| |+2| |+|
