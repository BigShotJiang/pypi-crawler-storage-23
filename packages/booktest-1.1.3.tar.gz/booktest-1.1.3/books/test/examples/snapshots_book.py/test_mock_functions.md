# mocks:

 * timestamp: 10000000000000
 * random: 42
 * async random: 23
