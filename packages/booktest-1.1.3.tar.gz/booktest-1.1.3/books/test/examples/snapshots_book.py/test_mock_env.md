# test environment variable:

 * TEST_ENV_VARIABLE: hello2
