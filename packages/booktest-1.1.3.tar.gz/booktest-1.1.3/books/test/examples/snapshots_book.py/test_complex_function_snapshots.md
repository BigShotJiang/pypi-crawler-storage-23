# running 20 snapshots in random order to 2 different methods:

done.

randomized order is 16, 10, 19, 3, 15, 12, 9, 1, 18, 6, 13, 7, 11, 0, 14, 5, 4, 2, 8, 17

# results:

 * 0: 1
 * 1: 0
 * 2: 3
 * 3: 2
 * 4: 5
 * 5: 4
 * 6: 7
 * 7: 6
 * 8: 9
 * 9: 8
 * 10: 11
 * 11: 10
 * 12: 13
 * 13: 12
 * 14: 15
 * 15: 14
 * 16: 17
 * 17: 16
 * 18: 19
 * 19: 18

check sum: 190
