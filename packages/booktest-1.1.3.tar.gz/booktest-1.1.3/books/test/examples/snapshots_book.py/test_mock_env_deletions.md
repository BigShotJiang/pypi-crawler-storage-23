# deleted variables:

 * SHELL: None
 * HOME: None
 * LANG: None
 * USERNAME: None
