# async t.snapshot() usage


## first fetch:

{
  "data": 1179,
  "timestamp": 1770743799205681676,
  "url": "https://api.example.com"
}
cached result matches: True

## fetch /users:

{
  "data": 7061,
  "timestamp": 1770743799216649777,
  "url": "https://api.example.com/users"
}
