# description:

in this test, the headers are stored within the expectation files.

# response:

{
    "message": "hello"
}
