# t.snapshot() with kwargs


## GET /users:

{
  "endpoint": "/users",
  "method": "GET",
  "random": 5113,
  "timeout": 30
}
cached result matches: True

## POST /users:

{
  "endpoint": "/users",
  "method": "POST",
  "random": 5437,
  "timeout": 30
}
