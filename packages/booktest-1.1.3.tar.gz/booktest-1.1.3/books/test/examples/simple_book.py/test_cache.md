returns 'foo'
