# async test:

 * waiting on async io..0.101 s (was 0.100 s)
 * done
