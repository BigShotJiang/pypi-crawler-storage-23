# response:

{
    "args": {},
    "headers": {
        "host": "postman-echo.com",
        "accept-encoding": "gzip, br",
        "accept": "*/*",
        "x-forwarded-proto": "https",
        "user-agent": "python-requests/2.32.3"
    },
    "url": "https://postman-echo.com/get"
}
