# response:

{
    "args": {},
    "headers": {
        "host": "postman-echo.com",
        "accept-encoding": "gzip, br",
        "user-agent": "python-httpx/0.27.2",
        "x-forwarded-proto": "https",
        "accept": "*/*"
    },
    "url": "https://postman-echo.com/get"
}
