# async test:

 * calculating things..0.100 s (was 0.100 s)
 * result is 42
