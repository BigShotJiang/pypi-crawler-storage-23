 * value is 42 
