 * creating server socket..0.033 ms (was 0.016 ms)
 * binding the socket in port 10000..0.227 ms (was 0.043 ms)
 * start listening to the connection..0.009 ms (was 0.005 ms)
 * server socket opened at port 10000
 * sleeping for 100 milliseconds..100.084 ms (was 100.061 ms)
 * server socket closed at port 10000.
