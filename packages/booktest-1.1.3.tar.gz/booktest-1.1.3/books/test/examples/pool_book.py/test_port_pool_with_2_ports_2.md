 * creating server socket..0.040 ms (was 0.021 ms)
 * creating server socket 2..0.026 ms (was 0.009 ms)
 * binding the socket in port 10000..0.099 ms (was 0.051 ms)
 * binding the socket 2 in port 10001..0.073 ms (was 0.026 ms)
 * start listening to the connection..0.011 ms (was 0.006 ms)
 * server socket opened at port 10000
 * start listening to the connection..0.007 ms (was 0.004 ms)
 * server socket 2 opened at port 10001
 * sleeping for 100 milliseconds..100.083 ms (was 100.077 ms)
 * server socket closed at port 10000.
 * server socket 2 closed at port 10001.
