 * creating server socket..0.039 ms (was 0.036 ms)
 * binding the socket in port 10000..0.067 ms (was 0.081 ms)
 * start listening to the connection..0.007 ms (was 0.009 ms)
 * server socket opened at port 10000
 * sleeping for 100 milliseconds..100.088 ms (was 100.082 ms)
 * server socket closed at port 10000.
