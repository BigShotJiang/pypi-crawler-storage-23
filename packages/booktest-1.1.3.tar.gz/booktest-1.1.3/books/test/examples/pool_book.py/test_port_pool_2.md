 * creating server socket..0.031 ms (was 0.020 ms)
 * binding the socket in port 10000..0.061 ms (was 0.048 ms)
 * start listening to the connection..0.007 ms (was 0.006 ms)
 * server socket opened at port 10000
 * sleeping for 100 milliseconds..100.089 ms (was 100.078 ms)
 * server socket closed at port 10000.
