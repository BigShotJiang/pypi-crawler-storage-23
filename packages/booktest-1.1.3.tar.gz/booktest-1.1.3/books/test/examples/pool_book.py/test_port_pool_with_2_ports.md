 * creating server socket..0.036 ms (was 0.014 ms)
 * creating server socket 2..0.022 ms (was 0.007 ms)
 * binding the socket in port 10000..0.073 ms (was 0.044 ms)
 * binding the socket 2 in port 10001..0.047 ms (was 0.023 ms)
 * start listening to the connection..0.010 ms (was 0.005 ms)
 * server socket opened at port 10000
 * start listening to the connection..0.009 ms (was 0.003 ms)
 * server socket 2 opened at port 10001
 * sleeping for 100 milliseconds..100.082 ms (was 100.080 ms)
 * server socket closed at port 10000.
 * server socket 2 closed at port 10001.
