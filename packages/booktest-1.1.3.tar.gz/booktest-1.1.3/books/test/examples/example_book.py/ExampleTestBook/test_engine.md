dog is a mammal with probability 0.5,
because most mammals have 4 legs

bat is a mammal with probability 0.1,
because bats exist

spider is a mammal with probability 0.0,
because if it has lots of legs, it's likely something else

