# This test demonstrates tmp file


## Writing following message

this is message

## Message read from file:

this is message

## Verify results:

file name: books/.out/test/examples/example_book.py/ExampleTestBook/test_tmp_file.tmp/message.txt

file byte size: 15

is message same? ok
