the cached text is 'text'
