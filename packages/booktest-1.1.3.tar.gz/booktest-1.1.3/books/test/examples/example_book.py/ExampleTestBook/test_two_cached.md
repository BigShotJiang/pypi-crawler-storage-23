the cached texts are 'text' and 'more text'
