sleeping 1 second.. 1000.083 ms (was 1000.091 ms)

sleeping 1 second.. 1000.088 ms (was 1000.079 ms)
