# this is a header:

 * list item
 * *bolded* item

# here's random garbage:

this is not tested
this is not tested

anchors help test compare right line
