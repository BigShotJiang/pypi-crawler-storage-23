# This test demonstrates tables

|x|y     |
|-|------|
|1|foo   |
|2|bar   |
|3|foobar|
