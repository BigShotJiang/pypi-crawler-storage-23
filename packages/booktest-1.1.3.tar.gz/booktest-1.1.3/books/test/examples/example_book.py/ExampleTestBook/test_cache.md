this creates a cache with text 'text'
