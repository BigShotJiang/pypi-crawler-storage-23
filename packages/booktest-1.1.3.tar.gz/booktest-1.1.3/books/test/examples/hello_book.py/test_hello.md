# This test prints hello world

hello world
