# Info Image Test


## Summary:

 * accuracy: 0.880 (was 0.900)

### Accuracy over epochs:

![Accuracy over epochs](test_iimage_method/1480cb506ba82537e06cc694cd30c74f87edfd21)
