# Mixed Output Test

 * Training started with 1000 samples
 * Final accuracy: 0.95

## Training history:

|epoch|loss               |
|-----|-------------------|
|1    |0.4989             |
|2    |0.3                |
|3    |0.20450000000000002|
