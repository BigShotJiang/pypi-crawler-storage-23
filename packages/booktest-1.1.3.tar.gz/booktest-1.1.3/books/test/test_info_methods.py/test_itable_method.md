# Info Table Test

Dataset sizes:
|dataset|samples|
|-------|-------|
|train  |1000   |
|val    |200    |
|test   |300    |
Test completed
