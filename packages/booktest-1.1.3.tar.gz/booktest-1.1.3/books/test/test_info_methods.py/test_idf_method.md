# Info DataFrame Test


## Model performance metrics:

|metric   |value|
|---------|-----|
|accuracy |0.86 |
|precision|0.93 |
|recall   |1.0  |
