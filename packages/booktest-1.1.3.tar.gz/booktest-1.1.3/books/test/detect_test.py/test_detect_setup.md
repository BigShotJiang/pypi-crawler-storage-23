# detecting setup:


## fs setup:

 * asset fs setup was found..ok
 * asset fs setup method was found..ok

## module setup:

 * asset module setup was found..ok
 * asset module setup method was found..ok
