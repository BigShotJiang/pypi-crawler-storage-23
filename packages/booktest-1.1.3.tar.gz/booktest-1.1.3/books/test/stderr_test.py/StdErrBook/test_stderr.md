using logging on background.

# err file content:

 * this is a warning

