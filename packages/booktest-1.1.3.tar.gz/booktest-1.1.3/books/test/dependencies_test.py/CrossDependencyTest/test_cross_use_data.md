## data value..

 * MUST equal big data...ok
