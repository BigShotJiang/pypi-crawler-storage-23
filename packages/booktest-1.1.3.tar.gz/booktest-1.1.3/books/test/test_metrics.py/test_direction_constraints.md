# Test: Direction Constraints


## Directional Metric Tracking

Accuracy: should not drop (direction='>=')
Error rate: should not increase (direction='<=')
Latency: should not increase (direction='<=')

Accuracy: 0.973 was 0.973, Δ+0.000)

Error Rate: 0.027 was 0.027, Δ+0.000)

Latency: 42.500ms (baseline)
