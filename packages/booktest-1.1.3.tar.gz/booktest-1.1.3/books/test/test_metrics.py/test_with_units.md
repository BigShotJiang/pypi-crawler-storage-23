# Test: Metrics with Units


## Performance Metrics

Accuracy: 97.300% (was 97.300%, Δ+0.000%)
Latency: 42.500ms (was 42.500ms, Δ+0.000ms)
Throughput: 1250.800req/s (was 1250.800req/s, Δ+0.000req/s)
