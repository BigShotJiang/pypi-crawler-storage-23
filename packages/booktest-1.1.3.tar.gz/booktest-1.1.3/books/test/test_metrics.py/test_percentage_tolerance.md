# Test: Percentage-Based Tolerance


## Relative Tolerance Tracking

Using 5% relative tolerance (±5% of baseline)

Response Time: 125.000ms (was 125.000ms, Δ+0.000ms [+0.0%])
Memory Usage: 512.000MB (was 512.000MB, Δ+0.000MB [+0.0%])
