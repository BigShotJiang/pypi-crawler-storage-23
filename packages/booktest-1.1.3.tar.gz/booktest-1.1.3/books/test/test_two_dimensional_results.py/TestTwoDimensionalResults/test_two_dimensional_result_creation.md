# Two-Dimensional Test Result


## Result Combinations

OK/INTACT
  Legacy: TestResult.OK
  Requires Review: False
  Is Success: True
  Can Auto Approve: True

OK/UPDATED
  Legacy: TestResult.OK
  Requires Review: False
  Is Success: True
  Can Auto Approve: True

DIFF/INTACT
  Legacy: TestResult.DIFF
  Requires Review: True
  Is Success: False
  Can Auto Approve: False

FAIL/FAIL
  Legacy: TestResult.FAIL
  Requires Review: False
  Is Success: False
  Can Auto Approve: False

