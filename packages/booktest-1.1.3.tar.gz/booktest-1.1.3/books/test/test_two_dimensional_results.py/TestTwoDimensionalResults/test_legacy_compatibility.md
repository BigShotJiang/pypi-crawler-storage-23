# Legacy Compatibility


## Legacy Results

TestResult.OK: exit code 0
TestResult.DIFF: exit code -1
TestResult.FAIL: exit code -1

## Two-Dimensional Results with Legacy Function

OK/INTACT: exit code 0
DIFF/UPDATED: exit code -1
FAIL/FAIL: exit code -1
