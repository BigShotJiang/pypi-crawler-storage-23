# Review Decision Logic


## Decision Matrix

OK/INTACT → Auto-approve
OK/UPDATED → Auto-approve
OK/FAIL → Warning only
DIFF/INTACT → Human review required
DIFF/UPDATED → Human review required
DIFF/FAIL → Human review required
FAIL/INTACT → Fix test logic first
FAIL/UPDATED → Fix test logic first
FAIL/FAIL → Fix test logic first
