# Class Selection

Testing class selection:
 ✓ test/foo_test.py::FooBook/test_bar with selection ['test/foo_test.py::FooBook']: True
 ✓ test/foo_test.py::FooBook/test_baz with selection ['test/foo_test.py::FooBook']: True
 ✓ test/foo_test.py::test_standalone with selection ['test/foo_test.py::FooBook']: False
 ✓ test/foo_test.py::BarBook/test_other with selection ['test/foo_test.py::FooBook']: False

✓ All class selection tests passed!
