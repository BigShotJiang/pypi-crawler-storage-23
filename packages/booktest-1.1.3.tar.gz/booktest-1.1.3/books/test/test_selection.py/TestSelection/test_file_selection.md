# File Path Selection

Testing file path selection:
 ✓ test/foo_test.py::test_bar with selection ['test/foo_test.py']: True
 ✓ test/foo_test.py::FooBook/test_bar with selection ['test/foo_test.py']: True
 ✓ test/foo_test.py::FooBook/test_baz with selection ['test/foo_test.py']: True
 ✓ test/other_test.py::test_other with selection ['test/foo_test.py']: False

✓ All file selection tests passed!
