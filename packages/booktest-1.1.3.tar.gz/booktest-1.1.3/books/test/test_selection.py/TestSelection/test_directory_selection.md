# Directory Selection

Testing directory selection:
 ✓ test/examples/foo_test.py::test_bar with selection ['test/examples']: True
 ✓ test/examples/subdir/bar_test.py::test_baz with selection ['test/examples']: True
 ✓ test/other/foo_test.py::test_bar with selection ['test/examples']: False

✓ All directory selection tests passed!
