# BOOKTEST_LLM Selection

 * BOOKTEST_LLM=ollama: OllamaLlm
 * Ollama selected: ok
