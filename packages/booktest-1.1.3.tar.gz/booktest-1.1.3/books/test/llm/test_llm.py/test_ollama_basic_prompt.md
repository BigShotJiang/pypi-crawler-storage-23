# Configuration

 * model: gpt-oss:20b
 * context_size: 32768

# Response

 * response: 4

# Validation

 * contains '4': ok
