# Configuration

 * model: gpt-oss:20b

# Parsed Result

 * answer: Paris
 * country: France

# Validation

 * answer contains 'paris': ok
