# OLLAMA_CONTEXT_SIZE Configuration


## Default value

 * context_size: 32768
 * is 32768: ok

## Custom value (65536)

 * context_size: 65536
 * is 65536: ok
