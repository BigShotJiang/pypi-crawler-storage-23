# ALLCAPSTestBook:

default name: test/test_names/allcaps

test book path: test/utils/all_caps

