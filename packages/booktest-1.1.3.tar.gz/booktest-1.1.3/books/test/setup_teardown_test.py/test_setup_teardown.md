# description:

global operations are needed to things like faking system times
or initializing resources. 

booktest allows user to define process_setup_teardown in __booktest__.py
to set up and teardown global settings

# test:

the global variable should always be 'set'

global variable is 'set'..ok
