# description:

resources snapshots files makes booktest look for files via python resource system

# command:

booktest --resource-snapshots

# configuration:

 * context: examples/pytest

# output:


# test results:

  book/test_hello.py::test_hello - <number> ms
  book/test_snapshot.py::test_auto_function_snapshots - <number> ms
  book/teardown/setup_teardown_test.py::test_setup_teardown - <number> ms

3/3 test succeeded in <number> ms


