# command:

booktest -l

# configuration:

 * context: examples/predictor

# output:

  book/predictor_book.py::PredictorBook/test_predictor - ok <number> ms
  book/predictor_book.py::PredictorBook/test_predict_dog - ok <number> ms

