# command:

booktest --context examples/predictor

# configuration:

 * context: .

# output:


# test results:

  book/predictor_book.py::PredictorBook/test_predictor - <number> ms
  book/predictor_book.py::PredictorBook/test_predict_dog - <number> ms

2/2 test succeeded in <number> ms


