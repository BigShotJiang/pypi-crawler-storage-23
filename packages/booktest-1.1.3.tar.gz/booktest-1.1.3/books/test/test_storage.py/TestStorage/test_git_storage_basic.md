# GitStorage Basic Operations


## Store Operation

Stored content with hash: sha256:7f1dc60888819936e8f53f76617bfe0020619215ae0b0347529d8a9329a24b34

## Fetch Operation

Fetched content matches: False

## Exists Check

Snapshot exists: True
Non-existent snapshot: False

## Manifest Generation

Manifest: {
  "test/example/test_case": {
    "func": "sha256:9d6c1804e6649a401f8466715dd9e789c1017ecd0cc8289630b99fef0fa70789"
  }
}
