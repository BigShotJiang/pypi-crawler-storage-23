# GitStorage Path Construction


## Test ID: test/simple::test_case

Path: test/simple/test_case.snapshots.json
File exists: True
Snapshot exists: True

## Test ID: test/nested/deep::test_func

Path: test/nested/deep/test_func.snapshots.json
File exists: True
Snapshot exists: True

## Test ID: examples/snapshots::httpx_test

Path: examples/snapshots/httpx_test.snapshots.json
File exists: True
Snapshot exists: True
