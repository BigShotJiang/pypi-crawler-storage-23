# DVCStorage Fallback Behavior

Testing storage creation without DVC...
Created storage type: GitStorage
Is GitStorage: True
