# Manifest Operations


## GitStorage Manifest

Manifest: {
  "test1": {
    "env": "sha256:aa0ca6242c13eb7bea50854eb412d299f29425290fc3d568cfcc62d4aa9b6b05",
    "http": "sha256:96a0db10d808ed5db0ce365268b3253ec9ec3107436397be15590c91647fb40d"
  },
  "test2": {
    "func": "sha256:9cefc0aec6862ee2dcf70b0e71d4c3582eae9ded201e1c877441c50a933dd85e"
  }
}
GitStorage update_manifest is a no-op (as expected)
