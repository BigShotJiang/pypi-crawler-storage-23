# Storage Mode Detection


## No Configuration

Detected mode: git

## Explicit Configuration

Configured mode: git

## Auto Configuration

Auto-detected mode: git
