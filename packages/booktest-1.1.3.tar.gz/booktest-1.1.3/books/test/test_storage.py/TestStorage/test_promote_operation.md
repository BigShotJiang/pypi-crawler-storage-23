# Promote Operation


## GitStorage Promote

GitStorage promote is a no-op (as expected)
Content still accessible: True
