<!-- markdownlint-disable -->

<a href="../../booktest/llm/tokenizer.py#L0"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

# <kbd>module</kbd> `llm.tokenizer`






---

<a href="../../booktest/llm/tokenizer.py#L6"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>class</kbd> `TestTokenizer`
simple tokenizer, that tokenizes whitespaces, words and numbers  

<a href="../../booktest/llm/tokenizer.py#L9"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>method</kbd> `__init__`

```python
__init__(buf, at=0)
```








---

<a href="../../booktest/llm/tokenizer.py#L22"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>method</kbd> `has_next`

```python
has_next()
```





---

<a href="../../booktest/llm/tokenizer.py#L16"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>method</kbd> `peek`

```python
peek()
```






---

<a href="../../booktest/llm/tokenizer.py#L60"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>class</kbd> `BufferIterator`




<a href="../../booktest/llm/tokenizer.py#L61"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>method</kbd> `__init__`

```python
__init__(iterator)
```








---

<a href="../../booktest/llm/tokenizer.py#L71"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>method</kbd> `has_next`

```python
has_next()
```








---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
