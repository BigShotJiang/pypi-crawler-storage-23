<!-- markdownlint-disable -->

<a href="../booktest/naming.py#L0"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

# <kbd>module</kbd> `naming.py`





---

<a href="../booktest/naming.py#L9"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `camel_case_to_snake_case`

```python
camel_case_to_snake_case(name)
```






---

<a href="../booktest/naming.py#L22"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `clean_test_postfix`

```python
clean_test_postfix(name)
```






---

<a href="../booktest/naming.py#L43"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `clean_class_name`

```python
clean_class_name(name: str)
```






---

<a href="../booktest/naming.py#L47"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `clean_method_name`

```python
clean_method_name(name: str)
```






---

<a href="../booktest/naming.py#L54"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `class_to_test_path`

```python
class_to_test_path(clazz)
```








---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
