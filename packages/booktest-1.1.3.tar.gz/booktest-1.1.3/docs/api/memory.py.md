<!-- markdownlint-disable -->

<a href="../booktest/memory.py#L0"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

# <kbd>module</kbd> `memory.py`





---

<a href="../booktest/memory.py#L41"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `t_memory`

```python
t_memory(t, name, func)
```






---

<a href="../booktest/memory.py#L55"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `monitor_memory`

```python
monitor_memory()
```






---

## <kbd>class</kbd> `MemoryMonitor`




<a href="../booktest/memory.py#L11"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>function</kbd> `__init__`

```python
__init__()
```








---

<a href="../booktest/memory.py#L29"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>function</kbd> `results`

```python
results()
```





---

<a href="../booktest/memory.py#L33"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>function</kbd> `run`

```python
run()
```





---

<a href="../booktest/memory.py#L20"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>function</kbd> `stop`

```python
stop()
```








---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
