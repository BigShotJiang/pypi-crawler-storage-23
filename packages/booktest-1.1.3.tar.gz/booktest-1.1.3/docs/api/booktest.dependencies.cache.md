<!-- markdownlint-disable -->

# <kbd>module</kbd> `booktest.dependencies.cache`






---

## <kbd>class</kbd> `LruCache`




### <kbd>method</kbd> `__init__`

```python
__init__(size: int)
```









---

## <kbd>class</kbd> `NoCache`










---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
