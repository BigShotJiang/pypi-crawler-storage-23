<!-- markdownlint-disable -->

# <kbd>module</kbd> `booktest.reporting.books`






---

## <kbd>class</kbd> `Books`
This is a for helping run books locally e.g. inside pytest or inside a script 

### <kbd>method</kbd> `__init__`

```python
__init__(book_src_module_or_path, books_module_or_path, selection=None)
```








---

### <kbd>method</kbd> `assert_test`

```python
assert_test(test_case)
```





---

### <kbd>method</kbd> `list_tests`

```python
list_tests(prefix='')
```





---

### <kbd>method</kbd> `run_test`

```python
run_test(test_case, cache={})
```








---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
