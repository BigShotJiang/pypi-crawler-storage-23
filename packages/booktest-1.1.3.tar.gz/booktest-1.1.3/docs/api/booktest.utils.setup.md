<!-- markdownlint-disable -->

# <kbd>module</kbd> `booktest.utils.setup`




**Global Variables**
---------------
- **DEFAULT_TIMEOUT**
- **personal_comment**
- **project_comment**
- **config_comments**
- **config_defaults**

---

## <kbd>function</kbd> `prompt_config`

```python
prompt_config(key, config)
```






---

## <kbd>function</kbd> `setup_personal`

```python
setup_personal()
```






---

## <kbd>function</kbd> `setup_project`

```python
setup_project()
```






---

## <kbd>function</kbd> `setup_booktest`

```python
setup_booktest()
```








---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
