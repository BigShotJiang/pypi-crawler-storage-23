<!-- markdownlint-disable -->

<a href="../../booktest/dependencies/cache.py#L0"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

# <kbd>module</kbd> `dependencies.cache`






---

<a href="../../booktest/dependencies/cache.py#L4"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>class</kbd> `LruCache`




<a href="../../booktest/dependencies/cache.py#L8"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>method</kbd> `__init__`

```python
__init__(size: int)
```









---

<a href="../../booktest/dependencies/cache.py#L38"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>class</kbd> `NoCache`










---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
