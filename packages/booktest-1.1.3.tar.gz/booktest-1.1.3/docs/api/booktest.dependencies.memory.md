<!-- markdownlint-disable -->

# <kbd>module</kbd> `booktest.dependencies.memory`





---

## <kbd>function</kbd> `t_memory`

```python
t_memory(t, name, func)
```






---

## <kbd>function</kbd> `monitor_memory`

```python
monitor_memory()
```






---

## <kbd>class</kbd> `MemoryMonitor`




### <kbd>method</kbd> `__init__`

```python
__init__()
```








---

### <kbd>method</kbd> `results`

```python
results()
```





---

### <kbd>method</kbd> `run`

```python
run()
```





---

### <kbd>method</kbd> `stop`

```python
stop()
```








---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
