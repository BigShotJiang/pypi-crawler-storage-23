<!-- markdownlint-disable -->

<a href="../booktest/utils.py#L0"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

# <kbd>module</kbd> `utils.py`





---

<a href="../booktest/utils.py#L8"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `accept_all`

```python
accept_all(_)
```






---

<a href="../booktest/utils.py#L12"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `path_to_module_resource`

```python
path_to_module_resource(path: str)
```






---

<a href="../booktest/utils.py#L17"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `open_file_or_resource`

```python
open_file_or_resource(path: str, is_resource: bool)
```






---

<a href="../booktest/utils.py#L24"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `file_or_resource_exists`

```python
file_or_resource_exists(path: str, is_resource: bool)
```






---

<a href="../booktest/utils.py#L55"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `setup_teardown`

```python
setup_teardown(setup_teardown_generator)
```






---

<a href="../booktest/utils.py#L68"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `combine_decorators`

```python
combine_decorators(*decorators)
```






---

## <kbd>class</kbd> `SetupTeardown`




<a href="../booktest/utils.py#L37"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>function</kbd> `__init__`

```python
__init__(setup_teardown_generator)
```











---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
