<!-- markdownlint-disable -->

<a href="../../booktest/utils/coroutines.py#L0"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

# <kbd>module</kbd> `utils.coroutines`





---

<a href="../../booktest/utils/coroutines.py#L4"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `maybe_async_call`

```python
maybe_async_call(func, args2, kwargs)
```








---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
