<!-- markdownlint-disable -->

<a href="../booktest/books.py#L0"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

# <kbd>module</kbd> `books.py`






---

## <kbd>class</kbd> `Books`
This is a for helping run books locally e.g. inside pytest or inside a script 

<a href="../booktest/books.py#L11"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>function</kbd> `__init__`

```python
__init__(book_src_module_or_path, books_module_or_path, selection=None)
```








---

<a href="../booktest/books.py#L42"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>function</kbd> `assert_test`

```python
assert_test(test_case)
```





---

<a href="../booktest/books.py#L26"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>function</kbd> `list_tests`

```python
list_tests(prefix='')
```





---

<a href="../booktest/books.py#L33"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>function</kbd> `run_test`

```python
run_test(test_case, cache={})
```








---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
