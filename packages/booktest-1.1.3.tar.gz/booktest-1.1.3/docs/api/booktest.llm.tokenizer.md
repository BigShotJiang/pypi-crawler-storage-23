<!-- markdownlint-disable -->

# <kbd>module</kbd> `booktest.llm.tokenizer`






---

## <kbd>class</kbd> `TestTokenizer`
simple tokenizer, that tokenizes whitespaces, words and numbers  

### <kbd>method</kbd> `__init__`

```python
__init__(buf, at=0)
```








---

### <kbd>method</kbd> `has_next`

```python
has_next()
```





---

### <kbd>method</kbd> `peek`

```python
peek()
```






---

## <kbd>class</kbd> `BufferIterator`




### <kbd>method</kbd> `__init__`

```python
__init__(iterator)
```








---

### <kbd>method</kbd> `has_next`

```python
has_next()
```








---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
