<!-- markdownlint-disable -->

# <kbd>module</kbd> `booktest.config`




**Global Variables**
---------------
- **naming**
- **selection**
- **detection**
- **config**




---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
