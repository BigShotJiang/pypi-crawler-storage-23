<!-- markdownlint-disable -->

# <kbd>module</kbd> `booktest.snapshots`




**Global Variables**
---------------
- **snapshots**
- **functions**
- **requests**
- **httpx**
- **env**




---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
