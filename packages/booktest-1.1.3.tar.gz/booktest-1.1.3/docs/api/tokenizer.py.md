<!-- markdownlint-disable -->

<a href="../booktest/tokenizer.py#L0"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

# <kbd>module</kbd> `tokenizer.py`






---

## <kbd>class</kbd> `BufferIterator`




<a href="../booktest/tokenizer.py#L61"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>function</kbd> `__init__`

```python
__init__(iterator)
```








---

<a href="../booktest/tokenizer.py#L71"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>function</kbd> `has_next`

```python
has_next()
```






---

## <kbd>class</kbd> `TestTokenizer`
simple tokenizer, that tokenizes whitespaces, words and numbers  

<a href="../booktest/tokenizer.py#L9"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>function</kbd> `__init__`

```python
__init__(buf, at=0)
```








---

<a href="../booktest/tokenizer.py#L22"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>function</kbd> `has_next`

```python
has_next()
```





---

<a href="../booktest/tokenizer.py#L16"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>function</kbd> `peek`

```python
peek()
```








---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
