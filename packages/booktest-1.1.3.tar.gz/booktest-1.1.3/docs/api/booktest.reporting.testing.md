<!-- markdownlint-disable -->

# <kbd>module</kbd> `booktest.reporting.testing`





---

## <kbd>function</kbd> `value_format`

```python
value_format(value)
```






---

## <kbd>class</kbd> `TestIt`
utility for making assertions related to a specific object  

### <kbd>method</kbd> `__init__`

```python
__init__(run: OutputWriter, title: str, it)
```








---

### <kbd>method</kbd> `member`

```python
member(title, select)
```

Creates a TestIt class for the member of 'it'  

---

### <kbd>method</kbd> `must_apply`

```python
must_apply(title, cond)
```





---

### <kbd>method</kbd> `must_be_a`

```python
must_be_a(typ)
```





---

### <kbd>method</kbd> `must_contain`

```python
must_contain(member)
```





---

### <kbd>method</kbd> `must_equal`

```python
must_equal(member)
```








---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
