<!-- markdownlint-disable -->

<a href="../booktest/snapshots.py#L0"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

# <kbd>module</kbd> `snapshots.py`





---

<a href="../booktest/snapshots.py#L6"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `out_snapshot_path`

```python
out_snapshot_path(t: TestCaseRun, path: str)
```






---

<a href="../booktest/snapshots.py#L13"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `frozen_snapshot_path`

```python
frozen_snapshot_path(t: TestCaseRun, path: str)
```






---

<a href="../booktest/snapshots.py#L28"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `have_snapshots_dir`

```python
have_snapshots_dir(t)
```








---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
