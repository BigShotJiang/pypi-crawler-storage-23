<!-- markdownlint-disable -->

# <kbd>module</kbd> `booktest.reporting`




**Global Variables**
---------------
- **reports**
- **review**
- **output**
- **colors**
- **books**
- **testing**




---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
