<!-- markdownlint-disable -->

# <kbd>module</kbd> `booktest.core`




**Global Variables**
---------------
- **testcaserun**
- **testrun**
- **runs**
- **tests**
- **testsuite**
- **testbook**




---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
