<!-- markdownlint-disable -->

<a href="../booktest/setup.py#L0"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

# <kbd>module</kbd> `setup.py`




**Global Variables**
---------------
- **DEFAULT_TIMEOUT**
- **personal_comment**
- **project_comment**
- **config_comments**
- **config_defaults**

---

<a href="../booktest/setup.py#L108"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `prompt_config`

```python
prompt_config(key, config)
```






---

<a href="../booktest/setup.py#L126"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `setup_personal`

```python
setup_personal()
```






---

<a href="../booktest/setup.py#L154"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `setup_project`

```python
setup_project()
```






---

<a href="../booktest/setup.py#L179"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

## <kbd>function</kbd> `setup_booktest`

```python
setup_booktest()
```








---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
