<!-- markdownlint-disable -->

# <kbd>module</kbd> `booktest.migration`




**Global Variables**
---------------
- **migrate**




---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
