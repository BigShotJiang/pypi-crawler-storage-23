<!-- markdownlint-disable -->

# <kbd>module</kbd> `booktest.utils.coroutines`





---

## <kbd>function</kbd> `maybe_async_call`

```python
maybe_async_call(func, args2, kwargs)
```








---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
