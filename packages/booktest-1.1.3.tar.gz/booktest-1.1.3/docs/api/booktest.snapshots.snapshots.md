<!-- markdownlint-disable -->

# <kbd>module</kbd> `booktest.snapshots.snapshots`





---

## <kbd>function</kbd> `out_snapshot_path`

```python
out_snapshot_path(t: TestCaseRun, path: str)
```






---

## <kbd>function</kbd> `frozen_snapshot_path`

```python
frozen_snapshot_path(t: TestCaseRun, path: str)
```






---

## <kbd>function</kbd> `have_snapshots_dir`

```python
have_snapshots_dir(t)
```








---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
