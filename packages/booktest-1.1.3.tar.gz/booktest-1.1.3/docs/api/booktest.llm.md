<!-- markdownlint-disable -->

# <kbd>module</kbd> `booktest.llm`




**Global Variables**
---------------
- **tokenizer**: # Text processing used in test
#

- **llm**
- **llm_review**




---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
