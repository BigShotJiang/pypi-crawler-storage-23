<!-- markdownlint-disable -->

# <kbd>module</kbd> `booktest.cli`
This package introduces the lumoa-rl cli interface. It can be used for creating insights or for creating topics. 

**Global Variables**
---------------
- **DEFAULT_PYTHON_PATH**

---

## <kbd>function</kbd> `add_exec`

```python
add_exec(parser, method)
```






---

## <kbd>function</kbd> `setup_test_suite`

```python
setup_test_suite(parser, python_path=None, detect_selection=None)
```






---

## <kbd>function</kbd> `exec_parsed`

```python
exec_parsed(parsed)
```






---

## <kbd>function</kbd> `main`

```python
main(arguments=None)
```








---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
