<!-- markdownlint-disable -->

<a href="../booktest/cache.py#L0"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

# <kbd>module</kbd> `cache.py`






---

## <kbd>class</kbd> `LruCache`




<a href="../booktest/cache.py#L8"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

### <kbd>function</kbd> `__init__`

```python
__init__(size: int)
```









---

## <kbd>class</kbd> `NoCache`










---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
