from __future__ import annotations

from typing import Any, Literal, Mapping

Mode = Literal["text", "json", "rpc"]
ThinkingLevel = Literal["off", "minimal", "low", "medium", "high", "xhigh"]
ToolName = Literal["read", "bash", "edit", "write", "grep", "find", "ls"]

VALID_THINKING_LEVELS: tuple[ThinkingLevel, ...] = ("off", "minimal", "low", "medium", "high", "xhigh")
VALID_TOOLS: tuple[ToolName, ...] = ("read", "bash", "edit", "write", "grep", "find", "ls")


def is_valid_thinking_level(level: str) -> bool:
    return level in VALID_THINKING_LEVELS


def parse_args(
    args: list[str],
    extension_flags: Mapping[str, Mapping[str, Literal["boolean", "string"]]] | None = None,
) -> dict[str, Any]:
    """Parse coding-agent CLI args with compatibility to the TypeScript parser."""

    result: dict[str, Any] = {
        "messages": [],
        "fileArgs": [],
        "unknownFlags": {},
    }

    i = 0
    while i < len(args):
        arg = args[i]

        if arg in {"--help", "-h"}:
            result["help"] = True
        elif arg in {"--version", "-v"}:
            result["version"] = True
        elif arg == "--mode" and i + 1 < len(args):
            i += 1
            mode = args[i]
            if mode in {"text", "json", "rpc"}:
                result["mode"] = mode
        elif arg in {"--continue", "-c"}:
            result["continue"] = True
        elif arg in {"--resume", "-r"}:
            result["resume"] = True
        elif arg == "--provider" and i + 1 < len(args):
            i += 1
            result["provider"] = args[i]
        elif arg == "--model" and i + 1 < len(args):
            i += 1
            result["model"] = args[i]
        elif arg == "--api-key" and i + 1 < len(args):
            i += 1
            result["apiKey"] = args[i]
        elif arg == "--system-prompt" and i + 1 < len(args):
            i += 1
            result["systemPrompt"] = args[i]
        elif arg == "--append-system-prompt" and i + 1 < len(args):
            i += 1
            result["appendSystemPrompt"] = args[i]
        elif arg == "--no-session":
            result["noSession"] = True
        elif arg == "--session" and i + 1 < len(args):
            i += 1
            result["session"] = args[i]
        elif arg == "--session-dir" and i + 1 < len(args):
            i += 1
            result["sessionDir"] = args[i]
        elif arg == "--models" and i + 1 < len(args):
            i += 1
            result["models"] = [part.strip() for part in args[i].split(",")]
        elif arg == "--no-tools":
            result["noTools"] = True
        elif arg == "--tools" and i + 1 < len(args):
            i += 1
            tool_names = [part.strip() for part in args[i].split(",")]
            result["tools"] = [name for name in tool_names if name in VALID_TOOLS]
        elif arg == "--thinking" and i + 1 < len(args):
            i += 1
            level = args[i]
            if is_valid_thinking_level(level):
                result["thinking"] = level
        elif arg in {"--print", "-p"}:
            result["print"] = True
        elif arg == "--export" and i + 1 < len(args):
            i += 1
            result["export"] = args[i]
        elif arg in {"--extension", "-e"} and i + 1 < len(args):
            i += 1
            extensions: list[str] = result.setdefault("extensions", [])
            extensions.append(args[i])
        elif arg in {"--no-extensions", "-ne"}:
            result["noExtensions"] = True
        elif arg == "--skill" and i + 1 < len(args):
            i += 1
            skills: list[str] = result.setdefault("skills", [])
            skills.append(args[i])
        elif arg == "--prompt-template" and i + 1 < len(args):
            i += 1
            prompt_templates: list[str] = result.setdefault("promptTemplates", [])
            prompt_templates.append(args[i])
        elif arg == "--theme" and i + 1 < len(args):
            i += 1
            themes: list[str] = result.setdefault("themes", [])
            themes.append(args[i])
        elif arg in {"--no-skills", "-ns"}:
            result["noSkills"] = True
        elif arg in {"--no-prompt-templates", "-np"}:
            result["noPromptTemplates"] = True
        elif arg == "--no-themes":
            result["noThemes"] = True
        elif arg == "--list-models":
            if i + 1 < len(args) and not args[i + 1].startswith("-") and not args[i + 1].startswith("@"):
                i += 1
                result["listModels"] = args[i]
            else:
                result["listModels"] = True
        elif arg == "--verbose":
            result["verbose"] = True
        elif arg.startswith("@"):
            file_args: list[str] = result["fileArgs"]
            file_args.append(arg[1:])
        elif arg.startswith("--") and extension_flags is not None:
            flag_name = arg[2:]
            ext_flag = extension_flags.get(flag_name)
            if ext_flag:
                flag_type = ext_flag.get("type")
                if flag_type == "boolean":
                    unknown_flags: dict[str, bool | str] = result["unknownFlags"]
                    unknown_flags[flag_name] = True
                elif flag_type == "string" and i + 1 < len(args):
                    i += 1
                    unknown_flags = result["unknownFlags"]
                    unknown_flags[flag_name] = args[i]
        elif not arg.startswith("-"):
            messages: list[str] = result["messages"]
            messages.append(arg)

        i += 1

    return result
