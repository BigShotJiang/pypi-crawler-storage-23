from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .diagnostics import ResourceDiagnostic
from .prompt_templates import PromptTemplate, load_prompt_templates
from .settings_manager import SettingsManager
from .skills import Skill, load_skills


@dataclass(frozen=True)
class PathMetadata:
    source: str
    scope: str
    origin: str
    base_dir: str | None = None

    @property
    def baseDir(self) -> str | None:
        return self.base_dir


def _resolve_resource_path(path: str, cwd: str) -> str:
    expanded = os.path.expanduser(path.strip())
    if os.path.isabs(expanded):
        return str(Path(expanded).resolve())
    return str((Path(cwd) / expanded).resolve())


def _merge_paths(*groups: list[str]) -> list[str]:
    ordered: list[str] = []
    seen: set[str] = set()
    for group in groups:
        for item in group:
            if item in seen:
                continue
            seen.add(item)
            ordered.append(item)
    return ordered


def _apply_overrides(paths: list[str], overrides: list[str]) -> list[str]:
    disabled: set[str] = set()
    explicit: list[str] = []
    for raw in overrides:
        if raw.startswith("-"):
            disabled.add(raw[1:])
        elif raw.startswith("+"):
            explicit.append(raw[1:])
        else:
            explicit.append(raw)

    result: list[str] = []
    for path in paths:
        if any(path.endswith(disabled_suffix) for disabled_suffix in disabled):
            continue
        result.append(path)
    return _merge_paths(result, explicit)


def _load_context_file_from_dir(dir_path: Path) -> dict[str, str] | None:
    for candidate in ("AGENTS.md", "CLAUDE.md"):
        path = dir_path / candidate
        if not path.exists():
            continue
        try:
            return {"path": str(path), "content": path.read_text(encoding="utf-8")}
        except Exception:
            continue
    return None


def _load_project_context_files(cwd: Path, agent_dir: Path) -> list[dict[str, str]]:
    files: list[dict[str, str]] = []
    seen: set[str] = set()

    global_ctx = _load_context_file_from_dir(agent_dir)
    if global_ctx:
        files.append(global_ctx)
        seen.add(global_ctx["path"])

    collected: list[dict[str, str]] = []
    current = cwd.resolve()
    root = Path(current.root)
    while True:
        ctx = _load_context_file_from_dir(current)
        if ctx and ctx["path"] not in seen:
            collected.insert(0, ctx)
            seen.add(ctx["path"])
        if current == root:
            break
        parent = current.parent
        if parent == current:
            break
        current = parent

    files.extend(collected)
    return files


class DefaultResourceLoader:
    def __init__(self, options: dict[str, Any] | None = None) -> None:
        opts = options or {}
        self.cwd = Path(str(opts.get("cwd") or Path.cwd()))
        self.agent_dir = Path(str(opts.get("agentDir") or (Path.home() / ".pi" / "agent")))
        self.settings_manager = opts.get("settingsManager") or SettingsManager.create(self.cwd, self.agent_dir)

        self.additional_extension_paths = list(opts.get("additionalExtensionPaths") or [])
        self.additional_skill_paths = list(opts.get("additionalSkillPaths") or [])
        self.additional_prompt_template_paths = list(opts.get("additionalPromptTemplatePaths") or [])
        self.additional_theme_paths = list(opts.get("additionalThemePaths") or [])

        self.no_extensions = bool(opts.get("noExtensions", False))
        self.no_skills = bool(opts.get("noSkills", False))
        self.no_prompt_templates = bool(opts.get("noPromptTemplates", False))
        self.no_themes = bool(opts.get("noThemes", False))

        self.system_prompt_source = opts.get("systemPrompt")
        self.append_system_prompt_source = opts.get("appendSystemPrompt")

        self.skills_override = opts.get("skillsOverride")
        self.prompts_override = opts.get("promptsOverride")
        self.themes_override = opts.get("themesOverride")
        self.agents_files_override = opts.get("agentsFilesOverride")
        self.system_prompt_override = opts.get("systemPromptOverride")
        self.append_system_prompt_override = opts.get("appendSystemPromptOverride")

        self.extensions_result: dict[str, Any] = {"extensions": [], "errors": [], "runtime": {}}
        self.skills: list[Skill] = []
        self.skill_diagnostics: list[ResourceDiagnostic] = []
        self.prompts: list[PromptTemplate] = []
        self.prompt_diagnostics: list[ResourceDiagnostic] = []
        self.themes: list[dict[str, Any]] = []
        self.theme_diagnostics: list[ResourceDiagnostic] = []
        self.agents_files: list[dict[str, str]] = []
        self.system_prompt: str | None = None
        self.append_system_prompt: list[str] = []
        self.path_metadata: dict[str, PathMetadata] = {}
        self.last_skill_paths: list[str] = []
        self.last_prompt_paths: list[str] = []
        self.last_theme_paths: list[str] = []

    def get_extensions(self) -> dict[str, Any]:
        return self.extensions_result

    def getExtensions(self) -> dict[str, Any]:
        return self.get_extensions()

    def get_skills(self) -> dict[str, Any]:
        return {"skills": self.skills, "diagnostics": self.skill_diagnostics}

    def getSkills(self) -> dict[str, Any]:
        return self.get_skills()

    def get_prompts(self) -> dict[str, Any]:
        return {"prompts": self.prompts, "diagnostics": self.prompt_diagnostics}

    def getPrompts(self) -> dict[str, Any]:
        return self.get_prompts()

    def get_themes(self) -> dict[str, Any]:
        return {"themes": self.themes, "diagnostics": self.theme_diagnostics}

    def getThemes(self) -> dict[str, Any]:
        return self.get_themes()

    def get_agents_files(self) -> dict[str, Any]:
        return {"agentsFiles": self.agents_files}

    def getAgentsFiles(self) -> dict[str, Any]:
        return self.get_agents_files()

    def get_system_prompt(self) -> str | None:
        return self.system_prompt

    def getSystemPrompt(self) -> str | None:
        return self.get_system_prompt()

    def get_append_system_prompt(self) -> list[str]:
        return list(self.append_system_prompt)

    def getAppendSystemPrompt(self) -> list[str]:
        return self.get_append_system_prompt()

    def get_path_metadata(self) -> dict[str, PathMetadata]:
        return dict(self.path_metadata)

    def getPathMetadata(self) -> dict[str, PathMetadata]:
        return self.get_path_metadata()

    def _add_default_metadata_for_path(self, path: str) -> None:
        if path in self.path_metadata:
            return
        self.path_metadata[path] = PathMetadata(source="auto", scope="user", origin="top-level")

    def _discover_system_prompt_file(self) -> str | None:
        system_file = self.cwd / ".pi" / "SYSTEM.md"
        if system_file.exists():
            return str(system_file)
        return None

    def _discover_append_system_prompt_file(self) -> str | None:
        append_file = self.cwd / ".pi" / "APPEND_SYSTEM.md"
        if append_file.exists():
            return str(append_file)
        return None

    def _resolve_prompt_input(self, input_value: str | None) -> str | None:
        if not input_value:
            return None
        candidate = Path(input_value)
        if candidate.exists():
            try:
                return candidate.read_text(encoding="utf-8")
            except Exception:
                return input_value
        return input_value

    def _discover_extensions(self) -> list[str]:
        default_paths: list[str] = []
        extension_dirs = [self.agent_dir / "extensions", self.cwd / ".pi" / "extensions"]
        for directory in extension_dirs:
            if not directory.exists():
                continue
            for child in directory.iterdir():
                if child.is_file() and child.suffix in {".py", ".ts", ".js"}:
                    default_paths.append(str(child.resolve()))
                    continue

                if not child.is_dir():
                    continue

                manifest_paths: list[Path] = []
                package_json = child / "package.json"
                if package_json.exists():
                    try:
                        payload = json.loads(package_json.read_text(encoding="utf-8"))
                    except Exception:
                        payload = None

                    if isinstance(payload, dict):
                        pi_config = payload.get("pi")
                        extensions = pi_config.get("extensions") if isinstance(pi_config, dict) else None
                        if isinstance(extensions, str):
                            manifest_paths = [child / extensions]
                        elif isinstance(extensions, list):
                            manifest_paths = [child / str(path) for path in extensions]

                if manifest_paths:
                    for manifest_path in manifest_paths:
                        if manifest_path.exists():
                            default_paths.append(str(manifest_path.resolve()))
                    continue

                index_ts = child / "index.ts"
                index_js = child / "index.js"
                index_py = child / "index.py"
                if index_ts.exists():
                    default_paths.append(str(index_ts.resolve()))
                elif index_js.exists():
                    default_paths.append(str(index_js.resolve()))
                elif index_py.exists():
                    default_paths.append(str(index_py.resolve()))

        configured = [
            _resolve_resource_path(path, str(self.cwd))
            for path in self.settings_manager.get_extension_paths()
        ]
        return _merge_paths(default_paths, configured, self.additional_extension_paths)

    def _discover_skills(self) -> tuple[list[Skill], list[ResourceDiagnostic]]:
        configured = getattr(self.settings_manager, "getSkillPaths", lambda: [])()
        configured = [_resolve_resource_path(path, str(self.cwd)) for path in configured]

        paths = _merge_paths(
            configured,
            [_resolve_resource_path(path, str(self.cwd)) for path in self.additional_skill_paths],
        )

        if self.no_skills:
            paths = _merge_paths([path for path in paths if Path(path).exists()], [])
            result = load_skills(
                {
                    "cwd": str(self.cwd),
                    "agentDir": str(self.agent_dir),
                    "skillPaths": paths,
                    "includeDefaults": False,
                }
            )
        else:
            result = load_skills(
                {
                    "cwd": str(self.cwd),
                    "agentDir": str(self.agent_dir),
                    "skillPaths": paths,
                    "includeDefaults": True,
                }
            )

        return result["skills"], result["diagnostics"]

    def _discover_prompts(self) -> list[PromptTemplate]:
        configured = getattr(self.settings_manager, "getPromptTemplatePaths", lambda: [])()
        configured = [_resolve_resource_path(path, str(self.cwd)) for path in configured]
        prompt_paths = _merge_paths(
            configured,
            [_resolve_resource_path(path, str(self.cwd)) for path in self.additional_prompt_template_paths],
        )
        return load_prompt_templates(
            {
                "cwd": str(self.cwd),
                "agentDir": str(self.agent_dir),
                "promptPaths": prompt_paths,
                "includeDefaults": not self.no_prompt_templates,
            }
        )

    def _discover_themes(self) -> tuple[list[dict[str, Any]], list[ResourceDiagnostic]]:
        configured = getattr(self.settings_manager, "getThemePaths", lambda: [])()
        configured = [_resolve_resource_path(path, str(self.cwd)) for path in configured]
        theme_paths = _merge_paths(
            configured,
            [_resolve_resource_path(path, str(self.cwd)) for path in self.additional_theme_paths],
        )

        themes: list[dict[str, Any]] = []
        diagnostics: list[ResourceDiagnostic] = []

        default_dirs = [] if self.no_themes else [self.agent_dir / "themes", self.cwd / ".pi" / "themes"]
        for directory in default_dirs:
            if not directory.exists():
                continue
            for file_path in directory.glob("*.json"):
                theme_paths.append(str(file_path.resolve()))

        for raw_path in _merge_paths(theme_paths):
            path = Path(raw_path)
            if not path.exists():
                continue
            if path.is_dir():
                files = list(path.glob("*.json"))
            else:
                files = [path] if path.suffix == ".json" else []

            for file_path in files:
                try:
                    payload = json.loads(file_path.read_text(encoding="utf-8"))
                except Exception as exc:  # noqa: BLE001
                    diagnostics.append({"type": "warning", "path": str(file_path), "message": str(exc)})
                    continue
                if isinstance(payload, dict):
                    payload = dict(payload)
                    payload.setdefault("name", file_path.stem)
                    payload.setdefault("sourcePath", str(file_path))
                    themes.append(payload)

        return themes, diagnostics

    def _apply_extension_paths(self, paths: list[dict[str, Any]]) -> list[dict[str, Any]]:
        normalized: list[dict[str, Any]] = []
        for entry in paths:
            path = _resolve_resource_path(str(entry["path"]), str(self.cwd))
            metadata = entry.get("metadata", {})
            normalized.append({"path": path, "metadata": metadata})
        return normalized

    def extend_resources(self, paths: dict[str, Any]) -> None:
        skill_paths = self._apply_extension_paths(paths.get("skillPaths", []))
        prompt_paths = self._apply_extension_paths(paths.get("promptPaths", []))
        theme_paths = self._apply_extension_paths(paths.get("themePaths", []))

        if skill_paths:
            self.last_skill_paths = _merge_paths(self.last_skill_paths, [item["path"] for item in skill_paths])
            result = load_skills(
                {
                    "cwd": str(self.cwd),
                    "agentDir": str(self.agent_dir),
                    "skillPaths": self.last_skill_paths,
                    "includeDefaults": not self.no_skills,
                }
            )
            self.skills = result["skills"]
            self.skill_diagnostics = result["diagnostics"]
            for item in skill_paths:
                metadata = item["metadata"]
                self.path_metadata[item["path"]] = PathMetadata(
                    source=str(metadata.get("source", "extension")),
                    scope=str(metadata.get("scope", "temporary")),
                    origin=str(metadata.get("origin", "top-level")),
                    base_dir=metadata.get("baseDir"),
                )

        if prompt_paths:
            self.last_prompt_paths = _merge_paths(self.last_prompt_paths, [item["path"] for item in prompt_paths])
            self.prompts = load_prompt_templates(
                {
                    "cwd": str(self.cwd),
                    "agentDir": str(self.agent_dir),
                    "promptPaths": self.last_prompt_paths,
                    "includeDefaults": not self.no_prompt_templates,
                }
            )
            for item in prompt_paths:
                metadata = item["metadata"]
                self.path_metadata[item["path"]] = PathMetadata(
                    source=str(metadata.get("source", "extension")),
                    scope=str(metadata.get("scope", "temporary")),
                    origin=str(metadata.get("origin", "top-level")),
                    base_dir=metadata.get("baseDir"),
                )

        if theme_paths:
            self.last_theme_paths = _merge_paths(self.last_theme_paths, [item["path"] for item in theme_paths])
            self.themes, self.theme_diagnostics = self._discover_themes()
            for item in theme_paths:
                metadata = item["metadata"]
                self.path_metadata[item["path"]] = PathMetadata(
                    source=str(metadata.get("source", "extension")),
                    scope=str(metadata.get("scope", "temporary")),
                    origin=str(metadata.get("origin", "top-level")),
                    base_dir=metadata.get("baseDir"),
                )

    def extendResources(self, paths: dict[str, Any]) -> None:
        self.extend_resources(paths)

    async def reload(self) -> None:
        self.path_metadata = {}

        extension_paths = [] if self.no_extensions else self._discover_extensions()
        extension_paths = _apply_overrides(extension_paths, self.settings_manager.get_extension_paths())
        self.extensions_result = {
            "extensions": [{"path": path} for path in extension_paths],
            "errors": [],
            "runtime": {},
        }
        for path in extension_paths:
            self._add_default_metadata_for_path(path)

        skills, skill_diagnostics = self._discover_skills()
        base_skills_result = {"skills": skills, "diagnostics": skill_diagnostics}
        if self.skills_override:
            base_skills_result = self.skills_override(base_skills_result)
        self.skills = base_skills_result["skills"]
        self.skill_diagnostics = base_skills_result["diagnostics"]
        for skill in self.skills:
            self._add_default_metadata_for_path(skill.file_path)

        prompts = self._discover_prompts()
        base_prompts_result = {"prompts": prompts, "diagnostics": []}
        if self.prompts_override:
            base_prompts_result = self.prompts_override(base_prompts_result)
        self.prompts = base_prompts_result["prompts"]
        self.prompt_diagnostics = base_prompts_result["diagnostics"]
        for prompt in self.prompts:
            self._add_default_metadata_for_path(prompt.file_path)

        themes, theme_diagnostics = self._discover_themes()
        base_themes_result = {"themes": themes, "diagnostics": theme_diagnostics}
        if self.themes_override:
            base_themes_result = self.themes_override(base_themes_result)
        self.themes = base_themes_result["themes"]
        self.theme_diagnostics = base_themes_result["diagnostics"]
        for theme in self.themes:
            source_path = theme.get("sourcePath")
            if isinstance(source_path, str):
                self._add_default_metadata_for_path(source_path)

        agents_files = {"agentsFiles": _load_project_context_files(self.cwd, self.agent_dir)}
        if self.agents_files_override:
            agents_files = self.agents_files_override(agents_files)
        self.agents_files = agents_files["agentsFiles"]

        base_system_prompt = self._resolve_prompt_input(
            str(self.system_prompt_source)
            if self.system_prompt_source is not None
            else self._discover_system_prompt_file()
        )
        if self.system_prompt_override:
            self.system_prompt = self.system_prompt_override(base_system_prompt)
        else:
            self.system_prompt = base_system_prompt

        append_source = (
            str(self.append_system_prompt_source)
            if self.append_system_prompt_source is not None
            else self._discover_append_system_prompt_file()
        )
        append_content = self._resolve_prompt_input(append_source)
        base_append = [append_content] if append_content else []
        self.append_system_prompt = (
            self.append_system_prompt_override(base_append) if self.append_system_prompt_override else base_append
        )


__all__ = [
    "DefaultResourceLoader",
    "PathMetadata",
]
