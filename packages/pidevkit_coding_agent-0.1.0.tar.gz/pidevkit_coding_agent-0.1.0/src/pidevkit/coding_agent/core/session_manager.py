from __future__ import annotations

import json
import os
import secrets
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

CURRENT_SESSION_VERSION = 3


@dataclass(frozen=True, slots=True)
class SessionInfo:
    path: str
    id: str
    cwd: str
    name: str | None
    created: datetime
    modified: datetime
    message_count: int
    first_message: str
    all_messages_text: str
    parent_session_path: str | None = None


def _new_id() -> str:
    return secrets.token_hex(4)


def _now_iso() -> str:
    return datetime.now(tz=UTC).isoformat()


def _safe_iso_to_datetime(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        if value.endswith("Z"):
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def _ms_to_datetime(value: int | float) -> datetime:
    return datetime.fromtimestamp(float(value) / 1000.0, tz=UTC)


def _extract_message_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        chunks: list[str] = []
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text" and isinstance(item.get("text"), str):
                chunks.append(item["text"])
        return "\n".join(chunks)
    return ""


def parse_session_entries(content: str) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for line in content.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            parsed = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict):
            entries.append(parsed)
    return entries


def parseSessionEntries(content: str) -> list[dict[str, Any]]:
    return parse_session_entries(content)


def migrate_session_entries(entries: list[dict[str, Any]]) -> None:
    if not entries or entries[0].get("type") != "session":
        return

    header = entries[0]
    version = int(header.get("version", 1))
    if version >= CURRENT_SESSION_VERSION:
        return

    if version < 2:
        prev_id: str | None = None
        for entry in entries[1:]:
            if "id" not in entry:
                entry["id"] = _new_id()
            if "parentId" not in entry:
                entry["parentId"] = prev_id
            prev_id = entry.get("id")

    # v2 -> v3 hookMessage migration (minimal parity behavior)
    for entry in entries[1:]:
        if entry.get("type") == "message":
            message = entry.get("message")
            if isinstance(message, dict) and message.get("role") == "hookMessage":
                message["role"] = "custom"

    header["version"] = CURRENT_SESSION_VERSION


def migrateSessionEntries(entries: list[dict[str, Any]]) -> None:
    migrate_session_entries(entries)


def load_entries_from_file(path: str | Path) -> list[dict[str, Any]]:
    file_path = Path(path)
    if not file_path.exists():
        return []

    content = file_path.read_text(encoding="utf-8")
    if not content.strip():
        return []

    entries = parse_session_entries(content)
    if not entries:
        return []
    if entries[0].get("type") != "session":
        return []

    migrate_session_entries(entries)
    return entries


def loadEntriesFromFile(path: str | Path) -> list[dict[str, Any]]:
    return load_entries_from_file(path)


def find_most_recent_session(session_dir: str | Path) -> str | None:
    root = Path(session_dir)
    if not root.exists() or not root.is_dir():
        return None

    newest_path: Path | None = None
    newest_mtime = -1.0

    for candidate in root.glob("*.jsonl"):
        entries = load_entries_from_file(candidate)
        if not entries:
            continue
        mtime = candidate.stat().st_mtime
        if mtime > newest_mtime:
            newest_mtime = mtime
            newest_path = candidate

    return str(newest_path) if newest_path else None


def findMostRecentSession(session_dir: str | Path) -> str | None:
    return find_most_recent_session(session_dir)


def get_latest_compaction_entry(entries: list[dict[str, Any]]) -> dict[str, Any] | None:
    for entry in reversed(entries):
        if entry.get("type") == "compaction":
            return entry
    return None


def getLatestCompactionEntry(entries: list[dict[str, Any]]) -> dict[str, Any] | None:
    return get_latest_compaction_entry(entries)


def build_session_context(
    entries: list[dict[str, Any]],
    leaf_id: str | None = None,
    by_id: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    if not entries:
        return {"messages": [], "thinkingLevel": "off", "model": None}

    index = by_id or {entry["id"]: entry for entry in entries if isinstance(entry.get("id"), str)}
    if not index:
        return {"messages": [], "thinkingLevel": "off", "model": None}

    leaf: dict[str, Any] | None
    if leaf_id is None:
        leaf = entries[-1]
    else:
        leaf = index.get(leaf_id) or entries[-1]

    if leaf is None:
        return {"messages": [], "thinkingLevel": "off", "model": None}

    path: list[dict[str, Any]] = []
    current = leaf
    while current is not None:
        path.append(current)
        parent_id = current.get("parentId")
        if not isinstance(parent_id, str):
            break
        current = index.get(parent_id)
    path.reverse()

    thinking_level = "off"
    model: dict[str, str] | None = None
    compaction: dict[str, Any] | None = None

    for entry in path:
        entry_type = entry.get("type")
        if entry_type == "thinking_level_change":
            thinking_level = str(entry.get("thinkingLevel", thinking_level))
        elif entry_type == "model_change":
            provider = entry.get("provider")
            model_id = entry.get("modelId")
            if isinstance(provider, str) and isinstance(model_id, str):
                model = {"provider": provider, "modelId": model_id}
        elif entry_type == "message":
            message = entry.get("message")
            if isinstance(message, dict) and message.get("role") == "assistant":
                provider = message.get("provider")
                model_id = message.get("model")
                if isinstance(provider, str) and isinstance(model_id, str):
                    model = {"provider": provider, "modelId": model_id}
        elif entry_type == "compaction":
            compaction = entry

    messages: list[dict[str, Any]] = []
    path_slice = path
    if compaction is not None:
        messages.append({"role": "assistant", "summary": str(compaction.get("summary", ""))})
        first_kept = compaction.get("firstKeptEntryId")
        if isinstance(first_kept, str):
            start = next((i for i, entry in enumerate(path) if entry.get("id") == first_kept), len(path))
            path_slice = path[start:]

    for entry in path_slice:
        entry_type = entry.get("type")
        if entry_type == "compaction":
            continue
        if entry_type == "branch_summary":
            messages.append({"role": "assistant", "summary": str(entry.get("summary", ""))})
            continue
        if entry_type == "message":
            message = entry.get("message")
            if isinstance(message, dict):
                messages.append(message)

    return {
        "messages": messages,
        "thinkingLevel": thinking_level,
        "model": model,
    }


def buildSessionContext(
    entries: list[dict[str, Any]],
    leaf_id: str | None = None,
    by_id: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    return build_session_context(entries, leaf_id, by_id)


class SessionManager:
    def __init__(
        self,
        header: dict[str, Any],
        entries: list[dict[str, Any]],
        *,
        session_file: Path | None = None,
        session_dir: Path | None = None,
        in_memory: bool = False,
    ) -> None:
        self.header = header
        self.entries = entries
        self.session_file = session_file
        self.session_dir = session_dir
        self.in_memory = in_memory
        self.by_id: dict[str, dict[str, Any]] = {}
        for entry in entries:
            entry_id = entry.get("id")
            if isinstance(entry_id, str):
                self.by_id[entry_id] = entry

        self.leaf_id: str | None = entries[-1]["id"] if entries and isinstance(entries[-1].get("id"), str) else None

    @classmethod
    def in_memory(cls) -> SessionManager:
        header = {
            "type": "session",
            "id": _new_id(),
            "version": CURRENT_SESSION_VERSION,
            "timestamp": _now_iso(),
            "cwd": "",
        }
        return cls(header, [], in_memory=True)

    @classmethod
    def open(cls, session_file: str | Path, session_dir: str | Path | None = None) -> SessionManager:
        path = Path(session_file)
        path.parent.mkdir(parents=True, exist_ok=True)

        entries = load_entries_from_file(path)
        if not entries:
            header = {
                "type": "session",
                "id": _new_id(),
                "version": CURRENT_SESSION_VERSION,
                "timestamp": _now_iso(),
                "cwd": os.getcwd(),
            }
            path.write_text(json.dumps(header, ensure_ascii=False) + "\n", encoding="utf-8")
            return cls(
                header,
                [],
                session_file=path,
                session_dir=Path(session_dir) if session_dir is not None else path.parent,
            )

        header = entries[0]
        body = [entry for entry in entries[1:] if entry.get("type") != "session"]
        return cls(
            header,
            body,
            session_file=path,
            session_dir=Path(session_dir) if session_dir is not None else path.parent,
        )

    def _append(self, entry: dict[str, Any]) -> str:
        entry = dict(entry)
        if "id" not in entry:
            entry["id"] = _new_id()
        if "parentId" not in entry:
            entry["parentId"] = self.leaf_id
        if "timestamp" not in entry:
            entry["timestamp"] = _now_iso()

        entry_id = str(entry["id"])
        self.entries.append(entry)
        self.by_id[entry_id] = entry
        self.leaf_id = entry_id

        if not self.in_memory and self.session_file is not None:
            with self.session_file.open("a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False))
                f.write("\n")

        return entry_id

    def append_message(self, message: dict[str, Any]) -> str:
        return self._append({"type": "message", "message": dict(message)})

    def appendMessage(self, message: dict[str, Any]) -> str:
        return self.append_message(message)

    def append_thinking_level_change(self, level: str) -> str:
        return self._append({"type": "thinking_level_change", "thinkingLevel": level})

    def appendThinkingLevelChange(self, level: str) -> str:
        return self.append_thinking_level_change(level)

    def append_model_change(self, provider: str, model_id: str) -> str:
        return self._append({"type": "model_change", "provider": provider, "modelId": model_id})

    def appendModelChange(self, provider: str, model_id: str) -> str:
        return self.append_model_change(provider, model_id)

    def append_compaction(self, summary: str, first_kept_entry_id: str, tokens_before: int) -> str:
        return self._append(
            {
                "type": "compaction",
                "summary": summary,
                "firstKeptEntryId": first_kept_entry_id,
                "tokensBefore": tokens_before,
            }
        )

    def appendCompaction(self, summary: str, first_kept_entry_id: str, tokens_before: int) -> str:
        return self.append_compaction(summary, first_kept_entry_id, tokens_before)

    def append_custom_entry(self, custom_type: str, data: Any = None) -> str:
        return self._append({"type": "custom", "customType": custom_type, "data": data})

    def appendCustomEntry(self, custom_type: str, data: Any = None) -> str:
        return self.append_custom_entry(custom_type, data)

    def append_label_change(self, target_id: str, label: str | None) -> str:
        if target_id not in self.by_id:
            raise ValueError(f"Entry {target_id} not found")
        return self._append({"type": "label", "targetId": target_id, "label": label})

    def appendLabelChange(self, target_id: str, label: str | None) -> str:
        return self.append_label_change(target_id, label)

    def get_session_id(self) -> str:
        return str(self.header.get("id", ""))

    def getSessionId(self) -> str:
        return self.get_session_id()

    def get_session_file(self) -> str | None:
        return str(self.session_file) if self.session_file else None

    def getSessionFile(self) -> str | None:
        return self.get_session_file()

    def get_header(self) -> dict[str, Any]:
        return dict(self.header)

    def getHeader(self) -> dict[str, Any]:
        return self.get_header()

    def get_entries(self) -> list[dict[str, Any]]:
        return [dict(entry) for entry in self.entries]

    def getEntries(self) -> list[dict[str, Any]]:
        return self.get_entries()

    def get_leaf_id(self) -> str | None:
        return self.leaf_id

    def getLeafId(self) -> str | None:
        return self.get_leaf_id()

    def get_entry(self, entry_id: str) -> dict[str, Any] | None:
        entry = self.by_id.get(entry_id)
        return dict(entry) if entry else None

    def getEntry(self, entry_id: str) -> dict[str, Any] | None:
        return self.get_entry(entry_id)

    def get_label(self, target_id: str) -> str | None:
        label: str | None = None
        for entry in self.entries:
            if entry.get("type") == "label" and entry.get("targetId") == target_id:
                raw = entry.get("label")
                label = str(raw) if isinstance(raw, str) else None
        return label

    def getLabel(self, target_id: str) -> str | None:
        return self.get_label(target_id)

    def branch(self, entry_id: str) -> None:
        if entry_id not in self.by_id:
            raise ValueError(f"Entry {entry_id} not found")
        self.leaf_id = entry_id

    def get_branch(self, leaf_id: str | None = None) -> list[dict[str, Any]]:
        pointer = leaf_id if leaf_id is not None else self.leaf_id
        if pointer is None:
            return []

        path: list[dict[str, Any]] = []
        while pointer is not None:
            entry = self.by_id.get(pointer)
            if entry is None:
                break
            path.append(entry)
            parent = entry.get("parentId")
            pointer = parent if isinstance(parent, str) else None
        path.reverse()
        return [dict(entry) for entry in path]

    def getBranch(self, leaf_id: str | None = None) -> list[dict[str, Any]]:
        return self.get_branch(leaf_id)

    def create_branched_session(self, leaf_id: str) -> None:
        path_ids = {entry["id"] for entry in self.get_branch(leaf_id) if isinstance(entry.get("id"), str)}
        if not path_ids:
            return

        kept_entries: list[dict[str, Any]] = []
        for entry in self.entries:
            if entry.get("type") == "label":
                if entry.get("targetId") in path_ids:
                    kept_entries.append(entry)
                continue

            entry_id = entry.get("id")
            if isinstance(entry_id, str) and entry_id in path_ids:
                kept_entries.append(entry)

        self.entries = kept_entries
        self.by_id = {
            entry["id"]: entry
            for entry in self.entries
            if isinstance(entry.get("id"), str)
        }
        self.leaf_id = leaf_id

    def createBranchedSession(self, leaf_id: str) -> None:
        self.create_branched_session(leaf_id)

    def get_tree(self) -> list[dict[str, Any]]:
        if not self.entries:
            return []

        label_map: dict[str, str | None] = {}
        for entry in self.entries:
            if entry.get("type") == "label" and isinstance(entry.get("targetId"), str):
                raw_label = entry.get("label")
                label_map[entry["targetId"]] = str(raw_label) if isinstance(raw_label, str) else None

        nodes: dict[str, dict[str, Any]] = {}
        roots: list[dict[str, Any]] = []

        for entry in self.entries:
            entry_id = entry.get("id")
            if not isinstance(entry_id, str):
                continue
            node = {"entry": dict(entry), "children": []}
            label = label_map.get(entry_id)
            if label is not None:
                node["label"] = label
            nodes[entry_id] = node

        for entry in self.entries:
            entry_id = entry.get("id")
            if not isinstance(entry_id, str) or entry_id not in nodes:
                continue

            parent_id = entry.get("parentId")
            if isinstance(parent_id, str) and parent_id in nodes:
                nodes[parent_id]["children"].append(nodes[entry_id])
            else:
                roots.append(nodes[entry_id])

        return roots

    def getTree(self) -> list[dict[str, Any]]:
        return self.get_tree()

    def build_session_context(self, leaf_id: str | None = None) -> dict[str, Any]:
        return build_session_context(self.entries, leaf_id, self.by_id)

    def buildSessionContext(self, leaf_id: str | None = None) -> dict[str, Any]:
        return self.build_session_context(leaf_id)

    @classmethod
    def list(cls, cwd: str, session_dir: str) -> list[SessionInfo]:
        _ = cwd
        root = Path(session_dir)
        if not root.exists():
            return []

        sessions: list[SessionInfo] = []
        for file_path in root.rglob("*"):
            if not file_path.is_file():
                continue
            entries = load_entries_from_file(file_path)
            if not entries:
                continue

            header = entries[0]
            body = entries[1:]

            created = _safe_iso_to_datetime(header.get("timestamp")) or datetime.fromtimestamp(
                file_path.stat().st_mtime, tz=UTC
            )
            session_id = str(header.get("id", file_path.stem))
            session_cwd = str(header.get("cwd", ""))

            msg_count = 0
            first_message = ""
            all_text: list[str] = []
            latest_ms: int | None = None
            session_name: str | None = None

            for entry in body:
                if entry.get("type") == "session_info":
                    name = entry.get("name")
                    if isinstance(name, str):
                        session_name = name

                if entry.get("type") != "message":
                    continue
                message = entry.get("message")
                if not isinstance(message, dict):
                    continue
                role = message.get("role")
                if role not in {"user", "assistant"}:
                    continue
                msg_count += 1
                text = _extract_message_text(message.get("content"))
                if text:
                    if not first_message:
                        first_message = text
                    all_text.append(text)

                ts = message.get("timestamp")
                if isinstance(ts, (int, float)):
                    ts_int = int(ts)
                    latest_ms = ts_int if latest_ms is None else max(latest_ms, ts_int)

            if latest_ms is not None:
                modified = _ms_to_datetime(latest_ms)
            else:
                modified = datetime.fromtimestamp(file_path.stat().st_mtime, tz=UTC)

            parent_session_path = header.get("parentSession")
            parent_value = str(parent_session_path) if isinstance(parent_session_path, str) else None

            sessions.append(
                SessionInfo(
                    path=str(file_path),
                    id=session_id,
                    cwd=session_cwd,
                    name=session_name,
                    created=created,
                    modified=modified,
                    message_count=msg_count,
                    first_message=first_message,
                    all_messages_text="\n".join(all_text),
                    parent_session_path=parent_value,
                )
            )

        sessions.sort(key=lambda item: item.modified, reverse=True)
        return sessions


__all__ = [
    "CURRENT_SESSION_VERSION",
    "SessionInfo",
    "SessionManager",
    "build_session_context",
    "buildSessionContext",
    "find_most_recent_session",
    "findMostRecentSession",
    "get_latest_compaction_entry",
    "getLatestCompactionEntry",
    "load_entries_from_file",
    "loadEntriesFromFile",
    "migrate_session_entries",
    "migrateSessionEntries",
    "parse_session_entries",
    "parseSessionEntries",
]
