from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class RpcError(Exception):
    message: str
    code: int = -32600
    data: Any = None

    def to_response(self, *, command: str, request_id: str | int | None = None) -> dict[str, Any]:
        response: dict[str, Any] = {
            "type": "response",
            "command": command,
            "success": False,
            "error": self.message,
        }
        if request_id is not None:
            response["id"] = request_id
        return response


def encode_json_line(payload: dict[str, Any]) -> str:
    return json.dumps(payload, ensure_ascii=False) + "\n"


def decode_json_line(line: str) -> dict[str, Any]:
    stripped = line.strip()
    if not stripped:
        raise RpcError("Empty RPC message")
    try:
        loaded = json.loads(stripped)
    except json.JSONDecodeError as exc:
        raise RpcError(f"Invalid JSON: {exc.msg}") from exc
    if not isinstance(loaded, dict):
        raise RpcError("RPC message must be a JSON object")
    return loaded


def parse_rpc_command(line: str) -> dict[str, Any]:
    command = decode_json_line(line)
    command_type = command.get("type")
    if not isinstance(command_type, str) or not command_type:
        raise RpcError('RPC command must include a non-empty string "type"')
    return command


def make_response(
    *,
    command: str,
    success: bool,
    request_id: str | int | None = None,
    data: Any = None,
    error: str | None = None,
) -> dict[str, Any]:
    response: dict[str, Any] = {
        "type": "response",
        "command": command,
        "success": bool(success),
    }
    if request_id is not None:
        response["id"] = request_id
    if success:
        if data is not None:
            response["data"] = data
    else:
        response["error"] = error or "Unknown RPC error"
    return response


encodeJsonLine = encode_json_line
decodeJsonLine = decode_json_line
parseRpcCommand = parse_rpc_command
makeResponse = make_response
