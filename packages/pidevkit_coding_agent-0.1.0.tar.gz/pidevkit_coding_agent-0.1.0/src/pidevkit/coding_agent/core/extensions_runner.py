from __future__ import annotations

import inspect
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

EventHandler = Callable[[dict[str, Any]], dict[str, Any] | None | Awaitable[dict[str, Any] | None]]


@dataclass(frozen=True, slots=True)
class ExtensionWarning:
    extension: str
    message: str


class ExtensionRunner:
    def __init__(
        self,
        *,
        reserved_shortcuts: set[str] | None = None,
        reserved_commands: set[str] | None = None,
    ) -> None:
        self._reserved_shortcuts = set(reserved_shortcuts or set())
        self._reserved_commands = set(reserved_commands or set())
        self._tools: dict[str, dict[str, Any]] = {}
        self._commands: dict[str, dict[str, Any]] = {}
        self._flags: dict[str, dict[str, Any]] = {}
        self._shortcuts: dict[str, dict[str, Any]] = {}
        self._handlers: dict[str, list[EventHandler]] = {}
        self._message_renderers: dict[str, Callable[[Any], str]] = {}
        self._warnings: list[ExtensionWarning] = []
        self._errors: list[str] = []

    @property
    def warnings(self) -> list[ExtensionWarning]:
        return list(self._warnings)

    @property
    def errors(self) -> list[str]:
        return list(self._errors)

    def register_extension(self, extension: dict[str, Any]) -> None:
        name = str(extension.get("name") or extension.get("path") or "extension")

        for tool in extension.get("tools", []) or []:
            tool_name = str(tool.get("name", "")).strip()
            if tool_name:
                self._tools[tool_name] = dict(tool)

        for command in extension.get("commands", []) or []:
            command_name = str(command.get("name", "")).strip()
            if not command_name:
                continue
            if command_name in self._reserved_commands:
                self._warnings.append(
                    ExtensionWarning(
                        name,
                        f'Command "{command_name}" conflicts with reserved command',
                    )
                )
                continue
            self._commands[command_name] = dict(command)

        shortcuts = extension.get("shortcuts", {}) or {}
        if isinstance(shortcuts, dict):
            for key, value in shortcuts.items():
                shortcut = str(key)
                if shortcut in self._reserved_shortcuts:
                    self._warnings.append(ExtensionWarning(name, f'Shortcut "{shortcut}" is reserved'))
                    continue
                if shortcut in self._shortcuts:
                    self._warnings.append(ExtensionWarning(name, f'Shortcut "{shortcut}" already registered'))
                    continue
                self._shortcuts[shortcut] = {"extension": name, "action": value}

        for flag in extension.get("flags", []) or []:
            flag_name = str(flag.get("name", "")).strip()
            if flag_name:
                self._flags[flag_name] = dict(flag)

        for item in extension.get("messageRenderers", []) or []:
            renderer_type = str(item.get("type", "")).strip()
            renderer = item.get("render")
            if renderer_type and callable(renderer):
                self._message_renderers[renderer_type] = renderer

        handlers = extension.get("handlers", {}) or {}
        if isinstance(handlers, dict):
            for event_type, value in handlers.items():
                if callable(value):
                    self._handlers.setdefault(str(event_type), []).append(value)
                elif isinstance(value, list):
                    for handler in value:
                        if callable(handler):
                            self._handlers.setdefault(str(event_type), []).append(handler)

    def registerExtension(self, extension: dict[str, Any]) -> None:
        self.register_extension(extension)

    def get_tools(self) -> list[dict[str, Any]]:
        return [dict(tool) for tool in self._tools.values()]

    def getTools(self) -> list[dict[str, Any]]:
        return self.get_tools()

    def get_commands(self) -> list[dict[str, Any]]:
        return [dict(command) for command in self._commands.values()]

    def getCommands(self) -> list[dict[str, Any]]:
        return self.get_commands()

    def get_command(self, name: str) -> dict[str, Any] | None:
        command = self._commands.get(name)
        return dict(command) if command is not None else None

    def getCommand(self, name: str) -> dict[str, Any] | None:
        return self.get_command(name)

    def get_flags(self) -> list[dict[str, Any]]:
        return [dict(flag) for flag in self._flags.values()]

    def getFlags(self) -> list[dict[str, Any]]:
        return self.get_flags()

    def get_message_renderer(self, type_name: str) -> Callable[[Any], str] | None:
        return self._message_renderers.get(type_name)

    def getMessageRenderer(self, type_name: str) -> Callable[[Any], str] | None:
        return self.get_message_renderer(type_name)

    def has_handlers(self, event_type: str) -> bool:
        return bool(self._handlers.get(event_type))

    def hasHandlers(self, event_type: str) -> bool:
        return self.has_handlers(event_type)

    async def emit_tool_result(self, content: list[dict[str, Any]]) -> list[dict[str, Any]]:
        current_content = [dict(item) for item in content]
        for handler in self._handlers.get("tool_result", []):
            try:
                result = handler({"type": "tool_result", "content": current_content})
                if inspect.isawaitable(result):
                    result = await result
            except Exception as exc:  # noqa: BLE001
                self._errors.append(str(exc))
                continue

            if not isinstance(result, dict):
                continue
            patch = result.get("content")
            if isinstance(patch, list):
                current_content = [dict(item) for item in patch]
        return current_content

    async def emitToolResult(self, content: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return await self.emit_tool_result(content)
