from __future__ import annotations

import inspect
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, Literal

InputSource = Literal["interactive", "rpc", "extension"]
InputAction = Literal["continue", "transform", "handled"]

InputHandler = Callable[[dict[str, Any]], Awaitable[dict[str, Any] | None] | dict[str, Any] | None]
ErrorListener = Callable[[Exception], None]


@dataclass(frozen=True, slots=True)
class InputEventResult:
    action: InputAction
    text: str | None = None
    images: list[dict[str, Any]] | None = None


async def _invoke_handler(handler: InputHandler, event: dict[str, Any]) -> dict[str, Any] | None:
    result = handler(event)
    if inspect.isawaitable(result):
        awaited = await result
        return awaited if isinstance(awaited, dict) else None
    return result if isinstance(result, dict) else None


class InputEventRunner:
    def __init__(self, handlers: list[InputHandler] | None = None) -> None:
        self._handlers: list[InputHandler] = list(handlers or [])
        self._error_listeners: list[ErrorListener] = []

    def add_handler(self, handler: InputHandler) -> None:
        self._handlers.append(handler)

    def addHandler(self, handler: InputHandler) -> None:
        self.add_handler(handler)

    def on_error(self, listener: ErrorListener) -> None:
        self._error_listeners.append(listener)

    def onError(self, listener: ErrorListener) -> None:
        self.on_error(listener)

    def has_handlers(self) -> bool:
        return bool(self._handlers)

    def hasHandlers(self) -> bool:
        return self.has_handlers()

    async def emit_input(
        self,
        text: str,
        images: list[dict[str, Any]] | None,
        source: InputSource,
    ) -> InputEventResult:
        current_text = text
        current_images = images

        for handler in self._handlers:
            event = {
                "type": "input",
                "text": current_text,
                "images": current_images,
                "source": source,
            }
            try:
                result = await _invoke_handler(handler, event)
            except Exception as exc:  # noqa: BLE001
                for listener in self._error_listeners:
                    listener(exc)
                continue

            if result is None:
                continue

            action = result.get("action")
            if action == "handled":
                return InputEventResult(
                    action="handled",
                    text=str(result.get("text")) if isinstance(result.get("text"), str) else None,
                    images=result.get("images") if isinstance(result.get("images"), list) else None,
                )
            if action == "transform":
                next_text = result.get("text")
                if isinstance(next_text, str):
                    current_text = next_text
                if "images" in result:
                    images_value = result.get("images")
                    if images_value is None or isinstance(images_value, list):
                        current_images = images_value
                continue

        if current_text != text or current_images != images:
            return InputEventResult(action="transform", text=current_text, images=current_images)
        return InputEventResult(action="continue")

    async def emitInput(
        self,
        text: str,
        images: list[dict[str, Any]] | None,
        source: InputSource,
    ) -> InputEventResult:
        return await self.emit_input(text, images, source)


async def emit_input(
    handlers: list[InputHandler],
    *,
    text: str,
    images: list[dict[str, Any]] | None,
    source: InputSource,
) -> InputEventResult:
    runner = InputEventRunner(handlers)
    return await runner.emit_input(text, images, source)


emitInput = emit_input
