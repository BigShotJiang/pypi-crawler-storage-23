from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

from pidevkit.ai.types import Model
from pidevkit.coding_agent.cli.args import is_valid_thinking_level

DEFAULT_THINKING_LEVEL = "off"

default_model_per_provider: dict[str, str] = {
    "amazon-bedrock": "us.anthropic.claude-opus-4-6-v1",
    "anthropic": "claude-opus-4-6",
    "openai": "gpt-5.1-codex",
    "azure-openai-responses": "gpt-5.2",
    "openai-codex": "gpt-5.3-codex",
    "google": "gemini-2.5-pro",
    "google-gemini-cli": "gemini-2.5-pro",
    "google-antigravity": "gemini-3-pro-high",
    "google-vertex": "gemini-3-pro-preview",
    "github-copilot": "gpt-4o",
    "openrouter": "openai/gpt-5.1-codex",
    "vercel-ai-gateway": "anthropic/claude-opus-4-6",
    "xai": "grok-4-fast-non-reasoning",
    "groq": "openai/gpt-oss-120b",
    "cerebras": "zai-glm-4.6",
    "zai": "glm-4.6",
    "mistral": "devstral-medium-latest",
    "minimax": "MiniMax-M2.1",
    "minimax-cn": "MiniMax-M2.1",
    "huggingface": "moonshotai/Kimi-K2.5",
    "opencode": "claude-opus-4-6",
    "kimi-coding": "kimi-k2-thinking",
}


def _is_alias(model_id: str) -> bool:
    if model_id.endswith("-latest"):
        return True

    if len(model_id) >= 9 and model_id[-9] == "-" and model_id[-8:].isdigit():
        return False
    return True


def _model_matches_provider_and_id(model: Model, provider: str, model_id: str) -> bool:
    return (
        str(model.get("provider", "")).lower() == provider.lower()
        and str(model.get("id", "")).lower() == model_id.lower()
    )


def _try_match_model(model_pattern: str, available_models: list[Model]) -> Model | None:
    slash_index = model_pattern.find("/")
    if slash_index != -1:
        provider = model_pattern[:slash_index]
        model_id = model_pattern[slash_index + 1 :]
        for model in available_models:
            if _model_matches_provider_and_id(model, provider, model_id):
                return model

    lower_pattern = model_pattern.lower()
    for model in available_models:
        if str(model.get("id", "")).lower() == lower_pattern:
            return model

    matches = [
        model
        for model in available_models
        if lower_pattern in str(model.get("id", "")).lower()
        or lower_pattern in str(model.get("name", "")).lower()
    ]
    if not matches:
        return None

    aliases = [model for model in matches if _is_alias(str(model.get("id", "")))]
    if aliases:
        aliases.sort(key=lambda model: str(model.get("id", "")), reverse=True)
        return aliases[0]

    matches.sort(key=lambda model: str(model.get("id", "")), reverse=True)
    return matches[0]


@dataclass(frozen=True, slots=True)
class ParsedModelResult:
    model: Model | None
    thinking_level: str | None = None
    warning: str | None = None

    @property
    def thinkingLevel(self) -> str | None:
        return self.thinking_level


def parse_model_pattern(
    pattern: str,
    available_models: list[Model],
    *,
    allow_invalid_thinking_level_fallback: bool = True,
) -> ParsedModelResult:
    exact_match = _try_match_model(pattern, available_models)
    if exact_match is not None:
        return ParsedModelResult(model=exact_match, thinking_level=None, warning=None)

    last_colon_index = pattern.rfind(":")
    if last_colon_index == -1:
        return ParsedModelResult(model=None, thinking_level=None, warning=None)

    prefix = pattern[:last_colon_index]
    suffix = pattern[last_colon_index + 1 :]

    if is_valid_thinking_level(suffix):
        result = parse_model_pattern(
            prefix,
            available_models,
            allow_invalid_thinking_level_fallback=allow_invalid_thinking_level_fallback,
        )
        if result.model is None:
            return result
        if result.warning is not None:
            return ParsedModelResult(model=result.model, thinking_level=None, warning=result.warning)
        return ParsedModelResult(model=result.model, thinking_level=suffix, warning=None)

    if not allow_invalid_thinking_level_fallback:
        return ParsedModelResult(model=None, thinking_level=None, warning=None)

    result = parse_model_pattern(
        prefix,
        available_models,
        allow_invalid_thinking_level_fallback=allow_invalid_thinking_level_fallback,
    )
    if result.model is None:
        return result
    return ParsedModelResult(
        model=result.model,
        thinking_level=None,
        warning=f'Invalid thinking level "{suffix}" in pattern "{pattern}". Using default instead.',
    )


class _RegistryGetAll(Protocol):
    def get_all(self) -> list[Model]: ...


class _RegistryGetAllCompat(Protocol):
    def getAll(self) -> list[Model]: ...


@dataclass(frozen=True, slots=True)
class ResolveCliModelResult:
    model: Model | None
    thinking_level: str | None = None
    warning: str | None = None
    error: str | None = None

    @property
    def thinkingLevel(self) -> str | None:
        return self.thinking_level


def _registry_get_all(model_registry: Any) -> list[Model]:
    if hasattr(model_registry, "get_all"):
        return list(model_registry.get_all())
    if hasattr(model_registry, "getAll"):
        return list(model_registry.getAll())
    return []


def resolve_cli_model(
    *,
    cli_provider: str | None = None,
    cli_model: str | None = None,
    model_registry: _RegistryGetAll | _RegistryGetAllCompat | Any,
) -> ResolveCliModelResult:
    if not cli_model:
        return ResolveCliModelResult(model=None, thinking_level=None, warning=None, error=None)

    available_models = _registry_get_all(model_registry)
    if not available_models:
        return ResolveCliModelResult(
            model=None,
            thinking_level=None,
            warning=None,
            error="No models available. Check your installation or add models to models.json.",
        )

    provider_map: dict[str, str] = {}
    for model in available_models:
        provider = str(model.get("provider", "")).strip()
        if provider:
            provider_map[provider.lower()] = provider

    provider: str | None = None
    if cli_provider:
        provider = provider_map.get(cli_provider.lower())
        if provider is None:
            return ResolveCliModelResult(
                model=None,
                thinking_level=None,
                warning=None,
                error=f'Unknown provider "{cli_provider}". Use --list-models to see available providers/models.',
            )

    if provider is None:
        cli_model_lower = cli_model.lower()
        for model in available_models:
            model_id = str(model.get("id", "")).lower()
            provider_and_id = f'{str(model.get("provider", "")).lower()}/{model_id}'
            if model_id == cli_model_lower or provider_and_id == cli_model_lower:
                return ResolveCliModelResult(model=model, thinking_level=None, warning=None, error=None)

    pattern = cli_model
    if provider is None:
        slash_index = cli_model.find("/")
        if slash_index != -1:
            maybe_provider = cli_model[:slash_index]
            canonical = provider_map.get(maybe_provider.lower())
            if canonical is not None:
                provider = canonical
                pattern = cli_model[slash_index + 1 :]
    else:
        prefix = f"{provider}/"
        if cli_model.lower().startswith(prefix.lower()):
            pattern = cli_model[len(prefix) :]

    if provider:
        candidates = [model for model in available_models if str(model.get("provider", "")) == provider]
    else:
        candidates = available_models
    parsed = parse_model_pattern(
        pattern,
        candidates,
        allow_invalid_thinking_level_fallback=False,
    )

    if parsed.model is None:
        display = f"{provider}/{pattern}" if provider else cli_model
        return ResolveCliModelResult(
            model=None,
            thinking_level=None,
            warning=parsed.warning,
            error=f'Model "{display}" not found. Use --list-models to see available models.',
        )

    return ResolveCliModelResult(
        model=parsed.model,
        thinking_level=parsed.thinking_level,
        warning=parsed.warning,
        error=None,
    )


@dataclass(frozen=True, slots=True)
class ScopedModel:
    model: Model
    thinking_level: str | None = None

    @property
    def thinkingLevel(self) -> str | None:
        return self.thinking_level


@dataclass(frozen=True, slots=True)
class InitialModelResult:
    model: Model | None
    thinking_level: str
    fallback_message: str | None = None

    @property
    def thinkingLevel(self) -> str:
        return self.thinking_level

    @property
    def fallbackMessage(self) -> str | None:
        return self.fallback_message


async def _registry_get_available(model_registry: Any) -> list[Model]:
    if hasattr(model_registry, "get_available"):
        return list(await model_registry.get_available())
    if hasattr(model_registry, "getAvailable"):
        return list(await model_registry.getAvailable())
    return []


def _registry_find(model_registry: Any, provider: str, model_id: str) -> Model | None:
    if hasattr(model_registry, "find"):
        found = model_registry.find(provider, model_id)
    elif hasattr(model_registry, "get"):
        found = model_registry.get(provider, model_id)
    else:
        found = None
    if found is None:
        return None
    return dict(found)


async def find_initial_model(
    *,
    scoped_models: list[ScopedModel],
    is_continuing: bool,
    model_registry: Any,
    cli_provider: str | None = None,
    cli_model: str | None = None,
    default_provider: str | None = None,
    default_model_id: str | None = None,
    default_thinking_level: str | None = None,
) -> InitialModelResult:
    if cli_provider and cli_model:
        found = _registry_find(model_registry, cli_provider, cli_model)
        if found is not None:
            return InitialModelResult(found, DEFAULT_THINKING_LEVEL, None)

    if scoped_models and not is_continuing:
        first = scoped_models[0]
        return InitialModelResult(
            model=first.model,
            thinking_level=first.thinking_level or default_thinking_level or DEFAULT_THINKING_LEVEL,
            fallback_message=None,
        )

    if default_provider and default_model_id:
        found = _registry_find(model_registry, default_provider, default_model_id)
        if found is not None:
            return InitialModelResult(
                model=found,
                thinking_level=default_thinking_level or DEFAULT_THINKING_LEVEL,
                fallback_message=None,
            )

    available_models = await _registry_get_available(model_registry)
    if available_models:
        for provider, model_id in default_model_per_provider.items():
            for model in available_models:
                if str(model.get("provider", "")) == provider and str(model.get("id", "")) == model_id:
                    return InitialModelResult(
                        model=model,
                        thinking_level=DEFAULT_THINKING_LEVEL,
                        fallback_message=None,
                    )
        return InitialModelResult(
            model=available_models[0],
            thinking_level=DEFAULT_THINKING_LEVEL,
            fallback_message=None,
        )

    return InitialModelResult(model=None, thinking_level=DEFAULT_THINKING_LEVEL, fallback_message=None)


parseModelPattern = parse_model_pattern
resolveCliModel = resolve_cli_model
findInitialModel = find_initial_model
