from __future__ import annotations

import base64
import io
import struct
from dataclasses import dataclass
from typing import Any

try:
    from PIL import Image
except Exception:  # noqa: BLE001
    Image = None  # type: ignore[assignment]

DEFAULT_MAX_BYTES = int(4.5 * 1024 * 1024)


@dataclass(frozen=True, slots=True)
class ImageResizeOptions:
    max_width: int = 2000
    max_height: int = 2000
    max_bytes: int = DEFAULT_MAX_BYTES
    jpeg_quality: int = 80

    @property
    def maxWidth(self) -> int:
        return self.max_width

    @property
    def maxHeight(self) -> int:
        return self.max_height

    @property
    def maxBytes(self) -> int:
        return self.max_bytes

    @property
    def jpegQuality(self) -> int:
        return self.jpeg_quality


@dataclass(frozen=True, slots=True)
class ResizedImage:
    data: str
    mime_type: str
    original_width: int
    original_height: int
    width: int
    height: int
    was_resized: bool

    @property
    def mimeType(self) -> str:
        return self.mime_type

    @property
    def originalWidth(self) -> int:
        return self.original_width

    @property
    def originalHeight(self) -> int:
        return self.original_height

    @property
    def wasResized(self) -> bool:
        return self.was_resized


def _decode_base64(data: str) -> bytes:
    return base64.b64decode(data.encode("ascii"), validate=False)


def _encode_base64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _probe_png_dimensions(data: bytes) -> tuple[int, int] | None:
    if len(data) < 24:
        return None
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        return None
    width, height = struct.unpack(">II", data[16:24])
    return int(width), int(height)


def _probe_jpeg_dimensions(data: bytes) -> tuple[int, int] | None:
    if len(data) < 4 or data[0:2] != b"\xff\xd8":
        return None

    idx = 2
    while idx + 9 < len(data):
        if data[idx] != 0xFF:
            idx += 1
            continue
        marker = data[idx + 1]
        idx += 2

        if marker in {0xD8, 0xD9, 0x01} or 0xD0 <= marker <= 0xD7:
            continue

        if idx + 2 > len(data):
            return None
        segment_length = (data[idx] << 8) | data[idx + 1]
        if segment_length < 2 or idx + segment_length > len(data):
            return None

        if marker in {
            0xC0,
            0xC1,
            0xC2,
            0xC3,
            0xC5,
            0xC6,
            0xC7,
            0xC9,
            0xCA,
            0xCB,
            0xCD,
            0xCE,
            0xCF,
        }:
            if idx + 7 > len(data):
                return None
            height = (data[idx + 3] << 8) | data[idx + 4]
            width = (data[idx + 5] << 8) | data[idx + 6]
            return int(width), int(height)

        idx += segment_length

    return None


def _probe_dimensions(data: bytes, mime_type: str) -> tuple[int, int]:
    lowered = mime_type.lower()
    if lowered == "image/png":
        dims = _probe_png_dimensions(data)
        if dims is not None:
            return dims
    if lowered in {"image/jpeg", "image/jpg"}:
        dims = _probe_jpeg_dimensions(data)
        if dims is not None:
            return dims
    dims = _probe_png_dimensions(data) or _probe_jpeg_dimensions(data)
    if dims is not None:
        return dims
    return 0, 0


def convert_to_png(base64_data: str, mime_type: str) -> dict[str, str] | None:
    if mime_type == "image/png":
        return {"data": base64_data, "mimeType": mime_type}

    if Image is None:
        return None

    try:
        source = _decode_base64(base64_data)
        with Image.open(io.BytesIO(source)) as image:
            out = io.BytesIO()
            image.save(out, format="PNG")
        return {"data": _encode_base64(out.getvalue()), "mimeType": "image/png"}
    except Exception:  # noqa: BLE001
        return None


def _pick_smaller(
    a: tuple[bytes, str],
    b: tuple[bytes, str],
) -> tuple[bytes, str]:
    return a if len(a[0]) <= len(b[0]) else b


def _encode_candidate(image: Any, fmt: str, *, quality: int = 80) -> bytes:
    out = io.BytesIO()
    if fmt == "JPEG":
        image.convert("RGB").save(out, format=fmt, quality=quality, optimize=True)
    else:
        image.save(out, format=fmt, optimize=True)
    return out.getvalue()


def _resize_dimensions(width: int, height: int, max_width: int, max_height: int) -> tuple[int, int]:
    target_width = width
    target_height = height

    if target_width > max_width:
        target_height = int(round(target_height * max_width / target_width))
        target_width = max_width
    if target_height > max_height:
        target_width = int(round(target_width * max_height / target_height))
        target_height = max_height

    return max(1, target_width), max(1, target_height)


def resize_image(img: dict[str, Any], options: ImageResizeOptions | dict[str, Any] | None = None) -> ResizedImage:
    if isinstance(options, dict):
        opts = ImageResizeOptions(
            max_width=int(options.get("maxWidth", 2000)),
            max_height=int(options.get("maxHeight", 2000)),
            max_bytes=int(options.get("maxBytes", DEFAULT_MAX_BYTES)),
            jpeg_quality=int(options.get("jpegQuality", 80)),
        )
    elif isinstance(options, ImageResizeOptions):
        opts = options
    else:
        opts = ImageResizeOptions()

    data = str(img.get("data", ""))
    mime_type = str(img.get("mimeType", "image/png"))
    source = _decode_base64(data)
    source_size = len(source)
    original_width, original_height = _probe_dimensions(source, mime_type)

    if Image is None:
        return ResizedImage(
            data=data,
            mime_type=mime_type,
            original_width=original_width,
            original_height=original_height,
            width=original_width,
            height=original_height,
            was_resized=False,
        )

    try:
        with Image.open(io.BytesIO(source)) as image:
            original_width, original_height = image.size
            if (
                original_width <= opts.max_width
                and original_height <= opts.max_height
                and source_size <= opts.max_bytes
            ):
                return ResizedImage(
                    data=data,
                    mime_type=mime_type,
                    original_width=original_width,
                    original_height=original_height,
                    width=original_width,
                    height=original_height,
                    was_resized=False,
                )

            target_width, target_height = _resize_dimensions(
                original_width,
                original_height,
                opts.max_width,
                opts.max_height,
            )

            quality_steps = [opts.jpeg_quality, 85, 70, 55, 40]
            scale_steps = [1.0, 0.75, 0.5, 0.35, 0.25]

            best_buffer = source
            best_mime = mime_type
            final_width = target_width
            final_height = target_height

            for scale in scale_steps:
                scaled_width = max(1, int(round(target_width * scale)))
                scaled_height = max(1, int(round(target_height * scale)))
                if scaled_width < 1 or scaled_height < 1:
                    continue

                resized = image.resize((scaled_width, scaled_height))
                for quality in quality_steps:
                    png_buffer = _encode_candidate(resized, "PNG")
                    jpeg_buffer = _encode_candidate(resized, "JPEG", quality=quality)
                    picked_buffer, picked_mime = _pick_smaller(
                        (png_buffer, "image/png"),
                        (jpeg_buffer, "image/jpeg"),
                    )

                    if len(picked_buffer) < len(best_buffer) or (
                        len(best_buffer) == source_size and len(picked_buffer) <= len(source)
                    ):
                        best_buffer = picked_buffer
                        best_mime = picked_mime
                        final_width = scaled_width
                        final_height = scaled_height

                    if len(picked_buffer) <= opts.max_bytes:
                        return ResizedImage(
                            data=_encode_base64(picked_buffer),
                            mime_type=picked_mime,
                            original_width=original_width,
                            original_height=original_height,
                            width=scaled_width,
                            height=scaled_height,
                            was_resized=True,
                        )

                if scaled_width < 100 or scaled_height < 100:
                    break

            return ResizedImage(
                data=_encode_base64(best_buffer),
                mime_type=best_mime,
                original_width=original_width,
                original_height=original_height,
                width=final_width,
                height=final_height,
                was_resized=True,
            )
    except Exception:  # noqa: BLE001
        return ResizedImage(
            data=data,
            mime_type=mime_type,
            original_width=0,
            original_height=0,
            width=0,
            height=0,
            was_resized=False,
        )


def format_dimension_note(result: ResizedImage | dict[str, Any]) -> str | None:
    was_resized = bool(result.was_resized if isinstance(result, ResizedImage) else result.get("wasResized"))
    if not was_resized:
        return None

    if isinstance(result, ResizedImage):
        original_width = result.original_width
        original_height = result.original_height
        width = result.width
        height = result.height
    else:
        original_width = int(result.get("originalWidth", 0))
        original_height = int(result.get("originalHeight", 0))
        width = int(result.get("width", 0))
        height = int(result.get("height", 0))

    scale = (original_width / width) if width else 1.0
    return (
        f"[Image: original {original_width}x{original_height}, displayed at {width}x{height}. "
        f"Multiply coordinates by {scale:.2f} to map to original image.]"
    )


convertToPng = convert_to_png
resizeImage = resize_image
formatDimensionNote = format_dimension_note
