from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from pathlib import Path
from threading import RLock
from typing import Any, Callable, Literal, TypedDict

from pidevkit.ai.stream import get_env_api_key

from .resolve_config_value import resolve_config_value

CredentialType = Literal["api_key", "oauth"]


class ApiKeyCredential(TypedDict):
    type: Literal["api_key"]
    key: str


class OAuthCredential(TypedDict, total=False):
    type: Literal["oauth"]
    refresh: str
    access: str
    expires: int


AuthCredential = ApiKeyCredential | OAuthCredential
AuthStorageData = dict[str, AuthCredential]


@dataclass(frozen=True, slots=True)
class LockResult:
    result: Any
    next: str | None = None


class AuthStorageBackend:
    def with_lock(self, fn: Callable[[str | None], LockResult]) -> Any:
        raise NotImplementedError

    async def with_lock_async(self, fn: Callable[[str | None], asyncio.Future | Any]) -> Any:  # noqa: ANN401
        raise NotImplementedError


class FileAuthStorageBackend(AuthStorageBackend):
    def __init__(self, auth_path: str | Path) -> None:
        self.auth_path = Path(auth_path)
        self._lock = RLock()

    def _ensure_file(self) -> None:
        self.auth_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.auth_path.exists():
            self.auth_path.write_text("{}", encoding="utf-8")

    def with_lock(self, fn: Callable[[str | None], LockResult]) -> Any:
        with self._lock:
            self._ensure_file()
            current = self.auth_path.read_text(encoding="utf-8") if self.auth_path.exists() else None
            payload = fn(current)
            if payload.next is not None:
                self.auth_path.write_text(payload.next, encoding="utf-8")
            return payload.result

    async def with_lock_async(self, fn: Callable[[str | None], asyncio.Future | Any]) -> Any:  # noqa: ANN401
        with self._lock:
            self._ensure_file()
            current = self.auth_path.read_text(encoding="utf-8") if self.auth_path.exists() else None
            value = fn(current)
            payload = await value if asyncio.iscoroutine(value) else value
            if payload.next is not None:
                self.auth_path.write_text(payload.next, encoding="utf-8")
            return payload.result


class InMemoryAuthStorageBackend(AuthStorageBackend):
    def __init__(self, value: str | None = None) -> None:
        self.value = value
        self._lock = RLock()

    def with_lock(self, fn: Callable[[str | None], LockResult]) -> Any:
        with self._lock:
            payload = fn(self.value)
            if payload.next is not None:
                self.value = payload.next
            return payload.result

    async def with_lock_async(self, fn: Callable[[str | None], asyncio.Future | Any]) -> Any:  # noqa: ANN401
        with self._lock:
            value = fn(self.value)
            payload = await value if asyncio.iscoroutine(value) else value
            if payload.next is not None:
                self.value = payload.next
            return payload.result


class AuthStorage:
    def __init__(self, backend: AuthStorageBackend) -> None:
        self._backend = backend
        self._data: AuthStorageData = {}
        self._runtime_overrides: dict[str, str] = {}
        self._fallback_resolver: Callable[[str], str | None] | None = None
        self._errors: list[Exception] = []
        self._load_error: Exception | None = None
        self.reload()

    @classmethod
    def create(cls, auth_path: str | Path) -> AuthStorage:
        return cls(FileAuthStorageBackend(auth_path))

    @classmethod
    def from_storage(cls, backend: AuthStorageBackend) -> AuthStorage:
        return cls(backend)

    @classmethod
    def in_memory(cls, data: AuthStorageData | None = None) -> AuthStorage:
        value = json.dumps(data or {}, ensure_ascii=False, indent=2)
        return cls(InMemoryAuthStorageBackend(value))

    def _parse_storage_data(self, content: str | None) -> AuthStorageData:
        if not content:
            return {}
        parsed = json.loads(content)
        if not isinstance(parsed, dict):
            return {}
        return parsed  # type: ignore[return-value]

    def _record_error(self, error: Exception) -> None:
        self._errors.append(error)

    def reload(self) -> None:
        content: str | None = None
        try:
            def _capture(current: str | None) -> LockResult:
                nonlocal content
                content = current
                return LockResult(result=None, next=None)

            self._backend.with_lock(_capture)
        except Exception as exc:  # noqa: BLE001
            self._load_error = exc
            self._record_error(exc)
            return

        try:
            self._data = self._parse_storage_data(content)
            self._load_error = None
        except Exception as exc:  # noqa: BLE001
            self._load_error = exc
            self._record_error(exc)

    def _persist_provider_change(self, provider: str, credential: AuthCredential | None) -> None:
        if self._load_error is not None:
            return

        try:
            def _mutate(current: str | None) -> LockResult:
                merged = self._parse_storage_data(current)
                if credential is None:
                    merged.pop(provider, None)
                else:
                    merged[provider] = credential
                return LockResult(result=None, next=json.dumps(merged, ensure_ascii=False, indent=2))

            self._backend.with_lock(_mutate)
        except Exception as exc:  # noqa: BLE001
            self._record_error(exc if isinstance(exc, Exception) else Exception(str(exc)))

    def set_runtime_api_key(self, provider: str, api_key: str) -> None:
        self._runtime_overrides[provider] = api_key

    def setRuntimeApiKey(self, provider: str, api_key: str) -> None:
        self.set_runtime_api_key(provider, api_key)

    def remove_runtime_api_key(self, provider: str) -> None:
        self._runtime_overrides.pop(provider, None)

    def removeRuntimeApiKey(self, provider: str) -> None:
        self.remove_runtime_api_key(provider)

    def set_fallback_resolver(self, resolver: Callable[[str], str | None]) -> None:
        self._fallback_resolver = resolver

    def setFallbackResolver(self, resolver: Callable[[str], str | None]) -> None:
        self.set_fallback_resolver(resolver)

    def get(self, provider: str) -> AuthCredential | None:
        value = self._data.get(provider)
        return value.copy() if isinstance(value, dict) else None

    def set(self, provider: str, credential: AuthCredential) -> None:
        self._data[provider] = credential
        self._persist_provider_change(provider, credential)

    def remove(self, provider: str) -> None:
        self._data.pop(provider, None)
        self._persist_provider_change(provider, None)

    def list(self) -> list[str]:
        return list(self._data.keys())

    def has(self, provider: str) -> bool:
        return provider in self._data

    def has_auth(self, provider: str) -> bool:
        if provider in self._runtime_overrides:
            return True
        if provider in self._data:
            return True
        if get_env_api_key(provider):
            return True
        fallback = self._fallback_resolver(provider) if self._fallback_resolver else None
        return bool(fallback)

    def hasAuth(self, provider: str) -> bool:
        return self.has_auth(provider)

    def get_all(self) -> AuthStorageData:
        return dict(self._data)

    def getAll(self) -> AuthStorageData:
        return self.get_all()

    def drain_errors(self) -> list[Exception]:
        drained = list(self._errors)
        self._errors.clear()
        return drained

    def drainErrors(self) -> list[Exception]:
        return self.drain_errors()

    def _resolve_api_key_credential(self, credential: AuthCredential) -> str | None:
        if credential.get("type") != "api_key":
            return None
        key = credential.get("key")
        if not isinstance(key, str):
            return None
        return resolve_config_value(key)

    async def get_api_key(self, provider: str) -> str | None:
        runtime = self._runtime_overrides.get(provider)
        if runtime:
            return runtime

        credential = self._data.get(provider)
        if isinstance(credential, dict):
            resolved = self._resolve_api_key_credential(credential)
            if resolved:
                return resolved

        env = get_env_api_key(provider)
        if env:
            return env

        if self._fallback_resolver:
            fallback = self._fallback_resolver(provider)
            if fallback:
                return fallback

        return None

    async def getApiKey(self, provider: str) -> str | None:
        return await self.get_api_key(provider)

    # OAuth support is intentionally minimal in this port.
    async def login(self, provider_id: str, callbacks: Any) -> None:  # noqa: ANN401
        raise NotImplementedError(f"OAuth login is not implemented for provider {provider_id}")

    def logout(self, provider: str) -> None:
        self.remove(provider)

    def get_oauth_providers(self) -> list[Any]:  # noqa: ANN401
        return []

    def getOAuthProviders(self) -> list[Any]:  # noqa: ANN401
        return self.get_oauth_providers()


__all__ = [
    "ApiKeyCredential",
    "AuthCredential",
    "AuthStorage",
    "AuthStorageBackend",
    "AuthStorageData",
    "FileAuthStorageBackend",
    "InMemoryAuthStorageBackend",
    "OAuthCredential",
]
