from __future__ import annotations

from typing import Literal, TypedDict


class ResourceDiagnostic(TypedDict, total=False):
    type: Literal["warning", "error"]
    message: str
    path: str


class ResourceCollision(TypedDict, total=False):
    path: str
    message: str


__all__ = ["ResourceCollision", "ResourceDiagnostic"]
