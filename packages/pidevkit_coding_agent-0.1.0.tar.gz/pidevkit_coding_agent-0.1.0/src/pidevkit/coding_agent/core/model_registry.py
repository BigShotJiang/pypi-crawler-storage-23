from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from pidevkit.ai.models import get_models, get_providers
from pidevkit.ai.types import Model

from .auth_storage import AuthStorage
from .resolve_config_value import clear_config_value_cache, resolve_config_value, resolve_headers


def _merge_compat(base_compat: dict[str, Any] | None, override_compat: dict[str, Any] | None) -> dict[str, Any] | None:
    if not override_compat:
        return dict(base_compat) if base_compat else None

    merged = dict(base_compat or {})
    for key, value in override_compat.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            nested = dict(merged[key])
            nested.update(value)
            merged[key] = nested
        else:
            merged[key] = value
    return merged


def _apply_model_override(model: Model, override: dict[str, Any]) -> Model:
    result: Model = dict(model)
    for key in ("name", "reasoning", "input", "contextWindow", "maxTokens", "api", "baseUrl"):
        if key in override:
            result[key] = override[key]  # type: ignore[typeddict-item]

    if "cost" in override and isinstance(override["cost"], dict):
        existing_cost = dict(result.get("cost", {}))
        existing_cost.update(override["cost"])
        result["cost"] = existing_cost  # type: ignore[typeddict-item]

    if "headers" in override and isinstance(override["headers"], dict):
        resolved = resolve_headers(override["headers"])
        merged_headers = dict(result.get("headers", {}))
        if resolved:
            merged_headers.update(resolved)
        if merged_headers:
            result["headers"] = merged_headers  # type: ignore[typeddict-item]

    if "compat" in override and isinstance(override["compat"], dict):
        compat = _merge_compat(result.get("compat"), override["compat"])  # type: ignore[arg-type]
        if compat:
            result["compat"] = compat  # type: ignore[typeddict-item]

    return result


def clear_api_key_cache() -> None:
    clear_config_value_cache()


def clearApiKeyCache() -> None:
    clear_api_key_cache()


@dataclass
class _CustomModelsResult:
    models: list[Model]
    overrides: dict[str, dict[str, Any]]
    model_overrides: dict[str, dict[str, dict[str, Any]]]
    error: str | None = None


class ModelRegistry:
    def __init__(self, auth_storage: AuthStorage, models_json_path: str | Path | None = None) -> None:
        self.auth_storage = auth_storage
        self.models_json_path = Path(models_json_path) if models_json_path else None
        self.models: list[Model] = []
        self.custom_provider_api_keys: dict[str, str] = {}
        self.load_error: str | None = None

        self.auth_storage.set_fallback_resolver(self._resolve_custom_provider_key)
        self._load_models()

    def _resolve_custom_provider_key(self, provider: str) -> str | None:
        raw = self.custom_provider_api_keys.get(provider)
        if not raw:
            return None
        return resolve_config_value(raw)

    def refresh(self) -> None:
        self.custom_provider_api_keys.clear()
        self.load_error = None
        self._load_models()

    def get_error(self) -> str | None:
        return self.load_error

    def getError(self) -> str | None:
        return self.get_error()

    def get_all(self) -> list[Model]:
        return [dict(model) for model in self.models]

    def getAll(self) -> list[Model]:
        return self.get_all()

    def get(self, provider: str, model_id: str) -> Model | None:
        for model in self.models:
            if model.get("provider") == provider and model.get("id") == model_id:
                return dict(model)
        return None

    def _load_builtin_models(
        self,
        overrides: dict[str, dict[str, Any]],
        model_overrides: dict[str, dict[str, dict[str, Any]]],
    ) -> list[Model]:
        loaded: list[Model] = []
        for provider in get_providers():
            for model in get_models(provider):
                current: Model = dict(model)

                provider_override = overrides.get(provider)
                if provider_override:
                    if provider_override.get("baseUrl"):
                        current["baseUrl"] = provider_override["baseUrl"]  # type: ignore[typeddict-item]
                    if provider_override.get("headers"):
                        resolved_headers = resolve_headers(provider_override["headers"])
                        merged = dict(current.get("headers", {}))
                        if resolved_headers:
                            merged.update(resolved_headers)
                        if merged:
                            current["headers"] = merged  # type: ignore[typeddict-item]

                per_model_overrides = model_overrides.get(provider, {})
                override = per_model_overrides.get(str(model.get("id")))
                if override:
                    current = _apply_model_override(current, override)

                loaded.append(current)
        return loaded

    def _merge_custom_models(self, built_in: list[Model], custom: list[Model]) -> list[Model]:
        merged = [dict(model) for model in built_in]
        for custom_model in custom:
            provider = custom_model.get("provider")
            model_id = custom_model.get("id")
            index = next(
                (
                    i
                    for i, model in enumerate(merged)
                    if model.get("provider") == provider and model.get("id") == model_id
                ),
                -1,
            )
            if index >= 0:
                merged[index] = dict(custom_model)
            else:
                merged.append(dict(custom_model))
        return merged

    def _load_custom_models(self, path: Path) -> _CustomModelsResult:
        if not path.exists():
            return _CustomModelsResult(models=[], overrides={}, model_overrides={}, error=None)

        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            return _CustomModelsResult(models=[], overrides={}, model_overrides={}, error=f"Failed to parse models.json: {exc}")
        except Exception as exc:  # noqa: BLE001
            return _CustomModelsResult(models=[], overrides={}, model_overrides={}, error=f"Failed to load models.json: {exc}")

        providers = raw.get("providers")
        if not isinstance(providers, dict):
            return _CustomModelsResult(models=[], overrides={}, model_overrides={}, error="Invalid models.json: missing providers object")

        custom_models: list[Model] = []
        overrides: dict[str, dict[str, Any]] = {}
        per_model_overrides: dict[str, dict[str, dict[str, Any]]] = {}

        for provider_name, provider_cfg in providers.items():
            if not isinstance(provider_cfg, dict):
                continue

            override: dict[str, Any] = {}
            if isinstance(provider_cfg.get("baseUrl"), str):
                override["baseUrl"] = provider_cfg["baseUrl"]
            if isinstance(provider_cfg.get("headers"), dict):
                override["headers"] = provider_cfg["headers"]
            if isinstance(provider_cfg.get("apiKey"), str):
                override["apiKey"] = provider_cfg["apiKey"]
                self.custom_provider_api_keys[provider_name] = provider_cfg["apiKey"]
            if override:
                overrides[provider_name] = override

            model_override_cfg = provider_cfg.get("modelOverrides")
            if isinstance(model_override_cfg, dict):
                normalized: dict[str, dict[str, Any]] = {}
                for model_id, model_override in model_override_cfg.items():
                    if isinstance(model_override, dict):
                        normalized[model_id] = model_override
                if normalized:
                    per_model_overrides[provider_name] = normalized

            models_cfg = provider_cfg.get("models", [])
            if not isinstance(models_cfg, list):
                continue

            for model_def in models_cfg:
                if not isinstance(model_def, dict):
                    continue
                model_id = model_def.get("id")
                if not isinstance(model_id, str) or not model_id:
                    continue

                provider_api = provider_cfg.get("api")
                model_api = model_def.get("api")
                api = model_api if isinstance(model_api, str) else provider_api if isinstance(provider_api, str) else None
                if not api:
                    continue

                base_url = provider_cfg.get("baseUrl")
                if not isinstance(base_url, str) or not base_url:
                    continue

                provider_headers = provider_cfg.get("headers")
                model_headers = model_def.get("headers")
                merged_headers: dict[str, str] = {}
                if isinstance(provider_headers, dict):
                    resolved = resolve_headers(provider_headers)
                    if resolved:
                        merged_headers.update(resolved)
                if isinstance(model_headers, dict):
                    resolved = resolve_headers(model_headers)
                    if resolved:
                        merged_headers.update(resolved)

                parsed_model: Model = {
                    "id": model_id,
                    "name": str(model_def.get("name") or model_id),
                    "api": api,
                    "provider": provider_name,
                    "baseUrl": base_url,
                    "reasoning": bool(model_def.get("reasoning", False)),
                    "input": model_def.get("input") if isinstance(model_def.get("input"), list) else ["text"],
                    "cost": model_def.get("cost")
                    if isinstance(model_def.get("cost"), dict)
                    else {"input": 0.0, "output": 0.0, "cacheRead": 0.0, "cacheWrite": 0.0},
                    "contextWindow": int(model_def.get("contextWindow", 100000)),
                    "maxTokens": int(model_def.get("maxTokens", 8000)),
                }
                if merged_headers:
                    parsed_model["headers"] = merged_headers  # type: ignore[typeddict-item]
                if isinstance(model_def.get("compat"), dict):
                    parsed_model["compat"] = model_def["compat"]  # type: ignore[typeddict-item]

                custom_models.append(parsed_model)

        return _CustomModelsResult(
            models=custom_models,
            overrides=overrides,
            model_overrides=per_model_overrides,
            error=None,
        )

    def _load_models(self) -> None:
        if self.models_json_path:
            custom_result = self._load_custom_models(self.models_json_path)
            self.load_error = custom_result.error
        else:
            custom_result = _CustomModelsResult(models=[], overrides={}, model_overrides={}, error=None)

        built_in = self._load_builtin_models(custom_result.overrides, custom_result.model_overrides)
        self.models = self._merge_custom_models(built_in, custom_result.models)

    def find(self, model_id: str) -> Model | None:
        for model in self.models:
            if model.get("id") == model_id:
                return dict(model)
        return None

    def get_api_key_for_model(self, model: Model) -> str | None:
        provider = str(model.get("provider", ""))
        if not provider:
            return None
        # This call path is sync in TS but async in Python port. Keep API sync by running loop if needed.
        try:
            asyncio.get_running_loop()
        except Exception:
            return asyncio.run(self.auth_storage.get_api_key(provider))
        else:
            # If already inside loop, caller should use async helpers.
            return self.custom_provider_api_keys.get(provider)


__all__ = [
    "ModelRegistry",
    "clear_api_key_cache",
    "clearApiKeyCache",
]
