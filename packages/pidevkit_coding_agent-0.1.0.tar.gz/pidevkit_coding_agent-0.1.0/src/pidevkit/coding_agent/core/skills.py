from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .diagnostics import ResourceDiagnostic
from ..utils.frontmatter import parse_frontmatter

MAX_NAME_LENGTH = 64
MAX_DESCRIPTION_LENGTH = 1024


@dataclass(frozen=True)
class Skill:
    name: str
    description: str
    file_path: str
    base_dir: str
    source: str
    disable_model_invocation: bool = False

    @property
    def filePath(self) -> str:
        return self.file_path

    @property
    def baseDir(self) -> str:
        return self.base_dir

    @property
    def disableModelInvocation(self) -> bool:
        return self.disable_model_invocation


def _validate_name(name: str, parent_dir_name: str) -> list[str]:
    errors: list[str] = []
    if name != parent_dir_name:
        errors.append(f'name "{name}" does not match parent directory "{parent_dir_name}"')
    if len(name) > MAX_NAME_LENGTH:
        errors.append(f"name exceeds {MAX_NAME_LENGTH} characters ({len(name)})")
    if not re.fullmatch(r"[a-z0-9-]+", name):
        errors.append("name contains invalid characters (must be lowercase a-z, 0-9, hyphens only)")
    if name.startswith("-") or name.endswith("-"):
        errors.append("name must not start or end with a hyphen")
    if "--" in name:
        errors.append("name must not contain consecutive hyphens")
    return errors


def _validate_description(description: str | None) -> list[str]:
    errors: list[str] = []
    if not description or not description.strip():
        errors.append("description is required")
    elif len(description) > MAX_DESCRIPTION_LENGTH:
        errors.append(f"description exceeds {MAX_DESCRIPTION_LENGTH} characters ({len(description)})")
    return errors


def _load_skill_from_file(file_path: Path, source: str) -> tuple[Skill | None, list[ResourceDiagnostic]]:
    diagnostics: list[ResourceDiagnostic] = []
    try:
        raw = file_path.read_text(encoding="utf-8")
    except Exception as exc:  # noqa: BLE001
        diagnostics.append({"type": "warning", "message": str(exc), "path": str(file_path)})
        return None, diagnostics

    parsed = parse_frontmatter(raw)
    frontmatter = parsed.get("frontmatter", {})
    description = frontmatter.get("description") if isinstance(frontmatter, dict) else None
    if description is not None and not isinstance(description, str):
        description = str(description)

    for error in _validate_description(description):
        diagnostics.append({"type": "warning", "message": error, "path": str(file_path)})

    parent_dir_name = file_path.parent.name
    name = parent_dir_name
    if isinstance(frontmatter, dict) and isinstance(frontmatter.get("name"), str):
        name = frontmatter["name"]

    for error in _validate_name(name, parent_dir_name):
        diagnostics.append({"type": "warning", "message": error, "path": str(file_path)})

    if not description or not description.strip():
        return None, diagnostics

    disable = False
    if isinstance(frontmatter, dict):
        disable = frontmatter.get("disable-model-invocation") is True

    skill = Skill(
        name=name,
        description=description,
        file_path=str(file_path),
        base_dir=str(file_path.parent),
        source=source,
        disable_model_invocation=disable,
    )
    return skill, diagnostics


def load_skills_from_dir(dir: str | Path, source: str, include_root_files: bool = True) -> dict[str, Any]:
    base = Path(dir)
    skills: list[Skill] = []
    diagnostics: list[ResourceDiagnostic] = []

    if not base.exists():
        return {"skills": skills, "diagnostics": diagnostics}

    try:
        entries = list(base.iterdir())
    except Exception:
        return {"skills": skills, "diagnostics": diagnostics}

    for entry in entries:
        if entry.name.startswith("."):
            continue
        if entry.name == "node_modules":
            continue

        if entry.is_dir():
            sub = load_skills_from_dir(entry, source, include_root_files=False)
            skills.extend(sub["skills"])
            diagnostics.extend(sub["diagnostics"])
            continue

        if not entry.is_file():
            continue

        is_root_md = include_root_files and entry.suffix == ".md"
        is_skill_md = not include_root_files and entry.name == "SKILL.md"
        if not is_root_md and not is_skill_md:
            continue

        skill, file_diags = _load_skill_from_file(entry, source)
        diagnostics.extend(file_diags)
        if skill:
            skills.append(skill)

    return {"skills": skills, "diagnostics": diagnostics}


def loadSkillsFromDir(options: dict[str, str]) -> dict[str, Any]:
    return load_skills_from_dir(options["dir"], options["source"])


def _normalize_path(path: str) -> str:
    expanded = os.path.expanduser(path.strip())
    return expanded


def _resolve_skill_path(path: str, cwd: str) -> str:
    normalized = _normalize_path(path)
    if os.path.isabs(normalized):
        return normalized
    return str((Path(cwd) / normalized).resolve())


def load_skills(options: dict[str, Any] | None = None) -> dict[str, Any]:
    opts = options or {}
    cwd = str(opts.get("cwd") or Path.cwd())
    agent_dir = str(opts.get("agentDir") or (Path.home() / ".pi" / "agent"))
    skill_paths = list(opts.get("skillPaths") or [])
    include_defaults = bool(opts.get("includeDefaults", True))

    results: list[Skill] = []
    diagnostics: list[ResourceDiagnostic] = []

    seen_paths: set[str] = set()

    def merge_result(result: dict[str, Any]) -> None:
        for skill in result["skills"]:
            if skill.file_path in seen_paths:
                continue
            seen_paths.add(skill.file_path)
            results.append(skill)
        diagnostics.extend(result["diagnostics"])

    if include_defaults:
        merge_result(load_skills_from_dir(Path(agent_dir) / "skills", "user"))
        merge_result(load_skills_from_dir(Path(cwd) / ".codex" / "skills", "project"))

    for raw in skill_paths:
        resolved = Path(_resolve_skill_path(raw, cwd))
        if not resolved.exists():
            continue
        if resolved.is_dir():
            merge_result(load_skills_from_dir(resolved, "path"))
        elif resolved.is_file() and resolved.suffix == ".md":
            skill, file_diags = _load_skill_from_file(resolved, "path")
            diagnostics.extend(file_diags)
            if skill and skill.file_path not in seen_paths:
                seen_paths.add(skill.file_path)
                results.append(skill)

    return {"skills": results, "diagnostics": diagnostics}


def loadSkills(options: dict[str, Any] | None = None) -> dict[str, Any]:
    return load_skills(options)


def _escape_xml(value: str) -> str:
    return (
        value.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )


def format_skills_for_prompt(skills: list[Skill]) -> str:
    visible = [skill for skill in skills if not skill.disable_model_invocation]
    if not visible:
        return ""

    lines = [
        "",
        "",
        "The following skills provide specialized instructions for specific tasks.",
        "Use the read tool to load a skill's file when the task matches its description.",
        "When a skill file references a relative path, resolve it against the skill directory (parent of SKILL.md / dirname of the path) and use that absolute path in tool commands.",
        "",
        "<available_skills>",
    ]

    for skill in visible:
        lines.append("  <skill>")
        lines.append(f"    <name>{_escape_xml(skill.name)}</name>")
        lines.append(f"    <description>{_escape_xml(skill.description)}</description>")
        lines.append(f"    <location>{_escape_xml(skill.file_path)}</location>")
        lines.append("  </skill>")

    lines.append("</available_skills>")
    return "\n".join(lines)


def formatSkillsForPrompt(skills: list[Skill]) -> str:
    return format_skills_for_prompt(skills)


__all__ = [
    "Skill",
    "format_skills_for_prompt",
    "formatSkillsForPrompt",
    "load_skills",
    "load_skills_from_dir",
    "loadSkills",
    "loadSkillsFromDir",
]
