from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class PromptConcurrencyGuard:
    is_streaming: bool = False

    def start_stream(self) -> None:
        self.is_streaming = True

    def stop_stream(self) -> None:
        self.is_streaming = False

    def ensure_prompt_allowed(self) -> None:
        if self.is_streaming:
            raise RuntimeError("Cannot call prompt while streaming")

    def can_steer(self) -> bool:
        return True

    def can_follow_up(self) -> bool:
        return True


PromptGuard = PromptConcurrencyGuard
