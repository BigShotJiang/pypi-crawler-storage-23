from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path
from typing import TypedDict

ToolDescriptionMap = dict[str, str]


class ContextFile(TypedDict):
    path: str
    content: str


class Skill(TypedDict, total=False):
    name: str
    description: str


TOOL_DESCRIPTIONS: ToolDescriptionMap = {
    "read": "Read file contents",
    "bash": "Execute bash commands (ls, grep, find, etc.)",
    "edit": "Make surgical edits to files (find exact text and replace)",
    "write": "Create or overwrite files",
    "grep": "Search file contents for patterns (respects .gitignore)",
    "find": "Find files by glob pattern (respects .gitignore)",
    "ls": "List directory contents",
}

DEFAULT_TOOLS: tuple[str, ...] = ("read", "bash", "edit", "write")


def _format_date_time() -> str:
    now = datetime.now().astimezone()
    return now.strftime("%A, %B %d, %Y, %I:%M:%S %p %Z")


def _format_context_files(context_files: list[ContextFile]) -> str:
    if not context_files:
        return ""

    lines = ["", "", "# Project Context", "", "Project-specific instructions and guidelines:", ""]
    for file in context_files:
        lines.extend([f"## {file['path']}", "", file["content"], ""])
    return "\n".join(lines).rstrip()


def _format_skills(skills: list[Skill]) -> str:
    if not skills:
        return ""

    lines = ["", "", "# Skills", ""]
    for skill in skills:
        name = skill.get("name", "unnamed")
        description = skill.get("description", "").strip()
        if description:
            lines.append(f"- {name}: {description}")
        else:
            lines.append(f"- {name}")
    return "\n".join(lines)


def build_system_prompt(
    *,
    custom_prompt: str | None = None,
    selected_tools: list[str] | None = None,
    append_system_prompt: str | None = None,
    cwd: str | None = None,
    context_files: list[ContextFile] | None = None,
    skills: list[Skill] | None = None,
) -> str:
    resolved_cwd = cwd or os.getcwd()
    date_time = _format_date_time()
    append_section = f"\n\n{append_system_prompt}" if append_system_prompt else ""
    resolved_context_files = context_files or []
    resolved_skills = skills or []

    if custom_prompt is not None:
        prompt = custom_prompt
        prompt += append_section
        prompt += _format_context_files(resolved_context_files)

        has_read_tool = selected_tools is None or "read" in selected_tools
        if has_read_tool:
            prompt += _format_skills(resolved_skills)

        prompt += f"\nCurrent date and time: {date_time}"
        prompt += f"\nCurrent working directory: {resolved_cwd}"
        return prompt

    tools_source = list(DEFAULT_TOOLS) if selected_tools is None else selected_tools
    tools = [tool for tool in tools_source if tool in TOOL_DESCRIPTIONS]
    tools_list = "\n".join(f"- {tool}: {TOOL_DESCRIPTIONS[tool]}" for tool in tools) if tools else "(none)"

    has_bash = "bash" in tools
    has_edit = "edit" in tools
    has_write = "write" in tools
    has_grep = "grep" in tools
    has_find = "find" in tools
    has_ls = "ls" in tools
    has_read = "read" in tools

    guidelines: list[str] = []
    if has_bash and not (has_grep or has_find or has_ls):
        guidelines.append("Use bash for file operations like ls, rg, find")
    elif has_bash and (has_grep or has_find or has_ls):
        guidelines.append("Prefer grep/find/ls tools over bash for file exploration (faster, respects .gitignore)")

    if has_read and has_edit:
        guidelines.append("Use read to examine files before editing. You must use this tool instead of cat or sed.")
    if has_edit:
        guidelines.append("Use edit for precise changes (old text must match exactly)")
    if has_write:
        guidelines.append("Use write only for new files or complete rewrites")
    if has_edit or has_write:
        guidelines.append("When summarizing your actions, output plain text directly - do NOT use cat or bash to display what you did")

    guidelines.append("Be concise in your responses")
    guidelines.append("Show file paths clearly when working with files")

    guidelines_text = "\n".join(f"- {guideline}" for guideline in guidelines)

    readme_path = str(Path("README.md"))
    docs_path = str(Path("docs"))
    examples_path = str(Path("examples"))

    prompt = f"""You are an expert coding assistant operating inside pi, a coding agent harness. You help users by reading files, executing commands, editing code, and writing new files.

Available tools:
{tools_list}

In addition to the tools above, you may have access to other custom tools depending on the project.

Guidelines:
{guidelines_text}

Pi documentation (read only when the user asks about pi itself, its SDK, extensions, themes, skills, or TUI):
- Main documentation: {readme_path}
- Additional docs: {docs_path}
- Examples: {examples_path} (extensions, custom tools, SDK)
- When working on pi topics, read the docs and examples, and follow .md cross-references before implementing"""

    prompt += append_section
    prompt += _format_context_files(resolved_context_files)
    if has_read:
        prompt += _format_skills(resolved_skills)
    prompt += f"\nCurrent date and time: {date_time}"
    prompt += f"\nCurrent working directory: {resolved_cwd}"

    return prompt


def buildSystemPrompt(
    customPrompt: str | None = None,
    selectedTools: list[str] | None = None,
    appendSystemPrompt: str | None = None,
    cwd: str | None = None,
    contextFiles: list[ContextFile] | None = None,
    skills: list[Skill] | None = None,
) -> str:
    return build_system_prompt(
        custom_prompt=customPrompt,
        selected_tools=selectedTools,
        append_system_prompt=appendSystemPrompt,
        cwd=cwd,
        context_files=contextFiles,
        skills=skills,
    )


__all__ = ["build_system_prompt", "buildSystemPrompt", "ContextFile", "Skill"]
