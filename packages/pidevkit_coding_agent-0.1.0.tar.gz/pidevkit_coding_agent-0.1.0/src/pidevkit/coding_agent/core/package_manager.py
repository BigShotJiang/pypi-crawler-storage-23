from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..utils.git import GitSource, parse_git_url
from .settings_manager import SettingsManager


@dataclass(frozen=True, slots=True)
class LocalSource:
    type: str
    path: str


class DefaultPackageManager:
    def __init__(self, *, cwd: str, agent_dir: str, settings_manager: SettingsManager) -> None:
        self.cwd = Path(cwd)
        self.agent_dir = Path(agent_dir)
        self.settings_manager = settings_manager

    def parse_source(self, source: str) -> GitSource | LocalSource:
        parsed = parse_git_url(source)
        if parsed is not None:
            return parsed
        return LocalSource(type="local", path=source)

    def parseSource(self, source: str) -> GitSource | LocalSource:
        return self.parse_source(source)

    def get_package_identity(self, source: str) -> str:
        parsed = self.parse_source(source)
        if isinstance(parsed, LocalSource):
            candidate = Path(parsed.path)
            if not candidate.is_absolute():
                candidate = self.cwd / candidate
            return f"local:{candidate.resolve()}"

        return f"git:{parsed.host}/{parsed.path.rstrip('/')}"

    def getPackageIdentity(self, source: str) -> str:
        return self.get_package_identity(source)

    # API placeholders for parity with TS package manager surface.
    async def resolve(self, on_missing: Any = None) -> dict[str, list[Any]]:  # noqa: ANN401
        return {"extensions": [], "skills": [], "prompts": [], "themes": []}

    async def install(self, source: str, options: dict[str, Any] | None = None) -> None:  # noqa: ANN401
        _ = (source, options)

    async def remove(self, source: str, options: dict[str, Any] | None = None) -> None:  # noqa: ANN401
        _ = (source, options)

    async def update(self, source: str | None = None) -> None:
        _ = source


__all__ = [
    "DefaultPackageManager",
]
