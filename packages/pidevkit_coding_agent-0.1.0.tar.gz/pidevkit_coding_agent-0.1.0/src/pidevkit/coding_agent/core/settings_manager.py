from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

SettingsScope = Literal["global", "project"]


@dataclass(frozen=True, slots=True)
class SettingsError:
    scope: SettingsScope
    error: Exception


def _deep_merge_settings(base: dict[str, Any], overrides: dict[str, Any]) -> dict[str, Any]:
    result = dict(base)
    for key, value in overrides.items():
        if value is None:
            result[key] = value
            continue

        base_value = result.get(key)
        if isinstance(base_value, dict) and isinstance(value, dict):
            result[key] = {**base_value, **value}
        else:
            result[key] = value
    return result


def _migrate_settings(settings: dict[str, Any]) -> dict[str, Any]:
    data = dict(settings)

    if "queueMode" in data and "steeringMode" not in data:
        data["steeringMode"] = data.pop("queueMode")

    if "transport" not in data and isinstance(data.get("websockets"), bool):
        data["transport"] = "websocket" if data.pop("websockets") else "sse"

    skills = data.get("skills")
    if isinstance(skills, dict):
        if "enableSkillCommands" in skills and "enableSkillCommands" not in data:
            data["enableSkillCommands"] = skills.get("enableSkillCommands")
        custom_dirs = skills.get("customDirectories")
        if isinstance(custom_dirs, list) and custom_dirs:
            data["skills"] = custom_dirs
        else:
            data.pop("skills", None)

    return data


class SettingsManager:
    def __init__(
        self,
        *,
        project_dir: Path | None,
        agent_dir: Path | None,
        global_settings: dict[str, Any] | None = None,
        project_settings: dict[str, Any] | None = None,
        in_memory: bool = False,
        initial_errors: list[SettingsError] | None = None,
    ) -> None:
        self.project_dir = project_dir
        self.agent_dir = agent_dir
        self.in_memory = in_memory
        self.global_settings = dict(global_settings or {})
        self.project_settings = dict(project_settings or {})
        self.settings = _deep_merge_settings(self.global_settings, self.project_settings)

        self.modified_global_fields: set[str] = set()
        self.modified_project_fields: set[str] = set()
        self._errors: list[SettingsError] = list(initial_errors or [])

    @classmethod
    def create(cls, project_dir: str | Path, agent_dir: str | Path) -> SettingsManager:
        project_path = Path(project_dir)
        agent_path = Path(agent_dir)

        errors: list[SettingsError] = []
        global_settings, global_error = cls._try_load_json(agent_path / "settings.json")
        if global_error:
            errors.append(SettingsError(scope="global", error=global_error))

        project_settings, project_error = cls._try_load_json(project_path / ".pi" / "settings.json")
        if project_error:
            errors.append(SettingsError(scope="project", error=project_error))

        return cls(
            project_dir=project_path,
            agent_dir=agent_path,
            global_settings=global_settings,
            project_settings=project_settings,
            initial_errors=errors,
        )

    @classmethod
    def in_memory(cls, settings: dict[str, Any] | None = None) -> SettingsManager:
        return cls(
            project_dir=None,
            agent_dir=None,
            global_settings=settings or {},
            project_settings={},
            in_memory=True,
        )

    @staticmethod
    def _try_load_json(path: Path) -> tuple[dict[str, Any], Exception | None]:
        if not path.exists():
            return {}, None
        try:
            loaded = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(loaded, dict):
                return {}, ValueError(f"{path} must contain a JSON object")
            return _migrate_settings(loaded), None
        except Exception as exc:  # noqa: BLE001
            return {}, exc

    def _refresh_merged(self) -> None:
        self.settings = _deep_merge_settings(self.global_settings, self.project_settings)

    def _set_global(self, key: str, value: Any) -> None:
        self.global_settings[key] = value
        self.modified_global_fields.add(key)
        self._refresh_merged()

    def _set_project(self, key: str, value: Any) -> None:
        self.project_settings[key] = value
        self.modified_project_fields.add(key)
        self._refresh_merged()

    def set_theme(self, theme: str) -> None:
        self._set_global("theme", theme)

    def setTheme(self, theme: str) -> None:
        self.set_theme(theme)

    def set_default_thinking_level(self, level: str) -> None:
        self._set_global("defaultThinkingLevel", level)

    def setDefaultThinkingLevel(self, level: str) -> None:
        self.set_default_thinking_level(level)

    def set_project_extension_paths(self, paths: list[str]) -> None:
        self._set_project("extensions", list(paths))

    def setProjectExtensionPaths(self, paths: list[str]) -> None:
        self.set_project_extension_paths(paths)

    def set_extension_paths(self, paths: list[str]) -> None:
        self._set_global("extensions", list(paths))

    def setExtensionPaths(self, paths: list[str]) -> None:
        self.set_extension_paths(paths)

    def set_skill_paths(self, paths: list[str]) -> None:
        self._set_global("skills", list(paths))

    def setSkillPaths(self, paths: list[str]) -> None:
        self.set_skill_paths(paths)

    def set_prompt_template_paths(self, paths: list[str]) -> None:
        self._set_global("prompts", list(paths))

    def setPromptTemplatePaths(self, paths: list[str]) -> None:
        self.set_prompt_template_paths(paths)

    def set_theme_paths(self, paths: list[str]) -> None:
        self._set_global("themes", list(paths))

    def setThemePaths(self, paths: list[str]) -> None:
        self.set_theme_paths(paths)

    def _set_global_image_setting(self, key: str, value: Any) -> None:
        images = self.global_settings.get("images")
        if not isinstance(images, dict):
            images = {}
        merged = dict(images)
        merged[key] = value
        self._set_global("images", merged)

    def get_theme(self) -> str | None:
        value = self.settings.get("theme")
        return value if isinstance(value, str) else None

    def getTheme(self) -> str | None:
        return self.get_theme()

    def get_default_model(self) -> str | None:
        value = self.settings.get("defaultModel")
        return value if isinstance(value, str) else None

    def getDefaultModel(self) -> str | None:
        return self.get_default_model()

    def get_shell_command_prefix(self) -> str | None:
        value = self.settings.get("shellCommandPrefix")
        return value if isinstance(value, str) else None

    def getShellCommandPrefix(self) -> str | None:
        return self.get_shell_command_prefix()

    def get_block_images(self) -> bool:
        top_level = self.settings.get("blockImages")
        if isinstance(top_level, bool):
            return top_level
        images = self.settings.get("images")
        if isinstance(images, dict):
            nested = images.get("blockImages")
            if isinstance(nested, bool):
                return nested
        return False

    def getBlockImages(self) -> bool:
        return self.get_block_images()

    def set_block_images(self, blocked: bool) -> None:
        self._set_global_image_setting("blockImages", bool(blocked))

    def setBlockImages(self, blocked: bool) -> None:
        self.set_block_images(blocked)

    def get_auto_resize(self) -> bool:
        top_level = self.settings.get("autoResize")
        if isinstance(top_level, bool):
            return top_level
        images = self.settings.get("images")
        if isinstance(images, dict):
            nested = images.get("autoResize")
            if isinstance(nested, bool):
                return nested
        return True

    def getAutoResize(self) -> bool:
        return self.get_auto_resize()

    def set_auto_resize(self, enabled: bool) -> None:
        self._set_global_image_setting("autoResize", bool(enabled))

    def setAutoResize(self, enabled: bool) -> None:
        self.set_auto_resize(enabled)

    def get_packages(self) -> list[Any]:
        value = self.settings.get("packages")
        return list(value) if isinstance(value, list) else []

    def getPackages(self) -> list[Any]:
        return self.get_packages()

    def get_extension_paths(self) -> list[str]:
        value = self.settings.get("extensions")
        if not isinstance(value, list):
            return []
        return [str(item) for item in value]

    def getExtensionPaths(self) -> list[str]:
        return self.get_extension_paths()

    def get_skill_paths(self) -> list[str]:
        value = self.settings.get("skills")
        if not isinstance(value, list):
            return []
        return [str(item) for item in value]

    def getSkillPaths(self) -> list[str]:
        return self.get_skill_paths()

    def get_prompt_template_paths(self) -> list[str]:
        value = self.settings.get("prompts")
        if not isinstance(value, list):
            return []
        return [str(item) for item in value]

    def getPromptTemplatePaths(self) -> list[str]:
        return self.get_prompt_template_paths()

    def get_theme_paths(self) -> list[str]:
        value = self.settings.get("themes")
        if not isinstance(value, list):
            return []
        return [str(item) for item in value]

    def getThemePaths(self) -> list[str]:
        return self.get_theme_paths()

    def get_global_settings(self) -> dict[str, Any]:
        return dict(self.global_settings)

    def getGlobalSettings(self) -> dict[str, Any]:
        return self.get_global_settings()

    def get_project_settings(self) -> dict[str, Any]:
        return dict(self.project_settings)

    def getProjectSettings(self) -> dict[str, Any]:
        return self.get_project_settings()

    def drain_errors(self) -> list[SettingsError]:
        errors = list(self._errors)
        self._errors.clear()
        return errors

    def drainErrors(self) -> list[SettingsError]:
        return self.drain_errors()

    def reload(self) -> None:
        if self.in_memory:
            return

        global_path = self._global_settings_path
        project_path = self._project_settings_path

        if global_path is not None:
            loaded, error = self._try_load_json(global_path)
            if error is None:
                self.global_settings = loaded
            else:
                self._errors.append(SettingsError(scope="global", error=error))

        if project_path is not None:
            loaded, error = self._try_load_json(project_path)
            if error is None:
                self.project_settings = loaded
            else:
                self._errors.append(SettingsError(scope="project", error=error))

        self._refresh_merged()

    @property
    def _global_settings_path(self) -> Path | None:
        if self.agent_dir is None:
            return None
        return self.agent_dir / "settings.json"

    @property
    def _project_settings_path(self) -> Path | None:
        if self.project_dir is None:
            return None
        return self.project_dir / ".pi" / "settings.json"

    def _flush_scope(self, scope: SettingsScope) -> None:
        if scope == "global":
            path = self._global_settings_path
            modified = self.modified_global_fields
            source = self.global_settings
        else:
            path = self._project_settings_path
            modified = self.modified_project_fields
            source = self.project_settings

        if path is None:
            return

        path.parent.mkdir(parents=True, exist_ok=True)
        current, _ = self._try_load_json(path)
        merged = dict(current)
        for field in modified:
            merged[field] = source.get(field)
        path.write_text(json.dumps(merged, indent=2, ensure_ascii=False), encoding="utf-8")

        if scope == "global":
            self.global_settings = merged
        else:
            self.project_settings = merged

    def flush(self) -> None:
        if self.in_memory:
            return

        self._flush_scope("global")
        self._flush_scope("project")

        self.modified_global_fields.clear()
        self.modified_project_fields.clear()
        self._refresh_merged()


__all__ = [
    "SettingsError",
    "SettingsManager",
]
