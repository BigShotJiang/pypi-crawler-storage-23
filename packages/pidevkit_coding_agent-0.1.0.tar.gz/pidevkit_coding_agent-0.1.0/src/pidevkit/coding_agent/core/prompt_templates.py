from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path

from ..utils.frontmatter import parse_frontmatter


def parse_command_args(args_string: str) -> list[str]:
    """
    Parse command arguments using simple quote-aware splitting.

    Behavior matches the TypeScript implementation:
    - Supports single and double quotes
    - Splits on spaces and tabs outside quotes
    - Does not support escaping within quotes
    """

    args: list[str] = []
    current = ""
    in_quote: str | None = None

    for char in args_string:
        if in_quote is not None:
            if char == in_quote:
                in_quote = None
            else:
                current += char
        elif char in {'"', "'"}:
            in_quote = char
        elif char in {" ", "\t"}:
            if current:
                args.append(current)
                current = ""
        else:
            current += char

    if current:
        args.append(current)

    return args


_POSITIONAL_ARG_RE = re.compile(r"\$(\d+)")
_SLICE_ARG_RE = re.compile(r"\$\{@:(\d+)(?::(\d+))?\}")


def substitute_args(content: str, args: list[str]) -> str:
    """
    Substitute placeholder arguments in a prompt template.

    Supported placeholders:
    - $1, $2, ...: positional args (1-indexed)
    - $@: all args joined by spaces
    - $ARGUMENTS: all args joined by spaces
    - ${@:N}: slice args from Nth (1-indexed, ${@:0} == all args)
    - ${@:N:L}: slice L args starting from Nth
    """

    result = content

    def replace_positional(match: re.Match[str]) -> str:
        index = int(match.group(1)) - 1
        if index < 0:
            return ""
        return args[index] if index < len(args) else ""

    # Replace positional args first.
    result = _POSITIONAL_ARG_RE.sub(replace_positional, result)

    def replace_slice(match: re.Match[str]) -> str:
        start = int(match.group(1)) - 1
        if start < 0:
            start = 0

        length_str = match.group(2)
        if length_str is None:
            return " ".join(args[start:])

        length = int(length_str)
        return " ".join(args[start : start + length])

    # Replace slices before simple wildcard placeholders.
    result = _SLICE_ARG_RE.sub(replace_slice, result)

    all_args = " ".join(args)
    result = result.replace("$ARGUMENTS", all_args)
    result = result.replace("$@", all_args)

    return result


@dataclass(frozen=True)
class PromptTemplate:
    name: str
    description: str
    content: str
    source: str
    file_path: str

    @property
    def filePath(self) -> str:
        return self.file_path


def _normalize_path(input_path: str) -> str:
    return os.path.expanduser(input_path.strip())


def _resolve_prompt_path(path: str, cwd: str) -> Path:
    normalized = _normalize_path(path)
    candidate = Path(normalized)
    if candidate.is_absolute():
        return candidate
    return (Path(cwd) / candidate).resolve()


def _load_template_from_file(file_path: Path, source: str, source_label: str) -> PromptTemplate | None:
    try:
        raw = file_path.read_text(encoding="utf-8")
    except Exception:
        return None

    parsed = parse_frontmatter(raw)
    frontmatter = parsed.get("frontmatter", {})
    body = parsed.get("body", "")

    name = file_path.stem
    description = ""
    if isinstance(frontmatter, dict) and isinstance(frontmatter.get("description"), str):
        description = frontmatter["description"]

    if not description:
        first_non_empty = next((line.strip() for line in str(body).splitlines() if line.strip()), "")
        if first_non_empty:
            description = first_non_empty[:60] + ("..." if len(first_non_empty) > 60 else "")

    description = f"{description} {source_label}".strip() if description else source_label

    return PromptTemplate(
        name=name,
        description=description,
        content=str(body),
        source=source,
        file_path=str(file_path),
    )


def _load_templates_from_dir(dir_path: Path, source: str, source_label: str) -> list[PromptTemplate]:
    if not dir_path.exists():
        return []

    templates: list[PromptTemplate] = []
    try:
        entries = list(dir_path.iterdir())
    except Exception:
        return []

    for entry in entries:
        if not entry.is_file() or entry.suffix != ".md":
            continue
        template = _load_template_from_file(entry, source, source_label)
        if template is not None:
            templates.append(template)

    return templates


def load_prompt_templates(options: dict[str, object] | None = None) -> list[PromptTemplate]:
    opts = options or {}
    cwd = str(opts.get("cwd") or Path.cwd())
    agent_dir = str(opts.get("agentDir") or (Path.home() / ".pi" / "agent"))
    prompt_paths = list(opts.get("promptPaths") or [])
    include_defaults = bool(opts.get("includeDefaults", True))

    templates: list[PromptTemplate] = []

    if include_defaults:
        templates.extend(_load_templates_from_dir(Path(agent_dir) / "prompts", "user", "(user)"))
        templates.extend(_load_templates_from_dir(Path(cwd) / ".pi" / "prompts", "project", "(project)"))

    def source_for_path(path: Path) -> tuple[str, str]:
        user_prompts_dir = (Path(agent_dir) / "prompts").resolve()
        project_prompts_dir = (Path(cwd) / ".pi" / "prompts").resolve()
        resolved = path.resolve()

        if not include_defaults and (resolved == user_prompts_dir or user_prompts_dir in resolved.parents):
            return "user", "(user)"
        if not include_defaults and (resolved == project_prompts_dir or project_prompts_dir in resolved.parents):
            return "project", "(project)"
        return "path", f"(path:{resolved.stem})"

    for raw_path in prompt_paths:
        resolved = _resolve_prompt_path(str(raw_path), cwd)
        if not resolved.exists():
            continue

        source, label = source_for_path(resolved)
        if resolved.is_dir():
            templates.extend(_load_templates_from_dir(resolved, source, label))
        elif resolved.is_file() and resolved.suffix == ".md":
            template = _load_template_from_file(resolved, source, label)
            if template is not None:
                templates.append(template)

    # stable de-dup by file path (first wins)
    deduped: list[PromptTemplate] = []
    seen: set[str] = set()
    for template in templates:
        if template.file_path in seen:
            continue
        seen.add(template.file_path)
        deduped.append(template)
    return deduped


def loadPromptTemplates(options: dict[str, object] | None = None) -> list[PromptTemplate]:
    return load_prompt_templates(options)


def expand_prompt_template(text: str, templates: list[PromptTemplate]) -> str:
    if not text.startswith("/"):
        return text

    space_index = text.find(" ")
    if space_index < 0:
        template_name = text[1:]
        args_string = ""
    else:
        template_name = text[1:space_index]
        args_string = text[space_index + 1 :]

    template = next((item for item in templates if item.name == template_name), None)
    if not template:
        return text

    args = parse_command_args(args_string)
    return substitute_args(template.content, args)


def expandPromptTemplate(text: str, templates: list[PromptTemplate]) -> str:
    return expand_prompt_template(text, templates)


def parseCommandArgs(args_string: str) -> list[str]:
    return parse_command_args(args_string)


def substituteArgs(content: str, args: list[str]) -> str:
    return substitute_args(content, args)


__all__ = [
    "PromptTemplate",
    "expand_prompt_template",
    "expandPromptTemplate",
    "load_prompt_templates",
    "loadPromptTemplates",
    "parse_command_args",
    "parseCommandArgs",
    "substitute_args",
    "substituteArgs",
]
