from __future__ import annotations

import os
import subprocess
from typing import Final

_COMMAND_TIMEOUT_SECONDS: Final[float] = 10.0
_command_result_cache: dict[str, str | None] = {}


def _execute_command(command_config: str) -> str | None:
    cached = _command_result_cache.get(command_config, ...)
    if cached is not ...:
        return cached

    command = command_config[1:]
    try:
        completed = subprocess.run(
            command,
            shell=True,
            check=False,
            capture_output=True,
            text=True,
            timeout=_COMMAND_TIMEOUT_SECONDS,
        )
    except Exception:
        result = None
    else:
        if completed.returncode != 0:
            result = None
        else:
            value = completed.stdout.strip()
            result = value if value else None

    _command_result_cache[command_config] = result
    return result


def resolve_config_value(config: str) -> str | None:
    if config.startswith("!"):
        return _execute_command(config)
    return os.getenv(config) or config


def resolveConfigValue(config: str) -> str | None:
    return resolve_config_value(config)


def resolve_headers(headers: dict[str, str] | None) -> dict[str, str] | None:
    if not headers:
        return None

    resolved: dict[str, str] = {}
    for key, value in headers.items():
        resolved_value = resolve_config_value(value)
        if resolved_value:
            resolved[key] = resolved_value

    return resolved or None


def resolveHeaders(headers: dict[str, str] | None) -> dict[str, str] | None:
    return resolve_headers(headers)


def clear_config_value_cache() -> None:
    _command_result_cache.clear()


def clearConfigValueCache() -> None:
    clear_config_value_cache()


__all__ = [
    "clear_config_value_cache",
    "clearConfigValueCache",
    "resolve_config_value",
    "resolve_headers",
    "resolveConfigValue",
    "resolveHeaders",
]
