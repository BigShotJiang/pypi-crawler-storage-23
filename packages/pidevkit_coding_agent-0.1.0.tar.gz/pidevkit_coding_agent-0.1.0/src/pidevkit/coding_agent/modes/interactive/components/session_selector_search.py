from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from typing import Literal, Pattern, Protocol, runtime_checkable

from pidevkit.tui import fuzzy_match

SortMode = Literal["threaded", "recent", "relevance"]
NameFilter = Literal["all", "named"]
TokenKind = Literal["fuzzy", "phrase"]


@dataclass(frozen=True)
class SearchToken:
    kind: TokenKind
    value: str


@dataclass(frozen=True)
class ParsedSearchQuery:
    mode: Literal["tokens", "regex"]
    tokens: list[SearchToken]
    regex: Pattern[str] | None
    error: str | None = None


@dataclass(frozen=True)
class MatchResult:
    matches: bool
    score: float


@runtime_checkable
class SessionSearchable(Protocol):
    id: str
    name: str | None
    all_messages_text: str
    cwd: str
    modified: datetime


def _normalize_whitespace_lower(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower()).strip()


def _get_session_search_text(session: SessionSearchable) -> str:
    return f"{session.id} {session.name or ''} {session.all_messages_text} {session.cwd}"


def has_session_name(session: SessionSearchable) -> bool:
    return bool(session.name and session.name.strip())


def _matches_name_filter(session: SessionSearchable, name_filter: NameFilter) -> bool:
    if name_filter == "all":
        return True
    return has_session_name(session)


def parse_search_query(query: str) -> ParsedSearchQuery:
    trimmed = query.strip()
    if not trimmed:
        return ParsedSearchQuery(mode="tokens", tokens=[], regex=None)

    if trimmed.startswith("re:"):
        pattern = trimmed[3:].strip()
        if not pattern:
            return ParsedSearchQuery(mode="regex", tokens=[], regex=None, error="Empty regex")
        try:
            return ParsedSearchQuery(mode="regex", tokens=[], regex=re.compile(pattern, re.IGNORECASE))
        except re.error as err:
            return ParsedSearchQuery(mode="regex", tokens=[], regex=None, error=str(err))

    tokens: list[SearchToken] = []
    buf = ""
    in_quote = False
    had_unclosed_quote = False

    def flush(kind: TokenKind) -> None:
        nonlocal buf
        value = buf.strip()
        buf = ""
        if not value:
            return
        tokens.append(SearchToken(kind=kind, value=value))

    for char in trimmed:
        if char == '"':
            if in_quote:
                flush("phrase")
                in_quote = False
            else:
                flush("fuzzy")
                in_quote = True
            continue

        if not in_quote and char.isspace():
            flush("fuzzy")
            continue

        buf += char

    if in_quote:
        had_unclosed_quote = True

    if had_unclosed_quote:
        fallback_tokens = [
            SearchToken(kind="fuzzy", value=token)
            for token in (part.strip() for part in trimmed.split())
            if token
        ]
        return ParsedSearchQuery(mode="tokens", tokens=fallback_tokens, regex=None)

    flush("phrase" if in_quote else "fuzzy")
    return ParsedSearchQuery(mode="tokens", tokens=tokens, regex=None)


def match_session(session: SessionSearchable, parsed: ParsedSearchQuery) -> MatchResult:
    text = _get_session_search_text(session)

    if parsed.mode == "regex":
        if parsed.regex is None:
            return MatchResult(matches=False, score=0)
        match = parsed.regex.search(text)
        if match is None:
            return MatchResult(matches=False, score=0)
        return MatchResult(matches=True, score=match.start() * 0.1)

    if not parsed.tokens:
        return MatchResult(matches=True, score=0)

    total_score = 0.0
    normalized_text: str | None = None

    for token in parsed.tokens:
        if token.kind == "phrase":
            if normalized_text is None:
                normalized_text = _normalize_whitespace_lower(text)
            phrase = _normalize_whitespace_lower(token.value)
            if not phrase:
                continue
            index = normalized_text.find(phrase)
            if index < 0:
                return MatchResult(matches=False, score=0)
            total_score += index * 0.1
            continue

        match = fuzzy_match(token.value, text)
        if not match.matches:
            return MatchResult(matches=False, score=0)
        total_score += match.score

    return MatchResult(matches=True, score=total_score)


def filter_and_sort_sessions(
    sessions: list[SessionSearchable],
    query: str,
    sort_mode: SortMode,
    name_filter: NameFilter = "all",
) -> list[SessionSearchable]:
    if name_filter == "all":
        name_filtered = sessions
    else:
        name_filtered = [session for session in sessions if _matches_name_filter(session, name_filter)]

    if not query.strip():
        return name_filtered

    parsed = parse_search_query(query)
    if parsed.error:
        return []

    if sort_mode == "recent":
        filtered: list[SessionSearchable] = []
        for session in name_filtered:
            result = match_session(session, parsed)
            if result.matches:
                filtered.append(session)
        return filtered

    scored: list[tuple[SessionSearchable, float]] = []
    for session in name_filtered:
        result = match_session(session, parsed)
        if not result.matches:
            continue
        scored.append((session, result.score))

    scored.sort(key=lambda item: (item[1], -item[0].modified.timestamp()))
    return [session for session, _score in scored]


__all__ = [
    "MatchResult",
    "NameFilter",
    "ParsedSearchQuery",
    "SearchToken",
    "SortMode",
    "filter_and_sort_sessions",
    "has_session_name",
    "match_session",
    "parse_search_query",
]
