from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class InteractiveStatusLog:
    lines: list[str] = field(default_factory=list)
    _last_status_index: int | None = None

    def append_line(self, line: str) -> None:
        self.lines.append(line)
        if self._last_status_index is not None and self._last_status_index != len(self.lines) - 1:
            self._last_status_index = None

    def show_status(self, status: str) -> None:
        if self._last_status_index is not None and self._last_status_index == len(self.lines) - 1:
            self.lines[self._last_status_index] = status
            return

        self.lines.append("")
        self.lines.append(status)
        self._last_status_index = len(self.lines) - 1

    def show_loaded_resources(
        self,
        *,
        quiet_startup: bool,
        force: bool = False,
        show_diagnostics_when_quiet: bool = True,
        skills: list[str] | None = None,
        diagnostics: list[str] | None = None,
        extension_paths: list[str] | None = None,
    ) -> None:
        skill_list = list(skills or [])
        diagnostic_list = list(diagnostics or [])
        extension_list = list(extension_paths or [])

        if quiet_startup and not force:
            if show_diagnostics_when_quiet and diagnostic_list:
                self.lines.append("[Skill conflicts]")
                self.lines.extend(diagnostic_list)
            return

        if skill_list:
            self.lines.append("[Skills]")
            self.lines.extend(skill_list)
        if extension_list:
            self.lines.append("[Extensions]")
            self.lines.extend(extension_list)
        if diagnostic_list:
            self.lines.append("[Skill conflicts]")
            self.lines.extend(diagnostic_list)


InteractiveModeStatus = InteractiveStatusLog
