from __future__ import annotations

import re
from dataclasses import dataclass
from urllib.parse import urlsplit, urlunsplit


@dataclass(frozen=True, slots=True)
class GitSource:
    type: str
    repo: str
    host: str
    path: str
    ref: str | None
    pinned: bool


def _split_ref(url: str) -> tuple[str, str | None]:
    scp_like_match = re.match(r"^git@([^:]+):(.+)$", url)
    if scp_like_match:
        host = scp_like_match.group(1)
        path_with_maybe_ref = scp_like_match.group(2)
        ref_separator = path_with_maybe_ref.find("@")
        if ref_separator < 0:
            return url, None
        repo_path = path_with_maybe_ref[:ref_separator]
        ref = path_with_maybe_ref[ref_separator + 1 :]
        if not repo_path or not ref:
            return url, None
        return f"git@{host}:{repo_path}", ref

    if "://" in url:
        try:
            parsed = urlsplit(url)
        except ValueError:
            return url, None

        path_with_maybe_ref = parsed.path.lstrip("/")
        ref_separator = path_with_maybe_ref.find("@")
        if ref_separator < 0:
            return url, None
        repo_path = path_with_maybe_ref[:ref_separator]
        ref = path_with_maybe_ref[ref_separator + 1 :]
        if not repo_path or not ref:
            return url, None

        repo = urlunsplit((parsed.scheme, parsed.netloc, f"/{repo_path}", parsed.query, parsed.fragment))
        return repo.rstrip("/"), ref

    slash_index = url.find("/")
    if slash_index < 0:
        return url, None

    host = url[:slash_index]
    path_with_maybe_ref = url[slash_index + 1 :]
    ref_separator = path_with_maybe_ref.find("@")
    if ref_separator < 0:
        return url, None

    repo_path = path_with_maybe_ref[:ref_separator]
    ref = path_with_maybe_ref[ref_separator + 1 :]
    if not repo_path or not ref:
        return url, None

    return f"{host}/{repo_path}", ref


def _parse_generic_git_url(url: str) -> GitSource | None:
    repo_without_ref, ref = _split_ref(url)
    repo = repo_without_ref

    host = ""
    path = ""

    scp_like_match = re.match(r"^git@([^:]+):(.+)$", repo_without_ref)
    if scp_like_match:
        host = scp_like_match.group(1)
        path = scp_like_match.group(2)
    elif repo_without_ref.startswith(("https://", "http://", "ssh://", "git://")):
        try:
            parsed = urlsplit(repo_without_ref)
        except ValueError:
            return None
        host = parsed.hostname or ""
        path = parsed.path.lstrip("/")
    else:
        slash_index = repo_without_ref.find("/")
        if slash_index < 0:
            return None
        host = repo_without_ref[:slash_index]
        path = repo_without_ref[slash_index + 1 :]
        if "." not in host and host != "localhost":
            return None
        repo = f"https://{repo_without_ref}"

    normalized_path = re.sub(r"\.git$", "", path).lstrip("/")
    if not host or not normalized_path or len(normalized_path.split("/")) < 2:
        return None

    return GitSource(
        type="git",
        repo=repo,
        host=host,
        path=normalized_path,
        ref=ref,
        pinned=bool(ref),
    )


def parse_git_url(source: str) -> GitSource | None:
    trimmed = source.strip()
    has_git_prefix = trimmed.startswith("git:")
    url = trimmed[4:].strip() if has_git_prefix else trimmed

    if not has_git_prefix and not re.match(r"^(https?|ssh|git)://", url, flags=re.IGNORECASE):
        return None

    return _parse_generic_git_url(url)
