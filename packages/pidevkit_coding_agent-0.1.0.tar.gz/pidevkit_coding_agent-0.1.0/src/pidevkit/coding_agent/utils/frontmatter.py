from __future__ import annotations

from typing import Any

import yaml


def _normalize_newlines(value: str) -> str:
    return value.replace("\r\n", "\n").replace("\r", "\n")


def _extract_frontmatter(content: str) -> tuple[str | None, str]:
    normalized = _normalize_newlines(content)

    if not normalized.startswith("---"):
        return None, normalized

    end_index = normalized.find("\n---", 3)
    if end_index == -1:
        return None, normalized

    return normalized[4:end_index], normalized[end_index + 4 :].strip()


def parse_frontmatter(content: str) -> dict[str, Any]:
    yaml_string, body = _extract_frontmatter(content)
    if not yaml_string:
        return {"frontmatter": {}, "body": body}

    # Keep YAML block-scalar clipping behavior aligned with the TS parser.
    parsed = yaml.safe_load(f"{yaml_string}\n")
    return {"frontmatter": parsed if parsed is not None else {}, "body": body}


def strip_frontmatter(content: str) -> str:
    return parse_frontmatter(content)["body"]
