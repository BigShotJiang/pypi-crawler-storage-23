from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from pidevkit.coding_agent.core.image_processing import convert_to_png

SUPPORTED_IMAGE_MIME_TYPES: tuple[str, ...] = ("image/png", "image/jpeg", "image/webp", "image/gif")

RunCommand = Callable[[str, list[str]], dict[str, Any]]


@dataclass(frozen=True, slots=True)
class ClipboardImage:
    bytes: bytes
    mime_type: str

    @property
    def mimeType(self) -> str:
        return self.mime_type


def is_wayland_session(env: dict[str, str] | None = None) -> bool:
    env_data = env or {}
    return bool(env_data.get("WAYLAND_DISPLAY")) or env_data.get("XDG_SESSION_TYPE") == "wayland"


def _base_mime_type(mime_type: str) -> str:
    return mime_type.split(";", 1)[0].strip().lower()


def extension_for_image_mime_type(mime_type: str) -> str | None:
    mapping = {
        "image/png": "png",
        "image/jpeg": "jpg",
        "image/webp": "webp",
        "image/gif": "gif",
    }
    return mapping.get(_base_mime_type(mime_type))


def _select_preferred_image_mime_type(mime_types: list[str]) -> str | None:
    normalized = [t.strip() for t in mime_types if t.strip()]
    for preferred in SUPPORTED_IMAGE_MIME_TYPES:
        for candidate in normalized:
            if _base_mime_type(candidate) == preferred:
                return candidate
    for candidate in normalized:
        if _base_mime_type(candidate).startswith("image/"):
            return candidate
    return None


def _is_supported_image_mime_type(mime_type: str) -> bool:
    return _base_mime_type(mime_type) in SUPPORTED_IMAGE_MIME_TYPES


def _default_run_command(command: str, args: list[str]) -> dict[str, Any]:
    import subprocess

    completed = subprocess.run(
        [command, *args],
        capture_output=True,
        check=False,
    )
    if completed.returncode != 0:
        return {"ok": False, "stdout": b""}
    return {"ok": True, "stdout": bytes(completed.stdout)}


def _read_via_wl_paste(run_command: RunCommand) -> ClipboardImage | None:
    listed = run_command("wl-paste", ["--list-types"])
    if not listed.get("ok"):
        return None

    types = [
        line.strip()
        for line in bytes(listed.get("stdout", b"")).decode("utf-8", errors="ignore").splitlines()
        if line.strip()
    ]
    selected = _select_preferred_image_mime_type(types)
    if selected is None:
        return None

    data = run_command("wl-paste", ["--type", selected, "--no-newline"])
    stdout = bytes(data.get("stdout", b""))
    if not data.get("ok") or not stdout:
        return None

    return ClipboardImage(bytes=stdout, mime_type=_base_mime_type(selected))


def _read_via_xclip(run_command: RunCommand) -> ClipboardImage | None:
    targets = run_command("xclip", ["-selection", "clipboard", "-t", "TARGETS", "-o"])
    candidate_types: list[str] = []
    if targets.get("ok"):
        candidate_types = [
            line.strip()
            for line in bytes(targets.get("stdout", b"")).decode("utf-8", errors="ignore").splitlines()
            if line.strip()
        ]

    preferred = _select_preferred_image_mime_type(candidate_types) if candidate_types else None
    try_types = [preferred, *SUPPORTED_IMAGE_MIME_TYPES] if preferred is not None else list(SUPPORTED_IMAGE_MIME_TYPES)

    seen: set[str] = set()
    for mime_type in try_types:
        if mime_type in seen:
            continue
        seen.add(mime_type)
        data = run_command("xclip", ["-selection", "clipboard", "-t", mime_type, "-o"])
        stdout = bytes(data.get("stdout", b""))
        if data.get("ok") and stdout:
            return ClipboardImage(bytes=stdout, mime_type=_base_mime_type(mime_type))
    return None


async def read_clipboard_image(
    *,
    env: dict[str, str] | None = None,
    platform: str = "linux",
    run_command: RunCommand | None = None,
    clipboard_backend: Any = None,
) -> ClipboardImage | None:
    env_data = env or {}
    if env_data.get("TERMUX_VERSION"):
        return None

    runner = run_command or _default_run_command
    image: ClipboardImage | None = None

    if platform == "linux" and is_wayland_session(env_data):
        image = _read_via_wl_paste(runner) or _read_via_xclip(runner)
    else:
        backend = clipboard_backend
        if backend is None:
            return None
        has_image = getattr(backend, "has_image", None) or getattr(backend, "hasImage", None)
        get_binary = getattr(backend, "get_image_binary", None) or getattr(backend, "getImageBinary", None)
        if not callable(has_image) or not callable(get_binary) or not has_image():
            return None
        value = get_binary()
        if hasattr(value, "__await__"):
            value = await value
        if value is None:
            return None
        if isinstance(value, bytes):
            bytes_value = value
        else:
            bytes_value = bytes(value)
        if not bytes_value:
            return None
        image = ClipboardImage(bytes=bytes_value, mime_type="image/png")

    if image is None:
        return None

    if not _is_supported_image_mime_type(image.mime_type):
        from base64 import b64decode, b64encode

        converted = convert_to_png(b64encode(image.bytes).decode("ascii"), image.mime_type)
        if converted is None:
            return None

        converted_bytes = b64decode(converted["data"].encode("ascii"), validate=False)
        return ClipboardImage(bytes=converted_bytes, mime_type="image/png")

    return image


isWaylandSession = is_wayland_session
extensionForImageMimeType = extension_for_image_mime_type
readClipboardImage = read_clipboard_image
