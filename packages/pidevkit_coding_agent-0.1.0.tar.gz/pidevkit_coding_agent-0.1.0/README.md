# pidevkit-coding-agent

Port of the coding-agent subsystem, including resource loading, session handling, extension hooks, and utilities.

## Install

```bash
pip install pidevkit-coding-agent
```

## Import

```python
from pidevkit.coding_agent.core.session_manager import SessionManager
```
