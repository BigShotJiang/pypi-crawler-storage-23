"""Dashboard module for CAS server monitoring and configuration."""

from cascache_server.dashboard.app import create_dashboard_app

__all__ = ["create_dashboard_app"]
