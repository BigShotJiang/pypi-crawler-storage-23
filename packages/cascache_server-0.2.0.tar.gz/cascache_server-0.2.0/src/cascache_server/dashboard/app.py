"""FastAPI dashboard application for CAS server monitoring."""

from __future__ import annotations

from typing import TYPE_CHECKING

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

if TYPE_CHECKING:
    from cascache_server.monitoring.metrics import ServerMetrics

import pathlib
import time


def create_dashboard_app(metrics: ServerMetrics) -> FastAPI:
    """
    Create FastAPI dashboard application.

    Args:
        metrics: ServerMetrics instance to expose

    Returns:
        Configured FastAPI application
    """
    app = FastAPI(
        title="Python CAS Server Dashboard",
        description="Content Addressable Storage Server Monitoring",
        version="1.0.0",
    )

    # Setup templates
    template_dir = pathlib.Path(__file__).parent / "templates"
    templates = Jinja2Templates(directory=str(template_dir))

    @app.get("/", response_class=HTMLResponse)
    async def dashboard(request: Request):
        """Serve the dashboard HTML page."""
        response = templates.TemplateResponse(
            request, "dashboard.html", media_type="text/html; charset=utf-8"
        )
        return response

    @app.get("/api/stats")
    async def stats():
        """
        Get current server statistics.

        Returns:
            JSON object with current metrics
        """
        stats = metrics.get_stats()

        # Calculate derived metrics
        total_requests = stats["hits"] + stats["misses"]
        hit_rate = stats["hits"] / total_requests if total_requests > 0 else 0.0

        # Add server info
        uptime = time.time() - stats.get("started_at", time.time())

        return {
            "cache": {
                "hits": stats["hits"],
                "misses": stats["misses"],
                "total_requests": total_requests,
                "hit_rate": f"{hit_rate:.2%}",
                "hit_rate_value": hit_rate,
            },
            "storage": {
                "blobs_count": stats["blobs_count"],
                "total_bytes": stats["total_bytes"],
                "total_bytes_human": _format_bytes(stats["total_bytes"]),
            },
            "operations": {
                "writes": stats.get("writes", 0),
                "reads": stats.get("reads", 0),
                "deletes": stats.get("deletes", 0),
            },
            "eviction": {
                "evictions": stats.get("evictions", 0),
                "last_run": stats.get("last_eviction_run"),
                "next_run": stats.get("next_eviction_run"),
            },
            "server": {
                "uptime_seconds": int(uptime),
                "uptime_human": _format_uptime(uptime),
            },
        }

    @app.get("/health")
    async def health():
        """Health check endpoint."""
        return {"status": "ok"}

    return app


def _format_bytes(bytes_count: int) -> str:
    """Format bytes to human-readable string."""
    value = float(bytes_count)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if value < 1024.0:
            return f"{value:.2f} {unit}"
        value /= 1024.0
    return f"{value:.2f} PB"


def _format_uptime(seconds: float) -> str:
    """Format uptime seconds to human-readable string."""
    days, remainder = divmod(int(seconds), 86400)
    hours, remainder = divmod(remainder, 3600)
    minutes, seconds = divmod(remainder, 60)

    parts = []
    if days > 0:
        parts.append(f"{days}d")
    if hours > 0:
        parts.append(f"{hours}h")
    if minutes > 0:
        parts.append(f"{minutes}m")
    if seconds > 0 or not parts:
        parts.append(f"{seconds}s")

    return " ".join(parts)
