"""Configuration management for CAS server."""

from __future__ import annotations

import os
from pathlib import Path

import yaml
from pydantic import BaseModel, Field, field_validator, model_validator

from cascache_server.utils.errors import ConfigError
from cascache_server.utils.logger import get_logger

logger = get_logger(__name__)


class CASConfig(BaseModel):
    """
    CAS server configuration.

    Configuration can be loaded from:
    1. YAML config files (searched in priority order:
       - ./cascache_server.yaml
       - ~/.config/cascache_server/config.yaml
       - /etc/cascache_server/config.yaml)
    2. Environment variables (CAS_ prefix)
    3. Direct instantiation with keyword arguments

    Environment variables take precedence over config file values.

    Example:
        >>> config = CASConfig(storage_type="filesystem", port=50051)
        >>> config.port
        50051
    """

    # Core storage settings
    storage_type: str = Field(
        default="filesystem",
        description="Storage backend type: filesystem, s3, or memory",
    )
    storage_path: str = Field(
        default="/tmp/cas", description="Path for filesystem storage or S3 bucket name"
    )

    # Server settings
    port: int = Field(default=50051, ge=1, le=65535, description="gRPC server port")
    host: str = Field(default="[::]", description="Server bind address")
    workers: int = Field(default=10, ge=1, description="Number of gRPC worker threads")

    # Blob settings
    max_blob_size: int = Field(
        default=1_000_000_000,  # 1GB
        ge=1_000_000,  # 1MB minimum
        le=10_000_000_000,  # 10GB maximum
        description="Maximum blob size in bytes",
    )
    max_age_days: int = Field(
        default=30, ge=0, description="Default TTL for blobs in days (0 = no expiration)"
    )
    max_batch_size: int = Field(default=1000, ge=1, description="Maximum batch size for operations")

    # Logging settings
    log_level: str = Field(default="INFO", description="Logging level")
    log_format: str = Field(default="json", description="Log format: json or text")

    # REAPI settings
    reapi_versions: str | list[str] = Field(
        default=["simple"],
        description="List of REAPI protocol versions to support (e.g., ['simple', 'v2'])",
    )

    # Cache settings
    enable_cache: bool = Field(default=True, description="Enable in-memory LRU cache for hot blobs")
    cache_size: int = Field(default=1000, ge=0, description="Number of blobs to cache")
    cache_max_blob_size: int = Field(
        default=65536, ge=0, description="Maximum blob size to cache in bytes (default: 64KB)"
    )

    # Authentication settings
    auth_enabled: bool = Field(default=False, description="Enable token-based authentication")
    auth_tokens_file: Path = Field(
        default=Path("/etc/cas/tokens.json"), description="Path to tokens JSON file"
    )

    # Rate limiting settings
    rate_limit_enabled: bool = Field(default=True, description="Enable rate limiting")
    rate_limit_rps: float = Field(
        default=1000.0, ge=0, description="Rate limit in requests per second"
    )
    rate_limit_burst: int = Field(
        default=100, ge=1, description="Maximum burst size for rate limiter"
    )

    # S3 settings
    s3_endpoint: str | None = Field(
        default=None, description="Custom S3 endpoint URL (for MinIO, R2, B2)"
    )
    s3_region: str = Field(default="us-east-1", description="AWS region")
    s3_access_key: str | None = Field(default=None, description="AWS access key ID")
    s3_secret_key: str | None = Field(default=None, description="AWS secret access key")
    s3_prefix: str = Field(default="", description="Optional key prefix for S3 objects")

    # Eviction settings
    eviction_enabled: bool = Field(
        default=False, description="Enable automatic eviction of old blobs"
    )
    eviction_policy: str = Field(
        default="ttl", description="Eviction policy: ttl, lru, or size_quota"
    )
    eviction_max_age_days: int = Field(
        default=30, ge=1, description="Maximum age for blobs in days (TTL policy)"
    )
    eviction_interval_hours: int = Field(
        default=24, ge=1, description="Interval between eviction runs in hours"
    )
    eviction_max_size_gb: int = Field(
        default=100, ge=1, description="Maximum total size in GB (size_quota policy)"
    )
    eviction_target_size_gb: int = Field(
        default=80, ge=1, description="Target size in GB after eviction (size_quota policy)"
    )

    # Dashboard settings
    dashboard_enabled: bool = Field(default=False, description="Enable web dashboard")
    dashboard_port: int = Field(default=8080, ge=1, le=65535, description="Dashboard HTTP port")
    dashboard_host: str = Field(default="0.0.0.0", description="Dashboard bind address")

    # TLS settings
    tls_enabled: bool = Field(default=False, description="Enable TLS for gRPC")
    tls_cert_file: Path | None = Field(default=None, description="TLS certificate file")
    tls_key_file: Path | None = Field(default=None, description="TLS private key file")
    tls_ca_cert_file: Path | None = Field(default=None, description="TLS CA certificate for mTLS")

    # Audit settings
    audit_log_enabled: bool = Field(default=False, description="Enable audit logging")
    audit_log_file: Path = Field(
        default=Path("/var/log/cas/audit.log"), description="Audit log file path"
    )

    @field_validator("storage_type")
    @classmethod
    def validate_storage_type(cls, v: str) -> str:
        """Validate storage type is supported."""
        valid_types = ["filesystem", "s3", "memory"]
        if v not in valid_types:
            raise ValueError(f"Invalid storage_type: {v}. Must be one of: {', '.join(valid_types)}")
        return v

    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        """Validate log level is recognized."""
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR"]
        upper_v = v.upper()
        if upper_v not in valid_levels:
            raise ValueError(f"Invalid log_level: {v}. Must be one of: {', '.join(valid_levels)}")
        return upper_v

    @field_validator("log_format")
    @classmethod
    def validate_log_format(cls, v: str) -> str:
        """Validate log format is recognized."""
        valid_formats = ["json", "text"]
        if v not in valid_formats:
            raise ValueError(f"Invalid log_format: {v}. Must be one of: {', '.join(valid_formats)}")
        return v

    @field_validator("eviction_policy")
    @classmethod
    def validate_eviction_policy(cls, v: str) -> str:
        """Validate eviction policy is recognized."""
        valid_policies = ["ttl", "lru", "size_quota"]
        if v not in valid_policies:
            raise ValueError(
                f"Invalid eviction_policy: {v}. Must be one of: {', '.join(valid_policies)}"
            )
        return v

    @field_validator("reapi_versions", mode="before")
    @classmethod
    def parse_reapi_versions(cls, v) -> list[str]:
        """Parse comma-separated REAPI versions string into list."""
        if isinstance(v, str):
            return [version.strip() for version in v.split(",")]
        return v

    @model_validator(mode="after")
    def validate_tls_files(self) -> CASConfig:
        """Validate TLS configuration consistency."""
        if self.tls_enabled:
            if not self.tls_cert_file or not self.tls_key_file:
                raise ValueError(
                    "TLS enabled but certificate or key file not specified. "
                    "Set CAS_TLS_CERT_FILE and CAS_TLS_KEY_FILE"
                )
        return self

    @model_validator(mode="after")
    def validate_eviction_size_quota(self) -> CASConfig:
        """Validate size quota policy configuration."""
        if self.eviction_policy == "size_quota":
            if self.eviction_target_size_gb >= self.eviction_max_size_gb:
                raise ValueError(
                    f"eviction_target_size_gb ({self.eviction_target_size_gb}) must be less than "
                    f"eviction_max_size_gb ({self.eviction_max_size_gb})"
                )
        return self

    def validate(self) -> None:
        """
        Legacy validate method for backward compatibility.

        Pydantic handles validation automatically, so this is mostly a no-op.
        We log successful validation for consistency with old behavior.
        """
        logger.info("Configuration validated successfully")


def _find_config_file() -> Path | None:
    """
    Search for config file in standard locations.

    Searches in priority order:
    1. ./cascache_server.yaml (current directory)
    2. ~/.config/cascache_server/config.yaml (user config)
    3. /etc/cascache_server/config.yaml (system config)

    Returns:
        Path to config file if found, None otherwise
    """
    search_paths = [
        Path.cwd() / "cascache_server.yaml",
        Path.home() / ".config" / "cascache_server" / "config.yaml",
        Path("/etc/cascache_server/config.yaml"),
    ]

    for path in search_paths:
        if path.exists() and path.is_file():
            logger.info(f"Found config file: {path}")
            return path

    logger.debug("No config file found in standard locations")
    return None


def _load_env_overrides() -> dict:
    """
    Load configuration overrides from environment variables.

    Looks for env vars with CAS_ prefix and returns a dict with normalized keys.
    Type conversions are handled by Pydantic.

    Returns:
        Dict of config overrides from environment variables
    """
    overrides = {}

    # Map of env var names to config field names
    env_mappings = {
        "CAS_STORAGE_TYPE": "storage_type",
        "CAS_STORAGE_PATH": "storage_path",
        "CAS_PORT": "port",
        "CAS_HOST": "host",
        "CAS_WORKERS": "workers",
        "CAS_MAX_BLOB_SIZE": "max_blob_size",
        "CAS_MAX_AGE_DAYS": "max_age_days",
        "CAS_MAX_BATCH_SIZE": "max_batch_size",
        "CAS_LOG_LEVEL": "log_level",
        "CAS_LOG_FORMAT": "log_format",
        "CAS_REAPI_VERSIONS": "reapi_versions",
        "CAS_ENABLE_CACHE": "enable_cache",
        "CAS_CACHE_SIZE": "cache_size",
        "CAS_CACHE_MAX_BLOB_SIZE": "cache_max_blob_size",
        "CAS_AUTH_ENABLED": "auth_enabled",
        "CAS_AUTH_TOKENS_FILE": "auth_tokens_file",
        "CAS_RATE_LIMIT_ENABLED": "rate_limit_enabled",
        "CAS_RATE_LIMIT_RPS": "rate_limit_rps",
        "CAS_RATE_LIMIT_BURST": "rate_limit_burst",
        "CAS_S3_ENDPOINT": "s3_endpoint",
        "CAS_S3_REGION": "s3_region",
        "CAS_S3_ACCESS_KEY": "s3_access_key",
        "CAS_S3_SECRET_KEY": "s3_secret_key",
        "CAS_S3_PREFIX": "s3_prefix",
        "CAS_EVICTION_ENABLED": "eviction_enabled",
        "CAS_EVICTION_POLICY": "eviction_policy",
        "CAS_EVICTION_MAX_AGE_DAYS": "eviction_max_age_days",
        "CAS_EVICTION_INTERVAL_HOURS": "eviction_interval_hours",
        "CAS_EVICTION_MAX_SIZE_GB": "eviction_max_size_gb",
        "CAS_EVICTION_TARGET_SIZE_GB": "eviction_target_size_gb",
        "CAS_DASHBOARD_ENABLED": "dashboard_enabled",
        "CAS_DASHBOARD_PORT": "dashboard_port",
        "CAS_DASHBOARD_HOST": "dashboard_host",
        "CAS_TLS_ENABLED": "tls_enabled",
        "CAS_TLS_CERT_FILE": "tls_cert_file",
        "CAS_TLS_KEY_FILE": "tls_key_file",
        "CAS_TLS_CA_CERT_FILE": "tls_ca_cert_file",
        "CAS_AUDIT_LOG_ENABLED": "audit_log_enabled",
        "CAS_AUDIT_LOG_FILE": "audit_log_file",
    }

    for env_var, field_name in env_mappings.items():
        value = os.getenv(env_var)
        if value is not None:
            # Handle special cases
            if field_name in (
                "auth_enabled",
                "rate_limit_enabled",
                "enable_cache",
                "eviction_enabled",
                "dashboard_enabled",
                "tls_enabled",
                "audit_log_enabled",
            ):
                # Boolean conversion
                overrides[field_name] = value.lower() in ("true", "1", "yes")
            elif field_name in (
                "port",
                "workers",
                "max_blob_size",
                "max_age_days",
                "max_batch_size",
                "cache_size",
                "cache_max_blob_size",
                "rate_limit_burst",
                "eviction_max_age_days",
                "eviction_interval_hours",
                "eviction_max_size_gb",
                "eviction_target_size_gb",
                "dashboard_port",
            ):
                # Integer conversion
                overrides[field_name] = int(value)
            elif field_name == "rate_limit_rps":
                # Float conversion
                overrides[field_name] = float(value)
            elif field_name in (
                "auth_tokens_file",
                "tls_cert_file",
                "tls_key_file",
                "tls_ca_cert_file",
                "audit_log_file",
            ):
                # Path conversion
                overrides[field_name] = Path(value)
            else:
                # String values
                overrides[field_name] = value

    return overrides


def load_config(config_file: Path | None = None) -> CASConfig:
    """
    Load configuration from YAML file and/or environment variables.

    Configuration is loaded in the following priority (highest to lowest):
    1. Environment variables (CAS_* prefix)
    2. Specified config file (if config_file parameter provided)
    3. Auto-discovered config file (./cascache_server.yaml, ~/.config/cascache_server/config.yaml, /etc/cascache_server/config.yaml)
    4. Default values from CASConfig

    Args:
        config_file: Optional explicit path to config file

    Returns:
        CASConfig instance with all settings

    Raises:
        ConfigError: If configuration is invalid

    Example:
        >>> # Load from auto-discovered file + env vars
        >>> config = load_config()

        >>> # Load from specific file + env vars
        >>> config = load_config(Path("my-config.yaml"))

        >>> # Override with env var
        >>> os.environ['CAS_PORT'] = '50052'
        >>> config = load_config()
        >>> config.port
        50052
    """
    # Try to find config file if not explicitly provided
    if config_file is None:
        config_file = _find_config_file()

    # Load config data from YAML file if available
    config_data = {}
    if config_file is not None:
        try:
            with open(config_file) as f:
                yaml_data = yaml.safe_load(f) or {}
                # Convert yaml keys to match field names (remove CAS_ prefix if present)
                for key, value in yaml_data.items():
                    # Normalize key: remove CAS_ prefix and convert to lowercase
                    normalized_key = key.lower()
                    if normalized_key.startswith("cas_"):
                        normalized_key = normalized_key[4:]
                    config_data[normalized_key] = value

            logger.info(
                "Loaded configuration from file",
                extra={
                    "config_file": str(config_file),
                    "keys_loaded": len(config_data),
                },
            )
        except Exception as e:
            raise ConfigError(f"Failed to load config file {config_file}: {e}")

    # Load environment variable overrides
    env_overrides = _load_env_overrides()
    if env_overrides:
        logger.debug(
            "Applying environment variable overrides",
            extra={"overridden_keys": list(env_overrides.keys())},
        )

    # Merge config data: file data + env overrides
    # Environment variables take precedence
    merged_data = {**config_data, **env_overrides}

    # Create config instance with merged data
    try:
        config = CASConfig(**merged_data)
    except Exception as e:
        raise ConfigError(f"Invalid configuration: {e}")

    # Legacy validate() call for compatibility
    config.validate()

    logger.info(
        "Configuration loaded successfully",
        extra={
            "storage_type": config.storage_type,
            "storage_path": config.storage_path,
            "port": config.port,
            "reapi_versions": config.reapi_versions,
            "config_source": "file" if config_file else "environment",
        },
    )

    return config


def create_storage_from_config(config: CASConfig):
    """
    Factory function to create storage backend from configuration.

    Args:
        config: CAS configuration

    Returns:
        StorageBackend instance (optionally wrapped with CachedStorage)

    Raises:
        ConfigError: If storage type is not supported
    """
    from .storage import CachedStorage, FilesystemStorage, MemoryStorage, S3Storage

    # Create base storage backend
    if config.storage_type == "filesystem":
        logger.info("Creating filesystem storage", extra={"path": config.storage_path})
        backend = FilesystemStorage(config.storage_path)
    elif config.storage_type == "memory":
        logger.info("Creating memory storage (testing only)")
        backend = MemoryStorage()
    elif config.storage_type == "s3":
        logger.info(
            "Creating S3 storage",
            extra={
                "bucket": config.storage_path,
                "endpoint": config.s3_endpoint or "AWS S3",
                "region": config.s3_region,
                "prefix": config.s3_prefix or "(none)",
            },
        )
        backend = S3Storage(
            bucket=config.storage_path,
            endpoint_url=config.s3_endpoint,
            region=config.s3_region,
            access_key=config.s3_access_key,
            secret_key=config.s3_secret_key,
            prefix=config.s3_prefix,
        )
    else:
        raise ConfigError(f"Unknown storage type: {config.storage_type}")

    # Wrap with cache layer if enabled
    if config.enable_cache:
        logger.info(
            "Enabling LRU cache layer",
            extra={
                "cache_size": config.cache_size,
                "max_blob_size": config.cache_max_blob_size,
            },
        )
        return CachedStorage(
            backend=backend,
            cache_size=config.cache_size,
            max_blob_size=config.cache_max_blob_size,
        )

    return backend
