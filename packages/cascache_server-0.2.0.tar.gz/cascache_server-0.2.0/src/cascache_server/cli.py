"""CLI entry point for cascache_server."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

from cascache_server._version import __version__

app = typer.Typer(
    name="cascache_server",
    help="Flexible ContentAddressableStorage written in python",
    no_args_is_help=True,
    add_completion=False,
)
admin_app = typer.Typer(
    name="admin",
    help="Administrative commands",
    no_args_is_help=True,
)
app.add_typer(admin_app, name="admin")

console = Console()


def version_callback(value: bool):
    """Show version and exit."""
    if value:
        console.print(f"cascache_server version {__version__}")
        raise typer.Exit()


@app.callback()
def main_callback(
    version: Annotated[
        bool | None,
        typer.Option(
            "--version",
            "-V",
            callback=version_callback,
            is_eager=True,
            help="Show version and exit",
        ),
    ] = None,
):
    """Flexible ContentAddressableStorage written in python."""
    pass


@app.command()
def serve(
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Enable verbose output"),
    ] = False,
):
    """Start the CAS gRPC server."""
    from cascache_server.server import main as server_main

    if verbose:
        console.print("[green]Starting CAS server...[/green]")

    server_main()


@admin_app.command("create-token")
def create_token(
    name: Annotated[
        str,
        typer.Option(
            "--name",
            "-n",
            help="Human-readable name for the token (e.g., 'team-ci')",
            prompt="Token name",
        ),
    ],
    expires_days: Annotated[
        int,
        typer.Option(
            "--expires-days",
            "-e",
            help="Number of days until token expires",
        ),
    ] = 30,
    tokens_file: Annotated[
        Path | None,
        typer.Option(
            "--tokens-file",
            "-f",
            help="Path to tokens file (default: from CAS_AUTH_TOKENS_FILE env or /etc/cas/tokens.json)",
        ),
    ] = None,
):
    """Generate a new authentication token."""
    from cascache_server.auth.token_manager import TokenManager

    tokens_path = _get_tokens_file(tokens_file)

    try:
        token_manager = TokenManager(tokens_path)
        token = token_manager.generate_token(name, expires_days)

        console.print("[green]✓ Token created successfully![/green]\n")
        console.print(f"[bold]Token:[/bold] {token}\n")
        console.print(f"[bold]Name:[/bold] {name}")
        console.print(f"[bold]Expires:[/bold] {expires_days} days")
        console.print(f"[bold]Stored in:[/bold] {tokens_path}\n")
        console.print("[yellow]⚠️  Save this token securely - it won't be shown again![/yellow]\n")
        console.print("[bold]Usage (Bazel .bazelrc):[/bold]")
        console.print(f"build --remote_header=authorization=Bearer {token}")

    except Exception as e:
        console.print(f"[red]✗ Error: {e}[/red]")
        raise typer.Exit(code=1)


@admin_app.command("list-tokens")
def list_tokens(
    tokens_file: Annotated[
        Path | None,
        typer.Option(
            "--tokens-file",
            "-f",
            help="Path to tokens file (default: from CAS_AUTH_TOKENS_FILE env or /etc/cas/tokens.json)",
        ),
    ] = None,
):
    """List all authentication tokens."""
    from cascache_server.auth.token_manager import TokenManager

    tokens_path = _get_tokens_file(tokens_file)

    try:
        token_manager = TokenManager(tokens_path)
        tokens = token_manager.list_tokens()

        if not tokens:
            console.print("No tokens found.")
            return

        console.print(f"\n[bold]Tokens ({len(tokens)} total):[/bold]\n")

        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("Token ID", width=20)
        table.add_column("Name", width=20)
        table.add_column("Created", width=12)
        table.add_column("Expires", width=12)
        table.add_column("Status", width=10)

        for token in tokens:
            status = (
                "[green]✓ Valid[/green]"
                if token["valid"]
                else ("[red]✗ Revoked[/red]" if token["revoked"] else "[yellow]✗ Expired[/yellow]")
            )
            table.add_row(
                token["token_id"],
                token["name"],
                token["created"][:10],
                token["expires"][:10],
                status,
            )

        console.print(table)

    except FileNotFoundError:
        console.print(f"[red]✗ Tokens file not found: {tokens_path}[/red]")
        console.print(
            "\n[yellow]Create a token first with:[/yellow] cascache_server admin create-token --name <name>"
        )
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[red]✗ Error: {e}[/red]")
        raise typer.Exit(code=1)


@admin_app.command("revoke-token")
def revoke_token(
    token: Annotated[
        str,
        typer.Argument(help="Token string to revoke"),
    ],
    tokens_file: Annotated[
        Path | None,
        typer.Option(
            "--tokens-file",
            "-f",
            help="Path to tokens file (default: from CAS_AUTH_TOKENS_FILE env or /etc/cas/tokens.json)",
        ),
    ] = None,
):
    """Revoke an authentication token."""
    from cascache_server.auth.token_manager import TokenManager

    tokens_path = _get_tokens_file(tokens_file)

    try:
        token_manager = TokenManager(tokens_path)
        success = token_manager.revoke_token(token)

        if success:
            console.print("[green]✓ Token revoked successfully![/green]")
        else:
            console.print("[red]✗ Token not found.[/red]")
            raise typer.Exit(code=1)

    except FileNotFoundError:
        console.print(f"[red]✗ Tokens file not found: {tokens_path}[/red]")
        console.print(
            "\n[yellow]Create a token first with:[/yellow] cascache_server admin create-token --name <name>"
        )
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[red]✗ Error: {e}[/red]")
        raise typer.Exit(code=1)


def _get_tokens_file(tokens_file: Path | None) -> Path:
    """Get tokens file path from argument or environment."""
    if tokens_file:
        return tokens_file

    from_env = os.getenv("CAS_AUTH_TOKENS_FILE")
    if from_env:
        return Path(from_env)

    return Path("/etc/cas/tokens.json")


def main():
    """Main entry point for the CLI."""
    app()


if __name__ == "__main__":
    sys.exit(main())
