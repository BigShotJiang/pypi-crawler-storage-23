"""Rate limiting middleware using token bucket algorithm."""

import threading
import time
from collections import defaultdict
from collections.abc import Callable
from typing import Any

import grpc

from cascache_server.utils.logger import get_logger

logger = get_logger(__name__)


class RateLimiter:
    """
    Thread-safe rate limiter using token bucket algorithm.

    The token bucket algorithm allows bursts while maintaining average rate:
    - Tokens are added at a constant rate (refill_rate)
    - Each request consumes one token
    - If no tokens available, request is rate limited
    - Bucket has maximum capacity to prevent unlimited bursts

    Attributes:
        rate: Maximum requests per second (tokens added per second)
        burst: Maximum burst size (bucket capacity)
    """

    def __init__(self, rate: float = 1000.0, burst: int = 100):
        """
        Initialize rate limiter.

        Args:
            rate: Requests per second (default: 1000)
            burst: Maximum burst size (default: 100)
        """
        self.rate = rate
        self.burst = burst
        self._lock = threading.Lock()
        # Per-client buckets: {client_id: (tokens, last_refill_time)}
        self._buckets: dict[str, tuple[float, float]] = defaultdict(
            lambda: (float(burst), time.monotonic())
        )

        logger.info(
            "Rate limiter initialized",
            extra={"rate": rate, "burst": burst},
        )

    def _refill_bucket(self, client_id: str) -> None:
        """
        Refill tokens for a client bucket (called under lock).

        Args:
            client_id: Client identifier
        """
        tokens, last_refill = self._buckets[client_id]
        now = time.monotonic()
        elapsed = now - last_refill

        # Add tokens based on elapsed time
        new_tokens = min(self.burst, tokens + (elapsed * self.rate))
        self._buckets[client_id] = (new_tokens, now)

    def acquire(self, client_id: str = "default", tokens: int = 1) -> bool:
        """
        Try to acquire tokens for a request.

        Args:
            client_id: Client identifier (e.g., IP address, user ID)
            tokens: Number of tokens to consume (default: 1)

        Returns:
            True if tokens acquired (request allowed), False if rate limited
        """
        with self._lock:
            self._refill_bucket(client_id)
            current_tokens, last_refill = self._buckets[client_id]

            if current_tokens >= tokens:
                # Consume tokens
                self._buckets[client_id] = (current_tokens - tokens, last_refill)
                return True
            else:
                # Rate limited
                logger.debug(
                    "Rate limit exceeded",
                    extra={
                        "client_id": client_id,
                        "tokens_available": current_tokens,
                        "tokens_requested": tokens,
                    },
                )
                return False

    def reset(self, client_id: str) -> None:
        """
        Reset rate limit for a client (useful for testing).

        Args:
            client_id: Client identifier
        """
        with self._lock:
            if client_id in self._buckets:
                del self._buckets[client_id]

    def get_stats(self) -> dict[str, Any]:
        """
        Get rate limiter statistics.

        Returns:
            Dictionary with rate limiter stats
        """
        with self._lock:
            return {
                "rate": self.rate,
                "burst": self.burst,
                "active_clients": len(self._buckets),
            }


class RateLimitInterceptor(grpc.ServerInterceptor):
    """
    gRPC interceptor for rate limiting requests.

    Checks rate limits before processing requests and returns
    RESOURCE_EXHAUSTED status if limit exceeded.
    """

    def __init__(self, rate_limiter: RateLimiter):
        """
        Initialize rate limit interceptor.

        Args:
            rate_limiter: RateLimiter instance
        """
        self.rate_limiter = rate_limiter
        logger.info("Rate limit interceptor initialized")

    def intercept_service(
        self,
        continuation: Callable[[grpc.HandlerCallDetails], grpc.RpcMethodHandler],
        handler_call_details: grpc.HandlerCallDetails,
    ) -> grpc.RpcMethodHandler:
        """
        Intercept gRPC service calls for rate limiting.

        Args:
            continuation: Next handler in the chain
            handler_call_details: Details about the RPC call

        Returns:
            RPC method handler (possibly rate limited)
        """
        # Extract client identifier from metadata
        # Use peer address as default, can be overridden with client-id header
        client_id: str = "unknown"
        invocation_metadata = dict(handler_call_details.invocation_metadata)

        # Try to get client ID from metadata
        if "client-id" in invocation_metadata:
            client_id_raw = invocation_metadata["client-id"]
            client_id = (
                client_id_raw.decode("utf-8") if isinstance(client_id_raw, bytes) else client_id_raw
            )
        # TODO: Could extract from peer address in the future
        # For now, use method name as basic identifier
        else:
            client_id = handler_call_details.method

        # Check rate limit
        if not self.rate_limiter.acquire(client_id):
            # Rate limited - return error
            def rate_limited(_request, _context):
                _context.abort(
                    grpc.StatusCode.RESOURCE_EXHAUSTED,
                    f"Rate limit exceeded for {client_id}. Try again later.",
                )

            return grpc.unary_unary_rpc_method_handler(
                rate_limited,
                request_deserializer=lambda x: x,  # type: ignore[arg-type]
                response_serializer=lambda x: x,  # type: ignore[arg-type]
            )

        # Not rate limited - proceed with request
        return continuation(handler_call_details)
