"""Enable 'python -m cascache_server'."""

from __future__ import annotations

from cascache_server.server import main

if __name__ == "__main__":
    main()
