"""Core data types for CAS server."""

from dataclasses import dataclass
from datetime import datetime


@dataclass
class Digest:
    """
    Represents a content hash (digest) of a blob.

    Digests are used as keys for content-addressable storage.
    The hash is a SHA256 hex string and size_bytes is the blob size.

    Attributes:
        hash: SHA256 hex string (64 characters)
        size_bytes: Size of the blob in bytes
    """

    hash: str
    size_bytes: int

    def __post_init__(self):
        """Validate digest fields."""
        if len(self.hash) != 64:
            raise ValueError(f"Digest hash must be 64 characters, got {len(self.hash)}")
        if self.size_bytes < 0:
            raise ValueError(f"Digest size must be non-negative, got {self.size_bytes}")


@dataclass
class Blob:
    """
    Represents a piece of content with its digest.

    Attributes:
        digest: Content digest (hash + size)
        data: Raw blob data as bytes
    """

    digest: Digest
    data: bytes

    def __post_init__(self):
        """Validate blob data matches digest."""
        if len(self.data) != self.digest.size_bytes:
            raise ValueError(
                f"Blob data size {len(self.data)} doesn't match digest size {self.digest.size_bytes}"
            )


@dataclass
class ActionResult:
    """
    Result of a build action.

    Contains information about the action execution, including
    output files, exit code, and timing information.

    Attributes:
        action_digest: Digest of the action that was executed
        output_digests: List of output file digests produced
        exit_code: Exit code of the action execution
        timestamp: When the action was executed
    """

    action_digest: Digest
    output_digests: list[Digest]
    exit_code: int
    timestamp: datetime
