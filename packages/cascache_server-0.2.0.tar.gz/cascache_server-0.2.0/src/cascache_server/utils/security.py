"""Security utilities for file permissions and validation."""

from __future__ import annotations

import os
import stat
from pathlib import Path

from cascache_server.utils.errors import ConfigError
from cascache_server.utils.logger import get_logger

logger = get_logger(__name__)


def check_file_permissions(file_path: Path, expected_mode: int = 0o600) -> None:
    """
    Check that a file has the expected permissions (owner-only by default).

    Args:
        file_path: Path to file to check
        expected_mode: Expected permission bits (default: 0o600 = owner read/write only)

    Raises:
        ConfigError: If file permissions are too permissive
        FileNotFoundError: If file doesn't exist

    Example:
        >>> check_file_permissions(Path("/etc/cas/tokens.json"))
        # Raises ConfigError if not mode 600
    """
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    # Get file stats
    file_stat = file_path.stat()
    file_mode = stat.S_IMODE(file_stat.st_mode)

    # Check if file is readable/writable by group or others
    group_other_bits = file_mode & 0o077
    if group_other_bits != 0:
        actual_str = oct(file_mode)
        expected_str = oct(expected_mode)
        raise ConfigError(
            f"Insecure file permissions on {file_path}: {actual_str}. "
            f"Expected {expected_str} (owner-only access). "
            f"Fix with: chmod {expected_str} {file_path}"
        )

    logger.debug(f"File permissions verified: {file_path}")


def fix_file_permissions(file_path: Path, mode: int = 0o600) -> None:
    """
    Set file permissions to owner-only.

    Args:
        file_path: Path to file to fix
        mode: Permission mode to set (default: 0o600)

    Example:
        >>> fix_file_permissions(Path("/etc/cas/tokens.json"))
    """
    try:
        os.chmod(file_path, mode)
        logger.info(f"Fixed file permissions: {file_path} -> {oct(mode)}")
    except OSError as e:
        logger.error(f"Failed to fix file permissions on {file_path}: {e}")
        raise ConfigError(f"Cannot fix file permissions: {e}") from e
