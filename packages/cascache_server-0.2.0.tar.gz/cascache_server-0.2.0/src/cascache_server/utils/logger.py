"""Structured logging setup for CAS server."""

import logging
import sys
from typing import Any

# Global logger instances cache
_loggers: dict[str, logging.Logger] = {}


def setup_logging(
    level: str = "INFO",
    format_type: str = "json",
) -> None:
    """
    Set up logging configuration for the CAS server.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR)
        format_type: Log format ('json' or 'text')
    """
    log_level = getattr(logging, level.upper(), logging.INFO)

    if format_type == "json":
        # JSON structured logging (for production)
        formatter = logging.Formatter(
            '{"timestamp": "%(asctime)s", "level": "%(levelname)s", '
            '"logger": "%(name)s", "message": "%(message)s"}'
        )
    else:
        # Text logging (for development)
        formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)

    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    root_logger.handlers.clear()
    root_logger.addHandler(handler)


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance for the given name.

    Args:
        name: Logger name (typically __name__)

    Returns:
        Logger instance

    Example:
        >>> logger = get_logger(__name__)
        >>> logger.info("Server started")
    """
    if name not in _loggers:
        _loggers[name] = logging.getLogger(name)
    return _loggers[name]


def log_operation(
    logger: logging.Logger,
    level: str,
    message: str,
    **kwargs: Any,
) -> None:
    """
    Log an operation with structured context.

    Args:
        logger: Logger instance
        level: Log level (info, debug, warning, error)
        message: Log message
        **kwargs: Additional context fields

    Example:
        >>> logger = get_logger(__name__)
        >>> log_operation(
        ...     logger, "info", "Blob stored",
        ...     digest="abc123", size_bytes=1024
        ... )
    """
    log_func = getattr(logger, level.lower())
    if kwargs:
        extra_str = " - " + ", ".join(f"{k}={v}" for k, v in kwargs.items())
        log_func(message + extra_str)
    else:
        log_func(message)
