"""Security audit logging utilities."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from cascache_server.utils.logger import get_logger

logger = get_logger(__name__)


class AuditLogger:
    """
    Security audit logger for tracking security-relevant events.

    Events logged:
    - Authentication failures
    - Authorization failures
    - Blob deletions
    - Rate limit violations
    - Configuration changes
    - Token operations
    """

    def __init__(self, enabled: bool = False, log_file: Path | None = None):
        """
        Initialize audit logger.

        Args:
            enabled: Whether audit logging is enabled
            log_file: Path to audit log file (None = use standard logger only)
        """
        self.enabled = enabled
        self.log_file = log_file

        if enabled and log_file:
            # Create log directory if needed
            log_file.parent.mkdir(parents=True, exist_ok=True)
            logger.info(f"Audit logging enabled: {log_file}")

    def log(
        self,
        event_type: str,
        success: bool = True,
        **details: Any,
    ) -> None:
        """
        Log a security audit event.

        Args:
            event_type: Type of event (AUTH_FAILURE, BLOB_DELETED, etc.)
            success: Whether the operation succeeded
            **details: Additional event details
        """
        if not self.enabled:
            return

        event = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "event_type": event_type,
            "success": success,
            **details,
        }

        # Log to standard logger
        log_method = logger.info if success else logger.warning
        log_method(
            f"AUDIT: {event_type}",
            extra={"audit_event": event},
        )

        # Also write to dedicated audit log file
        if self.log_file:
            try:
                with open(self.log_file, "a") as f:
                    f.write(json.dumps(event) + "\n")
            except OSError as e:
                logger.error(f"Failed to write audit log: {e}")

    def auth_failure(self, reason: str, client_ip: str | None = None, **details: Any) -> None:
        """Log authentication failure."""
        self.log(
            "AUTH_FAILURE",
            success=False,
            reason=reason,
            client_ip=client_ip,
            **details,
        )

    def auth_success(self, token_name: str | None = None, client_ip: str | None = None) -> None:
        """Log successful authentication."""
        self.log(
            "AUTH_SUCCESS",
            success=True,
            token_name=token_name,
            client_ip=client_ip,
        )

    def rate_limit_exceeded(self, client_ip: str | None = None, **details: Any) -> None:
        """Log rate limit violation."""
        self.log(
            "RATE_LIMIT_EXCEEDED",
            success=False,
            client_ip=client_ip,
            **details,
        )

    def blob_deleted(self, digest: str, size: int, user: str | None = None) -> None:
        """Log blob deletion."""
        self.log(
            "BLOB_DELETED",
            success=True,
            digest=digest[:16] + "...",
            size=size,
            user=user,
        )

    def token_created(self, token_name: str, expires_days: int, creator: str | None = None) -> None:
        """Log token creation."""
        self.log(
            "TOKEN_CREATED",
            success=True,
            token_name=token_name,
            expires_days=expires_days,
            creator=creator,
        )

    def token_revoked(self, token_name: str, revoker: str | None = None) -> None:
        """Log token revocation."""
        self.log(
            "TOKEN_REVOKED",
            success=True,
            token_name=token_name,
            revoker=revoker,
        )

    def config_changed(self, setting: str, old_value: Any, new_value: Any) -> None:
        """Log configuration change."""
        self.log(
            "CONFIG_CHANGED",
            success=True,
            setting=setting,
            old_value=str(old_value),
            new_value=str(new_value),
        )


# Global audit logger instance
_audit_logger: AuditLogger | None = None


def init_audit_logger(enabled: bool, log_file: Path | None = None) -> None:
    """Initialize global audit logger."""
    global _audit_logger
    _audit_logger = AuditLogger(enabled=enabled, log_file=log_file)


def get_audit_logger() -> AuditLogger:
    """Get global audit logger instance."""
    if _audit_logger is None:
        # Return disabled logger by default
        return AuditLogger(enabled=False)
    return _audit_logger
