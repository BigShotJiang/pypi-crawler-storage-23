"""Custom exception classes for CAS server."""


class CASError(Exception):
    """Base exception for all CAS server errors."""

    pass


class DigestError(CASError):
    """Raised when digest validation fails."""

    pass


class StorageError(CASError):
    """Raised when storage backend operations fail."""

    pass


class ConfigError(CASError):
    """Raised when configuration is invalid."""

    pass
