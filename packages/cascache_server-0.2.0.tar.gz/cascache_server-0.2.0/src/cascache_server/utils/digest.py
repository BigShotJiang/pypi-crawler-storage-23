"""Digest computation and validation utilities."""

import hashlib

from cascache_server.models.types import Digest
from cascache_server.utils.errors import DigestError


def compute_digest(data: bytes) -> Digest:
    """
    Compute SHA256 digest for blob data.

    Args:
        data: Blob data as bytes

    Returns:
        Digest object with hash and size

    Example:
        >>> data = b"hello world"
        >>> digest = compute_digest(data)
        >>> digest.size_bytes
        11
    """
    hash_obj = hashlib.sha256(data)
    return Digest(hash=hash_obj.hexdigest(), size_bytes=len(data))


def validate_digest(hash_str: str, size_bytes: int) -> None:
    """
    Validate digest format.

    Args:
        hash_str: SHA256 hex string
        size_bytes: Size in bytes

    Raises:
        DigestError: If digest format is invalid

    Example:
        >>> validate_digest("a" * 64, 100)  # OK
        >>> validate_digest("abc", 100)  # Raises DigestError
    """
    if len(hash_str) != 64:
        raise DigestError(f"Digest hash must be 64 characters, got {len(hash_str)}")

    try:
        int(hash_str, 16)
    except ValueError:
        raise DigestError(f"Digest hash must be hexadecimal, got {hash_str[:16]}...")

    if size_bytes < 0:
        raise DigestError(f"Digest size must be non-negative, got {size_bytes}")


def verify_blob(data: bytes, digest: Digest) -> bool:
    """
    Verify that blob data matches its digest.

    Args:
        data: Blob data to verify
        digest: Expected digest

    Returns:
        True if data matches digest, False otherwise

    Example:
        >>> data = b"hello"
        >>> digest = compute_digest(data)
        >>> verify_blob(data, digest)
        True
        >>> verify_blob(b"world", digest)
        False
    """
    computed = compute_digest(data)
    return computed.hash == digest.hash and computed.size_bytes == digest.size_bytes
