"""Capabilities service for remote cache system.

This service allows clients to query what the server supports,
which is required by Bazel for proper remote cache interaction.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cascache_server.config import CASConfig

logger = logging.getLogger(__name__)


class CapabilitiesService:
    """Service for querying server capabilities.

    Provides information about:
    - Supported digest functions (SHA256)
    - Cache capabilities
    - API versions supported
    - Maximum batch sizes
    """

    def __init__(self, config: CASConfig):
        """Initialize capabilities service.

        Args:
            config: Server configuration
        """
        self.config = config
        logger.info("Capabilities service initialized")

    def get_capabilities(self, instance_name: str) -> dict:
        """Get server capabilities.

        Args:
            instance_name: Remote instance name (optional)

        Returns:
            Dictionary with server capabilities
        """
        logger.debug(f"GetCapabilities called for instance: {instance_name or '(default)'}")

        return {
            "cache_capabilities": {
                "digest_function": ["SHA256"],  # We only support SHA256 for now
                "action_cache_update_capabilities": {
                    "update_enabled": True  # ActionCache fully implemented
                },
                "max_batch_total_size_bytes": 4 * 1024 * 1024,  # 4MB batch limit
                "compression_supported": False,  # MVP: Not yet implemented
            },
            "execution_capabilities": {
                "digest_function": "SHA256",
                "exec_enabled": False,  # MVP: No remote execution, cache only
            },
            "low_api_version": {"major": 2, "minor": 0, "patch": 0, "prerelease": ""},
            "high_api_version": {"major": 2, "minor": 0, "patch": 0, "prerelease": ""},
        }
