"""Content Addressable Storage service implementation."""

from cascache_server.monitoring.metrics import metrics
from cascache_server.storage.base import StorageBackend
from cascache_server.utils.digest import validate_digest
from cascache_server.utils.errors import DigestError
from cascache_server.utils.logger import get_logger

logger = get_logger(__name__)


class ContentAddressableStorageService:
    """
    Main CAS service implementing business logic.

    This service handles blob operations, validates inputs,
    records metrics, and coordinates with the storage backend.

    Args:
        storage: Storage backend implementation
        max_batch_size: Maximum number of digests per batch request (default: 1000)
    """

    def __init__(self, storage: StorageBackend, max_batch_size: int = 1000):
        """Initialize CAS service with storage backend."""
        self.storage = storage
        self.max_batch_size = max_batch_size
        logger.info(
            "CAS service initialized",
            extra={"storage": type(storage).__name__, "max_batch_size": max_batch_size},
        )

    def find_missing_blobs(self, digests: list[str]) -> list[str]:
        """
        Find which blobs don't exist in storage.

        Args:
            digests: List of digest hash strings to check

        Returns:
            List of digest hashes that don't exist in storage

        Raises:
            ValueError: If batch size exceeds limit or digest format invalid

        Example:
            >>> service.find_missing_blobs(["abc123", "def456"])
            ["def456"]  # abc123 exists, def456 doesn't
        """
        # Validate batch size
        if len(digests) > self.max_batch_size:
            raise ValueError(f"Batch size {len(digests)} exceeds maximum {self.max_batch_size}")

        # Validate all digests
        for digest in digests:
            try:
                validate_digest(digest, size_bytes=0)  # Size unknown at this point
            except DigestError as e:
                raise ValueError(f"Invalid digest '{digest[:16]}...': {e}") from e

        missing = []
        for digest in digests:
            if not self.storage.exists(digest):
                missing.append(digest)
                metrics.record_miss()
            else:
                metrics.record_hit()

        logger.info(
            "Missing blobs check completed",
            extra={
                "total_digests": len(digests),
                "missing_count": len(missing),
                "hit_count": len(digests) - len(missing),
            },
        )
        return missing

    def batch_read_blobs(self, digests: list[str]) -> dict[str, bytes | None]:
        """
        Read multiple blobs from storage.

        Args:
            digests: List of digest hash strings to read

        Returns:
            Dictionary mapping digest to blob data (or None if not found)

        Raises:
            ValueError: If batch size exceeds limit or digest format invalid

        Example:
            >>> service.batch_read_blobs(["abc123", "def456"])
            {"abc123": b"data", "def456": None}
        """
        # Validate batch size
        if len(digests) > self.max_batch_size:
            raise ValueError(f"Batch size {len(digests)} exceeds maximum {self.max_batch_size}")

        # Validate all digests
        for digest in digests:
            try:
                validate_digest(digest, size_bytes=0)
            except DigestError as e:
                raise ValueError(f"Invalid digest '{digest[:16]}...': {e}") from e

        result = {}
        for digest in digests:
            try:
                data = self.storage.get(digest)
                result[digest] = data
                metrics.record_hit()
            except FileNotFoundError:
                result[digest] = None
                metrics.record_miss()
                logger.warning("Blob not found", extra={"digest": digest[:16]})

        logger.info(
            "Batch read completed",
            extra={
                "digest_count": len(digests),
                "found_count": sum(1 for v in result.values() if v is not None),
            },
        )
        return result

    def batch_write_blobs(self, blobs: dict[str, bytes], max_blob_size: int | None = None) -> None:
        """
        Write multiple blobs to storage.

        Args:
            blobs: Dictionary mapping digest to blob data
            max_blob_size: Maximum allowed blob size in bytes (optional)

        Raises:
            ValueError: If batch size exceeds limit, digest format invalid, or blob too large

        Example:
            >>> service.batch_write_blobs({"abc123": b"data"})
        """
        # Validate batch size
        if len(blobs) > self.max_batch_size:
            raise ValueError(f"Batch size {len(blobs)} exceeds maximum {self.max_batch_size}")

        total_bytes = 0
        for digest, data in blobs.items():
            # Validate digest format
            size = len(data)
            try:
                validate_digest(digest, size_bytes=size)
            except DigestError as e:
                raise ValueError(f"Invalid digest '{digest[:16]}...': {e}") from e

            # Validate blob size
            if max_blob_size and size > max_blob_size:
                raise ValueError(
                    f"Blob size {size} exceeds maximum {max_blob_size} for digest {digest[:16]}..."
                )

            # Validate size is non-negative
            if size < 0:
                raise ValueError(f"Invalid blob size {size} for digest {digest[:16]}...")

            self.storage.put(digest, data)
            total_bytes += size
            metrics.record_blob_added(size)

        logger.info(
            "Batch write completed",
            extra={"blob_count": len(blobs), "total_bytes": total_bytes},
        )

    def get_blob(self, digest: str) -> bytes:
        """
        Fetch single blob from storage.

        Args:
            digest: Digest hash string

        Returns:
            Blob data

        Raises:
            FileNotFoundError: If blob doesn't exist
        """
        try:
            data = self.storage.get(digest)
            metrics.record_hit()
            logger.debug("Blob retrieved", extra={"digest": digest[:16], "size": len(data)})
            return data
        except FileNotFoundError:
            metrics.record_miss()
            logger.warning("Blob not found", extra={"digest": digest[:16]})
            raise

    def put_blob(self, digest: str, data: bytes) -> None:
        """
        Store single blob.

        Args:
            digest: Digest hash string
            data: Blob data
        """
        self.storage.put(digest, data)
        metrics.record_blob_added(len(data))
        logger.debug("Blob stored", extra={"digest": digest[:16], "size": len(data)})
