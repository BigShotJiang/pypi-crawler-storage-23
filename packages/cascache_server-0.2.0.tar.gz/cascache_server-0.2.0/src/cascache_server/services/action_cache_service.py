"""ActionCache service for caching build action results.

This service stores the mapping between build actions and their results,
allowing Bazel to skip rebuilding if it has already built something identical.

Uses protobuf binary serialization for performance.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from cascache_server.api.generated import action_cache_pb2

if TYPE_CHECKING:
    from cascache_server.storage.base import StorageBackend

logger = logging.getLogger(__name__)


class ActionCacheService:
    """Service for caching action results.

    Stores ActionResult objects keyed by action digest. This allows build
    systems to check if they've already performed a particular action and
    retrieve the cached result instead of re-executing.
    """

    # Prefix for action cache entries to separate from regular blobs
    ACTION_CACHE_PREFIX = "ac_"

    def __init__(self, storage: StorageBackend):
        """Initialize action cache service.

        Args:
            storage: Storage backend for persisting action results
        """
        self.storage = storage
        logger.info("ActionCache service initialized")

    def _get_action_key(self, action_digest: str) -> str:
        """Get storage key for an action digest.

        Args:
            action_digest: Digest of the action (format: "hash/size")

        Returns:
            Storage key with action cache prefix (flattened for filesystem)
        """
        # Replace / with _ to avoid creating nested directories
        safe_digest = action_digest.replace("/", "_")
        return f"{self.ACTION_CACHE_PREFIX}{safe_digest}"

    def get_action_result(
        self, action_digest: str, instance_name: str = ""
    ) -> action_cache_pb2.ActionResult | None:
        """Get cached action result.

        Args:
            action_digest: Digest of the action to look up (format: "hash/size")
            instance_name: Optional instance name for multi-tenancy

        Returns:
            ActionResult proto if found, None otherwise
        """
        key = self._get_action_key(action_digest)

        try:
            # Check if action result exists
            if not self.storage.exists(key):
                logger.debug(
                    "Action cache miss",
                    extra={
                        "action_digest": action_digest,
                        "instance": instance_name or "(default)",
                    },
                )
                return None

            # Retrieve and deserialize protobuf
            data = self.storage.get(key)
            action_result = action_cache_pb2.ActionResult()
            action_result.ParseFromString(data)

            logger.info(
                "Action cache hit",
                extra={
                    "action_digest": action_digest,
                    "instance": instance_name or "(default)",
                    "exit_code": action_result.exit_code,
                    "bytes": len(data),
                },
            )

            return action_result

        except FileNotFoundError:
            logger.debug(f"Action result not found: {action_digest}")
            return None
        except Exception as e:
            logger.error(f"Error retrieving action result: {e}", exc_info=True)
            return None

    def update_action_result(
        self,
        action_digest: str,
        action_result: action_cache_pb2.ActionResult,
        instance_name: str = "",
    ) -> action_cache_pb2.ActionResult:
        """Store action result in cache.

        Args:
            action_digest: Digest of the action (format: "hash/size")
            action_result: ActionResult proto to store
            instance_name: Optional instance name for multi-tenancy

        Returns:
            The stored action result
        """
        key = self._get_action_key(action_digest)

        try:
            # Serialize protobuf to binary (much faster than JSON)
            data = action_result.SerializeToString()

            # Store in cache
            self.storage.put(key, data)

            logger.info(
                "Action result cached",
                extra={
                    "action_digest": action_digest,
                    "instance": instance_name or "(default)",
                    "exit_code": action_result.exit_code,
                    "output_files": len(action_result.output_files),
                    "size_bytes": len(data),
                },
            )

            return action_result

        except Exception as e:
            logger.error(f"Error storing action result: {e}", exc_info=True)
            raise
