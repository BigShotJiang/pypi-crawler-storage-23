"""TTL-based eviction policy."""

from datetime import datetime, timedelta

from cascache_server.eviction.policy import BlobMetadata, EvictionPolicy
from cascache_server.utils.logger import get_logger

logger = get_logger(__name__)


class TTLEvictionPolicy(EvictionPolicy):
    """Time-To-Live (TTL) eviction policy.

    Evicts blobs that haven't been accessed within a specified time period.

    Args:
        max_age_days: Maximum age in days before eviction
    """

    def __init__(self, max_age_days: int = 30):
        if max_age_days <= 0:
            raise ValueError("max_age_days must be positive")

        self.max_age_days = max_age_days
        self.max_age = timedelta(days=max_age_days)
        self._evicted_count = 0
        self._evicted_bytes = 0

        logger.info("TTL eviction policy initialized", extra={"max_age_days": max_age_days})

    def should_evict(self, metadata: BlobMetadata) -> bool:
        """Check if blob has exceeded TTL.

        Args:
            metadata: Blob metadata

        Returns:
            True if blob is older than max_age
        """
        now = datetime.now()
        age = now - metadata.accessed_at
        return age > self.max_age

    def get_eviction_candidates(self, all_metadata: list[BlobMetadata]) -> list[str]:
        """Get all blobs that have exceeded TTL.

        Args:
            all_metadata: List of all blob metadata

        Returns:
            List of digests to evict
        """
        candidates = []
        candidate_bytes = 0

        for metadata in all_metadata:
            if self.should_evict(metadata):
                candidates.append(metadata.digest)
                candidate_bytes += metadata.size

        if candidates:
            logger.info(
                "Found TTL eviction candidates",
                extra={
                    "count": len(candidates),
                    "bytes": candidate_bytes,
                    "max_age_days": self.max_age_days,
                },
            )

        return candidates

    def record_eviction(self, size: int):
        """Record a successful eviction.

        Args:
            size: Size of evicted blob in bytes
        """
        self._evicted_count += 1
        self._evicted_bytes += size

    def get_stats(self) -> dict:
        """Get TTL eviction statistics.

        Returns:
            Dictionary with policy stats
        """
        return {
            "policy": "ttl",
            "max_age_days": self.max_age_days,
            "evicted_count": self._evicted_count,
            "evicted_bytes": self._evicted_bytes,
        }
