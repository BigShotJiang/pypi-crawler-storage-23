"""LRU (Least Recently Used) eviction policy."""

from cascache_server.eviction.policy import BlobMetadata, EvictionPolicy
from cascache_server.utils.logger import get_logger

logger = get_logger(__name__)


class LRUEvictionPolicy(EvictionPolicy):
    """Least Recently Used (LRU) eviction policy.

    Evicts least recently accessed blobs when storage quota is exceeded.

    Args:
        max_size_bytes: Maximum total storage size in bytes
        target_size_bytes: Target size after eviction (default: 80% of max_size_bytes)
    """

    def __init__(self, max_size_bytes: int, target_size_bytes: int | None = None):
        if max_size_bytes <= 0:
            raise ValueError("max_size_bytes must be positive")

        self.max_size_bytes = max_size_bytes

        # Apply default before validation
        if target_size_bytes is None:
            self.target_size_bytes = int(max_size_bytes * 0.8)
        else:
            self.target_size_bytes = target_size_bytes

        if self.target_size_bytes <= 0:
            raise ValueError("target_size_bytes must be positive")
        if self.target_size_bytes > max_size_bytes:
            raise ValueError("target_size_bytes cannot exceed max_size_bytes")

        self._evicted_count = 0
        self._evicted_bytes = 0

        logger.info(
            "LRU eviction policy initialized",
            extra={
                "max_size_bytes": max_size_bytes,
                "target_size_bytes": self.target_size_bytes,
            },
        )

    def should_evict(self, metadata: BlobMetadata) -> bool:
        """Check if eviction is needed (not used for LRU - see get_eviction_candidates).

        Args:
            metadata: Blob metadata

        Returns:
            False (LRU eviction is quota-based, not per-blob)
        """
        # LRU doesn't evict individual blobs - it evicts based on total quota
        # This method exists for protocol compliance but isn't used
        return False

    def get_eviction_candidates(self, all_metadata: list[BlobMetadata]) -> list[str]:
        """Get blobs to evict based on LRU policy.

        If total storage exceeds max_size_bytes, evicts least recently accessed
        blobs until storage is under target_size_bytes.

        Args:
            all_metadata: List of all blob metadata

        Returns:
            List of digests to evict (sorted by accessed_at, oldest first)
        """
        if not all_metadata:
            return []

        # Calculate total storage size
        total_size = sum(m.size for m in all_metadata)

        # Check if eviction is needed
        if total_size <= self.max_size_bytes:
            logger.debug(
                "Storage under quota, no eviction needed",
                extra={
                    "total_size": total_size,
                    "max_size": self.max_size_bytes,
                    "usage_percent": (total_size / self.max_size_bytes) * 100,
                },
            )
            return []

        # Eviction needed - sort by accessed_at (oldest first)
        sorted_metadata = sorted(all_metadata, key=lambda m: m.accessed_at)

        # Select blobs to evict until under target size
        candidates = []
        candidate_bytes = 0
        current_size = total_size

        for metadata in sorted_metadata:
            if current_size <= self.target_size_bytes:
                break

            candidates.append(metadata.digest)
            candidate_bytes += metadata.size
            current_size -= metadata.size

        if candidates:
            logger.info(
                "Found LRU eviction candidates",
                extra={
                    "count": len(candidates),
                    "bytes": candidate_bytes,
                    "total_size_before": total_size,
                    "total_size_after": current_size,
                    "max_size": self.max_size_bytes,
                    "target_size": self.target_size_bytes,
                    "over_quota_bytes": total_size - self.max_size_bytes,
                },
            )

        return candidates

    def record_eviction(self, size: int):
        """Record a successful eviction.

        Args:
            size: Size of evicted blob in bytes
        """
        self._evicted_count += 1
        self._evicted_bytes += size

    def get_stats(self) -> dict:
        """Get LRU eviction statistics.

        Returns:
            Dictionary with policy stats
        """
        return {
            "policy": "lru",
            "max_size_bytes": self.max_size_bytes,
            "target_size_bytes": self.target_size_bytes,
            "evicted_count": self._evicted_count,
            "evicted_bytes": self._evicted_bytes,
        }
