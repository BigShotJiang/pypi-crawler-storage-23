"""Background worker for blob eviction."""

import threading
import time

from cascache_server.eviction.policy import BlobMetadata, EvictionPolicy
from cascache_server.storage.base import StorageBackend
from cascache_server.utils.logger import get_logger

logger = get_logger(__name__)


class EvictionWorker:
    """Background worker that periodically evicts old blobs.

    Runs in a separate thread and applies eviction policies at regular intervals.

    Args:
        storage: Storage backend to evict from
        policy: Eviction policy to apply
        interval_seconds: Time between eviction runs (default: 1 hour)
    """

    def __init__(
        self,
        storage: StorageBackend,
        policy: EvictionPolicy,
        interval_seconds: int = 3600,
    ):
        self.storage = storage
        self.policy = policy
        self.interval_seconds = interval_seconds

        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()

        # Statistics
        self._runs = 0
        self._total_evicted = 0
        self._total_freed_bytes = 0
        self._last_run_time: float | None = None

        logger.info(
            "Eviction worker initialized",
            extra={
                "policy": policy.__class__.__name__,
                "interval_seconds": interval_seconds,
            },
        )

    def start(self):
        """Start the background eviction worker."""
        if self._thread and self._thread.is_alive():
            logger.warning("Eviction worker already running")
            return

        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run_loop,
            name="EvictionWorker",
            daemon=True,
        )
        self._thread.start()

        logger.info("Eviction worker started")

    def stop(self, wait: bool = True):
        """Stop the background eviction worker.

        Args:
            wait: Wait for thread to finish
        """
        if not self._thread or not self._thread.is_alive():
            logger.warning("Eviction worker not running")
            return

        logger.info("Stopping eviction worker")
        self._stop_event.set()

        if wait and self._thread:
            self._thread.join(timeout=5.0)

        logger.info("Eviction worker stopped")

    def _run_loop(self):
        """Main eviction loop (runs in background thread)."""
        logger.info("Eviction worker loop started")

        while not self._stop_event.is_set():
            try:
                # Run eviction
                self._run_eviction()

                # Sleep until next run (or stop signal)
                self._stop_event.wait(timeout=self.interval_seconds)

            except Exception as e:
                logger.error(f"Eviction worker error: {e}", exc_info=True)
                # Continue running despite errors
                self._stop_event.wait(timeout=60)  # Wait 1 min on error

        logger.info("Eviction worker loop exited")

    def _run_eviction(self):
        """Run a single eviction cycle."""
        start_time = time.time()

        logger.info("Starting eviction cycle")

        try:
            # Get all blob metadata
            all_metadata = self._collect_metadata()

            if not all_metadata:
                logger.debug("No blobs to evaluate for eviction")
                # Still increment run counter
                with self._lock:
                    self._runs += 1
                    self._last_run_time = time.time() - start_time
                return

            # Get eviction candidates from policy
            candidates = self.policy.get_eviction_candidates(all_metadata)

            if not candidates:
                logger.info("No blobs selected for eviction")
                # Still increment run counter
                with self._lock:
                    self._runs += 1
                    self._last_run_time = time.time() - start_time
                return

            # Evict blobs
            evicted_count = 0
            freed_bytes = 0

            for digest in candidates:
                try:
                    # Get size before deletion
                    size = self.storage.get_size(digest)

                    # Delete blob
                    self.storage.delete(digest)

                    evicted_count += 1
                    freed_bytes += size

                    # Record in policy
                    self.policy.record_eviction(size)

                    logger.debug(f"Evicted blob {digest} ({size} bytes)")

                except FileNotFoundError:
                    # Blob already deleted (race condition)
                    logger.debug(f"Blob {digest} already deleted")
                except Exception as e:
                    logger.warning(f"Failed to evict blob {digest}: {e}")

            # Update statistics
            with self._lock:
                self._runs += 1
                self._total_evicted += evicted_count
                self._total_freed_bytes += freed_bytes
                self._last_run_time = time.time() - start_time

            logger.info(
                "Eviction cycle completed",
                extra={
                    "evicted": evicted_count,
                    "freed_bytes": freed_bytes,
                    "duration_seconds": self._last_run_time,
                },
            )

        except Exception as e:
            logger.error(f"Eviction cycle failed: {e}", exc_info=True)

    def _collect_metadata(self) -> list[BlobMetadata]:
        """Collect metadata for all blobs.

        Returns:
            List of blob metadata
        """
        from datetime import datetime

        all_metadata = []

        try:
            # List all blobs
            digests = self.storage.list_all()

            for digest in digests:
                try:
                    # Try to get metadata from storage backend
                    metadata = self.storage.get_metadata(digest)

                    if metadata is None:
                        # Fallback: No metadata available, use placeholders
                        size = self.storage.get_size(digest)
                        now = datetime.now()
                        metadata = BlobMetadata(
                            digest=digest,
                            size=size,
                            created_at=now,
                            accessed_at=now,
                        )

                    all_metadata.append(metadata)

                except FileNotFoundError:
                    # Blob was deleted during listing (race condition)
                    logger.debug(f"Blob {digest} not found during metadata collection")
                except Exception as e:
                    logger.warning(f"Failed to get metadata for {digest}: {e}")

        except Exception as e:
            logger.error(f"Failed to list blobs: {e}", exc_info=True)

        return all_metadata

    def get_stats(self) -> dict:
        """Get eviction worker statistics.

        Returns:
            Dictionary with worker stats
        """
        with self._lock:
            return {
                "runs": self._runs,
                "total_evicted": self._total_evicted,
                "total_freed_bytes": self._total_freed_bytes,
                "last_run_duration_seconds": self._last_run_time,
                "interval_seconds": self.interval_seconds,
                "is_running": self._thread.is_alive() if self._thread else False,
            }

    def run_now(self):
        """Trigger an immediate eviction run (blocking).

        This runs in the calling thread, useful for testing.
        """
        logger.info("Running immediate eviction")
        self._run_eviction()
