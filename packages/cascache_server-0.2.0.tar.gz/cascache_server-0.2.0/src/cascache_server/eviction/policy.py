"""Base eviction policy interface."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime

from cascache_server.utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class BlobMetadata:
    """Metadata about a stored blob.

    Attributes:
        digest: Blob digest (unique identifier)
        size: Size in bytes
        created_at: Creation timestamp
        accessed_at: Last access timestamp
    """

    digest: str
    size: int
    created_at: datetime
    accessed_at: datetime


class EvictionPolicy(ABC):
    """Abstract base class for eviction policies.

    Eviction policies determine which blobs should be removed
    to free up space or enforce retention rules.
    """

    @abstractmethod
    def should_evict(self, metadata: BlobMetadata) -> bool:
        """Determine if a blob should be evicted.

        Args:
            metadata: Blob metadata

        Returns:
            True if blob should be evicted, False otherwise
        """
        pass

    @abstractmethod
    def get_eviction_candidates(self, all_metadata: list[BlobMetadata]) -> list[str]:
        """Get list of blob digests to evict.

        Args:
            all_metadata: List of all blob metadata

        Returns:
            List of digests to evict
        """
        pass

    @abstractmethod
    def get_stats(self) -> dict:
        """Get eviction policy statistics.

        Returns:
            Dictionary with policy stats
        """
        pass

    def record_eviction(self, size: int) -> None:
        """Record that a blob was evicted (optional hook for stats tracking).

        Args:
            size: Size in bytes of evicted blob

        Note:
            This is an optional method that policies can override to track evictions.
            Default implementation does nothing.
        """
        pass
