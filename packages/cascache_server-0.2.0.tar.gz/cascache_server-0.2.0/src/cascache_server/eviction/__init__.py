"""Eviction policies for automatic blob cleanup."""

from cascache_server.eviction.lru import LRUEvictionPolicy
from cascache_server.eviction.policy import EvictionPolicy
from cascache_server.eviction.size_quota import SizeQuotaEvictionPolicy
from cascache_server.eviction.ttl import TTLEvictionPolicy
from cascache_server.eviction.worker import EvictionWorker

__all__ = [
    "EvictionPolicy",
    "TTLEvictionPolicy",
    "LRUEvictionPolicy",
    "SizeQuotaEvictionPolicy",
    "EvictionWorker",
]
