"""gRPC service handlers for CAS server."""

import grpc

from cascache_server.api.generated import cas_simple_pb2, cas_simple_pb2_grpc
from cascache_server.services.cas_service import ContentAddressableStorageService
from cascache_server.utils.logger import get_logger

logger = get_logger(__name__)


class ContentAddressableStorageServicer(cas_simple_pb2_grpc.ContentAddressableStorageServicer):
    """
    gRPC servicer for ContentAddressableStorage.

    This is a thin translation layer between gRPC and the service layer.
    No business logic should be implemented here - only protocol translation.

    Args:
        cas_service: CAS service instance with business logic
    """

    def __init__(self, cas_service: ContentAddressableStorageService):
        """Initialize servicer with CAS service."""
        self.cas_service = cas_service
        logger.info("ContentAddressableStorageServicer initialized")

    def FindMissingBlobs(
        self,
        request: cas_simple_pb2.FindMissingBlobsRequest,
        context: grpc.ServicerContext,
    ) -> cas_simple_pb2.FindMissingBlobsResponse:
        """
        Check which blobs are missing from storage.

        Args:
            request: FindMissingBlobsRequest with blob digests to check
            context: gRPC context

        Returns:
            FindMissingBlobsResponse with missing blob digests
        """
        try:
            # Extract digest hashes from request
            digest_hashes = [d.hash for d in request.blob_digests]

            # Call service layer
            missing_hashes = self.cas_service.find_missing_blobs(digest_hashes)

            # Build response
            missing_digests = []
            for hash_str in missing_hashes:
                # Find original digest with size info
                for d in request.blob_digests:
                    if d.hash == hash_str:
                        missing_digests.append(
                            cas_simple_pb2.Digest(hash=d.hash, size_bytes=d.size_bytes)
                        )
                        break

            return cas_simple_pb2.FindMissingBlobsResponse(missing_blob_digests=missing_digests)

        except Exception as e:
            logger.error(f"FindMissingBlobs failed: {e}")
            context.abort(grpc.StatusCode.INTERNAL, str(e))

    def BatchReadBlobs(
        self,
        request: cas_simple_pb2.BatchReadBlobsRequest,
        context: grpc.ServicerContext,
    ) -> cas_simple_pb2.BatchReadBlobsResponse:
        """
        Read multiple blobs from storage.

        Args:
            request: BatchReadBlobsRequest with digests to read
            context: gRPC context

        Returns:
            BatchReadBlobsResponse with blob data
        """
        try:
            # Extract digest hashes
            digest_hashes = [d.hash for d in request.digests]

            # Call service layer
            blob_data = self.cas_service.batch_read_blobs(digest_hashes)

            # Build response
            responses = []
            for digest in request.digests:
                data = blob_data.get(digest.hash)

                if data is not None:
                    # Blob found
                    responses.append(
                        cas_simple_pb2.BatchReadBlobsResponse.Response(
                            digest=cas_simple_pb2.Digest(
                                hash=digest.hash, size_bytes=digest.size_bytes
                            ),
                            data=data,
                            status_code=0,  # OK
                            status_message="OK",
                        )
                    )
                else:
                    # Blob not found
                    responses.append(
                        cas_simple_pb2.BatchReadBlobsResponse.Response(
                            digest=cas_simple_pb2.Digest(
                                hash=digest.hash, size_bytes=digest.size_bytes
                            ),
                            status_code=5,  # NOT_FOUND
                            status_message=f"Blob {digest.hash[:16]}... not found",
                        )
                    )

            return cas_simple_pb2.BatchReadBlobsResponse(responses=responses)

        except Exception as e:
            logger.error(f"BatchReadBlobs failed: {e}")
            context.abort(grpc.StatusCode.INTERNAL, str(e))

    def BatchUpdateBlobs(
        self,
        request: cas_simple_pb2.BatchUpdateBlobsRequest,
        context: grpc.ServicerContext,
    ) -> cas_simple_pb2.BatchUpdateBlobsResponse:
        """
        Write multiple blobs to storage.

        Args:
            request: BatchUpdateBlobsRequest with blobs to write
            context: gRPC context

        Returns:
            BatchUpdateBlobsResponse with upload results
        """
        try:
            # Build dictionary of digests to data
            blobs_to_write = {}
            for req in request.requests:
                # Validate digest matches data
                if len(req.data) != req.digest.size_bytes:
                    context.abort(
                        grpc.StatusCode.INVALID_ARGUMENT,
                        f"Data size {len(req.data)} doesn't match digest size {req.digest.size_bytes}",
                    )
                    return

                blobs_to_write[req.digest.hash] = req.data

            # Call service layer
            self.cas_service.batch_write_blobs(blobs_to_write)

            # Build response - all successful
            responses = []
            for req in request.requests:
                responses.append(
                    cas_simple_pb2.BatchUpdateBlobsResponse.Response(
                        digest=cas_simple_pb2.Digest(
                            hash=req.digest.hash, size_bytes=req.digest.size_bytes
                        ),
                        status_code=0,  # OK
                        status_message="OK",
                    )
                )

            return cas_simple_pb2.BatchUpdateBlobsResponse(responses=responses)

        except Exception as e:
            logger.error(f"BatchUpdateBlobs failed: {e}")
            context.abort(grpc.StatusCode.INTERNAL, str(e))
