"""gRPC handler for ActionCache service.

Translates between gRPC protocol buffer messages and service layer calls.
Optimized to work directly with proto objects without intermediate conversions.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import grpc

from cascache_server.api.generated import action_cache_pb2, action_cache_pb2_grpc

if TYPE_CHECKING:
    from cascache_server.services.action_cache_service import ActionCacheService

logger = logging.getLogger(__name__)


class ActionCacheServicer(action_cache_pb2_grpc.ActionCacheServicer):
    """gRPC servicer for ActionCache.

    Handles GetActionResult and UpdateActionResult RPCs.
    """

    def __init__(self, service: ActionCacheService):
        """Initialize handler.

        Args:
            service: ActionCache service instance
        """
        self.service = service
        logger.info("ActionCache gRPC handler initialized")

    def GetActionResult(
        self, request: action_cache_pb2.GetActionResultRequest, context: grpc.ServicerContext
    ) -> action_cache_pb2.ActionResult:
        """Get a cached action result.

        Args:
            request: GetActionResult request
            context: gRPC context

        Returns:
            ActionResult if found

        Raises:
            grpc.StatusCode.NOT_FOUND: If action result not in cache
        """
        try:
            # Extract action digest
            action_digest = f"{request.action_digest.hash}/{request.action_digest.size_bytes}"

            # Query service (returns proto directly now)
            result = self.service.get_action_result(
                action_digest=action_digest, instance_name=request.instance_name
            )

            if result is None:
                context.set_code(grpc.StatusCode.NOT_FOUND)
                context.set_details(f"ActionResult not found for digest: {action_digest}")
                return action_cache_pb2.ActionResult()

            # Return proto directly - no conversion needed!
            return result

        except Exception as e:
            logger.error(f"Error in GetActionResult: {e}", exc_info=True)
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(f"Internal error: {str(e)}")
            return action_cache_pb2.ActionResult()

    def UpdateActionResult(
        self, request: action_cache_pb2.UpdateActionResultRequest, context: grpc.ServicerContext
    ) -> action_cache_pb2.ActionResult:
        """Update a cached action result.

        Args:
            request: UpdateActionResult request
            context: gRPC context

        Returns:
            The stored ActionResult
        """
        try:
            # Extract action digest
            action_digest = f"{request.action_digest.hash}/{request.action_digest.size_bytes}"

            # Store in service (pass proto directly - no conversion!)
            stored_result = self.service.update_action_result(
                action_digest=action_digest,
                action_result=request.action_result,
                instance_name=request.instance_name,
            )

            # Return proto directly
            return stored_result

        except Exception as e:
            logger.error(f"Error in UpdateActionResult: {e}", exc_info=True)
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(f"Internal error: {str(e)}")
            return action_cache_pb2.ActionResult()
