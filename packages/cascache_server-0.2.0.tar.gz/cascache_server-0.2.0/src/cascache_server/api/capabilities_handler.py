"""gRPC handler for Capabilities service.

Translates gRPC requests to service layer calls and back.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import grpc

from cascache_server.api.generated import capabilities_pb2, capabilities_pb2_grpc
from cascache_server.services.capabilities_service import CapabilitiesService

if TYPE_CHECKING:
    from cascache_server.config import CASConfig

logger = logging.getLogger(__name__)


class CapabilitiesServicer(capabilities_pb2_grpc.CapabilitiesServicer):
    """gRPC servicer for Capabilities API."""

    def __init__(self, config: CASConfig):
        """Initialize capabilities servicer.

        Args:
            config: Server configuration
        """
        self.service = CapabilitiesService(config)
        logger.info("CapabilitiesServicer initialized")

    def GetCapabilities(
        self,
        request: capabilities_pb2.GetCapabilitiesRequest,
        context: grpc.ServicerContext,
    ) -> capabilities_pb2.ServerCapabilities:
        """Get server capabilities.

        Args:
            request: GetCapabilities request
            context: gRPC context

        Returns:
            ServerCapabilities response
        """
        try:
            # Get capabilities from service layer
            capabilities = self.service.get_capabilities(request.instance_name)

            # Build cache capabilities
            cache_caps = capabilities_pb2.CacheCapabilities(
                digest_function=[capabilities_pb2.DigestFunction.SHA256],
                action_cache_update_capabilities=capabilities_pb2.ActionCacheUpdateCapabilities(
                    update_enabled=capabilities["cache_capabilities"][
                        "action_cache_update_capabilities"
                    ]["update_enabled"]
                ),
                max_batch_total_size_bytes=capabilities["cache_capabilities"][
                    "max_batch_total_size_bytes"
                ],
                compression_supported=capabilities["cache_capabilities"]["compression_supported"],
            )

            # Build execution capabilities
            exec_caps = capabilities_pb2.ExecutionCapabilities(
                digest_function=capabilities_pb2.DigestFunction.SHA256,
                exec_enabled=capabilities["execution_capabilities"]["exec_enabled"],
            )

            # Build API versions
            low_version = capabilities_pb2.ApiVersion(
                major=capabilities["low_api_version"]["major"],
                minor=capabilities["low_api_version"]["minor"],
                patch=capabilities["low_api_version"]["patch"],
                prerelease=capabilities["low_api_version"]["prerelease"],
            )

            high_version = capabilities_pb2.ApiVersion(
                major=capabilities["high_api_version"]["major"],
                minor=capabilities["high_api_version"]["minor"],
                patch=capabilities["high_api_version"]["patch"],
                prerelease=capabilities["high_api_version"]["prerelease"],
            )

            # Build response
            response = capabilities_pb2.ServerCapabilities(
                cache_capabilities=cache_caps,
                execution_capabilities=exec_caps,
                low_api_version=low_version,
                high_api_version=high_version,
            )

            logger.info(
                "GetCapabilities successful",
                extra={
                    "instance_name": request.instance_name or "(default)",
                    "digest_function": "SHA256",
                    "exec_enabled": False,
                    "low_version": f"{low_version.major}.{low_version.minor}.{low_version.patch}",
                    "high_version": f"{high_version.major}.{high_version.minor}.{high_version.patch}",
                },
            )

            return response

        except Exception as e:
            logger.error(f"GetCapabilities failed: {e}", exc_info=True)
            context.abort(grpc.StatusCode.INTERNAL, f"Internal error: {e}")
