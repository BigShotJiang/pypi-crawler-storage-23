"""gRPC API layer for CAS server.

This layer handles protocol translation between gRPC and the service layer.
No business logic should be implemented here.
"""

from cascache_server.api.grpc_handlers import ContentAddressableStorageServicer

__all__ = ["ContentAddressableStorageServicer"]
