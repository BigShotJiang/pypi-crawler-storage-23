"""Generated gRPC protocol buffer modules."""

# Generated files - do not modify manually
# To regenerate, run: uv run python -m grpc_tools.protoc ...
