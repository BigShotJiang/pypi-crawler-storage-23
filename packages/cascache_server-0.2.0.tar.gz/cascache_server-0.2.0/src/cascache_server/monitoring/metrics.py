"""Cache metrics tracking."""

import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class CacheMetrics:
    """
    Track cache performance metrics (thread-safe).

    Records hits, misses, storage statistics, and other
    operational metrics for monitoring and debugging.

    All counter operations are protected by a threading lock
    to ensure accuracy under concurrent access.

    Attributes:
        hits: Total number of cache hits
        misses: Total number of cache misses
        total_bytes_stored: Total bytes currently in storage
        total_blobs: Total number of blobs in storage
        start_time: When the server started
    """

    hits: int = 0
    misses: int = 0
    total_bytes_stored: int = 0
    total_blobs: int = 0
    start_time: datetime = field(default_factory=datetime.now)

    def __post_init__(self):
        """Initialize thread lock after dataclass init."""
        self._lock = threading.Lock()

    def record_hit(self) -> None:
        """Record a cache hit (thread-safe)."""
        with self._lock:
            self.hits += 1

    def record_miss(self) -> None:
        """Record a cache miss (thread-safe)."""
        with self._lock:
            self.misses += 1

    def record_blob_added(self, size_bytes: int) -> None:
        """
        Record a new blob being stored (thread-safe).

        Args:
            size_bytes: Size of the blob in bytes
        """
        with self._lock:
            self.total_blobs += 1
            self.total_bytes_stored += size_bytes

    def record_blob_removed(self, size_bytes: int) -> None:
        """
        Record a blob being removed (thread-safe).

        Args:
            size_bytes: Size of the blob in bytes
        """
        with self._lock:
            self.total_blobs -= 1
            self.total_bytes_stored -= size_bytes

    def hit_rate(self) -> float:
        """
        Calculate cache hit rate (thread-safe).

        Returns:
            Hit rate as a percentage (0.0 to 1.0)
        """
        with self._lock:
            total = self.hits + self.misses
            return self.hits / total if total > 0 else 0.0

    def uptime_seconds(self) -> int:
        """
        Calculate server uptime.

        Returns:
            Uptime in seconds
        """
        # start_time is read-only after init, no lock needed
        return int((datetime.now() - self.start_time).total_seconds())

    def summary(self) -> dict[str, Any]:
        """
        Get summary of all metrics (thread-safe).

        Returns:
            Dictionary with all metric values
        """
        with self._lock:
            return {
                "hits": self.hits,
                "misses": self.misses,
                "hit_rate": self.hits / (self.hits + self.misses)
                if (self.hits + self.misses) > 0
                else 0.0,
                "total_blobs": self.total_blobs,
                "total_bytes": self.total_bytes_stored,
                "uptime_seconds": self.uptime_seconds(),
            }

    def reset(self) -> None:
        """Reset all metrics to zero (thread-safe, useful for testing)."""
        with self._lock:
            self.hits = 0
            self.misses = 0
            self.total_bytes_stored = 0
            self.total_blobs = 0
            self.start_time = datetime.now()


# Global metrics instance
metrics = CacheMetrics()


class ServerMetrics:
    """
    Comprehensive server metrics for dashboard.

    Extends CacheMetrics with operational metrics and eviction tracking.
    Thread-safe for concurrent access.
    """

    def __init__(self, cache_metrics: CacheMetrics | None = None):
        """
        Initialize server metrics.

        Args:
            cache_metrics: Optional CacheMetrics instance (defaults to global)
        """
        self.cache_metrics = cache_metrics or metrics
        self._lock = threading.Lock()
        self._started_at = time.time()
        self._reads = 0
        self._writes = 0
        self._deletes = 0
        self._evictions = 0
        self._last_eviction_run: float | None = None
        self._next_eviction_run: float | None = None

    def record_read(self) -> None:
        """Record a read operation (thread-safe)."""
        with self._lock:
            self._reads += 1

    def record_write(self) -> None:
        """Record a write operation (thread-safe)."""
        with self._lock:
            self._writes += 1

    def record_delete(self) -> None:
        """Record a delete operation (thread-safe)."""
        with self._lock:
            self._deletes += 1

    def record_eviction(self, count: int = 1) -> None:
        """
        Record eviction operations (thread-safe).

        Args:
            count: Number of blobs evicted
        """
        with self._lock:
            self._evictions += count

    def record_eviction_run(self) -> None:
        """Record that eviction worker ran (thread-safe)."""
        with self._lock:
            self._last_eviction_run = time.time()

    def set_next_eviction_run(self, timestamp: float) -> None:
        """
        Set next scheduled eviction run time (thread-safe).

        Args:
            timestamp: Unix timestamp of next run
        """
        with self._lock:
            self._next_eviction_run = timestamp

    def get_stats(self) -> dict:
        """
        Get all server statistics (thread-safe).

        Returns:
            Dictionary with all metrics
        """
        cache_stats = self.cache_metrics.summary()

        with self._lock:
            return {
                # Cache metrics
                "hits": cache_stats["hits"],
                "misses": cache_stats["misses"],
                "hit_rate": cache_stats["hit_rate"],
                "blobs_count": cache_stats["total_blobs"],
                "total_bytes": cache_stats["total_bytes"],
                "started_at": self._started_at,
                # Operational metrics
                "reads": self._reads,
                "writes": self._writes,
                "deletes": self._deletes,
                # Eviction metrics
                "evictions": self._evictions,
                "last_eviction_run": self._last_eviction_run,
                "next_eviction_run": self._next_eviction_run,
            }

    def reset(self) -> None:
        """Reset all metrics (thread-safe, useful for testing)."""
        self.cache_metrics.reset()
        with self._lock:
            self._started_at = time.time()
            self._reads = 0
            self._writes = 0
            self._deletes = 0
            self._evictions = 0
            self._last_eviction_run = None
            self._next_eviction_run = None
