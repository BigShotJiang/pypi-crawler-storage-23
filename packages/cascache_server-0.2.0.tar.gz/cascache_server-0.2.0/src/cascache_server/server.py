"""CAS server entry point."""

import signal
import sys
import threading
from concurrent import futures

import grpc

from cascache_server.api.action_cache_handler import ActionCacheServicer
from cascache_server.api.capabilities_handler import CapabilitiesServicer
from cascache_server.api.generated import (
    action_cache_pb2_grpc,
    capabilities_pb2_grpc,
    cas_simple_pb2_grpc,
)
from cascache_server.api.grpc_handlers import ContentAddressableStorageServicer
from cascache_server.config import create_storage_from_config, load_config
from cascache_server.middleware import RateLimiter, RateLimitInterceptor
from cascache_server.monitoring.metrics import ServerMetrics
from cascache_server.services.action_cache_service import ActionCacheService
from cascache_server.services.cas_service import ContentAddressableStorageService
from cascache_server.utils.logger import get_logger, setup_logging

logger = get_logger(__name__)


class CasCacheServer:
    """CAS Cache Server class to encapsulate server state and components."""

    def __init__(self):
        self._config = load_config()

        # Setup logging
        setup_logging(level=self._config.log_level, format_type=self._config.log_format)
        self._logger = get_logger(__name__)

        self.create_storage_backend()
        self.create_service_layer()
        self.create_server_metrics()
        self.create_eviction_worker()
        self.create_interceptors()
        self.create_grpc_server()

    def create_storage_backend(self):
        """Create storage backend based on configuration."""
        self._storage = create_storage_from_config(self._config)

    def create_service_layer(self):
        """Create service layer instances."""
        self._cas_service = ContentAddressableStorageService(self._storage)
        self._action_cache_service = ActionCacheService(self._storage)

    def create_server_metrics(self):
        """Create server metrics tracker."""
        self._server_metrics = ServerMetrics()

    def create_eviction_worker(self):
        """Create eviction worker if enabled in configuration."""
        self._eviction_worker = None
        if self._config.eviction_enabled:
            from .eviction import (
                EvictionWorker,
                LRUEvictionPolicy,
                SizeQuotaEvictionPolicy,
                TTLEvictionPolicy,
            )

            # Create eviction policy
            if self._config.eviction_policy == "ttl":
                policy = TTLEvictionPolicy(max_age_days=self._config.eviction_max_age_days)
                policy_extra = {"max_age_days": self._config.eviction_max_age_days}
            elif self._config.eviction_policy == "lru":
                max_size_bytes = self._config.eviction_max_size_gb * 1024 * 1024 * 1024
                target_size_bytes = self._config.eviction_target_size_gb * 1024 * 1024 * 1024
                policy = LRUEvictionPolicy(
                    max_size_bytes=max_size_bytes,
                    target_size_bytes=target_size_bytes,
                )
                policy_extra = {
                    "max_size_gb": self._config.eviction_max_size_gb,
                    "target_size_gb": self._config.eviction_target_size_gb,
                }
            elif self._config.eviction_policy == "size_quota":
                max_size_bytes = self._config.eviction_max_size_gb * 1024 * 1024 * 1024
                target_size_bytes = self._config.eviction_target_size_gb * 1024 * 1024 * 1024
                policy = SizeQuotaEvictionPolicy(
                    max_size_bytes=max_size_bytes,
                    target_size_bytes=target_size_bytes,
                )
                policy_extra = {
                    "max_size_gb": self._config.eviction_max_size_gb,
                    "target_size_gb": self._config.eviction_target_size_gb,
                }
            else:
                logger.warning(
                    f"Unknown eviction policy '{self._config.eviction_policy}', using TTL"
                )
                policy = TTLEvictionPolicy(max_age_days=self._config.eviction_max_age_days)
                policy_extra = {"max_age_days": self._config.eviction_max_age_days}

            # Create and start worker
            self._eviction_worker = EvictionWorker(
                storage=self._storage,
                policy=policy,
                interval_seconds=self._config.eviction_interval_hours * 3600,
            )

            self._eviction_worker.start()

            logger.info(
                "Eviction worker started",
                extra={
                    "policy": self._config.eviction_policy,
                    "interval_hours": self._config.eviction_interval_hours,
                    **policy_extra,
                },
            )

    def create_interceptors(self):
        """Create gRPC interceptors based on configuration."""
        self._interceptors: list[grpc.ServerInterceptor] = []

        # Rate limiting interceptor
        if self._config.rate_limit_enabled:
            self.create_rate_limiter()
            if self._rate_limiter:
                self._interceptors.append(RateLimitInterceptor(self._rate_limiter))

    def create_rate_limiter(self):
        """Create rate limiter if enabled in configuration."""
        self._rate_limiter = None
        if self._config.rate_limit_enabled:
            self._rate_limiter = RateLimiter(
                rate=self._config.rate_limit_rps,
                burst=self._config.rate_limit_burst,
            )
            logger.info(
                "Rate limiting enabled",
                extra={
                    "rate": self._config.rate_limit_rps,
                    "burst": self._config.rate_limit_burst,
                },
            )

    def create_grpc_server(self):
        """Create and configure gRPC server."""
        self._server = grpc.server(
            futures.ThreadPoolExecutor(max_workers=self._config.workers),
            interceptors=self._interceptors if self._interceptors else None,
        )

        # Register Capabilities service (required by Bazel)
        capabilities_servicer = CapabilitiesServicer(self._config)
        capabilities_pb2_grpc.add_CapabilitiesServicer_to_server(
            capabilities_servicer, self._server
        )
        logger.info("Registered Capabilities service (REAPI v2)")

        # Register ActionCache service (required by Bazel)
        action_cache_servicer = ActionCacheServicer(self._action_cache_service)
        action_cache_pb2_grpc.add_ActionCacheServicer_to_server(action_cache_servicer, self._server)
        logger.info("Registered ActionCache service (REAPI v2)")

        # Register services for each supported REAPI version
        for version in self._config.reapi_versions:
            if version == "simple":
                # MVP: Simplified CAS proto (for initial development)
                servicer = ContentAddressableStorageServicer(self._cas_service)
                cas_simple_pb2_grpc.add_ContentAddressableStorageServicer_to_server(
                    servicer, self._server
                )
                logger.info("Registered ContentAddressableStorage service (simple MVP)")
            elif version == "v2":
                # Future: Full REAPI v2 support
                # from .api.generated.v2 import cas_pb2_grpc
                # servicer_v2 = ContentAddressableStorageServicerV2(cas_service)
                # cas_pb2_grpc.add_ContentAddressableStorageServicer_to_server(servicer_v2, server)
                logger.warning("REAPI v2 not yet implemented, skipping")
            elif version == "v3":
                # Future: REAPI v3 support when available
                logger.warning("REAPI v3 not yet implemented, skipping")
            else:
                logger.warning(f"Unknown REAPI version '{version}', skipping")

    def run(self, enable_signals: bool = True):
        """
        Start the CAS gRPC server.

        Args:
            enable_signals: Whether to set up signal handlers (only works in main thread).

        This function:
        1. Loads configuration from environment
        2. Sets up logging
        3. Creates storage backend
        4. Creates service layer
        5. Creates gRPC handlers
        6. Starts gRPC server

        Returns:
            The gRPC server instance.
        """

        self._logger.info(
            "Starting CAS server",
            extra={
                "storage_type": self._config.storage_type,
                "storage_path": self._config.storage_path,
                "port": self._config.port,
                "reapi_versions": self._config.reapi_versions,
            },
        )

        # Bind to port
        server_address = f"{self._config.host}:{self._config.port}"
        self._server.add_insecure_port(server_address)

        # Start server
        self._server.start()
        logger.info(f"CAS server listening on {server_address}")

        # Start dashboard if enabled
        dashboard_thread = None
        if self._config.dashboard_enabled:
            try:
                import uvicorn  # type: ignore[import-not-found]

                from .dashboard import create_dashboard_app

                self._dashboard_app = create_dashboard_app(self._server_metrics)
                dashboard_address = f"{self._config.dashboard_host}:{self._config.dashboard_port}"

                def run_dashboard():
                    uvicorn.run(
                        self._dashboard_app,
                        host=self._config.dashboard_host,
                        port=self._config.dashboard_port,
                        log_level="warning",  # Suppress uvicorn logs
                    )

                dashboard_thread = threading.Thread(target=run_dashboard, daemon=True)
                dashboard_thread.start()

                logger.info(
                    f"Dashboard started on http://{dashboard_address}",
                    extra={
                        "dashboard_host": self._config.dashboard_host,
                        "dashboard_port": self._config.dashboard_port,
                    },
                )
            except ImportError as e:
                logger.warning(
                    f"Dashboard dependencies not installed or incompatible: {e}. "
                    "Install with: uv pip install cascache_server[dashboard]. "
                    "Note: Dashboard requires Python 3.13 or lower due to FastAPI/Pydantic compatibility."
                )
            except Exception as e:
                logger.error(
                    f"Failed to start dashboard: {e}",
                    exc_info=True,
                )

        # Setup signal handlers for graceful shutdown (only in main thread)
        if enable_signals:

            def signal_handler(sig, frame):
                logger.info("Received shutdown signal, stopping server...")

                # Stop eviction worker if running
                if self._eviction_worker:
                    self._eviction_worker.stop(wait=True)

                self._server.stop(grace=5)  # 5 second grace period
                logger.info("Server stopped")
                sys.exit(0)

            signal.signal(signal.SIGINT, signal_handler)
            signal.signal(signal.SIGTERM, signal_handler)

            # Wait for termination
            try:
                self._server.wait_for_termination()
            except KeyboardInterrupt:
                logger.info("Keyboard interrupt received, stopping server...")
                self._server.stop(grace=5)

        return self._server


def run_server(enable_signals: bool = True) -> grpc.Server:
    """Create and run a CAS server instance.

    Args:
        enable_signals: Whether to enable signal handlers (SIGINT/SIGTERM).
                       Set to False when running in background threads or tests.

    Returns:
        The gRPC server instance.
    """
    server_instance = CasCacheServer()
    return server_instance.run(enable_signals=enable_signals)


def main():
    """Main entry point."""
    try:
        CasCacheServer().run()
    except Exception as e:
        logger.error(f"Server failed to start: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
