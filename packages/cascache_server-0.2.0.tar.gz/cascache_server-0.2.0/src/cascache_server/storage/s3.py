"""S3-compatible storage backend implementation.

Supports AWS S3, MinIO, Cloudflare R2, Backblaze B2, and other S3-compatible services.
"""

from __future__ import annotations

import time
from datetime import datetime
from typing import BinaryIO

import boto3
from botocore.exceptions import ClientError, EndpointConnectionError

from cascache_server.eviction.policy import BlobMetadata
from cascache_server.storage.base import StorageBackend
from cascache_server.utils.logger import get_logger

logger = get_logger(__name__)


class S3Storage(StorageBackend):
    """S3-compatible storage backend.

    Works with:
    - AWS S3
    - MinIO (self-hosted)
    - Cloudflare R2
    - Backblaze B2
    - Any S3-compatible service

    Args:
        bucket: S3 bucket name
        endpoint_url: Custom endpoint URL (for MinIO, R2, B2)
        region: AWS region (default: us-east-1)
        access_key: Access key ID (optional, uses AWS credentials chain if not provided)
        secret_key: Secret access key (optional)
        prefix: Optional key prefix for all objects (e.g., "cas/")
    """

    def __init__(
        self,
        bucket: str,
        endpoint_url: str | None = None,
        region: str = "us-east-1",
        access_key: str | None = None,
        secret_key: str | None = None,
        prefix: str = "",
    ):
        self.bucket = bucket
        self.endpoint_url = endpoint_url
        self.region = region
        self.prefix = prefix.rstrip("/")

        # Create S3 client
        session_kwargs = {}
        if access_key and secret_key:
            session_kwargs = {
                "aws_access_key_id": access_key,
                "aws_secret_access_key": secret_key,
            }

        self.s3_client = boto3.client(
            "s3",
            endpoint_url=endpoint_url,
            region_name=region,
            **session_kwargs,
        )

        # Create bucket if it doesn't exist (useful for MinIO)
        self._ensure_bucket_exists()

        logger.info(
            "S3Storage initialized",
            extra={
                "bucket": bucket,
                "endpoint": endpoint_url or "AWS S3",
                "region": region,
                "prefix": self.prefix or "(none)",
            },
        )

    def _ensure_bucket_exists(self) -> None:
        """Create bucket if it doesn't exist (idempotent).

        Retries connection for up to 30 seconds to handle startup timing with MinIO.
        """
        max_retries = 15
        retry_delay = 2

        for attempt in range(max_retries):
            try:
                self.s3_client.head_bucket(Bucket=self.bucket)
                logger.debug(f"Bucket {self.bucket} exists")
                return
            except EndpointConnectionError as e:
                if attempt < max_retries - 1:
                    logger.warning(
                        f"Cannot connect to S3 endpoint (attempt {attempt + 1}/{max_retries}): {e}. "
                        f"Retrying in {retry_delay}s..."
                    )
                    time.sleep(retry_delay)
                    continue
                else:
                    logger.error(f"Failed to connect to S3 endpoint after {max_retries} attempts")
                    raise
            except ClientError as e:
                error_code = e.response.get("Error", {}).get("Code")
                if error_code == "404":
                    # Bucket doesn't exist, create it
                    try:
                        if self.region == "us-east-1":
                            self.s3_client.create_bucket(Bucket=self.bucket)
                        else:
                            self.s3_client.create_bucket(
                                Bucket=self.bucket,
                                CreateBucketConfiguration={"LocationConstraint": self.region},
                            )
                        logger.info(f"Created bucket {self.bucket}")
                        return
                    except ClientError as create_error:
                        logger.warning(
                            f"Failed to create bucket {self.bucket}: {create_error}. "
                            "Bucket may already exist or insufficient permissions."
                        )
                        return
                else:
                    if attempt < max_retries - 1:
                        logger.warning(
                            f"Error checking bucket (attempt {attempt + 1}/{max_retries}): {e}"
                        )
                        time.sleep(retry_delay)
                        continue
                    else:
                        logger.error(f"Failed to verify bucket after {max_retries} attempts: {e}")
                        raise

    def _get_key(self, digest: str) -> str:
        """Get full S3 key for a digest."""
        if self.prefix:
            return f"{self.prefix}/{digest}"
        return digest

    def exists(self, digest: str) -> bool:
        """Check if a blob exists in S3."""
        key = self._get_key(digest)
        try:
            self.s3_client.head_object(Bucket=self.bucket, Key=key)
            return True
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "404":
                return False
            raise OSError(f"Error checking object {key}: {e}") from e

    def get(self, digest: str) -> bytes:
        """Retrieve a blob from S3."""
        key = self._get_key(digest)
        try:
            response = self.s3_client.get_object(Bucket=self.bucket, Key=key)
            data = response["Body"].read()
            logger.debug(f"Retrieved blob {digest} ({len(data)} bytes) from S3")

            # Update accessed_at timestamp
            self._update_accessed_at(digest)

            return data
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "NoSuchKey":
                raise FileNotFoundError(f"Blob not found: {digest}") from e
            raise OSError(f"Error retrieving object {key}: {e}") from e

    def get_stream(self, digest: str) -> BinaryIO:
        """Get a streaming handle for reading a blob from S3."""
        key = self._get_key(digest)
        try:
            response = self.s3_client.get_object(Bucket=self.bucket, Key=key)
            # Return the streaming body (file-like object)
            logger.debug(f"Opened stream for blob {digest} from S3")
            return response["Body"]
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "NoSuchKey":
                raise FileNotFoundError(f"Blob not found: {digest}") from e
            raise OSError(f"Error opening stream for {key}: {e}") from e

    def put(self, digest: str, data: bytes) -> None:
        """Store a blob in S3 with metadata."""
        key = self._get_key(digest)
        now = datetime.now()
        try:
            self.s3_client.put_object(
                Bucket=self.bucket,
                Key=key,
                Body=data,
                ContentType="application/octet-stream",
                Metadata={
                    "created-at": now.isoformat(),
                    "accessed-at": now.isoformat(),
                },
            )
            logger.debug(f"Stored blob {digest} ({len(data)} bytes) in S3")
        except ClientError as e:
            raise OSError(f"Error storing object {key}: {e}") from e

    def put_stream(self, digest: str, stream: BinaryIO, size: int | None = None) -> None:
        """Store a blob in S3 from a stream.

        For large files (>5GB), this automatically uses multipart upload.
        """
        key = self._get_key(digest)
        now = datetime.now()
        try:
            # boto3 automatically handles multipart uploads for large files
            self.s3_client.upload_fileobj(
                stream,
                Bucket=self.bucket,
                Key=key,
                ExtraArgs={
                    "ContentType": "application/octet-stream",
                    "Metadata": {
                        "created-at": now.isoformat(),
                        "accessed-at": now.isoformat(),
                    },
                },
            )
            logger.debug(f"Stored blob {digest} (stream) in S3")
        except ClientError as e:
            raise OSError(f"Error storing stream for {key}: {e}") from e

    def delete(self, digest: str) -> None:
        """Delete a blob from S3."""
        key = self._get_key(digest)
        try:
            self.s3_client.delete_object(Bucket=self.bucket, Key=key)
            logger.debug(f"Deleted blob {digest} from S3")
        except ClientError as e:
            raise OSError(f"Error deleting object {key}: {e}") from e

    def get_size(self, digest: str) -> int:
        """Get the size of a blob in S3."""
        key = self._get_key(digest)
        try:
            response = self.s3_client.head_object(Bucket=self.bucket, Key=key)
            size = response["ContentLength"]
            logger.debug(f"Blob {digest} size: {size} bytes")
            return size
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "404":
                raise FileNotFoundError(f"Blob not found: {digest}") from e
            raise OSError(f"Error getting size for {key}: {e}") from e

    def list_all(self) -> list[str]:
        """List all blob digests in S3 bucket.

        Warning: Can be slow for buckets with many objects.
        """
        digests = []
        prefix = f"{self.prefix}/" if self.prefix else ""

        try:
            paginator = self.s3_client.get_paginator("list_objects_v2")
            pages = paginator.paginate(Bucket=self.bucket, Prefix=prefix)

            for page in pages:
                for obj in page.get("Contents", []):
                    key = obj["Key"]
                    # Remove prefix to get digest
                    if self.prefix:
                        digest = key[len(prefix) :]
                    else:
                        digest = key
                    digests.append(digest)

            logger.debug(f"Listed {len(digests)} blobs from S3")
            return digests
        except ClientError as e:
            raise OSError(f"Error listing objects: {e}") from e

    def clear(self) -> None:
        """Delete all blobs from S3 bucket (or prefix).

        Warning: This can be slow for large buckets.
        """
        prefix = f"{self.prefix}/" if self.prefix else ""

        try:
            paginator = self.s3_client.get_paginator("list_objects_v2")
            pages = paginator.paginate(Bucket=self.bucket, Prefix=prefix)

            deleted_count = 0
            for page in pages:
                objects = page.get("Contents", [])
                if objects:
                    # Batch delete (up to 1000 objects at a time)
                    delete_keys = [{"Key": obj["Key"]} for obj in objects]
                    self.s3_client.delete_objects(
                        Bucket=self.bucket,
                        Delete={"Objects": delete_keys},
                    )
                    deleted_count += len(delete_keys)

            logger.info(f"Cleared {deleted_count} blobs from S3")
        except ClientError as e:
            raise OSError(f"Error clearing bucket: {e}") from e

    def _update_accessed_at(self, digest: str) -> None:
        """Update accessed_at timestamp in S3 object metadata."""
        key = self._get_key(digest)
        try:
            # Get current metadata
            response = self.s3_client.head_object(Bucket=self.bucket, Key=key)
            metadata = response.get("Metadata", {})

            # Update accessed_at
            metadata["accessed-at"] = datetime.now().isoformat()

            # Copy object to itself with updated metadata (S3 doesn't support metadata-only updates)
            self.s3_client.copy_object(
                Bucket=self.bucket,
                Key=key,
                CopySource={"Bucket": self.bucket, "Key": key},
                Metadata=metadata,
                MetadataDirective="REPLACE",
                ContentType="application/octet-stream",
            )
            logger.debug(f"Updated accessed_at for blob {digest}")
        except ClientError as e:
            # Non-critical, just log the error
            logger.warning(f"Failed to update accessed_at for {digest}: {e}")

    def get_metadata(self, digest: str) -> BlobMetadata | None:
        """Get blob metadata from S3 object metadata."""
        key = self._get_key(digest)
        try:
            response = self.s3_client.head_object(Bucket=self.bucket, Key=key)
            metadata = response.get("Metadata", {})
            size = response["ContentLength"]

            # Parse timestamps from metadata
            created_at_str = metadata.get("created-at")
            accessed_at_str = metadata.get("accessed-at")

            # Fallback to LastModified if no custom metadata
            last_modified = response.get("LastModified")

            if created_at_str:
                created_at = datetime.fromisoformat(created_at_str)
            elif last_modified:
                created_at = last_modified.replace(tzinfo=None)  # Remove timezone
            else:
                created_at = datetime.now()

            if accessed_at_str:
                accessed_at = datetime.fromisoformat(accessed_at_str)
            elif last_modified:
                accessed_at = last_modified.replace(tzinfo=None)
            else:
                accessed_at = datetime.now()

            return BlobMetadata(
                digest=digest,
                size=size,
                created_at=created_at,
                accessed_at=accessed_at,
            )
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code")
            if error_code == "404":
                return None
            logger.warning(f"Error getting metadata for {digest}: {e}")
            return None
