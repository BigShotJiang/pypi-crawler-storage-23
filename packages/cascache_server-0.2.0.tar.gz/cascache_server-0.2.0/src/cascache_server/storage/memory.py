"""In-memory storage backend for testing."""

from __future__ import annotations

from datetime import datetime
from typing import cast

from cascache_server.eviction.policy import BlobMetadata
from cascache_server.storage.base import StorageBackend


class MemoryStorage(StorageBackend):
    """
    Store blobs in memory.

    This implementation is intended for testing only and will
    lose all data when the process exits.

    Not suitable for production use due to memory constraints.
    """

    def __init__(self):
        """Initialize memory storage."""
        self._storage: dict[str, bytes] = {}
        self._metadata: dict[str, dict[str, datetime | int]] = {}

    def exists(self, digest: str) -> bool:
        """Check if blob exists in memory."""
        return digest in self._storage

    def get(self, digest: str) -> bytes:
        """Retrieve blob from memory."""
        if digest not in self._storage:
            raise FileNotFoundError(f"Blob {digest} not found")
        # Update accessed_at timestamp
        if digest in self._metadata:
            self._metadata[digest]["accessed_at"] = datetime.now()
        return self._storage[digest]

    def put(self, digest: str, data: bytes) -> None:
        """Store blob in memory."""
        self._storage[digest] = data
        # Create or update metadata
        now = datetime.now()
        if digest not in self._metadata:
            self._metadata[digest] = {"created_at": now, "accessed_at": now, "size": len(data)}
        else:
            # Update existing metadata
            self._metadata[digest]["accessed_at"] = now
            self._metadata[digest]["size"] = len(data)

    def delete(self, digest: str) -> None:
        """Delete blob from memory."""
        if digest not in self._storage:
            raise FileNotFoundError(f"Blob {digest} not found")
        del self._storage[digest]
        # Delete metadata if exists
        if digest in self._metadata:
            del self._metadata[digest]

    def list_all(self) -> list[str]:
        """List all blob digests."""
        return list(self._storage.keys())

    def get_size(self, digest: str) -> int:
        """Get blob size."""
        if digest not in self._storage:
            raise FileNotFoundError(f"Blob {digest} not found")
        return len(self._storage[digest])

    def get_metadata(self, digest: str) -> BlobMetadata | None:
        """Get blob metadata (timestamps and size)."""
        if digest not in self._storage:
            return None

        if digest not in self._metadata:
            # No metadata yet, create placeholder
            now = datetime.now()
            return BlobMetadata(
                digest=digest,
                size=len(self._storage[digest]),
                created_at=now,
                accessed_at=now,
            )

        meta = self._metadata[digest]
        return BlobMetadata(
            digest=digest,
            size=cast(int, meta["size"]),
            created_at=cast(datetime, meta["created_at"]),
            accessed_at=cast(datetime, meta["accessed_at"]),
        )
