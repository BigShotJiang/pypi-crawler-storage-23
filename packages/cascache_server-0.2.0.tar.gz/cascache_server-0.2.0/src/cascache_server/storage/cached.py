"""Cached storage backend with LRU cache for hot blobs."""

from __future__ import annotations

from collections.abc import Iterator
from functools import lru_cache
from typing import TYPE_CHECKING

from cascache_server.storage.base import StorageBackend

if TYPE_CHECKING:
    from cascache_server.eviction.policy import BlobMetadata


class CachedStorage(StorageBackend):
    """
    Storage backend wrapper with in-memory LRU cache.

    Caches small, frequently accessed blobs in memory to reduce
    filesystem I/O. Large blobs bypass the cache.

    Args:
        backend: Underlying storage backend
        cache_size: Maximum number of cached blobs (default: 1000)
        max_blob_size: Maximum size for cached blobs in bytes (default: 64KB)
    """

    def __init__(
        self, backend: StorageBackend, cache_size: int = 1000, max_blob_size: int = 64 * 1024
    ):
        """Initialize cached storage."""
        self.backend = backend
        self.max_blob_size = max_blob_size

        # Create LRU cache for get operations
        self._cached_get = lru_cache(maxsize=cache_size)(self._get_internal)
        self._cached_exists = lru_cache(maxsize=cache_size * 2)(self._exists_internal)
        self._cached_size = lru_cache(maxsize=cache_size)(self._size_internal)

    def _exists_internal(self, digest: str) -> bool:
        """Internal exists check (cached)."""
        return self.backend.exists(digest)

    def _get_internal(self, digest: str) -> bytes:
        """Internal get (cached)."""
        return self.backend.get(digest)

    def _size_internal(self, digest: str) -> int:
        """Internal size check (cached)."""
        return self.backend.get_size(digest)

    def exists(self, digest: str) -> bool:
        """Check if blob exists (cached)."""
        return self._cached_exists(digest)

    def get(self, digest: str) -> bytes:
        """
        Get blob data with smart caching.

        Small blobs are cached in memory. Large blobs bypass cache.
        """
        try:
            size = self._cached_size(digest)
        except FileNotFoundError:
            raise

        # Large blobs bypass cache
        if size > self.max_blob_size:
            return self.backend.get(digest)

        # Small blobs use LRU cache
        return self._cached_get(digest)

    def put(self, digest: str, data: bytes) -> None:
        """
        Store blob and invalidate cache.
        """
        self.backend.put(digest, data)

        # Invalidate caches for this digest
        try:
            self._cached_get.cache_clear()  # Simple approach: clear all
            self._cached_size.cache_clear()
        except Exception:
            pass  # Ignore cache clear errors

        # Update exists cache
        self._cached_exists.cache_info()  # Touch cache

    def delete(self, digest: str) -> None:
        """Delete blob and invalidate cache."""
        self.backend.delete(digest)

        # Clear caches
        self._cached_get.cache_clear()
        self._cached_exists.cache_clear()
        self._cached_size.cache_clear()

    def list_all(self) -> list[str]:
        """List all blobs (not cached)."""
        return self.backend.list_all()

    def get_stream(self, digest: str, chunk_size: int = 64 * 1024) -> Iterator[bytes]:
        """Stream blob (bypass cache for large blobs)."""
        return self.backend.get_stream(digest, chunk_size)

    def put_stream(self, digest: str, data_stream: Iterator[bytes]) -> None:
        """Store from stream (bypass cache)."""
        self.backend.put_stream(digest, data_stream)

        # Clear caches
        self._cached_get.cache_clear()
        self._cached_size.cache_clear()

    def get_size(self, digest: str) -> int:
        """Get blob size (cached)."""
        return self._cached_size(digest)

    def get_cache_stats(self) -> dict:
        """Get cache statistics for monitoring."""
        return {
            "get_cache": self._cached_get.cache_info()._asdict(),
            "exists_cache": self._cached_exists.cache_info()._asdict(),
            "size_cache": self._cached_size.cache_info()._asdict(),
        }

    def get_metadata(self, digest: str) -> BlobMetadata | None:
        """Get blob metadata (pass through to backend, not cached)."""
        return self.backend.get_metadata(digest)
