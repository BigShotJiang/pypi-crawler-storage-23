"""Filesystem-based storage backend implementation."""

from __future__ import annotations

import json
import os
import tempfile
from collections.abc import Iterator
from datetime import datetime
from pathlib import Path

from cascache_server.eviction.policy import BlobMetadata
from cascache_server.storage.base import StorageBackend


class FilesystemStorage(StorageBackend):
    """
    Store blobs as files on local filesystem.

    Blobs are stored in a flat directory structure where each file
    is named by its digest hash.

    Args:
        base_path: Root directory path for blob storage
    """

    # Threshold for using streaming vs loading into memory
    STREAM_THRESHOLD = 1 * 1024 * 1024  # 1MB

    def __init__(self, base_path: str):
        """Initialize filesystem storage."""
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)

    def _metadata_path(self, digest: str) -> Path:
        """Get metadata file path for a blob."""
        return self.base_path / f"{digest}.meta"

    def _write_metadata(self, digest: str, size: int, created_at: datetime | None = None) -> None:
        """Write metadata file for a blob."""
        now = datetime.now()
        metadata = {
            "created_at": (created_at or now).isoformat(),
            "accessed_at": now.isoformat(),
            "size": size,
        }
        self._metadata_path(digest).write_text(json.dumps(metadata))

    def _update_accessed_at(self, digest: str) -> None:
        """Update accessed_at timestamp in metadata."""
        meta_path = self._metadata_path(digest)
        if not meta_path.exists():
            # No metadata yet, create it
            path = self.base_path / digest
            if path.exists():
                self._write_metadata(digest, path.stat().st_size)
            return

        try:
            metadata = json.loads(meta_path.read_text())
            metadata["accessed_at"] = datetime.now().isoformat()
            meta_path.write_text(json.dumps(metadata))
        except (json.JSONDecodeError, KeyError):
            # Corrupted metadata, recreate it
            path = self.base_path / digest
            if path.exists():
                self._write_metadata(digest, path.stat().st_size)

    def get_metadata(self, digest: str) -> BlobMetadata | None:
        """Get blob metadata (timestamps and size)."""
        meta_path = self._metadata_path(digest)
        if not meta_path.exists():
            # No metadata file, check if blob exists
            path = self.base_path / digest
            if not path.exists():
                return None
            # Blob exists but no metadata, create placeholder
            size = path.stat().st_size
            now = datetime.now()
            return BlobMetadata(
                digest=digest,
                size=size,
                created_at=now,
                accessed_at=now,
            )

        try:
            metadata = json.loads(meta_path.read_text())
            return BlobMetadata(
                digest=digest,
                size=metadata["size"],
                created_at=datetime.fromisoformat(metadata["created_at"]),
                accessed_at=datetime.fromisoformat(metadata["accessed_at"]),
            )
        except (json.JSONDecodeError, KeyError, ValueError):
            # Corrupted metadata, return None
            return None

    def exists(self, digest: str) -> bool:
        """Check if blob file exists."""
        return (self.base_path / digest).exists()

    def get(self, digest: str) -> bytes:
        """Read blob data from file."""
        path = self.base_path / digest
        if not path.exists():
            raise FileNotFoundError(f"Blob {digest} not found")
        data = path.read_bytes()
        # Update access timestamp
        self._update_accessed_at(digest)
        return data

    def put(self, digest: str, data: bytes) -> None:
        """
        Write blob data to file atomically.

        Uses temp file + rename for atomic write to prevent corruption
        during concurrent writes to the same blob.
        """
        final_path = self.base_path / digest

        # Create temp file in same directory (ensures same filesystem for atomic rename)
        fd, temp_path = tempfile.mkstemp(dir=self.base_path, prefix=".tmp_")
        try:
            # Write data to temp file
            os.write(fd, data)
            os.close(fd)

            # Atomic rename (POSIX guarantee)
            os.rename(temp_path, final_path)

            # Write metadata
            self._write_metadata(digest, len(data))
        except Exception:
            # Clean up temp file on error
            try:
                os.close(fd)
            except OSError:
                pass
            try:
                os.unlink(temp_path)
            except OSError:
                pass
            raise

    def delete(self, digest: str) -> None:
        """Delete blob file and metadata."""
        path = self.base_path / digest
        if not path.exists():
            raise FileNotFoundError(f"Blob {digest} not found")
        path.unlink()
        # Delete metadata file if it exists
        meta_path = self._metadata_path(digest)
        if meta_path.exists():
            meta_path.unlink()

    def list_all(self) -> list[str]:
        """List all blob files (excluding metadata files)."""
        return [
            f.name for f in self.base_path.iterdir() if f.is_file() and not f.name.endswith(".meta")
        ]

    def get_stream(self, digest: str, chunk_size: int = 64 * 1024) -> Iterator[bytes]:
        """Stream blob data in chunks (optimized for filesystem)."""
        path = self.base_path / digest
        if not path.exists():
            raise FileNotFoundError(f"Blob {digest} not found")

        # Update access timestamp before streaming
        self._update_accessed_at(digest)

        with open(path, "rb") as f:
            while True:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                yield chunk

    def put_stream(self, digest: str, data_stream: Iterator[bytes]) -> None:
        """
        Store blob from stream atomically.

        Uses temp file + rename for atomic write to prevent corruption
        during concurrent writes to the same blob.
        """
        final_path = self.base_path / digest

        # Create temp file in same directory
        fd, temp_path = tempfile.mkstemp(dir=self.base_path, prefix=".tmp_")
        total_size = 0
        try:
            # Write stream to temp file
            with os.fdopen(fd, "wb") as f:
                for chunk in data_stream:
                    f.write(chunk)
                    total_size += len(chunk)

            # Atomic rename (POSIX guarantee)
            os.rename(temp_path, final_path)

            # Write metadata
            self._write_metadata(digest, total_size)
        except Exception:
            # Clean up temp file on error
            try:
                os.unlink(temp_path)
            except OSError:
                pass
            raise

    def get_size(self, digest: str) -> int:
        """Get blob size efficiently using stat."""
        path = self.base_path / digest
        if not path.exists():
            raise FileNotFoundError(f"Blob {digest} not found")
        return path.stat().st_size
