"""Abstract base class for storage backends."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterator
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cascache_server.eviction.policy import BlobMetadata


class StorageBackend(ABC):
    """
    Contract for all storage implementations.

    All storage backends must implement this interface to ensure
    they can be used interchangeably by the service layer.
    """

    @abstractmethod
    def exists(self, digest: str) -> bool:
        """
        Check if blob with given digest exists in storage.

        Args:
            digest: SHA256 hash string (64 hex characters)

        Returns:
            True if blob exists, False otherwise
        """
        pass

    @abstractmethod
    def get(self, digest: str) -> bytes:
        """
        Retrieve blob data by digest.

        Args:
            digest: SHA256 hash string (64 hex characters)

        Returns:
            Blob data as bytes

        Raises:
            FileNotFoundError: If blob with given digest doesn't exist
        """
        pass

    @abstractmethod
    def put(self, digest: str, data: bytes) -> None:
        """
        Store blob data.

        This operation should be idempotent - storing the same blob
        twice should not cause errors.

        Args:
            digest: SHA256 hash string (64 hex characters)
            data: Blob data as bytes
        """
        pass

    @abstractmethod
    def delete(self, digest: str) -> None:
        """
        Delete blob from storage.

        Args:
            digest: SHA256 hash string (64 hex characters)

        Raises:
            FileNotFoundError: If blob with given digest doesn't exist
        """
        pass

    @abstractmethod
    def list_all(self) -> list[str]:
        """
        List all digest hashes in storage.

        Returns:
            List of digest hash strings
        """
        pass

    def get_metadata(self, digest: str) -> BlobMetadata | None:
        """
        Get blob metadata (timestamps and size).

        Args:
            digest: SHA256 hash string

        Returns:
            BlobMetadata with timestamps and size, or None if not found

        Note:
            Default implementation returns None (no metadata tracking).
            Subclasses should override to provide actual metadata.
        """
        return None

    def get_stream(self, digest: str, chunk_size: int = 64 * 1024) -> Iterator[bytes]:
        """
        Stream blob data in chunks (for large blobs).

        Args:
            digest: Digest hash of the blob
            chunk_size: Size of each chunk in bytes (default 64KB)

        Yields:
            Chunks of blob data

        Raises:
            FileNotFoundError: If blob doesn't exist

        Note:
            Default implementation loads entire blob then yields chunks.
            Subclasses should override for true streaming from storage.
        """
        data = self.get(digest)
        for i in range(0, len(data), chunk_size):
            yield data[i : i + chunk_size]

    def put_stream(self, digest: str, data_stream: Iterator[bytes]) -> None:
        """
        Store blob from stream (for large blobs).

        Args:
            digest: Digest hash for the blob
            data_stream: Iterator yielding blob data chunks

        Note:
            Default implementation accumulates all chunks then writes.
            Subclasses should override for true streaming to storage.
        """
        chunks = list(data_stream)
        self.put(digest, b"".join(chunks))

    def get_size(self, digest: str) -> int:
        """
        Get size of blob without loading it.

        Args:
            digest: Digest hash of the blob

        Returns:
            Size in bytes

        Raises:
            FileNotFoundError: If blob doesn't exist

        Note:
            Default implementation loads blob to measure.
            Subclasses should override for efficiency.
        """
        return len(self.get(digest))
