"""cascache_server — Flexible ContentAddressableStorage written in python"""
