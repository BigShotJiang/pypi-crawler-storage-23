"""Token generation and validation for authentication."""

from __future__ import annotations

import hashlib
import json
import secrets
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path


@dataclass
class Token:
    """
    Authentication token metadata.

    Attributes:
        token_id: SHA256 hash of the original token (for lookup)
        name: Human-readable name for the token
        created: When the token was created
        expires: When the token expires
        revoked: Whether the token has been revoked
    """

    token_id: str
    name: str
    created: datetime
    expires: datetime
    revoked: bool = False

    def is_valid(self) -> bool:
        """
        Check if token is valid (not expired or revoked).

        Returns:
            True if token is valid, False otherwise
        """
        return not self.revoked and datetime.now() < self.expires

    def to_dict(self) -> dict:
        """Convert token to dictionary for JSON serialization."""
        return {
            "name": self.name,
            "created": self.created.isoformat(),
            "expires": self.expires.isoformat(),
            "revoked": self.revoked,
        }

    @classmethod
    def from_dict(cls, token_id: str, data: dict) -> Token:
        """Create Token from dictionary."""
        return cls(
            token_id=token_id,
            name=data["name"],
            created=datetime.fromisoformat(data["created"]),
            expires=datetime.fromisoformat(data["expires"]),
            revoked=data.get("revoked", False),
        )


class TokenManager:
    """
    Manage authentication tokens.

    Tokens are generated using cryptographically secure random bytes
    and stored as SHA256 hashes for security. The actual token value
    is only shown once during creation.

    Args:
        tokens_file: Path to JSON file storing token metadata
    """

    def __init__(self, tokens_file: Path):
        """Initialize token manager."""
        self.tokens_file = Path(tokens_file)
        self._tokens: dict[str, Token] = {}
        self._load_tokens()

    def _load_tokens(self) -> None:
        """Load tokens from file."""
        if not self.tokens_file.exists():
            self._tokens = {}
            return

        # Check if file is empty
        if self.tokens_file.stat().st_size == 0:
            self._tokens = {}
            return

        try:
            with open(self.tokens_file) as f:
                data = json.load(f)
                tokens_data = data.get("tokens", {})
                self._tokens = {
                    token_id: Token.from_dict(token_id, token_data)
                    for token_id, token_data in tokens_data.items()
                }
        except (json.JSONDecodeError, KeyError) as e:
            raise ValueError(f"Failed to load tokens from {self.tokens_file}: {e}")

    def _save_tokens(self) -> None:
        """Save tokens to file with restricted permissions."""
        # Ensure parent directory exists
        self.tokens_file.parent.mkdir(parents=True, exist_ok=True)

        # Save tokens
        data = {"tokens": {token_id: token.to_dict() for token_id, token in self._tokens.items()}}

        with open(self.tokens_file, "w") as f:
            json.dump(data, f, indent=2)

        # Restrict file permissions (owner read/write only)
        self.tokens_file.chmod(0o600)

    @staticmethod
    def _hash_token(token: str) -> str:
        """Hash token using SHA256."""
        return hashlib.sha256(token.encode()).hexdigest()

    def generate_token(self, name: str, expires_days: int = 30) -> str:
        """
        Generate a new authentication token.

        The token is generated using cryptographically secure random bytes
        and returned in URL-safe base64 format. The SHA256 hash is stored
        for validation.

        Args:
            name: Human-readable name for the token
            expires_days: Number of days until token expires

        Returns:
            The generated token string (only shown once!)

        Example:
            >>> manager = TokenManager(Path("/etc/cas/tokens.json"))
            >>> token = manager.generate_token("team-ci", expires_days=30)
            >>> print(f"Save this token: {token}")
        """
        # Generate cryptographically secure random token
        token = f"cas-token-{secrets.token_urlsafe(32)}"

        # Hash for storage
        token_id = self._hash_token(token)

        # Create token metadata
        token_obj = Token(
            token_id=token_id,
            name=name,
            created=datetime.now(),
            expires=datetime.now() + timedelta(days=expires_days),
            revoked=False,
        )

        # Store and save
        self._tokens[token_id] = token_obj
        self._save_tokens()

        return token

    def validate_token(self, token: str) -> bool:
        """
        Validate an authentication token.

        Args:
            token: Token string to validate

        Returns:
            True if token is valid (exists, not expired, not revoked)
        """
        token_id = self._hash_token(token)

        if token_id not in self._tokens:
            return False

        return self._tokens[token_id].is_valid()

    def revoke_token(self, token: str) -> bool:
        """
        Revoke a token.

        Args:
            token: Token string to revoke

        Returns:
            True if token was revoked, False if not found
        """
        token_id = self._hash_token(token)

        if token_id not in self._tokens:
            return False

        self._tokens[token_id].revoked = True
        self._save_tokens()
        return True

    def list_tokens(self) -> list[dict]:
        """
        List all tokens (without revealing actual token values).

        Returns:
            List of token metadata dictionaries
        """
        return [
            {
                "token_id": token_id[:16] + "...",  # Show only prefix
                "name": token.name,
                "created": token.created.isoformat(),
                "expires": token.expires.isoformat(),
                "revoked": token.revoked,
                "valid": token.is_valid(),
            }
            for token_id, token in self._tokens.items()
        ]

    def cleanup_expired(self) -> int:
        """
        Remove expired tokens from storage.

        Returns:
            Number of tokens removed
        """
        expired = [
            token_id
            for token_id, token in self._tokens.items()
            if not token.is_valid() and token.revoked
        ]

        for token_id in expired:
            del self._tokens[token_id]

        if expired:
            self._save_tokens()

        return len(expired)
