"""gRPC authentication interceptor."""

import grpc
from grpc import ServerInterceptor

from cascache_server.auth.token_manager import TokenManager


class AuthInterceptor(ServerInterceptor):
    """
    Intercepts gRPC requests to validate authentication tokens.

    Extracts the 'authorization' metadata from requests and validates
    the Bearer token against the TokenManager. Rejects requests with
    invalid or missing tokens.

    Args:
        token_manager: TokenManager instance for validation
        enabled: Whether authentication is enabled (default: True)
    """

    def __init__(self, token_manager: TokenManager, enabled: bool = True):
        """Initialize auth interceptor."""
        self.token_manager = token_manager
        self.enabled = enabled

    def intercept_service(self, continuation, handler_call_details):
        """
        Intercept and validate authentication.

        Args:
            continuation: Next handler in the chain
            handler_call_details: Details about the RPC call

        Returns:
            RPC handler or error
        """
        # Skip auth if disabled
        if not self.enabled:
            return continuation(handler_call_details)

        # Extract authorization header
        metadata = dict(handler_call_details.invocation_metadata)
        auth_header = metadata.get("authorization", "")

        # Convert bytes to str if needed (gRPC metadata can be str or bytes)
        if isinstance(auth_header, bytes):
            auth_header = auth_header.decode("utf-8")

        # Check for Bearer token format
        if not auth_header.startswith("Bearer "):
            return self._unauthenticated("Missing or invalid authorization header")

        # Extract token (remove "Bearer " prefix)
        token = auth_header[7:]

        # Validate token
        if not self.token_manager.validate_token(token):
            return self._unauthenticated("Invalid or expired token")

        # Token is valid, proceed with request
        return continuation(handler_call_details)

    def _unauthenticated(self, message: str):
        """
        Return UNAUTHENTICATED error.

        Args:
            message: Error message to include

        Returns:
            RPC handler that returns UNAUTHENTICATED status
        """

        def abort(request, context):
            context.abort(grpc.StatusCode.UNAUTHENTICATED, message)

        return grpc.unary_unary_rpc_method_handler(
            abort,
            request_deserializer=lambda x: x,  # type: ignore[arg-type]
            response_serializer=lambda x: x,  # type: ignore[arg-type]
        )
