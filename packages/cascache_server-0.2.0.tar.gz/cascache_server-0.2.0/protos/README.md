# Protocol Buffer Definitions

This directory contains the `.proto` source files for the cascache_server gRPC services.

## Files

- **`cas_simple.proto`** - Simplified Content Addressable Storage (CAS) service (MVP implementation)
- **`capabilities.proto`** - Capabilities service (REAPI v2 compliant)

## Generating Python Bindings

Bindings are pre-generated and committed in `src/cascache_server/api/generated/`. 

To regenerate if needed:

```bash
# Generate CAS bindings
uv run python -m grpc_tools.protoc \
  -I./protos \
  --python_out=src/cascache_server/api/generated \
  --grpc_python_out=src/cascache_server/api/generated \
  --pyi_out=src/cascache_server/api/generated \
  protos/cas_simple.proto

# Generate Capabilities bindings
uv run python -m grpc_tools.protoc \
  -I./protos \
  --python_out=src/cascache_server/api/generated \
  --grpc_python_out=src/cascache_server/api/generated \
  --pyi_out=src/cascache_server/api/generated \
  protos/capabilities.proto
```

**Important:** After generation, fix imports in generated `*_grpc.py` files:
- Change: `import capabilities_pb2`
- To: `from . import capabilities_pb2`

## Proto Management Strategy

We use **pre-generated bindings** committed to the repository:
- ✅ Simplifies builds (no protoc required)
- ✅ Version controlled (see exactly what changed)
- ✅ CI/CD friendly
- ✅ No build-time dependencies

The source `.proto` files are kept for reference and regeneration when needed.

## Future Evolution

- **Week 2+**: May integrate full REAPI v2 protos
- **Week 3+**: May add ActionCache service proto
- For now: These simplified protos are sufficient for Bazel integration
