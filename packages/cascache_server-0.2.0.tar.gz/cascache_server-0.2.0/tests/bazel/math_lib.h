#ifndef MATH_LIB_H
#define MATH_LIB_H

namespace math {

int Add(int a, int b);
int Multiply(int a, int b);
double Divide(double a, double b);

}  // namespace math

#endif  // MATH_LIB_H
