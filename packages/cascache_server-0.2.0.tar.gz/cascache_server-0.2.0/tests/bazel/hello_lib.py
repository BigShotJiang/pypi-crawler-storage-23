"""Simple Python library for testing cache behavior."""

from __future__ import annotations


def greet(name: str) -> str:
    """Return a greeting message."""
    return f"Hello, {name}!"


def compute_sum(numbers: list[int]) -> int:
    """Compute sum of numbers (simulates some work)."""
    result = 0
    for num in numbers:
        result += num
    return result
