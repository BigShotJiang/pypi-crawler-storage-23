#include <iostream>
#include "math_lib.h"

int main() {
    std::cout << "10 + 5 = " << math::Add(10, 5) << std::endl;
    std::cout << "10 * 5 = " << math::Multiply(10, 5) << std::endl;
    std::cout << "10 / 5 = " << math::Divide(10.0, 5.0) << std::endl;
    return 0;
}
