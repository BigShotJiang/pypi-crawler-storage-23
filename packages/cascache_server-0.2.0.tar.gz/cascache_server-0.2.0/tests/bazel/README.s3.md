# Bazel S3 Backend Integration Test

This directory contains Docker-based integration tests for the CAS server with S3/MinIO backend.

## S3 Backend Test

The S3 backend test validates:
- **MinIO** as S3-compatible storage
- **CAS server** configured to use S3 backend
- **Bazel remote cache** reading/writing to S3 through CAS
- **Performance** with cold/warm cache cycles

### Architecture

```
┌──────────────┐
│ Bazel Runner │
└──────┬───────┘
       │ gRPC remote cache
       ▼
┌──────────────┐
│  CAS Server  │
│ (S3 backend) │
└──────┬───────┘
       │ S3 API
       ▼
┌──────────────┐
│    MinIO     │
│ (S3 storage) │
└──────────────┘
```

### Running S3 Backend Test

```bash
# From project root
just test-bazel-docker-s3

# Or manually
cd tests/bazel
docker compose -f docker-compose.s3.yml up --build --abort-on-container-exit
docker compose -f docker-compose.s3.yml down -v
```

### What Gets Tested

1. **Cold Build** - Bazel builds and stores artifacts in MinIO via CAS
2. **Warm Build** - Bazel retrieves cached artifacts from MinIO
3. **Performance** - Measures speedup (typically 5-11x)
4. **Correctness** - All tests pass with S3-backed cache

### Configuration

The test uses:
- **MinIO**: S3-compatible storage on port 9000
- **CAS Server**: Port 50051 with S3 backend
- **Bucket**: `cas-bazel-test`
- **Credentials**: minioadmin/minioadmin (test only)

### Expected Results

```
Cold build time:    11s (S3 write)
Warm build time:    1s (S3 read)
Speedup:            11x
```

### Environment Variables

The CAS server in the S3 test uses:
```bash
CAS_STORAGE_TYPE=s3
CAS_STORAGE_PATH=cas-bazel-test          # Bucket name
CAS_S3_ENDPOINT=http://minio:9000
CAS_S3_ACCESS_KEY=minioadmin
CAS_S3_SECRET_KEY=minioadmin
CAS_S3_REGION=us-east-1
```

### Troubleshooting

**MinIO not starting:**
```bash
docker compose -f docker-compose.s3.yml logs minio
```

**CAS server not connecting to MinIO:**
```bash
docker compose -f docker-compose.s3.yml logs cas-server
```

**Bazel not using remote cache:**
- Check `.bazelrc` has `--remote_cache` configured
- Verify CAS server is healthy: `docker compose ps`

### Comparing Backends

| Backend    | Cold Build | Warm Build | Speedup | Scalability |
|------------|-----------|-----------|---------|-------------|
| Filesystem | 11s       | 1s        | 11x     | Single node |
| S3/MinIO   | 11s       | 1s        | 11x     | Unlimited   |

S3 backend provides same performance with unlimited storage scalability.
