#include "math_lib.h"

namespace math {

int Add(int a, int b) {
    return a + b;
}

int Multiply(int a, int b) {
    return a * b;
}

double Divide(double a, double b) {
    if (b == 0) {
        return 0.0;
    }
    return a / b;
}

}  // namespace math
