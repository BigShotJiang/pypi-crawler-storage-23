#!/usr/bin/env bash
# Integration test script for validating CAS remote caching with Bazel
# Tests cold cache (first build) and warm cache (rebuild) behavior

set -e  # Exit on error
set -u  # Exit on undefined variable

# Color output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
CAS_SERVER_PORT="${CAS_SERVER_PORT:-50051}"
CAS_SERVER_HOST="${CAS_SERVER_HOST:-localhost}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEST_WORKSPACE="${SCRIPT_DIR}"
CAS_AUTH_TOKEN="${CAS_AUTH_TOKEN:-}"

# Build remote cache URL
CAS_REMOTE_CACHE="grpc://${CAS_SERVER_HOST}:${CAS_SERVER_PORT}"

echo -e "${GREEN}=== Bazel CAS Integration Test ===${NC}"
echo "Test workspace: ${TEST_WORKSPACE}"
echo "CAS server: grpc://${CAS_SERVER_HOST}:${CAS_SERVER_PORT}"
if [ -n "${CAS_AUTH_TOKEN}" ]; then
    echo "Authentication: ENABLED (token present)"
else
    echo "Authentication: DISABLED (no token)"
fi
echo ""

# Check if Bazel is installed
if ! command -v bazel &> /dev/null; then
    echo -e "${RED}ERROR: Bazel is not installed${NC}"
    echo "Install from: https://bazel.build/install"
    exit 1
fi

echo -e "${YELLOW}Bazel version:${NC}"
bazel version | grep "Build label" || true
echo ""

# Check if CAS server is running
echo -e "${YELLOW}Checking CAS server connectivity...${NC}"
if ! nc -z "${CAS_SERVER_HOST}" "${CAS_SERVER_PORT}" 2>/dev/null; then
    echo -e "${RED}ERROR: CAS server is not reachable at ${CAS_SERVER_HOST}:${CAS_SERVER_PORT}${NC}"
    echo "Start the server with: just serve"
    exit 1
fi
echo -e "${GREEN}✓ CAS server is running${NC}"
echo ""

# Change to test workspace
cd "${TEST_WORKSPACE}"

# Clean everything for a fresh start
echo -e "${YELLOW}=== Phase 1: Clean Build (Cold Cache) ===${NC}"
echo "Cleaning Bazel cache and build outputs..."
bazel clean --expunge 2>&1 | grep -v "^INFO:" || true
echo ""

# Build Bazel command with optional auth header
# First build - should populate the cache
echo -e "${YELLOW}Building all targets (cold cache)...${NC}"
START_TIME=$(date +%s)

if [ -n "${CAS_AUTH_TOKEN}" ]; then
    bazel build //... --config=cache --remote_cache="${CAS_REMOTE_CACHE}" \
      --remote_header="authorization=Bearer ${CAS_AUTH_TOKEN}" \
      2>&1 | tee /tmp/bazel_cold.log | grep -E "(INFO: Build|INFO: Elapsed|actions|cache)" || true
else
    bazel build //... --config=cache --remote_cache="${CAS_REMOTE_CACHE}" \
      2>&1 | tee /tmp/bazel_cold.log | grep -E "(INFO: Build|INFO: Elapsed|actions|cache)" || true
fi

END_TIME=$(date +%s)
COLD_BUILD_TIME=$((END_TIME - START_TIME))
echo -e "${GREEN}✓ Cold build completed in ${COLD_BUILD_TIME}s${NC}"
echo ""

# Run tests with same auth
echo -e "${YELLOW}Running tests (cold cache)...${NC}"

if [ -n "${CAS_AUTH_TOKEN}" ]; then
    bazel test //... --config=cache --remote_cache="${CAS_REMOTE_CACHE}" \
      --remote_header="authorization=Bearer ${CAS_AUTH_TOKEN}" \
      2>&1 | grep -E "(INFO:|PASSED|FAILED|//)" || true
else
    bazel test //... --config=cache --remote_cache="${CAS_REMOTE_CACHE}" \
      2>&1 | grep -E "(INFO:|PASSED|FAILED|//)" || true
fi

echo -e "${GREEN}✓ Tests completed${NC}"
echo ""

# Clean local cache but keep remote cache populated
echo -e "${YELLOW}=== Phase 2: Rebuild (Warm Cache) ===${NC}"
echo "Cleaning local cache (remote cache should be populated)..."
bazel clean 2>&1 | grep -v "^INFO:" || true
echo ""

# Second build - should hit cache
echo -e "${YELLOW}Rebuilding all targets (warm cache)...${NC}"
START_TIME=$(date +%s)

if [ -n "${CAS_AUTH_TOKEN}" ]; then
    bazel build //... --config=cache --remote_cache="${CAS_REMOTE_CACHE}" \
      --remote_header="authorization=Bearer ${CAS_AUTH_TOKEN}" \
      2>&1 | tee /tmp/bazel_warm.log | grep -E "(INFO: Build|INFO: Elapsed|actions|cache)" || true
else
    bazel build //... --config=cache --remote_cache="${CAS_REMOTE_CACHE}" \
      2>&1 | tee /tmp/bazel_warm.log | grep -E "(INFO: Build|INFO: Elapsed|actions|cache)" || true
fi

END_TIME=$(date +%s)
WARM_BUILD_TIME=$((END_TIME - START_TIME))
echo -e "${GREEN}✓ Warm build completed in ${WARM_BUILD_TIME}s${NC}"
echo ""

# Run tests again
echo -e "${YELLOW}Running tests (warm cache)...${NC}"

if [ -n "${CAS_AUTH_TOKEN}" ]; then
    bazel test //... --config=cache --remote_cache="${CAS_REMOTE_CACHE}" \
      --remote_header="authorization=Bearer ${CAS_AUTH_TOKEN}" \
      2>&1 | grep -E "(INFO:|PASSED|FAILED|//)" || true
else
    bazel test //... --config=cache --remote_cache="${CAS_REMOTE_CACHE}" \
      2>&1 | grep -E "(INFO:|PASSED|FAILED|//)" || true
fi

echo -e "${GREEN}✓ Tests completed${NC}"
echo ""

# Analyze results
echo -e "${GREEN}=== Cache Performance Summary ===${NC}"
echo "Cold build time: ${COLD_BUILD_TIME}s"
echo "Warm build time: ${WARM_BUILD_TIME}s"

if [ "${WARM_BUILD_TIME}" -eq 0 ]; then
    echo -e "${GREEN}✓ Cache speedup: Near-instant (100% cached)${NC}"
    echo -e "${GREEN}✓ Remote caching is working!${NC}"
elif [ "${WARM_BUILD_TIME}" -lt "${COLD_BUILD_TIME}" ]; then
    SPEEDUP=$(echo "scale=2; ${COLD_BUILD_TIME} / ${WARM_BUILD_TIME}" | bc)
    echo -e "${GREEN}✓ Cache speedup: ${SPEEDUP}x${NC}"
    echo -e "${GREEN}✓ Remote caching is working!${NC}"
else
    echo -e "${YELLOW}⚠ Warm build was not faster (possible issues)${NC}"
fi
echo ""

# Check for cache activity in logs
echo -e "${YELLOW}Analyzing cache behavior...${NC}"
if [ -f /tmp/bazel_warm.log ]; then
    # Look for action cache queries (indicates cache is being used)
    CACHE_CHECKS=$(grep -i "checking cached actions" /tmp/bazel_warm.log | wc -l || echo "0")
    echo "Action cache queries: ${CACHE_CHECKS}"
    
    # Look for remote-cache indicators in action descriptions
    REMOTE_CACHE_ACTIONS=$(grep -i "remote-cache" /tmp/bazel_warm.log | wc -l || echo "0")
    if [ "${REMOTE_CACHE_ACTIONS}" -gt 0 ]; then
        echo "Actions using remote cache: ${REMOTE_CACHE_ACTIONS}"
    fi
    
    # Show any warnings or errors (for debugging)
    WARNINGS=$(grep -iE "WARNING.*cache|ERROR.*cache" /tmp/bazel_warm.log | head -3 || true)
    if [ -n "${WARNINGS}" ]; then
        echo -e "${YELLOW}Cache-related messages:${NC}"
        echo "${WARNINGS}"
    fi
fi
echo ""

echo -e "${GREEN}=== Test Complete ===${NC}"
echo "Review full logs: /tmp/bazel_cold.log and /tmp/bazel_warm.log"
echo ""

# Optional: Build specific targets for detailed analysis
echo -e "${YELLOW}=== Optional: Individual Target Analysis ===${NC}"
echo "You can test individual targets:"
if [ -n "${CAS_AUTH_TOKEN}" ]; then
    echo "  bazel build //:hello --config=cache --remote_header=authorization=Bearer \$CAS_AUTH_TOKEN"
    echo "  bazel build //:math_app --config=cache --remote_header=authorization=Bearer \$CAS_AUTH_TOKEN"
    echo "  bazel test //:hello_test --config=cache --remote_header=authorization=Bearer \$CAS_AUTH_TOKEN"
else
    echo "  bazel build //:hello --config=cache"
    echo "  bazel build //:math_app --config=cache"
    echo "  bazel test //:hello_test --config=cache"
fi
echo ""
