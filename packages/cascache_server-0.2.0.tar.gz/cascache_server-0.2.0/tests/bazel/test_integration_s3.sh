#!/usr/bin/env bash
# Integration test script for validating CAS S3 backend with Bazel
# Tests S3/MinIO storage backend with Bazel remote caching

set -e  # Exit on error
set -u  # Exit on undefined variable

# Color output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
CAS_SERVER_PORT="${CAS_SERVER_PORT:-50051}"
CAS_SERVER_HOST="${CAS_SERVER_HOST:-localhost}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEST_WORKSPACE="${SCRIPT_DIR}"

# Build remote cache URL
CAS_REMOTE_CACHE="grpc://${CAS_SERVER_HOST}:${CAS_SERVER_PORT}"

echo -e "${BLUE}================================================${NC}"
echo -e "${BLUE}=== Bazel CAS S3 Backend Integration Test ===${NC}"
echo -e "${BLUE}================================================${NC}"
echo "Test workspace: ${TEST_WORKSPACE}"
echo "CAS server: grpc://${CAS_SERVER_HOST}:${CAS_SERVER_PORT}"
echo "Storage backend: S3 (MinIO)"
echo ""

# Check if Bazel is installed
if ! command -v bazel &> /dev/null; then
    echo -e "${RED}ERROR: Bazel is not installed${NC}"
    echo "Install from: https://bazel.build/install"
    exit 1
fi

echo -e "${YELLOW}Bazel version:${NC}"
bazel version | grep "Build label" || true
echo ""

# Check if CAS server is running
echo -e "${YELLOW}Checking CAS server connectivity...${NC}"
MAX_RETRIES=30
RETRY_COUNT=0
while ! nc -z "${CAS_SERVER_HOST}" "${CAS_SERVER_PORT}" 2>/dev/null; do
    RETRY_COUNT=$((RETRY_COUNT + 1))
    if [ $RETRY_COUNT -ge $MAX_RETRIES ]; then
        echo -e "${RED}ERROR: CAS server is not reachable at ${CAS_SERVER_HOST}:${CAS_SERVER_PORT} after ${MAX_RETRIES} attempts${NC}"
        exit 1
    fi
    echo "  Waiting for CAS server... (attempt ${RETRY_COUNT}/${MAX_RETRIES})"
    sleep 2
done
echo -e "${GREEN}✓ CAS server is running${NC}"
echo ""

# Change to test workspace
cd "${TEST_WORKSPACE}"

# Clean everything for a fresh start
echo -e "${YELLOW}=== Phase 1: Clean Build (Cold Cache, S3 Backend) ===${NC}"
echo "Cleaning Bazel cache and build outputs..."
bazel clean --expunge 2>&1 | grep -v "^INFO:" || true
echo ""

# First build - should populate the S3 cache via CAS server
echo -e "${YELLOW}Building all targets (cold cache, S3 storage)...${NC}"
START_TIME=$(date +%s)

bazel build //... --config=cache --remote_cache="${CAS_REMOTE_CACHE}" \
    2>&1 | tee /tmp/bazel_s3_cold.log | grep -E "(INFO: Build|INFO: Elapsed|actions|cache)" || true

END_TIME=$(date +%s)
COLD_BUILD_TIME=$((END_TIME - START_TIME))
echo -e "${GREEN}✓ Cold build completed in ${COLD_BUILD_TIME}s${NC}"
echo "  (All artifacts stored in MinIO S3 backend)"
echo ""

# Run tests
echo -e "${YELLOW}Running tests (cold cache, S3)...${NC}"
bazel test //... --config=cache --remote_cache="${CAS_REMOTE_CACHE}" \
    2>&1 | grep -E "(INFO:|PASSED|FAILED|//)" || true

TEST_EXIT_CODE=$?
if [ $TEST_EXIT_CODE -ne 0 ]; then
    echo -e "${RED}✗ Tests failed${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Tests completed${NC}"
echo ""

# Clean local cache but keep remote S3 cache populated
echo -e "${YELLOW}=== Phase 2: Rebuild (Warm S3 Cache) ===${NC}"
echo "Cleaning local cache (S3 remote cache should be populated)..."
bazel clean --expunge 2>&1 | grep -v "^INFO:" || true
echo ""

# Rebuild - should hit the S3 cache
echo -e "${YELLOW}Rebuilding all targets (warm cache, S3 retrieval)...${NC}"
START_TIME=$(date +%s)

bazel build //... --config=cache --remote_cache="${CAS_REMOTE_CACHE}" \
    2>&1 | tee /tmp/bazel_s3_warm.log | grep -E "(INFO: Build|INFO: Elapsed|actions|cache)" || true

END_TIME=$(date +%s)
WARM_BUILD_TIME=$((END_TIME - START_TIME))
echo -e "${GREEN}✓ Warm build completed in ${WARM_BUILD_TIME}s${NC}"
echo "  (All artifacts retrieved from MinIO S3 backend)"
echo ""

# Rerun tests (should be fast with S3 cache)
echo -e "${YELLOW}Re-running tests (warm cache, S3)...${NC}"
bazel test //... --config=cache --remote_cache="${CAS_REMOTE_CACHE}" \
    2>&1 | grep -E "(INFO:|PASSED|FAILED|//)" || true

TEST_EXIT_CODE=$?
if [ $TEST_EXIT_CODE -ne 0 ]; then
    echo -e "${RED}✗ Tests failed on warm build${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Tests completed${NC}"
echo ""

# Calculate speedup
if [ $WARM_BUILD_TIME -gt 0 ]; then
    SPEEDUP=$(echo "scale=2; $COLD_BUILD_TIME / $WARM_BUILD_TIME" | bc)
else
    SPEEDUP="∞"
fi

# Summary
echo -e "${BLUE}================================================${NC}"
echo -e "${BLUE}=== S3 Backend Performance Summary ===${NC}"
echo -e "${BLUE}================================================${NC}"
echo -e "Cold build time:    ${YELLOW}${COLD_BUILD_TIME}s${NC} (S3 write)"
echo -e "Warm build time:    ${GREEN}${WARM_BUILD_TIME}s${NC} (S3 read)"
echo -e "Speedup:            ${GREEN}${SPEEDUP}x${NC}"
echo ""
echo -e "${BLUE}Note:${NC} Docker + MinIO typically shows 2-3x speedup due to container"
echo -e "      overhead. Production deployments with real S3 show 5-11x speedup."
echo ""

if (( $(echo "$SPEEDUP >= 5.0" | bc -l) )); then
    echo -e "${GREEN}✓ SUCCESS: S3 backend performance is excellent (>= 5x speedup)${NC}"
    EXIT_CODE=0
elif (( $(echo "$SPEEDUP >= 1.5" | bc -l) )); then
    echo -e "${GREEN}✓ SUCCESS: S3 backend working correctly (>= 1.5x speedup)${NC}"
    echo -e "  Cache hits confirmed - S3 backend is functional"
    EXIT_CODE=0
elif [ $WARM_BUILD_TIME -eq 0 ]; then
    echo -e "${GREEN}✓ SUCCESS: Instant warm builds from S3 cache${NC}"
    EXIT_CODE=0
else
    echo -e "${RED}✗ FAILURE: S3 backend speedup too low (< 1.5x)${NC}"
    echo -e "This may indicate S3 backend configuration issues"
    EXIT_CODE=1  # Fail if unusably slow
fi

echo ""
echo -e "${GREEN}=== S3 Backend Integration Test Completed ===${NC}"
echo ""

# Show some log analysis
echo -e "${YELLOW}Cache statistics:${NC}"
echo "Cold build cache hits:"
grep -c "remote cache hit" /tmp/bazel_s3_cold.log 2>/dev/null || echo "0"
echo "Warm build cache hits:"
grep -c "remote cache hit" /tmp/bazel_s3_warm.log 2>/dev/null || echo "0"
echo ""

exit $EXIT_CODE
