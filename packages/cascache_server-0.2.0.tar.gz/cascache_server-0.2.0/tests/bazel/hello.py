"""Simple Python binary for testing cache behavior."""

import hello_lib


def main() -> None:
    """Main entry point."""
    print(hello_lib.greet("Bazel"))
    numbers = list(range(1, 101))
    total = hello_lib.compute_sum(numbers)
    print(f"Sum of 1-100: {total}")


if __name__ == "__main__":
    main()
