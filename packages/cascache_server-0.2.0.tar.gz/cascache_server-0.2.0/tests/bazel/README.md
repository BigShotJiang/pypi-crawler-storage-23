# Bazel Integration Tests

This directory contains a minimal Bazel workspace for testing the cascache_server server's remote caching capabilities.

## Overview

The test workspace includes:
- **Python targets**: Library, binary, and test targets
- **C++ targets**: Library, application, and test targets
- **Genrules**: For testing action caching
- **Remote cache configuration**: Configured to use `grpc://localhost:50051`

## Prerequisites

### Docker-based Testing (Recommended)

**Only requirement**: Docker and Docker Compose installed

```bash
# Ubuntu/Debian
sudo apt install docker.io docker-compose

# macOS
brew install docker docker-compose
```

### Local Testing (Optional)

If you prefer to run Bazel locally without Docker:

1. **Bazel**: Install from [bazel.build](https://bazel.build/install)
2. **C++ toolchain**: Required for C++ targets
3. **Running CAS server**: Start with `just serve`

## Running Tests

### Docker-based Testing (Recommended)

**Run complete integration test** (starts server + runs Bazel tests):

```bash
# From project root
just test-bazel-docker

# Or manually
cd tests/bazel
docker-compose up --build --abort-on-container-exit
```

This will:
1. Build the CAS server Docker image
2. Build the Bazel test environment image
3. Start the CAS server with health checks
4. Run the integration test script automatically
5. Report cache performance results

**Clean up after testing:**
```bash
cd tests/bazel
docker-compose down -v  # Remove containers and volumes
```

### Authentication Testing (Week 3+)

**Test with authentication enabled:**

```bash
# From project root
cd tests/bazel

# Run authentication integration test (Docker)
docker-compose -f docker-compose.auth.yml up --build --abort-on-container-exit

# Or run locally if server has auth enabled
export CAS_AUTH_ENABLED=true
export CAS_AUTH_TOKENS_FILE=/tmp/cas_test_tokens.json
just serve  # In one terminal

./test_integration_auth.sh  # In another terminal
```

This authentication test validates:
- ✓ Valid token accepted
- ✓ Invalid token rejected (UNAUTHENTICATED error)
- ✓ Missing token rejected
- ✓ Revoked token rejected
- ✓ Cache still works with authentication

**Manual authentication testing:**

```bash
# Create a token
cascache_server admin create-token --name "bazel-test" --expires-days 7

# Use token with Bazel (copy from output above)
export TOKEN="cas-token-YOUR_TOKEN_HERE"
bazel build //... --config=cache \
  --remote_header="authorization=Bearer ${TOKEN}"

# Revoke token
cascache_server admin revoke-token "${TOKEN}"

# Try again (should fail)
bazel build //... --config=cache \
  --remote_header="authorization=Bearer ${TOKEN}"
# Expected: UNAUTHENTICATED error
```

**Clean up after auth testing:**
```bash
docker-compose -f docker-compose.auth.yml down -v
rm -f /tmp/cas_test_tokens.json
```

### Local Testing (Alternative)

If you have Bazel installed locally:

```bash
# Start CAS server
just serve

# In another terminal, run test
cd tests/bazel
./test_integration.sh
```

The test script:
1. Cleans all caches
2. Performs a cold build (populates remote cache)
3. Cleans local cache
4. Performs a warm build (hits remote cache)
5. Compares build times and reports cache effectiveness
### Remote Cache Settings

The [.bazelrc](.bazelrc) file configures remote caching with environment variable support:

```ini
build --remote_cache=grpc://${CAS_SERVER_HOST:-localhost}:${CAS_SERVER_PORT:-50051}
build --remote_upload_local_results=true
build --remote_accept_cached=true
```

**Docker setup**: Automatically uses `cas-server:50051` (service name in docker-compose)  
**Local setup**: Uses `localhost:50051` by default

### Docker Compose Architecture

[docker-compose.yml](docker-compose.yml) orchestrates two services:

1. **cas-server**: The cascache_server gRPC server
   - Exposed on `localhost:50051`
   - Uses filesystem storage in Docker volume
   - Health checks ensure it's ready before tests run

2. **bazel-test**: Bazel environment with C++ toolchain
   - Connects to `cas-server` via Docker network
   - Runs integration test automatically
   - Caches Bazel artifacts for faster rebuildsel test //...
```

**Build specific targets:**
```bash
bazel build //:hello        # Python binary
bazel build //:math_app     # C++ binary
bazel test //:hello_test    # Python test
bazel test //:math_test     # C++ test
```

**Clean cache for retesting:**
```bash
bazel clean                 # Clean local cache only
bazel clean --expunge       # Clean all caches
```

## Configuration

The [.bazelrc](.bazelrc) file configures remote caching:

```ini
build --remote_cache=grpc://localhost:50051
build --remote_upload_local_results=true
build --remote_accept_cached=true
```

To use a different cache server:
```bash
bazel build //... --remote_cache=grpc://my-server:50051
```

## Project Structure

```
tests/bazel/
├── WORKSPACE              # Bazel workspace definition
├── BUILD.bazel            # Build targets
├── .bazelrc              # Remote cache configuration
├── .gitignore            # Ignore Bazel artifacts
├── test_integration.sh   # Integration test script
├── README.md             # This file
│
├── hello_lib.py          # Python library
├── hello.py              # Python binary
├── hello_test.py         # Python test
│
├── math_lib.h            # C++ library header
├── math_lib.cc           # C++ library implementation
├── math_app.cc           # C++ application
└── math_test.cc          # C++ test
```

## Interpreting Results

### Successful Caching

When remote caching works correctly:
- Warm builds should be **significantly faster** than cold builds
- You'll see messages like "remote cache hit" in verbose output
- The `test_integration.sh` script will report speedup (e.g., "5.2x")

### Cache Metrics

Check CAS server metrics after builds:
```bash
# View server logs
just serve-debug

# Look for:
# - cache_hits: Number of successful cache retrievals
# - cache_misses: Number of cache misses
# - total_blobs: Number of artifacts stored
```
Docker: Check server health with `docker-compose ps`
2. Local: Verify server is running on port 50051
3. Check firewall settings
4. Docker: Ensure containers are on same network

**Docker issues:**
1. Image build fails: Ensure Docker daemon is running
2. Permission denied: Add user to docker group or use `sudo`
3. Port already in use: Stop existing services on port 50051
**Builds not hitting cache:**
1. Verify server is running: `nc -z localhost 50051`
2. Check `.bazelrc` configuration
3. Run with verbose logging: `bazel build //... --verbose_failures`
4. Ensure deterministic builds (timestamps, random values affect caching)

**C++ targets failing:**
1. Install C++ toolchain (see Prerequisites)
2. Try Python targets only: `bazel build //:hello //:hello_test`

**Connection refused:**
1. Check CAS server is uses Docker Compose for integration testing:

```yaml
test:bazel:
  stage: integration
  services:
    - docker:dind
  script:
    - cd tests/bazel
    - docker-compose up --build --abort-on-container-exit
    - docker-compose down -v
```

This validates remote caching with every merge request to main, using the same Docker setup as local development
    - uv run python -m cascache_server &
    - sleep 5
    - cd tests/bazel && ./test_integration.sh
```

This validates remote caching with every merge request to main.

## Next Steps

After validating basic caching:

1. **Monitor metrics**: Track cache hit rates over time
2. **Test with real projects**: Point your actual Bazel projects to cascache_server
3. **Benchmark performance**: Measure speedup on large builds
4. **Test distributed builds**: Multiple clients accessing same cache
5. **Implement ActionCache**: Enable action result caching (Week 2)

## Additional Resources

- [Bazel Remote Caching Documentation](https://bazel.build/remote/caching)
- [Remote Execution API Specification](https://github.com/bazelbuild/remote-apis)
- [cascache_server API Documentation](../../docs/api.md)
- [cascache_server Operations Guide](../../docs/operations.md)
