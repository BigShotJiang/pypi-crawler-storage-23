#include "math_lib.h"
#include <cassert>
#include <iostream>

int main() {
    // Test addition
    assert(math::Add(2, 3) == 5);
    assert(math::Add(-1, 1) == 0);
    
    // Test multiplication
    assert(math::Multiply(4, 5) == 20);
    assert(math::Multiply(0, 10) == 0);
    
    // Test division
    assert(math::Divide(10.0, 2.0) == 5.0);
    assert(math::Divide(10.0, 0.0) == 0.0);  // Handles division by zero
    
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
