"""Tests for hello_lib."""

import unittest

import hello_lib


class HelloLibTest(unittest.TestCase):
    """Test cases for hello_lib."""

    def test_greet(self):
        """Test greeting function."""
        self.assertEqual(hello_lib.greet("World"), "Hello, World!")

    def test_compute_sum(self):
        """Test sum computation."""
        self.assertEqual(hello_lib.compute_sum([1, 2, 3]), 6)
        self.assertEqual(hello_lib.compute_sum([]), 0)
        self.assertEqual(hello_lib.compute_sum([10]), 10)


if __name__ == "__main__":
    unittest.main()
