#!/usr/bin/env bash
# Integration test with authentication enabled
# Tests that token-based authentication works correctly with Bazel

set -e  # Exit on error
set -u  # Exit on undefined variable

# Color output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
CAS_SERVER_PORT="${CAS_SERVER_PORT:-50051}"
CAS_SERVER_HOST="${CAS_SERVER_HOST:-localhost}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEST_WORKSPACE="${SCRIPT_DIR}"
TOKENS_FILE="${TOKENS_FILE:-/tmp/cas_test_tokens.json}"

echo -e "${GREEN}=== Bazel CAS Authentication Test ===${NC}"
echo "Test workspace: ${TEST_WORKSPACE}"
echo "CAS server: grpc://${CAS_SERVER_HOST}:${CAS_SERVER_PORT}"
echo "Tokens file: ${TOKENS_FILE}"
echo ""

# Check if cascache_server CLI is available
if ! command -v cascache_server &> /dev/null; then
    echo -e "${RED}ERROR: cascache_server CLI is not available${NC}"
    echo "Install with: uv pip install -e ."
    exit 1
fi

# Check if CAS server is running
echo -e "${YELLOW}Checking CAS server connectivity...${NC}"
if ! nc -z "${CAS_SERVER_HOST}" "${CAS_SERVER_PORT}" 2>/dev/null; then
    echo -e "${RED}ERROR: CAS server is not reachable at ${CAS_SERVER_HOST}:${CAS_SERVER_PORT}${NC}"
    echo "Start the authenticated server with:"
    echo "  export CAS_AUTH_ENABLED=true"
    echo "  export CAS_AUTH_TOKENS_FILE=${TOKENS_FILE}"
    echo "  just serve"
    exit 1
fi
echo -e "${GREEN}✓ CAS server is running${NC}"
echo ""

# Create authentication token
echo -e "${YELLOW}=== Creating Authentication Token ===${NC}"
TOKEN=$(cascache_server admin create-token --name "bazel-test" --expires-days 1 --tokens-file "${TOKENS_FILE}" 2>&1 | grep "cas-token-" | head -1 | awk '{print $2}')

if [ -z "${TOKEN}" ]; then
    echo -e "${RED}ERROR: Failed to create token${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Token created: ${TOKEN:0:20}...${NC}"
echo ""

# Export token for test script
export CAS_AUTH_TOKEN="${TOKEN}"

# Run regular integration test with authentication
echo -e "${YELLOW}=== Running Integration Test (with authentication) ===${NC}"
"${SCRIPT_DIR}/test_integration.sh"

# Test invalid token (should fail)
echo -e "${YELLOW}=== Testing Invalid Token (should fail) ===${NC}"
export CAS_AUTH_TOKEN="cas-token-invalid-12345678901234567890"
cd "${TEST_WORKSPACE}"
bazel clean --expunge 2>&1 | grep -v "^INFO:" || true

echo "Attempting build with invalid token..."
if bazel build //:hello --config=cache \
    --remote_cache="grpc://${CAS_SERVER_HOST}:${CAS_SERVER_PORT}" \
    --remote_header="authorization=Bearer ${CAS_AUTH_TOKEN}" 2>&1 | grep -q "UNAUTHENTICATED"; then
    echo -e "${GREEN}✓ Authentication correctly rejected invalid token${NC}"
else
    echo -e "${RED}✗ Server should have rejected invalid token${NC}"
    exit 1
fi
echo ""

# Test with no token (should fail)
echo -e "${YELLOW}=== Testing No Token (should fail) ===${NC}"
echo "Attempting build without token..."
if bazel build //:hello --config=cache \
    --remote_cache="grpc://${CAS_SERVER_HOST}:${CAS_SERVER_PORT}" 2>&1 | grep -q "UNAUTHENTICATED"; then
    echo -e "${GREEN}✓ Authentication correctly requires token${NC}"
else
    echo -e "${RED}✗ Server should require authentication${NC}"
    exit 1
fi
echo ""

# Test token revocation
echo -e "${YELLOW}=== Testing Token Revocation ===${NC}"
# Set back to valid token
export CAS_AUTH_TOKEN="${TOKEN}"

echo "Revoking token..."
cascache_server admin revoke-token "${TOKEN}" --tokens-file "${TOKENS_FILE}" > /dev/null

echo "Attempting build with revoked token..."
if bazel build //:hello --config=cache \
    --remote_cache="grpc://${CAS_SERVER_HOST}:${CAS_SERVER_PORT}" \
    --remote_header="authorization=Bearer ${CAS_AUTH_TOKEN}" 2>&1 | grep -q "UNAUTHENTICATED"; then
    echo -e "${GREEN}✓ Revoked token correctly rejected${NC}"
else
    echo -e "${RED}✗ Server should have rejected revoked token${NC}"
    exit 1
fi
echo ""

# Cleanup
echo -e "${YELLOW}Cleaning up test tokens...${NC}"
rm -f "${TOKENS_FILE}"
echo -e "${GREEN}✓ Cleanup complete${NC}"
echo ""

echo -e "${GREEN}=== Authentication Test Complete ===${NC}"
echo "All authentication scenarios verified:"
echo "  ✓ Valid token accepted"
echo "  ✓ Invalid token rejected"
echo "  ✓ Missing token rejected"
echo "  ✓ Revoked token rejected"
echo ""
