"""Unit tests for CAS service."""

from unittest.mock import Mock

import pytest

from cascache_server.monitoring.metrics import metrics
from cascache_server.services.cas_service import ContentAddressableStorageService

# Valid 64-character SHA256 digests for testing
DIGEST_EXISTS = "a" * 64
DIGEST_MISSING1 = "b" * 64
DIGEST_MISSING2 = "c" * 64
DIGEST_HIT = "d" * 64
DIGEST_MISS = "e" * 64
DIGEST_ABC = "f" * 64
DIGEST_DEF = "1" * 64
DIGEST_A = "2" * 64
DIGEST_B = "3" * 64
DIGEST_C = "4" * 64
DIGEST_ABC123 = "5" * 64


@pytest.fixture
def mock_storage():
    """Create mock storage backend."""
    return Mock()


@pytest.fixture
def service_with_mock(mock_storage):
    """Create CAS service with mock storage."""
    return ContentAddressableStorageService(mock_storage)


def test_find_missing_blobs_returns_missing(service_with_mock, mock_storage):
    """Test find_missing_blobs() returns only missing digests."""
    mock_storage.exists.side_effect = lambda d: d == DIGEST_EXISTS

    digests = [DIGEST_EXISTS, DIGEST_MISSING1, DIGEST_MISSING2]
    result = service_with_mock.find_missing_blobs(digests)

    assert result == [DIGEST_MISSING1, DIGEST_MISSING2]


def test_find_missing_blobs_records_metrics(service_with_mock, mock_storage):
    """Test find_missing_blobs() records cache hits/misses."""
    mock_storage.exists.side_effect = lambda d: d == DIGEST_HIT

    initial_hits = metrics.hits
    initial_misses = metrics.misses

    service_with_mock.find_missing_blobs([DIGEST_HIT, DIGEST_MISS])

    assert metrics.hits == initial_hits + 1
    assert metrics.misses == initial_misses + 1


def test_find_missing_blobs_all_exist(service_with_mock, mock_storage):
    """Test find_missing_blobs() returns empty when all exist."""
    mock_storage.exists.return_value = True

    result = service_with_mock.find_missing_blobs([DIGEST_A, DIGEST_B, DIGEST_C])

    assert result == []


def test_batch_read_blobs_returns_data(service_with_mock, mock_storage):
    """Test batch_read_blobs() returns blob data."""
    mock_storage.get.side_effect = lambda d: f"data-{d[:8]}".encode()

    result = service_with_mock.batch_read_blobs([DIGEST_ABC, DIGEST_DEF])

    assert result == {
        DIGEST_ABC: b"data-ffffffff",
        DIGEST_DEF: b"data-11111111",
    }


def test_batch_read_blobs_handles_missing(service_with_mock, mock_storage):
    """Test batch_read_blobs() handles missing blobs."""

    def get_side_effect(digest):
        if digest == DIGEST_MISSING1:
            raise FileNotFoundError()
        return b"data"

    mock_storage.get.side_effect = get_side_effect

    result = service_with_mock.batch_read_blobs([DIGEST_EXISTS, DIGEST_MISSING1])

    assert result == {DIGEST_EXISTS: b"data", DIGEST_MISSING1: None}


def test_batch_write_blobs_stores_all(service_with_mock, mock_storage):
    """Test batch_write_blobs() stores all blobs."""
    blobs = {DIGEST_ABC: b"data1", DIGEST_DEF: b"data2"}

    service_with_mock.batch_write_blobs(blobs)

    assert mock_storage.put.call_count == 2
    mock_storage.put.assert_any_call(DIGEST_ABC, b"data1")
    mock_storage.put.assert_any_call(DIGEST_DEF, b"data2")


def test_batch_write_blobs_records_metrics(service_with_mock, mock_storage):
    """Test batch_write_blobs() records metrics."""
    initial_blobs = metrics.total_blobs
    initial_bytes = metrics.total_bytes_stored

    blobs = {DIGEST_ABC: b"data1", DIGEST_DEF: b"data22"}
    service_with_mock.batch_write_blobs(blobs)

    assert metrics.total_blobs == initial_blobs + 2
    assert metrics.total_bytes_stored == initial_bytes + 5 + 6  # data1 + data22


def test_get_blob_returns_data(service_with_mock, mock_storage):
    """Test get_blob() returns blob data."""
    mock_storage.get.return_value = b"test data"

    result = service_with_mock.get_blob("abc123")

    assert result == b"test data"
    mock_storage.get.assert_called_once_with("abc123")


def test_get_blob_missing_raises_error(service_with_mock, mock_storage):
    """Test get_blob() raises FileNotFoundError for missing blob."""
    mock_storage.get.side_effect = FileNotFoundError("Blob not found")

    with pytest.raises(FileNotFoundError):
        service_with_mock.get_blob("missing")


def test_get_blob_records_hit(service_with_mock, mock_storage):
    """Test get_blob() records cache hit."""
    mock_storage.get.return_value = b"data"
    initial_hits = metrics.hits

    service_with_mock.get_blob("abc123")

    assert metrics.hits == initial_hits + 1


def test_put_blob_stores_data(service_with_mock, mock_storage):
    """Test put_blob() stores blob."""
    service_with_mock.put_blob("abc123", b"test data")

    mock_storage.put.assert_called_once_with("abc123", b"test data")


def test_put_blob_records_metrics(service_with_mock, mock_storage):
    """Test put_blob() records metrics."""
    initial_blobs = metrics.total_blobs
    initial_bytes = metrics.total_bytes_stored

    service_with_mock.put_blob("abc123", b"test data")

    assert metrics.total_blobs == initial_blobs + 1
    assert metrics.total_bytes_stored == initial_bytes + 9
