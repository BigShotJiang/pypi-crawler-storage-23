"""Unit tests for ActionCache service."""

from __future__ import annotations

import pytest

from cascache_server.api.generated import action_cache_pb2
from cascache_server.services.action_cache_service import ActionCacheService
from cascache_server.storage.memory import MemoryStorage


@pytest.fixture
def storage():
    """Create a fresh MemoryStorage instance."""
    return MemoryStorage()


@pytest.fixture
def action_cache_service(storage):
    """Create an ActionCacheService with memory storage."""
    return ActionCacheService(storage)


def test_initialization(action_cache_service):
    """Test service initializes correctly."""
    assert action_cache_service is not None
    assert action_cache_service.storage is not None


def test_action_key_prefix():
    """Test action cache keys use correct prefix."""
    storage = MemoryStorage()
    service = ActionCacheService(storage)

    key = service._get_action_key("abc123/1024")
    assert key.startswith("ac_")
    assert key == "ac_abc123_1024"  # Slash replaced with underscore


def test_get_action_result_not_found(action_cache_service):
    """Test getting non-existent action result returns None."""
    result = action_cache_service.get_action_result("nonexistent/123")
    assert result is None


def test_update_and_get_action_result(action_cache_service):
    """Test storing and retrieving action result."""
    action_digest = "abc123/1024"

    # Create action result proto
    action_result = action_cache_pb2.ActionResult(
        exit_code=0,
        output_files=[
            action_cache_pb2.OutputFile(
                path="output.txt",
                digest=action_cache_pb2.Digest(hash="def456", size_bytes=512),
                is_executable=False,
            )
        ],
    )

    # Store result
    stored = action_cache_service.update_action_result(action_digest, action_result)
    assert stored.exit_code == 0

    # Retrieve result
    retrieved = action_cache_service.get_action_result(action_digest)
    assert retrieved is not None
    assert retrieved.exit_code == 0
    assert len(retrieved.output_files) == 1
    assert retrieved.output_files[0].path == "output.txt"


def test_action_result_with_stderr(action_cache_service):
    """Test action result with stderr output."""
    action_digest = "err123/2048"
    action_result = action_cache_pb2.ActionResult(exit_code=1, stderr_raw=b"Error occurred")

    action_cache_service.update_action_result(action_digest, action_result)
    retrieved = action_cache_service.get_action_result(action_digest)

    assert retrieved.exit_code == 1
    assert retrieved.stderr_raw == b"Error occurred"


def test_action_result_with_stdout_digest(action_cache_service):
    """Test action result with stdout digest."""
    action_digest = "out123/4096"
    action_result = action_cache_pb2.ActionResult(
        exit_code=0, stdout_digest=action_cache_pb2.Digest(hash="stdout_hash", size_bytes=100)
    )

    action_cache_service.update_action_result(action_digest, action_result)
    retrieved = action_cache_service.get_action_result(action_digest)

    assert retrieved.stdout_digest.hash == "stdout_hash"
    assert retrieved.stdout_digest.size_bytes == 100


def test_action_result_with_output_directory(action_cache_service):
    """Test action result with output directory."""
    action_digest = "dir123/8192"
    action_result = action_cache_pb2.ActionResult(
        exit_code=0,
        output_directories=[
            action_cache_pb2.OutputDirectory(
                path="output_dir",
                tree_digest=action_cache_pb2.Digest(hash="tree_hash", size_bytes=1024),
            )
        ],
    )

    action_cache_service.update_action_result(action_digest, action_result)
    retrieved = action_cache_service.get_action_result(action_digest)

    assert len(retrieved.output_directories) == 1
    assert retrieved.output_directories[0].path == "output_dir"
    assert retrieved.output_directories[0].tree_digest.hash == "tree_hash"


def test_action_result_with_executable_file(action_cache_service):
    """Test action result with executable output file."""
    action_digest = "exe123/512"
    action_result = action_cache_pb2.ActionResult(
        exit_code=0,
        output_files=[
            action_cache_pb2.OutputFile(
                path="binary",
                digest=action_cache_pb2.Digest(hash="bin_hash", size_bytes=8192),
                is_executable=True,
            )
        ],
    )

    action_cache_service.update_action_result(action_digest, action_result)
    retrieved = action_cache_service.get_action_result(action_digest)

    assert retrieved.output_files[0].is_executable is True


def test_update_overwrites_existing(action_cache_service):
    """Test updating existing action result overwrites it."""
    action_digest = "update123/1024"

    # Store initial result
    initial_result = action_cache_pb2.ActionResult(exit_code=0)
    action_cache_service.update_action_result(action_digest, initial_result)

    # Update with new result
    updated_result = action_cache_pb2.ActionResult(exit_code=1, stderr_raw=b"Error")
    action_cache_service.update_action_result(action_digest, updated_result)

    # Retrieve should get updated result
    retrieved = action_cache_service.get_action_result(action_digest)
    assert retrieved.exit_code == 1
    assert retrieved.stderr_raw == b"Error"


def test_instance_name_handling(action_cache_service):
    """Test instance name is logged but doesn't affect storage."""
    action_digest = "inst123/2048"
    action_result = action_cache_pb2.ActionResult(exit_code=0)

    # Store with instance name
    action_cache_service.update_action_result(
        action_digest, action_result, instance_name="my-instance"
    )

    # Retrieve with different instance name (should still work)
    retrieved = action_cache_service.get_action_result(
        action_digest, instance_name="other-instance"
    )
    assert retrieved.exit_code == 0


def test_complex_action_result(action_cache_service):
    """Test complex action result with multiple outputs."""
    action_digest = "complex123/16384"
    action_result = action_cache_pb2.ActionResult(
        exit_code=0,
        stdout_raw=b"Build succeeded",
        stderr_raw=b"1 warning",
        output_files=[
            action_cache_pb2.OutputFile(
                path="lib.so",
                digest=action_cache_pb2.Digest(hash="lib_hash", size_bytes=50000),
                is_executable=True,
            ),
            action_cache_pb2.OutputFile(
                path="lib.h",
                digest=action_cache_pb2.Digest(hash="header_hash", size_bytes=2000),
                is_executable=False,
            ),
        ],
        output_directories=[
            action_cache_pb2.OutputDirectory(
                path="docs",
                tree_digest=action_cache_pb2.Digest(hash="docs_tree", size_bytes=100000),
            )
        ],
    )

    action_cache_service.update_action_result(action_digest, action_result)
    retrieved = action_cache_service.get_action_result(action_digest)

    assert retrieved.exit_code == 0
    assert retrieved.stdout_raw == b"Build succeeded"
    assert retrieved.stderr_raw == b"1 warning"
    assert len(retrieved.output_files) == 2
    assert len(retrieved.output_directories) == 1
