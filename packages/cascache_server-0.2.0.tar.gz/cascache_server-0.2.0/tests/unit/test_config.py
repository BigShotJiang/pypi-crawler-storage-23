"""Test YAML configuration loading."""

import os
import tempfile
from pathlib import Path

import pytest
import yaml

from cascache_server.config import CASConfig, load_config
from cascache_server.utils.errors import ConfigError


def test_load_config_from_yaml_file():
    """Test loading configuration from YAML file."""
    config_data = {
        "storage_type": "memory",
        "storage_path": "/custom/path",
        "port": 9999,
        "log_level": "DEBUG",
        "workers": 20,
    }

    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        yaml.dump(config_data, f)
        config_file = Path(f.name)

    try:
        config = load_config(config_file)
        assert config.storage_type == "memory"
        assert config.storage_path == "/custom/path"
        assert config.port == 9999
        assert config.log_level == "DEBUG"
        assert config.workers == 20
    finally:
        config_file.unlink()


def test_env_vars_override_yaml_file():
    """Test that environment variables take precedence over YAML file."""
    config_data = {
        "storage_type": "memory",
        "port": 9999,
    }

    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        yaml.dump(config_data, f)
        config_file = Path(f.name)

    try:
        # Set env var to override YAML
        os.environ["CAS_PORT"] = "8888"
        config = load_config(config_file)

        # Env var should win
        assert config.port == 8888
        # YAML value still applies
        assert config.storage_type == "memory"
    finally:
        config_file.unlink()
        del os.environ["CAS_PORT"]


def test_load_config_with_cas_prefix_in_yaml():
    """Test YAML file with CAS_ prefixed keys (should be normalized)."""
    config_data = {
        "CAS_STORAGE_TYPE": "s3",  # Should be normalized to storage_type
        "CAS_PORT": 7777,
        "storage_path": "/bucket",  # Mixed case
    }

    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        yaml.dump(config_data, f)
        config_file = Path(f.name)

    try:
        config = load_config(config_file)
        assert config.storage_type == "s3"
        assert config.port == 7777
        assert config.storage_path == "/bucket"
    finally:
        config_file.unlink()


def test_pydantic_validation_in_yaml():
    """Test that Pydantic validators work with YAML config."""
    config_data = {
        "storage_type": "invalid_type",  # Should fail validation
        "port": 50051,
    }

    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        yaml.dump(config_data, f)
        config_file = Path(f.name)

    try:
        with pytest.raises(ConfigError, match="Invalid storage_type"):
            load_config(config_file)
    finally:
        config_file.unlink()


def test_load_config_defaults_without_file():
    """Test loading config without file uses defaults."""
    config = load_config()

    # Check defaults
    assert config.storage_type == "filesystem"
    assert config.port == 50051
    assert config.workers == 10
    assert config.log_level == "INFO"
    assert config.enable_cache is True


def test_pydantic_basemodel_direct_instantiation():
    """Test direct instantiation of CASConfig with Pydantic."""
    config = CASConfig(
        storage_type="s3",
        storage_path="my-bucket",
        port=9000,
        log_level="warning",  # Should be uppercased by validator
    )

    assert config.storage_type == "s3"
    assert config.storage_path == "my-bucket"
    assert config.port == 9000
    assert config.log_level == "WARNING"  # Validator converts to uppercase


def test_field_validation_constraints():
    """Test Pydantic field constraints work correctly."""
    # Port too low
    with pytest.raises(Exception):  # Pydantic ValidationError
        CASConfig(port=0)

    # Port too high
    with pytest.raises(Exception):
        CASConfig(port=70000)

    # Workers too low
    with pytest.raises(Exception):
        CASConfig(workers=0)


def test_reapi_versions_comma_separated_string():
    """Test REAPI versions field handles comma-separated strings."""
    config = CASConfig(reapi_versions="simple,v2,v3")
    assert config.reapi_versions == ["simple", "v2", "v3"]

    # Also handles list directly
    config2 = CASConfig(reapi_versions=["simple", "v2"])
    assert config2.reapi_versions == ["simple", "v2"]


def test_tls_validation():
    """Test TLS configuration validation."""
    # TLS enabled but missing cert files
    with pytest.raises(Exception, match="certificate"):
        CASConfig(tls_enabled=True)

    # TLS with cert files should work
    config = CASConfig(
        tls_enabled=True,
        tls_cert_file=Path("/tmp/cert.pem"),
        tls_key_file=Path("/tmp/key.pem"),
    )
    assert config.tls_enabled is True


def test_eviction_size_quota_validation():
    """Test eviction size quota validation."""
    # Target size >= max size should fail
    with pytest.raises(Exception, match="target_size_gb"):
        CASConfig(
            eviction_policy="size_quota",
            eviction_max_size_gb=100,
            eviction_target_size_gb=100,
        )

    # Target < max should work
    config = CASConfig(
        eviction_policy="size_quota",
        eviction_max_size_gb=100,
        eviction_target_size_gb=80,
    )
    assert config.eviction_max_size_gb == 100
    assert config.eviction_target_size_gb == 80
