"""Tests for dashboard module."""

import pytest


@pytest.fixture
def server_metrics():
    """Create ServerMetrics instance for testing."""
    from cascache_server.monitoring.metrics import ServerMetrics

    return ServerMetrics()


@pytest.fixture
def dashboard_app(server_metrics):
    """Create dashboard app for testing."""
    pytest.importorskip("fastapi")
    pytest.importorskip("uvicorn")

    from cascache_server.dashboard import create_dashboard_app

    return create_dashboard_app(server_metrics)


class TestDashboardApp:
    """Test dashboard application."""

    def test_creates_fastapi_app(self, dashboard_app):
        """Test that create_dashboard_app returns a FastAPI instance."""
        from fastapi import FastAPI

        assert isinstance(dashboard_app, FastAPI)
        assert dashboard_app.title == "Python CAS Server Dashboard"

    def test_has_required_routes(self, dashboard_app):
        """Test that dashboard has all required routes."""
        routes = {route.path for route in dashboard_app.routes}

        assert "/" in routes
        assert "/api/stats" in routes
        assert "/health" in routes


class TestStatsEndpoint:
    """Test /api/stats endpoint."""

    @pytest.mark.asyncio
    async def test_stats_initial_state(self, dashboard_app, server_metrics):
        """Test stats endpoint returns correct initial state."""
        from httpx import ASGITransport, AsyncClient

        async with AsyncClient(
            transport=ASGITransport(app=dashboard_app), base_url="http://test"
        ) as client:
            response = await client.get("/api/stats")

        assert response.status_code == 200
        data = response.json()

        # Check structure
        assert "cache" in data
        assert "storage" in data
        assert "operations" in data
        assert "eviction" in data
        assert "server" in data

        # Check initial values
        assert data["cache"]["hits"] == 0
        assert data["cache"]["misses"] == 0
        assert data["cache"]["total_requests"] == 0
        assert data["storage"]["blobs_count"] == 0
        assert data["storage"]["total_bytes"] == 0

    @pytest.mark.asyncio
    async def test_stats_after_metrics_update(self, dashboard_app, server_metrics):
        """Test stats endpoint reflects metrics updates."""
        from httpx import ASGITransport, AsyncClient

        # Update metrics
        server_metrics.cache_metrics.record_hit()
        server_metrics.cache_metrics.record_hit()
        server_metrics.cache_metrics.record_miss()
        server_metrics.cache_metrics.record_blob_added(1024)
        server_metrics.record_read()
        server_metrics.record_write()
        server_metrics.record_eviction(5)

        async with AsyncClient(
            transport=ASGITransport(app=dashboard_app), base_url="http://test"
        ) as client:
            response = await client.get("/api/stats")

        assert response.status_code == 200
        data = response.json()

        # Check updated values
        assert data["cache"]["hits"] == 2
        assert data["cache"]["misses"] == 1
        assert data["cache"]["total_requests"] == 3
        assert data["cache"]["hit_rate"] == "66.67%"
        assert data["storage"]["blobs_count"] == 1
        assert data["storage"]["total_bytes"] == 1024
        assert data["operations"]["reads"] == 1
        assert data["operations"]["writes"] == 1
        assert data["eviction"]["evictions"] == 5

    @pytest.mark.asyncio
    async def test_stats_human_readable_formats(self, dashboard_app, server_metrics):
        """Test that stats include human-readable formats."""
        from httpx import ASGITransport, AsyncClient

        # Add large blob
        server_metrics.cache_metrics.record_blob_added(5 * 1024 * 1024 * 1024)  # 5GB

        async with AsyncClient(
            transport=ASGITransport(app=dashboard_app), base_url="http://test"
        ) as client:
            response = await client.get("/api/stats")

        assert response.status_code == 200
        data = response.json()

        # Check human-readable size
        assert "GB" in data["storage"]["total_bytes_human"]
        assert "uptime_human" in data["server"]


class TestHealthEndpoint:
    """Test /health endpoint."""

    @pytest.mark.asyncio
    async def test_health_check(self, dashboard_app):
        """Test health endpoint returns ok."""
        from httpx import ASGITransport, AsyncClient

        async with AsyncClient(
            transport=ASGITransport(app=dashboard_app), base_url="http://test"
        ) as client:
            response = await client.get("/health")

        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"


class TestDashboardHTML:
    """Test dashboard HTML page."""

    @pytest.mark.asyncio
    async def test_dashboard_page_loads(self, dashboard_app):
        """Test that dashboard HTML page loads."""
        from httpx import ASGITransport, AsyncClient

        async with AsyncClient(
            transport=ASGITransport(app=dashboard_app), base_url="http://test"
        ) as client:
            response = await client.get("/")

        assert response.status_code == 200
        assert "text/html" in response.headers["content-type"]

        # Check for key dashboard elements
        html = response.text
        assert "Python CAS Server Dashboard" in html
        assert "/api/stats" in html  # JavaScript should fetch from this endpoint
        assert "Cache Performance" in html


class TestServerMetrics:
    """Test ServerMetrics class."""

    def test_initial_state(self, server_metrics):
        """Test ServerMetrics initial state."""
        stats = server_metrics.get_stats()

        assert stats["reads"] == 0
        assert stats["writes"] == 0
        assert stats["deletes"] == 0
        assert stats["evictions"] == 0
        assert stats["last_eviction_run"] is None

    def test_record_operations(self, server_metrics):
        """Test recording operations."""
        server_metrics.record_read()
        server_metrics.record_read()
        server_metrics.record_write()
        server_metrics.record_delete()

        stats = server_metrics.get_stats()
        assert stats["reads"] == 2
        assert stats["writes"] == 1
        assert stats["deletes"] == 1

    def test_record_evictions(self, server_metrics):
        """Test recording evictions."""
        server_metrics.record_eviction(3)
        server_metrics.record_eviction(2)

        stats = server_metrics.get_stats()
        assert stats["evictions"] == 5

    def test_record_eviction_run(self, server_metrics):
        """Test recording eviction run times."""
        import time

        before = time.time()
        server_metrics.record_eviction_run()
        after = time.time()

        stats = server_metrics.get_stats()
        assert stats["last_eviction_run"] >= before
        assert stats["last_eviction_run"] <= after

    def test_thread_safety(self, server_metrics):
        """Test that ServerMetrics is thread-safe."""
        import threading

        def record_many():
            for _ in range(100):
                server_metrics.record_read()
                server_metrics.record_write()
                server_metrics.record_eviction(1)

        threads = [threading.Thread(target=record_many) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        stats = server_metrics.get_stats()
        assert stats["reads"] == 1000
        assert stats["writes"] == 1000
        assert stats["evictions"] == 1000

    def test_reset(self, server_metrics):
        """Test resetting metrics."""
        server_metrics.record_read()
        server_metrics.record_write()
        server_metrics.record_eviction(5)

        server_metrics.reset()

        stats = server_metrics.get_stats()
        assert stats["reads"] == 0
        assert stats["writes"] == 0
        assert stats["evictions"] == 0
