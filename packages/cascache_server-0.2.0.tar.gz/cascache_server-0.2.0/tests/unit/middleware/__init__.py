"""Tests for middleware components."""
