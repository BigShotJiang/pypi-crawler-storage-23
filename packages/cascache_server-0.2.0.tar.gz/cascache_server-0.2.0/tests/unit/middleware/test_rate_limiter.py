"""Tests for rate limiting middleware."""

import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from unittest.mock import MagicMock

from cascache_server.middleware import RateLimiter, RateLimitInterceptor


class TestRateLimiter:
    """Tests for RateLimiter class."""

    def test_basic_rate_limiting(self):
        """Test basic rate limiting with single client."""
        limiter = RateLimiter(rate=10.0, burst=5)

        # Should allow burst amount of requests immediately
        for _ in range(5):
            assert limiter.acquire("client1") is True

        # Should reject next request (no tokens left)
        assert limiter.acquire("client1") is False

    def test_per_client_buckets(self):
        """Test that rate limits are per-client."""
        limiter = RateLimiter(rate=10.0, burst=5)

        # Exhaust client1's tokens
        for _ in range(5):
            assert limiter.acquire("client1") is True
        assert limiter.acquire("client1") is False

        # Client2 should still have tokens
        assert limiter.acquire("client2") is True

    def test_token_refill(self):
        """Test that tokens refill over time."""
        limiter = RateLimiter(rate=10.0, burst=5)

        # Exhaust tokens
        for _ in range(5):
            assert limiter.acquire("client1") is True
        assert limiter.acquire("client1") is False

        # Wait for ~1 token to refill (0.1 seconds at 10 tokens/sec)
        time.sleep(0.15)

        # Should have 1 token now
        assert limiter.acquire("client1") is True
        # No more tokens
        assert limiter.acquire("client1") is False

    def test_burst_cap(self):
        """Test that tokens don't accumulate beyond burst limit."""
        limiter = RateLimiter(rate=100.0, burst=5)

        # Wait long enough to exceed burst capacity
        time.sleep(0.2)  # Would generate 20 tokens, but capped at 5

        # Should only allow burst amount
        for _ in range(5):
            assert limiter.acquire("client1") is True
        assert limiter.acquire("client1") is False

    def test_multiple_tokens(self):
        """Test acquiring multiple tokens at once."""
        limiter = RateLimiter(rate=10.0, burst=10)

        # Acquire 5 tokens
        assert limiter.acquire("client1", tokens=5) is True

        # Acquire 3 more tokens
        assert limiter.acquire("client1", tokens=3) is True

        # Try to acquire 5 more (only 2 left)
        assert limiter.acquire("client1", tokens=5) is False

        # Can acquire 2
        assert limiter.acquire("client1", tokens=2) is True

    def test_reset(self):
        """Test resetting client rate limit."""
        limiter = RateLimiter(rate=10.0, burst=5)

        # Exhaust tokens
        for _ in range(5):
            assert limiter.acquire("client1") is True
        assert limiter.acquire("client1") is False

        # Reset
        limiter.reset("client1")

        # Should have tokens again
        assert limiter.acquire("client1") is True

    def test_get_stats(self):
        """Test getting rate limiter statistics."""
        limiter = RateLimiter(rate=100.0, burst=50)

        limiter.acquire("client1")
        limiter.acquire("client2")

        stats = limiter.get_stats()

        assert stats["rate"] == 100.0
        assert stats["burst"] == 50
        assert stats["active_clients"] == 2

    def test_concurrent_access(self):
        """Test thread safety with concurrent requests."""
        limiter = RateLimiter(rate=100.0, burst=50)

        def make_request(client_id):
            return limiter.acquire(client_id)

        # Fire 100 concurrent requests from same client
        with ThreadPoolExecutor(max_workers=20) as executor:
            futures = [executor.submit(make_request, "client1") for _ in range(100)]
            results = [f.result() for f in as_completed(futures)]

        # Should accept burst amount (50) and reject most of the rest
        # Allow small margin for token refill during concurrent execution
        accepted = sum(1 for r in results if r is True)
        rejected = sum(1 for r in results if r is False)

        assert accepted >= 50  # At least burst size
        assert accepted <= 55  # Small margin for refill during execution
        assert rejected >= 45  # Most excess requests rejected

    def test_high_rate_limit(self):
        """Test rate limiter with high request rate."""
        limiter = RateLimiter(rate=10000.0, burst=1000)

        # Acquire all tokens in burst
        accepted = 0
        for _ in range(1100):  # Try more than burst
            if limiter.acquire("client1"):
                accepted += 1
            else:
                break  # Stop at first rejection

        # Should accept at least burst amount (might be more due to refill during loop)
        # At 10000 tokens/sec, the loop takes ~5ms, allowing ~50 extra tokens
        assert accepted >= 1000
        assert accepted <= 1100  # Allow realistic margin for refill during loop execution


class TestRateLimitInterceptor:
    """Tests for RateLimitInterceptor class."""

    def test_interceptor_allows_request(self):
        """Test that interceptor allows requests within limit."""
        limiter = RateLimiter(rate=10.0, burst=5)
        interceptor = RateLimitInterceptor(limiter)

        # Mock handler call details
        handler_call_details = MagicMock()
        handler_call_details.method = "/test.Service/TestMethod"
        handler_call_details.invocation_metadata = []

        # Mock continuation
        mock_handler = MagicMock()
        continuation = MagicMock(return_value=mock_handler)

        # Should allow request
        result = interceptor.intercept_service(continuation, handler_call_details)

        # Should call continuation
        continuation.assert_called_once_with(handler_call_details)
        assert result == mock_handler

    def test_interceptor_blocks_request(self):
        """Test that interceptor blocks requests over limit."""
        limiter = RateLimiter(rate=10.0, burst=2)
        interceptor = RateLimitInterceptor(limiter)

        # Mock handler call details
        handler_call_details = MagicMock()
        handler_call_details.method = "/test.Service/TestMethod"
        handler_call_details.invocation_metadata = []

        # Mock continuation
        continuation = MagicMock()

        # Exhaust rate limit
        interceptor.intercept_service(continuation, handler_call_details)
        interceptor.intercept_service(continuation, handler_call_details)

        # Third request should be blocked
        result = interceptor.intercept_service(continuation, handler_call_details)

        # Should return rate limit handler (not call continuation)
        assert result is not None
        # Continuation should only be called twice (for allowed requests)
        assert continuation.call_count == 2

    def test_interceptor_client_id_from_metadata(self):
        """Test that interceptor extracts client ID from metadata."""
        limiter = RateLimiter(rate=10.0, burst=5)
        interceptor = RateLimitInterceptor(limiter)

        # Mock handler with client-id in metadata
        handler_call_details = MagicMock()
        handler_call_details.method = "/test.Service/TestMethod"
        handler_call_details.invocation_metadata = [("client-id", "test-client")]

        continuation = MagicMock()

        # Make requests
        for _ in range(5):
            interceptor.intercept_service(continuation, handler_call_details)

        # Stats should show the client ID
        stats = limiter.get_stats()
        assert stats["active_clients"] == 1

    def test_interceptor_per_method_limiting(self):
        """Test that rate limiting is per-method by default."""
        limiter = RateLimiter(rate=10.0, burst=2)
        interceptor = RateLimitInterceptor(limiter)

        # Different methods should have separate rate limits
        handler1 = MagicMock()
        handler1.method = "/test.Service/Method1"
        handler1.invocation_metadata = []

        handler2 = MagicMock()
        handler2.method = "/test.Service/Method2"
        handler2.invocation_metadata = []

        continuation = MagicMock()

        # Exhaust Method1
        interceptor.intercept_service(continuation, handler1)
        interceptor.intercept_service(continuation, handler1)

        # Method2 should still work
        interceptor.intercept_service(continuation, handler2)
        continuation.assert_called()

        # Verify two different clients in stats
        stats = limiter.get_stats()
        assert stats["active_clients"] == 2


class TestRateLimiterIntegration:
    """Integration tests for rate limiting."""

    def test_rate_limiting_under_load(self):
        """Test rate limiter behavior under sustained load."""
        limiter = RateLimiter(rate=100.0, burst=50)

        def make_requests():
            results = []
            for _ in range(10):
                results.append(limiter.acquire("client1"))
                time.sleep(0.01)  # 100 req/sec
            return results

        # Run sustained load
        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(make_requests) for _ in range(5)]
            all_results = []
            for f in as_completed(futures):
                all_results.extend(f.result())

        # Most requests should succeed (rate matches limit)
        accepted = sum(1 for r in all_results if r is True)
        total = len(all_results)

        # Should accept majority of requests (>80%)
        acceptance_rate = accepted / total
        assert acceptance_rate > 0.8, f"Acceptance rate too low: {acceptance_rate}"
