"""Tests for size quota eviction policy."""

from datetime import datetime, timedelta

import pytest

from cascache_server.eviction.policy import BlobMetadata
from cascache_server.eviction.size_quota import SizeQuotaEvictionPolicy


def test_initialization():
    """Test size quota policy initialization."""
    policy = SizeQuotaEvictionPolicy(max_size_bytes=1000)

    assert policy.max_size_bytes == 1000
    assert policy.target_size_bytes == 800  # Default 80%


def test_initialization_with_custom_target():
    """Test size quota policy initialization with custom target."""
    policy = SizeQuotaEvictionPolicy(max_size_bytes=1000, target_size_bytes=600)

    assert policy.max_size_bytes == 1000
    assert policy.target_size_bytes == 600


def test_initialization_invalid_max_size():
    """Test initialization with invalid max_size_bytes."""
    with pytest.raises(ValueError, match="max_size_bytes must be positive"):
        SizeQuotaEvictionPolicy(max_size_bytes=0)

    with pytest.raises(ValueError, match="max_size_bytes must be positive"):
        SizeQuotaEvictionPolicy(max_size_bytes=-100)


def test_initialization_invalid_target_size():
    """Test initialization with invalid target_size_bytes."""
    with pytest.raises(ValueError, match="target_size_bytes must be positive"):
        SizeQuotaEvictionPolicy(max_size_bytes=1000, target_size_bytes=0)

    with pytest.raises(ValueError, match="target_size_bytes must be positive"):
        SizeQuotaEvictionPolicy(max_size_bytes=1000, target_size_bytes=-100)


def test_initialization_target_exceeds_max():
    """Test initialization with target_size_bytes exceeding max_size_bytes."""
    with pytest.raises(ValueError, match="target_size_bytes cannot exceed max_size_bytes"):
        SizeQuotaEvictionPolicy(max_size_bytes=1000, target_size_bytes=1500)


def test_should_evict_always_false():
    """Test should_evict always returns False (quota-based, not per-blob)."""
    policy = SizeQuotaEvictionPolicy(max_size_bytes=1000)

    # Create test blobs
    now = datetime.now()
    old_blob = BlobMetadata(
        digest="old",
        size=100,
        created_at=now - timedelta(days=10),
        accessed_at=now - timedelta(days=10),
    )
    new_blob = BlobMetadata(
        digest="new",
        size=100,
        created_at=now,
        accessed_at=now,
    )

    # should_evict is not used for size quota (protocol compliance only)
    assert policy.should_evict(old_blob) is False
    assert policy.should_evict(new_blob) is False


def test_get_eviction_candidates_empty():
    """Test get_eviction_candidates with empty list."""
    policy = SizeQuotaEvictionPolicy(max_size_bytes=1000)

    candidates = policy.get_eviction_candidates([])

    assert candidates == []


def test_get_eviction_candidates_under_quota():
    """Test get_eviction_candidates when storage is under quota."""
    policy = SizeQuotaEvictionPolicy(max_size_bytes=1000)

    # Create blobs totaling 500 bytes (under quota)
    now = datetime.now()
    metadata = [
        BlobMetadata(
            digest=f"blob{i}",
            size=100,
            created_at=now - timedelta(days=i),
            accessed_at=now,
        )
        for i in range(5)
    ]

    candidates = policy.get_eviction_candidates(metadata)

    assert candidates == []


def test_get_eviction_candidates_over_quota():
    """Test get_eviction_candidates when storage is over quota."""
    policy = SizeQuotaEvictionPolicy(max_size_bytes=1000, target_size_bytes=800)

    # Create blobs totaling 1200 bytes (over quota)
    now = datetime.now()
    metadata = [
        BlobMetadata(
            digest=f"blob{i}",
            size=100,
            created_at=now - timedelta(days=i),  # Oldest is blob11
            accessed_at=now,
        )
        for i in range(12)
    ]

    candidates = policy.get_eviction_candidates(metadata)

    # Should evict oldest blobs until under 800 bytes
    # Total: 1200, target: 800, need to free: 400 bytes (4 blobs)
    assert len(candidates) == 4
    # Should evict oldest first (highest day offset)
    assert "blob11" in candidates  # Oldest
    assert "blob10" in candidates
    assert "blob9" in candidates
    assert "blob8" in candidates


def test_get_eviction_candidates_oldest_first():
    """Test get_eviction_candidates evicts oldest blobs first."""
    policy = SizeQuotaEvictionPolicy(max_size_bytes=1000, target_size_bytes=500)

    # Create blobs with varying creation times (total > max_size to trigger eviction)
    now = datetime.now()
    metadata = [
        BlobMetadata(
            digest="oldest", size=300, created_at=now - timedelta(days=30), accessed_at=now
        ),
        BlobMetadata(digest="old", size=300, created_at=now - timedelta(days=20), accessed_at=now),
        BlobMetadata(
            digest="recent", size=200, created_at=now - timedelta(days=10), accessed_at=now
        ),
        BlobMetadata(digest="new", size=200, created_at=now - timedelta(days=5), accessed_at=now),
        BlobMetadata(digest="newest", size=200, created_at=now, accessed_at=now),
    ]

    candidates = policy.get_eviction_candidates(metadata)

    # Total: 1200, target: 500, need to free: 700 bytes (3-4 blobs)
    # Should evict oldest first
    assert "oldest" in candidates  # Oldest, 300 bytes
    assert "old" in candidates  # Second oldest, 300 bytes
    # After evicting oldest + old: 1200 - 300 - 300 = 600 (still over target)
    assert "recent" in candidates  # Third oldest, 200 bytes
    # After evicting recent: 600 - 200 = 400 (under target!)


def test_get_eviction_candidates_exact_target():
    """Test get_eviction_candidates stops at target size."""
    policy = SizeQuotaEvictionPolicy(max_size_bytes=1000, target_size_bytes=800)

    # Create blobs where evicting 2 oldest gets exactly to target
    now = datetime.now()
    metadata = [
        BlobMetadata(digest="blob1", size=100, created_at=now - timedelta(days=5), accessed_at=now),
        BlobMetadata(digest="blob2", size=100, created_at=now - timedelta(days=4), accessed_at=now),
        BlobMetadata(digest="blob3", size=100, created_at=now - timedelta(days=3), accessed_at=now),
        BlobMetadata(digest="blob4", size=900, created_at=now - timedelta(days=2), accessed_at=now),
    ]

    candidates = policy.get_eviction_candidates(metadata)

    # Total: 1200, target: 800, need to free: 400 bytes
    # Should evict blob1 (100) + blob2 (100) + blob3 (100) + blob4 (100 partial?)
    # Actually: 1200 - 800 = 400 to free, evict oldest until under 800
    # blob1 (100): 1200 - 100 = 1100 (still over)
    # blob2 (100): 1100 - 100 = 1000 (still over)
    # blob3 (100): 1000 - 100 = 900 (still over)
    # blob4 (900): 900 - 900 = 0 (under target!)
    assert len(candidates) == 4
    assert candidates == ["blob1", "blob2", "blob3", "blob4"]


def test_get_eviction_candidates_varying_sizes():
    """Test get_eviction_candidates with varying blob sizes."""
    policy = SizeQuotaEvictionPolicy(max_size_bytes=1000, target_size_bytes=500)

    # Create blobs with varying sizes
    now = datetime.now()
    metadata = [
        BlobMetadata(
            digest="large_old", size=400, created_at=now - timedelta(days=10), accessed_at=now
        ),
        BlobMetadata(
            digest="small_old", size=50, created_at=now - timedelta(days=9), accessed_at=now
        ),
        BlobMetadata(
            digest="medium_old", size=200, created_at=now - timedelta(days=8), accessed_at=now
        ),
        BlobMetadata(
            digest="large_new", size=400, created_at=now - timedelta(days=1), accessed_at=now
        ),
    ]

    candidates = policy.get_eviction_candidates(metadata)

    # Total: 1050, target: 500, need to free: 550+ bytes
    # Should evict oldest first regardless of size
    assert "large_old" in candidates  # Oldest, 400 bytes
    assert "small_old" in candidates  # Second oldest, 50 bytes
    # After evicting these: 1050 - 400 - 50 = 600 (still over target)
    assert "medium_old" in candidates  # Third oldest, 200 bytes
    # After: 600 - 200 = 400 (under target!)


def test_get_eviction_candidates_at_quota_boundary():
    """Test get_eviction_candidates when exactly at max quota."""
    policy = SizeQuotaEvictionPolicy(max_size_bytes=1000, target_size_bytes=800)

    # Create blobs totaling exactly 1000 bytes (at quota, not over)
    now = datetime.now()
    metadata = [
        BlobMetadata(
            digest=f"blob{i}",
            size=100,
            created_at=now - timedelta(days=i),
            accessed_at=now,
        )
        for i in range(10)
    ]

    candidates = policy.get_eviction_candidates(metadata)

    # At quota but not over, should not evict
    assert candidates == []


def test_record_eviction():
    """Test record_eviction updates statistics."""
    policy = SizeQuotaEvictionPolicy(max_size_bytes=1000)

    assert policy._evicted_count == 0
    assert policy._evicted_bytes == 0

    policy.record_eviction(100)
    assert policy._evicted_count == 1
    assert policy._evicted_bytes == 100

    policy.record_eviction(250)
    assert policy._evicted_count == 2
    assert policy._evicted_bytes == 350


def test_get_stats():
    """Test get_stats returns policy statistics."""
    policy = SizeQuotaEvictionPolicy(max_size_bytes=1000, target_size_bytes=600)

    policy.record_eviction(100)
    policy.record_eviction(200)

    stats = policy.get_stats()

    assert stats["policy"] == "size_quota"
    assert stats["max_size_bytes"] == 1000
    assert stats["target_size_bytes"] == 600
    assert stats["evicted_count"] == 2
    assert stats["evicted_bytes"] == 300
