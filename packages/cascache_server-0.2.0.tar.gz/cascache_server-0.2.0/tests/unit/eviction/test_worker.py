"""Unit tests for EvictionWorker."""

from datetime import datetime

import pytest

from cascache_server.eviction.policy import BlobMetadata, EvictionPolicy
from cascache_server.eviction.ttl import TTLEvictionPolicy
from cascache_server.eviction.worker import EvictionWorker
from cascache_server.storage.memory import MemoryStorage


@pytest.fixture
def storage():
    """Create a memory storage for testing."""
    storage = MemoryStorage()
    # Add some test blobs
    storage.put("blob1", b"data1")
    storage.put("blob2", b"data2")
    storage.put("blob3", b"data3")
    return storage


@pytest.fixture
def policy():
    """Create a TTL policy for testing."""
    return TTLEvictionPolicy(max_age_days=30)


def test_worker_initialization(storage, policy):
    """Test eviction worker creation."""
    worker = EvictionWorker(storage, policy, interval_seconds=60)

    assert worker.storage == storage
    assert worker.policy == policy
    assert worker.interval_seconds == 60
    assert worker._runs == 0
    assert worker._total_evicted == 0


def test_worker_start_stop(storage, policy):
    """Test starting and stopping eviction worker."""
    worker = EvictionWorker(storage, policy, interval_seconds=3600)

    # Start worker
    worker.start()
    assert worker._thread is not None
    assert worker._thread.is_alive()

    # Stop worker
    worker.stop(wait=True)
    assert not worker._thread.is_alive()


def test_worker_run_now(storage, policy):
    """Test immediate eviction run."""
    worker = EvictionWorker(storage, policy, interval_seconds=3600)

    # Initially 3 blobs
    assert len(storage.list_all()) == 3

    # Run eviction (but policy won't evict anything yet)
    worker.run_now()

    # Still 3 blobs (none are old enough)
    assert len(storage.list_all()) == 3

    # Check stats
    stats = worker.get_stats()
    assert stats["runs"] == 1
    assert stats["total_evicted"] == 0


def test_worker_evicts_old_blobs():
    """Test that worker actually evicts old blobs."""
    # Create storage with blobs
    storage = MemoryStorage()
    storage.put("old-blob", b"old data")
    storage.put("new-blob", b"new data")

    # Create policy that considers all blobs old
    # (by setting TTL to 1 day - blobs won't actually be evicted since
    # storage doesn't track real timestamps yet)
    policy = TTLEvictionPolicy(max_age_days=1)

    worker = EvictionWorker(storage, policy, interval_seconds=3600)

    # Verify blobs exist
    assert len(storage.list_all()) == 2

    # Note: Worker collects metadata which currently uses datetime.now()
    # So blobs won't actually be evicted yet. This is a limitation
    # of the current implementation that doesn't track real timestamps

    worker.run_now()

    # Check that run happened
    stats = worker.get_stats()
    assert stats["runs"] == 1


def test_worker_get_stats_initial(storage, policy):
    """Test getting stats from new worker."""
    worker = EvictionWorker(storage, policy)

    stats = worker.get_stats()
    assert stats["runs"] == 0
    assert stats["total_evicted"] == 0
    assert stats["total_freed_bytes"] == 0
    assert stats["last_run_duration_seconds"] is None
    assert stats["interval_seconds"] == 3600
    assert stats["is_running"] is False


def test_worker_handles_missing_blob(storage, policy):
    """Test worker handles blob deleted during eviction."""
    worker = EvictionWorker(storage, policy)

    # Run eviction (blobs exist)
    worker.run_now()

    # Delete a blob
    storage.delete("blob1")

    # Run again (should handle missing blob gracefully)
    worker.run_now()

    # Should still run successfully
    stats = worker.get_stats()
    assert stats["runs"] == 2


def test_worker_multiple_runs(storage, policy):
    """Test multiple eviction runs."""
    worker = EvictionWorker(storage, policy)

    worker.run_now()
    worker.run_now()
    worker.run_now()

    stats = worker.get_stats()
    assert stats["runs"] == 3


def test_worker_collects_metadata(storage, policy):
    """Test that worker collects metadata for all blobs."""
    worker = EvictionWorker(storage, policy)

    # Call internal method to get metadata
    metadata = worker._collect_metadata()

    assert len(metadata) == 3
    digests = {m.digest for m in metadata}
    assert digests == {"blob1", "blob2", "blob3"}

    # Check metadata structure
    for m in metadata:
        assert isinstance(m, BlobMetadata)
        assert m.size > 0
        assert isinstance(m.created_at, datetime)
        assert isinstance(m.accessed_at, datetime)


def test_worker_handles_empty_storage():
    """Test worker with empty storage."""
    storage = MemoryStorage()
    policy = TTLEvictionPolicy(max_age_days=30)
    worker = EvictionWorker(storage, policy)

    # Run on empty storage
    worker.run_now()

    stats = worker.get_stats()
    assert stats["runs"] == 1
    assert stats["total_evicted"] == 0


def test_worker_policy_integration():
    """Test worker uses policy correctly."""
    storage = MemoryStorage()
    storage.put("blob1", b"x" * 1000)
    storage.put("blob2", b"x" * 2000)
    storage.put("blob3", b"x" * 3000)

    # Custom policy that evicts blob1 and blob2
    class TestPolicy(EvictionPolicy):
        def should_evict(self, metadata: BlobMetadata) -> bool:
            return False  # Not used since we override get_eviction_candidates

        def get_eviction_candidates(self, all_metadata):
            return ["blob1", "blob2"]

        def record_eviction(self, size):
            pass

        def get_stats(self):
            return {}

    policy = TestPolicy()
    worker = EvictionWorker(storage, policy)

    assert len(storage.list_all()) == 3

    worker.run_now()

    # blob1 and blob2 should be evicted
    remaining = storage.list_all()
    assert len(remaining) == 1
    assert "blob3" in remaining

    stats = worker.get_stats()
    assert stats["total_evicted"] == 2
    assert stats["total_freed_bytes"] == 3000  # 1000 + 2000


def test_worker_concurrent_start():
    """Test that starting already running worker is handled."""
    storage = MemoryStorage()
    policy = TTLEvictionPolicy(max_age_days=30)
    worker = EvictionWorker(storage, policy)

    worker.start()

    # Try to start again (should warn but not crash)
    worker.start()

    worker.stop(wait=True)


def test_worker_stop_not_running():
    """Test stopping worker that isn't running."""
    storage = MemoryStorage()
    policy = TTLEvictionPolicy(max_age_days=30)
    worker = EvictionWorker(storage, policy)

    # Stop without starting (should warn but not crash)
    worker.stop(wait=True)
