"""Unit tests for TTL eviction policy."""

from datetime import datetime, timedelta

import pytest

from cascache_server.eviction.policy import BlobMetadata
from cascache_server.eviction.ttl import TTLEvictionPolicy


def test_ttl_policy_initialization():
    """Test TTL policy creation."""
    policy = TTLEvictionPolicy(max_age_days=30)
    assert policy.max_age_days == 30
    assert policy._evicted_count == 0
    assert policy._evicted_bytes == 0


def test_ttl_policy_invalid_age():
    """Test TTL policy with invalid age."""
    with pytest.raises(ValueError):
        TTLEvictionPolicy(max_age_days=0)

    with pytest.raises(ValueError):
        TTLEvictionPolicy(max_age_days=-1)


def test_should_evict_old_blob():
    """Test eviction of old blob."""
    policy = TTLEvictionPolicy(max_age_days=30)

    # Create blob metadata with old access time
    old_time = datetime.now() - timedelta(days=31)
    metadata = BlobMetadata(
        digest="old-blob",
        size=1000,
        created_at=old_time,
        accessed_at=old_time,
    )

    assert policy.should_evict(metadata)


def test_should_not_evict_recent_blob():
    """Test retention of recent blob."""
    policy = TTLEvictionPolicy(max_age_days=30)

    # Create blob metadata with recent access time
    recent_time = datetime.now() - timedelta(days=1)
    metadata = BlobMetadata(
        digest="recent-blob",
        size=1000,
        created_at=recent_time,
        accessed_at=recent_time,
    )

    assert not policy.should_evict(metadata)


def test_should_not_evict_boundary():
    """Test boundary condition at exact TTL."""
    policy = TTLEvictionPolicy(max_age_days=30)

    # Create blob at 29 days, 23 hours, 59 minutes (definitely under 30 days)
    # Use large buffer to avoid timing issues between datetime.now() calls
    boundary_time = datetime.now() - timedelta(days=29, hours=23, minutes=59)
    metadata = BlobMetadata(
        digest="boundary-blob",
        size=1000,
        created_at=boundary_time,
        accessed_at=boundary_time,
    )

    # Should not evict (blob is under 30 days old)
    assert not policy.should_evict(metadata)


def test_should_evict_over_boundary():
    """Test that blobs over TTL are evicted."""
    policy = TTLEvictionPolicy(max_age_days=30)

    # Create blob at 30 days + 1 hour (definitely over 30 days)
    old_time = datetime.now() - timedelta(days=30, hours=1)
    metadata = BlobMetadata(
        digest="old-blob",
        size=1000,
        created_at=old_time,
        accessed_at=old_time,
    )

    # Should evict (blob is over 30 days old)
    assert policy.should_evict(metadata)


def test_get_eviction_candidates_empty():
    """Test eviction with no blobs."""
    policy = TTLEvictionPolicy(max_age_days=30)

    candidates = policy.get_eviction_candidates([])
    assert candidates == []


def test_get_eviction_candidates_none_old():
    """Test eviction when no blobs are old enough."""
    policy = TTLEvictionPolicy(max_age_days=30)

    # All recent blobs
    all_metadata = [
        BlobMetadata(
            digest=f"blob-{i}",
            size=1000,
            created_at=datetime.now(),
            accessed_at=datetime.now(),
        )
        for i in range(5)
    ]

    candidates = policy.get_eviction_candidates(all_metadata)
    assert candidates == []


def test_get_eviction_candidates_all_old():
    """Test eviction when all blobs are old."""
    policy = TTLEvictionPolicy(max_age_days=30)

    # All old blobs
    old_time = datetime.now() - timedelta(days=60)
    all_metadata = [
        BlobMetadata(
            digest=f"blob-{i}",
            size=1000,
            created_at=old_time,
            accessed_at=old_time,
        )
        for i in range(5)
    ]

    candidates = policy.get_eviction_candidates(all_metadata)
    assert len(candidates) == 5
    assert set(candidates) == {f"blob-{i}" for i in range(5)}


def test_get_eviction_candidates_mixed():
    """Test eviction with mix of old and recent blobs."""
    policy = TTLEvictionPolicy(max_age_days=30)

    old_time = datetime.now() - timedelta(days=60)
    recent_time = datetime.now() - timedelta(days=1)

    all_metadata = [
        # Old blobs
        BlobMetadata(digest="old-1", size=1000, created_at=old_time, accessed_at=old_time),
        BlobMetadata(digest="old-2", size=2000, created_at=old_time, accessed_at=old_time),
        # Recent blobs
        BlobMetadata(digest="new-1", size=1000, created_at=recent_time, accessed_at=recent_time),
        BlobMetadata(digest="new-2", size=2000, created_at=recent_time, accessed_at=recent_time),
    ]

    candidates = policy.get_eviction_candidates(all_metadata)
    assert len(candidates) == 2
    assert set(candidates) == {"old-1", "old-2"}


def test_record_eviction():
    """Test recording evictions."""
    policy = TTLEvictionPolicy(max_age_days=30)

    policy.record_eviction(1000)
    policy.record_eviction(2000)
    policy.record_eviction(500)

    assert policy._evicted_count == 3
    assert policy._evicted_bytes == 3500


def test_get_stats():
    """Test getting policy statistics."""
    policy = TTLEvictionPolicy(max_age_days=30)

    policy.record_eviction(1000)
    policy.record_eviction(2000)

    stats = policy.get_stats()
    assert stats["policy"] == "ttl"
    assert stats["max_age_days"] == 30
    assert stats["evicted_count"] == 2
    assert stats["evicted_bytes"] == 3000


def test_multiple_ttl_values():
    """Test policies with different TTL values."""
    policy_short = TTLEvictionPolicy(max_age_days=7)
    policy_medium = TTLEvictionPolicy(max_age_days=30)
    policy_long = TTLEvictionPolicy(max_age_days=180)

    # Blob that's 15 days old
    blob_time = datetime.now() - timedelta(days=15)
    metadata = BlobMetadata(
        digest="test-blob",
        size=1000,
        created_at=blob_time,
        accessed_at=blob_time,
    )

    # Should be evicted by short TTL
    assert policy_short.should_evict(metadata)

    # Should not be evicted by medium/long TTL
    assert not policy_medium.should_evict(metadata)
    assert not policy_long.should_evict(metadata)
