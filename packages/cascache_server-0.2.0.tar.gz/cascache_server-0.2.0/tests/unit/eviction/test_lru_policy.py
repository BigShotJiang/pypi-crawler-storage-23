"""Unit tests for LRU eviction policy."""

from datetime import datetime, timedelta

import pytest

from cascache_server.eviction.lru import LRUEvictionPolicy
from cascache_server.eviction.policy import BlobMetadata


def test_lru_policy_initialization():
    """Test LRU policy creation with valid parameters."""
    policy = LRUEvictionPolicy(max_size_bytes=1000000)

    assert policy.max_size_bytes == 1000000
    assert policy.target_size_bytes == 800000  # Default: 80% of max


def test_lru_policy_custom_target():
    """Test LRU policy with custom target size."""
    policy = LRUEvictionPolicy(max_size_bytes=1000000, target_size_bytes=600000)

    assert policy.max_size_bytes == 1000000
    assert policy.target_size_bytes == 600000


def test_lru_policy_invalid_max_size():
    """Test that zero or negative max_size_bytes raises ValueError."""
    with pytest.raises(ValueError, match="max_size_bytes must be positive"):
        LRUEvictionPolicy(max_size_bytes=0)

    with pytest.raises(ValueError, match="max_size_bytes must be positive"):
        LRUEvictionPolicy(max_size_bytes=-1000)


def test_lru_policy_invalid_target_size():
    """Test that invalid target_size_bytes raises ValueError."""
    with pytest.raises(ValueError, match="target_size_bytes must be positive"):
        LRUEvictionPolicy(max_size_bytes=1000000, target_size_bytes=0)

    with pytest.raises(ValueError, match="target_size_bytes must be positive"):
        LRUEvictionPolicy(max_size_bytes=1000000, target_size_bytes=-1000)


def test_lru_policy_target_exceeds_max():
    """Test that target_size_bytes > max_size_bytes raises ValueError."""
    with pytest.raises(ValueError, match="target_size_bytes cannot exceed max_size_bytes"):
        LRUEvictionPolicy(max_size_bytes=1000000, target_size_bytes=1500000)


def test_should_evict_always_false():
    """Test that should_evict always returns False for LRU (quota-based, not per-blob)."""
    policy = LRUEvictionPolicy(max_size_bytes=1000000)

    metadata = BlobMetadata(
        digest="test-blob",
        size=1000,
        created_at=datetime.now(),
        accessed_at=datetime.now(),
    )

    # LRU doesn't evict individual blobs, only based on total quota
    assert not policy.should_evict(metadata)


def test_no_eviction_under_quota():
    """Test that no blobs are evicted when under quota."""
    policy = LRUEvictionPolicy(max_size_bytes=10000)

    # Total: 9000 bytes (under 10000)
    metadata = [
        BlobMetadata("blob1", 3000, datetime.now(), datetime.now()),
        BlobMetadata("blob2", 3000, datetime.now(), datetime.now()),
        BlobMetadata("blob3", 3000, datetime.now(), datetime.now()),
    ]

    candidates = policy.get_eviction_candidates(metadata)
    assert len(candidates) == 0


def test_eviction_over_quota():
    """Test that blobs are evicted when over quota."""
    policy = LRUEvictionPolicy(max_size_bytes=10000, target_size_bytes=8000)

    # Total: 12000 bytes (over 10000)
    now = datetime.now()
    metadata = [
        BlobMetadata("blob1", 4000, now, now - timedelta(days=3)),  # Oldest
        BlobMetadata("blob2", 4000, now, now - timedelta(days=2)),
        BlobMetadata("blob3", 4000, now, now - timedelta(days=1)),  # Newest
    ]

    candidates = policy.get_eviction_candidates(metadata)

    # Should evict blob1 (4000 bytes) to get under 8000 target
    # Before: 12000, After: 8000
    assert len(candidates) == 1
    assert candidates[0] == "blob1"


def test_lru_ordering_oldest_first():
    """Test that LRU evicts least recently accessed blobs first."""
    policy = LRUEvictionPolicy(max_size_bytes=10000, target_size_bytes=5000)

    # Total: 15000 bytes (over 10000)
    now = datetime.now()
    metadata = [
        BlobMetadata("new-blob", 3000, now, now),  # Most recent
        BlobMetadata("mid-blob", 3000, now, now - timedelta(hours=12)),
        BlobMetadata("old-blob", 3000, now, now - timedelta(days=1)),
        BlobMetadata("oldest-blob", 3000, now, now - timedelta(days=2)),
        BlobMetadata("ancient-blob", 3000, now, now - timedelta(days=3)),  # Least recent
    ]

    candidates = policy.get_eviction_candidates(metadata)

    # Should evict oldest blobs first until under 5000 target
    # Before: 15000, need to remove: 10000 bytes
    # Evict: ancient (3000), oldest (3000), old (3000), mid (3000) = 12000
    # After: 3000 (under target)
    assert len(candidates) == 4
    assert candidates == ["ancient-blob", "oldest-blob", "old-blob", "mid-blob"]


def test_evict_down_to_target():
    """Test that eviction stops when reaching target size."""
    policy = LRUEvictionPolicy(max_size_bytes=10000, target_size_bytes=7000)

    # Total: 12000 bytes (over 10000)
    now = datetime.now()
    metadata = [
        BlobMetadata("blob1", 2000, now, now - timedelta(days=5)),  # Oldest
        BlobMetadata("blob2", 2000, now, now - timedelta(days=4)),
        BlobMetadata("blob3", 2000, now, now - timedelta(days=3)),
        BlobMetadata("blob4", 2000, now, now - timedelta(days=2)),
        BlobMetadata("blob5", 2000, now, now - timedelta(days=1)),
        BlobMetadata("blob6", 2000, now, now),  # Newest
    ]

    candidates = policy.get_eviction_candidates(metadata)

    # Before: 12000, Target: 7000, Need to remove: 5000
    # Evict: blob1 (2000), blob2 (2000), blob3 (2000) = 6000
    # After: 6000 (under target, stop here)
    assert len(candidates) == 3
    assert candidates == ["blob1", "blob2", "blob3"]


def test_eviction_empty_storage():
    """Test eviction with empty storage."""
    policy = LRUEvictionPolicy(max_size_bytes=10000)

    candidates = policy.get_eviction_candidates([])
    assert len(candidates) == 0


def test_eviction_exact_quota():
    """Test when storage is exactly at quota (no eviction)."""
    policy = LRUEvictionPolicy(max_size_bytes=10000)

    # Total: exactly 10000 bytes
    metadata = [
        BlobMetadata("blob1", 5000, datetime.now(), datetime.now()),
        BlobMetadata("blob2", 5000, datetime.now(), datetime.now()),
    ]

    candidates = policy.get_eviction_candidates(metadata)
    assert len(candidates) == 0  # Exactly at quota, no eviction


def test_eviction_just_over_quota():
    """Test when storage is just barely over quota."""
    policy = LRUEvictionPolicy(max_size_bytes=10000, target_size_bytes=8000)

    # Total: 10001 bytes (1 byte over)
    now = datetime.now()
    metadata = [
        BlobMetadata("blob1", 5000, now, now - timedelta(days=1)),  # Older
        BlobMetadata("blob2", 5001, now, now),  # Newer
    ]

    candidates = policy.get_eviction_candidates(metadata)

    # Should evict blob1 to get under target
    assert len(candidates) == 1
    assert candidates[0] == "blob1"


def test_record_eviction():
    """Test recording eviction statistics."""
    policy = LRUEvictionPolicy(max_size_bytes=10000)

    policy.record_eviction(1000)
    policy.record_eviction(2000)
    policy.record_eviction(3000)

    stats = policy.get_stats()
    assert stats["evicted_count"] == 3
    assert stats["evicted_bytes"] == 6000


def test_get_stats():
    """Test getting policy statistics."""
    policy = LRUEvictionPolicy(max_size_bytes=100000, target_size_bytes=80000)

    stats = policy.get_stats()
    assert stats["policy"] == "lru"
    assert stats["max_size_bytes"] == 100000
    assert stats["target_size_bytes"] == 80000
    assert stats["evicted_count"] == 0
    assert stats["evicted_bytes"] == 0


def test_multiple_size_scenarios():
    """Test various storage size scenarios."""
    policy = LRUEvictionPolicy(max_size_bytes=1000, target_size_bytes=800)

    # Scenario 1: Way over quota
    now = datetime.now()
    metadata_over = [BlobMetadata(f"blob{i}", 500, now, now - timedelta(days=i)) for i in range(5)]
    # Total: 2500 bytes, need to remove 1700 to get under 800
    candidates = policy.get_eviction_candidates(metadata_over)
    assert len(candidates) == 4  # Remove 2000 bytes (4 blobs * 500)

    # Scenario 2: Slightly over quota
    metadata_slight = [
        BlobMetadata("a", 600, now, now - timedelta(days=1)),
        BlobMetadata("b", 500, now, now),
    ]
    # Total: 1100, need to remove 300 to get under 800
    candidates = policy.get_eviction_candidates(metadata_slight)
    assert len(candidates) == 1  # Remove oldest (600 bytes)

    # Scenario 3: Under quota
    metadata_under = [BlobMetadata("x", 500, now, now)]
    candidates = policy.get_eviction_candidates(metadata_under)
    assert len(candidates) == 0


def test_large_number_of_blobs():
    """Test LRU with many blobs."""
    policy = LRUEvictionPolicy(max_size_bytes=10000, target_size_bytes=5000)

    # Create 100 blobs, 200 bytes each = 20000 total (way over quota)
    now = datetime.now()
    metadata = [
        BlobMetadata(f"blob{i:03d}", 200, now, now - timedelta(hours=i)) for i in range(100)
    ]

    candidates = policy.get_eviction_candidates(metadata)

    # Before: 20000, Target: 5000, Need to remove: 15000
    # Evict 75 oldest blobs (15000 / 200 = 75)
    assert len(candidates) == 75

    # Verify oldest blobs are selected
    for i in range(75):
        assert f"blob{99 - i:03d}" in candidates  # blob099, blob098, etc.
