"""Tests for eviction policies."""
