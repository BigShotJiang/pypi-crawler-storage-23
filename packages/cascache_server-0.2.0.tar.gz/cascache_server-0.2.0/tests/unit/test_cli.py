"""Tests for CLI token management commands."""

import tempfile
from pathlib import Path

import pytest
from typer.testing import CliRunner

from cascache_server.cli import app

runner = CliRunner()


class TestCLITokenManagement:
    """Test CLI token management commands."""

    @pytest.fixture
    def tokens_file(self):
        """Create a temporary tokens file."""
        with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".json") as f:
            yield Path(f.name)
            # Cleanup
            Path(f.name).unlink(missing_ok=True)

    def test_create_token(self, tokens_file):
        """Test creating a token via CLI."""
        result = runner.invoke(
            app,
            [
                "admin",
                "create-token",
                "--name",
                "test-token",
                "--expires-days",
                "7",
                "--tokens-file",
                str(tokens_file),
            ],
        )

        assert result.exit_code == 0
        assert "Token created successfully" in result.stdout
        assert "cas-token-" in result.stdout
        assert "test-token" in result.stdout
        assert "7 days" in result.stdout

    def test_list_tokens_empty(self, tokens_file):
        """Test listing tokens when file is empty."""
        result = runner.invoke(app, ["admin", "list-tokens", "--tokens-file", str(tokens_file)])

        assert result.exit_code == 0  # Empty file is valid (no tokens yet)
        assert "No tokens found" in result.stdout

    def test_create_and_list_tokens(self, tokens_file):
        """Test creating and then listing tokens."""
        # Create first token
        result1 = runner.invoke(
            app,
            [
                "admin",
                "create-token",
                "--name",
                "token-1",
                "--tokens-file",
                str(tokens_file),
            ],
        )
        assert result1.exit_code == 0

        # Create second token
        result2 = runner.invoke(
            app,
            [
                "admin",
                "create-token",
                "--name",
                "token-2",
                "--expires-days",
                "60",
                "--tokens-file",
                str(tokens_file),
            ],
        )
        assert result2.exit_code == 0

        # List tokens
        result3 = runner.invoke(app, ["admin", "list-tokens", "--tokens-file", str(tokens_file)])
        assert result3.exit_code == 0

        assert "2 total" in result3.stdout
        assert "token-1" in result3.stdout
        assert "token-2" in result3.stdout
        assert "Valid" in result3.stdout

    def test_create_and_revoke_token(self, tokens_file):
        """Test creating and revoking a token."""
        # Create token
        result1 = runner.invoke(
            app,
            [
                "admin",
                "create-token",
                "--name",
                "to-revoke",
                "--tokens-file",
                str(tokens_file),
            ],
        )
        assert result1.exit_code == 0

        # Extract token from output
        lines = result1.stdout.split("\n")
        token_line = [line for line in lines if "cas-token-" in line][0]
        token = token_line.split("Token: ")[1].strip()

        # Revoke token
        result2 = runner.invoke(
            app, ["admin", "revoke-token", token, "--tokens-file", str(tokens_file)]
        )
        assert result2.exit_code == 0
        assert "revoked successfully" in result2.stdout.lower()

        # List tokens to verify revoked
        result3 = runner.invoke(app, ["admin", "list-tokens", "--tokens-file", str(tokens_file)])
        assert result3.exit_code == 0
        assert "Revoked" in result3.stdout

    def test_revoke_nonexistent_token(self, tokens_file):
        """Test revoking a token that doesn't exist."""
        # Create tokens file first
        runner.invoke(
            app,
            [
                "admin",
                "create-token",
                "--name",
                "dummy",
                "--tokens-file",
                str(tokens_file),
            ],
        )

        # Try to revoke non-existent token
        result = runner.invoke(
            app,
            ["admin", "revoke-token", "cas-token-nonexistent", "--tokens-file", str(tokens_file)],
        )

        assert result.exit_code == 1
        assert "not found" in result.stdout.lower()

    def test_admin_no_subcommand(self):
        """Test admin command without subcommand shows help."""
        result = runner.invoke(app, ["admin"])

        # Typer exits with code 2 when a required subcommand is missing
        assert result.exit_code == 2
        assert "create-token" in result.stdout
        assert "list-tokens" in result.stdout
        assert "revoke-token" in result.stdout

    def test_no_command_shows_help(self):
        """Test running cascache_server with no command shows help."""
        result = runner.invoke(app, [])

        # Typer exits with code 2 when a required command is missing
        assert result.exit_code == 2
        assert "serve" in result.stdout
        assert "admin" in result.stdout
