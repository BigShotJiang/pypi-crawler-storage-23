"""Unit tests for filesystem storage backend."""

import pytest

from cascache_server.storage.filesystem import FilesystemStorage


def test_put_and_get(temp_storage):
    """Test storing and retrieving a blob."""
    digest = "abc123"
    data = b"test data"

    temp_storage.put(digest, data)
    retrieved = temp_storage.get(digest)

    assert retrieved == data


def test_exists_returns_true_for_existing_blob(temp_storage):
    """Test exists() returns True for stored blob."""
    digest = "abc123"
    temp_storage.put(digest, b"data")

    assert temp_storage.exists(digest) is True


def test_exists_returns_false_for_missing_blob(temp_storage):
    """Test exists() returns False for missing blob."""
    assert temp_storage.exists("nonexistent") is False


def test_get_missing_blob_raises_file_not_found(temp_storage):
    """Test get() raises FileNotFoundError for missing blob."""
    with pytest.raises(FileNotFoundError, match="Blob nonexistent not found"):
        temp_storage.get("nonexistent")


def test_delete_removes_blob(temp_storage):
    """Test delete() removes blob from storage."""
    digest = "abc123"
    temp_storage.put(digest, b"data")

    temp_storage.delete(digest)

    assert temp_storage.exists(digest) is False


def test_delete_missing_blob_raises_file_not_found(temp_storage):
    """Test delete() raises FileNotFoundError for missing blob."""
    with pytest.raises(FileNotFoundError, match="Blob nonexistent not found"):
        temp_storage.delete("nonexistent")


def test_list_all_returns_all_digests(temp_storage):
    """Test list_all() returns all stored digests."""
    digests = ["abc123", "def456", "ghi789"]
    for digest in digests:
        temp_storage.put(digest, b"data")

    result = temp_storage.list_all()

    assert set(result) == set(digests)


def test_list_all_returns_empty_for_empty_storage(temp_storage):
    """Test list_all() returns empty list when no blobs stored."""
    result = temp_storage.list_all()

    assert result == []


def test_get_size_returns_blob_size(temp_storage):
    """Test get_size() returns correct blob size."""
    digest = "abc123"
    data = b"test data with known size"
    temp_storage.put(digest, data)

    size = temp_storage.get_size(digest)

    assert size == len(data)


def test_get_size_missing_blob_raises_file_not_found(temp_storage):
    """Test get_size() raises FileNotFoundError for missing blob."""
    with pytest.raises(FileNotFoundError, match="Blob nonexistent not found"):
        temp_storage.get_size("nonexistent")


def test_put_overwrites_existing_blob(temp_storage):
    """Test put() overwrites existing blob (idempotent)."""
    digest = "abc123"
    temp_storage.put(digest, b"original data")
    temp_storage.put(digest, b"new data")

    retrieved = temp_storage.get(digest)

    assert retrieved == b"new data"


def test_storage_creates_directory_if_not_exists(tmp_path):
    """Test storage creates directory if it doesn't exist."""
    storage_path = tmp_path / "subdir" / "cas"
    FilesystemStorage(str(storage_path))

    assert storage_path.exists()
    assert storage_path.is_dir()
