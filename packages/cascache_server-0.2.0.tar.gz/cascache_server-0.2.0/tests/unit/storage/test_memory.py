"""Unit tests for memory storage backend."""

import pytest

from cascache_server.storage.memory import MemoryStorage


def test_put_and_get():
    """Test storing and retrieving a blob."""
    storage = MemoryStorage()
    digest = "abc123"
    data = b"test data"

    storage.put(digest, data)
    retrieved = storage.get(digest)

    assert retrieved == data


def test_exists_returns_true_for_existing_blob():
    """Test exists() returns True for stored blob."""
    storage = MemoryStorage()
    digest = "abc123"
    storage.put(digest, b"data")

    assert storage.exists(digest) is True


def test_exists_returns_false_for_missing_blob():
    """Test exists() returns False for missing blob."""
    storage = MemoryStorage()

    assert storage.exists("nonexistent") is False


def test_get_missing_blob_raises_file_not_found():
    """Test get() raises FileNotFoundError for missing blob."""
    storage = MemoryStorage()

    with pytest.raises(FileNotFoundError, match="Blob nonexistent not found"):
        storage.get("nonexistent")


def test_delete_removes_blob():
    """Test delete() removes blob from storage."""
    storage = MemoryStorage()
    digest = "abc123"
    storage.put(digest, b"data")

    storage.delete(digest)

    assert storage.exists(digest) is False


def test_delete_missing_blob_raises_file_not_found():
    """Test delete() raises FileNotFoundError for missing blob."""
    storage = MemoryStorage()

    with pytest.raises(FileNotFoundError, match="Blob nonexistent not found"):
        storage.delete("nonexistent")


def test_list_all_returns_all_digests():
    """Test list_all() returns all stored digests."""
    storage = MemoryStorage()
    digests = ["abc123", "def456", "ghi789"]
    for digest in digests:
        storage.put(digest, b"data")

    result = storage.list_all()

    assert set(result) == set(digests)


def test_list_all_returns_empty_for_empty_storage():
    """Test list_all() returns empty list when no blobs stored."""
    storage = MemoryStorage()

    result = storage.list_all()

    assert result == []


def test_get_size_returns_blob_size():
    """Test get_size() returns correct blob size."""
    storage = MemoryStorage()
    digest = "abc123"
    data = b"test data with known size"
    storage.put(digest, data)

    size = storage.get_size(digest)

    assert size == len(data)


def test_get_size_missing_blob_raises_file_not_found():
    """Test get_size() raises FileNotFoundError for missing blob."""
    storage = MemoryStorage()

    with pytest.raises(FileNotFoundError, match="Blob nonexistent not found"):
        storage.get_size("nonexistent")


def test_put_overwrites_existing_blob():
    """Test put() overwrites existing blob (idempotent)."""
    storage = MemoryStorage()
    digest = "abc123"
    storage.put(digest, b"original data")
    storage.put(digest, b"new data")

    retrieved = storage.get(digest)

    assert retrieved == b"new data"


def test_multiple_storage_instances_independent():
    """Test that multiple MemoryStorage instances don't share data."""
    storage1 = MemoryStorage()
    storage2 = MemoryStorage()

    storage1.put("abc123", b"data1")
    storage2.put("def456", b"data2")

    assert storage1.exists("abc123") is True
    assert storage1.exists("def456") is False
    assert storage2.exists("abc123") is False
    assert storage2.exists("def456") is True
