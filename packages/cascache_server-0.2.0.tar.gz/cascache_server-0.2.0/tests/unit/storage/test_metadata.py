"""Tests for storage backend metadata tracking."""

import time
from datetime import datetime

from cascache_server.storage.filesystem import FilesystemStorage
from cascache_server.storage.memory import MemoryStorage


def test_filesystem_metadata_created_on_put(tmp_path):
    """Test that metadata is created when blob is stored."""
    storage = FilesystemStorage(str(tmp_path))

    digest = "abc123"
    data = b"test data"

    # Store blob
    storage.put(digest, data)

    # Get metadata
    metadata = storage.get_metadata(digest)

    assert metadata is not None
    assert metadata.digest == digest
    assert metadata.size == len(data)
    assert metadata.created_at is not None
    assert metadata.accessed_at is not None
    # Should be recent
    assert (datetime.now() - metadata.created_at).total_seconds() < 2


def test_filesystem_metadata_updated_on_get(tmp_path):
    """Test that accessed_at is updated when blob is retrieved."""
    storage = FilesystemStorage(str(tmp_path))

    digest = "abc123"
    data = b"test data"

    # Store blob
    storage.put(digest, data)

    # Get initial metadata
    metadata1 = storage.get_metadata(digest)
    assert metadata1 is not None

    # Wait a bit
    time.sleep(0.1)

    # Access blob
    storage.get(digest)

    # Get updated metadata
    metadata2 = storage.get_metadata(digest)

    assert metadata2 is not None
    # accessed_at should be newer
    assert metadata2.accessed_at > metadata1.accessed_at
    # created_at should be unchanged
    assert metadata2.created_at == metadata1.created_at


def test_filesystem_metadata_deleted_with_blob(tmp_path):
    """Test that metadata is deleted when blob is deleted."""
    storage = FilesystemStorage(str(tmp_path))

    digest = "abc123"
    data = b"test data"

    # Store blob
    storage.put(digest, data)

    # Verify metadata exists
    assert storage.get_metadata(digest) is not None

    # Delete blob
    storage.delete(digest)

    # Metadata should be gone
    assert storage.get_metadata(digest) is None


def test_filesystem_metadata_for_nonexistent_blob(tmp_path):
    """Test that get_metadata returns None for nonexistent blob."""
    storage = FilesystemStorage(str(tmp_path))

    metadata = storage.get_metadata("nonexistent")

    assert metadata is None


def test_memory_metadata_created_on_put():
    """Test that metadata is created when blob is stored in memory."""
    storage = MemoryStorage()

    digest = "abc123"
    data = b"test data"

    # Store blob
    storage.put(digest, data)

    # Get metadata
    metadata = storage.get_metadata(digest)

    assert metadata is not None
    assert metadata.digest == digest
    assert metadata.size == len(data)
    assert metadata.created_at is not None
    assert metadata.accessed_at is not None


def test_memory_metadata_updated_on_get():
    """Test that accessed_at is updated when blob is retrieved from memory."""
    storage = MemoryStorage()

    digest = "abc123"
    data = b"test data"

    # Store blob
    storage.put(digest, data)

    # Get initial metadata
    metadata1 = storage.get_metadata(digest)
    assert metadata1 is not None

    # Wait a bit
    time.sleep(0.1)

    # Access blob
    storage.get(digest)

    # Get updated metadata
    metadata2 = storage.get_metadata(digest)

    assert metadata2 is not None
    # accessed_at should be newer
    assert metadata2.accessed_at > metadata1.accessed_at


def test_memory_metadata_deleted_with_blob():
    """Test that metadata is deleted when blob is deleted from memory."""
    storage = MemoryStorage()

    digest = "abc123"
    data = b"test data"

    # Store blob
    storage.put(digest, data)

    # Verify metadata exists
    assert storage.get_metadata(digest) is not None

    # Delete blob
    storage.delete(digest)

    # Metadata should be gone
    assert storage.get_metadata(digest) is None


def test_memory_metadata_for_nonexistent_blob():
    """Test that get_metadata returns None for nonexistent blob in memory."""
    storage = MemoryStorage()

    metadata = storage.get_metadata("nonexistent")

    assert metadata is None


def test_filesystem_metadata_survives_blob_overwrite(tmp_path):
    """Test that metadata is updated when blob is overwritten."""
    storage = FilesystemStorage(str(tmp_path))

    digest = "abc123"
    data1 = b"original"
    data2 = b"overwritten data"

    # Store initial blob
    storage.put(digest, data1)
    metadata1 = storage.get_metadata(digest)
    assert metadata1 is not None

    # Wait a bit
    time.sleep(0.1)

    # Overwrite blob
    storage.put(digest, data2)
    metadata2 = storage.get_metadata(digest)

    assert metadata2 is not None
    assert metadata2.size == len(data2)
    # created_at should be updated (new file)
    assert metadata2.created_at >= metadata1.created_at


def test_memory_metadata_survives_blob_overwrite():
    """Test that metadata is updated when blob is overwritten in memory."""
    storage = MemoryStorage()

    digest = "abc123"
    data1 = b"original"
    data2 = b"overwritten data"

    # Store initial blob
    storage.put(digest, data1)
    metadata1 = storage.get_metadata(digest)
    assert metadata1 is not None

    # Wait a bit
    time.sleep(0.1)

    # Overwrite blob
    storage.put(digest, data2)
    metadata2 = storage.get_metadata(digest)

    assert metadata2 is not None
    assert metadata2.size == len(data2)
    # accessed_at should be updated
    assert metadata2.accessed_at >= metadata1.accessed_at
