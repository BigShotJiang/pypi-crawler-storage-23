"""Concurrency stress tests for storage backends."""

from concurrent.futures import ThreadPoolExecutor, as_completed

import pytest

from cascache_server.monitoring.metrics import CacheMetrics
from cascache_server.storage.filesystem import FilesystemStorage


class TestConcurrentWrites:
    """Test concurrent write operations."""

    @pytest.fixture
    def storage(self, tmp_path):
        """Create a filesystem storage for testing."""
        return FilesystemStorage(str(tmp_path))

    def test_concurrent_writes_same_blob(self, storage):
        """
        Test that concurrent writes to the same blob don't corrupt data.

        With atomic file writes (temp + rename), the last write should
        win cleanly without corruption.
        """
        digest = "test-digest-concurrent"
        data = b"Hello, concurrent world!" * 100  # Make it a bit bigger

        def write_blob():
            """Write the same blob."""
            storage.put(digest, data)
            return True

        # Execute 50 concurrent writes to the same blob
        with ThreadPoolExecutor(max_workers=50) as executor:
            futures = [executor.submit(write_blob) for _ in range(50)]
            results = [f.result() for f in as_completed(futures)]

        # All writes should succeed
        assert all(results)
        assert len(results) == 50

        # Verify the blob exists and data is not corrupted
        assert storage.exists(digest)
        retrieved_data = storage.get(digest)
        assert retrieved_data == data
        assert len(retrieved_data) == len(data)

    def test_concurrent_writes_different_blobs(self, storage):
        """Test concurrent writes to different blobs."""
        num_blobs = 100

        def write_blob(i):
            """Write a unique blob."""
            digest = f"blob-{i:04d}"
            data = f"Data for blob {i}".encode() * 10
            storage.put(digest, data)
            return digest, data

        # Write 100 different blobs concurrently
        with ThreadPoolExecutor(max_workers=20) as executor:
            futures = [executor.submit(write_blob, i) for i in range(num_blobs)]
            results = [f.result() for f in as_completed(futures)]

        # Verify all blobs were written correctly
        assert len(results) == num_blobs
        for digest, expected_data in results:
            assert storage.exists(digest)
            assert storage.get(digest) == expected_data

    def _read_blob_safe(self, storage, digest):
        """Helper: Read a blob safely."""
        try:
            return storage.get(digest)
        except FileNotFoundError:
            return None

    def _write_blob_safe(self, storage, digest, data):
        """Helper: Write a blob safely."""
        storage.put(digest, data)
        return True

    def _delete_blob_safe(self, storage, digest):
        """Helper: Delete a blob safely."""
        try:
            storage.delete(digest)
            return True
        except FileNotFoundError:
            return False

    def test_concurrent_mixed_operations(self, storage):
        """Test concurrent reads, writes, and deletes."""
        # Prepopulate with some blobs
        initial_blobs = {}
        for i in range(20):
            digest = f"initial-blob-{i:04d}"
            data = f"Initial data {i}".encode() * 5
            storage.put(digest, data)
            initial_blobs[digest] = data

        operations = []

        # Mix of operations
        with ThreadPoolExecutor(max_workers=30) as executor:
            # Concurrent reads
            for digest in list(initial_blobs.keys())[:10]:
                operations.append(executor.submit(self._read_blob_safe, storage, digest))

            # Concurrent writes (new blobs)
            for i in range(20, 40):
                digest = f"new-blob-{i:04d}"
                data = f"New data {i}".encode() * 5
                operations.append(executor.submit(self._write_blob_safe, storage, digest, data))

            # Concurrent deletes
            for digest in list(initial_blobs.keys())[10:15]:
                operations.append(executor.submit(self._delete_blob_safe, storage, digest))

            # Concurrent mixed reads
            for digest in list(initial_blobs.keys())[15:20]:
                operations.append(executor.submit(self._read_blob_safe, storage, digest))

            # Wait for all operations
            for future in as_completed(operations):
                future.result()  # May raise exception if operation failed

        # Verify storage is in consistent state (no crashes)
        all_blobs = storage.list_all()
        assert len(all_blobs) > 0  # Should have some blobs


class TestConcurrentMetrics:
    """Test thread-safe metrics under concurrent load."""

    def test_concurrent_metric_updates(self):
        """Test that concurrent metric updates are accurate."""
        metrics = CacheMetrics()
        num_operations = 1000

        def record_hit():
            """Record a cache hit."""
            metrics.record_hit()

        def record_miss():
            """Record a cache miss."""
            metrics.record_miss()

        # Execute concurrent metric updates
        with ThreadPoolExecutor(max_workers=50) as executor:
            # Half hits, half misses
            hit_futures = [executor.submit(record_hit) for _ in range(num_operations // 2)]
            miss_futures = [executor.submit(record_miss) for _ in range(num_operations // 2)]

            all_futures = hit_futures + miss_futures
            for future in as_completed(all_futures):
                future.result()

        # Verify counts are accurate (no lost updates)
        assert metrics.hits == num_operations // 2
        assert metrics.misses == num_operations // 2
        assert metrics.hit_rate() == 0.5

    def test_concurrent_blob_tracking(self):
        """Test concurrent blob add/remove tracking."""
        metrics = CacheMetrics()
        num_operations = 500

        def add_blob(size):
            """Record blob added."""
            metrics.record_blob_added(size)

        def remove_blob(size):
            """Record blob removed."""
            metrics.record_blob_removed(size)

        # Execute concurrent add/remove operations
        with ThreadPoolExecutor(max_workers=50) as executor:
            # Add blobs
            add_futures = [executor.submit(add_blob, 1000) for _ in range(num_operations)]
            for future in as_completed(add_futures):
                future.result()

            # Remove half of them
            remove_futures = [
                executor.submit(remove_blob, 1000) for _ in range(num_operations // 2)
            ]
            for future in as_completed(remove_futures):
                future.result()

        # Verify counts are accurate
        assert metrics.total_blobs == num_operations // 2
        assert metrics.total_bytes_stored == (num_operations // 2) * 1000

    def test_concurrent_summary_reads(self):
        """Test that summary() can be called concurrently without crashes."""
        metrics = CacheMetrics()

        def update_and_read():
            """Update metrics and read summary."""
            metrics.record_hit()
            summary = metrics.summary()
            metrics.record_miss()
            summary2 = metrics.summary()
            return (summary, summary2)

        # Execute concurrent reads and writes
        with ThreadPoolExecutor(max_workers=30) as executor:
            futures = [executor.submit(update_and_read) for _ in range(100)]
            results = [f.result() for f in as_completed(futures)]

        # Should not crash and return valid summaries
        assert len(results) == 100
        final_summary = metrics.summary()
        assert final_summary["hits"] == 100
        assert final_summary["misses"] == 100


class TestConcurrentStreaming:
    """Test concurrent streaming operations."""

    @pytest.fixture
    def storage(self, tmp_path):
        """Create a filesystem storage for testing."""
        return FilesystemStorage(str(tmp_path))

    def test_concurrent_streaming_writes(self, storage):
        """Test concurrent streaming writes to different blobs."""

        def write_stream(i):
            """Write a blob using streaming."""
            digest = f"stream-blob-{i:04d}"

            # Create a generator for streaming
            def data_generator():
                for j in range(10):
                    yield f"Chunk {j} for blob {i}\n".encode()

            storage.put_stream(digest, data_generator())
            return digest

        # Write 50 blobs concurrently using streaming
        with ThreadPoolExecutor(max_workers=20) as executor:
            futures = [executor.submit(write_stream, i) for i in range(50)]
            digests = [f.result() for f in as_completed(futures)]

        # Verify all blobs exist
        assert len(digests) == 50
        for digest in digests:
            assert storage.exists(digest)
            # Verify data is complete (not corrupted)
            data = storage.get(digest)
            assert len(data) > 0
            assert b"Chunk" in data

    def test_concurrent_read_and_write(self, storage):
        """Test concurrent reads and writes with streaming."""
        # Prepopulate some blobs
        for i in range(10):
            digest = f"rw-blob-{i:04d}"
            storage.put(digest, f"Data {i}".encode() * 100)

        def read_stream(digest):
            """Read blob using streaming."""
            chunks = list(storage.get_stream(digest))
            return len(chunks)

        def write_stream(i):
            """Write blob using streaming."""
            digest = f"rw-new-blob-{i:04d}"

            def gen():
                yield f"New data {i}".encode() * 50

            storage.put_stream(digest, gen())
            return digest

        operations = []

        with ThreadPoolExecutor(max_workers=30) as executor:
            # Concurrent reads
            for i in range(10):
                digest = f"rw-blob-{i:04d}"
                operations.append(executor.submit(read_stream, digest))

            # Concurrent writes
            for i in range(10, 30):
                operations.append(executor.submit(write_stream, i))

            results = [f.result() for f in as_completed(operations)]

        # All operations should complete
        assert len(results) == 30
