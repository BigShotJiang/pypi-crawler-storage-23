"""Unit tests for CachedStorage wrapper."""

import pytest

from cascache_server.storage import CachedStorage, MemoryStorage


@pytest.fixture
def memory_storage():
    """Provide a clean memory storage instance."""
    return MemoryStorage()


@pytest.fixture
def cached_storage(memory_storage):
    """Provide a cached storage wrapper."""
    return CachedStorage(backend=memory_storage, cache_size=100, max_blob_size=64 * 1024)


def test_initialization(memory_storage):
    """Test that CachedStorage initializes correctly."""
    cached = CachedStorage(backend=memory_storage, cache_size=10, max_blob_size=1024)
    assert cached.backend == memory_storage
    assert cached.max_blob_size == 1024


def test_put_and_get_cached(cached_storage):
    """Test that small blobs are cached."""
    digest = "abc123"
    data = b"test data"

    cached_storage.put(digest, data)

    # First get - should hit backend and cache
    result1 = cached_storage.get(digest)
    assert result1 == data

    # Second get - should hit cache
    result2 = cached_storage.get(digest)
    assert result2 == data

    # Verify cache stats show hits
    stats = cached_storage.get_cache_stats()
    assert stats["get_cache"]["hits"] > 0


def test_large_blob_bypasses_cache(cached_storage):
    """Test that large blobs bypass the cache."""
    digest = "large123"
    # Create blob larger than cache threshold (64KB)
    data = b"x" * (65 * 1024)

    cached_storage.put(digest, data)
    result = cached_storage.get(digest)
    assert result == data

    # Cache stats should show no operations for large blob
    # (it should bypass the cache entirely)


def test_exists_cached(cached_storage):
    """Test that exists checks are cached."""
    digest = "exists123"
    data = b"test"

    cached_storage.put(digest, data)

    # First exists - hits backend and caches
    assert cached_storage.exists(digest) is True

    # Second exists - should hit cache
    assert cached_storage.exists(digest) is True

    stats = cached_storage.get_cache_stats()
    assert stats["exists_cache"]["hits"] > 0


def test_get_size_cached(cached_storage):
    """Test that size checks are cached."""
    digest = "size123"
    data = b"test data"

    cached_storage.put(digest, data)

    # First get_size - hits backend and caches
    size1 = cached_storage.get_size(digest)
    assert size1 == len(data)

    # Second get_size - should hit cache
    size2 = cached_storage.get_size(digest)
    assert size2 == len(data)

    stats = cached_storage.get_cache_stats()
    assert stats["size_cache"]["hits"] > 0


def test_delete_invalidates_cache(cached_storage):
    """Test that delete operations work correctly."""
    digest = "delete123"
    data = b"test"

    cached_storage.put(digest, data)
    assert cached_storage.exists(digest) is True

    cached_storage.delete(digest)
    assert cached_storage.exists(digest) is False


def test_list_all_bypasses_cache(cached_storage):
    """Test that list_all always queries the backend."""
    cached_storage.put("digest1", b"data1")
    cached_storage.put("digest2", b"data2")

    digests = cached_storage.list_all()
    assert len(digests) == 2
    assert "digest1" in digests
    assert "digest2" in digests


def test_cache_stats_initialization(cached_storage):
    """Test that cache stats are properly initialized."""
    stats = cached_storage.get_cache_stats()

    assert "exists_cache" in stats
    assert "get_cache" in stats
    assert "size_cache" in stats

    for method_stats in stats.values():
        assert "hits" in method_stats
        assert "misses" in method_stats
        assert "maxsize" in method_stats
        assert "currsize" in method_stats


def test_cache_respects_max_size(memory_storage):
    """Test that cache evicts entries when full."""
    # Create cache with small size
    cached = CachedStorage(backend=memory_storage, cache_size=2, max_blob_size=64 * 1024)

    # Add 3 items (should evict oldest)
    cached.put("digest1", b"data1")
    cached.put("digest2", b"data2")
    cached.put("digest3", b"data3")

    # Access all 3 to populate cache
    cached.get("digest1")
    cached.get("digest2")
    cached.get("digest3")

    stats = cached.get_cache_stats()
    # With maxsize=2, currsize should not exceed 2
    assert stats["get_cache"]["currsize"] <= 2


def test_streaming_support(cached_storage):
    """Test that streaming methods work correctly."""
    digest = "stream123"
    data = b"streaming test data"

    # Put stream
    cached_storage.put_stream(digest, iter([data]))

    # Get stream
    chunks = list(cached_storage.get_stream(digest))
    assert b"".join(chunks) == data


def test_cache_with_missing_blob(cached_storage):
    """Test cache behavior with missing blobs."""
    digest = "missing123"

    # Should raise FileNotFoundError
    with pytest.raises(FileNotFoundError):
        cached_storage.get(digest)

    # Cache should track the miss
    stats = cached_storage.get_cache_stats()
    assert stats["get_cache"]["misses"] >= 0  # At least initialized
