"""Shared pytest fixtures for CAS server tests."""

import pytest

from cascache_server.monitoring.metrics import metrics
from cascache_server.services.cas_service import ContentAddressableStorageService
from cascache_server.storage.filesystem import FilesystemStorage
from cascache_server.storage.memory import MemoryStorage


@pytest.fixture
def temp_storage(tmp_path):
    """
    Temporary filesystem storage for testing.

    Args:
        tmp_path: pytest's temporary directory fixture

    Returns:
        FilesystemStorage instance using temporary directory
    """
    return FilesystemStorage(str(tmp_path))


@pytest.fixture
def memory_storage():
    """
    In-memory storage for testing.

    Returns:
        MemoryStorage instance
    """
    return MemoryStorage()


@pytest.fixture
def cas_service(memory_storage):
    """
    CAS service with memory storage backend.

    Returns:
        ContentAddressableStorageService instance
    """
    return ContentAddressableStorageService(memory_storage)


@pytest.fixture
def sample_blob():
    """
    Sample blob data for testing.

    Returns:
        Dictionary with digest, size, and data
    """
    return {
        "digest": "916f0027a575074ce72a331777c3478d6513f786a591bd892da1a577bf2335f9",
        "size": 9,
        "data": b"test data",
    }


@pytest.fixture(autouse=True)
def reset_metrics():
    """
    Reset metrics before each test.

    This fixture automatically runs before each test to ensure
    metrics start from a clean state.
    """
    metrics.reset()
    yield
    # Cleanup after test if needed
