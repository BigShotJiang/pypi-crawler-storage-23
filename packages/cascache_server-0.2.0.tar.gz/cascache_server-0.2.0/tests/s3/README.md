# MinIO S3-Compatible Storage for Testing

This directory contains Docker Compose configuration for running MinIO (S3-compatible storage) for testing the S3 backend.

## Quick Start

```bash
# Start MinIO
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f

# Stop MinIO
docker-compose down
```

## MinIO Console

- **Console URL:** http://localhost:9001
- **API Endpoint:** http://localhost:9000
- **Username:** `minioadmin`
- **Password:** `minioadmin`

## Configuration for Testing

Use these environment variables to test with MinIO:

```bash
export CAS_STORAGE_TYPE=s3
export CAS_STORAGE_PATH=cas-test-bucket
export CAS_S3_ENDPOINT=http://localhost:9000
export CAS_S3_ACCESS_KEY=minioadmin
export CAS_S3_SECRET_KEY=minioadmin
export CAS_S3_REGION=us-east-1
```

## Running Tests

```bash
# Start MinIO
docker-compose up -d

# Install dependencies (if needed)
uv sync

# Run S3 storage tests
pytest tests/unit/storage/test_s3.py -v

# Run integration tests
pytest tests/integration/test_s3_integration.py -v

# Stop MinIO
docker-compose down
```

## Storage Path

MinIO stores data in `./minio-data/` directory (gitignored).

## Bucket Auto-Creation

The S3Storage backend automatically creates the bucket if it doesn't exist, so you don't need to manually create buckets.

## Production Usage

For production, use:
- **AWS S3:** Remove `CAS_S3_ENDPOINT`, uses AWS credentials
- **Cloudflare R2:** Set `CAS_S3_ENDPOINT=https://ACCOUNT_ID.r2.cloudflarestorage.com`
- **Backblaze B2:** Set `CAS_S3_ENDPOINT=https://s3.us-west-000.backblazeb2.com`
- **Self-hosted MinIO:** Set `CAS_S3_ENDPOINT=https://your-minio-server:9000`
