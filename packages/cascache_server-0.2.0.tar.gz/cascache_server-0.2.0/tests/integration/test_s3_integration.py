"""Integration tests for S3Storage with real MinIO instance.

These tests require MinIO to be running:
    cd tests/s3 && docker-compose up -d

To run these tests:
    pytest tests/integration/test_s3_integration.py -v

To skip if MinIO is not running:
    pytest tests/integration/test_s3_integration.py -v -m "not s3_integration"
"""

import io
import os

import pytest

from cascache_server.storage.s3 import S3Storage

# Check if MinIO is available via environment variable
MINIO_AVAILABLE = os.getenv("MINIO_AVAILABLE", "false").lower() in ("true", "1", "yes")

# Default MinIO configuration
MINIO_ENDPOINT = os.getenv("MINIO_ENDPOINT", "http://localhost:9000")
MINIO_ACCESS_KEY = os.getenv("MINIO_ACCESS_KEY", "minioadmin")
MINIO_SECRET_KEY = os.getenv("MINIO_SECRET_KEY", "minioadmin")
MINIO_BUCKET = os.getenv("MINIO_BUCKET", "cas-integration-test")


@pytest.fixture
def minio_storage():
    """Create S3Storage connected to real MinIO instance."""
    if not MINIO_AVAILABLE:
        pytest.skip("MinIO not available (set MINIO_AVAILABLE=true to run)")

    try:
        storage = S3Storage(
            bucket=MINIO_BUCKET,
            endpoint_url=MINIO_ENDPOINT,
            region="us-east-1",
            access_key=MINIO_ACCESS_KEY,
            secret_key=MINIO_SECRET_KEY,
        )

        # Clean up before test
        storage.clear()

        yield storage

        # Clean up after test
        storage.clear()

    except Exception as e:
        pytest.skip(f"Cannot connect to MinIO: {e}")


@pytest.mark.s3_integration
def test_minio_connection(minio_storage):
    """Test basic MinIO connection."""
    # If we got here, connection works
    assert minio_storage.bucket == MINIO_BUCKET


@pytest.mark.s3_integration
def test_minio_put_get(minio_storage):
    """Test storing and retrieving from MinIO."""
    digest = "integration-test-blob"
    data = b"Hello from integration test!"

    minio_storage.put(digest, data)
    retrieved = minio_storage.get(digest)

    assert retrieved == data


@pytest.mark.s3_integration
def test_minio_streaming(minio_storage):
    """Test streaming operations with MinIO."""
    digest = "stream-test"
    # 5MB blob for realistic test
    data = b"x" * (5 * 1024 * 1024)
    stream = io.BytesIO(data)

    # Upload stream
    minio_storage.put_stream(digest, stream, size=len(data))

    # Download stream
    retrieved_stream = minio_storage.get_stream(digest)
    retrieved_data = retrieved_stream.read()

    assert len(retrieved_data) == len(data)


@pytest.mark.s3_integration
def test_minio_multiple_blobs(minio_storage):
    """Test storing multiple blobs in MinIO."""
    blobs = {f"blob-{i}": f"data-{i}".encode() for i in range(20)}

    # Store all
    for digest, data in blobs.items():
        minio_storage.put(digest, data)

    # Verify all exist
    listed = minio_storage.list_all()
    assert set(listed) == set(blobs.keys())

    # Retrieve all
    for digest, expected_data in blobs.items():
        assert minio_storage.get(digest) == expected_data


@pytest.mark.s3_integration
def test_minio_clear(minio_storage):
    """Test clearing MinIO bucket."""
    # Store blobs
    for i in range(10):
        minio_storage.put(f"clear-test-{i}", b"data")

    assert len(minio_storage.list_all()) == 10

    # Clear
    minio_storage.clear()
    assert len(minio_storage.list_all()) == 0


@pytest.mark.s3_integration
def test_minio_large_file_multipart(minio_storage):
    """Test multipart upload for large files (>5MB)."""
    digest = "large-multipart-test"
    # 10MB blob to trigger multipart upload
    data = b"A" * (10 * 1024 * 1024)
    stream = io.BytesIO(data)

    minio_storage.put_stream(digest, stream, size=len(data))

    # Verify size
    size = minio_storage.get_size(digest)
    assert size == len(data)

    # Verify data integrity
    retrieved = minio_storage.get(digest)
    assert len(retrieved) == len(data)
    assert retrieved == data


@pytest.mark.s3_integration
def test_minio_concurrent_access(minio_storage):
    """Test concurrent access patterns (simulated)."""
    import concurrent.futures

    def store_blob(index):
        digest = f"concurrent-{index}"
        data = f"data-{index}".encode()
        minio_storage.put(digest, data)
        return digest

    # Store 20 blobs concurrently
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        futures = [executor.submit(store_blob, i) for i in range(20)]
        digests = [f.result() for f in futures]

    # Verify all stored
    listed = minio_storage.list_all()
    assert set(listed) == set(digests)


@pytest.mark.s3_integration
def test_minio_delete_nonexistent(minio_storage):
    """Test deleting nonexistent blob (should not error)."""
    # Should not raise error
    minio_storage.delete("nonexistent-blob")


@pytest.mark.s3_integration
def test_minio_overwrite(minio_storage):
    """Test overwriting existing blob."""
    digest = "overwrite-test"
    data1 = b"original data"
    data2 = b"updated data"

    # Store original
    minio_storage.put(digest, data1)
    assert minio_storage.get(digest) == data1

    # Overwrite
    minio_storage.put(digest, data2)
    assert minio_storage.get(digest) == data2


@pytest.mark.s3_integration
def test_minio_prefix_isolation(minio_storage):
    """Test prefix isolation with real MinIO."""
    # Create two storage instances with different prefixes
    storage1 = S3Storage(
        bucket=MINIO_BUCKET,
        endpoint_url=MINIO_ENDPOINT,
        region="us-east-1",
        access_key=MINIO_ACCESS_KEY,
        secret_key=MINIO_SECRET_KEY,
        prefix="prefix1",
    )

    storage2 = S3Storage(
        bucket=MINIO_BUCKET,
        endpoint_url=MINIO_ENDPOINT,
        region="us-east-1",
        access_key=MINIO_ACCESS_KEY,
        secret_key=MINIO_SECRET_KEY,
        prefix="prefix2",
    )

    # Store same digest in both
    digest = "shared-digest"
    data1 = b"data from storage1"
    data2 = b"data from storage2"

    storage1.put(digest, data1)
    storage2.put(digest, data2)

    # Should retrieve different data
    assert storage1.get(digest) == data1
    assert storage2.get(digest) == data2

    # Clean up
    storage1.clear()
    storage2.clear()
