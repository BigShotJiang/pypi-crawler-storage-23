"""Integration tests for ActionCache gRPC service."""

from __future__ import annotations

import os
import time
from collections.abc import Generator
from pathlib import Path

import grpc
import pytest

from cascache_server.api.generated import action_cache_pb2, action_cache_pb2_grpc
from cascache_server.server import run_server


@pytest.fixture(scope="module")
def test_storage_path(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Create a temporary storage directory for the test server."""
    return tmp_path_factory.mktemp("action-cache-test")


@pytest.fixture(scope="module", autouse=True)
def configure_test_environment(test_storage_path: Path) -> Generator[None]:
    """Configure environment for test server."""
    # Save original environment
    original_env = {
        "CAS_STORAGE_PATH": os.environ.get("CAS_STORAGE_PATH"),
        "CAS_PORT": os.environ.get("CAS_PORT"),
        "CAS_LOG_LEVEL": os.environ.get("CAS_LOG_LEVEL"),
    }

    # Set test environment
    os.environ["CAS_STORAGE_PATH"] = str(test_storage_path)
    os.environ["CAS_PORT"] = "50053"
    os.environ["CAS_LOG_LEVEL"] = "WARNING"

    yield

    # Restore original environment
    for key, value in original_env.items():
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = value


@pytest.fixture(scope="module")
def grpc_server(configure_test_environment: None) -> Generator[grpc.Server]:
    """Start a gRPC server for testing."""
    # Start server without signal handlers (can't run in non-main thread)
    server = run_server(enable_signals=False)

    # Give server time to start
    time.sleep(0.5)

    yield server

    # Cleanup
    server.stop(grace=1)


@pytest.fixture
def action_cache_stub(grpc_server: grpc.Server) -> action_cache_pb2_grpc.ActionCacheStub:
    """Create a stub for ActionCache service."""
    channel = grpc.insecure_channel("localhost:50053")
    return action_cache_pb2_grpc.ActionCacheStub(channel)


def test_get_action_result_not_found(action_cache_stub):
    """Test GetActionResult returns NOT_FOUND for missing action."""
    request = action_cache_pb2.GetActionResultRequest(
        instance_name="",
        action_digest=action_cache_pb2.Digest(hash="nonexistent_hash", size_bytes=1024),
    )

    with pytest.raises(grpc.RpcError) as exc_info:
        action_cache_stub.GetActionResult(request)

    assert exc_info.value.code() == grpc.StatusCode.NOT_FOUND


def test_update_and_get_action_result(action_cache_stub):
    """Test storing and retrieving action result via gRPC."""
    action_digest = action_cache_pb2.Digest(hash="test_action_hash", size_bytes=2048)

    # Create action result
    action_result = action_cache_pb2.ActionResult(
        exit_code=0,
        output_files=[
            action_cache_pb2.OutputFile(
                path="output.o",
                digest=action_cache_pb2.Digest(hash="output_hash", size_bytes=512),
                is_executable=False,
            )
        ],
    )

    # Update action result
    update_request = action_cache_pb2.UpdateActionResultRequest(
        instance_name="", action_digest=action_digest, action_result=action_result
    )

    update_response = action_cache_stub.UpdateActionResult(update_request)
    assert update_response.exit_code == 0

    # Get action result
    get_request = action_cache_pb2.GetActionResultRequest(
        instance_name="", action_digest=action_digest
    )

    get_response = action_cache_stub.GetActionResult(get_request)
    assert get_response.exit_code == 0
    assert len(get_response.output_files) == 1
    assert get_response.output_files[0].path == "output.o"
    assert get_response.output_files[0].digest.hash == "output_hash"


def test_action_result_with_stdout_stderr(action_cache_stub):
    """Test action result with stdout and stderr."""
    action_digest = action_cache_pb2.Digest(hash="build_action", size_bytes=4096)

    action_result = action_cache_pb2.ActionResult(
        exit_code=0, stdout_raw=b"Build succeeded\n", stderr_raw=b"1 warning\n"
    )

    # Update
    update_request = action_cache_pb2.UpdateActionResultRequest(
        instance_name="test-instance", action_digest=action_digest, action_result=action_result
    )

    update_response = action_cache_stub.UpdateActionResult(update_request)
    assert update_response.exit_code == 0

    # Get
    get_request = action_cache_pb2.GetActionResultRequest(
        instance_name="test-instance", action_digest=action_digest
    )

    get_response = action_cache_stub.GetActionResult(get_request)
    assert get_response.stdout_raw == b"Build succeeded\n"
    assert get_response.stderr_raw == b"1 warning\n"


def test_action_result_with_directory_output(action_cache_stub):
    """Test action result with directory outputs."""
    action_digest = action_cache_pb2.Digest(hash="gen_action", size_bytes=8192)

    action_result = action_cache_pb2.ActionResult(
        exit_code=0,
        output_directories=[
            action_cache_pb2.OutputDirectory(
                path="generated",
                tree_digest=action_cache_pb2.Digest(hash="tree_hash", size_bytes=10240),
            )
        ],
    )

    # Update
    update_request = action_cache_pb2.UpdateActionResultRequest(
        instance_name="", action_digest=action_digest, action_result=action_result
    )

    update_response = action_cache_stub.UpdateActionResult(update_request)
    assert update_response.exit_code == 0

    # Get
    get_request = action_cache_pb2.GetActionResultRequest(
        instance_name="", action_digest=action_digest
    )

    get_response = action_cache_stub.GetActionResult(get_request)
    assert len(get_response.output_directories) == 1
    assert get_response.output_directories[0].path == "generated"
    assert get_response.output_directories[0].tree_digest.hash == "tree_hash"


def test_executable_output_file(action_cache_stub):
    """Test action result with executable output."""
    action_digest = action_cache_pb2.Digest(hash="compile_action", size_bytes=1024)

    action_result = action_cache_pb2.ActionResult(
        exit_code=0,
        output_files=[
            action_cache_pb2.OutputFile(
                path="myapp",
                digest=action_cache_pb2.Digest(hash="binary_hash", size_bytes=102400),
                is_executable=True,
            )
        ],
    )

    # Update
    update_request = action_cache_pb2.UpdateActionResultRequest(
        instance_name="", action_digest=action_digest, action_result=action_result
    )

    update_response = action_cache_stub.UpdateActionResult(update_request)
    assert update_response.exit_code == 0

    # Get
    get_request = action_cache_pb2.GetActionResultRequest(
        instance_name="", action_digest=action_digest
    )

    get_response = action_cache_stub.GetActionResult(get_request)
    assert get_response.output_files[0].is_executable is True
