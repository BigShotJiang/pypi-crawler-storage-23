"""Integration tests for gRPC CAS server."""

import hashlib
import os
import time
from collections.abc import Generator
from pathlib import Path

import grpc
import pytest

from cascache_server.api.generated import cas_simple_pb2, cas_simple_pb2_grpc
from cascache_server.server import run_server


@pytest.fixture(scope="module")
def test_storage_path(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Create a temporary storage directory for the test server."""
    return tmp_path_factory.mktemp("cas-integration-test")


@pytest.fixture(scope="module", autouse=True)
def configure_test_environment(test_storage_path: Path) -> Generator[None]:
    """Configure environment for test server."""
    # Save original environment
    original_env = {
        "CAS_STORAGE_PATH": os.environ.get("CAS_STORAGE_PATH"),
        "CAS_PORT": os.environ.get("CAS_PORT"),
        "CAS_LOG_LEVEL": os.environ.get("CAS_LOG_LEVEL"),
    }

    # Set test environment
    os.environ["CAS_STORAGE_PATH"] = str(test_storage_path)
    os.environ["CAS_PORT"] = "50052"
    os.environ["CAS_LOG_LEVEL"] = "WARNING"

    yield

    # Restore original environment
    for key, value in original_env.items():
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = value


@pytest.fixture(scope="module")
def grpc_server(configure_test_environment: None) -> Generator[grpc.Server]:
    """Start a gRPC server for testing."""
    # Start server without signal handlers (can't run in non-main thread)
    server = run_server(enable_signals=False)

    # Give server time to fully start
    time.sleep(0.5)

    yield server

    # Stop server
    server.stop(grace=2)


@pytest.fixture
def grpc_channel(grpc_server: grpc.Server) -> Generator[grpc.Channel]:
    """Create a gRPC channel to the test server."""
    channel = grpc.insecure_channel("localhost:50052")

    # Wait for channel to be ready
    try:
        grpc.channel_ready_future(channel).result(timeout=5)
    except grpc.FutureTimeoutError:
        pytest.fail("Server did not become ready in time")

    try:
        yield channel
    finally:
        channel.close()


@pytest.fixture
def cas_stub(grpc_channel: grpc.Channel) -> cas_simple_pb2_grpc.ContentAddressableStorageStub:
    """Create a CAS service stub."""
    return cas_simple_pb2_grpc.ContentAddressableStorageStub(grpc_channel)


def compute_digest(data: bytes) -> cas_simple_pb2.Digest:
    """Compute SHA256 digest for data."""
    hash_obj = hashlib.sha256(data)
    return cas_simple_pb2.Digest(
        hash=hash_obj.hexdigest(),
        size_bytes=len(data),
    )


class TestGRPCIntegration:
    """Integration tests for gRPC CAS operations."""

    def test_find_missing_blobs_all_missing(
        self, cas_stub: cas_simple_pb2_grpc.ContentAddressableStorageStub
    ) -> None:
        """Test FindMissingBlobs when all blobs are missing."""
        digests = [
            cas_simple_pb2.Digest(hash="a" * 64, size_bytes=10),
            cas_simple_pb2.Digest(hash="b" * 64, size_bytes=20),
        ]

        request = cas_simple_pb2.FindMissingBlobsRequest(blob_digests=digests)

        response = cas_stub.FindMissingBlobs(request)

        assert len(response.missing_blob_digests) == 2
        assert response.missing_blob_digests[0].hash == "a" * 64
        assert response.missing_blob_digests[1].hash == "b" * 64

    def test_batch_update_and_read_blobs(
        self, cas_stub: cas_simple_pb2_grpc.ContentAddressableStorageStub
    ) -> None:
        """Test uploading blobs and reading them back."""
        # Upload blobs
        test_data = [
            b"Hello, World!",
            b"Test data 123",
            b"CAS storage test",
        ]

        requests = []
        expected_digests = []

        for data in test_data:
            digest = compute_digest(data)
            expected_digests.append(digest)
            requests.append(
                cas_simple_pb2.BatchUpdateBlobsRequest.Request(
                    digest=digest,
                    data=data,
                )
            )

        update_request = cas_simple_pb2.BatchUpdateBlobsRequest(requests=requests)
        update_response = cas_stub.BatchUpdateBlobs(update_request)

        # Check all uploads succeeded
        assert len(update_response.responses) == len(test_data)
        for response in update_response.responses:
            assert response.status_code == 0, f"Upload failed: {response.status_message}"

        # Read blobs back
        read_request = cas_simple_pb2.BatchReadBlobsRequest(digests=expected_digests)
        read_response = cas_stub.BatchReadBlobs(read_request)

        # Verify data matches
        assert len(read_response.responses) == len(test_data)
        for i, response in enumerate(read_response.responses):
            assert response.status_code == 0, f"Read failed: {response.status_message}"
            assert response.data == test_data[i]
            assert response.digest.hash == expected_digests[i].hash
            assert response.digest.size_bytes == expected_digests[i].size_bytes

    def test_find_missing_blobs_some_present(
        self, cas_stub: cas_simple_pb2_grpc.ContentAddressableStorageStub
    ) -> None:
        """Test FindMissingBlobs when some blobs exist."""
        # Upload one blob
        data = b"Existing blob"
        digest = compute_digest(data)

        update_request = cas_simple_pb2.BatchUpdateBlobsRequest(
            requests=[
                cas_simple_pb2.BatchUpdateBlobsRequest.Request(
                    digest=digest,
                    data=data,
                )
            ]
        )
        cas_stub.BatchUpdateBlobs(update_request)

        # Check which blobs are missing
        missing_digest = cas_simple_pb2.Digest(hash="c" * 64, size_bytes=100)

        find_request = cas_simple_pb2.FindMissingBlobsRequest(blob_digests=[digest, missing_digest])
        find_response = cas_stub.FindMissingBlobs(find_request)

        # Only the missing digest should be returned
        assert len(find_response.missing_blob_digests) == 1
        assert find_response.missing_blob_digests[0].hash == missing_digest.hash

    def test_batch_read_missing_blob(
        self, cas_stub: cas_simple_pb2_grpc.ContentAddressableStorageStub
    ) -> None:
        """Test reading a blob that doesn't exist."""
        missing_digest = cas_simple_pb2.Digest(hash="d" * 64, size_bytes=50)

        read_request = cas_simple_pb2.BatchReadBlobsRequest(digests=[missing_digest])
        read_response = cas_stub.BatchReadBlobs(read_request)

        assert len(read_response.responses) == 1
        assert read_response.responses[0].status_code == 5  # NOT_FOUND
        assert "not found" in read_response.responses[0].status_message.lower()

    def test_large_blob(self, cas_stub: cas_simple_pb2_grpc.ContentAddressableStorageStub) -> None:
        """Test uploading and downloading a large blob."""
        # Create 1MB of data
        large_data = b"x" * (1024 * 1024)
        digest = compute_digest(large_data)

        # Upload
        update_request = cas_simple_pb2.BatchUpdateBlobsRequest(
            requests=[
                cas_simple_pb2.BatchUpdateBlobsRequest.Request(
                    digest=digest,
                    data=large_data,
                )
            ]
        )
        update_response = cas_stub.BatchUpdateBlobs(update_request)
        assert update_response.responses[0].status_code == 0, (
            f"Upload failed: {update_response.responses[0].status_message}"
        )

        # Read back
        read_request = cas_simple_pb2.BatchReadBlobsRequest(digests=[digest])
        read_response = cas_stub.BatchReadBlobs(read_request)

        assert read_response.responses[0].status_code == 0, (
            f"Read failed: {read_response.responses[0].status_message}"
        )
        assert read_response.responses[0].data == large_data
        assert read_response.responses[0].digest.size_bytes == len(large_data)
