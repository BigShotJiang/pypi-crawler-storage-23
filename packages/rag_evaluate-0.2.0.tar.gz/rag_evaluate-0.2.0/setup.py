from setuptools import setup, find_packages

with open("README.md", "r") as fh:
    description = fh.read()

setup(
    name='rag_evaluate',
    version='0.2.0',
    packages=find_packages(),
    install_requires=[
        'nltk',
        'rouge-score',
        'bert-score',
    ],
    long_description=description,
    long_description_content_type="text/markdown",
)