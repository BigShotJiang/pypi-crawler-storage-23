from collections.abc import Sequence

from pydantic import Field

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import Webhook


class GetWebhook(MSMethod):
    __return__ = Webhook
    __api_method__ = "entity/webhook"

    id: str = Field(..., alias="webhook_id")

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
