from pydantic import Field

from ..methods.base import MSMethod
from ..types import PurchaseOrderPosition


class UpdatePurchaseOrderPosition(MSMethod[PurchaseOrderPosition]):
    __return__ = PurchaseOrderPosition
    __api_method__ = "entity/purchaseorder/{purchaseorder_id}/positions"

    purchaseorder_id: str = Field(..., alias="purchaseorder_id")
    id: str = Field(..., alias="position_id")
    data: PurchaseOrderPosition
