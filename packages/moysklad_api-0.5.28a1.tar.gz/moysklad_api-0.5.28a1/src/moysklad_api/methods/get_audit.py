from collections.abc import Sequence

from pydantic import Field

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import Audit


class GetAudit(MSMethod):
    __return__ = Audit
    __api_method__ = "audit"

    id: str = Field(..., alias="audit_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
