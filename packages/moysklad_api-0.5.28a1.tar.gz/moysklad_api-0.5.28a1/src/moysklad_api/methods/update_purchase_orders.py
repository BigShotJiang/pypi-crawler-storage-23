from ..methods.base import MSMethod
from ..types import PurchaseOrder


class UpdatePurchaseOrders(MSMethod[PurchaseOrder]):
    __return__ = list[PurchaseOrder]
    __api_method__ = "entity/purchaseorder"

    data: list[PurchaseOrder]
