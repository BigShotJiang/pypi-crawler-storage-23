from collections.abc import Sequence

from pydantic import Field

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import Counterparty


class GetCounterparty(MSMethod):
    __return__ = Counterparty
    __api_method__ = "entity/counterparty"

    id: str = Field(..., alias="counterparty_id")

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
