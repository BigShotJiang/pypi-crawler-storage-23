from pydantic import Field

from .entity import Entity


class Download(Entity):
    href: str | None = Field(None, alias="href")
    media_type: str | None = Field(None, alias="mediaType")
