from typing import Any

from pydantic import Field

from .download import Download
from .entity import Entity
from .file import File


class Attribute(Entity):
    id: str | None = Field(None, alias="id")
    name: str | None = Field(None, alias="name")
    type: str | None = Field(None, alias="type")
    value: Any | None = Field(None, alias="value")
    download: Download | None = Field(None, alias="download")
    file: File | None = Field(None, alias="file")
