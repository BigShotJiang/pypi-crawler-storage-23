# singlespark

Singlenode spark — no JVM required. Use the best powerful APIs for Data on top.

- **Polars** for DataFrame operations
- **DuckDB** for Spark SQL
- **Local filesystem** for fake HDFS

## Installation

```bash
pip install singlespark
```

## Quick start

```python
from singlespark import SparkSession
from singlespark.sql import functions as F

spark = SparkSession.builder.appName("MyApp").getOrCreate()
df = spark.createDataFrame([("Alice", 30), ("Bob", 25)], ["name", "age"])
df.filter(F.col("age") > 26).show()
spark.stop()
```
