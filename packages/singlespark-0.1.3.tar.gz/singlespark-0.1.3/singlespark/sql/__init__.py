"""
singlespark.sql — SQL support subpackage.

Mirrors the pyspark.sql namespace:
    from singlespark.sql import functions as F
    from singlespark.sql.types import StructType, StringType, IntegerType, ...
"""

from singlespark.sql import functions, types

__all__ = ["functions", "types"]
