"""
SparkConf — key-value configuration store (mirrors pyspark.SparkConf).
"""
from __future__ import annotations


class SparkConf:
    """
    Mirrors pyspark.SparkConf.
    All settings are stored in a plain dict; none affect actual computation.
    """

    def __init__(self, config: dict | None = None):
        self._config: dict[str, str] = {}
        if config:
            for k, v in config.items():
                self._config[str(k)] = str(v)

    def set(self, key: str, value: str) -> "SparkConf":
        self._config[key] = str(value)
        return self

    def setAll(self, pairs) -> "SparkConf":
        for k, v in pairs:
            self.set(k, v)
        return self

    def setAppName(self, value: str) -> "SparkConf":
        return self.set("spark.app.name", value)

    def setMaster(self, value: str) -> "SparkConf":
        return self.set("spark.master", value)

    def get(self, key: str, defaultValue: str | None = None) -> str | None:
        return self._config.get(key, defaultValue)

    def getAll(self) -> list[tuple[str, str]]:
        return list(self._config.items())

    def contains(self, key: str) -> bool:
        return key in self._config

    def toDebugString(self) -> str:
        lines = [f"{k}={v}" for k, v in sorted(self._config.items())]
        return "\n".join(lines)

    def __repr__(self):
        return f"SparkConf({self._config!r})"
