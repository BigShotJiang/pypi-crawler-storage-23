"""
singlespark — PySpark emulator.

Polars for DataFrames. DuckDB for SQL. Local filesystem for HDFS.
No JVM required.

Quick start
-----------
    from singlespark import SparkSession
    from singlespark.sql import functions as F

    spark = SparkSession.builder.appName("MyApp").getOrCreate()
    df = spark.createDataFrame([("Alice", 30), ("Bob", 25)], ["name", "age"])
    df.filter(F.col("age") > 26).show()
    spark.stop()
"""

from singlespark.session import SparkSession, SparkContext
from singlespark.conf import SparkConf
from singlespark.row import Row
from singlespark import sql

__all__ = [
    "SparkSession",
    "SparkContext",
    "SparkConf",
    "Row",
    "sql",
]

__version__ = "0.1.0"
