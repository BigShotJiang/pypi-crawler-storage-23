"""agent-relay: OpenAI- and Anthropic-compatible API server for agent CLIs."""

__version__ = "0.5.1"
