"""Palette-related functionality for the shell layer."""
