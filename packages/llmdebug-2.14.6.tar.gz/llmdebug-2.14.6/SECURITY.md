# Security Policy

## Supported versions

Security fixes are applied to the latest release on `main`.

| Version line | Supported |
| --- | --- |
| latest `2.x` | Yes |
| older `2.x` | Best effort |
| `1.x` and earlier | No |

## Reporting a vulnerability

Please do not open a public issue for security vulnerabilities.

Report privately by email:

- `schuler.nicolas@proton.me`

Please include:

- a short description of the issue
- impact assessment
- reproduction steps or proof-of-concept
- affected versions/commit if known

## Response expectations

- Initial acknowledgment target: within 5 business days
- Status updates: at least weekly until resolution or mitigation

## Disclosure

After a fix is available, we may publish a security advisory and release notes
with enough detail for users to upgrade safely.
