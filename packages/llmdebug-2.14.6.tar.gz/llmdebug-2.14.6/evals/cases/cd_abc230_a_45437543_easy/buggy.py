N = input()
if int(N) >= 42:
    Z = int(N) + 1
    print("AGC0" + str(Z))
elif int(N) < 10:
    print("AGC00" + N)
else:
    print("AGC00" + N)
