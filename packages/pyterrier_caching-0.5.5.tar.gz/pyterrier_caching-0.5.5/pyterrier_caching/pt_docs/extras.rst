Extra Caching Utilities
=======================

These are additional utilities that can are sometimes useful when using the ``pyterrier-caching`` package.

.. autoclass:: pyterrier_caching.Lazy
   :members:

.. autofunction:: pyterrier_caching.closing_memmap
