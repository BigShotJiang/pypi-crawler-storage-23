"""Gdsfactory configuration."""

from __future__ import annotations

import getpass
import importlib
import pathlib
import sys
import tempfile
from enum import Enum, auto

from kfactory.conf import LogLevel, Settings, config, dotenv_path, get_affinity
from pydantic import Field
from pydantic_settings import SettingsConfigDict
from rich.console import Console
from rich.table import Table

__version__ = "9.36.0"
__next_major_version__ = "9.36.0"

PathType = str | pathlib.Path

home = pathlib.Path.home()
cwd = pathlib.Path.cwd()
module_path = pathlib.Path(__file__).parent.absolute()
repo_path = module_path.parent
home_path = pathlib.Path.home() / ".gdsfactory"
diff_path = repo_path / "gds_diff"
logpath = home_path / "log.log"

get_number_of_cores = get_affinity

GDSDIR_TEMP = (
    pathlib.Path(tempfile.tempdir or tempfile.gettempdir())
    / f"gdsfactory-{getpass.getuser()}"
)
GDSDIR_TEMP.mkdir(parents=True, exist_ok=True)

plugins = [
    "devsim",
    "femwell",
    "gdsfactoryplus",
    "gplugins",
    "kfactory",
    "lumapi",
    "meep",
    "meow",
    "ray",
    "sax",
    "tidy3d",
    "vlsir",
]


class ErrorType(Enum):
    ERROR = auto()
    WARNING = auto()
    IGNORE = auto()


def print_version_plugins(packages: list[str] | None = None) -> None:
    """Print gdsfactory plugin versions and paths.

    Args:
        packages: list of packages to print versions for.
    """
    table = Table(title="Modules")
    table.add_column("Package", justify="right", style="cyan", no_wrap=True)
    table.add_column("version", style="magenta")
    table.add_column("Path", justify="right", style="green")

    table.add_row("python", sys.version, str(sys.executable))
    table.add_row("gdsfactory", __version__, str(module_path))

    packages = packages or []

    for plugin in plugins + packages:
        try:
            m = importlib.import_module(plugin)
            try:
                table.add_row(plugin, str(m.__version__), str(m.__path__))
            except AttributeError:
                table.add_row(plugin, "", "")
        except ImportError:
            table.add_row(plugin, "not installed", "")

    console = Console()
    console.print(table)


def print_version_plugins_raw() -> None:
    """Print gdsfactory plugin versions and paths."""
    print("python", sys.version)
    print("gdsfactory", __version__)

    for plugin in plugins:
        try:
            m = importlib.import_module(plugin)
            try:
                print(plugin, m.__version__)
            except AttributeError:
                print(plugin)
        except ImportError:
            print(plugin, "not installed", "")


class Config(Settings):
    pdk: str | None = None
    layer_label: tuple[int, int] = (100, 0)
    difftest_ignore_label_differences: bool = False
    difftest_ignore_sliver_differences: bool = False
    difftest_ignore_cell_name_differences: bool = True
    bend_radius_error_type: ErrorType = ErrorType.ERROR
    layer_error_path: tuple[int, int] = (1000, 0)
    layer_marker: tuple[int, int] = (205, 0)
    connect_use_mirror: bool = False
    max_cellname_length: int = 64
    cell_layout_cache: bool = True
    port_types: list[str] = Field(
        default=[
            "optical",
            "electrical",
            "placement",
            "vertical_te",
            "vertical_tm",
            "vertical_dual",
            "electrical_rf",
            "pad",
            "pad_rf",
            "bump",
            "edge_coupler",
        ]
    )
    port_types_grating_couplers: list[str] = Field(
        default=["vertical_te", "vertical_tm", "vertical_dual"]
    )
    exclude_layers: list[tuple[int, int]] | list[str] | None = None

    model_config = SettingsConfigDict(
        arbitrary_types_allowed=True,
        env_prefix="",
        env_nested_delimiter="_",
        extra="allow",
        validate_assignment=True,
        env_file=dotenv_path,
    )


_defaults = Config()
for _field in Config.model_fields:
    setattr(config, _field, getattr(_defaults, _field))
config.logfilter.level = LogLevel.ERROR
CONF: Config = config  # type: ignore[assignment]


class Paths:
    module = module_path
    repo = repo_path
    results_tidy3d = home / ".tidy3d"

    generic_tech = module / "generic_tech"
    klayout = generic_tech / "klayout"
    klayout_tech = klayout
    klayout_lyp = klayout_tech / "layers.lyp"
    klayout_lyt = klayout_tech / "tech.lyt"

    gpdk = module / "gpdk"
    klayout_yaml = gpdk / "layer_views.yaml"

    schema_netlist = repo_path / "tests" / "schemas" / "netlist.json"
    netlists = module_path / "samples" / "netlists"
    gdsdir = repo_path / "tests" / "gds"
    gdslib = home / ".gdsfactory"
    modes = gdslib / "modes"
    sparameters = gdslib / "sp"
    capacitance = gdslib / "capacitance"
    interconnect = gdslib / "interconnect"
    optimiser = repo_path / "tune"
    notebooks = repo_path / "docs" / "notebooks"
    test_data = repo / "test-data-gds"
    gds_ref = test_data / "gds"
    gds_run = GDSDIR_TEMP / "gds_run"
    gds_diff = GDSDIR_TEMP / "gds_diff"
    cwd = cwd
    sparameters_repo = test_data / "sp"  # repo with some demo sparameters
    fonts = module / "components" / "texts" / "fonts"
    font_ocr = fonts / "OCR-A.ttf"


PATH = Paths()
sparameters_path = PATH.sparameters

valid_port_orientations = {0, 90, 180, -90, 270}


def rich_output() -> None:
    """Enables rich output."""
    from rich import pretty

    pretty.install()
