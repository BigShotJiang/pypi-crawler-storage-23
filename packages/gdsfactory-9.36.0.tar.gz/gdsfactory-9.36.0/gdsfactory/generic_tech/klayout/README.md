This folder is for the KLayout Salt package

Then you can register the package:

```
gdsfactory/gdsfactory.git/branches/main/gdsfactory/gpdk/klayout
```
