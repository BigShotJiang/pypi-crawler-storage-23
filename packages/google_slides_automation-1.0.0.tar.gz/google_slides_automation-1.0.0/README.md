# Google Slides Automation

A Python library for automating Google Slides presentations with JSON data—dynamic table population, slide duplication, and text replacement.

## Installation

```bash
# From PyPI (when published)
pip install google-slides-automation

# Or install from source
pip install -e .
```

## Quick Start

```python
from google_slides_automation import GoogleSlidesAutomation

# With service account
automation = GoogleSlidesAutomation(credentials_path="path/to/service-account.json")

# Create a presentation from a template
presentation_id = automation.create_presentation_from_template(
    template_id="YOUR_TEMPLATE_ID",
    json_data={
        "title": "Q1 Report",
        "subtitle": "Generated from Python",
        "images": {
            "hero": "https://example.com/hero.jpg",
        },
        "items": [
            {"name": "Item 1", "value": "100", "status": "Active"},
            {"name": "Item 2", "value": "200", "status": "Pending"},
        ],
    },
    title="My Presentation",
    drive_folder_url="https://drive.google.com/drive/folders/FOLDER_ID",  # Required for service accounts
)

print(f"Created: https://docs.google.com/presentation/d/{presentation_id}/edit")
```

### With User OAuth Token

```python
from google_slides_automation import GoogleSlidesAutomation
from google.oauth2.credentials import Credentials

# Use a user's OAuth2 access token
user_creds = Credentials(token="user_access_token_here")
automation = GoogleSlidesAutomation(user_credentials=user_creds)

presentation_id = automation.create_presentation_from_template(
    template_id="YOUR_TEMPLATE_ID",
    json_data={"title": "My Title", "items": [...]},
    title="Generated Presentation",
)
```

## Features

- **Dynamic Table Population**: Automatically populates tables with JSON data
- **Slide Duplication**: Intelligently duplicates slides for large datasets
- **Batch Processing**: Optimized batch updates with 10MB payload limits
- **Text Replacement**: Simple `{{key}}` placeholders in templates

## Template Requirements

Your Google Slides template should include:

1. **Placeholders**: Use `{{key}}` in text for simple replacements (e.g. `{{title}}`, `{{date}}`)
2. **Array Tables**: Use `{{array_key}}` in a table cell (e.g. `{{items}}`) to populate with data
3. **Image Placeholders**: Use `[[image:key]]` in a text shape. Size the shape to the desired image dimensions. The shape will be replaced with the image from the URL.
4. **Permissions**: Share the template with your service account (Viewer) or ensure the user has access

### Image placeholders

Add a text box containing `[[image:hero]]` (or any key), size it like an image placeholder. Pass URLs in `json_data["images"]`:

```python
json_data = {
    "title": "My Report",
    "images": {
        "hero": "https://example.com/hero.jpg",
        "logo": "https://example.com/logo.png",
    },
}
```

Images must be publicly accessible URLs (PNG, JPEG, or GIF; max 50MB, 25 megapixels).

## Project Structure

```
├── src/
│   └── google_slides_automation/
│       ├── __init__.py
│       ├── api_handler.py
│       ├── slides_automation.py
│       └── logger.py
├── pyproject.toml
└── README.md
```

## Configuration

### Environment Variables

- `GOOGLE_CREDENTIALS_PATH`: Path to Google service account credentials (default: `credentials.json`)

## Troubleshooting

### Common Issues

1. **Missing Credentials**: Ensure `credentials.json` is present and has correct permissions
2. **Template Access**: Verify the service account has edit access to the template
3. **Large Datasets**: The library automatically handles large datasets with slide duplication
4. **API Limits**: Batch processing helps stay within Google Slides API limits

### Debug Mode

Enable debug logging:
```bash
export LOG_LEVEL=DEBUG
```

## License

This project is licensed under the MIT License.
