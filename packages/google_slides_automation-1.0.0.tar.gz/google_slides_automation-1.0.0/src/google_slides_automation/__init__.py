"""
Google Slides Automation - Python library for automating Google Slides with JSON data.

Usage:

    from google_slides_automation import GoogleSlidesAutomation

    automation = GoogleSlidesAutomation(credentials_path="path/to/service-account.json")
    presentation_id = automation.create_presentation_from_template(
        template_id="YOUR_TEMPLATE_ID",
        json_data={"title": "My Title", "items": [...]},
        title="Generated Presentation",
        drive_folder_url="https://drive.google.com/drive/folders/FOLDER_ID",
    )
"""

from .slides_automation import GoogleSlidesAutomation
from .api_handler import GoogleSlidesAPIHandler

__all__ = ["GoogleSlidesAutomation", "GoogleSlidesAPIHandler"]
__version__ = "1.0.0"
