"""Allow running the package with `python -m aps_cli`."""

from aps_cli.cli import main

if __name__ == "__main__":
    main()
