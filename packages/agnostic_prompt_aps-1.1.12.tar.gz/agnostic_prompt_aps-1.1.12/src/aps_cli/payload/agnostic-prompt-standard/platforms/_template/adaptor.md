<instructions>
Replace this section with platform-specific generation instructions.
Describe tool naming conventions, file locations, and frontmatter rules.
</instructions>

<constants>
PLATFORM_ID: "your-platform-id"
DISPLAY_NAME: "Your Platform"
ADAPTER_VERSION: "0.1.0"
LAST_UPDATED: "YYYY-MM-DD"

INSTRUCTION_FILE_PATHS: [".github/copilot-instructions.md"]

DETECTION_MARKERS: [".github/agents/", "path/to/marker.file"]

DOCS_HOME_URL: "https://example.com/docs"
</constants>

<formats>
</formats>