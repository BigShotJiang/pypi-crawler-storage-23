<!-- Example: multi-line TEXT constant using TEXT<< ... >>.
     NOTE: Comment stripping (//) does NOT apply inside TEXT<< bodies. -->

<constants>
REPO_TREE: TEXT<<
cb-agnostic-prompt-protocol
├── assets
│   ├── constants
│   │   └── constants-json-block-v1.0.0.example.md
│   └── formats
│       ├── format-code-map-v1.0.0.example.md
│       └── format-error-v1.0.0.example.md
└── SKILL.md
>>
</constants>
