# Contributing to s3bolt

Thanks for your interest in contributing!

## Getting started

1. Fork and clone the repo
2. Install Rust (stable) and Python 3.10+
3. Run `cargo test --no-default-features` to verify your setup

## Development workflow

```bash
# Format
cargo fmt

# Lint
cargo clippy --no-default-features --lib -- -D warnings

# Test (Rust)
cargo test --no-default-features

# Test (Python)
maturin develop --release
pytest tests/ -v
```

## Pull requests

- Keep PRs focused on a single change
- Add tests for new functionality
- Ensure `cargo fmt`, `cargo clippy`, and `cargo test` pass
- Update documentation if applicable

## Reporting issues

Please include:
- s3bolt version (`s3bolt --version`)
- Rust version (`rustc --version`)
- OS and architecture
- Steps to reproduce
- Expected vs actual behavior

## Code of conduct

Be respectful and constructive. We're all here to build something useful.
