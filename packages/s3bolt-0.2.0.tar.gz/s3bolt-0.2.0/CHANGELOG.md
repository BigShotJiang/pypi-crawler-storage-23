# Changelog

All notable changes to this project will be documented in this file.

## [0.2.0] - 2026-02-28

### Changed

- Upgraded all Rust dependencies to latest versions (pyo3 0.28, indicatif 0.18, aws-sdk-s3, tokio, etc.)
- Updated Rust edition to 2024 and rust-version to 1.85
- Migrated codebase for pyo3 0.28 API changes (`detach`, `Py<PyAny>`, error types)
- Upgraded all Python build/dev dependencies to latest (maturin 1.12.5, pytest, ruff)
- Updated CI/CD workflows: latest GitHub Actions, manylinux_2_28 for aarch64, matrix improvements
- Added repository field to Cargo.toml

### Fixed

- Resolved CI/CD failures due to crates.io token and manylinux version
- Fixed clippy warnings (Default impl, formatting)
- Ensured all builds and tests pass for both CLI and Python extension

### Notes

- All dependencies, build tools, and CI actions are now at latest versions as of February 2026

## [0.1.0] - 2026-02-24

### Added

- Initial release
- Server-side copy via `CopyObject` for objects up to 5 GiB
- Multipart server-side copy via `UploadPartCopy` for objects > 5 GiB
- Adaptive concurrency with AIMD algorithm that dynamically resizes the
  semaphore at runtime (backs off on S3 503 SlowDown, ramps up on sustained success)
- Per-job retry with exponential backoff and full jitter (up to 3 retries,
  1s initial backoff, 30s cap)
- Bounded producer-consumer pipeline (listing → filter → semaphore → workers → progress)
- Multi-threaded Tokio runtime with named worker threads across all CPU cores
- Glob, regex, size, and date filtering
- Checkpoint/resume support for large copy jobs
- Dry-run mode
- Sync mode stub (ETag + size comparison)
- Cross-account support with separate source/destination AWS profiles
- Storage class override
- `S3Operations` trait abstraction for testability (mock-based tests, no AWS needed)
- CLI tool with `clap`
- Python package via PyO3 + maturin (GIL released during async work)
- Progress reporting (human-readable + JSON lines)
- CI/CD pipeline with cross-platform wheel builds
- Python test matrix gated on Rust checks passing
