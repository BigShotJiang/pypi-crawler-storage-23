"""Tests for the s3bolt Python bindings.

These tests verify that the native extension loads correctly and
exposes the expected API surface. No AWS credentials required.
"""

import s3bolt
from s3bolt import S3CopyEngine


def test_version_is_string():
    assert isinstance(s3bolt.__version__, str)
    assert len(s3bolt.__version__) > 0


def test_engine_class_exists():
    assert hasattr(s3bolt, "S3CopyEngine")


def test_engine_instantiation():
    engine = S3CopyEngine()
    assert engine is not None


def test_engine_with_profiles():
    engine = S3CopyEngine(source_profile=None, dest_profile=None)
    assert engine is not None


def test_copy_method_exists():
    engine = S3CopyEngine()
    assert callable(getattr(engine, "copy", None))
