//! JSON lines progress reporter for machine-readable output.

use crate::progress::reporter::{ProgressReporter, ProgressState};
use crate::types::CopyManifest;

/// Emits progress as JSON lines to stderr.
#[derive(Default)]
pub struct JsonReporter;

impl JsonReporter {
    pub fn new() -> Self {
        Self
    }
}

impl ProgressReporter for JsonReporter {
    fn tick(&self, state: &ProgressState) {
        let snap = state.snapshot();
        if let Ok(json) = serde_json::to_string(&snap) {
            eprintln!("{json}");
        }
    }

    fn finish(&self, manifest: &CopyManifest) {
        if let Ok(json) = serde_json::to_string(manifest) {
            eprintln!("{json}");
        }
    }
}
