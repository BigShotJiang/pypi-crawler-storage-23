//! S3 client, listing, copy operations, and trait abstraction.

pub mod client;
pub mod copier;
pub mod lister;
pub mod mock;
pub mod ops;
pub mod real;
