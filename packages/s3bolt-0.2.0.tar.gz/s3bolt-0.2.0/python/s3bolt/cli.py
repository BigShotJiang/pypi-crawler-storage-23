"""Thin Python CLI wrapper for s3bolt."""

from __future__ import annotations

import argparse
import json
import sys

from . import S3CopyEngine


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="s3bolt",
        description="High-performance S3 file copy tool",
    )
    parser.add_argument("source", help="Source S3 URI (s3://bucket/key)")
    parser.add_argument("destination", help="Destination S3 URI")
    parser.add_argument("-r", "--recursive", action="store_true", help="Recursive copy")
    parser.add_argument("--sync", action="store_true", help="Only copy new/changed objects")
    parser.add_argument("--dry-run", action="store_true", help="List without copying")
    parser.add_argument(
        "-j", "--concurrency", type=int, default=256, help="Max concurrent copies"
    )
    parser.add_argument("--include", action="append", default=[], help="Include glob (repeatable)")
    parser.add_argument("--exclude", action="append", default=[], help="Exclude glob (repeatable)")
    parser.add_argument("--storage-class", default=None, help="Override storage class")
    parser.add_argument("--source-profile", default=None, help="AWS profile for source")
    parser.add_argument("--dest-profile", default=None, help="AWS profile for destination")
    parser.add_argument("--json", action="store_true", help="Output as JSON")

    args = parser.parse_args()

    try:
        engine = S3CopyEngine(
            source_profile=args.source_profile,
            dest_profile=args.dest_profile,
        )

        result = engine.copy(
            args.source,
            args.destination,
            recursive=args.recursive,
            sync_mode=args.sync,
            dry_run=args.dry_run,
            max_concurrent=args.concurrency,
            include=args.include or None,
            exclude=args.exclude or None,
            storage_class=args.storage_class,
        )

        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(
                f"\nCopied {result['copied_objects']} objects "
                f"({result['copied_bytes']} bytes) | "
                f"Skipped {result['skipped_objects']} | "
                f"Failed {result['failed_objects']} | "
                f"{result['duration_secs']:.1f}s"
            )

        if result["failed_objects"] > 0:
            sys.exit(1)

    except KeyboardInterrupt:
        sys.exit(130)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
