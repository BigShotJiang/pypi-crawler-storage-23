"""
s3bolt — High-performance S3 file copy tool.

Powered by a Rust core via PyO3 for maximum throughput.

Classes
-------
S3CopyEngine
    The main copy engine. Holds a Tokio runtime and performs
    async S3 copies with adaptive concurrency.
"""

from ._s3bolt import S3CopyEngine, __version__

__all__ = ["S3CopyEngine", "__version__"]
