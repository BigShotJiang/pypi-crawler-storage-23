"""Backward-compatibility re-export — use ``python_discovery.PythonSpec`` directly."""

from __future__ import annotations

from python_discovery import PythonSpec

__all__ = [
    "PythonSpec",
]
