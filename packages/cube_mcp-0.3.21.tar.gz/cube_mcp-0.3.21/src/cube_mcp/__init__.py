from cube_agent.main import cli as main

__all__ = ["main"]
__version__ = "0.3.20"
