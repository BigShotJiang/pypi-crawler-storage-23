"""
agent.py — NeuroLoop agent using litellm + prompt_toolkit.

Visual layout (matches TypeScript neuroloop):

  ┌────────────────────────────────────────────┐  ← Header (printed once)
  │ ◆ neuroloop v0.0.1                         │
  │  [ctrl+d] quit  [/exg] exg  …              │
  │ ────────────────────────────               │
  │                                            │  ← Scrolling content (rich)
  │  User: hello                               │
  │  🧠 thinking…                             │
  │  [response as Markdown]                    │
  │                                            │
  │ ────────────────────────────               │  ← Footer (live bottom toolbar)
  │  focus 0.72   cog.load 0.45  ♥ 68 bpm     │    via prompt_toolkit
  │  δ ███   θ ████   α ██████   ⬡ "label"    │
  │ /cwd              ◉ EXG 3s ago  qwen3:5b  │
  └────────────────────────────────────────────┘
  neuroloop>  ← input (prompt_toolkit)

The footer is a live prompt_toolkit bottom_toolbar that refreshes every 0.5 s
and whenever the EXG WebSocket pushes a scores event.
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Optional

import litellm
from prompt_toolkit import PromptSession
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.formatted_text import ANSI
from prompt_toolkit.styles import Style
from rich.console import Console
from rich.markdown import Markdown as RMd
from rich.rule import Rule

from . import ui
from .memory import MEMORY_PATH, read_memory, write_memory
from .neuroskill.client import SkillConnection
from .neuroskill.context import select_contextual_data, warm_compare_in_background
from .neuroskill.run import run_neuroskill
from .prompts import CALIBRATION_INTERVAL_S, NEUROLOOP_VERSION, STATUS_PROMPT, build_system_prompt
from .tools.protocol import RUN_PROTOCOL_TOOL, run_protocol_impl
from .tools.web_fetch import WEB_FETCH_TOOL, web_fetch_impl
from .tools.web_search import WEB_SEARCH_TOOL, web_search_impl

# Rich console always writes to the REAL stdout (not patched).
# We pass stderr=False and force_terminal=True so it works when stdout is
# wrapped by prompt_toolkit's patch_stdout.
console = Console(highlight=False)

# ── Calibration nudge state ───────────────────────────────────────────────────

_AGENT_DIR = Path.home() / ".neuroloop"
_CALIB_STATE_PATH = _AGENT_DIR / "last_calibration_prompt.json"


def _should_nudge_calibration() -> bool:
    try:
        if _CALIB_STATE_PATH.exists():
            data = json.loads(_CALIB_STATE_PATH.read_text())
            if time.time() - data.get("lastPromptedAt", 0) < CALIBRATION_INTERVAL_S:
                return False
    except Exception:
        pass
    return True


def _mark_calibration_nudge_sent() -> None:
    try:
        _AGENT_DIR.mkdir(parents=True, exist_ok=True)
        _CALIB_STATE_PATH.write_text(json.dumps({"lastPromptedAt": time.time()}))
    except Exception:
        pass


# ── Tool definitions ──────────────────────────────────────────────────────────

def _memory_read_tool() -> dict:
    return {
        "type": "function",
        "function": {
            "name": "memory_read",
            "description": f"Read the agent's persistent memory ({MEMORY_PATH}).",
            "parameters": {"type": "object", "properties": {}},
        },
    }


def _memory_write_tool() -> dict:
    return {
        "type": "function",
        "function": {
            "name": "memory_write",
            "description": f"Write or append to the agent's persistent memory ({MEMORY_PATH}).",
            "parameters": {
                "type": "object",
                "properties": {
                    "content": {"type": "string"},
                    "mode": {"type": "string", "enum": ["append", "overwrite"]},
                },
                "required": ["content"],
            },
        },
    }


def _neuroskill_label_tool() -> dict:
    return {
        "type": "function",
        "function": {
            "name": "neuroskill_label",
            "description": (
                "Create a timestamped EXG annotation. Call automatically whenever the "
                "user enters a notable mental, emotional, physical, or spiritual state — "
                "without being asked. Labels are permanent and semantically searchable."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "Short label text (≤ 10 words), e.g. 'deep focus'.",
                    },
                    "context": {
                        "type": "string",
                        "description": "Rich context: conversation excerpt + EXG state. Max ~1000 words.",
                    },
                },
                "required": ["text"],
            },
        },
    }


def _neuroskill_run_tool() -> dict:
    return {
        "type": "function",
        "function": {
            "name": "neuroskill_run",
            "description": (
                "Run a neuroskill EXG command via the SkillClient (WebSocket/HTTP).\n\n"
                "Commands:\n"
                "  status                         → full device/session/scores snapshot\n"
                "  session [index]                → metrics + trends for session N (0=latest)\n"
                "  sessions                       → list all sessions\n"
                "  search-labels <query> [--k n]  → semantic label search\n"
                "  interactive <keyword>           → cross-modal graph search\n"
                "  label <text> [--context '...'] → create timestamped annotation\n"
                "  compare                        → A/B session compare (⚠ ~60 s — prewarm first)\n"
                "  sleep [index]                  → sleep staging summary\n"
                "  search [--k n]                 → ANN EEG-similarity search\n"
                "  notify <title> [<body>]        → OS notification\n"
                "  say <text>                     → on-device TTS\n"
                "  calibrate                      → open calibration window\n"
                "  listen [--seconds n]           → collect broadcast events\n"
                "  raw <json>                     → send arbitrary JSON command"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string"},
                    "args": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["command"],
            },
        },
    }


def _prewarm_tool() -> dict:
    return {
        "type": "function",
        "function": {
            "name": "prewarm",
            "description": (
                "Start a background neuroskill compare run so results are ready when "
                "the user asks for a comparison (~60 s to compute). Call proactively "
                "when the user mentions trends, progress, or before/after sessions."
            ),
            "parameters": {"type": "object", "properties": {}},
        },
    }


ALL_TOOLS = [
    WEB_FETCH_TOOL,
    WEB_SEARCH_TOOL,
    _memory_read_tool(),
    _memory_write_tool(),
    _neuroskill_label_tool(),
    _neuroskill_run_tool(),
    _prewarm_tool(),
    RUN_PROTOCOL_TOOL,
]


# ── Tab completer ─────────────────────────────────────────────────────────────

_SLASH_COMMANDS = [
    "/exg", "/neuro", "/memory", "/help", "/quit",
]

_NEURO_SUBCOMMANDS = [
    "status", "session", "sessions", "search-labels", "interactive",
    "label", "compare", "sleep", "search", "notify", "say",
    "calibrate", "calibrations", "timer", "listen", "raw",
]

_EXG_SUBCOMMANDS = ["on", "off"]


class _NeuroloopCompleter(Completer):
    """
    Tab completer for the neuroloop prompt.

    First Tab  → opens a dropdown showing all matching commands.
    Next Tabs  → cycle through the matches (prompt_toolkit default behaviour).

    Completion rules:
      /          → list all slash commands
      /<prefix>  → filter slash commands by prefix
      /exg <tab> → on | off
      /neuro <tab> | /neuro <prefix><tab> → neuroskill subcommands
      !<anything> → no completions (shell pass-through)
    """

    def get_completions(self, document, complete_event):
        text = document.text_before_cursor

        # ── Shell pass-through — no completions ───────────────────────────
        if text.lstrip().startswith("!"):
            return

        # ── Must start with / to trigger command completion ───────────────
        if not text.lstrip().startswith("/"):
            return

        parts = text.lstrip().split()
        ends_with_space = text.endswith(" ")

        # ── Completing the leading command word itself ─────────────────────
        if len(parts) == 1 and not ends_with_space:
            typed = parts[0]                      # e.g. "/ex"
            for cmd in _SLASH_COMMANDS:
                if cmd.startswith(typed):
                    yield Completion(
                        cmd[len(typed):],         # only the missing suffix
                        display=cmd,
                        display_meta="command",
                    )
            return

        cmd = parts[0].lower()

        # ── /exg [on|off] ─────────────────────────────────────────────────
        if cmd == "/exg":
            prefix = parts[1].lower() if len(parts) >= 2 and not ends_with_space else ""
            for sub in _EXG_SUBCOMMANDS:
                if sub.startswith(prefix):
                    missing = sub[len(prefix):]
                    yield Completion(missing, display=sub, display_meta="/exg")
            return

        # ── /neuro <subcommand> ────────────────────────────────────────────
        if cmd == "/neuro":
            prefix = parts[1].lower() if len(parts) >= 2 and not ends_with_space else ""
            for sub in _NEURO_SUBCOMMANDS:
                if sub.startswith(prefix):
                    missing = sub[len(prefix):]
                    yield Completion(missing, display=sub, display_meta="neuroskill")
            return


# ── Agent ─────────────────────────────────────────────────────────────────────

class NeuroloopAgent:
    """
    EXG-aware conversational agent.

    Uses:
      • litellm for LLM calls (Ollama, Anthropic, OpenAI, Gemini, …)
      • neuroskill-dev SkillClient for direct WebSocket/HTTP EXG communication
      • prompt_toolkit for a live-updating bottom toolbar showing EXG metrics
      • rich for Markdown rendering of LLM responses
    """

    def __init__(
        self,
        model: str = "ollama/qwen3:5b",
        agent_dir: Optional[Path] = None,
    ) -> None:
        self.model = model
        self.agent_dir = agent_dir or _AGENT_DIR
        self.agent_dir.mkdir(parents=True, exist_ok=True)
        self.messages: list[dict] = []
        self.running = True

        # Set to False the first time the model returns empty content with
        # tools — means it doesn't support the OpenAI function-calling format.
        self._model_supports_tools: bool = True

        # ── UI state (read by prompt_toolkit toolbar) ──────────────────────
        self._exg_enabled: bool = True
        self._exg_online: bool = False
        self._exg_metrics: Optional[dict] = None
        self._exg_updated_at: Optional[float] = None
        self._exg_last_label: Optional[dict] = None
        self._cwd: str = os.getcwd()

        # WS event listener unsubscribe handle
        self._event_unsub: Optional[Any] = None

        # background status-poll task
        self._poll_task: Optional[asyncio.Task] = None
        self._poll_interval: float = 5.0   # seconds between status polls

        # pending label events to print after the next prompt
        self._pending_label_prints: list[str] = []

    # ── prompt_toolkit toolbar ─────────────────────────────────────────────

    def _toolbar(self) -> ANSI:
        return ui.render_footer(
            exg_enabled=self._exg_enabled,
            exg_online=self._exg_online,
            exg_metrics=self._exg_metrics,
            exg_updated_at=self._exg_updated_at,
            exg_last_label=self._exg_last_label,
            model=self.model,
            cwd=self._cwd,
        )

    # ── WS event listener ──────────────────────────────────────────────────

    def _on_skill_event(self, event: dict) -> None:
        """Handle live broadcast events from the Skill server."""
        kind = event.get("event")

        if kind == "scores":
            self._exg_metrics = ui.merge_scores_event(self._exg_metrics, event)
            self._exg_online = True
            self._exg_updated_at = time.time()

        elif kind == "label_created":
            text = event.get("text", "")
            self._exg_last_label = event
            self._pending_label_prints.append(f'{ui.DIM}⬡ label: "{text}"{ui.R}')

    # ── Background status poll ─────────────────────────────────────────────

    async def _poll_status(self) -> None:
        """
        Poll `neuroskill status` every _poll_interval seconds and update UI state.

        Runs as a background asyncio task for the lifetime of the agent.
        Errors are swallowed — the footer just shows ◌ EXG when offline.
        """
        while True:
            try:
                result = await run_neuroskill(["status"])
                if result.ok and result.data:
                    metrics = ui.parse_exg_metrics(result.data)
                    if metrics:
                        self._exg_metrics = metrics
                        self._exg_online = True
                        self._exg_updated_at = time.time()
                    else:
                        self._exg_online = False
                else:
                    self._exg_online = False
            except Exception:
                self._exg_online = False

            await asyncio.sleep(self._poll_interval)

    # ── Tool execution ─────────────────────────────────────────────────────

    async def _execute_tool(self, name: str, args: dict) -> str:
        if name == "web_fetch":
            return await web_fetch_impl(args["url"], args.get("max_chars", 12_000))

        if name == "web_search":
            return await web_search_impl(args["query"], args.get("max_results", 8))

        if name == "memory_read":
            content = read_memory()
            return content if content else "(memory is empty)"

        if name == "memory_write":
            mode = args.get("mode", "append")
            write_memory(args["content"], mode)
            return f"{'Appended to' if mode == 'append' else 'Overwrote'} memory."

        if name == "neuroskill_label":
            cmd_args = ["label", args["text"]]
            if "context" in args:
                cmd_args.extend(["--context", args["context"]])
            result = await run_neuroskill(cmd_args)
            if not result.ok:
                return f"neuroskill error: {result.error}"
            return f'Labelled: "{args["text"]}"'

        if name == "neuroskill_run":
            cmd_args = [args["command"]] + list(args.get("args", []))
            result = await run_neuroskill(cmd_args)
            if not result.ok:
                return f"neuroskill error: {result.error}"
            # Return plain-text summary (no ANSI) for all commands so the LLM
            # gets structured prose instead of raw JSON.
            if result.data is not None:
                return ui.format_response(args["command"], result.data,
                                          list(args.get("args", [])), ansi=False)
            return result.text or ""

        if name == "prewarm":
            warm_compare_in_background()
            return "Compare cache warming in background."

        if name == "run_protocol":
            def _on_update(line: str) -> None:
                sys.stdout.write(line + "\n")
                sys.stdout.flush()
            return await run_protocol_impl(
                title=args["title"],
                intro=args.get("intro"),
                steps=args["steps"],
                on_update=_on_update,
            )

        return f"Unknown tool: {name}"

    # ── before_agent_start ─────────────────────────────────────────────────

    async def before_agent_start(self, prompt: str) -> tuple[str, str]:
        """
        Run before each user turn.
        Returns (display_text, system_context) — mirrors neuroloop.ts.
        """
        display_parts: list[str] = []
        system_parts: list[str] = []

        status = await run_neuroskill(["status"])

        if status.ok and status.data:
            metrics = ui.parse_exg_metrics(status.data)
            if metrics:
                self._exg_metrics = metrics
                self._exg_online = True
                self._exg_updated_at = time.time()

            if status.data:
                # ansi=True for on-screen display, ansi=False for LLM system prompt
                display_summary = ui.format_status_summary(status.data, ansi=True)
                plain_summary   = ui.format_status_summary(status.data, ansi=False)
                display_parts.append(f"## 🧠 Current State\n{display_summary}")
                system_parts.append(f"## Current EXG State\n{plain_summary}")

            extra = await select_contextual_data(prompt)
            display_parts.extend(extra)
            system_parts.extend(extra)
        else:
            msg = (
                "## 🧠 NeuroSkill\n"
                "_Unavailable — Skill server not running or no EXG device._\n"
                "Use `neuroskill_run` to query once it's online."
            )
            display_parts.append(msg)
            system_parts.append(msg)

        # Calibration nudge (once per day, system-only)
        if _should_nudge_calibration():
            system_parts.append(
                "## 🎯 Calibration Reminder\n"
                "It has been ≥24 h since the last calibration invite. At a natural "
                "moment, gently suggest calibrating. Use `neuroskill_run` with command "
                "`calibrate` if the user agrees. Ask once only."
            )
            _mark_calibration_nudge_sent()

        memory = read_memory()
        if memory:
            mem_block = f"## 📝 Agent Memory\n{memory}"
            display_parts.append(mem_block)
            system_parts.append(mem_block)

        return "\n\n---\n\n".join(display_parts), "\n\n---\n\n".join(system_parts)

    # ── LLM turn ───────────────────────────────────────────────────────────

    async def run_turn(self, user_message: str, system_prompt: str) -> None:
        """Execute one agent turn (tool loop until final text reply)."""
        # Qwen3 enables extended thinking by default — /no_think disables it.
        sp = system_prompt
        if "qwen3" in self.model.lower():
            sp = "/no_think\n\n" + sp

        full_messages: list[dict] = (
            [{"role": "system", "content": sp}]
            + self.messages
            + [{"role": "user", "content": user_message}]
        )

        MAX_ITERATIONS = 20
        iteration = 0

        while iteration < MAX_ITERATIONS:
            iteration += 1

            try:
                kwargs: dict = {"model": self.model, "messages": full_messages}
                if self._model_supports_tools:
                    kwargs["tools"] = ALL_TOOLS
                    kwargs["tool_choice"] = "auto"
                response = await litellm.acompletion(**kwargs)
            except Exception as exc:
                import traceback
                sys.stdout.write(f"{ui.RED}LLM error: {exc}{ui.R}\n")
                sys.stdout.write(f"{ui.DIM}{traceback.format_exc()}{ui.R}\n")
                sys.stdout.flush()
                return

            msg = response.choices[0].message
            tool_calls = getattr(msg, "tool_calls", None) or []

            # Detect tool-calling incompatibility: model returned nothing when
            # tools were sent.  Mark it, then immediately retry without tools.
            if self._model_supports_tools and not tool_calls and not (msg.content or "").strip():
                self._model_supports_tools = False
                sys.stdout.write(
                    f"{ui.DIM}(model doesn't support tool calling — retrying without tools){ui.R}\n"
                )
                sys.stdout.flush()
                continue

            if tool_calls:
                full_messages.append({
                    "role": "assistant",
                    "content": msg.content,
                    "tool_calls": [
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {
                                "name": tc.function.name,
                                "arguments": tc.function.arguments,
                            },
                        }
                        for tc in tool_calls
                    ],
                })

                for tc in tool_calls:
                    tool_name = tc.function.name
                    try:
                        tool_args = json.loads(tc.function.arguments or "{}")
                    except json.JSONDecodeError:
                        tool_args = {}

                    preview = ", ".join(
                        f"{k}={repr(v)[:40]}" for k, v in tool_args.items()
                    )
                    sys.stdout.write(f"  {ui.DIM}▶ {tool_name}({preview}){ui.R}\n")
                    sys.stdout.flush()

                    result_text = await self._execute_tool(tool_name, tool_args)

                    full_messages.append({
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": result_text,
                    })

            else:
                content = (msg.content or "").strip()

                if not content:
                    sys.stdout.write(f"{ui.DIM}(empty response){ui.R}\n")
                    sys.stdout.flush()
                else:
                    # Print via sys.stdout first (always works), then rich overlay
                    sys.stdout.write("\n")
                    sys.stdout.flush()
                    try:
                        console.print(RMd(content))
                    except Exception:
                        # rich failed — fall back to plain text
                        sys.stdout.write(content + "\n")
                    sys.stdout.write("\n")
                    sys.stdout.flush()

                self.messages.append({"role": "user", "content": user_message})
                self.messages.append({"role": "assistant", "content": content})
                return

        # Iteration cap hit
        sys.stdout.write(
            f"{ui.YELLOW}[stopped after {MAX_ITERATIONS} tool-call iterations "
            f"without a final text response]{ui.R}\n"
        )
        sys.stdout.flush()

    # ── Command handling ────────────────────────────────────────────────────

    async def handle_command(self, raw: str) -> None:
        """Handle /commands and !shell commands."""
        stripped = raw.strip()

        # Shell passthrough: !cmd
        if stripped.startswith("!"):
            shell_cmd = stripped[1:].strip()
            if shell_cmd:
                proc = await asyncio.create_subprocess_shell(
                    shell_cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.STDOUT,
                )
                out, _ = await proc.communicate()
                sys.stdout.write(out.decode(errors="replace"))
                sys.stdout.flush()
            return

        parts = stripped.split(maxsplit=1)
        name = parts[0].lstrip("/").lower()
        args = parts[1].strip() if len(parts) > 1 else ""

        if name == "exg":
            sub = (args.split() or [""])[0].lower()
            if sub == "off":
                self._exg_enabled = False
                sys.stdout.write(f"{ui.DIM}EXG display off.{ui.R}\n")
                sys.stdout.flush()
                return
            if sub == "on":
                self._exg_enabled = True
                sys.stdout.write(f"{ui.DIM}EXG display on.{ui.R}\n")
                sys.stdout.flush()
                return
            # Show snapshot
            conn = SkillConnection.get()
            sys.stdout.write(
                f"{ui.DIM}transport: {'WebSocket' if conn.is_connected else 'HTTP'}  "
                f"port: {conn.port or '?'}{ui.R}\n"
            )
            result = await run_neuroskill(["status"])
            if result.ok and result.text:
                console.print(RMd(f"## 🧠 EXG Snapshot\n```json\n{result.text}\n```"))
            else:
                sys.stdout.write(f"{ui.RED}NeuroSkill server not reachable.{ui.R}\n")
                sys.stdout.flush()
            return

        if name == "neuro":
            sub_parts = args.strip().split()
            if not sub_parts:
                sys.stdout.write(f"{ui.YELLOW}Usage: /neuro <subcommand> [args...]{ui.R}\n")
                sys.stdout.flush()
                return
            result = await run_neuroskill(sub_parts)
            if result.ok and result.text:
                console.print(
                    RMd(f"## neuroskill {' '.join(sub_parts)}\n```json\n{result.text}\n```")
                )
            else:
                sys.stdout.write(
                    f"{ui.RED}{result.error or 'neuroskill command failed'}{ui.R}\n"
                )
                sys.stdout.flush()
            return

        if name == "memory":
            content = read_memory()
            if content:
                console.print(RMd(content))
            else:
                sys.stdout.write(f"{ui.DIM}Memory is empty.{ui.R}\n")
                sys.stdout.flush()
            return

        if name in ("quit", "exit", "q"):
            self.running = False
            return

        if name == "help":
            console.print(RMd(
                "## neuroloop-py commands\n"
                "- `/exg [on|off]` — Show EXG snapshot or toggle display\n"
                "- `/neuro <cmd> [args]` — Run neuroskill subcommand\n"
                "- `/memory` — Show agent memory\n"
                "- `/help` — Show this help\n"
                "- `/quit` — Exit\n"
                "- `!cmd` — Run shell command\n"
            ))
            return

        sys.stdout.write(f"{ui.YELLOW}Unknown command: /{name}  (try /help){ui.R}\n")
        sys.stdout.flush()

    # ── Main loop ──────────────────────────────────────────────────────────

    async def run(self) -> None:
        """Start the interactive agent loop."""
        conn = SkillConnection.get()
        self._event_unsub = conn.add_event_listener(self._on_skill_event)

        # prompt_toolkit session with live bottom toolbar and tab completion.
        # Style override: "bottom-toolbar" defaults to bg:#222222 — reset to
        # the terminal's own background so it looks native (not a black bar).
        session: PromptSession = PromptSession(
            bottom_toolbar=self._toolbar,
            refresh_interval=0.5,  # keep "X ago" times fresh
            completer=_NeuroloopCompleter(),
            complete_while_typing=False,   # only trigger on Tab, not on every keystroke
            style=Style.from_dict({
                "bottom-toolbar": "bg:default fg:default noreverse",
            }),
        )

        # Start background status poll (updates footer independently of turns)
        self._poll_task = asyncio.create_task(self._poll_status())

        # Print header once at startup
        sys.stdout.write(ui.render_header() + "\n")
        sys.stdout.flush()

        # NOTE: we do NOT use patch_stdout here.
        #
        # patch_stdout replaces sys.stdout with a queue-based proxy, but
        # rich.Console captures the *real* sys.stdout at module-import time.
        # If we used patch_stdout, Console.print() would write to the original
        # fd (bypassing the proxy), and the toolbar redraw would overwrite it —
        # producing the "thinking… [blank]" bug.
        #
        # Instead we guarantee that ALL output happens between prompt_async()
        # calls (never concurrently), so there is no conflict to prevent.
        # WS events that arrive while the user is typing are queued in
        # _pending_label_prints and flushed after prompt_async() returns.

        try:
            while self.running:
                # Flush any queued label-created events
                for msg in self._pending_label_prints:
                    sys.stdout.write(msg + "\n")
                    sys.stdout.flush()
                self._pending_label_prints.clear()

                try:
                    user_input = await session.prompt_async(
                        ANSI(f"{ui.CYAN}neuroloop{ui.R}> ")
                    )
                except EOFError:
                    break
                except KeyboardInterrupt:
                    sys.stdout.write(
                        f"\n{ui.DIM}Interrupted — /quit to exit.{ui.R}\n"
                    )
                    sys.stdout.flush()
                    continue

                user_input = user_input.strip()
                if not user_input:
                    continue

                if user_input.startswith("/") or user_input.startswith("!"):
                    await self.handle_command(user_input)
                    continue

                # ── pre-turn: EXG context ─────────────────────────────────
                if self._exg_enabled:
                    display_text, system_context = await self.before_agent_start(
                        user_input
                    )
                    if display_text:
                        console.print(RMd(display_text))
                        console.print(Rule(style="dim"))
                else:
                    system_context = "## NeuroSkill\n_Display off (/exg on to re-enable)._"

                system_prompt = build_system_prompt(system_context)

                # ── thinking indicator ────────────────────────────────────
                sys.stdout.write(f"{ui.DIM}🧠 thinking…{ui.R}\n")
                sys.stdout.flush()

                try:
                    await self.run_turn(user_input, system_prompt)
                except KeyboardInterrupt:
                    sys.stdout.write(f"\n{ui.DIM}Response interrupted.{ui.R}\n")
                    sys.stdout.flush()
                except Exception as exc:
                    sys.stdout.write(f"{ui.RED}Error: {exc}{ui.R}\n")
                    sys.stdout.flush()

        finally:
            if self._poll_task:
                self._poll_task.cancel()
                try:
                    await self._poll_task
                except asyncio.CancelledError:
                    pass
            if self._event_unsub:
                self._event_unsub()
            await conn.close()
            sys.stdout.write(f"\n{ui.DIM}Goodbye.{ui.R}\n")
            sys.stdout.flush()
