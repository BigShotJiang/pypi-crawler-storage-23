"""
neuroskill/context.py — contextual EXG data selection.

Reads domain signals from the user's prompt and decides which neuroskill
commands to run. All tasks fire in parallel; failures are silently skipped.
The base `status` snapshot is always injected by agent.py — everything
here is additive.
"""

import asyncio
from pathlib import Path
from typing import Optional

from .run import run_neuroskill
from .signals import detect_signals

_HERE = Path(__file__).parent
PROTOCOLS_SKILL_PATH = _HERE.parent.parent / "skills" / "neuroskill-protocols" / "SKILL.md"

# ─────────────────────────────────────────────────────────────────────────────
# Compare cache
# ─────────────────────────────────────────────────────────────────────────────

COMPARE_CACHE_TTL_S = 10 * 60  # 10 minutes

_compare_cache: dict = {
    "text": None,
    "built_at": None,
    "task": None,
}


def _get_fresh_compare() -> Optional[str]:
    """Return cached compare text if still fresh, otherwise None."""
    import time
    text = _compare_cache.get("text")
    built_at = _compare_cache.get("built_at")
    if not text or built_at is None:
        return None
    if time.time() - built_at > COMPARE_CACHE_TTL_S:
        return None
    return text


def warm_compare_in_background() -> None:
    """Kick off a background compare run if not already running."""
    import time

    if _compare_cache.get("task") is not None:
        return  # already running
    if _get_fresh_compare() is not None:
        return  # cache still fresh

    async def _build():
        import time as t
        result = await run_neuroskill(["compare"])
        if result.ok and result.text:
            _compare_cache["text"] = result.text
            _compare_cache["built_at"] = t.time()
        _compare_cache["task"] = None

    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            task = loop.create_task(_build())
            _compare_cache["task"] = task
    except RuntimeError:
        pass  # no event loop — skip prewarm


async def select_contextual_data(prompt: str) -> list[str]:
    """Select additional neuroskill data blocks based on the user's prompt."""
    lp = prompt.lower()
    s = detect_signals(lp)

    extras: list[str] = []

    # ── Protocol skill on-demand ─────────────────────────────────────────────
    if s.get("protocols") and PROTOCOLS_SKILL_PATH.exists():
        try:
            skill_content = PROTOCOLS_SKILL_PATH.read_text(encoding="utf-8")
            extras.append(f"## 🧘 Protocol Repertoire\n{skill_content}")
        except OSError:
            pass

    # ── Queue helpers ────────────────────────────────────────────────────────
    queue: list[tuple[str, list[str]]] = []

    def enqueue(label: str, *args: str) -> None:
        queue.append((label, list(args)))

    def search_labels(label: str, query: str, k: str = "5") -> None:
        enqueue(label, "search-labels", query, "--k", k)

    # ── Signal-driven data selection ─────────────────────────────────────────

    if s.get("sleep"):
        enqueue("Sleep Staging (last 24 h)", "sleep")
        search_labels("Past Sleep Labels", "sleep tired rest deep sleep rem restoration drowsy")

    needs_session = any(s.get(k) for k in [
        "session", "sport", "learning", "social", "dating", "family",
        "creative", "leadership", "recovery", "morning", "evening",
        "nutrition", "therapy", "goals", "performance", "confidence",
        "anger", "grief", "loneliness", "addiction",
    ])
    if needs_session:
        enqueue("Current Session Metrics", "session", "0")

    if s.get("compare") or s.get("goals"):
        cached = _get_fresh_compare()
        if cached:
            queue.append(("Session Comparison (last 2) — cached", []))
        else:
            warm_compare_in_background()

    if s.get("sessions"):
        enqueue("Session History", "sessions")

    if s.get("focus"):
        enqueue("Current Session Metrics", "session", "0")
        search_labels("Past Focus & Deep Work Labels", "deep focus work productivity flow state concentration locked in")

    if s.get("stress"):
        enqueue("Current Session Metrics", "session", "0")
        search_labels("Past Stress & Overwhelm Labels", "stress overwhelmed burnout pressure tense nervous anxious overloaded")

    if s.get("meditation"):
        enqueue("Current Session Metrics", "session", "0")
        search_labels("Past Meditation & Relaxation Labels", "meditation mindfulness calm relaxation breathing peace stillness grounded")

    if s.get("social"):
        search_labels("Past Social Interaction Labels", "social meeting people conversation team collaboration networking friends")

    if s.get("dating"):
        search_labels("Past Romantic & Dating Labels", "romantic partner relationship date connection love intimacy attraction")

    if s.get("family"):
        search_labels("Past Family & Home Labels", "family children parenting home household spouse caregiving kids parent")

    if s.get("sport"):
        search_labels("Past Exercise & Sport Labels", "exercise workout training sport running gym fitness athletic cardio strength")

    if s.get("learning"):
        search_labels("Past Study & Learning Labels", "studying learning exam memorize reading concentration retention academic")

    if s.get("creative"):
        search_labels("Past Creative Work Labels", "creative art music writing design inspiration ideas innovation brainstorm")

    if s.get("leadership"):
        search_labels("Past Leadership & Management Labels", "leadership management decision making strategy team leading executive")

    if s.get("recovery"):
        search_labels("Past Recovery & Rest Labels", "recovery rest restoration recharge refresh downtime rejuvenate unwind")

    if s.get("morning"):
        search_labels("Past Morning Routine Labels", "morning routine wake up coffee start of day fresh clarity rested")

    if s.get("evening"):
        search_labels("Past Evening & Wind-down Labels", "evening wind down end of day night routine relax calm bedtime")

    if s.get("nutrition"):
        search_labels("Past Nutrition & Eating Labels", "food eating meal nutrition caffeine coffee tea fasting glucose brain fuel")

    if s.get("therapy"):
        search_labels("Past Therapy & Reflection Labels", "therapy reflection introspection emotional processing journaling self-aware")

    if s.get("travel"):
        enqueue("Sleep Staging (last 24 h)", "sleep")
        search_labels("Past Travel Labels", "travel jetlag timezone circadian rhythm body clock adjustment")

    if s.get("goals"):
        search_labels("Past Goal & Habit Labels", "goal habit routine intention achievement milestone streak self-improvement")

    if s.get("anger"):
        search_labels("Past Anger & Frustration Labels", "anger frustrated irritable rage outburst tense reactive triggered emotional")

    if s.get("grief"):
        search_labels("Past Grief & Loss Labels", "grief loss sad mourning bereavement sorrow heartbreak pain emotional")

    if s.get("loneliness"):
        search_labels("Past Loneliness & Isolation Labels", "lonely isolation alone disconnected withdrawn left out excluded belonging")

    if s.get("addiction"):
        search_labels("Past Craving & Compulsion Labels", "craving urge compulsion addiction impulse scroll distraction temptation")

    if s.get("confidence"):
        search_labels("Past Confidence & Self-Esteem Labels", "confident self-esteem doubt insecure imposter capable proud accomplished")

    if s.get("hrv"):
        enqueue("Current Session Metrics", "session", "0")
        search_labels("Past HRV & Cardiac Labels", "heart rate HRV palpitation breathing chest autonomic cardiac coherence calm vagal")

    if s.get("somatic"):
        enqueue("Current Session Metrics", "session", "0")
        search_labels("Past Somatic & Body Sensation Labels", "somatic body sensation tension embodied grounded interoception gut feeling physical")

    if s.get("consciousness"):
        enqueue("Current Session Metrics", "session", "0")
        search_labels("Past Consciousness & Awareness Labels", "consciousness awareness presence awakening ego dissolution lucid witness observer altered state")

    if s.get("philosophy"):
        enqueue("Current Session Metrics", "session", "0")
        search_labels("Past Philosophy & Inquiry Labels", "philosophy meaning purpose wisdom truth inquiry virtue contemplation stoic existential")

    if s.get("existential"):
        enqueue("Current Session Metrics", "session", "0")
        search_labels("Past Existential & Mortality Labels", "death mortality meaning existence purpose void impermanence legacy soul finitude")

    if s.get("depth"):
        enqueue("Current Session Metrics", "session", "0")
        search_labels("Past Deep Feeling & Inner Life Labels", "profound depth inner life soul contemplation moving stirred vast silence inward")

    if s.get("morals"):
        enqueue("Current Session Metrics", "session", "0")
        search_labels("Past Moral & Ethical Labels", "ethics morals integrity conscience guilt shame regret duty right wrong dilemma values justice")

    if s.get("symbiosis"):
        enqueue("Current Session Metrics", "session", "0")
        search_labels("Past Symbiosis & Connection Labels", "symbiosis interconnected oneness unity interdependence harmony nature collective ecosystem belonging")

    if s.get("awe"):
        enqueue("Current Session Metrics", "session", "0")
        search_labels("Past Awe & Wonder Labels", "awe wonder transcendence sublime sacred peak experience cosmic majestic beauty spiritual gratitude overwhelmed")

    if s.get("identity"):
        enqueue("Current Session Metrics", "session", "0")
        search_labels("Past Identity & Self-Discovery Labels", "identity authentic self-concept who am I true self mask persona values-alignment self-expression discovery")

    # ── Deduplicate & cap label searches ────────────────────────────────────
    MAX_LABEL_SEARCHES = 5
    seen: set[str] = set()
    label_search_count = 0
    unique_queue: list[tuple[str, list[str]]] = []

    for label, args in queue:
        key = "\0".join(args)
        if key in seen:
            continue
        seen.add(key)
        if args and args[0] == "search-labels":
            if label_search_count >= MAX_LABEL_SEARCHES:
                continue
            label_search_count += 1
        unique_queue.append((label, args))

    # ── Execute in parallel ───────────────────────────────────────────────────
    async def run_task(label: str, args: list[str]) -> Optional[str]:
        if not args:
            # Cached compare sentinel
            text = _get_fresh_compare()
            return f"### {label}\n{text}" if text else None
        result = await run_neuroskill(args)
        if result.ok and result.text:
            return f"### {label}\n{result.text}"
        return None

    results = await asyncio.gather(
        *(run_task(label, args) for label, args in unique_queue),
        return_exceptions=False,
    )

    return [*extras, *(r for r in results if r is not None)]
