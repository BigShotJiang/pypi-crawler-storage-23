"""Cyberwave Edge Core - The core component of the Cyberwave Edge."""

__version__ = "0.1.0"
