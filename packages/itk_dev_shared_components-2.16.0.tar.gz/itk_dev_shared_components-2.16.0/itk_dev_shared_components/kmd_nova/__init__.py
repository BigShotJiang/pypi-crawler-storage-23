"""This module provides helper functions to use the KMD Nova api.
The api is documented here: https://novaapi.kmd.dk/swagger/index.html
"""
