"""
Output formatting for Semantic API CLI.

Handles pretty JSON, compact JSON, and quiet mode output.
Uses ANSI colors when outputting to a TTY.
"""

import json
import sys
from typing import Any, Dict, Optional


# ANSI color codes
class Colors:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    
    # Foreground
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"
    
    # Bright
    BRIGHT_GREEN = "\033[92m"
    BRIGHT_YELLOW = "\033[93m"
    BRIGHT_BLUE = "\033[94m"
    BRIGHT_CYAN = "\033[96m"


def is_tty() -> bool:
    """Check if stdout is a TTY (supports colors)."""
    return hasattr(sys.stdout, 'isatty') and sys.stdout.isatty()


def colorize(text: str, color: str) -> str:
    """Apply color to text if outputting to TTY."""
    if is_tty():
        return f"{color}{text}{Colors.RESET}"
    return text


def success(text: str) -> str:
    """Green success text."""
    return colorize(text, Colors.GREEN)


def error(text: str) -> str:
    """Red error text."""
    return colorize(text, Colors.RED)


def warning(text: str) -> str:
    """Yellow warning text."""
    return colorize(text, Colors.YELLOW)


def info(text: str) -> str:
    """Blue info text."""
    return colorize(text, Colors.BLUE)


def dim(text: str) -> str:
    """Dimmed text."""
    return colorize(text, Colors.DIM)


def bold(text: str) -> str:
    """Bold text."""
    return colorize(text, Colors.BOLD)


def format_json(data: Any, raw: bool = False) -> str:
    """
    Format data as JSON.
    
    Args:
        data: Data to format
        raw: If True, compact JSON. Otherwise, pretty-printed.
    """
    if raw:
        return json.dumps(data, separators=(',', ':'))
    return json.dumps(data, indent=2)


def format_query_result(data: Dict[str, Any], quiet: bool = False) -> str:
    """
    Format a query result for display.
    
    Args:
        data: Query response data
        quiet: If True, show minimal output
    """
    lines = []
    
    if quiet:
        # Minimal output: just the essential fields
        if data.get("success"):
            provider = data.get("provider", "?")
            operation = data.get("operation", "?")
            lines.append(f"{provider}.{operation}")
            if data.get("data"):
                # Show snippet or first key info
                result_data = data["data"]
                if isinstance(result_data, dict):
                    if "endpoint" in result_data:
                        lines.append(result_data["endpoint"])
                    elif "url" in result_data:
                        lines.append(result_data["url"])
        else:
            lines.append(error(data.get("error", "Unknown error")))
    else:
        # Full formatted output
        if data.get("success"):
            lines.append(success("✓ Query matched"))
            lines.append("")
            
            provider = data.get("provider", "unknown")
            operation = data.get("operation", "unknown")
            lines.append(f"  {bold('Provider:')} {provider}")
            lines.append(f"  {bold('Operation:')} {operation}")
            
            # Show parsed intent params if present
            intent = data.get("parsed_intent", {})
            params = intent.get("params", {})
            if params:
                lines.append(f"  {bold('Parameters:')}")
                for k, v in params.items():
                    lines.append(f"    {dim(k)}: {v}")
            
            # Show data/snippet if present
            result_data = data.get("data", {})
            if isinstance(result_data, dict):
                if result_data.get("endpoint"):
                    lines.append("")
                    lines.append(f"  {bold('Endpoint:')} {result_data['endpoint']}")
                if result_data.get("curl"):
                    lines.append(f"  {bold('cURL:')}")
                    lines.append(f"    {dim(result_data['curl'][:200])}")
                if result_data.get("python"):
                    lines.append(f"  {bold('Python:')}")
                    for line in result_data['python'].split('\n')[:5]:
                        lines.append(f"    {dim(line)}")
        else:
            lines.append(error("✗ Query failed"))
            lines.append("")
            lines.append(f"  {data.get('error', 'Unknown error')}")
    
    return "\n".join(lines)


def format_preflight_result(data: Dict[str, Any], quiet: bool = False) -> str:
    """Format a preflight result for display."""
    lines = []
    
    if quiet:
        providers = data.get("providers", [])
        ready = data.get("ready", False)
        status = "ready" if ready else "needs_setup"
        provider_list = ", ".join(p.get("provider", "?") for p in providers)
        return f"{status}: {provider_list}"
    
    lines.append(bold("Preflight Check"))
    lines.append("")
    lines.append(f"  {bold('Query:')} {data.get('query', '?')}")
    lines.append("")
    
    providers = data.get("providers", [])
    if providers:
        lines.append(f"  {bold('Providers needed:')}")
        for p in providers:
            name = p.get("provider", "?")
            status = p.get("status", "?")
            
            if status == "ready":
                status_str = success("✓ ready")
            elif status == "needs_auth":
                status_str = warning("⚠ needs auth")
            elif status == "needs_discovery":
                status_str = info("? needs discovery")
            else:
                status_str = dim(status)
            
            lines.append(f"    • {name}: {status_str}")
            if p.get("reason"):
                lines.append(f"      {dim(p['reason'])}")
    
    lines.append("")
    if data.get("ready"):
        lines.append(success("  All providers ready! You can run this query."))
    else:
        lines.append(warning("  " + data.get("message", "Some setup required.")))
    
    return "\n".join(lines)


def format_discover_result(data: Dict[str, Any], quiet: bool = False) -> str:
    """Format a discover result for display."""
    lines = []
    
    if quiet:
        if data.get("success"):
            provider = data.get("provider", {})
            name = provider.get("name", "?")
            caps = data.get("capabilities_found", 0)
            return f"{name}: {caps} capabilities"
        else:
            return error(data.get("error", "Discovery failed"))
    
    if data.get("success"):
        lines.append(success("✓ Provider discovered"))
        lines.append("")
        
        provider = data.get("provider", {})
        lines.append(f"  {bold('Name:')} {provider.get('name', '?')}")
        lines.append(f"  {bold('ID:')} {provider.get('provider', '?')}")
        lines.append(f"  {bold('Base URL:')} {provider.get('base_url', '?')}")
        lines.append(f"  {bold('Capabilities:')} {data.get('capabilities_found', 0)}")
        
        if provider.get("description"):
            lines.append(f"  {bold('Description:')} {provider['description'][:100]}")
        
        if data.get("source_url") and data["source_url"] != "(cached)":
            lines.append(f"  {bold('Source:')} {data['source_url']}")
        
        if data.get("usage_note"):
            lines.append("")
            lines.append(f"  {dim(data['usage_note'])}")
        
        # Show capabilities
        caps = provider.get("capabilities", [])
        if caps:
            lines.append("")
            lines.append(f"  {bold('Capabilities:')}")
            for cap in caps[:10]:  # Show first 10
                lines.append(f"    • {cap.get('name', cap.get('id', '?'))}")
            if len(caps) > 10:
                lines.append(f"    {dim(f'... and {len(caps) - 10} more')}")
    else:
        lines.append(error("✗ Discovery failed"))
        lines.append("")
        lines.append(f"  {data.get('error', 'Unknown error')}")
    
    return "\n".join(lines)


def format_status_result(data: Dict[str, Any], quiet: bool = False) -> str:
    """Format health/status result for display."""
    lines = []
    
    if quiet:
        return data.get("status", "unknown")
    
    status = data.get("status", "unknown")
    if status == "ok":
        lines.append(success("✓ Semantic API is healthy"))
    elif status == "degraded":
        lines.append(warning("⚠ Semantic API is degraded"))
    else:
        lines.append(error(f"✗ Status: {status}"))
    
    lines.append("")
    lines.append(f"  {bold('Version:')} {data.get('version', '?')}")
    
    if data.get("database"):
        lines.append(f"  {bold('Database:')} {data['database']}")
    
    if data.get("cache"):
        cache = data["cache"]
        lines.append(f"  {bold('Cache:')}")
        lines.append(f"    Memory size: {cache.get('memory_size', '?')}")
        lines.append(f"    Hits: {cache.get('memory_hits', '?')}")
    
    return "\n".join(lines)


def format_agentic_result(data: Dict[str, Any], quiet: bool = False) -> str:
    """Format an agentic (execution) result for display."""
    lines = []
    
    if quiet:
        if data.get("success"):
            return data.get("response", "")[:200]
        else:
            return error(data.get("error", "Execution failed"))
    
    if data.get("success"):
        lines.append(success("✓ Execution complete"))
        lines.append("")
        
        # Show the synthesized response
        response = data.get("response", "")
        if response:
            lines.append(f"  {bold('Response:')}")
            for line in response.split('\n'):
                lines.append(f"    {line}")
        
        # Show steps taken
        steps = data.get("steps", [])
        if steps:
            lines.append("")
            lines.append(f"  {bold('Steps:')} ({len(steps)} API calls)")
            for i, step in enumerate(steps[:5], 1):
                tool = step.get("tool", "?")
                lines.append(f"    {i}. {dim(tool)}")
            if len(steps) > 5:
                lines.append(f"    {dim(f'... and {len(steps) - 5} more')}")
        
        # Show status if not complete
        status = data.get("status", "complete")
        if status == "needs_input":
            lines.append("")
            lines.append(warning(f"  ⚠ {data.get('question', 'Input needed')}"))
            if data.get("options"):
                for opt in data["options"]:
                    lines.append(f"    • {opt}")
        elif status == "awaiting_auth":
            lines.append("")
            lines.append(warning("  ⚠ Authentication required"))
            lines.append(f"    Execution ID: {data.get('execution_id', '?')}")
    else:
        lines.append(error("✗ Execution failed"))
        lines.append("")
        lines.append(f"  {data.get('error', 'Unknown error')}")
    
    return "\n".join(lines)


def print_error(message: str) -> None:
    """Print error message to stderr."""
    print(error(f"Error: {message}"), file=sys.stderr)


def print_result(data: Any, raw: bool = False, quiet: bool = False, formatter=None) -> None:
    """
    Print result to stdout.
    
    Args:
        data: Data to print
        raw: If True, output compact JSON
        quiet: If True, output minimal info
        formatter: Optional function to format non-JSON output
    """
    if raw:
        print(format_json(data, raw=True))
    elif formatter and not quiet:
        print(formatter(data, quiet=quiet))
    elif quiet and formatter:
        print(formatter(data, quiet=True))
    else:
        print(format_json(data))
