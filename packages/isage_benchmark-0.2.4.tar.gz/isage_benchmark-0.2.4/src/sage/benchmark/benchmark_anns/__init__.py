"""
Benchmark ANNS - Streaming Index Benchmark Framework

精简的流式索引基准测试框架

注意: 此文件保持为空,因为这是项目根目录,不应作为 Python 包使用。
测试和导入应该使用绝对导入方式访问 bench/ 和 datasets/ 子包。
"""

__version__ = "1.0.0"
