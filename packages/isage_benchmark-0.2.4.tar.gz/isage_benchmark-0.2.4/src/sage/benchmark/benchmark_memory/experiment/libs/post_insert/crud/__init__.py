"""CRUD Action - 实体级 CRUD 决策"""

from .base import CRUDAction

__all__ = ["CRUDAction"]
