"""
Core metrics for agent capability evaluation.

Implements metrics for tool selection, task planning, and timing judgment.
"""

import time
from typing import Any, Sequence

import numpy as np

from . import MetricOutput


class MetricRegistry:
    """Registry for metric implementations."""

    _metrics: dict[str, type] = {}

    @classmethod
    def register(cls, name: str):
        """Decorator to register a metric class."""

        def decorator(metric_class):
            cls._metrics[name] = metric_class
            return metric_class

        return decorator

    @classmethod
    def get(cls, name: str, **kwargs):
        """Get metric instance by name."""
        if name not in cls._metrics:
            raise ValueError(f"Unknown metric: {name}")
        return cls._metrics[name](**kwargs)

    @classmethod
    def list_metrics(cls) -> list[str]:
        """List all registered metric names."""
        return list(cls._metrics.keys())


@MetricRegistry.register("top_k_accuracy")
class TopKAccuracyMetric:
    """
    Top-K accuracy for tool selection.

    Measures if any predicted tool matches the ground truth within top-K.
    """

    name = "top_k_accuracy"

    def __init__(self, k: int = 5):
        """
        Initialize metric.

        Args:
            k: Number of top predictions to consider
        """
        self.k = k

    def compute(
        self, predictions: Sequence[list[str]], references: Sequence[list[str]]
    ) -> MetricOutput:
        """
        Compute top-k accuracy.

        Args:
            predictions: List of predicted tool ID lists
            references: List of reference tool ID lists

        Returns:
            MetricOutput with accuracy value
        """
        start_time = time.time()

        hits = 0
        for pred, ref in zip(predictions, references):
            pred_top_k = pred[: self.k] if isinstance(pred, list) else [pred]
            ref_set = set(ref) if isinstance(ref, list) else {ref}

            if any(p in ref_set for p in pred_top_k):
                hits += 1

        accuracy = hits / len(predictions) if len(predictions) > 0 else 0.0
        elapsed = time.time() - start_time

        return MetricOutput(
            value=accuracy,
            details={
                "k": self.k,
                "total_samples": len(predictions),
                "hits": hits,
                "compute_time_seconds": elapsed,
            },
        )


@MetricRegistry.register("recall_at_k")
class RecallAtKMetric:
    """
    Recall@K for tool selection.

    Measures what fraction of relevant tools are retrieved in top-K.
    """

    name = "recall_at_k"

    def __init__(self, k: int = 5):
        """
        Initialize metric.

        Args:
            k: Number of top predictions to consider
        """
        self.k = k

    def compute(
        self, predictions: Sequence[list[str]], references: Sequence[list[str]]
    ) -> MetricOutput:
        """
        Compute recall@k.

        Args:
            predictions: List of predicted tool ID lists
            references: List of reference tool ID lists

        Returns:
            MetricOutput with recall value
        """
        start_time = time.time()

        recalls = []
        for pred, ref in zip(predictions, references):
            pred_top_k = set(pred[: self.k]) if isinstance(pred, list) else {pred}
            ref_set = set(ref) if isinstance(ref, list) else {ref}

            if len(ref_set) == 0:
                recalls.append(0.0)
            else:
                recall = len(pred_top_k & ref_set) / len(ref_set)
                recalls.append(recall)

        avg_recall = np.mean(recalls) if len(recalls) > 0 else 0.0
        elapsed = time.time() - start_time

        return MetricOutput(
            value=float(avg_recall),
            details={
                "k": self.k,
                "total_samples": len(predictions),
                "per_sample_recalls": recalls,
                "compute_time_seconds": elapsed,
            },
        )


@MetricRegistry.register("precision_at_k")
class PrecisionAtKMetric:
    """
    Precision@K for tool selection.

    Measures what fraction of top-K predictions are relevant.
    """

    name = "precision_at_k"

    def __init__(self, k: int = 5):
        """
        Initialize metric.

        Args:
            k: Number of top predictions to consider
        """
        self.k = k

    def compute(
        self, predictions: Sequence[list[str]], references: Sequence[list[str]]
    ) -> MetricOutput:
        """
        Compute precision@k.

        Args:
            predictions: List of predicted tool ID lists
            references: List of reference tool ID lists

        Returns:
            MetricOutput with precision value
        """
        start_time = time.time()

        precisions = []
        for pred, ref in zip(predictions, references):
            pred_top_k = set(pred[: self.k]) if isinstance(pred, list) else {pred}
            ref_set = set(ref) if isinstance(ref, list) else {ref}

            if len(pred_top_k) == 0:
                precisions.append(0.0)
            else:
                precision = len(pred_top_k & ref_set) / len(pred_top_k)
                precisions.append(precision)

        avg_precision = np.mean(precisions) if len(precisions) > 0 else 0.0
        elapsed = time.time() - start_time

        return MetricOutput(
            value=float(avg_precision),
            details={
                "k": self.k,
                "total_samples": len(predictions),
                "per_sample_precisions": precisions,
                "compute_time_seconds": elapsed,
            },
        )


@MetricRegistry.register("mrr")
class MRRMetric:
    """
    Mean Reciprocal Rank (MRR) for tool selection.

    Measures the average of reciprocal ranks of the first correct prediction.
    """

    name = "mrr"

    def __init__(self, k: int | None = None):
        """
        Initialize metric.

        Args:
            k: Optional cutoff (only consider top-k predictions)
        """
        self.k = k

    def compute(
        self, predictions: Sequence[list[str]], references: Sequence[list[str]]
    ) -> MetricOutput:
        """
        Compute MRR.

        Args:
            predictions: List of predicted tool ID lists
            references: List of reference tool ID lists

        Returns:
            MetricOutput with MRR value
        """
        start_time = time.time()

        reciprocal_ranks = []
        for pred, ref in zip(predictions, references):
            pred_list = pred if isinstance(pred, list) else [pred]
            if self.k is not None:
                pred_list = pred_list[: self.k]
            ref_set = set(ref) if isinstance(ref, list) else {ref}

            # Find rank of first correct prediction
            rr = 0.0
            for i, p in enumerate(pred_list):
                if p in ref_set:
                    rr = 1.0 / (i + 1)
                    break
            reciprocal_ranks.append(rr)

        mrr = np.mean(reciprocal_ranks) if len(reciprocal_ranks) > 0 else 0.0
        elapsed = time.time() - start_time

        return MetricOutput(
            value=float(mrr),
            details={
                "k": self.k,
                "total_samples": len(predictions),
                "per_sample_rr": reciprocal_ranks,
                "compute_time_seconds": elapsed,
            },
        )


@MetricRegistry.register("plan_success_rate")
class PlanSuccessRateMetric:
    """
    Plan success rate for task planning.

    Measures if the predicted tool sequence exactly matches reference.
    """

    name = "plan_success_rate"

    def __init__(self, allow_partial: bool = False):
        """
        Initialize metric.

        Args:
            allow_partial: If True, count partial sequence matches
        """
        self.allow_partial = allow_partial

    def compute(
        self, predictions: Sequence[list[str]], references: Sequence[list[str]]
    ) -> MetricOutput:
        """
        Compute plan success rate.

        Args:
            predictions: List of predicted tool sequences
            references: List of reference tool sequences

        Returns:
            MetricOutput with success rate
        """
        start_time = time.time()

        successes = 0
        partial_matches = []

        for pred, ref in zip(predictions, references):
            if pred == ref:
                successes += 1
                partial_matches.append(1.0)
            elif self.allow_partial:
                # Compute longest common subsequence ratio
                min_len = min(len(pred), len(ref))
                matches = sum(1 for p, r in zip(pred[:min_len], ref[:min_len]) if p == r)
                ratio = matches / len(ref) if len(ref) > 0 else 0.0
                partial_matches.append(ratio)
            else:
                partial_matches.append(0.0)

        success_rate = successes / len(predictions) if len(predictions) > 0 else 0.0
        elapsed = time.time() - start_time

        return MetricOutput(
            value=success_rate,
            details={
                "total_samples": len(predictions),
                "exact_matches": successes,
                "allow_partial": self.allow_partial,
                "partial_match_scores": partial_matches,
                "avg_partial_score": float(np.mean(partial_matches)) if partial_matches else 0.0,
                "compute_time_seconds": elapsed,
            },
        )


@MetricRegistry.register("step_accuracy")
class StepAccuracyMetric:
    """
    Step accuracy for task planning.

    Measures the average accuracy of individual steps in plans.
    """

    name = "step_accuracy"

    def compute(
        self, predictions: Sequence[list[str]], references: Sequence[list[str]]
    ) -> MetricOutput:
        """
        Compute step accuracy.

        Args:
            predictions: List of predicted tool sequences
            references: List of reference tool sequences

        Returns:
            MetricOutput with step accuracy
        """
        start_time = time.time()

        total_correct = 0
        total_steps = 0
        per_sample_accuracy = []

        for pred, ref in zip(predictions, references):
            if len(ref) == 0:
                per_sample_accuracy.append(0.0)
                continue

            # Compare up to the length of reference
            correct = 0
            for i, ref_tool in enumerate(ref):
                if i < len(pred) and pred[i] == ref_tool:
                    correct += 1

            total_correct += correct
            total_steps += len(ref)
            per_sample_accuracy.append(correct / len(ref))

        step_accuracy = total_correct / total_steps if total_steps > 0 else 0.0
        elapsed = time.time() - start_time

        return MetricOutput(
            value=step_accuracy,
            details={
                "total_samples": len(predictions),
                "total_correct_steps": total_correct,
                "total_reference_steps": total_steps,
                "per_sample_accuracy": per_sample_accuracy,
                "avg_sample_accuracy": float(np.mean(per_sample_accuracy))
                if per_sample_accuracy
                else 0.0,
                "compute_time_seconds": elapsed,
            },
        )


@MetricRegistry.register("sequence_match")
class SequenceMatchMetric:
    """
    Sequence match rate for task planning.

    Measures the proportion of samples where the predicted tool sequence
    exactly matches the reference sequence.
    """

    name = "sequence_match"

    def compute(
        self, predictions: Sequence[list[str]], references: Sequence[list[str]]
    ) -> MetricOutput:
        """
        Compute sequence match rate.

        Args:
            predictions: List of predicted tool sequences
            references: List of reference tool sequences

        Returns:
            MetricOutput with match rate
        """
        start_time = time.time()

        exact_matches = sum(1 for pred, ref in zip(predictions, references) if pred == ref)
        match_rate = exact_matches / len(predictions) if len(predictions) > 0 else 0.0
        elapsed = time.time() - start_time

        return MetricOutput(
            value=match_rate,
            details={
                "total_samples": len(predictions),
                "exact_matches": exact_matches,
                "compute_time_seconds": elapsed,
            },
        )


@MetricRegistry.register("timing_f1")
class TimingF1Metric:
    """
    F1 score for timing judgment.

    Measures binary classification performance for tool invocation timing.
    """

    name = "timing_f1"

    def compute(self, predictions: Sequence[bool], references: Sequence[bool]) -> MetricOutput:
        """
        Compute F1 score.

        Args:
            predictions: List of predicted decisions (True = call tool)
            references: List of reference decisions

        Returns:
            MetricOutput with F1 score
        """
        start_time = time.time()

        # Convert to numpy arrays for vectorized computation
        preds = np.array(predictions, dtype=bool)
        refs = np.array(references, dtype=bool)

        # Compute confusion matrix components
        true_positives = np.sum(preds & refs)
        false_positives = np.sum(preds & ~refs)
        false_negatives = np.sum(~preds & refs)
        true_negatives = np.sum(~preds & ~refs)

        # Compute precision, recall, F1
        precision = (
            true_positives / (true_positives + false_positives)
            if (true_positives + false_positives) > 0
            else 0.0
        )
        recall = (
            true_positives / (true_positives + false_negatives)
            if (true_positives + false_negatives) > 0
            else 0.0
        )
        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0

        accuracy = (
            (true_positives + true_negatives) / len(predictions) if len(predictions) > 0 else 0.0
        )
        elapsed = time.time() - start_time

        return MetricOutput(
            value=float(f1),
            details={
                "precision": float(precision),
                "recall": float(recall),
                "accuracy": float(accuracy),
                "true_positives": int(true_positives),
                "false_positives": int(false_positives),
                "false_negatives": int(false_negatives),
                "true_negatives": int(true_negatives),
                "total_samples": len(predictions),
                "compute_time_seconds": elapsed,
            },
        )


@MetricRegistry.register("timing_accuracy")
class TimingAccuracyMetric:
    """Accuracy metric for timing judgment."""

    name = "timing_accuracy"

    def compute(self, predictions: Sequence[bool], references: Sequence[bool]) -> MetricOutput:
        """
        Compute accuracy for timing judgment.

        Args:
            predictions: List of predicted decisions (True = call tool)
            references: List of reference decisions

        Returns:
            MetricOutput with accuracy value
        """
        start_time = time.time()

        preds = np.array(predictions, dtype=bool)
        refs = np.array(references, dtype=bool)

        correct = np.sum(preds == refs)
        accuracy = correct / len(predictions) if len(predictions) > 0 else 0.0

        # Also compute per-class accuracy
        tool_mask = refs
        no_tool_mask = ~refs

        tool_correct = np.sum((preds == refs) & tool_mask)
        tool_total = np.sum(tool_mask)
        tool_accuracy = tool_correct / tool_total if tool_total > 0 else 0.0

        no_tool_correct = np.sum((preds == refs) & no_tool_mask)
        no_tool_total = np.sum(no_tool_mask)
        no_tool_accuracy = no_tool_correct / no_tool_total if no_tool_total > 0 else 0.0

        elapsed = time.time() - start_time

        return MetricOutput(
            value=float(accuracy),
            details={
                "correct": int(correct),
                "total_samples": len(predictions),
                "tool_accuracy": float(tool_accuracy),
                "tool_correct": int(tool_correct),
                "tool_total": int(tool_total),
                "no_tool_accuracy": float(no_tool_accuracy),
                "no_tool_correct": int(no_tool_correct),
                "no_tool_total": int(no_tool_total),
                "compute_time_seconds": elapsed,
            },
        )


@MetricRegistry.register("timing_precision")
class TimingPrecisionMetric:
    """Precision for timing judgment."""

    name = "timing_precision"

    def compute(self, predictions: Sequence[bool], references: Sequence[bool]) -> MetricOutput:
        """Compute precision."""
        preds = np.array(predictions, dtype=bool)
        refs = np.array(references, dtype=bool)

        true_positives = np.sum(preds & refs)
        false_positives = np.sum(preds & ~refs)

        precision = (
            true_positives / (true_positives + false_positives)
            if (true_positives + false_positives) > 0
            else 0.0
        )

        return MetricOutput(
            value=float(precision),
            details={
                "true_positives": int(true_positives),
                "false_positives": int(false_positives),
            },
        )


@MetricRegistry.register("timing_recall")
class TimingRecallMetric:
    """Recall for timing judgment."""

    name = "timing_recall"

    def compute(self, predictions: Sequence[bool], references: Sequence[bool]) -> MetricOutput:
        """Compute recall."""
        preds = np.array(predictions, dtype=bool)
        refs = np.array(references, dtype=bool)

        true_positives = np.sum(preds & refs)
        false_negatives = np.sum(~preds & refs)

        recall = (
            true_positives / (true_positives + false_negatives)
            if (true_positives + false_negatives) > 0
            else 0.0
        )

        return MetricOutput(
            value=float(recall),
            details={
                "true_positives": int(true_positives),
                "false_negatives": int(false_negatives),
            },
        )


def load_metrics(metric_names: list[str], **kwargs) -> list[Any]:
    """
    Load metric instances from names.

    Args:
        metric_names: List of metric names to load
        **kwargs: Additional parameters for metric initialization

    Returns:
        List of instantiated metrics
    """
    metrics = []
    for name in metric_names:
        # Parse metric name with parameters (e.g., "top_k_accuracy@10")
        if "@" in name:
            metric_name, param = name.split("@")
            k = int(param)
            metric = MetricRegistry.get(metric_name, k=k, **kwargs)
        else:
            metric = MetricRegistry.get(name, **kwargs)
        metrics.append(metric)

    return metrics
