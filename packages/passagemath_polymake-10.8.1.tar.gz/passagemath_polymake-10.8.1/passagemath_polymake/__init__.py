# sage_setup: distribution = sagemath-polymake

from sage.all__sagemath_polymake import *
