"""Core types and utilities for QuantLite."""
