"""Financial instruments: options, bonds, and exotic derivatives."""
