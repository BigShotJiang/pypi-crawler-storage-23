# __init__.py

# Importiere die wichtigsten Klassen direkt in das Paket
from .win_nav_tui import UserInterface, SubsectionManager, Subsection, progressbar, clear, confirm

# Optional: Paketversion
__version__ = "0.1.5"