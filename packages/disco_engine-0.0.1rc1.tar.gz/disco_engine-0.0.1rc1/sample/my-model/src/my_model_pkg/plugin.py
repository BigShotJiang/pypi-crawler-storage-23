def model_package() -> str:
    return "my_model_pkg"
