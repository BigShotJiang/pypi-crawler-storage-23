# Corporate Contributor License Agreement (CCLA)

This Corporate Contributor License Agreement ("Agreement") is entered
into between the contributing organization ("Corporation") and the
project owner ("Project").

## 1. Grant of Copyright License

The Corporation hereby grants the Project a perpetual, worldwide,
non-exclusive, no-charge, royalty-free, irrevocable copyright license
to reproduce, prepare derivative works of, publicly display, publicly
perform, sublicense, and distribute contributions made by its employees.

## 2. Grant of Patent License

The Corporation hereby grants the Project a perpetual, worldwide,
non-exclusive, no-charge, royalty-free, irrevocable patent license
covering patent claims necessarily infringed by the contributions.

## 3. Authority

The Corporation represents that it has the legal authority to grant
these licenses and that contributions are made by authorized employees.

## 4. No Warranty

Contributions are provided on an "AS IS" basis.

---

Authorized Signature:
Name:
Title:
Organization:
Date: