"""a11y-ci: CI gate for a11y-lint scorecards (low-vision-first)."""

__version__ = "0.3.0"
