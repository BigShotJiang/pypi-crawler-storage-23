"""Signal handlers for django-taskly.

Connects to Django 6.0 Tasks API signals to capture task results as
:class:`~django_taskly.models.TaskSnapshot` rows automatically, without
requiring the application to call the collector explicitly.

The ``task_finished`` signal import is wrapped in ``try/except ImportError``
so this module remains importable on environments where ``django.tasks`` is
not yet available (older Django versions, minimal test setups, etc.).
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


def task_finished_handler(sender: Any, task_result: Any, **kwargs: Any) -> None:
    """Handle the ``task_finished`` signal emitted by the Django Tasks API.

    Creates or updates a :class:`~django_taskly.models.TaskSnapshot` for
    every finished task result, provided the ``ENABLED`` setting is ``True``.
    All exceptions are caught and logged so that a monitoring failure never
    crashes the running task or its caller.

    Args:
        sender: The task class or callable that sent the signal.
        task_result: The ``TaskResult`` instance produced by the finished task.
        **kwargs: Additional keyword arguments forwarded by the signal
            dispatcher (ignored).

    Returns:
        None
    """
    from django_taskly.config import get_taskly_setting

    try:
        enabled: bool = bool(get_taskly_setting("ENABLED"))
        if not enabled:
            logger.debug("django-taskly is disabled; skipping snapshot for finished task.")
            return

        from django_taskly.collector import TaskCollector

        collector = TaskCollector()
        collector.snapshot_from_result(task_result)
    except Exception:
        logger.exception(
            "django-taskly: unhandled exception in task_finished_handler for sender=%r task_result=%r. "
            "Monitoring failure suppressed to protect task execution.",
            sender,
            task_result,
        )
