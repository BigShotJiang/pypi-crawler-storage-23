"""Management command: taskly_cleanup.

Prunes :class:`~django_taskly.models.TaskSnapshot` rows that exceed the
configured retention limit, keeping only the most recently-updated snapshots.

Usage::

    # Delete snapshots beyond the MAX_SNAPSHOTS setting (default: 1000).
    python manage.py taskly_cleanup

    # Override the retention limit for this run.
    python manage.py taskly_cleanup --max-snapshots 500

    # Preview what would be deleted without touching the database.
    python manage.py taskly_cleanup --dry-run
    python manage.py taskly_cleanup --max-snapshots 200 --dry-run
"""

from __future__ import annotations

from typing import Any

from django.core.management.base import BaseCommand, CommandParser

from django_taskly.collector import TaskCollector
from django_taskly.config import get_taskly_setting
from django_taskly.models import TaskSnapshot


class Command(BaseCommand):
    """Django management command that removes excess :class:`~django_taskly.models.TaskSnapshot` rows.

    The command delegates actual deletion to
    :meth:`~django_taskly.collector.TaskCollector.cleanup`, which always
    preserves the *most recently-updated* rows up to the configured limit.
    Pass ``--dry-run`` to inspect the count that would be removed without
    modifying the database.
    """

    help = (
        "Remove the oldest TaskSnapshot rows that exceed the retention limit. "
        "Use --dry-run to preview the count without deleting."
    )

    def add_arguments(self, parser: CommandParser) -> None:
        """Register command-line arguments.

        Args:
            parser: The argument parser provided by Django's management
                framework.
        """
        parser.add_argument(
            "--max-snapshots",
            type=int,
            default=None,
            metavar="N",
            help=(
                "Maximum number of snapshots to retain. "
                "Defaults to the MAX_SNAPSHOTS setting "
                f"(currently {get_taskly_setting('MAX_SNAPSHOTS')})."
            ),
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            default=False,
            help="Print the number of snapshots that would be deleted without performing any deletion.",
        )

    def handle(self, *args: Any, **options: Any) -> None:
        """Execute the cleanup command.

        Reads ``--max-snapshots`` and ``--dry-run`` from *options*, then
        either performs the deletion via :class:`~django_taskly.collector.TaskCollector`
        or reports what would have been deleted when ``--dry-run`` is set.

        Args:
            *args: Positional arguments forwarded by Django (unused).
            **options: Parsed command-line options dict provided by Django.

        Returns:
            None
        """
        max_snapshots: int | None = options["max_snapshots"]
        dry_run: bool = options["dry_run"]

        # Resolve the effective limit the same way TaskCollector.cleanup() would.
        effective_limit: int = max_snapshots if max_snapshots is not None else int(get_taskly_setting("MAX_SNAPSHOTS"))

        total: int = TaskSnapshot.objects.count()
        to_delete: int = max(0, total - effective_limit)

        if dry_run:
            self.stdout.write(
                self.style.WARNING(
                    f"[dry-run] Would delete {to_delete} snapshot(s) (total={total}, limit={effective_limit})."
                )
            )
            return

        if to_delete == 0:
            self.stdout.write(
                self.style.SUCCESS(f"Nothing to delete: {total} snapshot(s) present, limit={effective_limit}.")
            )
            return

        collector = TaskCollector()
        deleted_count: int = collector.cleanup(max_snapshots=effective_limit)

        self.stdout.write(
            self.style.SUCCESS(f"Deleted {deleted_count} snapshot(s) (total was {total}, limit={effective_limit}).")
        )
