"""Settings helpers for django-taskly.

All consumer code must retrieve settings through :func:`get_taskly_setting`
rather than accessing ``django.conf.settings`` directly.  This keeps a single
source of truth for defaults and makes the setting names easy to document.

Example usage::

    from django_taskly.config import get_taskly_setting

    slow_threshold = get_taskly_setting("SLOW_TASK_SECONDS")
"""

from typing import Any

from django.conf import settings

DEFAULTS: dict[str, Any] = {
    "ENABLED": True,
    "SLOW_TASK_SECONDS": 5,
    "MAX_SNAPSHOTS": 1000,
    "DASHBOARD_TITLE": "Django Taskly",
}


def get_taskly_setting(name: str) -> Any:
    """Return the value of a django-taskly setting.

    Looks up *name* first inside ``settings.TASKLY`` (a plain dict), then
    falls back to :data:`DEFAULTS`.  Raises :class:`KeyError` if the setting
    is unknown so that typos surface immediately at call-time rather than
    silently returning ``None``.

    Args:
        name: The setting key, e.g. ``"SLOW_TASK_SECONDS"``.

    Returns:
        The resolved setting value.

    Raises:
        KeyError: If *name* is not a recognised django-taskly setting.

    Example::

        >>> get_taskly_setting("ENABLED")
        True
    """
    if name not in DEFAULTS:
        raise KeyError(f"Unknown django-taskly setting: '{name}'. Valid keys: {sorted(DEFAULTS)}")

    taskly_settings: dict[str, Any] = getattr(settings, "TASKLY", {})
    return taskly_settings.get(name, DEFAULTS[name])
