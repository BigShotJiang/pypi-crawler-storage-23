"""URL configuration for django-taskly.

Include these URLs in your project's ``urlconf`` under a chosen prefix::

    from django.urls import include, path

    urlpatterns = [
        path("taskly/", include("django_taskly.urls")),
    ]

The namespace ``django_taskly`` is declared here; the ``include()`` call
must **not** supply a redundant ``namespace`` kwarg when the ``app_name``
attribute is already set at module level.

URL names
---------
``django_taskly:dashboard``
    Main overview page — stats cards, slow tasks, recent tasks.
``django_taskly:task_list``
    Paginated, filterable, and searchable task snapshot list.
``django_taskly:task_detail``
    Single-snapshot detail page, looked up by ``task_id``.
``django_taskly:task_list_partial``
    HTMX partial — task table ``<tbody>`` rows only.
``django_taskly:dashboard_stats_partial``
    HTMX partial — stats cards only, for auto-refresh.
"""

from django.urls import path

from django_taskly import views

app_name = "django_taskly"

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("tasks/", views.task_list, name="task_list"),
    path("tasks/<str:task_id>/", views.task_detail, name="task_detail"),
    path("partials/task-list/", views.task_list_partial, name="task_list_partial"),
    path("partials/dashboard-stats/", views.dashboard_stats_partial, name="dashboard_stats_partial"),
    path("partials/dashboard-content/", views.dashboard_content_partial, name="dashboard_content_partial"),
]
