"""Task result collector for django-taskly.

:class:`TaskCollector` is responsible for translating Django 6.0 Tasks API
``TaskResult`` objects into :class:`~django_taskly.models.TaskSnapshot` rows.

Important constraints
---------------------
* ``from django.tasks import ...`` is wrapped in ``try/except ImportError``
  because the package must be importable even when ``django.tasks`` is not
  available (e.g. older Django versions, or running unit-tests without the
  full task machinery installed).
* ``ImmediateBackend.get_result()`` raises :class:`NotImplementedError` — any
  call path that touches result attributes must guard against this.
* Status comparison uses ``result.status.value`` (the string representation),
  never ``result.status`` directly.
* :class:`~django_taskly.models.TaskSnapshot` properties are **never** mutated
  directly; changes go through ``update_or_create``.
"""

from __future__ import annotations

import logging
from collections.abc import Iterable
from typing import Any

from django_taskly.config import get_taskly_setting
from django_taskly.models import TaskSnapshot

try:
    from django.tasks import TaskResult  # type: ignore[import-not-found]

    _TASKS_AVAILABLE = True
except ImportError:
    _TASKS_AVAILABLE = False
    TaskResult = Any  # type: ignore[assignment,misc]

logger = logging.getLogger(__name__)


def _safe_get(obj: Any, attr: str, default: Any = None) -> Any:
    """Return ``getattr(obj, attr, default)`` while suppressing ``NotImplementedError``.

    ``ImmediateBackend`` raises :class:`NotImplementedError` for several
    result properties.  This helper centralises that guard so callers stay
    readable.

    Args:
        obj: The object to introspect.
        attr: Attribute name to retrieve.
        default: Value to return if the attribute is missing or raises
            ``NotImplementedError``.

    Returns:
        The attribute value or *default*.
    """
    try:
        return getattr(obj, attr, default)
    except NotImplementedError:
        logger.debug("NotImplementedError accessing '%s' on %r — using default %r", attr, obj, default)
        return default


class TaskCollector:
    """Collects Django Tasks API results and persists them as :class:`~django_taskly.models.TaskSnapshot` rows.

    Typical usage::

        from django_taskly.collector import TaskCollector

        collector = TaskCollector()
        snapshot = collector.snapshot_from_result(result)

    All public methods emit structured log records so that operators can
    monitor collection activity without coupling to ``print()``.
    """

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def snapshot_from_result(self, result: Any) -> TaskSnapshot:
        """Create or update a :class:`~django_taskly.models.TaskSnapshot` from a task result.

        Reads fields from *result* defensively: any attribute access that raises
        :class:`NotImplementedError` (as ``ImmediateBackend`` may do) is caught
        and replaced with a safe default value.

        Args:
            result: A Django 6.0 ``TaskResult`` instance.

        Returns:
            The created-or-updated :class:`~django_taskly.models.TaskSnapshot`.

        Raises:
            Exception: Re-raises unexpected exceptions after logging them so
                that callers can decide whether to swallow or propagate.
        """
        task_id: str = str(_safe_get(result, "id", ""))
        if not task_id:
            logger.warning("Received a result with no id; skipping snapshot creation.")
            # Return an unsaved sentinel so callers always get a TaskSnapshot back.
            return TaskSnapshot(task_id="", task_name="unknown", task_module="", status=TaskSnapshot.Status.PENDING)

        task_obj = _safe_get(result, "task", None)
        # Django 6.0: result.task is a Task dataclass with a .func attribute
        # holding the actual callable.  Fall back to reading __name__ directly
        # for compatibility with mocks and older patterns.
        task_func = getattr(task_obj, "func", task_obj) if task_obj is not None else None
        task_name: str = getattr(task_func, "__name__", "unknown") if task_func is not None else "unknown"
        task_module: str = getattr(task_func, "__module__", "") if task_func is not None else ""

        # status.value gives us the string representation ("PENDING", "FAILED", …)
        raw_status_obj = _safe_get(result, "status", None)
        status_value: str = TaskSnapshot.Status.PENDING
        if raw_status_obj is not None:
            try:
                status_value = raw_status_obj.value
            except (AttributeError, NotImplementedError):
                logger.debug("Could not read status.value for task %s; defaulting to PENDING.", task_id)

        backend: str = str(_safe_get(result, "backend", ""))

        enqueued_at = _safe_get(result, "enqueued_at", None)
        started_at = _safe_get(result, "started_at", None)
        finished_at = _safe_get(result, "finished_at", None)

        duration_seconds: float | None = self._calculate_duration(started_at, finished_at)

        attempts: int = int(_safe_get(result, "attempts", 0) or 0)

        last_error_class, last_error_traceback = self._extract_error_info(result)

        defaults: dict[str, Any] = {
            "task_name": task_name,
            "task_module": task_module,
            "status": status_value,
            "backend": backend,
            "enqueued_at": enqueued_at,
            "started_at": started_at,
            "finished_at": finished_at,
            "duration_seconds": duration_seconds,
            "attempts": attempts,
            "last_error_class": last_error_class,
            "last_error_traceback": last_error_traceback,
        }

        try:
            snapshot, created = TaskSnapshot.objects.update_or_create(
                task_id=task_id,
                defaults=defaults,
            )
        except Exception:
            logger.exception("Failed to upsert TaskSnapshot for task_id=%s", task_id)
            raise

        action = "Created" if created else "Updated"
        logger.debug("%s TaskSnapshot id=%s task_name=%s status=%s", action, task_id, task_name, status_value)
        return snapshot

    def collect_all(self, results: Iterable[Any]) -> list[TaskSnapshot]:
        """Snapshot every result in *results*, skipping individual failures.

        Args:
            results: An iterable of Django 6.0 ``TaskResult`` instances.

        Returns:
            List of :class:`~django_taskly.models.TaskSnapshot` instances that
            were successfully created or updated.
        """
        snapshots: list[TaskSnapshot] = []
        for result in results:
            try:
                snapshot = self.snapshot_from_result(result)
                snapshots.append(snapshot)
            except Exception:
                logger.exception("Skipping result due to unexpected error during snapshot_from_result.")
        logger.info("collect_all completed: %d snapshot(s) processed.", len(snapshots))
        return snapshots

    def cleanup(self, max_snapshots: int | None = None) -> int:
        """Delete the oldest snapshots beyond the configured retention limit.

        The retention limit is read from ``MAX_SNAPSHOTS`` via
        :func:`~django_taskly.config.get_taskly_setting` unless *max_snapshots*
        is provided explicitly.

        Args:
            max_snapshots: Override for the maximum number of snapshots to
                retain.  When ``None`` the value from settings is used.

        Returns:
            The number of rows deleted.
        """
        limit: int = max_snapshots if max_snapshots is not None else int(get_taskly_setting("MAX_SNAPSHOTS"))

        total: int = TaskSnapshot.objects.count()
        to_delete: int = max(0, total - limit)

        if to_delete == 0:
            logger.debug("cleanup: %d snapshot(s) present, limit=%d — nothing to delete.", total, limit)
            return 0

        # Identify the PKs of the oldest rows (smallest updated_at) that
        # push us over the limit, then delete them in a single query.
        oldest_pks = TaskSnapshot.objects.order_by("updated_at").values_list("pk", flat=True)[:to_delete]
        deleted_count, _ = TaskSnapshot.objects.filter(pk__in=list(oldest_pks)).delete()
        logger.info(
            "cleanup: deleted %d snapshot(s) (total was %d, limit=%d).",
            deleted_count,
            total,
            limit,
        )
        return deleted_count

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _calculate_duration(started_at: Any, finished_at: Any) -> float | None:
        """Return wall-clock seconds between *started_at* and *finished_at*.

        Args:
            started_at: A timezone-aware ``datetime`` or ``None``.
            finished_at: A timezone-aware ``datetime`` or ``None``.

        Returns:
            Duration in seconds as a float, or ``None`` if either timestamp
            is absent.
        """
        if started_at is None or finished_at is None:
            return None
        try:
            delta = finished_at - started_at
            return delta.total_seconds()
        except (TypeError, AttributeError):
            logger.debug("Could not compute duration from started_at=%r finished_at=%r", started_at, finished_at)
            return None

    @staticmethod
    def _extract_error_info(result: Any) -> tuple[str, str]:
        """Extract the exception class name and traceback from the last error.

        Django Tasks stores errors in ``result.errors`` as a sequence of error
        objects.  This method reads the *last* entry (most recent attempt) and
        pulls out the exception class and traceback string.

        Args:
            result: A Django 6.0 ``TaskResult`` instance.

        Returns:
            A 2-tuple of ``(error_class_name, traceback_string)``.  Both
            elements are empty strings when no error is present or when the
            attribute is not accessible.
        """
        errors = _safe_get(result, "errors", None)
        if not errors:
            return "", ""

        try:
            last_error = errors[-1]
        except (IndexError, TypeError):
            return "", ""

        exception_class: str = ""
        traceback_text: str = ""

        try:
            exc = _safe_get(last_error, "exception", None)
            if exc is not None:
                exc_type = type(exc)
                exception_class = f"{exc_type.__module__}.{exc_type.__qualname__}"
        except Exception:
            logger.debug("Could not extract exception_class from last error on result %r", result)

        try:
            traceback_text = str(_safe_get(last_error, "traceback", "") or "")
        except Exception:
            logger.debug("Could not extract traceback from last error on result %r", result)

        return exception_class, traceback_text
