"""Django admin configuration for django-taskly.

Registers :class:`~django_taskly.models.TaskSnapshot` with a read-only,
full-featured :class:`TaskSnapshotAdmin` that surfaces status colouring,
human-readable duration formatting, and a slow-task indicator.

All mutations (add, change) are disabled because snapshots are managed
exclusively by :class:`~django_taskly.collector.TaskCollector`.  Deletion
is intentionally preserved so that operators can prune old records directly
from the admin interface.
"""

from __future__ import annotations

import logging
from typing import Any

from django.contrib import admin
from django.http import HttpRequest
from django.utils.html import format_html
from django.utils.safestring import SafeString

from django_taskly.models import TaskSnapshot

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Colour palette — intentionally small so it is easy to override in tests.
# ---------------------------------------------------------------------------

_STATUS_COLOURS: dict[str, str] = {
    TaskSnapshot.Status.SUCCESSFUL: "#2e7d32",  # green
    TaskSnapshot.Status.FAILED: "#c62828",  # red
    TaskSnapshot.Status.RUNNING: "#1565c0",  # blue
    TaskSnapshot.Status.PENDING: "#e65100",  # orange
}


@admin.register(TaskSnapshot)
class TaskSnapshotAdmin(admin.ModelAdmin):  # type: ignore[type-arg]
    """Admin class for :class:`~django_taskly.models.TaskSnapshot`.

    Provides a read-only view of every captured task invocation.  Custom
    display columns offer at-a-glance status colouring, formatted duration,
    and a boolean indicator for slow tasks.

    Mutations are blocked via :meth:`has_add_permission` and
    :meth:`has_change_permission`.  Deletion is allowed so operators can
    clean up stale rows without needing shell access.
    """

    # ------------------------------------------------------------------
    # List view configuration
    # ------------------------------------------------------------------

    list_display: tuple[str, ...] = (
        "task_name",
        "task_module",
        "status_colored",
        "backend",
        "enqueued_at",
        "started_at",
        "finished_at",
        "duration_display",
        "attempts",
        "is_slow_display",
    )
    list_filter: tuple[str, ...] = ("status", "backend", "created_at")
    search_fields: tuple[str, ...] = (
        "task_id",
        "task_name",
        "task_module",
        "last_error_class",
    )
    ordering: list[str] = ["-updated_at"]
    list_per_page: int = 50
    date_hierarchy: str = "created_at"

    # ------------------------------------------------------------------
    # Detail view configuration
    # ------------------------------------------------------------------

    readonly_fields: tuple[str, ...] = (
        # Identity
        "task_id",
        "task_name",
        "task_module",
        # Status & backend
        "status",
        "backend",
        # Timing
        "enqueued_at",
        "started_at",
        "finished_at",
        "duration_seconds",
        # Attempts & errors
        "attempts",
        "last_error_class",
        "last_error_traceback",
        # Audit
        "created_at",
        "updated_at",
    )

    fieldsets: tuple[tuple[str, Any], ...] = (
        (
            "Identity",
            {
                "fields": ("task_id", "task_name", "task_module"),
            },
        ),
        (
            "Status & Backend",
            {
                "fields": ("status", "backend"),
            },
        ),
        (
            "Timing",
            {
                "fields": ("enqueued_at", "started_at", "finished_at", "duration_seconds"),
            },
        ),
        (
            "Attempts & Errors",
            {
                "fields": ("attempts", "last_error_class", "last_error_traceback"),
            },
        ),
        (
            "Audit",
            {
                "fields": ("created_at", "updated_at"),
            },
        ),
    )

    # ------------------------------------------------------------------
    # Custom display methods
    # ------------------------------------------------------------------

    @admin.display(description="Status", ordering="status")
    def status_colored(self, obj: TaskSnapshot) -> SafeString:
        """Render the task status as a coloured HTML badge.

        The colour is determined by :data:`_STATUS_COLOURS`.  Unknown status
        values are rendered in plain text without any inline style so that the
        admin remains functional even if the ``Status`` choices are extended in
        a future version without updating this method.

        Args:
            obj: The :class:`~django_taskly.models.TaskSnapshot` row being
                rendered.

        Returns:
            A :class:`~django.utils.safestring.SafeString` containing an
            ``<span>`` element with an inline ``color`` style, or the raw
            status value when no colour mapping exists.
        """
        colour = _STATUS_COLOURS.get(obj.status)
        label = obj.get_status_display()

        if colour is None:
            logger.debug("No colour mapping for status %r on snapshot pk=%s", obj.status, obj.pk)
            return format_html("{}", label)

        return format_html(
            '<span style="color: {}; font-weight: bold;">{}</span>',
            colour,
            label,
        )

    @admin.display(description="Duration", ordering="duration_seconds")
    def duration_display(self, obj: TaskSnapshot) -> str:
        """Format :attr:`~django_taskly.models.TaskSnapshot.duration_seconds` for display.

        Renders the duration as ``"X.XXs"`` (two decimal places) when the
        field is populated, or an em-dash when the task has not yet finished.

        Args:
            obj: The :class:`~django_taskly.models.TaskSnapshot` row being
                rendered.

        Returns:
            A human-readable duration string, e.g. ``"2.50s"``, or ``"—"``
            when :attr:`~django_taskly.models.TaskSnapshot.duration_seconds`
            is ``None``.
        """
        if obj.duration_seconds is None:
            return "\u2014"  # em dash
        return f"{obj.duration_seconds:.2f}s"

    @admin.display(description="Slow?", boolean=True, ordering="duration_seconds")
    def is_slow_display(self, obj: TaskSnapshot) -> bool:
        """Indicate whether the task exceeded the slow-task threshold.

        Delegates directly to :attr:`~django_taskly.models.TaskSnapshot.is_slow`
        so that the admin always reflects the same threshold logic as the rest
        of the package.  The ``boolean=True`` flag on the decorator causes
        Django admin to render a green tick or red cross icon instead of the
        raw ``True``/``False`` text.

        Args:
            obj: The :class:`~django_taskly.models.TaskSnapshot` row being
                rendered.

        Returns:
            ``True`` when the task is considered slow, ``False`` otherwise.
        """
        return obj.is_slow

    # ------------------------------------------------------------------
    # Permission overrides
    # ------------------------------------------------------------------

    def has_add_permission(self, request: HttpRequest) -> bool:
        """Disable add permission — snapshots are created by the collector only.

        Args:
            request: The current HTTP request.

        Returns:
            Always ``False``.
        """
        return False

    def has_change_permission(
        self,
        request: HttpRequest,
        obj: TaskSnapshot | None = None,
    ) -> bool:
        """Disable change permission — snapshots are immutable from the admin.

        Args:
            request: The current HTTP request.
            obj: The specific :class:`~django_taskly.models.TaskSnapshot`
                instance being viewed, or ``None`` for the list view.

        Returns:
            Always ``False``.
        """
        return False

    def has_delete_permission(
        self,
        request: HttpRequest,
        obj: TaskSnapshot | None = None,
    ) -> bool:
        """Allow delete permission so operators can prune stale snapshots.

        Args:
            request: The current HTTP request.
            obj: The specific :class:`~django_taskly.models.TaskSnapshot`
                instance being considered for deletion, or ``None`` when
                evaluating bulk delete eligibility.

        Returns:
            Delegates to the parent implementation, which checks
            ``django_taskly.delete_tasksnapshot`` permission on the user.
        """
        return super().has_delete_permission(request, obj)
