"""Dashboard and monitoring views for django-taskly.

All views are protected by :func:`~django.contrib.admin.views.decorators.staff_member_required`
and render templates that extend ``admin/base_site.html`` to integrate
seamlessly with the Django admin UI.

HTMX partial views are provided for live stat refresh and filtered task
list updates without full-page reloads.
"""

from __future__ import annotations

import logging
from typing import Any

from django.contrib.admin.views.decorators import staff_member_required
from django.core.paginator import Page, Paginator
from django.http import HttpRequest, HttpResponse
from django.shortcuts import get_object_or_404, render

from django_taskly.config import get_taskly_setting
from django_taskly.models import TaskSnapshot

logger = logging.getLogger(__name__)

_PAGE_SIZE: int = 25
_SLOW_TASK_LIMIT: int = 10
_RECENT_TASK_LIMIT: int = 20


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _build_task_queryset(
    status_filter: str,
    search_query: str,
) -> Any:
    """Return a filtered :class:`~django_taskly.models.TaskSnapshot` queryset.

    Applies an optional status filter and/or a case-insensitive task_name
    search.  The queryset is always ordered by ``-updated_at``.

    Args:
        status_filter: A :class:`~django_taskly.models.TaskSnapshot.Status`
            value (e.g. ``"FAILED"``), or an empty string to skip filtering.
        search_query: Substring to match against ``task_name``
            (case-insensitive), or an empty string to skip searching.

    Returns:
        A :class:`~django.db.models.QuerySet` of
        :class:`~django_taskly.models.TaskSnapshot` instances.
    """
    qs = TaskSnapshot.objects.all()

    valid_statuses = {choice[0] for choice in TaskSnapshot.Status.choices}
    if status_filter and status_filter in valid_statuses:
        qs = qs.filter(status=status_filter)
        logger.debug("task queryset filtered by status=%r", status_filter)

    if search_query:
        qs = qs.filter(task_name__icontains=search_query)
        logger.debug("task queryset filtered by task_name__icontains=%r", search_query)

    return qs


def _compute_success_rate(total: int, successful_count: int) -> float:
    """Compute the success rate as a percentage rounded to one decimal place.

    Args:
        total: Total number of task snapshots.
        successful_count: Number of snapshots with status SUCCESSFUL.

    Returns:
        Success rate as a float between 0.0 and 100.0, or 0.0 when *total*
        is zero to avoid :class:`ZeroDivisionError`.
    """
    if total == 0:
        return 0.0
    return round((successful_count / total) * 100, 1)


# ---------------------------------------------------------------------------
# Full-page views
# ---------------------------------------------------------------------------


def _dashboard_context() -> dict[str, Any]:
    """Build the shared context dict used by the dashboard and its partial."""
    total_tasks: int = TaskSnapshot.objects.count()
    successful_count: int = TaskSnapshot.objects.successful().count()
    failed_count: int = TaskSnapshot.objects.failed().count()
    slow_tasks = TaskSnapshot.objects.slow()[:_SLOW_TASK_LIMIT]
    recent_tasks = TaskSnapshot.objects.recent()[:_RECENT_TASK_LIMIT]
    success_rate: float = _compute_success_rate(total_tasks, successful_count)

    logger.debug(
        "dashboard: total=%d successful=%d failed=%d success_rate=%.1f%%",
        total_tasks,
        successful_count,
        failed_count,
        success_rate,
    )

    return {
        "title": get_taskly_setting("DASHBOARD_TITLE"),
        "total_tasks": total_tasks,
        "successful_count": successful_count,
        "failed_count": failed_count,
        "slow_tasks": slow_tasks,
        "recent_tasks": recent_tasks,
        "success_rate": success_rate,
    }


@staff_member_required
def dashboard(request: HttpRequest) -> HttpResponse:
    """Render the main django-taskly dashboard.

    Displays summary statistics, a slow-tasks table, and a recent-tasks
    table.  Stats cards are auto-refreshed every 30 seconds via HTMX.

    Args:
        request: The current HTTP request.  Must be from a staff member.

    Returns:
        Rendered ``django_taskly/dashboard.html`` with dashboard context.
    """
    return render(request, "django_taskly/dashboard.html", _dashboard_context())


@staff_member_required
def task_list(request: HttpRequest) -> HttpResponse:
    """Render the full task list with optional filtering, search, and pagination.

    Accepts the following query parameters:

    * ``status`` — filter by :class:`~django_taskly.models.TaskSnapshot.Status`
      value (e.g. ``?status=FAILED``).
    * ``q`` — case-insensitive substring search against ``task_name``
      (e.g. ``?q=send_email``).

    Results are paginated at :data:`_PAGE_SIZE` rows per page.

    Args:
        request: The current HTTP request.  Must be from a staff member.

    Returns:
        Rendered ``django_taskly/task_list.html`` with list context.
    """
    status_filter: str = request.GET.get("status", "").strip()
    search_query: str = request.GET.get("q", "").strip()

    qs = _build_task_queryset(status_filter, search_query)
    paginator = Paginator(qs, _PAGE_SIZE)
    page_number: str = request.GET.get("page", "1")

    try:
        page_obj: Page = paginator.get_page(page_number)
    except Exception:
        logger.warning("Invalid page number %r; falling back to page 1.", page_number)
        page_obj = paginator.get_page(1)

    context: dict[str, Any] = {
        "tasks": page_obj,
        "status_filter": status_filter,
        "search_query": search_query,
        "statuses": TaskSnapshot.Status.choices,
    }
    return render(request, "django_taskly/task_list.html", context)


@staff_member_required
def task_detail(request: HttpRequest, task_id: str) -> HttpResponse:
    """Render the detail page for a single task snapshot.

    Looks up the snapshot by :attr:`~django_taskly.models.TaskSnapshot.task_id`
    (the Django Tasks API identifier), *not* the database primary key.

    Args:
        request: The current HTTP request.  Must be from a staff member.
        task_id: The value of
            :attr:`~django_taskly.models.TaskSnapshot.task_id` to look up.

    Returns:
        Rendered ``django_taskly/task_detail.html`` with the snapshot object,
        or a 404 response when no matching snapshot exists.
    """
    task: TaskSnapshot = get_object_or_404(TaskSnapshot, task_id=task_id)
    logger.debug("task_detail: rendering snapshot task_id=%r pk=%d", task_id, task.pk)

    context: dict[str, Any] = {"task": task}
    return render(request, "django_taskly/task_detail.html", context)


# ---------------------------------------------------------------------------
# HTMX partial views
# ---------------------------------------------------------------------------


@staff_member_required
def task_list_partial(request: HttpRequest) -> HttpResponse:
    """Return the task table ``<tbody>`` rows for an HTMX swap.

    Accepts the same ``status`` and ``q`` query parameters as
    :func:`task_list` and applies pagination via the ``page`` parameter.
    The response renders only ``partials/task_table.html`` — no surrounding
    admin chrome — so HTMX can swap it directly into the table body.

    Args:
        request: The current HTTP request.  Must be from a staff member.

    Returns:
        Rendered ``django_taskly/partials/task_table.html`` fragment.
    """
    status_filter: str = request.GET.get("status", "").strip()
    search_query: str = request.GET.get("q", "").strip()

    qs = _build_task_queryset(status_filter, search_query)
    paginator = Paginator(qs, _PAGE_SIZE)
    page_number: str = request.GET.get("page", "1")

    try:
        page_obj: Page = paginator.get_page(page_number)
    except Exception:
        logger.warning("task_list_partial: invalid page %r; falling back to 1.", page_number)
        page_obj = paginator.get_page(1)

    context: dict[str, Any] = {
        "tasks": page_obj,
        "status_filter": status_filter,
        "search_query": search_query,
    }
    return render(request, "django_taskly/partials/task_table.html", context)


@staff_member_required
def dashboard_stats_partial(request: HttpRequest) -> HttpResponse:
    """Return the dashboard stats cards fragment for an HTMX swap.

    Computes the same aggregate values as :func:`dashboard` and renders
    only ``partials/dashboard_stats.html``.  Intended to be polled every
    30 seconds by the dashboard page so the stat cards stay current without
    a full-page reload.

    Args:
        request: The current HTTP request.  Must be from a staff member.

    Returns:
        Rendered ``django_taskly/partials/dashboard_stats.html`` fragment.
    """
    total_tasks: int = TaskSnapshot.objects.count()
    successful_count: int = TaskSnapshot.objects.successful().count()
    failed_count: int = TaskSnapshot.objects.failed().count()
    success_rate: float = _compute_success_rate(total_tasks, successful_count)

    logger.debug(
        "dashboard_stats_partial: total=%d successful=%d failed=%d success_rate=%.1f%%",
        total_tasks,
        successful_count,
        failed_count,
        success_rate,
    )

    context: dict[str, Any] = {
        "total_tasks": total_tasks,
        "successful_count": successful_count,
        "failed_count": failed_count,
        "success_rate": success_rate,
    }
    return render(request, "django_taskly/partials/dashboard_stats.html", context)


@staff_member_required
def dashboard_content_partial(request: HttpRequest) -> HttpResponse:
    """Return the full dashboard content (stats + tables) for an HTMX swap.

    Used by the manual Refresh button and the auto-refresh timer so the
    page never fully reloads and client-side state (e.g. auto-refresh
    toggle) is preserved.

    Args:
        request: The current HTTP request.  Must be from a staff member.

    Returns:
        Rendered ``django_taskly/partials/dashboard_content.html`` fragment.
    """
    return render(request, "django_taskly/partials/dashboard_content.html", _dashboard_context())
