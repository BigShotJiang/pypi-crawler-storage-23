"""Database models for django-taskly.

:class:`TaskSnapshot` is the central model: one row per task invocation,
kept in sync by :class:`~django_taskly.collector.TaskCollector`.
"""

from __future__ import annotations

import logging
from datetime import timedelta
from typing import ClassVar

from django.db import models
from django.utils import timezone

from django_taskly.config import get_taskly_setting

logger = logging.getLogger(__name__)


class TaskSnapshotManager(models.Manager["TaskSnapshot"]):
    """Custom queryset manager for :class:`TaskSnapshot`.

    Provides convenience filter methods used throughout the dashboard and
    cleanup logic.
    """

    def failed(self) -> models.QuerySet[TaskSnapshot]:
        """Return all snapshots whose status is FAILED.

        Returns:
            QuerySet filtered to status=FAILED.
        """
        return self.filter(status=TaskSnapshot.Status.FAILED)

    def successful(self) -> models.QuerySet[TaskSnapshot]:
        """Return all snapshots whose status is SUCCESSFUL.

        Returns:
            QuerySet filtered to status=SUCCESSFUL.
        """
        return self.filter(status=TaskSnapshot.Status.SUCCESSFUL)

    def slow(self) -> models.QuerySet[TaskSnapshot]:
        """Return snapshots whose duration exceeds the SLOW_TASK_SECONDS threshold.

        Reads :data:`~django_taskly.config.DEFAULTS` via
        :func:`~django_taskly.config.get_taskly_setting` so that the
        threshold is always honoured without hard-coding a value here.

        Returns:
            QuerySet of slow task snapshots, ordered by ``-duration_seconds``.
        """
        threshold: float = get_taskly_setting("SLOW_TASK_SECONDS")
        return self.filter(duration_seconds__gt=threshold).order_by("-duration_seconds")

    def recent(self, hours: int = 24) -> models.QuerySet[TaskSnapshot]:
        """Return snapshots updated within the last *hours* hours.

        Args:
            hours: Look-back window in hours.  Defaults to 24.

        Returns:
            QuerySet of recently-updated snapshots.
        """
        cutoff = timezone.now() - timedelta(hours=hours)
        return self.filter(updated_at__gte=cutoff)


class TaskSnapshot(models.Model):
    """Persisted snapshot of a single Django Tasks API task result.

    One row is created (or updated) each time
    :meth:`~django_taskly.collector.TaskCollector.snapshot_from_result` is
    called.  The row is identified by :attr:`task_id` which maps 1-to-1 to
    a ``TaskResult.id``.
    """

    class Status(models.TextChoices):
        """Mirrors the status values emitted by ``django.tasks``."""

        PENDING = "PENDING", "Pending"
        RUNNING = "RUNNING", "Running"
        SUCCESSFUL = "SUCCESSFUL", "Successful"
        FAILED = "FAILED", "Failed"

    # ------------------------------------------------------------------
    # Identity fields
    # ------------------------------------------------------------------

    task_id: models.CharField = models.CharField(
        max_length=255,
        unique=True,
        db_index=True,
        help_text="Unique identifier from TaskResult.id.",
    )
    task_name: models.CharField = models.CharField(
        max_length=255,
        db_index=True,
        help_text="The __name__ of the task callable.",
    )
    task_module: models.CharField = models.CharField(
        max_length=500,
        help_text="The __module__ of the task callable.",
    )

    # ------------------------------------------------------------------
    # Status & backend
    # ------------------------------------------------------------------

    status: models.CharField = models.CharField(
        max_length=50,
        choices=Status.choices,
        default=Status.PENDING,
        db_index=True,
        help_text="Last known execution status.",
    )
    backend: models.CharField = models.CharField(
        max_length=255,
        help_text="Dotted-path of the backend used to execute this task.",
    )

    # ------------------------------------------------------------------
    # Timing
    # ------------------------------------------------------------------

    enqueued_at: models.DateTimeField = models.DateTimeField(
        null=True,
        blank=True,
        help_text="When the task was placed on the queue.",
    )
    started_at: models.DateTimeField = models.DateTimeField(
        null=True,
        blank=True,
        help_text="When execution started.",
    )
    finished_at: models.DateTimeField = models.DateTimeField(
        null=True,
        blank=True,
        help_text="When execution finished (success or failure).",
    )
    duration_seconds: models.FloatField = models.FloatField(
        null=True,
        blank=True,
        help_text="Wall-clock seconds between started_at and finished_at.",
    )

    # ------------------------------------------------------------------
    # Attempts & errors
    # ------------------------------------------------------------------

    attempts: models.PositiveIntegerField = models.PositiveIntegerField(
        default=0,
        help_text="Number of execution attempts made so far.",
    )
    last_error_class: models.CharField = models.CharField(
        max_length=255,
        blank=True,
        default="",
        help_text="Dotted name of the exception class from the last failure.",
    )
    last_error_traceback: models.TextField = models.TextField(
        blank=True,
        default="",
        help_text="Full traceback text from the last failure.",
    )

    # ------------------------------------------------------------------
    # Audit timestamps
    # ------------------------------------------------------------------

    created_at: models.DateTimeField = models.DateTimeField(auto_now_add=True)
    updated_at: models.DateTimeField = models.DateTimeField(auto_now=True)

    objects: ClassVar[TaskSnapshotManager] = TaskSnapshotManager()

    class Meta:
        ordering = ["-updated_at"]
        verbose_name = "Task Snapshot"
        verbose_name_plural = "Task Snapshots"

    def __str__(self) -> str:
        return f"{self.task_name} ({self.status})"

    # ------------------------------------------------------------------
    # Computed properties
    # ------------------------------------------------------------------

    @property
    def is_slow(self) -> bool:
        """Return ``True`` when this task's duration exceeds the configured threshold.

        Reads ``SLOW_TASK_SECONDS`` via
        :func:`~django_taskly.config.get_taskly_setting`.  Returns
        ``False`` if :attr:`duration_seconds` is ``None`` (i.e. the task has
        not finished yet).

        Returns:
            Boolean indicating whether the task is considered slow.
        """
        if self.duration_seconds is None:
            return False
        threshold: float = get_taskly_setting("SLOW_TASK_SECONDS")
        return self.duration_seconds > threshold
