"""django-taskly — Django 6.0 Tasks API monitoring and admin panel."""

__version__ = "0.1.0"
