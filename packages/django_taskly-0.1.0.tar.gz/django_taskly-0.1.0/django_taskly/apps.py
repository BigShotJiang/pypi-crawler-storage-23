"""AppConfig for django_taskly."""

from django.apps import AppConfig


class DjangoTasklyConfig(AppConfig):
    """Application configuration for django-taskly.

    Registers the app under the label ``django_taskly`` and sets sensible
    defaults for auto-created primary keys.  The :meth:`ready` hook connects
    the :func:`~django_taskly.signals.task_finished_handler` to the Django
    Tasks API ``task_finished`` signal when that signal is available.
    """

    name = "django_taskly"
    verbose_name = "Django Taskly"
    default_auto_field = "django.db.models.BigAutoField"

    def ready(self) -> None:
        """Connect signal handlers once the app registry is fully populated.

        Imports are deferred to :meth:`ready` to avoid triggering model
        lookups before Django's application registry is initialised.  The
        ``task_finished`` signal import is guarded by ``try/except ImportError``
        so the app remains functional on Django versions that do not ship
        ``django.tasks``.

        Returns:
            None
        """
        from django_taskly.signals import task_finished_handler

        try:
            from django.tasks.signals import task_finished  # type: ignore[import-not-found]

            task_finished.connect(task_finished_handler)
            import logging

            logging.getLogger(__name__).debug("django-taskly: task_finished signal connected to task_finished_handler.")
        except ImportError:
            import logging

            logging.getLogger(__name__).warning(
                "django-taskly: django.tasks.signals not available — "
                "automatic snapshot collection via signal is disabled."
            )
