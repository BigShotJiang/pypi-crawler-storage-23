"""Tests for django_taskly views and URL configuration.

Covers:
- Authentication/authorisation guards (anonymous + non-staff → redirect).
- Dashboard view context and template rendering.
- Task list filtering (by status, by search query, combined).
- Task list pagination.
- Task detail view (found / not-found).
- HTMX partial views (task_list_partial, dashboard_stats_partial).
- URL namespace resolution.
- Edge cases: zero tasks, division-by-zero in success_rate, bad page number.
"""

from __future__ import annotations

from datetime import timedelta

import pytest
from django.contrib.auth import get_user_model
from django.test import Client
from django.urls import reverse
from django.utils import timezone

from django_taskly.models import TaskSnapshot

User = get_user_model()

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def staff_client(db) -> Client:
    """Return a :class:`~django.test.Client` authenticated as a staff user."""
    user = User.objects.create_user(
        username="staff",
        password="pass",
        is_staff=True,
    )
    client = Client()
    client.force_login(user)
    return client


@pytest.fixture()
def anon_client(db) -> Client:
    """Return an unauthenticated :class:`~django.test.Client`."""
    return Client()


@pytest.fixture()
def plain_client(db) -> Client:
    """Return a client authenticated as a non-staff user."""
    user = User.objects.create_user(
        username="plain",
        password="pass",
        is_staff=False,
    )
    client = Client()
    client.force_login(user)
    return client


@pytest.fixture()
def snapshot_factory(db):
    """Factory helper to create :class:`TaskSnapshot` instances in the DB."""

    def _make(
        task_name: str = "my_task",
        status: str = TaskSnapshot.Status.SUCCESSFUL,
        duration_seconds: float | None = 1.0,
        attempts: int = 1,
        backend: str = "django.tasks.backends.immediate.ImmediateBackend",
        task_id: str | None = None,
        updated_at_offset_seconds: int = 0,
    ) -> TaskSnapshot:
        import uuid

        snap = TaskSnapshot.objects.create(
            task_id=task_id or str(uuid.uuid4()),
            task_name=task_name,
            task_module="myapp.tasks",
            status=status,
            backend=backend,
            duration_seconds=duration_seconds,
            attempts=attempts,
            enqueued_at=timezone.now() - timedelta(seconds=2),
            started_at=timezone.now() - timedelta(seconds=1),
            finished_at=timezone.now(),
        )
        if updated_at_offset_seconds:
            # Force updated_at into the past to test recency filtering.
            TaskSnapshot.objects.filter(pk=snap.pk).update(
                updated_at=timezone.now() - timedelta(seconds=updated_at_offset_seconds)
            )
        return snap

    return _make


# ---------------------------------------------------------------------------
# URL namespace resolution
# ---------------------------------------------------------------------------


class TestUrlNamespace:
    """Verify the ``django_taskly`` URL namespace resolves all named URLs."""

    def test_dashboard_url(self):
        assert reverse("django_taskly:dashboard") == "/taskly/"

    def test_task_list_url(self):
        assert reverse("django_taskly:task_list") == "/taskly/tasks/"

    def test_task_detail_url(self):
        assert reverse("django_taskly:task_detail", kwargs={"task_id": "abc-123"}) == "/taskly/tasks/abc-123/"

    def test_task_list_partial_url(self):
        assert reverse("django_taskly:task_list_partial") == "/taskly/partials/task-list/"

    def test_dashboard_stats_partial_url(self):
        assert reverse("django_taskly:dashboard_stats_partial") == "/taskly/partials/dashboard-stats/"


# ---------------------------------------------------------------------------
# Authentication guards
# ---------------------------------------------------------------------------


class TestAuthGuards:
    """All views must redirect unauthenticated or non-staff users."""

    PROTECTED_URLS = [
        "/taskly/",
        "/taskly/tasks/",
        "/taskly/tasks/some-task-id/",
        "/taskly/partials/task-list/",
        "/taskly/partials/dashboard-stats/",
    ]

    @pytest.mark.parametrize("url", PROTECTED_URLS)
    def test_anonymous_redirected(self, anon_client: Client, url: str):
        response = anon_client.get(url)
        assert response.status_code in (301, 302), f"Expected redirect for {url}"

    @pytest.mark.parametrize("url", PROTECTED_URLS)
    def test_non_staff_redirected(self, plain_client: Client, url: str):
        response = plain_client.get(url)
        assert response.status_code in (301, 302), f"Expected redirect for {url}"


# ---------------------------------------------------------------------------
# Dashboard view
# ---------------------------------------------------------------------------


class TestDashboardView:
    """Tests for the ``dashboard`` full-page view."""

    URL = "/taskly/"

    def test_returns_200_for_staff(self, staff_client: Client):
        response = staff_client.get(self.URL)
        assert response.status_code == 200

    def test_uses_correct_template(self, staff_client: Client):
        response = staff_client.get(self.URL)
        assert "django_taskly/dashboard.html" in [t.name for t in response.templates]

    def test_context_title(self, staff_client: Client):
        response = staff_client.get(self.URL)
        assert response.context["title"] == "Django Taskly"

    def test_context_counts_with_no_snapshots(self, staff_client: Client, db):
        response = staff_client.get(self.URL)
        assert response.context["total_tasks"] == 0
        assert response.context["successful_count"] == 0
        assert response.context["failed_count"] == 0
        assert response.context["success_rate"] == 0.0

    def test_context_counts_with_snapshots(self, staff_client: Client, snapshot_factory):
        snapshot_factory(status=TaskSnapshot.Status.SUCCESSFUL)
        snapshot_factory(status=TaskSnapshot.Status.SUCCESSFUL)
        snapshot_factory(status=TaskSnapshot.Status.FAILED)
        response = staff_client.get(self.URL)
        assert response.context["total_tasks"] == 3
        assert response.context["successful_count"] == 2
        assert response.context["failed_count"] == 1

    def test_success_rate_calculation(self, staff_client: Client, snapshot_factory):
        snapshot_factory(status=TaskSnapshot.Status.SUCCESSFUL)
        snapshot_factory(status=TaskSnapshot.Status.SUCCESSFUL)
        snapshot_factory(status=TaskSnapshot.Status.SUCCESSFUL)
        snapshot_factory(status=TaskSnapshot.Status.FAILED)
        response = staff_client.get(self.URL)
        # 3 out of 4 = 75.0 %
        assert response.context["success_rate"] == 75.0

    def test_success_rate_zero_when_no_tasks(self, staff_client: Client, db):
        response = staff_client.get(self.URL)
        assert response.context["success_rate"] == 0.0

    def test_slow_tasks_limited_to_10(self, staff_client: Client, snapshot_factory):
        for i in range(15):
            snapshot_factory(duration_seconds=100.0 + i)
        response = staff_client.get(self.URL)
        assert len(response.context["slow_tasks"]) == 10

    def test_recent_tasks_limited_to_20(self, staff_client: Client, snapshot_factory):
        for _ in range(25):
            snapshot_factory()
        response = staff_client.get(self.URL)
        assert len(response.context["recent_tasks"]) == 20

    def test_slow_tasks_not_below_threshold(self, staff_client: Client, snapshot_factory):
        # SLOW_TASK_SECONDS = 5 in test settings; duration of 2 s should not appear.
        snapshot_factory(duration_seconds=2.0)
        response = staff_client.get(self.URL)
        assert len(response.context["slow_tasks"]) == 0

    def test_stats_partial_div_present(self, staff_client: Client, db):
        response = staff_client.get(self.URL)
        content = response.content.decode()
        assert "id=\"taskly-content\"" in content

    def test_htmx_script_tag_present(self, staff_client: Client, db):
        response = staff_client.get(self.URL)
        content = response.content.decode()
        assert "htmx.org" in content


# ---------------------------------------------------------------------------
# Task list view
# ---------------------------------------------------------------------------


class TestTaskListView:
    """Tests for the ``task_list`` full-page view."""

    URL = "/taskly/tasks/"

    def test_returns_200_for_staff(self, staff_client: Client, db):
        response = staff_client.get(self.URL)
        assert response.status_code == 200

    def test_uses_correct_template(self, staff_client: Client, db):
        response = staff_client.get(self.URL)
        assert "django_taskly/task_list.html" in [t.name for t in response.templates]

    def test_context_statuses_contains_all_choices(self, staff_client: Client, db):
        response = staff_client.get(self.URL)
        values = [v for v, _ in response.context["statuses"]]
        assert "PENDING" in values
        assert "RUNNING" in values
        assert "SUCCESSFUL" in values
        assert "FAILED" in values

    def test_empty_state_renders(self, staff_client: Client, db):
        response = staff_client.get(self.URL)
        assert response.status_code == 200
        assert b"No task snapshots" in response.content

    def test_all_tasks_shown_without_filter(self, staff_client: Client, snapshot_factory):
        snapshot_factory(task_name="alpha")
        snapshot_factory(task_name="beta")
        response = staff_client.get(self.URL)
        assert response.context["tasks"].paginator.count == 2

    def test_filter_by_status(self, staff_client: Client, snapshot_factory):
        snapshot_factory(status=TaskSnapshot.Status.FAILED)
        snapshot_factory(status=TaskSnapshot.Status.SUCCESSFUL)
        response = staff_client.get(self.URL + "?status=FAILED")
        assert response.context["tasks"].paginator.count == 1
        assert response.context["status_filter"] == "FAILED"

    def test_filter_by_invalid_status_ignored(self, staff_client: Client, snapshot_factory):
        snapshot_factory(status=TaskSnapshot.Status.FAILED)
        response = staff_client.get(self.URL + "?status=NOPE")
        assert response.context["tasks"].paginator.count == 1

    def test_search_by_task_name(self, staff_client: Client, snapshot_factory):
        snapshot_factory(task_name="send_email")
        snapshot_factory(task_name="process_data")
        response = staff_client.get(self.URL + "?q=send")
        assert response.context["tasks"].paginator.count == 1
        assert response.context["search_query"] == "send"

    def test_search_is_case_insensitive(self, staff_client: Client, snapshot_factory):
        snapshot_factory(task_name="SendEmail")
        response = staff_client.get(self.URL + "?q=sendemail")
        assert response.context["tasks"].paginator.count == 1

    def test_combined_status_and_search(self, staff_client: Client, snapshot_factory):
        snapshot_factory(task_name="send_email", status=TaskSnapshot.Status.FAILED)
        snapshot_factory(task_name="send_email", status=TaskSnapshot.Status.SUCCESSFUL)
        snapshot_factory(task_name="other_task", status=TaskSnapshot.Status.FAILED)
        response = staff_client.get(self.URL + "?status=FAILED&q=send")
        assert response.context["tasks"].paginator.count == 1

    def test_pagination_25_per_page(self, staff_client: Client, snapshot_factory):
        for i in range(30):
            snapshot_factory(task_name=f"task_{i}")
        response = staff_client.get(self.URL)
        assert len(response.context["tasks"].object_list) == 25

    def test_bad_page_number_falls_back_to_last_page(self, staff_client: Client, snapshot_factory):
        snapshot_factory()
        response = staff_client.get(self.URL + "?page=9999")
        assert response.status_code == 200


# ---------------------------------------------------------------------------
# Task detail view
# ---------------------------------------------------------------------------


class TestTaskDetailView:
    """Tests for the ``task_detail`` view."""

    def test_returns_200_for_existing_task(self, staff_client: Client, snapshot_factory):
        snap = snapshot_factory(task_id="unique-task-id-xyz")
        url = reverse("django_taskly:task_detail", kwargs={"task_id": snap.task_id})
        response = staff_client.get(url)
        assert response.status_code == 200

    def test_uses_correct_template(self, staff_client: Client, snapshot_factory):
        snap = snapshot_factory()
        url = reverse("django_taskly:task_detail", kwargs={"task_id": snap.task_id})
        response = staff_client.get(url)
        assert "django_taskly/task_detail.html" in [t.name for t in response.templates]

    def test_context_contains_task(self, staff_client: Client, snapshot_factory):
        snap = snapshot_factory(task_name="verify_me")
        url = reverse("django_taskly:task_detail", kwargs={"task_id": snap.task_id})
        response = staff_client.get(url)
        assert response.context["task"].pk == snap.pk

    def test_404_for_missing_task_id(self, staff_client: Client, db):
        url = reverse("django_taskly:task_detail", kwargs={"task_id": "does-not-exist"})
        response = staff_client.get(url)
        assert response.status_code == 404

    def test_traceback_rendered_when_present(self, staff_client: Client, db):
        snap = TaskSnapshot.objects.create(
            task_id="err-task-001",
            task_name="failing_task",
            task_module="myapp.tasks",
            status=TaskSnapshot.Status.FAILED,
            backend="some.backend",
            last_error_class="builtins.ValueError",
            last_error_traceback="Traceback:\n  ValueError: boom",
        )
        url = reverse("django_taskly:task_detail", kwargs={"task_id": snap.task_id})
        response = staff_client.get(url)
        content = response.content.decode()
        assert "taskly-traceback" in content
        assert "ValueError: boom" in content

    def test_no_traceback_message_when_absent(self, staff_client: Client, snapshot_factory):
        snap = snapshot_factory()
        url = reverse("django_taskly:task_detail", kwargs={"task_id": snap.task_id})
        response = staff_client.get(url)
        content = response.content.decode()
        assert "No traceback recorded" in content

    def test_back_link_present(self, staff_client: Client, snapshot_factory):
        snap = snapshot_factory()
        url = reverse("django_taskly:task_detail", kwargs={"task_id": snap.task_id})
        response = staff_client.get(url)
        content = response.content.decode()
        assert "/taskly/tasks/" in content

    def test_slow_badge_shown_for_slow_task(self, staff_client: Client, snapshot_factory):
        snap = snapshot_factory(duration_seconds=99.0)
        url = reverse("django_taskly:task_detail", kwargs={"task_id": snap.task_id})
        response = staff_client.get(url)
        assert b"taskly-slow-badge" in response.content


# ---------------------------------------------------------------------------
# HTMX partial: task_list_partial
# ---------------------------------------------------------------------------


class TestTaskListPartial:
    """Tests for the ``task_list_partial`` HTMX view."""

    URL = "/taskly/partials/task-list/"

    def test_returns_200(self, staff_client: Client, db):
        response = staff_client.get(self.URL)
        assert response.status_code == 200

    def test_uses_partial_template(self, staff_client: Client, db):
        response = staff_client.get(self.URL)
        assert "django_taskly/partials/task_table.html" in [t.name for t in response.templates]

    def test_filters_apply(self, staff_client: Client, snapshot_factory):
        snapshot_factory(status=TaskSnapshot.Status.FAILED)
        snapshot_factory(status=TaskSnapshot.Status.SUCCESSFUL)
        response = staff_client.get(self.URL + "?status=FAILED")
        assert response.context["tasks"].paginator.count == 1

    def test_search_applies(self, staff_client: Client, snapshot_factory):
        snapshot_factory(task_name="email_sender")
        snapshot_factory(task_name="data_processor")
        response = staff_client.get(self.URL + "?q=email")
        assert response.context["tasks"].paginator.count == 1

    def test_empty_tbody_message(self, staff_client: Client, db):
        response = staff_client.get(self.URL)
        content = response.content.decode()
        assert "No task snapshots" in content

    def test_bad_page_falls_back(self, staff_client: Client, snapshot_factory):
        snapshot_factory()
        response = staff_client.get(self.URL + "?page=999")
        assert response.status_code == 200


# ---------------------------------------------------------------------------
# HTMX partial: dashboard_stats_partial
# ---------------------------------------------------------------------------


class TestDashboardStatsPartial:
    """Tests for the ``dashboard_stats_partial`` HTMX view."""

    URL = "/taskly/partials/dashboard-stats/"

    def test_returns_200(self, staff_client: Client, db):
        response = staff_client.get(self.URL)
        assert response.status_code == 200

    def test_uses_partial_template(self, staff_client: Client, db):
        response = staff_client.get(self.URL)
        assert "django_taskly/partials/dashboard_stats.html" in [t.name for t in response.templates]

    def test_context_values(self, staff_client: Client, snapshot_factory):
        snapshot_factory(status=TaskSnapshot.Status.SUCCESSFUL)
        snapshot_factory(status=TaskSnapshot.Status.FAILED)
        response = staff_client.get(self.URL)
        assert response.context["total_tasks"] == 2
        assert response.context["successful_count"] == 1
        assert response.context["failed_count"] == 1
        assert response.context["success_rate"] == 50.0

    def test_zero_division_handled(self, staff_client: Client, db):
        response = staff_client.get(self.URL)
        assert response.context["success_rate"] == 0.0

    def test_stat_cards_rendered(self, staff_client: Client, db):
        response = staff_client.get(self.URL)
        content = response.content.decode()
        assert "taskly-stats-grid" in content
        assert "Total Tasks" in content
        assert "Successful" in content
        assert "Failed" in content
        assert "Success Rate" in content
