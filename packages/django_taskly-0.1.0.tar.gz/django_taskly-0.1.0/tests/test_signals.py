"""Tests for django_taskly.signals module.

Covers:
- task_finished_handler creates a snapshot when ENABLED=True.
- task_finished_handler is a no-op when ENABLED=False.
- task_finished_handler suppresses all exceptions and never re-raises.
- task_finished_handler logs at exception level when an error occurs.
- Ready() connection path (ImportError on django.tasks.signals).
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from django_taskly.signals import task_finished_handler


@pytest.mark.django_db
class TestTaskFinishedHandlerEnabled:
    """task_finished_handler creates snapshots when ENABLED is True."""

    def test_creates_snapshot_from_result(self, mock_task_result, settings):
        """Handler persists a TaskSnapshot for the given result when enabled."""
        settings.TASKLY = {"ENABLED": True}
        from django_taskly.models import TaskSnapshot

        task_finished_handler(sender=None, task_result=mock_task_result)

        assert TaskSnapshot.objects.filter(task_id="test-task-id-123").exists()

    def test_snapshot_has_correct_status(self, mock_task_result, settings):
        """Snapshot status matches the result's status value."""
        settings.TASKLY = {"ENABLED": True}
        from django_taskly.models import TaskSnapshot

        task_finished_handler(sender=None, task_result=mock_task_result)

        snapshot = TaskSnapshot.objects.get(task_id="test-task-id-123")
        assert snapshot.status == "SUCCESSFUL"

    def test_kwargs_are_accepted(self, mock_task_result, settings):
        """Handler accepts arbitrary extra kwargs without raising."""
        settings.TASKLY = {"ENABLED": True}

        # Should not raise even with unexpected kwargs.
        task_finished_handler(sender=None, task_result=mock_task_result, extra_kwarg="ignored")

    def test_sender_is_accepted(self, mock_task_result, settings):
        """Handler accepts any sender value without raising."""
        settings.TASKLY = {"ENABLED": True}
        from django_taskly.models import TaskSnapshot

        fake_sender = MagicMock(name="FakeTaskClass")
        task_finished_handler(sender=fake_sender, task_result=mock_task_result)

        assert TaskSnapshot.objects.filter(task_id="test-task-id-123").exists()


@pytest.mark.django_db
class TestTaskFinishedHandlerDisabled:
    """task_finished_handler skips collection when ENABLED is False."""

    def test_no_snapshot_when_disabled(self, mock_task_result, settings):
        """No TaskSnapshot is created when ENABLED=False."""
        settings.TASKLY = {"ENABLED": False}
        from django_taskly.models import TaskSnapshot

        task_finished_handler(sender=None, task_result=mock_task_result)

        assert not TaskSnapshot.objects.filter(task_id="test-task-id-123").exists()

    def test_disabled_logs_debug_message(self, mock_task_result, settings):
        """Handler logs at DEBUG level when ENABLED=False."""
        settings.TASKLY = {"ENABLED": False}

        with patch("django_taskly.signals.logger") as mock_logger:
            task_finished_handler(sender=None, task_result=mock_task_result)

        mock_logger.debug.assert_called_once()
        call_msg = mock_logger.debug.call_args[0][0]
        assert "disabled" in call_msg


class TestTaskFinishedHandlerExceptionSuppression:
    """task_finished_handler never propagates exceptions to the caller."""

    @pytest.mark.django_db
    def test_suppresses_collector_exception(self, mock_task_result, settings):
        """Exceptions raised inside snapshot_from_result are caught and logged.

        TaskCollector is imported locally inside the handler so we patch the
        class on its own module, not on ``django_taskly.signals``.
        """
        settings.TASKLY = {"ENABLED": True}

        with patch("django_taskly.collector.TaskCollector.snapshot_from_result", side_effect=RuntimeError("boom")):
            # Must not raise — the handler suppresses all exceptions.
            task_finished_handler(sender=None, task_result=mock_task_result)

    @pytest.mark.django_db
    def test_exception_is_logged(self, mock_task_result, settings):
        """An exception inside the handler is logged via logger.exception."""
        settings.TASKLY = {"ENABLED": True}

        with patch("django_taskly.signals.logger") as mock_logger:
            with patch(
                "django_taskly.collector.TaskCollector.snapshot_from_result",
                side_effect=ValueError("snapshot failed"),
            ):
                task_finished_handler(sender=None, task_result=mock_task_result)

        mock_logger.exception.assert_called_once()
        logged_msg: str = mock_logger.exception.call_args[0][0]
        assert "task_finished_handler" in logged_msg

    def test_suppresses_get_taskly_setting_exception(self, settings):
        """Exception from get_taskly_setting itself is suppressed.

        get_taskly_setting is imported locally inside the handler so we patch
        it on its own module (django_taskly.config).
        """
        settings.TASKLY = {"ENABLED": True}

        with patch("django_taskly.config.get_taskly_setting", side_effect=KeyError("ENABLED")):
            # Should not raise.
            task_finished_handler(sender=None, task_result=MagicMock())


class TestAppsReadySignalConnection:
    """Tests for DjangoTasklyConfig.ready() signal wiring."""

    def test_ready_connects_handler_when_tasks_available(self):
        """ready() calls task_finished.connect when django.tasks.signals imports."""
        mock_signal = MagicMock()
        mock_tasks_signals = MagicMock(task_finished=mock_signal)

        # Inject a fake django.tasks.signals so the import inside ready() succeeds.
        with patch.dict("sys.modules", {"django.tasks.signals": mock_tasks_signals}):
            # Re-import to pick up patched sys.modules in the local import scope.
            import importlib

            import django_taskly.apps as apps_mod

            importlib.reload(apps_mod)
            config = apps_mod.DjangoTasklyConfig.create("django_taskly")
            config.ready()

        mock_signal.connect.assert_called_once_with(task_finished_handler)

    def test_ready_warns_when_tasks_unavailable(self):
        """ready() logs a warning when django.tasks.signals cannot be imported."""
        import logging as stdlib_logging

        warning_messages: list[str] = []

        class _CapturingHandler(stdlib_logging.Handler):
            def emit(self, record: stdlib_logging.LogRecord) -> None:
                warning_messages.append(self.format(record))

        handler = _CapturingHandler()
        pkg_logger = stdlib_logging.getLogger("django_taskly.apps")
        pkg_logger.addHandler(handler)
        pkg_logger.setLevel(stdlib_logging.WARNING)

        try:
            # Setting the module to None forces an ImportError on ``from ... import``.
            with patch.dict("sys.modules", {"django.tasks.signals": None}):
                import importlib

                import django_taskly.apps as apps_mod

                importlib.reload(apps_mod)
                config = apps_mod.DjangoTasklyConfig.create("django_taskly")
                config.ready()
        finally:
            pkg_logger.removeHandler(handler)

        assert warning_messages, "Expected at least one WARNING log record from ready()"
        assert any("not available" in msg for msg in warning_messages)
