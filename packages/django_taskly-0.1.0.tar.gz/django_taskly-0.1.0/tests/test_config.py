"""Tests for django_taskly.config module."""

import pytest

from django_taskly.config import DEFAULTS, get_taskly_setting


class TestGetTasklySetting:
    """Tests for get_taskly_setting()."""

    def test_get_default_setting(self):
        """Default values from DEFAULTS dict are returned when not overridden."""
        # DASHBOARD_TITLE is not set in tests/settings.py TASKLY dict,
        # so it should fall back to the DEFAULTS value.
        assert get_taskly_setting("DASHBOARD_TITLE") == DEFAULTS["DASHBOARD_TITLE"]
        assert get_taskly_setting("DASHBOARD_TITLE") == "Django Taskly"

    def test_get_overridden_setting(self, settings):
        """Settings overridden in settings.TASKLY take precedence over defaults."""
        # tests/settings.py sets MAX_SNAPSHOTS=100, DEFAULTS has 1000
        assert get_taskly_setting("MAX_SNAPSHOTS") == 100

        # Also verify SLOW_TASK_SECONDS (set to 5 in both tests/settings and DEFAULTS)
        assert get_taskly_setting("SLOW_TASK_SECONDS") == 5

        # Verify ENABLED is overridden
        assert get_taskly_setting("ENABLED") is True

    def test_get_overridden_setting_with_different_value(self, settings):
        """Dynamically override a setting and verify it takes effect."""
        settings.TASKLY = {
            "SLOW_TASK_SECONDS": 15,
            "MAX_SNAPSHOTS": 500,
        }
        assert get_taskly_setting("SLOW_TASK_SECONDS") == 15
        assert get_taskly_setting("MAX_SNAPSHOTS") == 500

    def test_get_unknown_setting_raises_keyerror(self):
        """Requesting a setting not in DEFAULTS raises KeyError."""
        with pytest.raises(KeyError, match="Unknown django-taskly setting"):
            get_taskly_setting("NONEXISTENT_SETTING")

    def test_get_unknown_setting_error_contains_valid_keys(self):
        """The KeyError message includes the list of valid keys for discoverability."""
        with pytest.raises(KeyError, match="Valid keys"):
            get_taskly_setting("TYPO_SETTING")

    def test_no_taskly_attribute_uses_defaults(self, settings):
        """When settings has no TASKLY attribute at all, all defaults apply."""
        if hasattr(settings, "TASKLY"):
            delattr(settings, "TASKLY")
        assert get_taskly_setting("ENABLED") is True
        assert get_taskly_setting("SLOW_TASK_SECONDS") == 5
        assert get_taskly_setting("MAX_SNAPSHOTS") == 1000
        assert get_taskly_setting("DASHBOARD_TITLE") == "Django Taskly"

    def test_defaults_dict_has_expected_keys(self):
        """Sanity check: DEFAULTS dict contains all documented keys."""
        expected = {"ENABLED", "SLOW_TASK_SECONDS", "MAX_SNAPSHOTS", "DASHBOARD_TITLE"}
        assert set(DEFAULTS.keys()) == expected
