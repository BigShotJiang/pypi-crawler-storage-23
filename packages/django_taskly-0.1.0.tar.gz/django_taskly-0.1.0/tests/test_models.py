"""Tests for django_taskly.models module."""

import pytest
from datetime import timedelta

from django.utils import timezone

from django_taskly.models import TaskSnapshot


@pytest.mark.django_db
class TestTaskSnapshotStr:
    """Tests for __str__ representation."""

    def test_str_representation(self):
        """__str__ returns 'task_name (STATUS)' format."""
        snapshot = TaskSnapshot.objects.create(
            task_id="str-test-001",
            task_name="send_email",
            task_module="myapp.tasks",
            status=TaskSnapshot.Status.SUCCESSFUL,
            backend="django.tasks.backends.immediate.ImmediateBackend",
        )
        assert str(snapshot) == "send_email (SUCCESSFUL)"

    def test_str_representation_failed(self):
        """__str__ works correctly for FAILED status."""
        snapshot = TaskSnapshot.objects.create(
            task_id="str-test-002",
            task_name="process_data",
            task_module="myapp.tasks",
            status=TaskSnapshot.Status.FAILED,
            backend="django.tasks.backends.immediate.ImmediateBackend",
        )
        assert str(snapshot) == "process_data (FAILED)"

    def test_str_representation_pending(self):
        """__str__ works correctly for default PENDING status."""
        snapshot = TaskSnapshot.objects.create(
            task_id="str-test-003",
            task_name="check_status",
            task_module="myapp.tasks",
            backend="django.tasks.backends.immediate.ImmediateBackend",
        )
        assert str(snapshot) == "check_status (PENDING)"


@pytest.mark.django_db
class TestTaskSnapshotIsSlow:
    """Tests for the is_slow computed property."""

    def test_is_slow_when_duration_exceeds_threshold(self):
        """is_slow returns True when duration_seconds > SLOW_TASK_SECONDS (5)."""
        snapshot = TaskSnapshot.objects.create(
            task_id="slow-001",
            task_name="heavy_task",
            task_module="myapp.tasks",
            status=TaskSnapshot.Status.SUCCESSFUL,
            backend="test",
            duration_seconds=10.0,
        )
        assert snapshot.is_slow is True

    def test_is_slow_when_duration_is_none(self):
        """is_slow returns False when duration_seconds is None (task not finished)."""
        snapshot = TaskSnapshot.objects.create(
            task_id="slow-002",
            task_name="pending_task",
            task_module="myapp.tasks",
            status=TaskSnapshot.Status.RUNNING,
            backend="test",
            duration_seconds=None,
        )
        assert snapshot.is_slow is False

    def test_is_slow_when_duration_below_threshold(self):
        """is_slow returns False when duration is below the threshold."""
        snapshot = TaskSnapshot.objects.create(
            task_id="slow-003",
            task_name="fast_task",
            task_module="myapp.tasks",
            status=TaskSnapshot.Status.SUCCESSFUL,
            backend="test",
            duration_seconds=1.0,
        )
        assert snapshot.is_slow is False

    def test_is_slow_when_duration_equals_threshold(self):
        """is_slow returns False when duration_seconds exactly equals the threshold (not >)."""
        snapshot = TaskSnapshot.objects.create(
            task_id="slow-004",
            task_name="exact_task",
            task_module="myapp.tasks",
            status=TaskSnapshot.Status.SUCCESSFUL,
            backend="test",
            duration_seconds=5.0,  # exactly at threshold
        )
        assert snapshot.is_slow is False

    def test_is_slow_with_custom_threshold(self, settings):
        """is_slow respects a dynamically changed SLOW_TASK_SECONDS value."""
        settings.TASKLY = {"SLOW_TASK_SECONDS": 2}
        snapshot = TaskSnapshot.objects.create(
            task_id="slow-005",
            task_name="medium_task",
            task_module="myapp.tasks",
            status=TaskSnapshot.Status.SUCCESSFUL,
            backend="test",
            duration_seconds=3.0,
        )
        assert snapshot.is_slow is True


@pytest.mark.django_db
class TestTaskSnapshotManagerFailed:
    """Tests for TaskSnapshotManager.failed()."""

    def test_manager_failed_filter(self):
        """failed() returns only snapshots with FAILED status."""
        TaskSnapshot.objects.create(
            task_id="f-001", task_name="t1", task_module="m",
            status=TaskSnapshot.Status.FAILED, backend="b",
        )
        TaskSnapshot.objects.create(
            task_id="f-002", task_name="t2", task_module="m",
            status=TaskSnapshot.Status.SUCCESSFUL, backend="b",
        )
        TaskSnapshot.objects.create(
            task_id="f-003", task_name="t3", task_module="m",
            status=TaskSnapshot.Status.FAILED, backend="b",
        )
        result = TaskSnapshot.objects.failed()
        assert result.count() == 2
        assert all(s.status == TaskSnapshot.Status.FAILED for s in result)

    def test_manager_failed_empty(self):
        """failed() returns empty queryset when no tasks have failed."""
        TaskSnapshot.objects.create(
            task_id="f-004", task_name="t1", task_module="m",
            status=TaskSnapshot.Status.SUCCESSFUL, backend="b",
        )
        assert TaskSnapshot.objects.failed().count() == 0


@pytest.mark.django_db
class TestTaskSnapshotManagerSuccessful:
    """Tests for TaskSnapshotManager.successful()."""

    def test_manager_successful_filter(self):
        """successful() returns only snapshots with SUCCESSFUL status."""
        TaskSnapshot.objects.create(
            task_id="s-001", task_name="t1", task_module="m",
            status=TaskSnapshot.Status.SUCCESSFUL, backend="b",
        )
        TaskSnapshot.objects.create(
            task_id="s-002", task_name="t2", task_module="m",
            status=TaskSnapshot.Status.FAILED, backend="b",
        )
        result = TaskSnapshot.objects.successful()
        assert result.count() == 1
        assert result.first().task_id == "s-001"

    def test_manager_successful_empty(self):
        """successful() returns empty queryset when no tasks succeeded."""
        TaskSnapshot.objects.create(
            task_id="s-003", task_name="t1", task_module="m",
            status=TaskSnapshot.Status.PENDING, backend="b",
        )
        assert TaskSnapshot.objects.successful().count() == 0


@pytest.mark.django_db
class TestTaskSnapshotManagerSlow:
    """Tests for TaskSnapshotManager.slow()."""

    def test_manager_slow_filter(self):
        """slow() returns snapshots with duration_seconds > SLOW_TASK_SECONDS."""
        TaskSnapshot.objects.create(
            task_id="sl-001", task_name="slow_one", task_module="m",
            status=TaskSnapshot.Status.SUCCESSFUL, backend="b",
            duration_seconds=10.0,
        )
        TaskSnapshot.objects.create(
            task_id="sl-002", task_name="fast_one", task_module="m",
            status=TaskSnapshot.Status.SUCCESSFUL, backend="b",
            duration_seconds=1.0,
        )
        TaskSnapshot.objects.create(
            task_id="sl-003", task_name="slower_one", task_module="m",
            status=TaskSnapshot.Status.SUCCESSFUL, backend="b",
            duration_seconds=20.0,
        )
        result = TaskSnapshot.objects.slow()
        assert result.count() == 2
        # Ordered by -duration_seconds
        ids = list(result.values_list("task_id", flat=True))
        assert ids == ["sl-003", "sl-001"]

    def test_manager_slow_excludes_at_threshold(self):
        """slow() does not return a task whose duration equals the threshold exactly."""
        TaskSnapshot.objects.create(
            task_id="sl-004", task_name="exact", task_module="m",
            status=TaskSnapshot.Status.SUCCESSFUL, backend="b",
            duration_seconds=5.0,  # exactly at threshold
        )
        assert TaskSnapshot.objects.slow().count() == 0

    def test_manager_slow_excludes_none_duration(self):
        """slow() does not include tasks with None duration."""
        TaskSnapshot.objects.create(
            task_id="sl-005", task_name="none_dur", task_module="m",
            status=TaskSnapshot.Status.RUNNING, backend="b",
            duration_seconds=None,
        )
        assert TaskSnapshot.objects.slow().count() == 0


@pytest.mark.django_db
class TestTaskSnapshotManagerRecent:
    """Tests for TaskSnapshotManager.recent()."""

    def test_manager_recent_filter(self):
        """recent() returns snapshots updated within the last 24 hours by default."""
        snapshot = TaskSnapshot.objects.create(
            task_id="r-001", task_name="recent_task", task_module="m",
            status=TaskSnapshot.Status.SUCCESSFUL, backend="b",
        )
        # Freshly created -> should be in recent
        result = TaskSnapshot.objects.recent()
        assert result.count() == 1
        assert result.first().task_id == "r-001"

    def test_manager_recent_excludes_old_snapshots(self):
        """recent() excludes snapshots older than the specified window."""
        snapshot = TaskSnapshot.objects.create(
            task_id="r-002", task_name="old_task", task_module="m",
            status=TaskSnapshot.Status.SUCCESSFUL, backend="b",
        )
        # Force the updated_at to 48 hours ago
        old_time = timezone.now() - timedelta(hours=48)
        TaskSnapshot.objects.filter(task_id="r-002").update(updated_at=old_time)

        result = TaskSnapshot.objects.recent(hours=24)
        assert result.count() == 0

    def test_manager_recent_custom_hours(self):
        """recent() respects the custom hours parameter."""
        snapshot = TaskSnapshot.objects.create(
            task_id="r-003", task_name="custom_recent", task_module="m",
            status=TaskSnapshot.Status.SUCCESSFUL, backend="b",
        )
        # Force updated_at to 2 hours ago
        two_hours_ago = timezone.now() - timedelta(hours=2)
        TaskSnapshot.objects.filter(task_id="r-003").update(updated_at=two_hours_ago)

        # Within 1 hour -> should NOT be found
        assert TaskSnapshot.objects.recent(hours=1).count() == 0
        # Within 3 hours -> should be found
        assert TaskSnapshot.objects.recent(hours=3).count() == 1


@pytest.mark.django_db
class TestTaskSnapshotMeta:
    """Tests for model Meta options."""

    def test_default_ordering(self):
        """Default ordering is by -updated_at (newest first)."""
        s1 = TaskSnapshot.objects.create(
            task_id="meta-001", task_name="first", task_module="m",
            status=TaskSnapshot.Status.SUCCESSFUL, backend="b",
        )
        s2 = TaskSnapshot.objects.create(
            task_id="meta-002", task_name="second", task_module="m",
            status=TaskSnapshot.Status.SUCCESSFUL, backend="b",
        )
        ids = list(TaskSnapshot.objects.values_list("task_id", flat=True))
        # s2 was created after s1, so it should appear first
        assert ids[0] == "meta-002"
        assert ids[1] == "meta-001"

    def test_task_id_unique_constraint(self):
        """task_id has a unique constraint; duplicate raises IntegrityError."""
        from django.db import IntegrityError

        TaskSnapshot.objects.create(
            task_id="unique-001", task_name="t1", task_module="m",
            status=TaskSnapshot.Status.SUCCESSFUL, backend="b",
        )
        with pytest.raises(IntegrityError):
            TaskSnapshot.objects.create(
                task_id="unique-001", task_name="t2", task_module="m",
                status=TaskSnapshot.Status.SUCCESSFUL, backend="b",
            )
