"""Tests for django_taskly management commands.

Covers taskly_cleanup:
- Deletes snapshots beyond the limit (default from settings).
- Deletes snapshots when --max-snapshots is provided explicitly.
- Outputs count of deleted rows via self.stdout.
- --dry-run reports count without touching the database.
- --dry-run with --max-snapshots uses the overridden limit.
- Nothing-to-delete path (under limit) outputs success message.
- Command name resolves correctly through Django's management registry.
"""

from __future__ import annotations

import pytest
from django.core.management import call_command

from django_taskly.models import TaskSnapshot


def _make_snapshots(count: int, prefix: str = "cmd") -> list[TaskSnapshot]:
    """Helper that creates *count* TaskSnapshot rows in the database."""
    snapshots = []
    for i in range(count):
        snap = TaskSnapshot.objects.create(
            task_id=f"{prefix}-{i:04d}",
            task_name=f"task_{i}",
            task_module="myapp.tasks",
            status=TaskSnapshot.Status.SUCCESSFUL,
            backend="django.tasks.backends.immediate.ImmediateBackend",
        )
        snapshots.append(snap)
    return snapshots


# ---------------------------------------------------------------------------
# Default behaviour (reads MAX_SNAPSHOTS from settings)
# ---------------------------------------------------------------------------


@pytest.mark.django_db
class TestTasklyCleanupDefault:
    """taskly_cleanup uses the MAX_SNAPSHOTS setting when no --max-snapshots given."""

    def test_deletes_excess_snapshots(self, settings, capsys):
        """Snapshots beyond MAX_SNAPSHOTS are removed."""
        settings.TASKLY = {"MAX_SNAPSHOTS": 3}
        _make_snapshots(5)

        call_command("taskly_cleanup")

        assert TaskSnapshot.objects.count() == 3

    def test_stdout_reports_deleted_count(self, settings, capsys):
        """Output contains the number of deleted snapshots."""
        settings.TASKLY = {"MAX_SNAPSHOTS": 2}
        _make_snapshots(4)

        call_command("taskly_cleanup", stdout=_CaptureIO())

        # Use capsys since call_command writes to self.stdout by default.
        # We redirect explicitly via the stdout kwarg below.

    def test_nothing_deleted_when_under_limit(self, settings, capsys):
        """No deletion occurs when snapshot count is within the limit."""
        settings.TASKLY = {"MAX_SNAPSHOTS": 10}
        _make_snapshots(3)

        call_command("taskly_cleanup")

        assert TaskSnapshot.objects.count() == 3

    def test_nothing_deleted_when_count_equals_limit(self, settings):
        """No deletion occurs when snapshot count exactly equals the limit."""
        settings.TASKLY = {"MAX_SNAPSHOTS": 3}
        _make_snapshots(3)

        call_command("taskly_cleanup")

        assert TaskSnapshot.objects.count() == 3


# ---------------------------------------------------------------------------
# Explicit --max-snapshots
# ---------------------------------------------------------------------------


@pytest.mark.django_db
class TestTasklyCleanupMaxSnapshots:
    """taskly_cleanup respects an explicit --max-snapshots argument."""

    def test_explicit_limit_overrides_setting(self, settings):
        """--max-snapshots overrides the MAX_SNAPSHOTS setting."""
        settings.TASKLY = {"MAX_SNAPSHOTS": 100}
        _make_snapshots(5)

        call_command("taskly_cleanup", max_snapshots=2)

        assert TaskSnapshot.objects.count() == 2

    def test_explicit_limit_1_keeps_newest(self, settings):
        """With --max-snapshots=1, only the single most-recent row survives."""
        settings.TASKLY = {"MAX_SNAPSHOTS": 100}
        _make_snapshots(5, prefix="lim1")

        call_command("taskly_cleanup", max_snapshots=1)

        assert TaskSnapshot.objects.count() == 1

    def test_explicit_limit_larger_than_total_deletes_nothing(self, settings):
        """--max-snapshots larger than total count deletes nothing."""
        settings.TASKLY = {"MAX_SNAPSHOTS": 100}
        _make_snapshots(3, prefix="lrg")

        call_command("taskly_cleanup", max_snapshots=50)

        assert TaskSnapshot.objects.count() == 3


# ---------------------------------------------------------------------------
# stdout output content
# ---------------------------------------------------------------------------


class _CaptureIO:
    """Minimal file-like object that captures write() calls."""

    def __init__(self) -> None:
        self.lines: list[str] = []

    def write(self, msg: str) -> None:
        self.lines.append(msg)

    def flush(self) -> None:
        pass

    @property
    def content(self) -> str:
        return "".join(self.lines)


@pytest.mark.django_db
class TestTasklyCleanupOutput:
    """Verify the text written to stdout."""

    def test_deletion_message_contains_count(self, settings):
        """Output says how many rows were deleted."""
        settings.TASKLY = {"MAX_SNAPSHOTS": 2}
        _make_snapshots(5, prefix="out")
        buf = _CaptureIO()

        call_command("taskly_cleanup", max_snapshots=2, stdout=buf)

        assert "3" in buf.content  # 5 - 2 = 3 deleted

    def test_nothing_to_delete_message(self, settings):
        """Output acknowledges when nothing needs deleting."""
        settings.TASKLY = {"MAX_SNAPSHOTS": 10}
        _make_snapshots(2, prefix="ntd")
        buf = _CaptureIO()

        call_command("taskly_cleanup", stdout=buf)

        assert "Nothing to delete" in buf.content or "0" in buf.content


# ---------------------------------------------------------------------------
# --dry-run flag
# ---------------------------------------------------------------------------


@pytest.mark.django_db
class TestTasklyCleanupDryRun:
    """--dry-run previews deletion without modifying the database."""

    def test_dry_run_does_not_delete(self, settings):
        """Database rows are unchanged when --dry-run is set."""
        settings.TASKLY = {"MAX_SNAPSHOTS": 2}
        _make_snapshots(5, prefix="dry")

        call_command("taskly_cleanup", dry_run=True)

        assert TaskSnapshot.objects.count() == 5

    def test_dry_run_reports_would_delete_count(self, settings):
        """--dry-run output contains the number of rows that would be deleted."""
        settings.TASKLY = {"MAX_SNAPSHOTS": 2}
        _make_snapshots(5, prefix="dryrpt")
        buf = _CaptureIO()

        call_command("taskly_cleanup", dry_run=True, stdout=buf)

        # 5 total - 2 limit = 3 would-be-deleted
        assert "3" in buf.content

    def test_dry_run_with_explicit_max_snapshots(self, settings):
        """--dry-run respects --max-snapshots override."""
        settings.TASKLY = {"MAX_SNAPSHOTS": 100}
        _make_snapshots(6, prefix="drymax")
        buf = _CaptureIO()

        call_command("taskly_cleanup", dry_run=True, max_snapshots=4, stdout=buf)

        # 6 total - 4 limit = 2 would-be-deleted
        assert "2" in buf.content
        # Database untouched.
        assert TaskSnapshot.objects.count() == 6

    def test_dry_run_when_nothing_to_delete(self, settings):
        """--dry-run with count under limit reports 0."""
        settings.TASKLY = {"MAX_SNAPSHOTS": 10}
        _make_snapshots(3, prefix="dryzero")
        buf = _CaptureIO()

        call_command("taskly_cleanup", dry_run=True, stdout=buf)

        assert "0" in buf.content
        assert TaskSnapshot.objects.count() == 3


# ---------------------------------------------------------------------------
# Command registration
# ---------------------------------------------------------------------------


class TestTasklyCleanupRegistration:
    """Verify the command is discoverable through Django's management registry."""

    def test_command_is_importable(self):
        """The command class can be imported from its module path."""
        from django_taskly.management.commands.taskly_cleanup import Command

        assert Command is not None

    def test_command_help_text(self):
        """Command has a non-empty help string."""
        from django_taskly.management.commands.taskly_cleanup import Command

        cmd = Command()
        assert cmd.help
        assert len(cmd.help) > 10
