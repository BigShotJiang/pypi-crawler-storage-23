"""Tests for django_taskly.collector module."""

import pytest
from datetime import timedelta
from unittest.mock import MagicMock, patch

from django.utils.timezone import now

from django_taskly.collector import TaskCollector, _safe_get
from django_taskly.models import TaskSnapshot


@pytest.mark.django_db
class TestSnapshotFromSuccessfulResult:
    """Tests for TaskCollector.snapshot_from_result with successful results."""

    def test_snapshot_from_successful_result(self, mock_task_result):
        """A successful result creates a snapshot with correct fields."""
        collector = TaskCollector()
        snapshot = collector.snapshot_from_result(mock_task_result)

        assert snapshot.task_id == "test-task-id-123"
        assert snapshot.status == "SUCCESSFUL"
        assert snapshot.task_name == "send_email"
        assert snapshot.task_module == "myapp.tasks"
        assert snapshot.last_error_traceback == ""
        assert snapshot.last_error_class == ""
        assert snapshot.attempts == 1
        assert snapshot.backend == "django.tasks.backends.immediate.ImmediateBackend"

    def test_snapshot_from_successful_result_saved_to_db(self, mock_task_result):
        """Snapshot is persisted to the database."""
        collector = TaskCollector()
        snapshot = collector.snapshot_from_result(mock_task_result)

        assert snapshot.pk is not None
        db_snapshot = TaskSnapshot.objects.get(task_id="test-task-id-123")
        assert db_snapshot.status == "SUCCESSFUL"


@pytest.mark.django_db
class TestSnapshotFromFailedResult:
    """Tests for TaskCollector.snapshot_from_result with failed results."""

    def test_snapshot_from_failed_result(self, failed_task_result):
        """A failed result creates a snapshot with error info."""
        collector = TaskCollector()
        snapshot = collector.snapshot_from_result(failed_task_result)

        assert snapshot.task_id == "failed-task-id-456"
        assert snapshot.status == "FAILED"
        assert snapshot.task_name == "process_data"
        assert snapshot.attempts == 3
        assert snapshot.last_error_traceback == "Traceback:\n  ValueError: test error"

    def test_snapshot_from_failed_result_exception_class(self, failed_task_result):
        """Error info includes the exception class name."""
        collector = TaskCollector()
        snapshot = collector.snapshot_from_result(failed_task_result)

        # _extract_error_info reads error.exception and calls type() on it
        assert "ValueError" in snapshot.last_error_class


@pytest.mark.django_db
class TestSnapshotUpsert:
    """Tests for update_or_create behavior (no duplicate snapshots)."""

    def test_snapshot_upsert_no_duplicate(self, mock_task_result):
        """Calling snapshot_from_result twice for same task_id creates only one row."""
        collector = TaskCollector()
        collector.snapshot_from_result(mock_task_result)
        collector.snapshot_from_result(mock_task_result)
        assert TaskSnapshot.objects.filter(task_id="test-task-id-123").count() == 1

    def test_snapshot_upsert_updates_fields(self, mock_task_result):
        """Second call updates existing snapshot rather than creating a new one."""
        collector = TaskCollector()
        collector.snapshot_from_result(mock_task_result)

        # Change mock status to FAILED
        mock_task_result.status.value = "FAILED"
        collector.snapshot_from_result(mock_task_result)

        snapshot = TaskSnapshot.objects.get(task_id="test-task-id-123")
        assert snapshot.status == "FAILED"


@pytest.mark.django_db
class TestDurationCalculation:
    """Tests for duration_seconds calculation."""

    def test_duration_seconds_calculation(self, mock_task_result):
        """duration_seconds is computed from started_at and finished_at."""
        collector = TaskCollector()
        snapshot = collector.snapshot_from_result(mock_task_result)

        assert snapshot.duration_seconds is not None
        assert snapshot.duration_seconds >= 0
        # Our mock has 2.5 seconds between started_at and finished_at
        assert abs(snapshot.duration_seconds - 2.5) < 0.01

    def test_duration_seconds_none_when_started_at_missing(self):
        """duration_seconds is None when started_at is not available."""
        result = MagicMock()
        result.id = "dur-test-001"
        result.status.value = "RUNNING"
        result.started_at = None
        result.finished_at = now()
        result.enqueued_at = now()
        result.attempts = 0
        result.errors = []
        result.task.__module__ = "myapp.tasks"
        result.task.__name__ = "partial_task"
        result.backend = "test"

        collector = TaskCollector()
        snapshot = collector.snapshot_from_result(result)
        assert snapshot.duration_seconds is None

    def test_duration_seconds_none_when_finished_at_missing(self):
        """duration_seconds is None when finished_at is not available."""
        result = MagicMock()
        result.id = "dur-test-002"
        result.status.value = "RUNNING"
        result.started_at = now()
        result.finished_at = None
        result.enqueued_at = now()
        result.attempts = 0
        result.errors = []
        result.task.__module__ = "myapp.tasks"
        result.task.__name__ = "running_task"
        result.backend = "test"

        collector = TaskCollector()
        snapshot = collector.snapshot_from_result(result)
        assert snapshot.duration_seconds is None


@pytest.mark.django_db
class TestCollectAll:
    """Tests for TaskCollector.collect_all()."""

    def test_collect_all_multiple_results(self, mock_task_result, failed_task_result):
        """collect_all processes multiple results and returns snapshots."""
        collector = TaskCollector()
        snapshots = collector.collect_all([mock_task_result, failed_task_result])

        assert len(snapshots) == 2
        assert TaskSnapshot.objects.count() == 2

    def test_collect_all_skips_errors(self):
        """collect_all skips individual results that raise unexpected exceptions."""
        good_result = MagicMock()
        good_result.id = "good-001"
        good_result.status.value = "SUCCESSFUL"
        good_result.enqueued_at = now()
        good_result.started_at = now()
        good_result.finished_at = now()
        good_result.attempts = 1
        good_result.errors = []
        good_result.task.__module__ = "myapp.tasks"
        good_result.task.__name__ = "good_task"
        good_result.backend = "test"

        # A broken result that will cause an exception during update_or_create
        # We simulate this by making the id property raise an unexpected error
        bad_result = MagicMock()
        bad_result.id = "bad-001"
        bad_result.status.value = "SUCCESSFUL"
        bad_result.enqueued_at = now()
        bad_result.started_at = now()
        bad_result.finished_at = now()
        bad_result.attempts = 1
        bad_result.errors = []
        bad_result.task.__module__ = "myapp.tasks"
        bad_result.task.__name__ = "a" * 300  # Exceeds CharField max_length=255 -> DB error
        bad_result.backend = "test"

        collector = TaskCollector()
        snapshots = collector.collect_all([bad_result, good_result])

        # good_result should be processed; bad_result may fail at DB level
        # At minimum the good one should succeed
        assert any(s.task_id == "good-001" for s in snapshots)

    def test_collect_all_empty_iterable(self):
        """collect_all with empty iterable returns empty list."""
        collector = TaskCollector()
        snapshots = collector.collect_all([])
        assert snapshots == []
        assert TaskSnapshot.objects.count() == 0


@pytest.mark.django_db
class TestCleanup:
    """Tests for TaskCollector.cleanup()."""

    def test_cleanup_deletes_oldest(self):
        """cleanup deletes the oldest snapshots when count exceeds max_snapshots."""
        collector = TaskCollector()
        # Create 5 snapshots
        for i in range(5):
            TaskSnapshot.objects.create(
                task_id=f"cleanup-{i:03d}",
                task_name=f"task_{i}",
                task_module="m",
                status=TaskSnapshot.Status.SUCCESSFUL,
                backend="b",
            )

        assert TaskSnapshot.objects.count() == 5

        # Cleanup with limit of 3 -> should delete 2 oldest
        deleted = collector.cleanup(max_snapshots=3)
        assert deleted == 2
        assert TaskSnapshot.objects.count() == 3

    def test_cleanup_no_delete_when_under_limit(self):
        """cleanup does nothing when count is within the limit."""
        collector = TaskCollector()
        for i in range(3):
            TaskSnapshot.objects.create(
                task_id=f"no-del-{i:03d}",
                task_name=f"task_{i}",
                task_module="m",
                status=TaskSnapshot.Status.SUCCESSFUL,
                backend="b",
            )

        deleted = collector.cleanup(max_snapshots=10)
        assert deleted == 0
        assert TaskSnapshot.objects.count() == 3

    def test_cleanup_uses_setting_when_no_argument(self, settings):
        """cleanup reads MAX_SNAPSHOTS from config when no argument is provided."""
        settings.TASKLY = {"MAX_SNAPSHOTS": 2}
        collector = TaskCollector()
        for i in range(5):
            TaskSnapshot.objects.create(
                task_id=f"cfg-del-{i:03d}",
                task_name=f"task_{i}",
                task_module="m",
                status=TaskSnapshot.Status.SUCCESSFUL,
                backend="b",
            )

        deleted = collector.cleanup()
        assert deleted == 3
        assert TaskSnapshot.objects.count() == 2

    def test_cleanup_deletes_none_when_count_equals_limit(self):
        """cleanup returns 0 when count exactly equals the limit."""
        collector = TaskCollector()
        for i in range(3):
            TaskSnapshot.objects.create(
                task_id=f"exact-{i:03d}",
                task_name=f"task_{i}",
                task_module="m",
                status=TaskSnapshot.Status.SUCCESSFUL,
                backend="b",
            )

        deleted = collector.cleanup(max_snapshots=3)
        assert deleted == 0


@pytest.mark.django_db
class TestNotImplementedErrorHandling:
    """Tests for ImmediateBackend NotImplementedError handling."""

    def test_snapshot_from_result_handles_not_implemented_error(self, not_implemented_task_result):
        """snapshot_from_result gracefully handles NotImplementedError on result attributes.

        This simulates the ImmediateBackend which raises NotImplementedError
        for properties like status, started_at, finished_at, etc.
        """
        collector = TaskCollector()
        snapshot = collector.snapshot_from_result(not_implemented_task_result)

        # Should still create a snapshot with safe defaults
        assert snapshot.task_id == "nie-task-id-000"
        # Status should fall back to PENDING since we can't read it
        assert snapshot.status == TaskSnapshot.Status.PENDING
        # Duration should be None since timestamps are inaccessible
        assert snapshot.duration_seconds is None
        # Attempts default to 0
        assert snapshot.attempts == 0


@pytest.mark.django_db
class TestEmptyTaskId:
    """Tests for edge case of empty or missing task_id."""

    def test_snapshot_from_result_empty_task_id(self):
        """snapshot_from_result returns unsaved sentinel when task_id is empty."""
        result = MagicMock()
        result.id = ""
        result.status.value = "PENDING"
        result.task.__module__ = "myapp.tasks"
        result.task.__name__ = "orphan_task"

        collector = TaskCollector()
        snapshot = collector.snapshot_from_result(result)

        # Should return an unsaved TaskSnapshot
        assert snapshot.pk is None
        assert snapshot.task_id == ""
        assert snapshot.task_name == "unknown"

    def test_snapshot_from_result_none_task_id(self):
        """snapshot_from_result handles None task_id (becomes empty string after str())."""
        result = MagicMock()
        result.id = None  # str(None) = "None", not empty

        # Actually, str(None) == "None" which is truthy, so let's test the real empty case
        type(result).id = property(lambda self: (_ for _ in ()).throw(NotImplementedError))
        result.task.__module__ = "myapp.tasks"
        result.task.__name__ = "none_id_task"
        result.backend = "test"

        collector = TaskCollector()
        snapshot = collector.snapshot_from_result(result)

        # _safe_get returns default "" when NotImplementedError, str("") = ""
        assert snapshot.pk is None
        assert snapshot.task_id == ""


@pytest.mark.django_db
class TestStatusValueEdgeCases:
    """Tests for edge cases in status.value reading (lines 114-115)."""

    def test_status_value_attribute_error_defaults_to_pending(self):
        """When status is not None but .value raises AttributeError, defaults to PENDING."""
        result = MagicMock()
        result.id = "status-edge-001"
        result.enqueued_at = now()
        result.started_at = now()
        result.finished_at = now()
        result.attempts = 1
        result.errors = []
        result.task.__module__ = "myapp.tasks"
        result.task.__name__ = "status_edge_task"
        result.backend = "test"

        # Create a status object where .value raises AttributeError
        # We need to use a real class (not MagicMock property) to ensure
        # _safe_get returns it and then raw_status_obj.value raises.
        class BrokenStatus:
            @property
            def value(self):
                raise AttributeError("no value attribute")

        result.status = BrokenStatus()

        collector = TaskCollector()
        snapshot = collector.snapshot_from_result(result)
        assert snapshot.status == TaskSnapshot.Status.PENDING


@pytest.mark.django_db
class TestUpdateOrCreateException:
    """Tests for update_or_create exception handling (lines 148-150)."""

    def test_snapshot_from_result_reraises_db_exception(self):
        """snapshot_from_result re-raises exceptions from update_or_create."""
        result = MagicMock()
        result.id = "db-error-001"
        result.status.value = "SUCCESSFUL"
        result.enqueued_at = now()
        result.started_at = now()
        result.finished_at = now()
        result.attempts = 1
        result.errors = []
        result.task.__module__ = "myapp.tasks"
        result.task.__name__ = "db_error_task"
        result.backend = "test"

        collector = TaskCollector()
        with patch.object(
            TaskSnapshot.objects, "update_or_create",
            side_effect=RuntimeError("simulated DB error"),
        ):
            with pytest.raises(RuntimeError, match="simulated DB error"):
                collector.snapshot_from_result(result)


@pytest.mark.django_db
class TestCollectAllExceptionBranch:
    """Tests for collect_all exception handling (lines 171-172)."""

    def test_collect_all_catches_reraise_from_snapshot(self):
        """collect_all catches exceptions re-raised by snapshot_from_result."""
        good_result = MagicMock()
        good_result.id = "ca-good-001"
        good_result.status.value = "SUCCESSFUL"
        good_result.enqueued_at = now()
        good_result.started_at = now()
        good_result.finished_at = now()
        good_result.attempts = 1
        good_result.errors = []
        good_result.task.__module__ = "myapp.tasks"
        good_result.task.__name__ = "good_task"
        good_result.backend = "test"

        bad_result = MagicMock()
        bad_result.id = "ca-bad-001"
        bad_result.status.value = "SUCCESSFUL"
        bad_result.enqueued_at = now()
        bad_result.started_at = now()
        bad_result.finished_at = now()
        bad_result.attempts = 1
        bad_result.errors = []
        bad_result.task.__module__ = "myapp.tasks"
        bad_result.task.__name__ = "bad_task"
        bad_result.backend = "test"

        collector = TaskCollector()

        # The first call processes bad_result, which we make fail
        original = collector.snapshot_from_result
        call_count = [0]

        def side_effect(result):
            call_count[0] += 1
            if result is bad_result:
                raise RuntimeError("forced failure")
            return original(result)

        with patch.object(collector, "snapshot_from_result", side_effect=side_effect):
            snapshots = collector.collect_all([bad_result, good_result])

        # bad_result should be skipped, good_result should succeed
        assert len(snapshots) == 1
        assert snapshots[0].task_id == "ca-good-001"


class TestCalculateDurationEdgeCases:
    """Tests for _calculate_duration edge cases (lines 232-234)."""

    def test_calculate_duration_with_non_datetime_values(self):
        """_calculate_duration returns None when timestamps are not datetime objects."""
        collector = TaskCollector()
        # Strings instead of datetimes -> TypeError on subtraction
        result = collector._calculate_duration("not-a-date", "also-not")
        assert result is None

    def test_calculate_duration_with_incompatible_types(self):
        """_calculate_duration returns None when subtraction raises TypeError."""
        collector = TaskCollector()
        result = collector._calculate_duration(42, 100)
        # int subtraction works (100-42=58) but .total_seconds() raises AttributeError
        assert result is None


class TestExtractErrorInfoEdgeCases:
    """Tests for _extract_error_info edge cases (lines 258-259, 269-270, 274-275)."""

    def test_extract_error_info_errors_not_subscriptable(self):
        """_extract_error_info returns empty tuple when errors is not subscriptable."""
        result = MagicMock()
        # errors is truthy but not subscriptable (integer)
        result.errors = 42

        collector = TaskCollector()
        exc_class, tb = collector._extract_error_info(result)
        assert exc_class == ""
        assert tb == ""

    def test_extract_error_info_exception_class_extraction_failure(self):
        """_extract_error_info handles exception during exception_class extraction."""
        result = MagicMock()
        error = MagicMock()

        # Make _safe_get(last_error, "exception", None) return something
        # where type(exc).__module__ or __qualname__ access raises.
        # We can use a MagicMock for the exception, and then patch type()
        # indirectly by making the f-string formatting fail.
        # The code does: exc_type = type(exc); f"{exc_type.__module__}.{exc_type.__qualname__}"
        # type() always works, so we need __module__ or __qualname__ to fail.
        # We can create a metaclass that makes __module__ raise.
        class BadMeta(type):
            @property
            def __module__(cls):
                raise RuntimeError("bad module")

        class BadExc(metaclass=BadMeta):
            pass

        bad_exc = BadExc()
        error.exception = bad_exc
        error.traceback = "some traceback"
        result.errors = [error]

        collector = TaskCollector()
        exc_class, tb = collector._extract_error_info(result)
        # The exception_class extraction should fail and return ""
        # but traceback should still work
        assert exc_class == ""
        assert tb == "some traceback"

    def test_extract_error_info_traceback_extraction_failure(self):
        """_extract_error_info handles exception during traceback extraction."""
        result = MagicMock()
        error = MagicMock()

        error.exception = None  # No exception -> no exception class extraction

        # Make str() on the traceback result raise an exception
        # _safe_get returns the traceback value, then str() is called on it
        # We need str(_safe_get(...)) to raise. This is hard since str() rarely fails.
        # Instead, make _safe_get return something where str() raises.
        class BadStr:
            def __str__(self):
                raise RuntimeError("cannot convert to string")

        type(error).traceback = property(lambda self: BadStr())
        result.errors = [error]

        collector = TaskCollector()
        exc_class, tb = collector._extract_error_info(result)
        # Both should default to empty string on failure
        assert tb == ""


class TestSafeGet:
    """Tests for the _safe_get helper function."""

    def test_safe_get_returns_attribute(self):
        """_safe_get returns normal attribute value."""
        obj = MagicMock()
        obj.some_attr = "hello"
        assert _safe_get(obj, "some_attr") == "hello"

    def test_safe_get_returns_default_for_missing(self):
        """_safe_get returns default when attribute is missing."""
        obj = MagicMock(spec=[])  # spec=[] means no attributes
        result = _safe_get(obj, "missing_attr", "fallback")
        assert result == "fallback"

    def test_safe_get_catches_not_implemented_error(self):
        """_safe_get catches NotImplementedError and returns default."""
        obj = MagicMock()
        type(obj).problematic = property(
            lambda self: (_ for _ in ()).throw(NotImplementedError("not supported"))
        )
        result = _safe_get(obj, "problematic", "safe_default")
        assert result == "safe_default"

    def test_safe_get_default_is_none(self):
        """_safe_get default parameter is None when not specified."""
        obj = MagicMock(spec=[])
        result = _safe_get(obj, "nonexistent")
        assert result is None
