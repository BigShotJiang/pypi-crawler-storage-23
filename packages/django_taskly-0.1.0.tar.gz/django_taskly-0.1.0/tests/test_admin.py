"""Tests for django_taskly.admin module.

Covers:
* Registration of TaskSnapshot with the admin site.
* status_colored — correct HTML output for every Status value plus an unknown value.
* duration_display — formatted string and em-dash fallback.
* is_slow_display — delegates to the model property.
* Permission helpers — has_add_permission, has_change_permission, has_delete_permission.
* Fieldset completeness — every model field appears exactly once.
* List / search / filter configuration attributes.
"""

from __future__ import annotations

import pytest
from unittest.mock import MagicMock

from django.contrib.admin.sites import AdminSite
from django.contrib.auth.models import User
from django.test import RequestFactory

from django_taskly.admin import TaskSnapshotAdmin, _STATUS_COLOURS
from django_taskly.models import TaskSnapshot


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _make_admin() -> TaskSnapshotAdmin:
    """Return a fresh :class:`TaskSnapshotAdmin` bound to the default site."""
    return TaskSnapshotAdmin(TaskSnapshot, AdminSite())


def _make_request(*, superuser: bool = True) -> MagicMock:
    """Return a minimal mock HTTP request with a superuser attached."""
    request = MagicMock()
    request.user = MagicMock()
    request.user.is_superuser = superuser
    request.user.has_perm = MagicMock(return_value=superuser)
    return request


def _snapshot(**kwargs: object) -> TaskSnapshot:
    """Return an unsaved :class:`TaskSnapshot` with sensible defaults.

    Keyword arguments override the defaults, allowing tests to be concise.
    """
    defaults: dict[str, object] = {
        "task_id": "test-id-001",
        "task_name": "my_task",
        "task_module": "myapp.tasks",
        "status": TaskSnapshot.Status.PENDING,
        "backend": "django.tasks.backends.immediate.ImmediateBackend",
        "duration_seconds": None,
    }
    defaults.update(kwargs)
    return TaskSnapshot(**defaults)


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


class TestAdminRegistration:
    """The admin site must have TaskSnapshot registered."""

    def test_task_snapshot_is_registered(self) -> None:
        """TaskSnapshot appears in the default admin site registry."""
        from django.contrib import admin as django_admin

        assert TaskSnapshot in django_admin.site._registry

    def test_registered_class_is_task_snapshot_admin(self) -> None:
        """The registered class is TaskSnapshotAdmin."""
        from django.contrib import admin as django_admin

        registered = django_admin.site._registry[TaskSnapshot]
        assert isinstance(registered, TaskSnapshotAdmin)


# ---------------------------------------------------------------------------
# status_colored
# ---------------------------------------------------------------------------


class TestStatusColored:
    """Tests for TaskSnapshotAdmin.status_colored."""

    def test_successful_renders_green(self) -> None:
        """SUCCESSFUL status is rendered with the green colour."""
        admin_instance = _make_admin()
        obj = _snapshot(status=TaskSnapshot.Status.SUCCESSFUL)
        html = admin_instance.status_colored(obj)
        assert _STATUS_COLOURS[TaskSnapshot.Status.SUCCESSFUL] in html
        assert "Successful" in html

    def test_failed_renders_red(self) -> None:
        """FAILED status is rendered with the red colour."""
        admin_instance = _make_admin()
        obj = _snapshot(status=TaskSnapshot.Status.FAILED)
        html = admin_instance.status_colored(obj)
        assert _STATUS_COLOURS[TaskSnapshot.Status.FAILED] in html
        assert "Failed" in html

    def test_running_renders_blue(self) -> None:
        """RUNNING status is rendered with the blue colour."""
        admin_instance = _make_admin()
        obj = _snapshot(status=TaskSnapshot.Status.RUNNING)
        html = admin_instance.status_colored(obj)
        assert _STATUS_COLOURS[TaskSnapshot.Status.RUNNING] in html
        assert "Running" in html

    def test_pending_renders_orange(self) -> None:
        """PENDING status is rendered with the orange colour."""
        admin_instance = _make_admin()
        obj = _snapshot(status=TaskSnapshot.Status.PENDING)
        html = admin_instance.status_colored(obj)
        assert _STATUS_COLOURS[TaskSnapshot.Status.PENDING] in html
        assert "Pending" in html

    def test_unknown_status_renders_plain_text(self) -> None:
        """An unmapped status value is rendered as plain text without a colour span."""
        admin_instance = _make_admin()
        obj = _snapshot(status="UNKNOWN_STATUS")
        html = admin_instance.status_colored(obj)
        # No inline colour style should be present
        assert "color:" not in html
        # The raw value should still appear
        assert "UNKNOWN_STATUS" in html

    def test_output_is_safe_string(self) -> None:
        """status_colored returns a SafeString (not escaped by the template engine)."""
        from django.utils.safestring import SafeString

        admin_instance = _make_admin()
        obj = _snapshot(status=TaskSnapshot.Status.SUCCESSFUL)
        result = admin_instance.status_colored(obj)
        assert isinstance(result, SafeString)

    def test_span_tag_is_present_for_known_status(self) -> None:
        """A <span> element wraps the label for every known status."""
        admin_instance = _make_admin()
        for status in (
            TaskSnapshot.Status.SUCCESSFUL,
            TaskSnapshot.Status.FAILED,
            TaskSnapshot.Status.RUNNING,
            TaskSnapshot.Status.PENDING,
        ):
            obj = _snapshot(status=status)
            html = admin_instance.status_colored(obj)
            assert "<span" in html, f"No <span> found for status {status}"
            assert "font-weight: bold" in html


# ---------------------------------------------------------------------------
# duration_display
# ---------------------------------------------------------------------------


class TestDurationDisplay:
    """Tests for TaskSnapshotAdmin.duration_display."""

    def test_none_duration_returns_em_dash(self) -> None:
        """None duration_seconds renders as the em-dash character."""
        admin_instance = _make_admin()
        obj = _snapshot(duration_seconds=None)
        result = admin_instance.duration_display(obj)
        assert result == "\u2014"

    def test_duration_formatted_to_two_decimals(self) -> None:
        """A float duration is formatted as 'X.XXs'."""
        admin_instance = _make_admin()
        obj = _snapshot(duration_seconds=2.5)
        result = admin_instance.duration_display(obj)
        assert result == "2.50s"

    def test_duration_zero_renders_correctly(self) -> None:
        """Zero duration renders as '0.00s'."""
        admin_instance = _make_admin()
        obj = _snapshot(duration_seconds=0.0)
        result = admin_instance.duration_display(obj)
        assert result == "0.00s"

    def test_duration_large_value(self) -> None:
        """Large duration values are formatted without scientific notation."""
        admin_instance = _make_admin()
        obj = _snapshot(duration_seconds=3661.123)
        result = admin_instance.duration_display(obj)
        assert result == "3661.12s"

    def test_duration_sub_second_precision(self) -> None:
        """Sub-second durations are rounded to two decimal places."""
        admin_instance = _make_admin()
        obj = _snapshot(duration_seconds=0.123456)
        result = admin_instance.duration_display(obj)
        assert result == "0.12s"


# ---------------------------------------------------------------------------
# is_slow_display
# ---------------------------------------------------------------------------


@pytest.mark.django_db
class TestIsSlowDisplay:
    """Tests for TaskSnapshotAdmin.is_slow_display."""

    def test_is_slow_true_when_exceeds_threshold(self, settings: object) -> None:
        """is_slow_display returns True when duration exceeds SLOW_TASK_SECONDS."""
        settings.TASKLY = {"SLOW_TASK_SECONDS": 5}  # type: ignore[attr-defined]
        admin_instance = _make_admin()
        obj = TaskSnapshot.objects.create(
            task_id="slow-admin-001",
            task_name="heavy",
            task_module="m",
            status=TaskSnapshot.Status.SUCCESSFUL,
            backend="b",
            duration_seconds=10.0,
        )
        assert admin_instance.is_slow_display(obj) is True

    def test_is_slow_false_when_none_duration(self) -> None:
        """is_slow_display returns False when duration_seconds is None."""
        admin_instance = _make_admin()
        obj = _snapshot(duration_seconds=None)
        assert admin_instance.is_slow_display(obj) is False

    def test_is_slow_false_when_below_threshold(self, settings: object) -> None:
        """is_slow_display returns False when duration is below the threshold."""
        settings.TASKLY = {"SLOW_TASK_SECONDS": 5}  # type: ignore[attr-defined]
        admin_instance = _make_admin()
        obj = _snapshot(duration_seconds=1.0)
        assert admin_instance.is_slow_display(obj) is False

    def test_is_slow_display_delegates_to_model_property(self) -> None:
        """is_slow_display returns the same value as obj.is_slow."""
        admin_instance = _make_admin()
        obj = MagicMock(spec=TaskSnapshot)
        obj.is_slow = True
        assert admin_instance.is_slow_display(obj) is True

        obj.is_slow = False
        assert admin_instance.is_slow_display(obj) is False


# ---------------------------------------------------------------------------
# Permissions
# ---------------------------------------------------------------------------


class TestPermissions:
    """Tests for has_add_permission, has_change_permission, has_delete_permission."""

    def test_has_add_permission_always_false(self) -> None:
        """has_add_permission returns False regardless of the user."""
        admin_instance = _make_admin()
        request = _make_request(superuser=True)
        assert admin_instance.has_add_permission(request) is False

    def test_has_add_permission_false_for_non_superuser(self) -> None:
        """has_add_permission returns False for non-superusers too."""
        admin_instance = _make_admin()
        request = _make_request(superuser=False)
        assert admin_instance.has_add_permission(request) is False

    def test_has_change_permission_always_false(self) -> None:
        """has_change_permission returns False regardless of the user."""
        admin_instance = _make_admin()
        request = _make_request(superuser=True)
        assert admin_instance.has_change_permission(request) is False

    def test_has_change_permission_false_with_obj(self) -> None:
        """has_change_permission returns False even when an obj is provided."""
        admin_instance = _make_admin()
        request = _make_request(superuser=True)
        obj = _snapshot()
        assert admin_instance.has_change_permission(request, obj) is False

    def test_has_change_permission_false_for_non_superuser(self) -> None:
        """has_change_permission returns False for non-superusers too."""
        admin_instance = _make_admin()
        request = _make_request(superuser=False)
        assert admin_instance.has_change_permission(request) is False

    @pytest.mark.django_db
    def test_has_delete_permission_true_for_superuser(self) -> None:
        """has_delete_permission delegates to Django's default, allowing superusers."""
        admin_instance = _make_admin()
        factory = RequestFactory()
        raw_request = factory.get("/admin/")
        raw_request.user = User.objects.create_superuser(
            username="admin_del",
            password="pass",
            email="admin@example.com",
        )
        assert admin_instance.has_delete_permission(raw_request) is True

    @pytest.mark.django_db
    def test_has_delete_permission_false_for_regular_user(self) -> None:
        """has_delete_permission returns False for users without the delete permission."""
        admin_instance = _make_admin()
        factory = RequestFactory()
        raw_request = factory.get("/admin/")
        raw_request.user = User.objects.create_user(
            username="regular_del",
            password="pass",
        )
        assert admin_instance.has_delete_permission(raw_request) is False


# ---------------------------------------------------------------------------
# Admin metadata attributes
# ---------------------------------------------------------------------------


class TestAdminMetadata:
    """Tests for list_display, list_filter, search_fields, and other attributes."""

    def test_list_display_contains_required_columns(self) -> None:
        """list_display includes all specified columns."""
        admin_instance = _make_admin()
        required = {
            "task_name",
            "task_module",
            "status_colored",
            "backend",
            "enqueued_at",
            "started_at",
            "finished_at",
            "duration_display",
            "attempts",
            "is_slow_display",
        }
        assert required.issubset(set(admin_instance.list_display))

    def test_list_filter_contains_required_fields(self) -> None:
        """list_filter includes status, backend, and created_at."""
        admin_instance = _make_admin()
        assert "status" in admin_instance.list_filter
        assert "backend" in admin_instance.list_filter
        assert "created_at" in admin_instance.list_filter

    def test_search_fields_contains_required_fields(self) -> None:
        """search_fields covers task_id, task_name, task_module, and last_error_class."""
        admin_instance = _make_admin()
        required = {"task_id", "task_name", "task_module", "last_error_class"}
        assert required.issubset(set(admin_instance.search_fields))

    def test_ordering_is_by_updated_at_descending(self) -> None:
        """Default ordering is ['-updated_at']."""
        admin_instance = _make_admin()
        assert admin_instance.ordering == ["-updated_at"]

    def test_list_per_page_is_50(self) -> None:
        """list_per_page is 50."""
        admin_instance = _make_admin()
        assert admin_instance.list_per_page == 50

    def test_date_hierarchy_is_created_at(self) -> None:
        """date_hierarchy points to created_at."""
        admin_instance = _make_admin()
        assert admin_instance.date_hierarchy == "created_at"


# ---------------------------------------------------------------------------
# Fieldsets completeness
# ---------------------------------------------------------------------------


class TestFieldsets:
    """Every TaskSnapshot field must appear in exactly one fieldset section."""

    # Fields excluded from fieldset validation because they are intentionally
    # absent from the detail view (e.g. the auto-generated primary key).
    _EXCLUDED: frozenset[str] = frozenset({"id"})

    def _collect_fieldset_fields(self, admin_instance: TaskSnapshotAdmin) -> set[str]:
        """Return the union of all field names declared across all fieldsets."""
        fields: set[str] = set()
        for _title, options in admin_instance.fieldsets:
            for field in options.get("fields", ()):
                fields.add(field)
        return fields

    def test_all_readonly_fields_present_in_fieldsets(self) -> None:
        """Every readonly_field appears in at least one fieldset."""
        admin_instance = _make_admin()
        fieldset_fields = self._collect_fieldset_fields(admin_instance)
        for field in admin_instance.readonly_fields:
            assert field in fieldset_fields, (
                f"readonly field '{field}' is not listed in any fieldset"
            )

    def test_identity_section_contains_correct_fields(self) -> None:
        """The 'Identity' fieldset contains task_id, task_name, task_module."""
        admin_instance = _make_admin()
        identity_fields = next(
            options["fields"]
            for title, options in admin_instance.fieldsets
            if title == "Identity"
        )
        assert "task_id" in identity_fields
        assert "task_name" in identity_fields
        assert "task_module" in identity_fields

    def test_status_backend_section_contains_correct_fields(self) -> None:
        """The 'Status & Backend' fieldset contains status and backend."""
        admin_instance = _make_admin()
        sb_fields = next(
            options["fields"]
            for title, options in admin_instance.fieldsets
            if title == "Status & Backend"
        )
        assert "status" in sb_fields
        assert "backend" in sb_fields

    def test_timing_section_contains_correct_fields(self) -> None:
        """The 'Timing' fieldset contains all four timing fields."""
        admin_instance = _make_admin()
        timing_fields = next(
            options["fields"]
            for title, options in admin_instance.fieldsets
            if title == "Timing"
        )
        assert "enqueued_at" in timing_fields
        assert "started_at" in timing_fields
        assert "finished_at" in timing_fields
        assert "duration_seconds" in timing_fields

    def test_attempts_errors_section_contains_correct_fields(self) -> None:
        """The 'Attempts & Errors' fieldset contains error-related fields."""
        admin_instance = _make_admin()
        ae_fields = next(
            options["fields"]
            for title, options in admin_instance.fieldsets
            if title == "Attempts & Errors"
        )
        assert "attempts" in ae_fields
        assert "last_error_class" in ae_fields
        assert "last_error_traceback" in ae_fields

    def test_audit_section_contains_correct_fields(self) -> None:
        """The 'Audit' fieldset contains created_at and updated_at."""
        admin_instance = _make_admin()
        audit_fields = next(
            options["fields"]
            for title, options in admin_instance.fieldsets
            if title == "Audit"
        )
        assert "created_at" in audit_fields
        assert "updated_at" in audit_fields

    def test_five_fieldset_sections_declared(self) -> None:
        """Exactly five fieldset sections are declared."""
        admin_instance = _make_admin()
        assert len(admin_instance.fieldsets) == 5


# ---------------------------------------------------------------------------
# @admin.display decorator attributes
# ---------------------------------------------------------------------------


class TestDisplayDecoratorAttributes:
    """Verify @admin.display metadata is applied correctly to custom methods."""

    def test_status_colored_has_description(self) -> None:
        """status_colored carries the correct short_description."""
        admin_instance = _make_admin()
        assert admin_instance.status_colored.short_description == "Status"

    def test_status_colored_is_sortable(self) -> None:
        """status_colored is sortable by the 'status' field."""
        admin_instance = _make_admin()
        assert admin_instance.status_colored.admin_order_field == "status"

    def test_duration_display_has_description(self) -> None:
        """duration_display carries the correct short_description."""
        admin_instance = _make_admin()
        assert admin_instance.duration_display.short_description == "Duration"

    def test_duration_display_is_sortable(self) -> None:
        """duration_display is sortable by duration_seconds."""
        admin_instance = _make_admin()
        assert admin_instance.duration_display.admin_order_field == "duration_seconds"

    def test_is_slow_display_has_description(self) -> None:
        """is_slow_display carries the correct short_description."""
        admin_instance = _make_admin()
        assert admin_instance.is_slow_display.short_description == "Slow?"

    def test_is_slow_display_boolean_flag(self) -> None:
        """is_slow_display has boolean=True so Django renders tick/cross icons."""
        admin_instance = _make_admin()
        assert admin_instance.is_slow_display.boolean is True

    def test_is_slow_display_is_sortable(self) -> None:
        """is_slow_display is sortable by duration_seconds."""
        admin_instance = _make_admin()
        assert admin_instance.is_slow_display.admin_order_field == "duration_seconds"
