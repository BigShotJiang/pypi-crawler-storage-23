"""Version information for odoorpc-toolbox."""

__version__ = '0.4.0'
