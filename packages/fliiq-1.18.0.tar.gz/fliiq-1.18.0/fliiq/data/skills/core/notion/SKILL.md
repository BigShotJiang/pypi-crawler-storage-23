---
name: notion
description: "Search, create, read, and update Notion pages and databases. Query databases and add entries."
---

Use this tool to interact with Notion workspaces. Supports searching content, creating and reading pages, updating page properties, querying databases, and adding database entries.

## Setup
1. Go to https://www.notion.so/profile/integrations
2. Click "+ New integration" and name it (e.g. "Fliiq")
3. Select your workspace, create the integration
4. Go to Configuration tab and copy the **Internal Integration Secret** (starts with `ntn_` or `secret_`)
5. **Grant access**: Open each Notion page you want the integration to access, click "..." menu > "Add Connections" > search for your integration name > confirm

Add to your `.env` file:
```
NOTION_API_KEY=ntn_...
```

## Important Notes
- Integrations have **zero access by default** — you must explicitly connect each top-level page
- Connecting a page grants access to that page **and all its child pages**
- If API calls return 404, the integration likely doesn't have access to that page
