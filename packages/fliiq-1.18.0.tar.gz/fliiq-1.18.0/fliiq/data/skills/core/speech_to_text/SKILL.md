---
name: speech_to_text
description: "Transcribe audio files to text using OpenAI Whisper API. Supports OGG, MP3, M4A, WAV, WEBM formats."
---

Transcribe audio to text. Accepts a file path to an audio file and returns the transcribed text.

## Supported Formats
- OGG (Telegram voice messages)
- MP3, M4A, WAV, WEBM

## Typical Flow
1. Receive or download audio file
2. Call `speech_to_text` with the file path
3. Process the transcribed text
