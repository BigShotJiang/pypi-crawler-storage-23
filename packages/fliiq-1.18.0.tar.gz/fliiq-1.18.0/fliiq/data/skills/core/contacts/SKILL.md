---
name: contacts
description: "Manage contacts and relationships: add, search, update contacts, log interactions, and track deals through a sales pipeline. All data stored locally."
---

A lightweight CRM stored in ~/.fliiq/contacts.yaml. No external service needed.

## Actions
- **add**: Add a new contact (name required, plus email, phone, company, role, tags, notes)
- **search**: Find contacts by name, company, tag, or freetext across all fields
- **update**: Modify contact fields (email, phone, tags, notes, deal stage, deal value)
- **log_interaction**: Record an interaction (email, call, meeting, note) against a contact
- **pipeline**: View deals grouped by stage with counts and totals
