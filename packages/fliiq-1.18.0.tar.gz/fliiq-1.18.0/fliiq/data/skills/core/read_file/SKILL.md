---
name: read_file
description: "Read the contents of a file, with optional line offset and limit."
---

Use this tool to read files from the filesystem. Supports offset/limit for reading specific line ranges of large files. Binary files are detected and rejected. Output is capped at 100KB.
