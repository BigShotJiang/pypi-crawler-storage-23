# {domain} Playbook
#
# This playbook is loaded when Fliiq detects a {domain}-related task.
# It defines operational standards for how the agent approaches {domain} work.
#
# Detection: Fliiq matches keywords in your prompt against the domain name
# and any keywords listed below. Threshold is 2 keyword matches.
#
# Keywords: {domain}
# (Add comma-separated keywords that should trigger this playbook)

## Standards

- [Add your domain-specific standards here]

## Workflow

1. [Define the typical workflow for this domain]

## Rules

- [Add rules the agent should follow for this domain]
