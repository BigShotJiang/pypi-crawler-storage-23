"""Tests for Fliiq TUI widgets."""


from fliiq.cli.tui.widgets import (
    _count_lines,
    _format_tool_detail,
    _format_tool_summary,
    _shorten_path,
)

# ---------------------------------------------------------------------------
# _shorten_path
# ---------------------------------------------------------------------------

class TestShortenPath:
    def test_short_path_unchanged(self):
        assert _shorten_path("src/main.py") == "src/main.py"

    def test_long_path_shortened(self):
        path = "/Users/andychan/Documents/Projects/Very/Deep/Nested/Path/To/File/main.py"
        result = _shorten_path(path, max_len=30)
        assert result.startswith("...")
        assert result.endswith("main.py")

    def test_two_part_path_unchanged(self):
        assert _shorten_path("/main.py", max_len=5) == "/main.py"


# ---------------------------------------------------------------------------
# _count_lines
# ---------------------------------------------------------------------------

class TestCountLines:
    def test_empty(self):
        assert _count_lines("") == 0

    def test_single_line(self):
        assert _count_lines("hello") == 1

    def test_multiple_lines(self):
        assert _count_lines("a\nb\nc") == 3

    def test_trailing_newline(self):
        assert _count_lines("a\nb\n") == 2


# ---------------------------------------------------------------------------
# _format_tool_summary
# ---------------------------------------------------------------------------

class TestFormatToolSummary:
    def test_edit_file(self):
        result = _format_tool_summary(
            "edit_file",
            {"path": "src/main.py", "old_text": "old\nline", "new_text": "new\nline\nextra"},
            "{'result': 'ok'}",
        )
        assert "Update" in result
        assert "main.py" in result
        assert "+3" in result
        assert "-2" in result

    def test_read_file(self):
        result = _format_tool_summary(
            "read_file",
            {"path": "src/utils.py"},
            "{'content': 'line1\\nline2\\nline3'}",
        )
        assert "Read" in result
        assert "utils.py" in result

    def test_write_file(self):
        result = _format_tool_summary(
            "write_file",
            {"path": "out.txt", "content": "line1\nline2"},
            "{'result': 'ok'}",
        )
        assert "Write" in result
        assert "out.txt" in result
        assert "2 lines" in result

    def test_shell(self):
        result = _format_tool_summary(
            "shell",
            {"command": "pytest tests/"},
            "{'exit_code': 0, 'stdout': 'ok', 'stderr': ''}",
        )
        assert "Bash" in result
        assert "pytest" in result
        assert "exit 0" in result

    def test_shell_long_command(self):
        long_cmd = "a" * 100
        result = _format_tool_summary("shell", {"command": long_cmd}, "")
        assert "..." in result

    def test_grep(self):
        result = _format_tool_summary("grep", {"pattern": "TODO"}, "found stuff")
        assert "Grep" in result
        assert "TODO" in result

    def test_web_search(self):
        result = _format_tool_summary("web_search", {"query": "python tui"}, "results")
        assert "WebSearch" in result
        assert "python tui" in result

    def test_unknown_tool(self):
        result = _format_tool_summary("custom_tool", {"arg": "val"}, "output")
        assert "custom_tool" in result
        assert "val" in result

    def test_unknown_tool_no_params(self):
        result = _format_tool_summary("custom_tool", {}, "output")
        assert result == "custom_tool"


# ---------------------------------------------------------------------------
# _format_tool_detail
# ---------------------------------------------------------------------------

class TestFormatToolDetail:
    def test_edit_file_diff(self):
        result = _format_tool_detail(
            "edit_file",
            {"path": "f.py", "old_text": "old_line", "new_text": "new_line"},
            "",
        )
        assert "- old_line" in result
        assert "+ new_line" in result

    def test_shell_stdout(self):
        result = _format_tool_detail(
            "shell",
            {"command": "ls"},
            "{'exit_code': 0, 'stdout': 'file1\\nfile2', 'stderr': ''}",
        )
        assert "file1" in result

    def test_shell_no_output(self):
        result = _format_tool_detail(
            "shell",
            {"command": "true"},
            "{'exit_code': 0, 'stdout': '', 'stderr': ''}",
        )
        assert "(no output)" in result

    def test_read_file_preview(self):
        lines = "\n".join(f"line {i}" for i in range(30))
        result = _format_tool_detail(
            "read_file",
            {"path": "big.py"},
            f"{{'content': '''{lines}'''}}",
        )
        assert "line 0" in result
        assert "more lines" in result

    def test_default_truncation(self):
        long_result = "x" * 1000
        result = _format_tool_detail("unknown", {}, long_result)
        assert len(result) == 500
