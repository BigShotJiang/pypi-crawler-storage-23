# Mixins

::: pydantic_modelable.mixins.ModelableEnumMixin
    handler: python
    options:
      members:
        - __init_subclass__
      show_root_heading: true
      show_source: false
