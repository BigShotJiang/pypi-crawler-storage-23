# Plugin Loader utility

::: pydantic_modelable.loader.PluginLoader
    handler: python
    options:
      members:
        - __init__
        - load
        - loaded
      show_root_heading: true
      show_source: false
