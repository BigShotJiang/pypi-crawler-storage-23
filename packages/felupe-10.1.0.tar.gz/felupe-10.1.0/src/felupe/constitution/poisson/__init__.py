from ._laplace import Laplace

__all__ = [
    "Laplace",
]
