from __future__ import annotations

import sys
import types
import typing
from typing import Any

import typing_extensions

try:
    from typing import _TypingBase  # type: ignore[attr-defined]
except ImportError:
    from typing import _Final as _TypingBase

typing_base = _TypingBase


if sys.version_info < (3, 12):
    # python < 3.12 does not have TypeAliasType
    TypeAliasType = ()
else:
    from typing import TypeAliasType


def origin_is_union(tp: type[Any] | None) -> bool:
    return tp is typing.Union or tp is types.UnionType  # type: ignore


_GenericTypes = (typing._GenericAlias, types.GenericAlias)  # type: ignore[attr-defined]
WithArgsTypes = (*_GenericTypes, types.UnionType)


def origin_is_literal(tp: type[Any] | None) -> bool:
    return tp is typing_extensions.Literal  # type: ignore


class PlainRepr(str):
    """String class where repr doesn't include quotes.

    Useful with Representation when you want to return a string
    representation of something that is valid (or pseudo-valid) python.
    """

    def __repr__(self) -> str:
        return str(self)

    @classmethod
    def for_type(cls, tp: Any, *, modern_union: bool = False) -> PlainRepr:
        """Return a PlainRepr for a type."""
        return PlainRepr(display_as_type(tp, modern_union=modern_union))


def display_as_type(obj: Any, *, modern_union: bool = False) -> str:
    """Pretty representation of a type.

    Should be as close as possible to the original type definition string.
    Takes some logic from `typing._type_repr`.
    """
    if isinstance(obj, types.FunctionType):
        # In python < 3.10, NewType was a function with __supertype__ set to the
        # wrapped type, so NewTypes pass through here
        return obj.__name__
    elif obj is ...:
        return "..."
    elif obj in (None, type(None)):
        return "None"

    if not isinstance(
        obj,
        (
            typing_base,
            WithArgsTypes,
            type,
            TypeAliasType,
            typing.TypeVar,
            typing.NewType,
        ),
    ):
        obj = obj.__class__

    if isinstance(obj, typing.NewType):
        # NewType repr includes the module name prepended, so we use __name__
        # to get a clean name
        # NOTE: ignoring attr-defined because NewType has __name__ but mypy
        # can't see it for some reason; ignoring no-any-return because we
        # know __name__ must return a string
        return obj.__name__  # type: ignore[attr-defined, no-any-return]

    if isinstance(obj, typing.TypeVar):
        # TypeVar repr includes a prepended ~, so we use __name__ to get a clean name
        return obj.__name__

    origin = typing_extensions.get_origin(obj)
    if origin_is_literal(origin):
        # For Literal types, represent the actual values, not their types
        arg_reprs = [repr(arg) for arg in typing_extensions.get_args(obj)]
        return f"Literal[{', '.join(arg_reprs)}]"
    elif origin_is_union(origin):
        args = [display_as_type(x) for x in typing_extensions.get_args(obj)]
        if modern_union:
            return " | ".join(args)
        if len(args) == 2 and "None" in args:
            args.remove("None")
            return f"Optional[{args[0]}]"
        return f"Union[{', '.join(args)}]"
    elif isinstance(obj, _GenericTypes):
        argstr = ", ".join(map(display_as_type, typing_extensions.get_args(obj)))
        return f"{obj.__qualname__}[{argstr}]"
    elif isinstance(obj, type):
        return obj.__qualname__
    else:  # pragma: no cover
        return repr(obj).replace("typing.", "").replace("typing_extensions.", "")
