"""
Tests for Azure context package.
"""
