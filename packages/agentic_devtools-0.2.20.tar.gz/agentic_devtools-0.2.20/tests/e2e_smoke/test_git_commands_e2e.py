"""
E2E smoke tests for Git CLI commands.

These tests validate git workflow commands with mocked git operations
to ensure commands work correctly.
"""

from pathlib import Path

import pytest

from agentic_devtools.state import set_value


class TestGitSaveWorkE2E:
    """End-to-end smoke tests for agdt-git-save-work command."""

    def test_git_save_work_without_commit_message_fails(
        self,
        temp_state_dir: Path,
        clean_state: None,
    ) -> None:
        """
        Smoke test: agdt-git-save-work fails without commit message.

        Validates:
        - Command exits with error when commit_message is missing
        """
        from agentic_devtools.cli.git import commands

        # Arrange - don't set commit_message

        # Act & Assert
        with pytest.raises(SystemExit) as exc_info:
            commands.commit_cmd()

        assert exc_info.value.code == 1, "Should exit with error code 1"

    def test_git_save_work_requires_commit_message_state(
        self,
        temp_state_dir: Path,
        clean_state: None,
    ) -> None:
        """
        Smoke test: agdt-git-save-work reads commit message from state.

        Validates:
        - Command reads commit_message from state
        - Command validates required state before execution
        """
        from agentic_devtools.cli.git import core

        # Arrange - set commit message
        set_value("commit_message", "feat(DFLY-1234): Test commit")

        # Act - verify get_commit_message reads from state
        message = core.get_commit_message()

        # Assert - verify commit message is read from state
        assert message == "feat(DFLY-1234): Test commit"


class TestGitStageE2E:
    """End-to-end smoke tests for agdt-git-stage command."""

    def test_git_stage_command_exists(
        self,
        temp_state_dir: Path,
        clean_state: None,
    ) -> None:
        """
        Smoke test: agdt-git-stage command is callable.

        Validates:
        - Command function exists and is importable
        - Command has correct signature
        """
        from agentic_devtools.cli.git import commands

        # Assert - command should be a callable function
        assert callable(commands.stage_cmd), "stage_cmd should be a callable function"


class TestGitPushE2E:
    """End-to-end smoke tests for git push commands."""

    def test_git_push_command_exists(
        self,
        temp_state_dir: Path,
        clean_state: None,
    ) -> None:
        """
        Smoke test: agdt-git-push command is callable.

        Validates:
        - Command function exists and is importable
        """
        from agentic_devtools.cli.git import commands

        assert callable(commands.push_cmd), "push_cmd should be a callable function"

    def test_git_force_push_command_exists(
        self,
        temp_state_dir: Path,
        clean_state: None,
    ) -> None:
        """
        Smoke test: agdt-git-force-push command is callable.

        Validates:
        - Command function exists and is importable
        """
        from agentic_devtools.cli.git import commands

        assert callable(commands.force_push_cmd), "force_push_cmd should be a callable function"
