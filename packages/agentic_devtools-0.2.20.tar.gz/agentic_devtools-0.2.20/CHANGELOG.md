# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

### Added

- PyPI release command (`agdt-release-pypi`) with test gate,
  build/validate/upload flow, and summary output.
