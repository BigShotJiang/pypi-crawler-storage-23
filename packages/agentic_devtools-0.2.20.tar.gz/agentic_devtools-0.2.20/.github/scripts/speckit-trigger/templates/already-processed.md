## ℹ️ SpecKit: Specification Already Exists

A specification for this issue has already been created.

**Existing Spec**: [`{{existing_spec}}`]({{existing_spec}})

If you need to regenerate the specification, please delete the existing spec directory first.

---
_This comment was posted by the [SpecKit GitHub Action](https://github.com/{{GITHUB_REPOSITORY}}/actions/runs/{{GITHUB_RUN_ID}})._
