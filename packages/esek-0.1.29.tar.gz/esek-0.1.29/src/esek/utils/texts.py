class Errors:
    columns_must_be_two = "Two columns of data are required for this test."