# ESEK

**ESEK (Effect Size Estimation Kit)** is a Python package for calculating effect sizes for statistical tests.

> ⚠️ **Work in progress**
>
> This project is under active development.  
> The API, structure, and available functionality may change without notice.

## Purpose

Provide focused, reusable implementations of effect size calculations for research and data analysis.

## Status

- Early-stage development  
- Not production-ready  
- Documentation incomplete  

Use with caution.

## License

GPL-3.0
