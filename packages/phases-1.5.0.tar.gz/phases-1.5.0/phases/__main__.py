from phases.cli import main

main()
