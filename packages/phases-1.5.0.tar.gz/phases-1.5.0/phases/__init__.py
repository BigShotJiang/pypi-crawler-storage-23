__version__ = "v1.5.0"

from phases.commands.run import Run
from .DefaultProject import DefaultProject


loadProject = Run.loadProject
