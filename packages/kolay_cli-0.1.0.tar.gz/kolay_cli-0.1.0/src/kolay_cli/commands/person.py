import typer
from typing import Optional
from rich.console import Console
from rich.table import Table
import json

from ..api import KolayClient, APIError

app = typer.Typer(help="Manage person/employee records in Kolay.")
console = Console()

@app.command(name="list")
def list_people(page: int = 1, status: str = "active"):
    """
    List people from the Kolay API.
    By default, it lists active employees.
    """
    try:
        client = KolayClient()
        console.print(f"Fetching people... (Page {page}, Status: {status})")
        # Kolay uses POST for v2/person/list
        payload = {"page": page, "status": status}
        response = client.post("v2/person/list", data=payload)
        
        data_resp = response.get("data", {})
        if isinstance(data_resp, dict):
            items = data_resp.get("items", [])
        else:
            items = data_resp

        if not items:
            console.print("[yellow]No people found.[/yellow]")
            return

        table = Table(title=f"Kolay Personnel ({status})")
        table.add_column("ID", style="cyan", no_wrap=True)
        table.add_column("Name", style="magenta")
        table.add_column("Email", style="green")
        table.add_column("Title", style="yellow")

        for person in items:
            # Person object depends on Kolay API response structure
            # Usually has id, firstName, lastName, workEmail etc
            # Fallback to get them gracefully
            pid = str(person.get("id", "N/A"))
            fname = person.get("firstName", person.get("first_name", ""))
            lname = person.get("lastName", person.get("last_name", ""))
            name = f"{fname} {lname}".strip() or person.get("name", "N/A")
            
            email = person.get("workEmail", person.get("email", "N/A"))
            
            # Extract title if present in unitList or another field
            title = person.get("title", "N/A")
            if title == "N/A" and "unitList" in person:
                for unit in person.get("unitList", []):
                    if unit.get("default") or unit.get("active"):
                        for item in unit.get("items", []):
                            if item.get("unitName") == "Unvan":
                                title = item.get("unitItemName", title)

            table.add_row(pid, name, email, title)

        console.print(table)
    except APIError as e:
        console.print(f"[bold red]API Error:[/bold red] {e}")
        raise typer.Exit(1)

@app.command(name="view")
def view_person(person_id: str = typer.Argument(..., help="ID of the person to view")):
    """
    View structured details of a specific person.
    """
    from rich.panel import Panel
    from rich.columns import Columns
    
    try:
        client = KolayClient()
        response = client.get(f"v2/person/view/{person_id}")
        
        data = response.get("data", {})
        person = data.get("person", data) if isinstance(data, dict) else data

        if not person:
            console.print(f"[yellow]Person {person_id} not found or permission denied.[/yellow]")
            return
            
        # Basic Info
        full_name = f"{person.get('firstName', '')} {person.get('lastName', '')}".strip()
        status_val = person.get('status', 'N/A')
        status_color = "green" if status_val == "active" else "red"
        
        console.print(f"\n[bold cyan]Person Profile:[/bold cyan] [bold white]{full_name}[/bold white] [[{status_color}]{status_val}[/{status_color}]]")
        
        # 1. Personal Info Table
        personal_table = Table(show_header=False, box=None)
        personal_table.add_row("[bold]ID:[/bold]", person.get("id"))
        personal_table.add_row("[bold]Email:[/bold]", person.get("workEmail") or person.get("email") or "N/A")
        personal_table.add_row("[bold]Phone:[/bold]", person.get("mobilePhone") or "N/A")
        personal_table.add_row("[bold]Birthday:[/bold]", person.get("birthday") or "N/A")
        personal_table.add_row("[bold]Gender:[/bold]", person.get("gender") or "N/A")
        personal_table.add_row("[bold]ID Number:[/bold]", person.get("idNumber") or "N/A")
        
        # 2. Employment Table
        employment_table = Table(show_header=False, box=None)
        employment_table.add_row("[bold]Start Date:[/bold]", person.get("employmentStartDate") or "N/A")
        
        # Extract unit info
        units = person.get("unitList", [])
        active_unit = next((u for u in units if u.get("active") or u.get("default")), {})
        if active_unit:
            employment_table.add_row("[bold]Type:[/bold]", active_unit.get("employmentType", "N/A"))
            for item in active_unit.get("items", []):
                employment_table.add_row(f"[bold]{item.get('unitName')}:[/bold]", item.get("unitItemName"))

        console.print(Columns([
            Panel(personal_table, title="Personal Information", border_style="blue", expand=True),
            Panel(employment_table, title="Employment", border_style="magenta", expand=True)
        ]))

        # 3. Custom Fields (Data List)
        custom_data = person.get("dataList", [])
        # Filter only non-empty values
        non_empty_custom = [f for f in custom_data if f.get("value")]
        
        if non_empty_custom:
            custom_table = Table(title="Custom Fields", box=None, show_header=True, header_style="bold cyan")
            custom_table.add_column("Field")
            custom_table.add_column("Value")
            for field in non_empty_custom:
                custom_table.add_row(field.get("fieldToken", "N/A"), str(field.get("value")))
            
            console.print(Panel(custom_table, border_style="dim"))

    except APIError as e:
        console.print(f"[bold red]API Error:[/bold red] {e}")
        raise typer.Exit(1)

@app.command(name="leave-status")
def view_leave_status(person_id: str = typer.Argument(..., help="ID of the person to view leave status for")):
    """
    Get structured leave status and balances for a specific person.
    """
    try:
        client = KolayClient()
        response = client.get(f"v2/person/leave-status/{person_id}")
        
        data = response.get("data", [])
        if not data:
            console.print(f"[yellow]No leave status data for person {person_id}.[/yellow]")
            return
            
        console.print(f"\n[bold cyan]Leave Status & Balances:[/bold cyan] (ID: {person_id})")
        
        table = Table(title=None, box=None, header_style="bold cyan")
        table.add_column("Leave Type")
        table.add_column("Paid?", justify="center")
        table.add_column("Total", justify="right")
        table.add_column("Used", justify="right")
        table.add_column("Upcoming", justify="right")
        table.add_column("Remaining", justify="right", style="bold green")
        table.add_column("Next Accrual", justify="center")

        def fmt(val):
            if val is None: return "-"
            try:
                return str(int(val)) if float(val) == int(val) else str(val)
            except (ValueError, TypeError):
                return str(val)

        for leave in data:
            name = leave.get("name", "N/A")
            if leave.get("primary"):
                name = f"[bold white]⭐ {name}[/bold white]"
            
            is_paid = "[green]Yes[/green]" if leave.get("isPaid") else "[red]No[/red]"

            used = leave.get("used", 0)
            upcoming = leave.get("totalUpcoming", 0)
            total = leave.get("total", leave.get("dayLimit", "∞"))
            unused = leave.get("unused")
            
            # If unused is missing, try to calculate or show -
            remaining = fmt(unused) if unused is not None else "∞"
            
            next_date = leave.get("nextAccrualDate", "-")
            
            table.add_row(
                name,
                is_paid,
                fmt(total),
                fmt(used),
                fmt(upcoming),
                remaining,
                next_date
            )

        console.print(table)
        console.print("\n[dim]Note: ⭐ indicates Primary Leave Type.[/dim]")

    except APIError as e:
        console.print(f"[bold red]API Error:[/bold red] {e}")
        raise typer.Exit(1)
        
@app.command(name="terminate")
def terminate_person(
    person_id: str = typer.Argument(..., help="ID of the person to terminate"),
    termination_date: Optional[str] = typer.Option(
        None, 
        help="Termination date (YYYY-MM-DD)",
        show_default=False
    ),
    reason: Optional[str] = typer.Option(None, help="Termination reason")
):
    """
    Terminate employment of a person.
    """
    from datetime import datetime
    
    try:
        client = KolayClient()
        # Pre-check if person exists and is active
        console.print(f"Checking status for person {person_id}...")
        resp = client.get(f"v2/person/view/{person_id}")
        person_data = resp.get("data", {})
        person = person_data.get("person", person_data) if isinstance(person_data, dict) else person_data

        if not person:
             console.print(f"[red]Error: Person {person_id} not found.[/red]")
             return
             
        status = person.get("status")
        if status != "active":
            name = f"{person.get('firstName', '')} {person.get('lastName', '')}".strip()
            console.print(f"[bold red]Stop![/bold red] {name or person_id} is currently [bold yellow]{status}[/bold yellow].")
            console.print("Only active employees can be terminated.")
            return
            
    except APIError as e:
        console.print(f"[bold red]Error checking person status:[/bold red] {e}")
        raise typer.Exit(1)
    
    # Get today's date as default
    today = datetime.now().strftime("%Y-%m-%d")
    
    if termination_date is None:
        termination_date = typer.prompt("Termination date", default=today)
    
    # Try to handle common formats like DD.MM.YYYY
    if "." in termination_date:
        try:
            parts = termination_date.split(".")
            if len(parts) == 3:
                # Convert DD.MM.YYYY to YYYY-MM-DD
                d, m, y = parts
                termination_date = f"{y}-{m.zfill(2)}-{d.zfill(2)}"
        except:
            pass

    REASON_CODES = {
        "01": "Deneme süreli iş sözleşmesinin işverence feshi",
        "02": "Deneme süreli iş sözleşmesinin işçi tarafından feshi",
        "03": "Belirsiz süreli iş sözleşmesinin işçi tarafından feshi (İstifa)",
        "04": "Belirsiz süreli iş sözleşmesinin işveren tarafından haklı sebep bildirilmeden feshi",
        "05": "Belirli süreli iş sözleşmesinin sona ermesi",
        "08": "Emeklilik (Yaşlılık) veya Toptan Ödeme Nedeniyle",
        "09": "Maluliyet Nedeniyle",
        "10": "Ölüm",
        "11": "İş Kazası Sonucu Ölüm",
        "12": "Askerlik",
        "13": "Kadın İşçinin Evlenmesi",
        "14": "Emeklilik İçin Yaş Dışında Diğer Şartların Tamamlanması",
        "15": "Toplu İşçi Çıkarma",
        "17": "İşyerinin Kapanması",
        "18": "İşin Sona Ermesi",
        "19": "Mevsimlik İşin Sona Ermesi",
        "20": "Kampanya İşinin Sona Ermesi",
        "21": "Statü Değişikliği",
        "22": "Diğer Nedenler",
        "23": "İşçi Kuruluşunda Görev Alınması",
        "24": "Sözleşme Başlamadan Fesih",
        "25": "İşçi Tarafından Zorunlu Nedenle Fesih",
        "26": "İşçi Tarafından İşverenin Ahlak ve İyi Niyet Kurallarına Aykırı Davranışı Nedeniyle Fesih",
        "27": "İşveren Tarafından İşçinin Ahlak ve İyi Niyet Kurallarına Aykırı Davranışı Nedeniyle Fesih",
        "28": "Sağlık Nedeniyle İşçi Tarafından Fesih",
        "29": "Sağlık Nedeniyle İşveren Tarafından Fesih",
        "30": "Vize Süresinin Sona Ermesi",
        "31": "Borçlar Kanunu, Sendikalar Kanunu, Grev ve Lokavt Kanunu Kapsamında Fesih",
        "32": "4046 Sayılı Kanun Kapsamında Özelleştirme Nedeniyle Fesih",
        "33": "Gazeteci Tarafından Sözleşmenin Feshi",
        "34": "İşyerinin Devri, İşin veya İşyerinin Niteliğinin Değişmesi Nedeniyle Fesih",
        "36": "KHK ile Kamu Görevinden Çıkarılma",
        "37": "KHK ile Kamu Görevinden İade Edilme",
        "40": "696 Sayılı KHK ile Kamu İşçiliğine Geçiş",
        "41": "696 Sayılı KHK ile Kamu İşçiliğine Geçişte Başarısızlık",
    }

    if reason is None:
        console.print("\n[bold cyan]Turkish Termination (SGK) Reason Codes:[/bold cyan]")
        codes_table = Table(box=None, header_style="bold magenta", padding=(0, 2))
        codes_table.add_column("Code", width=4)
        codes_table.add_column("Description")
        
        # Show top common codes first or just a selection
        for c in ["01", "03", "04", "05", "12", "13", "17", "22", "27"]:
            codes_table.add_row(c, REASON_CODES[c])
        codes_table.add_row("..", "Enter 'all' to see all codes")
        
        console.print(codes_table)
        
        reason_code = typer.prompt("Reason Code", default="03")
        if reason_code.lower() == "all":
            full_table = Table(title="All Reason Codes", header_style="bold magenta")
            full_table.add_column("Code")
            full_table.add_column("Description")
            for c, desc in sorted(REASON_CODES.items()):
                full_table.add_row(c, desc)
            console.print(full_table)
            reason_code = typer.prompt("Reason Code", default="03")
            
        details = typer.prompt("Details", default=REASON_CODES.get(reason_code, ""))
    else:
        reason_code = "03"
        details = reason

    try:
        client = KolayClient()
        payload = {
            "personId": person_id,
            "date": termination_date,
            "reasonCode": reason_code,
            "details": details
        }
        
        console.print(f"Terminating person {person_id} with date [bold cyan]{termination_date}[/bold cyan] and reason code [bold magenta]{reason_code}[/bold magenta]...")
        client.post("v2/person/terminate", data=payload)
        console.print("[bold green]Success![/bold green] Operation completed.")
        
    except APIError as e:
        console.print(f"[bold red]API Error:[/bold red] {e}")
        raise typer.Exit(1)
