import typer
from ..config import set_config_value, get_api_token
from rich.console import Console

app = typer.Typer(help="Auth commands for the Kolay CLI.")
console = Console()

@app.command()
def login(token: str = typer.Option(..., prompt="Please enter your Kolay API token", hide_input=True)):
    """
    Save your Kolay API token for future CLI use.
    """
    # Simple check if token works (maybe we can hit a profile endpoint later, for now we just save it)
    set_config_value("api_token", token)
    console.print(f"[green]Successfully saved API token to your configuration.[/green]")

@app.command()
def status():
    """
    Check if you are currently logged in.
    """
    token = get_api_token()
    if token:
        console.print(f"[green]You are logged in.[/green] (Token: ...{token[-4:] if len(token) > 4 else ''})")
    else:
        console.print("[red]You are NOT logged in.[/red] Please run [bold cyan]kolay auth login[/bold cyan].")
