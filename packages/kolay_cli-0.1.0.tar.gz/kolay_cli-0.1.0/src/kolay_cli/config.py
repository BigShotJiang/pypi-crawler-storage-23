import json
import os
from pathlib import Path
from typing import Optional

CONFIG_DIR = Path.home() / ".config" / "kolay"
CONFIG_FILE = CONFIG_DIR / "config.json"

def get_config_value(key: str) -> Optional[str]:
    """Get a value from the config file or environment variables."""
    # Environment variables have precedence
    env_val = os.getenv(f"KOLAY_{key.upper()}")
    if env_val:
        return env_val

    if not CONFIG_FILE.exists():
        return None

    try:
        with open(CONFIG_FILE, "r") as f:
            data = json.load(f)
            return data.get(key)
    except Exception:
        return None

def set_config_value(key: str, value: str):
    """Set a value in the config file and ensure restricted permissions."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    
    data = {}
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r") as f:
                data = json.load(f)
        except Exception:
            pass
            
    data[key] = value
    
    # Create or overwrite file with restricted permissions
    # We use a temp file or just write it then chmod
    with open(CONFIG_FILE, "w") as f:
        json.dump(data, f, indent=4)
    
    try:
        os.chmod(CONFIG_FILE, 0o600)
    except Exception:
        pass # Fallback for environments where chmod might fail

def get_api_token() -> Optional[str]:
    return get_config_value("api_token")

def get_base_url() -> str:
    return get_config_value("base_url") or "https://api.kolayik.com"
