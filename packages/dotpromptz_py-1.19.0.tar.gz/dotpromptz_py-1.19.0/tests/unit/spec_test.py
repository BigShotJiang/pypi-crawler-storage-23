"""Runs specification tests defined in YAML files located in the `spec` directory.

These YAML files define test suites for Dotprompt templates.
The general structure of each YAML file is a list of test suites.

- Each YAML file is a set of test suites.
- Each test suite is a set of tests.
- Each test is a set of expectations.

Each test suite object in the list typically contains the following keys:

| Key                | Type   | Description                                                                          |
|--------------------|--------|--------------------------------------------------------------------------------------|
| `name`             | string | An identifier for this group of tests.                                               |
| `template`         | string | The Dotprompt template content (often multi-line, and may include YAML frontmatter). |
| `tests`            | list   | A list of individual test scenarios. Each scenario object has keys: `desc` (string), |
|                    |        | `data` (object, optional), `expect` (object).                                        |

Each test scenario object (i.e., an item in the `tests` list) has the following keys:

| Key      | Type   | Description                                                         |
|----------|--------|---------------------------------------------------------------------|
| `desc`   | string | A description of the specific test case.                            |
| `data`   | object | (Optional) Input data for the template. This can include `context`, |
|          |        | `input`, or other variables relevant to the template.               |
| `expect` | object | Defines the expected outcome. Common keys include                   |
|          |        | (list), and others corresponding to parsed frontmatter (`config`,   |
|          |        | `model`, `output.schema`, `input.schema`, `ext`, `raw`).            |

The YAML files located in the `spec/helpers` subdirectory also follow this
general structure, but are specifically focused on testing individual helper
functions available within the Dotprompt templating environment.

The structure of the YAML files is as follows:

```
spec/
├── *.yaml (e.g., metadata.yaml, picoschema.yaml, etc.)
│   └── List of Test Suites
│       └── Test Suite 1
│           ├── name: "suite_name_1"
│           ├── template: "..."

│           └── tests:
│               ├── Test Case 1.1
│               │   ├── desc: "description_1.1"
│               │   ├── data: { ... } (optional)
│               │   └── expect: { ... }
│               ├── Test Case 1.2
│               │   ├── desc: "description_1.2"
│               │   ├── data: { ... } (optional)
│               │   └── expect: { ... }
│               └── ... (more test cases)
│       └── Test Suite 2
│           ├── name: "suite_name_2"
│           ├── template: "..."
│           └── tests:
│               ├── Test Case 2.1
│               │   ├── desc: "description_2.1"
│               │   └── expect: { ... }
│               └── ... (more test cases)
│       └── ... (more test suites)
│
└── helpers/
    ├── *.yaml (e.g., history.yaml, json.yaml, ifEquals.yaml, etc.)
    │   └── List of Test Suites (same structure as above)
    │       └── Test Suite H1
    │           ├── name: "helper_suite_name_1"
    │           ├── template: "..."
    │           └── tests:
    │               ├── Test Case H1.1
    │               │   ├── desc: "description_H1.1"
    │               │   └── expect: { ... }
    │               └── ...
    └── ... (more helper spec files)
```
"""

import logging
import re
import unittest
from collections.abc import Callable
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field

from dotpromptz.dotprompt import Dotprompt
from dotpromptz.typing import (
    JsonSchema,
    Message,
    ModelConfigT,
    PromptInputConfig,
    PromptMetadata,
    PromptOutputConfig,
    ToolDefinition,
)

logger = logging.getLogger(__name__)


CURRENT_FILE = Path(__file__)
ROOT_DIR = CURRENT_FILE.parent.parent.parent
SPECS_DIR = ROOT_DIR / 'tests' / 'spec'

# List of files that are allowed to be used as spec files.
# Useful for debugging and testing.
ALLOWLISTED_FILES = [
    'tests/spec/helpers/ifEquals.yaml',
    'tests/spec/helpers/json.yaml',
    'tests/spec/helpers/media.yaml',
    'tests/spec/helpers/role.yaml',
    'tests/spec/helpers/unlessEquals.yaml',
    'tests/spec/metadata.yaml',
    'tests/spec/picoschema.yaml',
    'tests/spec/unicode.yaml',
    'tests/spec/variables.yaml',
    'tests/spec/whitespace.yaml',
]

# Counters for test class and test method names.
suite_counter = 0
test_case_counter = 0


class Expect(BaseModel):
    """An expectation for the spec."""

    config: dict[Any, Any] = Field(default_factory=dict)
    input: PromptInputConfig | None = None
    output: PromptOutputConfig | None = None
    messages: list[Message] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class SpecTest[ModelConfigT](BaseModel):
    """A test case for a YAML spec."""

    desc: str = Field(default='UnnamedTest')
    data: dict[str, Any] | None = None
    expect: Expect
    options: PromptMetadata[ModelConfigT] | None = None


class SpecSuite[ModelConfigT](BaseModel):
    """A suite of test cases for a YAML spec."""

    name: str = Field(default='UnnamedSuite')
    template: str
    data: dict[str, Any] | None = None
    schemas: dict[str, JsonSchema] | None = None
    tools: dict[str, ToolDefinition] | None = None
    tests: list[SpecTest[ModelConfigT]] = Field(default_factory=list)


def is_allowed_spec_file(file: Path) -> bool:
    """Check if a spec file is allowed.

    Args:
        file: The file to check.

    Returns:
        True if the file is allowed, False otherwise.
    """
    fname = file.absolute().as_posix()
    for allowed_file in ALLOWLISTED_FILES:
        if fname.endswith(allowed_file):
            return True
    return False


def sanitize_name_component(name: str | None) -> str:
    """Sanitizes a name component for use in a Python identifier.

    Args:
        name: The name to sanitize.

    Returns:
        A sanitized name.
    """
    name_str = str(name) if name is not None else 'None'
    name_str = re.sub(r'[^a-zA-Z0-9_]', '_', name_str)
    if name_str and name_str[0].isdigit():
        name_str = '_' + name_str
    return name_str or 'unnamed_component'


def make_test_method_name(yaml_file_name: str, suite_name: str | None, test_desc: str | None) -> str:
    """Creates a sanitized test method name.

    Args:
        yaml_file_name: The name of the YAML file.
        suite_name: The name of the suite.
        test_desc: The description of the test.

    Returns:
        A sanitized test method name.
    """
    file_part = sanitize_name_component(yaml_file_name.replace('.yaml', ''))
    suite_part = sanitize_name_component(suite_name)
    desc_part = sanitize_name_component(test_desc)
    return f'test_{file_part}_{suite_part}_{desc_part}_'


def make_test_class_name(yaml_file_name: str, suite_name: str | None) -> str:
    """Creates a sanitized test class name for a suite.

    Args:
        yaml_file_name: The name of the YAML file.
        suite_name: The name of the suite.

    Returns:
        A sanitized test class name.
    """
    file_part = sanitize_name_component(yaml_file_name.replace('.yaml', ''))
    suite_part = sanitize_name_component(suite_name)
    return f'Test_{file_part}_{suite_part}Suite'


def make_dotprompt_for_suite(suite: SpecSuite[ModelConfigT]) -> Dotprompt:
    """Constructs and sets up a Dotprompt instance for the given suite.

    Args:
        suite: The suite to construct a Dotprompt for.

    Returns:
        A Dotprompt instance.
    """
    dotprompt = Dotprompt(
        schemas=suite.schemas,
        tools=suite.tools,
    )
    return dotprompt


class TestSpecFiles(unittest.TestCase):
    """Runs essential checks to ensure the spec directory is valid."""

    def test_spec_path(self) -> None:
        """Test that the spec directory exists."""
        self.assertTrue(SPECS_DIR.exists())
        self.assertTrue(SPECS_DIR.is_dir())

    def test_spec_path_contains_yaml_files(self) -> None:
        """Test that the spec directory contains YAML files."""
        self.assertTrue(list(SPECS_DIR.glob('**/*.yaml')))

    def test_spec_files_are_valid(self) -> None:
        """Test that all spec files contain valid YAML."""
        for file in SPECS_DIR.glob('**/*.yaml'):
            with open(file) as f:
                data = yaml.safe_load(f)
                self.assertIsNotNone(data)


class YamlSpecTestBase[ModelConfigT](unittest.TestCase):
    """A base class that is used as a template for all YAML spec test suites."""

    def run_yaml_test(self, yaml_file: Path, suite: SpecSuite[ModelConfigT], test_case: SpecTest[ModelConfigT]) -> None:
        """Runs a YAML test.

        Args:
            yaml_file: The path to the YAML file.
            suite: The suite to run the test on.
            test_case: The test case to run.

        Returns:
            None.
        """
        logger.info(f'[TEST] {yaml_file.stem} > {suite.name} > {test_case.desc}')

        # Create test-specific dotprompt instance.
        dotprompt = make_dotprompt_for_suite(suite)
        self.assertIsNotNone(dotprompt)

        merged_data = self._merge_data(suite.data, test_case.data)
        input_data = merged_data.get('input') if merged_data else None
        result = dotprompt.render(suite.template, input=input_data, options=test_case.options)
        pruned_res: Expect = Expect(**result.model_dump())


        self.assertEqual(pruned_res, test_case.expect)

    def _merge_data(self, data1: dict[str, Any] | None, data2: dict[str, Any] | None) -> dict[str, Any] | None:
        """Merges two data dictionaries."""
        if not data1 and not data2:
            return None
        return {**(data1 or {}), **(data2 or {})}


def make_suite_class_name(yaml_file: Path, suite_name: str | None) -> str:
    """Creates a class name for a suite.

    Args:
        yaml_file: The path to the YAML file.
        suite_name: The name of the suite.

    Returns:
        A class name for the suite.
    """
    global suite_counter
    suite_counter += 1
    file_part = sanitize_name_component(yaml_file.stem)
    suite_part = sanitize_name_component(suite_name)
    return f'Test_{file_part}_{suite_part}Suite_{suite_counter}'


def make_test_case_name(yaml_file: Path, suite_name: str, test_desc: str) -> str:
    """Creates a test case name.

    Args:
        yaml_file: The path to the YAML file.
        suite_name: The name of the suite.
        test_desc: The description of the test.

    Returns:
        A test case name.
    """
    global test_case_counter
    test_case_counter += 1
    file_part = sanitize_name_component(yaml_file.stem)
    suite_part = sanitize_name_component(suite_name)
    test_method_part = sanitize_name_component(test_desc)
    return f'test_{file_part}_{suite_part}_{test_method_part}_{test_case_counter}'


def make_test_case_method(
    yaml_file: Path,
    suite: SpecSuite[ModelConfigT],
    test_case: SpecTest[ModelConfigT],
) -> Callable[[YamlSpecTestBase[ModelConfigT]], None]:
    """Creates a test method for a test case.

    Args:
        yaml_file: The path to the YAML file.
        suite: The suite to create the test method for.
        test_case: The test case to create the test method for.

    Returns:
        A test method.
    """

    def test_method(self_dynamic: YamlSpecTestBase[ModelConfigT]) -> None:
        """A test method."""
        self_dynamic.run_yaml_test(yaml_file, suite, test_case)

    return test_method


def make_async_skip_test_method(yaml_file: Path, suite_name: str) -> Callable[[YamlSpecTestBase[ModelConfigT]], None]:
    """Creates a skip test for a suite.

    Args:
        yaml_file: The path to the YAML file.
        suite_name: The name of the suite.

    Returns:
        A skip test.
    """

    def skip_method(self_dynamic: YamlSpecTestBase[ModelConfigT]) -> None:
        self_dynamic.skipTest(f"Suite '{suite_name}' in {yaml_file.stem} has no tests.")

    return skip_method


def generate_test_suites(files: list[Path]) -> None:
    """Dynamically generates test suite classes and methods from YAML spec files.

    Args:
        files: A list of YAML spec files to generate test suites from.

    Returns:
        None.
    """
    module_globals = globals()

    for yaml_file in files:
        if not is_allowed_spec_file(yaml_file):
            logger.warning('Skipping non-allowlisted spec file for class generation, file=%s', yaml_file)
            continue

        # Load the YAML file and ensure it's valid.
        try:
            with open(yaml_file, encoding='utf-8') as f:
                suites_data = yaml.safe_load(f)
            if not suites_data:
                logger.warning('Skipping spec file with no data, file=%s', yaml_file)
                continue
        except yaml.YAMLError as e:
            logger.error('Error loading spec file, file=%s, error=%s', yaml_file, e)
            raise

        # Iterate over the suites in the YAML file and ensure it has a name.
        for suite_data in suites_data:
            # Normalize the suite data to ensure it has a name.
            suite = SpecSuite(**suite_data)
            suite.name = suite.name or f'UnnamedSuite_{yaml_file.stem}'

            # Create the dynamic test class for the suite.
            class_name = make_suite_class_name(yaml_file, suite.name)
            klass = type(class_name, (YamlSpecTestBase,), {})

            # Skip the suite if it has no tests.
            if not suite.tests:
                klass.test_empty_suite = make_async_skip_test_method(yaml_file, suite.name)  # type: ignore[attr-defined]

            # Iterate over the tests in the suite and add them to the class.
            for tc in suite.tests:
                # Create the test case method and add it to the class.
                test_case_name = make_test_case_name(yaml_file, suite.name, tc.desc)
                test_method = make_test_case_method(yaml_file, suite, tc)
                setattr(klass, test_case_name, test_method)

            # Add the test suite class to the module globals.
            module_globals[class_name] = klass


generate_test_suites(list(SPECS_DIR.glob('**/*.yaml')))

if __name__ == '__main__':
    unittest.main()
