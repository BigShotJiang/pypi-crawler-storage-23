"""Dotpromptz: Python implementation of the Dotprompt executable prompt template format.

Provides parsing, rendering, and execution of .prompt files that combine
YAML frontmatter metadata with Jinja2 templates for generative AI prompts.
"""

from .credentials import Credential, CredentialPool, load_credentials
from .dotprompt import Dotprompt, TemplateMissingVariableError
from .inputs import infer_schema, resolve_files, resolve_input
from .logging import configure_logging
from .runner import (
    BatchResult,
    extract_response_content,
    part_to_dict,
    resolve_adapter,
    run,
    serialize_result,
    write_output,
)
from .version import CURRENT_MAJOR, PromptVersionError

__all__ = [
    'BatchResult',
    'CURRENT_MAJOR',
    'configure_logging',
    'Credential',
    'CredentialPool',
    'Dotprompt',
    'PromptVersionError',
    'TemplateMissingVariableError',

    'extract_response_content',
    'infer_schema',
    'load_credentials',
    'part_to_dict',
    'resolve_adapter',
    'resolve_files',
    'resolve_input',
    'run',
    'serialize_result',
    'write_output',
]
