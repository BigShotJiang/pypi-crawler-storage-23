# Repository Analysis Journal

This document contains ongoing technical reviews of the cvxcla repository.

---

## 2026-02-28 — Analysis Entry

### Summary

**cvxcla** is a focused, well-engineered Python implementation of Markowitz's Critical Line Algorithm for portfolio optimization. The codebase is clean, professionally structured, and production-ready with 100% test coverage. It leverages the **rhiza** framework for standardized Python development infrastructure, providing extensive automation and quality gates. The core algorithm implementation is mathematically sophisticated and appropriately documented.

### Strengths

- **Minimal, focused scope**: Only 5 Python modules in `src/cvxcla/` (`__init__.py`, `cla.py`, `first.py`, `optimize.py`, `types.py`) implementing a well-defined mathematical algorithm
- **Excellent test coverage**: Achieves 100% test coverage (per recent commit ff52f60), with 7 test files including dedicated benchmarks in `tests/benchmarks/`
- **Strong academic foundation**: README explicitly references three key papers (Niedermayer, Bailey/Lopez de Prado, Markowitz et al.) with implementation notes on improvements made
- **Immutable data structures**: Uses `@dataclass(frozen=True)` throughout (`CLA`, `FrontierPoint`, `TurningPoint`), promoting correctness and preventing mutation bugs
- **Type annotations**: Full use of `numpy.typing.NDArray` and type hints for function signatures
- **Modern dependency management**: Uses `uv` for deterministic builds with locked dependencies (`uv.lock`), Python 3.12 via `.python-version`
- **Comprehensive CI/CD**: 15 GitHub Actions workflows (prefixed with `rhiza_*`) covering CI, security (CodeQL, secret scanning), dependency checks (deptry), pre-commit, DevContainer builds, benchmarks, and documentation
- **Rich documentation**: Dedicated `docs/` folder with 10 markdown files covering architecture, testing, security, Marimo notebooks, and customization
- **Interactive documentation**: Marimo notebooks in `book/marimo/` for exploratory analysis and tutorials
- **Zero technical debt markers**: No TODO/FIXME/XXX/HACK comments found in source or tests
- **Minimal runtime dependencies**: Only 3 core dependencies (`numpy>=2.0.0`, `plotly>=6.0.1`, `kaleido==1.2.0`), all well-maintained projects
- **Custom 1D optimizer**: `optimize.py` implements a golden section search to avoid scipy dependency (reducing attack surface and install size)
- **Professional licensing**: Apache 2.0 license with copyright headers in all source files
- **Comprehensive pre-commit hooks**: 11 hooks including ruff, bandit (security), actionlint, pyproject validation, and rhiza-specific checks
- **Strict linting**: Extensive ruff configuration (120+ line `ruff.toml`) enforcing pydocstyle, pyflakes, isort, pyupgrade, bugbear, security checks

### Weaknesses

- **Python version discrepancy**: `pyproject.toml` requires Python >=3.11, but `.python-version` specifies 3.12, and README mentions 3.12. This inconsistency could confuse users or cause installation issues.
- **Dev dependencies unclear purpose**: `pyproject.toml` includes `mosek==11.1.6` (commercial optimization solver) in dev dependencies without explanation—no evidence of usage in tests or benchmarks
- **Kaleido pinned at 1.2.0**: Unusually specific pin for `kaleido` (Plotly static export) compared to other deps. `tool.deptry` explicitly ignores it (DEP002), suggesting it may not be directly imported—potential for removal or upgrade
- **Experiments folder unmanaged**: 9 Python files in `experiments/` (fusion1.py, fusion2.py, fusion3.py, minvar.py, etc.) with no clear purpose, documentation, or integration into tests/docs. Risk of code rot.
- **Limited API surface**: Only exports `CLA` class from `__init__.py`. Users cannot directly access `Frontier`, `FrontierPoint`, `TurningPoint` types without internal imports, limiting extensibility
- **No explicit changelog**: No CHANGELOG.md file tracking version history and breaking changes (current version 1.5.1 per pyproject.toml)
- **Documentation build process unclear**: References to `make book` in README but minimal documentation on how the book is structured or published to cvxgrp.org
- **No performance benchmarks published**: `tests/benchmarks/` exists but no CI job publishes results or tracks regression over time (though `rhiza_benchmarks.yml` workflow exists)

### Risks / Technical Debt

- **No integration tests**: All tests appear to be unit tests. No tests verify end-to-end portfolio optimization against known datasets or external solvers like CVXPY/scipy.optimize
- **Numerical stability untested at scale**: No tests with large portfolios (n>100 assets) or ill-conditioned covariance matrices to verify numerical stability
- **Custom optimizer edge cases**: `optimize.py` contains test-only parameter `_test_mode` with 'left_overflow', 'right_overflow' cases, suggesting known edge cases that may not be fully hardened
- **Sparse matrix opportunity**: `cla.py` comment mentions "Rather than using their sparse matrix construction, we bisect the weights into free and blocked parts" (line 172 reference in README). For large portfolios, this could be a performance bottleneck.
- **Error handling incomplete**: `first.py` raises `ValueError` for constraint violations but no try/except guidance for users. No custom exception hierarchy.
- **Dependency on rhiza framework**: Heavy reliance on external framework (`.rhiza/rhiza.mk` with 15 workflows) creates maintenance burden if framework evolves or becomes unmaintained
- **Marimo notebook compatibility risk**: Marimo is at 0.20.2 (early stage). If API changes, interactive docs may break.
- **No migration guide from competitors**: README lists PyCLA and CLA (Bailey/Lopez de Prado) as alternatives but no migration guide for users switching

### Score

**8.5 / 10**

This is a solid, production-grade implementation with excellent engineering practices. The algorithm is mathematically rigorous, the code is clean and well-tested, and the CI/CD infrastructure is comprehensive. The use of immutable dataclasses, type hints, and 100% test coverage demonstrates high-quality standards.

The score is not higher due to: (1) minor inconsistencies in Python version declarations, (2) unexplained dev dependencies, (3) unmanaged experiments folder, and (4) lack of large-scale numerical stability testing. However, these are minor issues that do not fundamentally compromise the library's reliability for typical portfolio optimization use cases (n<50 assets).

**Recommendation**: Suitable for production use in quantitative finance applications. Address Python version consistency and clarify the purpose of experiments/ and mosek dependency before 2.0 release.

