""" single_select.py -- executes the Select Action """

from mx.actions.select import Select


class SingleSelect(Select):

    def __init__(self, non_scalar_flow):
        super.__init__()

    def execute(self):
        pass
