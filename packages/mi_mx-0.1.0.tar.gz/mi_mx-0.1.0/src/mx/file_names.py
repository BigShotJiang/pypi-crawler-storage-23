""" file_names.py -- file names and extensions used throughout this package """

context_file_ext = ".sip"  # Scenario initial population
scenario_file_ext = ".scn"  # Interactions with a populated domain


