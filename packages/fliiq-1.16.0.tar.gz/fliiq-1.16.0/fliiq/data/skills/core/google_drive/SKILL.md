---
name: google_drive
description: "Manage Google Drive: list, search, upload, download, export, create folders, delete files. Supports multiple Google accounts. Requires OAuth via `fliiq google auth`."
---

Use this tool to manage files and folders in Google Drive. Supports listing, searching, uploading, exporting, and organizing files across multiple accounts.

## Setup Required
1. Create a Google Cloud project at https://console.cloud.google.com/
2. Enable the Google Drive API
3. Create OAuth 2.0 credentials (Desktop app type), set redirect URI to http://localhost:8080/callback
4. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in your .env file
5. Run `fliiq google auth` to authorize each Google account

If you authorized before Drive support was added, run `fliiq google auth` again to grant Drive permissions.

## Available Actions
- list_files: List files in a folder (defaults to root)
- search_files: Search files by name or content using Drive query syntax
- get_metadata: Get full metadata for a file by ID
- create_folder: Create a new folder
- upload_file: Upload a file (text or base64 content, max 5MB)
- export_file: Export a Google Workspace file to another format (e.g. Docs to PDF, Sheets to CSV)
- delete_file: Move a file to trash (recoverable)

## Multi-Account
Use the `account_email` parameter to specify which Google account to use. Defaults to the first authorized account.

## Search Query Syntax
The `query` parameter for search_files uses Google Drive query syntax:
- `name contains 'budget'` — files with "budget" in the name
- `mimeType = 'application/vnd.google-apps.spreadsheet'` — only spreadsheets
- `modifiedTime > '2026-01-01T00:00:00'` — modified after a date
- `'folder_id' in parents` — files in a specific folder

## Common MIME Types for Export
- Google Docs: `application/pdf`, `text/plain`, `application/vnd.openxmlformats-officedocument.wordprocessingml.document`
- Google Sheets: `text/csv`, `application/pdf`, `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`
- Google Slides: `application/pdf`, `application/vnd.openxmlformats-officedocument.presentationml.presentation`
