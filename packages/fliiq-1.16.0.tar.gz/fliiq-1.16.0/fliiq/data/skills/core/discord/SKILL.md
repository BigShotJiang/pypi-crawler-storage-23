---
name: discord
description: "Send messages, react with emoji, list channels, and read message history in Discord servers."
---

Use this tool to interact with Discord servers. Supports sending messages, adding emoji reactions, listing channels, and reading recent messages.

## Setup
1. Go to https://discord.com/developers/applications and click "New Application"
2. Go to the **Bot** tab and click "Reset Token" — copy the token immediately (shown once)
3. Enable **Message Content Intent** under Privileged Gateway Intents (required to read message text)
4. Go to **Installation** > generate an invite URL with scopes `bot` + `applications.commands`
5. Select permissions: Send Messages, Read Message History, Add Reactions, View Channels
6. Open the invite URL in your browser and authorize the bot to your server

Add to your `.env` file:
```
DISCORD_BOT_TOKEN=your-bot-token-here
```

## Important Notes
- **Message Content Intent** must be enabled or `message.content` will be empty
- Bot must be **invited to each server** individually
- For bots in 75+ servers, Discord requires privileged intent approval
