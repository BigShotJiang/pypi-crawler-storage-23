import os
from pathlib import Path

MAX_RESULTS = 1000

_SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv", ".tox", ".mypy_cache", ".ruff_cache"}


async def handler(params: dict) -> dict:
    """Find files matching a glob pattern."""
    pattern = params["pattern"]
    path = params.get("path") or os.getcwd()
    limit = params.get("limit") or MAX_RESULTS

    root = Path(path)
    if not root.is_dir():
        raise NotADirectoryError(f"Not a directory: {path}")

    results = []
    for match in root.rglob(pattern):
        # Skip excluded directories
        parts = match.relative_to(root).parts
        if any(part in _SKIP_DIRS for part in parts):
            continue

        results.append(str(match))
        if len(results) >= limit:
            break

    output = "\n".join(sorted(results))
    if not results:
        output = f"No files found matching: {pattern}"

    return {"files": output}
