---
name: shell
description: "Execute a shell command and return stdout, stderr, and exit code."
---

Use this tool to run shell commands. Supports configurable working directory and timeout. Output capped at 100KB. Use for git operations, package management, build commands, etc.
