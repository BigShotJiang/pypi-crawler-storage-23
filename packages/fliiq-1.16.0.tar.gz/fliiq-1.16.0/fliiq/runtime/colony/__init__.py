"""Fliiq Colony — self-improving multi-agent system."""
