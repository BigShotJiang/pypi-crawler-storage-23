"""
Verify decision token (RS256) with public key only.
Uses 'cryptography' if available; otherwise verification is skipped (caller can check).
"""

import base64
import json
from typing import Any, Dict, Optional

ISS = "blockintel-gate"
AUD = "gate-decision"


def _decode_jwt_unsafe(token: str) -> Optional[Dict[str, Any]]:
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        payload_b64 = parts[1]
        padding = 4 - len(payload_b64) % 4
        if padding != 4:
            payload_b64 += "=" * padding
        payload = json.loads(base64.urlsafe_b64decode(payload_b64))
        header_b64 = parts[0]
        padding = 4 - len(header_b64) % 4
        if padding != 4:
            header_b64 += "=" * padding
        header = json.loads(base64.urlsafe_b64decode(header_b64))
        return {"header": header, "payload": payload}
    except Exception:
        return None


def verify_decision_token_rs256(token: str, public_key_pem: str) -> Optional[Dict[str, Any]]:
    """Verify RS256 JWT and return payload if valid; None otherwise."""
    decoded = _decode_jwt_unsafe(token)
    if not decoded or (decoded["header"].get("alg") or "").upper() != "RS256":
        return None
    payload = decoded["payload"]
    import time
    now = int(time.time())
    if payload.get("iss") != ISS or payload.get("aud") != AUD:
        return None
    if payload.get("exp") is not None and payload["exp"] < now - 5:
        return None
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding
        from cryptography.hazmat.backends import default_backend

        parts = token.split(".")
        signing_input = (parts[0] + "." + parts[1]).encode("utf8")
        raw_sig = base64.urlsafe_b64decode(parts[2] + "==")
        key = serialization.load_pem_public_key(
            public_key_pem.encode() if isinstance(public_key_pem, str) else public_key_pem,
            backend=default_backend(),
        )
        key.verify(
            raw_sig,
            signing_input,
            padding.PKCS1v15(),
            hashes.SHA256(),
        )
        return payload
    except Exception:
        return None
