"""
Unit tests for gate_sdk.utils (canonical_json, sha256_hex, clamp, now_ms, now_epoch_seconds).
"""

from gate_sdk.utils import canonical_json, sha256_hex, clamp, now_ms, now_epoch_seconds


def test_canonical_json_scalar_returns_unchanged():
    """Exercise the non-dict/non-list branch in sort_keys_recursive."""
    result = canonical_json(42)
    assert result == b"42"
    result = canonical_json("hello")
    assert result == b'"hello"'


def test_clamp_direct():
    assert clamp(50, 10, 100) == 50
    assert clamp(5, 10, 100) == 10
    assert clamp(150, 10, 100) == 100


def test_now_ms_and_now_epoch_seconds():
    t_ms = now_ms()
    t_s = now_epoch_seconds()
    assert t_ms >= 0
    assert t_s >= 0
    assert t_ms >= t_s * 1000 - 1000
    assert t_ms <= t_s * 1000 + 1000
