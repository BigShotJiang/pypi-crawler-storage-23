"""
Unit tests for gate_sdk.provenance (Provenance, ProvenanceProvider).
"""

import os
import pytest

from gate_sdk.provenance import Provenance, ProvenanceProvider


class TestProvenance:
    def test_to_dict_empty(self):
        p = Provenance()
        assert p.to_dict() == {}

    def test_to_dict_with_values(self):
        p = Provenance(
            repo="org/repo",
            workflow="ci.yml",
            ref="main",
            actor="bot",
            attestation={"valid": True},
        )
        d = p.to_dict()
        assert d["repo"] == "org/repo"
        assert d["workflow"] == "ci.yml"
        assert d["ref"] == "main"
        assert d["actor"] == "bot"
        assert d["attestation"] == {"valid": True}

    def test_to_dict_omits_none(self):
        p = Provenance(repo="r", workflow=None)
        d = p.to_dict()
        assert "repo" in d
        assert "workflow" not in d


class TestProvenanceProvider:
    def test_get_provenance_returns_none_when_no_env(self):
        with _clear_provenance_env():
            assert ProvenanceProvider.get_provenance() is None

    def test_get_provenance_returns_provenance_when_repo_set(self):
        with _clear_provenance_env():
            os.environ["GATE_CALLER_REPO"] = "acme/app"
            try:
                p = ProvenanceProvider.get_provenance()
                assert p is not None
                assert p.repo == "acme/app"
            finally:
                os.environ.pop("GATE_CALLER_REPO", None)

    def test_get_provenance_with_workflow_and_ref(self):
        with _clear_provenance_env():
            os.environ["GATE_CALLER_REPO"] = "a/b"
            os.environ["GATE_CALLER_WORKFLOW"] = "build.yml"
            os.environ["GATE_CALLER_REF"] = "main"
            try:
                p = ProvenanceProvider.get_provenance()
                assert p.repo == "a/b"
                assert p.workflow == "build.yml"
                assert p.ref == "main"
            finally:
                for k in ["GATE_CALLER_REPO", "GATE_CALLER_WORKFLOW", "GATE_CALLER_REF"]:
                    os.environ.pop(k, None)

    def test_get_provenance_with_attestation_env(self):
        with _clear_provenance_env():
            os.environ["GATE_CALLER_REPO"] = "x"
            os.environ["GATE_ATTESTATION_VALID"] = "true"
            os.environ["GATE_ATTESTATION_ISSUER"] = "https://oidc.example.com"
            try:
                p = ProvenanceProvider.get_provenance()
                assert p is not None
                assert p.attestation is not None
                assert p.attestation["valid"] is True
                assert p.attestation["issuer"] == "https://oidc.example.com"
            finally:
                for k in list(os.environ):
                    if k.startswith("GATE_CALLER_") or k.startswith("GATE_ATTESTATION_"):
                        os.environ.pop(k, None)

    def test_attestation_valid_truthy(self):
        with _clear_provenance_env():
            os.environ["GATE_CALLER_REPO"] = "x"
            os.environ["GATE_ATTESTATION_VALID"] = "1"
            try:
                p = ProvenanceProvider.get_provenance()
                assert p.attestation["valid"] is True
            finally:
                os.environ.pop("GATE_CALLER_REPO", None)
                os.environ.pop("GATE_ATTESTATION_VALID", None)

    def test_is_enabled_false_when_no_env(self):
        with _clear_provenance_env():
            assert ProvenanceProvider.is_enabled() is False

    def test_is_enabled_true_when_repo_set(self):
        with _clear_provenance_env():
            os.environ["GATE_CALLER_REPO"] = "a/b"
            try:
                assert ProvenanceProvider.is_enabled() is True
            finally:
                os.environ.pop("GATE_CALLER_REPO", None)

    def test_is_enabled_true_when_workflow_set(self):
        with _clear_provenance_env():
            os.environ["GATE_CALLER_WORKFLOW"] = "ci"
            try:
                assert ProvenanceProvider.is_enabled() is True
            finally:
                os.environ.pop("GATE_CALLER_WORKFLOW", None)


class _clear_provenance_env:
    """Context manager to clear provenance-related env vars and restore after."""

    _keys = (
        "GATE_CALLER_REPO",
        "GATE_CALLER_WORKFLOW",
        "GATE_CALLER_REF",
        "GATE_CALLER_ACTOR",
        "GATE_ATTESTATION_VALID",
        "GATE_ATTESTATION_ISSUER",
        "GATE_ATTESTATION_SUBJECT",
        "GATE_ATTESTATION_SHA",
    )

    def __enter__(self):
        self._saved = {k: os.environ.pop(k, None) for k in self._keys}
        return self

    def __exit__(self, *args):
        for k, v in self._saved.items():
            if v is not None:
                os.environ[k] = v
        return False
