"""SNS Module - Classes for SNS Topic Publishing"""

from .publisher import SNSPublisher

__all__ = ['SNSPublisher']

