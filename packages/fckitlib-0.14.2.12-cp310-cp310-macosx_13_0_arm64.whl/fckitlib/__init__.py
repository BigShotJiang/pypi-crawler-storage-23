__version__ = '0.14.2.12'
__commit_hash__ = 'fd5b1fb059570ee9c49b2d2e4a580a25ad9b4613'
findlibs_dependencies = ["eckitlib"]
