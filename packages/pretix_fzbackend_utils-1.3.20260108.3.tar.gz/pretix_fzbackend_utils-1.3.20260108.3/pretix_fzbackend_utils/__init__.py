__version__ = "1.3.20260108.3"

import logging

logging.getLogger(__package__).setLevel(logging.DEBUG)
