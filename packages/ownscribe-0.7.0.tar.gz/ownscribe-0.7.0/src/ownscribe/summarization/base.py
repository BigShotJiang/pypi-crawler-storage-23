"""Abstract base class for summarizers."""

from __future__ import annotations

import abc


class Summarizer(abc.ABC):
    """Base class for summarization backends."""

    @abc.abstractmethod
    def summarize(self, transcript_text: str) -> str:
        """Summarize a transcript and return the summary text."""

    @abc.abstractmethod
    def generate_title(self, summary_text: str) -> str:
        """Generate a short meeting title from a summary."""

    @abc.abstractmethod
    def chat(
        self, system_prompt: str, user_prompt: str,
        json_mode: bool = False, json_schema: dict | None = None,
    ) -> str:
        """Send a chat completion request and return the response text."""

    @abc.abstractmethod
    def is_available(self) -> bool:
        """Check if the summarization backend is reachable."""
