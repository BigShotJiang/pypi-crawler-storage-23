# dependencies
import demist


def test_namespace() -> None:
    demist.nro45m.qlook.otf
    demist.nro45m.qlook.psw
