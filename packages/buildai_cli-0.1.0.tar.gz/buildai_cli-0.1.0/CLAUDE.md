# apps/buildai-cli/

Typer CLI with two planes, distributable as a standalone package:
- **Data plane**: SDK-backed commands (clips, jobs, collections, partners, operations, keys, stats). Requires `BUILDAI_API_KEY`. Works with just `pip install buildai-cli`.
- **Ops plane**: DAL-direct commands (database, schema, auth CRUD, permissions, ingest, projection, medoid, external). Requires DB access. Install with `pip install 'buildai-cli[ops]'`.

## Architecture

- `cli/_has_core.py` — detects if `buildai-core` is installed
- `cli/ops_init.py` — lazy DB/auth/observability setup (called by ops commands, NOT at startup)
- `cli/main.py` — lightweight callback, conditional ops registration, stubs when core absent
- `cli/commands/auth_lite.py` — login + status (no core deps)
- `cli/commands/auth_ops.py` — API key CRUD (ops-plane, requires core)

## Rules

1. Always run from repo root (`uv run buildai`), never from inside the app directory.
2. Default profile is read-only. Mutations require `--profile admin --write`.
3. Missing `--write` on mutating commands now errors (not silent no-op).
4. All DB access goes through `core/data/` DAL with a `CLIContext`. No raw SQL in commands.
5. The `query` command only permits SELECT/WITH/EXPLAIN — it blocks mutations at parse time (via sqlparse AST).
6. Data-plane commands go through the SDK — they need an API key, not DB credentials.
7. **No `infra` imports at module level** in main.py or data-plane modules.

## Data Plane (SDK-backed)

These commands wrap `buildai` SDK resources. Set `BUILDAI_API_KEY` or `buildai auth login <key>`.

```bash
uv run buildai clips list --factory <id> --limit 5
uv run buildai jobs list --status running
uv run buildai jobs retry <id> --write
uv run buildai collections list
uv run buildai stats overview
uv run buildai partners list        # internal mode
uv run buildai operations hours     # internal mode
uv run buildai keys list            # internal mode
```

## Ops Plane (DAL-direct)

```bash
uv run buildai --profile readonly database status
uv run buildai --profile readonly schema tables
uv run buildai auth status
```

## Output

- TTY detected: table format (Rich tables)
- Piped: JSON format (machine-readable)
- Override: `--format json|table|csv|jsonl`
- Status/errors go to stderr, data to stdout

## Install

```bash
# Workspace (all commands — ops + data plane)
uv pip install -e "apps/buildai-cli[ops]" -e core -e services -e apps/buildai-sdk

# Standalone data-plane only
pip install buildai-cli   # or: uv tool install -e ./apps/buildai-cli

# Global install
uv tool install -e ./apps/buildai-cli
```

## Run

```bash
uv run buildai --profile readonly <command>
uv run buildai --profile admin --write <command>
```

## Things That Will Bite You

- `uv run buildai` fails with `ModuleNotFoundError` after pulling — reinstall with: `uv pip install -e "apps/buildai-cli[ops]" -e core -e services -e apps/buildai-sdk`
- `--env production` requires valid production DB credentials.
- New data-plane command groups: register in `cli/main.py` in the data-plane section.
- New ops-plane command groups: register in `cli/main.py` via `_register_ops_typer()` inside `if has_core():`, and add to `_OPS_GROUPS` in the else branch.
- Data-plane commands fail without `BUILDAI_API_KEY` — use `buildai auth login` to configure.
- `--dry-run` is available on all mutating data-plane commands.
- Shell completion: `uv run buildai --install-completion`
- Auth ops commands (create-key, list-keys, show-key, revoke-key) call `init_ops_context()` themselves — they're registered onto the auth_lite app, not via `_register_ops_typer`.

## Closing the Loop

When adding a command group: register it in `cli/main.py`. Data-plane = always imported. Ops-plane = behind `has_core()` guard.

## See Also

| Topic | File |
|-------|------|
| DAL patterns, profiles, Context | `core/CLAUDE.md` |
| SDK resources | `apps/buildai-sdk/CLAUDE.md` |
| Common failure modes | `docs/gotchas.md` |
