"""
CLI configuration management.

Stores config in ~/.buildai/config.toml with fields:
  - profile: CLI scope profile (default: readonly)
  - api_key: optional API key for API-backed commands
"""

from __future__ import annotations

from pathlib import Path
import os
import tomllib

CONFIG_DIR = Path.home() / ".buildai"
CONFIG_PATH = CONFIG_DIR / "config.toml"


def _read_config_file() -> dict:
    if not CONFIG_PATH.exists():
        return {}
    try:
        data = CONFIG_PATH.read_bytes()
        return tomllib.loads(data.decode("utf-8"))
    except Exception:
        return {}


def load_cli_config() -> dict:
    """Load CLI config from disk."""
    return _read_config_file()


def save_cli_config(*, profile: str | None = None, api_key: str | None = None) -> None:
    """Write CLI config to disk (0600)."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lines = ["[cli]"]
    if profile:
        lines.append(f'profile = "{profile}"')
    if api_key:
        lines.append(f'api_key = "{api_key}"')
    content = "\n".join(lines) + "\n"
    CONFIG_PATH.write_text(content, encoding="utf-8")
    os.chmod(CONFIG_PATH, 0o600)


def resolve_cli_profile(explicit: str | None) -> str:
    """Resolve CLI profile with precedence: flag > env > config > readonly."""
    if explicit:
        return explicit
    env_profile = os.getenv("BUILDAI_CLI_PROFILE")
    if env_profile:
        return env_profile
    cfg = load_cli_config()
    profile = cfg.get("cli", {}).get("profile")
    return profile or "readonly"


def resolve_cli_api_key(explicit: str | None = None) -> str | None:
    """Resolve CLI API key with precedence: arg > env > config."""
    if explicit:
        return explicit
    env_key = os.getenv("BUILDAI_API_KEY")
    if env_key:
        return env_key
    cfg = load_cli_config()
    return cfg.get("cli", {}).get("api_key")
