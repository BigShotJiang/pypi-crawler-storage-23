"""BuildAI Backend CLI."""
