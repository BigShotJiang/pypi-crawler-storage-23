"""Data models for database schema synchronization."""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class IndexInfo:
    """Information about a database index."""

    schema_name: str
    table_name: str
    index_name: str
    index_def: str  # Full CREATE INDEX statement from pg_indexes
    is_unique: bool
    is_primary: bool
    index_type: str  # btree, hash, gin, gist, scann

    @property
    def full_name(self) -> str:
        """Return fully qualified index name."""
        return f"{self.schema_name}.{self.index_name}"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "schema_name": self.schema_name,
            "table_name": self.table_name,
            "index_name": self.index_name,
            "index_def": self.index_def,
            "is_unique": self.is_unique,
            "is_primary": self.is_primary,
            "index_type": self.index_type,
        }


@dataclass
class ConstraintInfo:
    """Information about a database constraint."""

    schema_name: str
    table_name: str
    constraint_name: str
    constraint_type: str  # PRIMARY KEY, FOREIGN KEY, UNIQUE, CHECK
    constraint_def: str  # Full constraint definition

    @property
    def full_name(self) -> str:
        """Return fully qualified constraint name."""
        return f"{self.schema_name}.{self.constraint_name}"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "schema_name": self.schema_name,
            "table_name": self.table_name,
            "constraint_name": self.constraint_name,
            "constraint_type": self.constraint_type,
            "constraint_def": self.constraint_def,
        }


@dataclass
class TriggerInfo:
    """Information about a database trigger."""

    schema_name: str
    table_name: str
    trigger_name: str
    trigger_def: str  # CREATE TRIGGER statement
    function_name: str  # Associated function
    function_def: str | None  # CREATE FUNCTION statement (may be None if built-in)

    @property
    def full_name(self) -> str:
        """Return fully qualified trigger name."""
        return f"{self.schema_name}.{self.trigger_name}"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "schema_name": self.schema_name,
            "table_name": self.table_name,
            "trigger_name": self.trigger_name,
            "trigger_def": self.trigger_def,
            "function_name": self.function_name,
            "function_def": self.function_def,
        }


@dataclass
class MaterializedViewInfo:
    """Information about a materialized view."""

    schema_name: str
    view_name: str
    view_def: str  # The SELECT statement
    indexes: list[IndexInfo] = field(default_factory=list)

    @property
    def full_name(self) -> str:
        """Return fully qualified view name."""
        return f"{self.schema_name}.{self.view_name}"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "schema_name": self.schema_name,
            "view_name": self.view_name,
            "view_def": self.view_def,
            "indexes": [idx.to_dict() for idx in self.indexes],
        }


@dataclass
class SequenceInfo:
    """Information about a sequence."""

    schema_name: str
    sequence_name: str
    data_type: str
    start_value: int
    increment_by: int

    @property
    def full_name(self) -> str:
        """Return fully qualified sequence name."""
        return f"{self.schema_name}.{self.sequence_name}"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "schema_name": self.schema_name,
            "sequence_name": self.sequence_name,
            "data_type": self.data_type,
            "start_value": self.start_value,
            "increment_by": self.increment_by,
        }


@dataclass
class SyncDiff:
    """Complete diff between source and target databases."""

    source_env: str
    target_env: str

    # Indexes
    indexes_missing_in_target: list[IndexInfo] = field(default_factory=list)
    indexes_extra_in_target: list[IndexInfo] = field(default_factory=list)

    # Constraints (non-PK unique/check/fk)
    constraints_missing: list[ConstraintInfo] = field(default_factory=list)
    constraints_extra: list[ConstraintInfo] = field(default_factory=list)

    # Triggers
    triggers_missing: list[TriggerInfo] = field(default_factory=list)
    triggers_extra: list[TriggerInfo] = field(default_factory=list)

    # Materialized views
    matviews_missing: list[MaterializedViewInfo] = field(default_factory=list)
    matviews_extra: list[MaterializedViewInfo] = field(default_factory=list)

    # Sequences (definitions only, not values)
    sequences_missing: list[SequenceInfo] = field(default_factory=list)
    sequences_extra: list[SequenceInfo] = field(default_factory=list)

    def is_empty(self) -> bool:
        """Check if there are no differences."""
        return not any(
            [
                self.indexes_missing_in_target,
                self.indexes_extra_in_target,
                self.constraints_missing,
                self.constraints_extra,
                self.triggers_missing,
                self.triggers_extra,
                self.matviews_missing,
                self.matviews_extra,
                self.sequences_missing,
                self.sequences_extra,
            ]
        )

    def summary(self) -> dict[str, int]:
        """Return a summary count of differences."""
        return {
            "indexes_missing": len(self.indexes_missing_in_target),
            "indexes_extra": len(self.indexes_extra_in_target),
            "constraints_missing": len(self.constraints_missing),
            "constraints_extra": len(self.constraints_extra),
            "triggers_missing": len(self.triggers_missing),
            "triggers_extra": len(self.triggers_extra),
            "matviews_missing": len(self.matviews_missing),
            "matviews_extra": len(self.matviews_extra),
            "sequences_missing": len(self.sequences_missing),
            "sequences_extra": len(self.sequences_extra),
        }

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "source_env": self.source_env,
            "target_env": self.target_env,
            "summary": self.summary(),
            "indexes_missing_in_target": [i.to_dict() for i in self.indexes_missing_in_target],
            "indexes_extra_in_target": [i.to_dict() for i in self.indexes_extra_in_target],
            "constraints_missing": [c.to_dict() for c in self.constraints_missing],
            "constraints_extra": [c.to_dict() for c in self.constraints_extra],
            "triggers_missing": [t.to_dict() for t in self.triggers_missing],
            "triggers_extra": [t.to_dict() for t in self.triggers_extra],
            "matviews_missing": [m.to_dict() for m in self.matviews_missing],
            "matviews_extra": [m.to_dict() for m in self.matviews_extra],
            "sequences_missing": [s.to_dict() for s in self.sequences_missing],
            "sequences_extra": [s.to_dict() for s in self.sequences_extra],
        }
