"""SQL queries for extracting database schema metadata."""

from typing import Sequence

import asyncpg

from cli.commands.sync.models import (
    ConstraintInfo,
    IndexInfo,
    MaterializedViewInfo,
    SequenceInfo,
    TriggerInfo,
)

# Schemas to include in sync operations
DEFAULT_SCHEMAS = ("core", "observations", "ops", "collections", "access")


def _build_schema_filter(schemas: Sequence[str] | None) -> str:
    """Build a SQL IN clause for schema filtering."""
    if schemas is None:
        schemas = DEFAULT_SCHEMAS
    quoted = ", ".join(f"'{s}'" for s in schemas)
    return f"({quoted})"


# =============================================================================
# Index queries
# =============================================================================

INDEXES_QUERY = """
SELECT
    schemaname as schema_name,
    tablename as table_name,
    indexname as index_name,
    indexdef as index_def,
    CASE WHEN indexdef ILIKE '%UNIQUE%' THEN true ELSE false END as is_unique,
    CASE WHEN indexname LIKE '%_pkey' THEN true ELSE false END as is_primary,
    CASE
        WHEN indexdef ILIKE '%USING btree%' THEN 'btree'
        WHEN indexdef ILIKE '%USING hash%' THEN 'hash'
        WHEN indexdef ILIKE '%USING gin%' THEN 'gin'
        WHEN indexdef ILIKE '%USING gist%' THEN 'gist'
        WHEN indexdef ILIKE '%USING spgist%' THEN 'spgist'
        WHEN indexdef ILIKE '%USING brin%' THEN 'brin'
        WHEN indexdef ILIKE '%USING scann%' THEN 'scann'
        ELSE 'btree'
    END as index_type
FROM pg_indexes
WHERE schemaname IN {schema_filter}
ORDER BY schemaname, tablename, indexname
"""


async def fetch_indexes(
    conn: asyncpg.Connection,
    schemas: Sequence[str] | None = None,
    include_primary_keys: bool = False,
) -> list[IndexInfo]:
    """
    Fetch all indexes from the database.

    Args:
        conn: Database connection
        schemas: List of schemas to include (defaults to all app schemas)
        include_primary_keys: Whether to include primary key indexes

    Returns:
        List of IndexInfo objects
    """
    schema_filter = _build_schema_filter(schemas)
    query = INDEXES_QUERY.format(schema_filter=schema_filter)

    rows = await conn.fetch(query)
    indexes = []

    for row in rows:
        is_primary = row["is_primary"]
        if is_primary and not include_primary_keys:
            continue

        indexes.append(
            IndexInfo(
                schema_name=row["schema_name"],
                table_name=row["table_name"],
                index_name=row["index_name"],
                index_def=row["index_def"],
                is_unique=row["is_unique"],
                is_primary=is_primary,
                index_type=row["index_type"],
            )
        )

    return indexes


# =============================================================================
# Constraint queries
# =============================================================================

CONSTRAINTS_QUERY = """
SELECT
    tc.table_schema as schema_name,
    tc.table_name,
    tc.constraint_name,
    tc.constraint_type,
    pg_get_constraintdef(c.oid) as constraint_def
FROM information_schema.table_constraints tc
JOIN pg_catalog.pg_namespace n ON n.nspname = tc.table_schema
JOIN pg_catalog.pg_class cl ON cl.relname = tc.table_name AND cl.relnamespace = n.oid
JOIN pg_catalog.pg_constraint c ON c.conname = tc.constraint_name AND c.conrelid = cl.oid
WHERE tc.table_schema IN {schema_filter}
  AND tc.constraint_type IN ('UNIQUE', 'CHECK', 'FOREIGN KEY')
ORDER BY tc.table_schema, tc.table_name, tc.constraint_name
"""


async def fetch_constraints(
    conn: asyncpg.Connection,
    schemas: Sequence[str] | None = None,
) -> list[ConstraintInfo]:
    """
    Fetch all constraints (UNIQUE, CHECK, FOREIGN KEY) from the database.

    Primary keys are excluded as they are created automatically with tables.

    Args:
        conn: Database connection
        schemas: List of schemas to include (defaults to all app schemas)

    Returns:
        List of ConstraintInfo objects
    """
    schema_filter = _build_schema_filter(schemas)
    query = CONSTRAINTS_QUERY.format(schema_filter=schema_filter)

    rows = await conn.fetch(query)
    constraints = []

    for row in rows:
        constraints.append(
            ConstraintInfo(
                schema_name=row["schema_name"],
                table_name=row["table_name"],
                constraint_name=row["constraint_name"],
                constraint_type=row["constraint_type"],
                constraint_def=row["constraint_def"],
            )
        )

    return constraints


# =============================================================================
# Trigger queries
# =============================================================================

TRIGGERS_QUERY = """
SELECT
    n.nspname as schema_name,
    c.relname as table_name,
    t.tgname as trigger_name,
    pg_get_triggerdef(t.oid, true) as trigger_def,
    p.proname as function_name,
    CASE
        WHEN p.prosrc IS NOT NULL AND p.prosrc != '-'
        THEN pg_get_functiondef(p.oid)
        ELSE NULL
    END as function_def
FROM pg_trigger t
JOIN pg_class c ON t.tgrelid = c.oid
JOIN pg_namespace n ON c.relnamespace = n.oid
JOIN pg_proc p ON t.tgfoid = p.oid
WHERE n.nspname IN {schema_filter}
  AND NOT t.tgisinternal
  AND t.tgname NOT LIKE 'RI_ConstraintTrigger%'
ORDER BY n.nspname, c.relname, t.tgname
"""


async def fetch_triggers(
    conn: asyncpg.Connection,
    schemas: Sequence[str] | None = None,
) -> list[TriggerInfo]:
    """
    Fetch all user-defined triggers from the database.

    Internal triggers (constraint triggers) are excluded.

    Args:
        conn: Database connection
        schemas: List of schemas to include (defaults to all app schemas)

    Returns:
        List of TriggerInfo objects
    """
    schema_filter = _build_schema_filter(schemas)
    query = TRIGGERS_QUERY.format(schema_filter=schema_filter)

    rows = await conn.fetch(query)
    triggers = []

    for row in rows:
        triggers.append(
            TriggerInfo(
                schema_name=row["schema_name"],
                table_name=row["table_name"],
                trigger_name=row["trigger_name"],
                trigger_def=row["trigger_def"],
                function_name=row["function_name"],
                function_def=row["function_def"],
            )
        )

    return triggers


# =============================================================================
# Materialized view queries
# =============================================================================

MATVIEWS_QUERY = """
SELECT
    schemaname as schema_name,
    matviewname as view_name,
    definition as view_def
FROM pg_matviews
WHERE schemaname IN {schema_filter}
ORDER BY schemaname, matviewname
"""

MATVIEW_INDEXES_QUERY = """
SELECT
    schemaname as schema_name,
    tablename as table_name,
    indexname as index_name,
    indexdef as index_def,
    CASE WHEN indexdef ILIKE '%UNIQUE%' THEN true ELSE false END as is_unique,
    CASE
        WHEN indexdef ILIKE '%USING btree%' THEN 'btree'
        WHEN indexdef ILIKE '%USING hash%' THEN 'hash'
        WHEN indexdef ILIKE '%USING gin%' THEN 'gin'
        WHEN indexdef ILIKE '%USING gist%' THEN 'gist'
        ELSE 'btree'
    END as index_type
FROM pg_indexes
WHERE schemaname = $1 AND tablename = $2
ORDER BY indexname
"""


async def fetch_materialized_views(
    conn: asyncpg.Connection,
    schemas: Sequence[str] | None = None,
    include_indexes: bool = True,
) -> list[MaterializedViewInfo]:
    """
    Fetch all materialized views from the database.

    Args:
        conn: Database connection
        schemas: List of schemas to include (defaults to all app schemas)
        include_indexes: Whether to fetch indexes on materialized views

    Returns:
        List of MaterializedViewInfo objects
    """
    schema_filter = _build_schema_filter(schemas)
    query = MATVIEWS_QUERY.format(schema_filter=schema_filter)

    rows = await conn.fetch(query)
    matviews = []

    for row in rows:
        indexes = []
        if include_indexes:
            idx_rows = await conn.fetch(MATVIEW_INDEXES_QUERY, row["schema_name"], row["view_name"])
            for idx_row in idx_rows:
                indexes.append(
                    IndexInfo(
                        schema_name=idx_row["schema_name"],
                        table_name=idx_row["table_name"],
                        index_name=idx_row["index_name"],
                        index_def=idx_row["index_def"],
                        is_unique=idx_row["is_unique"],
                        is_primary=False,
                        index_type=idx_row["index_type"],
                    )
                )

        matviews.append(
            MaterializedViewInfo(
                schema_name=row["schema_name"],
                view_name=row["view_name"],
                view_def=row["view_def"],
                indexes=indexes,
            )
        )

    return matviews


# =============================================================================
# Sequence queries
# =============================================================================

SEQUENCES_QUERY = """
SELECT
    n.nspname as schema_name,
    c.relname as sequence_name,
    COALESCE(s.data_type, 'bigint') as data_type,
    COALESCE(s.start_value, 1) as start_value,
    COALESCE(s.increment_by, 1) as increment_by
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
LEFT JOIN pg_sequences s ON s.schemaname = n.nspname AND s.sequencename = c.relname
WHERE c.relkind = 'S'
  AND n.nspname IN {schema_filter}
ORDER BY n.nspname, c.relname
"""


async def fetch_sequences(
    conn: asyncpg.Connection,
    schemas: Sequence[str] | None = None,
) -> list[SequenceInfo]:
    """
    Fetch all sequences from the database.

    Note: Only fetches structure, not current values.

    Args:
        conn: Database connection
        schemas: List of schemas to include (defaults to all app schemas)

    Returns:
        List of SequenceInfo objects
    """
    schema_filter = _build_schema_filter(schemas)
    query = SEQUENCES_QUERY.format(schema_filter=schema_filter)

    rows = await conn.fetch(query)
    sequences = []

    for row in rows:
        sequences.append(
            SequenceInfo(
                schema_name=row["schema_name"],
                sequence_name=row["sequence_name"],
                data_type=row["data_type"],
                start_value=row["start_value"],
                increment_by=row["increment_by"],
            )
        )

    return sequences
