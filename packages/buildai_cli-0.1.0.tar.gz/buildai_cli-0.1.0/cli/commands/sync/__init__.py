"""
Database schema synchronization CLI commands.

Provides bidirectional schema sync between prod and dev:
- `cli sync diff` - Compare schemas between environments
- `cli sync apply` - Apply missing schema objects
- `cli sync data` - Copy data subsets from prod to dev

Usage:
    cli sync diff                              # Show all differences
    cli sync diff --indexes                    # Only index differences
    cli sync apply --indexes                   # Apply missing indexes to dev
    cli sync apply --index idx_name            # Apply specific index
    cli sync data --factory abc123             # Copy factory data to dev
"""

import typer

from cli.commands.sync.diff import diff_command
from cli.commands.sync.apply import apply_command
from cli.commands.sync.data import data_command

# Export models and utilities for programmatic use
from cli.commands.sync.models import (
    ConstraintInfo,
    IndexInfo,
    MaterializedViewInfo,
    SequenceInfo,
    SyncDiff,
    TriggerInfo,
)
from cli.commands.sync.queries import (
    fetch_constraints,
    fetch_indexes,
    fetch_materialized_views,
    fetch_sequences,
    fetch_triggers,
)
from cli.commands.sync.ddl import (
    generate_add_constraint_ddl,
    generate_drop_constraint_ddl,
    generate_drop_index_ddl,
    generate_drop_index_ddl_concurrent,
    generate_index_ddl,
    generate_index_ddl_concurrent,
    generate_matview_ddl,
    generate_sequence_ddl,
    generate_trigger_ddl,
)
from cli.commands.sync.diff import compute_diff

# Create the Typer app for sync commands
sync_app = typer.Typer(
    name="sync",
    help="[DEPRECATED] Use 'cli database' instead. Database schema synchronization tools",
    no_args_is_help=True,
)


@sync_app.callback()
def _deprecation_warning() -> None:
    """Show deprecation warning for sync commands."""
    from cli.console import warning

    warning("'cli sync' is deprecated. Use 'cli database' instead.")
    warning("  cli sync diff   ->  cli database diff")
    warning("  cli sync apply  ->  cli database sync-schema")
    warning("  cli sync data   ->  cli database sync-data")


# Register subcommands
sync_app.command("diff")(diff_command)
sync_app.command("apply")(apply_command)
sync_app.command("data")(data_command)

__all__ = [
    # Main CLI app
    "sync_app",
    # Models
    "IndexInfo",
    "ConstraintInfo",
    "TriggerInfo",
    "MaterializedViewInfo",
    "SequenceInfo",
    "SyncDiff",
    # Query functions
    "fetch_indexes",
    "fetch_constraints",
    "fetch_triggers",
    "fetch_materialized_views",
    "fetch_sequences",
    # DDL generators
    "generate_index_ddl",
    "generate_index_ddl_concurrent",
    "generate_drop_index_ddl",
    "generate_drop_index_ddl_concurrent",
    "generate_add_constraint_ddl",
    "generate_drop_constraint_ddl",
    "generate_trigger_ddl",
    "generate_matview_ddl",
    "generate_sequence_ddl",
    # Diff function
    "compute_diff",
]
