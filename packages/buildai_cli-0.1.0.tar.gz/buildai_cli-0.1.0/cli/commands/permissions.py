"""CLI commands for permission preflight checks and sync."""

import asyncio
from pathlib import Path
from typing import Any

import typer
from typing_extensions import Annotated

from cli.console import console, error, info, success, warning
from cli.context import get_connection
from cli.config import resolve_cli_profile
from infra import permissions as perm_mod
from infra.settings import Settings

app = typer.Typer(name="permissions", help="Permission preflight checks", no_args_is_help=True)


@app.command("check")
def check_permissions(
    ctx: typer.Context,
    profile: Annotated[
        str | None,
        typer.Option("--profile", "-p", help="Profile to validate (defaults to CLI profile)"),
    ] = None,
    manifest: Annotated[
        Path | None,
        typer.Option("--manifest", help="Path to permissions_manifest.yaml"),
    ] = None,
) -> None:
    """Check DB privileges for a profile using the permissions manifest."""
    settings: Settings = ctx.obj["settings"]
    resolved_profile = resolve_cli_profile(profile)

    async def run() -> None:
        async with get_connection(settings) as conn:
            try:
                manifest_data = perm_mod.load_manifest(manifest)
                errors = await perm_mod.check_db_privileges(
                    conn, profile=resolved_profile, manifest=manifest_data
                )
                try:
                    from data import scopes as scope_module

                    profile_scopes = scope_module.PROFILES.get(resolved_profile, set())
                    errors.extend(
                        perm_mod.check_scopes(
                            profile=resolved_profile,
                            scopes=profile_scopes,
                            manifest=manifest_data,
                        )
                    )
                except Exception as e:
                    warning(f"Scope check skipped: {e}")
            except Exception as e:
                error(f"Permission check failed: {e}")
                raise typer.Exit(1)

            if errors:
                warning(f"Permission check failed for profile '{resolved_profile}':")
                for err in errors:
                    console.print(f"  - {err}")
                raise typer.Exit(1)
            success(f"Permissions OK for profile '{resolved_profile}'")

    asyncio.run(run())


@app.command("sync")
def sync_permissions(
    ctx: typer.Context,
    profile: Annotated[
        str | None,
        typer.Option("--profile", "-p", help="Sync a specific profile only"),
    ] = None,
    manifest: Annotated[
        Path | None,
        typer.Option("--manifest", help="Path to permissions_manifest.yaml"),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", "-n", help="Show SQL without executing"),
    ] = False,
) -> None:
    """Idempotently create DB roles and grants from permissions manifest."""
    settings: Settings = ctx.obj["settings"]

    if not dry_run:
        from cli.guard import require_write

        require_write(ctx, "Permission sync")

    manifest_data = perm_mod.load_manifest(manifest)
    profiles: dict[str, Any] = manifest_data.get("profiles", {})

    if profile:
        if profile not in profiles:
            error(f"Profile '{profile}' not found in manifest")
            raise typer.Exit(1)
        profiles = {profile: profiles[profile]}

    async def run() -> None:
        async with get_connection(settings) as conn:
            statements = await _build_sync_sql(conn, profiles)

            if not statements:
                info("Nothing to sync (no profiles with db_role)")
                return

            if dry_run:
                console.print("[bold]Dry run — would execute:[/bold]\n")
                for stmt in statements:
                    console.print(f"  {stmt}")
                return

            executed = 0
            for stmt in statements:
                try:
                    await conn.execute(stmt)
                    executed += 1
                except Exception as e:
                    warning(f"Statement failed: {stmt}\n  Error: {e}")

            success(f"Synced {len(profiles)} profile(s), {executed}/{len(statements)} statements")

    asyncio.run(run())


async def _build_sync_sql(conn: Any, profiles: dict[str, Any]) -> list[str]:
    """Build SQL statements for syncing roles and grants from manifest."""
    statements: list[str] = []

    for profile_name, spec in profiles.items():
        db_role = spec.get("db_role")
        if not db_role:
            continue

        # 1. Create role (idempotent via DO block)
        statements.append(
            f"DO $$ BEGIN "
            f"IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{db_role}') THEN "
            f'CREATE ROLE "{db_role}" NOLOGIN; '
            f"END IF; END $$"
        )

        # 2. Extract schemas from privilege patterns and grant USAGE
        schemas: set[str] = set()
        privileges = spec.get("privileges", {})
        for _action, patterns in privileges.items():
            for pattern in patterns:
                schema = pattern.split(".")[0]
                schemas.add(schema)

        for schema in sorted(schemas):
            statements.append(f'GRANT USAGE ON SCHEMA "{schema}" TO "{db_role}"')

        # 3. Expand patterns and grant privileges per table
        write_schemas: set[str] = set()
        for action, patterns in privileges.items():
            tables = await perm_mod._expand_table_patterns(conn, list(patterns))
            for table in tables:
                statements.append(f'GRANT {action.upper()} ON {table} TO "{db_role}"')
                if action in ("insert", "update", "delete"):
                    schema = table.split(".")[0]
                    write_schemas.add(schema)

        # 4. Grant role to backend-services
        statements.append(f'GRANT "{db_role}" TO "backend-services"')

        # 5. Grant sequence usage for schemas with write access
        for schema in sorted(write_schemas):
            statements.append(f'GRANT USAGE ON ALL SEQUENCES IN SCHEMA "{schema}" TO "{db_role}"')

    return statements
