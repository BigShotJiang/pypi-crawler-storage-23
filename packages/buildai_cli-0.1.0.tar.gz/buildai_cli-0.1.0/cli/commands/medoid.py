"""
Medoid CLI commands.

Manages hierarchical medoid computation for embedding visualization.
Medoids are representative embeddings for groups (workers, factories).

Commands:
    medoid status                    # Show medoid counts by space/group
    medoid compute --space-id 20     # Queue medoid computation job

Examples:
    # Show medoid status for all embedding spaces
    cli medoid status

    # Show medoid status for a specific space
    cli medoid status --space-id 20

    # Compute worker medoids for Qwen3-VL frame embeddings
    cli medoid compute --space-id 20 --entity-type frame --group-type worker

    # Dry-run to see plan before computing
    cli medoid compute --space-id 20 --group-type worker --dry-run

    # After queueing, submit to Cloud Batch:
    cli jobs submit <manifest_id>
"""

import asyncio
from typing import Literal

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from cli.context import get_connection, get_cli_context
from cli.guard import require_write

app = typer.Typer(help="Medoid commands (hierarchical representative embeddings)")
console = Console()


def success(msg: str) -> None:
    """Print success message."""
    console.print(f"[green]✓[/green] {msg}")


def error(msg: str) -> None:
    """Print error message."""
    console.print(f"[red]✗[/red] {msg}")


# =============================================================================
# Status Command
# =============================================================================


@app.command("status")
def status(
    ctx: typer.Context,
    space_id: int = typer.Option(None, "--space-id", "-s", help="Filter by embedding space ID"),
) -> None:
    """Show medoid counts by embedding space and group type."""
    asyncio.run(_status(ctx, space_id))


async def _status(ctx: typer.Context, space_id: int | None) -> None:
    settings = ctx.obj["settings"]

    async with get_connection(settings) as conn:
        # Check if new medoids table exists
        table_check = await conn.fetchrow(
            """
            SELECT EXISTS (
                SELECT FROM information_schema.tables
                WHERE table_schema = 'observations' AND table_name = 'medoids'
                AND EXISTS (
                    SELECT FROM information_schema.columns
                    WHERE table_schema = 'observations' AND table_name = 'medoids'
                    AND column_name = 'group_type'
                )
            ) as has_new_schema
            """
        )

        has_new_schema = table_check["has_new_schema"] if table_check else False

        if not has_new_schema:
            console.print("[yellow]New medoids schema not found. Run migration 035 first.[/yellow]")
            console.print("[dim]Run: cli database migrate all[/dim]")
            return

        # Get medoid counts by space and group type
        if space_id:
            query = """
                SELECT
                    m.embedding_space_id,
                    es.model_id,
                    es.variant,
                    m.group_type,
                    m.entity_type,
                    COUNT(*) as count,
                    SUM(m.n_entities) as total_entities,
                    MAX(m.created_at) as last_computed
                FROM observations.medoids m
                JOIN observations.embedding_spaces es ON es.id = m.embedding_space_id
                WHERE m.embedding_space_id = $1
                GROUP BY m.embedding_space_id, es.model_id, es.variant, m.group_type, m.entity_type
                ORDER BY m.embedding_space_id, m.group_type
            """
            rows = await conn.fetch(query, space_id)
        else:
            query = """
                SELECT
                    m.embedding_space_id,
                    es.model_id,
                    es.variant,
                    m.group_type,
                    m.entity_type,
                    COUNT(*) as count,
                    SUM(m.n_entities) as total_entities,
                    MAX(m.created_at) as last_computed
                FROM observations.medoids m
                JOIN observations.embedding_spaces es ON es.id = m.embedding_space_id
                GROUP BY m.embedding_space_id, es.model_id, es.variant, m.group_type, m.entity_type
                ORDER BY m.embedding_space_id, m.group_type
            """
            rows = await conn.fetch(query)

        if not rows:
            console.print("[yellow]No medoids found[/yellow]")
            if space_id:
                console.print(
                    f"[dim]Run: cli medoid compute --space-id {space_id} --group-type worker[/dim]"
                )
            else:
                console.print(
                    "[dim]Run: cli medoid compute --space-id <id> --group-type worker[/dim]"
                )
            return

        # Display medoids table
        table = Table(title="Medoids", show_header=True, header_style="bold cyan")
        table.add_column("Space", style="dim", justify="right")
        table.add_column("Model", style="green")
        table.add_column("Variant", style="blue")
        table.add_column("Group Type", style="yellow")
        table.add_column("Entity Type", style="magenta")
        table.add_column("Medoids", justify="right")
        table.add_column("Entities", justify="right")
        table.add_column("Last Computed", style="dim")

        for row in rows:
            table.add_row(
                str(row["embedding_space_id"]),
                row["model_id"],
                row["variant"] or "(none)",
                row["group_type"],
                row["entity_type"],
                f"{row['count']:,}",
                f"{row['total_entities']:,}",
                row["last_computed"].strftime("%Y-%m-%d %H:%M") if row["last_computed"] else "-",
            )

        console.print(table)

        # Show embedding spaces available for medoid computation
        console.print()
        spaces_query = """
            SELECT es.id, es.model_id, es.variant, es.dimensions,
                   (SELECT COUNT(*) FROM information_schema.tables
                    WHERE table_schema = 'observations'
                    AND table_name = es.table_name) as table_exists
            FROM observations.embedding_spaces es
            WHERE es.is_active = true
            ORDER BY es.id
        """
        spaces = await conn.fetch(spaces_query)

        if spaces:
            spaces_table = Table(
                title="Available Embedding Spaces", show_header=True, header_style="bold cyan"
            )
            spaces_table.add_column("ID", style="dim", justify="right")
            spaces_table.add_column("Model", style="green")
            spaces_table.add_column("Variant", style="blue")
            spaces_table.add_column("Dims", justify="right")

            for space in spaces:
                spaces_table.add_row(
                    str(space["id"]),
                    space["model_id"],
                    space["variant"] or "(none)",
                    str(space["dimensions"]),
                )

            console.print(spaces_table)


# =============================================================================
# Compute Command
# =============================================================================


@app.command("compute")
def compute(
    ctx: typer.Context,
    space_id: int = typer.Option(..., "--space-id", "-s", help="Embedding space ID (required)"),
    entity_type: str = typer.Option(
        "frame", "--entity-type", "-e", help="Entity type: frame or clip"
    ),
    group_type: str = typer.Option(
        "worker", "--group-type", "-g", help="Group type: worker or factory"
    ),
    algorithm: str = typer.Option(
        "mean_nearest", "--algorithm", "-a", help="Algorithm: mean_nearest, geometric"
    ),
    dry_run: bool = typer.Option(False, "--dry-run", "-n", help="Show plan without queuing"),
) -> None:
    """Queue medoid computation job (uses manifest system).

    After queueing, submit to Cloud Batch with:
        cli jobs submit <manifest_id>
    """
    if not dry_run:
        require_write(ctx, "Medoid computation")
    asyncio.run(_compute(ctx, space_id, entity_type, group_type, algorithm, dry_run))


async def _compute(
    ctx: typer.Context,
    space_id: int,
    entity_type: str,
    group_type: str,
    algorithm: str,
    dry_run: bool,
) -> None:
    from data.processing import jobs
    from infra.batch_configs import get_compute_medoids_config

    settings = ctx.obj["settings"]

    # Validate inputs
    if entity_type not in ("frame", "clip"):
        error(f"Invalid entity_type: {entity_type}. Use 'frame' or 'clip'")
        raise typer.Exit(1)

    if group_type not in ("worker", "factory"):
        error(f"Invalid group_type: {group_type}. Use 'worker' or 'factory'")
        raise typer.Exit(1)

    if algorithm not in ("mean_nearest", "geometric"):
        error(f"Invalid algorithm: {algorithm}. Use 'mean_nearest' or 'geometric'")
        raise typer.Exit(1)

    # Cast to Literal types for type safety
    entity_type_literal: Literal["frame", "clip"] = entity_type  # type: ignore
    group_type_literal: Literal["worker", "factory"] = group_type  # type: ignore

    async with get_cli_context(settings) as (db, ctx_dal):
        # Get embedding space info for display
        from data.observations.embeddings import spaces

        space = await spaces.get(ctx_dal, space_id)

        # Count entities and groups for plan display
        async with get_connection(settings) as conn:
            emb_table = f"observations.{space.table_name}"

            if group_type == "worker":
                count_query = f"""
                    SELECT
                        COUNT(DISTINCT c.worker_id) as group_count,
                        COUNT(*) as entity_count
                    FROM {emb_table} e
                    JOIN core.frames f ON f.id = e.entity_id
                    JOIN core.clips c ON c.id = f.clip_id
                    WHERE e.entity_type = $1 AND c.worker_id IS NOT NULL
                """
            else:  # factory
                count_query = f"""
                    SELECT
                        COUNT(DISTINCT c.factory_id) as group_count,
                        COUNT(*) as entity_count
                    FROM {emb_table} e
                    JOIN core.frames f ON f.id = e.entity_id
                    JOIN core.clips c ON c.id = f.clip_id
                    WHERE e.entity_type = $1 AND c.factory_id IS NOT NULL
                """

            counts = await conn.fetchrow(count_query, entity_type)
            group_count = counts["group_count"] if counts else 0
            entity_count = counts["entity_count"] if counts else 0

        if group_count == 0:
            error(f"No {group_type}s found with {entity_type} embeddings in space {space_id}")
            raise typer.Exit(1)

        # Get GPU config based on data size for display
        batch_config = get_compute_medoids_config(entity_count, space.dimensions)
        data_size_gb = (entity_count * space.dimensions * 4) / (1024**3)

        # Display plan
        console.print()
        console.print(
            Panel.fit(
                f"[bold]Medoid Computation Plan[/bold]\n\n"
                f"Embedding Space: [cyan]{space_id}[/cyan] ({space.model_id})\n"
                f"Entity Type: [blue]{entity_type}[/blue]\n"
                f"Group Type: [yellow]{group_type}[/yellow]\n"
                f"Algorithm: [magenta]{algorithm}[/magenta]\n\n"
                f"Groups ({group_type}s): [green]{group_count:,}[/green]\n"
                f"Entities ({entity_type}s): [cyan]{entity_count:,}[/cyan]\n"
                f"Data Size: {data_size_gb:.1f}GB\n\n"
                f"GPU: [green]{batch_config.machine_type}[/green] ({batch_config.gpu_type})\n"
                f"Memory: {batch_config.memory_mib // 1024}GB RAM\n\n"
                f"Output: [green]{group_count:,}[/green] medoids → observations.medoids",
                title="Plan",
            )
        )

        if dry_run:
            console.print("\n[yellow]Dry run - no job queued[/yellow]")
            console.print("[dim]Remove --dry-run to queue the job[/dim]")
            return

        # Queue using manifest system
        manifest = await jobs.queue_compute_medoids(
            ctx_dal,
            embedding_space_id=space_id,
            entity_type=entity_type_literal,
            group_type=group_type_literal,
            algorithm=algorithm,
        )

        success(f"Queued job: {manifest.id}")
        console.print()
        console.print("[bold]Next steps:[/bold]")
        console.print(f"  1. Submit to Cloud Batch: [cyan]cli jobs submit {manifest.id}[/cyan]")
        console.print(f"  2. Monitor progress: [cyan]cli jobs status {manifest.id}[/cyan]")
        console.print(f"  3. Check results: [cyan]cli medoid status --space-id {space_id}[/cyan]")
