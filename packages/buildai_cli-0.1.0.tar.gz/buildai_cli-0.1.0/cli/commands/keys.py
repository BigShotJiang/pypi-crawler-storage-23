"""CLI commands for API key management (SDK-backed, internal mode)."""

from __future__ import annotations

import typer

from cli.console import info, success, warning
from cli.guard import require_write
from cli.output import Format, format_option, output
from cli.sdk_client import get_internal_sdk_client

app = typer.Typer(
    name="keys",
    help="API key management (internal).",
    no_args_is_help=True,
)


@app.command("list")
def keys_list(
    include_revoked: bool = typer.Option(False, "--include-revoked", "-r"),
    format: Format | None = format_option(),
) -> None:
    """List API keys."""
    client = get_internal_sdk_client()
    results = list(client.keys.iter(include_revoked=include_revoked))
    output(
        results, format=format, columns=["key_prefix", "name", "profile", "is_active", "created_at"]
    )


@app.command("create")
def keys_create(
    ctx: typer.Context,
    name: str = typer.Argument(..., help="Name for the API key"),
    profile: str = typer.Option("readonly", "--profile", "-p"),
    key_type: str = typer.Option("live", "--type", "-t"),
    dry_run: bool = typer.Option(False, "--dry-run"),
) -> None:
    """Create a new API key."""
    if dry_run:
        info(f"Would create {key_type} key '{name}' with profile={profile}")
        return

    require_write(ctx, "API key creation")
    client = get_internal_sdk_client()
    key = client.keys.create(name=name, profile=profile, key_type=key_type)
    success(f"Created key: {key.key_prefix}...")
    warning("Save the secret key \u2014 it will not be shown again:")
    print(key.secret_key)


@app.command("revoke")
def keys_revoke(
    ctx: typer.Context,
    key_id: str = typer.Argument(..., help="Key UUID"),
    reason: str | None = typer.Option(None, "--reason", "-r"),
    dry_run: bool = typer.Option(False, "--dry-run"),
) -> None:
    """Revoke an API key."""
    if dry_run:
        info(f"Would revoke key {key_id}")
        return

    require_write(ctx, "API key revocation")
    client = get_internal_sdk_client()
    client.keys.revoke(key_id, reason=reason)
    success(f"Revoked key {key_id}")
