"""Ops-plane auth commands — API key CRUD via DAL.

These functions are registered onto the auth_lite ``app`` in ``cli/main.py``
when ``has_core()`` is True.  They require DB access (ops-plane).
"""

import asyncio
from uuid import UUID

import typer
from rich.panel import Panel
from rich.table import Table
from typing_extensions import Annotated

from cli.console import console, error, info, success, warning
from cli.guard import require_write
from cli.context import get_cli_context
from cli.ops_init import init_ops_context
from data.auth import keys, audit
from data.models.auth import ApiKeyCreate, KeyType
from infra.settings import Settings, get_settings


# =============================================================================
# Environment Validation
# =============================================================================


def validate_key_type_for_environment(settings: Settings, key_type: KeyType) -> None:
    """Validate that key type is allowed for the current environment."""
    if key_type == KeyType.LIVE and not settings.is_production:
        raise typer.BadParameter(
            "Live keys can only be created in production. "
            "Use --env production or use --type test for development."
        )
    if key_type == KeyType.TEST and settings.is_production:
        raise typer.BadParameter(
            "Test keys cannot be created in production. "
            "Use --type live or --type service for production."
        )


def infer_key_type(settings: Settings) -> KeyType:
    """Infer the appropriate key type based on environment."""
    return KeyType.LIVE if settings.is_production else KeyType.TEST


# =============================================================================
# Commands (bare functions — registered in main.py)
# =============================================================================


def create_key(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Name for the API key")],
    admin: Annotated[
        bool,
        typer.Option("--admin", help="Create an admin key with full access (scopes: ['*'])"),
    ] = False,
    key_type: Annotated[
        KeyType | None,
        typer.Option(
            "--type",
            "-t",
            help="Key type: live (production), test (development), or service. Auto-detected if not specified.",
        ),
    ] = None,
    description: Annotated[
        str | None,
        typer.Option("--description", "-d", help="Description for the key"),
    ] = None,
    scopes: Annotated[
        list[str] | None,
        typer.Option(
            "--scope", "-s", help="Scopes to grant (can be repeated). Ignored if --admin is set."
        ),
    ] = None,
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmation prompts"),
    ] = False,
    output_json: Annotated[
        bool,
        typer.Option("--json", help="Output in JSON format for scripting"),
    ] = False,
) -> None:
    """
    Create a new API key.

    Examples:
        buildai --env production --profile admin auth create "Initial Admin" --admin
        buildai --profile admin auth create "Dev Admin" --admin --type test
        buildai auth create "Read-only Key" --scope core:read --scope obs:read
    """
    init_ops_context(ctx)
    require_write(ctx, "API key creation")

    settings = ctx.obj.get("settings") if ctx.obj else None
    if settings is None:
        settings = get_settings()
    cli_profile = (ctx.obj or {}).get("cli_profile", "readonly")
    if cli_profile != "admin":
        error("API key creation requires --profile admin.")
        raise typer.Exit(1)

    if key_type is None:
        key_type = infer_key_type(settings)
        info(f"Using key type: {key_type.value} (based on environment)")

    try:
        validate_key_type_for_environment(settings, key_type)
    except typer.BadParameter as e:
        error(str(e))
        raise typer.Exit(1)

    if admin:
        final_scopes = ["*"]
    elif scopes:
        final_scopes = list(scopes)
    else:
        error("Scopes are required unless --admin is set.")
        raise typer.Exit(1)

    if admin and not yes:
        warning("Creating an ADMIN key with full access (['*']).")
        console.print(f"[dim]Environment: {settings.app_env.value}[/dim]")
        console.print(f"[dim]Key type: {key_type.value}[/dim]")
        if not typer.confirm("Proceed?", default=False):
            raise typer.Exit(0)

    async def run() -> None:
        async with get_cli_context(settings) as (_, ctx):
            key_data = ApiKeyCreate(
                name=name,
                description=description,
                key_type=key_type,
                scopes=final_scopes,
            )
            created_by = ctx.identity or "cli"
            result = await keys.create_key(ctx, key_data, created_by)
            audit.log_key_created(
                ctx,
                result.key.id,
                key_prefix=result.key.key_prefix,
                created_by=created_by,
                key_type=key_type.value,
                scopes=final_scopes,
            )
            if output_json:
                import json

                output = {
                    "id": str(result.key.id),
                    "key": result.raw_key,
                    "prefix": result.key.key_prefix,
                    "type": result.key.key_type.value,
                    "scopes": result.key.scopes,
                }
                console.print(json.dumps(output))
            else:
                console.print()
                console.print(
                    Panel(
                        f"[bold green]{result.raw_key}[/bold green]",
                        title="[yellow]API Key Created - SAVE THIS NOW[/yellow]",
                        subtitle="[red]This will NOT be shown again![/red]",
                        border_style="yellow",
                    )
                )
                console.print()
                success(f"Created key {result.key.key_prefix}... (ID: {result.key.id})")
                console.print(
                    f"  Type: {result.key.key_type.value} | Scopes: {', '.join(result.key.scopes)} | Expires: {'never' if not result.key.expires_at else result.key.expires_at}"
                )

    asyncio.run(run())


def list_keys(
    ctx: typer.Context,
    key_type: Annotated[
        KeyType | None,
        typer.Option("--type", "-t", help="Filter by key type"),
    ] = None,
    include_revoked: Annotated[
        bool,
        typer.Option("--include-revoked", "-r", help="Include revoked keys"),
    ] = False,
    limit: Annotated[
        int,
        typer.Option("--limit", "-n", help="Maximum number of keys to show"),
    ] = 50,
) -> None:
    """
    List API keys (ops-plane — requires DB access).

    Examples:
        buildai auth list
        buildai auth list --type live
        buildai auth list --include-revoked
    """
    init_ops_context(ctx)

    settings = ctx.obj.get("settings") if ctx.obj else None
    if settings is None:
        settings = get_settings()

    async def run() -> None:
        async with get_cli_context(settings) as (_, ctx):
            api_keys = await keys.list_keys(
                ctx,
                key_type=key_type,
                include_revoked=include_revoked,
                limit=limit,
            )

            if not api_keys:
                info("No API keys found")
                return

            table = Table(title=f"API Keys ({len(api_keys)} found)")
            table.add_column("ID", style="dim", max_width=36)
            table.add_column("Prefix", style="cyan")
            table.add_column("Name", style="white")
            table.add_column("Type", style="magenta")
            table.add_column("Scopes", style="green")
            table.add_column("Status", style="yellow")
            table.add_column("Created", style="dim")
            table.add_column("Last Used", style="dim")

            for key in api_keys:
                if key.revoked_at:
                    status = "[red]revoked[/red]"
                elif not key.is_active:
                    status = "[yellow]inactive[/yellow]"
                elif key.expires_at and key.expires_at < key.updated_at:
                    status = "[red]expired[/red]"
                else:
                    status = "[green]active[/green]"

                scopes_str = ", ".join(key.scopes[:3])
                if len(key.scopes) > 3:
                    scopes_str += f" (+{len(key.scopes) - 3})"

                created = key.created_at.strftime("%Y-%m-%d %H:%M") if key.created_at else "-"
                last_used = key.last_used_at.strftime("%Y-%m-%d %H:%M") if key.last_used_at else "-"

                table.add_row(
                    str(key.id),
                    key.key_prefix,
                    key.name,
                    key.key_type.value,
                    scopes_str,
                    status,
                    created,
                    last_used,
                )

            console.print(table)

    asyncio.run(run())


def show_key(
    ctx: typer.Context,
    key_id_or_prefix: Annotated[
        str, typer.Argument(help="Key UUID or prefix (e.g., build_live_a1b2)")
    ],
) -> None:
    """
    Show details of an API key (ops-plane — requires DB access).

    Examples:
        buildai auth show 550e8400-e29b-41d4-a716-446655440000
        buildai auth show build_live_a1b2
    """
    init_ops_context(ctx)

    settings = ctx.obj.get("settings") if ctx.obj else None
    if settings is None:
        settings = get_settings()

    async def run() -> None:
        async with get_cli_context(settings) as (_, ctx):
            key = await _find_key_by_id_or_prefix(ctx, key_id_or_prefix)
            if not key:
                error(f"Key not found: {key_id_or_prefix}")
                raise typer.Exit(1)

            status = (
                "active"
                if key.is_active and not key.revoked_at
                else "revoked"
                if key.revoked_at
                else "inactive"
            )

            details = [
                f"[bold]ID:[/bold] {key.id}",
                f"[bold]Prefix:[/bold] {key.key_prefix}",
                f"[bold]Name:[/bold] {key.name}",
                f"[bold]Type:[/bold] {key.key_type.value}",
                f"[bold]Status:[/bold] {status}",
                f"[bold]Scopes:[/bold] {', '.join(key.scopes)}",
                "",
                f"[bold]Created by:[/bold] {key.created_by}",
                f"[bold]Created at:[/bold] {key.created_at}",
            ]

            if key.description:
                details.insert(4, f"[bold]Description:[/bold] {key.description}")
            if key.expires_at:
                details.append(f"[bold]Expires at:[/bold] {key.expires_at}")
            if key.revoked_at:
                details.append(f"[bold]Revoked at:[/bold] {key.revoked_at}")
                details.append(f"[bold]Revoked by:[/bold] {key.revoked_by}")
                if key.revoked_reason:
                    details.append(f"[bold]Reason:[/bold] {key.revoked_reason}")

            details.append("")
            details.append(f"[bold]Last used:[/bold] {key.last_used_at or 'never'}")
            details.append(f"[bold]Use count:[/bold] {key.use_count}")

            if key.allowed_ips:
                details.append(f"[bold]Allowed IPs:[/bold] {', '.join(key.allowed_ips)}")
            if key.allowed_origins:
                details.append(f"[bold]Allowed origins:[/bold] {', '.join(key.allowed_origins)}")
            if key.rate_limit_rpm:
                details.append(f"[bold]Rate limit:[/bold] {key.rate_limit_rpm} rpm")

            console.print(
                Panel(
                    "\n".join(details),
                    title=f"API Key: {key.key_prefix}",
                    border_style="cyan",
                )
            )

    asyncio.run(run())


def revoke_key(
    ctx: typer.Context,
    key_id_or_prefix: Annotated[str, typer.Argument(help="Key UUID or prefix to revoke")],
    reason: Annotated[
        str | None,
        typer.Option("--reason", "-r", help="Reason for revocation"),
    ] = None,
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmation prompt"),
    ] = False,
) -> None:
    """
    Revoke an API key (ops-plane — requires DB access).

    Examples:
        buildai auth revoke build_live_a1b2 --reason "Compromised"
        buildai auth revoke 550e8400-... --yes
    """
    init_ops_context(ctx)
    require_write(ctx, "API key revocation")

    settings = ctx.obj.get("settings") if ctx.obj else None
    if settings is None:
        settings = get_settings()

    async def run() -> None:
        async with get_cli_context(settings) as (_, ctx):
            key = await _find_key_by_id_or_prefix(ctx, key_id_or_prefix)
            if not key:
                error(f"Key not found: {key_id_or_prefix}")
                raise typer.Exit(1)

            if key.revoked_at:
                warning(f"Key {key.key_prefix} is already revoked")
                raise typer.Exit(0)

            if not yes:
                console.print(f"[bold]Key to revoke:[/bold] {key.key_prefix}")
                console.print(f"[dim]Name: {key.name}[/dim]")
                console.print(f"[dim]Type: {key.key_type.value}[/dim]")
                console.print()
                warning("This action cannot be undone!")
                if not typer.confirm("Revoke this key?", default=False):
                    raise typer.Exit(0)

            revoked_by = ctx.identity or "cli"
            revoked = await keys.revoke_key(
                ctx,
                key.id,
                reason=reason,
                revoked_by=revoked_by,
            )

            if revoked:
                audit.log_key_revoked(
                    ctx,
                    key.id,
                    key_prefix=key.key_prefix,
                    revoked_by=revoked_by,
                    reason=reason,
                )
                success(f"Revoked key {key.key_prefix}")
            else:
                error("Failed to revoke key")
                raise typer.Exit(1)

    asyncio.run(run())


# =============================================================================
# Helpers
# =============================================================================


async def _find_key_by_id_or_prefix(ctx, key_id_or_prefix: str):
    """Find a key by UUID or prefix."""
    from data.errors import NotFound

    try:
        uuid_value = UUID(key_id_or_prefix)
        return await keys.get(ctx, uuid_value)
    except (ValueError, NotFound):
        pass

    all_keys = await keys.list_keys(ctx, include_revoked=True, limit=1000)
    for key in all_keys:
        if key.key_prefix == key_id_or_prefix or key.key_prefix.startswith(key_id_or_prefix):
            return key

    return None
