"""CLI commands for jobs (SDK-backed data-plane)."""

from __future__ import annotations

import itertools

import typer

from cli.console import error, info, success
from cli.guard import require_write
from cli.output import Format, format_option, output
from cli.sdk_client import get_sdk_client

app = typer.Typer(
    name="jobs",
    help="Manage processing jobs.",
    no_args_is_help=True,
)


@app.command("list")
def jobs_list(
    status: str | None = typer.Option(None, "--status", "-s", help="Filter by status"),
    type: str | None = typer.Option(None, "--type", "-t", help="Filter by job type"),
    limit: int = typer.Option(20, "--limit", "-n"),
    format: Format | None = format_option(),
) -> None:
    """List processing jobs."""
    client = get_sdk_client()
    results = list(
        itertools.islice(
            client.jobs.iter(status=status, type=type),
            limit,
        )
    )
    output(
        results,
        format=format,
        columns=["job_id", "job_type", "status", "progress_pct", "created_at"],
    )


@app.command("get")
def jobs_get(
    job_id: str = typer.Argument(..., help="Job UUID"),
    format: Format | None = format_option(),
) -> None:
    """Get details for a single job."""
    client = get_sdk_client()
    job = client.jobs.get(job_id)
    output(job, format=format)


@app.command("submit")
def jobs_submit(
    ctx: typer.Context,
    job_type: str = typer.Argument(
        ..., help="Job type: embed | project | processor | hf-upload | hf-exclusion"
    ),
    collection: str | None = typer.Option(None, "--collection", "-c"),
    factory: str | None = typer.Option(None, "--factory", "-f"),
    model_id: str | None = typer.Option(None, "--model-id", "-m"),
    dry_run: bool = typer.Option(False, "--dry-run"),
) -> None:
    """Submit a new processing job."""
    if dry_run:
        info(
            f"Would submit {job_type} job: collection={collection} factory={factory} model={model_id}"
        )
        return

    require_write(ctx, f"Submit {job_type} job")
    client = get_sdk_client()

    if job_type == "embed":
        job = client.jobs.submit_embed(
            collection_id=collection, factory_id=factory, model_id=model_id
        )
    elif job_type == "project":
        if not model_id:
            error("--model-id required for project jobs")
            raise typer.Exit(1)
        job = client.jobs.submit_project(model_id, factory_ids=[factory] if factory else None)
    elif job_type == "processor":
        job = client.jobs.submit_processor(factory_id=factory, collection_id=collection)
    elif job_type == "hf-upload":
        if not collection:
            error("--collection required for hf-upload jobs")
            raise typer.Exit(1)
        job = client.jobs.submit_hf_upload(collection)
    elif job_type == "hf-exclusion":
        if not collection:
            error("--collection required for hf-exclusion jobs")
            raise typer.Exit(1)
        job = client.jobs.submit_hf_exclusion(collection)
    else:
        error(f"Unknown job type: {job_type}")
        raise typer.Exit(1)

    success(f"Submitted {job_type} job: {job.job_id}")


@app.command("retry")
def jobs_retry(
    ctx: typer.Context,
    job_id: str = typer.Argument(..., help="Job UUID"),
    dry_run: bool = typer.Option(False, "--dry-run"),
) -> None:
    """Retry a failed job."""
    if dry_run:
        info(f"Would retry job {job_id}")
        return

    require_write(ctx, "Job retry")
    client = get_sdk_client()
    client.jobs.retry(job_id)
    success(f"Retried job {job_id}")


@app.command("cancel")
def jobs_cancel(
    ctx: typer.Context,
    job_id: str = typer.Argument(..., help="Job UUID"),
    dry_run: bool = typer.Option(False, "--dry-run"),
) -> None:
    """Cancel a running job."""
    if dry_run:
        info(f"Would cancel job {job_id}")
        return

    require_write(ctx, "Job cancel")
    client = get_sdk_client()
    client.jobs.cancel(job_id)
    success(f"Cancelled job {job_id}")
