"""Run database migrations."""

import asyncio
import os
from pathlib import Path

import typer
from typing_extensions import Annotated

from cli.console import console, success, error, info, warning, dim
from cli.context import get_connection
from cli.guard import require_write


MIGRATIONS_DIR = Path(__file__).parent.parent.parent.parent.parent / "migrations"

# Migration tracking table location
MIGRATIONS_TABLE = "public._migrations"


MIGRATIONS_SA_EMAIL = "migrations-sa@data-470400.iam.gserviceaccount.com"
MIGRATIONS_SA_DB_USER = "migrations-sa@data-470400.iam"  # AlloyDB truncated format


async def _get_migrations_connection(settings):
    """
    Connect as migrations-sa via SA impersonation.

    The calling user impersonates migrations-sa, which has buildai_owner
    role in AlloyDB. AlloyDB IAM SA users use truncated email format.
    """
    from infra.database import Database

    ip_type = "PRIVATE" if settings.use_private_ip else "PUBLIC"

    db = Database(
        instance_uri=settings.alloydb_instance_uri,
        database=settings.db_name,
        user=MIGRATIONS_SA_DB_USER,
        use_iam_auth=True,
        ip_type=ip_type,
        impersonate_sa=MIGRATIONS_SA_EMAIL,
    )

    await db.connect()
    return db


async def _get_admin_connection(settings):
    """
    Get a database connection as the postgres user via password auth.

    This is a fallback for when IAM auth isn't working or for operations
    that require the postgres user specifically.

    Requires ALLOYDB_PSW_PROD environment variable.
    """
    from infra.database import Database

    admin_password = os.getenv("ALLOYDB_PSW_PROD", "")

    if not admin_password:
        raise RuntimeError(
            "Admin credentials not configured.\nSet ALLOYDB_PSW_PROD in .env (postgres password)\n"
        )

    ip_type = "PRIVATE" if settings.use_private_ip else "PUBLIC"

    db = Database(
        instance_uri=settings.alloydb_instance_uri,
        database=settings.db_name,
        user="postgres",
        password=admin_password,
        use_iam_auth=False,
        ip_type=ip_type,
    )

    await db.connect()
    return db


async def _ensure_migrations_table(conn) -> None:
    """Create migrations tracking table if it doesn't exist."""
    await conn.execute(f"""
        CREATE TABLE IF NOT EXISTS {MIGRATIONS_TABLE} (
            id SERIAL PRIMARY KEY,
            filename TEXT UNIQUE NOT NULL,
            applied_at TIMESTAMPTZ DEFAULT NOW()
        )
    """)


async def _set_owner_role(conn) -> bool:
    """
    Set role to buildai_owner for DDL operations.

    Returns True if successful, False if role doesn't exist.
    """
    try:
        await conn.execute("SET ROLE buildai_owner")
        return True
    except Exception as e:
        if "does not exist" in str(e).lower() or "permission denied" in str(e).lower():
            return False
        raise


def migrate(
    ctx: typer.Context,
    target: Annotated[str | None, typer.Argument(help="Migration file to run (or 'all')")] = None,
    dry_run: bool = typer.Option(False, "--dry-run", help="Show migrations without running"),
    as_admin: bool = typer.Option(
        False,
        "--as-admin",
        help="Connect as postgres user via password auth (fallback mode)",
    ),
    timeout: int = typer.Option(
        3600,
        "--timeout",
        help="Statement timeout in seconds (default 3600 = 1 hour, 0 = no timeout)",
    ),
) -> None:
    """
    Run database migrations.

    By default, connects via IAM auth and uses SET ROLE buildai_owner for DDL.
    Use --as-admin to connect directly as postgres user (requires ALLOYDB_PSW_PROD).

    Examples:
        cli migrate                           # Show pending migrations
        cli migrate all                       # Run all pending migrations
        cli migrate 001_create_tables.sql     # Run specific migration
        cli migrate --dry-run all             # Preview what would run
        cli --env prod migrate all            # Run in production (with confirmation)
        cli migrate --as-admin all            # Use postgres password auth
    """
    from cli.ops_init import init_ops_context
    from infra.settings import Settings

    init_ops_context(ctx)

    async def run() -> None:
        settings: Settings = ctx.obj["settings"]
        if target is not None and not dry_run:
            require_write(ctx, "Database migrations")

        if not MIGRATIONS_DIR.exists():
            error(f"Migrations directory not found: {MIGRATIONS_DIR}")
            raise typer.Exit(1)

        # Get all migration files
        migration_files = sorted(MIGRATIONS_DIR.glob("*.sql"))
        if not migration_files:
            info("No migration files found")
            return

        # Get connection
        db = None  # Track Database object for cleanup
        if as_admin:
            info("Connecting as postgres (password auth)...")
            db = await _get_admin_connection(settings)
            conn = db.conn
            using_owner_role = False
            connection_context = None
        else:
            # Default: impersonate migrations-sa (has buildai_owner role)
            try:
                info(f"Connecting as {MIGRATIONS_SA_DB_USER} (impersonation)...")
                db = await _get_migrations_connection(settings)
                conn = db.conn
                using_owner_role = await _set_owner_role(conn)
                if using_owner_role:
                    dim("Using role: buildai_owner")
                connection_context = None
            except Exception as e:
                # Fallback: connect as current IAM user
                dim(f"Impersonation failed ({e}), falling back to IAM user...")
                db = None
                connection_context = get_connection(settings)
                conn = await connection_context.__aenter__()
                using_owner_role = await _set_owner_role(conn)
                if using_owner_role:
                    dim("Using role: buildai_owner")
                else:
                    dim("Role buildai_owner not available, using default permissions")

        try:
            # Ensure migrations table exists
            await _ensure_migrations_table(conn)

            # Get applied migrations
            applied = await conn.fetch(f"SELECT filename FROM {MIGRATIONS_TABLE}")
            applied_set = {row["filename"] for row in applied}

            # Find pending migrations
            pending = [f for f in migration_files if f.name not in applied_set]

            if target is None:
                # Just show status
                env_name = "prod" if settings.is_production else "dev"
                auth_mode = (
                    "postgres"
                    if as_admin
                    else ("buildai_owner" if using_owner_role else "IAM user")
                )
                console.print(
                    f"\n[bold]Migration Status[/bold] ({env_name}) [dim]as {auth_mode}[/dim]\n"
                )
                console.print(
                    f"Total: {len(migration_files)}, Applied: {len(applied_set)}, Pending: {len(pending)}\n"
                )

                if pending:
                    console.print("[yellow]Pending migrations:[/yellow]")
                    for f in pending[:10]:
                        console.print(f"  • {f.name}")
                    if len(pending) > 10:
                        dim(f"  ... and {len(pending) - 10} more")
                else:
                    success("All migrations applied")
                return

            # Determine which migrations to run
            if target == "all":
                to_run = pending
            else:
                # Find specific migration
                matches = [f for f in migration_files if target in f.name]
                if not matches:
                    error(f"Migration not found: {target}")
                    raise typer.Exit(1)
                to_run = matches

            if not to_run:
                success("No migrations to run")
                return

            if dry_run:
                console.print("[yellow]Dry run - would apply:[/yellow]")
                for f in to_run:
                    console.print(f"  • {f.name}")
                return

            # Confirm in production
            if settings.is_production:
                warning(f"About to run {len(to_run)} migration(s) in PRODUCTION")
                if not typer.confirm("Continue?"):
                    raise typer.Abort()

            # Run migrations
            for migration_file in to_run:
                info(f"Running {migration_file.name}...")

                try:
                    sql = migration_file.read_text()

                    # Disable statement timeout for long migrations
                    if timeout == 0:
                        await conn.execute("SET statement_timeout = '0'")
                    else:
                        await conn.execute(f"SET statement_timeout = '{timeout}s'")

                    # Execute migration (use None timeout to rely on server-side setting)
                    await conn.execute(sql, timeout=None)

                    # Record migration
                    await conn.execute(
                        f"INSERT INTO {MIGRATIONS_TABLE} (filename) VALUES ($1) ON CONFLICT DO NOTHING",
                        migration_file.name,
                    )

                    success(f"Applied {migration_file.name}")

                except Exception as e:
                    error(f"Migration failed: {migration_file.name}")
                    error(str(e))
                    raise typer.Exit(1)

            success(f"Applied {len(to_run)} migration(s)")

        finally:
            # Reset role if we changed it
            if using_owner_role:
                try:
                    await conn.execute("RESET ROLE")
                except Exception:
                    pass

            # Clean up connection
            if db is not None:
                await db.close()
            elif connection_context is not None:
                await connection_context.__aexit__(None, None, None)

    asyncio.run(run())
