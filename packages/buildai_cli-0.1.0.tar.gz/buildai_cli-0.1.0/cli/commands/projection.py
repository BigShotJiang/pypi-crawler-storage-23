"""
Projection CLI commands.

Manages 2D projection jobs for embedding visualization.

Commands:
    projection status                           # Show projections and status

Note: To submit projection jobs, use the unified jobs CLI:
    cli jobs queue umap_projection --space-id 2 --n-neighbors 15
    cli jobs submit <manifest_id>

Examples:
    # Show recent projections
    cli projection status

    # Filter by model
    cli projection status --model siglip2

    # Show pending jobs
    cli projection status --jobs
"""

import asyncio
import json
from typing import Any

import typer
from rich.console import Console
from rich.table import Table

from cli.context import get_connection

app = typer.Typer(help="Projection status and information")
console = Console()


# =============================================================================
# Status Command
# =============================================================================


@app.command("status")
def status(
    ctx: typer.Context,
    model: str = typer.Option(None, "--model", "-m", help="Filter by embedding model ID"),
    limit: int = typer.Option(20, "--limit", "-l", help="Number of projections to show"),
    show_jobs: bool = typer.Option(False, "--jobs", "-j", help="Also show pending manifests"),
) -> None:
    """Show projections and job status."""
    asyncio.run(_status(ctx, model, limit, show_jobs))


async def _status(
    ctx: typer.Context,
    model: str | None,
    limit: int,
    show_jobs: bool,
) -> None:
    settings = ctx.obj["settings"]
    async with get_connection(settings) as conn:
        # Build query for projections
        conditions = []
        params: list[Any] = []
        param_idx = 0

        if model:
            param_idx += 1
            conditions.append(f"es.model_id = ${param_idx}")
            params.append(model)

        where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""

        # Get recent projections
        runs_query = f"""
            SELECT
                p.id,
                p.embedding_space_id,
                es.model_id,
                es.variant,
                p.projection_scope,
                p.scope_id,
                p.source_type,
                p.algorithm,
                p.n_points,
                p.compute_time_ms,
                p.is_active,
                p.model_uri,
                p.created_at
            FROM observations.projections p
            JOIN observations.embedding_spaces es ON p.embedding_space_id = es.id
            {where_clause}
            ORDER BY p.created_at DESC
            LIMIT {limit}
        """
        runs = await conn.fetch(runs_query, *params)

        if not runs:
            console.print("[yellow]No projections found[/yellow]")
        else:
            # Display projections table
            table = Table(title="Projections", show_header=True, header_style="bold cyan")
            table.add_column("Space", style="dim")
            table.add_column("Model", style="green")
            table.add_column("Variant", style="blue")
            table.add_column("Scope", style="yellow")
            table.add_column("Algo", style="magenta")
            table.add_column("Points", justify="right")
            table.add_column("Time (s)", justify="right")
            table.add_column("Current", justify="center")
            table.add_column("Created", style="dim")

            for run in runs:
                time_sec = run["compute_time_ms"] / 1000 if run["compute_time_ms"] else 0
                current = "[green]✓[/green]" if run["is_active"] else ""
                # Build scope display from projection_scope and scope_id
                scope_type = run["projection_scope"] or "global"
                if scope_type == "global":
                    scope = "global"
                else:
                    scope_id_short = str(run["scope_id"])[:6] if run["scope_id"] else "?"
                    scope = f"{scope_type[0].upper()}:{scope_id_short}"
                # Add source type indicator
                source = run["source_type"] or "raw"
                if source == "medoids":
                    scope = f"{scope} (med)"
                table.add_row(
                    str(run["embedding_space_id"]),
                    run["model_id"],
                    run["variant"] or "(none)",
                    scope,
                    run["algorithm"] or "umap",
                    f"{run['n_points']:,}" if run["n_points"] else "0",
                    f"{time_sec:.1f}" if time_sec else "-",
                    current,
                    run["created_at"].strftime("%Y-%m-%d %H:%M") if run["created_at"] else "-",
                )

            console.print(table)

        if show_jobs:
            # Get pending projection manifests (not legacy processing.jobs)
            manifests_query = """
                SELECT
                    id,
                    status,
                    batch_job_name,
                    config,
                    error_message,
                    chunk_count,
                    chunks_succeeded,
                    chunks_failed,
                    created_at
                FROM processing.manifests
                WHERE job_type = 'umap_projection'
                ORDER BY created_at DESC
                LIMIT 20
            """
            manifests_rows = await conn.fetch(manifests_query)

            if manifests_rows:
                console.print()
                manifests_table = Table(
                    title="Projection Manifests", show_header=True, header_style="bold cyan"
                )
                manifests_table.add_column("ID", style="dim")
                manifests_table.add_column("Status", style="cyan")
                manifests_table.add_column("Batch Job", style="yellow")
                manifests_table.add_column("Space", style="green")
                manifests_table.add_column("Progress", justify="right")
                manifests_table.add_column("Created", style="dim")

                for manifest in manifests_rows:
                    config = (
                        manifest["config"]
                        if isinstance(manifest["config"], dict)
                        else json.loads(manifest["config"] or "{}")
                    )
                    status_color = {
                        "pending": "yellow",
                        "running": "blue",
                        "succeeded": "green",
                        "failed": "red",
                    }.get(manifest["status"], "white")

                    space_id = config.get("embedding_space_id", "-")
                    chunk_count = manifest["chunk_count"] or 0
                    succeeded = manifest["chunks_succeeded"] or 0
                    failed = manifest["chunks_failed"] or 0
                    progress = f"{succeeded}/{chunk_count}" if chunk_count else "-"
                    if failed > 0:
                        progress += f" ({failed} failed)"

                    manifests_table.add_row(
                        manifest["id"][:20] + "...",
                        f"[{status_color}]{manifest['status']}[/{status_color}]",
                        manifest["batch_job_name"] or "-",
                        str(space_id),
                        progress,
                        manifest["created_at"].strftime("%Y-%m-%d %H:%M")
                        if manifest["created_at"]
                        else "-",
                    )

                console.print(manifests_table)
            else:
                console.print("\n[dim]No projection manifests found[/dim]")

            # Hint about unified CLI
            console.print()
            console.print("[dim]To queue projection jobs:[/dim]")
            console.print("  [cyan]cli jobs queue umap_projection --space-id <id>[/cyan]")
            console.print("  [cyan]cli jobs submit <manifest_id>[/cyan]")

        # Get embedding counts from embedding_spaces registry
        counts_query = """
            SELECT s.model_id, s.variant, s.table_name
            FROM observations.embedding_spaces s
            WHERE s.is_active = true
            ORDER BY s.id
        """
        spaces = await conn.fetch(counts_query)

        if spaces:
            console.print()
            counts_table = Table(
                title="Embeddings by Space", show_header=True, header_style="bold cyan"
            )
            counts_table.add_column("Model", style="green")
            counts_table.add_column("Variant", style="yellow")
            counts_table.add_column("Count", justify="right")

            for space in spaces:
                # Count from each emb_* table
                count_result = await conn.fetchrow(
                    f"SELECT COUNT(*) as count FROM observations.{space['table_name']}"
                )
                count = count_result["count"] if count_result else 0
                variant_display = space["variant"] or "(none)"
                counts_table.add_row(space["model_id"], variant_display, f"{count:,}")

            console.print(counts_table)
