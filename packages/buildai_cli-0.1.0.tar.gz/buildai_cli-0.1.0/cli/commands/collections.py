"""CLI commands for collections (SDK-backed)."""

from __future__ import annotations

import itertools

import typer

from cli.console import info, success
from cli.guard import require_write
from cli.output import Format, format_option, output
from cli.sdk_client import get_sdk_client

app = typer.Typer(
    name="collections",
    help="Manage clip collections.",
    no_args_is_help=True,
)


@app.command("list")
def collections_list(
    limit: int = typer.Option(20, "--limit", "-n"),
    format: Format | None = format_option(),
) -> None:
    """List all collections."""
    client = get_sdk_client()
    results = list(itertools.islice(client.collections.iter(), limit))
    output(results, format=format, columns=["collection_id", "name", "clip_count", "created_at"])


@app.command("get")
def collections_get(
    collection_id: str = typer.Argument(..., help="Collection UUID"),
    format: Format | None = format_option(),
) -> None:
    """Get details for a single collection."""
    client = get_sdk_client()
    coll = client.collections.get(collection_id)
    output(coll, format=format)


@app.command("build")
def collections_build(
    ctx: typer.Context,
    collection_id: str = typer.Argument(..., help="Collection UUID"),
    dry_run: bool = typer.Option(False, "--dry-run"),
) -> None:
    """Trigger a build/refresh for a collection."""
    if dry_run:
        info(f"Would trigger build for collection {collection_id}")
        return

    require_write(ctx, "Collection build")
    client = get_sdk_client()
    client.jobs.submit_processor(collection_id=collection_id)
    success(f"Triggered build for collection {collection_id}")
