"""Lightweight auth commands — no core/infra deps."""

from typing_extensions import Annotated

import typer

from cli.config import resolve_cli_api_key, save_cli_config
from cli.console import console, success

app = typer.Typer(
    name="auth",
    help="Authentication and API key management",
    no_args_is_help=True,
)


@app.command("login")
def login(
    api_key: Annotated[str, typer.Argument(help="API key to store locally")],
    profile: Annotated[
        str | None,
        typer.Option(
            "--profile",
            "-p",
            help="Default CLI profile (e.g., readonly, mcp, svc_embedder)",
        ),
    ] = None,
) -> None:
    """Store an API key and optional profile in ~/.buildai/config.toml."""
    save_cli_config(api_key=api_key, profile=profile)
    success("Saved CLI credentials to ~/.buildai/config.toml")


@app.command("status")
def auth_status(ctx: typer.Context) -> None:
    """Show current authentication state — gcloud account, API key, profile."""
    import subprocess

    cli_profile = (ctx.obj or {}).get("cli_profile", "readonly")

    # gcloud active account
    try:
        result = subprocess.run(
            [
                "gcloud",
                "auth",
                "list",
                "--filter=status=ACTIVE",
                "--format=value(account)",
            ],
            capture_output=True,
            text=True,
            timeout=5,
        )
        gcloud_account = result.stdout.strip() or "not authenticated"
    except Exception:
        gcloud_account = "gcloud not available"

    console.print(f"  gcloud account : [cyan]{gcloud_account}[/cyan]")
    console.print(f"  profile        : {cli_profile}")

    # DB environment (only if core available)
    from cli._has_core import has_core

    if has_core() and ctx.obj and ctx.obj.get("_ops_ready"):
        settings = ctx.obj.get("settings")
        if settings:
            env_color = "yellow" if settings.is_production else "green"
            console.print(f"  DB environment : [{env_color}]{settings.app_env.value}[/]")
    else:
        console.print("  DB environment : [dim]n/a (ops-plane not loaded)[/dim]")

    # API key status
    api_key = resolve_cli_api_key()
    if api_key:
        prefix = api_key[:12] + "..."
        console.print(f"  API key        : [green]{prefix}[/green]")
    else:
        console.print("  API key        : [dim]not configured (set BUILDAI_API_KEY)[/dim]")
