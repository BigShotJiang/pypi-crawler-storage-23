"""Execute SQL queries against the database."""

import asyncio
import re

import typer
from typing_extensions import Annotated

from cli.console import console, error, show_sql, warning, dim
from cli.context import get_connection
from cli.output import Format, format_option, output
from infra.settings import Settings


# =============================================================================
# Query hints for DAL-covered tables
# =============================================================================

# Map of table patterns to suggested CLI commands
QUERY_HINTS = {
    "processing.jobs": "Tip: Use 'cli embed status' for embedding job statistics",
    "processing.jobs_embed": "Tip: Use 'cli embed status' for embedding job statistics",
    "observations.frame_embeddings": "Note: observations.frame_embeddings has been dropped. Use observations.emb_siglip2_ego100k_frame_default instead. 'cli embed status' shows counts.",
    "observations.clip_embeddings": "Note: observations.clip_embeddings has been dropped. Use observations.emb_qwen_holistic_v1 (or other emb_qwen_* / emb_siglip_*) instead. 'cli embed status' shows counts.",
    "observations.text_embeddings": "Note: observations.text_embeddings has been dropped. Use observations.emb_gemini_task_name (or other emb_gemini_*) instead. 'cli embed status' shows counts.",
    "observations.embedding_models": "Note: observations.embedding_models has been dropped. Use observations.embedding_spaces instead. 'cli embed status' shows counts.",
    "observations.embedding_spaces": "Tip: Use 'cli embed status' to see all embedding spaces and counts",
    "observations.projection": "Tip: Use 'cli generate-projections' to create UMAP projections",
    "public._migrations": "Tip: Use 'cli migrate' to view migration status",
    "core.clips": None,  # No specific hint, DAL covers this but raw queries are often needed
}


def _show_query_hints(sql: str) -> None:
    """Show helpful hints when queries touch DAL-covered tables."""
    sql_lower = sql.lower()
    shown = set()

    for table_pattern, hint in QUERY_HINTS.items():
        if hint and table_pattern.lower() in sql_lower and hint not in shown:
            dim(f"\n{hint}")
            shown.add(hint)


def _normalize_sql(sql: str) -> str:
    """Normalize SQL for analysis (remove comments, collapse whitespace)."""
    # Remove single-line comments
    normalized = re.sub(r"--.*$", "", sql, flags=re.MULTILINE)
    # Remove multi-line comments
    normalized = re.sub(r"/\*.*?\*/", "", normalized, flags=re.DOTALL)
    # Collapse whitespace
    return " ".join(normalized.split()).upper()


def _is_write_query(sql: str) -> bool:
    """
    Detect if query modifies data using sqlparse AST.

    Checks for SQL statements that modify database state.
    SELECT queries (including CTEs, subqueries) are considered safe.
    """
    import sqlparse

    _WRITE_TYPES = {
        "INSERT",
        "UPDATE",
        "DELETE",
        "DROP",
        "CREATE",
        "ALTER",
        "TRUNCATE",
        "GRANT",
        "REVOKE",
    }

    statements = sqlparse.parse(sql)
    for stmt in statements:
        stmt_type = stmt.get_type()
        if stmt_type and stmt_type.upper() in _WRITE_TYPES:
            return True

    # Fallback: sqlparse may not classify VACUUM/REASSIGN
    normalized = _normalize_sql(sql)
    for kw in ("VACUUM", "REASSIGN"):
        if normalized.startswith(kw + " ") or normalized == kw:
            return True

    return False


def _is_select_query(sql: str) -> bool:
    """
    Detect if query returns rows (SELECT or WITH ... SELECT).

    Commands like GRANT, DROP, INSERT, etc. return status strings, not rows.
    """
    normalized = _normalize_sql(sql)

    # SELECT queries return rows
    if normalized.startswith("SELECT "):
        return True

    # WITH ... SELECT returns rows (CTEs)
    if normalized.startswith("WITH "):
        # Check if it ends with SELECT (not INSERT/UPDATE/DELETE)
        for kw in ["INSERT", "UPDATE", "DELETE"]:
            if f" {kw} " in normalized:
                return False
        return True

    # SHOW, EXPLAIN, TABLE also return rows
    for kw in ["SHOW ", "EXPLAIN ", "TABLE "]:
        if normalized.startswith(kw):
            return True

    return False


def query(
    ctx: typer.Context,
    sql: Annotated[str, typer.Argument(help="SQL query to execute")],
    format: Format = format_option(),
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmation for write queries"),
    ] = False,
    write: Annotated[
        bool,
        typer.Option("--write", help="Allow write queries (requires admin profile)"),
    ] = False,
) -> None:
    """
    Execute SQL queries directly against the database.

    Environment is controlled by --env flag on the main CLI:
    - Default: development (safe)
    - Production: requires --env production flag

    SAFETY: Write operations (INSERT, UPDATE, DELETE, etc.) to production
    require confirmation. SELECT queries run without prompting.

    Examples:
        cli query "SELECT COUNT(*) FROM core.clips"
        cli query "SELECT * FROM operations.device_models"
        cli query "SELECT schemaname, tablename FROM pg_tables WHERE schemaname = 'core'" -f json
        cli --env production --profile admin query "INSERT INTO ..." --write --yes  # Skip confirmation
    """
    from cli.ops_init import init_ops_context

    init_ops_context(ctx)
    settings: Settings = ctx.obj["settings"]

    async def run() -> None:
        is_write = _is_write_query(sql)
        cli_profile = (ctx.obj or {}).get("cli_profile", "readonly")

        if is_write and not write:
            error("Write query blocked. Re-run with --write and an admin profile.")
            raise typer.Exit(1)

        if is_write and cli_profile != "admin":
            error("Write query requires --profile admin.")
            raise typer.Exit(1)

        # SAFETY: Only confirm WRITE operations to production
        if settings.is_production and is_write and not yes:
            warning("WRITE operation to PRODUCTION database")
            console.print(f"  Database: [bold red]{settings.db_name}[/bold red]")
            preview = sql[:100] + ("..." if len(sql) > 100 else "")
            console.print(f"  Query: [dim]{preview}[/dim]")
            console.print()
            if not typer.confirm("Execute this write query?", default=False):
                console.print("[dim]Aborted.[/dim]")
                raise typer.Exit(0)
            console.print()

        show_sql(sql)

        async with get_connection(settings) as conn:
            try:
                if _is_select_query(sql):
                    # SELECT queries return rows
                    result = await conn.fetch(sql)
                    rows = [dict(row) for row in result]
                    columns = list(result[0].keys()) if result else []
                    output(rows, format=format, columns=columns)
                else:
                    # DDL/DML commands return status string
                    status = await conn.execute(sql)
                    # Status examples: "GRANT", "REVOKE", "DROP OWNED", "INSERT 0 1", "UPDATE 5"
                    console.print(f"[green]✓[/green] {status}")

                # Show helpful hints for DAL-covered tables
                _show_query_hints(sql)
            except Exception as e:
                error(f"Query failed: {e}")
                # Show more details for permission errors
                err_str = str(e).lower()
                if "permission denied" in err_str:
                    console.print(
                        "[dim]Hint: You may need GRANT <role> TO your_user to perform this action[/dim]"
                    )
                elif "does not exist" in err_str:
                    console.print(
                        "[dim]Hint: Check if the object/role name is correct and quoted properly[/dim]"
                    )
                elif "cannot be dropped" in err_str:
                    console.print(
                        '[dim]Hint: Use DROP OWNED BY "user" CASCADE first to remove dependencies[/dim]'
                    )
                raise typer.Exit(1)

    asyncio.run(run())
