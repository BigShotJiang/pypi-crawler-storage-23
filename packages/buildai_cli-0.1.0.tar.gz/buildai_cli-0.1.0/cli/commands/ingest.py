"""
Ingest CLI - Sync video metadata from BigQuery to PostgreSQL.

Commands:
- ingest list-sources: List available sources (from database)
- ingest run: Run ingestion for a source
- ingest status: Check sync status
- ingest add-source: Add a new source to the database
"""

import asyncio

import typer
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn

from cli.console import console, success, error, info, warning
from cli.guard import require_write
from cli.context import get_cli_context

app = typer.Typer(name="ingest", help="Sync video metadata from BigQuery to PostgreSQL")


@app.command("list-sources")
def list_sources_cmd(
    ctx: typer.Context,
    active_only: bool = typer.Option(False, "--active", "-a", help="Only show active sources"),
):
    """List available ingestion sources from the database."""
    settings = ctx.obj["settings"]

    async def _list():
        from data.ingester import sources

        async with get_cli_context(settings) as (db, dal_ctx):
            # Check if table exists
            try:
                source_list = await sources.list_(dal_ctx, active_only=active_only)
            except Exception as e:
                if "does not exist" in str(e):
                    warning("processing.ingester_sources table does not exist.")
                    info("Run migration 032_ingester_dal_schema.sql to create it.")
                    _show_fallback_sources()
                    return
                raise

            if not source_list:
                if active_only:
                    info("No active sources configured.")
                else:
                    info("No sources configured. Use 'ingest add-source' to add one.")
                    info("Or run seed: uv run cli database seed shared")
                return

            table = Table(title="Ingestion Sources")
            table.add_column("Name", style="cyan")
            table.add_column("Description")
            table.add_column("BQ Table", style="dim")
            table.add_column("Bucket", style="dim")
            table.add_column("Format", style="yellow")
            table.add_column("Active", style="green")

            for src in source_list:
                table.add_row(
                    src.name,
                    src.description[:40] if src.description else "",
                    src.bq_table,
                    src.bucket_name,
                    src.factory_format.value,
                    "Yes" if src.is_active else "No",
                )

            console.print(table)

    asyncio.run(_list())


def _show_fallback_sources():
    """Show static sources as fallback when DB table doesn't exist."""
    info("Falling back to static source registry...")

    try:
        from services.ingester.sources import SOURCES

        table = Table(title="Static Sources (legacy)")
        table.add_column("Name", style="cyan")
        table.add_column("Description")
        table.add_column("BQ Table", style="dim")
        table.add_column("Factory Format", style="yellow")

        for name, config in SOURCES.items():
            table.add_row(
                name,
                config.description,
                config.bq_table,
                config.factory_format,
            )

        console.print(table)
    except ImportError:
        error("Could not load static sources")


@app.command("run")
def run(
    ctx: typer.Context,
    source: str = typer.Argument(
        "all",
        help="Source to sync (or 'all' for all active sources).",
    ),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show plan without running"),
    use_legacy: bool = typer.Option(False, "--legacy", help="Use legacy static source registry"),
):
    """Run ingestion for a source.

    Examples:
        cli ingest run                    # Sync all active sources
        cli ingest run buildai-100k       # Sync specific source
        cli ingest run --dry-run all      # Preview what would be synced
        cli ingest run --legacy           # Use static source registry
    """
    if not dry_run:
        require_write(ctx, "Ingest run")
    settings = ctx.obj["settings"]

    if use_legacy:
        _run_legacy(ctx, source, dry_run, settings)
        return

    async def _run():
        from data.ingester import sources, runs
        from data.schema.ingester import TriggerSource
        from data.errors import NotFound
        from infra import init_observability
        from infra.settings.services import IngesterSettings
        from services.ingester.executor import IngesterExecutor

        async with get_cli_context(settings) as (db, dal_ctx):
            # Validate source exists
            if source != "all":
                try:
                    src = await sources.get_by_name(dal_ctx, source)
                    if not src.is_active:
                        warning(f"Source '{source}' is not active.")
                        if not typer.confirm("Continue anyway?"):
                            raise typer.Exit(1)
                except NotFound:
                    error(f"Source '{source}' not found in database.")
                    info("Use 'ingest list-sources' to see available sources.")
                    info("Use 'ingest run --legacy' to use static registry.")
                    raise typer.Exit(1)

            if dry_run:
                if source == "all":
                    active = await sources.list_active(dal_ctx)
                    info(f"Dry run - would sync {len(active)} active sources:")
                    for s in active:
                        console.print(f"  - {s.name} ({s.bq_table})")
                else:
                    src = await sources.get_by_name(dal_ctx, source)
                    info(f"Dry run - would sync source '{source}':")
                    console.print(f"  BQ Table: {src.bq_table}")
                    console.print(f"  Bucket: {src.bucket_name}")
                    console.print(f"  Batch size: {src.batch_size}")
                return

            # Initialize
            config = IngesterSettings()
            try:
                config.validate_config()
            except Exception as e:
                error(f"Configuration error: {e}")
                raise typer.Exit(1)

            init_observability(
                service_name=config.service_name,
                environment=settings.app_env.value,
                sentry_dsn=settings.sentry_dsn or None,
            )

            executor = IngesterExecutor(config)

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                if source == "all":
                    progress.add_task("Syncing all active sources...", total=None)
                    results = await executor.execute_all_sources(
                        dal_ctx, triggered_by=TriggerSource.CLI
                    )
                    total_rows = sum(results.values())

                    console.print()
                    for name, rows in results.items():
                        console.print(f"  {name}: {rows:,} rows")
                else:
                    progress.add_task(f"Syncing {source}...", total=None)
                    src = await sources.get_by_name(dal_ctx, source)
                    run_record = await runs.start(
                        dal_ctx,
                        src.id,
                        src.name,
                        triggered_by=TriggerSource.CLI,
                    )
                    total_rows = await executor.execute_source_sync(dal_ctx, src, run_record.id)

            success(f"Ingestion complete: {total_rows:,} rows synced")

    asyncio.run(_run())


def _run_legacy(ctx, source: str, dry_run: bool, settings):
    """Run using legacy static source registry."""
    from services.ingester.sources import SOURCES, list_sources

    if source != "all" and source not in SOURCES:
        available = ", ".join(list_sources())
        error(f"Unknown source '{source}'. Available: {available}")
        raise typer.Exit(1)

    if dry_run:
        sources_to_run = list_sources() if source == "all" else [source]
        info(f"Dry run mode - would sync: {sources_to_run}")
        return

    async def _run_legacy_sync():
        from infra import init_observability
        from infra.settings.services import IngesterSettings
        from services.ingester.main import IngesterService

        config = IngesterSettings()
        try:
            config.validate_config()
        except Exception as e:
            error(f"Configuration error: {e}")
            raise typer.Exit(1)

        init_observability(
            service_name=config.service_name,
            environment=settings.app_env.value,
            sentry_dsn=settings.sentry_dsn or None,
        )

        service = IngesterService(config)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            if source == "all":
                progress.add_task("Syncing all sources (legacy)...", total=None)
                total_rows = await service.sync_all_sources()
            else:
                progress.add_task(f"Syncing {source} (legacy)...", total=None)
                total_rows = await service.sync_source(source)

        success(f"Ingestion complete: {total_rows:,} rows synced")

    asyncio.run(_run_legacy_sync())


@app.command("status")
def status(ctx: typer.Context, limit: int = typer.Option(10, "--limit", "-n")):
    """Check ingestion sync status.

    Shows the status of recent ingestion runs from processing.ingester_runs.
    """
    settings = ctx.obj["settings"]

    async def _status():
        from data.ingester import runs

        async with get_cli_context(settings) as (db, dal_ctx):
            # Check if table exists
            try:
                run_list = await runs.list_recent(dal_ctx, limit=limit)
            except Exception as e:
                if "does not exist" in str(e):
                    info("processing.ingester_runs table does not exist yet.")
                    info("Run migration 032_ingester_dal_schema.sql to create it.")
                    _show_legacy_status(dal_ctx)
                    return
                raise

            if not run_list:
                info("No sync runs recorded yet.")
                return

            table = Table(title="Ingestion Runs")
            table.add_column("Source", style="cyan")
            table.add_column("Status", style="bold")
            table.add_column("Rows", justify="right")
            table.add_column("Duration", justify="right")
            table.add_column("Started")
            table.add_column("Error", style="red", max_width=40)

            for run in run_list:
                status_style = {
                    "success": "green",
                    "running": "yellow",
                    "failed": "red",
                    "cancelled": "dim",
                }.get(run.status.value, "")

                table.add_row(
                    run.source_name,
                    f"[{status_style}]{run.status.value}[/]",
                    f"{run.rows_processed:,}" if run.rows_processed else "-",
                    f"{run.duration_sec:.1f}s" if run.duration_sec else "-",
                    run.started_at.strftime("%Y-%m-%d %H:%M"),
                    (run.error_message or "")[:40],
                )

            console.print(table)

    asyncio.run(_status())


async def _show_legacy_status(dal_ctx):
    """Show legacy sync_state as fallback."""
    info("Checking legacy processing.sync_state table...")

    try:
        rows = await dal_ctx.db.fetch("""
            SELECT
                sync_name,
                status,
                rows_processed,
                duration_sec,
                last_run_at,
                error_message
            FROM processing.sync_state
            ORDER BY last_run_at DESC
            LIMIT 10
        """)

        if not rows:
            info("No sync runs in legacy table either.")
            return

        table = Table(title="Legacy Sync Status (processing.sync_state)")
        table.add_column("Sync Name", style="cyan")
        table.add_column("Status", style="bold")
        table.add_column("Rows", justify="right")
        table.add_column("Duration", justify="right")
        table.add_column("Last Run")

        for row in rows:
            status_style = {
                "success": "green",
                "running": "yellow",
                "failed": "red",
            }.get(row["status"], "")

            table.add_row(
                row["sync_name"],
                f"[{status_style}]{row['status']}[/]",
                f"{row['rows_processed']:,}" if row["rows_processed"] else "-",
                f"{row['duration_sec']:.1f}s" if row["duration_sec"] else "-",
                row["last_run_at"].strftime("%Y-%m-%d %H:%M") if row["last_run_at"] else "-",
            )

        console.print(table)

    except Exception:
        pass  # Silently ignore if legacy table also doesn't exist


@app.command("add-source")
def add_source(
    ctx: typer.Context,
    name: str = typer.Argument(..., help="Source name (e.g., 'buildai-200k')"),
    bq_table: str = typer.Option(..., "--bq-table", "-t", help="BigQuery table name"),
    bucket: str = typer.Option(..., "--bucket", "-b", help="GCS bucket name"),
    description: str = typer.Option("", "--description", "-d", help="Source description"),
    factory_format: str = typer.Option(
        "numbered",
        "--factory-format",
        "-f",
        help="Factory format: 'numbered' (factory123) or 'descriptive' (needs resolution)",
    ),
    batch_size: int = typer.Option(10000, "--batch-size", help="Batch size for inserts"),
):
    """Add a new ingestion source to the database.

    Example:
        cli ingest add-source buildai-200k \\
            --bq-table new_bucket_obj_table \\
            --bucket buildai-200k \\
            --description "New 200k bucket" \\
            --factory-format numbered
    """
    require_write(ctx, "Ingest source creation")
    settings = ctx.obj["settings"]

    async def _add():
        from data.ingester import sources
        from data.schema.ingester import IngesterSourceCreate, FactoryFormat
        from data.errors import ValidationError

        # Validate factory_format
        try:
            fmt = FactoryFormat(factory_format)
        except ValueError:
            error(f"Invalid factory format: {factory_format}")
            info("Valid options: numbered, descriptive")
            raise typer.Exit(1)

        async with get_cli_context(settings) as (db, dal_ctx):
            try:
                data = IngesterSourceCreate(
                    name=name,
                    description=description,
                    bq_table=bq_table,
                    bucket_name=bucket,
                    factory_format=fmt,
                    batch_size=batch_size,
                )

                source = await sources.create(dal_ctx, data)
                success(f"Source '{name}' created with ID: {source.id}")

            except ValidationError as e:
                error(f"Validation error: {e}")
                raise typer.Exit(1)

    asyncio.run(_add())


@app.command("deactivate")
def deactivate_source(
    ctx: typer.Context,
    name: str = typer.Argument(..., help="Source name to deactivate"),
):
    """Deactivate an ingestion source (soft delete)."""
    require_write(ctx, "Ingest source deactivation")
    settings = ctx.obj["settings"]

    async def _deactivate():
        from data.ingester import sources
        from data.errors import NotFound

        async with get_cli_context(settings) as (db, dal_ctx):
            try:
                source = await sources.get_by_name(dal_ctx, name)
                await sources.deactivate(dal_ctx, source.id)
                success(f"Source '{name}' deactivated")
            except NotFound:
                error(f"Source '{name}' not found")
                raise typer.Exit(1)

    asyncio.run(_deactivate())


@app.command("activate")
def activate_source(
    ctx: typer.Context,
    name: str = typer.Argument(..., help="Source name to activate"),
):
    """Reactivate a deactivated ingestion source."""
    require_write(ctx, "Ingest source activation")
    settings = ctx.obj["settings"]

    async def _activate():
        from data.ingester import sources
        from data.errors import NotFound

        async with get_cli_context(settings) as (db, dal_ctx):
            try:
                source = await sources.get_by_name(dal_ctx, name)
                await sources.activate(dal_ctx, source.id)
                success(f"Source '{name}' activated")
            except NotFound:
                error(f"Source '{name}' not found")
                raise typer.Exit(1)

    asyncio.run(_activate())
