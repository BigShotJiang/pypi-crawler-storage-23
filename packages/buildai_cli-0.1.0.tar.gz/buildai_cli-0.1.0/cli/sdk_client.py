"""Lazy SDK client initialization for CLI commands."""

from __future__ import annotations

import os

import typer

from cli.config import resolve_cli_api_key
from cli.console import error


def get_sdk_client(mode: str = "public"):
    """Get initialized SDK client. Uses BUILDAI_API_KEY or config file."""
    from buildai import Client

    api_key = resolve_cli_api_key()
    if not api_key:
        error("No API key found. Set BUILDAI_API_KEY or run: cli auth login <key>")
        raise typer.Exit(1)

    base_url = os.environ.get("BUILDAI_API_URL", "https://api.build.ai")
    return Client(api_key=api_key, base_url=base_url, mode=mode)


def get_internal_sdk_client():
    """Get SDK client in internal mode."""
    return get_sdk_client(mode="internal")
