#!/usr/bin/env python3
"""
BuildAI CLI — distributable entry-point.

Data-plane commands (clips, jobs, collections, …) work standalone with just
``pip install buildai-cli``.  Ops-plane commands (schema, database, query, …)
require the ``ops`` extra: ``pip install 'buildai-cli[ops]'``.
"""

import typer
from typing import Annotated
from dotenv import load_dotenv

from cli.console import set_verbose
from cli.config import resolve_cli_profile
from cli._has_core import has_core

load_dotenv()


def _version_callback(value: bool) -> None:
    if value:
        from importlib.metadata import version as pkg_version

        try:
            v = pkg_version("buildai-cli")
        except Exception:
            v = "dev"
        print(f"buildai-cli {v}")
        raise typer.Exit()


app = typer.Typer(
    name="buildai",
    help="Build AI CLI — data-scaling infrastructure for robotics.",
    no_args_is_help=True,
)


# ---------------------------------------------------------------------------
# Lightweight callback — NO infra imports, NO DB, NO observability
# ---------------------------------------------------------------------------


@app.callback()
def main_callback(
    ctx: typer.Context,
    env: Annotated[
        str | None,
        typer.Option(
            "--env",
            "-e",
            help=(
                "Target environment: production (default), development, or test. "
                "Default is production. Use --env development for dev database."
            ),
        ),
    ] = None,
    auth: Annotated[
        str | None,
        typer.Option(
            "--auth",
            "-a",
            help="Authentication method: iam or password. Default depends on environment.",
        ),
    ] = None,
    user: Annotated[
        str | None,
        typer.Option(
            "--user",
            "-u",
            help="Override database user (e.g., 'postgres', 'madhav@build.ai').",
        ),
    ] = None,
    profile: Annotated[
        str | None,
        typer.Option(
            "--profile",
            "-p",
            help="CLI scope profile (default: readonly).",
        ),
    ] = None,
    write: Annotated[
        bool,
        typer.Option(
            "--write",
            help="Allow write operations (required for any mutation, even with admin profile).",
        ),
    ] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
    version: Annotated[
        bool | None,
        typer.Option(
            "--version",
            callback=_version_callback,
            is_eager=True,
            help="Show version and exit.",
        ),
    ] = None,
) -> None:
    """
    CLI for Build AI backend.

    ENVIRONMENT SELECTION:
    - Default is PRODUCTION
    - Use --env development to access development database
    - Production write queries require confirmation

    AUTHENTICATION:
    - Production defaults to IAM auth with your gcloud account
    - Development defaults to password auth with postgres user
    """
    set_verbose(verbose)
    ctx.ensure_object(dict)
    ctx.obj["cli_profile"] = resolve_cli_profile(profile)
    ctx.obj["allow_write"] = write
    # Stash raw flags for lazy ops init (see cli/ops_init.py)
    ctx.obj["_env"] = env
    ctx.obj["_auth"] = auth
    ctx.obj["_user"] = user
    ctx.obj["_verbose"] = verbose
    ctx.obj["_ops_ready"] = False


# ---------------------------------------------------------------------------
# Data-plane commands (always available — SDK-backed)
# ---------------------------------------------------------------------------

from cli.commands.clips import app as clips_app
from cli.commands.jobs import app as jobs_app
from cli.commands.collections import app as collections_app
from cli.commands.partners import app as partners_app
from cli.commands.operations import app as operations_app
from cli.commands.keys import app as keys_app
from cli.commands.stats import app as stats_app
from cli.commands.auth_lite import app as auth_app

app.add_typer(clips_app, name="clips")
app.add_typer(jobs_app, name="jobs")
app.add_typer(collections_app, name="collections")
app.add_typer(partners_app, name="partners")
app.add_typer(operations_app, name="operations")
app.add_typer(keys_app, name="keys")
app.add_typer(stats_app, name="stats")
app.add_typer(auth_app, name="auth")


# ---------------------------------------------------------------------------
# Ops-plane commands (only if buildai-core is installed)
# ---------------------------------------------------------------------------


def _register_ops_typer(parent: typer.Typer, sub_app: typer.Typer, name: str) -> None:
    """Register an ops-plane sub-app with a callback that calls init_ops_context."""

    @sub_app.callback(invoke_without_command=True)
    def _ops_init(ctx: typer.Context) -> None:
        if ctx.invoked_subcommand is not None:
            from cli.ops_init import init_ops_context

            init_ops_context(ctx)

    parent.add_typer(sub_app, name=name)


if has_core():
    # Standalone ops commands
    from cli.commands.query import query
    from cli.commands.migrate import migrate

    app.command()(query)
    app.command()(migrate)

    # Ops-plane sub-apps
    from cli.commands.schema import app as schema_app
    from cli.commands.database import app as database_app
    from cli.commands.ingest import app as ingest_app
    from cli.commands.embed import app as embed_app
    from cli.commands.external import app as external_app
    from cli.commands.permissions import app as permissions_app
    from cli.commands.projection import app as projection_app
    from cli.commands.medoid import app as medoid_app

    _register_ops_typer(app, schema_app, "schema")
    _register_ops_typer(app, database_app, "database")
    _register_ops_typer(app, ingest_app, "ingest")
    _register_ops_typer(app, embed_app, "embed")
    _register_ops_typer(app, external_app, "external")
    _register_ops_typer(app, permissions_app, "permissions")
    _register_ops_typer(app, projection_app, "projection")
    _register_ops_typer(app, medoid_app, "medoid")

    # Ops auth commands → add to the lightweight auth app
    from cli.commands.auth_ops import create_key, list_keys, show_key, revoke_key

    auth_app.command("create-key")(create_key)
    auth_app.command("list-keys")(list_keys)
    auth_app.command("show-key")(show_key)
    auth_app.command("revoke-key")(revoke_key)

else:
    # -----------------------------------------------------------------------
    # Stubs — show friendly error when ops commands are invoked without core
    # -----------------------------------------------------------------------

    _OPS_GROUPS = [
        "database",
        "schema",
        "ingest",
        "embed",
        "external",
        "permissions",
        "projection",
        "medoid",
    ]

    def _make_stub_callback(group_name: str):
        def _stub_cb(ctx: typer.Context) -> None:
            from cli.console import error

            error(
                f"'{group_name}' requires ops-plane deps.\n"
                f"  Install with: pip install 'buildai-cli[ops]'\n"
                f"  Or workspace: uv pip install -e 'apps/buildai-cli[ops]' -e core"
            )
            raise typer.Exit(1)

        return _stub_cb

    for _name in _OPS_GROUPS:
        _stub = typer.Typer(
            name=_name,
            help="[requires: pip install 'buildai-cli[ops]']",
        )

        @_stub.callback(invoke_without_command=True)
        def _cb(ctx: typer.Context, _n: str = _name) -> None:
            _make_stub_callback(_n)(ctx)

        app.add_typer(_stub, name=_name)

    # Standalone command stubs
    @app.command("query")
    def _query_stub() -> None:
        """Execute SQL queries (requires ops-plane)."""
        from cli.console import error

        error(
            "'query' requires ops-plane deps.\n"
            "  Install with: pip install 'buildai-cli[ops]'\n"
            "  Or workspace: uv pip install -e 'apps/buildai-cli[ops]' -e core"
        )
        raise typer.Exit(1)

    @app.command("migrate")
    def _migrate_stub() -> None:
        """Run database migrations (requires ops-plane)."""
        from cli.console import error

        error(
            "'migrate' requires ops-plane deps.\n"
            "  Install with: pip install 'buildai-cli[ops]'\n"
            "  Or workspace: uv pip install -e 'apps/buildai-cli[ops]' -e core"
        )
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Entry-point
# ---------------------------------------------------------------------------


def main() -> None:
    """CLI entry point."""
    app()


if __name__ == "__main__":
    main()
