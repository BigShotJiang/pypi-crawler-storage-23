"""Output formatting for CLI commands.

Supports table, JSON, CSV, and JSONL output formats.
Auto-detects format based on TTY: table for interactive, JSON for pipes.
"""

import json
import sys
from enum import Enum
from typing import Any

import typer
from pydantic import BaseModel
from rich.table import Table

from cli.console import data_console, status_console


class Format(str, Enum):
    """Supported output formats."""

    TABLE = "table"
    JSON = "json"
    CSV = "csv"
    JSONL = "jsonl"


def detect_format() -> Format:
    """Auto-detect: table for TTY, json for pipes."""
    return Format.TABLE if sys.stdout.isatty() else Format.JSON


def format_option(default: Format | None = None) -> Any:
    """Typer option for --format flag. None means auto-detect."""
    return typer.Option(
        default,
        "--format",
        "-f",
        help="Output format: json, table, csv, jsonl (default: auto-detect from TTY)",
    )


def _to_dict(item: Any) -> dict:
    """Convert a Pydantic model or dict to a plain dict."""
    if isinstance(item, BaseModel):
        return item.model_dump(mode="json")
    if isinstance(item, dict):
        return item
    return dict(item)


def _to_dicts(data: Any) -> list[dict]:
    """Normalize data to a list of dicts."""
    if isinstance(data, BaseModel):
        return [_to_dict(data)]
    if isinstance(data, list):
        return [_to_dict(i) for i in data]
    if isinstance(data, dict):
        return [data]
    return [_to_dict(data)]


def output(
    data: Any,
    format: Format | None = None,
    columns: list[str] | None = None,
) -> None:
    """Output data in specified format.

    Args:
        data: List of dicts, single dict, or Pydantic model(s)
        format: Output format (None = auto-detect from TTY)
        columns: Column names for table/CSV (default: keys from first row)
    """
    fmt = format or detect_format()
    rows = _to_dicts(data)

    if not rows:
        status_console.print("[dim]No results[/dim]")
        return

    cols = columns or list(rows[0].keys())

    if fmt == Format.JSON:
        _print_json(rows)
    elif fmt == Format.JSONL:
        _print_jsonl(rows)
    elif fmt == Format.CSV:
        _print_csv(rows, cols)
    else:
        _print_table(rows, cols)


def _print_json(rows: list[dict]) -> None:
    data_console.print(json.dumps(rows, indent=2, default=str))


def _print_jsonl(rows: list[dict]) -> None:
    for row in rows:
        data_console.print(json.dumps(row, default=str))


def _print_csv(rows: list[dict], cols: list[str]) -> None:
    data_console.print(",".join(cols))
    for row in rows:
        values = [str(row.get(c, "")).replace(",", ";") for c in cols]
        data_console.print(",".join(values))


def _print_table(rows: list[dict], cols: list[str]) -> None:
    table = Table(show_header=True, header_style="bold cyan")
    for col in cols:
        table.add_column(col)
    for row in rows:
        table.add_row(*[str(row.get(c, "")) for c in cols])
    data_console.print(table)
    status_console.print(f"[dim]{len(rows)} row(s)[/dim]")
