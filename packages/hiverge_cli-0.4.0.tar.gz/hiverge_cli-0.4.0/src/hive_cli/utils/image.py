import logging
import subprocess

from hive_cli.utils.logger import logger


def build_image(
    image: str,
    platforms: str = "linux/amd64,linux/arm64",
    context: str = ".",
    dockerfile: str = "Dockerfile",
    push: bool = False,
    build_args: dict = None,
    build_secret: str = None,
    verbose: bool = False,
):
    cmd = [
        "docker",
        "buildx",
        "build",
        "--platform",
        platforms,
        "--file",
        dockerfile,
        "--tag",
        image,
    ]

    if push:
        cmd.append("--push")

    if build_args:
        for key, value in build_args.items():
            cmd.extend(["--build-arg", f"{key}={value}"])

    if build_secret:
        cmd.extend(["--secret", f"id={build_secret},env={build_secret}"])

    if verbose:
        cmd.extend(["--progress", "plain"])

    cmd.append(context)
    print(f"Image build command: {' '.join(map(str, cmd))}")

    try:
        if logger.isEnabledFor(logging.DEBUG) or verbose:
            capture_output = False
        else:
            capture_output = True

        subprocess.run(
            cmd,
            check=True,
            capture_output=capture_output,
            text=True,
        )
    except subprocess.CalledProcessError as e:
        print("Build STDERR:\n", e.stderr)
        raise
