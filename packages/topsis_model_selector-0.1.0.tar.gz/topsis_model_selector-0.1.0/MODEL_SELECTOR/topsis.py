import argparse
import numpy as np
import pandas as pd
import torch
import time

from transformers import AutoTokenizer, AutoModelForSequenceClassification
from sklearn.metrics import accuracy_score, f1_score


# ---------------- TOPSIS FUNCTION ----------------
def topsis(decision_matrix, weights, impacts):
    X = np.array(decision_matrix, dtype=float)
    weights = np.array(weights, dtype=float)

    norm = np.sqrt((X ** 2).sum(axis=0))
    X_norm = X / norm
    X_weighted = X_norm * weights

    ideal_best = []
    ideal_worst = []

    for j in range(X.shape[1]):
        if impacts[j] == '+':
            ideal_best.append(X_weighted[:, j].max())
            ideal_worst.append(X_weighted[:, j].min())
        else:
            ideal_best.append(X_weighted[:, j].min())
            ideal_worst.append(X_weighted[:, j].max())

    ideal_best = np.array(ideal_best)
    ideal_worst = np.array(ideal_worst)

    dist_best = np.sqrt(((X_weighted - ideal_best) ** 2).sum(axis=1))
    dist_worst = np.sqrt(((X_weighted - ideal_worst) ** 2).sum(axis=1))

    score = dist_worst / (dist_best + dist_worst)
    return score


# ---------------- MODEL EVALUATION ----------------
def evaluate_model(model_name, texts, labels, device):
    print(f"\nEvaluating {model_name}...")

    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSequenceClassification.from_pretrained(model_name)
    model.to(device)
    model.eval()

    predictions = []

    start_time = time.time()

    with torch.no_grad():
        for text in texts:
            inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True)
            inputs = {k: v.to(device) for k, v in inputs.items()}

            outputs = model(**inputs)
            pred = torch.argmax(outputs.logits, dim=1).item()
            predictions.append(pred)

    end_time = time.time()

    acc = accuracy_score(labels, predictions)
    f1 = f1_score(labels, predictions)
    inference_time = (end_time - start_time) * 1000  # ms

    # Model size in MB
    param_size = sum(p.numel() for p in model.parameters()) * 4 / (1024 ** 2)

    return acc, f1, inference_time, param_size


# ---------------- CLI ----------------
def main():
    parser = argparse.ArgumentParser(description="HuggingFace Model Comparator with TOPSIS")

    parser.add_argument("--models", required=True,
                        help="Comma separated model names")
    parser.add_argument("--dataset", required=True,
                        help="CSV file with text,label columns")

    args = parser.parse_args()

    models = args.models.split(',')

    # Load dataset
    df = pd.read_csv(args.dataset)

    if "text" not in df.columns or "label" not in df.columns:
        raise ValueError("CSV must contain 'text' and 'label' columns")

    texts = df["text"].tolist()
    labels = df["label"].tolist()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")

    results = []

    for model_name in models:
        acc, f1, time_ms, size = evaluate_model(model_name, texts, labels, device)
        results.append([model_name, acc, f1, time_ms, size])

    result_df = pd.DataFrame(results, columns=[
        "Model", "Accuracy", "F1_Score", "Time_ms", "Size_MB"
    ])

    # TOPSIS
    weights = [0.35, 0.35, 0.15, 0.15]
    impacts = ['+', '+', '-', '-']

    matrix = result_df[["Accuracy", "F1_Score", "Time_ms", "Size_MB"]].values

    result_df["TOPSIS_Score"] = topsis(matrix, weights, impacts)
    result_df["Rank"] = result_df["TOPSIS_Score"].rank(ascending=False).astype(int)

    result_df = result_df.sort_values("Rank")

    print("\nFinal Ranking:\n")
    print(result_df)


if __name__ == "__main__":
    main()
