import argparse
import pandas as pd
from .topsis import calculate_topsis


def main():
    parser = argparse.ArgumentParser(description="TOPSIS Model Selector CLI")

    parser.add_argument("input_file", help="Input CSV file path")
    parser.add_argument("--weights", required=True,
                        help="Comma separated weights (e.g., 0.35,0.35,0.15,0.15)")
    parser.add_argument("--impacts", required=True,
                        help="Comma separated impacts (e.g., +,+,-,-)")
    parser.add_argument("--output", default="result.csv",
                        help="Output CSV file")

    args = parser.parse_args()

    df = pd.read_csv(args.input_file)
    weights = list(map(float, args.weights.split(',')))
    impacts = args.impacts.split(',')

    result = calculate_topsis(df, weights, impacts)
    result.to_csv(args.output, index=False)

    print("\nTOPSIS Ranking Completed!")
    print(result)
