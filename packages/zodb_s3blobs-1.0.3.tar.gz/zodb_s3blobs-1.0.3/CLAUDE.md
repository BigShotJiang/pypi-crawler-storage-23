# Project Instructions

## Worktrees

Always create git worktrees under `.worktrees/` in the project root:

```
git worktree add .worktrees/<name> -b <branch-name>
```

The `.worktrees/` directory is gitignored.
