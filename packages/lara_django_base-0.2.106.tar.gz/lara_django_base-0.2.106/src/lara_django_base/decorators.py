# common lara_django decorators

from django.conf import settings

def postgres_only(func):
    def wrapper(*args, **kwargs):
        if settings.DATABASES["default"]["ENGINE"] != "django.db.backends.postgresql":
            return
        return func(*args, **kwargs)
    return wrapper