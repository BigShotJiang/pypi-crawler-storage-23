"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_base Model Context Protocol (MCP) handler *

:details: lara_django_base Model Context Protocol (MCP) handler.

:authors: mark doerr <mark.doerr@uni-greifswald.de>

________________________________________________________________________
"""

from mcp_server import ModelQueryToolset

from .models import (
    Address,
    City,
    Country,
    CountrySubdivision,
    Currency,
    DataType,
    ExternalResource,
    ExtraData,
    GeoLocation,
    ItemRole,
    ItemStatus,
    LARAExtension,
    LARASyncServer,
    Location,
    LocationType,
    MediaType,
    Namespace,
    PhysicalStateMatter,
    PhysicalUnit,
    Room,
    RoomCategory,
    ScientificConstant,
    SubdivisionType,
    Tag,
)


class MediaTypeQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `MediaType`."""

    model = MediaType


class DataTypeQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `DataType`."""

    model = DataType


class NamespaceQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Namespace`."""

    model = Namespace


class TagQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Tag`."""

    model = Tag


class ItemRoleQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ItemRole`."""

    model = ItemRole


class ItemStatusQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ItemStatus`."""

    model = ItemStatus


class ExtraDataQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ExtraData`."""

    model = ExtraData


class ExternalResourceQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ExternalResource`."""

    model = ExternalResource


class PhysicalUnitQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `PhysicalUnit`."""

    model = PhysicalUnit


class PhysicalStateMatterQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `PhysicalStateMatter`."""

    model = PhysicalStateMatter


class ScientificConstantQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ScientificConstant`."""

    model = ScientificConstant


class CurrencyQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Currency`."""

    model = Currency


class LARAExtensionQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `LARAExtension`."""

    model = LARAExtension


class GeoLocationQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `GeoLocation`."""

    model = GeoLocation


class CountryQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Country`."""

    model = Country


class SubdivisionTypeQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `SubdivisionType`."""

    model = SubdivisionType


class CountrySubdivisionQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `CountrySubdivision`."""

    model = CountrySubdivision


class CityQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `City`."""

    model = City


class LocationTypeQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `LocationType`."""

    model = LocationType


class LocationQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Location`."""

    model = Location


class RoomCategoryQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `RoomCategory`."""

    model = RoomCategory


class RoomQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Room`."""

    model = Room


class AddressQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Address`."""

    model = Address


class LARASyncServerQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `LARASyncServer`."""

    model = LARASyncServer



