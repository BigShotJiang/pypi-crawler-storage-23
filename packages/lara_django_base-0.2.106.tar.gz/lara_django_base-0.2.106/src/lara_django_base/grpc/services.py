"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC services*

:details: lara_django_myproj gRPC services.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_base  (LARA-version)

import asyncio

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
from django_socio_grpc import generics, mixins
from django_socio_grpc.decorators import grpc_action

from lara_django_base.grpc.mixins import (
    AsyncDownloadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncUploadModelMixin,
)
from lara_django_base.models import (
    Address,
    City,
    Country,
    CountrySubdivision,
    Currency,
    DataType,
    ExternalResource,
    ExtraData,
    GeoLocation,
    ItemStatus,
    LARASyncServer,
    Location,
    MediaType,
    Namespace,
    PhysicalStateMatter,
    PhysicalUnit,
    Room,
    RoomCategory,
    ScientificConstant,
    SubdivisionType,
    Tag,
)

from ..filters import (
    AddressFilterSet,
    CityFilterSet,
    CountryFilterSet,
    CountrySubdivisionFilterSet,
    CurrencyFilterSet,
    DataTypeFilterSet,
    ExternalResourceFilterSet,
    ExtraDataFilterSet,
    GeoLocationFilterSet,
    ItemStatusFilterSet,
    LARASyncServerFilterSet,
    LocationFilterSet,
    MediaTypeFilterSet,
    NamespaceFilterSet,
    PhysicalStateMatterFilterSet,
    PhysicalUnitFilterSet,
    RoomCategoryFilterSet,
    RoomFilterSet,
    ScientificConstantFilterSet,
    SubdivisionTypeFilterSet,
    TagFilterSet,
)
from .serializers import (
    AddressProtoSerializer,
    CityProtoSerializer,
    CountryProtoSerializer,
    CountrySubdivisionProtoSerializer,
    CurrencyProtoSerializer,
    DataTypeProtoSerializer,
    ExternalResourceProtoSerializer,
    ExtraDataProtoSerializer,
    GeoLocationProtoSerializer,
    ItemStatusProtoSerializer,
    LARASyncServerProtoSerializer,
    LocationProtoSerializer,
    MediaTypeProtoSerializer,
    NamespaceByURIProtoSerializer,
    NamespaceProtoSerializer,
    PhysicalStateMatterProtoSerializer,
    PhysicalUnitProtoSerializer,
    RoomCategoryProtoSerializer,
    RoomProtoSerializer,
    ScientificConstantProtoSerializer,
    SubdivisionTypeProtoSerializer,
    TagProtoSerializer,
)


class DataTypeService(
    generics.AsyncModelService,
    AsyncRetrieveByNameModelMixin,
    mixins.AsyncStreamModelMixin,
):
    queryset = DataType.objects.all()
    serializer_class = DataTypeProtoSerializer
    filterset_class = DataTypeFilterSet


class MediaTypeService(
    generics.AsyncModelService,
    AsyncRetrieveByNameModelMixin,
    mixins.AsyncStreamModelMixin,
):
    queryset = MediaType.objects.all()
    filterset_class = MediaTypeFilterSet
    serializer_class = MediaTypeProtoSerializer


class NamespaceService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Namespace.objects.all()
    filterset_class = NamespaceFilterSet
    serializer_class = NamespaceProtoSerializer

    lookup_field = "namespace_id"


class NamespaceByURIService(
    generics.GenericService, mixins.AsyncListModelMixin, mixins.AsyncRetrieveModelMixin
):
    serializer_class = NamespaceByURIProtoSerializer
    queryset = Namespace.objects.all().order_by("uri")

    lookup_field = "uri"


class TagService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Tag.objects.all()
    serializer_class = TagProtoSerializer
    filterset_class = TagFilterSet


class ItemStatusService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = ItemStatus.objects.all()
    serializer_class = ItemStatusProtoSerializer
    filterset_class = ItemStatusFilterSet


class ExtraDataService(
    generics.AsyncModelService,
    mixins.AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    pb2 = lara_django_base_pb2
    queryset = ExtraData.objects.all()
    serializer_class = ExtraDataProtoSerializer
    filterset_class = ExtraDataFilterSet


class PhysicalUnitService(
    generics.AsyncModelService,
    AsyncRetrieveByNameModelMixin,
    mixins.AsyncStreamModelMixin,
):
    queryset = PhysicalUnit.objects.all()
    serializer_class = PhysicalUnitProtoSerializer
    filterset_class = PhysicalUnitFilterSet


class ExternalResourceService(
    generics.AsyncModelService,
    AsyncRetrieveByNameModelMixin,
    mixins.AsyncStreamModelMixin,
):
    queryset = ExternalResource.objects.all()
    serializer_class = ExternalResourceProtoSerializer
    filterset_class = ExternalResourceFilterSet


class PhysicalStateMatterService(
    generics.AsyncModelService,
    AsyncRetrieveByNameModelMixin,
    mixins.AsyncStreamModelMixin,
):
    queryset = PhysicalStateMatter.objects.all()
    serializer_class = PhysicalStateMatterProtoSerializer
    filterset_class = PhysicalStateMatterFilterSet


class ScientificConstantService(
    generics.AsyncModelService,
    AsyncRetrieveByNameModelMixin,
    mixins.AsyncStreamModelMixin,
):
    queryset = ScientificConstant.objects.all()
    serializer_class = ScientificConstantProtoSerializer
    filterset_class = ScientificConstantFilterSet


class CurrencyService(
    generics.AsyncModelService,
    AsyncRetrieveByNameModelMixin,
    mixins.AsyncStreamModelMixin,
):
    queryset = Currency.objects.all()
    serializer_class = CurrencyProtoSerializer
    filterset_class = CurrencyFilterSet


class GeoLocationService(
    generics.AsyncModelService,
    AsyncRetrieveByNameModelMixin,
    mixins.AsyncStreamModelMixin,
):
    queryset = GeoLocation.objects.all()
    serializer_class = GeoLocationProtoSerializer
    filterset_class = GeoLocationFilterSet


class CountryService(
    generics.AsyncModelService,
    AsyncRetrieveByNameModelMixin,
    mixins.AsyncStreamModelMixin,
):
    queryset = Country.objects.all()
    serializer_class = CountryProtoSerializer
    filterset_class = CountryFilterSet


class SubdivisionTypeService(
    generics.AsyncModelService,
    AsyncRetrieveByNameModelMixin,
    mixins.AsyncStreamModelMixin,
):
    queryset = SubdivisionType.objects.all()
    serializer_class = SubdivisionTypeProtoSerializer
    filterset_class = SubdivisionTypeFilterSet


class CountrySubdivisionService(
    generics.AsyncModelService,
    AsyncRetrieveByNameModelMixin,
    mixins.AsyncStreamModelMixin,
):
    queryset = CountrySubdivision.objects.all()
    serializer_class = CountrySubdivisionProtoSerializer
    filterset_class = CountrySubdivisionFilterSet


class CityService(
    generics.AsyncModelService,
    AsyncRetrieveByNameModelMixin,
    mixins.AsyncStreamModelMixin,
):
    queryset = City.objects.all()
    serializer_class = CityProtoSerializer
    filterset_class = CityFilterSet


class AddressService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Address.objects.all()
    serializer_class = AddressProtoSerializer
    filterset_class = AddressFilterSet


class RoomCategoryService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = RoomCategory.objects.all()
    serializer_class = RoomCategoryProtoSerializer
    filterset_class = RoomCategoryFilterSet


class RoomService(
    generics.AsyncModelService,
    AsyncRetrieveByNameModelMixin,
    mixins.AsyncStreamModelMixin,
):
    queryset = Room.objects.all()
    serializer_class = RoomProtoSerializer
    filterset_class = RoomFilterSet


class LocationService(
    generics.AsyncModelService,
    AsyncRetrieveByNameModelMixin,
    mixins.AsyncStreamModelMixin,
):
    queryset = Location.objects.all()
    serializer_class = LocationProtoSerializer
    filterset_class = LocationFilterSet


class LARASyncServerService(
    generics.AsyncModelService,
    AsyncRetrieveByNameModelMixin,
    mixins.AsyncStreamModelMixin,
):
    queryset = LARASyncServer.objects.all()
    serializer_class = LARASyncServerProtoSerializer
    filterset_class = LARASyncServerFilterSet
