"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_base admin *

:details: lara_django_base admin module admin backend configuration.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev admin_generator lara_django_base >> admin.py" to update this file
________________________________________________________________________
"""

# -*- coding: utf-8 -*-
from django.contrib import admin

from .models import Address
from .models import City
from .models import Country
from .models import CountrySubdivision
from .models import Currency
from .models import DataType
from .models import ExternalResource
from .models import ExtraData
from .models import GeoLocation
from .models import ItemRole
from .models import ItemStatus
from .models import LARASyncServer
from .models import Location
from .models import MediaType
from .models import Namespace
from .models import PhysicalStateMatter
from .models import PhysicalUnit
from .models import Room
from .models import RoomCategory
from .models import ScientificConstant
from .models import SubdivisionType
from .models import Tag


@admin.register(DataType)
class DataTypeAdmin(admin.ModelAdmin):
    list_display = ("datatype_id", "name", "description")


@admin.register(MediaType)
class MediaTypeAdmin(admin.ModelAdmin):
    list_display = (
        "mediatype_id",
        "name",
        "media_type",
        "def_filename_extension_regex",
        "description",
    )
    search_fields = ("name",)


@admin.register(Namespace)
class NamespaceAdmin(admin.ModelAdmin):
    list_display = (
        "uri",
        "description",
        "namespace_id",
    )
    search_fields = ("uri",)


@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
    list_display = ("tag", "iri", "tag_id")


@admin.register(ItemRole)
class ItemRoleAdmin(admin.ModelAdmin):
    list_display = ("itemrole_id", "role", )
    search_fields = ("role",)

@admin.register(ItemStatus)
class ItemStatusAdmin(admin.ModelAdmin):
    list_display = ("itemstatus_id", "status", "value", "color", )


@admin.register(ExtraData)
class ExtraDataAdmin(admin.ModelAdmin):
    list_display = (
        "name_full",
        "name",
        "namespace",
        "data_type",
        "iri",
        "data_json",
        "media_type",
        "description",
        "extradata_id",
        "file",
    )
    list_filter = ("name", "namespace", "media_type")


@admin.register(ExternalResource)
class ExternalResourceAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "url",
        "iri",
        "externalresource_id",
    )
    list_filter = ("name", "tags", "url", "iri")
    # raw_id_fields = ()


@admin.register(PhysicalStateMatter)
class PhysicalStateMatterAdmin(admin.ModelAdmin):
    list_display = ("physicalstatematter_id", "name", "description")
    search_fields = ("name",)


@admin.register(PhysicalUnit)
class PhysicalUnitAdmin(admin.ModelAdmin):
    list_display = ("physicalunit_id", "name", "dimension", "description")
    search_fields = ("name",)


@admin.register(ScientificConstant)
class ScientificConstantAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "value",
        "unit",
        "data_json",
        "iri",
        "url_source",
        "url_definition",
        "description",
        "scientificconstant_id",
    )
    list_filter = ("unit",)
    search_fields = ("name",)


@admin.register(Currency)
class CurrencyAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "iri",
        "alpha3code",
        "numeric_code",
        "symbol",
        "exchange_rate_eur",
        "currency_id",
    )
    search_fields = ("name",)


@admin.register(GeoLocation)
class GeoLocationAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "coordinates_dd_lat",
        "coordinates_dd_long",
        "elevation",
        "openstreetmap",
        "googlemap",
        "geolocation_id",
    )
    raw_id_fields = ("data_extra",)
    search_fields = ("name",)


@admin.register(Country)
class CountryAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "name_local",
        "alpha2code",
        "alpha3code",
        "numeric_code",
        "phone_code",
        "icon",
        "currency",
        "country_id",
    )
    raw_id_fields = ("currency",)
    search_fields = ("name",)


@admin.register(SubdivisionType)
class SubdivisionTypeAdmin(admin.ModelAdmin):
    list_display = ("subdivisiontype_id", "name", "description")
    search_fields = ("name",)


@admin.register(CountrySubdivision)
class CountrySubdivisionAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "name_local",
        "code",
        "alpha2code",
        "subdivision_type",
        "country",
        "timezone",
        "countrysubdivision_id",
    )
    raw_id_fields = ("subdivision_type", "country")
    search_fields = ("name",)


@admin.register(City)
class CityAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "name_local",
        "country",
        "subdivision",
        "timezone",
        "city_id",
    )
    list_filter = ("country", "subdivision")
    search_fields = ("name",)


@admin.register(Address)
class AddressAdmin(admin.ModelAdmin):
    list_display = (
        "address_id",
        "building",
        "street",
        "house_number",
        "supplement",
        "city",
        "subdivision",
        "country",
        "postal_code",
        "geolocation",
    )
    list_filter = ("city", "subdivision", "country", "geolocation")
    raw_id_fields = ("data_extra",)


@admin.register(RoomCategory)
class RoomCategoryAdmin(admin.ModelAdmin):
    list_display = ("roomcategory_id", "category", "description")


@admin.register(Room)
class RoomAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "category",
        "number",
        "floor",
        "phone_number",
        "room_map",
        "max_people",
        "area",
        "volume",
        "room_id",
    )
    list_filter = ("category",)
    search_fields = ("name",)


@admin.register(Location)
class LocationAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "barcode",
        "geolocation",
        "address",
        # "building",
        # "floor",
        # "room",
        # "cabinet",
        # "shelf",
        # "drawer",
        # "box",
        # "position",
        "iri",
        "url",
        "description",
        "location_id",
    )
    list_filter = ("geolocation", "address")
    raw_id_fields = ("data_extra",)
    search_fields = ("name",)


@admin.register(LARASyncServer)
class LARASyncServerAdmin(admin.ModelAdmin):
    list_display = (
        "url",
        "port",
        "description",
        "laraserver_id",
    )
    list_filter = ("description", "url")
    search_fields = ("url", "tags")
