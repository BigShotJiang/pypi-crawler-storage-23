
from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.postgres.search import SearchVector
from lara_django_base.decorators import postgres_only

from .models.models import (
    ExtraData,
    ExternalResource,
    ScientificConstant,
    City,
    Address,
    Room,
    Location,
)


@receiver(post_save, sender=ExtraData)
@postgres_only
def update_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector("name", weight="A")
            + SearchVector("name_display", weight="B")
            + SearchVector("description", weight="C")
        )
    )


@receiver(post_save, sender=ExternalResource)
@postgres_only
def update_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector("name", weight="A") + SearchVector("description", weight="B")
        )
    )


@receiver(post_save, sender=ScientificConstant)
@postgres_only
def update_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector("name", weight="A") + SearchVector("description", weight="B")
        )
    )


@receiver(post_save, sender=City)
@postgres_only
def update_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector("name", weight="A")
            + SearchVector("name_local", weight="B")
            + SearchVector("description", weight="C")
        )
    )


@receiver(post_save, sender=Address)
@postgres_only
def update_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector("name", weight="A") + 
            SearchVector("street", weight="B") +
            SearchVector("description", weight="C")
        )
    )

@receiver(post_save, sender=Room)
@postgres_only
def update_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector("name", weight="A") + SearchVector("description", weight="B")
        )
    )

@receiver(post_save, sender=Location)
@postgres_only
def update_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector("name", weight="A") + SearchVector("description", weight="B")
        )
    )
from django.dispatch import receiver
from django.db.models.signals import post_save
from lara_django_base.decorators import postgres_only

from .semantics import insert_semantic_data

logger = logging.getLogger('lara_signals')


# @receiver(post_save, sender=Evaluation)
# def semantics_data_handler(sender, instance, created, **kwargs):
#     """Semantic data post_save signal handler.

#        This function is triggered after an instance of the Evaluation model is saved.
#        It calls the insert_semantics function to handle the semantic data insertion
#        into the triplestore, running asynchronously as celery task.
#     """
#     logger.debug("post_save_handler1: %s, %s ", sender, instance)

#     insert_semantic_data(sender, instance, **kwargs)


# @receiver(post_save, sender=Evaluation)
# @postgres_only
# def update_search_vector(sender, instance, **kwargs):
#     sender.objects.filter(pk=instance.pk).update(
#         search_vector=(
#             SearchVector('name', weight='A') +
#             SearchVector('name_display', weight='B') +
#             SearchVector('description', weight='C') +
#             SearchVector('caption', weight='D')
#         )
#     )