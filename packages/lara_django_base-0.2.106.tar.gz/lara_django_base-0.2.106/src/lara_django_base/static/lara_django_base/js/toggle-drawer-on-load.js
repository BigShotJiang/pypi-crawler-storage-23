(() => {
  function toggleDrawerOnLoad() {
    const el = document.getElementById('drawer-toggle');
    if (!el) return;
    // Toggle state
    el.checked = !el.checked;
    // Notify any listeners
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', toggleDrawerOnLoad, { once: true });
  } else {
    toggleDrawerOnLoad();
  }
})();