"""Setup script for jaclang."""

from setuptools import setup

setup()
