:mod:`cosmicshear` --- Utility functions for cosmic shear
=========================================================

.. toctree::
   :maxdepth: 1

   ellipticity
