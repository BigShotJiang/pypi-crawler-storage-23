# `cosmicshear`

[![Test](https://github.com/ntessore/cosmicshear/actions/workflows/test.yml/badge.svg)](https://github.com/ntessore/cosmicshear/actions/workflows/test.yml)
[![Docs](https://app.readthedocs.org/projects/cosmicshear/badge/?version=latest)](https://cosmicshear.readthedocs.io)

Utility functions for cosmic shear in astronomy.

