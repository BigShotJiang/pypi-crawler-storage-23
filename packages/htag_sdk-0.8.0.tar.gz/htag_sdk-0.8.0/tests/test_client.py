"""Tests for the sync client constructor and configuration."""

from __future__ import annotations

import pytest

from htag_sdk import HtAgApi, AsyncHtAgApi


class TestHtAgApiInit:
    def test_requires_api_key(self):
        with pytest.raises(ValueError, match="api_key"):
            HtAgApi(api_key="", environment="prod")

    def test_requires_environment_or_base_url(self):
        with pytest.raises(ValueError, match="environment.*base_url"):
            HtAgApi(api_key="sk-test")

    def test_rejects_unknown_environment(self):
        with pytest.raises(ValueError, match="Unknown environment"):
            HtAgApi(api_key="sk-test", environment="staging")

    def test_creates_sub_clients(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        assert client.address is not None
        assert client.property is not None
        assert client.markets is not None
        assert client.markets.trends is not None
        client.close()

    def test_prod_base_url(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        assert "api.prod.htagai.com" in client._base_url
        assert "/v1" in client._base_url
        client.close()

    def test_dev_base_url(self):
        client = HtAgApi(api_key="sk-test", environment="dev")
        assert "api.dev.htagai.com" in client._base_url
        client.close()

    def test_custom_base_url(self):
        client = HtAgApi(api_key="sk-test", base_url="https://custom.api.com")
        assert client._base_url == "https://custom.api.com"
        client.close()

    def test_custom_base_url_strips_trailing_slash(self):
        client = HtAgApi(api_key="sk-test", base_url="https://custom.api.com/")
        assert not client._base_url.endswith("/")
        client.close()

    def test_context_manager(self):
        with HtAgApi(api_key="sk-test", environment="prod") as client:
            assert client.address is not None

    def test_repr(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        assert "HtAgApi" in repr(client)
        assert "api.prod.htagai.com" in repr(client)
        client.close()

    def test_default_headers_contain_api_key(self):
        client = HtAgApi(api_key="sk-my-key", environment="prod")
        headers = client._default_headers
        assert headers["x-api-key"] == "sk-my-key"
        assert "User-Agent" in headers
        client.close()


class TestAsyncHtAgApiInit:
    def test_requires_api_key(self):
        with pytest.raises(ValueError, match="api_key"):
            AsyncHtAgApi(api_key="", environment="prod")

    def test_creates_sub_clients(self):
        client = AsyncHtAgApi(api_key="sk-test", environment="prod")
        assert client.address is not None
        assert client.property is not None
        assert client.markets is not None
        client.close()
