"""Tests for the exception hierarchy."""

from __future__ import annotations

from htag_sdk import (
    HtAgError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
    ServerError,
    ConnectionError,
    NotFoundError,
)


class TestHtAgError:
    def test_stores_message(self):
        err = HtAgError("something failed")
        assert err.message == "something failed"
        assert str(err) == "something failed"

    def test_stores_optional_fields(self):
        err = HtAgError("fail", status_code=500, body={"detail": "oops"}, request_id="req-123")
        assert err.status_code == 500
        assert err.body == {"detail": "oops"}
        assert err.request_id == "req-123"

    def test_is_exception(self):
        err = HtAgError("test")
        assert isinstance(err, Exception)

    def test_repr(self):
        err = HtAgError("test", status_code=500)
        r = repr(err)
        assert "HtAgError" in r
        assert "500" in r


class TestAuthenticationError:
    def test_is_htag_error(self):
        err = AuthenticationError("auth failed", status_code=401)
        assert isinstance(err, HtAgError)
        assert err.status_code == 401


class TestRateLimitError:
    def test_stores_retry_after(self):
        err = RateLimitError("rate limited", retry_after=5.0)
        assert isinstance(err, HtAgError)
        assert err.status_code == 429
        assert err.retry_after == 5.0

    def test_retry_after_defaults_to_none(self):
        err = RateLimitError("rate limited")
        assert err.retry_after is None


class TestValidationError:
    def test_is_htag_error(self):
        err = ValidationError("bad request", status_code=422, body={"detail": "q required"})
        assert isinstance(err, HtAgError)
        assert err.status_code == 422
        assert err.body == {"detail": "q required"}


class TestNotFoundError:
    def test_is_htag_error(self):
        err = NotFoundError("not found", status_code=404)
        assert isinstance(err, HtAgError)


class TestServerError:
    def test_is_htag_error(self):
        err = ServerError("server error", status_code=502)
        assert isinstance(err, HtAgError)


class TestConnectionError:
    def test_is_htag_error(self):
        err = ConnectionError("connection refused", status_code=None)
        assert isinstance(err, HtAgError)
        assert err.status_code is None
