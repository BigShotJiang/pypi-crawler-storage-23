"""Tests for Pydantic models."""

from __future__ import annotations

from htag_sdk import (
    AddressRecord,
    AddressSearchResult,
    AddressSearchResponse,
    SoldPropertyRecord,
    SoldPropertiesResponse,
    MarketSnapshot,
    PriceHistoryOut,
    BaseResponse,
)


class TestAddressModels:
    def test_address_record_optional_fields(self):
        record = AddressRecord()
        assert record.address_label is None
        assert record.flood is None
        assert record.lat is None

    def test_address_record_with_data(self):
        record = AddressRecord(
            address_label="100 George St Sydney",
            flood=False,
            bushfire=True,
            lat=-33.8688,
            lon=151.2093,
        )
        assert record.address_label == "100 George St Sydney"
        assert record.flood is False
        assert record.bushfire is True

    def test_address_search_result_has_score(self):
        result = AddressSearchResult(score=0.95, address_label="Test")
        assert result.score == 0.95
        assert result.address_label == "Test"

    def test_address_search_response(self):
        response = AddressSearchResponse(
            results=[AddressSearchResult(score=0.9, address_label="A")],
            total=1,
        )
        assert len(response.results) == 1
        assert response.results[0].score == 0.9


class TestPropertyModels:
    def test_sold_property_record(self):
        record = SoldPropertyRecord(
            street_address="100 George St",
            suburb="Sydney",
            sold_price=1500000,
            sold_date="2024-06-15",
            bedrooms=3,
        )
        assert record.sold_price == 1500000
        assert record.bedrooms == 3

    def test_sold_properties_response(self):
        response = SoldPropertiesResponse(
            results=[SoldPropertyRecord(street_address="Test")],
            total=1,
        )
        assert response.total == 1


class TestMarketModels:
    def test_market_snapshot_optional_fields(self):
        snap = MarketSnapshot()
        assert snap.typical_price is None
        assert snap.suburb is None

    def test_market_snapshot_with_data(self):
        snap = MarketSnapshot(
            suburb="Sydney",
            typical_price=1500000,
            one_y_price_growth=0.05,
            rent=800,
        )
        assert snap.suburb == "Sydney"
        assert snap.typical_price == 1500000

    def test_price_history_out(self):
        record = PriceHistoryOut(
            area_id="SAL10001",
            period_end="2024-06-30",
            property_type="house",
            typical_price=1200000,
            sales=45,
        )
        assert record.typical_price == 1200000
        assert record.sales == 45

    def test_base_response_generic(self):
        response = BaseResponse[PriceHistoryOut](
            results=[
                PriceHistoryOut(
                    area_id="SAL10001",
                    period_end="2024-06-30",
                    property_type="house",
                )
            ],
            total=1,
            limit=100,
            offset=0,
        )
        assert len(response.results) == 1
        assert response.total == 1
