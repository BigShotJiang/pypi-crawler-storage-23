"""Pydantic models for the Address API domain."""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict


class AddressRecord(BaseModel):
    """A single address record with full GNAF and enrichment data."""

    model_config = ConfigDict(populate_by_name=True)

    address_key: Optional[str] = None
    gnaf_property_pid: Optional[str] = None
    legal_parcel_id: Optional[str] = None
    mb_category: Optional[str] = None
    suburb_loc_pid: Optional[str] = None
    suburb_slug: Optional[str] = None
    lat: Optional[float] = None
    lon: Optional[float] = None
    flood: Optional[bool] = None
    bushfire: Optional[bool] = None
    heritage: Optional[bool] = None
    zoning: Optional[str] = None
    IRSD: Optional[int] = None
    IRSAD: Optional[int] = None
    IER: Optional[int] = None
    IEO: Optional[int] = None
    public_housing: Optional[float] = None
    private_rentals: Optional[float] = None
    address_label: Optional[str] = None
    address_site_name: Optional[str] = None
    building_name: Optional[str] = None
    flat_type: Optional[str] = None
    flat_number: Optional[str] = None
    level_type: Optional[str] = None
    level_number: Optional[str] = None
    number_first: Optional[str] = None
    number_last: Optional[str] = None
    lot_number: Optional[str] = None
    street_name: Optional[str] = None
    street_type: Optional[str] = None
    street_suffix: Optional[str] = None
    locality_name: Optional[str] = None
    state: Optional[str] = None
    postcode: Optional[str] = None


class AddressSearchResult(AddressRecord):
    """An address search result with a relevance score."""

    score: Optional[float] = None


class AddressSearchResponse(BaseModel):
    """Response from the address search endpoint."""

    model_config = ConfigDict(populate_by_name=True)

    total: int
    results: List[AddressSearchResult]


class AddressInsightsResponse(BaseModel):
    """Response from the address insights endpoint."""

    model_config = ConfigDict(populate_by_name=True)

    total: int
    results: List[AddressRecord]


class AustralianAddressComponents(BaseModel):
    """Standardised Australian address components."""

    model_config = ConfigDict(populate_by_name=True)

    building_name: Optional[str] = None
    flat_type: Optional[str] = None
    flat_number: Optional[str] = None
    level_type: Optional[str] = None
    level_number: Optional[str] = None
    number_first: Optional[str] = None
    number_last: Optional[str] = None
    lot_number: Optional[str] = None
    street_name: Optional[str] = None
    street_type: Optional[str] = None
    street_suffix: Optional[str] = None
    locality_name: Optional[str] = None
    state: Optional[str] = None
    postcode: Optional[str] = None


class StandardiseResult(BaseModel):
    """Result for a single address in a batch standardisation request."""

    model_config = ConfigDict(populate_by_name=True)

    input_address: str
    address_key: Optional[str] = None
    standardised_address: Optional[AustralianAddressComponents] = None
    error: Optional[str] = None


class BatchStandardiseResponse(BaseModel):
    """Response from the address standardise endpoint."""

    model_config = ConfigDict(populate_by_name=True)

    results: List[StandardiseResult]
