"""Property API domain — sold property search and data."""

from htag_sdk.property.async_client import AsyncPropertyClient
from htag_sdk.property.client import PropertyClient
from htag_sdk.property.models import (
    SoldPropertiesResponse,
    SoldPropertyRecord,
)

__all__ = [
    "AsyncPropertyClient",
    "PropertyClient",
    "SoldPropertiesResponse",
    "SoldPropertyRecord",
]
