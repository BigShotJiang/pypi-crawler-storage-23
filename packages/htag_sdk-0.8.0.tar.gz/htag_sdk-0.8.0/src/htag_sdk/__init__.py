"""HtAG AI Python SDK.

The official Python client for the HtAG AI API, providing access to
Australian address data, property sales records, and market analytics.

Quick start::

    from htag_sdk import HtAgApi

    client = HtAgApi(api_key="sk-...", environment="prod")
    results = client.address.search("100 George St Sydney")

For async usage::

    from htag_sdk import AsyncHtAgApi

    async_client = AsyncHtAgApi(api_key="sk-...", environment="prod")
    results = await async_client.address.search("100 George St Sydney")
"""

from htag_sdk._async_client import AsyncHtAgApi
from htag_sdk._client import HtAgApi
from htag_sdk._exceptions import (
    AuthenticationError,
    ConnectionError,
    HtAgError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)

# Domain models -- address
from htag_sdk.address.models import (
    AddressInsightsResponse,
    AddressRecord,
    AddressSearchResponse,
    AddressSearchResult,
    AustralianAddressComponents,
    BatchStandardiseResponse,
    StandardiseResult,
)

# Domain models -- property
from htag_sdk.property.models import (
    SoldPropertiesResponse,
    SoldPropertyRecord,
)

# Domain models -- intent hub
from htag_sdk.intent_hub.models import (
    ClassifiedEvent,
    EventCategory,
    EventType,
    Integration,
    IntegrationStatus,
    IntegrationType,
    PaginatedEvents,
    Sentiment,
    SourceType,
    Subscription,
    TagInfo,
    Urgency,
)

# Domain models -- markets
from htag_sdk.markets.models import (
    AdvancedSearchBody,
    BaseResponse,
    DemandProfileOut,
    EssentialsOut,
    FSDMonthlyOut,
    FSDQuarterlyOut,
    FSDYearlyOut,
    GRCOut,
    LevelEnum,
    MarketSnapshot,
    PriceHistoryOut,
    PropertyTypeEnum,
    RentHistoryOut,
    YieldHistoryOut,
)

__version__ = "0.4.1"

__all__ = [
    # Clients
    "HtAgApi",
    "AsyncHtAgApi",
    # Exceptions
    "HtAgError",
    "AuthenticationError",
    "ConnectionError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "ValidationError",
    # Address models
    "AddressInsightsResponse",
    "AddressRecord",
    "AddressSearchResponse",
    "AddressSearchResult",
    "AustralianAddressComponents",
    "BatchStandardiseResponse",
    "StandardiseResult",
    # Property models
    "SoldPropertiesResponse",
    "SoldPropertyRecord",
    # Intent Hub models
    "ClassifiedEvent",
    "EventCategory",
    "EventType",
    "Integration",
    "IntegrationStatus",
    "IntegrationType",
    "PaginatedEvents",
    "Sentiment",
    "SourceType",
    "Subscription",
    "TagInfo",
    "Urgency",
    # Markets models
    "AdvancedSearchBody",
    "BaseResponse",
    "DemandProfileOut",
    "EssentialsOut",
    "FSDMonthlyOut",
    "FSDQuarterlyOut",
    "FSDYearlyOut",
    "GRCOut",
    "LevelEnum",
    "MarketSnapshot",
    "PriceHistoryOut",
    "PropertyTypeEnum",
    "RentHistoryOut",
    "YieldHistoryOut",
]
