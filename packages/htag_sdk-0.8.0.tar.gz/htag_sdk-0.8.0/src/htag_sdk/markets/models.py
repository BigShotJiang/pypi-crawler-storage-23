"""Pydantic models for the Markets API domain."""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, Generic, List, Optional, TypeVar

from pydantic import BaseModel, ConfigDict


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class LevelEnum(str, Enum):
    """Geographic level for market data queries."""

    lga = "lga"
    suburb = "suburb"


class PropertyTypeEnum(str, Enum):
    """Property type classification."""

    house = "house"
    unit = "unit"
    townhouse = "townhouse"
    other = "other"


# ---------------------------------------------------------------------------
# Generic paginated response
# ---------------------------------------------------------------------------

T = TypeVar("T")


class BaseResponse(BaseModel, Generic[T]):
    """Generic paginated API response wrapper.

    All markets endpoints return data in this shape.
    """

    model_config = ConfigDict(populate_by_name=True)

    total: int
    limit: int
    offset: int
    results: List[T]


# ---------------------------------------------------------------------------
# Market snapshots
# ---------------------------------------------------------------------------


class MarketSnapshot(BaseModel):
    """Comprehensive market snapshot for a geographic area.

    Contains approximately 80 metrics covering price, rent, supply/demand,
    growth rates, risk scores, and long-term/short-term indicators.
    """

    model_config = ConfigDict(populate_by_name=True)

    area_id: Optional[str] = None
    composite_key: Optional[str] = None
    state_name: Optional[str] = None
    region_reference: Optional[str] = None
    suburb: Optional[str] = None
    postcode: Optional[str] = None
    council_area_reference: Optional[str] = None
    council_area: Optional[str] = None
    period_end: Optional[str] = None
    property_type: Optional[str] = None
    bedrooms: Optional[str] = None

    # Price and sales
    typical_price: Optional[float] = None
    sales: Optional[int] = None
    annual_sales_volume: Optional[int] = None
    sales_ratio: Optional[float] = None
    clearance_rate: Optional[float] = None
    dom: Optional[int] = None
    discounting: Optional[float] = None
    years_to_own: Optional[float] = None
    som_percent: Optional[float] = None
    inventory: Optional[float] = None
    hold_period: Optional[float] = None

    # Rent and yield
    rent: Optional[float] = None
    rentals: Optional[int] = None
    annual_rental_volume: Optional[int] = None
    rentals_ratio: Optional[float] = None
    vacancy_rate: Optional[float] = None
    yield_val: Optional[float] = None

    # Price growth
    one_y_price_growth: Optional[float] = None
    three_y_price_growth: Optional[float] = None
    five_y_price_growth: Optional[float] = None
    ten_y_price_growth: Optional[float] = None

    # Rent growth
    one_m_rent_growth: Optional[float] = None
    one_q_rent_growth: Optional[float] = None
    six_m_rent_growth: Optional[float] = None
    one_y_rent_growth: Optional[float] = None
    three_y_rent_growth: Optional[float] = None
    five_y_rent_growth: Optional[float] = None
    ten_y_rent_growth: Optional[float] = None

    # Yield growth
    yield_1y_growth: Optional[float] = None
    yield_3y_growth: Optional[float] = None
    yield_5y_growth: Optional[float] = None
    yield_10y_growth: Optional[float] = None

    # Projections
    projected_annual_capital_growth_low: Optional[float] = None
    projected_annual_capital_growth_high: Optional[float] = None
    projected_annual_rent_increase: Optional[float] = None
    projected_annual_roi_low: Optional[float] = None
    projected_annual_roi_high: Optional[float] = None

    # Demographics and area stats
    estimated_dwellings: Optional[int] = None
    adult_population: Optional[int] = None
    irsad: Optional[int] = None
    building_approvals_estimated: Optional[int] = None
    ba_ratio: Optional[float] = None
    school_rank: Optional[float] = None
    non_res_ba_per_capita_value: Optional[float] = None

    # Confidence and risk
    confidence: Optional[str] = None
    volatility_index: Optional[float] = None
    growth_rate_cycle: Optional[str] = None

    # Ratios
    ro_ratio: Optional[float] = None
    uh_ratio: Optional[float] = None
    uhv_ratio: Optional[float] = None

    # Search indices
    buy_si: Optional[float] = None
    rent_si: Optional[float] = None

    # Scores
    rcs_lower_risk: Optional[float] = None
    rcs_cashflow: Optional[float] = None
    rcs_capital_growth: Optional[float] = None
    rcs_overall: Optional[float] = None
    hapi_score: Optional[float] = None

    # Geographic and environmental
    gpo_dist: Optional[float] = None
    ediv_ind: Optional[float] = None
    hrp_flood: Optional[float] = None
    hrp_fire: Optional[float] = None
    madi: Optional[float] = None

    # Growth projections
    gpd_3: Optional[float] = None
    gpd_5: Optional[float] = None
    gpd_10: Optional[float] = None
    gsp_3: Optional[float] = None
    gsp_5: Optional[float] = None
    gsp_10: Optional[float] = None

    # GRC
    min_grc: Optional[float] = None
    grc_price_index: Optional[float] = None

    # Long-term indicators
    lt_som_perc: Optional[float] = None
    lt_inventory: Optional[float] = None
    lt_dom: Optional[float] = None
    lt_vacancy_rate: Optional[float] = None
    lt_clearance_rate: Optional[float] = None
    lt_hold_period: Optional[float] = None
    lt_buy_si: Optional[float] = None
    lt_rent_si: Optional[float] = None

    # Short-term indicators
    st_som_perc: Optional[float] = None
    st_inventory: Optional[float] = None
    st_dom: Optional[float] = None
    st_vacancy_rate: Optional[float] = None
    st_clearance_rate: Optional[float] = None
    st_hold_period: Optional[float] = None
    st_buy_si: Optional[float] = None
    st_rent_si: Optional[float] = None

    # Link
    area_link: Optional[str] = None


# ---------------------------------------------------------------------------
# Advanced search body
# ---------------------------------------------------------------------------


class AdvancedSearchBody(BaseModel):
    """Request body for the advanced market query endpoint."""

    model_config = ConfigDict(populate_by_name=True)

    level: str
    mode: str
    property_types: List[str]
    area_ids: Optional[List[str]] = None
    typical_price_min: Optional[int] = None
    typical_price_max: Optional[int] = None
    logic: Optional[Dict[str, Any]] = None
    limit: Optional[int] = None
    offset: Optional[int] = None


# ---------------------------------------------------------------------------
# Trend models
# ---------------------------------------------------------------------------


class PriceHistoryOut(BaseModel):
    """Price trend data point."""

    model_config = ConfigDict(populate_by_name=True)

    area_id: Optional[str] = None
    period_end: Optional[str] = None
    property_type: Optional[str] = None
    typical_price: Optional[float] = None
    sales: Optional[int] = None
    typical_price_conf_low: Optional[float] = None
    typical_price_conf_high: Optional[float] = None


class RentHistoryOut(BaseModel):
    """Rent trend data point."""

    model_config = ConfigDict(populate_by_name=True)

    area_id: Optional[str] = None
    period_end: Optional[str] = None
    property_type: Optional[str] = None
    bedrooms: Optional[int] = None
    median_rent: Optional[float] = None
    rentals: Optional[int] = None
    confidence_low: Optional[float] = None
    confidence_high: Optional[float] = None


class YieldHistoryOut(BaseModel):
    """Yield trend data point."""

    model_config = ConfigDict(populate_by_name=True)

    area_id: Optional[str] = None
    period_end: Optional[str] = None
    property_type: Optional[str] = None
    bedrooms: Optional[int] = None
    yield_val: Optional[float] = None


class FSDMonthlyOut(BaseModel):
    """Supply and demand (monthly frequency) data point."""

    model_config = ConfigDict(populate_by_name=True)

    area_id: Optional[str] = None
    period_end: Optional[str] = None
    property_type: Optional[str] = None
    inventory: Optional[float] = None
    vacancies: Optional[float] = None
    clearance_rate: Optional[float] = None


class FSDQuarterlyOut(BaseModel):
    """Search index (quarterly frequency) data point."""

    model_config = ConfigDict(populate_by_name=True)

    area_id: Optional[str] = None
    period_end: Optional[str] = None
    property_type: Optional[str] = None
    buy_si: Optional[float] = None
    rent_si: Optional[float] = None


class FSDYearlyOut(BaseModel):
    """Hold period (yearly frequency) data point."""

    model_config = ConfigDict(populate_by_name=True)

    area_id: Optional[str] = None
    period_end: Optional[str] = None
    property_type: Optional[str] = None
    hold_period: Optional[float] = None


class EssentialsOut(BaseModel):
    """Performance essentials data point."""

    model_config = ConfigDict(populate_by_name=True)

    area_id: Optional[str] = None
    period_end: Optional[str] = None
    property_type: Optional[str] = None
    typical_price: Optional[float] = None
    rent: Optional[float] = None
    sales: Optional[int] = None
    rentals: Optional[int] = None
    yield_val: Optional[float] = None


class GRCOut(BaseModel):
    """Growth rate cycle data point."""

    model_config = ConfigDict(populate_by_name=True)

    area_id: Optional[str] = None
    period_end: Optional[str] = None
    property_type: Optional[str] = None
    price_chg: Optional[float] = None
    rent_chg: Optional[float] = None
    yield_chg: Optional[float] = None


class DemandProfileOut(BaseModel):
    """Demand profile data point."""

    model_config = ConfigDict(populate_by_name=True)

    area_id: Optional[str] = None
    period_end: Optional[str] = None
    property_type: Optional[str] = None
    bedrooms: Optional[str] = None
    sales: Optional[int] = None
