"""ATK - Agent Toolkit.

Manage AI development tools through a git-backed, declarative manifest.
"""

from importlib.metadata import version

__version__ = version("atk-cli")

