#!/bin/bash
# Start script for Full Plugin
echo "[Full Plugin] Starting service..."
echo "[Full Plugin] Listening on port 8080..."
echo "[Full Plugin] Service started successfully!"

