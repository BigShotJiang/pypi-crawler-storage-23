"""Cursor Memory — persistent memory system for Cursor IDE."""

__version__ = "0.1.0"
