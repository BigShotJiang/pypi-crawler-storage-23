"""Managers for djpymissive."""

from .provider import ProviderManager
from .missive import MissiveManager
from .campaign import MissiveCampaignManager
from .event import MissiveEventManager
from .document import (
    MissiveDocumentManager,
    MissiveAttachmentManager,
    MissiveVirtualAttachmentManager,
)
from .related_object import MissiveRelatedObjectManager
from .recipient import (
    MissiveRecipientManager,
    MissiveRecipientEmailManager,
    MissiveRecipientPhoneManager,
    MissiveRecipientAddressManager,
    MissiveRecipientNotificationManager,
)

__all__ = [
    "ProviderManager",
    "MissiveManager",
    "MissiveCampaignManager",
    "MissiveEventManager",
    "MissiveDocumentManager",
    "MissiveAttachmentManager",
    "MissiveVirtualAttachmentManager",
    "MissiveRelatedObjectManager",
    "MissiveRecipientManager",
    "MissiveRecipientEmailManager",
    "MissiveRecipientPhoneManager",
    "MissiveRecipientAddressManager",
    "MissiveRecipientNotificationManager",
]
