"""Django forms for django-missive."""

from .webhook import WebhookForm

__all__ = ["WebhookForm"]
