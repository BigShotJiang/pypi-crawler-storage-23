"""Django Missive - Django library for missive management."""

__version__ = "0.1.1"
