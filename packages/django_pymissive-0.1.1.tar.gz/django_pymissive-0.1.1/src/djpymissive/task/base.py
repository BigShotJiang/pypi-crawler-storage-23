class BaseCampaignBackend:
    def delay(self, campaign_id: int):
        raise NotImplementedError
