"""Unit tests for the elastro module."""
