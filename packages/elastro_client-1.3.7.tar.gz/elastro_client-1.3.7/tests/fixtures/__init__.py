"""Test fixtures for the elastro module."""
