"""
Python module for configuration management in AltaSigma Modules.

This module defines job types, environment settings, and configuration classes
for various components of the system.
"""