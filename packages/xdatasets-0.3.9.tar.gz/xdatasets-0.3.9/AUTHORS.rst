=======
Credits
=======

Development Lead
----------------

* Sebastien Langlois <sebastien.langlois62@gmail.com> `@sebastienlanglois <https://github.com/sebastienlanglois>`_

Co-Developers
-------------

* Trevor James Smith <smith.trevorj@ouranos.ca> `@Zeitsperre <https://github.com/Zeitsperre>`_

Contributors
------------

* Juliette Lavoie <lavoie.juliette@ouranos.ca> `@juliettelavoie <https://github.com/juliettelavoie>`_
