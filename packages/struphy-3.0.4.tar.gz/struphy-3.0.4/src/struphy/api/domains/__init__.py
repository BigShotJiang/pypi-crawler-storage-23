from struphy.geometry import domains

__all__ = ["domains"]
