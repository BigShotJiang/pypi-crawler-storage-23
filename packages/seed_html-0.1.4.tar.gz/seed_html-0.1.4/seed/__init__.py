from __future__ import annotations

from pathlib import Path

from .parser import parse
from .renderer import Renderer
from .nodes import Page, Content, RawContent


class Seed:
    def __init__(
        self,
        templates_dir: Path | None = None,
        project_dir: Path | None = None,
        components_dir: Path | None = None,
        theme_dir: Path | None = None,
        components_lib_dir: Path | None = None,
    ):
        self.renderer = Renderer()
        self.templates_dir = templates_dir
        self.project_dir = project_dir
        self.theme_dir = theme_dir
        self.components_lib_dir = components_lib_dir
        from .components import reload_components_yaml
        effective_components_dir = components_dir or (project_dir / "src" / "components" if project_dir else None)
        if effective_components_dir or theme_dir or components_lib_dir:
            reload_components_yaml(
                components_dir=effective_components_dir,
                theme_dir=theme_dir,
                components_lib_dir=components_lib_dir,
            )

    def render_string(self, source: str, full_page: bool = False) -> str:
        page = parse(source)
        if full_page:
            return self.renderer.render_page(page)
        return self.renderer.render(page)

    def render_file(self, path: str | Path, full_page: bool = False, layout_path: str | None = None) -> str:
        path = Path(path)
        source = path.read_text(encoding="utf-8")
        page = parse(source)

        # Resolve layout: use specified layout_path param, or from front matter, or find default layout
        if layout_path is None:
            # Check if page has layout specified in front matter
            layout_path = page.meta.get("layout")

        if layout_path:
            # Resolve extension: prefer .layout, fall back to .seed
            if not layout_path.endswith((".layout", ".seed")):
                resolved = False
                for ext in (".layout", ".seed"):
                    candidate = path.parent / f"{layout_path}{ext}"
                    if candidate.is_file():
                        layout_path = str(candidate)
                        resolved = True
                        break
                if not resolved:
                    # Fallback: look in theme layouts/
                    if self.theme_dir:
                        candidate = self.theme_dir / "layouts" / f"{layout_path}.layout"
                        if candidate.is_file():
                            layout_path = str(candidate)
                        else:
                            layout_path = f"{layout_path}.layout"
                    else:
                        layout_path = f"{layout_path}.layout"
            # Resolve relative to file's directory if not already absolute
            if not Path(layout_path).is_absolute():
                layout_resolved = path.parent / layout_path
                if layout_resolved.is_file():
                    layout_path = str(layout_resolved)

        if layout_path is None:
            # Try to find default.layout going up the directory tree, stopping at src_dir
            src_dir = self.project_dir / "src" if self.project_dir else None
            layout_path = self._find_default_layout(path.parent, stop_at=src_dir)

        if layout_path:
            # Merge page content into layout
            page = self._apply_layout(page, layout_path, path.parent)

        theme_includes_dir = self.theme_dir / "includes" if self.theme_dir else None
        self.renderer.resolve_includes(page, path.parent, self.templates_dir, theme_includes_dir)

        if full_page:
            return self.renderer.render_page(page)
        return self.renderer.render(page)

    def _find_default_layout(self, start_dir: Path, stop_at: Path | None = None) -> str | None:
        """Search for default.layout (or legacy layout.seed) going up the directory tree.

        Args:
            start_dir: directory to start searching from.
            stop_at: stop walk-up at this directory (inclusive). Prevents capturing
                     layouts outside the project's src/ tree.
        """
        current = start_dir
        while True:
            for name in ("default.layout", "layout.seed"):
                candidate = current / name
                if candidate.is_file():
                    return str(candidate)
            if stop_at and current == stop_at:
                break
            parent = current.parent
            if parent == current:  # Reached filesystem root
                break
            current = parent
        # Fallback: theme default layout (only if theme is active)
        if self.theme_dir:
            candidate = self.theme_dir / "layouts" / "default.layout"
            if candidate.is_file():
                return str(candidate)
        return None

    def _apply_layout(self, page: Page, layout_path: str, base_dir: Path) -> Page:
        """Apply layout to page: render page content and inject into layout's {content} placeholder."""
        from .parser import parse
        from .nodes import Component

        # Read and parse layout file
        layout_file = Path(layout_path)
        layout_source = layout_file.read_text(encoding="utf-8")
        layout_page = parse(layout_source)

        theme_includes_dir = self.theme_dir / "includes" if self.theme_dir else None
        # Resolve includes in layout (using layout's directory)
        self.renderer.resolve_includes(layout_page, layout_file.parent, self.templates_dir, theme_includes_dir)

        # Resolve includes in page content before rendering
        self.renderer.resolve_includes(page, base_dir, self.templates_dir, theme_includes_dir)

        # Render page content
        page_content = self.renderer.render_children(page.children)

        # Merge meta: page meta overrides layout meta
        merged_meta = {**layout_page.meta, **page.meta}

        # Find and replace {content} placeholder recursively
        def replace_content_placeholder(children):
            new_children = []
            for child in children:
                if isinstance(child, Content) and "{content}" in child.text:
                    # Split content around placeholder and add page content
                    parts = child.text.split("{content}")
                    for i, part in enumerate(parts):
                        if part:
                            new_children.append(Content(text=part))
                        if i < len(parts) - 1:
                            # Add rendered page content as raw HTML (must not be escaped)
                            new_children.append(RawContent(html=page_content))
                elif isinstance(child, Component) and child.children:
                    # Recursively process children
                    child.children = replace_content_placeholder(child.children)
                    new_children.append(child)
                else:
                    new_children.append(child)
            return new_children

        layout_page.children = replace_content_placeholder(layout_page.children)

        return Page(meta=merged_meta, children=layout_page.children)

    def build(self, path: str | Path, output_dir: str | Path) -> Path:
        path = Path(path)
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        html = self.render_file(path, full_page=True)
        index = output_dir / "index.html"
        index.write_text(html, encoding="utf-8")

        return index

    def parse(self, source: str) -> Page:
        return parse(source)


__all__ = ["Seed"]
