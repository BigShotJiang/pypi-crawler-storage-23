from __future__ import annotations
import copy
from typing import TYPE_CHECKING, Callable, Any
import re
from pathlib import Path

import yaml

from .parser import parse
from .nodes import Content, Component as CompNode

if TYPE_CHECKING:
    from .nodes import Component

# Registry now stores configs: {"class": "...", "variants": {"name": "classes"}}
_registry: dict[str, dict[str, Any]] = {}

# Keys that are NOT modifier groups — they have special meaning in the config
_RESERVED_KEYS = frozenset({"tag", "class", "alias", "design"})

# Design cache: {component_name: {variant_name: Page}}
_design_cache: dict[str, dict[str, Any]] = {}

# Names of components that live inside a composite component's folder and
# can only be used as subitems of that parent. Populated by _load_component_folder.
_subitem_names: set[str] = set()

# Regex for finding slot placeholders like {title}, {children}, {image}
_SLOT_RE = re.compile(r"\{([\w-]+)\}")


def _merge_classes(base: str, extra: str) -> str:
    """Merge two class strings, removing duplicates while preserving order."""
    seen = set()
    result = []
    for cls in base.split() + extra.split():
        if cls and cls not in seen:
            seen.add(cls)
            result.append(cls)
    return " ".join(result)


def register(name: str, config: dict[str, Any], merge: bool = False):
    """Register a component. If merge=True and component exists:
    - tag: overrides
    - class: extends (appends without duplicates)
    - modifier groups (any non-reserved dict key): extends (adds new, overrides existing)
    """
    if merge and name in _registry:
        existing = _registry[name]
        merged = {**existing}
        if "tag" in config:
            merged["tag"] = config["tag"]
        if "class" in config:
            merged["class"] = _merge_classes(existing.get("class", ""), config["class"])
        # Merge modifier groups (any non-reserved dict key)
        for key, val in config.items():
            if key not in _RESERVED_KEYS and isinstance(val, dict):
                merged[key] = {**existing.get(key, {}), **val}
        _registry[name] = merged
    else:
        _registry[name] = config


def get_config(name: str) -> dict[str, Any] | None:
    """Get component config by name, resolving aliases transparently."""
    config = _registry.get(name)
    if isinstance(config, dict) and "alias" in config:
        target = config["alias"]
        resolved = _registry.get(target)
        if resolved is None:
            return config
        # Ensure the target's tag is explicit so the alias doesn't use its own name as tag
        base = {**resolved}
        if "tag" not in base:
            base["tag"] = target
        # Merge: target is base, alias overrides (except the 'alias' key itself)
        overrides = {k: v for k, v in config.items() if k != "alias"}
        return {**base, **overrides} if overrides else base
    return config


def is_registered(name: str) -> bool:
    """Check if a component is registered"""
    return name in _registry


def load_components():
    """Load component configs from YAML and registry"""
    # Load from YAML first
    load_components_from_yaml()


def load_components_from_yaml(path: Path | None = None):
    """Load component configs from YAML file(s).

    If path is a file, loads that file.
    If path is a directory, loads all .yaml files in that directory.
    If path is None, does nothing (no builtin components — use libs instead).
    """
    if path is None:
        return

    if path.is_file():
        _load_yaml_file(path)
    elif path.is_dir():
        _load_yaml_directory(path)


def _normalize_config(config: dict) -> dict:
    """Normalize config so all modifier group keys are strings."""
    result = {}
    for k, v in config.items():
        if isinstance(v, dict):
            result[k] = {str(gk): gv for gk, gv in v.items()}
        else:
            result[k] = v
    return result


def _load_yaml_file(path: Path):
    """Load component configs from a single YAML file"""
    with open(path, encoding="utf-8") as f:
        components = yaml.safe_load(f) or {}

    for name, config in components.items():
        config = _normalize_config(config)

        # Extract inline design before registering (so it doesn't end up in the registry)
        design_value = config.pop("design", None)

        register(name, config)

        # Load inline design if present
        if isinstance(design_value, str):
            _load_design_source(name, "default", design_value)
        elif isinstance(design_value, dict):
            for variant_name, variant_source in design_value.items():
                if isinstance(variant_source, str):
                    _load_design_source(name, str(variant_name), variant_source)


def _load_yaml_directory(directory: Path):
    """Load component configs from all .yaml files in a directory and discover component folders"""
    for yaml_file in sorted(directory.glob("*.yaml")):
        _load_yaml_file(yaml_file)

    # Discover component folders (subdirectories with .yaml files)
    for subfolder in sorted(directory.iterdir()):
        if subfolder.is_dir() and not subfolder.name.startswith("__"):
            _load_component_folder(subfolder)


def _load_component_folder(folder: Path):
    """Load a component folder: YAML config + .design files.

    The folder is named after the complex component it defines (e.g. accordion/).
    Any other .yaml files in the folder (e.g. item.yaml) are subitems that can
    only be used inside that parent; their names are added to _subitem_names.
    """
    parent_name = folder.name
    for yaml_file in sorted(folder.glob("*.yaml")):
        _load_yaml_file(yaml_file)
        if yaml_file.stem != parent_name:
            _subitem_names.add(yaml_file.stem)

    # Load .design files
    for design_file in sorted(folder.glob("*.design")):
        stem = design_file.stem
        if (folder / f"{stem}.yaml").exists():
            # Has its own .yaml → default design of that component
            component_name = stem
            variant_name = "default"
        else:
            # No own yaml → variant of the folder component (e.g. hero/center.design)
            component_name = folder.name
            variant_name = stem
            if variant_name == component_name:
                variant_name = "default"
        _load_design_file(component_name, variant_name, design_file)


def _load_design_file(component_name: str, variant_name: str, path: Path):
    """Parse a .design file and store in cache"""
    source = path.read_text(encoding="utf-8")
    _load_design_source(component_name, variant_name, source)


def _load_design_source(component_name: str, variant_name: str, source: str):
    """Parse a design source string and store in cache"""
    page = parse(source)
    if component_name not in _design_cache:
        _design_cache[component_name] = {}
    _design_cache[component_name][variant_name] = {"ast": page, "source": source}


def _extract_slots(page) -> list[str]:
    """Extract slot names from a design AST by finding {name} placeholders in Content nodes"""
    slots = []

    def walk(children):
        for child in children:
            if isinstance(child, Content):
                for match in _SLOT_RE.finditer(child.text):
                    name = match.group(1)
                    if name not in slots:
                        slots.append(name)
            elif isinstance(child, CompNode) and child.children:
                walk(child.children)

    walk(page.children)
    return slots


def _resolve_alias_name(name: str) -> str:
    """Resolve an alias name to its target. Returns the original name if not an alias."""
    config = _registry.get(name)
    if isinstance(config, dict) and "alias" in config:
        return config["alias"]
    return name


def has_design(name: str) -> bool:
    """Check if a component has a design template (resolves alias automatically)"""
    target = _resolve_alias_name(name)
    return target in _design_cache


def get_design(name: str, variant: str = "default"):
    """Get design AST for a component. Resolves alias and falls back to 'default' variant."""
    target = _resolve_alias_name(name)
    designs = _design_cache.get(target)
    if not designs:
        return None
    entry = designs.get(variant) or designs.get("default")
    if entry is None:
        return None
    return entry["ast"] if isinstance(entry, dict) else entry


def get_design_source(name: str, variant: str = "default") -> str:
    """Get raw .design source text for a component."""
    target = _resolve_alias_name(name)
    designs = _design_cache.get(target)
    if not designs:
        return ""
    entry = designs.get(variant) or designs.get("default")
    if entry is None:
        return ""
    return entry["source"] if isinstance(entry, dict) else ""


def get_design_slot_names(name: str, variant: str = "default") -> list[str]:
    """Get slot names from a design (resolves alias automatically)"""
    design = get_design(name, variant)
    if not design:
        return []
    return _extract_slots(design)


def load_project_components(project_dir: Path):
    """Load project-level component YAML files, merging with existing globals.

    Loads all .yaml files from the project directory.
    Also discovers component folders in the project directory.
    """
    if not project_dir.exists():
        return

    # Load all .yaml files from project directory
    for yaml_file in sorted(project_dir.glob("*.yaml")):
        with open(yaml_file, encoding="utf-8") as f:
            components = yaml.safe_load(f) or {}
        for name, config in components.items():
            config = _normalize_config(config)
            design_value = config.pop("design", None)
            register(name, config, merge=name in _registry)
            if isinstance(design_value, str):
                _load_design_source(name, "default", design_value)
            elif isinstance(design_value, dict):
                for variant_name, variant_source in design_value.items():
                    if isinstance(variant_source, str):
                        _load_design_source(name, str(variant_name), variant_source)

    # Discover component folders in project directory
    for subfolder in sorted(project_dir.iterdir()):
        if subfolder.is_dir() and not subfolder.name.startswith(("__", ".", "dist")):
            # Check if it's a component folder (has .yaml or .design files)
            has_yaml = any(subfolder.glob("*.yaml"))
            has_design_files = any(subfolder.glob("*.design"))
            if has_yaml or has_design_files:
                _load_component_folder(subfolder)


def reload_components_yaml(
    components_dir: Path | None = None,
    theme_dir: Path | None = None,
    components_lib_dir: Path | None = None,
):
    """Reload all components in priority order: lib → theme → project.

    Args:
        components_lib_dir: external component library (e.g. project/libs/components/seed-ui/).
        theme_dir: active theme root (e.g. project/libs/themes/seed-blog/).
        components_dir: project components directory (e.g. project/src/components/).
                        Always has highest priority.
    """
    _registry.clear()
    _design_cache.clear()
    _subitem_names.clear()
    if components_lib_dir:
        lib_components = components_lib_dir / "components"
        if lib_components.is_dir():
            load_project_components(lib_components)           # 1. external lib
    if theme_dir:
        theme_components = theme_dir / "components"
        if theme_components.exists():
            load_project_components(theme_components)         # 2. theme (merge)
    if components_dir and components_dir.exists():
        load_project_components(components_dir)              # 3. project (override)


def _get_class_prefix(cls: str) -> str:
    """Extract the deduplication key for a Tailwind class.

    Only classes that set the SAME CSS property should share a key.
    Classes with different keys always coexist.

    Modifiers (hover:, lg:, md:) are kept so responsive/state variants never conflict
    with their base class.
    """
    if not cls:
        return cls

    # Split off modifier prefix (hover:, lg:, md:text-lg, etc.)
    modifier = ""
    rest = cls
    if ":" in cls:
        modifier, rest = cls.split(":", 1)
        modifier = modifier + ":"

    # Arbitrary values [color:red] — treat as unique
    if rest.startswith("["):
        return cls

    parts = rest.split("-")

    # Single-segment classes are always unique (flex, grid, hidden, block, etc.)
    # They never conflict with multi-segment classes that share the same root,
    # because e.g. `flex` sets display while `flex-col` sets flex-direction.
    if len(parts) == 1:
        return modifier + rest

    root = parts[0]
    second = parts[1] if len(parts) > 1 else ""

    # --- flex ---
    # flex = display:flex (unique)
    # flex-col / flex-row / flex-col-reverse / flex-row-reverse → flex-direction
    # flex-wrap / flex-nowrap / flex-wrap-reverse → flex-wrap
    # flex-1 / flex-auto / flex-none / flex-<n> → flex shorthand
    # flex-grow / flex-shrink → flex-grow / flex-shrink (each unique)
    if root == "flex":
        if second in ("col", "row") or (second in ("col", "row") and len(parts) > 2 and parts[2] == "reverse"):
            return modifier + "flex-direction"
        if second in ("wrap", "nowrap") or (second == "wrap" and len(parts) > 2 and parts[2] == "reverse"):
            return modifier + "flex-wrap"
        if second == "grow":
            return modifier + "flex-grow"
        if second == "shrink":
            return modifier + "flex-shrink"
        # flex-1, flex-auto, flex-none, flex-<n> → flex shorthand
        return modifier + "flex-shorthand"

    # --- grid ---
    # grid = display:grid (unique, handled above as single-segment — but grid itself is 1 seg)
    # grid-cols-* → grid-template-columns
    # grid-rows-* → grid-template-rows
    # grid-flow-* → grid-auto-flow
    if root == "grid":
        if second == "cols":
            return modifier + "grid-template-columns"
        if second == "rows":
            return modifier + "grid-template-rows"
        if second == "flow":
            return modifier + "grid-auto-flow"
        return modifier + rest  # fallback: treat as unique

    # --- gap ---
    # gap-* → gap (all axes), gap-x-* → column-gap, gap-y-* → row-gap
    if root == "gap":
        if second == "x":
            return modifier + "column-gap"
        if second == "y":
            return modifier + "row-gap"
        return modifier + "gap"

    # --- space ---
    # space-x-* → margin-left (children), space-y-* → margin-top (children)
    if root == "space":
        if second == "x":
            return modifier + "space-x"
        if second == "y":
            return modifier + "space-y"
        return modifier + rest

    # --- overflow ---
    # overflow-* → overflow, overflow-x-* → overflow-x, overflow-y-* → overflow-y
    if root == "overflow":
        if second == "x":
            return modifier + "overflow-x"
        if second == "y":
            return modifier + "overflow-y"
        return modifier + "overflow"

    # --- border ---
    # border-* is extremely overloaded:
    # border / border-0 / border-2 … → border-width
    # border-t / border-r / border-b / border-l → border-side-width (each unique)
    # border-t-0 … border-t-8 → border-top-width
    # border-<color>-<shade> → border-color
    # border-solid / border-dashed / border-dotted … → border-style
    # border-collapse / border-separate → border-collapse (table)
    _BORDER_SIDES = frozenset({"t", "r", "b", "l", "x", "y", "s", "e"})
    _BORDER_STYLES = frozenset({"solid", "dashed", "dotted", "double", "hidden", "none"})
    _BORDER_COLLAPSE = frozenset({"collapse", "separate"})
    if root == "border":
        if second in _BORDER_SIDES:
            # border-t, border-t-2, border-t-red-500 etc.
            side = second
            if len(parts) == 2:
                # border-t alone → border-top-width
                return modifier + f"border-{side}-width"
            third = parts[2]
            # Check if third segment is a number (width) or color name
            if third.isdigit() or third == "0":
                return modifier + f"border-{side}-width"
            elif third in _BORDER_STYLES:
                return modifier + f"border-{side}-style"
            else:
                return modifier + f"border-{side}-color"
        if second in _BORDER_STYLES:
            return modifier + "border-style"
        if second in _BORDER_COLLAPSE:
            return modifier + "border-collapse"
        if second.isdigit() or second == "0":
            return modifier + "border-width"
        # border-<color>-<shade> or border-<color>
        return modifier + "border-color"

    # --- rounded ---
    # rounded / rounded-sm / rounded-lg → border-radius (all same property)
    # rounded-t / rounded-r … → border-radius corners (each axis unique)
    _ROUNDED_SIDES = frozenset({"t", "r", "b", "l", "tl", "tr", "bl", "br", "s", "e", "ss", "se", "es", "ee"})
    if root == "rounded":
        if second in _ROUNDED_SIDES:
            return modifier + f"rounded-{second}"
        return modifier + "rounded"

    # --- font ---
    # font-sans / font-serif / font-mono → font-family
    # font-thin / font-light / font-normal / font-bold … → font-weight
    _FONT_FAMILIES = frozenset({"sans", "serif", "mono"})
    _FONT_WEIGHTS = frozenset({"thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black"})
    if root == "font":
        if second in _FONT_FAMILIES:
            return modifier + "font-family"
        if second in _FONT_WEIGHTS:
            return modifier + "font-weight"
        return modifier + rest  # fallback unique

    # --- text ---
    # text-left / text-center / text-right / text-justify → text-align
    # text-xs / text-sm / text-base / text-lg / text-xl … → font-size
    # text-<color>-<shade> → color
    # text-white / text-black / text-current / text-transparent / text-inherit → color (2 parts but not size)
    _TEXT_ALIGNS = frozenset({"left", "center", "right", "justify", "start", "end"})
    _TEXT_SIZES = frozenset({"xs", "sm", "base", "lg", "xl", "2xl", "3xl", "4xl", "5xl", "6xl", "7xl", "8xl", "9xl"})
    if root == "text":
        if second in _TEXT_ALIGNS:
            return modifier + "text-align"
        if second.startswith("["):
            inner = second[1:].rstrip("]").lower()
            if inner.startswith(("#", "rgb", "hsl")) or inner in ("transparent", "current", "inherit"):
                return modifier + "text-color"
            return modifier + "text-size"
        if len(parts) == 2:
            if second in _TEXT_SIZES:
                return modifier + "text-size"
            return modifier + "text-color"
        return modifier + "text-color"

    # --- bg ---
    # bg-<color>-<shade> → background-color
    # bg-fixed / bg-local / bg-scroll → background-attachment
    # bg-clip-* → background-clip
    # bg-origin-* → background-origin
    # bg-repeat / bg-no-repeat / bg-repeat-x / bg-repeat-y → background-repeat
    # bg-auto / bg-cover / bg-contain → background-size
    # bg-center / bg-top / bg-bottom … → background-position
    # bg-none / bg-gradient-to-* → background-image
    _BG_ATTACHMENT = frozenset({"fixed", "local", "scroll"})
    _BG_REPEAT = frozenset({"repeat", "no", "repeat-x", "repeat-y", "round", "space"})
    _BG_SIZE = frozenset({"auto", "cover", "contain"})
    _BG_POSITION = frozenset({"center", "top", "bottom", "left", "right"})
    if root == "bg":
        if second in _BG_ATTACHMENT:
            return modifier + "bg-attachment"
        if second == "clip":
            return modifier + "bg-clip"
        if second == "origin":
            return modifier + "bg-origin"
        if second in _BG_REPEAT or (second == "no" and len(parts) > 2 and parts[2] == "repeat"):
            return modifier + "bg-repeat"
        if second in _BG_SIZE:
            return modifier + "bg-size"
        if second in _BG_POSITION or (second in ("left", "right") and len(parts) > 2):
            return modifier + "bg-position"
        if second in ("none", "gradient"):
            return modifier + "bg-image"
        return modifier + "bg-color"

    # --- ring ---
    # ring / ring-0 / ring-1 … → box-shadow (ring width)
    # ring-inset → ring-inset (unique)
    # ring-<color>-<shade> → ring color
    # ring-offset-* → ring-offset-width or ring-offset-color
    if root == "ring":
        if second == "offset":
            if len(parts) == 2:
                return modifier + "ring-offset-width"
            third = parts[2]
            if third.isdigit() or third == "0":
                return modifier + "ring-offset-width"
            return modifier + "ring-offset-color"
        if second == "inset":
            return modifier + "ring-inset"
        if second.isdigit() or second == "0":
            return modifier + "ring-width"
        return modifier + "ring-color"

    # --- shadow ---
    # shadow / shadow-sm / shadow-lg / shadow-xl / shadow-none → box-shadow size
    # shadow-<color>-<shade> → box-shadow color
    _SHADOW_SIZES = frozenset({"sm", "md", "lg", "xl", "2xl", "inner", "none"})
    if root == "shadow":
        if second in _SHADOW_SIZES or len(parts) == 1:
            return modifier + "shadow-size"
        return modifier + "shadow-color"

    # --- col / row (grid placement) ---
    # col-span-* → grid-column span
    # col-start-* → grid-column-start
    # col-end-* → grid-column-end
    # row-span-* → grid-row span
    if root == "col":
        if second == "span":
            return modifier + "grid-column-span"
        if second == "start":
            return modifier + "grid-column-start"
        if second == "end":
            return modifier + "grid-column-end"
        return modifier + rest
    if root == "row":
        if second == "span":
            return modifier + "grid-row-span"
        if second == "start":
            return modifier + "grid-row-start"
        if second == "end":
            return modifier + "grid-row-end"
        return modifier + rest

    # --- place / justify / items / content / self ---
    # justify-content vs justify-items vs justify-self are different properties
    if root == "justify":
        if second == "items":
            return modifier + "justify-items"
        if second == "self":
            return modifier + "justify-self"
        return modifier + "justify-content"

    if root == "place":
        if second == "content":
            return modifier + "place-content"
        if second == "items":
            return modifier + "place-items"
        if second == "self":
            return modifier + "place-self"
        return modifier + rest

    # --- divide ---
    # divide-x-* → border-right-width (children)
    # divide-y-* → border-bottom-width (children)
    # divide-<color> → divide color
    # divide-solid / divide-dashed … → divide style
    if root == "divide":
        if second == "x":
            return modifier + "divide-x"
        if second == "y":
            return modifier + "divide-y"
        if second in _BORDER_STYLES:
            return modifier + "divide-style"
        return modifier + "divide-color"

    # --- scale / translate / rotate / skew ---
    # scale-x-* and scale-y-* are different from scale-*
    if root == "scale":
        if second == "x":
            return modifier + "scale-x"
        if second == "y":
            return modifier + "scale-y"
        return modifier + "scale"
    if root == "translate":
        if second == "x":
            return modifier + "translate-x"
        if second == "y":
            return modifier + "translate-y"
        return modifier + rest
    if root == "skew":
        if second == "x":
            return modifier + "skew-x"
        if second == "y":
            return modifier + "skew-y"
        return modifier + rest

    # --- outline ---
    # outline / outline-0 / outline-1 … → outline-width
    # outline-<color>-<shade> → outline-color
    # outline-solid / outline-dashed … → outline-style
    # outline-offset-* → outline-offset
    if root == "outline":
        if second == "offset":
            return modifier + "outline-offset"
        if second in _BORDER_STYLES:
            return modifier + "outline-style"
        if second.isdigit() or second == "0" or second == "none":
            return modifier + "outline-width"
        return modifier + "outline-color"

    # --- stroke ---
    # stroke-* → stroke color
    # stroke-0 / stroke-1 / stroke-2 → stroke-width
    if root == "stroke":
        if second.isdigit():
            return modifier + "stroke-width"
        return modifier + "stroke-color"

    # --- Default: drop last segment as prefix ---
    # This works correctly for simple utilities like mb-4, pt-2, w-full, h-screen, etc.
    # where all values under the same prefix set the same CSS property.
    return modifier + "-".join(parts[:-1])


def build_classes(component_name: str, props: dict) -> str:
    """Build the complete class string for a component with proper deduplication.

    Order: base -> variant -> custom
    Classes with same prefix are deduplicated (last wins).
    Deduplication only happens between different sources (base vs variant vs custom),
    not within the same source.
    """
    config = get_config(component_name)

    if not config:
        # Not registered - return component name as class
        return component_name

    # Store all classes in order, then deduplicate by prefix at the end
    all_classes: list[str] = []

    # 1. Add base class from config first (lowest priority)
    base_class = config.get("class", "")
    if base_class:
        all_classes.extend(base_class.split())

    # 2. Add modifier group classes — any non-reserved dict key in config is a modifier group
    for key, group in config.items():
        if key in _RESERVED_KEYS or not isinstance(group, dict):
            continue
        chosen = props.get(key)
        if chosen and chosen in group and group[chosen]:
            all_classes.extend(str(group[chosen]).split())

    # 4. Add custom class from props last (highest priority)
    if "class" in props:
        custom_class = props["class"]
        if custom_class:
            all_classes.extend(str(custom_class).split())

    # Deduplicate by prefix, keeping the LAST occurrence (highest priority wins)
    # Use a dict to track which classes to keep (last one wins)
    prefix_to_class: dict[str, str] = {}
    for cls in all_classes:
        if not cls:
            continue
        prefix = _get_class_prefix(cls)
        if prefix:  # Only deduplicate if we can extract a meaningful prefix
            prefix_to_class[prefix] = cls

    # Now rebuild the class list, but only include classes whose prefix is in our keep list
    # However, we also need to include classes without a detectable prefix
    keep_classes = set(prefix_to_class.values())

    result_classes = []
    for cls in all_classes:
        if not cls:
            continue
        # Include if it's in our keep set OR if it has no detectable prefix
        prefix = _get_class_prefix(cls)
        if not prefix or cls in keep_classes:
            result_classes.append(cls)

    # Remove duplicates while preserving order (keep first occurrence)
    seen = set()
    unique_classes = []
    for cls in result_classes:
        if cls not in seen:
            seen.add(cls)
            unique_classes.append(cls)

    return " ".join(unique_classes) if unique_classes else component_name


def get_modifier_keys(component_name: str) -> set[str]:
    """Return the set of modifier group keys for a component (non-reserved config keys)."""
    config = get_config(component_name)
    if not config:
        return set()
    return {k for k, v in config.items() if k not in _RESERVED_KEYS and isinstance(v, dict)}


def build_extra_attrs(props: dict, modifier_keys: set[str] | None = None) -> str:
    """Build extra HTML attributes from props (excluding class, variant, internal props, and modifier keys)"""
    # Props that should not become HTML attributes
    excluded = {"class", "variant", "children", "design"}
    if modifier_keys:
        excluded = excluded | modifier_keys
    attrs = []
    for key, val in props.items():
        if key in excluded:
            continue
        if val is True:
            # Boolean attribute
            attrs.append(key)
        elif val:
            # Regular attribute
            attrs.append(f'{key}="{val}"')
    return " " + " ".join(attrs) if attrs else ""


def _wrap_in_link_if_needed(html: str, props: dict, tag: str) -> str:
    """Wrap content in <a> tag if component has href but is not already an anchor.

    Args:
        html: The rendered component HTML
        props: Component props containing potential href
        tag: The HTML tag being used for the component

    Returns:
        Wrapped HTML if needs link, otherwise original HTML
    """
    href = props.get("href")
    if href and tag != "a":
        # Get target and rel attrs if present
        target = props.get("target")
        rel = props.get("rel", "noopener noreferrer")  # Default for security

        # Build link attributes
        link_attrs = f'href="{href}"'
        if target:
            link_attrs += f' target="{target}"'
        if rel:
            link_attrs += f' rel="{rel}"'

        inner_html = re.sub(r'\s+href="[^"]*"', '', html)

        return f'<a {link_attrs}>{inner_html}</a>'

    return html


# HTML tags whose content should be rendered as preformatted (whitespace preserved)
_PREFORMATTED_TAGS = frozenset(["pre", "code"])


def render_component(component: Component, render_children: Callable, render_children_raw: Callable | None = None) -> str:
    """Render a component based on its config"""
    # Check for design-based rendering
    if has_design(component.name):
        return _render_with_design(component, render_children)

    config = get_config(component.name)

    # Use raw (preformatted) renderer for pre/code tags
    effective_tag = config.get("tag", component.name) if config else component.name
    if effective_tag in _PREFORMATTED_TAGS and render_children_raw is not None:
        children_html = render_children_raw(component.children)
    else:
        children_html = render_children(component.children)

    if config:
        # Registered component - use config
        cls = build_classes(component.name, component.props)
        tag = effective_tag

        # Build extra attributes from props
        extra_attrs = build_extra_attrs(component.props, get_modifier_keys(component.name))

        # Handle self-closing tags
        if tag in ("img", "input", "br", "hr"):
            html = f'<{tag} class="{cls}"{extra_attrs} />'
            return _wrap_in_link_if_needed(html, component.props, tag)

        html = f'<{tag} class="{cls}"{extra_attrs}>{children_html}</{tag}>'
        return _wrap_in_link_if_needed(html, component.props, tag)

    # Not registered - render as generic tag with same rules as registered components
    # (no base class, no variants, no design — but class and all other props apply normally)
    tag = component.name
    if tag in _PREFORMATTED_TAGS and render_children_raw is not None:
        children_html = render_children_raw(component.children)
    cls = component.props.get("class", "")
    extra_attrs = build_extra_attrs(component.props)
    if cls:
        html = f'<{tag} class="{cls}"{extra_attrs}>{children_html}</{tag}>'
    else:
        html = f'<{tag}{extra_attrs}>{children_html}</{tag}>'
    return _wrap_in_link_if_needed(html, component.props, tag)


def _render_with_design(component: Component, render_children: Callable) -> str:
    """Render a component using its design template"""

    # Determine design to use:
    # 1. design= explicit prop takes precedence (allows variant + design independently)
    # 2. variant= is used as design name if no matching design exists for it
    # 3. fallback to "default"
    explicit_design = component.props.get("design")
    variant = component.props.get("variant", "default")
    if explicit_design:
        design = get_design(component.name, explicit_design) or get_design(component.name, "default")
    else:
        design = get_design(component.name, variant) or get_design(component.name, "default")
    if not design:
        # Fallback to normal rendering if design not found
        return _render_without_design(component, render_children)

    # Get slot names from the design
    slot_names = _extract_slots(design)

    # Separate children into slots
    slots: dict[str, list] = {}
    slot_props: dict[str, dict] = {}  # props do filho-slot
    other_children: list = []

    for child in component.children:
        if isinstance(child, CompNode) and child.name in slot_names:
            # This child fills a named slot
            slots[child.name] = child.children if child.children else [child]
            slot_props[child.name] = child.props
        else:
            other_children.append(child)

    # Render each slot's content
    rendered_slots: dict[str, str] = {}
    for slot_name in slot_names:
        if slot_name == "children":
            rendered_slots["children"] = render_children(other_children)
        elif slot_name in slots:
            slot_content = slots[slot_name]
            # Check if it's a self-closing slot (Component with no children that was kept as-is)
            if (len(slot_content) == 1
                    and isinstance(slot_content[0], CompNode)
                    and slot_content[0].name in slot_names):
                # Self-closing slot component: render it as a regular component
                rendered_slots[slot_name] = render_component(slot_content[0], render_children, None)
            else:
                slot_html = render_children(slot_content)
                # If slot had href and content is not already a link, wrap it
                s_props = slot_props.get(slot_name, {})
                if s_props.get("href") and not slot_html.lstrip().startswith("<a"):
                    slot_html = _wrap_in_link_if_needed(slot_html, s_props, "")
                rendered_slots[slot_name] = slot_html
            # Expose slot props as {slot-propname} placeholders
            for prop_key, prop_val in slot_props.get(slot_name, {}).items():
                rendered_slots[f"{slot_name}-{prop_key}"] = prop_val if isinstance(prop_val, str) else ""
        else:
            rendered_slots[slot_name] = ""

    # Render the design AST, substituting placeholders
    design_copy = copy.deepcopy(design)
    inner_html = _render_design_children(design_copy.children, rendered_slots, render_children)

    # Wrap in outer tag+class from YAML config
    config = get_config(component.name)
    if config:
        cls = build_classes(component.name, component.props)
        tag = config.get("tag", component.name)
        extra_attrs = build_extra_attrs(component.props, get_modifier_keys(component.name))
        # Only include class attribute if there are real classes (not just component name fallback)
        has_real_class = cls and cls != component.name
        class_attr = f' class="{cls}"' if has_real_class else ""
        return f'<{tag}{class_attr}{extra_attrs}>{inner_html}</{tag}>'

    # No config, just return inner HTML with wrapper
    cls = component.name
    extra_attrs = build_extra_attrs(component.props)
    return f'<div class="{cls}"{extra_attrs}>{inner_html}</div>'


def _render_without_design(component: Component, render_children: Callable) -> str:
    """Fallback: render component without design (same as normal rendering)"""
    config = get_config(component.name)
    children_html = render_children(component.children)

    if config:
        cls = build_classes(component.name, component.props)
        tag = config.get("tag", component.name)
        extra_attrs = build_extra_attrs(component.props, get_modifier_keys(component.name))
        if tag in ("img", "input", "br", "hr"):
            return f'<{tag} class="{cls}"{extra_attrs} />'
        return f'<{tag} class="{cls}"{extra_attrs}>{children_html}</{tag}>'

    cls = component.name
    extra_attrs = build_extra_attrs(component.props)
    return f'<{cls} class="{cls}"{extra_attrs}>{children_html}</{cls}>'


def _has_slot_placeholders(children: list) -> bool:
    """Check if any child (recursively) contains a {slot} placeholder in content or props."""
    for child in children:
        if isinstance(child, Content) and _SLOT_RE.search(child.text):
            return True
        if isinstance(child, CompNode):
            # Check props values for placeholders
            if any(_SLOT_RE.search(str(v)) for v in child.props.values() if isinstance(v, str)):
                return True
            if _has_slot_placeholders(child.children):
                return True
    return False


def _direct_slot_names(children: list) -> list[str]:
    """Return slot names that appear directly (not nested) in children Content nodes."""
    names = []
    for child in children:
        if isinstance(child, Content):
            for m in _SLOT_RE.finditer(child.text):
                name = m.group(1)
                if name not in names:
                    names.append(name)
    return names


def _render_design_children(children: list, rendered_slots: dict[str, str], render_children: Callable) -> str:
    """Render the design AST children, replacing {slot} placeholders with rendered slot content"""

    parts = []
    for child in children:
        if isinstance(child, Content):
            # Replace all {slot_name} placeholders in content text
            text = child.text
            text = _SLOT_RE.sub(
                lambda m: rendered_slots.get(m.group(1), ""),
                text
            )
            if text.strip():
                parts.append(text.strip())
        elif isinstance(child, CompNode):
            # Render the design's structural components
            inner = _render_design_children(child.children, rendered_slots, render_children)
            # Substitute slot placeholders in props values
            # Resolve placeholders in props, tracking which had unresolved slots
            has_empty_slot_prop = False
            resolved_props = {}
            for k, v in child.props.items():
                if isinstance(v, str) and _SLOT_RE.search(v):
                    resolved = _SLOT_RE.sub(lambda m: rendered_slots.get(m.group(1), ""), v)
                    if not resolved:
                        has_empty_slot_prop = True
                    resolved_props[k] = resolved
                else:
                    resolved_props[k] = v

            # Omit element entirely if a required prop slot (e.g. href) resolved to empty
            if has_empty_slot_prop:
                continue

            # Merge slot-class props into this element's class.
            # If any direct child slot has a {slot-class} extra class, append it here.
            # e.g. @title class=font-serif → rendered_slots["title-class"] = "font-serif"
            direct_slots = _direct_slot_names(child.children)
            for slot_name in direct_slots:
                slot_extra_class = rendered_slots.get(f"{slot_name}-class", "")
                if slot_extra_class:
                    existing = resolved_props.get("class", "")
                    resolved_props["class"] = (existing + " " + slot_extra_class).strip()

            cls = resolved_props.get("class", "")
            tag = child.name
            child.props = resolved_props
            extra_attrs = build_extra_attrs(resolved_props)
            if tag in ("img", "input", "br", "hr"):
                parts.append(f'<{tag} class="{cls}"{extra_attrs} />' if cls else f'<{tag}{extra_attrs} />')
            elif not inner.strip():
                # Only omit if this element (or its descendants) had slot placeholders that
                # were not filled. Pure structural elements (no slots) are always rendered.
                if _has_slot_placeholders(child.children):
                    pass  # slot was empty — omit this element
                else:
                    # Structural element with no slots — render even if visually empty
                    if cls:
                        parts.append(f'<{tag} class="{cls}"{extra_attrs}></{tag}>')
                    else:
                        parts.append(f'<{tag}{extra_attrs}></{tag}>')
            elif cls:
                parts.append(f'<{tag} class="{cls}"{extra_attrs}>{inner}</{tag}>')
            else:
                parts.append(f'<{tag}{extra_attrs}>{inner}</{tag}>')
    return "".join(parts)
