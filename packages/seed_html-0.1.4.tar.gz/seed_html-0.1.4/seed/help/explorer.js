/**
 * Seed Component Explorer — overlay injected into every dev-server page.
 * Triggered by: pressing 'h' in terminal (via /__help SSE) or 'h' key in browser.
 * Closed by: Esc key or clicking the backdrop.
 */
(function () {
  'use strict';

  // ── State ────────────────────────────────────────────────────────────────
  let overlay = null;
  let components = [];
  let activeTab = 'all';
  let searchQuery = '';

  // ── SSE: listen for terminal 'h' key ─────────────────────────────────────
  (function connectHelpSSE() {
    const es = new EventSource('/__help');
    es.addEventListener('help', () => toggleOverlay());
    es.onerror = () => {
      setTimeout(connectHelpSSE, 3000);
      es.close();
    };
  })();

  // ── Browser keyboard shortcut ─────────────────────────────────────────────
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && overlay) {
      closeOverlay();
      return;
    }
    if (e.key === 'h' || e.key === 'H') {
      const tag = document.activeElement?.tagName?.toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
      if (document.activeElement?.isContentEditable) return;
      toggleOverlay();
    }
  });

  // ── Toggle / open / close ─────────────────────────────────────────────────
  function toggleOverlay() {
    if (overlay) closeOverlay();
    else openOverlay();
  }

  function closeOverlay() {
    if (!overlay) return;
    overlay.remove();
    overlay = null;
    document.body.style.overflow = '';
  }

  async function openOverlay() {
    if (overlay) return;
    buildOverlay();
    document.body.style.overflow = 'hidden';
    try {
      const res = await fetch('/__components');
      const data = await res.json();
      components = data.components || [];
    } catch (e) {
      components = [];
    }
    renderCards();
  }

  // ── Build overlay DOM ─────────────────────────────────────────────────────
  function buildOverlay() {
    overlay = document.createElement('div');
    overlay.id = 'seed-explorer-overlay';
    overlay.style.cssText = [
      'position:fixed', 'inset:0', 'z-index:99999',
      'display:flex', 'flex-direction:column',
      'background:rgba(0,0,0,0.6)',
      'backdrop-filter:blur(2px)',
    ].join(';');

    overlay.innerHTML = `
      <div id="seed-explorer-panel"
           style="position:absolute;inset:2%;border-radius:12px;
                  background:#0f1117;color:#e2e8f0;
                  display:flex;flex-direction:column;overflow:hidden;
                  box-shadow:0 25px 60px rgba(0,0,0,0.7);
                  border:1px solid #2d3148">

        <!-- Header -->
        <div style="display:flex;align-items:center;gap:12px;
                    padding:12px 20px;border-bottom:1px solid #2d3148;
                    background:#1a1d27;flex-shrink:0;flex-wrap:wrap">

          <span style="font-size:0.95rem;font-weight:700;color:#a5b4fc;white-space:nowrap">
            🌿 Component Explorer
          </span>

          <span id="se-count"
                style="font-size:0.7rem;color:#64748b;background:#1e2235;
                       border:1px solid #2d3148;padding:2px 8px;border-radius:9999px">
            loading…
          </span>

          <!-- Tabs -->
          <div style="display:flex;gap:4px;background:#1e2235;
                      border:1px solid #2d3148;border-radius:8px;padding:3px;margin-left:8px">
            <button class="se-tab se-tab-active" data-tab="all"
                    style="background:#0f1117;color:#a5b4fc;border:none;border-radius:6px;
                           padding:4px 12px;font-size:0.78rem;font-weight:600;cursor:pointer">
              All
            </button>
            <button class="se-tab" data-tab="simple"
                    style="background:transparent;color:#64748b;border:none;border-radius:6px;
                           padding:4px 12px;font-size:0.78rem;font-weight:600;cursor:pointer">
              Simple
            </button>
            <button class="se-tab" data-tab="composite"
                    style="background:transparent;color:#64748b;border:none;border-radius:6px;
                           padding:4px 12px;font-size:0.78rem;font-weight:600;cursor:pointer">
              Composite
            </button>
          </div>

          <!-- Search -->
          <input id="se-search" type="search" placeholder="Filter components…"
                 autocomplete="off"
                 style="flex:1;min-width:160px;max-width:280px;
                        background:#1e2235;border:1px solid #2d3148;
                        color:#e2e8f0;border-radius:8px;padding:5px 10px;
                        font-size:0.82rem;outline:none;margin-left:auto">

          <!-- Close -->
          <button id="se-close"
                  style="background:#ef4444;color:white;border:none;border-radius:8px;
                         padding:5px 14px;font-size:0.8rem;font-weight:600;cursor:pointer;
                         white-space:nowrap">
            ✕ Close
          </button>
        </div>

        <!-- Card grid -->
        <div id="se-grid"
             style="flex:1;min-height:0;overflow-y:auto;padding:20px;
                    display:grid;
                    grid-template-columns:repeat(auto-fill,minmax(360px,1fr));
                    grid-auto-rows:max-content;
                    gap:14px">
          <p style="color:#64748b;font-size:0.85rem">Loading…</p>
        </div>
      </div>
    `;

    // Backdrop click → close
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeOverlay();
    });

    // Close button
    overlay.querySelector('#se-close').addEventListener('click', closeOverlay);

    // Tabs
    overlay.querySelectorAll('.se-tab').forEach((btn) => {
      btn.addEventListener('click', () => {
        activeTab = btn.dataset.tab;
        overlay.querySelectorAll('.se-tab').forEach((b) => {
          const isActive = b === btn;
          b.style.background = isActive ? '#0f1117' : 'transparent';
          b.style.color = isActive ? '#a5b4fc' : '#64748b';
        });
        renderCards();
      });
    });

    // Search
    overlay.querySelector('#se-search').addEventListener('input', (e) => {
      searchQuery = e.target.value.toLowerCase().trim();
      renderCards();
    });

    document.body.appendChild(overlay);

    // Focus search
    setTimeout(() => overlay?.querySelector('#se-search')?.focus(), 50);
  }

  // ── Render cards ──────────────────────────────────────────────────────────
  function renderCards() {
    if (!overlay) return;
    const grid = overlay.querySelector('#se-grid');
    const countEl = overlay.querySelector('#se-count');
    if (!grid) return;

    // Filter by tab + search
    const filtered = components.filter((c) => {
      if (activeTab === 'simple' && c.has_design) return false;
      if (activeTab === 'composite' && !c.has_design) return false;
      if (searchQuery) {
        const hay = [c.name, c.tag, ...(c.variants || []), ...(c.design_variants || [])].join(' ').toLowerCase();
        if (!hay.includes(searchQuery)) return false;
      }
      return true;
    });

    if (countEl) countEl.textContent = `${filtered.length} of ${components.length}`;

    if (filtered.length === 0) {
      grid.innerHTML = '<p style="color:#64748b;font-size:0.85rem;grid-column:1/-1">No components found.</p>';
      return;
    }

    grid.innerHTML = filtered.map(cardHTML).join('');

    // Wire up copy buttons
    grid.querySelectorAll('.se-copy-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const code = btn.dataset.code;
        navigator.clipboard.writeText(code).then(() => {
          btn.textContent = 'Copied!';
          btn.style.color = '#22c55e';
          btn.style.borderColor = '#22c55e';
          setTimeout(() => {
            btn.textContent = 'Copy';
            btn.style.color = '';
            btn.style.borderColor = '';
          }, 1800);
        });
      });
    });
  }

  // ── Card template ─────────────────────────────────────────────────────────
  function cardHTML(c) {
    const isComposite = c.has_design;
    const accentColor = isComposite ? '#4c1d95' : '#166534';
    const typeBadge = isComposite
      ? '<span style="font-size:0.6rem;padding:1px 6px;border-radius:4px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;background:#1c1340;color:#c4b5fd;border:1px solid #4c1d95">composite</span>'
      : '<span style="font-size:0.6rem;padding:1px 6px;border-radius:4px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;background:#14291a;color:#4ade80;border:1px solid #166534">simple</span>';

    const variantBadges = (c.variants || []).map((v) =>
      `<span style="font-size:0.64rem;background:#1e2937;color:#38bdf8;border:1px solid #1e3a4a;padding:1px 7px;border-radius:9999px;font-family:monospace">${esc(v)}</span>`
    ).join('');

    const designBadges = (c.design_variants || []).map((v) =>
      `<span style="font-size:0.64rem;background:#1a1040;color:#c4b5fd;border:1px solid #3b1f8c;padding:1px 7px;border-radius:9999px;font-family:monospace">${esc(v)}</span>`
    ).join('');

    const variantsRow = variantBadges
      ? `<div style="display:flex;flex-wrap:wrap;align-items:center;gap:4px;margin-top:6px">
           <span style="font-size:0.6rem;color:#64748b;text-transform:uppercase;letter-spacing:.08em;font-weight:600;margin-right:2px">variants</span>
           ${variantBadges}
         </div>`
      : '';

    const designVariantsRow = designBadges
      ? `<div style="display:flex;flex-wrap:wrap;align-items:center;gap:4px;margin-top:4px">
           <span style="font-size:0.6rem;color:#64748b;text-transform:uppercase;letter-spacing:.08em;font-weight:600;margin-right:2px">designs</span>
           ${designBadges}
         </div>`
      : '';

    const desc = c.description
      ? `<p style="font-size:0.78rem;color:#94a3b8;margin-top:4px;line-height:1.5">${esc(c.description)}</p>`
      : '';

    const exampleCode = c.example || autoExample(c);
    const encodedCode = encodeURIComponent(exampleCode);

    return `
      <div style="background:#1a1d27;border:1px solid #2d3148;border-radius:10px;
                  border-left:3px solid ${accentColor};overflow:hidden">

        <!-- Card header -->
        <div style="padding:12px 16px 10px;border-bottom:1px solid #2d3148">
          <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:3px">
            <span style="font-size:0.9rem;font-weight:700;color:#a5b4fc;
                         font-family:'Fira Code','JetBrains Mono',monospace">@${esc(c.name)}</span>
            <span style="font-size:0.65rem;color:#64748b;font-family:monospace;
                         background:#1e2235;border:1px solid #2d3148;padding:1px 6px;border-radius:4px">
              &lt;${esc(c.tag)}&gt;
            </span>
            ${typeBadge}
          </div>
          ${desc}
          ${variantsRow}
          ${designVariantsRow}
        </div>

        <!-- Card body -->
        <div style="padding:12px 16px">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
            <span style="font-size:0.6rem;color:#64748b;text-transform:uppercase;letter-spacing:.1em;font-weight:600">seed</span>
            <button class="se-copy-btn" data-code="${esc(exampleCode, true)}"
                    style="background:transparent;border:1px solid #2d3148;color:#64748b;
                           border-radius:6px;padding:2px 10px;font-size:0.7rem;cursor:pointer">
              Copy
            </button>
          </div>
          <pre style="background:#0d1117;border:1px solid #21262d;border-radius:7px;
                      padding:10px 12px;font-size:0.75rem;
                      font-family:'Fira Code','JetBrains Mono',monospace;
                      color:#c9d1d9;overflow-x:auto;white-space:pre;line-height:1.6;
                      margin:0">${esc(exampleCode)}</pre>
          <div style="margin-top:8px">
            <a href="/__preview?code=${encodedCode}" target="_blank"
               style="display:inline-flex;align-items:center;gap:4px;font-size:0.73rem;
                      color:#6366f1;text-decoration:none;background:#1e1e35;
                      border:1px solid #3730a3;border-radius:6px;padding:3px 10px;font-weight:500">
              ▶ Preview
            </a>
          </div>
        </div>
      </div>
    `;
  }

  // ── Helpers ───────────────────────────────────────────────────────────────
  function autoExample(c) {
    return `@${c.name}\n  Content here`;
  }

  function esc(str, attr) {
    const s = String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    if (attr) return s.replace(/"/g, '&quot;');
    return s;
  }
})();
