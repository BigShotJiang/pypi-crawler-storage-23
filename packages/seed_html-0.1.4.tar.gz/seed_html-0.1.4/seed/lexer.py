from __future__ import annotations
import re
from dataclasses import dataclass
from enum import Enum, auto

from .errors import SeedError


class TokenType(Enum):
    HEADER = auto()
    COMPONENT = auto()
    CONTENT = auto()
    INDENT = auto()
    DEDENT = auto()
    INLINE_OPEN = auto()
    INLINE_CLOSE = auto()
    EOF = auto()


@dataclass
class Token:
    type: TokenType
    value: str
    line: int
    col: int = 0
    props: dict | None = None
    name: str = ""


_COMPONENT_RE = re.compile(r"^@([\w-]+):?\s+(.+)$")
_COMPONENT_BARE_RE = re.compile(r"^@([\w-]+):?\s*$")

# Components that treat their single-word inline argument as a prop/path, not content
_PROP_ARG_COMPONENTS = frozenset(["include", "block"])
_HEADER_FENCE = "---"
_INLINE_OPEN_RE = re.compile(r"\{(\w+)\s+([^}]*)\}")
_INLINE_CLOSE_RE = re.compile(r"\{/(\w+)\}")


def parse_props(raw: str) -> dict:
    props: dict = {}
    if not raw or not raw.strip():
        return props
    raw = raw.strip()
    
    # Check for positional argument: single word without = or ,
    # e.g., @include navbar or @button centered
    if "=" not in raw and "," not in raw and " " not in raw:
        props[raw] = True
        return props
    
    i = 0
    while i < len(raw):
        if raw[i] in " ,":
            i += 1
            continue
        key_start = i
        while i < len(raw) and raw[i] not in "=,":
            i += 1
        key = raw[key_start:i].strip()
        if not key:
            i += 1
            continue
        if i < len(raw) and raw[i] == "=":
            i += 1
            if i < len(raw) and raw[i] == '"':
                i += 1
                val_start = i
                while i < len(raw) and raw[i] != '"':
                    i += 1
                props[key] = raw[val_start:i]
                if i < len(raw):
                    i += 1
            else:
                val_start = i
                # Value goes until comma or end of string (allows spaces in values)
                while i < len(raw) and raw[i] != ",":
                    i += 1
                props[key] = raw[val_start:i].strip()
        else:
            # Flag (no = sign) - value is True
            props[key] = True
    return props


# Tags that should capture their content as raw preformatted text,
# preserving relative indentation and not parsing child components.
_RAW_CONTENT_TAGS = frozenset(["pre", "code"])


def tokenize(source: str) -> list[Token]:
    lines = source.split("\n")
    tokens: list[Token] = []
    indent_stack = [0]
    i = 0

    if lines and lines[0].strip() == _HEADER_FENCE:
        header_lines = []
        i = 1
        while i < len(lines) and lines[i].strip() != _HEADER_FENCE:
            header_lines.append(lines[i])
            i += 1
        if i >= len(lines):
            raise SeedError("Unclosed header block", line=1)
        tokens.append(Token(TokenType.HEADER, "\n".join(header_lines), line=1))
        i += 1

    in_code_fence = False

    while i < len(lines):
        line = lines[i]
        stripped = line.rstrip()
        i += 1

        if not stripped:
            continue

        indent = len(stripped) - len(stripped.lstrip())
        # Preserve a single trailing space if the original line had trailing whitespace
        # (allows "text " before a sibling @component to produce a space in output)
        raw_content = line.rstrip("\n\r").lstrip()
        content = raw_content if raw_content.rstrip() == stripped.lstrip() else raw_content

        current_indent = indent_stack[-1]
        if indent > current_indent:
            indent_stack.append(indent)
            tokens.append(Token(TokenType.INDENT, "", line=i))
        else:
            while indent < indent_stack[-1]:
                indent_stack.pop()
                tokens.append(Token(TokenType.DEDENT, "", line=i))

        if content.startswith("```"):
            in_code_fence = not in_code_fence
            tokens.append(Token(TokenType.CONTENT, content, line=i))
            continue

        if in_code_fence:
            tokens.append(Token(TokenType.CONTENT, content, line=i))
            continue

        m = _COMPONENT_RE.match(content)
        if m:
            name = m.group(1)
            raw_props = m.group(2) or ""
            # If the text after @name has no '=' it's inline content, not props
            # Exception: components like @include and @block take a path/name as positional arg
            if "=" not in raw_props and name not in _PROP_ARG_COMPONENTS:
                tokens.append(Token(TokenType.COMPONENT, content, line=i, name=name, props={}))
                tokens.append(Token(TokenType.INDENT, "", line=i))
                tokens.append(Token(TokenType.CONTENT, raw_props, line=i))
                tokens.append(Token(TokenType.DEDENT, "", line=i))
            else:
                props = parse_props(raw_props)
                tokens.append(Token(TokenType.COMPONENT, content, line=i, name=name, props=props))
                if name in _RAW_CONTENT_TAGS:
                    tokens.extend(_tokenize_raw_block(lines, i, indent_stack[-1]))
                    # Skip lines that were consumed by the raw block reader
                    # Find how many lines were consumed (scan ahead until dedent)
                    i = _skip_raw_block_lines(lines, i, indent_stack[-1])
            continue

        m = _COMPONENT_BARE_RE.match(content)
        if m:
            name = m.group(1)
            tokens.append(Token(TokenType.COMPONENT, content, line=i, name=name, props={}))
            if name in _RAW_CONTENT_TAGS:
                tokens.extend(_tokenize_raw_block(lines, i, indent_stack[-1]))
                i = _skip_raw_block_lines(lines, i, indent_stack[-1])
            continue

        if _INLINE_OPEN_RE.search(content) or _INLINE_CLOSE_RE.search(content):
            tokens.append(Token(TokenType.CONTENT, content, line=i))
            continue

        tokens.append(Token(TokenType.CONTENT, content, line=i))

    while len(indent_stack) > 1:
        indent_stack.pop()
        tokens.append(Token(TokenType.DEDENT, "", line=i))

    tokens.append(Token(TokenType.EOF, "", line=i))
    return tokens


def _tokenize_raw_block(lines: list[str], start: int, parent_indent: int) -> list[Token]:
    """Emit INDENT, raw CONTENT lines (with relative indentation), and DEDENT
    for a @pre/@code block. The block's base indent is the first non-empty
    child line's indent level."""
    result: list[Token] = []
    base_indent: int | None = None

    for j in range(start, len(lines)):
        raw = lines[j].rstrip()
        if not raw:
            if base_indent is not None:
                result.append(Token(TokenType.CONTENT, "", line=j + 1))
            continue
        line_indent = len(raw) - len(raw.lstrip())
        if line_indent <= parent_indent:
            break
        if base_indent is None:
            base_indent = line_indent
            result.append(Token(TokenType.INDENT, "", line=j + 1))
        relative_spaces = " " * max(0, line_indent - base_indent)
        result.append(Token(TokenType.CONTENT, relative_spaces + raw.lstrip(), line=j + 1))

    if base_indent is not None:
        result.append(Token(TokenType.DEDENT, "", line=start))

    return result


def _skip_raw_block_lines(lines: list[str], start: int, parent_indent: int) -> int:
    """Return the index of the first line after the raw block."""
    for j in range(start, len(lines)):
        raw = lines[j].rstrip()
        if not raw:
            continue
        line_indent = len(raw) - len(raw.lstrip())
        if line_indent <= parent_indent:
            return j
    return len(lines)
