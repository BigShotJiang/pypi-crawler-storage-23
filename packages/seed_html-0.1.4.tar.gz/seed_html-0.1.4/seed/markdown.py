from __future__ import annotations
import re
import mistune


_INLINE_RE = re.compile(r"\{(\w+)\s+([^}]*)\}(.*?)\{/\1\}", re.DOTALL)

# Inline patterns: backtick code, bold, italic, links — no block elements
_INLINE_CODE_RE = re.compile(r"`([^`]+)`")
_BOLD_RE = re.compile(r"\*\*(.+?)\*\*")
_ITALIC_RE = re.compile(r"\*(.+?)\*|_(.+?)_")
_LINK_RE = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")

_HTML_ESCAPE = str.maketrans({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"})

_HTML_ENTITY_RE = re.compile(r"&(?:#\d+|#x[\da-fA-F]+|[a-zA-Z]\w*);")


def escape_html(text: str) -> str:
    """Escape HTML special characters in plain text."""
    return text.translate(_HTML_ESCAPE)


def render_inline(text: str) -> str:
    """Render inline markdown only (code, bold, italic, links) with HTML escaping.
    Does NOT wrap in <p> tags. Safe for use inside any HTML element."""
    # Step 1: extract code spans first (before escaping), replace with placeholders
    placeholders: list[str] = []

    def extract_code(m: re.Match) -> str:
        # Escape the raw content, then wrap in <code>
        escaped = escape_html(m.group(1))
        placeholders.append(f"<code>{escaped}</code>")
        return f"\x00{len(placeholders) - 1}\x00"

    result = _INLINE_CODE_RE.sub(extract_code, text)

    # Step 1b: extract HTML entities (&nbsp; &amp; &#160; etc.) before escaping
    def extract_entity(m: re.Match) -> str:
        placeholders.append(m.group(0))
        return f"\x00{len(placeholders) - 1}\x00"

    result = _HTML_ENTITY_RE.sub(extract_entity, result)

    # Step 2: escape HTML in the remaining text
    result = escape_html(result)

    # Step 3: apply other inline patterns (bold, italic, links) — content already escaped
    result = _BOLD_RE.sub(lambda m: f"<strong>{m.group(1)}</strong>", result)
    result = _ITALIC_RE.sub(lambda m: f"<em>{m.group(1) or m.group(2)}</em>", result)
    result = _LINK_RE.sub(lambda m: f'<a href="{m.group(2)}">{m.group(1)}</a>', result)

    # Step 4: restore code placeholders
    for i, ph in enumerate(placeholders):
        result = result.replace(f"\x00{i}\x00", ph)

    return result


def _process_inline_components(text: str) -> str:
    def replacer(m: re.Match) -> str:
        tag = m.group(1)
        raw_attrs = m.group(2).strip()
        content = m.group(3)

        parts = raw_attrs.split()
        classes = []
        attrs = {}
        for part in parts:
            if "=" in part:
                k, v = part.split("=", 1)
                attrs[k] = v
            else:
                classes.append(part)

        cls = f' class="{" ".join(classes)}"' if classes else ""
        href = f' href="{attrs["href"]}"' if "href" in attrs else ""

        if tag == "btn":
            el = "a" if href else "button"
            return f"<{el}{cls}{href}>{content}</{el}>"

        if tag == "tag":
            return f'<span{cls}>{content}</span>'

        extra = "".join(f' {k}="{v}"' for k, v in attrs.items())
        return f"<span{cls}{extra}>{content}</span>"

    return _INLINE_RE.sub(replacer, text)


_md = mistune.create_markdown(escape=False)


def render_markdown(text: str) -> str:
    text = _process_inline_components(text)
    return _md(text)
