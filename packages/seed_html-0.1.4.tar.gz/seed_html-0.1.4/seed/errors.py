class SeedError(Exception):
    def __init__(self, message: str, line: int = 0, col: int = 0):
        self.line = line
        self.col = col
        super().__init__(f"[line {line}, col {col}] {message}" if line else message)
