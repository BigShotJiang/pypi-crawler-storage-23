#!/usr/bin/env python3
"""Seed CLI — init / dev / build / theme-install / theme-update / components-install / components-update"""

import html as html_mod
import json
import mimetypes
import os
import select
import shutil
import sys
import threading
import time
import urllib.parse
import webbrowser
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path


# ─── Helpers ────────────────────────────────────────────────────────────────

SEED_ENGINE_DIR = Path(__file__).parent

RELOAD_SNIPPET = b'<script>new EventSource("/__reload").onmessage=()=>location.reload()</script>'
HELP_SNIPPET = b'<script src="/__help/explorer.js"></script>'

reload_version = 0
reload_lock = threading.Condition()
help_version = 0
help_lock = threading.Condition()
python_restart_event = threading.Event()
_raw_mode = False  # True while terminal is in raw mode


def _load_seed_class():
    """Load Seed class in both package and direct-script execution modes."""
    try:
        from . import Seed
        return Seed
    except ImportError:
        pass

    try:
        from seed import Seed
        return Seed
    except ModuleNotFoundError:
        repo_root = Path(__file__).resolve().parent.parent
        if str(repo_root) not in sys.path:
            sys.path.insert(0, str(repo_root))
        from seed import Seed
        return Seed


def dev_print(msg=""):
    """Print respeitando modo raw do terminal (emite \\r\\n em vez de só \\n)."""
    if _raw_mode:
        sys.stdout.write(msg + "\r\n")
        sys.stdout.flush()
    else:
        print(msg)


def notify_reload():
    global reload_version
    with reload_lock:
        reload_version += 1
        reload_lock.notify_all()


def notify_help():
    global help_version
    with help_lock:
        help_version += 1
        help_lock.notify_all()


def find_seed_files(src_dir: Path):
    return sorted(src_dir.rglob("*.seed"))


def build_file(seed_instance, seed_file: Path, src_dir: Path, dist_dir: Path):
    """Build a single .seed file. src/blog/post.seed → dist/blog/post.html"""
    rel = seed_file.relative_to(src_dir)
    out = dist_dir / rel.with_suffix(".html")
    out.parent.mkdir(parents=True, exist_ok=True)
    html = seed_instance.render_file(seed_file, full_page=True)
    out.write_text(html, encoding="utf-8")
    return rel


def build_all(seed_instance, src_dir: Path, dist_dir: Path):
    for f in find_seed_files(src_dir):
        rel = build_file(seed_instance, f, src_dir, dist_dir)
        dev_print(f"  built {rel}")



def copy_static_layered(
    dist_dir: Path,
    project_static: Path,
    theme_static: Path | None = None,
    lib_static: Path | None = None,
):
    """Copy static files in layers: lib first, then theme, then project (project wins).

    This function only populates dist/static/.
    Missing directories are skipped silently.
    """
    dest = dist_dir / "static"
    if lib_static and lib_static.is_dir():
        shutil.copytree(lib_static, dest, dirs_exist_ok=True)
    if theme_static and theme_static.is_dir():
        shutil.copytree(theme_static, dest, dirs_exist_ok=True)
    if project_static.is_dir() and any(project_static.iterdir()):
        shutil.copytree(project_static, dest, dirs_exist_ok=True)


# ─── seed.yaml helpers ───────────────────────────────────────────────────────

def _read_seed_yaml(folder: Path) -> dict:
    """Read and parse seed.yaml. Returns empty dict if file doesn't exist."""
    import yaml
    seed_yaml = folder / "seed.yaml"
    if not seed_yaml.is_file():
        return {}
    try:
        config = yaml.safe_load(seed_yaml.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as e:
        raise ValueError(f"seed.yaml: erro de sintaxe YAML — {e}") from e
    if not isinstance(config, dict):
        raise ValueError("seed.yaml inválido: esperado mapeamento YAML (chave: valor)")
    return config


def _write_seed_yaml(folder: Path, config: dict):
    """Write seed.yaml preserving key order."""
    import yaml
    seed_yaml = folder / "seed.yaml"
    seed_yaml.write_text(yaml.dump(config, allow_unicode=True, default_flow_style=False), encoding="utf-8")


def _validate_lib_name(name: str, key: str):
    """Validate that a lib name is simple (no path separators) or absolute path.
    Rejects path traversal attempts.
    """
    p = Path(name)
    if p.is_absolute():
        return
    if p.parts != (name,):
        raise ValueError(
            f"seed.yaml: {key} '{name}' inválido — use nome simples (ex: seed-blog-theme) "
            f"ou caminho absoluto. Caminhos relativos com separador não são permitidos."
        )


def _resolve_lib_dir(folder: Path, subfolder: str, name: str) -> Path | None:
    """Resolve libs/<subfolder>/<name> directory. Returns None if name not set."""
    if not name:
        return None
    _validate_lib_name(name, subfolder)
    p = Path(name)
    lib_dir = p if p.is_absolute() else folder / "libs" / subfolder / name
    if not lib_dir.is_dir():
        raise FileNotFoundError(
            f"'{name}' não encontrado em: {lib_dir}\n"
            f"Use 'seed {subfolder[:-1]}-install' para instalar."
        )
    return lib_dir


def _load_project_config(folder: Path) -> tuple[Path | None, Path | None]:
    """Read seed.yaml and resolve theme_dir and components_lib_dir.

    Returns:
        (theme_dir, components_lib_dir) — either can be None
    """
    config = _read_seed_yaml(folder)
    theme_dir = _resolve_lib_dir(folder, "themes", config.get("theme") or "")
    components_lib_dir = _resolve_lib_dir(folder, "components", config.get("components") or "")
    return theme_dir, components_lib_dir


# ─── Install helpers ─────────────────────────────────────────────────────────

def _install_from_source(source: str, dest: Path):
    """Install a lib from a local path or GitHub URL into dest/.

    Supported sources:
    - Local absolute path: /Users/me/libs/seed-blog-theme
    - GitHub URL: https://github.com/user/repo
    """
    src_path = Path(source)

    if src_path.is_absolute() or (not source.startswith("http") and Path(source).exists()):
        # Local path
        src_path = Path(source).resolve()
        if not src_path.is_dir():
            raise FileNotFoundError(f"Caminho não encontrado: {src_path}")
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(src_path, dest)
        return src_path.name

    if "github.com" in source:
        return _install_from_github(source, dest)

    raise ValueError(
        f"Fonte inválida: '{source}'\n"
        f"Use um caminho absoluto ou URL do GitHub (https://github.com/user/repo)"
    )


def _install_from_github(url: str, dest: Path):
    """Download and extract a GitHub repository as ZIP into dest/."""
    import urllib.request
    import zipfile
    import tempfile

    # Normalize URL: strip trailing slash and .git
    url = url.rstrip("/").removesuffix(".git")

    # Extract user/repo from URL
    parts = url.replace("https://github.com/", "").replace("http://github.com/", "").split("/")
    if len(parts) < 2:
        raise ValueError(f"URL do GitHub inválida: {url}")
    repo_name = parts[1]

    zip_url = f"{url}/archive/refs/heads/main.zip"
    print(f"  downloading {zip_url}...")

    with tempfile.TemporaryDirectory() as tmp:
        zip_path = Path(tmp) / "repo.zip"
        try:
            urllib.request.urlretrieve(zip_url, zip_path)
        except Exception:
            # Try 'master' branch as fallback
            zip_url = f"{url}/archive/refs/heads/master.zip"
            print(f"  retrying with master branch...")
            urllib.request.urlretrieve(zip_url, zip_path)

        with zipfile.ZipFile(zip_path, "r") as z:
            z.extractall(tmp)

        # Find extracted directory (typically repo-main/ or repo-master/)
        extracted = [p for p in Path(tmp).iterdir() if p.is_dir()]
        if not extracted:
            raise RuntimeError("ZIP do GitHub não contém diretório raiz esperado")
        extracted_dir = extracted[0]

        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(extracted_dir, dest)

    return repo_name


def _ask_yes_no(question: str, default: bool = False) -> bool:
    hint = "[Y/n]" if default else "[y/N]"
    try:
        answer = input(f"{question} {hint} ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return False
    if not answer:
        return default
    return answer in ("y", "yes", "s", "sim")


def _install_lib(kind: str, project_dir: Path, source: str) -> str | None:
    """Install a lib (theme or components) from source, asking before overwriting."""
    libs_dir = project_dir / "libs" / kind
    libs_dir.mkdir(parents=True, exist_ok=True)
    src_path = Path(source)
    dest_name = src_path.name if src_path.is_absolute() else source.split("/")[-1].removesuffix(".git")
    dest = libs_dir / dest_name
    if dest.exists():
        if not _ask_yes_no(f"  '{dest_name}' already installed. Update?", default=False):
            print("  Cancelled.")
            return None
    print(f"  Installing from '{source}'...")
    return _install_from_source(source, dest)


# ─── Component Explorer ──────────────────────────────────────────────────────

def build_components_json() -> bytes:
    """Return JSON listing all top-level registered components."""
    from seed import components as comp_mod

    registry: dict = comp_mod._registry
    design_cache: dict = comp_mod._design_cache
    subitem_names: set = comp_mod._subitem_names

    components = []
    for name in sorted(registry):
        cfg = registry[name]
        if not isinstance(cfg, dict) or "alias" in cfg or name in subitem_names:
            continue
        has_design = name in design_cache
        design_variants = [v for v in design_cache.get(name, {}) if v != "default"]
        # Use explicit example from YAML, fallback to raw .design source for composite components
        example = cfg.get("example", "")
        if not example and has_design:
            example = comp_mod.get_design_source(name)
        components.append({
            "name": name,
            "tag": cfg.get("tag", name),
            "variants": list(cfg.get("variants", {}).keys()),
            "has_design": has_design,
            "design_variants": design_variants,
            "description": cfg.get("description", ""),
            "example": example,
        })
    return json.dumps({"components": components}).encode()


def build_preview_html(seed_code: str, state: dict) -> bytes:
    """Render a seed snippet as a full HTML page for preview."""
    try:
        seed_instance = state["seed"]
        rendered = seed_instance.render_string(seed_code, full_page=True)
    except Exception as exc:
        escaped = html_mod.escape(str(exc))
        rendered = f"""<!DOCTYPE html><html><body style="font-family:monospace;padding:2rem;color:#ef4444">
        <strong>Render error:</strong><pre>{escaped}</pre></body></html>"""
    return rendered.encode("utf-8")


# ─── HTTP Handler ────────────────────────────────────────────────────────────

class SeedDevHandler(SimpleHTTPRequestHandler):
    """HTTP handler that:
    - Serves /static/* in layers: lib static/ → theme static/ → project static/ (no copy)
    - Injects live-reload SSE snippet into HTML responses
    - Serves everything else from dist/
    """

    static_dir: Path = None        # project src/static/ dir
    theme_static_dir: Path = None  # theme static/ dir (optional)
    lib_static_dir: Path = None    # component lib static/ dir (optional, lowest priority)
    dev_state: dict = None         # mutable state dict shared with watcher

    def handle(self):
        try:
            super().handle()
        except ConnectionResetError:
            pass

    def do_GET(self):
        path = self.path.split("?")[0]

        # SSE endpoint for live reload
        if path == "/__reload":
            self._serve_reload_sse()
            return

        # SSE endpoint for help/explorer trigger
        if path == "/__help":
            self._serve_help_sse()
            return

        # Serve explorer.js static file
        if path == "/__help/explorer.js":
            js_path = SEED_ENGINE_DIR / "help" / "explorer.js"
            if js_path.is_file():
                data = js_path.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "application/javascript")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            else:
                self.send_error(404, "explorer.js not found")
            return

        # Component explorer — returns JSON
        if path == "/__components":
            data = build_components_json()
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        # Component preview (renders a seed snippet)
        if path == "/__preview":
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            code = qs.get("code", [""])[0]
            data = build_preview_html(code, self.dev_state or {})
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        # Serve user static files directly (no copy to dist)
        # Priority: project static/ > theme static/ > lib static/
        if path.startswith("/static/"):
            rel = path[len("/static/"):]
            static_file = self.static_dir / rel if self.static_dir else None
            theme_file = self.theme_static_dir / rel if self.theme_static_dir else None
            lib_file = self.lib_static_dir / rel if self.lib_static_dir else None
            if static_file and static_file.is_file():
                self._serve_static_file(static_file)
            elif theme_file and theme_file.is_file():
                self._serve_static_file(theme_file)
            elif lib_file and lib_file.is_file():
                self._serve_static_file(lib_file)
            else:
                self.send_error(404, f"Static file not found: {rel}")
            return

        # Serve HTML from dist/
        translated = Path(self.translate_path(path))
        if translated.is_dir():
            translated = translated / "index.html"
        if translated.is_file() and translated.suffix == ".html":
            self._serve_html(translated)
        else:
            super().do_GET()

    def _serve_reload_sse(self):
        """Serve SSE (Server-Sent Events) for live reload."""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.end_headers()
        try:
            last = reload_version
            while True:
                with reload_lock:
                    reload_lock.wait(timeout=30)
                if reload_version != last:
                    last = reload_version
                    self.wfile.write(b"data: reload\n\n")
                    self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, OSError):
            return

    def _serve_help_sse(self):
        """Serve SSE for triggering the component explorer overlay."""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.end_headers()
        try:
            last = help_version
            while True:
                with help_lock:
                    help_lock.wait(timeout=30)
                if help_version != last:
                    last = help_version
                    self.wfile.write(b"event: help\ndata: open\n\n")
                    self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, OSError):
            return

    def _serve_html(self, filepath: Path):
        data = filepath.read_bytes()
        data = data.replace(b"</body>", RELOAD_SNIPPET + b"\n" + HELP_SNIPPET + b"\n</body>")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _serve_static_file(self, filepath: Path):
        mime_type, _ = mimetypes.guess_type(str(filepath))
        mime_type = mime_type or "application/octet-stream"
        data = filepath.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", mime_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_request(self, code="-", size="-"):
        if self.path.split("?")[0] in ("/__reload", "/__help"):
            return
        now = time.strftime("%H:%M:%S")
        dev_print(f"  {now}  {code}  {self.path}")

    def log_error(self, format, *args):
        pass

    def log_message(self, format, *args):
        pass


# ─── File Watcher ────────────────────────────────────────────────────────────

_last_rebuild_time: dict = {}
_REBUILD_COOLDOWN = 1.0


def _debounce(key: str) -> bool:
    """Returns True if we should skip (too soon since last rebuild)."""
    now = time.time()
    if now - _last_rebuild_time.get(key, 0) < _REBUILD_COOLDOWN:
        return True
    _last_rebuild_time[key] = now
    return False


def _rebuild_full(state: dict, src_dir: Path, dist_dir: Path):
    """Clear include cache and rebuild all files. Uses current state['seed']."""
    state["seed"].renderer.clear_includes()
    build_all(state["seed"], src_dir, dist_dir)


def _make_seed_instance(folder: Path, theme_dir: Path | None, components_lib_dir: Path | None):
    """Create a fresh Seed instance with the current config."""
    Seed = _load_seed_class()
    src_components = folder / "src" / "components"
    return Seed(
        project_dir=folder,
        components_dir=src_components if src_components.exists() else None,
        theme_dir=theme_dir,
        components_lib_dir=components_lib_dir,
    )


def make_change_handler(state: dict, src_dir: Path, dist_dir: Path, project_dir: Path, observer_ref: list):
    """Create file change handler. state is a mutable dict with keys:
        'seed'               : current Seed instance
        'theme_dir'          : current active theme dir (Path | None)
        'components_lib_dir' : current active components lib dir (Path | None)
    observer_ref is a list holding the current Observer so it can be replaced on config change.
    """
    from watchdog.events import FileSystemEventHandler

    src_components = project_dir / "src" / "components"

    class ChangeHandler(FileSystemEventHandler):
        def _handle(self, event):
            if event.is_directory:
                return
            src_path = Path(event.src_path)
            if _debounce(str(src_path)):
                return

            # seed.yaml changed → recalculate config, recreate Seed, restart watchers
            if src_path.name == "seed.yaml" and src_path.parent == project_dir:
                dev_print("  seed.yaml changed — reloading config...")
                try:
                    new_theme_dir, new_components_lib_dir = _load_project_config(project_dir)
                    from seed.components import reload_components_yaml
                    reload_components_yaml(
                        components_dir=src_components if src_components.exists() else None,
                        theme_dir=new_theme_dir,
                        components_lib_dir=new_components_lib_dir,
                    )
                    old_theme_dir = state["theme_dir"]
                    old_components_lib_dir = state["components_lib_dir"]
                    state["theme_dir"] = new_theme_dir
                    state["components_lib_dir"] = new_components_lib_dir
                    state["seed"] = _make_seed_instance(project_dir, new_theme_dir, new_components_lib_dir)
                    _restart_lib_watches(observer_ref, handler,
                                        old_theme_dir, new_theme_dir,
                                        old_components_lib_dir, new_components_lib_dir)
                    _rebuild_full(state, src_dir, dist_dir)
                    parts = []
                    if new_theme_dir:
                        parts.append(f"theme: {new_theme_dir.name}")
                    if new_components_lib_dir:
                        parts.append(f"components: {new_components_lib_dir.name}")
                    dev_print(f"  rebuilt all ({', '.join(parts) if parts else 'no libs'})")
                    notify_reload()
                except Exception as e:
                    dev_print(f"  error reloading config: {e}")
                return

            if src_path.suffix == ".layout" and src_path.is_relative_to(src_dir):
                rel = src_path.relative_to(src_dir)
                dev_print(f"  layout changed: {rel}")
                try:
                    _rebuild_full(state, src_dir, dist_dir)
                    dev_print("  rebuilt all")
                    notify_reload()
                except Exception as e:
                    dev_print(f"  error: {e}")

            elif src_path.suffix == ".layout" and state["theme_dir"] and src_path.is_relative_to(state["theme_dir"]):
                dev_print(f"  theme layout changed: {src_path.name}")
                try:
                    _rebuild_full(state, src_dir, dist_dir)
                    dev_print("  rebuilt all")
                    notify_reload()
                except Exception as e:
                    dev_print(f"  error: {e}")

            elif src_path.suffix == ".seed" and src_path.is_relative_to(src_dir):
                rel = src_path.relative_to(src_dir)
                # Includes (_*.seed) may be used by many pages — rebuild all
                if src_path.stem.startswith("_"):
                    dev_print(f"  include changed: {rel}")
                    try:
                        _rebuild_full(state, src_dir, dist_dir)
                        dev_print("  rebuilt all")
                        notify_reload()
                    except Exception as e:
                        dev_print(f"  error: {e}")
                else:
                    dev_print(f"  changed {rel}")
                    try:
                        state["seed"].renderer.clear_includes()
                        build_file(state["seed"], src_path, src_dir, dist_dir)
                        dev_print(f"  rebuilt {rel}")
                        notify_reload()
                    except Exception as e:
                        dev_print(f"  error: {e}")

            elif src_path.suffix in (".yaml", ".design"):
                dev_print(f"  component changed: {src_path.name}")
                try:
                    from seed.components import reload_components_yaml
                    reload_components_yaml(
                        components_dir=src_components if src_components.exists() else None,
                        theme_dir=state["theme_dir"],
                        components_lib_dir=state["components_lib_dir"],
                    )
                    _rebuild_full(state, src_dir, dist_dir)
                    dev_print("  rebuilt all")
                    notify_reload()
                except Exception as e:
                    dev_print(f"  error: {e}")

            elif src_path.suffix == ".py":
                dev_print(f"  Python changed: {src_path.name} — restart required")
                python_restart_event.set()

        def on_modified(self, event):
            self._handle(event)

        def on_created(self, event):
            self._handle(event)

    handler = ChangeHandler()
    return handler


def _restart_lib_watches(
    observer_ref: list,
    handler,
    old_theme_dir: Path | None,
    new_theme_dir: Path | None,
    old_components_lib_dir: Path | None,
    new_components_lib_dir: Path | None,
):
    """Restart observer if theme or components lib directories changed."""
    if old_theme_dir == new_theme_dir and old_components_lib_dir == new_components_lib_dir:
        return
    observer = observer_ref[0]
    observer.stop()
    observer.join()
    from watchdog.observers import Observer
    new_observer = Observer()
    for path, recursive in observer_ref[1]:  # restore persistent watches
        new_observer.schedule(handler, path, recursive=recursive)
    if new_theme_dir and new_theme_dir.exists():
        new_observer.schedule(handler, str(new_theme_dir), recursive=True)
    if new_components_lib_dir and new_components_lib_dir.exists():
        new_observer.schedule(handler, str(new_components_lib_dir), recursive=True)
    new_observer.start()
    observer_ref[0] = new_observer


def watch(state: dict, src_dir: Path, dist_dir: Path, project_dir: Path):
    from watchdog.observers import Observer

    persistent_watches = []
    if src_dir.exists():
        persistent_watches.append((str(src_dir), True))
    src_components = project_dir / "src" / "components"
    if src_components.exists():
        persistent_watches.append((str(src_components), True))
    if SEED_ENGINE_DIR.exists():
        persistent_watches.append((str(SEED_ENGINE_DIR), True))
    # Watch project root for seed.yaml changes (non-recursive to avoid watching libs/)
    persistent_watches.append((str(project_dir), False))

    observer = Observer()
    observer_ref = [observer, persistent_watches]

    handler = make_change_handler(state, src_dir, dist_dir, project_dir, observer_ref)

    for path, recursive in persistent_watches:
        observer.schedule(handler, path, recursive=recursive)

    # Watch active libs
    if state.get("theme_dir") and state["theme_dir"].exists():
        observer.schedule(handler, str(state["theme_dir"]), recursive=True)
    if state.get("components_lib_dir") and state["components_lib_dir"].exists():
        observer.schedule(handler, str(state["components_lib_dir"]), recursive=True)

    observer.start()
    try:
        while not python_restart_event.is_set():
            time.sleep(0.5)
    finally:
        observer_ref[0].stop()
        observer_ref[0].join()


# ─── Commands ────────────────────────────────────────────────────────────────

INDEX_SEED_TEMPLATE = """\
---
title: Home
---
@h1
  Hello, World!

Welcome to your new Seed project.
"""

DEFAULT_LAYOUT_TEMPLATE = """\
---
title: My Site
---
@div: class=min-h-screen flex flex-col
  {content}
"""


def _parse_init_args(args):
    """Parse init args: <name> [--theme <src>] [--components <src>]
    Returns (name, theme_source, components_source).
    """
    if not args:
        return None, None, None
    name = args[0]
    theme_source = None
    components_source = None
    i = 1
    while i < len(args):
        if args[i] in ("--theme", "-t") and i + 1 < len(args):
            theme_source = args[i + 1]
            i += 2
        elif args[i] in ("--components", "-c") and i + 1 < len(args):
            components_source = args[i + 1]
            i += 2
        else:
            i += 1
    return name, theme_source, components_source


def cmd_init(args):
    name, theme_source, components_source = _parse_init_args(args)
    if not name:
        print("Usage: seed init <project-name> [--theme <path|github-url>] [--components <path|github-url>]")
        sys.exit(1)

    project_dir = Path(name)

    if project_dir.exists():
        print(f"Error: '{name}' already exists.")
        sys.exit(1)

    # Project structure
    (project_dir / "src").mkdir(parents=True)
    (project_dir / "src" / "components").mkdir()
    (project_dir / "src" / "static").mkdir()
    (project_dir / "libs" / "themes").mkdir(parents=True)
    (project_dir / "libs" / "components").mkdir(parents=True)

    # Starter files
    (project_dir / "src" / "default.layout").write_text(DEFAULT_LAYOUT_TEMPLATE, encoding="utf-8")
    (project_dir / "src" / "index.seed").write_text(INDEX_SEED_TEMPLATE, encoding="utf-8")

    # seed.yaml: start empty, populate after installs
    seed_config = {}

    print(f"Created project '{name}'")

    # Install theme if requested
    theme_installed = None
    if theme_source:
        libs_themes = project_dir / "libs" / "themes"
        src_path = Path(theme_source)
        dest_name = src_path.name if src_path.is_absolute() else theme_source.split("/")[-1].removesuffix(".git")
        print(f"Installing theme from '{theme_source}'...")
        try:
            theme_installed = _install_from_source(theme_source, libs_themes / dest_name)
            seed_config["theme"] = theme_installed
            print(f"  installed → libs/themes/{theme_installed}/")
        except Exception as e:
            print(f"  Error installing theme: {e}")

    # Install components lib if requested
    components_installed = None
    if components_source:
        libs_components = project_dir / "libs" / "components"
        src_path = Path(components_source)
        dest_name = src_path.name if src_path.is_absolute() else components_source.split("/")[-1].removesuffix(".git")
        print(f"Installing components from '{components_source}'...")
        try:
            components_installed = _install_from_source(components_source, libs_components / dest_name)
            seed_config["components"] = components_installed
            print(f"  installed → libs/components/{components_installed}/")
        except Exception as e:
            print(f"  Error installing components: {e}")

    # Auto-install seed-ui if --components was not passed
    if not components_source:
        libs_components = project_dir / "libs" / "components"
        seed_ui_url = "https://github.com/ssjunior/seed-ui"
        print(f"Installing seed-ui component library...")
        try:
            name_ui = _install_from_source(seed_ui_url, libs_components / "seed-ui")
            seed_config["components"] = name_ui
            print(f"  installed → libs/components/{name_ui}/")
        except Exception as e:
            print(f"  Warning: could not install seed-ui ({e})")
            print(f"  You can install it later with: seed components-install {name} {seed_ui_url}")
            if _ask_yes_no("  Continue without components?", default=True):
                pass
            else:
                print("  Aborted. Removing project directory.")
                import shutil as _shutil
                _shutil.rmtree(project_dir, ignore_errors=True)
                sys.exit(1)

    # Write seed.yaml
    if seed_config:
        _write_seed_yaml(project_dir, seed_config)
    else:
        (project_dir / "seed.yaml").write_text("# theme: <name>\n# components: <name>\n", encoding="utf-8")

    print()
    print("  seed.yaml              — config do projeto")
    print("  src/index.seed         — página inicial")
    print("  src/default.layout     — layout padrão")
    print("  src/components/        — componentes do projeto")
    print("  src/static/            — assets do projeto")
    print("  libs/themes/           — temas instalados")
    print("  libs/components/       — libs de componentes instaladas")
    print()
    print("Next steps:")
    if not theme_source:
        print(f"  seed theme-install {name} <path|github-url>")
    print(f"  seed dev {name}")


def cmd_theme_install(args):
    if len(args) < 2:
        print("Usage: seed theme-install <project> <path|github-url>")
        sys.exit(1)

    project_dir = Path(args[0]).resolve()
    source = args[1]

    if not (project_dir / "src").is_dir():
        print(f"Error: '{project_dir}' não é um projeto Seed válido (sem src/)")
        sys.exit(1)

    try:
        name = _install_lib("themes", project_dir, source)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

    if name:
        config = _read_seed_yaml(project_dir)
        config["theme"] = name
        _write_seed_yaml(project_dir, config)
        print(f"  updated seed.yaml: theme: {name}")


def cmd_components_install(args):
    if len(args) < 2:
        print("Usage: seed components-install <project> <path|github-url>")
        sys.exit(1)

    project_dir = Path(args[0]).resolve()
    source = args[1]

    if not (project_dir / "src").is_dir():
        print(f"Error: '{project_dir}' não é um projeto Seed válido (sem src/)")
        sys.exit(1)

    try:
        name = _install_lib("components", project_dir, source)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

    if name:
        config = _read_seed_yaml(project_dir)
        config["components"] = name
        _write_seed_yaml(project_dir, config)
        print(f"  updated seed.yaml: components: {name}")


def _cmd_lib_update(kind: str, args: list):
    key = "theme" if kind == "themes" else "components"
    if len(args) < 2:
        print(f"Usage: seed {key}-update <project> <path|github-url>")
        sys.exit(1)

    project_dir = Path(args[0]).resolve()
    source = args[1]

    if not (project_dir / "src").is_dir():
        print(f"Error: '{project_dir}' não é um projeto Seed válido (sem src/)")
        sys.exit(1)

    config = _read_seed_yaml(project_dir)
    lib_name = config.get(key)
    if not lib_name:
        print(f"Error: No {key} configured in seed.yaml")
        sys.exit(1)

    lib_dir = project_dir / "libs" / kind / lib_name
    if not lib_dir.is_dir():
        if not _ask_yes_no(f"  '{lib_name}' not found locally. Install it?", default=True):
            return

    print(f"Updating {key} '{lib_name}' from '{source}'...")
    try:
        _install_from_source(source, lib_dir)
        print(f"  Updated → libs/{kind}/{lib_name}/")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


def cmd_theme_update(args):
    _cmd_lib_update("themes", args)


def cmd_components_update(args):
    _cmd_lib_update("components", args)


def cmd_dev(args):
    if not args:
        print("Usage: seed dev <folder> [port]")
        sys.exit(1)

    folder = Path(args[0]).resolve()
    port = int(args[1]) if len(args) > 1 else 8000

    src_dir = folder / "src"
    dist_dir = folder / "dist"

    if not folder.is_dir():
        print(f"Error: '{folder}' is not a directory.")
        sys.exit(1)
    if not src_dir.is_dir():
        print(f"Error: '{src_dir}' not found. Is this a Seed project? (expected src/ folder)")
        sys.exit(1)

    try:
        theme_dir, components_lib_dir = _load_project_config(folder)
    except (ValueError, FileNotFoundError) as e:
        print(f"Error: {e}")
        sys.exit(1)

    dist_dir.mkdir(parents=True, exist_ok=True)

    seed_instance = _make_seed_instance(folder, theme_dir, components_lib_dir)

    # Mutable state shared with watcher
    state = {
        "seed": seed_instance,
        "theme_dir": theme_dir,
        "components_lib_dir": components_lib_dir,
    }

    print(f"Building {folder.name}...")
    if theme_dir:
        print(f"  theme: {theme_dir.name}")
    if components_lib_dir:
        print(f"  components: {components_lib_dir.name}")
    _rebuild_full(state, src_dir, dist_dir)
    print("Build complete.")
    print()

    # Build handler class with static dirs bound
    theme_static = theme_dir / "static" if theme_dir else None
    lib_static = components_lib_dir / "static" if components_lib_dir else None
    project_static = folder / "src" / "static"

    class Handler(SeedDevHandler):
        pass
    Handler.static_dir = project_static
    Handler.theme_static_dir = theme_static
    Handler.lib_static_dir = lib_static
    Handler.dev_state = state

    handler_factory = partial(Handler, directory=str(dist_dir))
    server = ThreadingHTTPServer(("0.0.0.0", port), handler_factory)
    server.daemon_threads = True

    watcher_thread = threading.Thread(
        target=watch,
        args=(state, src_dir, dist_dir, folder),
        daemon=True,
    )
    watcher_thread.start()

    import socket
    url = f"http://localhost:{port}"
    print(f"Serving at:")
    print(f"  Local:   {url}")
    try:
        local_ip = socket.gethostbyname(socket.gethostname())
        if local_ip and local_ip != "127.0.0.1":
            print(f"  Network: http://{local_ip}:{port}")
    except Exception:
        pass
    print("Press o to open, b to build, h to toggle component explorer, r to restart, q to quit")

    def handle_input():
        global _raw_mode
        import tty
        import termios
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            _raw_mode = True
            while True:
                if select.select([sys.stdin], [], [], 0.1)[0]:
                    key = sys.stdin.read(1).lower()
                    if key == "o":
                        try:
                            import subprocess
                            subprocess.run(["open", "-g", url], check=True)
                        except Exception:
                            webbrowser.open(url)
                    elif key == "b":
                        from seed.components import reload_components_yaml
                        src_components = folder / "src" / "components"
                        reload_components_yaml(
                            components_dir=src_components if src_components.exists() else None,
                            theme_dir=state["theme_dir"],
                            components_lib_dir=state["components_lib_dir"],
                        )
                        _rebuild_full(state, src_dir, dist_dir)
                        dev_print("  Built all.")
                        notify_reload()
                    elif key == "h":
                        dev_print("  Component explorer toggled.")
                        notify_help()
                    elif key == "r":
                        dev_print("  Restarting...")
                        _raw_mode = False
                        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
                        server.shutdown()
                        os.execv(sys.executable, [sys.executable] + sys.argv)
                    elif key in ("q", "\x03"):  # q or Ctrl+C
                        server.shutdown()
                        break
        finally:
            _raw_mode = False
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    input_thread = threading.Thread(target=handle_input, daemon=True)
    input_thread.start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()


def cmd_build(args):
    if not args:
        print("Usage: seed build <folder>")
        sys.exit(1)

    folder = Path(args[0]).resolve()
    src_dir = folder / "src"
    dist_dir = folder / "dist"

    if not folder.is_dir():
        print(f"Error: '{folder}' is not a directory.")
        sys.exit(1)
    if not src_dir.is_dir():
        print(f"Error: '{src_dir}' not found. Is this a Seed project?")
        sys.exit(1)

    try:
        theme_dir, components_lib_dir = _load_project_config(folder)
    except (ValueError, FileNotFoundError) as e:
        print(f"Error: {e}")
        sys.exit(1)

    # Clean dist/
    if dist_dir.exists():
        shutil.rmtree(dist_dir)
    dist_dir.mkdir(parents=True)

    seed_instance = _make_seed_instance(folder, theme_dir, components_lib_dir)

    print(f"Building {folder.name}...")
    if theme_dir:
        print(f"  theme: {theme_dir.name}")
    if components_lib_dir:
        print(f"  components: {components_lib_dir.name}")
    build_all(seed_instance, src_dir, dist_dir)

    # Copy static in layers: lib → theme → project → dist/static/
    theme_static = theme_dir / "static" if theme_dir else None
    lib_static = components_lib_dir / "static" if components_lib_dir else None
    project_static = folder / "src" / "static"
    copy_static_layered(dist_dir, project_static, theme_static, lib_static)
    if lib_static and lib_static.is_dir():
        print(f"  copied libs/components/{components_lib_dir.name}/static/ → dist/static/")
    if theme_static and theme_static.is_dir():
        print(f"  copied libs/themes/{theme_dir.name}/static/ → dist/static/")
    if project_static.is_dir() and any(project_static.iterdir()):
        print(f"  copied src/static/ → dist/static/")

    # Summary
    html_files = list(dist_dir.rglob("*.html"))
    total_size = sum(f.stat().st_size for f in dist_dir.rglob("*") if f.is_file())
    print()
    print(f"Build complete: {len(html_files)} HTML file(s), {total_size // 1024} KB total → dist/")


# ─── Entry point ─────────────────────────────────────────────────────────────

COMMANDS = {
    "init": cmd_init,
    "dev": cmd_dev,
    "build": cmd_build,
    "theme-install": cmd_theme_install,
    "theme-update": cmd_theme_update,
    "components-install": cmd_components_install,
    "components-update": cmd_components_update,
}


def main(argv: list[str] | None = None):
    args = argv if argv is not None else sys.argv[1:]
    cmd = args[0] if args else None
    if cmd not in COMMANDS:
        print("Usage: seed <command> [args]")
        print()
        print("  init <name> [--theme <src>] [--components <src>]   Create a new Seed project")
        print("  dev  <folder>                                       Start dev server with live reload")
        print("  build <folder>                                      Build for production")
        print("  theme-install <project> <src>                       Install or update a theme")
        print("  theme-update  <project> <src>                       Update installed theme from source")
        print("  components-install <project> <src>                  Install or update a component library")
        print("  components-update  <project> <src>                  Update installed component library from source")
        sys.exit(1)
    COMMANDS[cmd](args[1:])


if __name__ == "__main__":
    main()
