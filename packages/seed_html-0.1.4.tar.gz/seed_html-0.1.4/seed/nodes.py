from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Content:
    text: str
    line: int = 0


@dataclass
class RawContent:
    """Pre-rendered HTML — must be emitted as-is, never escaped."""
    html: str


@dataclass
class Component:
    name: str
    props: dict[str, Any] = field(default_factory=dict)
    children: list[Component | Content] = field(default_factory=list)
    line: int = 0


@dataclass
class Include:
    path: str
    line: int = 0


@dataclass
class Page:
    meta: dict[str, Any] = field(default_factory=dict)
    children: list[Component | Content | Include] = field(default_factory=list)
