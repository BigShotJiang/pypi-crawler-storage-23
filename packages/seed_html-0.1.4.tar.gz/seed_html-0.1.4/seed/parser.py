from __future__ import annotations

import yaml

from .errors import SeedError
from .lexer import Token, TokenType, tokenize
from .nodes import Component, Content, Include, Page


class Parser:
    def __init__(self, tokens: list[Token]):
        self.tokens = tokens
        self.pos = 0

    def current(self) -> Token:
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return self.tokens[-1]

    def advance(self) -> Token:
        tok = self.current()
        self.pos += 1
        return tok

    def expect(self, tt: TokenType) -> Token:
        tok = self.current()
        if tok.type != tt:
            raise SeedError(f"Expected {tt.name}, got {tok.type.name}", line=tok.line)
        return self.advance()

    def parse(self) -> Page:
        meta = {}
        if self.current().type == TokenType.HEADER:
            tok = self.advance()
            meta = yaml.safe_load(tok.value) or {}

        children = self._parse_children()
        return Page(meta=meta, children=children)

    def _parse_children(self) -> list:
        children = []
        content_lines = []

        def flush_content():
            if content_lines:
                text = "\n".join(content_lines)
                children.append(Content(text=text, line=content_lines[0][1] if isinstance(content_lines[0], tuple) else 0))
                content_lines.clear()

        while self.current().type not in (TokenType.EOF, TokenType.DEDENT):
            tok = self.current()

            if tok.type == TokenType.COMPONENT:
                flush_content()
                children.append(self._parse_component())

            elif tok.type == TokenType.CONTENT:
                tok = self.advance()
                content_lines.append(tok.value)

            elif tok.type == TokenType.INDENT:
                self.advance()
                nested = self._parse_children()
                if children and isinstance(children[-1], Component):
                    children[-1].children.extend(nested)
                else:
                    for item in nested:
                        if isinstance(item, Content):
                            content_lines.append(item.text)
                        else:
                            flush_content()
                            children.append(item)
                if self.current().type == TokenType.DEDENT:
                    self.advance()

            else:
                break

        if content_lines:
            text = "\n".join(content_lines)
            children.append(Content(text=text))

        return children

    def _parse_component(self) -> Component | Include:
        tok = self.advance()
        name = tok.name
        props = tok.props or {}
        line = tok.line

        if name == "include":
            # Support: @include path=file, @include file, @include: file
            path = props.get("path", "")
            if not path:
                # Treat first flag key as the path (e.g. @include _sidebar → {"_sidebar": True})
                for k, v in props.items():
                    if v is True:
                        path = k
                        break
            return Include(path=path, line=line)

        return Component(name=name, props=props, line=line)


def parse(source: str) -> Page:
    tokens = tokenize(source)
    return Parser(tokens).parse()
