# Seed

Seed is a Python framework that compiles `.seed` files into static HTML.

It includes:
- A lexer/parser/renderer pipeline for `.seed`
- YAML + `.design` component system
- Layouts and includes
- CLI commands for init, dev server, and build

## Install

```bash
python -m pip install seed
```

## CLI

```bash
seed init my-site
seed dev my-site
seed build my-site
```

## Python API

```python
from seed import Seed

engine = Seed()
html = engine.render_string("@h1\n  Hello", full_page=True)
```

## Development

```bash
python -m pip install -e ".[dev]"
python -m pytest tests -v
```

## License

MIT. See `LICENSE`.
