from seed.parser import parse
from seed.nodes import Component, Content, Include


class TestParser:
    def test_empty(self):
        page = parse("")
        assert page.meta == {}
        assert page.children == []

    def test_header(self):
        page = parse("---\ntitle: Test\ntemplate: base\n---\n")
        assert page.meta["title"] == "Test"
        assert page.meta["template"] == "base"

    def test_simple_component(self):
        page = parse("@hero: centered, bg=primary")
        assert len(page.children) == 1
        hero = page.children[0]
        assert isinstance(hero, Component)
        assert hero.name == "hero"
        assert hero.props["centered"] is True
        assert hero.props["bg"] == "primary"

    def test_component_with_content(self):
        source = "@hero:\n  # Title\n  Some text."
        page = parse(source)
        hero = page.children[0]
        assert isinstance(hero, Component)
        assert len(hero.children) == 1
        assert isinstance(hero.children[0], Content)
        assert "# Title" in hero.children[0].text

    def test_nested_components(self):
        source = "@hero:\n  @button: href=/go\n    Click"
        page = parse(source)
        hero = page.children[0]
        assert isinstance(hero, Component)
        assert len(hero.children) == 1
        btn = hero.children[0]
        assert isinstance(btn, Component)
        assert btn.name == "button"
        assert btn.props["href"] == "/go"
        assert len(btn.children) == 1
        assert isinstance(btn.children[0], Content)

    def test_mixed_children(self):
        source = "@hero:\n  # Title\n  @button: href=/go\n    Click\n  More text."
        page = parse(source)
        hero = page.children[0]
        assert len(hero.children) == 3
        assert isinstance(hero.children[0], Content)
        assert isinstance(hero.children[1], Component)
        assert isinstance(hero.children[2], Content)

    def test_include(self):
        page = parse("@include: path=fragments/navbar")
        assert len(page.children) == 1
        assert isinstance(page.children[0], Include)
        assert page.children[0].path == "fragments/navbar"

    def test_deep_nesting(self):
        source = "@hero:\n  @columns: count=2\n    @column:\n      # Title\n      @button: href=/go\n        Click"
        page = parse(source)
        hero = page.children[0]
        cols = hero.children[0]
        assert cols.name == "columns"
        col = cols.children[0]
        assert col.name == "column"
        assert len(col.children) == 2
        assert isinstance(col.children[0], Content)
        assert isinstance(col.children[1], Component)

    def test_sibling_components(self):
        source = "@hero: centered\n  # Title\n\n@section:\n  ## Next"
        page = parse(source)
        assert len(page.children) == 2
        assert page.children[0].name == "hero"
        assert page.children[1].name == "section"

    def test_responsive_props(self):
        source = "@features: columns=3, columns.md=2, columns.sm=1"
        page = parse(source)
        feat = page.children[0]
        assert feat.props["columns"] == "3"
        assert feat.props["columns.md"] == "2"
        assert feat.props["columns.sm"] == "1"
