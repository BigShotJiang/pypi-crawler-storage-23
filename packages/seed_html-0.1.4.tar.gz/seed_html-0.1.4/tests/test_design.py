"""Tests for the design system (component folders with .design files)"""
from pathlib import Path

import pytest

from seed import Seed
from seed.components import (
    _design_cache,
    _registry,
    _extract_slots,
    _load_component_folder,
    get_design,
    get_design_slot_names,
    has_design,
    reload_components_yaml,
)


def _make_component_folder(tmp_path, name, yaml_content, designs: dict[str, str]):
    """Helper: create a component folder with yaml and .design files"""
    folder = tmp_path / name
    folder.mkdir()

    yaml_file = folder / f"{name}.yaml"
    yaml_file.write_text(yaml_content, encoding="utf-8")

    for design_name, design_content in designs.items():
        design_file = folder / f"{design_name}.design"
        design_file.write_text(design_content, encoding="utf-8")

    return folder


class TestDesignLoading:
    def test_load_component_folder_with_yaml_and_design(self, tmp_path):
        """Loading a component folder registers YAML config and parses .design files"""
        folder = _make_component_folder(
            tmp_path,
            "mycomp",
            "mycomp:\n  tag: section\n  class: my-class\n",
            {"mycomp": "@div class=wrapper\n  {title}\n  {children}"},
        )

        _load_component_folder(folder)

        assert "mycomp" in _registry
        assert _registry["mycomp"]["tag"] == "section"
        assert has_design("mycomp")
        assert get_design("mycomp", "default") is not None

    def test_load_design_variant(self, tmp_path):
        """Design files with names different from folder become named variants"""
        folder = _make_component_folder(
            tmp_path,
            "mycomp",
            "mycomp:\n  tag: div\n  class: base\n",
            {
                "mycomp": "@div class=default-layout\n  {title}",
                "compact": "@div class=compact-layout\n  {title}",
            },
        )

        _load_component_folder(folder)

        assert get_design("mycomp", "default") is not None
        assert get_design("mycomp", "compact") is not None

    def test_get_design_falls_back_to_default(self, tmp_path):
        """get_design falls back to 'default' when requested variant doesn't exist"""
        folder = _make_component_folder(
            tmp_path,
            "mycomp",
            "mycomp:\n  tag: div\n  class: base\n",
            {"mycomp": "@div\n  {title}"},
        )

        _load_component_folder(folder)

        design = get_design("mycomp", "nonexistent")
        assert design is not None

    def teardown_method(self):
        _design_cache.clear()
        reload_components_yaml()


class TestSlotExtraction:
    def test_extract_slots_from_design(self, tmp_path):
        """Slot names are extracted from {placeholder} in Content nodes"""
        folder = _make_component_folder(
            tmp_path,
            "mycomp",
            "mycomp:\n  tag: div\n  class: base\n",
            {"mycomp": "@div\n  @h1\n    {title}\n  @p\n    {description}\n  {cta}"},
        )

        _load_component_folder(folder)

        slots = get_design_slot_names("mycomp")
        assert "title" in slots
        assert "description" in slots
        assert "cta" in slots

    def test_extract_children_slot(self, tmp_path):
        """The {children} placeholder is also a valid slot"""
        folder = _make_component_folder(
            tmp_path,
            "mycomp",
            "mycomp:\n  tag: div\n  class: base\n",
            {"mycomp": "@div\n  {title}\n  {children}"},
        )

        _load_component_folder(folder)

        slots = get_design_slot_names("mycomp")
        assert "title" in slots
        assert "children" in slots

    def teardown_method(self):
        _design_cache.clear()
        reload_components_yaml()


class TestDesignWithTmpComponents:
    """Test design system with temporary component folders"""

    def test_render_with_custom_design(self, tmp_path):
        """Custom component folder with design renders correctly"""
        folder = _make_component_folder(
            tmp_path,
            "banner",
            "banner:\n  tag: div\n  class: banner-wrapper\n",
            {"banner": "@div class=inner\n  @h2\n    {title}\n  @div class=body\n    {children}"},
        )

        _load_component_folder(folder)

        seed = Seed()
        source = (
            "@banner\n"
            "  @title\n"
            "    Hello Banner\n"
            "  Some body content\n"
        )
        html = seed.render_string(source)

        assert "banner-wrapper" in html
        assert "inner" in html
        assert "Hello Banner" in html
        assert "Some body content" in html

    def test_children_catch_all(self, tmp_path):
        """Children not matching any slot go to {children} catch-all"""
        folder = _make_component_folder(
            tmp_path,
            "wrapper",
            "wrapper:\n  tag: div\n  class: wrap\n",
            {"wrapper": "@div class=header\n  {title}\n@div class=body\n  {children}"},
        )

        _load_component_folder(folder)

        seed = Seed()
        source = (
            "@wrapper\n"
            "  @title\n"
            "    My Title\n"
            "  @button\n"
            "    Click\n"
            "  Some text\n"
        )
        html = seed.render_string(source)

        assert "My Title" in html
        assert "Click" in html
        assert "Some text" in html

    def test_unfilled_slot_is_empty(self, tmp_path):
        """Slots not filled by user produce empty string (no leftover placeholder)"""
        folder = _make_component_folder(
            tmp_path,
            "card",
            "card:\n  tag: div\n  class: card\n",
            {"card": "@div\n  @h2\n    {title}\n  @p\n    {description}\n  {cta}"},
        )

        _load_component_folder(folder)

        seed = Seed()
        source = "@card\n  @title\n    Only Title\n"
        html = seed.render_string(source)

        assert "Only Title" in html
        assert "{description}" not in html
        assert "{cta}" not in html

    def test_design_variant(self, tmp_path):
        """design= prop selects an alternate design template"""
        folder = _make_component_folder(
            tmp_path,
            "card",
            "card:\n  tag: div\n  class: card\n  variant:\n    dark: bg-gray-900\n",
            {
                "card": "@div class=default-card\n  {title}",
                "compact": "@div class=compact-card\n  {title}",
            },
        )

        _load_component_folder(folder)

        seed = Seed()
        html = seed.render_string("@card design=compact\n  @title\n    Hello\n")
        assert "compact-card" in html
        assert "Hello" in html

    def teardown_method(self):
        _design_cache.clear()
        reload_components_yaml()
