from pathlib import Path

from seed import Seed


class TestRenderer:
    def setup_method(self):
        self.seed = Seed()

    def test_unregistered_component_renders_as_tag(self):
        html = self.seed.render_string("@div: class=wrapper\n  Hello")
        assert "<div" in html
        assert "wrapper" in html
        assert "Hello" in html

    def test_nested_unregistered_components(self):
        source = "@div: class=outer\n  @span: class=inner\n    Text"
        html = self.seed.render_string(source)
        assert "<div" in html
        assert "<span" in html
        assert "Text" in html

    def test_markdown_rendering(self):
        source = "@div:\n  **bold** and *italic*"
        html = self.seed.render_string(source)
        assert "<strong>bold</strong>" in html
        assert "<em>italic</em>" in html

    def test_inline_components(self):
        source = "@div:\n  Use {tag warning}cuidado{/tag} aqui."
        html = self.seed.render_string(source)
        assert "warning" in html
        assert "cuidado" in html

    def test_header_meta(self):
        source = "---\ntitle: Test\ntemplate: base\n---\n@div\n  Hello"
        page = self.seed.parse(source)
        assert page.meta["title"] == "Test"
        html = self.seed.render_string(source)
        assert "Hello" in html

    def test_empty_string(self):
        html = self.seed.render_string("")
        assert html == ""

    def test_code_fence_renders_as_code(self):
        source = "@div:\n  ```\n  @hero: bg=primary\n  ```"
        html = self.seed.render_string(source)
        assert "<code>" in html or "<code " in html
        assert "@hero: bg=primary" in html

    def test_plain_content(self):
        html = self.seed.render_string("Just some text.")
        assert "Just some text." in html

    def test_markdown_in_component(self):
        source = "@div:\n  **bold** and _italic_"
        html = self.seed.render_string(source)
        assert "<strong>bold</strong>" in html
        assert "<em>italic</em>" in html

    def test_render_file(self, tmp_path):
        seed_file = tmp_path / "test.seed"
        seed_file.write_text("@div: class=wrapper\n  Hello")
        html = self.seed.render_file(seed_file)
        assert "wrapper" in html
        assert "Hello" in html

    def test_props_become_attributes(self):
        html = self.seed.render_string('@a: href=/home\n  Home')
        assert 'href="/home"' in html
        assert "Home" in html

    def test_img_self_closing(self):
        html = self.seed.render_string('@img: src=/logo.png, alt=Logo')
        assert 'src="/logo.png"' in html
        assert 'alt="Logo"' in html


class TestFullPage:
    def setup_method(self):
        self.seed = Seed()

    def test_full_page_has_html_structure(self):
        source = "---\ntitle: My Page\nlang: pt-BR\ncss: /style.css\njs: /main.js\n---\n@div\n  Hello"
        html = self.seed.render_string(source, full_page=True)
        assert "<!DOCTYPE html>" in html
        assert '<html lang="pt-BR">' in html
        assert "<title>My Page</title>" in html
        assert "/style.css" in html
        assert "/main.js" in html
        assert "Hello" in html

    def test_full_page_defaults(self):
        source = "@div:\n  Hello"
        html = self.seed.render_string(source, full_page=True)
        assert '<html lang="en">' in html
        assert "<title></title>" in html

    def test_full_page_false_no_doctype(self):
        source = "@div:\n  Hello"
        html = self.seed.render_string(source, full_page=False)
        assert "<!DOCTYPE" not in html

    def test_render_file_full_page(self, tmp_path):
        seed_file = tmp_path / "test.seed"
        seed_file.write_text("---\ntitle: File Test\n---\n@div\n  Content")
        html = self.seed.render_file(seed_file, full_page=True)
        assert "<!DOCTYPE html>" in html
        assert "<title>File Test</title>" in html
        assert "Content" in html


class TestIncludes:
    def test_include_resolves_from_file(self, tmp_path):
        navbar = tmp_path / "navbar.seed"
        navbar.write_text("@nav: class=main-nav\n  @a: href=/\n    Home")

        index = tmp_path / "index.seed"
        index.write_text("@include: path=navbar\n@div:\n  Content")

        seed = Seed()
        html = seed.render_file(index)
        assert "main-nav" in html
        assert "Home" in html
        assert "Content" in html

    def test_include_not_found_renders_comment(self):
        source = "@include: path=missing\n@div:\n  Content"
        seed = Seed()
        html = seed.render_string(source)
        assert "<!-- include: missing -->" in html
        assert "Content" in html


class TestBuild:
    def test_build_creates_output(self, tmp_path):
        src = tmp_path / "src"
        src.mkdir()
        seed_file = src / "index.seed"
        seed_file.write_text("---\ntitle: Build Test\n---\n@div\n  Hello")

        output = tmp_path / "output"
        seed = Seed()
        result = seed.build(seed_file, output)

        assert result.exists()
        assert (output / "index.html").exists()

        html = (output / "index.html").read_text()
        assert "<!DOCTYPE html>" in html
        assert "Build Test" in html
