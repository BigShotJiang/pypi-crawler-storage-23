from seed.lexer import tokenize, parse_props, TokenType


class TestParseProps:
    def test_key_value(self):
        assert parse_props("key=value") == {"key": "value"}

    def test_flag(self):
        assert parse_props("centered") == {"centered": True}

    def test_mixed(self):
        result = parse_props("centered, bg=primary")
        assert result == {"centered": True, "bg": "primary"}

    def test_quoted(self):
        result = parse_props('title="Meu Título"')
        assert result == {"title": "Meu Título"}

    def test_responsive(self):
        result = parse_props("columns=3, columns.md=2, columns.sm=1")
        assert result == {"columns": "3", "columns.md": "2", "columns.sm": "1"}

    def test_empty(self):
        assert parse_props("") == {}
        assert parse_props("   ") == {}


class TestTokenize:
    def test_header(self):
        source = "---\ntitle: Test\n---\n"
        tokens = tokenize(source)
        assert tokens[0].type == TokenType.HEADER
        assert "title: Test" in tokens[0].value

    def test_component(self):
        source = "@hero: centered, bg=primary"
        tokens = tokenize(source)
        comp = [t for t in tokens if t.type == TokenType.COMPONENT][0]
        assert comp.name == "hero"
        assert comp.props == {"centered": True, "bg": "primary"}

    def test_bare_component(self):
        source = "@column"
        tokens = tokenize(source)
        comp = [t for t in tokens if t.type == TokenType.COMPONENT][0]
        assert comp.name == "column"
        assert comp.props == {}

    def test_indentation(self):
        source = "@hero:\n  # Title\n  @button: href=/go\n    Click"
        tokens = tokenize(source)
        types = [t.type for t in tokens]
        assert TokenType.INDENT in types
        assert TokenType.DEDENT in types

    def test_content(self):
        source = "# Hello\nSome text here."
        tokens = tokenize(source)
        content_tokens = [t for t in tokens if t.type == TokenType.CONTENT]
        assert len(content_tokens) == 2
        assert content_tokens[0].value == "# Hello"

    def test_eof(self):
        tokens = tokenize("")
        assert tokens[-1].type == TokenType.EOF

    def test_nested_components(self):
        source = "@hero:\n  @columns:\n    @column:\n      # Title"
        tokens = tokenize(source)
        comps = [t for t in tokens if t.type == TokenType.COMPONENT]
        assert len(comps) == 3
        assert comps[0].name == "hero"
        assert comps[1].name == "columns"
        assert comps[2].name == "column"

    def test_code_fence_escapes_components(self):
        source = "```\n@hero: bg=primary\n```"
        tokens = tokenize(source)
        types = [t.type for t in tokens]
        assert TokenType.COMPONENT not in types
        content_tokens = [t for t in tokens if t.type == TokenType.CONTENT]
        assert len(content_tokens) == 3
        assert content_tokens[1].value == "@hero: bg=primary"

    def test_unclosed_header(self):
        import pytest
        from seed.errors import SeedError
        with pytest.raises(SeedError):
            tokenize("---\ntitle: Test\n")
