"""Tests for the theme/components lib system."""
from pathlib import Path

import pytest

from seed import Seed
from seed.components import reload_components_yaml, _registry, _design_cache
from seed.cli import _load_project_config, copy_static_layered


# ─── Fixtures ────────────────────────────────────────────────────────────────

def _make_project(tmp_path: Path, with_src_layout=True) -> Path:
    """Create a minimal project structure (new layout: src/ contains everything user-owned)."""
    project = tmp_path / "project"
    (project / "src" / "components").mkdir(parents=True)
    (project / "src" / "static").mkdir()
    (project / "libs" / "themes").mkdir(parents=True)
    (project / "libs" / "components").mkdir(parents=True)
    if with_src_layout:
        (project / "src" / "default.layout").write_text(
            "---\ntitle: Test\n---\n@div\n  {content}\n", encoding="utf-8"
        )
    (project / "src" / "index.seed").write_text(
        "---\ntitle: Home\n---\nHello from index.\n", encoding="utf-8"
    )
    return project


def _make_theme(project: Path, name="seed-blog-theme") -> Path:
    """Create a minimal theme inside project/libs/themes/<name>/."""
    theme = project / "libs" / "themes" / name
    (theme / "components").mkdir(parents=True)
    (theme / "layouts").mkdir()
    (theme / "includes").mkdir()
    (theme / "static").mkdir()

    (theme / "layouts" / "default.layout").write_text(
        "---\ntitle: Theme Layout\n---\n@div: class=theme-wrapper\n  {content}\n",
        encoding="utf-8",
    )
    (theme / "layouts" / "blog.layout").write_text(
        "---\ntitle: Blog Layout\n---\n@div: class=blog-wrapper\n  {content}\n",
        encoding="utf-8",
    )
    (theme / "includes" / "_header.seed").write_text(
        "@header: class=theme-header\n  Blog Header\n", encoding="utf-8"
    )
    (theme / "includes" / "_footer.seed").write_text(
        "@footer: class=theme-footer\n  Blog Footer\n", encoding="utf-8"
    )
    (theme / "static" / "blog.css").write_text("/* theme css */\n", encoding="utf-8")
    (theme / "components" / "themecard.yaml").write_text(
        "themecard:\n  tag: article\n  class: theme-card\n", encoding="utf-8"
    )
    return theme


def _make_components_lib(project: Path, name="seed-ui") -> Path:
    """Create a minimal component lib inside project/libs/components/<name>/."""
    lib = project / "libs" / "components" / name
    (lib / "components").mkdir(parents=True)
    (lib / "components" / "libbutton.yaml").write_text(
        "libbutton:\n  tag: button\n  class: lib-button\n", encoding="utf-8"
    )
    return lib


def _write_seed_yaml(project: Path, **kwargs):
    import yaml
    (project / "seed.yaml").write_text(
        yaml.dump(kwargs, allow_unicode=True), encoding="utf-8"
    )


@pytest.fixture(autouse=True)
def reset_components():
    """Reset component registry before each test."""
    reload_components_yaml()
    yield
    reload_components_yaml()


# ─── 1. Sem tema — regressão ─────────────────────────────────────────────────

class TestNoTheme:
    def test_render_without_theme(self, tmp_path):
        project = _make_project(tmp_path)
        seed = Seed(project_dir=project)
        html = seed.render_file(project / "src" / "index.seed", full_page=True)
        assert "Hello from index." in html

    def test_layout_walkup_finds_src_layout(self, tmp_path):
        project = _make_project(tmp_path)
        seed = Seed(project_dir=project)
        html = seed.render_file(project / "src" / "index.seed", full_page=True)
        assert "Hello from index." in html

    def test_no_theme_dir_attribute(self, tmp_path):
        project = _make_project(tmp_path)
        seed = Seed(project_dir=project)
        assert seed.theme_dir is None
        assert seed.components_lib_dir is None


# ─── 2. Com tema ─────────────────────────────────────────────────────────────

class TestWithTheme:
    def test_theme_default_layout_used_when_no_src_layout(self, tmp_path):
        project = _make_project(tmp_path, with_src_layout=False)
        theme = _make_theme(project)
        seed = Seed(project_dir=project, theme_dir=theme)
        html = seed.render_file(project / "src" / "index.seed", full_page=True)
        assert "theme-wrapper" in html

    def test_explicit_layout_from_front_matter_uses_theme(self, tmp_path):
        project = _make_project(tmp_path, with_src_layout=False)
        theme = _make_theme(project)
        (project / "src" / "post.seed").write_text(
            "---\ntitle: Post\nlayout: blog\n---\nPost content.\n", encoding="utf-8"
        )
        seed = Seed(project_dir=project, theme_dir=theme)
        html = seed.render_file(project / "src" / "post.seed", full_page=True)
        assert "blog-wrapper" in html
        assert "Post content." in html

    def test_src_layout_takes_priority_over_theme(self, tmp_path):
        project = _make_project(tmp_path, with_src_layout=True)
        theme = _make_theme(project)
        seed = Seed(project_dir=project, theme_dir=theme)
        html = seed.render_file(project / "src" / "index.seed", full_page=True)
        assert "theme-wrapper" not in html

    def test_include_fallback_to_theme(self, tmp_path):
        project = _make_project(tmp_path, with_src_layout=False)
        theme = _make_theme(project)
        (project / "src" / "index.seed").write_text(
            "@include _header\nHello.\n", encoding="utf-8"
        )
        seed = Seed(project_dir=project, theme_dir=theme)
        html = seed.render_file(project / "src" / "index.seed")
        assert "theme-header" in html
        assert "Blog Header" in html

    def test_project_include_takes_priority_over_theme(self, tmp_path):
        project = _make_project(tmp_path, with_src_layout=False)
        theme = _make_theme(project)
        (project / "src" / "_header.seed").write_text(
            "@header: class=project-header\n  Project Header\n", encoding="utf-8"
        )
        (project / "src" / "index.seed").write_text(
            "@include _header\nHello.\n", encoding="utf-8"
        )
        seed = Seed(project_dir=project, theme_dir=theme)
        html = seed.render_file(project / "src" / "index.seed")
        assert "project-header" in html
        assert "theme-header" not in html

    def test_theme_component_loaded(self, tmp_path):
        project = _make_project(tmp_path, with_src_layout=False)
        theme = _make_theme(project)
        (project / "src" / "index.seed").write_text(
            "@themecard\n  Card content.\n", encoding="utf-8"
        )
        seed = Seed(project_dir=project, theme_dir=theme)
        html = seed.render_file(project / "src" / "index.seed")
        assert "theme-card" in html

    def test_project_component_merges_with_theme(self, tmp_path):
        """Project component merges with theme component (registry uses merge=True)."""
        project = _make_project(tmp_path, with_src_layout=False)
        theme = _make_theme(project)
        (project / "src" / "components" / "themecard.yaml").write_text(
            "themecard:\n  tag: section\n  class: project-card\n", encoding="utf-8"
        )
        (project / "src" / "index.seed").write_text(
            "@themecard\n  Content.\n", encoding="utf-8"
        )
        seed = Seed(project_dir=project, theme_dir=theme)
        html = seed.render_file(project / "src" / "index.seed")
        assert "project-card" in html
        assert "theme-card" in html


# ─── 3. Com lib de componentes ───────────────────────────────────────────────

class TestWithComponentsLib:
    def test_components_lib_loaded(self, tmp_path):
        project = _make_project(tmp_path, with_src_layout=False)
        lib = _make_components_lib(project)
        (project / "src" / "index.seed").write_text(
            "@libbutton\n  Click\n", encoding="utf-8"
        )
        seed = Seed(project_dir=project, components_lib_dir=lib)
        html = seed.render_file(project / "src" / "index.seed")
        assert "lib-button" in html

    def test_project_component_overrides_lib(self, tmp_path):
        project = _make_project(tmp_path, with_src_layout=False)
        lib = _make_components_lib(project)
        (project / "src" / "components" / "libbutton.yaml").write_text(
            "libbutton:\n  tag: a\n  class: project-button\n", encoding="utf-8"
        )
        (project / "src" / "index.seed").write_text(
            "@libbutton\n  Click\n", encoding="utf-8"
        )
        seed = Seed(project_dir=project, components_lib_dir=lib)
        html = seed.render_file(project / "src" / "index.seed")
        assert "project-button" in html


# ─── 4. Walk-up limitado ao src_dir ──────────────────────────────────────────

class TestWalkupLimited:
    def test_layout_outside_src_not_captured(self, tmp_path):
        """Layout in project root (outside src/) is not captured by walk-up."""
        project = _make_project(tmp_path, with_src_layout=False)
        (project / "default.layout").write_text(
            "---\ntitle: Outer\n---\n@div: class=outer-layout\n  {content}\n",
            encoding="utf-8",
        )
        seed = Seed(project_dir=project)
        html = seed.render_file(project / "src" / "index.seed", full_page=False)
        assert "outer-layout" not in html


# ─── 5. Cache de includes ────────────────────────────────────────────────────

class TestIncludeCache:
    def test_includes_cleared_between_renders(self, tmp_path):
        project = _make_project(tmp_path, with_src_layout=False)
        theme = _make_theme(project)
        (project / "src" / "index.seed").write_text(
            "@include _header\nHello.\n", encoding="utf-8"
        )
        seed = Seed(project_dir=project, theme_dir=theme)
        seed.render_file(project / "src" / "index.seed")
        assert len(seed.renderer.includes) > 0

        seed.renderer.clear_includes()
        assert len(seed.renderer.includes) == 0
        assert len(seed.renderer._include_paths) == 0

    def test_same_include_name_resolves_correctly(self, tmp_path):
        project = _make_project(tmp_path, with_src_layout=False)
        theme = _make_theme(project)
        (project / "src" / "_header.seed").write_text(
            "@span: class=proj-hdr\n  ProjectHeader\n", encoding="utf-8"
        )
        seed = Seed(project_dir=project, theme_dir=theme)
        (project / "src" / "index.seed").write_text("@include _header\n", encoding="utf-8")
        html = seed.render_file(project / "src" / "index.seed")
        assert "proj-hdr" in html
        assert "theme-header" not in html


# ─── 6. Troca de tema ────────────────────────────────────────────────────────

class TestThemeSwitch:
    def test_reload_components_clears_old_theme(self, tmp_path):
        theme_a = tmp_path / "theme_a"
        (theme_a / "components").mkdir(parents=True)
        (theme_a / "components" / "compA.yaml").write_text(
            "compA:\n  tag: div\n  class: comp-a\n", encoding="utf-8"
        )
        theme_b = tmp_path / "theme_b"
        (theme_b / "components").mkdir(parents=True)
        (theme_b / "components" / "compB.yaml").write_text(
            "compB:\n  tag: div\n  class: comp-b\n", encoding="utf-8"
        )

        reload_components_yaml(theme_dir=theme_a)
        assert "compA" in _registry
        assert "compB" not in _registry

        reload_components_yaml(theme_dir=theme_b)
        assert "compB" in _registry
        assert "compA" not in _registry


# ─── 7. Erros amigáveis ──────────────────────────────────────────────────────

class TestErrors:
    def test_seed_yaml_invalid_not_a_dict(self, tmp_path):
        project = _make_project(tmp_path)
        (project / "seed.yaml").write_text("- item1\n- item2\n", encoding="utf-8")
        with pytest.raises(ValueError, match="mapeamento YAML"):
            _load_project_config(project)

    def test_seed_yaml_theme_not_found(self, tmp_path):
        project = _make_project(tmp_path)
        _write_seed_yaml(project, theme="nonexistent")
        with pytest.raises(FileNotFoundError, match="nonexistent"):
            _load_project_config(project)

    def test_seed_yaml_path_traversal_rejected(self, tmp_path):
        project = _make_project(tmp_path)
        _write_seed_yaml(project, theme="../escape")
        with pytest.raises(ValueError, match="inválido"):
            _load_project_config(project)

    def test_seed_yaml_relative_path_with_separator_rejected(self, tmp_path):
        project = _make_project(tmp_path)
        _write_seed_yaml(project, theme="sub/mytheme")
        with pytest.raises(ValueError, match="inválido"):
            _load_project_config(project)

    def test_no_seed_yaml_returns_none(self, tmp_path):
        project = _make_project(tmp_path)
        theme_dir, components_lib_dir = _load_project_config(project)
        assert theme_dir is None
        assert components_lib_dir is None

    def test_seed_yaml_no_theme_key_returns_none(self, tmp_path):
        project = _make_project(tmp_path)
        (project / "seed.yaml").write_text("other_key: value\n", encoding="utf-8")
        theme_dir, components_lib_dir = _load_project_config(project)
        assert theme_dir is None
        assert components_lib_dir is None


# ─── 8. Static skip silencioso ───────────────────────────────────────────────

class TestStaticLayered:
    def test_no_theme_static_no_error(self, tmp_path):
        dist = tmp_path / "dist"
        dist.mkdir()
        project_static = tmp_path / "static"
        project_static.mkdir()
        theme_static = tmp_path / "theme_static_nonexistent"
        copy_static_layered(dist, project_static, theme_static)

    def test_theme_static_copied_to_dist(self, tmp_path):
        dist = tmp_path / "dist"
        dist.mkdir()
        project_static = tmp_path / "static"
        project_static.mkdir()
        theme_static = tmp_path / "theme_static"
        theme_static.mkdir()
        (theme_static / "theme.css").write_text("/* theme */", encoding="utf-8")

        copy_static_layered(dist, project_static, theme_static)
        assert (dist / "static" / "theme.css").is_file()

    def test_project_static_overrides_theme(self, tmp_path):
        dist = tmp_path / "dist"
        dist.mkdir()
        theme_static = tmp_path / "theme_static"
        theme_static.mkdir()
        (theme_static / "style.css").write_text("/* theme */", encoding="utf-8")
        project_static = tmp_path / "static"
        project_static.mkdir()
        (project_static / "style.css").write_text("/* project */", encoding="utf-8")

        copy_static_layered(dist, project_static, theme_static)
        content = (dist / "static" / "style.css").read_text()
        assert "/* project */" in content

    def test_both_missing_no_dist_static_created(self, tmp_path):
        dist = tmp_path / "dist"
        dist.mkdir()
        project_static = tmp_path / "static"
        project_static.mkdir()
        theme_static = tmp_path / "theme_no_static"

        copy_static_layered(dist, project_static, theme_static)
        assert not (dist / "static").exists()
