"""Analyzer registry (P4)."""
