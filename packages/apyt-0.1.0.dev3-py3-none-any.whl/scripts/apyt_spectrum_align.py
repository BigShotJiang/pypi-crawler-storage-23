"""
Wrapper entry point for the `spectrum_align.py` command-line script.
"""
#
#
def main():
    import apyt_cli.spectrum_align
