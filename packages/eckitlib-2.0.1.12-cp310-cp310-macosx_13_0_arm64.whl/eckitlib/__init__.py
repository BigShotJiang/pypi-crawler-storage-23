__version__ = '2.0.1.12'
__commit_hash__ = '4deb67e8267f7d31edc049b816e84eeb904ff61f'
findlibs_dependencies = []
