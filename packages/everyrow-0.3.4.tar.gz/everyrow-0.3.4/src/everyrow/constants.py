DEFAULT_EVERYROW_APP_URL = "https://everyrow.io"
DEFAULT_EVERYROW_API_URL = "https://everyrow.io/api/v0"


class EveryrowError(Exception): ...
