# aam-py

A Python implementation of the Abstract Alias Mapping Language (AAML) parser and configuration system.
