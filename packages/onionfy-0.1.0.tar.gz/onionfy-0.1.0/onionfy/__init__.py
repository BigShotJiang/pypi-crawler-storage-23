# onionfy/__init__.py
from .client import OnionClient

__version__ = "0.1.0"
