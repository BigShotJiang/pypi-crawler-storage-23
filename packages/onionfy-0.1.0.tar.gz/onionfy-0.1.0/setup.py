# setup.py
from setuptools import setup, find_packages

setup(
    name="onionfy",
    version="0.1.0",
    packages=find_packages(),
    package_data={
        'onionfy': ['onionfy.conf', 'geoip/geoip', 'geoip/geoip6', 'geoip/torrc'],
    },
    install_requires=[
        "requests[socks]"
    ],
    description="ProxyChains alternative for Windows - Route any Python code through Tor",
    author="mohammedcha",
    python_requires='>=3.8',
)
