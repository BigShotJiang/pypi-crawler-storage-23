# Core operations tests package
