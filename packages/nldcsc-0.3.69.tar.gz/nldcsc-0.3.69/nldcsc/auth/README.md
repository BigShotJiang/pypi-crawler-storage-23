## Authentication (auth)

#### expected environment variables and defaults

```python
# LDAP CLIENT:

# Does the flask app need to run in debug mode
LDAP_CACERTFILE = os.getenv("LDAP_CACERTFILE", None) # optional
```