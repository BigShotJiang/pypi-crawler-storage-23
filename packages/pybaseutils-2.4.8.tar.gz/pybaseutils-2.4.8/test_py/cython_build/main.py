# -*- coding: utf-8 -*-
"""
    @Author : PKing
    @E-mail : 
    @Date   : 2023-09-20 08:50:00
    @Brief  :
"""
from fun_sum import sum

if __name__ == '__main__':
    s = sum(1, 2)
    print(s)
