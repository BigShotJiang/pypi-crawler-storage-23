"""Backtesting and cross-validation module"""

from autotsforecast.backtesting.validator import BacktestValidator

__all__ = ["BacktestValidator"]