"""PactKit - Spec-driven agentic DevOps toolkit."""

__version__ = "1.4.0"
