## Summary

<!-- Brief description of what this PR does -->

## Changes

<!-- Bullet list of changes -->

## Test Plan

- [ ] All existing tests pass
- [ ] New tests added for new functionality
- [ ] Manual verification completed

## Related Issues

<!-- Link to related issues: Fixes #123, Closes #456 -->
