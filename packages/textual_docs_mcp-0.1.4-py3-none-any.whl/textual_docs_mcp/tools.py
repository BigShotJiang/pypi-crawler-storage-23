"""MCP tool implementations for the textual-docs-mcp server.

Each function in this module corresponds to an MCP tool registered in
:mod:`textual_docs_mcp.server`.  Functions are intentionally thin: they
delegate all retrieval/search logic to
:class:`~textual_docs_mcp.search.BM25Search`.
"""

from __future__ import annotations

import contextlib
import json
import logging
import subprocess
import sys
from pathlib import Path
from typing import Any

from textual_docs_mcp.constants import MAX_CONTENT_CHARS, MAX_SEARCH_RESULTS
from textual_docs_mcp.models import Category, DocEntry, SearchResult
from textual_docs_mcp.search import BM25Search

logger = logging.getLogger(__name__)

# Path to the bundle metadata
_DATA_DIR = Path(__file__).parent / "data"
_METADATA_FILE = _DATA_DIR / "bundle_metadata.json"


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------


def _relative_label(path: Path) -> str:
    """Return a short, human-readable relative path label."""
    parts = path.parts
    # Trim to the last three path components for brevity
    return "/".join(parts[-3:]) if len(parts) >= 3 else str(path)


def _format_search_results(query: str, results: list[SearchResult]) -> str:
    """Render a list of :class:`SearchResult` objects as Markdown text."""
    if not results:
        return (
            f"No results found for **{query}**.\n\n"
            "Try `list_guides` or `list_widgets` to browse available topics."
        )

    lines: list[str] = [f'## Search Results for "{query}"\n']
    for rank, result in enumerate(results, start=1):
        entry = result.entry
        label = _relative_label(entry.path)
        lines.append(f"### {rank}. {entry.title}")
        lines.append(f"**Category:** `{entry.category.value}` | **File:** `{label}`\n")
        lines.append(result.snippet)
        lines.append("\n---\n")

    return "\n".join(lines)


def _format_doc_entry(entry: DocEntry, max_chars: int = MAX_CONTENT_CHARS) -> str:
    """Render a :class:`DocEntry` as full Markdown content (truncated if needed)."""
    content = entry.content
    truncated = len(content) > max_chars
    if truncated:
        content = content[:max_chars]

    header = (
        f"# {entry.title}\n\n"
        f"**Category:** `{entry.category.value}` | **File:** `{_relative_label(entry.path)}`"
        "\n\n---\n\n"
    )
    footer = (
        "\n\n> *Content truncated. Use a more specific query to retrieve further sections.*"
        if truncated
        else ""
    )
    return header + content + footer


def _format_entry_list(entries: list[DocEntry], heading: str) -> str:
    """Format a list of :class:`DocEntry` objects as a Markdown catalogue."""
    if not entries:
        return f"No entries found for category: {heading}"

    lines: list[str] = [f"## {heading}\n"]
    for entry in entries:
        lines.append(f"- **{entry.title}** (`{entry.slug}`)")
        if entry.excerpt:
            first_line = entry.excerpt.splitlines()[0][:120]
            lines.append(f"  {first_line}")
    return "\n".join(lines)


def _not_found_message(name: str, category: Category, searcher: BM25Search) -> str:
    """Build a helpful "not found" message with similar entries."""
    available = searcher.list_by_category(category)
    suggestions = ", ".join(f"`{e.slug}`" for e in available[:10])
    return (
        f"No {category.value} documentation found for **{name!r}**.\n\n"
        f"Available {category.value}s: {suggestions}\n\n"
        "Use `list_guides` or `list_widgets` for a full catalogue."
    )


# ---------------------------------------------------------------------------
# Tool functions
# ---------------------------------------------------------------------------


def search_textual_docs(
    searcher: BM25Search,
    query: str,
    category: str | None = None,
    max_results: int = 5,
) -> str:
    """Search across all Textual documentation, guides, examples, and API references.

    This is the primary discovery tool.  Use it when you need to find relevant
    documentation for a concept, widget, CSS property, or task.

    Parameters
    ----------
    query:
        Natural-language query, e.g. ``"how to handle key events"``,
        ``"DataTable row selection"``, ``"CSS layout grid"``.
    category:
        Optional filter.  One of: ``guide``, ``widget``, ``api``,
        ``event``, ``style``, ``css_type``, ``how_to``, ``example``,
        ``tutorial``, ``reference``, ``faq``.
    max_results:
        Number of results to return (1–20, default 5).
    """
    cat: Category | None = None
    if category:
        try:
            cat = Category(category)
        except ValueError:
            valid = [c.value for c in Category]
            return f"Unknown category '{category}'. Valid options: {', '.join(valid)}"

    capped = min(max(1, max_results), MAX_SEARCH_RESULTS)
    results = searcher.search(query, max_results=capped, category=cat)
    return _format_search_results(query, results)


def get_guide(searcher: BM25Search, guide_name: str) -> str:
    """Retrieve the full content of a specific Textual guide.

    Guides explain core concepts such as layouts, events, reactivity,
    CSS, workers, screens, and more.

    Parameters
    ----------
    guide_name:
        Guide slug or human-readable name, e.g. ``"layout"``,
        ``"events"``, ``"reactivity"``, ``"workers"``, ``"screens"``,
        ``"styles"``, ``"actions"``, ``"animation"``, ``"design"``.
        Call ``list_guides`` first if you are unsure of the exact name.
    """
    entry = searcher.fuzzy_get(guide_name, category=Category.GUIDE)
    if entry is None:
        return _not_found_message(guide_name, Category.GUIDE, searcher)
    return _format_doc_entry(entry)


def get_widget_docs(searcher: BM25Search, widget_name: str) -> str:
    """Retrieve complete documentation for a specific Textual widget.

    Covers widget purpose, constructor options, CSS pseudo-classes,
    reactive attributes, messages/events it emits, and usage examples.

    Parameters
    ----------
    widget_name:
        Widget name or slug, e.g. ``"Button"``, ``"DataTable"``,
        ``"Input"``, ``"TextArea"``, ``"ListView"``, ``"Tree"``.
        Call ``list_widgets`` first if you are unsure of the exact name.
    """
    entry = searcher.fuzzy_get(widget_name, category=Category.WIDGET)
    if entry is None:
        return _not_found_message(widget_name, Category.WIDGET, searcher)
    return _format_doc_entry(entry)


def get_code_examples(
    searcher: BM25Search,
    topic: str,
    max_results: int = 3,
) -> str:
    """Find and return Textual Python code examples relevant to a topic.

    Examples are real, runnable scripts taken from the Textual repository and
    demonstrate idiomatic usage of the framework.

    Parameters
    ----------
    topic:
        Topic or widget name to search for, e.g. ``"calculator"``,
        ``"DataTable"``, ``"async workers"``, ``"CSS animation"``.
    max_results:
        Number of example files to return (1–10, default 3).
    """
    capped = min(max(1, max_results), 10)
    results = searcher.search(topic, max_results=capped, category=Category.EXAMPLE)

    if not results:
        return (
            f"No code examples found for **{topic}**.\n\n"
            "Try `search_textual_docs` with a broader query."
        )

    lines: list[str] = [f'## Code Examples for "{topic}"\n']
    for rank, result in enumerate(results, start=1):
        entry = result.entry
        label = _relative_label(entry.path)
        lines.append(f"### {rank}. `{label}`\n")
        lines.append(f"```python\n{entry.content[: MAX_CONTENT_CHARS // capped]}\n```\n")
        if len(entry.content) > MAX_CONTENT_CHARS // capped:
            lines.append("> *File truncated for brevity.*\n")

    return "\n".join(lines)


def list_guides(searcher: BM25Search) -> str:
    """List all available Textual guide topics.

    Returns the full catalogue of guides with their slugs and brief
    descriptions.  Use a slug with ``get_guide`` to fetch the full content.
    """
    guides = searcher.list_by_category(Category.GUIDE)
    tutorials = searcher.list_by_category(Category.TUTORIAL)
    how_tos = searcher.list_by_category(Category.HOW_TO)

    sections: list[str] = []
    if guides:
        sections.append(_format_entry_list(guides, "Guides"))
    if tutorials:
        sections.append(_format_entry_list(tutorials, "Tutorials"))
    if how_tos:
        sections.append(_format_entry_list(how_tos, "How-To Articles"))

    if not sections:
        return "No guides found in the index."

    return "\n\n".join(sections)


def list_widgets(searcher: BM25Search) -> str:
    """List all available Textual widget documentation pages.

    Returns the full widget catalogue with slugs and brief descriptions.
    Use a slug with ``get_widget_docs`` to fetch the full documentation.
    """
    widgets = searcher.list_by_category(Category.WIDGET)
    return _format_entry_list(widgets, "Textual Widgets")


def get_textual_overview(searcher: BM25Search) -> str:
    """Return a high-level overview of the Textual framework.

    Covers what Textual is, its key concepts, and where to start.
    Ideal as a first call when starting to build a Textual TUI application.
    """
    # Prefer getting_started guide
    entry = (
        searcher.get_by_slug("getting_started")
        or searcher.get_by_slug("getting-started")
        or searcher.fuzzy_get("getting started")
    )
    if entry:
        return _format_doc_entry(entry)

    # Fallback: run a broad search
    results = searcher.search("what is textual how to get started", max_results=3)
    if results:
        return _format_search_results("Textual overview / getting started", results)

    return (
        "**Textual** is a Python framework for building rich terminal (TUI) applications.\n\n"
        "Use `list_guides` to explore available documentation topics, or "
        "`search_textual_docs` to look up specific features."
    )


# ---------------------------------------------------------------------------
# Bundle management tools
# ---------------------------------------------------------------------------


def check_bundle_status() -> str:
    """Check if the documentation bundle is up-to-date with upstream Textual.

    This tool checks if there are updates available in the Textual repository
    since the bundle was last built. If updates are available, you should run
    `python scripts/build_bundle.py` to rebuild.

    Returns
    -------
    str
        Status message indicating if the bundle is current or needs updating.
    """
    # Load current metadata
    metadata: dict[str, Any] = {}
    if _METADATA_FILE.exists():
        with contextlib.suppress(json.JSONDecodeError, OSError):
            metadata = json.loads(_METADATA_FILE.read_text())

    current_commit = metadata.get("commit")
    built_at = metadata.get("built_at")
    entry_count = metadata.get("entry_count")

    # Get upstream commit
    textual_repo_url = "https://github.com/Textualize/textual.git"
    try:
        result = subprocess.run(  # noqa: S603
            ["git", "ls-remote", textual_repo_url, "HEAD"],  # noqa: S607
            capture_output=True,
            text=True,
            check=True,
            timeout=30,
        )
        upstream_commit = result.stdout.split()[0]
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, IndexError):
        return (
            "## Bundle Status\n\n"
            "**Error:** Could not fetch upstream commit from GitHub.\n\n"
            f"**Current bundle:**\n"
            f"- Commit: `{current_commit[:12] if current_commit else 'unknown'}`\n"
            f"- Built: {built_at or 'unknown'}\n"
            f"- Entries: {entry_count or 'unknown'}"
        )

    # Compare
    if current_commit is None:
        status = "⚠️ **Unknown** - No metadata found (bundle may be from older version)"
        needs_update = True
    elif current_commit == upstream_commit:
        status = "✅ **Up-to-date**"
        needs_update = False
    else:
        status = "🔄 **Update available**"
        needs_update = True

    lines = [
        "## Bundle Status\n",
        f"**Status:** {status}\n",
        f"**Current commit:** `{current_commit[:12] if current_commit else 'none'}`",
        f"**Upstream commit:** `{upstream_commit[:12]}`",
        f"**Built at:** {built_at or 'unknown'}",
        f"**Entry count:** {entry_count or 'unknown'}",
    ]

    if needs_update:
        lines.extend(
            [
                "\n---\n",
                "To update the bundle, run:",
                "```bash",
                "python scripts/build_bundle.py --force",
                "```",
            ]
        )

    return "\n".join(lines)


def update_bundle() -> str:
    """Trigger an update of the documentation bundle.

    This runs the bundle build script to fetch the latest Textual documentation
    and rebuild the embedded knowledge. Only rebuilds if upstream has changes
    (unless the bundle is already up-to-date).

    **Note:** This operation may take 30-60 seconds as it clones the Textual
    repository and indexes all documentation.

    Returns
    -------
    str
        Result of the update operation.
    """
    # Find the script path
    script_path = Path(__file__).parent.parent.parent / "scripts" / "build_bundle.py"
    if not script_path.exists():
        return (
            "## Update Failed\n\n"
            "**Error:** build_bundle.py script not found.\n\n"
            "This tool requires the full source installation. "
            "If installed via pip/uvx, update by reinstalling the package."
        )

    try:
        result = subprocess.run(  # noqa: S603
            [sys.executable, str(script_path), "--force"],
            capture_output=True,
            text=True,
            timeout=300,  # 5 minute timeout
            check=False,
        )

        if result.returncode == 0:
            # Read updated metadata
            metadata: dict[str, Any] = {}
            if _METADATA_FILE.exists():
                with contextlib.suppress(json.JSONDecodeError, OSError):
                    metadata = json.loads(_METADATA_FILE.read_text())

            return (
                "## Bundle Update Complete\n\n"
                "✅ Successfully rebuilt the documentation bundle.\n\n"
                f"**Commit:** `{metadata.get('commit', 'unknown')[:12]}`\n"
                f"**Entries:** {metadata.get('entry_count', 'unknown')}\n"
                f"**Built:** {metadata.get('built_at', 'now')}\n\n"
                "The MCP server will use the new documentation on the next request."
            )
        else:
            return (
                "## Update Failed\n\n"
                f"**Exit code:** {result.returncode}\n\n"
                f"**stderr:**\n```\n{result.stderr[-1000:]}\n```"
            )

    except subprocess.TimeoutExpired:
        return (
            "## Update Timeout\n\n"
            "**Error:** Build script timed out after 5 minutes.\n\n"
            "Try running manually: `python scripts/build_bundle.py --force`"
        )
    except OSError as e:
        return f"## Update Failed\n\n**Error:** {e}"
