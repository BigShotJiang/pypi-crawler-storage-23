"""textual-docs-mcp: MCP server for Textual TUI library documentation."""

__version__ = "0.1.4"
__all__ = ["__version__"]
