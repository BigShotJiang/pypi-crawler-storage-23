"""TTS provider registry and auto-detection."""

from __future__ import annotations

import os
import platform
import shutil
from collections.abc import Callable
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from punt_vox.types import TTSProvider

__all__ = [
    "DEFAULT_VOICES",
    "auto_detect_provider",
    "format_voice_hint",
    "get_provider",
]

# Canonical default voice per provider, used in help text.
# Must stay in sync with each provider's default_voice property.
DEFAULT_VOICES: dict[str, str] = {
    "elevenlabs": "matilda",
    "polly": "joanna",
    "openai": "nova",
    "say": "samantha",
    "espeak": "en",
}


def format_voice_hint(names: list[str], limit: int = 10) -> str:
    """Format a truncated voice list for error messages."""
    sample = names[:limit]
    hint = ", ".join(sample)
    if len(names) > limit:
        hint += f" ... ({len(names)} total)"
    return hint


# Registry mapping provider name → factory callable.
# Factories are lazy (no imports at module level) to avoid loading
# boto3/openai/etc when the provider isn't used.
# Factories accept **kwargs to allow provider-specific options (e.g. model).
PROVIDER_REGISTRY: dict[str, Callable[..., TTSProvider]] = {}


def _register_polly(**kwargs: str | None) -> TTSProvider:
    from punt_vox.providers.polly import PollyProvider

    return PollyProvider()


def _register_openai(**kwargs: str | None) -> TTSProvider:
    from punt_vox.providers.openai import OpenAIProvider

    model = kwargs.get("model")
    return OpenAIProvider(model=model)


def _register_elevenlabs(**kwargs: str | None) -> TTSProvider:
    from punt_vox.providers.elevenlabs import ElevenLabsProvider

    model = kwargs.get("model")
    return ElevenLabsProvider(model=model)


def _register_say(**kwargs: str | None) -> TTSProvider:
    from punt_vox.providers.say import SayProvider

    return SayProvider()


def _register_espeak(**kwargs: str | None) -> TTSProvider:
    from punt_vox.providers.espeak import EspeakProvider

    return EspeakProvider()


PROVIDER_REGISTRY["polly"] = _register_polly
PROVIDER_REGISTRY["openai"] = _register_openai
PROVIDER_REGISTRY["elevenlabs"] = _register_elevenlabs
PROVIDER_REGISTRY["say"] = _register_say
PROVIDER_REGISTRY["espeak"] = _register_espeak


def auto_detect_provider() -> str:
    """Detect the provider from environment.

    Checks TTS_PROVIDER env var first, then probes for API keys:
    ElevenLabs > OpenAI > system fallback. On macOS, falls back to
    say; on Linux, falls back to espeak-ng if installed. Final
    fallback is polly (requires AWS credentials).
    """
    env = os.environ.get("TTS_PROVIDER")
    if env:
        return env.lower()
    if os.environ.get("ELEVENLABS_API_KEY"):
        return "elevenlabs"
    if os.environ.get("OPENAI_API_KEY"):
        return "openai"
    if platform.system() == "Darwin" and shutil.which("say"):
        return "say"
    if platform.system() == "Linux" and (
        shutil.which("espeak-ng") or shutil.which("espeak")
    ):
        return "espeak"
    return "polly"


def get_provider(name: str | None = None, **kwargs: str | None) -> TTSProvider:
    """Look up a provider by name, or auto-detect.

    Args:
        name: Provider name (e.g. 'polly', 'openai'). If None, auto-detects.
        **kwargs: Provider-specific options (e.g. model='tts-1-hd').

    Returns:
        An initialized TTSProvider instance.

    Raises:
        ValueError: If the provider name is not registered.
    """
    resolved = name.lower() if name is not None else auto_detect_provider()
    factory = PROVIDER_REGISTRY.get(resolved)
    if factory is None:
        available = ", ".join(sorted(PROVIDER_REGISTRY))
        msg = f"Unknown provider '{resolved}'. Available: {available}"
        raise ValueError(msg)
    return factory(**kwargs)
