"""FastMCP server for punt-vox."""

from __future__ import annotations

import json
import logging
import random
import re
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from punt_vox import __version__
from punt_vox.core import TTSClient
from punt_vox.ephemeral import clean_ephemeral, ephemeral_output_dir
from punt_vox.logging_config import configure_logging
from punt_vox.output import default_output_dir
from punt_vox.playback import enqueue as _enqueue_audio
from punt_vox.providers import get_provider
from punt_vox.types import (
    AudioProviderId,
    MergeStrategy,
    SynthesisRequest,
    SynthesisResult,
    TTSProvider,
    VoiceNotFoundError,
    generate_filename,
    result_to_dict,
    validate_language,
)

logger = logging.getLogger(__name__)

mcp = FastMCP(
    "vox",
    instructions=(
        "TTS is a text-to-speech engine. Use these tools to speak text aloud, "
        "generate audio files, and create language-learning pairs.\n\n"
        "When a stop hook blocks with a ♪ phrase (e.g. '♪ Speaking my thoughts...'), "
        "first use the Read tool to read .vox/config.md and check the vibe, "
        "vibe_mode, and vibe_signals fields. If vibe_mode is 'manual', treat "
        "vibe as your primary mood hint. If vibe_mode is 'auto' and "
        "vibe_signals is non-empty, interpret those signals to pick mood. Then "
        "write 1-2 sentences summarizing what you completed and call the speak "
        'tool with ephemeral=true and vibe_tags="[tag1] [tag2]" to set mood '
        "and speak in one call. No other output."
    ),
)
mcp._mcp_server.version = __version__  # pyright: ignore[reportPrivateUsage]


def _validate_voice_settings(
    stability: float | None,
    similarity: float | None,
    style: float | None,
) -> None:
    """Validate ElevenLabs voice settings are in 0.0-1.0 range."""
    for name, value in [
        ("stability", stability),
        ("similarity", similarity),
        ("style", style),
    ]:
        if value is not None and not 0.0 <= value <= 1.0:
            msg = f"{name} must be between 0.0 and 1.0, got {value}"
            raise ValueError(msg)


_VOICE_EXCUSES = [
    "is temporarily indisposed",
    "is grabbing something to eat",
    "stepped out for a coffee",
    "is in the bathroom",
]

_VOICE_BLURBS: dict[tuple[str, str], str] = {
    # ElevenLabs (popular English voices)
    ("elevenlabs", "matilda"): (
        "Warm and thoughtful — sounds like she read the docs before answering"
    ),
    ("elevenlabs", "aria"): (
        "Bright and clear — could narrate your life and you'd keep listening"
    ),
    ("elevenlabs", "roger"): (
        "Steady and reassuring — the voice you want explaining turbulence"
    ),
    ("elevenlabs", "charlie"): ("Relaxed and genuine — telling you this over coffee"),
    ("elevenlabs", "drew"): (
        "Eloquent and calm — thinks before speaking, every word lands"
    ),
    ("elevenlabs", "sarah"): (
        "Poised and articulate — boardroom-ready but never stiff"
    ),
    ("elevenlabs", "laura"): (
        "Expressive and warm — brings stories to life without trying"
    ),
    ("elevenlabs", "george"): (
        "Rich and composed — could read a phone book and make it interesting"
    ),
    ("elevenlabs", "jessica"): (
        "Friendly and upbeat — makes everything sound like good news"
    ),
    ("elevenlabs", "river"): (
        "Calm and unhurried — late-night radio host who never rushes"
    ),
    ("elevenlabs", "lily"): ("Gentle and precise — the quiet expert in the room"),
    ("elevenlabs", "callum"): (
        "Crisp and energetic — always slightly ahead of schedule"
    ),
    # OpenAI (all 9)
    ("openai", "nova"): ("Balanced and versatile — the reliable all-rounder"),
    ("openai", "alloy"): ("Neutral and clear — gets out of the way of the words"),
    ("openai", "echo"): ("Deep and measured — gravitas without the drama"),
    ("openai", "fable"): ("Warm and expressive — born to tell stories"),
    ("openai", "onyx"): ("Low and authoritative — the voice of serious announcements"),
    ("openai", "shimmer"): ("Bright and airy — light on its feet"),
    ("openai", "coral"): ("Smooth and natural — easy to listen to for hours"),
    ("openai", "sage"): ("Thoughtful and steady — wisdom in every syllable"),
    ("openai", "ash"): ("Grounded and direct — no frills, all substance"),
    # Polly (popular English voices)
    ("polly", "joanna"): ("Clear and professional — the classic narrator"),
    ("polly", "matthew"): ("Warm and conversational — a newscast you'd actually watch"),
    ("polly", "ruth"): ("Confident and modern — neural voice with presence"),
    ("polly", "amy"): ("British and crisp — the voice of polished documentation"),
}


def _voice_not_found_message(exc: VoiceNotFoundError) -> str:
    """Build a friendly, brand-appropriate message for an unknown voice."""
    excuse = random.choice(_VOICE_EXCUSES)
    suggestions = random.sample(exc.available, min(3, len(exc.available)))
    return f"{exc.voice_name} {excuse}. How about {', '.join(suggestions)}?"


def _resolve_output_dir(output_dir: str | None, *, ephemeral: bool = False) -> Path:
    """Resolve an output directory, using the default if not specified.

    When *ephemeral* is True, returns the ephemeral `.vox/` directory
    in the current working directory and ignores *output_dir*.
    """
    if ephemeral:
        clean_ephemeral()
        return ephemeral_output_dir()
    if output_dir:
        return Path(output_dir)
    return default_output_dir()


def _resolve_output_path(
    output_path: str | None, output_dir: Path, default_name: str
) -> Path:
    """Resolve an output file path."""
    if output_path:
        return Path(output_path)
    return output_dir / default_name


def _resolve_voice_and_language(
    provider: TTSProvider,
    voice: str | None,
    language: str | None,
) -> tuple[str, str | None]:
    """Resolve voice and language from MCP tool input.

    Priority: explicit voice > session voice > language default > provider default.

    If only language is provided, selects the provider's default voice for it.
    If only voice is provided, infers language from the voice (best-effort).
    If both, validates compatibility.
    """
    if language is not None:
        language = validate_language(language)

    if voice is None:
        voice = _read_session_voice()

    if voice is None and language is not None:
        voice = provider.get_default_voice(language)
    elif voice is None:
        voice = provider.default_voice

    if language is not None:
        provider.resolve_voice(voice, language)
    else:
        provider.resolve_voice(voice)
        language = provider.infer_language_from_voice(voice)

    return voice, language


_VIBE_TAGS_RE = re.compile(r'^vibe_tags:\s*"?([^"\n]*)"?\s*$', re.MULTILINE)
_VOICE_RE = re.compile(r'^voice:\s*"?([^"\n]*)"?\s*$', re.MULTILINE)
_CONFIG_PATH = Path(".vox/config.md")


def _read_session_voice() -> str | None:
    """Read the session voice from .vox/config.md, or None if unset."""
    if not _CONFIG_PATH.exists():
        return None
    text = _CONFIG_PATH.read_text()
    match = _VOICE_RE.search(text)
    if match and match.group(1).strip():
        return match.group(1).strip()
    return None


def _read_vibe_tags() -> str | None:
    """Read expressive tags from .vox/config.md, or None if unset."""
    if not _CONFIG_PATH.exists():
        return None
    text = _CONFIG_PATH.read_text()
    match = _VIBE_TAGS_RE.search(text)
    if match and match.group(1).strip():
        return match.group(1).strip()
    return None


_LEADING_TAG_RE = re.compile(r"^\s*\[[^\]\n]+\]")


def _apply_vibe(text: str, *, expressive_tags: bool) -> str:
    """Prepend session vibe tags to text if the provider supports them.

    Only providers whose ``supports_expressive_tags`` is True interpret
    bracketed tags as performance cues. Other providers would speak
    them as literal words.

    Skips prepending when the text already starts with an expression
    tag (e.g. ``[calm]``) to avoid doubling.
    """
    if not expressive_tags:
        return text
    tags = _read_vibe_tags()
    if tags and not _LEADING_TAG_RE.match(text):
        return f"{tags} {text}"
    return text


ALLOWED_CONFIG_KEYS: frozenset[str] = frozenset(
    {
        "notify",
        "speak",
        "voice",
        "voice_enabled",
        "vibe",
        "vibe_tags",
        "vibe_mode",
        "vibe_signals",
    }
)

_CLOSING_FENCE_RE = re.compile(r"\n---\s*$", re.MULTILINE)


def _write_config_field(key: str, value: str) -> None:
    """Write a single YAML frontmatter field to .vox/config.md.

    Updates the field in-place if present, or inserts it before the
    closing ``---`` if absent. Creates the file with minimal frontmatter
    if it does not exist.
    """
    if key not in ALLOWED_CONFIG_KEYS:
        allowed = ", ".join(sorted(ALLOWED_CONFIG_KEYS))
        msg = f"Unknown config key '{key}'. Allowed: {allowed}"
        raise ValueError(msg)

    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)

    replacement = f'{key}: "{value}"'

    if not _CONFIG_PATH.exists():
        _CONFIG_PATH.write_text(f"---\n{replacement}\n---\n")
        return

    text = _CONFIG_PATH.read_text()
    field_re = re.compile(rf"^{re.escape(key)}:\s*\"?[^\"\n]*\"?\s*$", re.MULTILINE)

    if field_re.search(text):
        text = field_re.sub(replacement, text)
    elif _CLOSING_FENCE_RE.search(text):
        text = _CLOSING_FENCE_RE.sub(f"\n{replacement}\n---", text, count=1)
    else:
        logger.warning("Malformed config (no closing ---): %s", _CONFIG_PATH)
        text = f"---\n{replacement}\n---\n"

    _CONFIG_PATH.write_text(text)
    logger.info("Config: set %s = %r in %s", key, value, _CONFIG_PATH)


def _write_config_fields(updates: dict[str, str]) -> None:
    """Write multiple YAML frontmatter fields in a single read-write cycle.

    Reads the file once, applies all regex substitutions, writes once.
    All keys are validated before any I/O so a single bad key aborts
    the entire batch.
    """
    for key in updates:
        if key not in ALLOWED_CONFIG_KEYS:
            allowed = ", ".join(sorted(ALLOWED_CONFIG_KEYS))
            msg = f"Unknown config key '{key}'. Allowed: {allowed}"
            raise ValueError(msg)

    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)

    if not _CONFIG_PATH.exists():
        lines = [f'{k}: "{v}"' for k, v in updates.items()]
        _CONFIG_PATH.write_text("---\n" + "\n".join(lines) + "\n---\n")
        return

    text = _CONFIG_PATH.read_text()
    for key, value in updates.items():
        replacement = f'{key}: "{value}"'
        field_re = re.compile(rf"^{re.escape(key)}:\s*\"?[^\"\n]*\"?\s*$", re.MULTILINE)
        if field_re.search(text):
            text = field_re.sub(replacement, text)
        elif _CLOSING_FENCE_RE.search(text):
            text = _CLOSING_FENCE_RE.sub(f"\n{replacement}\n---", text, count=1)
        else:
            logger.warning("Malformed config (no closing ---): %s", _CONFIG_PATH)
            lines = [f'{k}: "{v}"' for k, v in updates.items()]
            text = "---\n" + "\n".join(lines) + "\n---\n"
            break

    _CONFIG_PATH.write_text(text)
    for key, value in updates.items():
        logger.info("Config: set %s = %r in %s", key, value, _CONFIG_PATH)


def _cached_result(
    provider: TTSProvider, request: SynthesisRequest, output_path: Path
) -> SynthesisResult:
    """Build a cached AudioResult without calling the provider."""
    provider_id = AudioProviderId(provider.name)
    return SynthesisResult(
        path=output_path,
        text=request.text,
        provider=provider_id,
        voice=request.voice,
        language=request.language,
        metadata=request.metadata,
    )


@mcp.tool()
def speak(
    text: str,
    voice: str | None = None,
    language: str | None = None,
    rate: int = 90,
    auto_play: bool = True,
    output_path: str | None = None,
    output_dir: str | None = None,
    ephemeral: bool = False,
    stability: float | None = None,
    similarity: float | None = None,
    style: float | None = None,
    speaker_boost: bool | None = None,
    vibe_tags: str | None = None,
) -> str:
    """Speak text aloud and save as MP3.

    Args:
        text: The text to convert to speech. With ElevenLabs eleven_v3,
            you can embed audio tags in square brackets anywhere in the
            text to control delivery — e.g. [tired], [excited], [whisper],
            [sad], [sigh], [laughs], [dramatic tone]. Tags are free-form;
            the model interprets them as performance cues. Combine with
            punctuation (ellipsis for pauses, ! for emphasis) for best
            results. Tags only work with ElevenLabs eleven_v3 model.
        voice: Voice name. Default: provider's default voice (currently
            matilda for ElevenLabs, joanna for Polly, nova for OpenAI,
            samantha for Say, en for eSpeak).
            If language is provided without voice, a suitable default
            voice for that language is selected automatically.
        language: ISO 639-1 language code (e.g. 'de', 'ko', 'fr').
            Enables language-aware voice selection and validation.
            With Polly, validates voice-language compatibility.
            With ElevenLabs/OpenAI, passed through (voices are
            multilingual).
        rate: Speech rate as percentage (90 = 90% speed, good for
            language learners). Defaults to 90. ElevenLabs ignores rate;
            use audio tags like [rushed] or [drawn out] instead.
        auto_play: Open the file in the default audio player after
            synthesis. Defaults to true.
        output_path: Full path for the output file. If not provided,
            a file is auto-generated in output_dir.
        output_dir: Directory for output. Defaults to VOX_OUTPUT_DIR
            env var or ~/vox-output/.
        ephemeral: If true, write to `.vox/` in cwd and clean up
            previous ephemeral files. Ignores output_dir/output_path.
        stability: ElevenLabs voice stability (0.0-1.0). Ignored by
            other providers. Defaults to provider default.
        similarity: ElevenLabs voice similarity boost (0.0-1.0). Ignored
            by other providers. Defaults to provider default.
        style: ElevenLabs voice style/expressiveness (0.0-1.0). Ignored
            by other providers. Defaults to provider default.
        speaker_boost: ElevenLabs speaker boost toggle. Ignored by other
            providers. Defaults to provider default.
        vibe_tags: ElevenLabs expressive tags to apply before synthesis
            (e.g. "[warm] [satisfied]"). When provided, writes the tags
            to config and clears vibe_signals in one step — replacing
            the separate set_config call. Tags are prepended to text
            automatically via _apply_vibe.

    Returns:
        JSON string with path, text, voice, and language fields.
    """
    _validate_voice_settings(stability, similarity, style)
    if vibe_tags is not None:
        _write_config_fields({"vibe_tags": vibe_tags, "vibe_signals": ""})
    provider = get_provider()
    try:
        voice, language = _resolve_voice_and_language(provider, voice, language)
    except VoiceNotFoundError as exc:
        return json.dumps({"error": _voice_not_found_message(exc)})

    dir_path = _resolve_output_dir(output_dir, ephemeral=ephemeral)
    path = _resolve_output_path(
        output_path,
        dir_path,
        f"{voice}_{text[:20].replace(' ', '_')}.mp3",
    )

    text = _apply_vibe(text, expressive_tags=provider.supports_expressive_tags)
    request = SynthesisRequest(
        text=text,
        voice=voice,
        language=language,
        rate=rate,
        stability=stability,
        similarity=similarity,
        style=style,
        speaker_boost=speaker_boost,
    )

    client = TTSClient(provider)
    if path.exists():
        result = _cached_result(provider, request, path)
    else:
        result = client.synthesize(request, path)
    if auto_play:
        _enqueue_audio(result.path)
    return json.dumps(result_to_dict(result))


@mcp.tool()
def chorus(
    texts: list[str],
    voice: str | None = None,
    language: str | None = None,
    rate: int = 90,
    merge: bool = False,
    pause_ms: int = 500,
    auto_play: bool = True,
    output_dir: str | None = None,
    ephemeral: bool = False,
    stability: float | None = None,
    similarity: float | None = None,
    style: float | None = None,
    speaker_boost: bool | None = None,
    vibe_tags: str | None = None,
) -> str:
    """Speak multiple texts to MP3 files.

    Args:
        texts: List of texts to synthesize. With ElevenLabs eleven_v3,
            embed audio tags like [tired], [excited], [whisper] in text.
        voice: Voice name for all texts. Default: provider's default voice
            (currently matilda for ElevenLabs, joanna for Polly, nova for
            OpenAI, fred for Say, en for eSpeak). If language is provided
            without voice,
            auto-selects.
        language: ISO 639-1 language code (e.g. 'de', 'ko').
        rate: Speech rate as percentage. Defaults to 90.
        merge: If true, produce one merged file instead of separate
            files per text. Defaults to false.
        pause_ms: Pause between segments in milliseconds when merging.
            Defaults to 500.
        auto_play: Open the file(s) in the default audio player after
            synthesis. Defaults to true.
        output_dir: Directory for output files. Defaults to
            VOX_OUTPUT_DIR env var or ~/vox-output/.
        ephemeral: If true, write to `.vox/` in cwd and clean up
            previous ephemeral files. Ignores output_dir.
        stability: ElevenLabs voice stability (0.0-1.0).
        similarity: ElevenLabs voice similarity boost (0.0-1.0).
        style: ElevenLabs voice style/expressiveness (0.0-1.0).
        speaker_boost: ElevenLabs speaker boost toggle.
        vibe_tags: ElevenLabs expressive tags to apply before synthesis
            (e.g. "[warm] [satisfied]"). When provided, writes the tags
            to config and clears vibe_signals in one step.

    Returns:
        JSON string with list of results, each containing path,
        text, voice, and language fields.
    """
    _validate_voice_settings(stability, similarity, style)
    if vibe_tags is not None:
        _write_config_fields({"vibe_tags": vibe_tags, "vibe_signals": ""})
    provider = get_provider()
    expressive = provider.supports_expressive_tags
    texts = [_apply_vibe(t, expressive_tags=expressive) for t in texts]
    try:
        voice, language = _resolve_voice_and_language(provider, voice, language)
    except VoiceNotFoundError as exc:
        return json.dumps({"error": _voice_not_found_message(exc)})
    requests = [
        SynthesisRequest(
            text=t,
            voice=voice,
            language=language,
            rate=rate,
            stability=stability,
            similarity=similarity,
            style=style,
            speaker_boost=speaker_boost,
        )
        for t in texts
    ]
    if not requests:
        return json.dumps([])
    dir_path = _resolve_output_dir(output_dir, ephemeral=ephemeral)

    client = TTSClient(provider)
    results: list[SynthesisResult]
    if merge:
        combined_text = " | ".join(r.text for r in requests)
        out_path = dir_path / generate_filename(combined_text, prefix="batch_")
        if out_path.exists():
            cached = SynthesisResult(
                path=out_path,
                text=combined_text,
                provider=AudioProviderId(provider.name),
                voice=voice,
                language=language,
                metadata=requests[0].metadata,
            )
            results = [cached]
        else:
            results = client.synthesize_batch(
                requests, dir_path, MergeStrategy.ONE_FILE_PER_BATCH, pause_ms
            )
    else:
        results = []
        for req in requests:
            out_path = dir_path / generate_filename(req.text)
            if out_path.exists():
                results.append(_cached_result(provider, req, out_path))
            else:
                results.append(client.synthesize(req, out_path))
    if auto_play:
        for r in results:
            _enqueue_audio(r.path)
    return json.dumps([result_to_dict(r) for r in results])


@mcp.tool()
def duet(
    text1: str,
    text2: str,
    voice1: str | None = None,
    voice2: str | None = None,
    lang1: str | None = None,
    lang2: str | None = None,
    rate: int = 90,
    pause_ms: int = 500,
    auto_play: bool = True,
    output_path: str | None = None,
    output_dir: str | None = None,
    ephemeral: bool = False,
    stability: float | None = None,
    similarity: float | None = None,
    style: float | None = None,
    speaker_boost: bool | None = None,
) -> str:
    """Stitch a pair of texts into one MP3.

    Creates [text1 audio] [pause] [text2 audio]. Use for language
    learning pairs like "strong" (English) + "stark" (German).

    Args:
        text1: First text (typically English). With ElevenLabs eleven_v3,
            embed audio tags like [tired], [excited], [whisper] in text.
        text2: Second text (typically target language). Same audio tag
            support as text1.
        voice1: Voice for text1. Defaults to provider's default voice.
            If lang1 is provided without voice1, auto-selects.
        voice2: Voice for text2. Defaults to provider's default voice.
            If lang2 is provided without voice2, auto-selects.
        lang1: ISO 639-1 language code for text1 (e.g. 'en').
        lang2: ISO 639-1 language code for text2 (e.g. 'de').
        rate: Speech rate as percentage. Defaults to 90.
        pause_ms: Pause between the two texts in milliseconds.
            Defaults to 500.
        auto_play: Play the audio after synthesis. Defaults to true.
        output_path: Full path for the output file.
        output_dir: Directory for output. Defaults to
            VOX_OUTPUT_DIR env var or ~/vox-output/.
        ephemeral: If true, write to `.vox/` in cwd and clean up
            previous ephemeral files. Ignores output_dir/output_path.
        stability: ElevenLabs voice stability (0.0-1.0).
        similarity: ElevenLabs voice similarity boost (0.0-1.0).
        style: ElevenLabs voice style/expressiveness (0.0-1.0).
        speaker_boost: ElevenLabs speaker boost toggle.

    Returns:
        JSON string with path, text, voice, and language fields.
    """
    _validate_voice_settings(stability, similarity, style)
    provider = get_provider()
    try:
        voice1, lang1 = _resolve_voice_and_language(provider, voice1, lang1)
    except VoiceNotFoundError as exc:
        return json.dumps({"error": _voice_not_found_message(exc)})
    try:
        voice2, lang2 = _resolve_voice_and_language(provider, voice2, lang2)
    except VoiceNotFoundError as exc:
        return json.dumps({"error": _voice_not_found_message(exc)})
    req1 = SynthesisRequest(
        text=text1,
        voice=voice1,
        language=lang1,
        rate=rate,
        stability=stability,
        similarity=similarity,
        style=style,
        speaker_boost=speaker_boost,
    )
    req2 = SynthesisRequest(
        text=text2,
        voice=voice2,
        language=lang2,
        rate=rate,
        stability=stability,
        similarity=similarity,
        style=style,
        speaker_boost=speaker_boost,
    )

    dir_path = _resolve_output_dir(output_dir, ephemeral=ephemeral)
    path = _resolve_output_path(
        output_path,
        dir_path,
        f"pair_{text1[:10]}_{text2[:10]}.mp3",
    )

    client = TTSClient(provider)
    if path.exists():
        voice_parts = [v for v in (voice1, voice2) if v]
        combined_voice = "+".join(voice_parts) if voice_parts else None
        result = SynthesisResult(
            path=path,
            text=f"{text1} | {text2}",
            provider=AudioProviderId(provider.name),
            voice=combined_voice,
            language=lang1,
            metadata=req1.metadata,
        )
    else:
        result = client.synthesize_pair(text1, req1, text2, req2, path, pause_ms)
    if auto_play:
        _enqueue_audio(result.path)
    return json.dumps(result_to_dict(result))


@mcp.tool()
def ensemble(
    pairs: list[list[str]],
    voice1: str | None = None,
    voice2: str | None = None,
    lang1: str | None = None,
    lang2: str | None = None,
    rate: int = 90,
    pause_ms: int = 500,
    merge: bool = False,
    auto_play: bool = True,
    output_dir: str | None = None,
    ephemeral: bool = False,
    stability: float | None = None,
    similarity: float | None = None,
    style: float | None = None,
    speaker_boost: bool | None = None,
) -> str:
    """Stitch multiple text pairs into MP3 files.

    Each pair becomes [text1 audio] [pause] [text2 audio]. Use for
    vocabulary lists like [["strong","stark"], ["house","Haus"]].

    Args:
        pairs: List of [text1, text2] pairs. With ElevenLabs eleven_v3,
            texts can include audio tags like [tired], [excited].
        voice1: Voice for all first texts. Defaults to provider's default.
            If lang1 is provided without voice1, auto-selects.
        voice2: Voice for all second texts. Defaults to provider's default.
            If lang2 is provided without voice2, auto-selects.
        lang1: ISO 639-1 language code for first texts (e.g. 'en').
        lang2: ISO 639-1 language code for second texts (e.g. 'de').
        rate: Speech rate as percentage. Defaults to 90.
        pause_ms: Pause between pair segments in milliseconds.
            Defaults to 500.
        merge: If true, produce one merged file instead of separate
            files per pair. Defaults to false.
        auto_play: Play the audio after synthesis. Defaults to true.
        output_dir: Directory for output files. Defaults to
            VOX_OUTPUT_DIR env var or ~/vox-output/.
        ephemeral: If true, write to `.vox/` in cwd and clean up
            previous ephemeral files. Ignores output_dir.
        stability: ElevenLabs voice stability (0.0-1.0).
        similarity: ElevenLabs voice similarity boost (0.0-1.0).
        style: ElevenLabs voice style/expressiveness (0.0-1.0).
        speaker_boost: ElevenLabs speaker boost toggle.

    Returns:
        JSON string with list of results.
    """
    _validate_voice_settings(stability, similarity, style)
    provider = get_provider()
    try:
        voice1, lang1 = _resolve_voice_and_language(provider, voice1, lang1)
    except VoiceNotFoundError as exc:
        return json.dumps({"error": _voice_not_found_message(exc)})
    try:
        voice2, lang2 = _resolve_voice_and_language(provider, voice2, lang2)
    except VoiceNotFoundError as exc:
        return json.dumps({"error": _voice_not_found_message(exc)})

    pair_requests: list[tuple[SynthesisRequest, SynthesisRequest]] = [
        (
            SynthesisRequest(
                text=p[0],
                voice=voice1,
                language=lang1,
                rate=rate,
                stability=stability,
                similarity=similarity,
                style=style,
                speaker_boost=speaker_boost,
            ),
            SynthesisRequest(
                text=p[1],
                voice=voice2,
                language=lang2,
                rate=rate,
                stability=stability,
                similarity=similarity,
                style=style,
                speaker_boost=speaker_boost,
            ),
        )
        for p in pairs
    ]
    if not pair_requests:
        return json.dumps([])

    dir_path = _resolve_output_dir(output_dir, ephemeral=ephemeral)

    client = TTSClient(provider)
    results: list[SynthesisResult]
    if merge:
        all_texts = " | ".join(f"{r1.text}-{r2.text}" for r1, r2 in pair_requests)
        out_path = dir_path / generate_filename(all_texts, prefix="pairs_")
        if out_path.exists():
            results = [
                SynthesisResult(
                    path=out_path,
                    text=all_texts,
                    provider=AudioProviderId(provider.name),
                    voice="mixed",
                    metadata=pair_requests[0][0].metadata,
                )
            ]
        else:
            results = client.synthesize_pair_batch(
                pair_requests, dir_path, MergeStrategy.ONE_FILE_PER_BATCH, pause_ms
            )
    else:
        results = []
        for req_1, req_2 in pair_requests:
            combined = f"{req_1.text}_{req_2.text}"
            out_path = dir_path / generate_filename(combined, prefix="pair_")
            if out_path.exists():
                voice_parts = [v for v in (req_1.voice, req_2.voice) if v]
                combined_voice = "+".join(voice_parts) if voice_parts else None
                results.append(
                    SynthesisResult(
                        path=out_path,
                        text=f"{req_1.text} | {req_2.text}",
                        provider=AudioProviderId(provider.name),
                        voice=combined_voice,
                        language=req_1.language,
                        metadata=req_1.metadata,
                    )
                )
            else:
                results.append(
                    client.synthesize_pair(
                        req_1.text,
                        req_1,
                        req_2.text,
                        req_2,
                        out_path,
                        pause_ms,
                    )
                )
    if auto_play:
        for r in results:
            _enqueue_audio(r.path)
    return json.dumps([result_to_dict(r) for r in results])


@mcp.tool()
def set_config(
    key: str | None = None,
    value: str | None = None,
    updates: dict[str, str] | None = None,
) -> str:
    """Write configuration field(s) to .vox/config.md.

    Updates plugin state that controls TTS behavior. Use this instead
    of Read/Write/Edit file tools when changing plugin configuration.

    Supports two modes:

    **Single field** (backward compatible): pass ``key`` and ``value``.

    **Batch** (preferred for multi-field updates): pass ``updates``
    dict. All fields are written in a single read-write cycle.
    When ``updates`` is provided, ``key`` and ``value`` are ignored.

    Args:
        key: The config field to set. One of: notify, speak, voice,
            voice_enabled, vibe, vibe_tags, vibe_mode, vibe_signals.
            - notify: "y" or "n" — task completion notifications
            - speak: "y" or "n" — spoken vs chime notifications
            - voice: Voice name for this session (e.g. "matilda", "aria").
              Used as default when speak/chorus/duet/ensemble omit voice.
              Empty string to clear (reverts to provider default).
            - voice_enabled: "true" or "false" — voice mode
            - vibe: Human-readable mood description (e.g. "3am debugging")
            - vibe_tags: ElevenLabs expressive tags (e.g. "[tired] [slow]")
            - vibe_mode: "auto", "manual", or "off" — vibe detection mode
            - vibe_signals: Accumulated session signals (usually cleared
              by passing empty string after reading)
        value: The value to write. Use empty string to clear a field.
        updates: Dict of key-value pairs to write in one pass. When
            provided, key and value are ignored. All keys must be
            valid config fields. Example:
            ``{"vibe": "happy", "vibe_tags": "[cheerful]",
            "vibe_mode": "manual"}``

    Returns:
        JSON string. Single mode: ``{"key": k, "value": v}``.
        Batch mode: ``{"updates": {k: v, ...}}``.
    """
    if updates is not None:
        _write_config_fields(updates)
        return json.dumps({"updates": updates})
    if key is None or value is None:
        msg = "Single mode requires both key and value"
        raise ValueError(msg)
    _write_config_field(key, value)
    return json.dumps({"key": key, "value": value})


@mcp.tool()
def list_voices(language: str | None = None) -> str:
    """Browse available voices for the current provider.

    Returns a curated "who's around" list: featured voices with personality
    blurbs, the full roster, and the current session voice (if set).

    Args:
        language: ISO 639-1 language code to filter by (e.g. 'de', 'ko').
            When provided, only voices available in that language are listed.

    Returns:
        JSON string with provider, current voice, featured voices (with
        blurbs), and full voice list.
    """
    if language is not None:
        language = validate_language(language)
    provider = get_provider()
    all_voices = provider.list_voices(language)
    current = _read_session_voice()

    featured = [
        {"name": name, "blurb": blurb}
        for (prov, name), blurb in _VOICE_BLURBS.items()
        if prov == provider.name and name in all_voices
    ]
    random.shuffle(featured)
    featured = featured[:6]

    return json.dumps(
        {
            "provider": provider.name,
            "current": current,
            "featured": featured,
            "all": all_voices,
        }
    )


def _start_watcher() -> None:
    """Start the session event watcher if a session directory exists.

    Lazily imports the watcher module so that watcher-related imports and
    side effects are only triggered when needed. Gracefully skips if the
    session directory is
    missing (e.g. running outside Claude Code).
    """
    from punt_vox.watcher import (
        SessionWatcher,
        derive_session_dir,
        make_notification_consumer,
        resolve_chime_path,
    )

    session_dir = derive_session_dir()
    if not session_dir.is_dir():
        logger.info("Session dir %s not found, watcher not started", session_dir)
        return

    chime_path = resolve_chime_path()
    consumer = make_notification_consumer(chime_path=chime_path)
    watcher = SessionWatcher(session_dir=session_dir, consumers=[consumer])
    watcher.start()


def run_server() -> None:
    """Run the MCP server with stdio transport."""
    # MCP stdio servers must not write to stdout; stderr handler is safe.
    configure_logging(stderr_level="INFO")
    logger.info("Starting tts MCP server")
    _start_watcher()
    mcp.run(transport="stdio")


if __name__ == "__main__":
    run_server()
