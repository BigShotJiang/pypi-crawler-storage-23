from .openie_openai import OpenIE

__all__ = ["OpenIE"]
