"""oneprompt MCP servers — PostgreSQL, Chart, and Python sandbox."""
