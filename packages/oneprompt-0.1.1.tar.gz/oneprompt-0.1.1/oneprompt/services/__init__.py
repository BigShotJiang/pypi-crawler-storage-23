"""oneprompt services — state management, artifact handling, and local API."""
