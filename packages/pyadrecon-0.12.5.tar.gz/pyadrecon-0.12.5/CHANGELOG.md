## [0.12.5](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.4...v0.12.5) (2026-02-21)


### Bug Fixes

* counter for security findings in navigation ([b856c3d](https://github.com/l4rm4nd/PyADRecon/commit/b856c3d4395b093cb0545c8ed716aaed3f868223))

## [0.12.4](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.3...v0.12.4) (2026-02-21)


### Bug Fixes

* show detected cleartext pws in description/info fields ([d681224](https://github.com/l4rm4nd/PyADRecon/commit/d6812246687d1c73af910dbc906b3a843cf7a7f1))

## [0.12.3](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.2...v0.12.3) (2026-02-21)


### Bug Fixes

* add krbtgt rotation and protected users group to dashboard ([03e3046](https://github.com/l4rm4nd/PyADRecon/commit/03e30466f1f1f9033e0aa3341dba7521f855a62e))

## [0.12.2](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.1...v0.12.2) (2026-02-21)


### Bug Fixes

* Update Dockerfile ([783e6ea](https://github.com/l4rm4nd/PyADRecon/commit/783e6eab3f3396107f52c1183a135efaa5766561))

## [0.12.1](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.0...v0.12.1) (2026-02-21)


### Bug Fixes

* column sorting bug ([d160142](https://github.com/l4rm4nd/PyADRecon/commit/d160142e94d919421f5996c57e83187ac217a70b))

