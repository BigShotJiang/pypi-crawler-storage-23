# gasoline-mcp-linux-x64

Platform-specific binary package for Gasoline MCP (linux-x64).

This package is automatically installed as a dependency when you run:

```bash
pip install gasoline-mcp
```

You do not need to install this package directly.

For more information, see the main [gasoline-mcp](https://pypi.org/project/gasoline-mcp/) package.
