import numpy as np
import cffi
import os
import sys
import glob

# ─── 라이브러리 로드 ───
ffi = cffi.FFI()
ffi.cdef("""
    void popimg_imshow(const char *title, const unsigned char *data, int w, int h, int channels);
    void popimg_imshow_file(const char *title, const char *filepath);
    void popimg_waitKey(int milliseconds);
    void popimg_destroyAllWindows(void);
""")


def _find_lib():
    d = os.path.dirname(os.path.abspath(__file__))
    names = {"darwin": "libpopimg.dylib", "win32": "popimg.dll", "linux": "libpopimg.so"}
    name = names.get(sys.platform, names["linux"])
    for search in [d, os.path.join(d, "popimg")]:
        path = os.path.join(search, name)
        if os.path.exists(path):
            return path
    raise ImportError(f"{name} not found")


_lib = ffi.dlopen(_find_lib())

# ─── PIL 지원 (선택) ───
try:
    import PIL.Image

    _HAS_PIL = True
except ImportError:
    _HAS_PIL = False


# ─── 전처리 ───
def _preprocess(img):
    if _HAS_PIL and isinstance(img, PIL.Image.Image):
        img = np.asarray(img)[:, :, ::-1]  # RGB → BGR

    if not isinstance(img, np.ndarray):
        raise TypeError(f"Expected numpy.ndarray or PIL.Image, got {type(img)}")

    if img.ndim == 2 or (img.ndim == 3 and img.shape[2] == 1):
        img = np.stack([img.squeeze()] * 3, axis=-1)

    return np.ascontiguousarray(img)


# ─── Public API ───
def imshow(winname: str, img):
    img = _preprocess(img)
    ptr = ffi.from_buffer("const unsigned char[]", img)
    _lib.popimg_imshow(winname.encode(), ptr, img.shape[1], img.shape[0], img.shape[2])


def imshow_file(winname: str, filepath: str):
    _lib.popimg_imshow_file(winname.encode(), filepath.encode())


def waitKey(milliseconds: int = 0):
    _lib.popimg_waitKey(milliseconds)


def destroyAllWindows():
    _lib.popimg_destroyAllWindows()
