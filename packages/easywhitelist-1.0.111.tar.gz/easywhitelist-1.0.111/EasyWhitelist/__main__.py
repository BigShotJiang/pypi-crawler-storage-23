from ._core import main

main()
