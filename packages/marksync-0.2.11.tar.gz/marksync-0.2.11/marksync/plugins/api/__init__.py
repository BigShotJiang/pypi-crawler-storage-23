"""
marksync.plugins.api — API schema adapters.

Supported formats:
    OpenAPI 3.x    — REST API description (formerly Swagger)
    AsyncAPI 2.x   — Event-driven / message-based API description
    GraphQL        — GraphQL Schema Definition Language (SDL)
    gRPC           — Protocol Buffers / gRPC service definitions
    JSON Schema    — JSON Schema for pipeline data validation
"""
