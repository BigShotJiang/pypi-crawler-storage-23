"""
marksync.plugins.formats — BPM & workflow format converters.

Supported formats:
    BPMN 2.0    — Business Process Model and Notation (ISO 19510)
    XPDL 2.2    — XML Process Definition Language (WfMC)
    WS-BPEL 2.0 — Business Process Execution Language (OASIS)
    PNML        — Petri Net Markup Language (ISO/IEC 15909-2)
    EPC         — Event-driven Process Chain (ARIS)
    DMN 1.3     — Decision Model and Notation (OMG)
    CMMN 1.1    — Case Management Model and Notation (OMG)
    UML-AD      — UML Activity Diagram (XMI export)
"""
