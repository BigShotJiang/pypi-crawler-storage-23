#!/usr/bin/env bash
code2logic ./ -f toon --compact --function-logic --with-schema -o project.toon
