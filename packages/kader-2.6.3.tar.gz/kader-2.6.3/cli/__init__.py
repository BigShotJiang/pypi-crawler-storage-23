"""Kader CLI - Modern AI Coding CLI."""

from .app import KaderApp, main

__all__ = ["KaderApp", "main"]
