"""Microsoft Fabric Airflow Plugins"""

from .fabric_status_plugin import FabricStatusPlugin

__all__ = ["FabricStatusPlugin"]