"""MCP and Claude Settings models."""
from typing import Any, Optional
from .base import CoreModel

class MCPServerConfig(CoreModel):
    """Configuration for a single MCP server."""
    command: str
    args: list[str] = []
    env: dict[str, str] = {}

class MCPConfig(CoreModel):
    """Configuration for Model Context Protocol servers (.mcp.json)."""
    mcpServers: dict[str, MCPServerConfig] = {}

class ClaudeSettings(CoreModel):
    """Claude project/user settings (settings.json)."""
    model: Optional[str] = None
    maxTokens: Optional[int] = None
    temperature: Optional[float] = None
    # Add other settings as needed based on research
    extra_settings: dict[str, Any] = {}
