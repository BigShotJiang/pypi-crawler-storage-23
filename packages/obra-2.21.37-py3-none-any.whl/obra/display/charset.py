"""Terminal-aware character set with automatic Unicode/ASCII detection.

This module provides terminal-safe glyphs that automatically fall back to ASCII
on terminals that don't support Unicode (e.g., Windows CMD, older PowerShell).

Detection order:
1. OBRA_ASCII_MODE env var (forces ASCII if '1' or 'true')
2. OBRA_UNICODE_MODE env var (forces Unicode if '1' or 'true')
3. Config display.ascii_mode (forces ASCII if True)
4. Platform-specific detection (Windows Terminal, ConEmu, VSCode, Git Bash, etc.)
5. Encoding check (UTF-8 encoding indicates Unicode support)

Usage:
    from obra.display.charset import glyphs

    print(f"{glyphs.success} Task completed")  # ✓ or [ok]
    print(f"{glyphs.failure} Task failed")     # ✗ or [FAIL]
    print(glyphs.divider)                      # ────── or ------
"""

import os
import sys

# Module-level cache for Unicode support detection
_UNICODE_SUPPORT: bool | None = None


def _check_env_overrides() -> bool | None:
    """Check environment variable overrides for Unicode support.

    Returns:
        True if Unicode forced, False if ASCII forced, None if no override.
    """
    # OBRA_ASCII_MODE forces ASCII
    ascii_mode = os.environ.get("OBRA_ASCII_MODE", "").lower()
    if ascii_mode in ("1", "true"):
        return False

    # OBRA_UNICODE_MODE forces Unicode
    unicode_mode = os.environ.get("OBRA_UNICODE_MODE", "").lower()
    if unicode_mode in ("1", "true"):
        return True

    return None


def _check_config_override() -> bool | None:
    """Check config override for Unicode support.

    Returns:
        False if ASCII mode configured, None otherwise.
    """
    try:
        from obra.config import load_config

        config = load_config()
        if config.get("display", {}).get("ascii_mode", False):
            return False
    except Exception:
        pass
    return None


def _check_windows_terminal() -> bool:
    """Check if running in a Windows terminal that supports Unicode.

    Returns:
        True if Unicode-capable Windows terminal detected.
    """
    # Windows Terminal (modern, supports Unicode)
    if os.environ.get("WT_SESSION"):
        return True
    # ConEmu terminal (env var is mixed case by design)
    if os.environ.get("ConEmuANSI") == "ON":
        return True
    # VSCode integrated terminal
    if os.environ.get("TERM_PROGRAM") == "vscode":
        return True
    # Git Bash / MSYS2
    return bool(os.environ.get("MSYSTEM"))


def _detect_unicode_support() -> bool:
    """Detect whether the terminal supports Unicode.

    Returns:
        True if Unicode is supported, False otherwise.
    """
    # 1-2. Check env var overrides
    env_override = _check_env_overrides()
    if env_override is not None:
        return env_override

    # 3. Check config override
    config_override = _check_config_override()
    if config_override is not None:
        return config_override

    # 4. Platform-specific detection
    if sys.platform == "win32":
        return _check_windows_terminal()

    # 5. macOS/Linux: check stdout encoding
    try:
        encoding = getattr(sys.stdout, "encoding", "") or ""
        return encoding.lower() in ("utf-8", "utf8")
    except Exception:
        return False


def get_unicode_support() -> bool:
    """Get whether Unicode is supported, using cached result.

    Returns:
        True if Unicode is supported, False otherwise.
    """
    global _UNICODE_SUPPORT
    if _UNICODE_SUPPORT is None:
        _UNICODE_SUPPORT = _detect_unicode_support()
    return _UNICODE_SUPPORT


def reset_detection() -> None:
    """Reset the Unicode detection cache.

    Useful for testing different terminal environments.
    """
    global _UNICODE_SUPPORT
    _UNICODE_SUPPORT = None


class _Glyphs:
    """Terminal-safe glyphs with automatic Unicode/ASCII fallback.

    All properties return Unicode characters if supported, otherwise ASCII.
    ASCII fallback uses escaped brackets to prevent Rich markup interpretation.
    """

    @property
    def success(self) -> str:
        """Success indicator: checkmark or [ok]."""
        return "\u2713" if get_unicode_support() else r"\[ok]"

    @property
    def failure(self) -> str:
        """Failure indicator: X mark or [FAIL]."""
        return "\u2717" if get_unicode_support() else r"\[FAIL]"

    @property
    def warning(self) -> str:
        """Warning indicator: warning sign or [!]."""
        return "\u26a0" if get_unicode_support() else r"\[!]"

    @property
    def paused(self) -> str:
        """Paused indicator: pause symbol or [PAUSED]."""
        return "\u23f8" if get_unicode_support() else r"\[PAUSED]"

    @property
    def timeout(self) -> str:
        """Timeout indicator: stopwatch or [TIMEOUT]."""
        return "\u23f1" if get_unicode_support() else r"\[TIMEOUT]"

    @property
    def arrow(self) -> str:
        """Arrow indicator: right arrow or ->."""
        return "\u2192" if get_unicode_support() else "->"

    @property
    def hline(self) -> str:
        """Horizontal line character: box drawing or dash."""
        return "\u2500" if get_unicode_support() else "-"

    @property
    def divider(self) -> str:
        """60-character divider line."""
        return self.hline * 60

    @property
    def tree_last(self) -> str:
        """Tree branch for last item: corner or `--."""
        return "\u2514\u2500" if get_unicode_support() else "`--"

    @property
    def tree_mid(self) -> str:
        """Tree branch for middle items: tee or |--."""
        return "\u251c\u2500" if get_unicode_support() else "|--"

    @property
    def skip(self) -> str:
        """Skip indicator: dash or [skip]."""
        return "\u2013" if get_unicode_support() else r"\[skip]"


# Module-level singleton
glyphs = _Glyphs()
