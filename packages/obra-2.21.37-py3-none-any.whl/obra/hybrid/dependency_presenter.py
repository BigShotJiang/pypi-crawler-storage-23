"""Dependency presenter implementing Steps 2 (PRESENT) and 6 (REPORT).

Renders dependency manifests as bordered console tables and diff reports.
Uses plain string formatting only — no external table libraries.
"""

from __future__ import annotations

from obra.hybrid.dependency_manifest import DependencyManifest


# Status display symbols (plain ASCII — no emoji per project conventions)
_STATUS_SYMBOLS: dict[str, str] = {
    "installed": "+ found",
    "missing": "x missing",
    "unknown": "? unknown",
    "unverified": "? unverified",
    "unexecutable": "! unexecutable",
}


class DependencyPresenter:
    """Render dependency manifests for console output."""

    def __init__(self, terminal_width: int = 80) -> None:
        self._width = terminal_width

    # ------------------------------------------------------------------
    # Step 2: PRESENT
    # ------------------------------------------------------------------

    def render_table(self, manifest: DependencyManifest) -> str:
        """Render the manifest as a bordered table grouped by ecosystem."""
        if not manifest.entries:
            return "No dependencies detected."

        # Column widths
        col_name = 20
        col_kind = 10
        col_status = 15
        col_elev = 4
        # Borders, separators: | + padding
        fixed = col_name + col_kind + col_status + col_elev + 14  # pipes + spaces
        col_cmd = max(20, self._width - fixed)

        header = self._row(
            "Name", "Kind", "Status", "Proposed Command", "Elev",
            col_name, col_kind, col_status, col_cmd, col_elev,
        )
        sep = self._sep(col_name, col_kind, col_status, col_cmd, col_elev)
        top = self._top(col_name, col_kind, col_status, col_cmd, col_elev)
        bot = self._bot(col_name, col_kind, col_status, col_cmd, col_elev)

        # Group entries by ecosystem
        by_eco: dict[str, list] = {}
        for e in manifest.entries:
            by_eco.setdefault(e.ecosystem, []).append(e)

        lines = [" Dependency Scan Results", top, header, sep]

        for eco, entries in by_eco.items():
            # Ecosystem header
            total_inner = col_name + col_kind + col_status + col_cmd + col_elev + 8
            eco_label = f" [{eco}]"
            lines.append(f"|{eco_label:<{total_inner}}|")
            lines.append(sep)

            for e in entries:
                status_str = _STATUS_SYMBOLS.get(e.status, e.status)
                cmd_str = self._format_command(e, col_cmd)
                elev_str = "sudo" if e.requires_elevation else ""

                lines.append(self._row(
                    self._trunc(e.name, col_name),
                    self._trunc(e.kind, col_kind),
                    self._trunc(status_str, col_status),
                    self._trunc(cmd_str, col_cmd),
                    elev_str,
                    col_name, col_kind, col_status, col_cmd, col_elev,
                ))

        lines.append(bot)
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Step 6: REPORT (diff)
    # ------------------------------------------------------------------

    def render_diff(
        self,
        before: DependencyManifest,
        after: DependencyManifest,
    ) -> str:
        """Show what changed between two manifest snapshots."""
        before_map = {e.dependency_id: e for e in before.entries}
        lines: list[str] = []

        for entry in after.entries:
            prev = before_map.get(entry.dependency_id)
            if prev is None:
                # New entry (shouldn't happen per invariant 1, but handle)
                lines.append(
                    f"  {entry.name:<20} {entry.kind:<10} "
                    f"{_STATUS_SYMBOLS.get(entry.status, entry.status):<15} (new)"
                )
                continue

            if prev.status != entry.status:
                lines.append(
                    f"  {entry.name:<20} {entry.kind:<10} "
                    f"{_STATUS_SYMBOLS.get(entry.status, entry.status):<15} "
                    f"(was: {prev.status})"
                )
            elif entry.status != "installed":
                lines.append(
                    f"  {entry.name:<20} {entry.kind:<10} "
                    f"{_STATUS_SYMBOLS.get(entry.status, entry.status):<15} "
                    f"(still {entry.status})"
                )

        if not lines:
            return "  No changes detected."

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Step 3: PROMPT
    # ------------------------------------------------------------------

    def render_prompt(
        self,
        manifest: DependencyManifest,
        mode: str,
    ) -> str:
        """Render the interactive prompt options.

        Returns empty string for auto_full (prompt skipped).
        """
        if mode == "auto_full":
            return ""

        executable_count = sum(
            1 for e in manifest.entries
            if e.effective_command is not None and e.status != "installed"
        )

        lines = ["", "Options:"]
        if executable_count > 0:
            lines.append(
                f"  [A] Auto-install all proposed commands"
                f" ({executable_count} commands)"
            )
            lines.append("  [E] Edit commands before running")
        else:
            lines.append(
                "  (No auto-install commands available"
                " — manual installation required)"
            )
        lines.extend([
            "  [R] Re-scan (after manual installation)",
            "  [X] Abort session",
            "",
            "  (You can install dependencies manually now, then choose [R] to re-scan)",
            "> ",
        ])
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _format_command(entry, max_width: int) -> str:
        if entry.effective_command is None:
            return "(manual install required)"
        cmd = " ".join(entry.effective_command)
        if len(cmd) > max_width:
            return cmd[: max_width - 1] + "\u2026"
        return cmd

    @staticmethod
    def _trunc(text: str, width: int) -> str:
        if len(text) > width:
            return text[: width - 1] + "\u2026"
        return text

    @staticmethod
    def _row(
        c1: str, c2: str, c3: str, c4: str, c5: str,
        w1: int, w2: int, w3: int, w4: int, w5: int,
    ) -> str:
        return (
            f"| {c1:<{w1}} | {c2:<{w2}} | {c3:<{w3}} | {c4:<{w4}} | {c5:<{w5}} |"
        )

    @staticmethod
    def _sep(w1: int, w2: int, w3: int, w4: int, w5: int) -> str:
        return (
            f"|{'-' * (w1 + 2)}+{'-' * (w2 + 2)}+{'-' * (w3 + 2)}"
            f"+{'-' * (w4 + 2)}+{'-' * (w5 + 2)}|"
        )

    @staticmethod
    def _top(w1: int, w2: int, w3: int, w4: int, w5: int) -> str:
        total = w1 + w2 + w3 + w4 + w5 + 12  # separators + padding
        return f"+{'-' * total}+"

    @staticmethod
    def _bot(w1: int, w2: int, w3: int, w4: int, w5: int) -> str:
        total = w1 + w2 + w3 + w4 + w5 + 12
        return f"+{'-' * total}+"
