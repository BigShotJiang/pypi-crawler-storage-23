"""Strategy planner for Story0 prerequisites.

Determines execution strategy (install/probe/service/manual) and
automatability for each prerequisite. Makes LLM categories advisory
rather than authoritative for routing decisions.

Strategy assignment priority:
1. Check capability probe registry — if a probe matches, strategy=probe.
2. Check category — AUTO/AUTO_CONFIRM -> install, SERVICE -> service,
   LOCAL_CAPABILITY -> probe, CREDENTIAL/USER_ACTION/ACCOUNT -> manual.
3. The probe registry can override category: a USER_ACTION item that
   matches a capability probe becomes automatable (strategy=probe).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any

from obra.hybrid.capability_probes import match_capability_probe
from obra.models.story0_state import (
    Prerequisite,
    PrerequisiteCategory,
)

logger = logging.getLogger(__name__)


class PrerequisiteStrategy(str, Enum):
    """Execution strategy for a Story0 prerequisite."""

    INSTALL = "install"
    PROBE = "probe"
    SERVICE = "service"
    MANUAL = "manual"


@dataclass(frozen=True)
class StrategyAssignment:
    """Outcome of strategy planning for a single prerequisite."""

    strategy: PrerequisiteStrategy
    automatable: bool
    classification_trace: str


# Categories that are inherently manual (require user interaction)
_MANUAL_CATEGORIES = frozenset({
    PrerequisiteCategory.CREDENTIAL,
    PrerequisiteCategory.ACCOUNT,
})


class StrategyPlanner:
    """Assign execution strategy to Story0 prerequisites.

    The planner checks each prerequisite against the capability probe
    registry first, allowing it to override LLM category assignments.
    For example, a USER_ACTION item like "Tk GUI bindings" that matches
    the tkinter probe will be assigned strategy=probe (automatable),
    instead of being routed to the manual prompt flow.
    """

    def __init__(self, config: dict[str, Any]) -> None:
        self._config = config
        self._depres_config: dict[str, Any] = config.get("story0", {}).get(
            "dependency_resolution", {},
        )

    def assign(
        self,
        prereq: Prerequisite,
        raw_prereq: dict[str, Any],
    ) -> StrategyAssignment:
        """Assign execution strategy to a prerequisite.

        Args:
            prereq: Coerced prerequisite model instance.
            raw_prereq: Original raw prerequisite dict from LLM/server.

        Returns:
            StrategyAssignment with strategy, automatable flag, and trace.
        """
        original_category = prereq.category.value

        # 1. Check capability probe registry (overrides category)
        probe_name = match_capability_probe(prereq.name)
        if probe_name is not None:
            trace = (
                f"category={original_category} -> probe registry matched "
                f"'{probe_name}' -> strategy=probe, automatable=True"
            )
            logger.debug("[StrategyPlanner] %s: %s", prereq.name, trace)
            return StrategyAssignment(
                strategy=PrerequisiteStrategy.PROBE,
                automatable=True,
                classification_trace=trace,
            )

        # 2. Category-based assignment (LLM category is advisory input)

        # AUTO/AUTO_CONFIRM -> install strategy (handled by resolver)
        if prereq.category in (
            PrerequisiteCategory.AUTO,
            PrerequisiteCategory.AUTO_CONFIRM,
        ):
            trace = (
                f"category={original_category} -> strategy=install, automatable=True"
            )
            return StrategyAssignment(
                strategy=PrerequisiteStrategy.INSTALL,
                automatable=True,
                classification_trace=trace,
            )

        # LOCAL_CAPABILITY -> probe strategy (handled by capability handler)
        if prereq.category == PrerequisiteCategory.LOCAL_CAPABILITY:
            trace = (
                f"category={original_category} -> strategy=probe, automatable=True"
            )
            return StrategyAssignment(
                strategy=PrerequisiteStrategy.PROBE,
                automatable=True,
                classification_trace=trace,
            )

        # SERVICE -> service strategy (Docker/TCP, non-interactive)
        if prereq.category == PrerequisiteCategory.SERVICE:
            trace = (
                f"category={original_category} -> strategy=service, automatable=True"
            )
            return StrategyAssignment(
                strategy=PrerequisiteStrategy.SERVICE,
                automatable=True,
                classification_trace=trace,
            )

        # CREDENTIAL, ACCOUNT -> manual (requires user interaction)
        if prereq.category in _MANUAL_CATEGORIES:
            trace = (
                f"category={original_category} -> strategy=manual, automatable=False"
            )
            return StrategyAssignment(
                strategy=PrerequisiteStrategy.MANUAL,
                automatable=False,
                classification_trace=trace,
            )

        # USER_ACTION without probe match -> manual
        if prereq.category == PrerequisiteCategory.USER_ACTION:
            trace = (
                f"category={original_category}, no probe match "
                f"-> strategy=manual, automatable=False"
            )
            return StrategyAssignment(
                strategy=PrerequisiteStrategy.MANUAL,
                automatable=False,
                classification_trace=trace,
            )

        # Fallback: unknown category -> use unknown_behavior policy
        unknown_behavior = self._depres_config.get(
            "unknown_behavior", "unverified_non_blocking",
        )
        if unknown_behavior == "manual":
            trace = (
                f"category={original_category}, unknown -> "
                f"policy unknown_behavior=manual -> strategy=manual"
            )
            return StrategyAssignment(
                strategy=PrerequisiteStrategy.MANUAL,
                automatable=False,
                classification_trace=trace,
            )

        # Default: treat as automatable probe (unverified_non_blocking)
        trace = (
            f"category={original_category}, unknown -> "
            f"policy unknown_behavior={unknown_behavior} -> strategy=probe"
        )
        return StrategyAssignment(
            strategy=PrerequisiteStrategy.PROBE,
            automatable=True,
            classification_trace=trace,
        )
