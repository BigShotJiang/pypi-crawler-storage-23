"""Obra Gateway — local HTTP/WebSocket server bridging external clients to HybridOrchestrator.

The gateway package provides a dual-transport server (HTTP/SSE + WebSocket) that allows
external clients to submit objectives, stream progress events, and handle escalations
interactively. It bridges the synchronous HybridOrchestrator callbacks to async transports
via a per-session event bus.

Install gateway dependencies with: pip install obra[gateway]

Key components:
    GatewayServer: FastAPI-based server with HTTP and WebSocket endpoints
    SessionManager: Thread-per-session lifecycle manager
    SessionEventBus: Async queue bridging sync callbacks to async consumers
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from obra.gateway.event_bus import SessionEventBus
    from obra.gateway.server import GatewayServer
    from obra.gateway.session_manager import SessionManager

_PUBLIC_NAMES = {
    "GatewayServer": "obra.gateway.server",
    "SessionManager": "obra.gateway.session_manager",
    "SessionEventBus": "obra.gateway.event_bus",
}

__all__ = ["GatewayServer", "SessionManager", "SessionEventBus"]


def __getattr__(name: str) -> object:
    """PEP 562 lazy loading — defers heavy imports (fastapi, uvicorn) until first use."""
    if name in _PUBLIC_NAMES:
        module_path = _PUBLIC_NAMES[name]
        try:
            import importlib

            module = importlib.import_module(module_path)
        except ImportError as exc:
            msg = (
                f"Gateway requires additional dependencies. "
                f"Install with: pip install obra[gateway]\n"
                f"Original error: {exc}"
            )
            raise ImportError(msg) from exc
        return getattr(module, name)
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)
