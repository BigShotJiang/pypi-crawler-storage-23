"""Bridge between HybridOrchestrator sync callbacks and the SessionEventBus."""

from __future__ import annotations

from typing import Any

from obra.api.protocol import EscalationDecision, EscalationNotice
from obra.gateway.event_bus import SessionEventBus


class OrchestratorBridge:
    """Adapts SessionEventBus to the callback signatures expected by HybridOrchestrator.

    All methods are synchronous — called from the orchestrator thread.

    Args:
        event_bus: The session event bus to push events to.
    """

    def __init__(self, event_bus: SessionEventBus) -> None:
        self._event_bus = event_bus

    @classmethod
    def from_event_bus(cls, event_bus: SessionEventBus) -> OrchestratorBridge:
        """Convenience factory."""
        return cls(event_bus)

    def on_progress(self, action: str, payload: dict[str, Any]) -> None:
        """Progress callback — matches HybridOrchestrator on_progress signature."""
        self._event_bus.push_event("progress", {"action": action, **payload})

    def on_stream(self, event_type: str, content: str) -> None:
        """Stream callback — matches HybridOrchestrator on_stream signature."""
        self._event_bus.push_event("stream", {"event_type": event_type, "content": content})

    def on_escalation(self, notice: EscalationNotice) -> EscalationDecision:
        """Escalation callback — blocks until client resolves or timeout."""
        return self._event_bus.push_escalation(notice)
