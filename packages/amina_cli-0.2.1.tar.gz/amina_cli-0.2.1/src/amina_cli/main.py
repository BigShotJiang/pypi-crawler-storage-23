"""
Amina CLI - Main entry point.

This is the main CLI application using Typer. Subcommands are organized in
separate modules under amina_cli/commands/.
"""

import typer
from rich.console import Console

from amina_cli import __version__
from amina_cli.commands import auth_cmd, init_cmd, jobs_cmd, run_cmd, tools_cmd

# Create the main application
app = typer.Typer(
    name="amina",
    help="""Protein engineering tools at your fingertips.

[bold]Quick start:[/bold]
    amina auth set-key "ami_..."       # Set your API key
    amina tools                        # List all available tools

[bold]Running tools:[/bold]
    amina tools <tool>                 # View tool parameters
    amina run <tool> [OPTIONS]         # Run a tool

[bold]Get an API key:[/bold] https://aminoanalytica.com

[bold]Claude Code integration:[/bold]
    amina init claude-skills           # Install skills to .claude/skills/

    Then run [bold]/amina-init[/bold] in Claude Code to get started.""",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

# Console for rich output
console = Console()

# Register subcommands
app.add_typer(auth_cmd.app, name="auth", help="Manage API key authentication")
app.add_typer(init_cmd.app, name="init", help="Initialize project resources")
app.add_typer(jobs_cmd.app, name="jobs", help="Manage background jobs")
app.add_typer(run_cmd.app, name="run", help="Run computational biology tools")
app.add_typer(tools_cmd.app, name="tools", help="List tools and view their parameters")


@app.command()
def version():
    """Show the CLI version."""
    console.print(f"amina-cli version {__version__}")


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        help="Show version and exit",
        is_eager=True,
    ),
):
    """
    Amina CLI - Protein engineering tools at your fingertips.

    Run computational biology tools from the command line with your AminoAnalytica API key.

    Claude Code: Run 'amina init claude-skills' then '/amina-init' to get started.
    """
    if version:
        console.print(f"amina-cli version {__version__}")
        raise typer.Exit()


if __name__ == "__main__":
    app()
