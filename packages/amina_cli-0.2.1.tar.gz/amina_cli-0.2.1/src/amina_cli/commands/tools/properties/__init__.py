"""Property prediction tools."""
