"""
Amina CLI - Command-line interface for AminoAnalytica protein engineering platform.

Installation:
    pip install amina-cli

Quick start:
    amina auth set-key "ami_your_api_key"
    amina run esmfold --sequence "MKFLILLFNILCLFPVLAADNH"
"""

__version__ = "0.2.1"
