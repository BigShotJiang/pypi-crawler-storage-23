from __future__ import annotations

SPORTS_DETECTION_KIND = "sportvision.sports_detection"
