import platformdirs

ov_dir = platformdirs.user_config_dir("open-vulnera")
