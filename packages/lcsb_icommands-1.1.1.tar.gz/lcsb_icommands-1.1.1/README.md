# lcsb-icommands - iRODS Client for Automatic Ingestion

OAuth2-based data ingestion system for iRODS, using the same Keycloak authentication as Mango.

---

## Overview

```
User Laptop → Keycloak (OAuth2) → lcsb-icommands Client
                      ↓
         lcsb-icommands Server (validates token) → iRODS HTTP API
```

- Browser-based OAuth2 login (SSO on VPN)
- Direct file upload from laptop or staging from server landing zone
- 1-hour sessions with auto-refresh
- iRODS password never exposed to users

---

## Quick Start

### Install

```bash
pip install lcsb-icommands
```

> **Note:** On Linux/macOS, `pip install --user` puts scripts in `~/.local/bin`.
> If commands like `lcsb-icommands` or `ils` are not found, add this to your `~/.bashrc`:
> ```bash
> export PATH="$HOME/.local/bin:$PATH"
> source ~/.bashrc
> ```

### Usage

```bash
lcsb-icommands login                                              # Authenticate (once per session)
lcsb-icommands upload My_project/dataset_01 ./my_files/          # Upload files from laptop
lcsb-icommands staging /server/landing/dir --project P --dataset D  # Stage from server landing zone
lcsb-icommands ls                                                 # List projects
lcsb-icommands ls My_project                                      # List datasets in a project
lcsb-icommands download My_project/dataset_01 ./output/           # Download files
```

---

## Documentation

See [SETUP.md](SETUP.md) for full installation and configuration guide.

---

## Repository Structure

```
lcsb-icommands/
├── client/
│   └── lcsb_icommands.py      # CLI client (single-file, distribute to users)
├── server/
│   └── main.py             # FastAPI server
├── http_api.py             # iRODS HTTP API client
├── INSTALL.sh              # Server installation script
└── SETUP.md                # Full setup guide
```

---

Version: 2.0.0
Author: Sandesh Patil (sandesh.patil@uni.lu)
