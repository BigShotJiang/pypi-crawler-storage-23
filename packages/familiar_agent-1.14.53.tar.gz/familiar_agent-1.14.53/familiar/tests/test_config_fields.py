# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Licensed under the MIT License - see LICENSE file for details

"""Tests: Promoted config fields exist on AgentConfig with correct defaults."""

from familiar.core.config import AgentConfig, _validate_config_section


class TestPromotedConfigDefaults:
    """Each promoted field has the right default on a bare AgentConfig()."""

    def test_planning_enabled_default(self):
        assert AgentConfig().planning_enabled is True

    def test_memory_extraction_enabled_default(self):
        assert AgentConfig().memory_extraction_enabled is True

    def test_guardrail_max_tokens_default(self):
        assert AgentConfig().guardrail_max_tokens == 200_000

    def test_guardrail_max_cost_request_default(self):
        assert AgentConfig().guardrail_max_cost_request == 2.00

    def test_guardrail_max_cost_hour_default(self):
        assert AgentConfig().guardrail_max_cost_hour == 20.00

    def test_guardrail_max_cost_day_default(self):
        assert AgentConfig().guardrail_max_cost_day == 100.00

    def test_max_iterations_default(self):
        assert AgentConfig().max_iterations == 15

    def test_guardrail_rpm_default(self):
        assert AgentConfig().guardrail_rpm == 30

    def test_guardrail_timeout_default(self):
        assert AgentConfig().guardrail_timeout == 300.0

    def test_blocked_tools_default(self):
        assert AgentConfig().blocked_tools == []

    def test_require_approval_tools_default(self):
        assert AgentConfig().require_approval_tools == []

    def test_saga_default_timeout_default(self):
        assert AgentConfig().saga_default_timeout == 300.0

    def test_mesh_enabled_default(self):
        assert AgentConfig().mesh_enabled is False

    def test_hipaa_enabled_default(self):
        assert AgentConfig().hipaa_enabled is False

    def test_distributed_bus_enabled_default(self):
        assert AgentConfig().distributed_bus_enabled is False


class TestMutableListFieldIndependence:
    """Mutable list fields should produce independent instances."""

    def test_blocked_tools_independent(self):
        a = AgentConfig()
        b = AgentConfig()
        a.blocked_tools.append("shell_execute")
        assert b.blocked_tools == []

    def test_require_approval_tools_independent(self):
        a = AgentConfig()
        b = AgentConfig()
        a.require_approval_tools.append("file_write")
        assert b.require_approval_tools == []


class TestValidateConfigAcceptsNewFields:
    """_validate_config_section should accept all promoted field names."""

    def test_no_warnings_for_promoted_fields(self):
        data = {
            "planning_enabled": True,
            "memory_extraction_enabled": True,
            "guardrail_max_tokens": 200_000,
            "guardrail_max_cost_request": 2.00,
            "guardrail_max_cost_hour": 20.00,
            "guardrail_max_cost_day": 100.00,
            "max_iterations": 15,
            "guardrail_rpm": 30,
            "guardrail_timeout": 300.0,
            "blocked_tools": [],
            "require_approval_tools": [],
            "saga_default_timeout": 300.0,
            "mesh_enabled": False,
            "hipaa_enabled": False,
            "distributed_bus_enabled": False,
        }
        warnings = []
        _validate_config_section(data, AgentConfig, "agent", warnings)
        assert warnings == []
