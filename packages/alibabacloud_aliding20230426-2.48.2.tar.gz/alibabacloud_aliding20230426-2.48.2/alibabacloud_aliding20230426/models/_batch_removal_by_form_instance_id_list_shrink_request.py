# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class BatchRemovalByFormInstanceIdListShrinkRequest(DaraModel):
    def __init__(
        self,
        app_type: str = None,
        asynchronous_execution: bool = None,
        execute_expression: bool = None,
        form_instance_id_list_shrink: str = None,
        form_uuid: str = None,
        system_token: str = None,
    ):
        # This parameter is required.
        self.app_type = app_type
        self.asynchronous_execution = asynchronous_execution
        self.execute_expression = execute_expression
        # This parameter is required.
        self.form_instance_id_list_shrink = form_instance_id_list_shrink
        # This parameter is required.
        self.form_uuid = form_uuid
        # This parameter is required.
        self.system_token = system_token

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.app_type is not None:
            result['AppType'] = self.app_type

        if self.asynchronous_execution is not None:
            result['AsynchronousExecution'] = self.asynchronous_execution

        if self.execute_expression is not None:
            result['ExecuteExpression'] = self.execute_expression

        if self.form_instance_id_list_shrink is not None:
            result['FormInstanceIdList'] = self.form_instance_id_list_shrink

        if self.form_uuid is not None:
            result['FormUuid'] = self.form_uuid

        if self.system_token is not None:
            result['SystemToken'] = self.system_token

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('AppType') is not None:
            self.app_type = m.get('AppType')

        if m.get('AsynchronousExecution') is not None:
            self.asynchronous_execution = m.get('AsynchronousExecution')

        if m.get('ExecuteExpression') is not None:
            self.execute_expression = m.get('ExecuteExpression')

        if m.get('FormInstanceIdList') is not None:
            self.form_instance_id_list_shrink = m.get('FormInstanceIdList')

        if m.get('FormUuid') is not None:
            self.form_uuid = m.get('FormUuid')

        if m.get('SystemToken') is not None:
            self.system_token = m.get('SystemToken')

        return self

