"""
Output module for the speech transcription pipeline.

Generates markdown documents with slides interleaved at correct timestamps
or in a sequential gallery layout.
"""

import re
from pathlib import Path

from transcribe_critic.shared import (
    tprint as print,
    SpeechConfig, SpeechData, is_up_to_date,
    TRANSCRIPT_MD, SLIDE_TIMESTAMPS_JSON,
    _print_reusing, _dry_run_skip, _should_skip,
)


def generate_markdown(config: SpeechConfig, data: SpeechData) -> None:
    """Generate markdown document with slides interleaved at correct timestamps."""
    print()
    print("[markdown] Generating markdown...")

    markdown_path = config.output_dir / TRANSCRIPT_MD

    # Inputs: merged or whisper transcript, slide timestamps, slides JSON
    md_inputs = [p for p in [data.merged_transcript_path, data.transcript_path,
                             data.slides_json_path] if p]
    timestamps_file = config.output_dir / SLIDE_TIMESTAMPS_JSON
    if timestamps_file.exists():
        md_inputs.append(timestamps_file)
    if _should_skip(config, markdown_path, "generate markdown", *md_inputs):
        if markdown_path.exists():
            data.markdown_path = markdown_path
        return

    # Determine if we can do timestamp-based placement
    has_timestamps = (
        data.transcript_segments and
        data.slide_timestamps and
        len(data.slide_timestamps) > 0
    )

    if has_timestamps:
        print("  Using timestamp-based slide placement")
        content = _generate_interleaved_markdown(data)
    else:
        print("  Using sequential layout (no timestamps available)")
        content = _generate_sequential_markdown(data)

    # Write markdown
    with open(markdown_path, 'w') as f:
        f.write(content)

    data.markdown_path = markdown_path
    print(f"  Markdown saved: {markdown_path.name}")


def _generate_interleaved_markdown(data: SpeechData) -> str:
    """Generate markdown with slides placed at their timestamp positions.

    Note: Interleaved mode uses Whisper segments for timestamps.
    For merged transcript content, use sequential mode.
    """
    lines = [
        f"# {data.title}",
        "",
        "---",
        "",
    ]

    # Note about source
    source_note = "Whisper transcript"
    if data.merged_transcript_path and data.merged_transcript_path.exists():
        source_note = "Whisper transcript (merged version available in transcript_merged.txt)"

    # Create a list of all events (segments and slides) sorted by timestamp
    events = []

    # Add transcript segments
    for seg in data.transcript_segments:
        event = {
            "type": "text",
            "timestamp": seg["start"],
            "content": seg["text"],
        }
        if seg.get("speaker"):
            event["speaker"] = seg["speaker"]
        events.append(event)

    # Add slides
    for slide_info in data.slide_timestamps:
        slide_idx = slide_info["slide_number"] - 1
        if slide_idx < len(data.slide_images):
            slide_path = data.slide_images[slide_idx]

            # Get slide metadata if available
            alt_text = f"Slide {slide_info['slide_number']}"
            if data.slide_metadata and slide_idx < len(data.slide_metadata):
                meta = data.slide_metadata[slide_idx]
                if meta.get("title"):
                    alt_text = meta["title"]

            events.append({
                "type": "slide",
                "timestamp": slide_info["timestamp"],
                "filename": slide_path.name,
                "alt_text": alt_text,
                "slide_number": slide_info["slide_number"]
            })

    # Sort all events by timestamp
    events.sort(key=lambda x: x["timestamp"])

    # Group consecutive text segments into paragraphs by speaker
    current_paragraph = []
    current_speaker = None
    last_slide_time = -1

    def _flush_paragraph():
        if not current_paragraph:
            return
        if current_speaker:
            lines.append(f"**{current_speaker}**")
            lines.append("")
        paragraph_text = " ".join(current_paragraph)
        lines.append(_format_paragraph(paragraph_text))
        lines.append("")

    for event in events:
        if event["type"] == "text":
            speaker = event.get("speaker")
            if speaker != current_speaker and current_paragraph:
                _flush_paragraph()
                current_paragraph = []
            current_speaker = speaker
            current_paragraph.append(event["content"])
        elif event["type"] == "slide":
            # Flush current paragraph before slide
            _flush_paragraph()
            current_paragraph = []
            current_speaker = None

            # Add slide
            lines.append(f"![{event['alt_text']}](slides/{event['filename']})")
            lines.append("")
            last_slide_time = event["timestamp"]

    # Flush remaining paragraph
    _flush_paragraph()

    # Add footer
    lines.extend([
        "---",
        "",
        f"*Generated by transcriber.py (source: {source_note})*",
    ])

    return '\n'.join(lines)


def _get_best_transcript_text(data: SpeechData) -> str:
    """Get the best available transcript text (merged > whisper)."""
    # Prefer merged transcript if available
    if data.merged_transcript_path and data.merged_transcript_path.exists():
        with open(data.merged_transcript_path, 'r') as f:
            return f.read()

    # Fall back to Whisper transcript
    if data.transcript_path and data.transcript_path.exists():
        with open(data.transcript_path, 'r') as f:
            return f.read()

    return ""


def _generate_sequential_markdown(data: SpeechData) -> str:
    """Generate markdown with slides in a gallery (fallback when no timestamps)."""
    lines = [
        f"# {data.title}",
        "",
        "---",
        "",
    ]

    # Add title slide if we have slides
    if data.slide_images:
        first_slide = data.slide_images[0]
        lines.extend([
            f"[![Title Slide](slides/{first_slide.name})](slides/{first_slide.name})",
            "",
            "---",
            "",
        ])

    # Add transcript
    lines.append("## Transcript")
    lines.append("")

    transcript_text = _get_best_transcript_text(data)
    if transcript_text:
        lines.append(transcript_text)
    lines.append("")

    # Add slides gallery if we have them
    if data.slide_images:
        lines.extend([
            "---",
            "",
            "## Slides",
            "",
        ])

        for i, slide_path in enumerate(data.slide_images):
            slide_info = ""
            if data.slide_metadata and i < len(data.slide_metadata):
                meta = data.slide_metadata[i]
                if meta.get("title"):
                    slide_info = f" - {meta['title']}"
                elif meta.get("description"):
                    slide_info = f" - {meta['description'][:50]}"

            lines.append(f"### Slide {i+1}{slide_info}")
            lines.append("")
            lines.append(f"[![Slide {i+1}](slides/{slide_path.name})](slides/{slide_path.name})")
            lines.append("")

    # Add footer
    source_note = "merged transcript" if data.merged_transcript_path else "Whisper transcript"
    lines.extend([
        "---",
        "",
        f"*Generated by transcriber.py (source: {source_note})*",
    ])

    return '\n'.join(lines)


def _format_paragraph(text: str) -> str:
    """Format a paragraph of text, adding line breaks at sentence boundaries for readability."""
    # Simple sentence splitting - break on . ! ? followed by space and capital
    # This keeps the text readable in markdown
    sentences = re.split(r'(?<=[.!?])\s+(?=[A-Z])', text)

    # Group into ~3 sentence chunks for readability
    chunks = []
    current_chunk = []
    for sentence in sentences:
        current_chunk.append(sentence)
        if len(current_chunk) >= 3:
            chunks.append(" ".join(current_chunk))
            current_chunk = []

    if current_chunk:
        chunks.append(" ".join(current_chunk))

    return "\n\n".join(chunks)
