from transcribe_critic.transcriber import main

main()
