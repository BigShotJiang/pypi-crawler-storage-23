import re
from sylriekit.ConfigLoader import ConfigLoader


class ReLib:
    config = None
    _config_items = {
        "unique_string_id": "@UStr:#|",
        "string_id_num_char": "#",
        "string_id_padding_char": "_"
    }

    def __init__(self, config: dict | str = None):
        self.config = ConfigLoader("ReLib", self._config_items, config)
        self.cur_str_id = 0
        self.index_sets = [{}]
        self.cur_idx_id = 0
        self._temp_idx_id = None
        self.values = []
        self._split_result = []

    def _get_indexes(self):
        if self._temp_idx_id is not None:
            idx = self._temp_idx_id
            self._temp_idx_id = None
            if idx >= len(self.index_sets):
                raise Exception("Invalid index set id")
            return self.index_sets[idx]
        return self.index_sets[self.cur_idx_id]

    def _get_safe_string_id(self, text: str):
        string_id = self.config.get("unique_string_id")
        num_char = self.config.get("string_id_num_char")
        padding = self.config.get("string_id_padding_char")
        prefix = string_id.split(num_char)[0]
        while prefix in text:
            string_id = padding + string_id
            prefix = padding + prefix
        return string_id

    def _remove_extracted(self, text: str, matches, cur_id_num: int,
                          string_id: str, indexes: dict):
        id_num = cur_id_num
        new_text = text
        for match in matches:
            id_num += 1
            str_id_val = string_id.replace(
                self.config.get("string_id_num_char"), str(id_num)
            )
            if match.group(0) in indexes.values():
                id_num -= 1
                continue
            new_text = new_text.replace(match.group(0), str_id_val)
            indexes[str_id_val] = match.group(0)
        self.values[self.cur_str_id] = new_text
        return self

    @staticmethod
    def _build_between_pattern(start: list[str], end: list[str],
                               ignore: list[str] = None, regex: bool = False):
        def prep(possible_re_str):
            return possible_re_str if regex else re.escape(possible_re_str)

        alternatives = []
        for s, e in zip(start, end):
            s_p, e_p = prep(s), prep(e)
            if ignore:
                ign_group = "|".join(prep(i) for i in ignore)
                inner = f"(?:{ign_group}|(?!{e_p}).)*"
            else:
                inner = f"(?:(?!{e_p}).)*"
            alternatives.append(f"({s_p}{inner}{e_p})")

        return re.compile("|".join(alternatives), re.DOTALL)

    def use_indexes(self, idx_id: int):
        self._temp_idx_id = idx_id
        return self

    def set_indexes(self, idx_id: int):
        if idx_id >= len(self.index_sets):
            raise Exception("Invalid index set id")
        self.cur_idx_id = idx_id
        return self

    def new_indexes(self):
        self.index_sets.append({})
        self.cur_idx_id = len(self.index_sets) - 1
        return self

    def load(self, text: str | int):
        if isinstance(text, int):
            if text >= len(self.values):
                raise Exception("Invalid string id")
            elif text < 0:
                self.cur_str_id = len(self.values) - 1
            else:
                self.cur_str_id = text
        else:
            self.values.append(text)
            self.cur_str_id = len(self.values) - 1
        return self

    def extract_strings(self):
        indexes = self._get_indexes()
        text = self.values[self.cur_str_id]
        id_num = len(indexes)
        string_id = self._get_safe_string_id(text)
        pattern = re.compile(
            r'"""[^"\\]*(?:(?:\\.|"(?!""))[^"\\]*)*"""'
            r"|'''[^'\\]*(?:(?:\\.|'(?!''))[^'\\]*)*'''"
            r"|```[^`\\]*(?:(?:\\.|`(?!``))[^`\\]*)*```"
            r'|"[^"\\]*(?:\\.[^"\\]*)*"'
            r"|'[^'\\]*(?:\\.[^'\\]*)*'"
            r'|`[^`\\]*(?:\\.[^`\\]*)*`',
            re.DOTALL
        )
        matches = pattern.finditer(text)
        return self._remove_extracted(text, matches, id_num, string_id, indexes)

    def extract_between(self, start: list[str], end: list[str],
                        ignore: list[str] = None, regex: bool = False):
        indexes = self._get_indexes()
        text = self.values[self.cur_str_id]
        id_num = len(indexes)
        string_id = self._get_safe_string_id(text)

        pattern = self._build_between_pattern(start, end, ignore=ignore, regex=regex)
        matches = pattern.finditer(text)
        return self._remove_extracted(text, matches, id_num, string_id, indexes)

    def extract_nested(self, open_delim: str, close_delim: str):
        indexes = self._get_indexes()
        text = self.values[self.cur_str_id]
        id_num = len(indexes)
        string_id = self._get_safe_string_id(text)

        new_text = text
        i = 0
        o_len = len(open_delim)
        c_len = len(close_delim)
        while i < len(new_text):
            if new_text[i:i + o_len] == open_delim:
                depth = 1
                j = i + o_len
                while j < len(new_text) and depth > 0:
                    if new_text[j:j + c_len] == close_delim:
                        depth -= 1
                        j += c_len
                    elif new_text[j:j + o_len] == open_delim:
                        depth += 1
                        j += o_len
                    else:
                        j += 1
                if depth == 0:
                    matched = new_text[i:j]
                    if matched not in indexes.values():
                        id_num += 1
                        str_id_val = string_id.replace(
                            self.config.get("string_id_num_char"), str(id_num)
                        )
                        indexes[str_id_val] = matched
                        new_text = new_text[:i] + str_id_val + new_text[j:]
                        i += len(str_id_val)
                    else:
                        i = j
                else:
                    i += 1
            else:
                i += 1
        self.values[self.cur_str_id] = new_text
        return self

    def split(self, splits: list[str], regex: bool = False):
        text = self.values[self.cur_str_id]
        if regex:
            pattern = "|".join(splits)
        else:
            pattern = "|".join(re.escape(s) for s in splits)
        self._split_result = re.split(pattern, text)
        return self

    def split_keep(self, splits: list[str], regex: bool = False):
        text = self.values[self.cur_str_id]
        if regex:
            parts = "|".join(splits)
        else:
            parts = "|".join(re.escape(s) for s in splits)
        self._split_result = re.split(f"({parts})", text)
        return self

    def replace(self, find: list[str], replace_with: list[str], regex: bool = False):
        text = self.values[self.cur_str_id]
        for f, r in zip(find, replace_with):
            if regex:
                text = re.sub(f, r, text)
            else:
                text = text.replace(f, r)
        self.values[self.cur_str_id] = text
        return self

    def replace_between(self, start: list[str], end: list[str], replacement: str,
                        ignore: list[str] = None, regex: bool = False):
        text = self.values[self.cur_str_id]
        pattern = self._build_between_pattern(start, end, ignore=ignore, regex=regex)
        self.values[self.cur_str_id] = pattern.sub(replacement, text)
        return self

    def strip_between(self, start: list[str], end: list[str],
                      ignore: list[str] = None, regex: bool = False):
        return self.replace_between(start, end, "", ignore, regex)

    def insert_extracted(self, new_id: int = None, new_text: str = None,
                         recursive: bool = False):
        indexes = self._get_indexes()
        if new_id is not None:
            self.load(new_id)
        if new_text is not None:
            self.values[self.cur_str_id] = new_text
        text = self.values[self.cur_str_id]
        for key, value in indexes.items():
            text = text.replace(key, value, 1)
        if recursive:
            has_placeholder = True
            while has_placeholder:
                has_placeholder = False
                for key, value in indexes.items():
                    if key in text:
                        text = text.replace(key, value, 1)
                        has_placeholder = True
        self.values[self.cur_str_id] = text
        return self

    def get_raw(self):
        return self.values, self.index_sets, self.cur_str_id

    def get_id(self):
        return self.cur_str_id

    def get_idx_id(self):
        return self.cur_idx_id

    def get_text(self):
        return self.values[self.cur_str_id]

    def get_split(self):
        return self._split_result

    def get_indexes(self, idx_id: int = None):
        if idx_id is not None:
            if idx_id >= len(self.index_sets):
                raise Exception("Invalid index set id")
            return self.index_sets[idx_id]
        return self.index_sets[self.cur_idx_id]

    def get_matches(self, pattern: str, regex: bool = False):
        text = self.values[self.cur_str_id]
        if not regex:
            pattern = re.escape(pattern)
        return re.findall(pattern, text)

    def get_positions(self, pattern: str, regex: bool = False):
        text = self.values[self.cur_str_id]
        if not regex:
            pattern = re.escape(pattern)
        return [(m.start(), m.end(), m.group(0)) for m in re.finditer(pattern, text)]

    def get_lines(self, pattern: str, regex: bool = False):
        text = self.values[self.cur_str_id]
        if not regex:
            pattern = re.escape(pattern)
        compiled = re.compile(pattern)
        return [line for line in text.splitlines() if compiled.search(line)]

    def get_count(self, pattern: str, regex: bool = False):
        return len(self.get_matches(pattern, regex))

    def get_contains(self, pattern: str, regex: bool = False):
        return self.get_count(pattern, regex) > 0

    def get_unextracted(self):
        indexes = self._get_indexes()
        text = self.values[self.cur_str_id]
        for key in indexes:
            text = text.replace(key, "")
        return text