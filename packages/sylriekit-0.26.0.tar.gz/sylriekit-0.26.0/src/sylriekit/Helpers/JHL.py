from sylriekit.ConfigLoader import ConfigLoader
from sylriekit.Files import Files
from sylriekit.ReLib import ReLib
from sylriekit.JHtml import JHtml
from sylriekit.Helpers.JHtml import JHtmlPath
import math
import json
import hashlib
import re
import textwrap
from datetime import datetime
import os

class JHLCommandHandler:
    _COMMANDS_HELP: dict = {
        "import": {
            "signature":   "import (JHL file path)",
            "description": "Imports another JHL script and runs it instantly before continuing",
            "flags": [
                (["force", "f"], "Optional", "Run even if already cached / hashed"),
                (["after",  "a"], "Optional", "Add as next-in-queue instead of running instantly"),
            ],
        },
        "help": {
            "signature":   "help  |  help (command)",
            "description": "Prints help for all commands (or a single command) to the log and console",
            "flags": [],
        },
        "meta": {
            "signature":   "meta (key) (value)",
            "description": (
                "Sets a metadata value on the currently-executing script's hash. "
                "Special key -- always_run (bool): never skip this script even if already hashed"
            ),
            "flags": [],
        },
        "var": {
            "signature":   "var (name) (operator) (value)",
            "description": (
                "Declare or update a variable. "
                "Types: str, number (int / float), bool. "
                "Operators: =  +  -  +=  -=  *=  /=  ^=. "
                "Defaults when var is unset: '' for str,  0 for number,  false for bool"
            ),
            "flags": [
                (["-s", "-str",       "-string"                      ], "Optional", "Force string type"),
                (["-n", "-num",       "-number"                      ], "Optional", "Force number (int / float) type"),
                (["-b", "-bool"                                      ], "Optional", "Force boolean type"),
                (["-v", "-var",       "-variable"                    ], "Optional", "Treat value as a variable reference"),
                (["-p", "-pv", "-path", "-path_var", "-path_variable"], "Optional",
                 "Create a JHtmlPath cursor from the given selector string. Navigate with the cd command."),
                (["-ds", "-dstr", "-dystr",
                  "-dynamic_str", "-dynamic_string"                  ], "Optional",
                 "Interpolate {varname} placeholders at assignment time, then store as a plain string"),
                (["-r N", "-round N"                                 ], "Optional",
                 "Round result to N  (e.g. -r 0.1 = tenths,  -r 1 = integer)"),
            ],
        },
        "add": {
            "signature":   "add (jhtml path) (json|html)",
            "description": (
                "Appends a new child element to the node found at the given JHtml path. "
                "Accepts raw JSON or an HTML snippet (auto-converted)."
            ),
            "flags": [
                (["-j", "-json"], "Optional", "Treat value as JSON  (default)"),
                (["-h", "-html"], "Optional", "Treat value as HTML and auto-convert to a node"),
            ],
        },
        "rm": {
            "signature":   "rm (jhtml path)",
            "description": "Removes the element at the given JHtml path from the tree",
            "flags": [],
        },
        "cd": {
            "signature":   "cd (path_var) (cd_path)",
            "description": (
                "Navigate a Path variable using JHtmlPath.cd(). "
                "The first argument must be the name of a variable created with 'var -p'. "
                "The second argument is the cd path string (supports .., ~, selectors, etc.)."
            ),
            "flags": [],
        },
        "mod": {
            "signature":   "mod (jhtml path) (json|html)",
            "description": (
                "Replaces the element at the given JHtml path with a new node. "
                "Accepts raw JSON or an HTML snippet (auto-converted)."
            ),
            "flags": [
                (["-j", "-json"], "Optional", "Treat value as JSON  (default)"),
                (["-h", "-html"], "Optional", "Treat value as HTML and auto-convert to a node"),
            ],
        },
        "log": {
            "signature":   "log (value)",
            "description": (
                "Writes a value to the compile log. "
                "If the value matches a known variable it is resolved by default. "
                "Use -str to log the literal token instead of the variable value, "
                "or -var to force variable resolution even for string-like tokens."
            ),
            "flags": [
                (["-var", "-v"], "Optional", "Force variable resolution"),
                (["-str", "-s"], "Optional", "Log the raw token as a string, ignoring variables"),
            ],
        },
        "shortcut": {
            "signature":   "shortcut (name) (value)",
            "description": (
                "Defines a shortcut alias. "
                "If value is a single word it becomes a command alias (args pass through). "
                "If value is a quoted JHL snippet it is parsed and run when the shortcut is invoked."
            ),
            "flags": [],
        },
        "fn": {
            "signature":   "fn new [-py] (name) (body)  |  fn (name) [args...]",
            "description": (
                "Define or call a JHL/Python function. "
                "'fn new (name) \"\"\"body\"\"\"' stores a JHL function. "
                "'fn new -py (name) \'\'\'body\'\'\'' stores a Python function. "
                "Calling 'fn (name) arg1 arg2...' sets arg1, arg2, ... variables, runs the body, "
                "then wipes all argN variables. All other vars are global."
            ),
            "flags": [
                (["-py"], "Optional (define only)", "Store body as Python instead of JHL"),
            ],
        },
        "py": {
            "signature":   "py (python code)",
            "description": (
                "Execute a Python snippet immediately. "
                "The snippet has access to: vars (the live variable dict), "
                "args (empty list), and jhl(text) to run JHL commands inline."
            ),
            "flags": [],
        },
        "objc": {
            "signature":   "objc (name)[:(param_names)] (path) [-flag (flag)] { body }",
            "description": (
                "Define a custom object type. The body is a JHL script that receives "
                "'path' and any declared flags/params as variables. "
                "Invoke via:  obj (path) (name) [-flag value];  or  obj (path) name:value;"
            ),
            "flags": [],
        },
        "if": {
            "signature":   "if (condition); ... elif (condition); ... else; ... endif;",
            "description": (
                "Conditional execution. Evaluates a condition and runs the following "
                "commands only if the condition is truthy. Supports elif/else branches. "
                "Must be closed with endif. Conditions support: bare variable truthiness, "
                "comparisons (==, !=, >, <, >=, <=), logical operators (and, or, not), "
                "and the exists(path) function to test if a JHtml path resolves."
            ),
            "flags": [],
        },
        "elif": {
            "signature":   "elif (condition);",
            "description": "Alternate branch in an if block. Evaluated only if all prior if/elif conditions were false.",
            "flags": [],
        },
        "else": {
            "signature":   "else;",
            "description": "Default branch in an if block. Runs only if all prior if/elif conditions were false.",
            "flags": [],
        },
        "endif": {
            "signature":   "endif;",
            "description": "Closes an if/elif/else block.",
            "flags": [],
        },
    }

    _HELP_PAD: str = "       |"

    def __init__(self, config: dict | str = None, dev: bool = False):
        self.config = ConfigLoader("_JHLCommandHandler", {}, config)
        self.files = Files(config)
        self.relib = ReLib(config)
        self.dev = dev

        self.jhtml:            JHtml | None = None
        self.vars:             dict = {}
        self.shortcuts:        dict = {}
        self.functions:        dict = {}
        self.custom_objects:   dict = {}
        self.script_hashes:    set = set()
        self.scripts_metadata: dict = {}
        self.script_queue:     list = []
        self.current_script_queue_index: int = 0
        self._current_script_hash:       str | None = None

        self._entries:  list[str] = []
        self._warnings: list[str] = []
        self._errors:   list[str] = []

        self._js_handler  = JHLJavaScriptCommandHandler(self)
        self._css_handler = JHLCSSCommandHandler(self)
        self._obj_handler = JHLObjectsCommandHandler(self)

        self._COMMANDS_HELP.update(self._js_handler.HELP)
        self._COMMANDS_HELP.update(self._css_handler.HELP)
        self._COMMANDS_HELP.update(self._obj_handler.HELP)

    def set_jhtml(self, jhtml: JHtml) -> None:
        self.jhtml = jhtml

    def queue_script(self, jhl_script) -> None:
        self.script_queue.append(self._make_script(jhl_script))

    def insert_script_to_queue(self, jhl_script) -> None:
        idx = self.current_script_queue_index + 1
        self.script_queue.insert(idx, self._make_script(jhl_script))

    def run_queue(self, json_html, root_cwd: str) -> tuple:
        log_start = len(self._entries)
        warn_start = len(self._warnings)
        err_start = len(self._errors)

        self._ensure_jhtml(json_html)

        self.current_script_queue_index = 0
        result = self.jhtml.json()

        while self.current_script_queue_index < len(self.script_queue):
            script = self.script_queue[self.current_script_queue_index]
            result = self._execute_script(script, result, root_cwd)
            self.current_script_queue_index += 1

        return result, self._get_run_info(log_start, warn_start, err_start)

    def run_script(self, jhl_script, json_html, root_cwd: str,
                   clear_data: bool = True) -> tuple:
        if clear_data:
            self.clear_data()

        log_start = len(self._entries)
        warn_start = len(self._warnings)
        err_start = len(self._errors)

        self._ensure_jhtml(json_html)

        script = self._make_script(jhl_script)
        result = self._execute_script(script, self.jhtml.json(), root_cwd)

        return result, self._get_run_info(log_start, warn_start, err_start)

    def clear_data(self) -> None:
        self._entries = []
        self._warnings = []
        self._errors = []
        self._obj_handler.clear_reactive_state()

    def _execute_script(self, script: dict, json_html, root_cwd: str):
        h = script["hash"]
        always_run = self.scripts_metadata.get(h, {}).get("always_run", False)

        if not self.dev and h in self.script_hashes and not always_run:
            label = script.get("path") or h[:8]
            self._log_entry("INFO", f"[script] Skipping (already hashed): {label}")
            return json_html

        if not self.dev and not always_run:
            self.script_hashes.add(h)

        prev_hash = self._current_script_hash
        self._current_script_hash = h
        try:
            commands = self._prepare_jhl(script["content"])
            label = script.get("path") or h[:8]
            self._log_entry("INFO", f"[script] Running {len(commands)} command(s) [{label}]")
            self._sync_jhtml(json_html)
            json_html = self._run_commands(commands, json_html, root_cwd)
        finally:
            self._current_script_hash = prev_hash

        return json_html

    def _run_commands(self, commands: list, json_html, root_cwd: str):

        if_stack: list[dict] = []

        for cmd_dict in commands:
            for cmd, args in cmd_dict.items():

                if cmd == "if":
                    cond = self._evaluate_condition(args)
                    if_stack.append({"active": cond, "resolved": cond})
                    continue

                if cmd == "elif":
                    if not if_stack:
                        self._log_entry("WARNING", "[elif] No matching 'if' -- skipped")
                        continue
                    top = if_stack[-1]
                    if top["resolved"]:
                        top["active"] = False
                    else:
                        cond = self._evaluate_condition(args)
                        top["active"] = cond
                        if cond:
                            top["resolved"] = True
                    continue

                if cmd == "else":
                    if not if_stack:
                        self._log_entry("WARNING", "[else] No matching 'if' -- skipped")
                        continue
                    top = if_stack[-1]
                    top["active"] = not top["resolved"]
                    top["resolved"] = True
                    continue

                if cmd == "endif":
                    if not if_stack:
                        self._log_entry("WARNING", "[endif] No matching 'if' -- skipped")
                        continue
                    if_stack.pop()
                    continue

                if if_stack and not if_stack[-1]["active"]:
                    continue

                json_html = self._run_command(cmd, args, json_html, root_cwd)

        if if_stack:
            self._log_entry("WARNING",
                            f"[if] {len(if_stack)} unclosed if block(s) at end of script")

        return json_html

    def _evaluate_condition(self, tokens: list) -> bool:
        if not tokens:
            return False

        parts = [str(t) for t in tokens]

        if len(parts) == 1:
            return self._cond_truthy(parts[0])

        try:
            result, _ = self._parse_or_expr(parts, 0)
            return result
        except Exception as exc:
            self._log_entry("WARNING", f"[if] Condition parse error: {exc}")
            return False

    def _parse_or_expr(self, parts: list, pos: int) -> tuple:
        result, pos = self._parse_and_expr(parts, pos)
        while pos < len(parts) and parts[pos].lower() == "or":
            pos += 1
            right, pos = self._parse_and_expr(parts, pos)
            result = result or right
        return result, pos

    def _parse_and_expr(self, parts: list, pos: int) -> tuple:
        result, pos = self._parse_not_expr(parts, pos)
        while pos < len(parts) and parts[pos].lower() == "and":
            pos += 1
            right, pos = self._parse_not_expr(parts, pos)
            result = result and right
        return result, pos

    def _parse_not_expr(self, parts: list, pos: int) -> tuple:
        if pos < len(parts) and parts[pos].lower() == "not":
            pos += 1
            result, pos = self._parse_not_expr(parts, pos)
            return not result, pos
        return self._parse_comparison(parts, pos)

    def _parse_comparison(self, parts: list, pos: int) -> tuple:
        left, pos = self._parse_atom(parts, pos)
        cmp_ops = {"==", "!=", ">", "<", ">=", "<="}
        if pos < len(parts) and parts[pos] in cmp_ops:
            op = parts[pos]
            pos += 1
            right, pos = self._parse_atom(parts, pos)
            return self._cmp(left, op, right), pos

        return bool(left), pos

    def _parse_atom(self, parts: list, pos: int) -> tuple:
        if pos >= len(parts):
            return None, pos

        token = parts[pos]

        if token.lower().startswith("exists(") and token.endswith(")"):
            path_str = token[7:-1]
            found = self._path_find(path_str) is not None
            return found, pos + 1

        return self._cond_resolve(token), pos + 1

    def _cond_resolve(self, token: str):
        if token in self.vars:
            return self.vars[token]

        try:
            return int(token)
        except (ValueError, TypeError):
            pass
        try:
            return float(token)
        except (ValueError, TypeError):
            pass
        if token.lower() == "true":
            return True
        if token.lower() == "false":
            return False
        return token

    def _cond_truthy(self, token: str) -> bool:

        if token.lower().startswith("exists(") and token.endswith(")"):
            path_str = token[7:-1]
            return self._path_find(path_str) is not None
        val = self._cond_resolve(token)
        if isinstance(val, str) and val.lower() in ("false", "0", ""):
            return False
        return bool(val)

    @staticmethod
    def _cmp(left, op: str, right) -> bool:
        try:
            if op == "==": return left == right
            if op == "!=": return left != right
            if op == ">":  return left > right
            if op == "<":  return left < right
            if op == ">=": return left >= right
            if op == "<=": return left <= right
        except TypeError:
            return False
        return False

    def _run_command(self, command: str, args: list, json_html, root_cwd: str):
        dispatch = {
            "import":   self._import_command,
            "help":     self._help_command,
            "meta":     self._meta_command,
            "var":      self._var_command,
            "add":      self._add_command,
            "rm":       self._rm_command,
            "cd":       self._cd_command,
            "mod":      self._mod_command,
            "log":      self._log_command,
            "shortcut": self._shortcut_command,
            "fn":       self._fn_command,
            "py":       self._py_command,
            "js":       self._js_handler.run,
            "css":      self._css_handler.run,
            "obj":      self._obj_handler.run,
            "objc":     self._objc_command,
        }
        if command in dispatch:
            return dispatch[command](args, json_html, root_cwd)

        if command in self.shortcuts:
            return self._expand_shortcut(command, args, json_html, root_cwd)

        self._log_entry("WARNING", f"[cmd] Unknown command '{command}' -- skipped")
        return json_html

    def _import_command(self, args: list, json_html, root_cwd: str):
        force = False
        after = False
        path_tokens: list[str] = []

        for token in args:
            t = str(token).lower()
            if t in ("-force", "-f"):
                force = True
            elif t in ("-after", "-a"):
                after = True
            else:
                path_tokens.append(str(token))

        if not path_tokens:
            self._log_entry("WARNING", "[import] No file path provided -- skipped")
            return json_html

        rel_path = path_tokens[0]
        abs_path = os.path.normpath(os.path.join(root_cwd, rel_path))
        flag_note = "".join(
            f" [{label}]" for label, active in [("force", force), ("after", after)] if active
        )
        self._log_entry("INFO", f"[import]{flag_note} Loading: {abs_path}")

        content = self.files.read(abs_path)
        if content is None:
            self._log_entry("ERROR", f"[import] Could not read: {abs_path}")
            return json_html

        script = self._make_script({"content": content, "path": rel_path})
        h = script["hash"]
        always_run = self.scripts_metadata.get(h, {}).get("always_run", False)

        if after:
            if force:
                self.script_hashes.discard(h)
            self.insert_script_to_queue(script)
            self._log_entry("INFO", f"[import] Queued as next: {rel_path}")
            return json_html

        if h in self.script_hashes and not force and not always_run and not self.dev:
            self._log_entry("INFO", f"[import] Skipping (already hashed): {rel_path}")
            return json_html

        if force and h in self.script_hashes:
            self._log_entry("INFO", f"[import] Force re-run: {rel_path}")
            self.script_hashes.discard(h)

        import_dir = os.path.dirname(abs_path)
        return self._execute_script(script, json_html, import_dir)

    def _help_command(self, args: list, json_html, _root_cwd: str):
        output = (
            self._format_help_entry(str(args[0]).lower())
            if args
            else self._format_all_help()
        )
        print(output)
        self._log_entry("HELP", "\n" + output)
        return json_html

    def _meta_command(self, args: list, json_html, _root_cwd: str):
        if len(args) < 2:
            self._log_entry("WARNING", "[meta] Requires (key) and (value) -- skipped")
            return json_html

        key = str(args[0])
        raw_value = args[1]

        if isinstance(raw_value, str) and raw_value.lower() in ("true", "false"):
            value = (raw_value.lower() == "true")
        else:
            value = raw_value

        h = self._current_script_hash
        if h is None:
            self._log_entry("WARNING", "[meta] No active script hash -- skipped")
            return json_html

        if h not in self.scripts_metadata:
            self.scripts_metadata[h] = {}
        self.scripts_metadata[h][key] = value

        self._log_entry("INFO", f"[meta] {key!r} = {value!r}  (script {h[:8]}...)")
        return json_html

    def _var_command(self, args: list, json_html, _root_cwd: str):
        if not args:
            self._log_entry("WARNING", "[var] No arguments -- skipped")
            return json_html

        try:
            varname, op, raw_value, type_flag, round_to = self._parse_var_args(args)
        except Exception as exc:
            self._log_entry("ERROR", f"[var] Parse error: {exc}")
            return json_html

        if op is None:
            self._log_entry("WARNING", f"[var] No operator found for '{varname}' -- skipped")
            return json_html
        if raw_value is None and op != "=":
            self._log_entry("WARNING", f"[var] Missing value for '{varname} {op}' -- skipped")
            return json_html

        value = self._infer_value(raw_value, type_flag)

        try:
            result = self._apply_op(varname, op, value)
        except ZeroDivisionError:
            self._log_entry("ERROR", f"[var] Division by zero: '{varname} {op} {value}'")
            return json_html
        except TypeError as exc:
            self._log_entry("ERROR", f"[var] Type error for '{varname} {op} {value}': {exc}")
            return json_html
        except Exception as exc:
            self._log_entry("ERROR", f"[var] Operation error for '{varname}': {exc}")
            return json_html

        if round_to is not None:
            result = self._apply_round(result, round_to)

        self.vars[varname] = result
        self._log_entry("INFO", f"[var] {varname} {op} {value!r} =>  {result!r}")
        return json_html

    def _add_command(self, args: list, json_html, _root_cwd: str):
        path, payload, use_html = self._parse_tree_mutation_args("add", args)
        if path is None:
            return json_html

        new_node = self._node_from_payload("add", payload, use_html)
        if new_node is None:
            return json_html

        path_obj = self._path_find(path)
        if path_obj is None:
            self._log_entry("ERROR", f"[add] Path not found: '{path}'")
            return json_html

        target = path_obj.node()
        if not isinstance(target, dict):
            self._log_entry("ERROR", f"[add] Path resolved to a non-dict node: '{path}'")
            return json_html

        if "inner html" not in target:
            target["inner html"] = []

        target["inner html"].append(new_node)
        self._log_entry("INFO", f"[add] Appended child at '{path}'")
        return json_html

    def _rm_command(self, args: list, json_html, _root_cwd: str):
        if not args:
            self._log_entry("WARNING", "[rm] No path provided -- skipped")
            return json_html

        path = str(args[0])
        path_obj = self._path_find(path)

        if path_obj is None:
            self._log_entry("ERROR", f"[rm] Path not found: '{path}'")
            return json_html

        location = self._locate_in_parent(path_obj)
        if location is None:
            self._log_entry("ERROR", f"[rm] Could not locate node in parent: '{path}'")
            return json_html

        parent_list, index = location
        parent_list.pop(index)
        self._log_entry("INFO", f"[rm] Removed node at '{path}'")
        return json_html

    def _cd_command(self, args: list, json_html, _root_cwd: str):
        if len(args) < 2:
            self._log_entry("WARNING", "[cd] Requires (path_var) and (cd_path) -- skipped")
            return json_html

        varname = str(args[0])
        cd_path = str(args[1])

        if varname not in self.vars:
            self._log_entry("ERROR", f"[cd] Variable '{varname}' not found")
            return json_html

        path_obj = self.vars[varname]
        if not isinstance(path_obj, JHtmlPath):
            self._log_entry("ERROR",
                            f"[cd] Variable '{varname}' is not a Path variable "
                            f"(type: {type(path_obj).__name__})")
            return json_html

        try:
            path_obj.cd(cd_path)
            self._log_entry("INFO",
                            f"[cd] {varname}.cd({cd_path!r}) => "
                            f"{path_obj.count()} branch(es), "
                            f"at '{path_obj.to_string()}'")
        except Exception as exc:
            self._log_entry("ERROR", f"[cd] Navigation error: {exc}")

        return json_html

    def _mod_command(self, args: list, json_html, _root_cwd: str):
        path, payload, use_html = self._parse_tree_mutation_args("mod", args)
        if path is None:
            return json_html

        new_node = self._node_from_payload("mod", payload, use_html)
        if new_node is None:
            return json_html

        path_obj = self._path_find(path)
        if path_obj is None:
            self._log_entry("ERROR", f"[mod] Path not found: '{path}'")
            return json_html

        location = self._locate_in_parent(path_obj)
        if location is None:
            self._log_entry("ERROR", f"[mod] Could not locate node in parent: '{path}'")
            return json_html

        parent_list, index = location
        parent_list[index] = new_node
        self._log_entry("INFO", f"[mod] Replaced node at '{path}'")
        return json_html

    def _log_command(self, args: list, json_html, _root_cwd: str):
        if not args:
            self._log_entry("WARNING", "[log] No value provided -- skipped")
            return json_html

        force_var = False
        force_str = False
        value_tokens: list[str] = []

        for token in args:
            t = str(token).lower()
            if t in ("-var", "-v"):
                force_var = True
            elif t in ("-str", "-s"):
                force_str = True
            else:
                value_tokens.append(str(token))

        if not value_tokens:
            self._log_entry("WARNING", "[log] No value provided after flags -- skipped")
            return json_html

        raw = " ".join(value_tokens)

        if force_str:
            output = raw
        elif force_var:
            if raw in self.vars:
                output = str(self.vars[raw])
            else:
                self._log_entry("WARNING", f"[log] -var: '{raw}' not found -- logging as string")
                output = raw
        else:
            output = str(self.vars[raw]) if raw in self.vars else raw

        self._log_entry("LOG", f"[log] {output}")
        return json_html

    def _shortcut_command(self, args: list, json_html, _root_cwd: str):
        if len(args) < 2:
            self._log_entry("WARNING", "[shortcut] Requires (name) and (value) -- skipped")
            return json_html

        name  = str(args[0])
        value = str(args[1])

        if name in ("import", "help", "meta", "var", "add", "rm", "cd",
                    "mod", "log", "shortcut", "fn", "py", "js", "css", "obj", "objc",
                    "if", "elif", "else", "endif"):
            self._log_entry("WARNING",
                            f"[shortcut] '{name}' shadows a built-in command -- skipped")
            return json_html

        if " " in value or ";" in value:
            higher_args = re.findall(r'\{arg(\d+)}', value)
            for n in higher_args:
                if int(n) > 1:
                    self._log_entry(
                        "WARNING",
                        f"[shortcut] Snippet body references {{arg{n}}} but only "
                        f"{{arg1}} is supported in snippet shortcuts — use 'fn' for "
                        f"multiple arguments",
                    )
                    break

        self.shortcuts[name] = value
        self._log_entry("INFO", f"[shortcut] '{name}' => {value!r}")
        return json_html

    def _expand_shortcut(self, name: str, args: list, json_html, root_cwd: str):
        value = self.shortcuts[name]

        if " " not in value and ";" not in value:
            self._log_entry("INFO", f"[shortcut] '{name}' -> '{value}' (alias)")
            return self._run_command(value, args, json_html, root_cwd)

        snippet = value
        if args:
            snippet = snippet.replace("{arg1}", str(args[0]))

        if len(args) > 1:
            self._log_entry(
                "WARNING",
                f"[shortcut] '{name}' called with {len(args)} arg(s) but snippet "
                f"shortcuts only support {{arg1}} — {len(args) - 1} extra arg(s) ignored",
            )

        self._log_entry("INFO", f"[shortcut] '{name}' -> snippet")
        return self._run_jhl_snippet(snippet, json_html, root_cwd)

    def _fn_command(self, args: list, json_html, root_cwd: str):
        if not args:
            self._log_entry("WARNING", "[fn] No arguments -- skipped")
            return json_html

        first = str(args[0])

        if first == "new":
            is_py = False
            rest  = args[1:]

            if rest and str(rest[0]).lower() == "-py":
                is_py = True
                rest  = rest[1:]

            if len(rest) < 2:
                self._log_entry("WARNING", "[fn new] Requires (name) and (body) -- skipped")
                return json_html

            fn_name = str(rest[0])
            body    = str(rest[1])

            self.functions[fn_name] = {"type": "py" if is_py else "jhl", "body": body}
            lang = "Python" if is_py else "JHL"
            self._log_entry("INFO", f"[fn] Defined {lang} function '{fn_name}'")
            return json_html

        fn_name  = first
        fn_args  = [str(a) for a in args[1:]]

        if fn_name not in self.functions:
            self._log_entry("ERROR", f"[fn] Undefined function '{fn_name}'")
            return json_html

        fn = self.functions[fn_name]

        for i, val in enumerate(fn_args, start=1):
            self.vars[f"arg{i}"] = val

        self._log_entry("INFO",
                        f"[fn] Calling '{fn_name}' with {len(fn_args)} arg(s)")

        try:
            if fn["type"] == "jhl":
                json_html = self._run_jhl_snippet(fn["body"], json_html, root_cwd)
            else:
                json_html = self._run_py_snippet(fn["body"], fn_args, json_html, root_cwd)
        finally:
            keys_to_del = [k for k in self.vars if k.startswith("arg") and k[3:].isdigit()]
            for k in keys_to_del:
                del self.vars[k]

        return json_html

    def _py_command(self, args: list, json_html, root_cwd: str):
        if not args:
            self._log_entry("WARNING", "[py] No code provided -- skipped")
            return json_html

        code = " ".join(str(a) for a in args)
        return self._run_py_snippet(code, [], json_html, root_cwd)

    def _objc_command(self, args: list, json_html, root_cwd: str):
        if len(args) < 2:
            self._log_entry("WARNING", "[objc] Requires at least (name) and { body } -- skipped")
            return json_html

        first = str(args[0])
        if ":" in first:
            name, param_names_raw = first.split(":", 1)

            param_names_raw = param_names_raw.strip("()")
            param_names = [p.strip() for p in param_names_raw.split(",") if p.strip()]
        else:
            name = first
            param_names = []

        flags: list[str] = []
        body: str | None = None
        path_token: str | None = None
        i = 1
        while i < len(args):
            token = str(args[i])

            if token.startswith("-") and not token.startswith("--"):

                flag_name = token.lstrip("-")
                if i + 1 < len(args) and not str(args[i + 1]).startswith("-"):

                    flag_name = str(args[i + 1])
                    i += 2
                else:
                    i += 1
                flags.append(flag_name)
                continue

            if path_token is None:
                path_token = token
                i += 1
                continue

            body = token
            i += 1

        if body is None:
            self._log_entry("WARNING", "[objc] No body { ... } found -- skipped")
            return json_html

        self.custom_objects[name] = {
            "body":        body,
            "flags":       flags,
            "param_names": param_names,
            "path_token":  path_token,
        }

        self._log_entry(
            "INFO",
            f"[objc] Defined custom object '{name}' "
            f"(flags={flags}, params={param_names})",
        )
        return json_html

    def _run_jhl_snippet(self, snippet: str, json_html, root_cwd: str):
        try:

            snippet = self._interpolate_vars(snippet)
            commands = self._prepare_jhl(snippet)
            json_html = self._run_commands(commands, json_html, root_cwd)
        except Exception as exc:
            self._log_entry("ERROR", f"[jhl snippet] Runtime error: {exc}")
        return json_html

    def _run_py_snippet(self, code: str, fn_args: list, json_html, root_cwd: str):
        container = [json_html]

        def jhl_callable(jhl_text: str):
            container[0] = self._run_jhl_snippet(str(jhl_text), container[0], root_cwd)

        exec_namespace = {
            "vars":      self.vars,
            "args":      fn_args,
            "jhl":       jhl_callable,
            "call":      jhl_callable,
            "jhtml":     self.jhtml,
            "JHtmlPath": JHtmlPath,
        }

        try:
            code = textwrap.dedent(code).strip()
            exec(code, exec_namespace)
        except Exception as exc:
            self._log_entry("ERROR", f"[py] Runtime error: {exc}")

        return container[0]

    def _parse_tree_mutation_args(self, cmd: str, args: list) -> tuple:
        use_html = False
        non_flags: list[str] = []

        for token in args:
            t = str(token).lower()
            if t in ("-h", "-html"):
                use_html = True
            elif t in ("-j", "-json"):
                use_html = False
            else:
                non_flags.append(str(token))

        if not non_flags:
            self._log_entry("WARNING", f"[{cmd}] No path provided -- skipped")
            return None, None, False

        path = non_flags[0]

        if len(non_flags) < 2:
            self._log_entry("WARNING", f"[{cmd}] No value provided -- skipped")
            return None, None, False

        payload = " ".join(non_flags[1:])
        return path, payload, use_html

    def _node_from_payload(self, cmd: str, payload: str, use_html: bool) -> dict | None:
        if payload is None:
            self._log_entry("WARNING", f"[{cmd}] Empty payload -- skipped")
            return None

        if use_html:
            try:
                jh = JHtml()
                jh.html(payload)
                tree = jh.json()
                if not tree:
                    raise ValueError("HTML produced an empty node tree")
                return tree[0]
            except Exception as exc:
                self._log_entry("ERROR", f"[{cmd}] HTML parse error: {exc}")
                return None
        else:
            try:
                node = json.loads(payload)
                if not isinstance(node, dict):
                    raise ValueError("JSON payload must be an object, not an array or scalar")
                return node
            except Exception as exc:
                self._log_entry("ERROR", f"[{cmd}] JSON parse error: {exc}")
                return None

    def _ensure_jhtml(self, json_html) -> None:
        if self.jhtml is None:
            self.jhtml = JHtml()
        self.jhtml.json(json_html)

    def _sync_jhtml(self, json_html) -> None:
        if self.jhtml is None:
            self.jhtml = JHtml()
        self.jhtml.json(json_html)

    def _path_find(self, path_str: str) -> JHtmlPath | None:
        if self.jhtml is None:
            self._log_entry("WARNING", "[path] No JHtml instance available")
            return None
        try:
            p = self.jhtml.path(path_str)
            if p.count() == 0:
                return None
            return p
        except Exception as exc:
            self._log_entry("WARNING", f"[path] Path error for '{path_str}': {exc}")
            return None

    def _inject_sibling_after(self, target: dict, new_node: dict) -> bool:
        root = self.jhtml.json()
        if isinstance(root, list):
            if self._inject_sibling_walk(root, target, new_node):
                return True
        elif isinstance(root, dict):
            children = root.get("inner html")
            if isinstance(children, list):
                if self._inject_sibling_walk(children, target, new_node):
                    return True

        target.setdefault("inner html", []).append(new_node)
        return False

    def _inject_sibling_walk(self, children: list, target: dict, new_node: dict) -> bool:
        for i, item in enumerate(children):
            if item is target:
                children.insert(i + 1, new_node)
                return True
            if isinstance(item, dict):
                inner = item.get("inner html")
                if isinstance(inner, list) and self._inject_sibling_walk(inner, target, new_node):
                    return True
        return False

    def _locate_in_parent(self, path_obj: JHtmlPath) -> tuple | None:
        branch = path_obj._active_branch()
        if branch is None:
            return None

        node = branch["node"]
        parent_chain = branch["parent_chain"]

        if parent_chain:
            parent = parent_chain[-1]
            children = parent.get("inner html") or parent.get("html data") or []
            if not isinstance(children, list):
                children = [children]
        else:
            children = self.jhtml.json()
            if not isinstance(children, list):
                children = [children]

        for i, child in enumerate(children):
            if child is node:
                return (children, i)

        return None

    def _parse_var_args(self, args: list) -> tuple:
        operators = {"=", "+", "-", "+=", "-=", "*=", "/=", "^="}
        type_flags = {
            "-s":              "str",
            "-str":            "str",
            "-string":         "str",
            "-b":              "bool",
            "-bool":           "bool",
            "-n":              "num",
            "-num":            "num",
            "-number":         "num",
            "-v":              "var",
            "-var":            "var",
            "-variable":       "var",
            "-p":              "path",
            "-pv":             "path",
            "-path":           "path",
            "-path_var":       "path",
            "-path_variable":  "path",
            "-ds":             "dstr",
            "-dstr":           "dstr",
            "-dystr":          "dstr",
            "-dynamic_str":    "dstr",
            "-dynamic_string": "dstr",
        }
        round_flags = {"-r", "-round"}

        varname = str(args[0])
        type_flag = None
        round_to = None
        non_flags = []

        i = 1
        while i < len(args):
            token = str(args[i])
            token_lower = token.lower()

            if token_lower in type_flags:
                type_flag = type_flags[token_lower]
                i += 1

            elif token_lower in round_flags:
                if i + 1 < len(args):
                    try:
                        round_to = float(str(args[i + 1]))
                    except (ValueError, TypeError):
                        self._log_entry("WARNING",
                                        f"[var] Invalid -r value '{args[i + 1]}' -- ignored")
                    i += 2
                else:
                    self._log_entry("WARNING", "[var] -r / -round flag is missing its value -- ignored")
                    i += 1

            else:
                non_flags.append(args[i])
                i += 1

        op = str(non_flags[0]) if len(non_flags) >= 1 else None
        raw_value = non_flags[1]       if len(non_flags) >= 2 else None

        if op is not None and op not in operators:
            raise ValueError(f"Unknown operator '{op}' for var '{varname}'")

        return varname, op, raw_value, type_flag, round_to

    def _infer_value(self, raw, type_flag: str | None):
        if raw is None:
            return None

        if type_flag == "str":
            return str(raw)

        if type_flag == "bool":
            if isinstance(raw, bool):
                return raw
            return str(raw).lower() in ("true", "1", "yes")

        if type_flag == "num":
            if isinstance(raw, (int, float)) and not isinstance(raw, bool):
                return raw
            try:
                return int(str(raw))
            except ValueError:
                pass
            try:
                return float(str(raw))
            except ValueError:
                return 0

        if type_flag == "var":
            key = str(raw)
            if key in self.vars:
                return self.vars[key]
            self._log_entry("WARNING",
                            f"[var] Variable reference '{key}' not found -- using None")
            return None

        if type_flag == "dstr":
            return self._interpolate_vars(str(raw))

        if type_flag == "path":
            if self.jhtml is None:
                self._log_entry("WARNING",
                                "[var] Cannot create Path variable -- no JHtml instance available")
                return None
            try:
                return self.jhtml.path(str(raw))
            except Exception as exc:
                self._log_entry("ERROR", f"[var] Path creation error for '{raw}': {exc}")
                return None

        if isinstance(raw, bool):
            return raw
        if isinstance(raw, (int, float)):
            return raw

        s = str(raw)
        try:
            return int(s)
        except ValueError:
            pass
        try:
            return float(s)
        except ValueError:
            pass
        if s.lower() == "true":
            return True
        if s.lower() == "false":
            return False
        if s in self.vars:
            return self.vars[s]
        return s

    def _interpolate_vars(self, text: str) -> str:
        self.relib.load(text).new_indexes().extract_between(["{"], ["}"])
        indexes = self.relib.get_indexes()

        if not indexes:
            return text

        find_list = []
        repl_list = []
        for placeholder, original in indexes.items():
            key = original[1:-1]

            if not re.match(r'^[A-Za-z_][A-Za-z0-9_.]*$', key):
                find_list.append(placeholder)
                repl_list.append(original)
                continue

            if key in self.vars:
                find_list.append(placeholder)
                repl_list.append(str(self.vars[key]))
            else:
                self._log_entry(
                    "WARNING",
                    f"[var] Dynamic string: variable '{original}' not found -- left as-is",
                )
                find_list.append(placeholder)
                repl_list.append(original)

        self.relib.replace(find_list, repl_list)
        return self.relib.get_text()

    def _apply_op(self, varname: str, op: str, value):
        current = self.vars.get(varname)

        if op == "=":
            return value

        if current is None:
            if isinstance(value, bool):
                current = False
            elif isinstance(value, (int, float)):
                current = 0
            else:
                current = ""

        if   op in ("+",  "+="): return current + value
        elif op in ("-",  "-="): return current - value
        elif op == "*=":         return current * value
        elif op == "/=":
            if value == 0:
                raise ZeroDivisionError
            result = current / value

            if (isinstance(current, int) and isinstance(value, int)
                    and not isinstance(current, bool)
                    and result == int(result)):
                return int(result)
            return result
        elif op == "^=":
            return current ** value
        else:
            raise ValueError(f"Unknown operator: '{op}'")

    @staticmethod
    def _apply_round(value, round_to: float):
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            return value
        if round_to <= 0:
            return value
        if round_to >= 1:
            return int(round(value))

        places = round(-math.log10(round_to))
        return round(value, int(places))

    @staticmethod
    def _make_script(jhl_script, path: str | None = None) -> dict:
        if isinstance(jhl_script, str):
            content = jhl_script
            script_path = path
        elif isinstance(jhl_script, dict):
            content = jhl_script.get("content", "")
            script_path = jhl_script.get("path", path)
        else:
            content = str(jhl_script)
            script_path = path

        h = hashlib.md5(content.encode("utf-8")).hexdigest()
        return {"content": content, "path": script_path, "hash": h}

    @staticmethod
    def _strip_line_comments(text: str) -> str:
        result: list[str] = []
        i = 0
        length = len(text)
        while i < length:
            ch = text[i]

            if i + 2 < length:
                tri = text[i:i + 3]
                if tri in ('"""', "'''", '```'):

                    result.append(tri)
                    j = i + 3
                    while j < length:
                        if text[j] == '\\' and j + 1 < length:
                            result.append(text[j:j + 2])
                            j += 2
                            continue
                        if text[j:j + 3] == tri:
                            result.append(tri)
                            j += 3
                            break
                        result.append(text[j])
                        j += 1
                    i = j
                    continue

            if ch in ('"', "'", '`'):
                result.append(ch)
                j = i + 1
                while j < length:
                    if text[j] == '\\' and j + 1 < length:
                        result.append(text[j:j + 2])
                        j += 2
                        continue
                    if text[j] == ch:
                        result.append(ch)
                        j += 1
                        break
                    result.append(text[j])
                    j += 1
                i = j
                continue

            if ch == '/' and i + 1 < length and text[i + 1] == '/':

                j = i + 2
                while j < length and text[j] != '\n':
                    j += 1
                i = j
                continue

            result.append(ch)
            i += 1

        return "".join(result)

    def _prepare_jhl(self, raw_jhl: str) -> list:

        cleaned_jhl = self._strip_line_comments(raw_jhl)

        self.relib.load(cleaned_jhl).new_indexes().extract_strings()
        string_indexes = dict(self.relib.get_indexes())

        self.relib.new_indexes().extract_nested("{", "}")
        block_indexes = dict(self.relib.get_indexes())

        indexes = {}
        indexes.update(string_indexes)
        indexes.update(block_indexes)

        safe_text = self.relib.get_text()

        commands = []
        for raw_stmt in safe_text.split(";"):
            normalized = " ".join(raw_stmt.split())
            if not normalized:
                continue

            tokens = normalized.split(" ")
            restored = []
            skip_next = False
            for token in tokens:
                if skip_next:
                    skip_next = False
                    continue
                if token == "--c":
                    skip_next = True
                    continue
                if token in block_indexes:

                    body = self._strip_delimiters(block_indexes[token])
                    for s_key, s_val in string_indexes.items():
                        body = body.replace(s_key, s_val)
                    restored.append(body)
                elif token in indexes:
                    restored.append(self._strip_delimiters(indexes[token]))
                else:
                    restored.append(self._cast_token(token))

            if not restored:
                continue

            cmd_name = str(restored[0])
            args = restored[1:]
            commands.append({cmd_name: args})

        return commands

    @staticmethod
    def _strip_delimiters(raw: str) -> str:
        for triple in ('"""', "'''", '```'):
            if raw.startswith(triple) and raw.endswith(triple):
                return raw[3:-3]

        if len(raw) >= 2:
            return raw[1:-1]
        return raw

    @staticmethod
    def _cast_token(token: str) -> int | float | str:
        try:
            return int(token)
        except ValueError:
            pass
        try:
            return float(token)
        except ValueError:
            pass
        return token

    def _format_help_entry(self, cmd_name: str) -> str:
        if cmd_name not in self._COMMANDS_HELP:
            return f"[Help] Unknown command: '{cmd_name}'"

        info = self._COMMANDS_HELP[cmd_name]
        p = self._HELP_PAD
        lines = [
            f"[Help] >> {info['signature']}",
            p,
            f"{p}--- Description",
            f"{p}-> {info['description']}",
        ]
        if info["flags"]:
            lines += [p, f"{p}--- Flags"]
            for names, required, desc in info["flags"]:
                lines.append(f"{p}-> {json.dumps(names)} ({required}) -> {desc}")

        return "\n".join(lines)

    def _format_all_help(self) -> str:
        separator = "\n" + "-" * 52 + "\n"
        return separator.join(self._format_help_entry(cmd) for cmd in self._COMMANDS_HELP)

    def _log_entry(self, level: str, message: str) -> str:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"[{ts}] [{level:<7}] {message}"
        self._entries.append(entry)
        if level == "WARNING":
            self._warnings.append(entry)
        elif level == "ERROR":
            self._errors.append(entry)
        return entry

    def _get_run_info(self, log_start:  int = 0,
                      warn_start: int = 0,
                      err_start:  int = 0) -> dict:
        return {
            "log":      list(self._entries [log_start: ]),
            "warnings": list(self._warnings[warn_start:]),
            "errors":   list(self._errors  [err_start: ]),
        }

class JHLCSSCommandHandler:
    HELP: dict = {
        "css": {
            "signature":   "css (path) [-multi] (css code) [-e (event)]",
            "description": (
                "Injects CSS onto the element(s) at the given JHtml path. "
                "Use -multi to target all matches. "
                "Use -e (event) to apply CSS only when a specific event fires."
            ),
            "flags": [
                (["-multi", "-m"], "Optional", "Apply to all matching elements instead of only the first"),
                (["-e", "-event"], "Optional", "Attach CSS to an event: hover, active, focus (pure CSS) "
                                               "or any JS event (click, scroll, load, key_down:KEY, "
                                               "key_up:KEY, every:TIME, after:TIME, moved)"),
            ],
        },
    }

    _CSS_PSEUDO_EVENTS = {"hover", "active", "focus"}
    _JS_SIMPLE_EVENTS = {"click", "scroll", "load", "moved"}
    _JS_PARAMETERISED_EVENTS = {"key_down", "key_up", "every", "after"}
    _TIME_SUFFIXES = {"ms": 1, "s": 1000, "min": 60000}

    _uid_counter: int = 0

    def __init__(self, handler):
        self._h = handler

    def run(self, args: list, json_html, _root_cwd: str):
        if not args:
            self._h._log_entry("WARNING", "[css] No arguments -- skipped")
            return json_html

        path_str, multi, css_code, event_raw = self._parse_args(args)

        if path_str is None:
            return json_html
        if css_code is None:
            self._h._log_entry("WARNING", "[css] No CSS code provided -- skipped")
            return json_html

        css_stripped = css_code.strip()
        if (css_stripped
                and " " not in css_stripped
                and ":" not in css_stripped
                and ";" not in css_stripped):
            if css_stripped in self._h.vars:
                resolved = str(self._h.vars[css_stripped])
                self._h._log_entry(
                    "INFO",
                    f"[css] Resolved variable '{css_stripped}' -> {resolved!r}",
                )
                css_code = resolved
            else:
                self._h._log_entry(
                    "ERROR",
                    f"[css] '{css_stripped}' does not look like valid CSS "
                    f"(no ':' or ';' found). If this is a variable name, it "
                    f"was not found. Did you mean: css {path_str} \"{css_stripped}: ...;\" "
                    f"or define a variable first with var {css_stripped} = \"...\"; "
                    f"then use css {path_str} {css_stripped}; (bare, no quotes)?",
                )
                return json_html

        path_obj = self._h._path_find(path_str)
        if path_obj is None:
            self._h._log_entry("ERROR", f"[css] Path not found: '{path_str}'")
            return json_html

        targets = self._resolve_targets(path_obj, multi, path_str)
        if not targets:
            return json_html

        if event_raw is None:
            for target in targets:
                self._apply_inline_css(target, css_code)
            label = f"{len(targets)} element(s)" if multi else "1 element"
            self._h._log_entry("INFO", f"[css] Inline CSS applied at '{path_str}' ({label})")
        else:
            event_name, event_param = self._parse_event(event_raw)
            if event_name is None:
                return json_html

            if event_name in self._CSS_PSEUDO_EVENTS:
                for target in targets:
                    self._apply_pseudo_css(target, css_code, event_name)
                self._h._log_entry(
                    "INFO",
                    f"[css] Pseudo :{event_name} CSS applied at '{path_str}'",
                )
            else:
                for target in targets:
                    self._apply_js_event_css(target, css_code, event_name, event_param, path_str)
                self._h._log_entry(
                    "INFO",
                    f"[css] JS-event '{event_raw}' CSS applied at '{path_str}'",
                )

        return json_html

    def _parse_args(self, args: list) -> tuple:
        multi = False
        event_raw = None
        remaining: list[str] = []

        i = 0
        while i < len(args):
            token = str(args[i])
            t = token.lower()

            if t in ("-multi", "-m"):
                multi = True
                i += 1
            elif t in ("-e", "-event"):
                if i + 1 < len(args):
                    event_raw = str(args[i + 1])
                    i += 2
                else:
                    self._h._log_entry("WARNING", "[css] -e flag missing event value -- ignored")
                    i += 1
            else:
                remaining.append(token)
                i += 1

        if not remaining:
            self._h._log_entry("WARNING", "[css] No path provided -- skipped")
            return None, False, None, None

        path_str = remaining[0]
        css_code = " ".join(remaining[1:]) if len(remaining) > 1 else None

        return path_str, multi, css_code, event_raw

    def _resolve_targets(self, path_obj, multi: bool, path_str: str) -> list[dict]:
        if multi:
            all_paths = path_obj.get_all()
            targets = []
            for p in all_paths:
                node = p.node()
                if isinstance(node, dict):
                    targets.append(node)
            if not targets:
                self._h._log_entry("ERROR", f"[css] No dict nodes found at '{path_str}'")
            return targets
        else:
            node = path_obj.node()
            if not isinstance(node, dict):
                self._h._log_entry("ERROR", f"[css] Path resolved to a non-dict node: '{path_str}'")
                return []
            return [node]

    def _parse_event(self, raw: str) -> tuple:
        relib = self._h.relib

        if relib.load(raw).get_contains(":"):
            parts = relib.split([":"]).get_split()
            name = parts[0]
            param = ":".join(parts[1:])
        else:
            name, param = raw, None

        name_lower = name.lower()

        all_known = self._CSS_PSEUDO_EVENTS | self._JS_SIMPLE_EVENTS | set(self._JS_PARAMETERISED_EVENTS)
        if name_lower not in all_known:
            self._h._log_entry("WARNING", f"[css] Unknown event type '{raw}' -- skipped")
            return None, None

        if name_lower in self._CSS_PSEUDO_EVENTS | self._JS_SIMPLE_EVENTS:
            return name_lower, None

        if param is None:
            self._h._log_entry(
                "WARNING",
                f"[css] Event '{name_lower}' requires a parameter (e.g. {name_lower}:value) -- skipped",
            )
            return None, None

        if name_lower in ("every", "after"):
            ms = self._parse_time(param)
            if ms is None:
                return None, None
            return name_lower, ms

        return name_lower, param

    def _parse_time(self, raw: str) -> int | None:
        relib = self._h.relib
        matches = relib.load(raw.strip()).get_matches(
            r"^(\d+(?:\.\d+)?)(ms|s|min)$", regex=True
        )
        if not matches:
            self._h._log_entry(
                "ERROR",
                f"[css] Invalid time value '{raw}' -- expected e.g. 100ms, 2s, 1min",
            )
            return None

        relib.load(raw.strip())
        num_part = relib.get_matches(r"^\d+(?:\.\d+)?", regex=True)[0]
        suffix = relib.get_matches(r"(ms|s|min)$", regex=True)[0]
        value = float(num_part)
        return int(value * self._TIME_SUFFIXES[suffix.lower()])

    def _apply_inline_css(self, target: dict, css_code: str) -> None:
        existing = target.get("style", "")
        relib = self._h.relib
        if existing and not relib.load(existing).get_matches(r";\s*$", regex=True):
            existing += "; "
        target["style"] = existing + css_code

    def _apply_pseudo_css(self, target: dict, css_code: str, pseudo: str) -> None:
        uid = self._ensure_uid(target)
        style_rule = f"[data-jhl-uid='{uid}']:{pseudo} {{ {css_code} }}"
        style_node = {
            "el type": "style",
            "inner html": [style_rule],
        }
        self._h._inject_sibling_after(target, style_node)

    def _apply_js_event_css(self, target: dict, css_code: str,
                            event: str, param, path_str: str) -> None:
        uid = self._ensure_uid(target)
        selector = f"[data-jhl-uid='{uid}']"
        escaped_css = self._escape_css_for_js(css_code)

        apply_js = (
            f"var _el = document.querySelector(\"{selector}\");\n"
            f"if (_el) {{ _el.style.cssText += '{escaped_css}'; }}"
        )

        script_block = self._build_event_wrapper(selector, event, param, apply_js)
        script_node = {
            "el type": "script",
            "inner html": [script_block],
        }
        self._h._inject_sibling_after(target, script_node)

    def _build_event_wrapper(self, selector: str, event: str, param, code: str) -> str:
        if event == "click":
            return self._wrap_dom(selector, "click", code)
        if event == "scroll":
            return self._wrap_dom(selector, "scroll", code)
        if event == "load":
            return (
                f"document.addEventListener('DOMContentLoaded', function() {{\n"
                f"  {code}\n"
                f"}});\n"
            )
        if event in ("key_down", "key_up"):
            dom_event = "keydown" if event == "key_down" else "keyup"
            return self._wrap_key(selector, dom_event, param, code)
        if event == "every":
            return f"setInterval(function() {{ {code} }}, {param});\n"
        if event == "after":
            return f"setTimeout(function() {{ {code} }}, {param});\n"
        if event == "moved":
            return (
                f"(function() {{\n"
                f"  var _t = document.querySelector(\"{selector}\");\n"
                f"  if (_t) {{\n"
                f"    new MutationObserver(function(muts) {{\n"
                f"      muts.forEach(function(m) {{\n"
                f"        if (m.type==='childList') m.removedNodes.forEach(function(n) {{\n"
                f"          if (n===_t || (n.contains && n.contains(_t))) {{ {code} }}\n"
                f"        }});\n"
                f"      }});\n"
                f"    }}).observe(document.body, {{childList:true, subtree:true}});\n"
                f"  }}\n"
                f"}})();\n"
            )
        return ""

    def _wrap_dom(self, selector: str, dom_event: str, code: str) -> str:
        return (
            f"document.querySelector(\"{selector}\")"
            f".addEventListener('{dom_event}', function(event) {{\n"
            f"  {code}\n"
            f"}});\n"
        )

    def _wrap_key(self, selector: str, dom_event: str, combo: str, code: str) -> str:
        relib = self._h.relib
        parts = relib.load(combo).split(["+"]).get_split()
        parts = [p.strip() for p in parts]
        key = parts[-1]
        modifiers = [m.lower() for m in parts[:-1]]

        conditions = [f"event.key.toLowerCase()==='{key.lower()}'"]
        if "ctrl" in modifiers:
            conditions.append("event.ctrlKey")
        if "alt" in modifiers:
            conditions.append("event.altKey")
        if "shift" in modifiers:
            conditions.append("event.shiftKey")
        if "meta" in modifiers:
            conditions.append("event.metaKey")

        check = " && ".join(conditions)
        return (
            f"document.querySelector(\"{selector}\")"
            f".addEventListener('{dom_event}', function(event) {{\n"
            f"  if ({check}) {{ {code} }}\n"
            f"}});\n"
        )

    def _escape_css_for_js(self, css_code: str) -> str:
        relib = self._h.relib
        return relib.load(css_code).replace(
            ["\\",   "'"],
            ["\\\\", "\\'"],
        ).get_text()

    def _ensure_uid(self, target: dict) -> str:
        uid = target.get("data-jhl-uid")
        if uid is None:
            JHLCSSCommandHandler._uid_counter += 1
            uid = f"jhl-css-{JHLCSSCommandHandler._uid_counter}"
            target["data-jhl-uid"] = uid
        return uid
class JHLObjectsCommandHandler:
    HELP: dict = {
        "obj": {
            "signature":   "obj (path) (type) [-multi] [-e event path] [-d event path] [-flag value]",
            "description": (
                "Assigns a behavioural type to element(s) at the given JHtml path. "
                "Built-in types: bucket:ids, draggable:id, modal:js_var, dependant:js_var. "
                "Custom types defined via objc are also accepted (with -flag or :param syntax). "
                "Use -e/-d to attach enable/disable events from other elements."
            ),
            "flags": [
                (["-multi", "-m"], "Optional",
                 "Apply to all matching elements instead of only the first"),
                (["-e", "-enable-event"], "Optional",
                 "Enable/show when (event) fires on element at (path)"),
                (["-d", "-disable-event"], "Optional",
                 "Disable/hide when (event) fires on element at (path)"),
            ],
        },
    }

    _VALID_TYPES = {"bucket", "draggable", "modal", "dependant"}

    _TOGGLE_SIMPLE_EVENTS = {"click", "hover", "scroll", "load"}
    _TOGGLE_PARAM_EVENTS = {"key_down", "key_up"}

    _uid_counter: int = 0
    _reactive_bootstrapped: bool = False

    _REACTIVE_BOOTSTRAP_JS = (
        "(function() {\n"
        "  if (window.__jhlReactive) return;\n"
        "  var _watchers = {};\n"
        "  window.__jhlReactive = {\n"
        "    watch: function(key, fn) {\n"
        "      if (!_watchers[key]) _watchers[key] = [];\n"
        "      _watchers[key].push(fn);\n"
        "    },\n"
        "    notify: function(key) {\n"
        "      var fns = _watchers[key];\n"
        "      if (fns) for (var i = 0; i < fns.length; i++) fns[i]();\n"
        "    }\n"
        "  };\n"
        "  /* Proxy wrapper — intercept property sets on window */\n"
        "  var _origSet = Object.getOwnPropertyDescriptor(Window.prototype, 'window') || {};\n"
        "  var _handler = {\n"
        "    set: function(target, prop, value) {\n"
        "      target[prop] = value;\n"
        "      if (_watchers[prop]) window.__jhlReactive.notify(prop);\n"
        "      return true;\n"
        "    }\n"
        "  };\n"
        "  /* We can't Proxy window directly in all browsers, so we patch\n"
        "     watched keys with Object.defineProperty instead. */\n"
        "  window.__jhlReactive._define = function(key) {\n"
        "    if (window.__jhlReactive['_def_' + key]) return;\n"
        "    window.__jhlReactive['_def_' + key] = true;\n"
        "    var _val = window[key];\n"
        "    try {\n"
        "      Object.defineProperty(window, key, {\n"
        "        get: function() { return _val; },\n"
        "        set: function(v) { _val = v; window.__jhlReactive.notify(key); },\n"
        "        configurable: true\n"
        "      });\n"
        "    } catch(e) {\n"
        "      /* Fallback: poll only this one key at a slow rate */\n"
        "      setInterval(function() {\n"
        "        if (window[key] !== _val) { _val = window[key]; window.__jhlReactive.notify(key); }\n"
        "      }, 300);\n"
        "    }\n"
        "  };\n"
        "})();\n"
    )

    def __init__(self, handler):
        self._h = handler

    def run(self, args: list, json_html, _root_cwd: str):
        if len(args) < 2:
            self._h._log_entry(
                "WARNING",
                "[obj] Requires (path) (type) -- skipped",
            )
            return json_html

        path_str, type_raw, multi, enable_event, disable_event, extra_flags = self._parse_args(args)
        if path_str is None:
            return json_html

        type_name, type_param = self._parse_type(type_raw)
        if type_name is None:
            return json_html

        path_obj = self._h._path_find(path_str)
        if path_obj is None:
            self._h._log_entry("ERROR", f"[obj] Path not found: '{path_str}'")
            return json_html

        targets = self._resolve_targets(path_obj, multi, path_str)
        if not targets:
            return json_html

        for target in targets:
            self._apply_type(target, type_name, type_param, path_str,
                             enable_event, disable_event, extra_flags)

        label = f"{len(targets)} element(s)" if multi else "1 element"
        self._h._log_entry(
            "INFO",
            f"[obj] Applied '{type_raw}' to {label} at '{path_str}'",
        )
        return json_html

    def _parse_args(self, args: list) -> tuple:
        multi = False
        enable_event = None
        disable_event = None
        extra_flags: dict = {}
        remaining: list[str] = []

        i = 0
        while i < len(args):
            t = str(args[i])
            t_low = t.lower()

            if t_low in ("-multi", "-m"):
                multi = True
                i += 1
                continue

            if t_low in ("-e", "-enable-event"):
                parsed = self._consume_event_flag(args, i, "enable")
                if parsed is not None:
                    enable_event = parsed[0]
                    i = parsed[1]
                else:
                    i += 1
                continue

            if t_low in ("-d", "-disable-event"):
                parsed = self._consume_event_flag(args, i, "disable")
                if parsed is not None:
                    disable_event = parsed[0]
                    i = parsed[1]
                else:
                    i += 1
                continue

            if t.startswith("-") and not t.startswith("--") and t_low not in ("-multi", "-m"):
                flag_name = t.lstrip("-")
                if i + 1 < len(args) and not str(args[i + 1]).startswith("-"):
                    extra_flags[flag_name] = str(args[i + 1])
                    i += 2
                else:
                    extra_flags[flag_name] = "true"
                    i += 1
                continue

            remaining.append(str(args[i]))
            i += 1

        if len(remaining) < 2:
            self._h._log_entry("WARNING", "[obj] Missing path or type -- skipped")
            return None, None, False, None, None, {}

        return remaining[0], remaining[1], multi, enable_event, disable_event, extra_flags

    def _consume_event_flag(self, args: list, start_idx: int, kind: str):
        flag = str(args[start_idx])
        if start_idx + 2 >= len(args):
            self._h._log_entry(
                "WARNING",
                f"[obj] {flag} requires (event) (path) -- skipped",
            )
            return None
        event_str = str(args[start_idx + 1])
        path_str = str(args[start_idx + 2])
        return (event_str, path_str), start_idx + 3

    def _parse_type(self, raw: str) -> tuple:
        if ":" in raw:
            name, param = raw.split(":", 1)
        else:
            name, param = raw, None

        name_lower = name.lower()

        if hasattr(self._h, 'custom_objects') and name in self._h.custom_objects:
            return name, param

        if name_lower not in self._VALID_TYPES:

            if hasattr(self._h, 'custom_objects') and name_lower in self._h.custom_objects:
                return name_lower, param
            self._h._log_entry(
                "WARNING",
                f"[obj] Unknown type '{raw}' -- expected one of: "
                f"{', '.join(sorted(self._VALID_TYPES))} (or a custom objc type)",
            )
            return None, None

        if param is None or param.strip() == "":
            self._h._log_entry(
                "WARNING",
                f"[obj] Type '{name_lower}' requires a parameter (e.g. {name_lower}:value) -- skipped",
            )
            return None, None

        return name_lower, param

    def _resolve_targets(self, path_obj, multi: bool, path_str: str) -> list[dict]:
        if multi:
            all_paths = path_obj.get_all()
            targets = []
            for p in all_paths:
                node = p.node()
                if isinstance(node, dict):
                    targets.append(node)
            if not targets:
                self._h._log_entry("ERROR", f"[obj] No dict nodes found at '{path_str}'")
            return targets
        else:
            node = path_obj.node()
            if not isinstance(node, dict):
                self._h._log_entry("ERROR", f"[obj] Path resolved to a non-dict node: '{path_str}'")
                return []
            return [node]

    def _apply_type(self, target: dict, type_name: str, param: str,
                    path_str: str, enable_event=None, disable_event=None,
                    extra_flags: dict = None) -> None:
        dispatch = {
            "bucket":    self._apply_bucket,
            "draggable": self._apply_draggable,
            "modal":     self._apply_modal,
            "dependant": self._apply_dependant,
        }
        if type_name in dispatch:
            dispatch[type_name](target, param, path_str, enable_event, disable_event)
        elif hasattr(self._h, 'custom_objects') and type_name in self._h.custom_objects:
            self._apply_custom(target, type_name, param, path_str,
                               enable_event, disable_event, extra_flags or {})
        else:
            self._h._log_entry(
                "WARNING",
                f"[obj] Cannot apply unknown type '{type_name}'",
            )

    def _apply_bucket(self, target: dict, param: str, _path_str: str,
                      enable_event=None, disable_event=None) -> None:
        ids = [i.strip() for i in param.split(",") if i.strip()]
        uid = self._ensure_uid(target)
        selector = f"[data-jhl-uid='{uid}']"

        target["data-jhl-bucket"] = ",".join(ids)

        ids_json = str(ids).replace("'", '"')

        script = (
            f"(function() {{\n"
            f"  var bucket = document.querySelector(\"{selector}\");\n"
            f"  if (!bucket) return;\n"
            f"  var _jhlEnabled = true;\n"
            f"  var acceptIds = {ids_json};\n"
            f"  bucket.addEventListener('dragover', function(e) {{\n"
            f"    if (!_jhlEnabled) return;\n"
            f"    var dragId = e.dataTransfer.types.find(function(t) {{ return t.startsWith('jhl-drag-id/'); }});\n"
            f"    if (dragId) {{\n"
            f"      var id = dragId.replace('jhl-drag-id/', '');\n"
            f"      if (acceptIds.indexOf(id) !== -1) e.preventDefault();\n"
            f"    }}\n"
            f"  }});\n"
            f"  bucket.addEventListener('drop', function(e) {{\n"
            f"    if (!_jhlEnabled) return;\n"
            f"    e.preventDefault();\n"
            f"    var dragUid = e.dataTransfer.getData('text/jhl-uid');\n"
            f"    if (dragUid) {{\n"
            f"      var dragged = document.querySelector('[data-jhl-uid=\"' + dragUid + '\"]');\n"
            f"      if (dragged) bucket.appendChild(dragged);\n"
            f"    }}\n"
            f"  }});\n"
            f"{self._build_toggle_listeners(enable_event, disable_event, '_jhlEnabled')}"
            f"}})();\n"
        )

        self._inject_script(target, script)

    def _apply_draggable(self, target: dict, param: str, _path_str: str,
                         enable_event=None, disable_event=None) -> None:
        drag_id = param.strip()
        uid = self._ensure_uid(target)
        selector = f"[data-jhl-uid='{uid}']"

        target["draggable"] = "true"
        target["data-jhl-draggable"] = drag_id

        script = (
            f"(function() {{\n"
            f"  var el = document.querySelector(\"{selector}\");\n"
            f"  if (!el) return;\n"
            f"  var _jhlEnabled = true;\n"
            f"  el.addEventListener('dragstart', function(e) {{\n"
            f"    if (!_jhlEnabled) {{ e.preventDefault(); return; }}\n"
            f"    e.dataTransfer.setData('text/jhl-uid', '{uid}');\n"
            f"    e.dataTransfer.setData('jhl-drag-id/{drag_id}', '');\n"
            f"  }});\n"
            f"{self._build_toggle_listeners(enable_event, disable_event, '_jhlEnabled')}"
            f"}})();\n"
        )

        self._inject_script(target, script)

    def _apply_modal(self, target: dict, param: str, _path_str: str,
                     enable_event=None, disable_event=None) -> None:
        js_var = param.strip()
        uid = self._ensure_uid(target)
        selector = f"[data-jhl-uid='{uid}']"

        target["data-jhl-modal"] = js_var

        style_rule = (
            f"[data-jhl-uid='{uid}'].jhl-modal-hidden {{ display: none !important; }}\n"
            f"[data-jhl-uid='{uid}'].jhl-modal-visible {{\n"
            f"  position: fixed !important; top: 0 !important; left: 0 !important; width: 100% !important; height: 100% !important;\n"
            f"  display: flex !important; align-items: center !important; justify-content: center !important;\n"
            f"  background: rgba(0,0,0,0.5); z-index: 9999;\n"
            f"}}\n"
        )
        style_node = {
            "el type": "style",
            "inner html": [style_rule],
        }
        target.setdefault("inner html", []).append(style_node)

        has_toggles = enable_event is not None or disable_event is not None

        if has_toggles:

            script = (
                f"(function() {{\n"
                f"  var el = document.querySelector(\"{selector}\");\n"
                f"  if (!el) return;\n"
                f"  function _showModal() {{ {js_var} = true; el.classList.add('jhl-modal-visible'); el.classList.remove('jhl-modal-hidden'); }}\n"
                f"  function _hideModal() {{ {js_var} = false; el.classList.remove('jhl-modal-visible'); el.classList.add('jhl-modal-hidden'); }}\n"
                f"  _hideModal();\n"
                f"{self._build_toggle_listeners(enable_event, disable_event, None, '_showModal()', '_hideModal()')}"
                f"}})();\n"
            )
        else:

            self._inject_reactive_bootstrap(target)
            watch_key = self._extract_watch_key(js_var)
            script = (
                f"(function() {{\n"
                f"  var el = document.querySelector(\"{selector}\");\n"
                f"  if (!el) return;\n"
                f"  function _checkModal() {{\n"
                f"    try {{\n"
                f"      var show = !!eval('{js_var}');\n"
                f"      el.classList.toggle('jhl-modal-visible', show);\n"
                f"      el.classList.toggle('jhl-modal-hidden', !show);\n"
                f"    }} catch(e) {{\n"
                f"      el.classList.add('jhl-modal-hidden');\n"
                f"      el.classList.remove('jhl-modal-visible');\n"
                f"    }}\n"
                f"  }}\n"
                f"  _checkModal();\n"
                f"  if (window.__jhlReactive) {{\n"
                f"    window.__jhlReactive._define('{watch_key}');\n"
                f"    window.__jhlReactive.watch('{watch_key}', _checkModal);\n"
                f"  }}\n"
                f"}})();\n"
            )

        self._inject_script(target, script)

    def _apply_dependant(self, target: dict, param: str, _path_str: str,
                         enable_event=None, disable_event=None) -> None:
        js_var = param.strip()
        uid = self._ensure_uid(target)
        selector = f"[data-jhl-uid='{uid}']"

        target["data-jhl-dependant"] = js_var

        has_toggles = enable_event is not None or disable_event is not None

        if has_toggles:

            script = (
                f"(function() {{\n"
                f"  var el = document.querySelector(\"{selector}\");\n"
                f"  if (!el) return;\n"
                f"  function _showDep() {{ {js_var} = true; el.style.display = ''; }}\n"
                f"  function _hideDep() {{ {js_var} = false; el.style.display = 'none'; }}\n"
                f"  _showDep();\n"
                f"{self._build_toggle_listeners(enable_event, disable_event, None, '_showDep()', '_hideDep()')}"
                f"}})();\n"
            )
        else:

            self._inject_reactive_bootstrap(target)
            watch_key = self._extract_watch_key(js_var)
            script = (
                f"(function() {{\n"
                f"  var el = document.querySelector(\"{selector}\");\n"
                f"  if (!el) return;\n"
                f"  function _checkDep() {{\n"
                f"    try {{\n"
                f"      el.style.display = !!eval('{js_var}') ? '' : 'none';\n"
                f"    }} catch(e) {{\n"
                f"      el.style.display = 'none';\n"
                f"    }}\n"
                f"  }}\n"
                f"  _checkDep();\n"
                f"  if (window.__jhlReactive) {{\n"
                f"    window.__jhlReactive._define('{watch_key}');\n"
                f"    window.__jhlReactive.watch('{watch_key}', _checkDep);\n"
                f"  }}\n"
                f"}})();\n"
            )

        self._inject_script(target, script)

    def _apply_custom(self, target: dict, type_name: str, param: str,
                      path_str: str, enable_event=None, disable_event=None,
                      extra_flags: dict = None) -> None:
        defn = self._h.custom_objects[type_name]
        body = defn["body"]
        declared_flags = defn["flags"]
        param_names = defn["param_names"]

        saved_vars: dict = {}
        vars_to_set: dict = {"path": path_str}

        if extra_flags is None:
            extra_flags = {}
        for flag in declared_flags:
            if flag in extra_flags:
                vars_to_set[flag] = extra_flags[flag]

        if param_names and param is not None:
            param_parts = param.split(",")
            for i, pname in enumerate(param_names):
                if i < len(param_parts):
                    vars_to_set[pname] = param_parts[i].strip()
                else:
                    vars_to_set[pname] = ""
        elif param is not None and not param_names and declared_flags:

            if declared_flags:
                vars_to_set[declared_flags[0]] = param

        for key, value in vars_to_set.items():
            if key in self._h.vars:
                saved_vars[key] = self._h.vars[key]
            self._h.vars[key] = value

        try:
            self._h._log_entry(
                "INFO",
                f"[obj] Running custom object '{type_name}' body at '{path_str}'",
            )

            root_cwd = os.getcwd()
            self._h._run_jhl_snippet(body, self._h.jhtml.json(), root_cwd)
        except Exception as exc:
            self._h._log_entry(
                "ERROR",
                f"[obj] Custom object '{type_name}' error: {exc}",
            )
        finally:

            for key in vars_to_set:
                if key in saved_vars:
                    self._h.vars[key] = saved_vars[key]
                elif key in self._h.vars:
                    del self._h.vars[key]

    def _ensure_uid(self, target: dict) -> str:
        uid = target.get("data-jhl-uid")
        if uid is None:
            JHLObjectsCommandHandler._uid_counter += 1
            uid = f"jhl-obj-{JHLObjectsCommandHandler._uid_counter}"
            target["data-jhl-uid"] = uid
        return uid

    @staticmethod
    def _inject_script(target: dict, script_block: str) -> None:
        script_node = {
            "el type": "script",
            "inner html": [script_block],
        }
        target.setdefault("inner html", []).append(script_node)

    def _inject_reactive_bootstrap(self, target: dict) -> None:
        if JHLObjectsCommandHandler._reactive_bootstrapped:
            return
        JHLObjectsCommandHandler._reactive_bootstrapped = True

        bootstrap_node = {
            "el type": "script",
            "inner html": [self._REACTIVE_BOOTSTRAP_JS],
        }

        body = None
        if self._h.jhtml is not None:
            try:
                p = self._h.jhtml.path("body")
                if p.count() > 0:
                    body = p.node()
            except Exception:
                pass

        if body is not None and isinstance(body, dict):
            body.setdefault("inner html", []).insert(0, bootstrap_node)
        else:

            target.setdefault("inner html", []).insert(0, bootstrap_node)

        self._h._log_entry(
            "INFO",
            "[obj] Injected reactive runtime (Proxy-based change detection)",
        )

    @staticmethod
    def _extract_watch_key(js_var: str) -> str:
        expr = js_var.strip()

        if expr.startswith("window."):
            expr = expr[7:]

        dot = expr.find(".")
        if dot != -1:
            return expr[:dot]
        return expr

    @classmethod
    def clear_reactive_state(cls) -> None:
        cls._reactive_bootstrapped = False

    def _build_toggle_listeners(self, enable_event, disable_event,
                                bool_var_name=None,
                                enable_code=None, disable_code=None) -> str:
        if enable_event is None and disable_event is None:
            return ""

        parts = []

        if enable_event is not None:
            e_str = enable_code if enable_code else f"{bool_var_name} = true;"
            parts.append(self._build_one_toggle_listener(enable_event, e_str))

        if disable_event is not None:
            d_str = disable_code if disable_code else f"{bool_var_name} = false;"
            parts.append(self._build_one_toggle_listener(disable_event, d_str))

        return "".join(parts)

    def _build_one_toggle_listener(self, event_def: tuple, code: str) -> str:
        event_raw, target_path = event_def
        dom_event, key_check = self._resolve_event_dom(event_raw)

        if dom_event is None:
            return ""

        trigger_selector = self._resolve_toggle_selector(target_path)
        if trigger_selector is None:
            return ""

        if key_check:
            return (
                f"  document.querySelector('{trigger_selector}')"
                f".addEventListener('{dom_event}', function(event) {{\n"
                f"    if ({key_check}) {{ event.preventDefault(); {code} }}\n"
                f"  }});\n"
            )
        else:
            return (
                f"  document.querySelector('{trigger_selector}')"
                f".addEventListener('{dom_event}', function(event) {{ {code} }});\n"
            )

    def _resolve_toggle_selector(self, path_str: str) -> str | None:
        if path_str.startswith("#") or path_str.startswith("."):
            return path_str

        path_obj = self._h._path_find(path_str)
        if path_obj is None:
            self._h._log_entry(
                "WARNING",
                f"[obj] Toggle event target not found: '{path_str}'",
            )
            return None

        node = path_obj.node()
        if not isinstance(node, dict):
            return path_str

        if "id" in node:
            return f"#{node['id']}"

        classes = node.get("class", "")
        if isinstance(classes, list):
            classes = " ".join(classes)
        if classes:
            el_type = node.get("el type", "div")
            return f"{el_type}.{'.' .join(classes.split())}"

        return path_str

    def _resolve_event_dom(self, event_raw: str) -> tuple:
        event_lower = event_raw.lower()

        simple_map = {
            "click": "click",
            "hover": "mouseenter",
            "scroll": "scroll",
            "load": "DOMContentLoaded",
        }
        if event_lower in simple_map:
            return simple_map[event_lower], None

        if ":" in event_raw:
            parts = event_raw.split(":", 1)
            name = parts[0].lower()
            combo = parts[1]

            if name in ("key_down", "key_up"):
                dom_event = "keydown" if name == "key_down" else "keyup"
                key_check = self._build_key_check(combo)
                return dom_event, key_check

        self._h._log_entry(
            "WARNING",
            f"[obj] Unknown toggle event type '{event_raw}' -- skipped",
        )
        return None, None

    @staticmethod
    def _build_key_check(combo: str) -> str:
        parts = [p.strip() for p in combo.split("+")]
        key = parts[-1]
        modifiers = [m.lower() for m in parts[:-1]]

        conditions = [f"event.key.toLowerCase()==='{key.lower()}'"]
        if "ctrl" in modifiers:
            conditions.append("event.ctrlKey")
        if "alt" in modifiers:
            conditions.append("event.altKey")
        if "shift" in modifiers:
            conditions.append("event.shiftKey")
        if "meta" in modifiers:
            conditions.append("event.metaKey")

        return " && ".join(conditions)

class JHLJavaScriptCommandHandler:
    HELP: dict = {
        "js": {
            "signature":   "js (path) (event) (js code | file.js)",
            "description": (
                "Attaches a JavaScript event handler to the element(s) at the given JHtml path. "
                "The JS code runs each time the specified event fires. "
                "If the code argument is a path ending in .js, the file is read and inlined."
            ),
            "flags": [],
        },
    }

    _SIMPLE_EVENTS = {"click", "hover", "scroll", "load", "moved"}
    _PARAMETERISED_EVENTS = {"key_down", "key_up", "every", "after"}
    _TIME_SUFFIXES = {"ms": 1, "s": 1000, "min": 60000}

    def __init__(self, handler):
        self._h = handler

    def run(self, args: list, json_html, root_cwd: str):
        if len(args) < 3:
            self._h._log_entry(
                "WARNING",
                "[js] Requires (path) (event) (js code | file.js) -- skipped",
            )
            return json_html

        path_str = str(args[0])
        event_raw = str(args[1])
        js_code = " ".join(str(a) for a in args[2:])

        js_code_stripped = js_code.strip()
        if js_code_stripped.endswith(".js") and "\n" not in js_code_stripped and ";" not in js_code_stripped:
            abs_js_path = os.path.normpath(os.path.join(root_cwd, js_code_stripped))
            content = self._h.files.read(abs_js_path)
            if content is None:
                self._h._log_entry("ERROR", f"[js] Could not read JS file: {abs_js_path}")
                return json_html
            self._h._log_entry("INFO", f"[js] Loaded JS file: {js_code_stripped}")
            js_code = content

        event_name, event_param = self._parse_event(event_raw)
        if event_name is None:
            return json_html

        path_obj = self._h._path_find(path_str)
        if path_obj is None:
            self._h._log_entry("ERROR", f"[js] Path not found: '{path_str}'")
            return json_html

        target = path_obj.node()
        if not isinstance(target, dict):
            self._h._log_entry("ERROR", f"[js] Path resolved to a non-dict node: '{path_str}'")
            return json_html

        script_block = self._build_script(target, event_name, event_param, js_code, path_str)
        self._inject_script(target, script_block)
        self._h._log_entry("INFO", f"[js] Attached '{event_raw}' handler at '{path_str}'")
        return json_html

    def _parse_event(self, raw: str) -> tuple:
        relib = self._h.relib

        if relib.load(raw).get_contains(":"):
            parts = relib.split([":"]).get_split()
            name = parts[0]
            param = ":".join(parts[1:])
        else:
            name, param = raw, None

        name_lower = name.lower()

        if name_lower in self._SIMPLE_EVENTS:
            if param is not None:
                self._h._log_entry(
                    "WARNING",
                    f"[js] Event '{name_lower}' does not take a parameter -- ignoring '{param}'",
                )
            return name_lower, None

        if name_lower in self._PARAMETERISED_EVENTS:
            if param is None:
                self._h._log_entry(
                    "WARNING",
                    f"[js] Event '{name_lower}' requires a parameter (e.g. {name_lower}:value) -- skipped",
                )
                return None, None

            if name_lower in ("every", "after"):
                ms = self._parse_time(param)
                if ms is None:
                    return None, None
                return name_lower, ms

            return name_lower, param

        self._h._log_entry("WARNING", f"[js] Unknown event type '{raw}' -- skipped")
        return None, None

    def _parse_time(self, raw: str) -> int | None:
        relib = self._h.relib
        matches = relib.load(raw.strip()).get_matches(
            r"^(\d+(?:\.\d+)?)(ms|s|min)$", regex=True
        )
        if not matches:
            self._h._log_entry(
                "ERROR",
                f"[js] Invalid time value '{raw}' -- expected e.g. 100ms, 2s, 1min",
            )
            return None

        relib.load(raw.strip())
        num_part = relib.get_matches(r"^\d+(?:\.\d+)?", regex=True)[0]
        suffix = relib.get_matches(r"(ms|s|min)$", regex=True)[0]
        value = float(num_part)
        return int(value * self._TIME_SUFFIXES[suffix.lower()])

    def _build_script(self, target: dict, event: str, param, js_code: str, path_str: str) -> str:
        selector = self._css_selector_for(target, path_str)
        escaped_code = self._escape_js(js_code)

        if event == "click":
            return self._wrap_dom_event(selector, "click", escaped_code)

        if event == "hover":
            return self._wrap_dom_event(selector, "mouseenter", escaped_code)

        if event == "scroll":
            return self._wrap_dom_event(selector, "scroll", escaped_code)

        if event == "load":
            return (
                f"document.addEventListener('DOMContentLoaded', function() {{\n"
                f"  var _el = document.querySelector('{selector}');\n"
                f"  if (_el) {{ (function() {{ {escaped_code} }}).call(_el); }}\n"
                f"}});\n"
            )

        if event in ("key_down", "key_up"):
            dom_event = "keydown" if event == "key_down" else "keyup"
            return self._wrap_key_event(selector, dom_event, param, escaped_code)

        if event == "every":
            return (
                f"setInterval(function() {{\n"
                f"  var _el = document.querySelector('{selector}');\n"
                f"  if (_el) {{ (function() {{ {escaped_code} }}).call(_el); }}\n"
                f"}}, {param});\n"
            )

        if event == "after":
            return (
                f"setTimeout(function() {{\n"
                f"  var _el = document.querySelector('{selector}');\n"
                f"  if (_el) {{ (function() {{ {escaped_code} }}).call(_el); }}\n"
                f"}}, {param});\n"
            )

        if event == "moved":
            return (
                f"(function() {{\n"
                f"  var _el = document.querySelector('{selector}');\n"
                f"  if (_el) {{\n"
                f"    var _obs = new MutationObserver(function(mutations) {{\n"
                f"      mutations.forEach(function(m) {{\n"
                f"        if (m.type === 'childList') {{\n"
                f"          m.removedNodes.forEach(function(n) {{\n"
                f"            if (n === _el || (n.contains && n.contains(_el))) {{\n"
                f"              (function() {{ {escaped_code} }}).call(_el);\n"
                f"            }}\n"
                f"          }});\n"
                f"        }}\n"
                f"      }});\n"
                f"    }});\n"
                f"    _obs.observe(document.body, {{ childList: true, subtree: true }});\n"
                f"  }}\n"
                f"}})();\n"
            )

        return ""

    def _wrap_dom_event(self, selector: str, dom_event: str, code: str) -> str:
        return (
            f"document.querySelector('{selector}')"
            f".addEventListener('{dom_event}', function(event) {{\n"
            f"  {code}\n"
            f"}});\n"
        )

    def _wrap_key_event(self, selector: str, dom_event: str, combo: str, code: str) -> str:
        relib = self._h.relib
        parts = relib.load(combo).split(["+"]).get_split()
        parts = [p.strip() for p in parts]
        key = parts[-1]
        modifiers = [m.lower() for m in parts[:-1]]

        conditions = [f"event.key.toLowerCase() === '{key.lower()}'"]
        if "ctrl" in modifiers:
            conditions.append("event.ctrlKey")
        if "alt" in modifiers:
            conditions.append("event.altKey")
        if "shift" in modifiers:
            conditions.append("event.shiftKey")
        if "meta" in modifiers:
            conditions.append("event.metaKey")

        check = " && ".join(conditions)

        return (
            f"document.querySelector('{selector}')"
            f".addEventListener('{dom_event}', function(event) {{\n"
            f"  if ({check}) {{\n"
            f"    event.preventDefault();\n"
            f"    {code}\n"
            f"  }}\n"
            f"}});\n"
        )

    def _escape_js(self, code: str) -> str:
        return code

    @staticmethod
    def _css_selector_for(node: dict, fallback_path: str) -> str:
        el_type = node.get("el type", "div")

        if "id" in node:
            return f"#{node['id']}"

        classes = node.get("class", "")
        if isinstance(classes, list):
            classes = " ".join(classes)
        if classes:
            cls_sel = "." + ".".join(classes.split())
            return f"{el_type}{cls_sel}"

        return fallback_path.replace("/", " > ")

    def _inject_script(self, target: dict, script_block: str) -> None:
        script_node = {
            "el type": "script",
            "inner html": [script_block],
        }
        self._h._inject_sibling_after(target, script_node)