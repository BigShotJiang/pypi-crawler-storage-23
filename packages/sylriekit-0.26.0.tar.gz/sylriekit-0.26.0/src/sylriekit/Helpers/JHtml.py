class JHtmlPath:
    def __init__(self, str_path: str, jhtml=None, _branches: list = None):
        self.str_path = str_path
        self._jhtml = jhtml
        self._active_index = 0
        self._branches = _branches or []

        if jhtml is not None and _branches is None:
            self._init_path()


    def _init_path(self):
        tree = self._jhtml.config.get("data")
        parent_map = self._build_parent_map(tree)
        matches = self._jhtml._get_all_paths(self.str_path)

        for node in matches:
            chain = self._chain_for(node, parent_map)
            self._branches.append({
                "node": node,
                "parent_chain": chain,
            })


    def cd(self, path: str):
        parts = self._split_cd_parts(path)
        new_branches = list(self._branches)

        for part in parts:
            if part == "..":
                next_branches = []
                for branch in new_branches:
                    if branch["parent_chain"]:
                        parent = branch["parent_chain"][-1]
                        next_branches.append({
                            "node": parent,
                            "parent_chain": branch["parent_chain"][:-1],
                        })
                new_branches = next_branches
            else:
                next_branches = []
                for branch in new_branches:
                    matches = self._jhtml._search_segment_all(
                        branch["node"], self._to_search_segment(part), False
                    )
                    for match in matches:
                        next_branches.append({
                            "node": match,
                            "parent_chain": branch["parent_chain"] + [branch["node"]],
                        })
                new_branches = next_branches

        self._branches = new_branches
        self._active_index = 0
        return self


    def to_string(self):
        branch = self._active_branch()
        if branch is None:
            return ""
        return self._branch_to_path_string(branch)

    def get_all(self):
        paths = []
        for branch in self._branches:
            p = JHtmlPath(self.str_path, self._jhtml, _branches=[branch])
            paths.append(p)
        return paths

    def use_index(self, index: int):
        if index < 0 or index >= len(self._branches):
            raise IndexError(
                f"Branch index {index} out of range (0..{len(self._branches) - 1})"
            )
        self._active_index = index
        return self

    def node(self):
        branch = self._active_branch()
        return branch["node"] if branch else None

    def count(self):
        return len(self._branches)


    def absolute_path(self):
        branch = self._active_branch()
        if branch is None:
            return ""
        full_chain = branch["parent_chain"] + [branch["node"]]
        parts = []
        for n in full_chain:
            if not isinstance(n, dict):
                continue
            parts.append(self._node_to_full_selector(n))
        return "/".join(parts)

    def min_path(self):
        branch = self._active_branch()
        if branch is None:
            return ""

        node = branch["node"]

        if isinstance(node, dict) and node.get("id"):
            candidate = f"#{node['id']}"
            if self._is_unique(candidate):
                return candidate

        full_chain = branch["parent_chain"] + [node]
        full_chain = [n for n in full_chain if isinstance(n, dict)]

        for length in range(1, len(full_chain) + 1):
            suffix = full_chain[-length:]
            candidate = self._chain_to_min_selector(suffix, full_chain)
            if self._is_unique(candidate):
                return candidate

        return self.absolute_path()


    def _active_branch(self):
        if not self._branches:
            return None
        if self._active_index >= len(self._branches):
            return None
        return self._branches[self._active_index]

    def _build_parent_map(self, tree):
        parent_map = {}
        if isinstance(tree, list):
            for item in tree:
                self._walk_parents(item, None, parent_map)
        elif isinstance(tree, dict):
            self._walk_parents(tree, None, parent_map)
        return parent_map

    def _walk_parents(self, node, parent, parent_map):
        if not isinstance(node, dict):
            return
        parent_map[id(node)] = parent
        children = node.get("inner html") or node.get("html data") or []
        if not isinstance(children, list):
            children = [children]
        for child in children:
            self._walk_parents(child, node, parent_map)

    def _chain_for(self, node, parent_map):
        chain = []
        current = parent_map.get(id(node))
        while current is not None:
            chain.append(current)
            current = parent_map.get(id(current))
        chain.reverse()
        return chain

    def _split_cd_parts(self, path: str):
        parts = []
        raw = path.strip("/")
        if not raw:
            return parts

        tokens = raw.split("/")
        i = 0
        while i < len(tokens):
            tok = tokens[i]
            if tok == "..":
                parts.append("..")
                i += 1
            elif tok == "~" and i + 1 < len(tokens):
                parts.append("~" + tokens[i + 1])
                i += 2
            elif tok == "":
                i += 1
            else:
                segment = tok
                if i + 1 < len(tokens) and tokens[i + 1].isdigit():
                    segment += "/" + tokens[i + 1]
                    i += 2
                else:
                    i += 1
                parts.append(segment)
        return parts

    def _to_search_segment(self, part: str):
        is_deep = part.startswith("~")
        if is_deep:
            return "~" + part[1:]
        return "~" + part

    def _node_to_full_selector(self, node: dict):
        el_type = node.get("el type", "")
        if el_type == "text":
            return "text"

        selector = el_type
        classes = node.get("class", [])
        if isinstance(classes, str):
            classes = [classes]
        for cls in classes:
            selector += f".{cls}"

        node_id = node.get("id", "")
        if node_id:
            selector += f"#{node_id}"

        return selector

    def _node_to_min_selector(self, node: dict):
        el_type = node.get("el type", "")
        node_id = node.get("id", "")
        if node_id:
            return f"#{node_id}"
        return el_type

    def _branch_to_path_string(self, branch):
        full_chain = branch["parent_chain"] + [branch["node"]]
        parts = []
        for n in full_chain:
            if not isinstance(n, dict):
                continue
            el_type = n.get("el type", "")
            if el_type == "text":
                parts.append("text")
            else:
                parts.append(el_type)
        return "/".join(parts)

    def _chain_to_min_selector(self, suffix_chain, full_chain):
        parts = []
        for node in suffix_chain:
            parent_idx = full_chain.index(node) - 1
            if parent_idx >= 0:
                parent = full_chain[parent_idx]
                children = self._jhtml._get_children(parent)
            else:
                children = self._jhtml.config.get("data")
                if not isinstance(children, list):
                    children = [children]

            selector = self._node_to_min_selector(node)
            parsed, _ = self._jhtml._parse_selector(selector)
            siblings = self._jhtml._find_children(children, parsed)

            if len(siblings) > 1:
                idx = next(
                    (i for i, s in enumerate(siblings) if s is node), 0
                )
                parts.append(f"{selector}/{idx}")
            else:
                parts.append(selector)

        is_from_root = len(suffix_chain) == len(full_chain)
        result = "/".join(parts)
        if not is_from_root:
            result = "~/" + result
        else:
            result = "/" + result
        return result

    def _is_unique(self, path_candidate: str):
        try:
            results = self._jhtml._get_all_paths(path_candidate)
            return len(results) == 1
        except Exception:
            return False

