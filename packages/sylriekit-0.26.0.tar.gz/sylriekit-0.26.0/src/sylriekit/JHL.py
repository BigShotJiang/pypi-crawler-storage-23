import os
import json
import time
from datetime import datetime

from sylriekit.ConfigLoader import ConfigLoader
from sylriekit.Files import Files
from sylriekit.JHtml import JHtml
from sylriekit.ReLib import ReLib
from sylriekit.Helpers.JHL import JHLCommandHandler as _JHLCommandHandler

class JHL:
    _config_items = {
        "JHL_DIR": ".jhl",
        "CACHE_DIR": "run_cache"
    }
    _REVERTIBLE_FILES = {"base.html", "base.json", "compile.html", "compile.json"}
    _STATUS_FILE = "status.json"

    def __init__(self, config: dict | str = None, dev: bool = False):
        self.config = ConfigLoader("JHL", self._config_items, config)
        self.files = Files(config)
        self.relib = ReLib(config)
        self.dev = dev
        self.cmd_handler = _JHLCommandHandler(config, dev=dev)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run_file(self, file_path: str, force: bool = False) -> dict:
        abs_path = os.path.normpath(os.path.abspath(file_path))
        root_dir = os.path.dirname(abs_path)
        self._ensure_jhl_dir(root_dir)

        # Guard: skip if already compiled (unless forced)
        if not force and self._is_compiled(abs_path, root_dir):
            return {
                "success": True,
                "skipped": True,
                "reason": "Already compiled (use force=True or revert first)",
                "cache_dir": self._get_cache_dir(abs_path, root_dir),
            }

        return self._process_file(abs_path, root_dir)

    def run_directory(self, folder_path: str, recursive: bool = True,
                      force: bool = False) -> dict:
        root_dir = os.path.normpath(os.path.abspath(folder_path))
        self._ensure_jhl_dir(root_dir)

        results = {}
        for dirpath, dir_names, filenames in os.walk(root_dir):
            dir_names[:] = sorted(d for d in dir_names if d != self.config.get("JHL_DIR"))

            if not recursive and os.path.normpath(dirpath) != root_dir:
                break

            for filename in sorted(filenames):
                if filename.lower().endswith(".html"):
                    abs_path = os.path.join(dirpath, filename)
                    rel = os.path.relpath(abs_path, root_dir)

                    if not force and self._is_compiled(abs_path, root_dir):
                        results[rel] = {
                            "success": True,
                            "skipped": True,
                            "reason": "Already compiled",
                            "cache_dir": self._get_cache_dir(abs_path, root_dir),
                        }
                        continue

                    results[rel] = self._process_file(abs_path, root_dir)

        return results

    def revert_file(self, file_path: str) -> bool:
        abs_path = os.path.normpath(os.path.abspath(file_path))
        root_dir = os.path.dirname(abs_path)
        cache_dir = self._get_cache_dir(abs_path, root_dir)

        if not os.path.isdir(cache_dir):
            return False

        log = []
        self._log(log, "INFO", f"Reverting: {abs_path}")

        base_html_path = os.path.join(cache_dir, "base.html")
        base_content = self.files.read(base_html_path)
        if base_content is None:
            self._log(log, "ERROR", "base.html not found in cache — revert aborted")
            self._write_log(cache_dir, log)
            return False

        self._safe_replace_file(base_content, abs_path, log)
        self._clear_status(abs_path, root_dir)
        self._log(log, "INFO", "Cleared compile status")
        self._write_log(cache_dir, log)
        self._clean_cache_dir(cache_dir)
        return True

    def revert_directory(self, folder_path: str) -> bool:
        root_dir = os.path.normpath(os.path.abspath(folder_path))
        cache_root = os.path.join(root_dir, self.config.get("JHL_DIR"),
                                  self.config.get("CACHE_DIR"))
        if not os.path.isdir(cache_root):
            return False

        # Revert individual files so their originals are restored
        for dirpath, _dir_names, filenames in os.walk(cache_root):
            for filename in filenames:
                if filename == "base.html":
                    base_path = os.path.join(dirpath, filename)
                    # Reconstruct the original file path from cache structure
                    rel_cache = os.path.relpath(dirpath, cache_root)
                    original_path = os.path.join(root_dir, rel_cache + ".html")
                    original_path = os.path.normpath(original_path)
                    base_content = self.files.read(base_path)
                    if base_content is not None and os.path.isfile(original_path):
                        log = []
                        self._safe_replace_file(base_content, original_path, log)

        # Clear all status entries
        self._clear_all_status(root_dir)

        self._clean_cache_tree(cache_root)
        return True

    def is_compiled(self, file_path: str) -> bool:
        abs_path = os.path.normpath(os.path.abspath(file_path))
        root_dir = os.path.dirname(abs_path)
        return self._is_compiled(abs_path, root_dir)

    def get_status(self, folder_path: str = None, file_path: str = None) -> dict:
        if file_path is not None:
            abs_path = os.path.normpath(os.path.abspath(file_path))
            root_dir = os.path.dirname(abs_path)
            status = self._read_status(root_dir)
            rel = os.path.relpath(abs_path, root_dir)
            entry = status.get(rel)
            return {"file": rel, "compiled": entry is not None, "info": entry}

        if folder_path is not None:
            root_dir = os.path.normpath(os.path.abspath(folder_path))
            return self._read_status(root_dir)

        return {}

    def watch_file(self, file_path: str, interval: float = 1.0,
                   on_compile: callable = None) -> None:
        abs_path = os.path.normpath(os.path.abspath(file_path))
        root_dir = os.path.dirname(abs_path)

        def _gather_watch_paths() -> list[str]:
            paths = [abs_path]
            html_content = self.files.read(abs_path)
            if html_content is None:
                return paths
            jhtml = JHtml()
            jhtml.html(html_content)
            base_dir = os.path.dirname(abs_path)
            log_sink: list = []
            scripts = self._find_jhl_scripts(jhtml.json(), base_dir, log_sink)
            for label, _content in scripts:
                if label.startswith("link:"):
                    href = label[5:]
                    script_path = os.path.normpath(os.path.join(base_dir, href))
                    if os.path.isfile(script_path):
                        paths.append(script_path)
            return paths

        def _get_mtimes(paths: list[str]) -> dict[str, float]:
            mtimes = {}
            for p in paths:
                try:
                    mtimes[p] = os.stat(p).st_mtime
                except OSError:
                    mtimes[p] = 0
            return mtimes

        watch_paths = _gather_watch_paths()
        last_mtimes = _get_mtimes(watch_paths)

        ts = datetime.now().strftime("%H:%M:%S")
        print(f"[{ts}] [JHL watch] Watching {abs_path}")
        print(f"[{ts}] [JHL watch] Tracking {len(watch_paths)} file(s) — "
              f"poll interval {interval}s")
        print(f"[{ts}] [JHL watch] Press Ctrl+C to stop\n")

        try:
            while True:
                time.sleep(interval)

                # Refresh watched paths (in case new <link> tags were added)
                watch_paths = _gather_watch_paths()
                current_mtimes = _get_mtimes(watch_paths)

                changed = []
                for p, mtime in current_mtimes.items():
                    if mtime != last_mtimes.get(p, 0):
                        changed.append(os.path.basename(p))

                if not changed:
                    continue

                last_mtimes = current_mtimes
                ts = datetime.now().strftime("%H:%M:%S")
                print(f"[{ts}] [JHL watch] Change detected in: "
                      f"{', '.join(changed)}")

                # Revert if currently compiled
                if self._is_compiled(abs_path, root_dir):
                    self.revert_file(file_path)

                result = self.run_file(file_path, force=True)
                ts = datetime.now().strftime("%H:%M:%S")
                if result.get("success"):
                    print(f"[{ts}] [JHL watch] Compiled successfully")
                else:
                    print(f"[{ts}] [JHL watch] Compile failed: "
                          f"{result.get('error', 'unknown')}")

                if on_compile is not None:
                    try:
                        on_compile(abs_path, result)
                    except Exception as exc:
                        print(f"[{ts}] [JHL watch] on_compile callback error: {exc}")

        except KeyboardInterrupt:
            ts = datetime.now().strftime("%H:%M:%S")
            print(f"\n[{ts}] [JHL watch] Stopped")

    def validate_file(self, file_path: str) -> dict:
        abs_path = os.path.normpath(os.path.abspath(file_path))
        issues: list[dict] = []
        script_labels: list[str] = []

        # --- Read HTML -----------------------------------------------
        html_content = self.files.read(abs_path)
        if html_content is None:
            issues.append({
                "level": "ERROR",
                "command": "validate",
                "message": f"Could not read file: {abs_path}",
            })
            return {"valid": False, "scripts": [], "issues": issues}

        jhtml = JHtml()
        jhtml.html(html_content)
        base_json = jhtml.json()
        base_dir = os.path.dirname(abs_path)

        # --- Discover scripts ----------------------------------------
        log_sink: list = []
        scripts = self._find_jhl_scripts(base_json, base_dir, log_sink)

        for entry in log_sink:
            if "[WARNING]" in entry:
                issues.append({
                    "level": "WARNING",
                    "command": "discovery",
                    "message": entry,
                })

        # --- Validate each script ------------------------------------
        handler = _JHLCommandHandler(self.config._raw_config if hasattr(self.config, '_raw_config') else None)
        handler.set_jhtml(jhtml)

        PATH_COMMANDS = {"add", "rm", "mod", "js", "css", "obj"}

        for label, content in scripts:
            script_labels.append(label)

            # Parse the script
            try:
                commands = handler._prepare_jhl(content)
            except Exception as exc:
                issues.append({
                    "level": "ERROR",
                    "command": f"parse ({label})",
                    "message": f"Syntax error: {exc}",
                })
                continue

            for cmd_dict in commands:
                for cmd, args in cmd_dict.items():
                    # Check import paths
                    if cmd == "import":
                        import_tokens = [str(a) for a in args
                                         if not str(a).lower().startswith("-")]
                        if import_tokens:
                            import_path = os.path.normpath(
                                os.path.join(base_dir, import_tokens[0]))
                            if not os.path.isfile(import_path):
                                issues.append({
                                    "level": "ERROR",
                                    "command": f"import ({label})",
                                    "message": f"File not found: {import_tokens[0]} "
                                               f"(resolved: {import_path})",
                                })

                    # Check path arguments for tree-mutating/injection commands
                    if cmd in PATH_COMMANDS and args:
                        path_token = str(args[0])
                        if path_token.startswith("-"):
                            continue  # flag, not a path
                        path_obj = handler._path_find(path_token)
                        if path_obj is None:
                            issues.append({
                                "level": "WARNING",
                                "command": f"{cmd} ({label})",
                                "message": f"Path not found in HTML tree: '{path_token}'",
                            })

                    # Note about unvalidated py blocks
                    if cmd == "py":
                        issues.append({
                            "level": "INFO",
                            "command": f"py ({label})",
                            "message": "Python block cannot be statically validated",
                        })

        has_errors = any(i["level"] == "ERROR" for i in issues)
        return {
            "valid": not has_errors,
            "scripts": script_labels,
            "issues": issues,
        }

    def watch_directory(self, folder_path: str, recursive: bool = True,
                        interval: float = 1.0,
                        on_compile: callable = None) -> None:
        root_dir = os.path.normpath(os.path.abspath(folder_path))
        jhl_dir_name = self.config.get("JHL_DIR")

        def _discover_html_files() -> list[str]:
            html_files = []
            for dirpath, dir_names, filenames in os.walk(root_dir):
                dir_names[:] = sorted(d for d in dir_names if d != jhl_dir_name)
                if not recursive and os.path.normpath(dirpath) != root_dir:
                    break
                for fn in sorted(filenames):
                    if fn.lower().endswith(".html"):
                        html_files.append(os.path.join(dirpath, fn))
            return html_files

        def _gather_all_watch_paths(html_files: list[str]) -> dict[str, list[str]]:
            mapping: dict[str, list[str]] = {}
            for html_path in html_files:
                paths = [html_path]
                html_content = self.files.read(html_path)
                if html_content is not None:
                    jhtml = JHtml()
                    jhtml.html(html_content)
                    base_dir = os.path.dirname(html_path)
                    log_sink: list = []
                    scripts = self._find_jhl_scripts(jhtml.json(), base_dir, log_sink)
                    for label, _content in scripts:
                        if label.startswith("link:"):
                            href = label[5:]
                            sp = os.path.normpath(os.path.join(base_dir, href))
                            if os.path.isfile(sp):
                                paths.append(sp)
                mapping[html_path] = paths
            return mapping

        def _get_mtimes(path_map: dict[str, list[str]]) -> dict[str, float]:
            mtimes: dict[str, float] = {}
            for paths in path_map.values():
                for p in paths:
                    if p not in mtimes:
                        try:
                            mtimes[p] = os.stat(p).st_mtime
                        except OSError:
                            mtimes[p] = 0
            return mtimes

        def _changed_html_files(
            path_map: dict[str, list[str]],
            old_mtimes: dict[str, float],
            new_mtimes: dict[str, float],
        ) -> list[str]:
            changed = []
            for html_path, paths in path_map.items():
                for p in paths:
                    if new_mtimes.get(p, 0) != old_mtimes.get(p, 0):
                        changed.append(html_path)
                        break
            return changed

        html_files = _discover_html_files()
        path_map = _gather_all_watch_paths(html_files)
        last_mtimes = _get_mtimes(path_map)

        total_files = sum(len(v) for v in path_map.values())
        ts = datetime.now().strftime("%H:%M:%S")
        print(f"[{ts}] [JHL watch] Watching directory: {root_dir}")
        print(f"[{ts}] [JHL watch] Tracking {len(html_files)} HTML file(s), "
              f"{total_files} total file(s) — poll interval {interval}s")
        print(f"[{ts}] [JHL watch] Press Ctrl+C to stop\n")

        try:
            while True:
                time.sleep(interval)

                html_files = _discover_html_files()
                path_map = _gather_all_watch_paths(html_files)
                current_mtimes = _get_mtimes(path_map)

                changed = _changed_html_files(path_map, last_mtimes, current_mtimes)
                if not changed:
                    last_mtimes = current_mtimes
                    continue

                last_mtimes = current_mtimes

                for html_path in changed:
                    rel = os.path.relpath(html_path, root_dir)
                    ts = datetime.now().strftime("%H:%M:%S")
                    print(f"[{ts}] [JHL watch] Change detected: {rel}")

                    if self._is_compiled(html_path, root_dir):
                        self.revert_file(html_path)

                    result = self.run_file(html_path, force=True)
                    ts = datetime.now().strftime("%H:%M:%S")
                    if result.get("success"):
                        print(f"[{ts}] [JHL watch] Compiled: {rel}")
                    else:
                        print(f"[{ts}] [JHL watch] Failed: {rel} — "
                              f"{result.get('error', 'unknown')}")

                    if on_compile is not None:
                        try:
                            on_compile(html_path, result)
                        except Exception as exc:
                            print(f"[{ts}] [JHL watch] on_compile error: {exc}")

        except KeyboardInterrupt:
            ts = datetime.now().strftime("%H:%M:%S")
            print(f"\n[{ts}] [JHL watch] Stopped")

    def validate_directory(self, folder_path: str,
                           recursive: bool = True) -> dict:
        root_dir = os.path.normpath(os.path.abspath(folder_path))
        jhl_dir_name = self.config.get("JHL_DIR")
        results: dict[str, dict] = {}

        for dirpath, dir_names, filenames in os.walk(root_dir):
            dir_names[:] = sorted(d for d in dir_names if d != jhl_dir_name)
            if not recursive and os.path.normpath(dirpath) != root_dir:
                break
            for fn in sorted(filenames):
                if fn.lower().endswith(".html"):
                    abs_path = os.path.join(dirpath, fn)
                    rel = os.path.relpath(abs_path, root_dir)
                    results[rel] = self.validate_file(abs_path)

        all_valid = all(r["valid"] for r in results.values()) if results else True
        return {"dir_valid": all_valid, "files": results}

    # ------------------------------------------------------------------
    # Compile pipeline
    # ------------------------------------------------------------------

    def _process_file(self, abs_file_path: str, root_dir: str) -> dict:
        cache_dir = self._get_cache_dir(abs_file_path, root_dir)
        os.makedirs(cache_dir, exist_ok=True)

        log = []
        self._log(log, "INFO", f"Processing: {abs_file_path}")

        html_content = self.files.read(abs_file_path)
        if html_content is None:
            self._log(log, "ERROR", f"Could not read file: {abs_file_path}")
            self._write_log(cache_dir, log)
            return {"success": False, "error": "Could not read file"}

        self.files.write(os.path.join(cache_dir, "base.html"), html_content)
        self._log(log, "INFO", "Wrote base.html")

        json_html = JHtml()
        json_html.html(html_content)
        base_json = json_html.json()

        self.files.write(
            os.path.join(cache_dir, "base.json"),
            json.dumps(base_json, indent=2, ensure_ascii=False)
        )
        self._log(log, "INFO", "Wrote base.json")

        base_dir = os.path.dirname(abs_file_path)
        scripts = self._find_jhl_scripts(base_json, base_dir, log)
        self._log(log, "INFO", f"Found {len(scripts)} JHL script(s)")

        self.cmd_handler.clear_data()
        self.cmd_handler.set_jhtml(json_html)
        compiled_data = base_json

        for label, content in scripts:
            self._log(log, "INFO", f"Running script: [{label}]")
            try:
                compiled_data, info = self.cmd_handler.run_script(
                    {"content": content, "path": label},
                    compiled_data,
                    base_dir,
                    clear_data=False
                )
                log.extend(info["log"])
            except Exception as exc:
                self._log(log, "ERROR", f"  Script error: {exc}")

        # Strip <link rel="jhl"> and <jhl> nodes from the compiled tree
        removed = self._strip_jhl_nodes(compiled_data)
        self._log(log, "INFO", f"Stripped {removed} JHL node(s) from compiled output")

        self.files.write(
            os.path.join(cache_dir, "compile.json"),
            json.dumps(compiled_data, indent=2, ensure_ascii=False)
        )
        self._log(log, "INFO", "Wrote compile.json")

        json_html_out = JHtml()
        json_html_out.json(compiled_data)
        compiled_html = json_html_out.html()
        self.files.write(os.path.join(cache_dir, "compile.html"), compiled_html)
        self._log(log, "INFO", "Wrote compile.html")

        self._safe_replace_file(compiled_html, abs_file_path, log)

        # Mark as compiled in status
        self._set_status(abs_file_path, root_dir, {
            "compiled_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "cache_dir": cache_dir,
            "scripts": len(scripts),
            "stripped_nodes": removed,
        })
        self._log(log, "INFO", "Status set to compiled")

        self._write_log(cache_dir, log)
        return {"success": True, "cache_dir": cache_dir}

    # ------------------------------------------------------------------
    # Script discovery
    # ------------------------------------------------------------------

    def _find_jhl_scripts(self, json_html_data: list, base_dir: str, log: list) -> list:
        scripts = []
        self._collect_jhl_nodes(json_html_data, base_dir, log, scripts)
        return scripts

    def _collect_jhl_nodes(self, nodes, base_dir: str, log: list, out: list):
        if isinstance(nodes, dict):
            nodes = [nodes]
        if not isinstance(nodes, list):
            return

        for node in nodes:
            if not isinstance(node, dict):
                continue

            el = node.get("el type", "")

            if el == "link" and node.get("rel") == "jhl":
                href = node.get("href", "").strip()
                if href:
                    abs_jhl = os.path.normpath(os.path.join(base_dir, href))
                    content = self.files.read(abs_jhl)
                    if content is not None:
                        out.append((f"link:{href}", content))
                        self._log(log, "INFO", f"  Loaded linked script: {href}")
                    else:
                        self._log(log, "WARNING", f"  Could not read linked script: {href}")
                else:
                    self._log(log, "WARNING", "  <link rel='jhl'> has no href attribute")

            elif el == "jhl":
                inner = node.get("inner html", [])
                text_parts = [
                    child.get("content", "")
                    for child in inner
                    if isinstance(child, dict) and child.get("el type") == "text"
                ]
                content = "\n".join(text_parts).strip()
                if content:
                    out.append(("inline:jhl", content))
                    self._log(log, "INFO", "  Found inline <jhl> block")

            for child_key in ("inner html", "html data"):
                children = node.get(child_key)
                if isinstance(children, list):
                    self._collect_jhl_nodes(children, base_dir, log, out)

    # ------------------------------------------------------------------
    # JHL node stripping
    # ------------------------------------------------------------------

    def _strip_jhl_nodes(self, tree) -> int:
        if isinstance(tree, dict):
            tree = [tree]
        if not isinstance(tree, list):
            return 0
        return self._strip_jhl_from_list(tree)

    def _strip_jhl_from_list(self, nodes: list) -> int:
        removed = 0
        i = 0
        while i < len(nodes):
            node = nodes[i]
            if not isinstance(node, dict):
                i += 1
                continue

            el = node.get("el type", "")
            is_jhl_link = (el == "link" and node.get("rel") == "jhl")
            is_jhl_block = (el == "jhl")

            if is_jhl_link or is_jhl_block:
                nodes.pop(i)
                removed += 1
                continue

            # Recurse into children
            for child_key in ("inner html", "html data"):
                children = node.get(child_key)
                if isinstance(children, list):
                    removed += self._strip_jhl_from_list(children)

            i += 1
        return removed

    # ------------------------------------------------------------------
    # Status tracking
    # ------------------------------------------------------------------

    def _get_status_path(self, root_dir: str) -> str:
        return os.path.join(root_dir, self.config.get("JHL_DIR"), self._STATUS_FILE)

    def _read_status(self, root_dir: str) -> dict:
        path = self._get_status_path(root_dir)
        if not os.path.isfile(path):
            return {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}

    def _write_status(self, root_dir: str, status: dict):
        path = self._get_status_path(root_dir)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(status, f, indent=2, ensure_ascii=False)

    def _is_compiled(self, abs_file_path: str, root_dir: str) -> bool:
        status = self._read_status(root_dir)
        rel = os.path.relpath(abs_file_path, root_dir)
        return rel in status

    def _set_status(self, abs_file_path: str, root_dir: str, info: dict):
        status = self._read_status(root_dir)
        rel = os.path.relpath(abs_file_path, root_dir)
        status[rel] = info
        self._write_status(root_dir, status)

    def _clear_status(self, abs_file_path: str, root_dir: str):
        status = self._read_status(root_dir)
        rel = os.path.relpath(abs_file_path, root_dir)
        if rel in status:
            del status[rel]
            self._write_status(root_dir, status)

    def _clear_all_status(self, root_dir: str):
        path = self._get_status_path(root_dir)
        if os.path.isfile(path):
            with open(path, "w", encoding="utf-8") as f:
                json.dump({}, f)

    # ------------------------------------------------------------------
    # File I/O helpers
    # ------------------------------------------------------------------

    def _safe_replace_file(self, content: str, dst_path: str, log: list):
        stem, _ext = os.path.splitext(dst_path)
        tmp_path = dst_path + ".jhl_tmp"
        fallback_path = f"{stem}-move-error.html"

        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                f.write(content)
            os.replace(tmp_path, dst_path)
            self._log(log, "INFO", f"Replaced original file: {dst_path}")
        except OSError as exc:
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except OSError:
                pass
            try:
                with open(fallback_path, "w", encoding="utf-8") as f:
                    f.write(content)
                self._log(log, "WARNING",
                          f"Could not replace original ({exc}). "
                          f"Compiled output saved to: {fallback_path}")
            except OSError as fallback_exc:
                self._log(log, "ERROR",
                          f"Could not replace original ({exc}) and fallback "
                          f"also failed ({fallback_exc}). Compiled output only in cache.")

    def _get_cache_dir(self, abs_file_path: str, root_dir: str) -> str:
        rel = os.path.relpath(abs_file_path, root_dir)
        name_no_ext = os.path.splitext(rel)[0]
        return os.path.join(root_dir, self.config.get("JHL_DIR"),
                            self.config.get("CACHE_DIR"), name_no_ext)

    def _ensure_jhl_dir(self, root_dir: str):
        cache_path = os.path.join(root_dir, self.config.get("JHL_DIR"),
                                  self.config.get("CACHE_DIR"))
        os.makedirs(cache_path, exist_ok=True)

    def _clean_cache_dir(self, cache_dir: str) -> bool:
        if not os.path.isdir(cache_dir):
            return False
        for filename in self._REVERTIBLE_FILES:
            target = os.path.join(cache_dir, filename)
            if os.path.exists(target):
                os.remove(target)
        try:
            remaining = [f for f in os.listdir(cache_dir) if f != "compile.log"]
            if not remaining and not os.listdir(cache_dir):
                os.rmdir(cache_dir)
        except OSError:
            pass
        return True

    def _clean_cache_tree(self, cache_root: str):
        for dirpath, dir_names, filenames in os.walk(cache_root, topdown=False):
            dir_names.sort()
            for filename in filenames:
                if filename in self._REVERTIBLE_FILES:
                    os.remove(os.path.join(dirpath, filename))
            if dirpath == cache_root:
                continue
            try:
                remaining = os.listdir(dirpath)
                if not remaining:
                    os.rmdir(dirpath)
            except OSError:
                pass

    # ------------------------------------------------------------------
    # Logging
    # ------------------------------------------------------------------

    @staticmethod
    def _log(log: list, level: str, message: str):
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log.append(f"[{ts}] [{level:<7}] {message}")

    @staticmethod
    def _write_log(cache_dir: str, log: list):
        log_path = os.path.join(cache_dir, "compile.log")
        divider = "=" * 60
        header = f"\n{divider}\nRun: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n{divider}\n"
        mode = "a" if os.path.exists(log_path) else "w"
        with open(log_path, mode) as f:
            f.write(header + "\n".join(log) + "\n")