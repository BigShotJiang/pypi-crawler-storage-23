from sylriekit.ConfigLoader import ConfigLoader
import os
import re
import glob
import shutil

class Files:
    config = None
    _config_items = {
        "CWD": "",
        "FORCED_DIR": ""
    }

    def __init__(self, config: dict | str = None):
        self._config_items["CWD"] = os.getcwd()
        self.config = ConfigLoader("Files", self._config_items, config)
        self._last_search_results = []
        self._last_search_index = 0

    def read(self, file_path: str, encoding="utf-8") -> str | None:
        path = self._legal_path(self._handle_path_shortcuts(self._format_path(file_path)))
        if path is None:
            return None
        with open(path, "r", encoding=encoding) as f:
            return f.read()

    def write(self, file_path: str, content: str = "", overwrite: bool = True, encoding="utf-8") -> bool:
        path = self._legal_path(self._format_path(file_path))
        if path is None:
            return False
        if file_path.endswith("/") or file_path.endswith(os.sep):
            os.makedirs(path, exist_ok=True)
            return True
        if os.path.exists(path) and not overwrite:
            return False
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding=encoding) as f:
            f.write(content)
        return True

    def copy(self, file_path: str, new_file_path: str) -> str | None:
        src = self._legal_path(self._handle_path_shortcuts(self._format_path(file_path)))
        dst = self._legal_path(self._format_path(new_file_path))
        if src is None or dst is None:
            return None
        if os.path.dirname(os.path.abspath(src)) == os.path.dirname(os.path.abspath(dst)):
            name, ext = os.path.splitext(os.path.basename(dst))
            dst = os.path.join(os.path.dirname(dst), f"{name}_copy{ext}")
        if os.path.isdir(src):
            shutil.copytree(src, dst)
        else:
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
        return dst

    def delete(self, file_path: str) -> bool:
        path = self._legal_path(self._handle_path_shortcuts(self._format_path(file_path)))
        if path is None or not os.path.exists(path):
            return False
        if os.path.isdir(path):
            shutil.rmtree(path)
        else:
            os.remove(path)
        return True

    def move(self, file_path: str, new_destination: str) -> str | None:
        src = self._legal_path(self._handle_path_shortcuts(self._format_path(file_path)))
        dst = self._legal_path(self._format_path(new_destination))
        if src is None or dst is None:
            return None
        os.makedirs(dst if os.path.isdir(dst) else os.path.dirname(dst), exist_ok=True)
        shutil.move(src, dst)
        return os.path.join(dst, os.path.basename(src)) if os.path.isdir(dst) else dst

    def map(self, is_json: bool = False, max_results: int = -1, only_files: bool = False, only_folders: bool = False) -> list | dict:
        cwd = self.config.get("CWD")
        counter = [0]
        if is_json:
            result = {}
            folders = sorted(e for e in os.listdir(cwd) if os.path.isdir(os.path.join(cwd, e)))
            files = sorted(e for e in os.listdir(cwd) if not os.path.isdir(os.path.join(cwd, e)))
            entries = [(e, True) for e in folders] + [(e, False) for e in files]
            for entry, is_dir in entries:
                if max_results != -1 and counter[0] >= max_results:
                    break
                if only_files and is_dir:
                    continue
                if only_folders and not is_dir:
                    continue
                counter[0] += 1
                full_path = os.path.join(cwd, entry)
                if is_dir:
                    children = self._build_map(full_path, is_json, max_results, only_files, only_folders, counter)
                    result[entry] = {"folder": True, "children": children}
                else:
                    result[entry] = {"folder": False}
            return result
        else:
            result = []
            folders = sorted(e for e in os.listdir(cwd) if os.path.isdir(os.path.join(cwd, e)))
            files = sorted(e for e in os.listdir(cwd) if not os.path.isdir(os.path.join(cwd, e)))
            entries = [(e, True) for e in folders] + [(e, False) for e in files]
            for entry, is_dir in entries:
                if max_results != -1 and counter[0] >= max_results:
                    break
                if only_files and is_dir:
                    continue
                if only_folders and not is_dir:
                    continue
                counter[0] += 1
                rel = entry + "/" if is_dir else entry
                result.append(rel)
                if is_dir:
                    result.extend(self._build_map(os.path.join(cwd, entry), is_json, max_results, only_files, only_folders, counter, rel))
            return result

    def cwd(self, folder_path: str) -> str:
        path = self._legal_path(self._format_path(folder_path))
        self.config.set("CWD", path)
        os.chdir(path)
        return path

    def _build_map(self, base: str, is_json: bool, max_results: int, only_files: bool, only_folders: bool, counter: list, prefix: str = "") -> list:
        try:
            folders = sorted(e for e in os.listdir(base) if os.path.isdir(os.path.join(base, e)))
            files = sorted(e for e in os.listdir(base) if not os.path.isdir(os.path.join(base, e)))
        except (PermissionError, FileNotFoundError):
            return [] if not is_json else []
        entries = [(e, True) for e in folders] + [(e, False) for e in files]

        if is_json:
            result = []
            for entry, is_dir in entries:
                if max_results != -1 and counter[0] >= max_results:
                    break
                if only_files and is_dir:
                    continue
                if only_folders and not is_dir:
                    continue
                counter[0] += 1
                full_path = os.path.join(base, entry)
                if is_dir:
                    children = self._build_map(full_path, is_json, max_results, only_files, only_folders, counter)
                    result.append({entry: {"folder": True, "children": children}})
                else:
                    result.append({entry: {"folder": False}})
            return result
        else:
            result = []
            for entry, is_dir in entries:
                if max_results != -1 and counter[0] >= max_results:
                    break
                if only_files and is_dir:
                    continue
                if only_folders and not is_dir:
                    continue
                counter[0] += 1
                rel = prefix + entry + "/" if is_dir else prefix + entry
                result.append(rel)
                if is_dir:
                    result.extend(self._build_map(os.path.join(base, entry), is_json, max_results, only_files, only_folders, counter, rel))
            return result


    def _format_path(self, path: str) -> str:
        path = path.strip()

        if re.match(r"^/[A-Za-z]:[/\\]", path):
            path = path[1:]

        path = path.replace("\\\\", "/").replace("\\", "/")

        if os.name == "nt":
            mnt = re.match(r"^/?mnt/([a-zA-Z])(/.*)?$", path)
            if mnt:
                path = f"{mnt.group(1).upper()}:{mnt.group(2) or ''}"
        else:
            drive = re.match(r"^([A-Za-z]):(/.*)$", path)
            if drive:
                path = f"/mnt/{drive.group(1).lower()}{drive.group(2)}"

        return os.path.normpath(path)

    def _legal_path(self, path: str) -> str | None:
        if path is None:
            return None

        forced_dir = self.config.get("FORCED_DIR")
        cwd = self.config.get("CWD")

        if not os.path.isabs(path):
            path = os.path.join(cwd, path)

        path = os.path.normpath(path)

        if not forced_dir:
            return path

        forced_dir = os.path.normpath(forced_dir)

        if path.startswith(forced_dir):
            return path

        corrected = os.path.normpath(os.path.join(forced_dir, path.lstrip(os.sep)))
        if corrected.startswith(forced_dir):
            return corrected

        raise PermissionError(f"Path '{path}' is outside the forced directory '{forced_dir}'")

    def _handle_path_shortcuts(self, path: str) -> str | None:
        at_match = re.match(r"^@(next|\+|prev|p|l|n|last|-|=(\d+)|i(\d+))$", path.strip(), re.IGNORECASE)
        if at_match:
            token = at_match.group(1).lower()
            if token in ("next", "+", "n"):
                self._last_search_index += 1
            elif token in ("prev", "last", "-", "l", "p"):
                self._last_search_index -= 1
            elif token.startswith("=") or token.startswith("i"):
                self._last_search_index = int(at_match.group(2)) - 1
            self._last_search_index = max(0, self._last_search_index)
            if self._last_search_index < len(self._last_search_results):
                return self._last_search_results[self._last_search_index]
            return None

        limit_start, limit_end = None, None
        colon_match = re.search(r":(\d+)(?:-(\d+))?$", path)
        if colon_match:
            path = path[: colon_match.start()]
            n1 = int(colon_match.group(1))
            n2 = int(colon_match.group(2)) if colon_match.group(2) else None
            limit_start, limit_end = (n1 - 1, n2) if n2 is not None else (0, n1)

        if "|" in path:
            return self._resolve_or_path(path, limit_start, limit_end)

        return self._resolve_pattern(path, limit_start, limit_end)

    def _resolve_or_path(self, path: str, limit_start, limit_end) -> str | None:
        segments = path.split("/")
        combinations = [[]]
        for seg in segments:
            if "|" in seg:
                combinations = [combo + [alt] for combo in combinations for alt in seg.split("|")]
            else:
                for combo in combinations:
                    combo.append(seg)

        all_results = []
        for combo in combinations:
            result = self._resolve_pattern("/".join(combo), None, None)
            if result and result not in all_results:
                all_results.append(result)

        if not all_results:
            return None

        self._last_search_results = all_results
        self._last_search_index = 0

        if limit_start is not None:
            sliced = all_results[limit_start:limit_end]
            self._last_search_results = sliced
            return sliced[0] if sliced else None

        return all_results[0]

    def _resolve_pattern(self, path: str, limit_start, limit_end) -> str | None:
        if "~" in path:
            results = self._resolve_tilde(path)
        else:
            parts = path.replace("\\", "/").split("/")
            results = self._expand_parts(parts, 0, "")

        results = sorted(set(results))

        if limit_start is not None:
            results = results[limit_start:limit_end]

        self._last_search_results = results
        self._last_search_index = 0

        return results[0] if results else path

    def _resolve_tilde(self, path: str) -> list:
        parts = re.split(r"(?<=/?)~(?=/?)", path)
        left = parts[0].rstrip("/")
        right = parts[-1].lstrip("/") if len(parts) > 1 else ""

        search_base = left if left else self.config.get("CWD")
        results = []

        for root, dirs, files in os.walk(search_base):
            dirs.sort()
            if right:
                candidate = os.path.join(root, right)
                if os.path.exists(candidate):
                    results.append(os.path.normpath(candidate))
            else:
                results.append(os.path.normpath(root))

        return results

    def _expand_parts(self, parts: list, index: int, current: str) -> list:
        if index >= len(parts):
            return [current] if current and os.path.exists(current) else []

        part = parts[index]

        if part == "" and index == 0:
            return self._expand_parts(parts, index + 1, "/")

        if part == "" and current == "/":
            return self._expand_parts(parts, index + 1, current)

        base = current if current else "."

        if part == ".":
            try:
                entries = sorted(e for e in os.listdir(base) if os.path.isdir(os.path.join(base, e)))
            except (PermissionError, FileNotFoundError):
                return []
            results = []
            for entry in entries:
                results.extend(self._expand_parts(parts, index + 1, os.path.join(base, entry)))
            return results

        if "*" in part:
            matches = sorted(glob.glob(os.path.join(base, part)))
            results = []
            for match in matches:
                results.extend(self._expand_parts(parts, index + 1, match))
            return results

        next_path = os.path.join(base, part) if base != "." else part
        return self._expand_parts(parts, index + 1, next_path)