import json
class ConfigLoaderError(Exception):
    pass

class ConfigLoader:
    _CONFIG_DEFAULTS = {}

    def __init__(
        self,
        class_name: str = "*",
        items: dict | None = None,
        config: str | dict | None = None,
    ):
        if items is None:
            raise ConfigLoaderError("`items` cannot be None.")
        for key, val in items.items():
            try:
                self._CONFIG_DEFAULTS[key] = [val]
                setattr(self, key, val)
            except AttributeError:
                raise ConfigLoaderError(f"item ({key}) in `items` has an invalid name")
        if config is None:
            return
        if class_name not in config.keys():
            return
        if type(config[class_name]) == str:
            try:
                config[class_name] = json.loads(config[class_name])
            except json.JSONDecodeError:
                return
        if type(config[class_name]) != dict:
            raise ConfigLoaderError("`config` is not a dict/json.")
        config = config[class_name]
        for key, val in config.items():
            setattr(self, key, val)

    def get(self, val: str):
        return getattr(self, val)

    def get_defaults(self) -> dict:
        return self._CONFIG_DEFAULTS
