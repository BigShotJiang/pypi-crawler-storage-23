from sylriekit.ConfigLoader import ConfigLoader
from sylriekit.ReLib import ReLib
from sylriekit.Helpers.JHtml import JHtmlPath as _JHtmlPath


class JHtml:
    config = None
    _config_items = {
        "data": {}
    }

    _RESERVED_KEYS = {"el type", "inner html", "content"}

    def __init__(self, config: dict | str = None):
        self.relib = ReLib(config)
        self.config = ConfigLoader("JHtml", self._config_items, config)

    def html(self, new_value: str = None):
        if new_value is not None:
            self.config.data = self._convert_html(new_value)
        return self._parse_json(self.config.get("data"))

    def json(self, new_value: dict = None):
        if new_value is not None:
            self.config.data = new_value
        return self.config.get("data")

    def json_at(self, path_str: str):
        return self._get_path(path_str)

    def html_at(self, path_str: str):
        return self._parse_json(self._get_path(path_str))

    def get_all_at_path(self, path_str: str):
        return self._get_all_paths(path_str)

    def path(self, path_str: str):
        return _JHtmlPath(path_str, self)

    def _parse_html(self, html: str):
        return self._convert_html(html)

    def _parse_json(self, json_html: list | dict):
        if isinstance(json_html, dict):
            if "html data" in json_html:
                json_html = json_html["html data"]
            else:
                json_html = [json_html]
        return self._convert_json(json_html)

    ### JSON Path functions:

    def _get_path(self, path_str: str):
        if not path_str:
            return self.config.get("data")

        is_absolute = path_str.startswith("/")

        if is_absolute:
            path_str = path_str[1:]
        else:
            path_str = "~/" + path_str

        segments = self._split_path_segments(path_str)
        current_data = self.config.get("data")

        for segment in segments:
            if current_data is None:
                return []

            current_data = self._search_segment(current_data, segment, is_absolute)

        return current_data if current_data is not None else []

    def _get_all_paths(self, path_str: str):
        if not path_str:
            return [self.config.get("data")]

        is_absolute = path_str.startswith("/")

        if is_absolute:
            path_str = path_str[1:]
        else:
            path_str = "~/" + path_str

        segments = self._split_path_segments(path_str)
        current_results = [self.config.get("data")]

        for segment in segments:
            next_results = []
            for data in current_results:
                if data is None:
                    continue
                matches = self._search_segment_all(data, segment, is_absolute)
                next_results.extend(matches)
            current_results = next_results

        return current_results

    def _search_segment_all(self, data, segment: str, is_absolute: bool = False):
        if isinstance(data, dict) and segment in data:
            return [data[segment]]

        is_deep = segment.startswith("~")
        if is_deep:
            segment = segment[1:]

        selector, _ = self._parse_selector(segment)

        children = self._get_children(data)
        if not children:
            return []

        if is_deep:
            return self._find_descendants(children, selector)
        else:
            return self._find_children(children, selector)

    def _split_path_segments(self, path_str: str):
        segments = []
        current = ""
        i = 0

        while i < len(path_str):
            char = path_str[i]

            if char == "/":
                if i + 1 < len(path_str) and path_str[i + 1] == "~":
                    current += "/~"
                    i += 2
                else:
                    if current and current != "~" and not current.endswith("/~"):
                        index_str = ""
                        i += 1
                        while i < len(path_str) and path_str[i].isdigit():
                            index_str += path_str[i]
                            i += 1

                        current += "/" + index_str

                        if i < len(path_str) and path_str[i] != "/":
                            segments.append(current)
                            current = ""
                        continue
                    elif current == "~" or current.endswith("/~"):
                        i += 1
                    else:
                        i += 1
            else:
                current += char
                i += 1

        if current:
            segments.append(current)

        return segments

    def _search_segment(self, data, segment: str, is_absolute: bool = False):
        if isinstance(data, dict) and segment in data:
            return data[segment]

        is_deep = segment.startswith("~")
        if is_deep:
            segment = segment[1:]

        selector, index = self._parse_selector(segment)

        children = self._get_children(data)
        if not children:
            return None

        if is_deep:
            matches = self._find_descendants(children, selector)
        else:
            matches = self._find_children(children, selector)

        if not matches or index >= len(matches):
            return None

        return matches[index]

    def _parse_selector(self, selector_str: str):
        index = 0
        if "/" in selector_str:
            selector_str, index_str = selector_str.rsplit("/", 1)
            if index_str:
                index = int(index_str)

        selector = {"el": "", "class": [], "id": ""}

        i = 0

        while i < len(selector_str) and selector_str[i] not in ".#":
            selector["el"] += selector_str[i]
            i += 1

        while i < len(selector_str):
            if selector_str[i] == ".":
                i += 1
                class_name = ""
                while i < len(selector_str) and selector_str[i] not in ".#":
                    class_name += selector_str[i]
                    i += 1
                if class_name:
                    selector["class"].append(class_name)

            elif selector_str[i] == "#":
                i += 1
                id_name = ""
                while i < len(selector_str) and selector_str[i] not in ".#":
                    id_name += selector_str[i]
                    i += 1
                selector["id"] = id_name

            else:
                i += 1

        return selector, index

    def _get_children(self, data):
        if isinstance(data, dict):
            children = data.get("inner html") or data.get("html data") or []
            if not isinstance(children, list):
                children = [children]
            return children
        elif isinstance(data, list):
            return data
        return None

    def _find_children(self, items: list, selector: dict):
        matches = []

        for item in items:
            if isinstance(item, dict) and self._matches(item, selector):
                matches.append(item)

        return matches

    def _find_descendants(self, items: list, selector: dict):
        matches = []

        for item in items:
            if isinstance(item, dict):
                if self._matches(item, selector):
                    matches.append(item)
                children = self._get_children(item)
                if children:
                    matches.extend(self._find_descendants(children, selector))

        return matches

    def _matches(self, item: dict, selector: dict):
        if selector["el"] and item.get("el type") != selector["el"]:
            return False

        if selector["id"] and item.get("id") != selector["id"]:
            return False

        if selector["class"]:
            item_classes = item.get("class", [])
            if isinstance(item_classes, str):
                item_classes = [item_classes]

            for required_class in selector["class"]:
                if required_class not in item_classes:
                    return False

        return True

    ### Regular expressions functions:

    def _find_elements(self, html: str):
        parts = self.relib.load(html).split_keep([r'<[^>]+>'], regex=True).get_split()
        elements = []
        for part in parts:
            stripped = part.strip()
            if not stripped:
                continue
            if stripped.startswith("<"):
                elements.append({"type": "tag", "value": stripped})
            else:
                elements.append({"type": "text", "value": stripped})
        return elements

    def _get_element_type(self, element: str):
        matches = self.relib.load(element).get_matches(r'<!?([^>\s]+)', regex=True)
        return matches[0] if matches else ""

    def _get_element_data(self, element: str):
        matches = self.relib.load(element).get_matches(r'<!?[^>\s]+(.*?)>', regex=True)
        return matches[0] if matches else ""

    def _html_extract_strings(self, html: str):
        self.relib.load(html).new_indexes().extract_strings()
        return self.relib.get_text(), self.relib.get_indexes()

    def _get_closable_elements(self, html: str):
        closable = set()
        elements = self._find_elements(html)
        for element in elements:
            if element["type"] != "tag":
                continue
            el_type = self._get_element_type(element["value"])
            if el_type.startswith("/"):
                closable.add(el_type[1:])
        return closable

    def _get_element_metadata(self, tag: str, strings_list: dict):
        el_type = self._get_element_type(tag)

        is_closing = False
        if el_type.startswith("/"):
            is_closing = True
            el_type = el_type[1:]

        attrs = {}
        el_data = self._get_element_data(tag).split(" ")
        if len(el_data) > 1:
            for data_part in el_data[1:]:
                if not data_part:
                    continue
                parts = data_part.split("=", 1)
                if len(parts) == 1:
                    attrs[parts[0]] = True
                else:
                    value = parts[1]
                    if value in strings_list:
                        value = strings_list[value][1:-1]
                    attrs[parts[0]] = value

        return {
            "el type": el_type,
            "is closing": is_closing,
            "attrs": attrs
        }

    def _convert_html(self, html: str):
        html, strings_list = self._html_extract_strings(html)
        closable = self._get_closable_elements(html)
        elements = self._find_elements(html)
        root = []
        stack = [root]

        for el in elements:
            if el["type"] == "text":
                text = el["value"]
                for key, val in strings_list.items():
                    text = text.replace(key, val[1:-1])
                stack[-1].append({"el type": "text", "content": text})
                continue

            meta = self._get_element_metadata(el["value"], strings_list)

            if meta["is closing"]:
                if len(stack) > 1:
                    stack.pop()
                continue

            node = {"el type": meta["el type"]}
            node.update(meta["attrs"])

            stack[-1].append(node)

            if meta["el type"] in closable:
                node["inner html"] = []
                stack.append(node["inner html"])

        return root

    def _convert_json(self, nodes: list, indent: int = 0):
        html = ""
        tab = "\t" * indent
        for node in nodes:
            if isinstance(node, str):
                html += f"{tab}{node}\n"
                continue

            if node["el type"] == "text":
                html += f"{tab}{node['content']}\n"
                continue

            attrs = ""
            for key, value in node.items():
                if key in self._RESERVED_KEYS:
                    continue
                if value is True:
                    attrs += f" {key}"
                else:
                    attrs += f' {key}="{value}"'

            el_type = node["el type"]

            if el_type == "DOCTYPE":
                html += f"{tab}<!DOCTYPE{attrs}>\n"
                continue

            if el_type == "--":
                html += f"{tab}<!--{attrs} -->\n"
                continue

            if "inner html" in node:
                inner = node["inner html"]
                if not inner:
                    html += f"{tab}<{el_type}{attrs}></{el_type}>\n"
                elif len(inner) == 1 and isinstance(inner[0], dict) and inner[0]["el type"] == "text":
                    html += f"{tab}<{el_type}{attrs}>{inner[0]['content']}</{el_type}>\n"
                elif len(inner) == 1 and isinstance(inner[0], str):
                    html += f"{tab}<{el_type}{attrs}>{inner[0]}</{el_type}>\n"
                else:
                    html += f"{tab}<{el_type}{attrs}>\n"
                    html += self._convert_json(inner, indent + 1)
                    html += f"{tab}</{el_type}>\n"
            else:
                html += f"{tab}<{el_type}{attrs}>\n"
        return html