## Sylriekit
A personal kitchen sink toolset I made for myself to speed up the creation of some random personal projects.

**Warning**: This is a personal project and may contain bugs or incomplete features. It is mainly coded for convenience over optimization. Use at your own risk.

---
## Tools
### Files
 - File system utilities.
### JHtml
 - Coverts HTML to JSON and back
### JHL
 - JSON HTML Language, a build-time interpreted language for JHtml, that allows for dynamic content generation.
### ReLib
 - A tool for using common regular expression patterns.
### ConfigLoader
 - A tool for loading configuration settings for all tools.
---

### Change Log:
**0.26.0**:
 - Deleted all tools and reworked the entire system to be more modular and instance-based, allowing for better organization and easier maintenance. Each tool is now an instance of a class, and they can be easily imported and used in different projects without relying on static classes.
 - Added a new tool called ConfigLoader, which is responsible for loading configuration settings for all tools.
 - Added a new tool called ReLib, which provides a collection of common regular expression patterns for easy use in various projects.
 - Removed a lot of the features of the File tool.
 - Added a new tool called JHtml and JHL which are used to convert HTML to JSON and back, as well as a build-time interpreted language for JHtml.

**0.25.9**:
 - Reworked the JHtml entirely, now it is one-way JSON to HTML and not reversible from pure HTML. It also has a built-in interpreted language (jhl) that allows build-time scripts.

**0.25.8**:
 - Updated the logging of the MCP tool.

**0.25.7**:
 - Added support so that private functions (starting with underscore) will not showup to the js bridge endpoint anymore in the Website, InlinePython, or Window tools.

**Previous change log entries are visible in the description of older versions**