#!/usr/bin/env python3
"""StockClaw Kit — 진입점

openclaw-stock-kit                → 브라우저 설정 페이지 (기본)
openclaw-stock-kit -p 9000        → 포트 지정
openclaw-stock-kit call list      → 사용 가능한 도구 목록
openclaw-stock-kit call gateway_status  → 도구 직접 호출
openclaw-stock-kit call datakit_call '{"function":"get_price","ticker":"005930"}'
openclaw-stock-kit setup          → Claude Code + OpenClaw 통합 설치
openclaw-stock-kit setup claude-code  → Claude Code 플러그인만
openclaw-stock-kit setup openclaw     → OpenClaw 스킬만
"""

import argparse
import json
import logging
import os
import sys
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(name)s | %(message)s")
logger = logging.getLogger("stock-kit")

# ─── 키 저장 디렉토리 (홈 디렉토리 하위, 프로젝트 폴더 아님) ───
CONFIG_DIR = Path(os.getenv(
    "OPENCLAW_STOCK_KIT_HOME",
    Path.home() / ".openclaw-stock-kit"
))
ENV_FILE = CONFIG_DIR / ".env"
_LEGACY_JSON = CONFIG_DIR / "api_keys.json"


def _ensure_config_dir():
    """설정 디렉토리 생성 + 권한 700"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        CONFIG_DIR.chmod(0o700)
    except OSError:
        pass  # Windows에서는 chmod 무시


def _migrate_json_to_env():
    """기존 api_keys.json → .env 마이그레이션 (1회성)"""
    if not _LEGACY_JSON.exists():
        return
    try:
        with open(_LEGACY_JSON, encoding="utf-8") as f:
            keys = json.load(f)
        if keys:
            save_keys(keys)
            logger.info(f"[Keys] api_keys.json → .env 마이그레이션 완료 ({len(keys)}개)")
        _LEGACY_JSON.unlink()
    except Exception as e:
        logger.warning(f"[Keys] JSON 마이그레이션 실패: {e}")


def load_saved_keys():
    """.env 파일에서 저장된 키를 환경변수로 로딩 (기존 환경변수 우선)"""
    _migrate_json_to_env()
    if not ENV_FILE.exists():
        return {}
    try:
        from dotenv import dotenv_values
        keys = dotenv_values(ENV_FILE)
        applied = 0
        for k, v in keys.items():
            if v and k not in os.environ:
                os.environ[k] = str(v)
                applied += 1
        if applied:
            logger.info(f"[Keys] {applied}개 키 로딩 ({ENV_FILE})")
        return dict(keys)
    except Exception as e:
        logger.warning(f"[Keys] 로딩 실패: {e}")
        return {}


def save_keys(keys: dict):
    """키를 .env 파일에 저장 (권한 600)"""
    _ensure_config_dir()
    lines = [f"{k}={v}" for k, v in keys.items() if v]
    ENV_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try:
        ENV_FILE.chmod(0o600)
    except OSError:
        pass  # Windows
    # 환경변수에 즉시 반영
    for k, v in keys.items():
        if v:
            os.environ[k] = str(v)


def _build_mcp():
    """도구 레지스트리 생성 + 모듈 로딩"""
    from openclaw_stock_kit.tool_registry import ToolRegistry

    mcp = ToolRegistry("StockClaw Kit")
    modules_status = {}

    # ── DB 연결 (optional) ──
    _pg_conn = None
    try:
        import psycopg2
        _has_pg = True
    except ImportError:
        _has_pg = False

    def _get_pg():
        nonlocal _pg_conn
        if not _has_pg:
            return None
        try:
            if _pg_conn is None or _pg_conn.closed:
                _pg_conn = psycopg2.connect(
                    host=os.getenv("PG_HOST", "localhost"),
                    port=int(os.getenv("PG_PORT", "5432")),
                    dbname=os.getenv("PG_DB", "shared_data_lake"),
                    user=os.getenv("PG_USER", "hub"),
                    password=os.getenv("PG_PASSWORD", ""),
                    connect_timeout=5,
                )
                _pg_conn.autocommit = True
            return _pg_conn
        except Exception:
            return None

    # ── 모듈 로딩 (실패 격리) ──
    def _load(name, fn, desc, extra=None):
        try:
            fn()
            info = {"ok": True, "description": desc}
            if extra:
                info.update(extra)
            modules_status[name] = info
            logger.info(f"[OK] {name}: {desc}")
        except Exception as e:
            modules_status[name] = {"ok": False, "description": desc, "error": str(e)}
            logger.warning(f"[SKIP] {name}: {e}")

    # 모듈 import 경로 설정 (패키지 내부)
    _pkg_dir = Path(__file__).parent
    sys.path.insert(0, str(_pkg_dir))

    # 1) Stock Data Kit (PyKRX, DART, ECOS, 환율, 지배구조)
    def _load_datakit():
        from pykrx_server import register_tools as reg
        reg(mcp, get_pg=_get_pg)

    _load("datakit", _load_datakit, "Stock Data Kit (PyKRX, DART, ECOS)", {
        "tools": ["datakit_call", "datakit_list_functions", "datakit_get_env_info"],
    })

    # 2) Kiwoom REST API
    def _load_kiwoom():
        from kiwoom_server import register_tools as reg
        reg(mcp, get_pg=_get_pg)

    _load("kiwoom", _load_kiwoom, "Kiwoom REST API (185 APIs)", {
        "tools": ["kiwoom_call_api", "kiwoom_list_apis", "kiwoom_get_env_info", "kiwoom_api_spec"],
    })

    # 3) KIS 한국투자증권 (네이티브, Docker 불필요)
    def _load_kis():
        from kis_server import register_tools as reg
        reg(mcp, get_pg=_get_pg)

    _load("kis", _load_kis, "KIS Trading (166 APIs, Docker-free)", {
        "tools": ["kis_domestic_stock", "kis_overseas_stock", "kis_auth", "kis_get_env_info"],
    })

    # 4) News & Telegram (Naver API + Telethon)
    def _load_news():
        from news_server import register_tools as reg
        reg(mcp, get_pg=_get_pg)

    _load("news", _load_news, "News & Telegram (Naver API, Telegram)", {
        "tools": ["news_search", "news_search_stock", "telegram_auth",
                  "telegram_get_channels", "telegram_get_messages",
                  "news_get_env_info"],
    })

    # 5) Premium (라이선스 키 있을 때만 활성)
    def _load_premium():
        from openclaw_stock_kit.premium import register_premium_tools
        tools = register_premium_tools(mcp)
        return tools

    _load("premium", _load_premium, "Premium Features (briefing, excel, backtest, course)", {
        "tools": ["premium_call", "premium_list_functions"],
    })

    # ── 피드 카탈로그 도구 ──
    @mcp.tool()
    def list_feeds() -> dict:
        """피드 카탈로그 조회 — 구독 가능한 뉴스/분석 피드 목록

        Hub에서 제공하는 텔레그램 피드 카탈로그를 반환합니다.
        무료 피드는 stock-kit 사용자도 수신 가능하며,
        유료 피드는 SimpleClaw 구독이 필요합니다.
        """
        catalog_path = Path(__file__).parent / "data" / "feeds_catalog.json"
        try:
            data = json.loads(catalog_path.read_text("utf-8"))
        except FileNotFoundError:
            return {"success": False, "error": "feeds_catalog.json not found"}
        feeds = data.get("feeds", [])
        free = [f for f in feeds if f.get("tier") == "free"]
        paid = [f for f in feeds if f.get("tier") == "paid"]
        return {
            "success": True,
            "total": len(feeds),
            "free_feeds": free,
            "paid_feeds": paid,
            "subscribe_info": "무료 피드는 텔레그램으로 수신됩니다. 유료 피드는 SimpleClaw 구독이 필요합니다.",
        }

    # ── Gateway 메타 도구 ──
    @mcp.tool()
    def gateway_status() -> dict:
        """OpenClaw Stock Kit 전체 상태 + 도구 선택 가이드

        첫 호출 시 이 도구를 사용하면 활성 모듈 확인 + 최적 도구 선택법을 안내받습니다.
        """
        active = sum(1 for m in modules_status.values() if m.get("ok"))
        total_tools = sum(
            len(m.get("tools", []))
            for m in modules_status.values()
            if m.get("ok")
        ) + 1

        # 활성 모듈 기반 라우팅 가이드 생성
        guide = {
            "how_to_choose": "아래 시나리오별 권장 도구를 참고하세요",
            "scenarios": [],
        }

        if modules_status.get("datakit", {}).get("ok"):
            guide["scenarios"].append({
                "when": "과거 주가/시세/거래량/시총/지수 조회 (무료, 키 불필요)",
                "tool": "datakit_call",
                "examples": ["get_price", "get_ohlcv", "get_market_cap", "get_index", "search_stock"],
                "note": "PyKRX 기반. 15분 지연. 과거 데이터/분석에 최적",
            })
            guide["scenarios"].append({
                "when": "DART 공시, ECOS 거시지표, 환율, 지배구조 조회",
                "tool": "datakit_call",
                "examples": ["dart_disclosures", "ecos_indicator", "exchange_rate", "governance_majority"],
                "note": "DART/ECOS/EXIM API 키 필요",
            })

        if modules_status.get("kiwoom", {}).get("ok"):
            guide["scenarios"].append({
                "when": "실시간 현재가/호가/체결/순위 + 매매 주문 (키움 계좌 필요)",
                "tool": "kiwoom_call_api",
                "examples": ["ka10001 (현재가)", "ka10004 (호가)", "kt10000 (매수주문)"],
                "note": "키움 REST API. 실시간 데이터 + 주문. 인증 필요",
            })

        if modules_status.get("kis", {}).get("ok"):
            guide["scenarios"].append({
                "when": "한국투자증권 시세/매매/분석 (KIS 계좌 필요)",
                "tool": "kis_domestic_stock / kis_overseas_stock",
                "examples": ["inquire_price (현재가)", "inquire_balance (잔고)", "order (주문)"],
                "note": "166 APIs. find_api_detail로 파라미터 확인 후 호출",
            })

        if modules_status.get("news", {}).get("ok"):
            guide["scenarios"].append({
                "when": "주식 뉴스 검색, 종목별 뉴스, 텔레그램 채널 메시지",
                "tool": "news_search / news_search_stock / telegram_get_messages",
                "examples": ["삼성전자 뉴스 7일", "텔레그램 @channel 최신 20개"],
                "note": "Naver API 키 필요. 텔레그램 공개채널은 키 없이 가능",
            })

        guide["decision_tree"] = [
            "1. 뉴스/소식 → news_search_stock 또는 telegram_get_messages",
            "2. 과거 주가/차트/시총 → datakit_call (무료, 즉시 사용)",
            "3. 실시간 현재가/호가 → kiwoom_call_api 또는 kis_domestic_stock",
            "4. 매매 주문 → kiwoom_call_api 또는 kis_domestic_stock",
            "5. 공시/거시지표 → datakit_call (DART/ECOS)",
            "6. 종목코드 모를 때 → datakit_call(function='search_stock')",
            "7. 모듈 상태 확인 → gateway_status (이 도구)",
        ]

        return {
            "success": True,
            "data": {
                "gateway": "OpenClaw Stock Kit",
                "active_modules": f"{active}/{len(modules_status)}",
                "total_tools": total_tools,
                "config_dir": str(CONFIG_DIR),
                "db_enabled": _has_pg,
            },
            "modules": modules_status,
            "tool_guide": guide,
        }

    return mcp, modules_status


def _run_serve(args):
    """설정 웹 서버 실행 (API 키 관리 페이지)"""
    # 저장된 키 로딩
    _ensure_config_dir()
    load_saved_keys()

    # 도구 레지스트리 빌드
    mcp, modules_status = _build_mcp()

    active = sum(1 for m in modules_status.values() if m.get("ok"))
    total_tools = sum(
        len(m.get("tools", []))
        for m in modules_status.values()
        if m.get("ok")
    ) + 1

    print()
    print("  ╔══════════════════════════════════════════════════╗")
    print("  ║        StockClaw Kit 설정 서버 시작됨             ║")
    print("  ╠══════════════════════════════════════════════════╣")
    print(f"  ║  모듈: {active}/{len(modules_status)}  |  도구: {total_tools}개                     ║")
    print("  ║                                                  ║")
    print(f"  ║  설정 페이지: http://localhost:{args.port}                ║")
    print("  ║                                                  ║")
    print("  ║  처음 사용하시면 위 URL을 브라우저에서 열어주세요   ║")
    print("  ╚══════════════════════════════════════════════════╝")
    print()

    import uvicorn
    from starlette.applications import Starlette
    from starlette.routing import Route
    from starlette.responses import HTMLResponse, JSONResponse

    # HTML 페이지 (패키지 내부)
    _pkg_dir = Path(__file__).parent
    _setup_path = _pkg_dir / "setup.html"
    _settings_path = _pkg_dir / "settings.html"
    _setup_html = _setup_path.read_text(encoding="utf-8") if _setup_path.exists() else "<h1>Setup page not found</h1>"
    _settings_html = _settings_path.read_text(encoding="utf-8") if _settings_path.exists() else "<h1>Settings page not found</h1>"

    def _is_setup_done() -> bool:
        """초기 설정 완료 여부: .env에 키가 1개 이상 저장되었으면 완료"""
        if not ENV_FILE.exists():
            return False
        try:
            from dotenv import dotenv_values
            keys = {k: v for k, v in dotenv_values(ENV_FILE).items() if v}
            return len(keys) > 0
        except Exception:
            return False

    async def _page_root(request):
        """/ 라우트: 초기 설정 미완료 → setup, 완료 → settings"""
        from starlette.responses import RedirectResponse
        if _is_setup_done():
            return RedirectResponse("/settings", status_code=302)
        return HTMLResponse(_setup_html)

    async def _page_setup(request):
        return HTMLResponse(_setup_html)

    async def _page_settings(request):
        return HTMLResponse(_settings_html)

    async def _api_keys(request):
        if request.method == "GET":
            saved = {}
            if ENV_FILE.exists():
                try:
                    from dotenv import dotenv_values
                    saved = dict(dotenv_values(ENV_FILE))
                except Exception:
                    pass
            return JSONResponse({"keys": saved})
        elif request.method == "POST":
            try:
                body = await request.json()
                new_keys = body.get("keys", {})
                saved = {}
                if ENV_FILE.exists():
                    try:
                        from dotenv import dotenv_values
                        saved = dict(dotenv_values(ENV_FILE))
                    except Exception:
                        pass
                saved.update(new_keys)
                saved = {k: v for k, v in saved.items() if v}
                save_keys(saved)
                return JSONResponse({"success": True})
            except Exception as e:
                return JSONResponse({"success": False, "error": str(e)}, status_code=400)

    async def _api_status(request):
        return JSONResponse({
            "active_modules": f"{active}/{len(modules_status)}",
            "total_tools": total_tools,
            "config_dir": str(CONFIG_DIR),
            "modules": modules_status,
        })

    async def _api_telegram(request):
        """Telegram auth HTTP wrapper — send_code / verify / verify_2fa / status"""
        try:
            from openclaw_stock_kit import news_server as tg
        except ImportError:
            try:
                import news_server as tg
            except ImportError:
                return JSONResponse({"success": False, "error": "news module not loaded"}, status_code=500)

        if request.method == "GET":
            action = "status"
            code = password = ""
        else:
            body = await request.json()
            action = body.get("action", "status")
            code = body.get("code", "")
            password = body.get("password", "")

        if not getattr(tg, "_HAS_TELETHON", False):
            return JSONResponse({"success": False, "status": "telethon_not_installed",
                                 "error": "pip install telethon"})

        api_id = int(os.getenv("TELEGRAM_API_ID", "0"))
        api_hash = os.getenv("TELEGRAM_API_HASH", "")
        phone = os.getenv("TELEGRAM_PHONE", "")

        if not api_id or not api_hash:
            return JSONResponse({"success": False, "status": "not_configured",
                                 "error": "TELEGRAM_API_ID/HASH not set"})

        try:
            if action == "status":
                client = await tg._ensure_tg()
                if client:
                    me = await client.get_me()
                    return JSONResponse({"success": True, "status": "connected",
                                         "user": me.first_name if me else "unknown"})
                return JSONResponse({"success": True, "status": "disconnected",
                                     "api_id_set": bool(api_id)})

            elif action == "send_code":
                if not phone:
                    return JSONResponse({"success": False, "error": "TELEGRAM_PHONE not set"})
                from telethon import TelegramClient
                session_path = str(tg._config_dir() / "telegram")
                if tg._tg_client is None:
                    tg._tg_client = TelegramClient(session_path, api_id, api_hash)
                if not tg._tg_client.is_connected():
                    await tg._tg_client.connect()
                result = await tg._tg_client.send_code_request(phone)
                tg._tg_phone_code_hash = result.phone_code_hash
                masked = phone[:4] + "****" + phone[-2:] if len(phone) > 6 else phone
                return JSONResponse({"success": True, "status": "code_sent", "phone": masked})

            elif action == "verify":
                if not code:
                    return JSONResponse({"success": False, "error": "code required"})
                if not tg._tg_client or not tg._tg_phone_code_hash:
                    return JSONResponse({"success": False, "error": "send_code first"})
                try:
                    await tg._tg_client.sign_in(phone, code,
                                                 phone_code_hash=tg._tg_phone_code_hash)
                    return JSONResponse({"success": True, "status": "connected"})
                except Exception as e:
                    err = str(e)
                    if "password" in err.lower() or "SessionPasswordNeeded" in type(e).__name__:
                        return JSONResponse({"success": True, "status": "need_2fa"})
                    return JSONResponse({"success": False, "error": err})

            elif action == "verify_2fa":
                if not password:
                    return JSONResponse({"success": False, "error": "password required"})
                if not tg._tg_client:
                    return JSONResponse({"success": False, "error": "not connected"})
                try:
                    await tg._tg_client.sign_in(password=password)
                    return JSONResponse({"success": True, "status": "connected"})
                except Exception as e:
                    return JSONResponse({"success": False, "error": str(e)})

            return JSONResponse({"success": False, "error": f"unknown action: {action}"})
        except Exception as e:
            return JSONResponse({"success": False, "error": str(e)}, status_code=500)

    async def _api_feeds(request):
        """피드 카탈로그 반환 (정적 JSON)"""
        catalog_path = _pkg_dir / "data" / "feeds_catalog.json"
        try:
            data = json.loads(catalog_path.read_text("utf-8"))
            return JSONResponse(data)
        except FileNotFoundError:
            return JSONResponse({"error": "feeds_catalog.json not found"}, status_code=404)

    app = Starlette(routes=[
        Route("/", _page_root),
        Route("/setup", _page_setup),
        Route("/settings", _page_settings),
        Route("/api/keys", _api_keys, methods=["GET", "POST"]),
        Route("/api/status", _api_status),
        Route("/api/telegram", _api_telegram, methods=["GET", "POST"]),
        Route("/api/feeds", _api_feeds),
    ])
    uvicorn.run(app, host="0.0.0.0", port=args.port)


def _run_call(args):
    """도구 직접 호출 (CLI에서 바로 실행)"""
    # call 모드: 로딩 로그를 stderr로, stdout은 순수 JSON만
    logging.basicConfig(level=logging.WARNING, format="%(name)s | %(message)s",
                        stream=sys.stderr, force=True)
    # Windows cp949 인코딩 문제 방지
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")

    _ensure_config_dir()
    load_saved_keys()
    mcp, modules_status = _build_mcp()

    tool_name = args.tool_name

    # list: 사용 가능한 도구 목록
    if tool_name == "list":
        print(json.dumps(mcp.list_tools(), ensure_ascii=False, indent=2))
        return

    # 파라미터 파싱
    params = {}
    if args.params:
        params = json.loads(args.params)

    # 도구 호출
    try:
        output = mcp.call(tool_name, params)
        print(output)
    except KeyError:
        available = [t["name"] for t in mcp.list_tools()]
        print(json.dumps({
            "error": f"Tool '{tool_name}' not found",
            "available_tools": available,
        }, ensure_ascii=False, indent=2))
        sys.exit(1)


def _run_setup(args):
    """통합 설치 실행"""
    from openclaw_stock_kit.setup import run_setup
    target = getattr(args, "target", None)
    sys.exit(run_setup(target))


def main():
    parser = argparse.ArgumentParser(
        prog="openclaw-stock-kit",
        description="Korean stock market data & trading toolkit — CLI direct call + settings server",
    )

    subparsers = parser.add_subparsers(dest="command")

    # serve (기본 — 서브커맨드 생략 시)
    serve_parser = subparsers.add_parser(
        "serve", help="Run settings web server (default)",
    )
    serve_parser.add_argument(
        "-p", "--port", type=int, default=8200,
        help="Port for settings page (default: 8200)",
    )

    # call (도구 직접 호출)
    call_parser = subparsers.add_parser(
        "call", help="Call a tool directly",
    )
    call_parser.add_argument(
        "tool_name",
        help="Tool name to call (use 'list' to see available tools)",
    )
    call_parser.add_argument(
        "params", nargs="?", default=None,
        help='JSON parameters (e.g. \'{"function":"get_price","ticker":"005930"}\')',
    )

    # setup
    setup_parser = subparsers.add_parser(
        "setup", help="Install Claude Code plugin and/or OpenClaw skill",
    )
    setup_parser.add_argument(
        "target", nargs="?", default=None,
        choices=["claude-code", "openclaw"],
        help="Install target (default: both)",
    )

    # 하위호환: 서브커맨드 없이 -p 사용 가능
    parser.add_argument(
        "-p", "--port", type=int, default=8200,
        help=argparse.SUPPRESS,
    )

    args = parser.parse_args()

    if args.command == "call":
        _run_call(args)
    elif args.command == "setup":
        _run_setup(args)
    else:
        # serve (명시적) 또는 서브커맨드 없음 (하위호환)
        _run_serve(args)


if __name__ == "__main__":
    main()
