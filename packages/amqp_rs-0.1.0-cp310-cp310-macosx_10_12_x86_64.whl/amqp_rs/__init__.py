from .amqp_rs import *

__doc__ = amqp_rs.__doc__
if hasattr(amqp_rs, "__all__"):
    __all__ = amqp_rs.__all__