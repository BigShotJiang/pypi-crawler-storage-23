# Spex Orchestration Guide

This guide provides the complete, step-by-step procedures for orchestrating feature development using the Spex state machine.

---

## State Machine Overview

| State | Description | Next State(s) | Human Checkpoint? |
|-------|-------------|---------------|-------------------|
| `INIT` | Feature request received | `RESEARCH_CODE` | No |
| `RESEARCH_CODE` | Gathering facts from code/docs | `RESEARCH_MEMORY` | No |
| `RESEARCH_MEMORY` | Grounding + conflict detection | `RESOLVING_CONFLICTS`, `GENERATE_PLAN`, `RESEARCH_CODE`, `STOP` | Conditional |
| `RESOLVING_CONFLICTS` | Human resolves conflicts | `GENERATE_PLAN`, `RESEARCH_CODE` | **Yes** |
| `GENERATE_PLAN` | Generate requirements + decisions | `REVIEWING_PLAN` | No |
| `REVIEWING_PLAN` | Human reviews and approves plan | `GENERATE_PLAN`, `COMPILING_TASKS` | **Yes** |
| `COMPILING_TASKS` | Break plan into executable tasks | `EXECUTE` | No |
| `EXECUTE` | Execute all tasks with memory-grounded implementation | `EXECUTE` (next task), `AUDITING` | No |
| `AUDITING` | Detect violations across all tasks | `COMPLETE`, `STOP` | Conditional |
| `COMPLETE` | All tasks done | - | No |
| `STOP` | Prompt for human clarification | `RESEARCH_CODE`, `GENERATE_PLAN` | **Yes** |

---

## Critical Rules

1. **Never skip states** - Follow the state machine exactly.
2. **Autonomous Execution** - Proceed automatically unless a "Human Checkpoint" is reached or blocking conflicts occur.
3. **Always Persist State** - Update `state.json` after every transition.
4. **Impact Mapping** - Every decision MUST include a detailed mapping of impacted files, data flows, and logic changes.
5. **Mandatory Audit** - All tasks MUST be audited after completion.
6. **Evidence Limit** - Max 3 iterations of RESEARCH_CODE → RESEARCH_MEMORY loop before STOP.
7. **No Assumptions** - If evidence is insufficient, move to `STOP`.

---

## 0. Scope Initialization (MANDATORY)

Before starting any feature, you MUST determine the active application scope.
1. **Load Active Apps**: `cat .spex/memory/apps.jsonl | jq -rc 'select(.status == "active")'`.
2. **Evaluate Scope**: 
   - Compare the user's request and files with the `filePath` of active apps.
   - The app whose `filePath` is a **prefix** of the working directory or modified files is the relevant scope.
   - If a change affects multiple apps, include all of them in a comma-separated list.
3. **Clarify**: If ambiguous, ask the user.
4. **Normalization**: App names are automatically normalized by replacing spaces with hyphens (e.g., `speX App` → `speX-App`).
5. **Persist**: This scope will be used in `state.json` and all subsequent memory entries. Empty scope means "global" and should be used rarely.

---

## 1. Starting a New Feature

1. **Create folder**: `mkdir -p .spex/<feature-name>`
2. **Initialize state.json**:
   ```json
   {
     "featureName": "<name>",
     "currentState": "INIT",
     "stateHistory": [{"state": "INIT", "timestamp": "<now>"}],
     "context": {
       "goal": "<goal>",
       "scope": ["<app-name>"],
       "evidenceGatheringIterations": 0
     }
   }
   ```

---

## State: RESEARCH_CODE

### Purpose
Produce a verifiable, source-cited snapshot of facts from the codebase.

### Procedure
1. **Validate Transition**: `spex validate-and-route --feature-name <name> --target-state RESEARCH_CODE`
2. **Identify Scrutinized Files**: List the core files/directories relevant to the goal.
2. **Collect EVIDENCE**: Facts with source citations (snippets) found in code/docs.
3. **Collect CONSTRAINTS**: Explicit rules found in code/docs (e.g., hardcoded limits, required props).
4. **Collect INVARIANTS**: Behaviors enforced by code (e.g., "Always uses UUIDs").
5. **Identify UNKNOWNS**: List information needed but missing from the physical codebase.

**Output**: Save/Update `.spex/<feature-name>/research.json`. Populate the `codebase` section including the `scrutinizedFiles` list.
- Format defined in: [Appendix: Research Contract](#appendix-research-contract)

---

## State: RESEARCH_MEMORY

### Purpose
Analyze history to detect contradictions or duplicates and ground the new goal in past decisions.

### Procedure
1. **Validate Transition**: `spex validate-and-route --feature-name <name> --target-state RESEARCH_MEMORY`
2. **Execute Procedure**:
   > **STOP. Read `memory-research.md` in full now and execute its steps verbatim. Do not paraphrase or summarize — follow each step exactly as written.**

**Output**: Update `.spex/<feature-name>/research.json`. Populate the `memory` section (conflicts, grounding, leverage).
- Format defined in: [Appendix: Research Contract](#appendix-research-contract)

### Decision Logic
Based on the `memory` results in `research.json`:
- **BLOCKING**: Direct contradictions with Architectural decisions or Policies? -> `RESOLVING_CONFLICTS`.
- **INSUFFICIENT**: Critical context missing and iterations < 3? -> `RESEARCH_CODE`.
- **READY**: No blocking conflicts + sufficient evidence? -> `GENERATE_PLAN`.
- **LIMIT REACHED**: Iterations >= 3? -> `STOP`.

---

## State: RESOLVING_CONFLICTS (Human Checkpoint)

### Procedure
1. **Execute Procedure**:
   > **STOP. Read `conflict-resolution.md` in full now and execute its steps verbatim. Do not paraphrase or summarize — follow each step exactly as written.**
2. **Report Side Effects**: Warn about orphaned references (e.g., Decisions referencing deprecated Requirements).

---

## State: GENERATE_PLAN

### Purpose
Generate a comprehensive, grounded proposal for a feature.

### Procedure
1. **Validate Transition**: `spex validate-and-route --feature-name <name> --target-state GENERATE_PLAN`
2. **Draft Plan**: Create `.spex/<feature-name>/plan.md` using the research findings in `research.json`.
2. **Requirement Definition (Capability-First)**:
   - Describe WHAT the user needs or the system must do.
   - **Categorization**: Use the **FR, NFR, CR, UR** types defined in the Spex Taxonomy (core skill instructions).
   - **Scope**: All requirements MUST have a scope.
3. **Decision Definition (Technical Implementation)**:
   - Describe HOW to implement technically.
   - **MANDATORY Alternatives**: State rejected options and rationale ("Negative Knowledge").
   - **Classification**: Classify as **Architectural**, **Structural**, or **Tactical** based on the Reversibility Filter in the core skill.
   - **Impact Maps**: Specify **Files**, **Data Flows**, **Logic**, and **UX** impact (All 4 REQUIRED).
4. **Linking & Traceability**:
   - Every requirement must be satisfied by at least one decision.
   - Link to relevant **Policies** and **Grounding** points from research.
5. **Implementation Plan & Constraints**: Break the changes into steps and define **Non-Goals** and **Open Questions**.
6. **Assign Official IDs**: Use temporary IDs `[FR-XXX]`, `[D-XXX]` during drafting. Official IDs are assigned by the CLI after approval.

### When to Refuse
- Required information is missing or research is incomplete.
- Cannot determine specific files/components to modify.
- Constraints are contradictory.
- Goal is too vague to create actionable decisions.

**Output**: Save to `.spex/<feature-name>/plan.md`.
- Format defined in: [Appendix: Plan Contract](#appendix-plan-contract)

---

## State: REVIEWING_PLAN (Human Checkpoint)

### Purpose
Obtain human validation of the proposed plan. **CRITICAL: Once the plan is approved, it is frozen and should not be changed.** Any necessary changes discovered during implementation must be handled via the AUDITING state.

### Procedure
1. **Validate Transition**: `spex validate-and-route --feature-name <name> --target-state REVIEWING_PLAN`
2. **Present Review**:
   - Summary of changes.
   - **High-Impact Decisions** table (Decision | Risk/Trade-off).
   - Open Questions.
2. **Await Approval**: Must get explicit "Approved" before implementation. **Once approved, the plan is frozen.**
3. **Persist Memory**:
   - `spex plan add --feature-name <name> --goal <goal>`
   - `spex requirement add --plan-id <P-ID> --type <type> --description "<desc>" --source "<source>" --acceptance-criteria "<criteria>" --scope "<scope>"`
   - `spex decision add --proposal "<proposal>" --rationale "<rationale>" --alternatives "<alternatives>" --satisfies "<req-ids>" --impact '{"files": [], "dataFlows": [], "logic": [], "ux": []}' --decision-class <class> --scope "<scope>"`
4. **Sync IDs**: Update `plan.md` with returned IDs (e.g., FR-042, D-089).

---

## State: COMPILING_TASKS

### Procedure
1. **Validate Transition**: `spex validate-and-route --feature-name <name> --target-state COMPILING_TASKS`
2. **Deconstruct**: Map approved Decisions to bounded, executable tasks.
3. **Define Implementation Steps**: Every task MUST include:
   - Failing test snippet.
   - Minimal implementation guidance.
   - `git commit` command with `decision_id` trailer.

**Output**: Save to `.spex/<feature-name>/tasks.md`.

List of tasks.
Each task must include:
- **Task ID**: Unique identifier (e.g., T-001, T-002)
- **Decision ID(s)**: Which decision(s) this task implements (REQUIRED)
- **Plan step**: Which plan step it maps to
- **Description**: Deep description of the flow change.
- **Implementation Steps**: 
  - **Step 1: Write failing test** (Include code snippet and command)
  - **Step 2: Implement minimal logic** (Include code snippet)
  - **Step 3: Verify pass** (Include command and expected output)
  - **Step 4: Commit** (Mandatory: `git commit -m "<Task Description>" --trailer "decision_id: <D-ID>"`)

---

## State: EXECUTE

### Purpose
Iterate through tasks with memory grounding. Never code "blind."

### Procedure (Per Task)
1. **Validate Transition**: `spex validate-and-route --feature-name <name> --target-state EXECUTE`
2. **Scoped Lookup**: Run `spex blame <files>` for the files being modified.
2. **Build Context**: Compile Constraints (policies), Guidance (patterns), and Gaps.
3. **TDD Implementation**: 
   - Write failing test.
   - Write minimal logic.
   - Verify pass.
4. **Decision Attribution**: Every choice must trace to memory or be recorded as a **New Tactical Decision** via `spex decision add`.
5. **Commit**: `git commit -m "<Task Description>" --trailer "decision_id: <ID>"`

---

## State: AUDITING

### Purpose
Detect drift between intent (`plan.md`) and implementation (`git diff`).

### Procedure
1. **Validate Transition**: `spex validate-and-route --feature-name <name> --target-state AUDITING`
2. **Review Commits**: Look at the task commits to get the picture of how the implementation was realized. Run: `jq -r '.context.decisionIds[]' .spex/<name>/state.json | xargs -I {} sh -c 'git --no-pager log --grep="decision_id: {}" --pretty=format:"%h %n"'` to get the commits that were done as part of the feature implementation.
3. **Compare**: Run `git diff HEAD --name-only`. Account for *every* file changed outside `.spex/`.
4. **Categorize Drift**:
   - **Type 1: Mandatory Gap**: Necessary change but missing from plan. -> Propose new requirement/decision.
   - **Type 2: Inaccuracy**: Implementation differs from plan specs. -> Explain rationale.
   - **Type 3: Unplanned**: Unrelated polish/fixes. -> Confirm intent.
5. **Memory Check**: Batch-check all drift items using the RESEARCH_MEMORY procedure once.
6. **Human Checkpoint (Approval)**: If drift is detected, present a **Human-Readable Audit Review**. Priority: **Understandability over raw data.** The report MUST include:
   - **The Discrepancy**: A clear "Plan says X, but Code does Y" comparison.
   - **Supporting Evidence**: Snippets from `git diff` or specific logic shifts that prove the drift.
   - **Rationale for Change**: Why the implementation drifted (e.g., "Discovered a nested dependency during coding").
   - **Proposed Resolution**: Explain the intended memory update (e.g., "I propose adding a new Tactical Decision to document this change") in plain English.
   - **Await Approval**: Must get explicit approval for the proposed resolutions before persisting to memory.
7. **Execution**: ONLY for approved items:
   - Generate the specific `spex` persistence commands (e.g., `decision add`, `requirement update`) required to align the memory with the implementation.
   - Execute the commands.
   - Update `state.json`
   - move to `COMPLETE`.

**Output**: Save to `.spex/<feature-name>/audit.json`. FAIL if blocking conflicts or unapproved policy drift found.
- Format defined in: [Appendix: Audit Contract](#appendix-audit-contract)

---

## State: COMPLETE

### Procedure
1. **Validate Transition**: `spex validate-and-route --feature-name <name> --target-state COMPLETE`
2. **Validation Checklist**:
   - All tasks executed + audited.
   - All audits passed.
   - All traces recorded.
2. **Close Plan**: `spex plan update-status --id <P-ID> --status complete`.
3. **Final Report**:
   - Summary of accomplishments.
   - Traceability table (Req -> Decision -> Commit).
   - Audit pass confirmation.
4. **Transition to Reflection**: Inform the user that the feature is officially complete. Mention that once they are satisfied with the final result (after their own testing and verification), they can invoke the `spex reflect` skill to capture learnings and improve the process for future features.

---

## Appendix: Data Contracts

### Appendix: Research Contract
The output of `RESEARCH_CODE` and `RESEARCH_MEMORY` is a unified JSON file saved to `.spex/<feature-name>/research.json`.

```json
{
  "featureName": "string",
  "iterations": "integer",
  "codebase": {
    "scrutinizedFiles": ["string"],
    "evidence": [
      {
        "fact": "string",
        "source": "path/to/file#L1-L10",
        "snippet": "string",
        "context": "string"
      }
    ],
    "constraints": [
      {
        "statement": "string",
        "source": "string",
        "snippet": "string"
      }
    ],
    "invariants": [
      {
        "behavior": "string",
        "tag": "FACT | INFERENCE",
        "source": "string"
      }
    ],
    "unknowns": [
      {
        "missing": "string",
        "whyNeeded": "string"
      }
    ]
  },
  "memory": {
    "conflicts": [
      {
        "severity": "blocking | warning",
        "type": "string",
        "message": "string",
        "existingId": "string",
        "reason": "string"
      }
    ],
    "grounding": [
      {
        "id": "string",
        "description": "string",
        "link": "string"
      }
    ],
    "leverage": [
      {
        "id": "string",
        "suggestion": "string"
      }
    ]
  }
}
```

### Appendix: Plan Contract
The output of `GENERATE_PLAN` is a Markdown file saved to `.spex/<feature-name>/plan.md`.

#### Structure
1. **Plan Header**: Goal, Status, Created.
2. **Requirements**: 
   - **Description**: [Clear, testable statement from user perspective]
   - **Source**: [Where requirement came from: user request, constraint, inference]
   - **Type**: FR (Functional), NFR (Non-Functional), CR (Constraint), UR (User Request).
   - **Acceptance Criteria**: must be **Test Cases**: Step-by-step verification instructions.
   - **Scope**: [Comma-separated app names, e.g., speX-Frontend] (All requirements MUST have a scope).
3. **Decisions**:
   - **Proposal**: [The technical approach or architectural choice]
   - **Rationale**: [Why this is the best way to satisfy linked requirements] 
   - **Satisfies**: [Comma-separated list of requirement IDs and Policy IDs].
   - **Grounding**: (optional) [References to historical memory items].
   - **Alternatives**: MANDATORY consideration of other options.
   - **Impact**: Files, Data Flows, Logic, UX (All 4 REQUIRED).
   - **Class**: architectural, structural, tactical (See Reversibility Filter).
   - **Scope**: [Comma-separated app names] (All decisions MUST have a scope).
4. **Implementation Plan**: Sequential steps linking to decisions.
5. **Non-Goals**: Explicitly state what is out of scope.
6. **Open Questions**: Items that block execution or require clarification.

### Appendix: Audit Contract
The output of `AUDITING` is a JSON file saved to `.spex/<feature-name>/audit.json`.

```json
{
  "auditResult": "PASS | FAIL",
  "scopeCreep": [
    {
      "category": "Mandatory Change | Implementation Not Accurate | Unplanned Functionality",
      "description": "string",
      "proposedAction": "string",
      "filePath": "string",
      "conflicts": [
        {
          "severity": "BLOCKING | WARNING",
          "conflictingId": "string",
          "description": "string"
        }
      ]
    }
  ],
  "summary": {
    "totalDrifts": "integer",
    "mandatoryChangeCount": "integer",
    "implementationDriftCount": "integer",
    "unplannedFunctionalityCount": "integer",
    "blockingConflictsCount": "integer"
  },
  "proposedResolutions": [
    {
      "summary": "string",
      "rationale": "string",
      "impact": "string",
      "suggestedMemoryUpdate": {
        "type": "requirement | decision | policy",
        "action": "add | update | deprecate",
        "params": {}
      }
    }
  ]
}
```
