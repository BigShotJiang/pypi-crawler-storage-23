# Memory Research Procedure

This procedure is used to ground development in historical context, detect contradictions/duplicates, and identify cross-cutting concerns.

## Search Principles

1.  **Literal Search**: Start with keywords from the current goal, application names, and filenames.
2.  **Semantic/Concept Search**: Move beyond literal matches. Generate search terms for **Cross-Cutting Concerns**:
    *   If UI: Search for "accessibility", "state-management", "styling-system", "design-tokens".
    *   If API: Search for "auth-protocols", "error-handling", "rate-limiting".
3.  **Lateral Thinking**: Identify **Implicit Dependencies**. "If I change X, what unrelated historical decision Y might be affected?"
4.  **Negative Space**: Search for what was explicitly *rejected* or *deprecated* in the past.

## Conflict Detection

Check for three types of conflicts:

1.  **Direct Contradiction (Blocking)**: The goal violates an active Policy or Architectural Decision.
2.  **Redundancy**: The goal or a proposed requirement already exists (>80% similarity).
3.  **Implicit Conflict**: The goal satisfies a new need but breaks an underlying invariant or non-functional requirement from the past.

## Detailed Procedure

### 1. Load Context
*   **Active Apps**: `cat .spex/memory/apps.jsonl | jq -rc 'select(.status == "active")'`
*   **Architectural Decisions**: `cat .spex/memory/decisions.jsonl | jq -rc 'select(.status == "active" and .decisionClass == "architectural")'`
*   **Policies**: `cat .spex/memory/policies.jsonl | jq -rc 'select(.status == "active")'`

### 2. Scoped Lookup
Run `spex blame <files>` for all scrutinized files. This surfaces linked Requirements and Decisions.

### 3. Broad Inquiry
Use `grep` or search concepts in `.spex/memory/` to find:
*   Historical decisions on similar features.
*   Rejected alternatives that mirror the current proposal.
*   Policies that might govern the implementation (e.g., TDD requirements).

### 4. Categorize Findings
Populate the `memory` section of `research.json` (or the `CAPTURE_CHECK` report):
*   **Conflicts**: Severity (blocking/warning), type, message, and existing ID.
*   **Grounding**: Existing items that support or define the current direction.
*   **Leverage**: Existing patterns or utilities that should be reused.
