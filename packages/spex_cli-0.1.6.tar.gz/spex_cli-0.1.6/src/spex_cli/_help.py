import json
from rich.console import Console
from rich.table import Table
from rich.text import Text

_console = Console()

_COMMANDS = [
    ("Developers", [
        ("enable",      [], "Set up spex in the current repository"),
        ("disable",     [], "Remove spex git hook and revert agent settings"),
        ("healthcheck", [], "Audit hooks and memory integrity"),
        ("ui",          [], "Launch the Spex visual memory in your browser"),
    ]),
    ("Memory", [
        ("requirement", ["add", "deprecate"],                  "Track functional and non-functional requirements"),
        ("decision",    ["add", "deprecate"],                  "Record technical decisions with rationale and impact"),
        ("policy",      ["add", "deprecate"],                  "Project-wide policies and guidelines"),
        ("app",         ["add", "update"],                     "Register applications and libraries"),
        ("plan",        ["add", "update-status", "deprecate"], "Feature planning lifecycle"),
    ]),
    ("System", [
        ("trace", ["add"],               "Link commits to decisions via git trailers"),
        ("blame", ["<file>[:<lines>]"],  "Find decisions and requirements for a file or line range"),
        ("validate-and-route", ["--feature-name", "--target-state"], "Enforce state machine transitions"),
    ]),
]

_SUBCOMMANDS = {
    "requirement": [
        ("add",       "Add a new requirement to memory"),
        ("deprecate", "Deprecate an existing requirement"),
    ],
    "decision": [
        ("add",       "Add a new technical decision"),
        ("deprecate", "Mark a decision as obsolete"),
    ],
    "policy": [
        ("add",       "Add a new project-wide policy or guideline"),
        ("deprecate", "Deprecate an existing policy"),
    ],
    "app": [
        ("add",    "Register a new application or library"),
        ("update", "Update app or library details"),
    ],
    "plan": [
        ("add",           "Create a new feature plan"),
        ("update-status", "Update the current status of a plan"),
        ("deprecate",     "Abandon a plan"),
    ],
    "trace": [
        ("add", "Link a commit hash to a decision"),
    ],
}


def print_help() -> None:
    _console.print()
    _console.print(
        "  [bold]Usage:[/bold]  [bold #F97316]spex[/bold #F97316] "
        "[dim][--version][/dim] [#FBBF24]<command>[/#FBBF24] [dim][options][/dim]"
    )
    _console.print()

    for section, commands in _COMMANDS:
        _console.rule(f"[bold #8B5CF6] {section} [/bold #8B5CF6]", style="dim #8B5CF6")
        _console.print()

        table = Table(box=None, padding=(0, 2, 0, 4), show_header=False, expand=False)
        table.add_column("cmd",     style="bold #F97316", no_wrap=True)
        table.add_column("actions", no_wrap=True)
        table.add_column("desc",    style="dim", no_wrap=False)

        for cmd, actions, desc in commands:
            action_text = Text()
            for i, action in enumerate(actions):
                if i > 0:
                    action_text.append("  ", style="dim")
                action_text.append(action, style="#FBBF24")
            table.add_row(cmd, action_text, desc)

        _console.print(table)
        _console.print()

    _console.print(
        "  [dim]Run [/dim][bold #F97316]spex[/bold #F97316]"
        " [dim]<command> --help for more information.[/dim]"
    )
    _console.print()


def print_subcommand_help(command: str) -> None:
    actions = _SUBCOMMANDS.get(command, [])
    _console.print()
    _console.rule(
        f"[bold #8B5CF6] spex {command} [/bold #8B5CF6]",
        style="dim #8B5CF6",
    )
    _console.print()

    table = Table(box=None, padding=(0, 2, 0, 4), show_header=False, expand=False)
    table.add_column("action", style="bold #FBBF24", no_wrap=True)
    table.add_column("desc",   style="dim", no_wrap=True)

    for action, desc in actions:
        table.add_row(action, desc)

    _console.print(table)
    _console.print()
    _console.print(
        f"  [dim]Run [/dim][bold #F97316]spex {command}[/bold #F97316]"
        " [dim]<action> --help for details.[/dim]"
    )
    _console.print()


def print_help_json() -> None:
    output = {
        "usage": "spex <command> [options]",
        "sections": [
            {
                "section": section,
                "commands": [
                    {"name": cmd, "actions": actions, "description": desc}
                    for cmd, actions, desc in commands
                ],
            }
            for section, commands in _COMMANDS
        ],
    }
    print(json.dumps(output, indent=2))
