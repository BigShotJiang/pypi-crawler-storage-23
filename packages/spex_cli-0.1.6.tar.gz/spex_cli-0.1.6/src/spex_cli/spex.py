#!/usr/bin/env python3
"""
spex - CLI tool for managing requirements and decisions

Handles write operations (add, deprecate) only.
Read operations should use native tools (grep, jq, cat).
Conflict detection is handled by the agent's intelligence in the historical-context-analyzer skill.
"""

import argparse
import json
import os
import subprocess
import sys
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Type, TypeVar
from dataclasses import asdict
import re

from spex_cli._help import print_help, print_help_json, print_subcommand_help, _SUBCOMMANDS
from spex_cli.enable import run_enable
from spex_cli.disable import run_disable
import importlib.metadata

try:
    __version__ = importlib.metadata.version("spex-cli")
except importlib.metadata.PackageNotFoundError:
    __version__ = "unknown"

# Import data models
from spex_cli.models import (
    Requirement, Decision, Policy, Plan, Trace, App,
    validate_requirement_type, validate_decision_class
)

# Type variable for generic operations
T = TypeVar('T')


# File paths
REQUIREMENTS_FILE = ".spex/memory/requirements.jsonl"
DECISIONS_FILE = ".spex/memory/decisions.jsonl"
POLICIES_FILE = ".spex/memory/policies.jsonl"
PLANS_FILE = ".spex/memory/plans.jsonl"
TRACES_FILE = ".spex/memory/traces.jsonl"
APPS_FILE = ".spex/memory/apps.jsonl"



class SpexError(Exception):
    """Base exception for spex errors"""
    pass


class ValidationError(SpexError):
    """Validation error"""
    pass


class ReferenceError(SpexError):
    """Reference integrity error"""
    pass


def get_git_author() -> str:
    """Get the current git author (name or email)"""
    try:
        # 1. Try to get user name directly
        result = subprocess.run(['git', 'config', 'user.name'], capture_output=True, text=True)
        name = result.stdout.strip()
        if name:
            return name
            
        # 2. Fallback to GIT_AUTHOR_IDENT which is more robust
        # Format: Name <email> timestamp timezone
        result = subprocess.run(['git', 'var', 'GIT_AUTHOR_IDENT'], capture_output=True, text=True)
        ident = result.stdout.strip()
        if ident:
            # Extract name from "Name <email> ..."
            name_match = re.match(r'^(.*?) <', ident)
            if name_match:
                name = name_match.group(1).strip()
                if name:
                    return name
            
            # Extract email if name is empty
            email_match = re.search(r'<(.*?)>', ident)
            if email_match:
                return email_match.group(1).strip()
        
        # 3. Last resort fallback to email from config
        result = subprocess.run(['git', 'config', 'user.email'], capture_output=True, text=True)
        email = result.stdout.strip()
        if email:
            return email
    except Exception:
        pass
    return "ai"


def ensure_file_exists(filepath: str) -> None:
    """Create file and parent directories if they don't exist"""
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.touch()


def read_jsonl(filepath: str, model: Type[T]) -> List[T]:
    """Read all entries from a JSONL file and parse into dataclass instances"""
    ensure_file_exists(filepath)
    entries = []
    with open(filepath, 'r') as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if line:
                try:
                    data = json.loads(line)
                    entries.append(model.from_dict(data))
                except (json.JSONDecodeError, ValueError, KeyError) as e:
                    raise ValidationError(f"Error parsing line {line_num} in {filepath}: {e}")
    return entries


def verify_jsonl(filepath: str, model: Type[T]) -> int:
    """Verify all entries in a JSONL file without loading all into memory. Returns count."""
    ensure_file_exists(filepath)
    count = 0
    with open(filepath, 'r') as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if line:
                try:
                    data = json.loads(line)
                    # This validates schema via __post_init__ without storing the object
                    model.from_dict(data)
                    count += 1
                except (json.JSONDecodeError, ValueError, KeyError) as e:
                    raise ValidationError(f"Error parsing line {line_num} in {filepath}: {e}")
    return count

def append_jsonl(filepath: str, entry: object) -> None:
    """Append a dataclass entry to a JSONL file, ensuring proper newline separation"""
    ensure_file_exists(filepath)
    path = Path(filepath)
    # Ensure file ends with newline before appending
    if path.stat().st_size > 0:
        with open(filepath, 'rb') as f:
            f.seek(-1, 2)
            if f.read(1) != b'\n':
                with open(filepath, 'a') as fa:
                    fa.write('\n')
    with open(filepath, 'a') as f:
        # Convert dataclass to dict, then to JSON
        entry_dict = asdict(entry) if hasattr(entry, '__dataclass_fields__') else entry
        f.write(json.dumps(entry_dict) + '\n')


def rewrite_jsonl(filepath: str, entries: List[object]) -> None:
    """Rewrite a JSONL file with updated dataclass entries"""
    ensure_file_exists(filepath)
    with open(filepath, 'w') as f:
        for entry in entries:
            # Convert dataclass to dict, then to JSON
            entry_dict = asdict(entry) if hasattr(entry, '__dataclass_fields__') else entry
            f.write(json.dumps(entry_dict) + '\n')


def get_latest_version(entries: List[T], entry_id: str) -> Optional[T]:
    """Get the latest version of an entry by ID"""
    matching = [e for e in entries if e.id == entry_id]
    if not matching:
        return None
    return max(matching, key=lambda e: e.version)






def get_active_entries(entries: List[T]) -> List[T]:
    """Filter to only active entries (latest version with status=active)"""
    active = []
    entry_ids = set(e.id for e in entries)
    for entry_id in entry_ids:
        latest = get_latest_version(entries, entry_id)
        if latest and latest.status == 'active':
            active.append(latest)
    return active


def run_jq(query: str, filepath: str) -> List[Dict[str, Any]]:
    """Run a jq query on a JSONL file and return parsed results"""
    if not Path(filepath).exists():
        return []
    
    try:
        # Use -c for compact output (one JSON object per line)
        result = subprocess.run(
            ['jq', '-c', query, filepath],
            capture_output=True,
            text=True,
            check=True
        )
        entries = []
        for line in result.stdout.splitlines():
            if line.strip():
                entries.append(json.loads(line))
        return entries
    except subprocess.CalledProcessError:
        # If jq fails, it might be due to empty results or syntax error
        return []
    except json.JSONDecodeError:
        return []


def get_latest_active_jq(entry_id: str, filepath: str) -> Optional[Dict[str, Any]]:
    """Use jq to find the latest active version of an entry by ID"""
    query = f'select(.id == "{entry_id}" and (.status == "active" or .status == null))'
    entries = run_jq(query, filepath)
    if not entries:
        return None
    return max(entries, key=lambda e: e.get('version', 1))





def validate_references(ref_ids: List[str], filepath: str, ref_type: str, model: Type[T]) -> None:
    """Validate that referenced IDs exist and are active"""
    if not ref_ids:
        return
    
    entries = read_jsonl(filepath, model)
    active = get_active_entries(entries)
    active_ids = set(e.id for e in active)
    
    for ref_id in ref_ids:
        if ref_id not in active_ids:
            raise ReferenceError(f"{ref_type} '{ref_id}' does not exist or is not active")


def validate_apps(app_names: List[str]) -> None:
    """Validate that scoped apps exist"""
    if not app_names:
        return
    
    apps = read_jsonl(APPS_FILE, App)
    active_apps = get_active_entries(apps)
    active_app_names = set(a.name.lower() for a in active_apps)
    
    for app_name in app_names:
        if app_name not in active_app_names:
            raise ReferenceError(f"App '{app_name}' does not exist or is not active")


def check_orphaned_references(entry_id: str, entry_type: str) -> List[str]:
    """Check if deprecating this entry will orphan any references"""
    warnings = []
    
    if entry_type == 'requirement':
        # Check if any active decisions reference this requirement
        decisions = read_jsonl(DECISIONS_FILE, Decision)
        active_decisions = get_active_entries(decisions)
        for decision in active_decisions:
            if entry_id in decision.satisfies:
                warnings.append(f"Decision {decision.id} still references {entry_id}")
        
        # Check if any active policies reference this requirement
        policies = read_jsonl(POLICIES_FILE, Policy)
        active_policies = get_active_entries(policies)
        for policy in active_policies:
            if entry_id in policy.satisfies:
                warnings.append(f"Policy {policy.id} still references {entry_id}")

    elif entry_type == 'policy':
        # Check if any active decisions reference this policy
        decisions = read_jsonl(DECISIONS_FILE, Decision)
        active_decisions = get_active_entries(decisions)
        for decision in active_decisions:
            if entry_id in decision.satisfiesPolicies:
                warnings.append(f"Decision {decision.id} still references policy {entry_id}")
    
    # Note: No need to check requirements when deprecating decisions
    # since requirements no longer have satisfiedBy field
    
    return warnings


def add_requirement(args) -> None:
    """Add a new requirement"""
    # Auto-generate ID
    req_id = get_next_requirement_id(args.type)

    # Create Requirement instance (validation happens in __post_init__)
    requirement = Requirement(
        id=req_id,
        version=1,
        status='active',
        createdAt=datetime.now().isoformat(),
        author=get_git_author(),
        planId=args.plan_id,
        type=args.type,
        description=args.description,
        source=args.source,
        acceptanceCriteria=args.acceptance_criteria,
        scope=[s.strip().replace(' ', '-').lower() for s in args.scope.split(',')] if args.scope else []
    )

    # Validate apps if scope provided
    validate_apps(requirement.scope)

    # Append to file
    append_jsonl(REQUIREMENTS_FILE, requirement)
    print(f"✓ Added requirement {req_id} (v1)")


def deprecate_requirement(args) -> None:
    """Deprecate a requirement (updates all versions)"""
    requirements = read_jsonl(REQUIREMENTS_FILE, Requirement)
    latest = get_latest_version(requirements, args.id)

    if not latest:
        raise ValidationError(f"Requirement {args.id} does not exist")

    if latest.status != 'active':
        raise ValidationError(f"Requirement {args.id} is already deprecated")

    # Check for orphaned references
    warnings = check_orphaned_references(args.id, 'requirement')

    now = datetime.now().isoformat()

    # Update all existing versions of this ID to deprecated
    for entry in requirements:
        if entry.id == args.id and entry.status == 'active':
            entry.status = 'deprecated'
            entry.deprecatedAt = now
            entry.deprecatedReason = args.reason
            if args.superseded_by:
                entry.supersededBy = args.superseded_by

    # Create new version as the canonical deprecation record
    new_version = Requirement(
        id=latest.id,
        version=latest.version + 1,
        status='deprecated',
        createdAt=latest.createdAt,
        author=latest.author,
        planId=latest.planId,
        type=latest.type,
        description=latest.description,
        source=latest.source,
        acceptanceCriteria=latest.acceptanceCriteria,
        deprecatedAt=now,
        deprecatedReason=args.reason,
        supersededBy=args.superseded_by if args.superseded_by else None
    )
    requirements.append(new_version)

    # Rewrite file with all versions updated
    rewrite_jsonl(REQUIREMENTS_FILE, requirements)
    print(f"✓ Deprecated requirement {args.id} (v{latest.version} → v{new_version.version})")

    for warning in warnings:
        print(f"⚠ Warning: {warning}", file=sys.stderr)




def add_decision(args) -> None:
    """Add a new decision"""
    # Parse satisfies
    satisfies = [s.strip() for s in args.satisfies.split(',')] if args.satisfies else []

    # Validate requirement references
    if satisfies:
        validate_references(satisfies, REQUIREMENTS_FILE, "Requirement", Requirement)

    # Validate decision class (now required)
    decision_class = args.decision_class
    validate_decision_class(decision_class)

    # Parse satisfiesPolicies
    satisfies_policies = [p.strip() for p in args.satisfies_policies.split(',')] if args.satisfies_policies else []
    if satisfies_policies:
        validate_references(satisfies_policies, POLICIES_FILE, "Policy", Policy)

    # Auto-generate ID
    dec_id = get_next_decision_id()

    # Attempt to parse impact as JSON for structured data
    impact_data = args.impact
    try:
        impact_data = json.loads(args.impact)
    except Exception:
        pass

    # Parse grounding as JSON if provided
    grounding_data = None
    if args.grounding:
        try:
            grounding_data = json.loads(args.grounding)
        except json.JSONDecodeError as e:
            raise ValidationError(f"Invalid JSON for --grounding: {e}")

    # Create Decision instance (validation happens in __post_init__)
    decision = Decision(
        id=dec_id,
        version=1,
        status='active',
        createdAt=datetime.now().isoformat(),
        author=get_git_author(),
        proposal=args.proposal,
        rationale=args.rationale,
        alternatives=args.alternatives,
        satisfies=satisfies,
        satisfiesPolicies=satisfies_policies,
        impact=impact_data,
        decisionClass=decision_class,
        grounding=grounding_data,
        scope=[s.strip().replace(' ', '-').lower() for s in args.scope.split(',')] if args.scope else []
    )

    # Validate apps if scope provided
    validate_apps(decision.scope)

    # Append to file
    append_jsonl(DECISIONS_FILE, decision)
    print(f"✓ Added {decision_class.upper()} decision {dec_id} (v1)")


def deprecate_decision(args) -> None:
    """Deprecate a decision (updates all versions)"""
    decisions = read_jsonl(DECISIONS_FILE, Decision)
    latest = get_latest_version(decisions, args.id)

    if not latest:
        raise ValidationError(f"Decision {args.id} does not exist")

    if latest.status != 'active':
        raise ValidationError(f"Decision {args.id} is already obsolete")

    # Check for orphaned references
    warnings = check_orphaned_references(args.id, 'decision')

    now = datetime.now().isoformat()

    # Update all existing versions of this ID to obsolete
    for entry in decisions:
        if entry.id == args.id and entry.status == 'active':
            entry.status = 'obsolete'
            entry.obsoleteAt = now
            entry.obsoleteReason = args.reason
            if args.superseded_by:
                entry.supersededBy = args.superseded_by

    # Create new version as the canonical obsolescence record
    new_version = Decision(
        id=latest.id,
        version=latest.version + 1,
        status='obsolete',
        createdAt=latest.createdAt,
        author=latest.author,
        proposal=latest.proposal,
        rationale=latest.rationale,
        alternatives=latest.alternatives,
        satisfies=latest.satisfies,
        satisfiesPolicies=latest.satisfiesPolicies,
        impact=latest.impact,
        decisionClass=latest.decisionClass,
        grounding=latest.grounding,
        obsoleteAt=now,
        obsoleteReason=args.reason,
        supersededBy=args.superseded_by if args.superseded_by else None
    )
    decisions.append(new_version)

    # Rewrite file with all versions updated
    rewrite_jsonl(DECISIONS_FILE, decisions)
    print(f"✓ Deprecated decision {args.id} (v{latest.version} → v{new_version.version})")

    for warning in warnings:
        print(f"⚠ Warning: {warning}", file=sys.stderr)


def get_next_requirement_id(req_type: str) -> str:
    """Generate a unique requirement ID using short UUID
    
    Format: <TYPE>-<8-char-uuid>
    Example: FR-a3f2b1c4
    
    This approach eliminates ID conflicts when working on multiple branches.
    """
    validate_requirement_type(req_type)
    return f"{req_type}-{str(uuid.uuid4())[:8]}"


def get_next_decision_id() -> str:
    """Generate a unique decision ID using short UUID
    
    Format: D-<8-char-uuid>
    Example: D-7e9d2a1f
    
    This approach eliminates ID conflicts when working on multiple branches.
    """
    return f"D-{str(uuid.uuid4())[:8]}"


def get_next_policy_id() -> str:
    """Generate a unique policy ID using short UUID
    
    Format: POL-<8-char-uuid>
    Example: POL-b4c8e2f1
    
    This approach eliminates ID conflicts when working on multiple branches.
    """
    return f"POL-{str(uuid.uuid4())[:8]}"


def add_policy(args) -> None:
    """Add a new policy"""
    # Parse satisfies
    satisfies = [s.strip() for s in args.satisfies.split(',')] if args.satisfies else []

    # Validate requirement references
    if satisfies:
        validate_references(satisfies, REQUIREMENTS_FILE, "Requirement", Requirement)

    # Auto-generate ID
    pol_id = get_next_policy_id()

    # Create Policy instance (validation happens in __post_init__)
    policy = Policy(
        id=pol_id,
        version=1,
        status='active',
        createdAt=datetime.now().isoformat(),
        author=get_git_author(),
        planId=args.plan_id,
        description=args.description,
        rationale=args.rationale,
        satisfies=satisfies,
        scope=[s.strip().replace(' ', '-').lower() for s in args.scope.split(',')] if args.scope else []
    )

    # Validate apps if scope provided
    validate_apps(policy.scope)

    # Append to file
    append_jsonl(POLICIES_FILE, policy)
    print(f"✓ Added policy {pol_id} (v1)")


def deprecate_policy(args) -> None:
    """Deprecate a policy (updates all versions)"""
    policies = read_jsonl(POLICIES_FILE, Policy)
    latest = get_latest_version(policies, args.id)

    if not latest:
        raise ValidationError(f"Policy {args.id} does not exist")

    if latest.status != 'active':
        raise ValidationError(f"Policy {args.id} is already deprecated")

    # Check for orphaned references
    warnings = check_orphaned_references(args.id, 'policy')

    now = datetime.now().isoformat()

    # Update all existing versions of this ID to deprecated
    for entry in policies:
        if entry.id == args.id and entry.status == 'active':
            entry.status = 'deprecated'
            entry.deprecatedAt = now
            entry.deprecatedReason = args.reason
            if args.superseded_by:
                entry.supersededBy = args.superseded_by

    # Create new version as the canonical deprecation record
    new_version = Policy(
        id=latest.id,
        version=latest.version + 1,
        status='deprecated',
        createdAt=latest.createdAt,
        author=latest.author,
        planId=latest.planId,
        description=latest.description,
        rationale=latest.rationale,
        satisfies=latest.satisfies,
        deprecatedAt=now,
        deprecatedReason=args.reason,
        supersededBy=args.superseded_by if args.superseded_by else None
    )
    policies.append(new_version)

    # Rewrite file with all versions updated
    rewrite_jsonl(POLICIES_FILE, policies)
    print(f"✓ Deprecated policy {args.id} (v{latest.version} → v{new_version.version})")

    for warning in warnings:
        print(f"⚠ Warning: {warning}", file=sys.stderr)


def get_next_app_id() -> str:
    """Generate a unique app ID using short UUID
    
    Format: APP-<8-char-uuid>
    Example: APP-a3f2b1c4
    
    This approach eliminates ID conflicts when working on multiple branches.
    """
    return f"APP-{str(uuid.uuid4())[:8]}"


def add_app(args) -> None:
    """Add a new app or library"""
    # Auto-generate ID
    app_id = get_next_app_id()
    
    normalized_name = args.name.replace(' ', '-').lower()
    
    # Validate uniqueness
    apps = read_jsonl(APPS_FILE, App)
    if any(app.id == app_id for app in apps):
        raise ValidationError(f"App ID collision: {app_id}")
    
    active_apps = get_active_entries(apps)
    
    # Check for name collision
    for app in active_apps:
        if app.name == normalized_name:
            raise ValidationError(f"An active app with name '{normalized_name}' already exists (ID: {app.id})")

    # Check for filepath collision
    new_abs_path = os.path.abspath(args.file_path)
    for app in active_apps:
        if app.filePath:
            existing_abs_path = os.path.abspath(app.filePath)
            if existing_abs_path == new_abs_path:
                raise ValidationError(f"An active app with filepath '{args.file_path}' already exists (ID: {app.id}, Name: {app.name})")

    # Create App instance (validation happens in __post_init__)
    app = App(
        id=app_id,
        version=1,
        status='active',
        createdAt=datetime.now().isoformat(),
        author=get_git_author(),
        name=normalized_name,
        type=args.type,
        repository=args.repository,
        appType=args.app_type if args.app_type else None,
        packageManager=args.package_manager if args.package_manager else None,
        filePath=args.file_path,
        owner=args.owner if args.owner else ""
    )

    # Append to file
    append_jsonl(APPS_FILE, app)
    print(f"✓ Added {args.type} {app_id} (v1)")


def update_app(args) -> None:
    """Update an app or library (e.g. change owner)"""
    apps = read_jsonl(APPS_FILE, App)
    latest = get_latest_version(apps, args.id)

    if not latest:
        raise ValidationError(f"App {args.id} does not exist")

    if latest.status != 'active':
        raise ValidationError(f"App {args.id} is not active")

    normalized_name = args.name.replace(' ', '-').lower() if args.name else latest.name.lower()

    # Validate name uniqueness if it changed
    if args.name:
        active_apps = get_active_entries(apps)
        for app in active_apps:
            if app.name == normalized_name and app.id != args.id:
                raise ValidationError(f"An active app with name '{normalized_name}' already exists (ID: {app.id})")



    # Create new version with updated fields
    new_version = App(
        id=latest.id,
        version=latest.version + 1,
        status=latest.status,
        createdAt=latest.createdAt,
        author=get_git_author(),
        name=normalized_name,
        type=latest.type,
        repository=latest.repository,
        appType=latest.appType,
        packageManager=latest.packageManager,
        filePath=latest.filePath,
        owner=args.owner if args.owner else latest.owner
    )
    
    # Mark old active versions as superseded
    for entry in apps:
        if entry.id == args.id and entry.status == 'active':
            entry.status = 'superseded'
            entry.supersededBy = f"v{new_version.version}"

    apps.append(new_version)

    # Rewrite file
    rewrite_jsonl(APPS_FILE, apps)
    print(f"✓ Updated app {args.id} (v{latest.version} → v{new_version.version})")


def validate_plan_status(status: str) -> None:
    """Validate plan status"""
    valid_statuses = ['draft', 'approved', 'executing', 'complete', 'abandoned']
    if status not in valid_statuses:
        raise ValidationError(f"Invalid status '{status}'. Must be one of: {', '.join(valid_statuses)}")


def get_next_plan_id() -> str:
    """Generate a unique plan ID using short UUID
    
    Format: P-<8-char-uuid>
    Example: P-a3f2b1c4
    
    This approach eliminates ID conflicts when working on multiple branches.
    """
    return f"P-{str(uuid.uuid4())[:8]}"


def add_plan(args) -> None:
    """Add a new plan"""
    # Auto-generate ID
    plan_id = get_next_plan_id()

    # Create Plan instance (validation happens in __post_init__)
    plan = Plan(
        id=plan_id,
        version=1,
        status='draft',
        createdAt=datetime.now().isoformat(),
        author=get_git_author(),
        featureName=args.feature_name,
        goal=args.goal,
        context=args.context if args.context else ''
    )

    # Append to file
    append_jsonl(PLANS_FILE, plan)
    print(f"✓ Added plan {plan_id} (v1, status=draft)")


def update_plan_status(args) -> None:
    """Update plan status"""
    validate_plan_status(args.status)
    
    plans = read_jsonl(PLANS_FILE, Plan)
    latest = get_latest_version(plans, args.id)
    
    if not latest:
        raise ValidationError(f"Plan {args.id} does not exist")
    
    if latest.status == 'abandoned':
        raise ValidationError(f"Plan {args.id} is abandoned and cannot be updated")
    
    # Create new version
    new_version = Plan(
        id=latest.id,
        version=latest.version + 1,
        status=args.status,
        createdAt=latest.createdAt,
        author=latest.author,
        featureName=latest.featureName,
        goal=latest.goal,
        context=latest.context,
        approvedAt=latest.approvedAt if latest.approvedAt else (datetime.now().isoformat() if args.status == 'approved' else None),
        completedAt=latest.completedAt if latest.completedAt else (datetime.now().isoformat() if args.status == 'complete' else None)
    )
    
    # Append to file
    append_jsonl(PLANS_FILE, new_version)
    print(f"✓ Updated plan {args.id} status: {latest.status} → {args.status} (v{latest.version} → v{new_version.version})")


def deprecate_plan(args) -> None:
    """Deprecate a plan (updates all versions)"""
    plans = read_jsonl(PLANS_FILE, Plan)
    latest = get_latest_version(plans, args.id)

    if not latest:
        raise ValidationError(f"Plan {args.id} does not exist")

    if latest.status == 'abandoned':
        raise ValidationError(f"Plan {args.id} is already abandoned")

    now = datetime.now().isoformat()

    # Update all existing versions of this ID to abandoned
    for entry in plans:
        if entry.id == args.id and entry.status != 'abandoned':
            entry.status = 'abandoned'
            entry.abandonedAt = now
            entry.abandonedReason = args.reason
            if args.superseded_by:
                entry.supersededBy = args.superseded_by

    # Create new version as the canonical abandonment record
    new_version = Plan(
        id=latest.id,
        version=latest.version + 1,
        status='abandoned',
        createdAt=latest.createdAt,
        author=latest.author,
        featureName=latest.featureName,
        goal=latest.goal,
        context=latest.context,
        approvedAt=latest.approvedAt,
        completedAt=latest.completedAt,
        abandonedAt=now,
        abandonedReason=args.reason,
        supersededBy=args.superseded_by if args.superseded_by else None
    )
    plans.append(new_version)

    # Rewrite file with all versions updated
    rewrite_jsonl(PLANS_FILE, plans)
    print(f"✓ Abandoned plan {args.id} (v{latest.version} → v{new_version.version})")


def validate_and_route(args) -> None:
    """Validate a state transition and update state.json"""
    feature_dir = Path(f".spex/{args.feature_name}")
    state_file = feature_dir / "state.json"
    
    if not state_file.exists():
        print(json.dumps({
            "valid": False,
            "nextState": "UNKNOWN",
            "error": f"Feature directory or state.json not found: {state_file}"
        }))
        sys.exit(1)
        
    try:
        with open(state_file, 'r') as f:
            state_data = json.load(f)
    except Exception as e:
        print(json.dumps({
            "valid": False,
            "nextState": "UNKNOWN",
            "error": f"Failed to read state.json: {e}"
        }))
        sys.exit(1)
        
    current_state = state_data.get("currentState", "INIT")
    target_state = args.target_state
    
    # Define valid transitions
    transitions = {
        "INIT": ["RESEARCH_CODE"],
        "RESEARCH_CODE": ["RESEARCH_MEMORY"],
        "RESEARCH_MEMORY": ["GENERATE_PLAN", "RESEARCH_CODE", "RESOLVING_CONFLICTS", "STOP"],
        "RESOLVING_CONFLICTS": ["GENERATE_PLAN", "RESEARCH_CODE"],
        "GENERATE_PLAN": ["REVIEWING_PLAN"],
        "REVIEWING_PLAN": ["COMPILING_TASKS", "GENERATE_PLAN"],
        "COMPILING_TASKS": ["EXECUTE"],
        "EXECUTE": ["AUDITING", "EXECUTE"],
        "AUDITING": ["COMPLETE", "STOP"],
        "STOP": ["RESEARCH_CODE", "GENERATE_PLAN"],
        "COMPLETE": []
    }
    
    # 1. Check if transition exists in graph
    if target_state not in transitions.get(current_state, []):
        print(json.dumps({
            "valid": False,
            "nextState": current_state,
            "error": f"Invalid transition: {current_state} -> {target_state}"
        }))
        sys.exit(1)
        
    # 2. Artifact Validation
    valid = True
    error = None
    
    if target_state == "RESEARCH_MEMORY":
        if not (feature_dir / "research.json").exists():
            valid = False
            error = "Missing research.json (required for RESEARCH_MEMORY)"
            
    elif target_state == "GENERATE_PLAN":
        res_file = feature_dir / "research.json"
        if not res_file.exists():
            valid = False
            error = "Missing research.json (required for GENERATE_PLAN)"
        else:
            try:
                with open(res_file, 'r') as f:
                    res_data = json.load(f)
                    if not res_data.get("memory"):
                        valid = False
                        error = "research.json is missing 'memory' section (requires grounded research)"
            except Exception:
                valid = False
                error = "Could not parse research.json"

                
    elif target_state == "REVIEWING_PLAN":
        if not (feature_dir / "plan.md").exists():
            valid = False
            error = "Missing plan.md (required for REVIEWING_PLAN)"
            
    elif target_state == "COMPILING_TASKS":
        # Check if plan is approved in memory
        plan_id = state_data.get("context", {}).get("planId")
        if plan_id:
            plan_data = get_latest_active_jq(plan_id, PLANS_FILE)
            if not plan_data or plan_data.get("status") != "approved":
                valid = False
                error = f"Plan {plan_id} must be 'approved' in memory before compiling tasks"
        else:
            valid = False
            error = "No planId found in state.json"
            
    elif target_state == "EXECUTE":
        if not (feature_dir / "tasks.md").exists():
            valid = False
            error = "Missing tasks.md (required for EXECUTE)"
            
    elif target_state == "COMPLETE":
        audit_file = feature_dir / "audit.json"
        if not audit_file.exists():
            valid = False
            error = "Missing audit.json (required for COMPLETE)"
        else:
            try:
                with open(audit_file, 'r') as f:
                    audit_data = json.load(f)
                    if audit_data.get("auditResult") != "PASS":
                        valid = False
                        error = "Audit must be PASS before transition to COMPLETE"
            except Exception:
                valid = False
                error = "Could not parse audit.json"


    if not valid:
        print(json.dumps({
            "valid": False,
            "nextState": current_state,
            "error": error
        }))
        sys.exit(1)
        
    # 3. Update state.json
    state_data["currentState"] = target_state
    state_data["stateHistory"].append({
        "state": target_state,
        "timestamp": datetime.now().isoformat()
    })
    state_data["metadata"]["updatedAt"] = datetime.now().isoformat()
    
    with open(state_file, 'w') as f:
        json.dump(state_data, f, indent=2)
        
    print(json.dumps({
        "valid": True,
        "nextState": target_state,
        "error": None
    }))





def find_referencing_files(file_path: str) -> List[str]:
    """Find files that reference the given file_path using grep (rg)"""
    filename = os.path.basename(file_path)
    stem = os.path.splitext(filename)[0]
    
    try:
        found_files = set()
        
        # Search for literal filename
        cmd1 = ["rg", "-l", "--fixed-strings", filename, "-g", f"!{file_path}"]
        result1 = subprocess.run(cmd1, capture_output=True, text=True)
        if result1.returncode == 0:
            found_files.update(result1.stdout.splitlines())
            
        # Search for stem with word boundaries (for extensionless imports)
        if stem and stem != filename:
            cmd2 = ["rg", "-l", "-w", stem, "-g", f"!{file_path}"]
            result2 = subprocess.run(cmd2, capture_output=True, text=True)
            if result2.returncode == 0:
                found_files.update(result2.stdout.splitlines())
        
        return [f.strip() for f in found_files if f.strip()]
    except Exception as e:
        print(f"⚠ Warning: grep fallback failed: {e}", file=sys.stderr)
        return []


def get_blame_commit(file_path: str, line: int) -> Optional[str]:
    """Get the commit hash for a specific line in a file using git blame"""
    try:
        # -L start,end (here start=end)
        # -l show long rev (Default)
        # -s suppress author name and timestamp
        cmd = ["git", "blame", "-L", f"{line},{line}", "-l", "-s", file_path]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode == 0 and result.stdout:
            # Output format: <sha> <content> or just <sha> if -s used? 
            # -s suppresses the author name and timestamp from the output.
            # Output is usually: "sha ( ... ) content" or just "sha content" depending on options.
            # With -l -s: "sha (Original Line)" but sometimes varies.
            # Only first token is reliably the SHA.
            parts = result.stdout.split()
            if parts:
                return parts[0]
    except Exception:
        pass
    return None


def parse_line_intervals(lines_str: str) -> List[tuple[int, int]]:
    """Parse line string into list of (start, end) intervals"""
    if not lines_str:
        return []
    
    intervals = []
    parts = lines_str.split(',')
    for part in parts:
        if '-' in part:
            start, end = part.split('-')
            intervals.append((int(start), int(end)))
        else:
            line = int(part)
            intervals.append((line, line))
    return intervals

def blame_targets(args) -> None:
    """Find relevant context for files and line ranges using git blame + trace lookup"""
    targets = args.targets
    results = []
    
    # 1. Phase 1: Identify all relevant commits across all targets
    # This avoids redundant work and allows surgical trace lookup
    all_commits = set()
    target_commits = {} # target_str -> set(commits)
    
    for target in targets:
        file_path = target
        target_intervals = []
        if ':' in target:
            file_path, lines_part = target.split(':', 1)
            try:
                target_intervals = parse_line_intervals(lines_part)
            except ValueError:
                raise ValidationError(f"Invalid line format in target: {target}")
        
        commits_found = set()
        if target_intervals:
            # If line numbers are provided, git blame specifically those lines
            for start, end in target_intervals:
                try:
                    cmd_simple = ["git", "blame", "-L", f"{start},{end}", "-l", "-s", file_path]
                    res_simple = subprocess.run(cmd_simple, capture_output=True, text=True)
                    if res_simple.returncode == 0:
                        for line in res_simple.stdout.splitlines():
                            parts = line.split()
                            if parts:
                                # Strip caret if it's a boundary commit
                                commit = parts[0].lstrip('^')
                                commits_found.add(commit)
                except Exception:
                    pass
        else:
            # No intervals - use git log to find recent commits touching this file
            try:
                cmd = ["git", "log", "-n", "10", "--format=%H", file_path]
                result = subprocess.run(cmd, capture_output=True, text=True)
                if result.returncode == 0:
                    for line in result.stdout.splitlines():
                        if line.strip():
                            commits_found.add(line.strip())
            except Exception:
                pass
        
        target_commits[target] = commits_found
        all_commits.update(commits_found)

    if not all_commits:
        # No history found, return empty results for each target
        print(json.dumps([{"target": t, "correlations": []} for t in targets], indent=2))
        return

    # 2. Phase 2: Surgical Trace Lookup
    # Instead of loading all traces, we filter line-by-line.
    # We still handle versioning but only for the relevant IDs.
    relevant_trace_versions = {} # id -> Trace (latest)
    if os.path.exists(TRACES_FILE):
        with open(TRACES_FILE, 'r') as f:
            for line in f:
                if not line.strip():
                    continue
                try:
                    data = json.loads(line)
                    tid = data.get('id')
                    if not tid:
                        continue
                    
                    trace = Trace.from_dict(data)
                    
                    # Check if this trace is relevant to any of our target commits
                    is_relevant = False
                    for h in trace.commitHashes:
                        if h in all_commits:
                            is_relevant = True
                            break
                        else:
                            # Prefix matching for short hashes
                            for c in all_commits:
                                if h.startswith(c) or c.startswith(h):
                                    is_relevant = True
                                    break
                        if is_relevant:
                            break
                    
                    if is_relevant:
                        if tid not in relevant_trace_versions or trace.version > relevant_trace_versions[tid].version:
                            relevant_trace_versions[tid] = trace
                except Exception:
                    continue


    # Build lookup map: commitHash -> [Trace] (active only)
    traces_by_commit = {}
    for t in relevant_trace_versions.values():
        if t.status == 'active':
            for h in t.commitHashes:
                if h not in traces_by_commit:
                    traces_by_commit[h] = []
                traces_by_commit[h].append(t)

    # 3. Phase 3: Resolve Details with Global Caching
    resolved_decisions = {}
    resolved_requirements = {}
    resolved_policies = {}

    for target in targets:
        found_commits = target_commits.get(target, set())
        matched_traces_total = []
        for commit in found_commits:
            # Check for exact matches
            if commit in traces_by_commit:
                matched_traces_total.extend(traces_by_commit[commit])
            
            # Check for prefix matches in our (now small) traces_by_commit keys
            for stored_h, traces in traces_by_commit.items():
                if stored_h != commit and (commit.startswith(stored_h) or stored_h.startswith(commit)):
                    matched_traces_total.extend(traces)

        # Deduplicate matched traces by ID
        unique_traces = {t.id: t for t in matched_traces_total}.values()
        correlations = []
        
        for trace in unique_traces:
            did = trace.decisionId
            if did not in resolved_decisions:
                resolved_decisions[did] = get_latest_active_jq(did, DECISIONS_FILE)
            
            decision = resolved_decisions.get(did)
            if not decision:
                continue
            
            # Find related requirements
            related_reqs = []
            for req_id in decision.get('satisfies', []):
                if req_id not in resolved_requirements:
                    resolved_requirements[req_id] = get_latest_active_jq(req_id, REQUIREMENTS_FILE)
                
                req = resolved_requirements.get(req_id)
                if req:
                    related_reqs.append(req)
            
            # Find related policies
            related_pols = []
            for pol_id in decision.get('satisfiesPolicies', []):
                if pol_id not in resolved_policies:
                    resolved_policies[pol_id] = get_latest_active_jq(pol_id, POLICIES_FILE)
                
                pol = resolved_policies.get(pol_id)
                if pol:
                    related_pols.append(pol)
            
            correlations.append({
                "traceId": trace.id,
                "commitHashes": trace.commitHashes,
                "source": "git-history",
                "decision": decision,
                "requirements": related_reqs,
                "policies": related_pols
            })
            
        results.append({
            "target": target,
            "correlations": correlations
        })
    
    print(json.dumps(results, indent=2))


def add_trace(args) -> None:
    """Add a trace entry mapping a commit hash to a decision"""
    
    # Use jq to find existing active traces for this decisionId efficiently
    query = f'select(.decisionId == "{args.decision_id}" and (.status == "active" or .status == null))'
    trace_dicts = run_jq(query, TRACES_FILE)
    
    existing_trace = None
    if trace_dicts:
        # Find latest version among active traces
        latest_dict = max(trace_dicts, key=lambda d: d.get('version', 1))
        existing_trace = Trace.from_dict(latest_dict)

    if existing_trace:
        # Check if hash already exists to avoid redundant work (but still update version/timestamp)
        if args.commit_hash in existing_trace.commitHashes:
             print(f"⚠ Commit {args.commit_hash} already traced to {args.decision_id}")
             return

        # Create a new version of the trace with the appended hash
        new_version = Trace(
            id=existing_trace.id,
            version=existing_trace.version + 1,
            status='active',
            createdAt=existing_trace.createdAt,
            author=args.author if args.author else get_git_author(),
            decisionId=args.decision_id,
            commitHashes=existing_trace.commitHashes + [args.commit_hash],
            timestamp=datetime.now().isoformat()
        )
        append_jsonl(TRACES_FILE, new_version)
        print(f"✓ Appended Commit {args.commit_hash} to {args.decision_id} (Trace {existing_trace.id} v{new_version.version})")
    else:
        # Create a completely new trace
        trace = Trace(
            id=f"TR-{str(uuid.uuid4())[:8]}",
            version=1,
            status='active',
            createdAt=datetime.now().isoformat(),
            author=args.author if args.author else get_git_author(),
            decisionId=args.decision_id,
            commitHashes=[args.commit_hash],
            timestamp=datetime.now().isoformat()
        )
        append_jsonl(TRACES_FILE, trace)
        print(f"✓ Traced {args.decision_id} → Commit {args.commit_hash} (Trace {trace.id} v1)")



def healthcheck(args) -> None:
    errors = []
    
    # 1. Audit Hooks
    print("Auditing Git Hooks...")
    try:
        # Check core.hooksPath
        result = subprocess.run(['git', 'config', 'core.hooksPath'], capture_output=True, text=True)
        hooks_path = result.stdout.strip()
        if hooks_path != '.spex/hooks':
            errors.append(f"Git core.hooksPath is set to '{hooks_path}' instead of '.spex/hooks'")
        else:
            print("  ✓ core.hooksPath is correctly set to .spex/hooks")
        
        # Check if hook files exist and are executable
        hooks_dir = Path('.spex/hooks')
        if not hooks_dir.is_dir():
            errors.append("Hooks directory .spex/hooks not found")
        else:
            required_hooks = ['post-commit']
            for hook in required_hooks:
                hook_file = hooks_dir / hook
                if not hook_file.exists():
                    errors.append(f"Required hook file missing: {hook_file}")
                elif not os.access(hook_file, os.X_OK):
                    errors.append(f"Hook file not executable: {hook_file}")
                else:
                    print(f"  ✓ Hook {hook} exists and is executable")
        
    except Exception as e:
        errors.append(f"Error auditing hooks: {e}")

    # 2. Audit Memory Integrity
    print("\nAuditing Memory Integrity...")
    memory_map = [
        (REQUIREMENTS_FILE, Requirement),
        (DECISIONS_FILE, Decision),
        (POLICIES_FILE, Policy),
        (PLANS_FILE, Plan),
        (TRACES_FILE, Trace),
        (APPS_FILE, App),
    ]
    
    for filepath, model in memory_map:
        if not os.path.exists(filepath):
            print(f"  - {filepath}: Not found (Empty memory is valid)")
            continue
            
        try:
            # verify_jsonl validates schema without loading all entries into memory
            count = verify_jsonl(filepath, model)
            print(f"  ✓ {filepath}: Valid ({count} entries)")
        except ValidationError as e:
            errors.append(f"Corruption in {filepath}: {e}")
        except Exception as e:
            errors.append(f"Unexpected error reading {filepath}: {e}")

    # Summary
    if errors:
        print("\n❌ Healthcheck failed with the following issues:")
        for err in errors:
            print(f"  - {err}")
        sys.exit(1)
    else:
        print("\n✅ Healthcheck passed! All systems nominal.")


def run_ui(args) -> None:
    """Launch the Spex visual memory in the browser"""
    import webbrowser
    import time
    
    # Path to the streamlit app script
    ui_dir = Path(__file__).parent / "ui"
    app_script = ui_dir / "memory.py"
    
    if not app_script.exists():
        print(f"Error: UI app script not found at {app_script}", file=sys.stderr)
        sys.exit(1)

    # Launch streamlit
    cmd = [
        sys.executable, "-m", "streamlit", "run",
        str(app_script),
        "--server.port", "5888",
        "--server.headless", "true",
        "--browser.gatherUsageStats", "false"
    ]
    
    # Ensure memory dir exists so streamlit doesn't crash on startup if no memory yet
    Path(".spex/memory").mkdir(parents=True, exist_ok=True)
    
    print("Launching Spex UI at http://localhost:5888/ ...")
    print("Press Ctrl+C to stop the server.")
    
    process = None
    try:
        # Start the process
        process = subprocess.Popen(cmd)
        
        # Give it a couple of seconds to start before opening the browser
        time.sleep(3)
        
        # Open the browser
        webbrowser.open("http://localhost:5888/")
        
        # Wait for the process to finish (usually by Ctrl+C)
        process.wait()
    except KeyboardInterrupt:
        print("\nStopping Spex UI server...")
        if process:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
        print("Done.")
    except Exception as e:
        print(f"Error launching UI: {e}", file=sys.stderr)
        if process:
            process.kill()
        sys.exit(1)


def main():
    # Rich top-level help
    _json_mode = '--json' in sys.argv
    _help_flags = {'-h', '--help'}
    if len(sys.argv) == 1 or (not _json_mode and len(sys.argv) == 2 and sys.argv[1] in _help_flags):
        print_help()
        sys.exit(0)
    if _json_mode and (len(sys.argv) == 2 or any(a in sys.argv for a in _help_flags)):
        print_help_json()
        sys.exit(0)

    # Rich subcommand help (e.g. `spex requirement --help`)
    if len(sys.argv) == 3 and sys.argv[2] in ('-h', '--help') and sys.argv[1] in _SUBCOMMANDS:
        print_subcommand_help(sys.argv[1])
        sys.exit(0)

    parser = argparse.ArgumentParser(
        description='spex - Manage requirements and decisions',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument('--version', action='version', version=f'spex {__version__}')
    
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')
    
    # Requirement commands
    req_parser = subparsers.add_parser('requirement', help='Requirement operations')
    req_subparsers = req_parser.add_subparsers(dest='action', help='Action to perform')
    
    # requirement add
    req_add = req_subparsers.add_parser('add', help='Add a new requirement to memory')
    req_add.add_argument('--plan-id', help='Plan ID (e.g., P-a3f2b1c4). Required when generating from a feature plan.')
    req_add.add_argument('--type', required=True, choices=['FR', 'NFR', 'CR', 'UR'], 
                         help='Requirement Category: FR (Functional), NFR (Non-Functional), CR (Constraint), UR (User Request)')
    req_add.add_argument('--description', required=True, help='Clear, testable statement of WHAT the system must do')
    req_add.add_argument('--source', required=True, help='Where this requirement came from (e.g., "User request", "Codebase constraint", "Ref-id: P-123")')
    req_add.add_argument('--acceptance-criteria', required=True, help='Step-by-step instructions to verify the requirement is met')
    req_add.add_argument('--scope', help='Comma-separated list of active app names (e.g., "speX-Frontend, speX-Backend")')

    # requirement deprecate
    req_dep = req_subparsers.add_parser('deprecate', help='Deprecate requirement')
    req_dep.add_argument('--id', required=True, help='Requirement ID')
    req_dep.add_argument('--reason', required=True, help='Deprecation reason')
    req_dep.add_argument('--superseded-by', help='ID of replacement requirement')
    
    # Decision commands
    dec_parser = subparsers.add_parser('decision', help='Decision operations')
    dec_subparsers = dec_parser.add_subparsers(dest='action', help='Action to perform')
    
    # decision add
    dec_add = dec_subparsers.add_parser('add', help='Add a new technical decision to memory')
    dec_add.add_argument('--proposal', required=True, help='Clear description of the technical implementation (HOW)')
    dec_add.add_argument('--rationale', required=True, help='Justification for why this approach was chosen')
    dec_add.add_argument('--alternatives', required=True, help='Negative Knowledge: What else was considered and why was it rejected?')
    dec_add.add_argument('--satisfies', required=True, help='Comma-separated requirement IDs this decision implements (e.g., "FR-123, NFR-456")')
    dec_add.add_argument('--satisfies-policies', help='Comma-separated policy IDs this decision complies with (e.g., "POL-789")')
    dec_add.add_argument('--impact', required=True, 
                         help='JSON string mapping impact: Files, Data Flows, Logic, UX. Example: \'{"files": ["auth.py"], "dataFlows": ["login -> session"], "logic": ["new hashing"], "ux": ["none"]}\'')
    dec_add.add_argument('--grounding', 
                         help='JSON object mapping memory IDs to grounding explanations. Example: \'{"P-123": "Follows established auth pattern"}\'')
    dec_add.add_argument('--decision-class', required=True, choices=['architectural', 'structural', 'tactical'],
                         help='Classification based on reversibility (Architectural: Hard to reverse, Tactical: Easy)')
    dec_add.add_argument('--scope', help='Comma-separated list of active app names (e.g., "speX-Frontend")')
    
    # decision deprecate
    dec_dep = dec_subparsers.add_parser('deprecate', help='Mark decision obsolete')
    dec_dep.add_argument('--id', required=True, help='Decision ID')
    dec_dep.add_argument('--reason', required=True, help='Reason for obsolescence')
    dec_dep.add_argument('--superseded-by', help='ID of replacement decision')

    # Policy commands
    pol_parser = subparsers.add_parser('policy', help='Policy operations')
    pol_subparsers = pol_parser.add_subparsers(dest='action', help='Action to perform')
    
    # policy add
    pol_add = pol_subparsers.add_parser('add', help='Add a new project-wide policy or guideline')
    pol_add.add_argument('--plan-id', required=True, help='Plan ID (e.g., P-a3f2b1c4) where this policy was defined')
    pol_add.add_argument('--description', required=True, help='Clear statement of the policy or best practice')
    pol_add.add_argument('--rationale', required=True, help='Why this policy is necessary for the project')
    pol_add.add_argument('--satisfies', help='Comma-separated requirement IDs this policy helps fulfill (e.g., "NFR-123")')
    pol_add.add_argument('--scope', help='Comma-separated list of active app names (e.g., "all" or "speX-Frontend")')

    # policy deprecate
    pol_dep = pol_subparsers.add_parser('deprecate', help='Deprecate policy')
    pol_dep.add_argument('--id', required=True, help='Policy ID')
    pol_dep.add_argument('--reason', required=True, help='Deprecation reason')
    pol_dep.add_argument('--superseded-by', help='ID of replacement policy')

    # App commands
    app_parser = subparsers.add_parser('app', help='App/Library operations')
    app_subparsers = app_parser.add_subparsers(dest='action', help='Action to perform')
    
    # app add
    app_add = app_subparsers.add_parser('add', help='Register a new application or library in the system')
    app_add.add_argument('--name', required=True, help='Display name of the app or library')
    app_add.add_argument('--type', required=True, choices=['application', 'library'], help='Category of the component')
    app_add.add_argument('--repository', required=True, help='Git repository URL or name')
    app_add.add_argument('--app-type', choices=['frontend', 'backend', 'cli', 'service'], 
                         help='Specialization of the application')
    app_add.add_argument('--package-manager', choices=['npm', 'pip', 'cargo', 'go', 'yarn', 'pnpm'], 
                         help='Primary package manager used')
    app_add.add_argument('--file-path', required=True, help='Relative path from git root to app root (e.g., "src/backend")')
    app_add.add_argument('--owner', help='Owner/maintainer team or person')

    # app update
    app_update = app_subparsers.add_parser('update', help='Update app/library details')
    app_update.add_argument('--id', required=True, help='App ID')
    app_update.add_argument('--name', help='New name')
    app_update.add_argument('--owner', help='New owner/maintainer')

    
    # Plan commands
    plan_parser = subparsers.add_parser('plan', help='Plan operations')
    plan_subparsers = plan_parser.add_subparsers(dest='action', help='Action to perform')
    
    # plan add
    plan_add = plan_subparsers.add_parser('add', help='Add new plan')
    plan_add.add_argument('--feature-name', required=True, help='Feature name')
    plan_add.add_argument('--goal', required=True, help='Plan goal')
    plan_add.add_argument('--context', help='Additional context')
    
    # plan update-status
    plan_status = plan_subparsers.add_parser('update-status', help='Update the current status of a feature plan')
    plan_status.add_argument('--id', required=True, help='Plan ID (e.g., P-a3f2b1c4)')
    plan_status.add_argument('--status', required=True, 
                             choices=['draft', 'approved', 'executing', 'complete', 'abandoned'],
                             help='New status: draft (writing), approved (frozen), executing (coding), complete (done), abandoned (stopped)')
    
    # plan deprecate
    plan_dep = plan_subparsers.add_parser('deprecate', help='Deprecate plan')
    plan_dep.add_argument('--id', required=True, help='Plan ID')
    plan_dep.add_argument('--reason', required=True, help='Deprecation reason')
    plan_dep.add_argument('--superseded-by', help='ID of replacement plan')

    # Trace commands
    trace_parser = subparsers.add_parser('trace', help='Decision trace operations')
    trace_subparsers = trace_parser.add_subparsers(dest='action', help='Action to perform')

    # trace add (single decision entry)
    trace_add = trace_subparsers.add_parser('add', help='Link a commit to a decision')
    trace_add.add_argument('--decision-id', required=True, help='ID of decision implemented (e.g., D-123)')
    trace_add.add_argument('--commit-hash', required=True, help='Full or short commit hash')
    trace_add.add_argument('--author', help='Git author (defaults to current git user.name)')
    

    # Blame command
    blame_parser = subparsers.add_parser('blame', help='Find relevant context for files and line ranges')
    blame_parser.add_argument('targets', nargs='+', help='One or more targets to blame. Format: "file" or "file:lines" (e.g., main.py or main.py:10-20)')

    # Validate and Route command
    route_parser = subparsers.add_parser('validate-and-route', help='Enforce state machine transitions and update state.json')
    route_parser.add_argument('--feature-name', required=True, help='Name of the feature directory in .spex/')
    route_parser.add_argument('--target-state', required=True, 
                             choices=["RESEARCH_CODE", "RESEARCH_MEMORY", "RESOLVING_CONFLICTS", "GENERATE_PLAN", "REVIEWING_PLAN", "COMPILING_TASKS", "EXECUTE", "AUDITING", "COMPLETE", "STOP"],
                             help='State to transition to')
    
    # Healthcheck command
    subparsers.add_parser('healthcheck', help='Audit hooks and memory integrity')


    # Enable / Disable commands
    subparsers.add_parser('enable', help='Set up spex in the current repository')
    subparsers.add_parser('disable', help='Remove spex git hook and revert agent settings')
    subparsers.add_parser('ui', help='Launch the Spex visual memory in the browser')

    args = parser.parse_args()
    
    if not args.command:
        print_help()
        sys.exit(1)
    
    try:
        if args.command == 'requirement':
            if args.action == 'add':
                add_requirement(args)
            elif args.action == 'deprecate':
                deprecate_requirement(args)
            else:
                print_subcommand_help('requirement')
                sys.exit(1)

        elif args.command == 'decision':
            if args.action == 'add':
                add_decision(args)
            elif args.action == 'deprecate':
                deprecate_decision(args)
            else:
                print_subcommand_help('decision')
                sys.exit(1)


        elif args.command == 'policy':
            if args.action == 'add':
                add_policy(args)
            elif args.action == 'deprecate':
                deprecate_policy(args)
            else:
                print_subcommand_help('policy')
                sys.exit(1)

        elif args.command == 'app':
            if args.action == 'add':
                add_app(args)
            elif args.action == 'update':
                update_app(args)
            else:
                print_subcommand_help('app')
                sys.exit(1)

        elif args.command == 'plan':
            if args.action == 'add':
                add_plan(args)
            elif args.action == 'update-status':
                update_plan_status(args)
            elif args.action == 'deprecate':
                deprecate_plan(args)
            else:
                print_subcommand_help('plan')
                sys.exit(1)

        elif args.command == 'trace':
            if args.action == 'add':
                add_trace(args)
            elif args.action == 'add-report':
                print("Error: add-report is deprecated. Traces are now added automatically via git commit hooks.", file=sys.stderr)
                sys.exit(1)
            else:
                print_subcommand_help('trace')
                sys.exit(1)

        elif args.command == 'blame':
            blame_targets(args)

        elif args.command == 'validate-and-route':
            validate_and_route(args)

        elif args.command == 'healthcheck':
            healthcheck(args)

        elif args.command == 'enable':
            run_enable()

        elif args.command == 'disable':
            run_disable()

        elif args.command == 'ui':
            run_ui(args)

    except ValidationError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except ReferenceError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(3)
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        sys.exit(2)


if __name__ == '__main__':
    main()
