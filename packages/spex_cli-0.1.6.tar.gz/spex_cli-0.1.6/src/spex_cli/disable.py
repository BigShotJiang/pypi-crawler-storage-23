"""Disable command — removes spex git hook and reverts agent settings."""

import json
import subprocess
import sys
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm
from rich.text import Text

from spex_cli.agents import AGENT_CONFIG
from spex_cli.enable import _agent_settings_src, _select_agent

console = Console()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _deep_remove(base: dict, to_remove: dict) -> dict:
    """Return base with all entries present in to_remove subtracted."""
    result = dict(base)
    for key, value in to_remove.items():
        if key not in result:
            continue
        if isinstance(result[key], dict) and isinstance(value, dict):
            cleaned = _deep_remove(result[key], value)
            if cleaned:
                result[key] = cleaned
            else:
                del result[key]
        elif isinstance(result[key], list) and isinstance(value, list):
            spex_set = {json.dumps(item, sort_keys=True) for item in value}
            result[key] = [
                item for item in result[key]
                if json.dumps(item, sort_keys=True) not in spex_set
            ]
            if not result[key]:
                del result[key]
        else:
            if result[key] == value:
                del result[key]
    return result


def _revert_agent_settings(repo_root: Path, agent_key: str) -> bool:
    """Remove spex entries from the agent's settings.local.json. Returns True if file was updated."""
    src = _agent_settings_src(agent_key)
    if src is None:
        return False

    dst = repo_root / AGENT_CONFIG[agent_key]["folder"] / "settings.local.json"
    if not dst.exists():
        return False

    with open(dst) as f:
        existing = json.load(f)
    with open(src) as f:
        spex_settings = json.load(f)

    cleaned = _deep_remove(existing, spex_settings)

    with open(dst, "w") as f:
        json.dump(cleaned, f, indent=2)
        f.write("\n")

    return True


def _remove_git_hook(repo_root: Path) -> bool:
    """Unset core.hooksPath if it points to .spex/hooks. Returns True if unset."""
    result = subprocess.run(
        ["git", "config", "core.hooksPath"],
        capture_output=True,
        text=True,
        cwd=str(repo_root),
    )
    if result.returncode != 0 or result.stdout.strip() != ".spex/hooks":
        return False

    subprocess.run(
        ["git", "config", "--unset", "core.hooksPath"],
        check=True,
        cwd=str(repo_root),
    )
    return True


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_disable() -> None:
    try:
        repo_root = Path(
            subprocess.check_output(
                ["git", "rev-parse", "--show-toplevel"],
                text=True,
                stderr=subprocess.DEVNULL,
            ).strip()
        )
    except subprocess.CalledProcessError:
        console.print(
            Panel(
                "[red]Not inside a git repository.[/red]\n"
                "Run [bold]spex disable[/bold] from within a git-tracked project.",
                border_style="red",
                title="Error",
            )
        )
        sys.exit(1)

    console.print(
        Panel(
            Text.assemble(
                ("Disabling Spex for this repository\n", "bold white"),
                (str(repo_root), "dim"),
            ),
            border_style="#EC4899",
            padding=(0, 2),
        )
    )

    # ── Interactive prompts (collected up front) ────────────────────────────
    console.print()
    console.print("[bold #FBBF24]Step 1[/bold #FBBF24]  Select your AI agent")
    agent_key = _select_agent()
    agent_name = AGENT_CONFIG[agent_key]["name"]

    console.print()
    confirmed = Confirm.ask(
        f"  Remove spex git hook and revert [bold]{agent_name}[/bold] settings?",
        default=False,
    )
    if not confirmed:
        console.print("\n  [dim]Aborted.[/dim]")
        sys.exit(0)

    # ── Execution ────────────────────────────────────────────────────────────
    console.print()
    console.print("[bold #FBBF24]Step 2[/bold #FBBF24]  Removing git hook")
    if _remove_git_hook(repo_root):
        console.print("  [green]✓[/green] [bold]core.hooksPath[/bold] unset")
    else:
        console.print("  [dim]–[/dim] core.hooksPath was not pointing to .spex/hooks, skipped")

    agent_settings_src = _agent_settings_src(agent_key)
    if agent_settings_src is not None:
        console.print()
        console.print("[bold #FBBF24]Step 3[/bold #FBBF24]  Reverting agent settings")
        agent_folder = AGENT_CONFIG[agent_key]["folder"]
        if _revert_agent_settings(repo_root, agent_key):
            console.print(f"  [green]✓[/green] Spex entries removed from [bold]{agent_folder}settings.local.json[/bold]")
        else:
            console.print(f"  [dim]–[/dim] {agent_folder}settings.local.json not found or nothing to revert")

    # ── Done ────────────────────────────────────────────────────────────────
    console.print()
    console.print(
        Panel(
            Text.assemble(
                ("Spex disabled.\n\n", "bold #EC4899"),
                ("Your memory (", "white"),
                (".spex/memory/", "bold"),
                (") has not been touched.", "white"),
            ),
            border_style="#EC4899",
            padding=(1, 2),
        )
    )
