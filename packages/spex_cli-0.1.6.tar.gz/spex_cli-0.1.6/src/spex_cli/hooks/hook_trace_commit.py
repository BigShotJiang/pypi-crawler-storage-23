#!/usr/bin/env python3
import subprocess
import sys

def get_decision_ids(key) -> list[str]:
    try:
        # Use git log to get the trailer from the last commit
        cmd = rf"git log -1 --pretty=format:%B | grep -oE '{key}:\s*D-[a-f0-9]+' | sed 's/{key}:\s*//' | sort -u"
        output = subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.DEVNULL).strip()
        if not output:
            return []
        return [line.strip() for line in output.split("\n") if line.strip()]
    except subprocess.CalledProcessError:
        return []

def get_commit_hash():
    try:
        cmd = ["git", "rev-parse", "HEAD"]
        output = subprocess.check_output(cmd, text=True, stderr=subprocess.DEVNULL).strip()
        return output
    except subprocess.CalledProcessError:
        return None

def main():
    # 1. Check for decision_id trailer
    decision_ids = get_decision_ids("decision_id")
    if not decision_ids:
        return

    # 2. Get commit hash
    commit_hash = get_commit_hash()
    if not commit_hash:
        print("[Spex] Could not retrieve commit hash.", file=sys.stderr)
        return

    print(f"[Spex] Found decision_ids: {decision_ids}. Linking to commit: {commit_hash}...")

    # 3. Call spex trace add
    failures = 0
    for decision_id in decision_ids:
        cmd = [
            "spex",
            "trace", "add",
            "--decision-id", decision_id,
            "--commit-hash", commit_hash
        ]
    
        try:
            subprocess.run(cmd, check=True)
        except subprocess.CalledProcessError as e:
            print(f"[Spex] Failed to add trace: {e}", file=sys.stderr)
            failures += 1

    if failures > 0:
        sys.exit(1)

if __name__ == "__main__":
    main()
