import json
import pytest
import sys
from subprocess import run

from spex_cli.spex import parse_line_intervals

@pytest.fixture
def temp_spex_env(tmp_path):
    """Setup a temporary .spex directory structure"""
    spex_dir = tmp_path / ".spex"
    memory_dir = spex_dir / "memory"
    memory_dir.mkdir(parents=True)
    
    # Create empty memory files
    (memory_dir / "requirements.jsonl").touch()
    (memory_dir / "decisions.jsonl").touch()
    (memory_dir / "policies.jsonl").touch()
    (memory_dir / "traces.jsonl").touch()
    (memory_dir / "apps.jsonl").touch()
    (memory_dir / "plans.jsonl").touch()
    
    # Initialize git repo for blame tests
    run(["git", "init"], cwd=tmp_path, capture_output=True)
    run(["git", "config", "user.email", "test@example.com"], cwd=tmp_path)
    run(["git", "config", "user.name", "test"], cwd=tmp_path)
    
    return tmp_path

def run_spex(cwd, args):
    """Run spex CLI with args"""
    res = run(["spex"] + args, cwd=cwd, capture_output=True, text=True)
    if res.stderr:
        print(f"SPEX STDERR: {res.stderr}", file=sys.stderr)
    return res

# --- Unit Tests ---

def test_parse_line_intervals():
    assert parse_line_intervals("10") == [(10, 10)]
    assert parse_line_intervals("10-20") == [(10, 20)]
    assert parse_line_intervals("1,5-10,15") == [(1, 1), (5, 10), (15, 15)]
    assert parse_line_intervals("") == []
    
    with pytest.raises(ValueError):
        parse_line_intervals("abc")



# --- Integration Tests ---

def test_blame_basic(temp_spex_env):
    memory_dir = temp_spex_env / ".spex/memory"
    
    # 1. Add Requirement
    req_data = {
        "id": "FR-1", "version": 1, "status": "active", 
        "createdAt": "2026-01-01", "author": "test",
        "type": "FR", "description": "Req 1"
    }
    with open(memory_dir / "requirements.jsonl", "w") as f:
        f.write(json.dumps(req_data) + "\n")
        
    # 2. Add Decision
    dec_data = {
        "id": "D1", "version": 1, "status": "active",
        "createdAt": "2026-01-01", "author": "test",
        "proposal": "Do thing", "decisionClass": "tactical",
        "satisfies": ["FR-1"]
    }
    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps(dec_data) + "\n")
        
    # 3. Create a file and commit it to get a real hash
    app_file = temp_spex_env / "app.py"
    with open(app_file, "w") as f:
        f.write("print('hello')\n")
    
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", "Initial commit"], cwd=temp_spex_env)
    
    commit_hash = run(["git", "rev-parse", "HEAD"], cwd=temp_spex_env, capture_output=True, text=True).stdout.strip()

    # 4. Add Trace
    trace_data = {
        "id": "TR-1", "version": 1, "status": "active",
        "decisionId": "D1", "commitHashes": [commit_hash]
    }
    with open(memory_dir / "traces.jsonl", "w") as f:
        f.write(json.dumps(trace_data) + "\n")
        
    # 5. Run blame
    res = run_spex(temp_spex_env, ["blame", "app.py:1"])
    assert res.returncode == 0
    
    output = json.loads(res.stdout)
    assert len(output) == 1
    assert output[0]["target"] == "app.py:1"
    assert len(output[0]["correlations"]) == 1
    corr = output[0]["correlations"][0]
    assert corr["decision"]["id"] == "D1"
    assert corr["requirements"][0]["id"] == "FR-1"

def test_blame_no_match(temp_spex_env):
    # Create a file and commit it
    app_file = temp_spex_env / "app.py"
    with open(app_file, "w") as f:
        f.write("print('no match')\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", "No trace commit"], cwd=temp_spex_env)
    
    # Run blame - should have no correlations because no trace exists for this commit
    res = run_spex(temp_spex_env, ["blame", "app.py:1"])
    output = json.loads(res.stdout)
    assert len(output[0]["correlations"]) == 0

def test_blame_multiple_targets(temp_spex_env):
    memory_dir = temp_spex_env / ".spex/memory"
    
    # Create file A and commit
    with open(temp_spex_env / "a.py", "w") as f:
        f.write("a\n")

    run(["git", "add", "a.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", "A"], cwd=temp_spex_env)
    hash_a = run(["git", "rev-parse", "HEAD"], cwd=temp_spex_env, capture_output=True, text=True).stdout.strip()
    
    # Create file B and commit
    with open(temp_spex_env / "b.py", "w") as f:
        f.write("b\n")

    run(["git", "add", "b.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", "B"], cwd=temp_spex_env)
    hash_b = run(["git", "rev-parse", "HEAD"], cwd=temp_spex_env, capture_output=True, text=True).stdout.strip()

    with open(memory_dir / "traces.jsonl", "w") as f:
        f.write(json.dumps({"id": "TR-1", "version": 1, "status": "active", "decisionId": "D1", "commitHashes": [hash_a]}) + "\n")
        f.write(json.dumps({"id": "TR-2", "version": 1, "status": "active", "decisionId": "D2", "commitHashes": [hash_b]}) + "\n")
    
    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({"id": "D1", "version": 1, "status": "active", "decisionClass": "tactical"}) + "\n")
        f.write(json.dumps({"id": "D2", "version": 1, "status": "active", "decisionClass": "tactical"}) + "\n")

    res = run_spex(temp_spex_env, ["blame", "a.py", "b.py"])
    output = json.loads(res.stdout)
    assert len(output) == 2
    assert output[0]["target"] == "a.py"
    assert output[1]["target"] == "b.py"
    assert len(output[0]["correlations"]) == 1
    assert len(output[1]["correlations"]) == 1
    assert output[0]["correlations"][0]["decision"]["id"] == "D1"
    assert output[1]["correlations"][0]["decision"]["id"] == "D2"
