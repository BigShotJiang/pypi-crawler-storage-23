"""
Support for main program, argv, etc.
"""

from __future__ import annotations

import ast
import importlib
import logging
import logging.config
import pathlib
import sys
from contextlib import suppress
from contextvars import ContextVar
from functools import partial, wraps
from types import NoneType

import asyncclick as click
import simpleeval

from moat.util import NotGiven, attrdict, ungroup
from moat.lib.config import CFG, CfgStore, current_cfg
from moat.lib.micro import ModuleNotFoundError  # noqa:A004
from moat.lib.path import P, Path

from collections import defaultdict
from collections.abc import Iterable, Mapping
from typing import TYPE_CHECKING, Any, cast

try:
    from moat.lib.proxy import Proxy as _Proxy
except ImportError:
    _Proxy = cast(Any, None)

if TYPE_CHECKING:
    from pkgutil import ModuleInfo

    from collections.abc import Awaitable, Callable, Iterator, Sequence
    from typing import Literal

Proxy: type[Any] | None = _Proxy

logger = logging.getLogger("_loader")

__all__ = [
    "AliasedGroup",
    "Loader",
    "attr_args",
    "list_ext",
    "load_ext",
    "load_subgroup",
    "main_",
    "option_ng",
    "process_args",
    "wrap_main",
]

this_load: ContextVar[str | None] = ContextVar("this_load", default=None)


class AliasedGroup(click.Group):
    """Click command group supporting unambiguous command prefixes."""

    def get_command(self, ctx, cmd_name):
        """Resolve a command, allowing unique prefixes."""
        rv = super().get_command(ctx, cmd_name)

        if rv is not None:
            return rv

        matches = [x for x in self.list_commands(ctx) if x.startswith(cmd_name)]

        if not matches:
            return None

        if len(matches) == 1:
            return super().get_command(ctx, matches[0])

        ctx.fail(f"Too many matches: {', '.join(sorted(matches))}")

    async def resolve_command(self, ctx, args):
        """Return the full command name after resolving aliases."""
        # always return the full command name
        name, cmd, args = await super().resolve_command(ctx, args)
        if name is None or cmd is None:
            ctx.fail("No such command.")
        return name, cmd, args


# cmd_eval is a simple and safe "eval" replacement.
_eval = simpleeval.SimpleEval(functions=dict(P=P, Path=Path))
if _eval.nodes is not None:
    _eval.nodes[ast.Tuple] = lambda node: tuple(  # pyright: ignore[reportOptionalSubscript]
        _eval._eval(x) for x in node.elts
    )
    _eval.nodes[ast.List] = lambda node: list(  # pyright: ignore[reportOptionalSubscript]
        _eval._eval(x) for x in node.elts
    )
    _eval.nodes[ast.Dict] = lambda node: attrdict(  # pyright: ignore[reportOptionalSubscript]
        (_eval._eval(x), _eval._eval(y)) for x, y in zip(node.keys, node.values, strict=False)
    )
cmd_eval = _eval.eval


def _no_config(*_a: Any, **_k: Any) -> None:
    import warnings  # noqa: PLC0415

    warnings.warn("Call to logging config ignored", stacklevel=2)


def attr_args(
    proc: Callable[..., Any] | None = None,
    with_combined: bool | str = "s",
    with_arglist: bool = False,
    with_path: bool = True,
    with_eval: bool = True,
    with_var: bool = True,
    with_proxy: bool = False,
    par_name: str = "Parameter",
) -> Callable[..., Any]:
    """
    Add an option for setting possibly-hierarchical values to :func:`asyncclick.command`.

    ``-s``/``--set`` accepts these prefix-tagged values:
    * ~str
    * =value (``=-``/``=t``/``=f``/``=n`` for ``undefined``/`True`/`False`/`None`)
    * .path (the leading dot is stripped)
    * :path (the colon is not stripped)
    * ^named_proxy

    Args:
        with_combined: display ``-s`` / ``--set`` help text.
        with_var: display ``-v`` / ``--var`` help text.
        with_eval: display ``-e`` / ``--eval`` help text.
        with_path: display ``-p`` / ``--path`` help text.
        with_proxy: display ``-P`` / ``--proxy`` help text.
        with_arglist: the command accepts non-option arguments.
        par_name: overrides the parameter name.

    Options are enabled (rather, displayed in the help text) by
    passing ``True`` in the corresponding argument.

    Legacy behavior (hidden unless ``with_combined`` is `False`): Adds separate
    ``-v``/``--var``, ``-e``/``--eval``, -p``/``--path, and
    ``-P``/``--proxy`` arguments.

    Use ``with_combined=False`` to get legacy behavior.
    Use ``with_combined=LETTER`` to change the default from ``-s``.

    If ``with_combined`` is not `False`, short options for hidden legacy
    flags are not availabile; the long options are available but hidden.

    Options access a hierarchical mapping. Positional arguments are
    accessible by the ``:n`` (`None`) key. Lists are appended to if the
    position is `None`.

    All arguments are of the form ``-X path value``. A path consisting of a
    single ``+`` expands to ``:n:n`` for easy appending to argument lists.
    Use ``:=`` if you ever need a path that consist of a single plus character.
    """

    def _proc(proc: Callable[..., Any]) -> Callable[..., Any]:
        if with_combined:
            ht = []
            if with_var:
                ht.append("~str")
            if with_eval:
                ht.append("=expr")
            if with_path:
                ht.append(".path, :path")
            if with_proxy:
                ht.append("^proxy")
            ht = " | ".join(ht)

            args = ("--set",) + (
                ("-" + ("s" if isinstance(with_combined, bool) else with_combined),)
                if with_combined
                else ()
            )
            proc = click.option(
                *args,
                "set_",
                nargs=2,
                type=(str, str),
                multiple=True,
                metavar="name|path value",
                help=f"{par_name} (value: {ht})",
                hidden=not with_eval or not with_combined,
            )(proc)

        if with_arglist:
            proc = click.argument(
                "args_",
                nargs=-1,
                type=str,
            )(proc)

        args = (f"--{with_path}" if isinstance(with_path, str) else "--path",) + (
            ("-p",) if with_path else ()
        )
        proc = click.option(
            *args,
            "path_",
            nargs=2,
            type=(P, P),
            multiple=True,
            help=f"{par_name} (name value), as path",
            hidden=not with_path or with_combined,
        )(proc)

        args = (f"--{with_eval}" if isinstance(with_eval, str) else "--eval",) + (
            ("-e",) if with_eval is True else ()
        )
        proc = click.option(
            *args,
            "eval_",
            nargs=2,
            type=(P, str),
            multiple=True,
            help=f"{par_name} (name value), evaluated",
            hidden=not with_eval or with_combined,
        )(proc)

        args = (f"--{with_var}" if isinstance(with_var, str) else "--var",) + (
            ("-v",) if with_var is True else ()
        )
        proc = click.option(
            *args,
            "vars_",
            nargs=2,
            type=(P, str),
            multiple=True,
            help=f"{par_name} (name value)",
            hidden=not with_var or with_combined,
        )(proc)

        args = (f"--{with_proxy}" if isinstance(with_proxy, str) else "--proxy",) + (
            ("-P",) if with_proxy is True else ()
        )
        proc = click.option(
            *args,
            "proxy_",
            nargs=2,
            type=(P, str),
            multiple=True,
            help="Remote proxy (name value)",
            hidden=not with_proxy or with_combined,
        )(proc)

        return proc

    if proc is None:
        return _proc
    else:
        return _proc(proc)


def process_args(
    val: dict[str | None, Any] | None = None,
    set_: Mapping[Any, Any] | Iterable[tuple[Any, Any]] = (),
    args_: Sequence[str] = (),
    vars_: Mapping[Any, Any] | Iterable[tuple[Any, Any]] = (),
    eval_: Mapping[Any, Any] | Iterable[tuple[Any, Any]] = (),
    path_: Mapping[Any, Any] | Iterable[tuple[Any, Any]] = (),
    proxy_: Mapping[Any, Any] | Iterable[tuple[Any, Any]] = (),
    no_path: bool = False,
    vs: set[str] | None = None,
) -> Any:
    """
    process ``set_``/``args_``/``vars_``/``eval_``/``path_``/``proxy_`` args.

    Arguments:
        val: dict to modify
        set_, vars_, args_, eval_, path_, proxy_: via `attr_args`
        vs: if given: set of vars
    Returns:
        the new value.
    """
    # otherwise these are assumes to be empty tuples.
    if isinstance(set_, Mapping):
        set_ = set_.items()
    if isinstance(vars_, Mapping):
        vars_ = vars_.items()
    if isinstance(eval_, Mapping):
        eval_ = eval_.items()
    if isinstance(path_, Mapping):
        path_ = path_.items()
    if isinstance(proxy_, Mapping):
        proxy_ = proxy_.items()

    def data() -> Iterator[tuple[Any, Any]]:
        def s_eval(v: str) -> Any:
            vv: Any = v
            if vv[0] == "~":
                vv = vv[1:]
            elif vv == "=-":
                vv = NotGiven
            elif vv == "=t":
                vv = True
            elif vv == "=f":
                vv = False
            elif vv == "=n":
                vv = None
            elif vv[0] == "=":
                vv = cmd_eval(vv[1:])
            elif vv[0] == ":":
                vv = P(vv)
            elif vv[0] == ".":
                vv = P(vv[1:])
            elif vv[0] == "^":
                if Proxy is None:
                    raise ImportError("No Proxy")
                vv = Proxy(vv[1:])
            else:
                try:
                    vv = int(vv)
                except ValueError:
                    try:
                        vv = float(vv)
                    except ValueError:
                        pass  # leave it as a string
            return vv

        for k, v in set_:
            yield k, s_eval(str(v))
        for k, v in vars_:
            yield k, v
        for k, v in eval_:
            # ruff:noqa:PLW2901 # var overwritten
            vv: Any = v
            if vv == "-":
                vv = NotGiven
            elif vv == "/":
                if vs is None:
                    raise click.BadOptionUsage(
                        option_name=str(k),
                        message="A slash value doesn't work here.",
                    )
                vv = NoneType
            else:
                vv = eval(vv)
            yield k, vv
        for k, pv in path_:
            vv = P(str(pv))
            if no_path:
                vv = tuple(vv)
            yield k, vv
        if proxy_:
            if Proxy is None:
                raise ImportError("No Proxy")
            for k, pv in proxy_:
                vv = Proxy(str(pv))
                yield k, vv

        # Arguments are given last, thus they get processed last.
        for v in args_:
            yield ((None, None), s_eval(str(v)))

    if set_:
        dd = data()
    else:
        dd = [(len(k), k, v) for k, v in data()]
        dd.sort()
        dd = [(k, v) for _l, k, v in dd]

    for k, v in dd:
        if isinstance(k, str):
            if k == "+":
                k = Path.build((None, None))
            else:
                k = P(k)
        if val is None:
            CFG.mod(k, v)
            continue

        if not len(k):
            if vs is not None:
                raise click.BadOptionUsage(
                    option_name=str(k),
                    message="You can't use empty paths here.",
                )
            val = v
            continue
        if not isinstance(val, Mapping):
            val = attrdict()
        if vs is not None:
            vs.add(str(k))
        if v is NotGiven:
            val = attrdict._delete(val, k)
        elif v is NoneType:
            val = attrdict._delete(val, k)
            if vs is not None:
                vs.discard(str(k))
        else:
            val = attrdict._update(val, k, v)
    return val


def load_ext(name: str, *attr: str, err: bool = False) -> Any:
    """
    Load a module
    """
    path = name.split(".")
    path.extend(attr[:-1])
    dp = ".".join(path)
    ".".join(path[:-1])
    try:
        mod = importlib.import_module(dp)
    except ModuleNotFoundError as exc:
        if err and exc.name is not None and not exc.name.endswith("._main"):
            logger.debug("Err %s: %r", dp, exc, exc_info=exc)
        return None
    except FileNotFoundError:
        if err:
            raise
        return None
    else:
        if attr:
            try:
                mod = getattr(mod, attr[-1])
            except AttributeError:
                logger.debug("Err %s.%s", dp, attr[-1])
                return None
        return mod


def _namespaces(name: str | object) -> Iterator[ModuleInfo]:
    import pkgutil  # noqa: PLC0415

    if name is NotGiven:
        return iter(())
    try:
        ext = importlib.import_module(cast(str, name))
    except ModuleNotFoundError:
        logger.debug("No NS: %s", name)
        return iter(())
    try:
        p = ext.__path__
    except AttributeError:
        fn = ext.__file__
        if fn is None:
            return iter(())
        p = (str(pathlib.Path(fn).parent),)
    logger.debug("NS: %s %s", name, p)
    return pkgutil.iter_modules(p, ext.__name__ + ".")


_ext_cache: defaultdict[str, dict[str, Any]] = defaultdict(dict)


def _cache_ext(ext_name: str, pkg_only: bool) -> None:
    """List external modules

    Yields (name,path) tuples.

    TODO: This is not zip safe.
    """
    for finder, name, ispkg in _namespaces(ext_name):
        if pkg_only and not ispkg:
            logger.debug("ExtNoC %s", name)
            continue
        logger.debug("ExtC %s", name)
        x = name.rsplit(".", 1)[-1]
        f = pathlib.Path(finder.path) / x
        _ext_cache[ext_name][x] = f


def list_ext(
    name: str, func: str | None = None, pkg_only: bool = True
) -> Iterator[tuple[str, Any]]:
    """List external modules

    Yields (name,path) tuples.

    TODO: This is not zip safe.
    """
    logger.debug("List Ext %s (%s)", name, func)
    if name not in _ext_cache:
        with suppress(ModuleNotFoundError):
            _cache_ext(name, pkg_only)
    if func is None:
        for a, b in _ext_cache[name].items():
            logger.debug("Found %s %s", a, b)
            yield a, b
        return

    for x, f in _ext_cache[name].items():
        if (f / ".no_load").is_file():
            logger.debug("Skip %s", f)
            continue
        fn = f / (func + ".py")
        if not fn.is_file():
            fn = f / func / "__init__.py"
            if not fn.is_file():
                # XXX this might be a namespace
                logger.debug("No file: %s/%s", f, func)
                continue
        logger.debug("Found2 %s %s", x, f)
        yield (x, f)


def load_subgroup(
    _fn: Callable[..., Any] | None = None,
    prefix: str | None = None,
    sub_pre: str | None = None,
    sub_post: str | None = None,
    ext_pre: str | None = None,
    ext_post: str | None = None,
    **kw: Any,
) -> Callable[..., Any]:
    """
    A decorator like :func:`asyncclick.group`, enabling loading of subcommands

    Internal extensions are loaded as ``{sub_pre}.*.{sub_post}``.
    External extensions are loaded as ``{ext_pre}.*.{ext_post}``.

    All other arguments are forwarded to :func:`asyncclick.command`.
    """

    def _ext(fn: Callable[..., Any], **kw: Any) -> Callable[..., Any]:
        return click.command(**kw)(fn)

    kw["cls"] = partial(
        kw.get("cls", Loader),
        _util_sub_pre=sub_pre or this_load.get() or prefix,
        _util_sub_post=sub_post or (None if prefix is None else "cli"),
        _util_ext_pre=ext_pre or prefix,
        _util_ext_post=ext_post or (None if prefix is None else "_main.cli"),
    )

    if _fn is None:
        return partial(_ext, **kw)
    else:
        return _ext(_fn, **kw)


class Loader(AliasedGroup):
    """
    An :class:`asyncclick.Group` that loads additional commands from subfolders and/or extensions.

    Subfolders: set _util_sub_pre to your module's name.
        This works with namespace packages.
        E.g. "distkv.command" loads "distkv.command.*.cli".

    Extensions: set _util_ext_pre to the extension basename.
        Set _util_ext_post to the name of the extension.

        E.g. "distkv_ext"+"client" loads "distkv_ext.*.client.cli".

    Both work in parallel.

    Caller::

        from moat.util import Loader
        from functools import partial

        @click.command(cls=partial(Loader,_util_sub_post='command'))
        async def cmd():
            print("I am the main program")

    Sub-Command Usage (``main`` is defined for you), e.g. in ``command/subcmd.py``::

        from moat.util import Loader
        from functools import partial

        @main.command / group()
        async def cmd(self):
            print("I am", self.name)  # prints "subcmd"
    """

    # ruff:noqa:SLF001

    def __init__(
        self,
        *,
        _util_sub_pre: str | None = None,
        _util_sub_post: str | None = None,
        _util_ext_pre: str | None = None,
        _util_ext_post: str | None = None,
        **kw: Any,
    ) -> None:
        logger.debug(
            "* Load: %s.*.%s / %s.*.%s",
            _util_sub_pre,
            _util_sub_post,
            _util_ext_pre,
            _util_ext_post,
        )
        if _util_sub_pre is not None:
            self._util_sub_pre = _util_sub_pre
        if _util_sub_post is not None:
            self._util_sub_post = _util_sub_post
        if _util_ext_pre is not None:
            self._util_ext_pre = _util_ext_pre
        if _util_ext_post is not None:
            self._util_ext_post = _util_ext_post
        super().__init__(**kw)

    def get_sub_ext(self, ctx: click.Context) -> tuple[Any, Any, Any, Any]:
        """Fetch extension variables"""
        try:
            uspr = ctx.obj._util_sub_pre
        except AttributeError:
            try:
                uspr = ctx.obj.moat.sub_pre
            except AttributeError:
                uspr = None
        try:
            uspo = ctx.obj._util_sub_post
        except AttributeError:
            try:
                uspo = ctx.obj.moat.sub_post
            except AttributeError:
                uspo = None
        try:
            expr = ctx.obj._util_ext_pre
        except AttributeError:
            try:
                expr = ctx.obj.moat.ext_pre
            except AttributeError:
                expr = None
        try:
            expo = ctx.obj._util_ext_post
        except AttributeError:
            try:
                expo = ctx.obj.moat.ext_post
            except AttributeError:
                expo = None

        sub_pre = getattr(self, "_util_sub_pre", uspr)
        sub_post = getattr(self, "_util_sub_post", uspo)
        ext_pre = getattr(self, "_util_ext_pre", expr)
        ext_post = getattr(self, "_util_ext_post", expo)

        if sub_pre is None:
            sub_post = None
        elif sub_post is None:
            sub_pre = ("cli",)
        elif isinstance(sub_post, str):
            sub_post = sub_post.split(".")

        if ext_pre is None:
            ext_post = None
        elif ext_post is None:
            ext_pre = None
        elif isinstance(ext_post, str):
            ext_post = ext_post.split(".")
            if len(ext_post) == 1:
                ext_post.append("cli")

        return sub_pre, sub_post, ext_pre, ext_post

    def list_commands(self, ctx: click.Context) -> list[str]:
        "show subpackages"
        rv = super().list_commands(ctx)
        sub_pre, sub_post, ext_pre, ext_post = self.get_sub_ext(ctx)
        logger.debug("* List: %s.*.%s / %s.*.%s", sub_pre, sub_post, ext_pre, ext_post)

        if sub_pre:
            logger.debug("Adding sub %s", sub_pre)
            for _finder, name, _ispkg in _namespaces(sub_pre):
                # ruff:noqa:PLW2901 # var overwritten
                name = name.rsplit(".", 1)[1]
                if name[0] == "_":
                    continue
                if load_ext(sub_pre, name, *sub_post, err=ctx.obj.get("debug_loader", False)):
                    rv.append(name)

        if ext_pre:
            logger.debug("Adding ext %s", ext_pre)
            for n, _ in list_ext(ext_pre):
                if load_ext(ext_pre, n, *ext_post, err=ctx.obj.get("debug_loader", False)):
                    rv.append(n)
        rv.sort()
        logger.debug("List: %r", rv)
        return rv

    def get_command(self, ctx, cmd_name):
        """Resolve a command, allowing unique prefixes."""
        rv = self._get_command(ctx, cmd_name)

        if rv is not None:
            return rv

        matches = [x for x in self.list_commands(ctx) if x.startswith(cmd_name)]

        if not matches:
            return None

        if len(matches) == 1:
            return self._get_command(ctx, matches[0])

        ctx.fail(f"Too many matches: {', '.join(sorted(matches))}")

    def _get_command(self, ctx: click.Context, cmd_name: str) -> click.Command | None:
        "add subpackages"
        command = super().get_command(ctx, cmd_name)

        sub_pre, sub_post, ext_pre, ext_post = self.get_sub_ext(ctx)

        if command is None and ext_pre is not None:
            command = load_ext(ext_pre, cmd_name, *ext_post)
            if command is not None:
                try:
                    CFG.with_(f"{ext_pre}.{cmd_name}")
                except AttributeError:
                    pass  # TODO happens during autocomplete

        if command is None:
            if sub_pre is None or sub_pre is NotGiven:
                return None
            if sub_post is None or sub_post is NotGiven:
                pass
            else:
                command = load_ext(sub_pre, cmd_name, *sub_post)
                if command is not None:
                    try:
                        CFG.with_(f"{sub_pre}.{cmd_name}")
                    except AttributeError:
                        pass  # TODO happens during autocomplete

        if command is None:
            # raise click.UsageError(f"No such subcommand: {cmd_name}")
            return None
        cmd = cast(Any, command)
        cmd.__name__ = cmd.name = cmd_name
        return cast(click.Command, cmd)


class MainLoader(Loader):
    """
    A special loader that runs the main setup code even if there's a
    subcommand with "--help".
    """

    async def invoke(self, ctx: click.Context) -> Any:
        if not getattr(ctx, "_moat_invoked", False):
            await ctx.invoke(cast(Any, self.callback), **ctx.params)
        return await super().invoke(ctx)


#
# There are two ways this can start up.
# (a) `main_` is the "real" main function. It sets up the Click environment and then
#     starts anyio and runs the function body, which calls `wrap_main`
#     synchronously to set up our object.
#
# (b) `wrap_main` is used as a wrapper, used mainly for testing. It sets up the context
#     and then returns "main_.main()", which is an awaitable, thus
#     `wrap_main` acts as an async function.


@load_subgroup(
    cls=MainLoader,
    add_help_option=False,
    invoke_without_command=True,
)  # , __file__, "command"))
@click.option("-V", "--verbose", count=True, help="Be more verbose. Can be used multiple times.")
@click.option("-L", "--debug-loader", is_flag=True, help="Debug submodule loading.")
@click.option("-Q", "--quiet", count=True, help="Be less verbose. Opposite of '--verbose'.")
@click.option("-D", "--debug", count=True, help="Enable debug speed-ups (smaller keys etc).")
@click.option(
    "-l",
    "--log",
    multiple=True,
    help="Adjust log level. Example: '--log asyncactor=DEBUG'.",
)
@click.option(
    "-c",
    "--cfg",
    "cfg_files",
    type=click.Path(readable=True),
    default=None,
    help="Configuration file (YAML).",
    multiple=True,
)
@click.option(
    "-h",
    "-?",
    "--help",
    is_flag=True,
    help="Show help. Subcommands only understand '--help'.",
)
@attr_args(par_name="Config item")
@click.pass_context
async def main_(
    ctx: click.Context, verbose: int, quiet: int, help: bool = False, **kv: Any
) -> None:
    """
    This is the main command. (You might want to override this text.)

    You need to add a subcommand for this to do anything.
    """
    ctx.allow_interspersed_args = True

    # The above `MainLoader.invoke` call causes this code to be called
    # twice instead of never.
    if hasattr(ctx, "_moat_invoked"):
        return
    cast(Any, ctx)._moat_invoked = True
    cfg = current_cfg.get()
    if cfg is not None:
        kv["cfg"] = cfg
    wrap_main(ctx=ctx, verbose=max(0, 1 + verbose - quiet), **kv)
    try:
        main = ctx.obj.moat.main_cmd
    except AttributeError:
        main = None
    if help or (
        main is None and ctx.invoked_subcommand is None and not ctx.args and not ctx.protected_args
    ):
        print(ctx.get_help())
        await ctx.aexit()
    elif main is not None:
        await main(ctx)


def wrap_main(
    main: Any = main_,
    *,
    set_: Mapping[str, str] | Sequence[tuple[str, str]] = (),
    vars_: Mapping[str, str] | Sequence[tuple[str, str]] = (),
    eval_: Mapping[str, str] | Sequence[tuple[str, str]] = (),
    path_: Mapping[str, str] | Sequence[tuple[str, str]] = (),
    proxy_: Mapping[str, str] | Sequence[tuple[str, str]] = (),
    name: str | None = None,
    sub_pre: str | bool | None = None,
    sub_post: str | None = None,
    ext_pre: str | None = None,
    ext_post: str | None = None,
    ext_name: str | None = None,
    cfg: CfgStore | attrdict | None | Literal[False] = None,
    cfg_files: str | Sequence[str] = (),
    cfg_load_all: bool | None = True,
    args: Sequence[str] | None = None,
    wrap: bool = False,
    verbose: int = 1,
    debug: int = 0,
    debug_loader: bool = False,
    log: Sequence[str] = (),
    ctx: click.Context | None = None,
    help: str | None = None,
) -> Awaitable[Any] | None:
    """
    The main command entry point, when testing.

    Args:
        main: special main function, defaults to :func:`moat.lib.run.main_`.
        name: command name, defaults to {main}'s toplevel module name.

        cfg: additional configuration to preconfigure
        cfg_files: additional configuration file(s) to load
        cfg_load_all: Flag whether to load the default config file(s): True=all,
            False=first found, None=No.

        wrap: Flag: this is a subcommand. Don't set up logging, return the awaitable.
        args: Argument list if called from a test, `None` otherwise.
        help: Help text of your code.

    The arguments ``{sub,ext}_{pre,post}`` contain prefixes and suffices
    for loading commands in submodules or extensions.

    Internal extensions are loaded as ``{sub_pre}.*.{sub_post}``.
    External extensions are loaded as ``{ext_pre}.*.{ext_post}``.
    """

    obj: attrdict = getattr(ctx, "obj", None)
    if obj is None:
        obj = attrdict()

    opts = obj.get("moat", None)
    if opts is None:
        obj.moat = opts = attrdict()

    if sub_pre is None:
        sub_pre = opts.get("sub_pre", None)
    else:
        opts["sub_pre"] = sub_pre

    if sub_post is None:
        sub_post = opts.get("sub_post", None)
    else:
        opts["sub_post"] = sub_post

    if ext_pre is None:
        ext_pre = opts.get("ext_pre", None)
    else:
        opts["ext_pre"] = ext_pre

    if ext_post is None:
        ext_post = opts.get("ext_post", None)
    else:
        opts["ext_post"] = ext_post

    # Name defaults to "moat", of course ;-)
    if name is None:
        name = opts.setdefault("name", "moat")
    else:
        opts["name"] = name

    if sub_pre is True:
        "discover from caller"
        import inspect  # noqa: PLC0415

        frame = inspect.currentframe()
        if frame is None or frame.f_back is None:
            raise RuntimeError("Cannot discover caller module")
        sub_pre = frame.f_back.f_globals["__package__"]
    elif sub_pre is None:
        sub_pre = name
    if sub_post is None:
        sub_post = "_main.cli"

    if main is None:
        if help is not None:
            raise RuntimeError("You can't set the help text this way")
    else:
        main.context_settings["obj"] = obj
        if help is not None:
            main.help = help

    obj._util_sub_pre = sub_pre
    obj._util_sub_post = sub_post
    obj._util_ext_pre = ext_pre
    obj._util_ext_post = ext_post

    if not isinstance(cfg, CfgStore):
        cfg = CFG(name, preload=cfg, load_all=cfg_load_all, ext=ext_name)

    if isinstance(cfg_files, str):
        cfg_files = (cfg_files,)
    for fn in cfg_files:
        cfg.add(fn)

    # our toplevel config file(s)
    CFG.with_("moat")
    if name != "moat":
        CFG.with_(name)

    obj.debug = verbose
    obj.DEBUG = debug

    if wrap:
        pass
    elif hasattr(logging.root, "_MoaT"):
        logging.debug("Logging already set up")  # noqa:LOG015
    else:
        # Configure logging. This is a somewhat arcane art.
        cfg.mod(
            P("logging.root.level"),
            "DEBUG"
            if verbose > 2
            else "INFO"
            if verbose > 1
            else "WARNING"
            if verbose
            else "ERROR",
        )
        for k in log:
            k, v = k.split("=")
            cfg.mod(P("logging.loggers") / k / "level", v)
        logging.config.dictConfig(cfg.logging)

    process_args(
        set_=set_,
        vars_=vars_,
        eval_=eval_,
        path_=path_,
        proxy_=proxy_,
    )

    try:
        in_test = cfg.env.in_test
    except AttributeError:
        pass
    else:
        in_test(cfg)

    if not wrap and not hasattr(logging.root, "_MoaT"):
        logging.basicConfig = cast(Any, _no_config)
        logging.config.dictConfig = cast(Any, _no_config)
        logging.config.fileConfig = cast(Any, _no_config)

        logging.captureWarnings(verbose > 0)
        logger.disabled = False
        if debug_loader:
            logger.level = logging.DEBUG
            for p in sys.path:
                logger.debug("Path: %s", p)
        cast(Any, logging.root)._MoaT = True

    obj.logger = logging.getLogger(name)
    obj.debug_loader = debug_loader
    obj.cfg = cfg.result[name]
    try:
        obj.stdout = cfg.result.env.stdout
    except AttributeError:
        obj.stdout = sys.stdout

    try:
        # NOTE this return an awaitable
        if ctx is not None:
            ctx.obj = obj
        elif main is not None:
            if wrap:
                main = main.main
            with ungroup():
                return main(args=args, standalone_mode=False, obj=obj)

    except click.exceptions.MissingParameter as exc:
        pname = (
            exc.param.name.upper()
            if exc.param is not None and exc.param.name is not None
            else "PARAMETER"
        )
        print(
            f"You need to provide an argument {pname!r}.\n",
            file=sys.stderr,
        )
        if exc.cmd is not None and exc.ctx is not None:
            print(exc.cmd.get_help(exc.ctx), file=sys.stderr)
        sys.exit(2)
    except click.exceptions.UsageError as exc:
        try:
            s = str(exc)
        except TypeError:
            logger.exception("??", exc_info=exc)
        else:
            print(s, file=sys.stderr)
        sys.exit(2)
    except click.exceptions.Abort:
        print("Aborted.", file=sys.stderr)


def _ng(type_: Callable[[Any], Any]) -> Callable[[Any], Any]:
    @wraps(type_)
    def gen(data: Any) -> Any:
        if data is NotGiven:
            return data
        return type_(data)

    return gen


def option_ng(*a: Any, type: Callable[[Any], Any] = str, **kw: Any) -> Any:  # noqa: A002, D103
    return click.option(*a, **kw, type=_ng(type), default=NotGiven)
