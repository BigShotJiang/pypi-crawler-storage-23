__version__ = '1.1.9'
commit_message = f'Improve books model'
