# CodeClone CLI

The analysis engine for CodeClone Suite. This CLI provides the protocol boundary for editor extensions.

## Installation

```bash
pip install codeclone-cli
```

Or install from source:

```bash
cd engines/codeclone-cli
pip install -e .
```

## Usage

```bash
# Show version
codeclone version --json

# Analyze a repository
codeclone analyze /path/to/repo --json
```

## Output Contract

This CLI follows the [Editor Integration Specification](../../docs/EDITOR_INTEGRATION.md).

- stdout is JSON only in `--json` mode
- stderr is for human diagnostics
- Exit codes: 0 (OK), 1 (PARTIAL), 2 (FAIL)

## Development

```bash
pip install -e ".[dev]"
pytest
```

## License

MIT
