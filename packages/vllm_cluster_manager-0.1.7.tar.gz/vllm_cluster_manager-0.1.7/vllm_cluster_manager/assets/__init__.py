"""Package data for vLLM Cluster Manager."""
