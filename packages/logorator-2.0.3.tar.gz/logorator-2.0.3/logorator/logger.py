from functools import wraps
from time import perf_counter
import re
import os
import inspect
import contextvars
from typing import Optional
from enum import IntEnum


class LogLevel(IntEnum):
    DEBUG = 10
    INFO = 20
    WARNING = 30
    ERROR = 40


class Logger:
    SILENT = False
    OUTPUT_FILE = None
    LEVEL = LogLevel.DEBUG
    _ANSI_PATTERN = re.compile(r'\033\[[0-9;]*m')
    _LEVEL_COLORS = {
        LogLevel.DEBUG: "\033[36m",    # Cyan
        LogLevel.INFO: "\033[32m",     # Green (default)
        LogLevel.WARNING: "\033[33m",  # Yellow
        LogLevel.ERROR: "\033[31m"     # Red
    }
    
    # Context tracking for nested calls
    _task_counter = 0
    _task_id = contextvars.ContextVar('logger_task_id', default=None)
    _call_depth = contextvars.ContextVar('logger_call_depth', default=0)

    def __init__(self, silent: Optional[bool] = None, mode: str = "normal", override_function_name: Optional[str] = None, level: LogLevel = LogLevel.INFO, include_args=None, exclude_args=None, show_depth: bool = True):
        if silent is not None and not isinstance(silent, bool):
            raise TypeError("`silent` must be a boolean or None.")
        self.silent = Logger.SILENT if silent is None else silent

        if mode not in {"normal", "short"}:
            raise ValueError("`mode` must be either 'normal' or 'short'.")
        self.mode = mode

        self.override_function_name = override_function_name
        
        if not isinstance(level, LogLevel):
            raise TypeError("`level` must be a LogLevel enum value.")
        self.level = level
        
        # Convert to sets for efficient lookup
        self.include_args = set(include_args) if include_args else None
        self.exclude_args = set(exclude_args) if exclude_args else None
        
        if self.include_args and self.exclude_args:
            raise ValueError("Cannot specify both `include_args` and `exclude_args`.")
        
        self.show_depth = show_depth

    def eol(self):
        if self.mode == "short":
            return "\t"
        return "\n"

    @staticmethod
    def log(message: str = "", end: str = ""):
        if not isinstance(message, str):
            raise TypeError("`message` must be a string.")
        if not isinstance(end, str):
            raise TypeError("`end` must be a string.")

        try:
            if Logger.OUTPUT_FILE is None:
                print(message, end=end)
            else:
                with open(Logger.OUTPUT_FILE, "a") as f:
                    sanitized_message = Logger._ANSI_PATTERN.sub("", message)
                    f.write(sanitized_message + end)
        except IOError as e:
            raise IOError(f"Failed to write to the log file: {Logger.OUTPUT_FILE}. Error: {e}")

    @staticmethod
    def _get_or_create_task_id():
        """Get or create a unique task ID for this context"""
        task_id = Logger._task_id.get()
        if task_id is None:
            Logger._task_counter += 1
            task_id = Logger._task_counter
            Logger._task_id.set(task_id)
        return task_id
    
    @staticmethod
    def _format_arg(arg):
        """Format argument for logging, using class name for objects without custom __str__"""
        # Handle class types (cls parameter in classmethods)
        if isinstance(arg, type):
            return arg.__name__
        # Check if it's a custom object (not a built-in type) without custom __str__
        if (hasattr(arg, '__class__') and 
            type(arg).__str__ is object.__str__ and
            type(arg).__module__ not in ('builtins', '__builtin__')):
            return arg.__class__.__name__
        return str(arg)[:1000]

    def _log_start(self, func_name: str, args: tuple, kwargs: dict, func, _logorator_async_func=False) -> None:
        if self.silent or self.level < Logger.LEVEL:
            return
        
        # Handle depth tracking with indentation
        indent = ""
        if self.show_depth:
            depth = Logger._call_depth.get()
            indent = "  " * depth
        
        # Get parameter names from function signature
        try:
            sig = inspect.signature(func)
            param_names = list(sig.parameters.keys())
        except (ValueError, TypeError):
            param_names = []
        
        # Check if first arg is 'self' or 'cls' and show it separately
        class_info = ""
        skip_first_arg = False
        if param_names and args:
            first_param = param_names[0]
            if first_param in ('self', 'cls'):
                skip_first_arg = True
                class_name = Logger._format_arg(args[0])
                class_info = f"\033[35m[{class_name}]\033[0m "
        
        async_string = "\033[35masync \033[0m" if _logorator_async_func else ""
        color = Logger._LEVEL_COLORS[self.level]
        Logger.log(message=f"{indent}Running {async_string}{class_info}{color}{func_name} \033[0m ", end=self.eol())
        
        # Log positional arguments with their names (skip self/cls)
        start_idx = 1 if skip_first_arg else 0
        for i in range(start_idx, len(args)):
            param_name = param_names[i] if i < len(param_names) else f"arg{i}"
            
            # Apply filtering
            if self.include_args and param_name not in self.include_args:
                continue
            if self.exclude_args and param_name in self.exclude_args:
                continue
            
            Logger.log(message=f"{indent}  {param_name}: \33[33m{Logger._format_arg(args[i])}\033[0m", end=self.eol())
        
        # Log keyword arguments
        for key in list(kwargs):
            # Apply filtering
            if self.include_args and key not in self.include_args:
                continue
            if self.exclude_args and key in self.exclude_args:
                continue
            
            Logger.log(message=f"{indent}  {key}: \33[33m{Logger._format_arg(kwargs[key])}\033[0m", end=self.eol())

    def _log_end(self, func_name: str, duration: str, first_arg=None, _logorator_async_func=False) -> None:
        if self.silent or self.level < Logger.LEVEL:
            return
        
        # Handle depth tracking with indentation
        indent = ""
        if self.show_depth:
            depth = Logger._call_depth.get()
            indent = "  " * depth
        
        async_string = "\033[35masync \033[0m" if _logorator_async_func else ""
        arg_str = f" \33[33m({Logger._format_arg(first_arg)[:100]})\33[0m" if _logorator_async_func and first_arg is not None else ""
        color = Logger._LEVEL_COLORS[self.level]
        Logger.log(message=f"{indent}Finished {async_string}{color}{func_name}{arg_str} \033[0m Time elapsed: {color}{duration} ms\033[0m", end="\n")

    def __call__(self, func):
        func_name = self.override_function_name or func.__name__

        if inspect.iscoroutinefunction(func):
            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                start = perf_counter()
                self._log_start(func_name, args, kwargs, func, _logorator_async_func=True)

                # Increment depth after logging start
                if self.show_depth:
                    depth = Logger._call_depth.get()
                    Logger._call_depth.set(depth + 1)

                result = await func(*args, **kwargs)

                # Decrement depth before logging end
                if self.show_depth:
                    depth = Logger._call_depth.get()
                    Logger._call_depth.set(depth - 1)

                end = perf_counter()
                duration = '{:,.2f}'.format((end - start) * 1000)
                first_arg = args[0] if args else None
                self._log_end(func_name, duration, first_arg, _logorator_async_func=True)

                return result

            return async_wrapper
        else:
            @wraps(func)
            def wrapper(*args, **kwargs):
                start = perf_counter()
                self._log_start(func_name, args, kwargs, func)

                # Increment depth after logging start
                if self.show_depth:
                    depth = Logger._call_depth.get()
                    Logger._call_depth.set(depth + 1)

                result = func(*args, **kwargs)

                # Decrement depth before logging end
                if self.show_depth:
                    depth = Logger._call_depth.get()
                    Logger._call_depth.set(depth - 1)

                end = perf_counter()
                duration = '{:,.2f}'.format((end - start) * 1000)
                self._log_end(func_name, duration)

                return result

            return wrapper

    @staticmethod
    def set_silent(silent: bool = True):
        if not isinstance(silent, bool):
            raise TypeError("`silent` must be a boolean.")
        Logger.SILENT = silent

    @staticmethod
    def set_level(level: LogLevel):
        if not isinstance(level, LogLevel):
            raise TypeError("`level` must be a LogLevel enum value.")
        Logger.LEVEL = level

    @staticmethod
    def set_output(filename: Optional[str] = None):
        if filename is not None and not isinstance(filename, str):
            raise TypeError("`filename` must be a string or None.")

        if filename is not None:
            directory = os.path.dirname(filename)
            if directory and not os.path.exists(directory):
                try:
                    os.makedirs(directory, exist_ok=True)
                except OSError as e:
                    raise OSError(f"Failed to create directory `{directory}` for log file: {e}")

            try:
                with open(filename, "a") as f:
                    pass
            except IOError as e:
                raise IOError(f"Failed to open log file `{filename}` for writing: {e}")

        Logger.OUTPUT_FILE = filename

    @staticmethod
    def note(note: str = "", mode: str = "normal"):
        if not isinstance(note, str):
            raise TypeError("`note` must be a string.")
        if mode not in {"normal", "short"}:
            raise ValueError("`mode` must be either 'normal' or 'short'.")

        if Logger.SILENT:
            return

        Logger.log(f"\033[34m{note} \033[0m", end=("\t" if mode == "short" else "\n"))