#!/usr/bin/env python3
"""USB 热拔插监控（Windows）- 基于 cyme --json watch

首次运行会自动下载 cyme.exe
"""
from __future__ import annotations

import asyncio
import json
import os
import shutil
import sys
import threading
import urllib.request
import zipfile
from typing import Callable

_版本缓存文件 = "cyme_version.txt"


def _获取安装目录() -> str:
    """获取安装目录"""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def _获取最新版本信息() -> tuple[str, str]:
    """获取 GitHub 最新版本号和下载地址"""
    api = "https://api.github.com/repos/tuna-f1sh/cyme/releases/latest"
    try:
        with urllib.request.urlopen(api, timeout=10) as resp:
            data = json.loads(resp.read().decode())
        version = data["tag_name"]  # 如 "v2.2.11"
        for asset in data.get("assets", []):
            name = asset["name"]
            if "windows" in name.lower() and name.endswith(".zip"):
                return version, asset["browser_download_url"]
        raise RuntimeError("未找到 Windows 版本下载链接")
    except Exception as e:
        raise RuntimeError(f"获取 cyme 版本失败: {e}")


def _下载cyme() -> str:
    """确保 cyme.exe 可用"""
    安装目录 = _获取安装目录()
    目标路径 = os.path.join(安装目录, "cyme.exe")
    版本文件 = os.path.join(安装目录, _版本缓存文件)

    # 1. 已存在且有效
    if os.path.isfile(目标路径):
        return 目标路径

    # 2. 系统 PATH 中有
    path = shutil.which("cyme") or shutil.which("cyme.exe")
    if path:
        return path

    # 3. 自动下载最新版
    print("正在获取 cyme 最新版本...")
    try:
        version, url = _获取最新版本信息()
        print(f"下载 cyme {version}...")
        zip路径 = os.path.join(安装目录, "cyme.zip")
        urllib.request.urlretrieve(url, zip路径)

        # 解压
        with zipfile.ZipFile(zip路径, "r") as z:
            for name in z.namelist():
                if name.endswith("cyme.exe"):
                    with z.open(name) as src, open(目标路径, "wb") as dst:
                        dst.write(src.read())
                    break

        os.remove(zip路径)
        with open(版本文件, "w") as f:
            f.write(version)
        print(f"cyme {version} 已安装")
        return 目标路径
    except Exception as e:
        raise RuntimeError(f"下载 cyme 失败: {e}\n请手动下载: https://github.com/tuna-f1sh/cyme/releases")


_路径 = _下载cyme()


def _创建设备字典(d: dict, 总线: int, 事件类型: str) -> dict:
    """创建设备字典"""
    loc = d.get("location_id", {})
    port = loc.get("number", 0)
    vid = d.get("vendor_id", 0)
    pid = d.get("product_id", 0)

    return {
        "事件": 事件类型,
        "名称": d.get("name", "未知设备"),
        "厂商ID": f"{vid:04x}",
        "产品ID": f"{pid:04x}",
        "VID_PID": f"{vid:04x}:{pid:04x}",
        "总线": 总线,
        "端口": port,
        "位置": f"{总线}-{port}",
        "厂商": d.get("manufacturer"),
        "序列号": d.get("serial_num"),
        "速度": d.get("device_speed"),
        "设备类": d.get("class"),
        "子类": d.get("sub_class"),
        "协议": d.get("protocol"),
        "版本": d.get("bcd_device"),
        "原始事件": d.get("last_event", {}),
    }


class USB监控:
    """USB 热拔插监控器"""

    def __init__(self):
        self._回调列表: list[Callable[[dict], None]] = []
        self._循环: asyncio.AbstractEventLoop | None = None
        self._任务: asyncio.Task | None = None
        self._运行中 = False
        self._已处理: set[str] = set()

    def 添加回调(self, 回调函数: Callable[[dict], None]) -> "USB监控":
        """添加事件回调函数"""
        self._回调列表.append(回调函数)
        return self

    def 启动(self) -> "USB监控":
        """开始监控"""
        if self._运行中:
            return self
        self._运行中 = True
        threading.Thread(target=self._运行循环, daemon=True).start()
        return self

    def 停止(self) -> None:
        """停止监控"""
        if not self._运行中:
            return
        self._运行中 = False
        if self._循环 and self._任务:
            self._循环.call_soon_threadsafe(self._任务.cancel)

    def _运行循环(self) -> None:
        self._循环 = asyncio.new_event_loop()
        asyncio.set_event_loop(self._循环)
        self._任务 = self._循环.create_task(self._监控())
        try:
            self._循环.run_until_complete(self._任务)
        except asyncio.CancelledError:
            pass
        finally:
            self._循环.run_until_complete(self._循环.shutdown_asyncgens())
            self._循环.close()

    async def _监控(self) -> None:
        proc = await asyncio.create_subprocess_exec(
            _路径, "--json", "watch",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        try:
            async for line in proc.stdout or ():
                if not self._运行中:
                    break
                try:
                    self._处理数据(json.loads(line))
                except json.JSONDecodeError:
                    pass
        except asyncio.CancelledError:
            pass
        finally:
            if proc.returncode is None:
                proc.terminate()
                try:
                    await asyncio.wait_for(proc.wait(), timeout=1.0)
                except (asyncio.TimeoutError, asyncio.CancelledError):
                    proc.kill()

    def _处理数据(self, data: dict) -> None:
        for bus in data.get("buses", []):
            bus_num = bus.get("usb_bus_number", 0)
            for d in bus.get("devices", []):
                evt = d.get("last_event", {})
                loc = d.get("location_id", {})
                port = loc.get("number", 0)

                if "connected" in evt:
                    evt_id = f"connect:{d.get('vendor_id')}:{d.get('product_id')}:{bus_num}:{port}:{evt['connected']}"
                    if evt_id not in self._已处理:
                        self._已处理.add(evt_id)
                        self._分发事件(d, bus_num, "插入")
                elif "disconnected" in evt:
                    evt_id = f"disconnect:{d.get('vendor_id')}:{d.get('product_id')}:{bus_num}:{port}:{evt['disconnected']}"
                    if evt_id not in self._已处理:
                        self._已处理.add(evt_id)
                        self._分发事件(d, bus_num, "拔出")

    def _分发事件(self, d: dict, bus: int, evt_type: str) -> None:
        dev = _创建设备字典(d, bus, evt_type)
        for cb in self._回调列表:
            try:
                cb(dev)
            except Exception:
                pass

    def __enter__(self) -> "USB监控":
        return self.启动()

    def __exit__(self, *args) -> None:
        self.停止()


_监控器: USB监控 | None = None


def 监控USB事件(回调函数: Callable[[dict], None]) -> USB监控:
    """注册 USB 事件回调（全局单例，最简单的调用方式）"""
    global _监控器
    if _监控器 is None:
        _监控器 = USB监控().启动()
    return _监控器.添加回调(回调函数)


def 停止监控() -> None:
    """停止全局监控"""
    global _监控器
    if _监控器:
        _监控器.停止()
        _监控器 = None


if __name__ == "__main__":
    import time

    def 处理事件(设备: dict):
        t = "+" if 设备["事件"] == "插入" else "-"
        print(f"[{t}] {设备['名称']} ({设备['VID_PID']})")
        print(f"  位置: {设备['位置']}")
        print(f"  厂商ID: {设备['厂商ID']}  产品ID: {设备['产品ID']}")
        print(f"  厂商: {设备['厂商'] or '-'}")
        print(f"  序列号: {设备['序列号'] or '-'}")
        print(f"  速度: {设备['速度'] or '-'}")
        if 设备.get("设备类"):
            print(f"  设备类: {设备['设备类']}")
        print()

    print("USB 监控中... (Ctrl+C 退出)\n")

    监控器 = USB监控().添加回调(处理事件).启动()
    try:
        while 监控器._运行中:
            time.sleep(0.5)
    except KeyboardInterrupt:
        print("\n已停止")
    finally:
        监控器.停止()