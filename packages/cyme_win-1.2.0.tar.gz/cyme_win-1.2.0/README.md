# cyme_win

Windows USB 热拔插监控库，基于 [cyme](https://github.com/tuna-f1sh/cyme)，简洁易用。

## 安装

```bash
pip install cyme_win
```

## 自动下载

首次运行会自动下载 `cyme.exe`，无需手动配置。

## 快速开始

```python
from cyme_win import 监控USB事件

# 一行代码监控 USB 热拔插
监控USB事件(lambda 设备: print(f"{设备['事件']}: {设备['名称']} ({设备['VID_PID']})"))

import time
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    pass
```

## 设备信息

回调函数接收一个字典，包含以下字段：

| 字段 | 说明 | 示例 |
|------|------|------|
| `事件` | 事件类型 | `"插入"` / `"拔出"` |
| `名称` | 设备名称 | `"SanDisk USB Flash Drive"` |
| `厂商ID` | Vendor ID | `"0781"` |
| `产品ID` | Product ID | `"5567"` |
| `VID_PID` | 组合格式 | `"0781:5567"` |
| `位置` | Linux 风格位置 | `"0-15"` |
| `厂商` | 制造商名称 | `"SanDisk"` |
| `序列号` | 设备序列号 | `"4C5300012345"` |
| `速度` | 传输速度 | `"480.0 Mb/s"` |
| `设备类` | USB 设备类 | `"mass-storage"` |
| `总线` | 总线号 | `0` |
| `端口` | 端口号 | `15` |

## 使用示例

### 示例 1：区分插入和拔出事件

```python
from cyme_win import 监控USB事件

def 处理设备(设备):
    if 设备["事件"] == "插入":
        print(f"[+] 新设备: {设备['名称']}")
    else:
        print(f"[-] 移除: {设备['名称']}")
    print(f"    VID/PID: {设备['VID_PID']}")
    print(f"    位置: {设备['位置']}")

监控USB事件(处理设备)

import time
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    print("监控已停止")
```

### 示例 2：监控特定设备

```python
from cyme_win import 监控USB事件

def 监控U盘(设备):
    # 只监控大容量存储设备
    if 设备["设备类"] == "mass-storage":
        print(f"U盘 {设备['事件']}: {设备['名称']}")
        print(f"  序列号: {设备['序列号']}")
        print(f"  速度: {设备['速度']}")

监控USB事件(监控U盘)
```

### 示例 3：使用类 API（多回调）

```python
from cyme_win import USB监控

def 记录日志(设备):
    with open("usb_log.txt", "a", encoding="utf-8") as f:
        f.write(f"{设备['事件']} | {设备['名称']} | {设备['VID_PID']}\n")

def 发送通知(设备):
    print(f"通知: {设备['事件']} - {设备['名称']}")

# 创建监控器，添加多个回调
监控器 = USB监控()
监控器.添加回调(记录日志)
监控器.添加回调(发送通知)
监控器.启动()

import time
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    监控器.停止()
```

### 示例 4：使用上下文管理器

```python
from cyme_win import USB监控

with USB监控().添加回调(lambda d: print(d)):
    print("监控中... 按 Ctrl+C 退出")
    import time
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
```

### 示例 5：获取设备完整信息

```python
from cyme_win import 监控USB事件

def 显示详情(设备):
    print(f"\n{'='*50}")
    print(f"事件: {设备['事件']}")
    print(f"名称: {设备['名称']}")
    print(f"VID:PID: {设备['VID_PID']}")
    print(f"厂商: {设备['厂商']}")
    print(f"序列号: {设备['序列号']}")
    print(f"速度: {设备['速度']}")
    print(f"位置: {设备['位置']} (总线 {设备['总线']}, 端口 {设备['端口']})")
    print(f"设备类: {设备['设备类']}")
    print(f"{'='*50}\n")

监控USB事件(显示详情)

import time
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    pass
```

## API 参考

### `监控USB事件(回调函数)`

全局单例模式，最简单的使用方式。

```python
监控USB事件(lambda 设备: print(设备))
```

### `USB监控` 类

| 方法 | 说明 |
|------|------|
| `添加回调(函数)` | 添加事件回调函数，返回 self 支持链式调用 |
| `启动()` | 开始监控 |
| `停止()` | 停止监控 |

### `停止监控()`

停止全局监控。

## 相关链接

- cyme 项目：https://github.com/tuna-f1sh/cyme
- cyme 下载：https://github.com/tuna-f1sh/cyme/releases

## License

MIT