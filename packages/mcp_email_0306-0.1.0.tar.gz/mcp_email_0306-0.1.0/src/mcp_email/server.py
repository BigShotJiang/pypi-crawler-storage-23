import smtplib
import imaplib
import email
from email.message import EmailMessage
from email.header import decode_header
from mcp.server.fastmcp import FastMCP
import os
# 初始化 FastMCP
mcp = FastMCP("Email Server")


EMAIL_ACCOUNT = os.environ.get("EMAIL_ACCOUNT")
EMAIL_PASSWORD = os.environ.get("EMAIL_PASSWORD")
SMTP_SERVER = os.environ.get("SMTP_SERVER", "smtp.qiye.163.com")
IMAP_SERVER = os.environ.get("IMAP_SERVER", "imap.qiye.163.com")

if not EMAIL_ACCOUNT or not EMAIL_PASSWORD:
    raise ValueError("请在环境变量中设置 EMAIL_ACCOUNT 和 EMAIL_PASSWORD")


def decode_mime_words(s):
    """解码经过 MIME 编码的字符串，解决乱码问题"""
    if not s:
        return ""
    decoded_words = decode_header(s)
    result = []
    for word, charset in decoded_words:
        if isinstance(word, bytes):
            charset = charset or 'utf-8'
            try:
                result.append(word.decode(charset))
            except LookupError:
                result.append(word.decode('utf-8', errors='replace'))
        else:
            result.append(word)
    return "".join(result)


def extract_body(msg):
    """提取邮件正文，优先取纯文本，其次取HTML"""
    text_body = ""
    html_body = ""

    if msg.is_multipart():
        for part in msg.walk():
            # 忽略多部分容器和附件
            if part.get_content_maintype() == 'multipart' or part.get('Content-Disposition') is not None:
                continue

            content_type = part.get_content_type()
            charset = part.get_content_charset() or 'utf-8'

            try:
                payload = part.get_payload(decode=True).decode(charset, errors='replace')
                if content_type == 'text/plain':
                    text_body += payload
                elif content_type == 'text/html':
                    html_body += payload
            except:
                continue
    else:
        content_type = msg.get_content_type()
        charset = msg.get_content_charset() or 'utf-8'
        try:
            payload = msg.get_payload(decode=True).decode(charset, errors='replace')
            if content_type == 'text/plain':
                text_body = payload
            elif content_type == 'text/html':
                html_body = payload
        except:
            pass

    # 优先返回纯文本，没有的话返回 HTML 让大模型自己去理解
    result = text_body.strip() if text_body else html_body.strip()
    return result if result else "[无法解析或正文为空]"


@mcp.tool()
def send_email(to_email: str, subject: str, body: str) -> str:
    """发送电子邮件"""
    try:
        msg = EmailMessage()
        msg.set_content(body)
        msg['Subject'] = subject
        msg['From'] = EMAIL_ACCOUNT
        msg['To'] = to_email

        with smtplib.SMTP_SSL(SMTP_SERVER, 465) as smtp:
            smtp.login(EMAIL_ACCOUNT, EMAIL_PASSWORD)
            smtp.send_message(msg)

        return f"成功发送邮件至 {to_email}，主题：{subject}"
    except Exception as e:
        return f"发送邮件失败: {str(e)}"


@mcp.tool()
def read_emails(limit: int = 5) -> str:
    """读取收件箱中最新的邮件（包含正文）"""
    try:
        mail = imaplib.IMAP4_SSL(IMAP_SERVER)
        mail.login(EMAIL_ACCOUNT, EMAIL_PASSWORD)
        mail.select("inbox")

        status, messages = mail.search(None, "ALL")
        email_ids = messages[0].split()
        latest_email_ids = email_ids[-limit:]

        results = []
        for e_id in reversed(latest_email_ids):
            status, msg_data = mail.fetch(e_id, "(RFC822)")
            for response_part in msg_data:
                if isinstance(response_part, tuple):
                    msg = email.message_from_bytes(response_part[1])

                    # 解码主题和发件人
                    subject = decode_mime_words(msg.get("Subject", ""))
                    from_ = decode_mime_words(msg.get("From", ""))

                    # 提取正文并做截断保护（防止正文太长把大模型上下文撑爆）
                    body = extract_body(msg)
                    if len(body) > 2000:
                        body = body[:2000] + "\n\n...[正文过长，已截断]..."

                    results.append(f"发件人: {from_}\n主题: {subject}\n正文内容:\n{body}\n" + "=" * 40)

        mail.logout()
        return "\n".join(results) if results else "收件箱为空。"

    except Exception as e:
        return f"读取邮件失败: {str(e)}"


def main():
    """这是包的启动入口"""
    mcp.run()

if __name__ == "__main__":
    main()