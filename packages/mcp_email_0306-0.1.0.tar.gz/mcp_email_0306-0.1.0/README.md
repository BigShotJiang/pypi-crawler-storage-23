# MCP Email Server 📧

这是一个基于 Model Context Protocol (MCP) 标准开发的电子邮件助手服务。它可以将你的本地/校园邮箱能力无缝接入到大模型（如 Claude Desktop、Cherry Studio 等）中，让 AI 帮你自动阅读和发送邮件。

本项目完美兼容网易企业邮底层的教育邮箱以及普通 163/126 邮箱。

## ✨ 核心功能

- **发送邮件** (`send_email`): 自动向指定收件人发送带有主题和正文的邮件。
- **读取邮件** (`read_emails`): 自动拉取收件箱最新邮件，并智能解析发件人、主题及正文内容（自动处理乱码，支持提取纯文本与 HTML 核心内容）。

## 🚀 安装

推荐使用 `uv` 运行（免配置环境），或者通过 `pip` 全局安装：

```bash
# 方式一：使用 pip 安装
pip install mcp-email-0306

# 方式二：使用 uvx 直接运行 (推荐)
uvx mcp-email-0306