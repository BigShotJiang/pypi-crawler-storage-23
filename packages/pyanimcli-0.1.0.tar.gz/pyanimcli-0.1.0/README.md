# PyAnim

Lib de animações para terminal em Python.

## Instalação
```bash
pip install PyAnim