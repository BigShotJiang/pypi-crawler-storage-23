import sys
import time
import importlib

class ProgressBar:

    # ===============================
    # 🔹 ImportLib (real)
    # ===============================
    class ImportLib:
        def __init__(self, speed: float, libs: list[str]):
            self.speed = speed
            self.libs = libs
            self.total = len(libs)

        def _draw(self, current, size=30):
            percent = current / self.total
            filled = int(size * percent)
            bar = "█" * filled + "-" * (size - filled)
            sys.stdout.write(
                f"\r[{bar}] {int(percent*100)}% ({current}/{self.total})"
            )
            sys.stdout.flush()

        def start(self):
            for i, lib in enumerate(self.libs, 1):
                try:
                    importlib.import_module(lib)
                    time.sleep(self.speed)
                except Exception as e:
                    sys.stdout.write(f"\n❌ {lib}: {e}\n")
                self._draw(i)

            print("\n✔ Imports concluídos")

    # ===============================
    # 🔹 Normal (fake)
    # ===============================
    class Normal:
        def __init__(self, style="block", speed=0.05):
            self.style = style
            self.speed = speed

            self.styles = {
                "block": ("█", "-"),
                "hash": ("#", "-"),
                "line": ("=", " "),
            }

        def start(self, total=100):
            fill, empty = self.styles.get(
                self.style, self.styles["block"]
            )

            for i in range(total + 1):
                percent = i / total
                size = 30
                filled = int(size * percent)
                bar = fill * filled + empty * (size - filled)

                sys.stdout.write(f"\r[{bar}] {int(percent*100)}%")
                sys.stdout.flush()
                time.sleep(self.speed)

            print("\n✔ Finalizado")