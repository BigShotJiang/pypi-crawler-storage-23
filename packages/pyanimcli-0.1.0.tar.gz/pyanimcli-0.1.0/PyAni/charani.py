import sys
import time
import threading

class CharAni:
    def __init__(self, sequence, looping=True, speed=0.1):
        self.sequence = sequence
        self.looping = looping
        self.speed = speed
        self._running = False

    def start(self, text=""):
        self._running = True

        def run():
            i = 0
            while self._running:
                char = self.sequence[i % len(self.sequence)]
                sys.stdout.write(f"\r{text} {char}")
                sys.stdout.flush()
                i += 1
                time.sleep(self.speed)
                if not self.looping and i >= len(self.sequence):
                    break

        self.thread = threading.Thread(target=run)
        self.thread.start()

    def stop(self):
        self._running = False
        self.thread.join()
        print()