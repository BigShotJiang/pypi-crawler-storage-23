from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="vuzo",
    version="0.1.1",
    author="Vuzo",
    author_email="support@vuzo.com",
    description="Official Python SDK for Vuzo API - unified access to OpenAI, xAI (Grok), and Google models",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/AurissoRnD/vuzo-unifai",
    project_urls={
        "Bug Tracker": "https://github.com/AurissoRnD/vuzo-unifai/issues",
        "Documentation": "https://github.com/AurissoRnD/vuzo-unifai#readme",
        "Source Code": "https://github.com/AurissoRnD/vuzo-unifai",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.31.0",
        "pydantic>=2.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
            "responses>=0.23.0",
        ],
    },
    keywords="vuzo llm ai openai xai grok google gemini gpt api sdk",
)
