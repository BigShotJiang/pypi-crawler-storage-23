"""
Vuzo Python SDK
===============

Official Python SDK for Vuzo API - unified access to OpenAI, Anthropic, and Google models.

Quick Start:
    >>> from vuzo import Vuzo
    >>> client = Vuzo("vz-sk_your_key_here")
    >>> response = client.chat.complete("gpt-4o-mini", "Hello!")
    >>> print(response)

Documentation: https://github.com/AurissoRnD/vuzo-python
"""

__version__ = "0.1.1"

from .client import Vuzo
from .exceptions import (
    VuzoError,
    AuthenticationError,
    InsufficientCreditsError,
    RateLimitError,
    InvalidRequestError,
    APIError,
)
from .types import (
    ChatResponse,
    ChatChunk,
    ChatMessage,
    ModelInfo,
    UsageLog,
    UsageSummary,
    DailyUsage,
    Transaction,
    APIKeyResponse,
    APIKeyInfo,
)

__all__ = [
    "Vuzo",
    "VuzoError",
    "AuthenticationError",
    "InsufficientCreditsError",
    "RateLimitError",
    "InvalidRequestError",
    "APIError",
    "ChatResponse",
    "ChatChunk",
    "ChatMessage",
    "ModelInfo",
    "UsageLog",
    "UsageSummary",
    "DailyUsage",
    "Transaction",
    "APIKeyResponse",
    "APIKeyInfo",
]
