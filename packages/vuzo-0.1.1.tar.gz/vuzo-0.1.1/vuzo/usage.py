"""Usage analytics module."""

from typing import List, Optional
from .types import UsageLog, UsageSummary, DailyUsage


class Usage:
    """Handle usage analytics requests."""
    
    def __init__(self, client):
        self._client = client
    
    def list(
        self,
        limit: int = 50,
        offset: int = 0,
        model: Optional[str] = None,
        provider: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[UsageLog]:
        """
        Get usage logs.
        
        Args:
            limit: Maximum number of logs to return (1-200)
            offset: Number of logs to skip
            model: Filter by model name
            provider: Filter by provider (openai, anthropic, google)
            start_date: Filter by start date (ISO format)
            end_date: Filter by end date (ISO format)
            
        Returns:
            List of UsageLog objects
            
        Example:
            >>> logs = client.usage.list(limit=10, model="gpt-4o-mini")
            >>> for log in logs:
            ...     print(f"{log.created_at}: {log.total_tokens} tokens, ${log.vuzo_cost}")
        """
        params = {"limit": limit, "offset": offset}
        if model:
            params["model"] = model
        if provider:
            params["provider"] = provider
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date
        
        response = self._client._get("/usage", params=params)
        return [UsageLog(**log) for log in response.json()]
    
    def summary(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> UsageSummary:
        """
        Get aggregated usage summary.
        
        Args:
            start_date: Filter by start date (ISO format)
            end_date: Filter by end date (ISO format)
            
        Returns:
            UsageSummary object
            
        Example:
            >>> summary = client.usage.summary()
            >>> print(f"Total requests: {summary.total_requests}")
            >>> print(f"Total cost: ${summary.total_vuzo_cost}")
        """
        params = {}
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date
        
        response = self._client._get("/usage/summary", params=params)
        return UsageSummary(**response.json())
    
    def daily(
        self,
        model: Optional[str] = None,
        provider: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[DailyUsage]:
        """
        Get daily aggregated usage.
        
        Args:
            model: Filter by model name
            provider: Filter by provider
            start_date: Filter by start date (ISO format)
            end_date: Filter by end date (ISO format)
            
        Returns:
            List of DailyUsage objects
            
        Example:
            >>> daily = client.usage.daily(start_date="2026-02-11")
            >>> for day in daily:
            ...     print(f"{day.date}: {day.total_requests} requests, ${day.total_cost}")
        """
        params = {}
        if model:
            params["model"] = model
        if provider:
            params["provider"] = provider
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date
        
        response = self._client._get("/usage/daily", params=params)
        return [DailyUsage(**day) for day in response.json()]
