"""Type definitions for Vuzo SDK."""

from typing import List, Optional, Literal
from pydantic import BaseModel, Field
from datetime import datetime


# Chat Completions

class ChatMessage(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str


class ChatUsage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class ChatChoice(BaseModel):
    index: int
    message: ChatMessage
    finish_reason: Optional[str] = None


class ChatResponse(BaseModel):
    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: List[ChatChoice]
    usage: ChatUsage


class ChatDelta(BaseModel):
    role: Optional[str] = None
    content: Optional[str] = None


class ChatChunkChoice(BaseModel):
    index: int
    delta: ChatDelta
    finish_reason: Optional[str] = None


class ChatChunk(BaseModel):
    id: str
    object: str = "chat.completion.chunk"
    created: int
    model: str
    choices: List[ChatChunkChoice]


# Models

class ModelInfo(BaseModel):
    provider: str
    model_name: str
    input_price_per_million: float
    output_price_per_million: float
    vuzo_input_price_per_million: float
    vuzo_output_price_per_million: float
    vuzo_markup_percent: float


# Usage

class UsageLog(BaseModel):
    id: str
    provider: str
    model: str
    input_tokens: int
    output_tokens: int
    total_tokens: int
    provider_cost: float
    vuzo_cost: float
    response_time_ms: int
    created_at: datetime


class UsageSummary(BaseModel):
    total_requests: int
    total_input_tokens: int
    total_output_tokens: int
    total_tokens: int
    total_provider_cost: float
    total_vuzo_cost: float


class DailyUsage(BaseModel):
    date: str
    model: str
    provider: str
    total_requests: int
    input_tokens: int
    output_tokens: int
    total_cost: float


# Billing

class BalanceResponse(BaseModel):
    user_id: str
    balance: float


class TopUpResponse(BaseModel):
    user_id: str
    amount: float
    new_balance: float
    transaction_id: str


class Transaction(BaseModel):
    id: str
    amount: float
    type: Literal["topup", "usage", "refund"]
    description: str
    created_at: datetime


# API Keys

class APIKeyResponse(BaseModel):
    id: str
    name: str
    key: str = Field(description="Full API key - shown only once")
    key_prefix: str
    created_at: datetime


class APIKeyInfo(BaseModel):
    id: str
    name: str
    key_prefix: str
    is_active: bool
    rate_limit_rpm: int
    created_at: datetime
    last_used_at: Optional[datetime] = None
