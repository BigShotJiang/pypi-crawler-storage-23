"""Billing module for balance and transactions."""

from typing import List
from .types import BalanceResponse, TopUpResponse, Transaction


class Billing:
    """Handle billing operations."""
    
    def __init__(self, client):
        self._client = client
    
    def get_balance(self) -> float:
        """
        Get current credit balance.
        
        Returns:
            Balance in USD
            
        Example:
            >>> balance = client.billing.get_balance()
            >>> print(f"Balance: ${balance}")
        """
        response = self._client._get("/billing/balance")
        data = BalanceResponse(**response.json())
        return data.balance
    
    def top_up(self, amount: float) -> TopUpResponse:
        """
        Add credits to account.
        
        Args:
            amount: Amount in USD to add
            
        Returns:
            TopUpResponse with new balance and transaction ID
            
        Example:
            >>> result = client.billing.top_up(10.0)
            >>> print(f"New balance: ${result.new_balance}")
        """
        response = self._client._post("/billing/topup", json={"amount": amount})
        return TopUpResponse(**response.json())
    
    def transactions(
        self,
        limit: int = 50,
        offset: int = 0
    ) -> List[Transaction]:
        """
        Get transaction history.
        
        Args:
            limit: Maximum number of transactions to return
            offset: Number of transactions to skip
            
        Returns:
            List of Transaction objects
            
        Example:
            >>> transactions = client.billing.transactions(limit=10)
            >>> for tx in transactions:
            ...     print(f"{tx.created_at}: {tx.type} ${tx.amount}")
        """
        params = {"limit": limit, "offset": offset}
        response = self._client._get("/billing/transactions", params=params)
        return [Transaction(**tx) for tx in response.json()]
