"""Models module for listing available models."""

from typing import List
from .types import ModelInfo


class Models:
    """Handle model information requests."""
    
    def __init__(self, client):
        self._client = client
    
    def list(self) -> List[ModelInfo]:
        """
        Get all available models with pricing information.
        
        Returns:
            List of ModelInfo objects
            
        Example:
            >>> models = client.models.list()
            >>> for model in models:
            ...     print(f"{model.model_name}: ${model.vuzo_input_price_per_million}/M input")
        """
        response = self._client._get("/models")
        return [ModelInfo(**model) for model in response.json()]
    
    def get(self, model_name: str) -> ModelInfo:
        """
        Get specific model details.
        
        Args:
            model_name: Name of the model (e.g., "gpt-4o-mini")
            
        Returns:
            ModelInfo object
            
        Example:
            >>> model = client.models.get("gpt-4o-mini")
            >>> print(f"Input: ${model.vuzo_input_price_per_million}/M")
        """
        models = self.list()
        for model in models:
            if model.model_name == model_name:
                return model
        raise ValueError(f"Model '{model_name}' not found")
