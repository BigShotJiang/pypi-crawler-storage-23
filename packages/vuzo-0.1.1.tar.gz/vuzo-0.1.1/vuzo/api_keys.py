"""API keys management module."""

from typing import List
from .types import APIKeyResponse, APIKeyInfo


class APIKeys:
    """Handle API key management."""
    
    def __init__(self, client):
        self._client = client
    
    def create(self, name: str = "Default") -> APIKeyResponse:
        """
        Create a new API key.
        
        Args:
            name: Name for the API key
            
        Returns:
            APIKeyResponse with the full key (shown only once)
            
        Example:
            >>> key = client.api_keys.create("Production")
            >>> print(f"Key: {key.key}")
            >>> print("Save this key - it won't be shown again!")
        """
        response = self._client._post("/api-keys", json={"name": name})
        return APIKeyResponse(**response.json())
    
    def list(self) -> List[APIKeyInfo]:
        """
        List all API keys.
        
        Returns:
            List of APIKeyInfo objects
            
        Example:
            >>> keys = client.api_keys.list()
            >>> for key in keys:
            ...     status = "active" if key.is_active else "revoked"
            ...     print(f"{key.name} ({key.key_prefix}...): {status}")
        """
        response = self._client._get("/api-keys")
        return [APIKeyInfo(**key) for key in response.json()]
    
    def delete(self, key_id: str) -> None:
        """
        Revoke an API key.
        
        Args:
            key_id: ID of the key to revoke
            
        Example:
            >>> client.api_keys.delete("key_id_here")
            >>> print("Key revoked successfully")
        """
        self._client._delete(f"/api-keys/{key_id}")
