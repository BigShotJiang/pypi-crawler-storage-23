"""Custom exceptions for Vuzo SDK."""


class VuzoError(Exception):
    """Base exception for all Vuzo SDK errors."""
    pass


class AuthenticationError(VuzoError):
    """Raised when API key is invalid or missing."""
    pass


class InsufficientCreditsError(VuzoError):
    """Raised when account has insufficient credits."""
    pass


class RateLimitError(VuzoError):
    """Raised when rate limit is exceeded."""
    pass


class InvalidRequestError(VuzoError):
    """Raised when request parameters are invalid."""
    pass


class APIError(VuzoError):
    """Raised when API returns an error."""
    
    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response
