"""Domain layer for IntentGraph."""
