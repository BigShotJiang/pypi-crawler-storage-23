"""Application layer for IntentGraph."""
