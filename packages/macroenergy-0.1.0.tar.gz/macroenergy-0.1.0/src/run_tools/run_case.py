from __future__ import annotations

from pathlib import Path
from typing import Any

from setup.julia_setup import _jl


def run_case(case_path: str | Path = ".", **kwargs: Any) -> tuple[Any, Any]:
    """Run `MacroEnergy.run_case` and return `(systems, solution)`.

    Parameters mirror `MacroEnergy.jl` `run_case` with passthrough keyword arguments.
    """
    macroenergy = _macroenergy_module()
    result = macroenergy.run_case(str(case_path), **kwargs)

    if isinstance(result, tuple) and len(result) == 2:
        return result

    return tuple(result)


def _macroenergy_module() -> Any:
    jl = _jl()
    jl.seval("using MacroEnergy")
    return jl.MacroEnergy
