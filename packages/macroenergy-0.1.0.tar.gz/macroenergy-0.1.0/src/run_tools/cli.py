from __future__ import annotations

import argparse

from setup import compile_macroenergy_jl, install_macroenergy_jl, setup_macroenergy_jl


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="macroenergy-setup",
        description="Install and compile MacroEnergy.jl from Python.",
    )
    parser.add_argument(
        "--project-path",
        default=None,
        help="Optional Julia project path to activate before running commands.",
    )
    parser.add_argument(
        "--url",
        default=None,
        help="Optional git URL for installing MacroEnergy.jl from source.",
    )
    parser.add_argument(
        "--rev",
        default=None,
        help="Optional git revision (branch, tag, commit) used with --url.",
    )
    parser.add_argument(
        "--install-only",
        action="store_true",
        help="Only install MacroEnergy.jl.",
    )
    parser.add_argument(
        "--compile-only",
        action="store_true",
        help="Only compile/load MacroEnergy.jl.",
    )
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.install_only and args.compile_only:
        parser.error("--install-only and --compile-only cannot be used together")

    if args.install_only:
        install_macroenergy_jl(project_path=args.project_path, url=args.url, rev=args.rev)
        return 0

    if args.compile_only:
        compile_macroenergy_jl(project_path=args.project_path)
        return 0

    setup_macroenergy_jl(project_path=args.project_path, url=args.url, rev=args.rev)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
