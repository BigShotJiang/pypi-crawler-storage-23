from __future__ import annotations

import pytest

from macroenergy import setup_macroenergy_jl


pytestmark = pytest.mark.integration


def test_setup_macroenergy_jl_installs_and_compiles_package() -> None:
    setup_macroenergy_jl(
        url="https://github.com/macroenergy/MacroEnergy.jl",
        rev="main",
    )
