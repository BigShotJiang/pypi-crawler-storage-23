from __future__ import annotations

import pytest

from macroenergy import list_examples


pytestmark = pytest.mark.integration


def test_list_examples_returns_real_list_of_strings():
    examples = list_examples()

    assert isinstance(examples, list)
    assert len(examples) > 0
    assert all(isinstance(item, str) for item in examples)
