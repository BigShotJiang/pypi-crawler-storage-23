from __future__ import annotations

import examples.examples as examples_module


class _FakeMacroEnergy:
    def __init__(self) -> None:
        self.received_auth = None

    def list_examples(self, *, auth=None):
        self.received_auth = auth
        return ["simple_case", "policy_case"]


def test_list_examples_returns_list_of_strings(monkeypatch):
    fake = _FakeMacroEnergy()
    monkeypatch.setattr(examples_module, "_macroenergy_module", lambda: fake)

    result = examples_module.list_examples()

    assert isinstance(result, list)
    assert result == ["simple_case", "policy_case"]
    assert all(isinstance(item, str) for item in result)


def test_list_examples_passes_auth_through(monkeypatch):
    fake = _FakeMacroEnergy()
    monkeypatch.setattr(examples_module, "_macroenergy_module", lambda: fake)
    auth_object = object()

    examples_module.list_examples(auth=auth_object)

    assert fake.received_auth is auth_object
