# gds-stockflow

Declarative stock-flow DSL over GDS semantics.
