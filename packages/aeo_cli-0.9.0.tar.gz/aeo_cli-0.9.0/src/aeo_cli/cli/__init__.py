"""CLI command package — registers all commands onto the Typer app."""
