"""CI/CD integration utilities for AEO audits."""
