# mrhzr-tools
習作を兼ねた使い回し用のツール群

## 機能
名前空間 : mrhzr
- config_manager : YAML 形式のコンフィグファイルの読み込み
  - set_config(path="config.yaml") : コンフィグファイルの読み込み
  - get_config(section=None, default=None) : 指定セクションのコンフィグ取得
- log : ログの管理
  - init_log() : 初期設定。必ず最初に実行すること
  - get_logger(name : str) : ロガーの取得

## インストール方法
PyPIからのインストールの場合

```bash
pip install mrhzr-tools
```

## 依存関係
このパッケージは以下の環境での動作確認をしています:
- Python 3.8+
- PyYAML
- pathlib

## ライセンス
このライブラリは [MIT ライセンス](LICENSE)のもとで公開されています。