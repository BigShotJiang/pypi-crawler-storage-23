from mrhzr.tools import config_manager, log

config_manager.set_config("config.yaml")

config = config_manager.get_config("test")
log.init_log()

print(config)

logger = log.get_logger(__name__)

logger.debug("test debug")
logger.info("test info")
logger.warning("test worning")
logger.error("test error")
logger.critical("test critical")