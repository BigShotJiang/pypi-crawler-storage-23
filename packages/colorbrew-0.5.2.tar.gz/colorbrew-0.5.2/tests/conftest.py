"""Shared fixtures for the ColorBrew test suite."""
