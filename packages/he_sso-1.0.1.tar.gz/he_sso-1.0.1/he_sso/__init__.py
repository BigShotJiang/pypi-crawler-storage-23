"""he-sso: HappyElements SSO 客户端库。

提供函数 API 和 CLI 工具，用于在脚本或应用中获取当前用户的 SSO 认证信息。

函数 API 用法::

    from he_sso import get_user_info, logout

    info = get_user_info()
    print(info["email"])

    logout()  # 清除本地缓存

CLI 用法::

    he-sso          # 输出用户信息
    he-sso --json   # JSON 格式输出（含 token）
    he-sso --help   # 查看所有选项
"""

from ._auth import DEFAULT_SERVICE_URL, get_user_info, logout

__all__ = [
    "get_user_info",
    "logout",
    "DEFAULT_SERVICE_URL",
]
