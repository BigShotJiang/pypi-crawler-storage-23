"""
凭证文件存取

Token 和用户信息保存在 ~/.config/happyelements-sso/credentials.json，
目录权限 0o700，文件权限 0o600。
"""

from __future__ import annotations

import json
import os
import sys

# 支持通过环境变量覆盖凭证目录
_TOKEN_DIR = os.environ.get(
    "SSO_TOKEN_DIR",
    os.path.join(os.path.expanduser("~"), ".config", "happyelements-sso"),
)
_TOKEN_FILE = os.path.join(_TOKEN_DIR, "credentials.json")


def save_token(token: str, user_info: dict) -> bool:
    """将 token 和用户信息持久化到本地凭证文件。

    Args:
        token: SSO 颁发的个人 token。
        user_info: 服务端返回的用户信息字典。

    Returns:
        保存成功返回 True，否则返回 False。
    """
    try:
        os.makedirs(_TOKEN_DIR, mode=0o700, exist_ok=True)
        data = {"token": token, "user_info": user_info}
        with open(_TOKEN_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.chmod(_TOKEN_FILE, 0o600)
        return True
    except Exception as e:
        print(f"❌ 保存凭证失败: {e}", file=sys.stderr)
        return False


def load_token() -> tuple[str | None, dict | None]:
    """从本地凭证文件加载 token 和用户信息。

    Returns:
        (token, user_info) 元组；文件不存在或解析失败时返回 (None, None)。
    """
    try:
        if not os.path.exists(_TOKEN_FILE):
            return None, None
        with open(_TOKEN_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("token"), data.get("user_info")
    except Exception as e:
        print(f"⚠️  加载凭证失败: {e}", file=sys.stderr)
        return None, None


def delete_token() -> bool:
    """删除本地凭证文件。

    Returns:
        文件存在并成功删除返回 True，文件不存在返回 False。
    """
    try:
        if os.path.exists(_TOKEN_FILE):
            os.remove(_TOKEN_FILE)
            return True
        return False
    except Exception as e:
        print(f"⚠️  删除凭证失败: {e}", file=sys.stderr)
        return False
