"""CLI 入口，薄封装层，所有业务逻辑委托给函数 API。"""

from __future__ import annotations

import json
import sys

import click

from ._auth import DEFAULT_SERVICE_URL, get_user_info, logout


@click.command()
@click.option(
    "--service-url",
    default=DEFAULT_SERVICE_URL,
    envvar="SSO_SERVICE_URL",
    show_default=True,
    help="SSO 服务根 URL",
)
@click.option("--no-browser", is_flag=True, help="不自动打开浏览器，打印 URL 手动访问")
@click.option("--json", "json_output", is_flag=True, help="以 JSON 格式输出（含 token）")
@click.option("--delete", is_flag=True, help="删除本地缓存的 token")
@click.option("--refresh", is_flag=True, help="忽略本地缓存，强制重新登录")
def main(service_url: str, no_browser: bool, json_output: bool, delete: bool, refresh: bool) -> None:
    """SSO 用户信息获取工具。

    默认使用本地缓存 token，验证有效后直接输出；token 不存在或失效时自动重新登录。

    \b
    示例:
        he-sso                              # 输出用户信息
        he-sso --refresh                    # 强制重新登录
        he-sso --json                       # JSON 格式输出（含 token）
        he-sso --delete                     # 删除本地缓存
        he-sso --service-url https://...    # 指定服务地址
    """
    if delete:
        if logout():
            click.echo("✅ 本地 token 已删除", err=True)
        else:
            click.echo("⚠️  未找到本地缓存的 token", err=True)
        return

    try:
        info = get_user_info(
            service_url=service_url,
            refresh=refresh,
            open_browser=not no_browser,
        )
    except KeyboardInterrupt:
        click.echo("\n\n⚠️  操作已取消", err=True)
        sys.exit(1)
    except RuntimeError as e:
        click.echo(f"\n❌ 错误: {e}", err=True)
        sys.exit(1)

    if json_output:
        print(json.dumps(info, ensure_ascii=False, indent=2))
        return

    click.echo("\n✅ 认证成功!\n")
    click.echo("👤 用户信息:")
    click.echo(f"   用户名: {info.get('username', 'N/A')}")
    click.echo(f"   工号:   {info.get('unique_id', 'N/A')}")
    if info.get("email"):
        click.echo(f"   邮箱:   {info['email']}")
    if info.get("mobile"):
        area = info.get("mobile_area_code", "")
        click.echo(f"   手机:   {area} {info['mobile']}")
    if info.get("account_type"):
        click.echo(f"   账户类型: {info['account_type']}")
    if info.get("login_channel"):
        click.echo(f"   登录方式: {info['login_channel']}")
    click.echo()
