"""SSO 认证流程与公共函数 API（内部模块）。"""

from __future__ import annotations

import sys
import webbrowser

from ._api import (
    _get_api_base,
    create_session,
    get_login_url,
    poll_until_ready,
    verify_token,
)
from ._credentials import delete_token, load_token, save_token

DEFAULT_SERVICE_URL = "https://it.kxxxl.com"


def _login(service_url: str, *, open_browser: bool = True) -> tuple[str, dict]:
    """执行完整的浏览器 SSO 登录流程，返回 (token, user_info)。

    Raises:
        RuntimeError: 服务请求失败、session 过期或超时。
    """
    try:
        api_base = _get_api_base(service_url)
        session_id = create_session(api_base)
        login_url = get_login_url(api_base, session_id)

        print(f"🌐 登录 URL: {login_url}", file=sys.stderr)

        if open_browser:
            print("🚀 正在打开浏览器...", file=sys.stderr)
            webbrowser.open(login_url)
        else:
            print("请手动访问以上 URL 完成登录", file=sys.stderr)

        print("⏳ 等待认证完成...", file=sys.stderr)
        data = poll_until_ready(api_base, session_id)

        token = data.get("token")
        user_info = data.get("user_info")
        if not token or not user_info:
            raise RuntimeError("服务端返回数据格式无效")

        return token, user_info

    except Exception as exc:
        if isinstance(exc, RuntimeError):
            raise
        raise RuntimeError(f"请求 SSO 服务失败: {exc}") from exc


def get_user_info(
    service_url: str = DEFAULT_SERVICE_URL,
    *,
    refresh: bool = False,
    open_browser: bool = True,
) -> dict:
    """获取当前用户信息，自动处理 token 缓存与刷新。

    优先使用本地缓存 token 并向服务端验证；token 不存在、已失效或指定
    ``refresh=True`` 时，自动打开浏览器完成 SSO 登录并缓存新 token。

    Args:
        service_url: SSO 服务根 URL，默认读取 ``SSO_SERVICE_URL`` 环境变量，
            否则使用内置默认地址。
        refresh: 是否忽略本地缓存，强制重新登录。
        open_browser: 是否自动打开系统浏览器。设为 False 时打印登录 URL 供手动访问。

    Returns:
        包含用户信息的字典，结构示例::

            {
                "username": "张三",
                "unique_id": "12345",
                "email": "zhangsan@example.com",
                "mobile": "13800138000",
                "mobile_area_code": "+86",
                "account_type": "employee",
                "login_channel": "wework",
                "token": "<sso-token>",
            }

    Raises:
        RuntimeError: 网络错误、SSO 超时或服务端返回异常。

    Example::

        from he_sso import get_user_info

        info = get_user_info()
        print(info["email"])

        # 强制刷新
        info = get_user_info(refresh=True)

        # 自定义服务地址
        info = get_user_info(service_url="https://sso.example.com")
    """
    import os

    resolved_url = os.environ.get("SSO_SERVICE_URL", service_url)

    if not refresh:
        token, _ = load_token()
        if token:
            user_info = verify_token(resolved_url, token)
            if user_info:
                return {**user_info, "token": token}

    token, user_info = _login(resolved_url, open_browser=open_browser)
    save_token(token, user_info)
    return {**user_info, "token": token}


def logout() -> bool:
    """删除本地缓存的 token。

    Returns:
        成功删除返回 True，本地无缓存返回 False。
    """
    return delete_token()
