"""
Module entry point for doc-fetch.
"""
from .cli import main

if __name__ == "__main__":
    main()