from datahub import *

with Daqbuf(backend="sls-archiver", cbor=False) as source:

    stdout = Stdout()
    source.add_listener(stdout)

    source.req(
        [ "ARS05-VCOL-0390:TRX-GAP",
          "ARS05-VCOL-0390:TRX-GAP-PosAct",
          "ARS05-VCOL-0450:TRY-GAP",
          "ARS05-VCOL-0450:TRY-GAP-PosAct"
        ],
        "2025-03-01 00:00",
        "2025-10-15 00:00",
        bins=None,
        backend="sls-archiver")