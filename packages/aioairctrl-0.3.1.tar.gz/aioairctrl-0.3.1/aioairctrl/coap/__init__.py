from aioairctrl.coap.client import Client  # noqa: F401
