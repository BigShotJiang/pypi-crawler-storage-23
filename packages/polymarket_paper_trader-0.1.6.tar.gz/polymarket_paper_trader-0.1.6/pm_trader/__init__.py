"""pm-trader: 1:1 faithful Polymarket paper trading simulator for AI agents."""
