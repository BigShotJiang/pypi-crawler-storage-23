def main():
    print("Hello from eidos-engine!")


if __name__ == "__main__":
    main()
