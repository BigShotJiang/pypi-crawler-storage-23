"""Recursivist: A directory structure visualization tool."""

__version__ = "1.4.8"
__author__ = "Armaanjeet Singh Sandhu"
__license__ = "MIT"
__email__ = "armaanjeetsandhu430@gmail.com"
