# Security Policy

To report a security vulnerability, email nico@sidequery.dev.
