# Generated from sidemantic/adapters/holistics_grammar/HolisticsParser.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,53,408,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,46,
        7,46,1,0,5,0,96,8,0,10,0,12,0,99,9,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,
        1,1,1,1,1,1,1,1,3,1,112,8,1,1,2,1,2,1,2,1,2,1,3,1,3,1,3,1,4,1,4,
        1,5,1,5,1,5,1,5,1,6,1,6,1,6,1,6,1,6,3,6,132,8,6,1,7,1,7,1,7,1,7,
        1,7,3,7,139,8,7,1,8,1,8,1,8,1,8,3,8,145,8,8,1,9,1,9,1,9,3,9,150,
        8,9,1,9,3,9,153,8,9,1,10,1,10,3,10,157,8,10,1,11,1,11,1,11,1,11,
        5,11,163,8,11,10,11,12,11,166,9,11,1,11,1,11,1,12,1,12,1,12,3,12,
        173,8,12,1,13,1,13,1,13,1,13,3,13,179,8,13,1,13,1,13,1,13,3,13,184,
        8,13,1,13,1,13,1,14,1,14,1,14,5,14,191,8,14,10,14,12,14,194,9,14,
        1,15,1,15,1,15,3,15,199,8,15,1,15,1,15,3,15,203,8,15,1,16,1,16,1,
        16,5,16,208,8,16,10,16,12,16,211,9,16,1,17,1,17,3,17,215,8,17,1,
        18,1,18,3,18,219,8,18,1,19,1,19,5,19,223,8,19,10,19,12,19,226,9,
        19,1,19,1,19,1,20,1,20,1,21,1,21,1,21,5,21,235,8,21,10,21,12,21,
        238,9,21,1,22,1,22,1,22,5,22,243,8,22,10,22,12,22,246,9,22,1,23,
        1,23,1,23,5,23,251,8,23,10,23,12,23,254,9,23,1,24,1,24,1,24,5,24,
        259,8,24,10,24,12,24,262,9,24,1,25,1,25,1,25,5,25,267,8,25,10,25,
        12,25,270,9,25,1,26,1,26,1,26,5,26,275,8,26,10,26,12,26,278,9,26,
        1,27,1,27,1,27,3,27,283,8,27,1,28,1,28,1,28,1,28,1,28,1,28,1,28,
        1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,3,28,302,8,28,
        1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,3,29,312,8,29,3,29,314,8,
        29,1,30,1,30,1,30,1,31,1,31,1,32,1,32,1,32,1,32,1,32,1,32,1,32,5,
        32,328,8,32,10,32,12,32,331,9,32,3,32,333,8,32,1,32,4,32,336,8,32,
        11,32,12,32,337,1,33,1,33,1,33,1,33,1,33,1,33,1,33,1,33,3,33,348,
        8,33,1,34,1,34,1,35,1,35,1,35,1,35,1,35,5,35,357,8,35,10,35,12,35,
        360,9,35,3,35,362,8,35,1,35,1,35,1,36,1,36,3,36,368,8,36,1,37,1,
        37,1,37,1,37,1,38,1,38,1,38,1,38,5,38,378,8,38,10,38,12,38,381,9,
        38,3,38,383,8,38,1,38,1,38,1,39,1,39,1,40,1,40,1,40,4,40,392,8,40,
        11,40,12,40,393,1,41,1,41,1,42,1,42,1,43,1,43,1,44,1,44,1,45,1,45,
        1,46,1,46,1,46,0,0,47,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,
        32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,
        76,78,80,82,84,86,88,90,92,0,8,2,0,1,11,50,50,1,0,31,32,1,0,33,36,
        2,0,38,38,47,47,1,0,39,41,2,0,44,44,47,47,1,0,17,18,3,0,1,11,13,
        19,50,50,421,0,97,1,0,0,0,2,111,1,0,0,0,4,113,1,0,0,0,6,117,1,0,
        0,0,8,120,1,0,0,0,10,122,1,0,0,0,12,126,1,0,0,0,14,133,1,0,0,0,16,
        140,1,0,0,0,18,146,1,0,0,0,20,156,1,0,0,0,22,158,1,0,0,0,24,169,
        1,0,0,0,26,174,1,0,0,0,28,187,1,0,0,0,30,195,1,0,0,0,32,204,1,0,
        0,0,34,214,1,0,0,0,36,216,1,0,0,0,38,220,1,0,0,0,40,229,1,0,0,0,
        42,231,1,0,0,0,44,239,1,0,0,0,46,247,1,0,0,0,48,255,1,0,0,0,50,263,
        1,0,0,0,52,271,1,0,0,0,54,282,1,0,0,0,56,301,1,0,0,0,58,303,1,0,
        0,0,60,315,1,0,0,0,62,318,1,0,0,0,64,320,1,0,0,0,66,347,1,0,0,0,
        68,349,1,0,0,0,70,351,1,0,0,0,72,367,1,0,0,0,74,369,1,0,0,0,76,373,
        1,0,0,0,78,386,1,0,0,0,80,388,1,0,0,0,82,395,1,0,0,0,84,397,1,0,
        0,0,86,399,1,0,0,0,88,401,1,0,0,0,90,403,1,0,0,0,92,405,1,0,0,0,
        94,96,3,2,1,0,95,94,1,0,0,0,96,99,1,0,0,0,97,95,1,0,0,0,97,98,1,
        0,0,0,98,100,1,0,0,0,99,97,1,0,0,0,100,101,5,0,0,1,101,1,1,0,0,0,
        102,112,3,4,2,0,103,112,3,6,3,0,104,112,3,10,5,0,105,112,3,12,6,
        0,106,112,3,14,7,0,107,112,3,16,8,0,108,112,3,18,9,0,109,112,3,26,
        13,0,110,112,3,36,18,0,111,102,1,0,0,0,111,103,1,0,0,0,111,104,1,
        0,0,0,111,105,1,0,0,0,111,106,1,0,0,0,111,107,1,0,0,0,111,108,1,
        0,0,0,111,109,1,0,0,0,111,110,1,0,0,0,112,3,1,0,0,0,113,114,3,8,
        4,0,114,115,3,92,46,0,115,116,3,38,19,0,116,5,1,0,0,0,117,118,3,
        8,4,0,118,119,3,38,19,0,119,7,1,0,0,0,120,121,7,0,0,0,121,9,1,0,
        0,0,122,123,3,92,46,0,123,124,5,27,0,0,124,125,3,40,20,0,125,11,
        1,0,0,0,126,127,5,14,0,0,127,128,3,92,46,0,128,129,5,37,0,0,129,
        131,3,40,20,0,130,132,5,46,0,0,131,130,1,0,0,0,131,132,1,0,0,0,132,
        13,1,0,0,0,133,134,3,8,4,0,134,135,3,92,46,0,135,136,5,37,0,0,136,
        138,3,40,20,0,137,139,5,46,0,0,138,137,1,0,0,0,138,139,1,0,0,0,139,
        15,1,0,0,0,140,141,3,92,46,0,141,142,5,37,0,0,142,144,3,40,20,0,
        143,145,5,46,0,0,144,143,1,0,0,0,144,145,1,0,0,0,145,17,1,0,0,0,
        146,147,5,13,0,0,147,149,3,20,10,0,148,150,3,22,11,0,149,148,1,0,
        0,0,149,150,1,0,0,0,150,152,1,0,0,0,151,153,5,46,0,0,152,151,1,0,
        0,0,152,153,1,0,0,0,153,19,1,0,0,0,154,157,3,80,40,0,155,157,3,92,
        46,0,156,154,1,0,0,0,156,155,1,0,0,0,157,21,1,0,0,0,158,159,5,21,
        0,0,159,164,3,24,12,0,160,161,5,28,0,0,161,163,3,24,12,0,162,160,
        1,0,0,0,163,166,1,0,0,0,164,162,1,0,0,0,164,165,1,0,0,0,165,167,
        1,0,0,0,166,164,1,0,0,0,167,168,5,22,0,0,168,23,1,0,0,0,169,172,
        3,92,46,0,170,171,5,27,0,0,171,173,3,92,46,0,172,170,1,0,0,0,172,
        173,1,0,0,0,173,25,1,0,0,0,174,175,5,8,0,0,175,176,3,92,46,0,176,
        178,5,25,0,0,177,179,3,28,14,0,178,177,1,0,0,0,178,179,1,0,0,0,179,
        180,1,0,0,0,180,183,5,26,0,0,181,182,5,30,0,0,182,184,3,32,16,0,
        183,181,1,0,0,0,183,184,1,0,0,0,184,185,1,0,0,0,185,186,3,38,19,
        0,186,27,1,0,0,0,187,192,3,30,15,0,188,189,5,28,0,0,189,191,3,30,
        15,0,190,188,1,0,0,0,191,194,1,0,0,0,192,190,1,0,0,0,192,193,1,0,
        0,0,193,29,1,0,0,0,194,192,1,0,0,0,195,198,3,92,46,0,196,197,5,27,
        0,0,197,199,3,32,16,0,198,196,1,0,0,0,198,199,1,0,0,0,199,202,1,
        0,0,0,200,201,5,37,0,0,201,203,3,40,20,0,202,200,1,0,0,0,202,203,
        1,0,0,0,203,31,1,0,0,0,204,209,3,34,17,0,205,206,5,45,0,0,206,208,
        3,34,17,0,207,205,1,0,0,0,208,211,1,0,0,0,209,207,1,0,0,0,209,210,
        1,0,0,0,210,33,1,0,0,0,211,209,1,0,0,0,212,215,3,92,46,0,213,215,
        3,84,42,0,214,212,1,0,0,0,214,213,1,0,0,0,215,35,1,0,0,0,216,218,
        3,40,20,0,217,219,5,46,0,0,218,217,1,0,0,0,218,219,1,0,0,0,219,37,
        1,0,0,0,220,224,5,21,0,0,221,223,3,2,1,0,222,221,1,0,0,0,223,226,
        1,0,0,0,224,222,1,0,0,0,224,225,1,0,0,0,225,227,1,0,0,0,226,224,
        1,0,0,0,227,228,5,22,0,0,228,39,1,0,0,0,229,230,3,42,21,0,230,41,
        1,0,0,0,231,236,3,44,22,0,232,233,5,43,0,0,233,235,3,44,22,0,234,
        232,1,0,0,0,235,238,1,0,0,0,236,234,1,0,0,0,236,237,1,0,0,0,237,
        43,1,0,0,0,238,236,1,0,0,0,239,244,3,46,23,0,240,241,5,42,0,0,241,
        243,3,46,23,0,242,240,1,0,0,0,243,246,1,0,0,0,244,242,1,0,0,0,244,
        245,1,0,0,0,245,45,1,0,0,0,246,244,1,0,0,0,247,252,3,48,24,0,248,
        249,7,1,0,0,249,251,3,48,24,0,250,248,1,0,0,0,251,254,1,0,0,0,252,
        250,1,0,0,0,252,253,1,0,0,0,253,47,1,0,0,0,254,252,1,0,0,0,255,260,
        3,50,25,0,256,257,7,2,0,0,257,259,3,50,25,0,258,256,1,0,0,0,259,
        262,1,0,0,0,260,258,1,0,0,0,260,261,1,0,0,0,261,49,1,0,0,0,262,260,
        1,0,0,0,263,268,3,52,26,0,264,265,7,3,0,0,265,267,3,52,26,0,266,
        264,1,0,0,0,267,270,1,0,0,0,268,266,1,0,0,0,268,269,1,0,0,0,269,
        51,1,0,0,0,270,268,1,0,0,0,271,276,3,54,27,0,272,273,7,4,0,0,273,
        275,3,54,27,0,274,272,1,0,0,0,275,278,1,0,0,0,276,274,1,0,0,0,276,
        277,1,0,0,0,277,53,1,0,0,0,278,276,1,0,0,0,279,280,7,5,0,0,280,283,
        3,54,27,0,281,283,3,56,28,0,282,279,1,0,0,0,282,281,1,0,0,0,283,
        55,1,0,0,0,284,302,3,58,29,0,285,302,3,64,32,0,286,302,3,70,35,0,
        287,302,3,78,39,0,288,302,3,82,41,0,289,302,3,60,30,0,290,302,3,
        62,31,0,291,302,3,76,38,0,292,302,3,84,42,0,293,302,3,86,43,0,294,
        302,3,88,44,0,295,302,3,90,45,0,296,302,3,92,46,0,297,298,5,25,0,
        0,298,299,3,40,20,0,299,300,5,26,0,0,300,302,1,0,0,0,301,284,1,0,
        0,0,301,285,1,0,0,0,301,286,1,0,0,0,301,287,1,0,0,0,301,288,1,0,
        0,0,301,289,1,0,0,0,301,290,1,0,0,0,301,291,1,0,0,0,301,292,1,0,
        0,0,301,293,1,0,0,0,301,294,1,0,0,0,301,295,1,0,0,0,301,296,1,0,
        0,0,301,297,1,0,0,0,302,57,1,0,0,0,303,304,5,15,0,0,304,305,5,25,
        0,0,305,306,3,40,20,0,306,307,5,26,0,0,307,313,3,38,19,0,308,311,
        5,16,0,0,309,312,3,58,29,0,310,312,3,38,19,0,311,309,1,0,0,0,311,
        310,1,0,0,0,312,314,1,0,0,0,313,308,1,0,0,0,313,314,1,0,0,0,314,
        59,1,0,0,0,315,316,3,92,46,0,316,317,3,38,19,0,317,61,1,0,0,0,318,
        319,3,38,19,0,319,63,1,0,0,0,320,335,3,66,33,0,321,322,5,29,0,0,
        322,323,5,12,0,0,323,332,5,25,0,0,324,329,3,68,34,0,325,326,5,28,
        0,0,326,328,3,68,34,0,327,325,1,0,0,0,328,331,1,0,0,0,329,327,1,
        0,0,0,329,330,1,0,0,0,330,333,1,0,0,0,331,329,1,0,0,0,332,324,1,
        0,0,0,332,333,1,0,0,0,333,334,1,0,0,0,334,336,5,26,0,0,335,321,1,
        0,0,0,336,337,1,0,0,0,337,335,1,0,0,0,337,338,1,0,0,0,338,65,1,0,
        0,0,339,348,3,60,30,0,340,348,3,70,35,0,341,348,3,78,39,0,342,348,
        3,92,46,0,343,344,5,25,0,0,344,345,3,40,20,0,345,346,5,26,0,0,346,
        348,1,0,0,0,347,339,1,0,0,0,347,340,1,0,0,0,347,341,1,0,0,0,347,
        342,1,0,0,0,347,343,1,0,0,0,348,67,1,0,0,0,349,350,3,40,20,0,350,
        69,1,0,0,0,351,352,3,92,46,0,352,361,5,25,0,0,353,358,3,72,36,0,
        354,355,5,28,0,0,355,357,3,72,36,0,356,354,1,0,0,0,357,360,1,0,0,
        0,358,356,1,0,0,0,358,359,1,0,0,0,359,362,1,0,0,0,360,358,1,0,0,
        0,361,353,1,0,0,0,361,362,1,0,0,0,362,363,1,0,0,0,363,364,5,26,0,
        0,364,71,1,0,0,0,365,368,3,74,37,0,366,368,3,40,20,0,367,365,1,0,
        0,0,367,366,1,0,0,0,368,73,1,0,0,0,369,370,3,92,46,0,370,371,5,27,
        0,0,371,372,3,40,20,0,372,75,1,0,0,0,373,382,5,23,0,0,374,379,3,
        40,20,0,375,376,5,28,0,0,376,378,3,40,20,0,377,375,1,0,0,0,378,381,
        1,0,0,0,379,377,1,0,0,0,379,380,1,0,0,0,380,383,1,0,0,0,381,379,
        1,0,0,0,382,374,1,0,0,0,382,383,1,0,0,0,383,384,1,0,0,0,384,385,
        5,24,0,0,385,77,1,0,0,0,386,387,3,80,40,0,387,79,1,0,0,0,388,391,
        3,92,46,0,389,390,5,29,0,0,390,392,3,92,46,0,391,389,1,0,0,0,392,
        393,1,0,0,0,393,391,1,0,0,0,393,394,1,0,0,0,394,81,1,0,0,0,395,396,
        5,20,0,0,396,83,1,0,0,0,397,398,5,48,0,0,398,85,1,0,0,0,399,400,
        5,49,0,0,400,87,1,0,0,0,401,402,7,6,0,0,402,89,1,0,0,0,403,404,5,
        19,0,0,404,91,1,0,0,0,405,406,7,7,0,0,406,93,1,0,0,0,39,97,111,131,
        138,144,149,152,156,164,172,178,183,192,198,202,209,214,218,224,
        236,244,252,260,268,276,282,301,311,313,329,332,337,347,358,361,
        367,379,382,393
    ]

class HolisticsParser ( Parser ):

    grammarFileName = "HolisticsParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'Model'", "'Dataset'", "'Relationship'", 
                     "'RelationshipConfig'", "'dimension'", "'measure'", 
                     "'metric'", "'Func'", "'Constant'", "'Module'", "'Extend'", 
                     "'extend'", "'use'", "'const'", "'if'", "'else'", "'true'", 
                     "'false'", "'null'", "<INVALID>", "'{'", "'}'", "'['", 
                     "']'", "'('", "')'", "':'", "','", "'.'", "'=>'", "'=='", 
                     "'!='", "'>='", "'<='", "'>'", "'<'", "'='", "'+'", 
                     "'*'", "'/'", "'%'", "'&&'", "'||'", "'!'", "'|'", 
                     "';'", "'-'" ]

    symbolicNames = [ "<INVALID>", "MODEL", "DATASET", "RELATIONSHIP", "RELATIONSHIP_CONFIG", 
                      "DIMENSION", "MEASURE", "METRIC", "FUNC", "CONSTANT", 
                      "MODULE", "EXTEND", "EXTEND_FUNC", "USE", "CONST", 
                      "IF", "ELSE", "TRUE", "FALSE", "NULL", "TAGGED_BLOCK", 
                      "LBRACE", "RBRACE", "LBRACK", "RBRACK", "LPAREN", 
                      "RPAREN", "COLON", "COMMA", "DOT", "ARROW", "EQEQ", 
                      "NOTEQ", "GTE", "LTE", "GT", "LT", "EQUAL", "PLUS", 
                      "STAR", "SLASH", "PERCENT", "AND", "OR", "NOT", "PIPE", 
                      "SEMI", "DASH", "STRING", "NUMBER", "IDENTIFIER", 
                      "LINE_COMMENT", "BLOCK_COMMENT", "WS" ]

    RULE_document = 0
    RULE_statement = 1
    RULE_namedBlock = 2
    RULE_anonymousBlock = 3
    RULE_blockKeyword = 4
    RULE_property = 5
    RULE_constDeclaration = 6
    RULE_objectAssignment = 7
    RULE_valueAssignment = 8
    RULE_useStatement = 9
    RULE_usePath = 10
    RULE_useImportBlock = 11
    RULE_useImportItem = 12
    RULE_funcDeclaration = 13
    RULE_paramList = 14
    RULE_param = 15
    RULE_typeExpr = 16
    RULE_typePrimary = 17
    RULE_expressionStatement = 18
    RULE_block = 19
    RULE_expression = 20
    RULE_logicalOr = 21
    RULE_logicalAnd = 22
    RULE_equality = 23
    RULE_comparison = 24
    RULE_additive = 25
    RULE_multiplicative = 26
    RULE_unary = 27
    RULE_primary = 28
    RULE_ifExpression = 29
    RULE_typedBlock = 30
    RULE_blockLiteral = 31
    RULE_extendCall = 32
    RULE_extendTarget = 33
    RULE_extendArg = 34
    RULE_functionCall = 35
    RULE_callArg = 36
    RULE_callNamedArg = 37
    RULE_array = 38
    RULE_reference = 39
    RULE_qualifiedName = 40
    RULE_taggedBlock = 41
    RULE_string = 42
    RULE_number = 43
    RULE_boolean = 44
    RULE_nullValue = 45
    RULE_identifier = 46

    ruleNames =  [ "document", "statement", "namedBlock", "anonymousBlock", 
                   "blockKeyword", "property", "constDeclaration", "objectAssignment", 
                   "valueAssignment", "useStatement", "usePath", "useImportBlock", 
                   "useImportItem", "funcDeclaration", "paramList", "param", 
                   "typeExpr", "typePrimary", "expressionStatement", "block", 
                   "expression", "logicalOr", "logicalAnd", "equality", 
                   "comparison", "additive", "multiplicative", "unary", 
                   "primary", "ifExpression", "typedBlock", "blockLiteral", 
                   "extendCall", "extendTarget", "extendArg", "functionCall", 
                   "callArg", "callNamedArg", "array", "reference", "qualifiedName", 
                   "taggedBlock", "string", "number", "boolean", "nullValue", 
                   "identifier" ]

    EOF = Token.EOF
    MODEL=1
    DATASET=2
    RELATIONSHIP=3
    RELATIONSHIP_CONFIG=4
    DIMENSION=5
    MEASURE=6
    METRIC=7
    FUNC=8
    CONSTANT=9
    MODULE=10
    EXTEND=11
    EXTEND_FUNC=12
    USE=13
    CONST=14
    IF=15
    ELSE=16
    TRUE=17
    FALSE=18
    NULL=19
    TAGGED_BLOCK=20
    LBRACE=21
    RBRACE=22
    LBRACK=23
    RBRACK=24
    LPAREN=25
    RPAREN=26
    COLON=27
    COMMA=28
    DOT=29
    ARROW=30
    EQEQ=31
    NOTEQ=32
    GTE=33
    LTE=34
    GT=35
    LT=36
    EQUAL=37
    PLUS=38
    STAR=39
    SLASH=40
    PERCENT=41
    AND=42
    OR=43
    NOT=44
    PIPE=45
    SEMI=46
    DASH=47
    STRING=48
    NUMBER=49
    IDENTIFIER=50
    LINE_COMMENT=51
    BLOCK_COMMENT=52
    WS=53

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class DocumentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(HolisticsParser.EOF, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.StatementContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.StatementContext,i)


        def getRuleIndex(self):
            return HolisticsParser.RULE_document

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDocument" ):
                listener.enterDocument(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDocument" ):
                listener.exitDocument(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDocument" ):
                return visitor.visitDocument(self)
            else:
                return visitor.visitChildren(self)




    def document(self):

        localctx = HolisticsParser.DocumentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_document)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 97
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 2128654557507582) != 0):
                self.state = 94
                self.statement()
                self.state = 99
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 100
            self.match(HolisticsParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def namedBlock(self):
            return self.getTypedRuleContext(HolisticsParser.NamedBlockContext,0)


        def anonymousBlock(self):
            return self.getTypedRuleContext(HolisticsParser.AnonymousBlockContext,0)


        def property_(self):
            return self.getTypedRuleContext(HolisticsParser.PropertyContext,0)


        def constDeclaration(self):
            return self.getTypedRuleContext(HolisticsParser.ConstDeclarationContext,0)


        def objectAssignment(self):
            return self.getTypedRuleContext(HolisticsParser.ObjectAssignmentContext,0)


        def valueAssignment(self):
            return self.getTypedRuleContext(HolisticsParser.ValueAssignmentContext,0)


        def useStatement(self):
            return self.getTypedRuleContext(HolisticsParser.UseStatementContext,0)


        def funcDeclaration(self):
            return self.getTypedRuleContext(HolisticsParser.FuncDeclarationContext,0)


        def expressionStatement(self):
            return self.getTypedRuleContext(HolisticsParser.ExpressionStatementContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatement" ):
                listener.enterStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatement" ):
                listener.exitStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatement" ):
                return visitor.visitStatement(self)
            else:
                return visitor.visitChildren(self)




    def statement(self):

        localctx = HolisticsParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_statement)
        try:
            self.state = 111
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 102
                self.namedBlock()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 103
                self.anonymousBlock()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 104
                self.property_()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 105
                self.constDeclaration()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 106
                self.objectAssignment()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 107
                self.valueAssignment()
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 108
                self.useStatement()
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 109
                self.funcDeclaration()
                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 110
                self.expressionStatement()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NamedBlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def blockKeyword(self):
            return self.getTypedRuleContext(HolisticsParser.BlockKeywordContext,0)


        def identifier(self):
            return self.getTypedRuleContext(HolisticsParser.IdentifierContext,0)


        def block(self):
            return self.getTypedRuleContext(HolisticsParser.BlockContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_namedBlock

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNamedBlock" ):
                listener.enterNamedBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNamedBlock" ):
                listener.exitNamedBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNamedBlock" ):
                return visitor.visitNamedBlock(self)
            else:
                return visitor.visitChildren(self)




    def namedBlock(self):

        localctx = HolisticsParser.NamedBlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_namedBlock)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 113
            self.blockKeyword()
            self.state = 114
            self.identifier()
            self.state = 115
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AnonymousBlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def blockKeyword(self):
            return self.getTypedRuleContext(HolisticsParser.BlockKeywordContext,0)


        def block(self):
            return self.getTypedRuleContext(HolisticsParser.BlockContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_anonymousBlock

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAnonymousBlock" ):
                listener.enterAnonymousBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAnonymousBlock" ):
                listener.exitAnonymousBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAnonymousBlock" ):
                return visitor.visitAnonymousBlock(self)
            else:
                return visitor.visitChildren(self)




    def anonymousBlock(self):

        localctx = HolisticsParser.AnonymousBlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_anonymousBlock)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 117
            self.blockKeyword()
            self.state = 118
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BlockKeywordContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MODEL(self):
            return self.getToken(HolisticsParser.MODEL, 0)

        def DATASET(self):
            return self.getToken(HolisticsParser.DATASET, 0)

        def RELATIONSHIP(self):
            return self.getToken(HolisticsParser.RELATIONSHIP, 0)

        def RELATIONSHIP_CONFIG(self):
            return self.getToken(HolisticsParser.RELATIONSHIP_CONFIG, 0)

        def DIMENSION(self):
            return self.getToken(HolisticsParser.DIMENSION, 0)

        def MEASURE(self):
            return self.getToken(HolisticsParser.MEASURE, 0)

        def METRIC(self):
            return self.getToken(HolisticsParser.METRIC, 0)

        def FUNC(self):
            return self.getToken(HolisticsParser.FUNC, 0)

        def CONSTANT(self):
            return self.getToken(HolisticsParser.CONSTANT, 0)

        def MODULE(self):
            return self.getToken(HolisticsParser.MODULE, 0)

        def EXTEND(self):
            return self.getToken(HolisticsParser.EXTEND, 0)

        def IDENTIFIER(self):
            return self.getToken(HolisticsParser.IDENTIFIER, 0)

        def getRuleIndex(self):
            return HolisticsParser.RULE_blockKeyword

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBlockKeyword" ):
                listener.enterBlockKeyword(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBlockKeyword" ):
                listener.exitBlockKeyword(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBlockKeyword" ):
                return visitor.visitBlockKeyword(self)
            else:
                return visitor.visitChildren(self)




    def blockKeyword(self):

        localctx = HolisticsParser.BlockKeywordContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_blockKeyword)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 120
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1125899906846718) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PropertyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(HolisticsParser.IdentifierContext,0)


        def COLON(self):
            return self.getToken(HolisticsParser.COLON, 0)

        def expression(self):
            return self.getTypedRuleContext(HolisticsParser.ExpressionContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_property

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProperty" ):
                listener.enterProperty(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProperty" ):
                listener.exitProperty(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProperty" ):
                return visitor.visitProperty(self)
            else:
                return visitor.visitChildren(self)




    def property_(self):

        localctx = HolisticsParser.PropertyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_property)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 122
            self.identifier()
            self.state = 123
            self.match(HolisticsParser.COLON)
            self.state = 124
            self.expression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstDeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONST(self):
            return self.getToken(HolisticsParser.CONST, 0)

        def identifier(self):
            return self.getTypedRuleContext(HolisticsParser.IdentifierContext,0)


        def EQUAL(self):
            return self.getToken(HolisticsParser.EQUAL, 0)

        def expression(self):
            return self.getTypedRuleContext(HolisticsParser.ExpressionContext,0)


        def SEMI(self):
            return self.getToken(HolisticsParser.SEMI, 0)

        def getRuleIndex(self):
            return HolisticsParser.RULE_constDeclaration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstDeclaration" ):
                listener.enterConstDeclaration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstDeclaration" ):
                listener.exitConstDeclaration(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstDeclaration" ):
                return visitor.visitConstDeclaration(self)
            else:
                return visitor.visitChildren(self)




    def constDeclaration(self):

        localctx = HolisticsParser.ConstDeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_constDeclaration)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 126
            self.match(HolisticsParser.CONST)
            self.state = 127
            self.identifier()
            self.state = 128
            self.match(HolisticsParser.EQUAL)
            self.state = 129
            self.expression()
            self.state = 131
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==46:
                self.state = 130
                self.match(HolisticsParser.SEMI)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ObjectAssignmentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def blockKeyword(self):
            return self.getTypedRuleContext(HolisticsParser.BlockKeywordContext,0)


        def identifier(self):
            return self.getTypedRuleContext(HolisticsParser.IdentifierContext,0)


        def EQUAL(self):
            return self.getToken(HolisticsParser.EQUAL, 0)

        def expression(self):
            return self.getTypedRuleContext(HolisticsParser.ExpressionContext,0)


        def SEMI(self):
            return self.getToken(HolisticsParser.SEMI, 0)

        def getRuleIndex(self):
            return HolisticsParser.RULE_objectAssignment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterObjectAssignment" ):
                listener.enterObjectAssignment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitObjectAssignment" ):
                listener.exitObjectAssignment(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitObjectAssignment" ):
                return visitor.visitObjectAssignment(self)
            else:
                return visitor.visitChildren(self)




    def objectAssignment(self):

        localctx = HolisticsParser.ObjectAssignmentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_objectAssignment)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 133
            self.blockKeyword()
            self.state = 134
            self.identifier()
            self.state = 135
            self.match(HolisticsParser.EQUAL)
            self.state = 136
            self.expression()
            self.state = 138
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==46:
                self.state = 137
                self.match(HolisticsParser.SEMI)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueAssignmentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(HolisticsParser.IdentifierContext,0)


        def EQUAL(self):
            return self.getToken(HolisticsParser.EQUAL, 0)

        def expression(self):
            return self.getTypedRuleContext(HolisticsParser.ExpressionContext,0)


        def SEMI(self):
            return self.getToken(HolisticsParser.SEMI, 0)

        def getRuleIndex(self):
            return HolisticsParser.RULE_valueAssignment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValueAssignment" ):
                listener.enterValueAssignment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValueAssignment" ):
                listener.exitValueAssignment(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitValueAssignment" ):
                return visitor.visitValueAssignment(self)
            else:
                return visitor.visitChildren(self)




    def valueAssignment(self):

        localctx = HolisticsParser.ValueAssignmentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_valueAssignment)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 140
            self.identifier()
            self.state = 141
            self.match(HolisticsParser.EQUAL)
            self.state = 142
            self.expression()
            self.state = 144
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==46:
                self.state = 143
                self.match(HolisticsParser.SEMI)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UseStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def USE(self):
            return self.getToken(HolisticsParser.USE, 0)

        def usePath(self):
            return self.getTypedRuleContext(HolisticsParser.UsePathContext,0)


        def useImportBlock(self):
            return self.getTypedRuleContext(HolisticsParser.UseImportBlockContext,0)


        def SEMI(self):
            return self.getToken(HolisticsParser.SEMI, 0)

        def getRuleIndex(self):
            return HolisticsParser.RULE_useStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUseStatement" ):
                listener.enterUseStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUseStatement" ):
                listener.exitUseStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUseStatement" ):
                return visitor.visitUseStatement(self)
            else:
                return visitor.visitChildren(self)




    def useStatement(self):

        localctx = HolisticsParser.UseStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_useStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 146
            self.match(HolisticsParser.USE)
            self.state = 147
            self.usePath()
            self.state = 149
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
            if la_ == 1:
                self.state = 148
                self.useImportBlock()


            self.state = 152
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==46:
                self.state = 151
                self.match(HolisticsParser.SEMI)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UsePathContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def qualifiedName(self):
            return self.getTypedRuleContext(HolisticsParser.QualifiedNameContext,0)


        def identifier(self):
            return self.getTypedRuleContext(HolisticsParser.IdentifierContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_usePath

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUsePath" ):
                listener.enterUsePath(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUsePath" ):
                listener.exitUsePath(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUsePath" ):
                return visitor.visitUsePath(self)
            else:
                return visitor.visitChildren(self)




    def usePath(self):

        localctx = HolisticsParser.UsePathContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_usePath)
        try:
            self.state = 156
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,7,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 154
                self.qualifiedName()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 155
                self.identifier()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UseImportBlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBRACE(self):
            return self.getToken(HolisticsParser.LBRACE, 0)

        def useImportItem(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.UseImportItemContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.UseImportItemContext,i)


        def RBRACE(self):
            return self.getToken(HolisticsParser.RBRACE, 0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.COMMA)
            else:
                return self.getToken(HolisticsParser.COMMA, i)

        def getRuleIndex(self):
            return HolisticsParser.RULE_useImportBlock

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUseImportBlock" ):
                listener.enterUseImportBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUseImportBlock" ):
                listener.exitUseImportBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUseImportBlock" ):
                return visitor.visitUseImportBlock(self)
            else:
                return visitor.visitChildren(self)




    def useImportBlock(self):

        localctx = HolisticsParser.UseImportBlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_useImportBlock)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 158
            self.match(HolisticsParser.LBRACE)
            self.state = 159
            self.useImportItem()
            self.state = 164
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==28:
                self.state = 160
                self.match(HolisticsParser.COMMA)
                self.state = 161
                self.useImportItem()
                self.state = 166
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 167
            self.match(HolisticsParser.RBRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UseImportItemContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.IdentifierContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.IdentifierContext,i)


        def COLON(self):
            return self.getToken(HolisticsParser.COLON, 0)

        def getRuleIndex(self):
            return HolisticsParser.RULE_useImportItem

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUseImportItem" ):
                listener.enterUseImportItem(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUseImportItem" ):
                listener.exitUseImportItem(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUseImportItem" ):
                return visitor.visitUseImportItem(self)
            else:
                return visitor.visitChildren(self)




    def useImportItem(self):

        localctx = HolisticsParser.UseImportItemContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_useImportItem)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 169
            self.identifier()
            self.state = 172
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==27:
                self.state = 170
                self.match(HolisticsParser.COLON)
                self.state = 171
                self.identifier()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FuncDeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FUNC(self):
            return self.getToken(HolisticsParser.FUNC, 0)

        def identifier(self):
            return self.getTypedRuleContext(HolisticsParser.IdentifierContext,0)


        def LPAREN(self):
            return self.getToken(HolisticsParser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(HolisticsParser.RPAREN, 0)

        def block(self):
            return self.getTypedRuleContext(HolisticsParser.BlockContext,0)


        def paramList(self):
            return self.getTypedRuleContext(HolisticsParser.ParamListContext,0)


        def ARROW(self):
            return self.getToken(HolisticsParser.ARROW, 0)

        def typeExpr(self):
            return self.getTypedRuleContext(HolisticsParser.TypeExprContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_funcDeclaration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncDeclaration" ):
                listener.enterFuncDeclaration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncDeclaration" ):
                listener.exitFuncDeclaration(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncDeclaration" ):
                return visitor.visitFuncDeclaration(self)
            else:
                return visitor.visitChildren(self)




    def funcDeclaration(self):

        localctx = HolisticsParser.FuncDeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_funcDeclaration)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 174
            self.match(HolisticsParser.FUNC)
            self.state = 175
            self.identifier()
            self.state = 176
            self.match(HolisticsParser.LPAREN)
            self.state = 178
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 1125899907887102) != 0):
                self.state = 177
                self.paramList()


            self.state = 180
            self.match(HolisticsParser.RPAREN)
            self.state = 183
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==30:
                self.state = 181
                self.match(HolisticsParser.ARROW)
                self.state = 182
                self.typeExpr()


            self.state = 185
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParamListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def param(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.ParamContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.ParamContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.COMMA)
            else:
                return self.getToken(HolisticsParser.COMMA, i)

        def getRuleIndex(self):
            return HolisticsParser.RULE_paramList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParamList" ):
                listener.enterParamList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParamList" ):
                listener.exitParamList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParamList" ):
                return visitor.visitParamList(self)
            else:
                return visitor.visitChildren(self)




    def paramList(self):

        localctx = HolisticsParser.ParamListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_paramList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 187
            self.param()
            self.state = 192
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==28:
                self.state = 188
                self.match(HolisticsParser.COMMA)
                self.state = 189
                self.param()
                self.state = 194
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParamContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(HolisticsParser.IdentifierContext,0)


        def COLON(self):
            return self.getToken(HolisticsParser.COLON, 0)

        def typeExpr(self):
            return self.getTypedRuleContext(HolisticsParser.TypeExprContext,0)


        def EQUAL(self):
            return self.getToken(HolisticsParser.EQUAL, 0)

        def expression(self):
            return self.getTypedRuleContext(HolisticsParser.ExpressionContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_param

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParam" ):
                listener.enterParam(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParam" ):
                listener.exitParam(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParam" ):
                return visitor.visitParam(self)
            else:
                return visitor.visitChildren(self)




    def param(self):

        localctx = HolisticsParser.ParamContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_param)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 195
            self.identifier()
            self.state = 198
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==27:
                self.state = 196
                self.match(HolisticsParser.COLON)
                self.state = 197
                self.typeExpr()


            self.state = 202
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==37:
                self.state = 200
                self.match(HolisticsParser.EQUAL)
                self.state = 201
                self.expression()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def typePrimary(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.TypePrimaryContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.TypePrimaryContext,i)


        def PIPE(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.PIPE)
            else:
                return self.getToken(HolisticsParser.PIPE, i)

        def getRuleIndex(self):
            return HolisticsParser.RULE_typeExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypeExpr" ):
                listener.enterTypeExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypeExpr" ):
                listener.exitTypeExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTypeExpr" ):
                return visitor.visitTypeExpr(self)
            else:
                return visitor.visitChildren(self)




    def typeExpr(self):

        localctx = HolisticsParser.TypeExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_typeExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 204
            self.typePrimary()
            self.state = 209
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==45:
                self.state = 205
                self.match(HolisticsParser.PIPE)
                self.state = 206
                self.typePrimary()
                self.state = 211
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypePrimaryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(HolisticsParser.IdentifierContext,0)


        def string(self):
            return self.getTypedRuleContext(HolisticsParser.StringContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_typePrimary

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypePrimary" ):
                listener.enterTypePrimary(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypePrimary" ):
                listener.exitTypePrimary(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTypePrimary" ):
                return visitor.visitTypePrimary(self)
            else:
                return visitor.visitChildren(self)




    def typePrimary(self):

        localctx = HolisticsParser.TypePrimaryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_typePrimary)
        try:
            self.state = 214
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 50]:
                self.enterOuterAlt(localctx, 1)
                self.state = 212
                self.identifier()
                pass
            elif token in [48]:
                self.enterOuterAlt(localctx, 2)
                self.state = 213
                self.string()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(HolisticsParser.ExpressionContext,0)


        def SEMI(self):
            return self.getToken(HolisticsParser.SEMI, 0)

        def getRuleIndex(self):
            return HolisticsParser.RULE_expressionStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpressionStatement" ):
                listener.enterExpressionStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpressionStatement" ):
                listener.exitExpressionStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpressionStatement" ):
                return visitor.visitExpressionStatement(self)
            else:
                return visitor.visitChildren(self)




    def expressionStatement(self):

        localctx = HolisticsParser.ExpressionStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_expressionStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 216
            self.expression()
            self.state = 218
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==46:
                self.state = 217
                self.match(HolisticsParser.SEMI)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBRACE(self):
            return self.getToken(HolisticsParser.LBRACE, 0)

        def RBRACE(self):
            return self.getToken(HolisticsParser.RBRACE, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.StatementContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.StatementContext,i)


        def getRuleIndex(self):
            return HolisticsParser.RULE_block

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBlock" ):
                listener.enterBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBlock" ):
                listener.exitBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBlock" ):
                return visitor.visitBlock(self)
            else:
                return visitor.visitChildren(self)




    def block(self):

        localctx = HolisticsParser.BlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_block)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 220
            self.match(HolisticsParser.LBRACE)
            self.state = 224
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 2128654557507582) != 0):
                self.state = 221
                self.statement()
                self.state = 226
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 227
            self.match(HolisticsParser.RBRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def logicalOr(self):
            return self.getTypedRuleContext(HolisticsParser.LogicalOrContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpression" ):
                return visitor.visitExpression(self)
            else:
                return visitor.visitChildren(self)




    def expression(self):

        localctx = HolisticsParser.ExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_expression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 229
            self.logicalOr()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LogicalOrContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def logicalAnd(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.LogicalAndContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.LogicalAndContext,i)


        def OR(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.OR)
            else:
                return self.getToken(HolisticsParser.OR, i)

        def getRuleIndex(self):
            return HolisticsParser.RULE_logicalOr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLogicalOr" ):
                listener.enterLogicalOr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLogicalOr" ):
                listener.exitLogicalOr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLogicalOr" ):
                return visitor.visitLogicalOr(self)
            else:
                return visitor.visitChildren(self)




    def logicalOr(self):

        localctx = HolisticsParser.LogicalOrContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_logicalOr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 231
            self.logicalAnd()
            self.state = 236
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==43:
                self.state = 232
                self.match(HolisticsParser.OR)
                self.state = 233
                self.logicalAnd()
                self.state = 238
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LogicalAndContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def equality(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.EqualityContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.EqualityContext,i)


        def AND(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.AND)
            else:
                return self.getToken(HolisticsParser.AND, i)

        def getRuleIndex(self):
            return HolisticsParser.RULE_logicalAnd

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLogicalAnd" ):
                listener.enterLogicalAnd(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLogicalAnd" ):
                listener.exitLogicalAnd(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLogicalAnd" ):
                return visitor.visitLogicalAnd(self)
            else:
                return visitor.visitChildren(self)




    def logicalAnd(self):

        localctx = HolisticsParser.LogicalAndContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_logicalAnd)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 239
            self.equality()
            self.state = 244
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==42:
                self.state = 240
                self.match(HolisticsParser.AND)
                self.state = 241
                self.equality()
                self.state = 246
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EqualityContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def comparison(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.ComparisonContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.ComparisonContext,i)


        def EQEQ(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.EQEQ)
            else:
                return self.getToken(HolisticsParser.EQEQ, i)

        def NOTEQ(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.NOTEQ)
            else:
                return self.getToken(HolisticsParser.NOTEQ, i)

        def getRuleIndex(self):
            return HolisticsParser.RULE_equality

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEquality" ):
                listener.enterEquality(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEquality" ):
                listener.exitEquality(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEquality" ):
                return visitor.visitEquality(self)
            else:
                return visitor.visitChildren(self)




    def equality(self):

        localctx = HolisticsParser.EqualityContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_equality)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 247
            self.comparison()
            self.state = 252
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==31 or _la==32:
                self.state = 248
                _la = self._input.LA(1)
                if not(_la==31 or _la==32):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 249
                self.comparison()
                self.state = 254
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ComparisonContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def additive(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.AdditiveContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.AdditiveContext,i)


        def GT(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.GT)
            else:
                return self.getToken(HolisticsParser.GT, i)

        def GTE(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.GTE)
            else:
                return self.getToken(HolisticsParser.GTE, i)

        def LT(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.LT)
            else:
                return self.getToken(HolisticsParser.LT, i)

        def LTE(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.LTE)
            else:
                return self.getToken(HolisticsParser.LTE, i)

        def getRuleIndex(self):
            return HolisticsParser.RULE_comparison

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparison" ):
                listener.enterComparison(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparison" ):
                listener.exitComparison(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComparison" ):
                return visitor.visitComparison(self)
            else:
                return visitor.visitChildren(self)




    def comparison(self):

        localctx = HolisticsParser.ComparisonContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_comparison)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 255
            self.additive()
            self.state = 260
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 128849018880) != 0):
                self.state = 256
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 128849018880) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 257
                self.additive()
                self.state = 262
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AdditiveContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def multiplicative(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.MultiplicativeContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.MultiplicativeContext,i)


        def PLUS(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.PLUS)
            else:
                return self.getToken(HolisticsParser.PLUS, i)

        def DASH(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.DASH)
            else:
                return self.getToken(HolisticsParser.DASH, i)

        def getRuleIndex(self):
            return HolisticsParser.RULE_additive

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAdditive" ):
                listener.enterAdditive(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAdditive" ):
                listener.exitAdditive(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAdditive" ):
                return visitor.visitAdditive(self)
            else:
                return visitor.visitChildren(self)




    def additive(self):

        localctx = HolisticsParser.AdditiveContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_additive)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 263
            self.multiplicative()
            self.state = 268
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,23,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 264
                    _la = self._input.LA(1)
                    if not(_la==38 or _la==47):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 265
                    self.multiplicative() 
                self.state = 270
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,23,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MultiplicativeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def unary(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.UnaryContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.UnaryContext,i)


        def STAR(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.STAR)
            else:
                return self.getToken(HolisticsParser.STAR, i)

        def SLASH(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.SLASH)
            else:
                return self.getToken(HolisticsParser.SLASH, i)

        def PERCENT(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.PERCENT)
            else:
                return self.getToken(HolisticsParser.PERCENT, i)

        def getRuleIndex(self):
            return HolisticsParser.RULE_multiplicative

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMultiplicative" ):
                listener.enterMultiplicative(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMultiplicative" ):
                listener.exitMultiplicative(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMultiplicative" ):
                return visitor.visitMultiplicative(self)
            else:
                return visitor.visitChildren(self)




    def multiplicative(self):

        localctx = HolisticsParser.MultiplicativeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_multiplicative)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 271
            self.unary()
            self.state = 276
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 3848290697216) != 0):
                self.state = 272
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 3848290697216) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 273
                self.unary()
                self.state = 278
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnaryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def unary(self):
            return self.getTypedRuleContext(HolisticsParser.UnaryContext,0)


        def NOT(self):
            return self.getToken(HolisticsParser.NOT, 0)

        def DASH(self):
            return self.getToken(HolisticsParser.DASH, 0)

        def primary(self):
            return self.getTypedRuleContext(HolisticsParser.PrimaryContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_unary

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnary" ):
                listener.enterUnary(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnary" ):
                listener.exitUnary(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnary" ):
                return visitor.visitUnary(self)
            else:
                return visitor.visitChildren(self)




    def unary(self):

        localctx = HolisticsParser.UnaryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_unary)
        self._la = 0 # Token type
        try:
            self.state = 282
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [44, 47]:
                self.enterOuterAlt(localctx, 1)
                self.state = 279
                _la = self._input.LA(1)
                if not(_la==44 or _la==47):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 280
                self.unary()
                pass
            elif token in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20, 21, 23, 25, 48, 49, 50]:
                self.enterOuterAlt(localctx, 2)
                self.state = 281
                self.primary()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrimaryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ifExpression(self):
            return self.getTypedRuleContext(HolisticsParser.IfExpressionContext,0)


        def extendCall(self):
            return self.getTypedRuleContext(HolisticsParser.ExtendCallContext,0)


        def functionCall(self):
            return self.getTypedRuleContext(HolisticsParser.FunctionCallContext,0)


        def reference(self):
            return self.getTypedRuleContext(HolisticsParser.ReferenceContext,0)


        def taggedBlock(self):
            return self.getTypedRuleContext(HolisticsParser.TaggedBlockContext,0)


        def typedBlock(self):
            return self.getTypedRuleContext(HolisticsParser.TypedBlockContext,0)


        def blockLiteral(self):
            return self.getTypedRuleContext(HolisticsParser.BlockLiteralContext,0)


        def array(self):
            return self.getTypedRuleContext(HolisticsParser.ArrayContext,0)


        def string(self):
            return self.getTypedRuleContext(HolisticsParser.StringContext,0)


        def number(self):
            return self.getTypedRuleContext(HolisticsParser.NumberContext,0)


        def boolean(self):
            return self.getTypedRuleContext(HolisticsParser.BooleanContext,0)


        def nullValue(self):
            return self.getTypedRuleContext(HolisticsParser.NullValueContext,0)


        def identifier(self):
            return self.getTypedRuleContext(HolisticsParser.IdentifierContext,0)


        def LPAREN(self):
            return self.getToken(HolisticsParser.LPAREN, 0)

        def expression(self):
            return self.getTypedRuleContext(HolisticsParser.ExpressionContext,0)


        def RPAREN(self):
            return self.getToken(HolisticsParser.RPAREN, 0)

        def getRuleIndex(self):
            return HolisticsParser.RULE_primary

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrimary" ):
                listener.enterPrimary(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrimary" ):
                listener.exitPrimary(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrimary" ):
                return visitor.visitPrimary(self)
            else:
                return visitor.visitChildren(self)




    def primary(self):

        localctx = HolisticsParser.PrimaryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_primary)
        try:
            self.state = 301
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,26,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 284
                self.ifExpression()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 285
                self.extendCall()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 286
                self.functionCall()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 287
                self.reference()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 288
                self.taggedBlock()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 289
                self.typedBlock()
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 290
                self.blockLiteral()
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 291
                self.array()
                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 292
                self.string()
                pass

            elif la_ == 10:
                self.enterOuterAlt(localctx, 10)
                self.state = 293
                self.number()
                pass

            elif la_ == 11:
                self.enterOuterAlt(localctx, 11)
                self.state = 294
                self.boolean()
                pass

            elif la_ == 12:
                self.enterOuterAlt(localctx, 12)
                self.state = 295
                self.nullValue()
                pass

            elif la_ == 13:
                self.enterOuterAlt(localctx, 13)
                self.state = 296
                self.identifier()
                pass

            elif la_ == 14:
                self.enterOuterAlt(localctx, 14)
                self.state = 297
                self.match(HolisticsParser.LPAREN)
                self.state = 298
                self.expression()
                self.state = 299
                self.match(HolisticsParser.RPAREN)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IfExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(HolisticsParser.IF, 0)

        def LPAREN(self):
            return self.getToken(HolisticsParser.LPAREN, 0)

        def expression(self):
            return self.getTypedRuleContext(HolisticsParser.ExpressionContext,0)


        def RPAREN(self):
            return self.getToken(HolisticsParser.RPAREN, 0)

        def block(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.BlockContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.BlockContext,i)


        def ELSE(self):
            return self.getToken(HolisticsParser.ELSE, 0)

        def ifExpression(self):
            return self.getTypedRuleContext(HolisticsParser.IfExpressionContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_ifExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIfExpression" ):
                listener.enterIfExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIfExpression" ):
                listener.exitIfExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIfExpression" ):
                return visitor.visitIfExpression(self)
            else:
                return visitor.visitChildren(self)




    def ifExpression(self):

        localctx = HolisticsParser.IfExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_ifExpression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 303
            self.match(HolisticsParser.IF)
            self.state = 304
            self.match(HolisticsParser.LPAREN)
            self.state = 305
            self.expression()
            self.state = 306
            self.match(HolisticsParser.RPAREN)
            self.state = 307
            self.block()
            self.state = 313
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,28,self._ctx)
            if la_ == 1:
                self.state = 308
                self.match(HolisticsParser.ELSE)
                self.state = 311
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [15]:
                    self.state = 309
                    self.ifExpression()
                    pass
                elif token in [21]:
                    self.state = 310
                    self.block()
                    pass
                else:
                    raise NoViableAltException(self)



        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypedBlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(HolisticsParser.IdentifierContext,0)


        def block(self):
            return self.getTypedRuleContext(HolisticsParser.BlockContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_typedBlock

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypedBlock" ):
                listener.enterTypedBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypedBlock" ):
                listener.exitTypedBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTypedBlock" ):
                return visitor.visitTypedBlock(self)
            else:
                return visitor.visitChildren(self)




    def typedBlock(self):

        localctx = HolisticsParser.TypedBlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_typedBlock)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 315
            self.identifier()
            self.state = 316
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BlockLiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def block(self):
            return self.getTypedRuleContext(HolisticsParser.BlockContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_blockLiteral

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBlockLiteral" ):
                listener.enterBlockLiteral(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBlockLiteral" ):
                listener.exitBlockLiteral(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBlockLiteral" ):
                return visitor.visitBlockLiteral(self)
            else:
                return visitor.visitChildren(self)




    def blockLiteral(self):

        localctx = HolisticsParser.BlockLiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_blockLiteral)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 318
            self.block()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExtendCallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def extendTarget(self):
            return self.getTypedRuleContext(HolisticsParser.ExtendTargetContext,0)


        def DOT(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.DOT)
            else:
                return self.getToken(HolisticsParser.DOT, i)

        def EXTEND_FUNC(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.EXTEND_FUNC)
            else:
                return self.getToken(HolisticsParser.EXTEND_FUNC, i)

        def LPAREN(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.LPAREN)
            else:
                return self.getToken(HolisticsParser.LPAREN, i)

        def RPAREN(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.RPAREN)
            else:
                return self.getToken(HolisticsParser.RPAREN, i)

        def extendArg(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.ExtendArgContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.ExtendArgContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.COMMA)
            else:
                return self.getToken(HolisticsParser.COMMA, i)

        def getRuleIndex(self):
            return HolisticsParser.RULE_extendCall

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExtendCall" ):
                listener.enterExtendCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExtendCall" ):
                listener.exitExtendCall(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExtendCall" ):
                return visitor.visitExtendCall(self)
            else:
                return visitor.visitChildren(self)




    def extendCall(self):

        localctx = HolisticsParser.ExtendCallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_extendCall)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 320
            self.extendTarget()
            self.state = 335 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 321
                self.match(HolisticsParser.DOT)
                self.state = 322
                self.match(HolisticsParser.EXTEND_FUNC)
                self.state = 323
                self.match(HolisticsParser.LPAREN)
                self.state = 332
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 2128654557507582) != 0):
                    self.state = 324
                    self.extendArg()
                    self.state = 329
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==28:
                        self.state = 325
                        self.match(HolisticsParser.COMMA)
                        self.state = 326
                        self.extendArg()
                        self.state = 331
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)



                self.state = 334
                self.match(HolisticsParser.RPAREN)
                self.state = 337 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==29):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExtendTargetContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def typedBlock(self):
            return self.getTypedRuleContext(HolisticsParser.TypedBlockContext,0)


        def functionCall(self):
            return self.getTypedRuleContext(HolisticsParser.FunctionCallContext,0)


        def reference(self):
            return self.getTypedRuleContext(HolisticsParser.ReferenceContext,0)


        def identifier(self):
            return self.getTypedRuleContext(HolisticsParser.IdentifierContext,0)


        def LPAREN(self):
            return self.getToken(HolisticsParser.LPAREN, 0)

        def expression(self):
            return self.getTypedRuleContext(HolisticsParser.ExpressionContext,0)


        def RPAREN(self):
            return self.getToken(HolisticsParser.RPAREN, 0)

        def getRuleIndex(self):
            return HolisticsParser.RULE_extendTarget

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExtendTarget" ):
                listener.enterExtendTarget(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExtendTarget" ):
                listener.exitExtendTarget(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExtendTarget" ):
                return visitor.visitExtendTarget(self)
            else:
                return visitor.visitChildren(self)




    def extendTarget(self):

        localctx = HolisticsParser.ExtendTargetContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_extendTarget)
        try:
            self.state = 347
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,32,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 339
                self.typedBlock()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 340
                self.functionCall()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 341
                self.reference()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 342
                self.identifier()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 343
                self.match(HolisticsParser.LPAREN)
                self.state = 344
                self.expression()
                self.state = 345
                self.match(HolisticsParser.RPAREN)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExtendArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(HolisticsParser.ExpressionContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_extendArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExtendArg" ):
                listener.enterExtendArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExtendArg" ):
                listener.exitExtendArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExtendArg" ):
                return visitor.visitExtendArg(self)
            else:
                return visitor.visitChildren(self)




    def extendArg(self):

        localctx = HolisticsParser.ExtendArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_extendArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 349
            self.expression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionCallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(HolisticsParser.IdentifierContext,0)


        def LPAREN(self):
            return self.getToken(HolisticsParser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(HolisticsParser.RPAREN, 0)

        def callArg(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.CallArgContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.CallArgContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.COMMA)
            else:
                return self.getToken(HolisticsParser.COMMA, i)

        def getRuleIndex(self):
            return HolisticsParser.RULE_functionCall

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunctionCall" ):
                listener.enterFunctionCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunctionCall" ):
                listener.exitFunctionCall(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunctionCall" ):
                return visitor.visitFunctionCall(self)
            else:
                return visitor.visitChildren(self)




    def functionCall(self):

        localctx = HolisticsParser.FunctionCallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_functionCall)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 351
            self.identifier()
            self.state = 352
            self.match(HolisticsParser.LPAREN)
            self.state = 361
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 2128654557507582) != 0):
                self.state = 353
                self.callArg()
                self.state = 358
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==28:
                    self.state = 354
                    self.match(HolisticsParser.COMMA)
                    self.state = 355
                    self.callArg()
                    self.state = 360
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 363
            self.match(HolisticsParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CallArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def callNamedArg(self):
            return self.getTypedRuleContext(HolisticsParser.CallNamedArgContext,0)


        def expression(self):
            return self.getTypedRuleContext(HolisticsParser.ExpressionContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_callArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCallArg" ):
                listener.enterCallArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCallArg" ):
                listener.exitCallArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCallArg" ):
                return visitor.visitCallArg(self)
            else:
                return visitor.visitChildren(self)




    def callArg(self):

        localctx = HolisticsParser.CallArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_callArg)
        try:
            self.state = 367
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,35,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 365
                self.callNamedArg()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 366
                self.expression()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CallNamedArgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(HolisticsParser.IdentifierContext,0)


        def COLON(self):
            return self.getToken(HolisticsParser.COLON, 0)

        def expression(self):
            return self.getTypedRuleContext(HolisticsParser.ExpressionContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_callNamedArg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCallNamedArg" ):
                listener.enterCallNamedArg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCallNamedArg" ):
                listener.exitCallNamedArg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCallNamedArg" ):
                return visitor.visitCallNamedArg(self)
            else:
                return visitor.visitChildren(self)




    def callNamedArg(self):

        localctx = HolisticsParser.CallNamedArgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_callNamedArg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 369
            self.identifier()
            self.state = 370
            self.match(HolisticsParser.COLON)
            self.state = 371
            self.expression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArrayContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBRACK(self):
            return self.getToken(HolisticsParser.LBRACK, 0)

        def RBRACK(self):
            return self.getToken(HolisticsParser.RBRACK, 0)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.ExpressionContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.COMMA)
            else:
                return self.getToken(HolisticsParser.COMMA, i)

        def getRuleIndex(self):
            return HolisticsParser.RULE_array

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArray" ):
                listener.enterArray(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArray" ):
                listener.exitArray(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArray" ):
                return visitor.visitArray(self)
            else:
                return visitor.visitChildren(self)




    def array(self):

        localctx = HolisticsParser.ArrayContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_array)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 373
            self.match(HolisticsParser.LBRACK)
            self.state = 382
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 2128654557507582) != 0):
                self.state = 374
                self.expression()
                self.state = 379
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==28:
                    self.state = 375
                    self.match(HolisticsParser.COMMA)
                    self.state = 376
                    self.expression()
                    self.state = 381
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 384
            self.match(HolisticsParser.RBRACK)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReferenceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def qualifiedName(self):
            return self.getTypedRuleContext(HolisticsParser.QualifiedNameContext,0)


        def getRuleIndex(self):
            return HolisticsParser.RULE_reference

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReference" ):
                listener.enterReference(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReference" ):
                listener.exitReference(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReference" ):
                return visitor.visitReference(self)
            else:
                return visitor.visitChildren(self)




    def reference(self):

        localctx = HolisticsParser.ReferenceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_reference)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 386
            self.qualifiedName()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class QualifiedNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(HolisticsParser.IdentifierContext)
            else:
                return self.getTypedRuleContext(HolisticsParser.IdentifierContext,i)


        def DOT(self, i:int=None):
            if i is None:
                return self.getTokens(HolisticsParser.DOT)
            else:
                return self.getToken(HolisticsParser.DOT, i)

        def getRuleIndex(self):
            return HolisticsParser.RULE_qualifiedName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQualifiedName" ):
                listener.enterQualifiedName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQualifiedName" ):
                listener.exitQualifiedName(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitQualifiedName" ):
                return visitor.visitQualifiedName(self)
            else:
                return visitor.visitChildren(self)




    def qualifiedName(self):

        localctx = HolisticsParser.QualifiedNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_qualifiedName)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 388
            self.identifier()
            self.state = 391 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 389
                    self.match(HolisticsParser.DOT)
                    self.state = 390
                    self.identifier()

                else:
                    raise NoViableAltException(self)
                self.state = 393 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,38,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TaggedBlockContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TAGGED_BLOCK(self):
            return self.getToken(HolisticsParser.TAGGED_BLOCK, 0)

        def getRuleIndex(self):
            return HolisticsParser.RULE_taggedBlock

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTaggedBlock" ):
                listener.enterTaggedBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTaggedBlock" ):
                listener.exitTaggedBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTaggedBlock" ):
                return visitor.visitTaggedBlock(self)
            else:
                return visitor.visitChildren(self)




    def taggedBlock(self):

        localctx = HolisticsParser.TaggedBlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_taggedBlock)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 395
            self.match(HolisticsParser.TAGGED_BLOCK)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StringContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING(self):
            return self.getToken(HolisticsParser.STRING, 0)

        def getRuleIndex(self):
            return HolisticsParser.RULE_string

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterString" ):
                listener.enterString(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitString" ):
                listener.exitString(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitString" ):
                return visitor.visitString(self)
            else:
                return visitor.visitChildren(self)




    def string(self):

        localctx = HolisticsParser.StringContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_string)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 397
            self.match(HolisticsParser.STRING)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMBER(self):
            return self.getToken(HolisticsParser.NUMBER, 0)

        def getRuleIndex(self):
            return HolisticsParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumber" ):
                return visitor.visitNumber(self)
            else:
                return visitor.visitChildren(self)




    def number(self):

        localctx = HolisticsParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_number)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 399
            self.match(HolisticsParser.NUMBER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BooleanContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TRUE(self):
            return self.getToken(HolisticsParser.TRUE, 0)

        def FALSE(self):
            return self.getToken(HolisticsParser.FALSE, 0)

        def getRuleIndex(self):
            return HolisticsParser.RULE_boolean

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBoolean" ):
                listener.enterBoolean(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBoolean" ):
                listener.exitBoolean(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBoolean" ):
                return visitor.visitBoolean(self)
            else:
                return visitor.visitChildren(self)




    def boolean(self):

        localctx = HolisticsParser.BooleanContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_boolean)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 401
            _la = self._input.LA(1)
            if not(_la==17 or _la==18):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NullValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NULL(self):
            return self.getToken(HolisticsParser.NULL, 0)

        def getRuleIndex(self):
            return HolisticsParser.RULE_nullValue

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNullValue" ):
                listener.enterNullValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNullValue" ):
                listener.exitNullValue(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNullValue" ):
                return visitor.visitNullValue(self)
            else:
                return visitor.visitChildren(self)




    def nullValue(self):

        localctx = HolisticsParser.NullValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_nullValue)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 403
            self.match(HolisticsParser.NULL)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdentifierContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(HolisticsParser.IDENTIFIER, 0)

        def MODEL(self):
            return self.getToken(HolisticsParser.MODEL, 0)

        def DATASET(self):
            return self.getToken(HolisticsParser.DATASET, 0)

        def RELATIONSHIP(self):
            return self.getToken(HolisticsParser.RELATIONSHIP, 0)

        def RELATIONSHIP_CONFIG(self):
            return self.getToken(HolisticsParser.RELATIONSHIP_CONFIG, 0)

        def DIMENSION(self):
            return self.getToken(HolisticsParser.DIMENSION, 0)

        def MEASURE(self):
            return self.getToken(HolisticsParser.MEASURE, 0)

        def METRIC(self):
            return self.getToken(HolisticsParser.METRIC, 0)

        def FUNC(self):
            return self.getToken(HolisticsParser.FUNC, 0)

        def CONSTANT(self):
            return self.getToken(HolisticsParser.CONSTANT, 0)

        def MODULE(self):
            return self.getToken(HolisticsParser.MODULE, 0)

        def EXTEND(self):
            return self.getToken(HolisticsParser.EXTEND, 0)

        def USE(self):
            return self.getToken(HolisticsParser.USE, 0)

        def CONST(self):
            return self.getToken(HolisticsParser.CONST, 0)

        def IF(self):
            return self.getToken(HolisticsParser.IF, 0)

        def ELSE(self):
            return self.getToken(HolisticsParser.ELSE, 0)

        def TRUE(self):
            return self.getToken(HolisticsParser.TRUE, 0)

        def FALSE(self):
            return self.getToken(HolisticsParser.FALSE, 0)

        def NULL(self):
            return self.getToken(HolisticsParser.NULL, 0)

        def getRuleIndex(self):
            return HolisticsParser.RULE_identifier

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdentifier" ):
                listener.enterIdentifier(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdentifier" ):
                listener.exitIdentifier(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIdentifier" ):
                return visitor.visitIdentifier(self)
            else:
                return visitor.visitChildren(self)




    def identifier(self):

        localctx = HolisticsParser.IdentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 92, self.RULE_identifier)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 405
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1125899907887102) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





