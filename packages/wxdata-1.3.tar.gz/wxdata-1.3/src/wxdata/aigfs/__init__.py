# (C) Eric J. Drewitz 2025-2026

from wxdata.aigfs.aigfs import aigfs