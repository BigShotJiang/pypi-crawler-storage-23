# (C) Eric J. Drewitz 2025-2026 

from wxdata.gfs.gfs import(
    gfs_0p25,
    gfs_0p25_secondary_parameters,
    gfs_0p50
)
