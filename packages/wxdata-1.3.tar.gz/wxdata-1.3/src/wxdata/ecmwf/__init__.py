# (C) Eric J. Drewitz 2025-2026

from wxdata.ecmwf.ecmwf import(
    ecmwf_ifs,
    ecmwf_aifs,
    ecmwf_ifs_high_res,
    ecmwf_ifs_wave
)

