"""Etcd validation rules for OpenShift clusters."""
