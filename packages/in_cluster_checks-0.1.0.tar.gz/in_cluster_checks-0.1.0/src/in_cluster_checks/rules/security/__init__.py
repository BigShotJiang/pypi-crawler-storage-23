"""Security validation rules."""
