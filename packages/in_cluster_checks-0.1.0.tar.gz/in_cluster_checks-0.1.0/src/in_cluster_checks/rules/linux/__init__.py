"""Linux validations for OpenShift in-cluster checks."""
