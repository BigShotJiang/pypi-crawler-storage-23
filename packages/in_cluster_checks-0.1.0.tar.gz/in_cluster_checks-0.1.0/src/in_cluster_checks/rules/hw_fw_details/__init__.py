"""Blueprint-style hardware validation rules."""
