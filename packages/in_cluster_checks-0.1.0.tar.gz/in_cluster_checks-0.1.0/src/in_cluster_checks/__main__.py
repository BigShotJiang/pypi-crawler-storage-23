"""Allow running as: python -m in_cluster_checks"""

from in_cluster_checks.cli import main

if __name__ == "__main__":
    main()
