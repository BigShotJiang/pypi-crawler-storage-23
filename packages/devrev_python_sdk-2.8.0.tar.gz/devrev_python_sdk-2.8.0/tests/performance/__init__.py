"""Performance benchmarks for DevRev SDK."""
