"""DevRev MCP Resources — URI-addressable DevRev objects."""
