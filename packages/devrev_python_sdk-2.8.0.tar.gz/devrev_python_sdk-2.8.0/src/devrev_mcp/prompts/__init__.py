"""DevRev MCP Prompts — pre-built support workflow templates."""
