"""Tests for client.py helper functions that don't require Redis."""

from __future__ import annotations

from redflow.client import (
    _decode,
    _normalize_max_concurrency,
    _parse_enqueue_result,
    _parse_redis_int,
    compute_retry_delay_ms,
    is_retryable_error,
    make_error_json,
)
from redflow.errors import (
    CanceledError,
    InputValidationError,
    NonRetriableError,
    OutputSerializationError,
    UnknownWorkflowError,
)


class TestNormalizeMaxConcurrency:
    def test_positive_int(self) -> None:
        assert _normalize_max_concurrency(5) == 5

    def test_zero_clamps_to_one(self) -> None:
        assert _normalize_max_concurrency(0) == 1

    def test_negative_clamps_to_one(self) -> None:
        assert _normalize_max_concurrency(-3) == 1

    def test_string_number(self) -> None:
        assert _normalize_max_concurrency("10") == 10

    def test_none_returns_one(self) -> None:
        assert _normalize_max_concurrency(None) == 1

    def test_invalid_string_returns_one(self) -> None:
        assert _normalize_max_concurrency("abc") == 1


class TestParseRedisInt:
    def test_none(self) -> None:
        assert _parse_redis_int(None) == 0

    def test_positive(self) -> None:
        assert _parse_redis_int(42) == 42

    def test_negative_clamps(self) -> None:
        assert _parse_redis_int(-5) == 0

    def test_string(self) -> None:
        assert _parse_redis_int("123") == 123

    def test_invalid(self) -> None:
        assert _parse_redis_int("not_a_number") == 0

    def test_bytes(self) -> None:
        assert _parse_redis_int(b"7") == 7


class TestDecode:
    def test_bytes(self) -> None:
        assert _decode(b"hello") == "hello"

    def test_str(self) -> None:
        assert _decode("world") == "world"

    def test_none(self) -> None:
        assert _decode(None) == ""

    def test_int(self) -> None:
        assert _decode(42) == "42"


class TestParseEnqueueResult:
    def test_created(self) -> None:
        result = _parse_enqueue_result(["created", "run-123"])
        assert result == ("created", "run-123")

    def test_existing(self) -> None:
        result = _parse_enqueue_result(["existing", "run-456"])
        assert result == ("existing", "run-456")

    def test_bytes(self) -> None:
        result = _parse_enqueue_result([b"created", b"run-789"])
        assert result == ("created", "run-789")

    def test_nested(self) -> None:
        result = _parse_enqueue_result([["created", "run-nested"]])
        assert result == ("created", "run-nested")

    def test_invalid_kind(self) -> None:
        assert _parse_enqueue_result(["unknown", "run-1"]) is None

    def test_empty_run_id(self) -> None:
        assert _parse_enqueue_result(["created", ""]) is None

    def test_not_list(self) -> None:
        assert _parse_enqueue_result("not a list") is None

    def test_none(self) -> None:
        assert _parse_enqueue_result(None) is None

    def test_empty_list(self) -> None:
        assert _parse_enqueue_result([]) is None


class TestComputeRetryDelayMs:
    def test_first_attempt(self) -> None:
        delay = compute_retry_delay_ms(1)
        assert 250 <= delay < 350  # base 250 + jitter 0-99

    def test_second_attempt(self) -> None:
        delay = compute_retry_delay_ms(2)
        assert 500 <= delay < 600

    def test_third_attempt(self) -> None:
        delay = compute_retry_delay_ms(3)
        assert 1000 <= delay < 1100

    def test_high_attempt_capped(self) -> None:
        delay = compute_retry_delay_ms(100)
        assert delay <= 30_100  # max_delay 30000 + jitter 99

    def test_zero_attempt(self) -> None:
        delay = compute_retry_delay_ms(0)
        assert 250 <= delay < 350


class TestIsRetryableError:
    def test_generic_exception(self) -> None:
        assert is_retryable_error(RuntimeError("oops")) is True

    def test_canceled(self) -> None:
        assert is_retryable_error(CanceledError("canceled")) is False

    def test_non_retriable(self) -> None:
        assert is_retryable_error(NonRetriableError("permanent")) is False

    def test_input_validation(self) -> None:
        assert is_retryable_error(InputValidationError("bad input")) is False

    def test_unknown_workflow(self) -> None:
        assert is_retryable_error(UnknownWorkflowError("missing")) is False

    def test_output_serialization(self) -> None:
        assert is_retryable_error(OutputSerializationError("bad output")) is False


class TestMakeErrorJson:
    def test_basic_error(self) -> None:
        result = make_error_json(RuntimeError("test error"))
        assert "test error" in result
        assert "RuntimeError" in result

    def test_non_exception(self) -> None:
        result = make_error_json("string error")
        assert isinstance(result, str)
