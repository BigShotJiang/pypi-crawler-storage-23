"""Compatibility module for public package namespace."""

from databricks_api.client import DatabricksApiClient

__all__ = ["DatabricksApiClient"]
