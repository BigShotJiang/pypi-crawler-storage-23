from setuptools import setup, find_packages

# Read the contents of your README file
try:
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
except UnicodeDecodeError:
    with open("README.md", "r", encoding="utf-16") as fh:
        long_description = fh.read()

setup(
    name="fdavrs",
    version="0.1.2", 
    packages=find_packages(),
    install_requires=[
        "torch>=2.0.0",
        "numpy>=1.24.0",
        "scipy>=1.11.0"
    ],
    author="Srivandhi",
    description="Federated Drift-Aware Vision Reliability System SDK",
    long_description=long_description,
    long_description_content_type="text/markdown", 
    
    # --- ADD YOUR GITHUB LINKS HERE ---
    url="https://github.com/Srivandhi/FDAVRS", # The main homepage link
    project_urls={
        "Clients": "https://github.com/Srivandhi/FDAVRS/tree/main/clients",
    },
)