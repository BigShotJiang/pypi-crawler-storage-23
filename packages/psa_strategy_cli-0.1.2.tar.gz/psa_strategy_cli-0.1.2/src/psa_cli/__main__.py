from __future__ import annotations

from psa_cli.app import main

if __name__ == "__main__":
    raise SystemExit(main())
