from .loader import load_customer_demo

__all__ = ["load_customer_demo"]