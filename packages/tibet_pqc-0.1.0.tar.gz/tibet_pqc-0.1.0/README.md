# tibet-pqc — Post-Quantum Crypto Shield Router

> Bridge legacy RSA/ECC to quantum-safe algorithms without touching legacy devices.
>
> Same pattern as tibet-y2k38: protect legacy via a router, not via replacement.

**tibet-pqc** shields data from quantum-vulnerable devices by wrapping it in post-quantum cryptography at the router level. Every cryptographic transition is tracked with [TIBET](https://pypi.org/project/tibet-core/) provenance tokens.

## The "Store Now, Decrypt Later" Crisis

Adversaries are intercepting encrypted traffic **today** and storing it. When cryptographically relevant quantum computers arrive (~2030), they'll decrypt everything. This is not theoretical — the NSA, NCSC, and BSI are actively warning about it.

Your legacy SCADA PLC running RSA-1024 can't be upgraded. But the data it sends can be **shielded** at the network boundary.

## Install

```bash
pip install tibet-pqc
```

## Quick Start

### Shield a legacy device

```python
from tibet_pqc import PQCRouter, ClassicAlgorithm

router = PQCRouter()
router.add_device("plc-01", classic=ClassicAlgorithm.RSA_1024, profile="scada")
result = router.shield("plc-01", data=b"sensor_reading_42")

print(result.pqc_algorithm)    # ml-kem-512
print(result.security_level)   # 1
print(result.shielded)         # True
```

### Scan for vulnerable endpoints

```bash
tibet-pqc scan example.com:443 api.example.com:443

  🟠 example.com:443
     Algorithm: rsa-2048 (256 bits)
     Risk:      HIGH
     Migrate:   → ml-kem-768 (Level 3)
```

```bash
pqc-scan --json example.com:443 | jq '.[].risk'
```

### View Q-Day countdown

```bash
tibet-pqc info
```

### Run interactive demo

```bash
tibet-pqc demo
```

## How It Works

```
[Legacy Device]  --RSA/ECC-->  [PQC Shield Router]  --ML-KEM-->  [Internet]
  (unchanged)                       |                              (quantum-safe)
                              TIBET audit-trail
                              JIS quantum-ID
```

1. Legacy device sends data encrypted with classic crypto (RSA, ECDSA, etc.)
2. PQC Router intercepts at the network boundary
3. Router wraps the data in a post-quantum shell (ML-KEM, ML-DSA)
4. Data travels quantum-safe over the internet
5. TIBET creates an audit trail of the transition
6. JIS provides quantum-resistant device identity

The legacy device never needs to change.

## NIST Standards (August 2024)

| Standard | Algorithm | Purpose | Replaces |
|----------|-----------|---------|----------|
| FIPS 203 | ML-KEM (Kyber) | Key Encapsulation | RSA, ECDH |
| FIPS 204 | ML-DSA (Dilithium) | Digital Signatures | RSA, ECDSA |
| FIPS 205 | SLH-DSA (SPHINCS+) | Hash-based Signatures | RSA, DSA |

## Sector Profiles

| Profile | Sector | Classic Crypto | → PQC | SNDL Risk | Compliance |
|---------|--------|---------------|-------|-----------|------------|
| `banking` | Financial | RSA-2048 | ML-KEM-1024 | Critical | PCI DSS, DORA, NIS2 |
| `healthcare` | Medical | RSA-2048 | ML-KEM-768 | Critical | HIPAA, MDR, FDA |
| `government` | Gov/Defense | RSA-4096 | ML-KEM-1024 | Critical | CNSA 2.0, eIDAS 2.0 |
| `scada` | Industrial | RSA-1024 | ML-KEM-512 | High | IEC 62443, NIS2 |
| `telecom` | Telecom | ECDSA-P256 | ML-DSA-65 | Critical | 3GPP, GSMA, NIS2 |
| `iot` | IoT | ECDSA-P256 | ML-KEM-512 | Medium | ETSI, CE RED |
| `generic` | IT | RSA-2048 | ML-KEM-768 | High | SOC2, ISO 27001 |

```bash
tibet-pqc profiles
tibet-pqc profiles --json
```

## TIBET Provenance

Every shield operation creates a TIBET token:

| Layer | Content |
|-------|---------|
| **ERIN** | What was shielded (data hash, algorithm transition) |
| **ERAAN** | Device dependencies (JIS identity, firmware) |
| **EROMHEEN** | Context (router, timestamp, network) |
| **ERACHTER** | Intent (compliance requirement, SNDL protection) |

This gives you **proof** of when each system was migrated to PQC — critical for compliance audits.

## Part of the TIBET ecosystem

| Package | Purpose |
|---------|---------|
| [`tibet-core`](https://pypi.org/project/tibet-core/) | Protocol core |
| [`tibet-y2k38`](https://pypi.org/project/tibet-y2k38/) | Y2K38 Time Bridge |
| [`tibet-pol`](https://pypi.org/project/tibet-pol/) | Process Integrity Checker |
| **tibet-pqc** | Post-Quantum Crypto Router |
| [`tibet-overlay`](https://pypi.org/project/tibet-overlay/) | Identity Overlay |
| [`tibet-twin`](https://pypi.org/project/tibet-twin/) | Digital Twin Guard |

## License

MIT — Humotica AI Lab 2025-2026

## Authors

- **J. van de Meent** — jasper@humotica.com
- **R. AI (Root AI)** — root_idd@humotica.nl
