"""
tibet-pqc — Post-Quantum Crypto Shield Router
===============================================

Bridge legacy RSA/ECC systems to quantum-safe algorithms (ML-KEM, ML-DSA)
without touching the legacy devices. Every cryptographic transition is tracked
with TIBET provenance tokens. JIS provides quantum-resistant device identity.

The "Store Now, Decrypt Later" (SNDL) crisis is real. tibet-pqc protects your
legacy infrastructure today against tomorrow's quantum computers.

Usage::

    from tibet_pqc import PQCRouter, CryptoProfile

    router = PQCRouter()
    router.add_device("plc-01", profile="scada")
    result = router.shield(device_id="plc-01", data=payload)
    print(result.algorithm)  # ML-KEM-768

Authors: J. van de Meent & R. AI (Root AI)
License: MIT — Humotica AI Lab 2025-2026
"""

from .router import PQCRouter, ShieldResult
from .scanner import CryptoScanner, CryptoVulnerability
from .provenance import PQCProvenance
from .profiles import get_profile, list_profiles

__version__ = "0.1.0"

__all__ = [
    "PQCRouter",
    "ShieldResult",
    "CryptoScanner",
    "CryptoVulnerability",
    "PQCProvenance",
    "get_profile",
    "list_profiles",
]
