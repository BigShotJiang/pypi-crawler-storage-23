"""
Sector profiles for PQC migration.

Each profile defines the typical cryptographic landscape
of a sector and the recommended migration path.
"""

from dataclasses import dataclass, field
from ..router import ClassicAlgorithm, PQCAlgorithm, SecurityLevel


@dataclass
class PQCProfile:
    """Sector-specific PQC migration profile."""
    name: str
    description: str
    sector: str
    typical_classic: ClassicAlgorithm
    recommended_pqc: PQCAlgorithm
    recommended_level: SecurityLevel
    compliance: list[str] = field(default_factory=list)
    typical_devices: list[str] = field(default_factory=list)
    sndl_risk: str = "high"  # How valuable is stored data to future decryption?
    migration_complexity: str = "medium"  # low/medium/high/extreme
    estimated_devices_global: str = ""
    notes: str = ""


_PROFILES: dict[str, PQCProfile] = {}


def _register(p: PQCProfile) -> None:
    _PROFILES[p.name] = p


def get_profile(name: str) -> PQCProfile:
    if name not in _PROFILES:
        raise ValueError(f"Unknown profile: {name}. Available: {list(_PROFILES.keys())}")
    return _PROFILES[name]


def list_profiles() -> list[str]:
    return list(_PROFILES.keys())


def all_profiles() -> list[PQCProfile]:
    return list(_PROFILES.values())


# --- Banking/Financial ---
_register(PQCProfile(
    name="banking",
    description="Financial systems: ATMs, SWIFT, online banking, HSMs",
    sector="Financial Services",
    typical_classic=ClassicAlgorithm.RSA_2048,
    recommended_pqc=PQCAlgorithm.ML_KEM_1024,
    recommended_level=SecurityLevel.LEVEL_5,
    compliance=["PCI DSS 4.0", "DORA", "MiFID II", "NIS2", "ECB TIBER-EU"],
    typical_devices=["ATMs (NCR/Diebold)", "HSMs (Thales/nCipher)", "SWIFT terminals", "POS systems"],
    sndl_risk="critical",
    migration_complexity="extreme",
    estimated_devices_global="5M+ ATMs, 100K+ HSMs",
    notes="Financial data has indefinite value for SNDL. ECB mandates PQC readiness by 2030.",
))

# --- Healthcare ---
_register(PQCProfile(
    name="healthcare",
    description="Medical devices, health records, hospital networks",
    sector="Healthcare",
    typical_classic=ClassicAlgorithm.RSA_2048,
    recommended_pqc=PQCAlgorithm.ML_KEM_768,
    recommended_level=SecurityLevel.LEVEL_3,
    compliance=["HIPAA", "MDR 2017/745", "FDA 21 CFR Part 11", "NIS2"],
    typical_devices=["MRI/CT scanners (Siemens/Philips)", "patient monitors", "infusion pumps", "EMR systems"],
    sndl_risk="critical",
    migration_complexity="high",
    estimated_devices_global="10M+ connected medical devices",
    notes="Patient data is protected for life. SNDL attack on health records is catastrophic.",
))

# --- Government ---
_register(PQCProfile(
    name="government",
    description="Government IT, classified networks, eID systems",
    sector="Government",
    typical_classic=ClassicAlgorithm.RSA_4096,
    recommended_pqc=PQCAlgorithm.ML_KEM_1024,
    recommended_level=SecurityLevel.LEVEL_5,
    compliance=["CNSA 2.0", "BSI TR-02102", "ANSSI", "NIS2", "eIDAS 2.0"],
    typical_devices=["PKI infrastructure", "eID cards", "VPN gateways", "classified networks"],
    sndl_risk="critical",
    migration_complexity="extreme",
    estimated_devices_global="Varies by country",
    notes="NSA CNSA 2.0 mandates ML-KEM-1024 and ML-DSA-87 by 2035.",
))

# --- Industrial/SCADA ---
_register(PQCProfile(
    name="scada",
    description="Industrial control systems, PLCs, SCADA networks",
    sector="Industrial",
    typical_classic=ClassicAlgorithm.RSA_1024,
    recommended_pqc=PQCAlgorithm.ML_KEM_512,
    recommended_level=SecurityLevel.LEVEL_1,
    compliance=["IEC 62443", "NIS2", "NERC CIP"],
    typical_devices=["Siemens S7 PLCs", "Allen-Bradley", "Modbus gateways", "RTUs"],
    sndl_risk="high",
    migration_complexity="extreme",
    estimated_devices_global="50M+ industrial controllers",
    notes="Many SCADA devices can't be updated. Router-based shielding is the only option.",
))

# --- Telecom ---
_register(PQCProfile(
    name="telecom",
    description="Telecom infrastructure, 5G cores, SIM/eSIM",
    sector="Telecommunications",
    typical_classic=ClassicAlgorithm.ECDSA_P256,
    recommended_pqc=PQCAlgorithm.ML_DSA_65,
    recommended_level=SecurityLevel.LEVEL_3,
    compliance=["3GPP SA3", "GSMA", "NIS2", "ETSI"],
    typical_devices=["5G core (Nokia/Ericsson)", "SIM cards", "VoLTE gateways", "lawful intercept"],
    sndl_risk="critical",
    migration_complexity="high",
    estimated_devices_global="8B+ SIM cards, 10M+ base stations",
    notes="3GPP Release 19+ includes PQC specifications. SIM crypto must migrate.",
))

# --- IoT ---
_register(PQCProfile(
    name="iot",
    description="IoT devices, smart home, sensors, embedded systems",
    sector="IoT",
    typical_classic=ClassicAlgorithm.ECDSA_P256,
    recommended_pqc=PQCAlgorithm.ML_KEM_512,
    recommended_level=SecurityLevel.LEVEL_1,
    compliance=["ETSI EN 303 645", "NIST IR 8259", "CE RED"],
    typical_devices=["ESP32", "STM32", "Arduino", "Zigbee hubs", "smart meters"],
    sndl_risk="medium",
    migration_complexity="high",
    estimated_devices_global="15B+ IoT devices",
    notes="Constrained devices need lightweight PQC. ML-KEM-512 fits in 32KB RAM.",
))

# --- Generic ---
_register(PQCProfile(
    name="generic",
    description="General purpose servers, web services, APIs",
    sector="IT",
    typical_classic=ClassicAlgorithm.RSA_2048,
    recommended_pqc=PQCAlgorithm.ML_KEM_768,
    recommended_level=SecurityLevel.LEVEL_3,
    compliance=["SOC2", "ISO 27001", "NIS2"],
    typical_devices=["Web servers", "API gateways", "databases", "message queues"],
    sndl_risk="high",
    migration_complexity="medium",
    estimated_devices_global="100M+ servers",
    notes="Most web servers can upgrade via OpenSSL 3.x with OQS provider.",
))
