"""
Crypto vulnerability scanner — find legacy crypto in your infrastructure.

Scans certificates, connections, and configurations to identify
systems still using quantum-vulnerable cryptography.
"""

import hashlib
import ssl
import socket
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

from .router import ClassicAlgorithm, PQC_MIGRATION_MAP, PQCAlgorithm, SecurityLevel


class RiskLevel(Enum):
    CRITICAL = "critical"  # RSA-1024, DSA, 3DES — broken NOW
    HIGH = "high"          # RSA-2048, ECDSA-P256 — SNDL vulnerable
    MEDIUM = "medium"      # RSA-4096, ECDSA-P384 — migrate within 3 years
    LOW = "low"            # Already hybrid or PQC
    SAFE = "safe"          # Fully migrated


RISK_MAP: dict[ClassicAlgorithm, RiskLevel] = {
    ClassicAlgorithm.RSA_1024: RiskLevel.CRITICAL,
    ClassicAlgorithm.DSA_1024: RiskLevel.CRITICAL,
    ClassicAlgorithm.THREEDES: RiskLevel.CRITICAL,
    ClassicAlgorithm.RSA_2048: RiskLevel.HIGH,
    ClassicAlgorithm.ECDSA_P256: RiskLevel.HIGH,
    ClassicAlgorithm.ECDH_P256: RiskLevel.HIGH,
    ClassicAlgorithm.DH_2048: RiskLevel.HIGH,
    ClassicAlgorithm.RSA_4096: RiskLevel.MEDIUM,
    ClassicAlgorithm.ECDSA_P384: RiskLevel.MEDIUM,
}


@dataclass
class CryptoVulnerability:
    """A discovered cryptographic vulnerability."""
    host: str
    port: int
    algorithm: ClassicAlgorithm
    key_bits: int
    risk: RiskLevel
    recommended_pqc: PQCAlgorithm
    recommended_level: SecurityLevel
    certificate_subject: str = ""
    certificate_expiry: str = ""
    discovered_at: str = ""

    def to_dict(self) -> dict:
        return {
            "host": self.host,
            "port": self.port,
            "algorithm": self.algorithm.value,
            "key_bits": self.key_bits,
            "risk": self.risk.value,
            "recommended_pqc": self.recommended_pqc.value,
            "recommended_level": self.recommended_level.value,
            "certificate_subject": self.certificate_subject,
            "certificate_expiry": self.certificate_expiry,
            "discovered_at": self.discovered_at,
        }


class CryptoScanner:
    """
    Scan network endpoints for quantum-vulnerable cryptography.

    Usage::

        scanner = CryptoScanner()
        vulns = scanner.scan_host("example.com", 443)
        for v in vulns:
            print(f"{v.host}: {v.algorithm.value} → {v.recommended_pqc.value}")
    """

    def __init__(self):
        self.results: list[CryptoVulnerability] = []

    def scan_host(self, host: str, port: int = 443, timeout: float = 5.0) -> list[CryptoVulnerability]:
        """Scan a TLS endpoint for vulnerable crypto."""
        vulns = []
        now = datetime.now(timezone.utc).isoformat()

        try:
            ctx = ssl.create_default_context()
            with socket.create_connection((host, port), timeout=timeout) as sock:
                with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                    cert = ssock.getpeercert()
                    cipher = ssock.cipher()

                    # Analyze cipher suite
                    if cipher:
                        cipher_name, _, key_bits = cipher
                        algo = self._classify_cipher(cipher_name, key_bits)

                        if algo != ClassicAlgorithm.UNKNOWN:
                            risk = RISK_MAP.get(algo, RiskLevel.MEDIUM)
                            rec_pqc, rec_level = PQC_MIGRATION_MAP.get(
                                algo, (PQCAlgorithm.ML_KEM_768, SecurityLevel.LEVEL_3)
                            )

                            subject = ""
                            expiry = ""
                            if cert:
                                subject_parts = cert.get("subject", ())
                                for part in subject_parts:
                                    for key, val in part:
                                        if key == "commonName":
                                            subject = val
                                expiry = cert.get("notAfter", "")

                            vuln = CryptoVulnerability(
                                host=host,
                                port=port,
                                algorithm=algo,
                                key_bits=key_bits,
                                risk=risk,
                                recommended_pqc=rec_pqc,
                                recommended_level=rec_level,
                                certificate_subject=subject,
                                certificate_expiry=expiry,
                                discovered_at=now,
                            )
                            vulns.append(vuln)

        except (socket.timeout, ConnectionRefusedError, ssl.SSLError, OSError):
            pass

        self.results.extend(vulns)
        return vulns

    def scan_hosts(self, hosts: list[tuple[str, int]]) -> list[CryptoVulnerability]:
        """Scan multiple endpoints."""
        all_vulns = []
        for host, port in hosts:
            vulns = self.scan_host(host, port)
            all_vulns.extend(vulns)
        return all_vulns

    def risk_summary(self) -> dict:
        """Summarize scan results by risk level."""
        summary: dict[str, int] = {}
        for v in self.results:
            summary[v.risk.value] = summary.get(v.risk.value, 0) + 1
        return {
            "total_scanned": len(self.results),
            "by_risk": summary,
        }

    @staticmethod
    def _classify_cipher(cipher_name: str, key_bits: int) -> ClassicAlgorithm:
        """Classify a TLS cipher suite into a classic algorithm category."""
        name = cipher_name.upper()

        if "ECDSA" in name or "ECDHE" in name:
            if key_bits >= 384:
                return ClassicAlgorithm.ECDSA_P384
            return ClassicAlgorithm.ECDSA_P256

        if "RSA" in name:
            if key_bits >= 4096:
                return ClassicAlgorithm.RSA_4096
            if key_bits >= 2048:
                return ClassicAlgorithm.RSA_2048
            return ClassicAlgorithm.RSA_1024

        if "DH" in name:
            return ClassicAlgorithm.DH_2048

        if "3DES" in name or "DES-CBC3" in name:
            return ClassicAlgorithm.THREEDES

        return ClassicAlgorithm.UNKNOWN
