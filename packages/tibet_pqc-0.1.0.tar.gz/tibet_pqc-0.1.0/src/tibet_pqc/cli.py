"""
tibet-pqc CLI — Post-Quantum Crypto Shield Router.

Usage::

    tibet-pqc info              Show PQC overview and Q-Day countdown
    tibet-pqc scan HOST:PORT    Scan endpoint for vulnerable crypto
    tibet-pqc profiles          List sector profiles
    tibet-pqc demo              Interactive demo
    tibet-pqc report            JSON migration report
"""

import argparse
import json
import sys
from datetime import datetime, timezone

from .router import PQCRouter, ClassicAlgorithm, PQCAlgorithm
from .scanner import CryptoScanner
from .profiles import all_profiles, get_profile


def cmd_info(args: argparse.Namespace) -> int:
    """Show PQC overview and Q-Day countdown."""
    # Estimated Q-Day range (cryptographically relevant quantum computer)
    q_day_early = datetime(2029, 1, 1, tzinfo=timezone.utc)
    q_day_likely = datetime(2033, 1, 1, tzinfo=timezone.utc)
    now = datetime.now(timezone.utc)
    days_early = (q_day_early - now).days
    days_likely = (q_day_likely - now).days

    print()
    print("=" * 60)
    print("🛡️  TIBET-PQC — Post-Quantum Crypto Shield Router")
    print("=" * 60)
    print()
    print("The Threat: Store Now, Decrypt Later (SNDL)")
    print("  Adversaries intercept encrypted data TODAY and store it.")
    print("  When quantum computers arrive, they decrypt it ALL.")
    print()
    print(f"  ⏱️  Q-Day (optimistic): ~{days_early} days ({q_day_early.year})")
    print(f"  ⏱️  Q-Day (likely):     ~{days_likely} days ({q_day_likely.year})")
    print()
    print("NIST Standards (August 2024):")
    print("  FIPS 203: ML-KEM (Kyber)     — Key Encapsulation")
    print("  FIPS 204: ML-DSA (Dilithium) — Digital Signatures")
    print("  FIPS 205: SLH-DSA (SPHINCS+) — Hash-based Signatures")
    print()
    print("How tibet-pqc works:")
    print("  [Legacy device] --classic--> [PQC Router] --ML-KEM--> [Internet]")
    print("                                    |")
    print("                              TIBET audit-trail")
    print("                              JIS quantum-ID")
    print()
    print("  Same pattern as tibet-y2k38: protect legacy via router,")
    print("  don't touch the legacy device itself.")
    print()
    print("=" * 60)
    return 0


def cmd_scan(args: argparse.Namespace) -> int:
    """Scan endpoints for quantum-vulnerable crypto."""
    scanner = CryptoScanner()

    targets = []
    for target in args.targets:
        if ":" in target:
            host, port = target.rsplit(":", 1)
            targets.append((host, int(port)))
        else:
            targets.append((target, 443))

    if not args.json:
        print(f"\n🔍 Scanning {len(targets)} endpoint(s) for quantum-vulnerable crypto...\n")

    vulns = scanner.scan_hosts(targets)

    if args.json:
        print(json.dumps([v.to_dict() for v in vulns], indent=2))
    else:
        if not vulns:
            print("  No vulnerabilities found (or hosts unreachable).")
        else:
            for v in vulns:
                risk_emoji = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🟢"}.get(v.risk.value, "⚪")
                print(f"  {risk_emoji} {v.host}:{v.port}")
                print(f"     Algorithm: {v.algorithm.value} ({v.key_bits} bits)")
                print(f"     Risk:      {v.risk.value.upper()}")
                print(f"     Migrate:   → {v.recommended_pqc.value} (Level {v.recommended_level.value})")
                if v.certificate_subject:
                    print(f"     Subject:   {v.certificate_subject}")
                print()

        summary = scanner.risk_summary()
        print(f"  Summary: {summary['total_scanned']} endpoint(s) scanned")
        for risk, count in summary["by_risk"].items():
            print(f"    {risk}: {count}")

    return 0


def cmd_profiles(args: argparse.Namespace) -> int:
    """List sector profiles."""
    profiles = all_profiles()

    if args.json:
        data = []
        for p in profiles:
            data.append({
                "name": p.name,
                "sector": p.sector,
                "classic": p.typical_classic.value,
                "pqc": p.recommended_pqc.value,
                "level": p.recommended_level.value,
                "sndl_risk": p.sndl_risk,
                "compliance": p.compliance,
            })
        print(json.dumps(data, indent=2))
    else:
        print()
        print(f"{'Profile':<12} {'Sector':<20} {'Classic':<14} {'→ PQC':<14} {'SNDL Risk':<10} {'Compliance'}")
        print("-" * 95)
        for p in profiles:
            compliance = ", ".join(p.compliance[:3])
            print(
                f"{p.name:<12} {p.sector:<20} {p.typical_classic.value:<14} "
                f"→ {p.recommended_pqc.value:<12} {p.sndl_risk:<10} {compliance}"
            )
        print()

    return 0


def cmd_demo(args: argparse.Namespace) -> int:
    """Interactive demo."""
    print("\n🛡️  tibet-pqc Demo: Shielding a SCADA network\n")

    router = PQCRouter(hybrid=True)

    devices = [
        ("plc-siemens-01", ClassicAlgorithm.RSA_1024, "scada"),
        ("plc-allen-02", ClassicAlgorithm.RSA_2048, "scada"),
        ("hmi-panel-03", ClassicAlgorithm.ECDSA_P256, "scada"),
        ("historian-04", ClassicAlgorithm.RSA_4096, "generic"),
    ]

    for dev_id, classic, profile in devices:
        entry = router.add_device(dev_id, classic=classic, profile=profile)
        print(f"  📡 Registered {dev_id}: {classic.value} → {entry.target_pqc.value}")

    print()
    for dev_id, _, _ in devices:
        result = router.shield(dev_id, data=f"sensor_reading_{dev_id}")
        warn = f" ⚠️  {result.warnings[0][:50]}" if result.warnings else ""
        print(f"  🛡️  Shielded {dev_id}: {result.pqc_algorithm.value} (Level {result.security_level.value}){warn}")

    print()
    status = router.status()
    print(f"  Network: {status['total_devices']} devices, {status['at_risk']} at risk")
    print(f"  Shielded: {status['total_shielded']} data packets")
    print(f"  TIBET tokens: {len(router.export_audit())}")
    print()

    return 0


def scan_main() -> None:
    """Entry point for pqc-scan command."""
    parser = argparse.ArgumentParser(prog="pqc-scan", description="Scan for quantum-vulnerable crypto")
    parser.add_argument("targets", nargs="+", help="host:port to scan")
    parser.add_argument("-j", "--json", action="store_true")
    args = parser.parse_args()
    sys.exit(cmd_scan(args))


def main() -> None:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="tibet-pqc",
        description="Post-Quantum Crypto Shield Router",
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("info", help="PQC overview and Q-Day countdown")

    p_scan = sub.add_parser("scan", help="Scan endpoints for vulnerable crypto")
    p_scan.add_argument("targets", nargs="+", help="host:port to scan")
    p_scan.add_argument("-j", "--json", action="store_true")

    p_prof = sub.add_parser("profiles", help="List sector profiles")
    p_prof.add_argument("-j", "--json", action="store_true")

    sub.add_parser("demo", help="Interactive demo")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)

    commands = {"info": cmd_info, "scan": cmd_scan, "profiles": cmd_profiles, "demo": cmd_demo}
    sys.exit(commands[args.command](args))
