"""
TIBET provenance for PQC migration audit trail.

Every cryptographic transition (classic → quantum-safe) produces a TIBET token:
- ERIN:     What was shielded (data hash, algorithm transition)
- ERAAN:    Device dependencies (JIS identity, firmware version)
- EROMHEEN: Context (router instance, timestamp, network)
- ERACHTER: Intent (why this transition, compliance requirement)
"""

import hashlib
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class PQCToken:
    """A TIBET token for a PQC transition event."""
    token_id: str
    timestamp: str
    device_id: str
    action: str
    classic_algorithm: str
    pqc_algorithm: str
    security_level: int

    erin: dict = field(default_factory=dict)
    eraan: dict = field(default_factory=dict)
    eromheen: dict = field(default_factory=dict)
    erachter: dict = field(default_factory=dict)

    parent_id: Optional[str] = None
    content_hash: str = ""

    def to_dict(self) -> dict:
        return {
            "token_id": self.token_id,
            "timestamp": self.timestamp,
            "type": "pqc_transition",
            "device_id": self.device_id,
            "action": self.action,
            "erin": self.erin,
            "eraan": self.eraan,
            "eromheen": self.eromheen,
            "erachter": self.erachter,
            "parent_id": self.parent_id,
            "content_hash": self.content_hash,
        }


class PQCProvenance:
    """Creates TIBET tokens for PQC migration events."""

    def __init__(self, actor: str = "tibet-pqc"):
        self.actor = actor
        self.tokens: list[PQCToken] = []
        self._last_id: str | None = None

    def create_token(
        self,
        device_id: str,
        action: str,
        classic: str,
        pqc: str,
        level: int,
        data_hash: str,
        hybrid: bool = False,
    ) -> PQCToken:
        now = datetime.now(timezone.utc).isoformat()

        erin = {
            "device_id": device_id,
            "action": action,
            "classic_algorithm": classic,
            "pqc_algorithm": pqc,
            "security_level": level,
            "data_hash": data_hash,
            "hybrid_mode": hybrid,
        }

        eraan = {
            "device_jis": f"jis:{device_id}",
            "parent_token": self._last_id,
        }

        eromheen = {
            "router": os.uname().nodename,
            "timestamp": now,
            "actor": self.actor,
        }

        erachter = {
            "intent": f"Shield {device_id} data: {classic} → {pqc}",
            "compliance": "NIST FIPS 203/204 PQC migration",
            "sndl_protection": True,
        }

        import json
        content = json.dumps({"erin": erin, "eraan": eraan}, sort_keys=True)
        token_id = hashlib.sha256(
            f"{device_id}:{action}:{now}".encode()
        ).hexdigest()[:16]
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:32]

        token = PQCToken(
            token_id=token_id,
            timestamp=now,
            device_id=device_id,
            action=action,
            classic_algorithm=classic,
            pqc_algorithm=pqc,
            security_level=level,
            erin=erin,
            eraan=eraan,
            eromheen=eromheen,
            erachter=erachter,
            parent_id=self._last_id,
            content_hash=content_hash,
        )

        self.tokens.append(token)
        self._last_id = token.token_id
        return token

    def chain(self) -> list[dict]:
        return [t.to_dict() for t in self.tokens]
