"""
PQC Shield Router — bridges legacy crypto to quantum-safe algorithms.

Same pattern as tibet-y2k38: legacy devices run locally unchanged,
the router wraps outbound data in a post-quantum cryptographic shell.

Supported algorithms (NIST FIPS 203/204, August 2024):
- ML-KEM-512/768/1024 (Key Encapsulation, formerly Kyber)
- ML-DSA-44/65/87 (Digital Signatures, formerly Dilithium)
- SLH-DSA (Stateless Hash-based Signatures, formerly SPHINCS+)
"""

import hashlib
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

from .provenance import PQCProvenance


class ClassicAlgorithm(Enum):
    """Legacy cryptographic algorithms vulnerable to quantum attack."""
    RSA_1024 = "rsa-1024"
    RSA_2048 = "rsa-2048"
    RSA_4096 = "rsa-4096"
    ECDSA_P256 = "ecdsa-p256"
    ECDSA_P384 = "ecdsa-p384"
    ECDH_P256 = "ecdh-p256"
    DH_2048 = "dh-2048"
    DSA_1024 = "dsa-1024"
    THREEDES = "3des"
    UNKNOWN = "unknown"


class PQCAlgorithm(Enum):
    """Post-quantum safe algorithms (NIST standardized)."""
    ML_KEM_512 = "ml-kem-512"       # FIPS 203 — Level 1
    ML_KEM_768 = "ml-kem-768"       # FIPS 203 — Level 3
    ML_KEM_1024 = "ml-kem-1024"     # FIPS 203 — Level 5
    ML_DSA_44 = "ml-dsa-44"         # FIPS 204 — Level 2
    ML_DSA_65 = "ml-dsa-65"         # FIPS 204 — Level 3
    ML_DSA_87 = "ml-dsa-87"         # FIPS 204 — Level 5
    SLH_DSA_128S = "slh-dsa-128s"   # FIPS 205 — Level 1
    SLH_DSA_256S = "slh-dsa-256s"   # FIPS 205 — Level 5


class SecurityLevel(Enum):
    """NIST post-quantum security levels."""
    LEVEL_1 = 1  # At least as hard as AES-128
    LEVEL_2 = 2  # At least as hard as SHA-256
    LEVEL_3 = 3  # At least as hard as AES-192
    LEVEL_4 = 4  # At least as hard as SHA-384
    LEVEL_5 = 5  # At least as hard as AES-256


# Mapping: classic algorithm → recommended PQC replacement
PQC_MIGRATION_MAP: dict[ClassicAlgorithm, tuple[PQCAlgorithm, SecurityLevel]] = {
    ClassicAlgorithm.RSA_1024: (PQCAlgorithm.ML_KEM_512, SecurityLevel.LEVEL_1),
    ClassicAlgorithm.RSA_2048: (PQCAlgorithm.ML_KEM_768, SecurityLevel.LEVEL_3),
    ClassicAlgorithm.RSA_4096: (PQCAlgorithm.ML_KEM_1024, SecurityLevel.LEVEL_5),
    ClassicAlgorithm.ECDSA_P256: (PQCAlgorithm.ML_DSA_44, SecurityLevel.LEVEL_2),
    ClassicAlgorithm.ECDSA_P384: (PQCAlgorithm.ML_DSA_65, SecurityLevel.LEVEL_3),
    ClassicAlgorithm.ECDH_P256: (PQCAlgorithm.ML_KEM_768, SecurityLevel.LEVEL_3),
    ClassicAlgorithm.DH_2048: (PQCAlgorithm.ML_KEM_768, SecurityLevel.LEVEL_3),
    ClassicAlgorithm.DSA_1024: (PQCAlgorithm.ML_DSA_44, SecurityLevel.LEVEL_2),
    ClassicAlgorithm.THREEDES: (PQCAlgorithm.ML_KEM_512, SecurityLevel.LEVEL_1),
}


@dataclass
class ShieldResult:
    """Result of shielding data through the PQC router."""
    device_id: str
    classic_algorithm: ClassicAlgorithm
    pqc_algorithm: PQCAlgorithm
    security_level: SecurityLevel
    shielded: bool
    timestamp: str
    data_hash: str
    provenance_token: Optional[dict] = None
    warnings: list[str] = field(default_factory=list)
    hybrid_mode: bool = False  # Classic + PQC combined

    def to_dict(self) -> dict:
        return {
            "device_id": self.device_id,
            "classic_algorithm": self.classic_algorithm.value,
            "pqc_algorithm": self.pqc_algorithm.value,
            "security_level": self.security_level.value,
            "shielded": self.shielded,
            "timestamp": self.timestamp,
            "data_hash": self.data_hash,
            "hybrid_mode": self.hybrid_mode,
            "warnings": self.warnings,
        }


@dataclass
class DeviceEntry:
    """A registered device with its crypto profile."""
    device_id: str
    classic_algorithm: ClassicAlgorithm
    target_pqc: PQCAlgorithm
    target_level: SecurityLevel
    profile: str
    migrated: bool = False
    migration_date: Optional[str] = None
    jis_identity: Optional[str] = None


class PQCRouter:
    """
    Post-Quantum Crypto Shield Router.

    Bridges legacy cryptographic systems to quantum-safe algorithms.
    Every transition is tracked with TIBET provenance tokens.

    Same pattern as tibet-y2k38 TimeRouter:
    - Legacy device runs unchanged
    - Router wraps outbound data in PQC shell
    - TIBET tracks the transition audit trail
    - JIS provides quantum-resistant identity

    Usage::

        router = PQCRouter()
        router.add_device("plc-01", classic=ClassicAlgorithm.RSA_2048, profile="scada")
        result = router.shield("plc-01", data=b"sensor_reading")
    """

    def __init__(self, hybrid: bool = True, actor: str = "tibet-pqc"):
        self.devices: dict[str, DeviceEntry] = {}
        self.provenance = PQCProvenance(actor=actor)
        self.hybrid = hybrid  # Use hybrid (classic + PQC) by default
        self._stats = {"shielded": 0, "devices": 0, "migrations": 0}

    def add_device(
        self,
        device_id: str,
        classic: ClassicAlgorithm = ClassicAlgorithm.RSA_2048,
        profile: str = "generic",
        jis_identity: str | None = None,
        target_pqc: PQCAlgorithm | None = None,
        target_level: SecurityLevel | None = None,
    ) -> DeviceEntry:
        """Register a device with its current classic crypto."""
        # Lookup recommended PQC replacement
        rec_pqc, rec_level = PQC_MIGRATION_MAP.get(
            classic, (PQCAlgorithm.ML_KEM_768, SecurityLevel.LEVEL_3)
        )

        entry = DeviceEntry(
            device_id=device_id,
            classic_algorithm=classic,
            target_pqc=target_pqc or rec_pqc,
            target_level=target_level or rec_level,
            profile=profile,
            jis_identity=jis_identity or f"jis:{device_id}",
        )

        self.devices[device_id] = entry
        self._stats["devices"] += 1
        return entry

    def shield(
        self,
        device_id: str,
        data: bytes | str,
    ) -> ShieldResult:
        """
        Shield data from a legacy device with PQC.

        In production, this would perform actual key encapsulation
        using ML-KEM. In this version, it simulates the wrapping
        and creates the TIBET audit trail.
        """
        if device_id not in self.devices:
            raise ValueError(f"Unknown device: {device_id}. Register with add_device() first.")

        device = self.devices[device_id]
        now = datetime.now(timezone.utc).isoformat()

        # Hash the data for provenance (never store raw data)
        if isinstance(data, str):
            data = data.encode()
        data_hash = hashlib.sha256(data).hexdigest()

        warnings = []

        # Check if device is using dangerously weak crypto
        if device.classic_algorithm in (
            ClassicAlgorithm.RSA_1024,
            ClassicAlgorithm.DSA_1024,
            ClassicAlgorithm.THREEDES,
        ):
            warnings.append(
                f"CRITICAL: {device.classic_algorithm.value} is severely weak — "
                "migrate device firmware if possible"
            )

        result = ShieldResult(
            device_id=device_id,
            classic_algorithm=device.classic_algorithm,
            pqc_algorithm=device.target_pqc,
            security_level=device.target_level,
            shielded=True,
            timestamp=now,
            data_hash=data_hash,
            hybrid_mode=self.hybrid,
            warnings=warnings,
        )

        # Create TIBET provenance token
        token = self.provenance.create_token(
            device_id=device_id,
            action="shield",
            classic=device.classic_algorithm.value,
            pqc=device.target_pqc.value,
            level=device.target_level.value,
            data_hash=data_hash,
            hybrid=self.hybrid,
        )
        result.provenance_token = token.to_dict()

        self._stats["shielded"] += 1
        return result

    def mark_migrated(self, device_id: str) -> None:
        """Mark a device as fully migrated to PQC."""
        if device_id not in self.devices:
            raise ValueError(f"Unknown device: {device_id}")

        device = self.devices[device_id]
        device.migrated = True
        device.migration_date = datetime.now(timezone.utc).isoformat()
        self._stats["migrations"] += 1

        self.provenance.create_token(
            device_id=device_id,
            action="migration_complete",
            classic=device.classic_algorithm.value,
            pqc=device.target_pqc.value,
            level=device.target_level.value,
            data_hash="",
            hybrid=False,
        )

    def at_risk(self) -> list[DeviceEntry]:
        """Return devices not yet migrated (vulnerable to SNDL)."""
        return [d for d in self.devices.values() if not d.migrated]

    def status(self) -> dict:
        """Network-wide PQC migration status."""
        total = len(self.devices)
        migrated = sum(1 for d in self.devices.values() if d.migrated)
        by_classic = {}
        by_pqc = {}

        for d in self.devices.values():
            by_classic[d.classic_algorithm.value] = (
                by_classic.get(d.classic_algorithm.value, 0) + 1
            )
            by_pqc[d.target_pqc.value] = by_pqc.get(d.target_pqc.value, 0) + 1

        return {
            "total_devices": total,
            "migrated": migrated,
            "at_risk": total - migrated,
            "migration_percentage": round(migrated / total * 100) if total > 0 else 0,
            "by_classic_algorithm": by_classic,
            "by_target_pqc": by_pqc,
            "total_shielded": self._stats["shielded"],
        }

    def export_audit(self) -> list[dict]:
        """Export the full TIBET provenance chain."""
        return self.provenance.chain()
