# Test event functionality
