from ._middleware import CORSMiddleware
from .config import CorsConfig

__all__ = ["CorsConfig", "CORSMiddleware"]
