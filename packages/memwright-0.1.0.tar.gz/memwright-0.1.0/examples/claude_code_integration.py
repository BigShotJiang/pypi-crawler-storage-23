"""Example: Setting up AgentMemory as a Claude Code MCP server.

After installing agent-memory, run:

    # Initialize the memory store
    agent-memory init ~/.agent-memory/my-project

    # See the MCP config to add to Claude Code
    agent-memory setup-claude-code ~/.agent-memory/my-project

    # Or start the server directly
    agent-memory serve ~/.agent-memory/my-project --mcp

Add the MCP config to your project's .mcp.json:

    {
        "agent-memory": {
            "command": "agent-memory",
            "args": ["serve", "/path/to/memory-store", "--mcp"]
        }
    }

Then in your CLAUDE.md, instruct Claude to use memory_recall at session start
and memory_add when the user shares important context. See CLAUDE.md.example.
"""

from agent_memory import AgentMemory

# You can also use the Python API directly in your own tools
mem = AgentMemory("~/.agent-memory/my-project")

# Session lifecycle
session = mem.start_session()
print(f"Started session: {session.id}")

# Recall context for the user's first message
context = mem.recall_as_context("help me refactor the auth module")
print(f"Loaded context:\n{context}")

# Store what you learn during the session
mem.add(
    "Auth module refactored to use JWT with refresh tokens",
    tags=["project", "auth", "jwt"],
    category="project",
    entity="auth-module",
)

# End session
mem.end_session(session.id, summary="Refactored auth to JWT")

mem.close()
