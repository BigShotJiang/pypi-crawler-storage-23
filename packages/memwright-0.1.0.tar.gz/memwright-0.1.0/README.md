# AgentMemory

Embedded cross-session memory for AI agents. No servers. No API keys. Just works.

> The SQLite of AI agent memory.

## Why

AI agents forget everything between sessions. The typical fix is a managed vector database or cloud memory service. AgentMemory takes a different approach: a local SQLite file with FTS5 full-text search, zero external dependencies, and sub-5ms retrieval.

**Works great as a Claude Code MCP server** — give Claude persistent memory across coding sessions.

## Install

```bash
pip install agent-memory           # Core — zero dependencies
pip install agent-memory[mcp]      # + MCP server for Claude Code
pip install agent-memory[vectors]  # + FAISS semantic search
pip install agent-memory[all]      # Everything
```

## Quick Start — Claude Code MCP Server

```bash
# 1. Initialize a memory store
agent-memory init ~/.agent-memory/my-project

# 2. Get the MCP config
agent-memory setup-claude-code ~/.agent-memory/my-project
```

Add the output to your project's `.mcp.json`:

```json
{
  "agent-memory": {
    "command": "agent-memory",
    "args": ["serve", "/Users/you/.agent-memory/my-project", "--mcp"]
  }
}
```

Claude now has 6 memory tools: `memory_add`, `memory_recall`, `memory_search`, `memory_forget`, `memory_timeline`, `memory_stats`.

Add instructions to your `CLAUDE.md` (see `examples/CLAUDE.md.example`):

```markdown
## Memory

Use `memory_recall` at the start of each session with the user's first message.
Use `memory_add` to store preferences, decisions, and project context.
```

## Quick Start — Python API

```python
from agent_memory import AgentMemory

mem = AgentMemory("./my-agent")

# Store facts
mem.add("User prefers Python over Java",
        tags=["preference", "coding"], category="preference")
mem.add("User works at SoFi as Staff SWE",
        tags=["career"], category="career", entity="SoFi")

# Recall relevant memories (3-layer cascade: tags → FTS5 → optional vectors)
results = mem.recall("what language does the user prefer?")
for r in results:
    print(f"[{r.match_source}:{r.score:.2f}] {r.content}")

# Get formatted context string for prompt injection
context = mem.recall_as_context("user background", budget=500)

# Contradiction handling — old facts get auto-superseded
mem.add("User works at Google as Principal Eng",
        tags=["career"], category="career", entity="SoFi")
# ^ The SoFi memory is now superseded automatically
```

## CLI

```bash
agent-memory init ./store
agent-memory add ./store "User prefers dark mode" --tags preference --category preference
agent-memory recall ./store "what theme?"
agent-memory search ./store "Python" --category preference
agent-memory list ./store --status active
agent-memory timeline ./store --entity SoFi
agent-memory stats ./store
agent-memory export ./store -o backup.json
agent-memory import ./store backup.json
agent-memory forget ./store <memory-id>
agent-memory compact ./store
agent-memory inspect ./store
agent-memory serve ./store --mcp
```

## How Retrieval Works

3-layer cascade, each layer tried in order:

| Layer | Method | Speed | Weight |
|-------|--------|-------|--------|
| 1. Tag match | SQL index lookup | <1ms | 1.0 |
| 2. FTS5 BM25 | SQLite full-text search | 1-3ms | 0.8 |
| 3. Vector similarity | FAISS flat index (optional) | 5-10ms | 0.6 |

Results are deduplicated, boosted by recency and entity relevance, then assembled within a token budget.

## Key Features

- **Zero infrastructure** — `pip install` and a directory. No Docker, no server, no signup.
- **Data sovereignty** — Everything in a local SQLite file. `cp` is the backup strategy.
- **Sub-5ms retrieval** — No network calls on the core path.
- **Token efficient** — 300-500 tokens per recall vs 15,000+ for full history replay.
- **Automatic contradiction handling** — New facts supersede old ones (same entity + category).
- **Inspectable** — `sqlite3 memory.db` and see exactly what the agent remembers.
- **MCP server** — First-class Claude Code / Claude Desktop integration.
- **Graduated complexity** — Start with tags + FTS5. Add FAISS vectors later. Add LLM extraction later.

## Architecture

```
AgentMemory
├── SQLite + FTS5 store (required, zero deps)
├── 3-layer retrieval (tag → BM25 → vector)
├── Temporal logic (contradiction detection, supersession, timeline)
├── Extraction pipeline (rule-based default, optional LLM)
├── MCP server (optional, for Claude Code)
└── CLI
```

## License

Apache 2.0
