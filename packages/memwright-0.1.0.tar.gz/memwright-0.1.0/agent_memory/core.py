"""AgentMemory main class — the public API."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from agent_memory.models import Memory, RetrievalResult, Session
from agent_memory.retrieval.orchestrator import RetrievalOrchestrator
from agent_memory.store.sqlite_store import SQLiteStore
from agent_memory.temporal.manager import TemporalManager
from agent_memory.utils.config import MemoryConfig, load_config, save_config


class AgentMemory:
    """Embedded cross-session memory for AI agents.

    Usage:
        mem = AgentMemory("./my-agent")
        mem.add("User prefers Python", tags=["preference"], category="preference")
        results = mem.recall("what language?")
    """

    def __init__(
        self,
        path: str | Path,
        config: Optional[Dict[str, Any]] = None,
    ):
        self.path = Path(path)
        self.path.mkdir(parents=True, exist_ok=True)

        # Load config
        if config:
            self.config = MemoryConfig.from_dict(config)
        else:
            self.config = load_config(self.path)
        save_config(self.path, self.config)

        # Initialize store
        db_path = self.path / "memory.db"
        self._store = SQLiteStore(db_path)

        # Initialize managers
        self._temporal = TemporalManager(self._store)
        self._retrieval = RetrievalOrchestrator(
            self._store,
            min_results=self.config.min_results,
        )

        # Session hooks
        self._on_session_start: Optional[Callable] = None
        self._on_session_end: Optional[Callable] = None

    def close(self) -> None:
        """Close the database connection."""
        self._store.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    # ── Write ──

    def add(
        self,
        content: str,
        tags: Optional[List[str]] = None,
        category: str = "general",
        entity: Optional[str] = None,
        event_date: Optional[str] = None,
        source_session: Optional[str] = None,
        confidence: float = 1.0,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Memory:
        """Store a new memory, handling contradictions automatically."""
        memory = Memory(
            content=content,
            tags=tags or [],
            category=category,
            entity=entity,
            event_date=event_date,
            source_session=source_session,
            confidence=confidence,
            metadata=metadata or {},
        )

        # Check for contradictions before insert
        contradictions = self._temporal.check_contradictions(memory)

        # Insert new memory first (so FK reference is valid)
        self._store.insert(memory)

        # Then supersede old contradicting memories
        for old in contradictions:
            self._temporal.supersede(old, memory.id)

        return memory

    def get(self, memory_id: str) -> Optional[Memory]:
        """Get a specific memory by ID."""
        return self._store.get(memory_id)

    # ── Read ──

    def recall(
        self, query: str, budget: Optional[int] = None
    ) -> List[RetrievalResult]:
        """Retrieve relevant memories for a query using 3-layer cascade."""
        token_budget = budget or self.config.default_token_budget
        return self._retrieval.recall(query, token_budget)

    def recall_as_context(
        self, query: str, budget: Optional[int] = None
    ) -> str:
        """Recall and format as a context string for prompt injection."""
        token_budget = budget or self.config.default_token_budget
        return self._retrieval.recall_as_context(query, token_budget)

    def search(
        self,
        query: Optional[str] = None,
        category: Optional[str] = None,
        entity: Optional[str] = None,
        status: str = "active",
        after: Optional[str] = None,
        before: Optional[str] = None,
        limit: int = 10,
    ) -> List[Memory]:
        """Search memories with filters."""
        if query:
            # Use FTS search with filters applied after
            fts_results = self._store.fts_search(query, limit=limit * 2)
            memories = [r["memory"] for r in fts_results]
            # Apply filters
            if category:
                memories = [m for m in memories if m.category == category]
            if entity:
                memories = [m for m in memories if m.entity and entity.lower() in m.entity.lower()]
            if status:
                memories = [m for m in memories if m.status == status]
            if after:
                memories = [m for m in memories if m.created_at >= after]
            if before:
                memories = [m for m in memories if m.created_at <= before]
            return memories[:limit]
        else:
            return self._store.list_memories(
                status=status,
                category=category,
                entity=entity,
                after=after,
                before=before,
                limit=limit,
            )

    # ── Timeline ──

    def timeline(self, entity: str) -> List[Memory]:
        """Get all memories about an entity in chronological order."""
        return self._temporal.timeline(entity)

    def current_facts(
        self,
        category: Optional[str] = None,
        entity: Optional[str] = None,
    ) -> List[Memory]:
        """Get only active, non-superseded memories."""
        return self._temporal.current_facts(category=category, entity=entity)

    # ── Session Management ──

    def start_session(self, metadata: Optional[Dict[str, Any]] = None) -> Session:
        """Start a new session."""
        session = Session(metadata=metadata or {})
        self._store.insert_session(session)

        if self._on_session_start:
            self._on_session_start(session.id)

        return session

    def end_session(
        self,
        session_id: str,
        summary: Optional[str] = None,
        conversation_history: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        """End a session, optionally extracting memories from conversation."""
        session = Session(
            id=session_id,
            ended_at=datetime.now(timezone.utc).isoformat(),
            summary=summary,
        )
        self._store.update_session(session)

        if conversation_history:
            self.extract(conversation_history, source_session=session_id)

        if self._on_session_end:
            self._on_session_end(session_id, conversation_history)

    def on_session_start(self, func: Callable) -> Callable:
        """Decorator to register a session start hook."""
        self._on_session_start = func
        return func

    def on_session_end(self, func: Callable) -> Callable:
        """Decorator to register a session end hook."""
        self._on_session_end = func
        return func

    # ── Extraction ──

    def extract(
        self,
        messages: List[Dict[str, Any]],
        model: str = "claude-haiku",
        use_llm: bool = False,
        source_session: Optional[str] = None,
    ) -> List[Memory]:
        """Extract and store memories from conversation messages."""
        from agent_memory.extraction.extractor import extract_memories

        extracted = extract_memories(messages, use_llm=use_llm, model=model)
        stored = []
        for mem in extracted:
            if source_session:
                mem.source_session = source_session
            stored_mem = self.add(
                content=mem.content,
                tags=mem.tags,
                category=mem.category,
                entity=mem.entity,
                source_session=source_session,
            )
            stored.append(stored_mem)
        return stored

    # ── Maintenance ──

    def forget(self, memory_id: str) -> bool:
        """Archive a specific memory."""
        memory = self._store.get(memory_id)
        if memory:
            memory.status = "archived"
            self._store.update(memory)
            return True
        return False

    def forget_before(self, date: str) -> int:
        """Archive memories created before a date."""
        return self._store.archive_before(date)

    def compact(self) -> int:
        """Permanently remove archived memories."""
        return self._store.compact()

    def stats(self) -> Dict[str, Any]:
        """Get store statistics."""
        return self._store.stats()

    # ── Export / Import ──

    def export_json(self, filepath: str) -> None:
        """Export all memories to a JSON file."""
        memories = self._store.list_memories(limit=1_000_000)
        data = [m.to_dict() for m in memories]
        with open(filepath, "w") as f:
            json.dump(data, f, indent=2)

    def import_json(self, filepath: str) -> int:
        """Import memories from a JSON file. Returns count imported."""
        with open(filepath) as f:
            data = json.load(f)
        count = 0
        for item in data:
            memory = Memory(
                id=item.get("id", Memory().id),
                content=item["content"],
                tags=item.get("tags", []),
                category=item.get("category", "general"),
                entity=item.get("entity"),
                created_at=item.get("created_at", datetime.now(timezone.utc).isoformat()),
                event_date=item.get("event_date"),
                valid_from=item.get("valid_from", datetime.now(timezone.utc).isoformat()),
                valid_until=item.get("valid_until"),
                superseded_by=item.get("superseded_by"),
                source_session=item.get("source_session"),
                confidence=item.get("confidence", 1.0),
                status=item.get("status", "active"),
                metadata=item.get("metadata", {}),
            )
            try:
                self._store.insert(memory)
                count += 1
            except Exception:
                # Skip duplicates
                pass
        return count

    # ── Raw SQL ──

    def execute(self, sql: str, params: Optional[List[Any]] = None) -> List[Dict[str, Any]]:
        """Execute raw SQL. Use with caution."""
        return self._store.execute(sql, params)
