"""Memory extraction from conversations."""

from __future__ import annotations

from typing import Any, Dict, List

from agent_memory.extraction.rule_based import extract_from_text
from agent_memory.models import Memory


def extract_memories(
    messages: List[Dict[str, Any]],
    use_llm: bool = False,
    model: str = "claude-haiku",
) -> List[Memory]:
    """Extract memories from conversation messages.

    Args:
        messages: List of message dicts with 'role' and 'content' keys.
        use_llm: If True, use LLM-based extraction (requires anthropic).
        model: LLM model to use if use_llm=True.

    Returns:
        List of Memory objects extracted from the conversation.
    """
    if use_llm:
        return _llm_extract(messages, model)
    return _rule_extract(messages)


def _rule_extract(messages: List[Dict[str, Any]]) -> List[Memory]:
    """Extract memories using rule-based patterns."""
    memories = []
    for msg in messages:
        content = msg.get("content", "")
        if not content or msg.get("role") == "system":
            continue
        extracted = extract_from_text(content)
        for item in extracted:
            memories.append(
                Memory(
                    content=item["content"],
                    tags=item["tags"],
                    category=item["category"],
                    entity=item.get("entity"),
                )
            )
    return memories


def _llm_extract(messages: List[Dict[str, Any]], model: str) -> List[Memory]:
    """Extract memories using LLM. Requires anthropic package."""
    try:
        from agent_memory.extraction.llm_extractor import llm_extract
        return llm_extract(messages, model)
    except ImportError:
        # Fall back to rule-based if anthropic not installed
        return _rule_extract(messages)
