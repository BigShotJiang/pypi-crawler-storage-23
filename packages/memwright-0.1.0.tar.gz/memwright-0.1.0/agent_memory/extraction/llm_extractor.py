"""LLM-based memory extraction (optional, requires anthropic)."""

from __future__ import annotations

import json
from typing import Any, Dict, List

from agent_memory.models import Memory

_EXTRACTION_PROMPT = """Extract atomic facts from this conversation that would be useful to remember across sessions.

For each fact, provide:
- content: A single, self-contained factual statement
- tags: List of relevant tags
- category: One of "career", "project", "preference", "personal", "technical", "general"
- entity: The primary entity this fact is about (company, person, tool, etc.), or null

Return a JSON array of objects. Only include facts that are clearly stated, not speculative.

Conversation:
{conversation}

Return ONLY valid JSON array, no other text."""


def llm_extract(
    messages: List[Dict[str, Any]], model: str = "claude-haiku"
) -> List[Memory]:
    """Extract memories using Claude API."""
    try:
        import anthropic
    except ImportError:
        raise ImportError(
            "anthropic package required for LLM extraction. "
            "Install with: pip install agent-memory[extraction]"
        )

    conversation_text = "\n".join(
        f"{msg.get('role', 'unknown')}: {msg.get('content', '')}"
        for msg in messages
        if msg.get("content")
    )

    client = anthropic.Anthropic()
    response = client.messages.create(
        model=model,
        max_tokens=2048,
        messages=[
            {
                "role": "user",
                "content": _EXTRACTION_PROMPT.format(conversation=conversation_text),
            }
        ],
    )

    try:
        facts = json.loads(response.content[0].text)
    except (json.JSONDecodeError, IndexError):
        return []

    memories = []
    for fact in facts:
        if isinstance(fact, dict) and "content" in fact:
            memories.append(
                Memory(
                    content=fact["content"],
                    tags=fact.get("tags", []),
                    category=fact.get("category", "general"),
                    entity=fact.get("entity"),
                )
            )
    return memories
