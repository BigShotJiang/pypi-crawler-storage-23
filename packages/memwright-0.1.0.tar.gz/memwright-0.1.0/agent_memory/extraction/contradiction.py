"""Contradiction detection and resolution."""

from __future__ import annotations

from typing import List

from agent_memory.models import Memory


def find_contradictions_rule_based(
    new_memory: Memory, candidates: List[Memory]
) -> List[Memory]:
    """Rule-based contradiction detection.

    A contradiction is when two memories share entity + category
    but have different content.
    """
    contradictions = []
    for existing in candidates:
        if (
            existing.entity
            and new_memory.entity
            and existing.entity.lower() == new_memory.entity.lower()
            and existing.category == new_memory.category
            and existing.content.strip() != new_memory.content.strip()
            and existing.status == "active"
        ):
            contradictions.append(existing)
    return contradictions
