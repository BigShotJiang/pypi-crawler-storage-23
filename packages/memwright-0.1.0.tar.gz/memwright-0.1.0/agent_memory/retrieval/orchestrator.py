"""3-layer retrieval cascade orchestrator."""

from __future__ import annotations

from typing import List, Optional

from agent_memory.models import Memory, RetrievalResult
from agent_memory.retrieval.fts_searcher import fts_search
from agent_memory.retrieval.scorer import (
    deduplicate,
    entity_boost,
    fit_to_budget,
    temporal_boost,
)
from agent_memory.retrieval.tag_matcher import extract_tags
from agent_memory.store.sqlite_store import SQLiteStore


class RetrievalOrchestrator:
    """Orchestrates the 3-layer retrieval cascade."""

    def __init__(
        self,
        store: SQLiteStore,
        min_results: int = 3,
        vector_searcher=None,
    ):
        self.store = store
        self.min_results = min_results
        self.vector_searcher = vector_searcher

    def recall(
        self,
        query: str,
        token_budget: int = 2000,
    ) -> List[RetrievalResult]:
        """Execute the 3-layer retrieval cascade."""
        results: List[RetrievalResult] = []

        # Layer 1: Tag match
        tags = extract_tags(query)
        if tags:
            tag_memories = self.store.tag_search(tags)
            for mem in tag_memories:
                results.append(
                    RetrievalResult(memory=mem, score=1.0, match_source="tag")
                )

        # Layer 2: FTS5 BM25 search
        fts_results = fts_search(self.store, query)
        results.extend(fts_results)

        # Layer 3: Vector similarity (optional)
        if (
            len(deduplicate(results)) < self.min_results
            and self.vector_searcher
            and self.vector_searcher.available
        ):
            # Vector search would go here — requires embedding the query
            pass

        # Score, dedupe, and assemble
        results = deduplicate(results)
        results = temporal_boost(results)

        # Extract entities from query for entity boost
        query_entities = [t for t in tags if t[0].isupper()] if tags else None
        results = entity_boost(results, query_entities)

        return fit_to_budget(results, token_budget)

    def recall_as_context(self, query: str, token_budget: int = 2000) -> str:
        """Recall and format as a context string for prompt injection."""
        results = self.recall(query, token_budget)
        if not results:
            return ""

        lines = ["Relevant memories:"]
        for r in results:
            prefix = f"[{r.match_source}:{r.score:.2f}]"
            lines.append(f"- {prefix} {r.memory.content}")
        return "\n".join(lines)
