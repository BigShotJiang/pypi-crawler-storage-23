"""Layer 3: Optional FAISS vector similarity search."""

from __future__ import annotations

from typing import List, Optional

from agent_memory.models import RetrievalResult

try:
    import faiss
    import numpy as np
    FAISS_AVAILABLE = True
except ImportError:
    FAISS_AVAILABLE = False


class VectorSearcher:
    """Optional FAISS-based vector similarity search.

    Only functional if faiss-cpu is installed.
    """

    def __init__(self, index_path: Optional[str] = None, dimension: int = 384):
        self.index_path = index_path
        self.dimension = dimension
        self._index = None
        self._id_map: List[str] = []  # memory_id at each index position

        if FAISS_AVAILABLE and index_path:
            self._load_or_create(index_path)

    def _load_or_create(self, path: str) -> None:
        try:
            self._index = faiss.read_index(path)
        except Exception:
            self._index = faiss.IndexFlatL2(self.dimension)

    @property
    def available(self) -> bool:
        return FAISS_AVAILABLE and self._index is not None

    def add(self, memory_id: str, embedding: List[float]) -> None:
        if not self.available:
            return
        vec = np.array([embedding], dtype=np.float32)
        self._index.add(vec)
        self._id_map.append(memory_id)

    def search(self, query_embedding: List[float], top_k: int = 10) -> List[dict]:
        """Search for similar vectors. Returns list of {memory_id, distance}."""
        if not self.available or self._index.ntotal == 0:
            return []
        vec = np.array([query_embedding], dtype=np.float32)
        distances, indices = self._index.search(vec, min(top_k, self._index.ntotal))
        results = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx < len(self._id_map) and idx >= 0:
                results.append({
                    "memory_id": self._id_map[idx],
                    "distance": float(dist),
                })
        return results

    def save(self) -> None:
        if self.available and self.index_path:
            faiss.write_index(self._index, self.index_path)
