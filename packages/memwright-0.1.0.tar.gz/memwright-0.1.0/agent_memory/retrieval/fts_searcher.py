"""Layer 2: FTS5 BM25 full-text search."""

from __future__ import annotations

from typing import List

from agent_memory.models import Memory, RetrievalResult
from agent_memory.store.sqlite_store import SQLiteStore


def fts_search(store: SQLiteStore, query: str, limit: int = 20) -> List[RetrievalResult]:
    """Perform FTS5 BM25 search and return scored results."""
    raw_results = store.fts_search(query, limit=limit)
    results = []
    for item in raw_results:
        # BM25 returns negative scores (lower = better match)
        # Normalize to 0-1 range: use abs and cap
        raw_rank = abs(item["rank"])
        score = min(raw_rank / 10.0, 1.0)  # rough normalization
        results.append(
            RetrievalResult(
                memory=item["memory"],
                score=score,
                match_source="fts",
            )
        )
    return results
