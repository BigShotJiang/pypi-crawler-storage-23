from http import HTTPMethod

from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import (
    IsAuthenticatedOrReadOnly,
)

from nkunyim_iam.models import (
    Logging,
    User,
)
from nkunyim_iam.serializers import (
    LoggingSerializer,
    UserSerializer,
)



class UserViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticatedOrReadOnly]
    queryset = User.objects.all()
    serializer_class = UserSerializer
    filterset_fields = [
        'gender',
        'is_pwd',
        'is_superuser',
        'is_admin',
        'is_verified',
        'is_active'
    ]
    search_fields = ['first_name', 'last_name', 'username', 'nickname', 'email_address']

    
    @action(detail=False, methods=[HTTPMethod.GET])
    def userinfo(self, request, format=None):
        try:
            pk = request.user.id
            query = User.objects.get(pk=pk)
            data = UserSerializer(query).data
            
            return Response(
                data=data,
                status=status.HTTP_200_OK
            )
        except User.DoesNotExist:
            return Response(
                data="User not found for id " + str(pk) + ".",
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as ex:
            return Response(data=str(ex),status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    


class LoggingViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticatedOrReadOnly]
    queryset = Logging.objects.all()
    serializer_class = LoggingSerializer
    filterset_fields = [
        'level',
    ]
    search_fields = ['message', 'context']
  
