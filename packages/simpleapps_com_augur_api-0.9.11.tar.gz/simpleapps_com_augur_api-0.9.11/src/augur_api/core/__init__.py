"""Core module for Augur API client.

Contains configuration, HTTP client, errors, and base schemas.
"""

from augur_api.core.config import AugurAPIConfig, AugurContext, ContextCreationError
from augur_api.core.errors import (
    AugurError,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import (
    BaseResponse,
    CamelCaseModel,
    HealthCheckData,
    PingData,
)

__all__ = [
    # Config
    "AugurAPIConfig",
    "AugurContext",
    "ContextCreationError",
    # HTTP Client
    "HTTPClient",
    # Errors
    "AugurError",
    "AuthenticationError",
    "NotFoundError",
    "RateLimitError",
    "ValidationError",
    # Schemas
    "BaseResponse",
    "CamelCaseModel",
    "HealthCheckData",
    "PingData",
]
