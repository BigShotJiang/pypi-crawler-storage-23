"""AGR Site service client for site content management."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, List

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.agr_site.schemas import (
    ContextGetParams,
    ContextResponse,
    FyxerTranscript,
    FyxerTranscriptListParams,
    GeoCodesPostalCodes,
    GeoCodesPostalCodesListParams,
    MetaFilesRobotsResponse,
    NotificationResponse,
    OpenSearchEmbeddingParams,
    OpenSearchEmbeddingResponse,
    Setting,
    SettingListParams,
    TrainingConv,
    TrainingConvListParams,
    TrainingMsg,
    TrainingMsgListParams,
    TrainingSet,
    TrainingSetListParams,
)
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient


class ContextResource(BaseResource):
    """Resource for /context endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/context")

    def get(
        self, site_id: str, params: ContextGetParams | None = None
    ) -> BaseResponse[ContextResponse]:
        """Get context for a site."""
        response = self._get(f"/{site_id}", params=params)
        return BaseResponse[ContextResponse].model_validate(response)


class SettingsResource(BaseResource):
    """Resource for /settings endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/settings")

    def list(self, params: SettingListParams | None = None) -> BaseResponse[List[Setting]]:
        """List settings."""
        response = self._get(params=params)
        return BaseResponse[List[Setting]].model_validate(response)

    def get(self, settings_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Setting]:
        """Get setting by UID."""
        response = self._get(f"/{settings_uid}", params=options)
        return BaseResponse[Setting].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Setting]:
        """Create a new setting."""
        response = self._post(data=data)
        return BaseResponse[Setting].model_validate(response)

    def update(self, settings_uid: int, data: Any) -> BaseResponse[Setting]:
        """Update a setting."""
        response = self._put(f"/{settings_uid}", data=data)
        return BaseResponse[Setting].model_validate(response)

    def delete(self, settings_uid: int) -> BaseResponse[bool]:
        """Delete a setting."""
        response = self._delete(f"/{settings_uid}")
        return BaseResponse[bool].model_validate(response)


class FyxerTranscriptResource(BaseResource):
    """Resource for /fyxer-transcript endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/fyxer-transcript")

    def list(
        self, params: FyxerTranscriptListParams | None = None
    ) -> BaseResponse[List[FyxerTranscript]]:
        """List Fyxer transcripts."""
        response = self._get(params=params)
        return BaseResponse[List[FyxerTranscript]].model_validate(response)

    def get(self, fyxer_transcript_hdr_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[FyxerTranscript]:
        """Get Fyxer transcript by UID."""
        response = self._get(f"/{fyxer_transcript_hdr_uid}", params=options)
        return BaseResponse[FyxerTranscript].model_validate(response)

    def create(self, data: Any) -> BaseResponse[FyxerTranscript]:
        """Create a new Fyxer transcript."""
        response = self._post(data=data)
        return BaseResponse[FyxerTranscript].model_validate(response)

    def update(self, fyxer_transcript_hdr_uid: int, data: Any) -> BaseResponse[FyxerTranscript]:
        """Update a Fyxer transcript."""
        response = self._put(f"/{fyxer_transcript_hdr_uid}", data=data)
        return BaseResponse[FyxerTranscript].model_validate(response)

    def delete(self, fyxer_transcript_hdr_uid: int) -> BaseResponse[bool]:
        """Delete a Fyxer transcript."""
        response = self._delete(f"/{fyxer_transcript_hdr_uid}")
        return BaseResponse[bool].model_validate(response)


class TrainingResource(BaseResource):
    """Resource for /training endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/training")

    # Training Sets
    def list(self, params: TrainingSetListParams | None = None) -> BaseResponse[List[TrainingSet]]:
        """List training sets."""
        response = self._get(params=params)
        return BaseResponse[List[TrainingSet]].model_validate(response)

    def get(self, training_set_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[TrainingSet]:
        """Get training set by UID."""
        response = self._get(f"/{training_set_uid}", params=options)
        return BaseResponse[TrainingSet].model_validate(response)

    def create(self, data: Any) -> BaseResponse[TrainingSet]:
        """Create a new training set."""
        response = self._post(data=data)
        return BaseResponse[TrainingSet].model_validate(response)

    def update(self, training_set_uid: int, data: Any) -> BaseResponse[TrainingSet]:
        """Update a training set."""
        response = self._put(f"/{training_set_uid}", data=data)
        return BaseResponse[TrainingSet].model_validate(response)

    def delete(self, training_set_uid: int) -> BaseResponse[bool]:
        """Delete a training set."""
        response = self._delete(f"/{training_set_uid}")
        return BaseResponse[bool].model_validate(response)

    # Training Conversations
    def list_conversations(
        self, training_set_uid: int, params: TrainingConvListParams | None = None
    ) -> BaseResponse[List[TrainingConv]]:
        """List training conversations."""
        response = self._get(f"/{training_set_uid}/conversations", params=params)
        return BaseResponse[List[TrainingConv]].model_validate(response)

    def get_conversation(
        self, training_set_uid: int, training_conv_uid: int, options: EdgeCacheParams | None = None
    ) -> BaseResponse[TrainingConv]:
        """Get training conversation."""
        response = self._get(f"/{training_set_uid}/conversations/{training_conv_uid}", params=options)
        return BaseResponse[TrainingConv].model_validate(response)

    def create_conversation(self, training_set_uid: int, data: Any) -> BaseResponse[TrainingConv]:
        """Create a training conversation."""
        response = self._post(f"/{training_set_uid}/conversations", data=data)
        return BaseResponse[TrainingConv].model_validate(response)

    def update_conversation(
        self, training_set_uid: int, training_conv_uid: int, data: Any
    ) -> BaseResponse[TrainingConv]:
        """Update a training conversation."""
        response = self._put(f"/{training_set_uid}/conversations/{training_conv_uid}", data=data)
        return BaseResponse[TrainingConv].model_validate(response)

    def delete_conversation(
        self, training_set_uid: int, training_conv_uid: int
    ) -> BaseResponse[bool]:
        """Delete a training conversation."""
        response = self._delete(f"/{training_set_uid}/conversations/{training_conv_uid}")
        return BaseResponse[bool].model_validate(response)

    # Training Messages
    def list_messages(
        self,
        training_set_uid: int,
        training_conv_uid: int,
        params: TrainingMsgListParams | None = None,
    ) -> BaseResponse[List[TrainingMsg]]:
        """List training messages."""
        response = self._get(
            f"/{training_set_uid}/conversations/{training_conv_uid}/messages", params=params
        )
        return BaseResponse[List[TrainingMsg]].model_validate(response)

    def get_message(
        self, training_set_uid: int, training_conv_uid: int, training_msg_uid: int, options: EdgeCacheParams | None = None
    ) -> BaseResponse[TrainingMsg]:
        """Get training message."""
        response = self._get(
            f"/{training_set_uid}/conversations/{training_conv_uid}/messages/{training_msg_uid}", params=options
        )
        return BaseResponse[TrainingMsg].model_validate(response)

    def create_message(
        self, training_set_uid: int, training_conv_uid: int, data: Any
    ) -> BaseResponse[TrainingMsg]:
        """Create a training message."""
        response = self._post(
            f"/{training_set_uid}/conversations/{training_conv_uid}/messages", data=data
        )
        return BaseResponse[TrainingMsg].model_validate(response)

    def update_message(
        self,
        training_set_uid: int,
        training_conv_uid: int,
        training_msg_uid: int,
        data: Any,
    ) -> BaseResponse[TrainingMsg]:
        """Update a training message."""
        response = self._put(
            f"/{training_set_uid}/conversations/{training_conv_uid}/messages/{training_msg_uid}",
            data=data,
        )
        return BaseResponse[TrainingMsg].model_validate(response)

    def delete_message(
        self, training_set_uid: int, training_conv_uid: int, training_msg_uid: int
    ) -> BaseResponse[bool]:
        """Delete a training message."""
        response = self._delete(
            f"/{training_set_uid}/conversations/{training_conv_uid}/messages/{training_msg_uid}"
        )
        return BaseResponse[bool].model_validate(response)


class GeoCodesPostalCodesResource(BaseResource):
    """Resource for /geo-codes-postal-codes endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/geo-codes-postal-codes")

    def list(
        self, params: GeoCodesPostalCodesListParams | None = None
    ) -> BaseResponse[List[GeoCodesPostalCodes]]:
        """List geo codes."""
        response = self._get(params=params)
        return BaseResponse[List[GeoCodesPostalCodes]].model_validate(response)

    def get(self, geo_codes_postal_codes_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[GeoCodesPostalCodes]:
        """Get geo code by UID."""
        response = self._get(f"/{geo_codes_postal_codes_uid}", params=options)
        return BaseResponse[GeoCodesPostalCodes].model_validate(response)


class NotificationsResource(BaseResource):
    """Resource for /notifications endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/notifications")

    def create(self, data: Any) -> BaseResponse[NotificationResponse]:
        """Create a notification."""
        response = self._post(data=data)
        return BaseResponse[NotificationResponse].model_validate(response)


class OpenSearchResource(BaseResource):
    """Resource for /open-search endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/open-search")

    def get_embedding(
        self, params: OpenSearchEmbeddingParams
    ) -> BaseResponse[OpenSearchEmbeddingResponse]:
        """Get embedding for text."""
        response = self._get("/embedding", params=params)
        return BaseResponse[OpenSearchEmbeddingResponse].model_validate(response)


class MetaFilesResource(BaseResource):
    """Resource for /meta-files endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/meta-files")

    def get_robots(self, options: EdgeCacheParams | None = None) -> BaseResponse[MetaFilesRobotsResponse]:
        """Get robots.txt content."""
        response = self._get("/robots", params=options)
        return BaseResponse[MetaFilesRobotsResponse].model_validate(response)


class AgrSiteClient(BaseServiceClient):
    """Client for the AGR Site service.

    Provides access to site content management endpoints including:
    - Context (context)
    - Health check (health_check)
    - Ping (ping)
    - Whoami (whoami)
    - Settings (settings)
    - Fyxer transcripts (fyxer_transcript)
    - Training data (training)
    - Geo codes (geo_codes_postal_codes)
    - Notifications (notifications)
    - OpenSearch (open_search)
    - Meta files (meta_files)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the AGR Site client."""
        super().__init__(http_client)
        self._context: ContextResource | None = None
        self._settings: SettingsResource | None = None
        self._fyxer_transcript: FyxerTranscriptResource | None = None
        self._training: TrainingResource | None = None
        self._geo_codes_postal_codes: GeoCodesPostalCodesResource | None = None
        self._notifications: NotificationsResource | None = None
        self._open_search: OpenSearchResource | None = None
        self._meta_files: MetaFilesResource | None = None

    @property
    def context(self) -> ContextResource:
        """Access context endpoints."""
        if self._context is None:
            self._context = ContextResource(self._http)
        return self._context

    @property
    def settings(self) -> SettingsResource:
        """Access settings endpoints."""
        if self._settings is None:
            self._settings = SettingsResource(self._http)
        return self._settings

    @property
    def fyxer_transcript(self) -> FyxerTranscriptResource:
        """Access Fyxer transcript endpoints."""
        if self._fyxer_transcript is None:
            self._fyxer_transcript = FyxerTranscriptResource(self._http)
        return self._fyxer_transcript

    @property
    def training(self) -> TrainingResource:
        """Access training endpoints."""
        if self._training is None:
            self._training = TrainingResource(self._http)
        return self._training

    @property
    def geo_codes_postal_codes(self) -> GeoCodesPostalCodesResource:
        """Access geo codes endpoints."""
        if self._geo_codes_postal_codes is None:
            self._geo_codes_postal_codes = GeoCodesPostalCodesResource(self._http)
        return self._geo_codes_postal_codes

    @property
    def notifications(self) -> NotificationsResource:
        """Access notifications endpoints."""
        if self._notifications is None:
            self._notifications = NotificationsResource(self._http)
        return self._notifications

    @property
    def open_search(self) -> OpenSearchResource:
        """Access OpenSearch endpoints."""
        if self._open_search is None:
            self._open_search = OpenSearchResource(self._http)
        return self._open_search

    @property
    def meta_files(self) -> MetaFilesResource:
        """Access meta files endpoints."""
        if self._meta_files is None:
            self._meta_files = MetaFilesResource(self._http)
        return self._meta_files
