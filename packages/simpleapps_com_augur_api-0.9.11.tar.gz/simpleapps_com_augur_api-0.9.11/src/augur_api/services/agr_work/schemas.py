"""Schemas for the AGR Work service."""

from augur_api.core.schemas import CamelCaseModel


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None
