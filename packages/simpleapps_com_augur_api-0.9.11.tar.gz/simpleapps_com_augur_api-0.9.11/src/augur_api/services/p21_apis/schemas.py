"""Schemas for the P21 APIs service."""

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Entity Contacts
class EntityContactsRefreshResponse(CamelCaseModel, extra="allow"):
    """Entity contacts refresh response (passthrough)."""


# Entity Customers
class EntityCustomersRefreshResponse(CamelCaseModel, extra="allow"):
    """Entity customers refresh response (passthrough)."""


# Trans Category
class TransCategoryParams(EdgeCacheParams):
    """Parameters for trans category queries."""

    category_id: str | None = None


class TransCategory(CamelCaseModel, extra="allow"):
    """Trans category entity (passthrough)."""

    category_uid: int | None = None


class TransCategoryCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a trans category (passthrough)."""


class TransCategoryUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a trans category (passthrough)."""


# Trans Company
class TransCompanyParams(EdgeCacheParams):
    """Parameters for trans company queries."""

    company_id: str | None = None


class TransCompany(CamelCaseModel, extra="allow"):
    """Trans company entity (passthrough)."""

    company_uid: int | None = None


class TransCompanyCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a trans company (passthrough)."""


class TransCompanyUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a trans company (passthrough)."""


# Trans Purchase Order Receipt
class TransPurchaseOrderReceiptParams(EdgeCacheParams):
    """Parameters for trans purchase order receipt queries (no query params)."""


class TransPurchaseOrderReceipt(CamelCaseModel, extra="allow"):
    """Trans purchase order receipt entity (passthrough)."""

    po_no: str | None = None


class TransPurchaseOrderReceiptUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a trans purchase order receipt (passthrough)."""


# Trans User
class TransUserParams(EdgeCacheParams):
    """Parameters for trans user queries."""

    user_id: str | None = None


class TransUser(CamelCaseModel, extra="allow"):
    """Trans user entity (passthrough)."""

    users_uid: int | None = None


class TransUserCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a trans user (passthrough)."""


class TransUserUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a trans user (passthrough)."""


# Trans Web Display Type
class TransWebDisplayTypeParams(EdgeCacheParams):
    """Parameters for trans web display type queries."""

    web_display_type_id: str | None = None


class TransWebDisplayType(CamelCaseModel, extra="allow"):
    """Trans web display type entity (passthrough)."""

    web_display_type_uid: int | None = None


class TransWebDisplayTypeCreateParams(BaseModel, extra="allow"):
    """Parameters for creating a trans web display type (passthrough)."""


class TransWebDisplayTypeUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating a trans web display type (passthrough)."""


class TransWebDisplayTypeDefaults(CamelCaseModel, extra="allow"):
    """Trans web display type defaults (passthrough)."""


class TransWebDisplayTypeDefinition(CamelCaseModel, extra="allow"):
    """Trans web display type definition (passthrough)."""
