"""Schemas for the P21 SISM service."""

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Import
class ImportListParams(EdgeCacheParams):
    """Parameters for listing imports."""

    import_state: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    reference_no: str | None = None


class Import(CamelCaseModel, extra="allow"):
    """Import entity (passthrough)."""

    import_uid: int | None = None
    transaction_set: str | None = None
    status: str | None = None


class ImportUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating an import (passthrough)."""


# Imp OE Hdr
class ImpOeHdr(CamelCaseModel, extra="allow"):
    """Imp OE Hdr entity (passthrough)."""

    import_uid: int | None = None


class ImpOeHdrUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating imp_oe_hdr (passthrough)."""


# Imp OE Hdr Salesrep
class ImpOeHdrSalesrep(CamelCaseModel, extra="allow"):
    """Imp OE Hdr Salesrep entity (passthrough)."""

    import_uid: int | None = None


class ImpOeHdrSalesrepUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating imp_oe_hdr_salesrep (passthrough)."""


# Imp OE Hdr Web
class ImpOeHdrWeb(CamelCaseModel, extra="allow"):
    """Imp OE Hdr Web entity (passthrough)."""

    import_uid: int | None = None


# Imp OE Line
class ImportRecentParams(EdgeCacheParams):
    """Parameters for listing recent imports."""

    hours: int | None = None
    limit: int | None = None


class ImportStuckParams(EdgeCacheParams):
    """Parameters for listing stuck imports."""

    hours: int | None = None
    limit: int | None = None


class ImpOeLineListParams(EdgeCacheParams):
    """Parameters for listing imp_oe_line."""

    import_uid: int | None = None
    item_id: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None


class ImpOeLine(CamelCaseModel, extra="allow"):
    """Imp OE Line entity (passthrough)."""

    import_uid: int | None = None
    line_no: int | None = None


class ImpOeLineUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating imp_oe_line (passthrough)."""


# Scheduled Import Metadata
class ScheduledImportSftpMetadataCreateParams(BaseModel, extra="allow"):
    """Parameters for creating SFTP metadata (passthrough)."""


class ScheduledImportSftpMetadata(CamelCaseModel, extra="allow"):
    """Scheduled import SFTP metadata (passthrough)."""
