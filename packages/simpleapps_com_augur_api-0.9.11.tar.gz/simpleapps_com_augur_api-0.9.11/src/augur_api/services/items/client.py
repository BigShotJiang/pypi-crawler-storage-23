"""Items service client for inventory management."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, List

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.items.schemas import (
    AlternateCode,
    Attribute,
    AttributeGroup,
    AttributeGroupListParams,
    AttributeGroupUpdateParams,
    AttributeListParams,
    AttributeValue,
    AttributeValueListParams,
    AttributeValueUpdateParams,
    AttributeXAttributeGroup,
    AttributeXAttributeGroupCreateParams,
    AttributeXAttributeGroupListParams,
    AttributeXAttributeGroupUpdateParams,
    Brands,
    BrandsListParams,
    BrandsXItems,
    BrandsXItemsListParams,
    BrandsXItemsUpdateParams,
    Category,
    CategoryAttributesData,
    CategoryAttributesParams,
    CategoryGetParams,
    CategoryImage,
    CategoryImagesParams,
    CategoryItemsData,
    CategoryItemsParams,
    CategoryLookupParams,
    ContractsAttribute,
    ContractsItem,
    ContractsItemsListParams,
    InvAccessory,
    InvBin,
    InvBinListParams,
    InvLoc,
    InvLocListParams,
    InvMast,
    InvMastDoc,
    InvMastFaq,
    InvMastFaqListParams,
    InvMastFaqUpdateParams,
    InvMastLinks,
    InvMastListParams,
    InvMastLookupParams,
    InvMastSimilar,
    InvMastSubParts,
    InvMastUd,
    InvMastUdListParams,
    InvSub,
    ItemAttribute,
    ItemAttributeListParams,
    ItemAttributeValue,
    ItemAttributeValueListParams,
    ItemAttributeValueUpdateParams,
    ItemCategory,
    ItemCategoryDoc,
    ItemCategoryListParams,
    ItemCategoryLookupParams,
    ItemFavoritesListParams,
    ItemUom,
    ItemUomListParams,
    ItemWishlist,
    ItemWishlistLine,
    ItemWishlistLineListParams,
    ItemWishlistListParams,
    ItemWishlistUpdateParams,
    LocationBin,
    P21InvMast,
    P21InvMastListParams,
    PdfResult,
    StockParams,
    StockSummary,
    Variant,
    VariantAttribute,
    VariantAttributeCreateParams,
    VariantAttributeListParams,
    VariantAttributeUpdateParams,
    VariantLine,
    VariantLineListParams,
    VariantLineUpdateParams,
    VariantsListParams,
)
from augur_api.services.resource import BaseResource

# ============================================================================
# Attribute Resources
# ============================================================================


class AttributeValuesResource(BaseResource):
    """Resource for /attributes/{attributeUid}/values endpoints."""

    def __init__(self, http: HTTPClient, attribute_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/attributes/{attribute_uid}/values")
        self._attribute_uid = attribute_uid

    def list(
        self, params: AttributeValueListParams | None = None
    ) -> BaseResponse[list[AttributeValue]]:
        """List attribute values."""
        response = self._get(params=params)
        return BaseResponse[list[AttributeValue]].model_validate(response)

    def get(self, attribute_value_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[AttributeValue]:
        """Get attribute value by UID."""
        response = self._get(f"/{attribute_value_uid}", params=options)
        return BaseResponse[AttributeValue].model_validate(response)

    def create(self, data: Any) -> BaseResponse[AttributeValue]:
        """Create an attribute value."""
        response = self._post(data=data)
        return BaseResponse[AttributeValue].model_validate(response)

    def update(
        self, attribute_value_uid: int, data: AttributeValueUpdateParams
    ) -> BaseResponse[AttributeValue]:
        """Update an attribute value."""
        response = self._put(f"/{attribute_value_uid}", data=data)
        return BaseResponse[AttributeValue].model_validate(response)

    def delete(self, attribute_value_uid: int) -> BaseResponse[bool]:
        """Delete an attribute value."""
        response = self._delete(f"/{attribute_value_uid}")
        return BaseResponse[bool].model_validate(response)


class AttributesResource(BaseResource):
    """Resource for /attributes endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/attributes")

    def list(self, params: AttributeListParams | None = None) -> BaseResponse[list[Attribute]]:
        """List attributes."""
        response = self._get(params=params)
        return BaseResponse[list[Attribute]].model_validate(response)

    def get(self, attribute_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Attribute]:
        """Get attribute by UID."""
        response = self._get(f"/{attribute_uid}", params=options)
        return BaseResponse[Attribute].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Attribute]:
        """Create an attribute."""
        response = self._post(data=data)
        return BaseResponse[Attribute].model_validate(response)

    def update(self, attribute_uid: int, data: Any) -> BaseResponse[Attribute]:
        """Update an attribute."""
        response = self._put(f"/{attribute_uid}", data=data)
        return BaseResponse[Attribute].model_validate(response)

    def delete(self, attribute_uid: int) -> BaseResponse[bool]:
        """Delete an attribute."""
        response = self._delete(f"/{attribute_uid}")
        return BaseResponse[bool].model_validate(response)

    def values(self, attribute_uid: int) -> AttributeValuesResource:
        """Get attribute values resource for a specific attribute."""
        return AttributeValuesResource(self._http, attribute_uid)


# ============================================================================
# Attribute Group Resources
# ============================================================================


class AttributeGroupAttributesResource(BaseResource):
    """Resource for /attribute-groups/{attributeGroupUid}/attributes endpoints."""

    def __init__(self, http: HTTPClient, attribute_group_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/attribute-groups/{attribute_group_uid}/attributes")
        self._attribute_group_uid = attribute_group_uid

    def list(
        self, params: AttributeXAttributeGroupListParams | None = None
    ) -> BaseResponse[list[AttributeXAttributeGroup]]:
        """List attribute x attribute group mappings."""
        response = self._get(params=params)
        return BaseResponse[list[AttributeXAttributeGroup]].model_validate(response)

    def get(self, attribute_x_attribute_group_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[AttributeXAttributeGroup]:
        """Get attribute x attribute group by UID."""
        response = self._get(f"/{attribute_x_attribute_group_uid}", params=options)
        return BaseResponse[AttributeXAttributeGroup].model_validate(response)

    def create(
        self, data: AttributeXAttributeGroupCreateParams
    ) -> BaseResponse[AttributeXAttributeGroup]:
        """Create an attribute x attribute group mapping."""
        response = self._post(data=data)
        return BaseResponse[AttributeXAttributeGroup].model_validate(response)

    def update(
        self,
        attribute_x_attribute_group_uid: int,
        data: AttributeXAttributeGroupUpdateParams,
    ) -> BaseResponse[AttributeXAttributeGroup]:
        """Update an attribute x attribute group mapping."""
        response = self._put(f"/{attribute_x_attribute_group_uid}", data=data)
        return BaseResponse[AttributeXAttributeGroup].model_validate(response)

    def delete(self, attribute_x_attribute_group_uid: int) -> BaseResponse[bool]:
        """Delete an attribute x attribute group mapping."""
        response = self._delete(f"/{attribute_x_attribute_group_uid}")
        return BaseResponse[bool].model_validate(response)


class AttributeGroupsResource(BaseResource):
    """Resource for /attribute-groups endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/attribute-groups")

    def list(
        self, params: AttributeGroupListParams | None = None
    ) -> BaseResponse[list[AttributeGroup]]:
        """List attribute groups."""
        response = self._get(params=params)
        return BaseResponse[list[AttributeGroup]].model_validate(response)

    def get(self, attribute_group_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[AttributeGroup]:
        """Get attribute group by UID."""
        response = self._get(f"/{attribute_group_uid}", params=options)
        return BaseResponse[AttributeGroup].model_validate(response)

    def create(self, data: Any) -> BaseResponse[AttributeGroup]:
        """Create an attribute group."""
        response = self._post(data=data)
        return BaseResponse[AttributeGroup].model_validate(response)

    def update(
        self, attribute_group_uid: int, data: AttributeGroupUpdateParams
    ) -> BaseResponse[AttributeGroup]:
        """Update an attribute group."""
        response = self._put(f"/{attribute_group_uid}", data=data)
        return BaseResponse[AttributeGroup].model_validate(response)

    def delete(self, attribute_group_uid: int) -> BaseResponse[bool]:
        """Delete an attribute group."""
        response = self._delete(f"/{attribute_group_uid}")
        return BaseResponse[bool].model_validate(response)

    def attributes(self, attribute_group_uid: int) -> AttributeGroupAttributesResource:
        """Get attributes resource for a specific attribute group."""
        return AttributeGroupAttributesResource(self._http, attribute_group_uid)


# ============================================================================
# Brands Resources
# ============================================================================


class BrandsItemsResource(BaseResource):
    """Resource for /brands/{brandsUid}/items endpoints."""

    def __init__(self, http: HTTPClient, brands_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/brands/{brands_uid}/items")
        self._brands_uid = brands_uid

    def list(
        self, params: BrandsXItemsListParams | None = None
    ) -> BaseResponse[list[BrandsXItems]]:
        """List brand items."""
        response = self._get(params=params)
        return BaseResponse[list[BrandsXItems]].model_validate(response)

    def get(self, brands_x_items_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[BrandsXItems]:
        """Get brand item by UID."""
        response = self._get(f"/{brands_x_items_uid}", params=options)
        return BaseResponse[BrandsXItems].model_validate(response)

    def create(self, data: Any) -> BaseResponse[BrandsXItems]:
        """Create a brand item."""
        response = self._post(data=data)
        return BaseResponse[BrandsXItems].model_validate(response)

    def update(
        self, brands_x_items_uid: int, data: BrandsXItemsUpdateParams
    ) -> BaseResponse[BrandsXItems]:
        """Update a brand item."""
        response = self._put(f"/{brands_x_items_uid}", data=data)
        return BaseResponse[BrandsXItems].model_validate(response)

    def delete(self, brands_x_items_uid: int) -> BaseResponse[bool]:
        """Delete a brand item."""
        response = self._delete(f"/{brands_x_items_uid}")
        return BaseResponse[bool].model_validate(response)


class BrandsResource(BaseResource):
    """Resource for /brands endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/brands")

    def list(self, params: BrandsListParams | None = None) -> BaseResponse[list[Brands]]:
        """List brands."""
        response = self._get(params=params)
        return BaseResponse[list[Brands]].model_validate(response)

    def get(self, brands_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Brands]:
        """Get brand by UID."""
        response = self._get(f"/{brands_uid}", params=options)
        return BaseResponse[Brands].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Brands]:
        """Create a brand."""
        response = self._post(data=data)
        return BaseResponse[Brands].model_validate(response)

    def update(self, brands_uid: int, data: Any) -> BaseResponse[Brands]:
        """Update a brand."""
        response = self._put(f"/{brands_uid}", data=data)
        return BaseResponse[Brands].model_validate(response)

    def delete(self, brands_uid: int) -> BaseResponse[bool]:
        """Delete a brand."""
        response = self._delete(f"/{brands_uid}")
        return BaseResponse[bool].model_validate(response)

    def items(self, brands_uid: int) -> BrandsItemsResource:
        """Get items resource for a specific brand."""
        return BrandsItemsResource(self._http, brands_uid)


# ============================================================================
# Categories Resource
# ============================================================================


class CategoriesResource(BaseResource):
    """Resource for /categories endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/categories")

    def lookup(self, params: CategoryLookupParams | None = None) -> BaseResponse[list[Category]]:
        """Lookup categories."""
        response = self._get("/lookup", params=params)
        return BaseResponse[list[Category]].model_validate(response)

    def get(
        self,
        item_category_uid: int,
        params: CategoryGetParams | None = None,
    ) -> BaseResponse[Category]:
        """Get category by UID."""
        response = self._get(f"/{item_category_uid}", params=params)
        return BaseResponse[Category].model_validate(response)

    def get_attributes(
        self,
        item_category_uid: int,
        params: CategoryAttributesParams | None = None,
    ) -> BaseResponse[CategoryAttributesData]:
        """List attributes in a category."""
        response = self._get(f"/{item_category_uid}/attributes", params=params)
        return BaseResponse[CategoryAttributesData].model_validate(response)

    def get_images(
        self,
        item_category_uid: int,
        params: CategoryImagesParams | None = None,
    ) -> BaseResponse[list[CategoryImage]]:
        """List images for a category."""
        response = self._get(f"/{item_category_uid}/images", params=params)
        return BaseResponse[list[CategoryImage]].model_validate(response)

    def get_items(
        self,
        item_category_uid: int,
        params: CategoryItemsParams | None = None,
    ) -> BaseResponse[CategoryItemsData]:
        """List items in a category."""
        response = self._get(f"/{item_category_uid}/items", params=params)
        return BaseResponse[CategoryItemsData].model_validate(response)


# ============================================================================
# Contracts Resource
# ============================================================================


class ContractsResource(BaseResource):
    """Resource for /contracts endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/contracts")

    def get_items(
        self, job_no: str, params: ContractsItemsListParams | None = None
    ) -> BaseResponse[list[ContractsItem]]:
        """List contract items for a job."""
        response = self._get(f"/{job_no}/items", params=params)
        return BaseResponse[list[ContractsItem]].model_validate(response)

    def get_attributes(self, job_no: str, options: EdgeCacheParams | None = None) -> BaseResponse[list[ContractsAttribute]]:
        """List attributes for contract items."""
        response = self._get(f"/{job_no}/attributes", params=options)
        return BaseResponse[list[ContractsAttribute]].model_validate(response)


# ============================================================================
# Inv Loc Resource
# ============================================================================


class InvLocResource(BaseResource):
    """Resource for /inv-loc endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-loc")

    def list(self, params: InvLocListParams | None = None) -> BaseResponse[list[InvLoc]]:
        """List inventory locations."""
        response = self._get(params=params)
        return BaseResponse[list[InvLoc]].model_validate(response)


# ============================================================================
# Inv Mast Nested Resources
# ============================================================================


class InvMastFaqResource(BaseResource):
    """Resource for /inv-mast/{invMastUid}/faq endpoints."""

    def __init__(self, http: HTTPClient, inv_mast_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/inv-mast/{inv_mast_uid}/faq")
        self._inv_mast_uid = inv_mast_uid

    def list(self, params: InvMastFaqListParams | None = None) -> BaseResponse[list[InvMastFaq]]:
        """List FAQs for an item."""
        response = self._get(params=params)
        return BaseResponse[list[InvMastFaq]].model_validate(response)

    def get(self, inv_mast_faq_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[InvMastFaq]:
        """Get FAQ by UID."""
        response = self._get(f"/{inv_mast_faq_uid}", params=options)
        return BaseResponse[InvMastFaq].model_validate(response)

    def create(self, data: Any) -> BaseResponse[InvMastFaq]:
        """Create an FAQ."""
        response = self._post(data=data)
        return BaseResponse[InvMastFaq].model_validate(response)

    def update(
        self, inv_mast_faq_uid: int, data: InvMastFaqUpdateParams
    ) -> BaseResponse[InvMastFaq]:
        """Update an FAQ."""
        response = self._put(f"/{inv_mast_faq_uid}", data=data)
        return BaseResponse[InvMastFaq].model_validate(response)

    def delete(self, inv_mast_faq_uid: int) -> BaseResponse[bool]:
        """Delete an FAQ."""
        response = self._delete(f"/{inv_mast_faq_uid}")
        return BaseResponse[bool].model_validate(response)


class InvMastAttributeValuesResource(BaseResource):
    """Resource for item attribute values endpoints."""

    def __init__(self, http: HTTPClient, inv_mast_uid: int, attribute_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/inv-mast/{inv_mast_uid}/attributes/{attribute_uid}/values")
        self._inv_mast_uid = inv_mast_uid
        self._attribute_uid = attribute_uid

    def list(
        self, params: ItemAttributeValueListParams | None = None
    ) -> BaseResponse[list[ItemAttributeValue]]:
        """List item attribute values."""
        response = self._get(params=params)
        return BaseResponse[list[ItemAttributeValue]].model_validate(response)

    def create(self, data: Any) -> BaseResponse[ItemAttributeValue]:
        """Create an item attribute value."""
        response = self._post(data=data)
        return BaseResponse[ItemAttributeValue].model_validate(response)

    def update(
        self, attribute_value_uid: int, data: ItemAttributeValueUpdateParams
    ) -> BaseResponse[ItemAttributeValue]:
        """Update an item attribute value."""
        response = self._put(f"/{attribute_value_uid}", data=data)
        return BaseResponse[ItemAttributeValue].model_validate(response)

    def delete(self, attribute_value_uid: int) -> BaseResponse[bool]:
        """Delete an item attribute value."""
        response = self._delete(f"/{attribute_value_uid}")
        return BaseResponse[bool].model_validate(response)


class InvMastAttributesResource(BaseResource):
    """Resource for /inv-mast/{invMastUid}/attributes endpoints."""

    def __init__(self, http: HTTPClient, inv_mast_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/inv-mast/{inv_mast_uid}/attributes")
        self._inv_mast_uid = inv_mast_uid

    def list(
        self, params: ItemAttributeListParams | None = None
    ) -> BaseResponse[list[ItemAttribute]]:
        """List item attributes."""
        response = self._get(params=params)
        return BaseResponse[list[ItemAttribute]].model_validate(response)

    def create(self, data: Any) -> BaseResponse[ItemAttribute]:
        """Create an item attribute."""
        response = self._post(data=data)
        return BaseResponse[ItemAttribute].model_validate(response)

    def values(self, attribute_uid: int) -> InvMastAttributeValuesResource:
        """Get values resource for a specific attribute."""
        return InvMastAttributeValuesResource(self._http, self._inv_mast_uid, attribute_uid)


class InvMastBinsResource(BaseResource):
    """Resource for /inv-mast/{invMastUid}/locations/{locationId}/bins endpoints."""

    def __init__(self, http: HTTPClient, inv_mast_uid: int, location_id: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/inv-mast/{inv_mast_uid}/locations/{location_id}/bins")
        self._inv_mast_uid = inv_mast_uid
        self._location_id = location_id

    def list(self, params: InvBinListParams | None = None) -> BaseResponse[list[InvBin]]:
        """List bins for a specific location."""
        response = self._get(params=params)
        return BaseResponse[list[InvBin]].model_validate(response)

    def get(self, bin: str, options: EdgeCacheParams | None = None) -> BaseResponse[InvBin]:
        """Get a specific bin."""
        response = self._get(f"/{bin}", params=options)
        return BaseResponse[InvBin].model_validate(response)


class InvMastLocationsResource(BaseResource):
    """Resource for /inv-mast/{invMastUid}/locations endpoints."""

    def __init__(self, http: HTTPClient, inv_mast_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/inv-mast/{inv_mast_uid}/locations")
        self._inv_mast_uid = inv_mast_uid

    def bins(self, location_id: int) -> InvMastBinsResource:
        """Get bins resource for a specific location."""
        return InvMastBinsResource(self._http, self._inv_mast_uid, location_id)


# ============================================================================
# Inv Mast Resource
# ============================================================================


class InvMastResource(BaseResource):
    """Resource for /inv-mast endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-mast")

    def list(self, params: InvMastListParams | None = None) -> BaseResponse[list[InvMast]]:
        """List inventory master items."""
        response = self._get(params=params)
        return BaseResponse[list[InvMast]].model_validate(response)

    def get(self, inv_mast_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[InvMast]:
        """Get inventory master item by UID."""
        response = self._get(f"/{inv_mast_uid}", params=options)
        return BaseResponse[InvMast].model_validate(response)

    def lookup(self, params: InvMastLookupParams | None = None) -> BaseResponse[List[InvMast]]:
        """Lookup inventory master items."""
        response = self._get("/lookup", params=params)
        return BaseResponse[List[InvMast]].model_validate(response)

    def get_doc(self, inv_mast_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[InvMastDoc]:
        """Get inventory master document."""
        response = self._get(f"/{inv_mast_uid}/doc", params=options)
        return BaseResponse[InvMastDoc].model_validate(response)

    def get_stock(
        self, inv_mast_uid: int, params: StockParams | None = None
    ) -> BaseResponse[List[StockSummary]]:
        """Get stock information for an inventory item."""
        response = self._get(f"/{inv_mast_uid}/stock", params=params)
        return BaseResponse[List[StockSummary]].model_validate(response)

    def get_alternate_codes(self, inv_mast_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[List[AlternateCode]]:
        """Get alternate codes for an inventory item."""
        response = self._get(f"/{inv_mast_uid}/alternate-code", params=options)
        return BaseResponse[List[AlternateCode]].model_validate(response)

    def get_accessories(self, inv_mast_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[List[InvAccessory]]:
        """Get accessories for an inventory item."""
        response = self._get(f"/{inv_mast_uid}/inv-accessory", params=options)
        return BaseResponse[List[InvAccessory]].model_validate(response)

    def get_substitutes(self, inv_mast_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[List[InvSub]]:
        """Get substitutes for an inventory item."""
        response = self._get(f"/{inv_mast_uid}/inv-sub", params=options)
        return BaseResponse[List[InvSub]].model_validate(response)

    def get_similar(self, inv_mast_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[List[InvMastSimilar]]:
        """Get similar items."""
        response = self._get(f"/{inv_mast_uid}/similar", params=options)
        return BaseResponse[List[InvMastSimilar]].model_validate(response)

    def faq(self, inv_mast_uid: int) -> InvMastFaqResource:
        """Get FAQ resource for a specific item."""
        return InvMastFaqResource(self._http, inv_mast_uid)

    def attributes(self, inv_mast_uid: int) -> InvMastAttributesResource:
        """Get attributes resource for a specific item."""
        return InvMastAttributesResource(self._http, inv_mast_uid)

    def locations(self, inv_mast_uid: int) -> InvMastLocationsResource:
        """Get locations resource for a specific item."""
        return InvMastLocationsResource(self._http, inv_mast_uid)


# ============================================================================
# Inv Mast Links Resource
# ============================================================================


class InvMastLinksResource(BaseResource):
    """Resource for /inv-mast-links endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-mast-links")

    def get(self, inv_mast_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[list[InvMastLinks]]:
        """List document links for an item."""
        response = self._get(f"/{inv_mast_uid}", params=options)
        return BaseResponse[list[InvMastLinks]].model_validate(response)


# ============================================================================
# Inv Mast Sub Parts Resource
# ============================================================================


class InvMastSubPartsResource(BaseResource):
    """Resource for /inv-mast-sub-parts endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-mast-sub-parts")

    def get(self, inv_mast_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[list[InvMastSubParts]]:
        """List sub parts for an item."""
        response = self._get(f"/{inv_mast_uid}", params=options)
        return BaseResponse[list[InvMastSubParts]].model_validate(response)


# ============================================================================
# Inv Mast UD Resource
# ============================================================================


class InvMastUdResource(BaseResource):
    """Resource for /inv-mast-ud endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-mast-ud")

    def list(self, params: InvMastUdListParams | None = None) -> BaseResponse[list[InvMastUd]]:
        """List inv mast ud records."""
        response = self._get(params=params)
        return BaseResponse[list[InvMastUd]].model_validate(response)


# ============================================================================
# Item Category Resource
# ============================================================================


class ItemCategoryResource(BaseResource):
    """Resource for /item-category endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/item-category")

    def list(
        self, params: ItemCategoryListParams | None = None
    ) -> BaseResponse[list[ItemCategory]]:
        """List item categories."""
        response = self._get(params=params)
        return BaseResponse[list[ItemCategory]].model_validate(response)

    def get(self, item_category_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[ItemCategory]:
        """Get item category by UID."""
        response = self._get(f"/{item_category_uid}", params=options)
        return BaseResponse[ItemCategory].model_validate(response)

    def lookup(
        self, params: ItemCategoryLookupParams | None = None
    ) -> BaseResponse[List[ItemCategory]]:
        """Lookup item categories."""
        response = self._get("/lookup", params=params)
        return BaseResponse[List[ItemCategory]].model_validate(response)

    def get_doc(self, item_category_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[ItemCategoryDoc]:
        """Get item category document."""
        response = self._get(f"/{item_category_uid}/doc", params=options)
        return BaseResponse[ItemCategoryDoc].model_validate(response)


# ============================================================================
# Item Favorites Resource
# ============================================================================


class ItemFavoritesResource(BaseResource):
    """Resource for /item-favorites endpoints.

    Note: The API returns arrays of item favorite objects.
    - GET returns: { data: [{ invMastUid: 86491, ... }, ...] }
    - POST expects body: [86491]
    """

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/item-favorites")

    def list(
        self,
        users_id: int,
        params: ItemFavoritesListParams | None = None,
    ) -> BaseResponse[List[Any]]:
        """List item favorites for a user."""
        response = self._get(f"/{users_id}/items", params=params)
        return BaseResponse[List[Any]].model_validate(response)

    def get(self, users_id: int, inv_mast_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """Get a single item favorite."""
        response = self._get(f"/{users_id}/items/{inv_mast_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def create(self, users_id: int, data: Any) -> BaseResponse[Any]:
        """Add items to user's favorites."""
        response = self._post(f"/{users_id}/items", data=data)
        return BaseResponse[Any].model_validate(response)

    def update(
        self,
        users_id: int,
        inv_mast_uid: int,
        data: Any,
    ) -> BaseResponse[Any]:
        """Update an item favorite."""
        response = self._put(
            f"/{users_id}/items/{inv_mast_uid}",
            data=data,
        )
        return BaseResponse[Any].model_validate(response)

    def delete(self, users_id: int, inv_mast_uid: int) -> BaseResponse[Any]:
        """Delete an item favorite."""
        response = self._delete(f"/{users_id}/items/{inv_mast_uid}")
        return BaseResponse[Any].model_validate(response)


# ============================================================================
# Item UOM Resource
# ============================================================================


class ItemUomResource(BaseResource):
    """Resource for /item-uom endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/item-uom")

    def list(self, params: ItemUomListParams | None = None) -> BaseResponse[list[ItemUom]]:
        """List item UOMs."""
        response = self._get(params=params)
        return BaseResponse[list[ItemUom]].model_validate(response)

    def get(self, item_uom_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[ItemUom]:
        """Get item UOM by UID."""
        response = self._get(f"/{item_uom_uid}", params=options)
        return BaseResponse[ItemUom].model_validate(response)


# ============================================================================
# Variant Resources
# ============================================================================


class VariantAttributesResource(BaseResource):
    """Resource for /variants/{itemVariantHdrUid}/attributes endpoints."""

    def __init__(self, http: HTTPClient, item_variant_hdr_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/variants/{item_variant_hdr_uid}/attributes")
        self._item_variant_hdr_uid = item_variant_hdr_uid

    def list(
        self, params: VariantAttributeListParams | None = None
    ) -> BaseResponse[list[VariantAttribute]]:
        """List variant attributes."""
        response = self._get(params=params)
        return BaseResponse[list[VariantAttribute]].model_validate(response)

    def get(self, attribute_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[VariantAttribute]:
        """Get variant attribute by UID."""
        response = self._get(f"/{attribute_uid}", params=options)
        return BaseResponse[VariantAttribute].model_validate(response)

    def create(self, data: VariantAttributeCreateParams | Any) -> BaseResponse[VariantAttribute]:
        """Create a variant attribute."""
        response = self._post(data=data)
        return BaseResponse[VariantAttribute].model_validate(response)

    def update(
        self, attribute_uid: int, data: VariantAttributeUpdateParams | Any
    ) -> BaseResponse[VariantAttribute]:
        """Update a variant attribute."""
        response = self._put(f"/{attribute_uid}", data=data)
        return BaseResponse[VariantAttribute].model_validate(response)

    def delete(self, attribute_uid: int) -> BaseResponse[bool]:
        """Delete a variant attribute."""
        response = self._delete(f"/{attribute_uid}")
        return BaseResponse[bool].model_validate(response)


class VariantLinesResource(BaseResource):
    """Resource for /variants/{itemVariantHdrUid}/lines endpoints."""

    def __init__(self, http: HTTPClient, item_variant_hdr_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/variants/{item_variant_hdr_uid}/lines")
        self._item_variant_hdr_uid = item_variant_hdr_uid

    def list(self, params: VariantLineListParams | None = None) -> BaseResponse[list[VariantLine]]:
        """List variant lines."""
        response = self._get(params=params)
        return BaseResponse[list[VariantLine]].model_validate(response)

    def get(self, item_variant_line_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[VariantLine]:
        """Get variant line by UID."""
        response = self._get(f"/{item_variant_line_uid}", params=options)
        return BaseResponse[VariantLine].model_validate(response)

    def create(self, data: Any) -> BaseResponse[VariantLine]:
        """Create a variant line."""
        response = self._post(data=data)
        return BaseResponse[VariantLine].model_validate(response)

    def update(
        self, item_variant_line_uid: int, data: VariantLineUpdateParams
    ) -> BaseResponse[VariantLine]:
        """Update a variant line."""
        response = self._put(f"/{item_variant_line_uid}", data=data)
        return BaseResponse[VariantLine].model_validate(response)

    def delete(self, item_variant_line_uid: int) -> BaseResponse[bool]:
        """Delete a variant line."""
        response = self._delete(f"/{item_variant_line_uid}")
        return BaseResponse[bool].model_validate(response)


class VariantsResource(BaseResource):
    """Resource for /variants endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/variants")

    def list(self, params: VariantsListParams | None = None) -> BaseResponse[list[Variant]]:
        """List variants."""
        response = self._get(params=params)
        return BaseResponse[list[Variant]].model_validate(response)

    def get(self, item_variant_hdr_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Variant]:
        """Get variant by UID."""
        response = self._get(f"/{item_variant_hdr_uid}", params=options)
        return BaseResponse[Variant].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Variant]:
        """Create a variant."""
        response = self._post(data=data)
        return BaseResponse[Variant].model_validate(response)

    def update(self, item_variant_hdr_uid: int, data: Any) -> BaseResponse[Variant]:
        """Update a variant."""
        response = self._put(f"/{item_variant_hdr_uid}", data=data)
        return BaseResponse[Variant].model_validate(response)

    def delete(self, item_variant_hdr_uid: int) -> BaseResponse[bool]:
        """Delete a variant."""
        response = self._delete(f"/{item_variant_hdr_uid}")
        return BaseResponse[bool].model_validate(response)

    def lines(self, item_variant_hdr_uid: int) -> VariantLinesResource:
        """Get lines resource for a specific variant."""
        return VariantLinesResource(self._http, item_variant_hdr_uid)

    def attributes(self, item_variant_hdr_uid: int) -> VariantAttributesResource:
        """Get attributes resource for a specific variant."""
        return VariantAttributesResource(self._http, item_variant_hdr_uid)


# ============================================================================
# Item Wishlist Resources
# ============================================================================


class ItemWishlistLinesResource(BaseResource):
    """Resource for wishlist lines endpoints."""

    def __init__(self, http: HTTPClient, users_id: int, item_wishlist_hdr_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/item-wishlist/{users_id}/hdr/{item_wishlist_hdr_uid}")
        self._users_id = users_id
        self._item_wishlist_hdr_uid = item_wishlist_hdr_uid

    def list(
        self, params: ItemWishlistLineListParams | None = None
    ) -> BaseResponse[list[ItemWishlistLine]]:
        """List items in a wishlist."""
        response = self._get(params=params)
        return BaseResponse[list[ItemWishlistLine]].model_validate(response)

    def create(self, data: Any) -> BaseResponse[ItemWishlistLine]:
        """Create one or more items in a wishlist."""
        response = self._post(data=data)
        return BaseResponse[ItemWishlistLine].model_validate(response)

    def delete(self, item_wishlist_line_uid: int) -> BaseResponse[ItemWishlistLine]:
        """Delete an item from a wishlist."""
        response = self._delete(f"/line/{item_wishlist_line_uid}")
        return BaseResponse[ItemWishlistLine].model_validate(response)


class ItemWishlistResource(BaseResource):
    """Resource for /item-wishlist endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/item-wishlist")

    def list(
        self, users_id: int, params: ItemWishlistListParams | None = None
    ) -> BaseResponse[list[ItemWishlist]]:
        """List wishlists for a user."""
        response = self._get(f"/{users_id}", params=params)
        return BaseResponse[list[ItemWishlist]].model_validate(response)

    def create(self, users_id: int, data: Any) -> BaseResponse[ItemWishlist]:
        """Create a wishlist."""
        response = self._post(f"/{users_id}", data=data)
        return BaseResponse[ItemWishlist].model_validate(response)

    def update(
        self,
        users_id: int,
        item_wishlist_hdr_uid: int,
        data: ItemWishlistUpdateParams,
    ) -> BaseResponse[ItemWishlist]:
        """Update a wishlist."""
        response = self._put(f"/{users_id}/hdr/{item_wishlist_hdr_uid}", data=data)
        return BaseResponse[ItemWishlist].model_validate(response)

    def delete(self, users_id: int, item_wishlist_hdr_uid: int) -> BaseResponse[ItemWishlist]:
        """Delete a wishlist."""
        response = self._delete(f"/{users_id}/hdr/{item_wishlist_hdr_uid}")
        return BaseResponse[ItemWishlist].model_validate(response)

    def lines(self, users_id: int, item_wishlist_hdr_uid: int) -> ItemWishlistLinesResource:
        """Get lines resource for a specific wishlist."""
        return ItemWishlistLinesResource(self._http, users_id, item_wishlist_hdr_uid)


# ============================================================================
# Locations Resource
# ============================================================================


class LocationBinsResource(BaseResource):
    """Resource for /locations/{locationId}/bins endpoints."""

    def __init__(self, http: HTTPClient, location_id: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/locations/{location_id}/bins")
        self._location_id = location_id

    def list(self, params: InvBinListParams | None = None) -> BaseResponse[List[LocationBin]]:
        """List all items in bins at a location."""
        response = self._get(params=params)
        return BaseResponse[List[LocationBin]].model_validate(response)

    def get(
        self,
        bin: str,
        params: InvBinListParams | None = None,
    ) -> BaseResponse[List[LocationBin]]:
        """List all items in a specific bin."""
        response = self._get(f"/{bin}", params=params)
        return BaseResponse[List[LocationBin]].model_validate(response)


class LocationsResource(BaseResource):
    """Resource for /locations endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/locations")

    def bins(self, location_id: int) -> LocationBinsResource:
        """Get bins resource for a specific location."""
        return LocationBinsResource(self._http, location_id)


# ============================================================================
# P21 Resource
# ============================================================================


class P21InvMastResource(BaseResource):
    """Resource for /p21/inv-mast endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/p21/inv-mast")

    def list(self, params: P21InvMastListParams | None = None) -> BaseResponse[list[P21InvMast]]:
        """List raw P21 inv mast data."""
        response = self._get(params=params)
        return BaseResponse[list[P21InvMast]].model_validate(response)


# ============================================================================
# Internal Resource
# ============================================================================


class InternalResource(BaseResource):
    """Resource for /internal endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/internal")

    def create_pdf(self, data: Any) -> BaseResponse[PdfResult]:
        """Generate a PDF."""
        response = self._post("/pdf", data=data)
        return BaseResponse[PdfResult].model_validate(response)


# ============================================================================
# Items Client
# ============================================================================


class ItemsClient(BaseServiceClient):
    """Client for the Items service.

    Provides access to inventory management endpoints including:
    - Attributes and attribute groups
    - Brands
    - Categories
    - Contracts
    - Inventory master items (inv_mast)
    - Inventory locations
    - Item categories
    - Item favorites
    - Item UOMs
    - Variants
    - Wishlists
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Items client."""
        super().__init__(http_client)
        self._attributes: AttributesResource | None = None
        self._attribute_groups: AttributeGroupsResource | None = None
        self._brands: BrandsResource | None = None
        self._categories: CategoriesResource | None = None
        self._contracts: ContractsResource | None = None
        self._inv_loc: InvLocResource | None = None
        self._inv_mast: InvMastResource | None = None
        self._inv_mast_links: InvMastLinksResource | None = None
        self._inv_mast_sub_parts: InvMastSubPartsResource | None = None
        self._inv_mast_ud: InvMastUdResource | None = None
        self._item_category: ItemCategoryResource | None = None
        self._item_favorites: ItemFavoritesResource | None = None
        self._item_uom: ItemUomResource | None = None
        self._variants: VariantsResource | None = None
        self._item_wishlist: ItemWishlistResource | None = None
        self._locations: LocationsResource | None = None
        self._p21_inv_mast: P21InvMastResource | None = None
        self._internal: InternalResource | None = None

    @property
    def attributes(self) -> AttributesResource:
        """Access attributes endpoints."""
        if self._attributes is None:
            self._attributes = AttributesResource(self._http)
        return self._attributes

    @property
    def attribute_groups(self) -> AttributeGroupsResource:
        """Access attribute groups endpoints."""
        if self._attribute_groups is None:
            self._attribute_groups = AttributeGroupsResource(self._http)
        return self._attribute_groups

    @property
    def brands(self) -> BrandsResource:
        """Access brands endpoints."""
        if self._brands is None:
            self._brands = BrandsResource(self._http)
        return self._brands

    @property
    def categories(self) -> CategoriesResource:
        """Access categories endpoints."""
        if self._categories is None:
            self._categories = CategoriesResource(self._http)
        return self._categories

    @property
    def contracts(self) -> ContractsResource:
        """Access contracts endpoints."""
        if self._contracts is None:
            self._contracts = ContractsResource(self._http)
        return self._contracts

    @property
    def inv_loc(self) -> InvLocResource:
        """Access inv loc endpoints."""
        if self._inv_loc is None:
            self._inv_loc = InvLocResource(self._http)
        return self._inv_loc

    @property
    def inv_mast(self) -> InvMastResource:
        """Access inventory master endpoints."""
        if self._inv_mast is None:
            self._inv_mast = InvMastResource(self._http)
        return self._inv_mast

    @property
    def inv_mast_links(self) -> InvMastLinksResource:
        """Access inv mast links endpoints."""
        if self._inv_mast_links is None:
            self._inv_mast_links = InvMastLinksResource(self._http)
        return self._inv_mast_links

    @property
    def inv_mast_sub_parts(self) -> InvMastSubPartsResource:
        """Access inv mast sub parts endpoints."""
        if self._inv_mast_sub_parts is None:
            self._inv_mast_sub_parts = InvMastSubPartsResource(self._http)
        return self._inv_mast_sub_parts

    @property
    def inv_mast_ud(self) -> InvMastUdResource:
        """Access inv mast ud endpoints."""
        if self._inv_mast_ud is None:
            self._inv_mast_ud = InvMastUdResource(self._http)
        return self._inv_mast_ud

    @property
    def item_category(self) -> ItemCategoryResource:
        """Access item category endpoints."""
        if self._item_category is None:
            self._item_category = ItemCategoryResource(self._http)
        return self._item_category

    @property
    def item_favorites(self) -> ItemFavoritesResource:
        """Access item favorites endpoints."""
        if self._item_favorites is None:
            self._item_favorites = ItemFavoritesResource(self._http)
        return self._item_favorites

    @property
    def item_uom(self) -> ItemUomResource:
        """Access item UOM endpoints."""
        if self._item_uom is None:
            self._item_uom = ItemUomResource(self._http)
        return self._item_uom

    @property
    def variants(self) -> VariantsResource:
        """Access variants endpoints."""
        if self._variants is None:
            self._variants = VariantsResource(self._http)
        return self._variants

    @property
    def item_wishlist(self) -> ItemWishlistResource:
        """Access item wishlist endpoints."""
        if self._item_wishlist is None:
            self._item_wishlist = ItemWishlistResource(self._http)
        return self._item_wishlist

    @property
    def locations(self) -> LocationsResource:
        """Access locations endpoints."""
        if self._locations is None:
            self._locations = LocationsResource(self._http)
        return self._locations

    @property
    def p21_inv_mast(self) -> P21InvMastResource:
        """Access P21 inv mast endpoints."""
        if self._p21_inv_mast is None:
            self._p21_inv_mast = P21InvMastResource(self._http)
        return self._p21_inv_mast

    @property
    def internal(self) -> InternalResource:
        """Access internal endpoints."""
        if self._internal is None:
            self._internal = InternalResource(self._http)
        return self._internal
