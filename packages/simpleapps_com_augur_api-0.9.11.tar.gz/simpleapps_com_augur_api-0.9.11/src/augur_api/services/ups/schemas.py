"""Schemas for the UPS service."""

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Rates Shop
class RatesShopParams(EdgeCacheParams):
    """Parameters for UPS rate shopping."""

    cache_site_id: str | None = None
    from_address1: str | None = None
    from_address2: str | None = None
    from_address3: str | None = None
    from_city: str | None = None
    from_country_code: str | None = None
    from_postal_code: str | None = None
    from_state_province_code: str | None = None
    to_address1: str | None = None
    to_address2: str | None = None
    to_address3: str | None = None
    to_city: str | None = None
    to_country_code: str | None = None
    to_postal_code: str | None = None
    to_state_province_code: str | None = None
    weight: int | None = None


class RatesShopItem(CamelCaseModel, extra="allow"):
    """Individual UPS rate item (passthrough for API flexibility)."""


# RatesShopData is a list of rate items (API returns array directly in data field)
RatesShopData = list[RatesShopItem]
