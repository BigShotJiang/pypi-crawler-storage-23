"""VMI (Vendor Managed Inventory) service client."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource
from augur_api.services.vmi.schemas import (
    Distributor,
    DistributorEnableParams,
    DistributorListParams,
    DistributorUpdateParams,
    InventoryAvailability,
    InventoryAvailabilityParams,
    InvProfileHdr,
    InvProfileHdrListParams,
    InvProfileHdrUpdateParams,
    InvProfileLine,
    InvProfileLineListParams,
    InvProfileLineUpdateParams,
    Product,
    ProductEnableParams,
    ProductFindItem,
    ProductFindParams,
    ProductListParams,
    ReplenishmentInfo,
    ReplenishmentParams,
    RestockHdr,
    RestockHdrListParams,
    RestockHdrUpdateParams,
    Section,
    SectionEnableParams,
    SectionListParams,
    Warehouse,
    WarehouseEnableParams,
    WarehouseListParams,
    WarehouseUser,
    WarehouseUserCreateQueryParams,
    WarehouseUserListParams,
)


# Warehouse nested resources
class WarehouseAvailabilityResource(BaseResource):
    """Resource for /warehouse/{id}/availability endpoints."""

    def __init__(self, http: HTTPClient, warehouse_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/warehouse/{warehouse_uid}/availability")

    def get(self, params: InventoryAvailabilityParams) -> BaseResponse[list[InventoryAvailability]]:
        """Get inventory availability."""
        response = self._get(params=params)
        return BaseResponse[list[InventoryAvailability]].model_validate(response)


class WarehouseAdjustResource(BaseResource):
    """Resource for /warehouse/{id}/adjust endpoints."""

    def __init__(self, http: HTTPClient, warehouse_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/warehouse/{warehouse_uid}/adjust")

    def create(self, data: Any) -> BaseResponse[bool]:
        """Adjust inventory."""
        response = self._post(data=data)
        return BaseResponse[bool].model_validate(response)


class WarehouseReceiveResource(BaseResource):
    """Resource for /warehouse/{id}/receive endpoints."""

    def __init__(self, http: HTTPClient, warehouse_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/warehouse/{warehouse_uid}/receive")

    def create(self, data: Any) -> BaseResponse[bool]:
        """Receive inventory."""
        response = self._post(data=data)
        return BaseResponse[bool].model_validate(response)


class WarehouseReplenishResource(BaseResource):
    """Resource for /warehouse/{id}/replenish endpoints."""

    def __init__(self, http: HTTPClient, warehouse_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/warehouse/{warehouse_uid}/replenish")

    def get(self, params: ReplenishmentParams | None = None) -> BaseResponse[ReplenishmentInfo]:
        """Get replenishment info."""
        response = self._get(params=params)
        return BaseResponse[ReplenishmentInfo].model_validate(response)

    def create(self, data: Any) -> BaseResponse[bool]:
        """Execute replenishment."""
        response = self._post(data=data)
        return BaseResponse[bool].model_validate(response)


class WarehouseTransferResource(BaseResource):
    """Resource for /warehouse/{id}/transfer endpoints."""

    def __init__(self, http: HTTPClient, warehouse_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/warehouse/{warehouse_uid}/transfer")

    def create(self, data: Any) -> BaseResponse[bool]:
        """Transfer inventory."""
        response = self._post(data=data)
        return BaseResponse[bool].model_validate(response)


class WarehouseUsageResource(BaseResource):
    """Resource for /warehouse/{id}/usage endpoints."""

    def __init__(self, http: HTTPClient, warehouse_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/warehouse/{warehouse_uid}/usage")

    def create(self, data: Any) -> BaseResponse[bool]:
        """Record usage."""
        response = self._post(data=data)
        return BaseResponse[bool].model_validate(response)


class WarehouseUsersResource(BaseResource):
    """Resource for /warehouse/{id}/users endpoints."""

    def __init__(self, http: HTTPClient, warehouse_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/warehouse/{warehouse_uid}/users")
        self._warehouse_uid = warehouse_uid

    def list(
        self, params: WarehouseUserListParams | None = None
    ) -> BaseResponse[list[WarehouseUser]]:
        """List warehouse users."""
        response = self._get(params=params)
        return BaseResponse[list[WarehouseUser]].model_validate(response)

    def get(self, users_id: int, options: EdgeCacheParams | None = None) -> BaseResponse[WarehouseUser]:
        """Get warehouse user by ID."""
        response = self._get(f"/{users_id}", params=options)
        return BaseResponse[WarehouseUser].model_validate(response)

    def create(
        self, data: Any, params: WarehouseUserCreateQueryParams | None = None
    ) -> BaseResponse[WarehouseUser]:
        """Create warehouse user."""
        response = self._post(data=data, params=params)
        return BaseResponse[WarehouseUser].model_validate(response)

    def update(self, users_id: int, data: Any) -> BaseResponse[WarehouseUser]:
        """Update warehouse user."""
        response = self._put(f"/{users_id}", data=data)
        return BaseResponse[WarehouseUser].model_validate(response)

    def delete(self, users_id: int) -> BaseResponse[bool]:
        """Delete warehouse user."""
        response = self._delete(f"/{users_id}")
        return BaseResponse[bool].model_validate(response)


class WarehouseResource(BaseResource):
    """Resource for /warehouse endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/warehouse")

    def list(self, params: WarehouseListParams | None = None) -> BaseResponse[list[Warehouse]]:
        """List warehouses."""
        response = self._get(params=params)
        return BaseResponse[list[Warehouse]].model_validate(response)

    def get(self, warehouse_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Warehouse]:
        """Get warehouse by UID."""
        response = self._get(f"/{warehouse_uid}", params=options)
        return BaseResponse[Warehouse].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Warehouse]:
        """Create a new warehouse."""
        response = self._post(data=data)
        return BaseResponse[Warehouse].model_validate(response)

    def update(self, warehouse_uid: int, data: Any) -> BaseResponse[Warehouse]:
        """Update warehouse."""
        response = self._put(f"/{warehouse_uid}", data=data)
        return BaseResponse[Warehouse].model_validate(response)

    def delete(self, warehouse_uid: int) -> BaseResponse[Any]:
        """Delete warehouse."""
        response = self._delete(f"/{warehouse_uid}")
        return BaseResponse[Any].model_validate(response)

    def enable(self, warehouse_uid: int, data: WarehouseEnableParams) -> BaseResponse[Warehouse]:
        """Enable/disable warehouse."""
        response = self._put(f"/{warehouse_uid}/enable", data=data)
        return BaseResponse[Warehouse].model_validate(response)

    def availability(self, warehouse_uid: int) -> WarehouseAvailabilityResource:
        """Access availability endpoints for a warehouse."""
        return WarehouseAvailabilityResource(self._http, warehouse_uid)

    def adjust(self, warehouse_uid: int) -> WarehouseAdjustResource:
        """Access adjust endpoints for a warehouse."""
        return WarehouseAdjustResource(self._http, warehouse_uid)

    def receive(self, warehouse_uid: int) -> WarehouseReceiveResource:
        """Access receive endpoints for a warehouse."""
        return WarehouseReceiveResource(self._http, warehouse_uid)

    def replenish(self, warehouse_uid: int) -> WarehouseReplenishResource:
        """Access replenish endpoints for a warehouse."""
        return WarehouseReplenishResource(self._http, warehouse_uid)

    def transfer(self, warehouse_uid: int) -> WarehouseTransferResource:
        """Access transfer endpoints for a warehouse."""
        return WarehouseTransferResource(self._http, warehouse_uid)

    def usage(self, warehouse_uid: int) -> WarehouseUsageResource:
        """Access usage endpoints for a warehouse."""
        return WarehouseUsageResource(self._http, warehouse_uid)

    def users(self, warehouse_uid: int) -> WarehouseUsersResource:
        """Access users endpoints for a warehouse."""
        return WarehouseUsersResource(self._http, warehouse_uid)


# Distributors nested resource
class DistributorProductsResource(BaseResource):
    """Resource for /distributors/{id}/products endpoints."""

    def __init__(self, http: HTTPClient, distributors_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/distributors/{distributors_uid}/products")

    def create(self, data: Any) -> BaseResponse[Product]:
        """Create product for distributor."""
        response = self._post(data=data)
        return BaseResponse[Product].model_validate(response)


class DistributorsResource(BaseResource):
    """Resource for /distributors endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/distributors")

    def list(self, params: DistributorListParams | None = None) -> BaseResponse[list[Distributor]]:
        """List distributors."""
        response = self._get(params=params)
        return BaseResponse[list[Distributor]].model_validate(response)

    def get(self, distributors_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Distributor]:
        """Get distributor by UID."""
        response = self._get(f"/{distributors_uid}", params=options)
        return BaseResponse[Distributor].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Distributor]:
        """Create a new distributor."""
        response = self._post(data=data)
        return BaseResponse[Distributor].model_validate(response)

    def update(
        self, distributors_uid: int, data: DistributorUpdateParams
    ) -> BaseResponse[Distributor]:
        """Update distributor."""
        response = self._put(f"/{distributors_uid}", data=data)
        return BaseResponse[Distributor].model_validate(response)

    def delete(self, distributors_uid: int) -> BaseResponse[Any]:
        """Delete distributor."""
        response = self._delete(f"/{distributors_uid}")
        return BaseResponse[Any].model_validate(response)

    def enable(
        self, distributors_uid: int, data: DistributorEnableParams
    ) -> BaseResponse[Distributor]:
        """Enable/disable distributor."""
        response = self._put(f"/{distributors_uid}/enable", data=data)
        return BaseResponse[Distributor].model_validate(response)

    def products(self, distributors_uid: int) -> DistributorProductsResource:
        """Access products endpoints for a distributor."""
        return DistributorProductsResource(self._http, distributors_uid)


# Products nested resource
class ProductFindResource(BaseResource):
    """Resource for /products/find endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/products/find")

    def get(self, params: ProductFindParams) -> BaseResponse[list[ProductFindItem]]:
        """Find products."""
        response = self._get(params=params)
        return BaseResponse[list[ProductFindItem]].model_validate(response)


class ProductsResource(BaseResource):
    """Resource for /products endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/products")
        self._find: ProductFindResource | None = None

    def list(self, params: ProductListParams | None = None) -> BaseResponse[list[Product]]:
        """List products."""
        response = self._get(params=params)
        return BaseResponse[list[Product]].model_validate(response)

    def get(self, products_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Product]:
        """Get product by UID."""
        response = self._get(f"/{products_uid}", params=options)
        return BaseResponse[Product].model_validate(response)

    def update(self, products_uid: int, data: Any) -> BaseResponse[Product]:
        """Update product."""
        response = self._put(f"/{products_uid}", data=data)
        return BaseResponse[Product].model_validate(response)

    def delete(self, products_uid: int) -> BaseResponse[Any]:
        """Delete product."""
        response = self._delete(f"/{products_uid}")
        return BaseResponse[Any].model_validate(response)

    def enable(self, products_uid: int, data: ProductEnableParams) -> BaseResponse[Product]:
        """Enable/disable product."""
        response = self._put(f"/{products_uid}/enable", data=data)
        return BaseResponse[Product].model_validate(response)

    @property
    def find(self) -> ProductFindResource:
        """Access find endpoint."""
        if self._find is None:
            self._find = ProductFindResource(self._http)
        return self._find


# InvProfileHdr nested resource
class InvProfileLineResource(BaseResource):
    """Resource for /inv-profile-hdr/{id}/inv-profile-line endpoints."""

    def __init__(self, http: HTTPClient, inv_profile_hdr_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/inv-profile-hdr/{inv_profile_hdr_uid}/inv-profile-line")

    def list(
        self, params: InvProfileLineListParams | None = None
    ) -> BaseResponse[list[InvProfileLine]]:
        """List inventory profile lines."""
        response = self._get(params=params)
        return BaseResponse[list[InvProfileLine]].model_validate(response)

    def get(self, inv_profile_line_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[InvProfileLine]:
        """Get inventory profile line by UID."""
        response = self._get(f"/{inv_profile_line_uid}", params=options)
        return BaseResponse[InvProfileLine].model_validate(response)

    def create(self, data: Any) -> BaseResponse[InvProfileLine]:
        """Create inventory profile lines (bulk). Accepts an array of line items."""
        response = self._post(data=data)
        return BaseResponse[InvProfileLine].model_validate(response)

    def update(
        self, inv_profile_line_uid: int, data: InvProfileLineUpdateParams
    ) -> BaseResponse[InvProfileLine]:
        """Update inventory profile line."""
        response = self._put(f"/{inv_profile_line_uid}", data=data)
        return BaseResponse[InvProfileLine].model_validate(response)

    def delete(self, inv_profile_line_uid: int) -> BaseResponse[Any]:
        """Delete inventory profile line."""
        response = self._delete(f"/{inv_profile_line_uid}")
        return BaseResponse[Any].model_validate(response)


class InvProfileUploadResource(BaseResource):
    """Resource for /inv-profile-hdr/{customerId}/upload endpoints."""

    def __init__(self, http: HTTPClient, customer_id: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/inv-profile-hdr/{customer_id}/upload")

    def create(self) -> BaseResponse[Any]:
        """Upload inventory profile."""
        response = self._post()
        return BaseResponse[Any].model_validate(response)


class InvProfileHdrResource(BaseResource):
    """Resource for /inv-profile-hdr endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-profile-hdr")

    def list(
        self, params: InvProfileHdrListParams | None = None
    ) -> BaseResponse[list[InvProfileHdr]]:
        """List inventory profile headers."""
        response = self._get(params=params)
        return BaseResponse[list[InvProfileHdr]].model_validate(response)

    def get(self, inv_profile_hdr_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[InvProfileHdr]:
        """Get inventory profile header by UID."""
        response = self._get(f"/{inv_profile_hdr_uid}", params=options)
        return BaseResponse[InvProfileHdr].model_validate(response)

    def create(self, data: Any) -> BaseResponse[InvProfileHdr]:
        """Create inventory profile header."""
        response = self._post(data=data)
        return BaseResponse[InvProfileHdr].model_validate(response)

    def update(
        self, inv_profile_hdr_uid: int, data: InvProfileHdrUpdateParams
    ) -> BaseResponse[InvProfileHdr]:
        """Update inventory profile header."""
        response = self._put(f"/{inv_profile_hdr_uid}", data=data)
        return BaseResponse[InvProfileHdr].model_validate(response)

    def delete(self, inv_profile_hdr_uid: int) -> BaseResponse[Any]:
        """Delete inventory profile header."""
        response = self._delete(f"/{inv_profile_hdr_uid}")
        return BaseResponse[Any].model_validate(response)

    def inv_profile_line(self, inv_profile_hdr_uid: int) -> InvProfileLineResource:
        """Access inv-profile-line endpoints for a header."""
        return InvProfileLineResource(self._http, inv_profile_hdr_uid)

    def upload(self, customer_id: int) -> InvProfileUploadResource:
        """Access upload endpoint for a customer."""
        return InvProfileUploadResource(self._http, customer_id)


class RestockHdrResource(BaseResource):
    """Resource for /restock-hdr endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/restock-hdr")

    def list(self, params: RestockHdrListParams | None = None) -> BaseResponse[list[RestockHdr]]:
        """List restock headers."""
        response = self._get(params=params)
        return BaseResponse[list[RestockHdr]].model_validate(response)

    def get(self, restock_hdr_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[RestockHdr]:
        """Get restock header by UID."""
        response = self._get(f"/{restock_hdr_uid}", params=options)
        return BaseResponse[RestockHdr].model_validate(response)

    def create(self, data: Any) -> BaseResponse[RestockHdr]:
        """Create restock header."""
        response = self._post(data=data)
        return BaseResponse[RestockHdr].model_validate(response)

    def update(
        self, restock_hdr_uid: int, data: RestockHdrUpdateParams
    ) -> BaseResponse[RestockHdr]:
        """Update restock header."""
        response = self._put(f"/{restock_hdr_uid}", data=data)
        return BaseResponse[RestockHdr].model_validate(response)

    def delete(self, restock_hdr_uid: int) -> BaseResponse[Any]:
        """Delete restock header."""
        response = self._delete(f"/{restock_hdr_uid}")
        return BaseResponse[Any].model_validate(response)


class SectionsResource(BaseResource):
    """Resource for /sections endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/sections")

    def list(self, params: SectionListParams | None = None) -> BaseResponse[list[Section]]:
        """List sections."""
        response = self._get(params=params)
        return BaseResponse[list[Section]].model_validate(response)

    def get(self, sections_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Section]:
        """Get section by UID."""
        response = self._get(f"/{sections_uid}", params=options)
        return BaseResponse[Section].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Section]:
        """Create section."""
        response = self._post(data=data)
        return BaseResponse[Section].model_validate(response)

    def update(self, sections_uid: int, data: Any) -> BaseResponse[Section]:
        """Update section."""
        response = self._put(f"/{sections_uid}", data=data)
        return BaseResponse[Section].model_validate(response)

    def delete(self, sections_uid: int) -> BaseResponse[Any]:
        """Delete section."""
        response = self._delete(f"/{sections_uid}")
        return BaseResponse[Any].model_validate(response)

    def enable(self, sections_uid: int, data: SectionEnableParams) -> BaseResponse[Section]:
        """Enable/disable section."""
        response = self._put(f"/{sections_uid}/enable", data=data)
        return BaseResponse[Section].model_validate(response)


class VMIClient(BaseServiceClient):
    """Client for the VMI (Vendor Managed Inventory) service.

    Provides access to VMI endpoints including:
    - Health check (health_check)
    - Warehouse (warehouse)
    - Distributors (distributors)
    - Products (products)
    - Inventory Profile Headers (inv_profile_hdr)
    - Restock Headers (restock_hdr)
    - Sections (sections)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> warehouses = api.vmi.warehouse.list()
        >>> for wh in warehouses.data:
        ...     print(wh.warehouse_uid)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the VMI client."""
        super().__init__(http_client)
        self._warehouse: WarehouseResource | None = None
        self._distributors: DistributorsResource | None = None
        self._products: ProductsResource | None = None
        self._inv_profile_hdr: InvProfileHdrResource | None = None
        self._restock_hdr: RestockHdrResource | None = None
        self._sections: SectionsResource | None = None

    @property
    def warehouse(self) -> WarehouseResource:
        """Access warehouse endpoints."""
        if self._warehouse is None:
            self._warehouse = WarehouseResource(self._http)
        return self._warehouse

    @property
    def distributors(self) -> DistributorsResource:
        """Access distributors endpoints."""
        if self._distributors is None:
            self._distributors = DistributorsResource(self._http)
        return self._distributors

    @property
    def products(self) -> ProductsResource:
        """Access products endpoints."""
        if self._products is None:
            self._products = ProductsResource(self._http)
        return self._products

    @property
    def inv_profile_hdr(self) -> InvProfileHdrResource:
        """Access inv-profile-hdr endpoints."""
        if self._inv_profile_hdr is None:
            self._inv_profile_hdr = InvProfileHdrResource(self._http)
        return self._inv_profile_hdr

    @property
    def restock_hdr(self) -> RestockHdrResource:
        """Access restock-hdr endpoints."""
        if self._restock_hdr is None:
            self._restock_hdr = RestockHdrResource(self._http)
        return self._restock_hdr

    @property
    def sections(self) -> SectionsResource:
        """Access sections endpoints."""
        if self._sections is None:
            self._sections = SectionsResource(self._http)
        return self._sections
