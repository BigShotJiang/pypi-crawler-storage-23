"""Schemas for the P21 Core service."""

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


class AddressListParams(EdgeCacheParams):
    """Parameters for listing addresses.

    Attributes:
        limit: Maximum number of items to return.
        offset: Number of items to skip.
        carrier_flag: Filter by carrier flag.
        default_cd: Filter by default code.
        enabled_cd: Filter by enabled code.
        status_cd: Filter by status code.
    """

    limit: int | None = None
    offset: int | None = None
    carrier_flag: str | None = None
    default_cd: str | None = None
    enabled_cd: str | None = None
    status_cd: int | None = None


class Address(CamelCaseModel):
    """Address entity.

    Attributes:
        address_id: Unique identifier for the address.
        name: Address name or label.
        address_1: First line of address.
        address_2: Second line of address.
        address_3: Third line of address.
        city: City name.
        state: State code.
        postal_code: Postal/ZIP code.
        country: Country code.
    """

    address_id: int
    name: str | None = None
    address_1: str | None = None
    address_2: str | None = None
    address_3: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    country: str | None = None


class BranchListParams(EdgeCacheParams):
    """Parameters for listing branches.

    Attributes:
        limit: Maximum number of items to return.
        offset: Number of items to skip.
        branch_id: Filter by branch ID.
        company_id: Filter by company ID.
    """

    limit: int | None = None
    offset: int | None = None
    branch_id: str | None = None
    company_id: str | None = None


class Branch(CamelCaseModel):
    """Branch entity.

    Attributes:
        branch_id: Unique identifier for the branch.
        branch_name: Name of the branch.
        company_id: Associated company ID.
        address_id: Associated address ID.
        is_active: Whether the branch is active.
    """

    branch_id: str
    branch_name: str | None = None
    company_id: str | None = None
    address_id: int | None = None
    is_active: str | None = None


class CashDrawerListParams(EdgeCacheParams):
    """Parameters for listing cash drawers.

    Attributes:
        limit: Maximum number of items to return.
        offset: Number of items to skip.
        order_by: Order results by field.
        q: Search query.
        status_cd: Filter by status code.
        drawer_open: Filter by drawer open status ('Y' or 'N').
    """

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None
    drawer_open: str | None = None


class CashDrawer(CamelCaseModel):
    """Cash drawer entity.

    Attributes:
        cash_drawer_id: Unique identifier for the cash drawer.
        location_id: Associated location ID.
        drawer_open: Whether the drawer is open ('Y' or 'N').
        opened_date: Date/time when drawer was opened.
        closed_date: Date/time when drawer was closed.
        opening_amount: Opening amount in drawer.
        closing_amount: Closing amount in drawer.
    """

    cash_drawer_id: int
    location_id: int | None = None
    drawer_open: str | None = None
    opened_date: str | None = None
    closed_date: str | None = None
    opening_amount: float | None = None
    closing_amount: float | None = None


class CompanyListParams(EdgeCacheParams):
    """Parameters for listing companies.

    Attributes:
        limit: Maximum number of items to return.
        offset: Number of items to skip.
        order_by: Order results by field.
        q: Search query.
    """

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None


class Company(CamelCaseModel):
    """Company entity.

    Attributes:
        company_id: Unique identifier for the company.
        company_name: Name of the company.
        is_active: Whether the company is active.
    """

    company_id: str
    company_name: str | None = None
    is_active: str | None = None


class LocationListParams(EdgeCacheParams):
    """Parameters for listing locations.

    Attributes:
        limit: Maximum number of items to return.
        offset: Number of items to skip.
        delete_flag: Filter by delete flag.
        order_by: Order results by field.
        q: Search query.
    """

    limit: int | None = None
    offset: int | None = None
    delete_flag: str | None = None
    order_by: str | None = None
    q: str | None = None


class Location(CamelCaseModel):
    """Location entity.

    Attributes:
        location_id: Unique identifier for the location.
        location_name: Name of the location.
        branch_id: Associated branch ID.
        address_id: Associated address ID.
        is_active: Whether the location is active.
    """

    location_id: int
    location_name: str | None = None
    branch_id: str | None = None
    address_id: int | None = None
    is_active: str | None = None


# Code P21
class CodeP21ListParams(EdgeCacheParams):
    """Parameters for listing code P21 records."""

    limit: int | None = None
    offset: int | None = None
    code_no_list: str | None = None
    q: str | None = None


class CodeP21(CamelCaseModel, extra="allow"):
    """Code P21 entity (passthrough)."""

    code_p21_uid: int | None = None


# Payment Types
class PaymentTypesListParams(EdgeCacheParams):
    """Parameters for listing payment types."""

    limit: int | None = None
    offset: int | None = None


class PaymentType(CamelCaseModel, extra="allow"):
    """Payment type entity (passthrough)."""

    payment_type_uid: int | None = None
