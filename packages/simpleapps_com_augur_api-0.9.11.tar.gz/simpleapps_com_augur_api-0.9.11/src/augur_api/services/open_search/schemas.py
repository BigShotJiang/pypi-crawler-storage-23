"""Schemas for the Open Search service."""

from typing import Any

from pydantic import BaseModel, Field

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Item Search
class ItemSearchParams(EdgeCacheParams):
    """Parameters for item search."""

    q: str
    limit: int | None = None
    offset: int | None = None
    category_id: int | None = None
    brand: str | None = None
    in_stock: bool | None = None
    sort_by: str | None = None
    sort_order: str | None = None


class ItemSearchResult(CamelCaseModel, extra="allow"):
    """Item search result entity (passthrough)."""

    inv_mast_uid: int | None = None
    item_id: str | None = None
    item_desc: str | None = None
    extended_desc: str | None = None
    category: str | None = None
    brand: str | None = None
    price: float | None = None
    in_stock: bool | None = None
    score: float | None = None
    highlights: dict[str, Any] | None = None


class ItemSearchData(CamelCaseModel, extra="allow"):
    """Item search response data wrapper."""

    items: list[ItemSearchResult] = Field(default_factory=list)
    total_results: int = 0
    max_score: float | None = None
    took: int | None = None
    query_string_uid: int | None = None
    query_string_redirect_link: bool | None = None


# Item Search Attributes
class ItemSearchAttributesParams(EdgeCacheParams):
    """Parameters for getting item search attributes."""

    q: str | None = None
    category_id: int | None = None


class ItemSearchAttribute(CamelCaseModel, extra="allow"):
    """Item search attribute entity (passthrough)."""

    attribute_uid: int | None = None
    attribute_name: str | None = None
    values: list[dict[str, Any]] | None = None


class ItemSearchAttributesData(CamelCaseModel, extra="allow"):
    """Item search attributes response data wrapper."""

    attributes: list[ItemSearchAttribute] = Field(default_factory=list)


# Items
class ItemsListParams(EdgeCacheParams):
    """Parameters for listing items."""

    limit: int | None = None
    offset: int | None = None


class ItemDocument(CamelCaseModel, extra="allow"):
    """Item document entity (passthrough)."""

    inv_mast_uid: int | None = None
    item_id: str | None = None
    item_desc: str | None = None


class ItemUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating an item document (passthrough)."""


class ItemRefreshResponse(CamelCaseModel, extra="allow"):
    """Response from item refresh operation (passthrough)."""


# Suggestions
class SuggestionParams(EdgeCacheParams):
    """Parameters for search suggestions (autocomplete)."""

    q: str
    limit: int | None = None


class SuggestionListParams(EdgeCacheParams):
    """Parameters for listing suggestions."""

    limit: int | None = None
    offset: int | None = None


class Suggestion(CamelCaseModel, extra="allow"):
    """Search suggestion entity (passthrough)."""

    suggestions_uid: int | None = None
    text: str | None = None
    type: str | None = None
    score: float | None = None
    count: int | None = None


# Query String
class QueryStringListParams(EdgeCacheParams):
    """Parameters for listing query strings."""

    limit: int | None = None
    offset: int | None = None


class QueryString(CamelCaseModel, extra="allow"):
    """Query string analytics entity (passthrough)."""

    query_string_uid: int | None = None
    query: str | None = None
    search_count: int | None = None
    result_count: int | None = None
    click_count: int | None = None
    conversion_count: int | None = None
    last_searched: str | None = None
