"""Augur API Python Client.

A Python client library for Augur API microservices.

Example:
    >>> from augur_api import AugurAPI
    >>> api = AugurAPI(token="...", site_id="...")
    >>> response = api.items.health_check()
    >>> print(response.data.site_id)
"""

from augur_api.client import AugurAPI
from augur_api.core.config import AugurAPIConfig, AugurContext, ContextCreationError
from augur_api.core.errors import (
    AugurError,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from augur_api.core.schemas import BaseResponse, HealthCheckData, PingData

__version__ = "0.9.11"
__all__ = [
    # Version
    "__version__",
    # Main client
    "AugurAPI",
    # Configuration
    "AugurAPIConfig",
    "AugurContext",
    "ContextCreationError",
    # Errors
    "AugurError",
    "AuthenticationError",
    "NotFoundError",
    "RateLimitError",
    "ValidationError",
    # Schemas
    "BaseResponse",
    "HealthCheckData",
    "PingData",
]
