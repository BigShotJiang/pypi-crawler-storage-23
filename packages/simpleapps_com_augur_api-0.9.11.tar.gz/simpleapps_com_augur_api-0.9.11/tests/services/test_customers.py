"""Tests for the Customers service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.customers.schemas import (
    Address,
    AddressParams,
    Contact,
    ContactCreateParams,
    ContactDoc,
    ContactListParams,
    ContactUd,
    Customer,
    CustomerDoc,
    CustomerListParams,
    CustomerLookupParams,
    HealthCheckData,
    Invoice,
    InvoiceListParams,
    Order,
    OrderListParams,
    PurchasedItem,
    PurchasedItemsParams,
    Quote,
    QuoteListParams,
    ShipTo,
    ShipToCreateParams,
    ShipToListParams,
    WebAllowance,
)


class TestCustomersSchemas:
    """Tests for Customers schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_customer_list_params(self) -> None:
        """Should create customer list params."""
        params = CustomerListParams(limit=10, offset=5, order_by="customer_name")
        assert params.limit == 10
        assert params.order_by == "customer_name"

    def test_customer_lookup_params(self) -> None:
        """Should create customer lookup params."""
        params = CustomerLookupParams(q="test")
        assert params.q == "test"

    def test_customer_model(self) -> None:
        """Should parse customer data."""
        data = {"customerId": 123, "customerName": "Test Customer"}
        result = Customer.model_validate(data)
        assert result.customer_id == 123
        assert result.customer_name == "Test Customer"

    def test_customer_doc_model(self) -> None:
        """Should parse customer doc data."""
        data = {"customerId": 123, "customerName": "Test", "contacts": []}
        result = CustomerDoc.model_validate(data)
        assert result.customer_id == 123

    def test_address_params(self) -> None:
        """Should create address params."""
        params = AddressParams(limit=10)
        assert params.limit == 10

    def test_address_model(self) -> None:
        """Should parse address data."""
        data = {"addressId": 1, "city": "Test City", "state": "CA"}
        result = Address.model_validate(data)
        assert result.address_id == 1
        assert result.city == "Test City"

    def test_contact_list_params(self) -> None:
        """Should create contact list params."""
        params = ContactListParams(limit=10, q="john")
        assert params.q == "john"

    def test_contact_model(self) -> None:
        """Should parse contact data."""
        data = {"contactId": 1, "firstName": "John", "lastName": "Doe"}
        result = Contact.model_validate(data)
        assert result.contact_id == 1
        assert result.first_name == "John"

    def test_contact_create_params(self) -> None:
        """Should create contact create params."""
        params = ContactCreateParams(first_name="John", email="john@test.com")
        assert params.first_name == "John"

    def test_contact_doc_model(self) -> None:
        """Should parse contact doc data."""
        data = {"contactId": 1, "firstName": "John", "customers": []}
        result = ContactDoc.model_validate(data)
        assert result.contact_id == 1

    def test_web_allowance_model(self) -> None:
        """Should parse web allowance data."""
        data = {"contactId": 1, "canViewOrders": True, "canPlaceOrders": False}
        result = WebAllowance.model_validate(data)
        assert result.can_view_orders is True

    def test_contact_ud_model(self) -> None:
        """Should parse contact ud data."""
        data = {"contactId": 1, "udField1": "value1"}
        result = ContactUd.model_validate(data)
        assert result.ud_field1 == "value1"

    def test_ship_to_list_params(self) -> None:
        """Should create ship to list params."""
        params = ShipToListParams(limit=10)
        assert params.limit == 10

    def test_ship_to_model(self) -> None:
        """Should parse ship to data."""
        data = {"shipToId": 1, "customerId": 123, "shipToName": "Main Office"}
        result = ShipTo.model_validate(data)
        assert result.ship_to_id == 1

    def test_ship_to_create_params(self) -> None:
        """Should create ship to create params."""
        params = ShipToCreateParams(ship_to_name="Branch", city="Test City")
        assert params.ship_to_name == "Branch"

    def test_order_list_params(self) -> None:
        """Should create order list params."""
        params = OrderListParams(limit=10, full_document=True)
        assert params.full_document is True

    def test_order_model(self) -> None:
        """Should parse order data."""
        data = {"orderNo": 12345, "customerId": 123, "totalAmount": 999.99}
        result = Order.model_validate(data)
        assert result.order_no == 12345

    def test_invoice_list_params(self) -> None:
        """Should create invoice list params."""
        params = InvoiceListParams(limit=10)
        assert params.limit == 10

    def test_invoice_model(self) -> None:
        """Should parse invoice data."""
        data = {"invoiceNo": 1001, "customerId": 123, "balanceDue": 500.00}
        result = Invoice.model_validate(data)
        assert result.invoice_no == 1001

    def test_quote_list_params(self) -> None:
        """Should create quote list params."""
        params = QuoteListParams(limit=10)
        assert params.limit == 10

    def test_quote_model(self) -> None:
        """Should parse quote data."""
        data = {"orderNo": 5001, "customerId": 123, "totalAmount": 1500.00}
        result = Quote.model_validate(data)
        assert result.order_no == 5001

    def test_purchased_items_params(self) -> None:
        """Should create purchased items params."""
        params = PurchasedItemsParams(limit=10)
        assert params.limit == 10

    def test_purchased_item_model(self) -> None:
        """Should parse purchased item data."""
        data = {"invMastUid": 1, "itemId": "ABC123", "totalQuantity": 100.0}
        result = PurchasedItem.model_validate(data)
        assert result.inv_mast_uid == 1


class TestCustomersClient:
    """Tests for CustomersClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://customers.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.customers.health_check()
        assert response.data.site_id == "test-site"

    def test_customer_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list customers."""
        mock_response = {
            "count": 1,
            "data": [{"customerId": 123, "customerName": "Test"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/customer",
            json=mock_response,
        )
        response = api.customers.customer.list()
        assert len(response.data) == 1

    def test_customer_lookup(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should lookup customers."""
        mock_response = {
            "count": 1,
            "data": [{"customerId": 123, "customerName": "Test"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/customer/lookup?q=test",
            json=mock_response,
        )
        response = api.customers.customer.lookup(CustomerLookupParams(q="test"))
        assert len(response.data) == 1

    def test_customer_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get customer by ID."""
        mock_response = {
            "count": 1,
            "data": {"customerId": 123, "customerName": "Test"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/customer/123",
            json=mock_response,
        )
        response = api.customers.customer.get(123)
        assert response.data.customer_id == 123

    def test_customer_get_doc(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get customer document."""
        mock_response = {
            "count": 1,
            "data": {"customerId": 123, "customerName": "Test", "contacts": []},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/customer/123/doc",
            json=mock_response,
        )
        response = api.customers.customer.get_doc(123)
        assert response.data.customer_id == 123

    def test_customer_get_address(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get customer addresses."""
        mock_response = {
            "count": 1,
            "data": [{"addressId": 1, "city": "Test City"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/customer/123/address",
            json=mock_response,
        )
        response = api.customers.customer.get_address(123)
        assert len(response.data) == 1

    def test_customer_list_contacts(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list customer contacts."""
        mock_response = {
            "count": 1,
            "data": [{"contactId": 1, "firstName": "John"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/customer/123/contacts",
            json=mock_response,
        )
        response = api.customers.customer.list_contacts(123)
        assert len(response.data) == 1

    def test_customer_create_contact(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create customer contact."""
        mock_response = {
            "count": 1,
            "data": {"contactId": 1, "firstName": "John"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/customer/123/contacts",
            json=mock_response,
            method="POST",
        )
        response = api.customers.customer.create_contact(
            123, ContactCreateParams(first_name="John")
        )
        assert response.data.contact_id == 1

    def test_customer_list_ship_to(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list customer ship-to addresses."""
        mock_response = {
            "count": 1,
            "data": [{"shipToId": 1, "shipToName": "Main"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/customer/123/ship-to",
            json=mock_response,
        )
        response = api.customers.customer.list_ship_to(123)
        assert len(response.data) == 1

    def test_customer_create_ship_to(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create customer ship-to address."""
        mock_response = {
            "count": 1,
            "data": {"shipToId": 1, "shipToName": "Branch"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/customer/123/ship-to",
            json=mock_response,
            method="POST",
        )
        response = api.customers.customer.create_ship_to(
            123, ShipToCreateParams(ship_to_name="Branch")
        )
        assert response.data.ship_to_id == 1

    def test_customer_list_orders(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list customer orders."""
        mock_response = {
            "count": 1,
            "data": [{"orderNo": 12345, "customerId": 123}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/customer/123/orders",
            json=mock_response,
        )
        response = api.customers.customer.list_orders(123)
        assert len(response.data) == 1

    def test_customer_get_order(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get customer order."""
        mock_response = {
            "count": 1,
            "data": {"orderNo": 12345, "customerId": 123},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/customer/123/orders/12345",
            json=mock_response,
        )
        response = api.customers.customer.get_order(123, 12345)
        assert response.data.order_no == 12345

    def test_customer_list_invoices(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list customer invoices."""
        mock_response = {
            "count": 1,
            "data": [{"invoiceNo": 1001, "customerId": 123}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/customer/123/invoices",
            json=mock_response,
        )
        response = api.customers.customer.list_invoices(123)
        assert len(response.data) == 1

    def test_customer_get_invoice(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get customer invoice."""
        mock_response = {
            "count": 1,
            "data": {"invoiceNo": 1001, "customerId": 123},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/customer/123/invoices/1001",
            json=mock_response,
        )
        response = api.customers.customer.get_invoice(123, 1001)
        assert response.data.invoice_no == 1001

    def test_customer_list_quotes(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list customer quotes."""
        mock_response = {
            "count": 1,
            "data": [{"orderNo": 5001, "customerId": 123}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/customer/123/quotes",
            json=mock_response,
        )
        response = api.customers.customer.list_quotes(123)
        assert len(response.data) == 1

    def test_customer_get_quote(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get customer quote."""
        mock_response = {
            "count": 1,
            "data": {"orderNo": 5001, "customerId": 123},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/customer/123/quotes/5001",
            json=mock_response,
        )
        response = api.customers.customer.get_quote(123, 5001)
        assert response.data.order_no == 5001

    def test_customer_list_purchased_items(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list customer purchased items."""
        mock_response = {
            "count": 1,
            "data": [{"invMastUid": 1, "itemId": "ABC123"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/customer/123/purchased-items",
            json=mock_response,
        )
        response = api.customers.customer.list_purchased_items(123)
        assert len(response.data) == 1

    def test_contacts_get_doc(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get contact document."""
        mock_response = {
            "count": 1,
            "data": {"contactId": 1, "firstName": "John", "customers": []},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/contacts/1/doc",
            json=mock_response,
        )
        response = api.customers.contacts.get_doc(1)
        assert response.data.contact_id == 1

    def test_contacts_get_web_allowance(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get contact web allowance."""
        mock_response = {
            "count": 1,
            "data": {"contactId": 1, "canViewOrders": True},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/contacts/1/web-allowance",
            json=mock_response,
        )
        response = api.customers.contacts.get_web_allowance(1)
        assert response.data.can_view_orders is True

    def test_contacts_list_customers(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list customers for contact."""
        mock_response = {
            "count": 1,
            "data": [{"customerId": 123, "customerName": "Test"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/contacts/1/customers",
            json=mock_response,
        )
        response = api.customers.contacts.list_customers(1)
        assert len(response.data) == 1

    def test_contacts_refresh(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should refresh contacts data."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/contacts/refresh",
            json=mock_response,
        )
        response = api.customers.contacts.refresh()
        assert response.data is True

    def test_contacts_ud_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get contact user-defined data."""
        mock_response = {
            "count": 1,
            "data": {"contactId": 1, "udField1": "value1"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/contacts-ud/1",
            json=mock_response,
        )
        response = api.customers.contacts_ud.get(1)
        assert response.data.ud_field1 == "value1"

    def test_ship_to_refresh(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should refresh ship-to data."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/ship-to/refresh",
            json=mock_response,
        )
        response = api.customers.ship_to.refresh()
        assert response.data is True

    def test_oe_contacts_customer_refresh(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should refresh OE contacts customer data."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://customers.augur-api.com/oe-contacts-customer/refresh",
            json=mock_response,
        )
        response = api.customers.oe_contacts_customer.refresh()
        assert response.data is True

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.customers
        assert client.customer is client.customer
        assert client.contacts is client.contacts
        assert client.contacts_ud is client.contacts_ud
        assert client.ship_to is client.ship_to
        assert client.oe_contacts_customer is client.oe_contacts_customer
