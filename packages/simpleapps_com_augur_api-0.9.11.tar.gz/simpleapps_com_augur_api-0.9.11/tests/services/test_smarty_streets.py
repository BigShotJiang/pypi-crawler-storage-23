"""Tests for the Smarty Streets service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.smarty_streets.schemas import (
    HealthCheckData,
    UsLookupData,
    UsLookupParams,
)


class TestSmartyStreetsSchemas:
    """Tests for Smarty Streets schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_us_lookup_params(self) -> None:
        """Should create US lookup params."""
        params = UsLookupParams(
            address1="123 Main St",
            city="Anytown",
            state="CA",
            postal_code="90210",
        )
        assert params.address1 == "123 Main St"
        assert params.city == "Anytown"
        assert params.state == "CA"
        assert params.postal_code == "90210"

    def test_us_lookup_data(self) -> None:
        """Should parse US lookup data."""
        data = {"candidates": [{"deliveryLine1": "123 MAIN ST", "lastLine": "ANYTOWN CA 90210"}]}
        result = UsLookupData.model_validate(data)
        assert result.candidates is not None
        assert len(result.candidates) == 1
        assert result.candidates[0]["deliveryLine1"] == "123 MAIN ST"


class TestSmartyStreetsClient:
    """Tests for SmartyStreetsClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://smarty-streets.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.smarty_streets.health_check()
        assert response.data.site_id == "test-site"

    def test_ping(self, httpx_mock: HTTPXMock, api: AugurAPI, mock_ping_response: dict) -> None:
        """Should call ping endpoint."""
        httpx_mock.add_response(
            url="https://smarty-streets.augur-api.com/ping",
            json=mock_ping_response,
        )
        response = api.smarty_streets.ping()
        assert response.data == "pong"

    def test_us_lookup_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should lookup US address."""
        mock_response = {
            "count": 1,
            "data": {
                "candidates": [{"deliveryLine1": "123 MAIN ST", "lastLine": "ANYTOWN CA 90210"}]
            },
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://smarty-streets.augur-api.com/us/lookup?address1=123+Main+St&city=Anytown&state=CA",
            json=mock_response,
        )
        response = api.smarty_streets.us.lookup.get(
            UsLookupParams(address1="123 Main St", city="Anytown", state="CA")
        )
        assert response.data.candidates is not None
        assert len(response.data.candidates) == 1

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.smarty_streets
        assert client.us is client.us
        assert client.us.lookup is client.us.lookup
