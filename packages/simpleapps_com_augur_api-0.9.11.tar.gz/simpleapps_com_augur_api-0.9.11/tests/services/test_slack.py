"""Tests for the Slack service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.slack.schemas import (
    HealthCheckData,
    WebHookMessage,
    WebHookResponse,
)


class TestSlackSchemas:
    """Tests for Slack schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_web_hook_message(self) -> None:
        """Should create web hook message."""
        message = WebHookMessage(
            text="Hello World!",
            channel="#general",
            username="bot",
            icon_emoji=":robot:",
            attachments=[{"text": "Attachment text"}],
        )
        assert message.text == "Hello World!"
        assert message.channel == "#general"
        assert len(message.attachments) == 1

    def test_web_hook_message_minimal(self) -> None:
        """Should create web hook message with only required fields."""
        message = WebHookMessage(text="Simple message")
        assert message.text == "Simple message"
        assert message.channel is None

    def test_web_hook_message_with_blocks(self) -> None:
        """Should create web hook message with blocks."""
        message = WebHookMessage(
            text="Fallback text",
            blocks=[{"type": "section", "text": {"type": "plain_text", "text": "Block text"}}],
        )
        assert len(message.blocks) == 1
        assert message.blocks[0]["type"] == "section"

    def test_web_hook_response_model(self) -> None:
        """Should parse web hook response data."""
        data = {"ok": True, "error": None}
        result = WebHookResponse.model_validate(data)
        assert result.ok is True
        assert result.error is None

    def test_web_hook_response_error(self) -> None:
        """Should parse web hook error response."""
        data = {"ok": False, "error": "channel_not_found"}
        result = WebHookResponse.model_validate(data)
        assert result.ok is False
        assert result.error == "channel_not_found"


class TestSlackClient:
    """Tests for SlackClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://slack.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.slack.health_check()
        assert response.data.site_id == "test-site"

    def test_web_hook_send(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should send web hook message."""
        mock_response = {
            "count": 1,
            "data": {"ok": True},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://slack.augur-api.com/web-hook",
            json=mock_response,
            method="POST",
        )
        response = api.slack.web_hook.send(WebHookMessage(text="Hello!"))
        assert response.data.ok is True

    def test_web_hook_send_with_channel(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should send web hook message to specific channel."""
        mock_response = {
            "count": 1,
            "data": {"ok": True},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://slack.augur-api.com/web-hook",
            json=mock_response,
            method="POST",
        )
        response = api.slack.web_hook.send(
            WebHookMessage(text="Hello!", channel="#general", username="TestBot")
        )
        assert response.data.ok is True

    def test_web_hook_refresh(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should refresh web hook configuration."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://slack.augur-api.com/web-hook/refresh",
            json=mock_response,
        )
        response = api.slack.web_hook.refresh()
        assert response.data is True

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.slack
        assert client.web_hook is client.web_hook
