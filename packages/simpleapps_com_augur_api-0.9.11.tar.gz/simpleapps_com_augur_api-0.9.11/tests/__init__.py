"""Tests for the Augur API Python client."""
