#!/usr/bin/env python3
"""JSON Story Runner CLI.

Runs stories from shared/stories/definitions/*.json

Usage:
    python -m tests.e2e.stories.run_story health-check
    python -m tests.e2e.stories.run_story --list
    uv run python tests/e2e/stories/run_story.py health-check
"""

import argparse
import json
import sys
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from augur_api import AugurAPI

from .story_runner import (
    SiteCredentials,
    StoryResult,
    list_available_stories,
    load_json_story,
    run_json_story,
)

RECORDINGS_DIR = Path(__file__).parent / "recordings"
PROTECTED_DIR = Path(__file__).parent.parent.parent.parent.parent.parent / ".protected"


def load_site_credentials() -> list[SiteCredentials]:
    """Load site credentials from individual site files in .protected/.

    Reads files like ampro-online.json, augur_info.json that contain:
    - siteId: string
    - jwt: string
    - users?: array of {username, password}
    - customerIds?: string[] (for story params)
    - itemIds?: string[] (for story params)
    """
    if not PROTECTED_DIR.exists():
        return []

    sites = []
    for file_path in PROTECTED_DIR.glob("*.json"):
        # Skip example files, sites.json (old format)
        if file_path.name.endswith(".example.json") or file_path.name == "sites.json":
            continue

        try:
            with open(file_path, encoding="utf-8") as f:
                site_data = json.load(f)

            # Skip files without required fields
            if "siteId" not in site_data or "jwt" not in site_data:
                continue

            # Build story params from site-specific test data
            story_params: dict[str, Any] = {}
            if "customerIds" in site_data:
                story_params["customerIds"] = site_data["customerIds"]
            if "itemIds" in site_data:
                story_params["itemIds"] = site_data["itemIds"]
            if "users" in site_data:
                story_params["users"] = site_data["users"]

            sites.append(
                SiteCredentials(
                    site_id=site_data["siteId"],
                    jwt=site_data["jwt"],
                    name=site_data.get("name", site_data["siteId"]),
                    story_params=story_params,
                )
            )
        except (json.JSONDecodeError, KeyError):
            # Skip files that can't be parsed
            continue

    return sites


def list_stories() -> None:
    """List all available JSON stories."""
    print("\nAvailable JSON stories:")
    print("=======================")

    for name in sorted(list_available_stories()):
        try:
            story = load_json_story(name)
            params = ""
            if story.get("required_params"):
                params = f" [requires: {', '.join(story['required_params'])}]"
            print(f"  {name.ljust(25)} - {story['description']}{params}")
        except Exception as e:
            print(f"  {name.ljust(25)} - Error loading: {e}")

    print()


def save_result(result: StoryResult) -> None:
    """Save story result to recordings directory."""
    date_dir = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    site_dir = RECORDINGS_DIR / date_dir / result.site_id

    site_dir.mkdir(parents=True, exist_ok=True)

    filename = result.story_name.lower().replace(" ", "-") + ".json"
    filepath = site_dir / filename

    # Convert dataclass to dict for JSON serialization
    result_dict = asdict(result)
    # Convert StepResult objects
    result_dict["steps"] = [asdict(step) for step in result.steps]

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(result_dict, f, indent=2, default=str)

    print(f"\n📁 Results saved to: {filepath}")


def generate_summary(result: StoryResult) -> None:
    """Print summary of story run."""
    print("\n" + "=" * 60)
    print("📊 SUMMARY")
    print("=" * 60)

    successful = sum(1 for s in result.steps if s.success)
    failed = sum(1 for s in result.steps if not s.success)
    total = len(result.steps)

    print(f"\n  Site: {result.site_name} ({result.site_id})")
    print(f"  Story: {result.story_name}")
    print(f"  Duration: {result.total_time_ms}ms")
    print(f"\n  Results: {successful}/{total} passed, {failed} failed")

    if failed > 0:
        print("\n  Failed steps:")
        for step in result.steps:
            if not step.success:
                print(f"    ❌ {step.description}: {step.error}")

    captured_count = len(result.captured_data)
    if captured_count > 0:
        print(f"\n  Captured {captured_count} values")

    if result.verifications:
        passed_verifications = sum(1 for v in result.verifications if v["passed"])
        print(f"  Verifications: {passed_verifications}/{len(result.verifications)} passed")

    print("\n" + "=" * 60)


def _parse_value(value: str) -> int | float | str:
    """Parse string value to int, float, or keep as string."""
    try:
        return int(value)
    except ValueError:
        try:
            return float(value)
        except ValueError:
            return value


def parse_runtime_params(args: list[str]) -> dict[str, Any]:
    """Parse runtime parameters from command line args."""
    params: dict[str, Any] = {}
    i = 0
    while i < len(args):
        arg = args[i]
        if arg.startswith("--") and "=" in arg:
            key, value = arg[2:].split("=", 1)
            params[key] = _parse_value(value)
        elif arg.startswith("--") and i + 1 < len(args) and not args[i + 1].startswith("--"):
            key = arg[2:]
            value = args[i + 1]
            params[key] = _parse_value(value)
            i += 1
        i += 1
    return params


def main() -> None:
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Run JSON story tests against Augur API",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m tests.e2e.stories.run_story health-check
  python -m tests.e2e.stories.run_story search --search_term_1=tape --search_term_2=wire
  python -m tests.e2e.stories.run_story --list
        """,
    )
    parser.add_argument("story", nargs="?", help="Name of the story to run")
    parser.add_argument("--list", "-l", action="store_true", help="List available stories")
    parser.add_argument("params", nargs="*", help="Runtime parameters (--key=value)")

    args, unknown = parser.parse_known_args()

    if args.list:
        list_stories()
        sys.exit(0)

    if not args.story:
        parser.print_help()
        list_stories()
        sys.exit(0)

    # Load story
    available = list_available_stories()
    if args.story not in available:
        print(f"\n❌ Unknown story: {args.story}")
        list_stories()
        sys.exit(1)

    story = load_json_story(args.story)
    runtime_params = parse_runtime_params(args.params + unknown)

    # Check required params
    required = story.get("required_params", [])
    if required:
        missing = [p for p in required if p not in runtime_params]
        if missing:
            print(f"\n⚠️  Missing required params: {', '.join(missing)}")
            print("   Story may fail or use defaults.\n")

    # Load site credentials
    sites = load_site_credentials()
    if not sites:
        print("\n❌ No sites configured in .protected/story-test-sites.json")
        print("\nCreate the file with:")
        print(
            json.dumps(
                {
                    "sites": [
                        {
                            "siteId": "YOUR-SITE-ID",
                            "jwt": "YOUR-JWT-TOKEN",
                            "name": "Site Name",
                        }
                    ]
                },
                indent=2,
            )
        )
        sys.exit(1)

    print(f"\n🎭 Running JSON story: {story['name']}")
    print(f"📍 Against {len(sites)} site(s)")
    if runtime_params:
        print(f"📦 Runtime params: {json.dumps(runtime_params)}")

    # Run against each site
    for site in sites:
        api = AugurAPI(token=site.jwt, site_id=site.site_id)
        result = run_json_story(api, site, story, runtime_params)
        generate_summary(result)
        save_result(result)

    print("\n✅ Story run complete!\n")


if __name__ == "__main__":
    main()
