"""Pytest configuration and fixtures for Augur API tests."""

import json
import os
from pathlib import Path

import pytest

from augur_api import AugurAPI, AugurAPIConfig, AugurContext

# Path to credentials for live testing
PROTECTED_DIR = Path(__file__).parent.parent.parent.parent.parent / ".protected"


@pytest.fixture
def api_config() -> AugurAPIConfig:
    """Create a test API configuration."""
    return AugurAPIConfig(
        token="test-token",
        site_id="test-site",
        timeout=30.0,
        retries=3,
        retry_delay=1.0,
    )


@pytest.fixture
def api(api_config: AugurAPIConfig) -> AugurAPI:
    """Create a test AugurAPI instance."""
    return AugurAPI.from_config(api_config)


@pytest.fixture
def context() -> AugurContext:
    """Create a test context."""
    return AugurContext(
        site_id="test-site",
        jwt="test-jwt-token",
    )


@pytest.fixture
def live_api() -> AugurAPI | None:
    """Create a live API client from .protected credentials.

    Returns None if credentials are not available.
    Use with: pytest.mark.skipif(not live_api, reason="No credentials")
    """
    creds_file = PROTECTED_DIR / "augur_info.json"
    if not creds_file.exists():
        return None

    with open(creds_file) as f:
        creds = json.load(f)

    return AugurAPI(token=creds["jwt"], site_id=creds["siteId"])


def has_live_credentials() -> bool:
    """Check if live API credentials are available."""
    return (PROTECTED_DIR / "augur_info.json").exists()


# Skip marker for live tests
live_test = pytest.mark.skipif(
    not has_live_credentials() or os.environ.get("SKIP_LIVE_TESTS", "").lower() == "true",
    reason="Live API credentials not available or SKIP_LIVE_TESTS=true",
)


# Mock responses use camelCase to match real API responses
@pytest.fixture
def mock_health_check_response() -> dict:
    """Create a mock health check response (camelCase like real API)."""
    return {
        "count": 1,
        "data": {
            "siteHash": "abc123",
            "siteId": "test-site",
        },
        "message": "Success",
        "options": [],
        "params": [],
        "status": 200,
        "total": 1,
        "totalResults": 1,
    }


@pytest.fixture
def mock_ping_response() -> dict:
    """Create a mock ping response."""
    return {
        "count": 1,
        "data": "pong",
        "message": "Success",
        "options": [],
        "params": [],
        "status": 200,
        "total": 1,
        "totalResults": 1,
    }


@pytest.fixture
def mock_inv_mast_list_response() -> dict:
    """Create a mock inventory master list response (camelCase like real API)."""
    return {
        "count": 2,
        "data": [
            {
                "invMastUid": 1,
                "itemId": "ITEM001",
                "itemDesc": "Test Item 1",
            },
            {
                "invMastUid": 2,
                "itemId": "ITEM002",
                "itemDesc": "Test Item 2",
            },
        ],
        "message": "Success",
        "options": [],
        "params": [],
        "status": 200,
        "total": 2,
        "totalResults": 2,
    }


@pytest.fixture
def mock_inv_mast_get_response() -> dict:
    """Create a mock inventory master get response (camelCase like real API)."""
    return {
        "count": 1,
        "data": {
            "invMastUid": 1,
            "itemId": "ITEM001",
            "itemDesc": "Test Item 1",
            "extendedDesc": "Extended description",
        },
        "message": "Success",
        "options": [],
        "params": [],
        "status": 200,
        "total": 1,
        "totalResults": 1,
    }


@pytest.fixture
def mock_cash_drawer_list_response() -> dict:
    """Create a mock cash drawer list response (camelCase like real API)."""
    return {
        "count": 1,
        "data": [
            {
                "cashDrawerId": 1,
                "locationId": 100,
                "drawerOpen": "Y",
            },
        ],
        "message": "Success",
        "options": [],
        "params": [],
        "status": 200,
        "total": 1,
        "totalResults": 1,
    }
