#!/bin/env python
from .scop import TrEnum
