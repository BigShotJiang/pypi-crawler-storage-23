#!/bin/bash
sbatch --partition genoa run_tb.sh
