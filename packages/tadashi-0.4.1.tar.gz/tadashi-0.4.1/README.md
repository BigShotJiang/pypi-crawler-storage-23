# Tadashi

## Install

TADASHI can be `pip` installed from [PyPI](https://pypi.org/project/tadashi/):

```bash
pip install tadashi
```
