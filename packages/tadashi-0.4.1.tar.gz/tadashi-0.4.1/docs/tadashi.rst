tadashi package
===============

Submodules
----------

tadashi.apps module
-------------------

.. automodule:: tadashi.apps
   :members:
   :show-inheritance:
   :undoc-members:

tadashi.node\_type module
-------------------------

.. automodule:: tadashi.node_type
   :members:
   :show-inheritance:
   :undoc-members:

tadashi.scop module
-------------------

.. automodule:: tadashi.scop
   :members:
   :show-inheritance:
   :undoc-members:

tadashi.translators module
--------------------------

.. automodule:: tadashi.translators
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: tadashi
   :members:
   :show-inheritance:
   :undoc-members:
