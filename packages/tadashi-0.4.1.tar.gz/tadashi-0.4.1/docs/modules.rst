tadashi
=======

.. toctree::
   :maxdepth: 4

   tadashi
