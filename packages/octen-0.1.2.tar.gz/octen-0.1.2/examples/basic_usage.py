"""Basic usage examples

Demonstrates basic features of Octen SDK
"""

from octen import Octen


def main():
    # Create client (using context manager)
    with Octen(api_key="your-api-key") as client:
        print("=" * 80)
        print("Octen SDK Basic usage examples")
        print("=" * 80)

        print("\n1. Simple Search")
        print("-" * 80)
        response = client.search.search("Python programming", count=5)

        print(f"Query: {response.query}")
        print(f"Search type: {response.search_type}")
        print(f"Result count: {len(response.results)}\n")

        for i, result in enumerate(response.results, 1):
            print(f"Result {i}:")
            print(f"  Title: {result['title']}")
            print(f"  URL: {result['url']}")
            if result.get('highlight'):
                print(f"  Summary: {result['highlight'][:100]}...")
            print()

        print("\n2. Create Text Embedding")
        print("-" * 80)
        embedding_response = client.embedding.create(
            input="Hello, world!",
            model="octen-embedding-4b"
        )

        vector = embedding_response.get_first_embedding()
        if vector:
            print(f"Input text: Hello, world!")
            print(f"Vector dimension: {len(vector)}")
            print(f"First 5 values: {vector[:5]}")
            print(f"Model used: {embedding_response.model}")

        print("\n3. Batch Text Embedding")
        print("-" * 80)
        texts = [
            "Python is a programming language",
            "JavaScript is used for web development",
            "Machine learning is a subset of AI"
        ]

        batch_response = client.embedding.create(input=texts)
        vectors = batch_response.get_embeddings()

        print(f"Number of input texts: {len(texts)}")
        print(f"Generated vector count: {len(vectors)}")
        for i, text in enumerate(texts):
            print(f"  {i + 1}. {text} -> Vector dimension {len(vectors[i])}")

        print("\n4. Using Convenience Methods")
        print("-" * 80)

        # Simple Search
        simple_response = client.search.simple_search("AI", count=3)
        print(f"Simple SearchResult: {len(simple_response.results)} items")

        query_vector = client.embedding.embed_query("search query")
        print(f"QueryVector dimension: {len(query_vector)}")

        doc_vectors = client.embedding.embed_documents(["doc 1", "doc 2"])
        print(f"Document vector count: {len(doc_vectors)}")


if __name__ == "__main__":
    main()
