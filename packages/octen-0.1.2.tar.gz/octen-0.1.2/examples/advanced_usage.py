"""Advanced usage examples

Demonstrates advanced features of Octen SDK including filtering, highlighting, full content, etc.
"""

from octen import Octen, HighlightOptions, FullContentOptions


def main():
    with Octen(api_key="your-api-key") as client:
        print("=" * 80)
        print("Octen SDK Advanced usage examples")
        print("=" * 80)

        print("\n1. Domain Filtering Search")
        print("-" * 80)
        response = client.search.search(
            query="machine learning tutorials",
            count=10,
            include_domains=["github.com", "arxiv.org", "medium.com"],
            exclude_domains=["pinterest.com"]
        )

        print(f"Found {len(response.results)} results")
        for result in response.results[:3]:
            print(f"  - {result['title']}")
            print(f"    {result['url']}")

        print("\n2. Time Range Search")
        print("-" * 80)
        response = client.search.search(
            query="Python 3.12 new features",
            count=5,
            time_basis="published",
            start_time="2024-01-01T00:00:00Z",
            end_time="2024-12-31T23:59:59Z"
        )

        print(f"Found {len(response.results)} results")
        for result in response.results:
            pub_time = result.get('time_published', 'Unknown')
            print(f"  - {result['title']}")
            print(f"    Published time: {pub_time}")

        print("\n3. Custom Highlightingoptions")
        print("-" * 80)
        response = client.search.search(
            query="deep learning",
            count=3,
            highlight=HighlightOptions(
                enable=True,
                max_tokens=500  # Longer summary
            )
        )

        for i, result in enumerate(response.results, 1):
            print(f"\nResult {i}:")
            print(f"Title: {result['title']}")
            if result.get('highlight'):
                print(f"Summary ({len(result['highlight'])} characters):")
                print(f"{result['highlight'][:200]}...")

        print("\n4. Get Full Content")
        print("-" * 80)
        response = client.search.search(
            query="API design best practices",
            count=2,
            full_content=FullContentOptions(
                enable=True,
                max_tokens=2000
            )
        )

        for i, result in enumerate(response.results, 1):
            print(f"\nResult {i}: {result['title']}")
            if result.get('full_content'):
                content_length = len(result['full_content'])
                print(f"Full content length: {content_length} characters")
                print(f"Content preview: {result['full_content'][:150]}...")

        print("\n5. Semantic Search")
        print("-" * 80)
        response = client.search.search(
            query="how to improve code quality",
            count=5,
            search_type="semantic",  # Use semantic search
            format="markdown"  # Return Markdown format
        )

        print(f"Search type: {response.search_type}")
        print(f"Result count: {len(response.results)}")
        for result in response.results[:3]:
            print(f"  - {result['title']}")

        print("\n6. Text Content Filtering")
        print("-" * 80)
        response = client.search.search(
            query="Python web framework",
            count=5,
            include_text=["Django", "Flask"],  # Must include these words
            exclude_text=["deprecated", "outdated"]  # Exclude these words
        )

        print(f"Found {len(response.results)} results")
        for result in response.results:
            print(f"  - {result['title']}")

        print("\n7. Custom Timeoutsettings")
        print("-" * 80)
        try:
            # This request uses 120 second timeout
            response = client.search.search(
                query="complex query",
                count=20,
                timeout=120.0
            )
            print(f"Request successful, found {len(response.results)} results")
        except Exception as e:
            print(f"Request failed: {e}")

        print("\n8. View Usage Information")
        print("-" * 80)
        response = client.search.search("test query", count=3)

        if response.usage:
            print(f"Token usage:")
            for key, value in response.usage.items():
                print(f"  {key}: {value}")

        if response.latency:
            print(f"\nLatency information:")
            for key, value in response.latency.items():
                print(f"  {key}: {value}ms")


if __name__ == "__main__":
    main()
