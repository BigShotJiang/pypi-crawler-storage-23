"""Async usage examples

Demonstrates async features of Octen SDK (requires octen[async] installation)
"""

import asyncio
from octen import AsyncOcten


async def main():
    """Async example main function"""
    async with AsyncOcten(api_key="your-api-key") as client:
        print("=" * 80)
        print("Octen SDK Async usage examples")
        print("=" * 80)

        print("\n1. Async Search")
        print("-" * 80)
        response = await client.search.search("Python async", count=5)

        print(f"Found {len(response.results)} results")
        for result in response.results[:3]:
            print(f"  - {result['title']}")

        print("\n2. Async Embedding")
        print("-" * 80)
        embedding = await client.embedding.create("async programming")
        vector = embedding.get_first_embedding()

        if vector:
            print(f"Vector dimension: {len(vector)}")

        print("\n3. Concurrent Execution")
        print("-" * 80)

        # Execute search and embedding concurrently
        search_task = client.search.search("AI", count=5)
        embedding_task = client.embedding.create("Hello")

        search_result, embedding_result = await asyncio.gather(
            search_task,
            embedding_task
        )

        print(f"SearchResult: {len(search_result.results)} items")
        print(f"Embedding dimension: {len(embedding_result.get_first_embedding())}")

        print("\n4. Batch Concurrent Search")
        print("-" * 80)

        queries = ["Python", "JavaScript", "Go", "Rust"]
        tasks = [client.search.search(q, count=3) for q in queries]
        results = await asyncio.gather(*tasks)

        for query, result in zip(queries, results):
            print(f"  {query}: {len(result.results)} results")

        print("\n5. Batch Concurrent Embedding")
        print("-" * 80)

        texts = [f"Document {i}" for i in range(10)]
        tasks = [client.embedding.create(text) for text in texts]
        embeddings = await asyncio.gather(*tasks)

        print(f"Generated {len(embeddings)} embedding vectors")


if __name__ == "__main__":
    # Run async main function
    asyncio.run(main())
