"""Test Octen client"""

import pytest
from octen import Octen
from octen.core.exceptions import OctenValidationError


def test_client_initialization():
    """Test client initialization"""
    client = Octen(api_key="test-key")
    assert client is not None
    assert client.search is not None
    assert client.embedding is not None
    client.close()


def test_client_context_manager():
    """Test context manager"""
    with Octen(api_key="test-key") as client:
        assert client is not None


def test_client_no_api_key():
    """Test exception when API key is missing"""
    with pytest.raises(ValueError, match="api_key cannot be empty"):
        Octen(api_key="")


def test_client_custom_config():
    """Test custom configuration"""
    client = Octen(
        api_key="test-key",
        base_url="https://custom.api.com",
        timeout=60.0,
        max_retries=5,
        http2=False,
    )
    assert client._http_client.base_url == "https://custom.api.com"
    assert client._http_client.timeout == 60.0
    assert client._http_client.max_retries == 5
    client.close()


def test_client_repr():
    """Test string representation"""
    client = Octen(api_key="test-key", base_url="https://api.octen.ai")
    repr_str = repr(client)
    assert "Octen" in repr_str
    assert "https://api.octen.ai" in repr_str
    client.close()
