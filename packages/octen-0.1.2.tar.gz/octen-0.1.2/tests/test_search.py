"""Test Search API"""

import pytest
from pydantic import ValidationError
from octen.models.search import (
    SearchRequest,
    SearchResponse,
    HighlightOptions,
    FullContentOptions,
)


def test_search_request_basic():
    """Test basic search request"""
    request = SearchRequest(query="test query")
    assert request.query == "test query"
    assert request.count == 5  # default value
    assert request.search_type == "auto"  # default value


def test_search_request_full():
    """Test complete search request"""
    request = SearchRequest(
        query="Python",
        count=10,
        search_type="semantic",
        include_domains=["github.com"],
        exclude_domains=["pinterest.com"],
        highlight=HighlightOptions(enable=True, max_tokens=300),
        full_content=FullContentOptions(enable=True, max_tokens=1000),
    )
    assert request.query == "Python"
    assert request.count == 10
    assert request.search_type == "semantic"
    assert request.include_domains == ["github.com"]


def test_search_request_validation():
    """Test request validation"""
    # Query string too long
    with pytest.raises(ValidationError):
        SearchRequest(query="x" * 501)

    # Result count out of range
    with pytest.raises(ValidationError):
        SearchRequest(query="test", count=0)

    with pytest.raises(ValidationError):
        SearchRequest(query="test", count=101)

    # Invalid search type
    with pytest.raises(ValidationError):
        SearchRequest(query="test", search_type="invalid")


def test_highlight_options():
    """Test highlight options"""
    options = HighlightOptions(enable=True, max_tokens=500)
    assert options.enable is True
    assert options.max_tokens == 500

    options_default = HighlightOptions()
    assert options_default.enable is True
    assert options_default.max_tokens == 300


def test_full_content_options():
    """Test full content options"""
    options = FullContentOptions(enable=True, max_tokens=2000)
    assert options.enable is True
    assert options.max_tokens == 2000

    options_default = FullContentOptions()
    assert options_default.enable is False
    assert options_default.max_tokens == 1000


def test_search_response():
    """Test search response"""
    response_data = {
        "code": 0,
        "msg": "success",
        "data": {
            "query": "test",
            "search_type": "auto",
            "results": [
                {
                    "title": "Test Result",
                    "url": "https://example.com",
                    "highlight": "Test highlight",
                }
            ],
        },
        "meta": {
            "usage": {"total_tokens": 100},
            "latency": {"total": 500},
        },
    }

    response = SearchResponse(**response_data)
    assert response.code == 0
    assert response.msg == "success"
    assert len(response.results) == 1
    assert response.results[0]["title"] == "Test Result"
    assert response.query == "test"
    assert response.search_type == "auto"
    assert response.usage["total_tokens"] == 100
    assert response.latency["total"] == 500
