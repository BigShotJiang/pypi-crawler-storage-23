"""SDK constant definitions"""

# Default configuration
DEFAULT_BASE_URL = "https://api.octen.ai"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 3

# Connection pool configuration
DEFAULT_MAX_CONNECTIONS = 100
DEFAULT_MAX_KEEPALIVE_CONNECTIONS = 20
DEFAULT_KEEPALIVE_EXPIRY = 30.0

# Retry configuration
RETRY_BASE_DELAY = 1.0
RETRY_MAX_DELAY = 60.0

# API endpoints
ENDPOINT_SEARCH = "/search"
ENDPOINT_EMBEDDING = "/embedding"

HEADER_API_KEY = "x-api-key"
HEADER_CONTENT_TYPE = "Content-Type"
HEADER_USER_AGENT = "User-Agent"

# User-Agent
USER_AGENT_TEMPLATE = "octen-python-sdk/{version}"

EMBEDDING_MODELS = {
    "0.6b": "octen-embedding-0.6b",
    "4b": "octen-embedding-4b",
    "8b": "octen-embedding-8b",
}

SEARCH_TYPES = {"auto", "keyword", "semantic"}

TIME_BASIS_OPTIONS = {"auto", "published", "crawled"}

FORMAT_OPTIONS = {"text", "markdown"}

SAFESEARCH_OPTIONS = {"off", "strict"}

INPUT_TYPES = {"query", "document"}
