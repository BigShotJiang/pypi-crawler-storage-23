"""Octen API asynchronous client"""

from typing import Optional
from .core.async_http_client import AsyncHTTPClient
from .resources.search import SearchResource
from .resources.embedding import EmbeddingResource
from .utils.constants import DEFAULT_BASE_URL, DEFAULT_TIMEOUT, DEFAULT_MAX_RETRIES


class AsyncSearchResource(SearchResource):
    """Async Search API resource

    Inherits from synchronous SearchResource but uses async HTTP client
    """

    async def search(self, *args, **kwargs):
        """Execute web search asynchronously

        Parameters same as synchronous version, but requires await
        """
        # Reuse parameter validation logic from parent class
        from octen.models.search import SearchRequest, SearchResponse
        from octen.utils.constants import ENDPOINT_SEARCH

        request = SearchRequest(
            query=kwargs.get("query"),
            count=kwargs.get("count"),
            search_type=kwargs.get("search_type"),
            include_domains=kwargs.get("include_domains"),
            exclude_domains=kwargs.get("exclude_domains"),
            include_text=kwargs.get("include_text"),
            exclude_text=kwargs.get("exclude_text"),
            time_basis=kwargs.get("time_basis"),
            start_time=kwargs.get("start_time"),
            end_time=kwargs.get("end_time"),
            highlight=kwargs.get("highlight"),
            format=kwargs.get("format"),
            safesearch=kwargs.get("safesearch"),
            full_content=kwargs.get("full_content"),
        )

        response_data = await self._client.request(
            method="POST",
            endpoint=ENDPOINT_SEARCH,
            json=request.model_dump(exclude_none=True),
            timeout=kwargs.get("timeout"),
        )

        return SearchResponse(**response_data)

    async def simple_search(self, query: str, count: int = 5, timeout: Optional[float] = None):
        """Async simplified search interface"""
        return await self.search(query=query, count=count, timeout=timeout)


class AsyncEmbeddingResource(EmbeddingResource):
    """Async Embedding API resource

    Inherits from synchronous EmbeddingResource but uses async HTTP client
    """

    async def create(self, *args, **kwargs):
        """Create text embeddings asynchronously

        Parameters same as synchronous version, but requires await
        """
        from octen.models.embedding import EmbeddingRequest, EmbeddingResponse
        from octen.utils.constants import ENDPOINT_EMBEDDING

        request = EmbeddingRequest(
            input=kwargs.get("input"),
            model=kwargs.get("model"),
            dimension=kwargs.get("dimension"),
            input_type=kwargs.get("input_type"),
            truncation=kwargs.get("truncation"),
        )

        response_data = await self._client.request(
            method="POST",
            endpoint=ENDPOINT_EMBEDDING,
            json=request.model_dump(exclude_none=True),
            timeout=kwargs.get("timeout"),
        )

        return EmbeddingResponse(**response_data)

    async def embed_query(self, text: str, model: Optional[str] = None,
                         dimension: Optional[int] = None, timeout: Optional[float] = None):
        """Embed query text asynchronously"""
        response = await self.create(
            input=text,
            model=model,
            dimension=dimension,
            input_type="query",
            timeout=timeout,
        )
        return response.get_first_embedding() or []

    async def embed_documents(self, texts, model: Optional[str] = None,
                             dimension: Optional[int] = None, timeout: Optional[float] = None):
        """Embed document text list asynchronously"""
        response = await self.create(
            input=texts,
            model=model,
            dimension=dimension,
            input_type="document",
            timeout=timeout,
        )
        return response.get_embeddings()


class AsyncOcten:
    """Octen API asynchronous client

    Provides async access to Octen API with search and embedding capabilities.

    Attributes:
        search: Async Search API resource
        embedding: Async Embedding API resource

    Example:
        Basic usage::

            import asyncio
            from octen import AsyncOcten

            async def main():
                # Using async context manager (recommended)
                async with AsyncOcten(api_key="your-api-key") as client:
                    # Async search
                    response = await client.search.search("Python", count=5)
                    for result in response.results:
                        print(result['title'])

                    # Async embedding
                    embedding = await client.embedding.create("Hello")
                    vector = embedding.get_first_embedding()

            asyncio.run(main())

        Concurrent requests::

            async def main():
                async with AsyncOcten(api_key="your-api-key") as client:
                    # Execute multiple requests concurrently
                    search_task = client.search.search("AI")
                    embedding_task = client.embedding.create("Hello")

                    results, embeddings = await asyncio.gather(
                        search_task,
                        embedding_task
                    )

            asyncio.run(main())
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        http2: bool = True,
    ):
        """Initialize async Octen client

        Args:
            api_key: Octen API key (required)
            base_url: API base URL (default: https://api.octen.ai)
            timeout: Default request timeout in seconds (default: 30.0)
            max_retries: Maximum number of retries (default: 3)
            http2: Whether to enable HTTP/2 (default: True)

        Raises:
            ValueError: if api_key is empty
        """
        if not api_key:
            raise ValueError("api_key cannot be empty")

        # Create async HTTP client
        self._http_client = AsyncHTTPClient(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            max_retries=max_retries,
            http2=http2,
        )

        # Initialize async resources
        self.search = AsyncSearchResource(self._http_client)
        self.embedding = AsyncEmbeddingResource(self._http_client)

    async def close(self):
        """Close client and release connection pool resources

        Should be called manually when not using async context manager.
        """
        await self._http_client.close()

    async def __aenter__(self):
        """Support async context manager protocol"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Automatically close client when exiting async context manager"""
        await self.close()
        return False

    def __repr__(self) -> str:
        """Return string representation of client"""
        return f"AsyncOcten(base_url={self._http_client.base_url!r})"
