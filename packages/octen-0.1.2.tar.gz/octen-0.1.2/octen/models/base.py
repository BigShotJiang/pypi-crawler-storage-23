"""Pydantic base model"""

from typing import Any, Dict
from pydantic import BaseModel, ConfigDict


class OctenBaseModel(BaseModel):
    """Base class for all Octen data models

    Configuration:
        - Allow extra fields (API may return unknown fields)
        - Use alias generator to support camelCase naming
        - Freeze model to ensure immutability
    """

    model_config = ConfigDict(
        extra="allow",  # Allow extra fields
        populate_by_name=True,  # Support field aliases
        validate_assignment=True,  # Validate on assignment
    )

    def to_dict(self, exclude_none: bool = True) -> Dict[str, Any]:
        """Convert to dictionary

        Args:
            exclude_none: Whether to exclude None values

        Returns:
            Dictionary representation
        """
        return self.model_dump(exclude_none=exclude_none, by_alias=True)
