"""Octen Python SDK

A Python SDK for accessing the Octen API, providing search and embedding capabilities.

Basic usage::

    from octen import Octen

    with Octen(api_key="your-api-key") as client:
        # Search
        response = client.search.search("Python", count=5)
        for result in response.results:
            print(result['title'])

        # Embedding
        embedding = client.embedding.create("Hello")
        vector = embedding.get_first_embedding()
"""

from .version import __version__, __author__, __license__
from .client import Octen

# Core exceptions
from .core.exceptions import (
    OctenError,
    OctenAPIError,
    OctenTimeoutError,
    OctenConnectionError,
    OctenValidationError,
    OctenRateLimitError,
    OctenAuthenticationError,
)

# Data models
from .models.search import (
    HighlightOptions,
    FullContentOptions,
    SearchRequest,
    SearchResponse,
)
from .models.embedding import (
    EmbeddingRequest,
    EmbeddingResponse,
)

# Try to import async client (if implemented)
try:
    from .async_client import AsyncOcten

    __all__ = [
        # Version info
        "__version__",
        "__author__",
        "__license__",
        # Clients
        "Octen",
        "AsyncOcten",
        # Exceptions
        "OctenError",
        "OctenAPIError",
        "OctenTimeoutError",
        "OctenConnectionError",
        "OctenValidationError",
        "OctenRateLimitError",
        "OctenAuthenticationError",
        # Data models
        "HighlightOptions",
        "FullContentOptions",
        "SearchRequest",
        "SearchResponse",
        "EmbeddingRequest",
        "EmbeddingResponse",
    ]
except ImportError:
    __all__ = [
        # Version info
        "__version__",
        "__author__",
        "__license__",
        # Clients
        "Octen",
        # Exceptions
        "OctenError",
        "OctenAPIError",
        "OctenTimeoutError",
        "OctenConnectionError",
        "OctenValidationError",
        "OctenRateLimitError",
        "OctenAuthenticationError",
        # Data models
        "HighlightOptions",
        "FullContentOptions",
        "SearchRequest",
        "SearchResponse",
        "EmbeddingRequest",
        "EmbeddingResponse",
    ]
