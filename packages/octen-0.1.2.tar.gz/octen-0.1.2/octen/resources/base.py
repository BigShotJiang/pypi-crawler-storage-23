"""Resource base class"""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..core.http_client import HTTPClient


class Resource:
    """Base class for all resource classes

    Encapsulates API endpoints and provides business logic layer interface

    Attributes:
        _client: HTTP client instance
    """

    def __init__(self, client: "HTTPClient"):
        """Initialize resource

        Args:
            client: HTTP client instance
        """
        self._client = client
