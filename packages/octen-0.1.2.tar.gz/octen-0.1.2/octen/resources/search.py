"""Search API resource wrapper"""

from typing import Optional, List
from .base import Resource
from ..models.search import (
    SearchRequest,
    SearchResponse,
    HighlightOptions,
    FullContentOptions,
)
from ..utils.constants import ENDPOINT_SEARCH


class SearchResource(Resource):
    """Search API resource

    Provides web search capabilities
    """

    def search(
        self,
        query: str,
        count: Optional[int] = None,
        search_type: Optional[str] = None,
        include_domains: Optional[List[str]] = None,
        exclude_domains: Optional[List[str]] = None,
        include_text: Optional[List[str]] = None,
        exclude_text: Optional[List[str]] = None,
        time_basis: Optional[str] = None,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        highlight: Optional[HighlightOptions] = None,
        format: Optional[str] = None,
        safesearch: Optional[str] = None,
        full_content: Optional[FullContentOptions] = None,
        timeout: Optional[float] = None,
    ) -> SearchResponse:
        """Execute web search

        Args:
            query: Search query string (required, max 500 characters)
            count: Number of results (1-100, default 5)
            search_type: Search type (auto/keyword/semantic, default auto)
            include_domains: List of included domains
            exclude_domains: List of excluded domains
            include_text: List of text that must be included
            exclude_text: List of text that must be excluded
            time_basis: Time basis (auto/published/crawled, default auto)
            start_time: Start time (ISO 8601 format)
            end_time: End time (ISO 8601 format)
            highlight: Highlight options configuration
            format: Content format (text/markdown, default text)
            safesearch: Safesearch level (off/strict, default strict)
            full_content: Full content options configuration
            timeout: Request timeout (seconds), overrides default

        Returns:
            SearchResponse: Search response object

        Raises:
            OctenValidationError: ParametersvalidateFailed
            OctenAPIError: API request failed
            OctenTimeoutError: Request timeout

        Example:
            >>> from octen import Octen
            >>> client = Octen(api_key="your-api-key")
            >>> response = client.search.search(
            ...     query="Python programming",
            ...     count=10,
            ...     search_type="semantic"
            ... )
            >>> for result in response.results:
            ...     print(result['title'], result['url'])
        """
        request = SearchRequest(
            query=query,
            count=count,
            search_type=search_type,
            include_domains=include_domains,
            exclude_domains=exclude_domains,
            include_text=include_text,
            exclude_text=exclude_text,
            time_basis=time_basis,
            start_time=start_time,
            end_time=end_time,
            highlight=highlight,
            format=format,
            safesearch=safesearch,
            full_content=full_content,
        )

        response_data = self._client.request(
            method="POST",
            endpoint=ENDPOINT_SEARCH,
            json=request.model_dump(exclude_none=True),
            timeout=timeout,
        )

        return SearchResponse(**response_data)

    def simple_search(
        self,
        query: str,
        count: int = 5,
        timeout: Optional[float] = None,
    ) -> SearchResponse:
        """Simplified search interface

        Execute quick search with default parameters

        Args:
            query: Search queryString
            count: Number of results (default 5)
            timeout: Request timeout (seconds)

        Returns:
            SearchResponse: Search response object

        Example:
            >>> response = client.search.simple_search("Python", count=5)
        """
        return self.search(query=query, count=count, timeout=timeout)
