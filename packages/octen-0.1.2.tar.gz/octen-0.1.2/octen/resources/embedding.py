"""Embedding API resource wrapper"""

from typing import Union, List, Optional
from .base import Resource
from ..models.embedding import EmbeddingRequest, EmbeddingResponse
from ..utils.constants import ENDPOINT_EMBEDDING


class EmbeddingResource(Resource):
    """Embedding API resource

    Provides text embedding capabilities
    """

    def create(
        self,
        input: Union[str, List[str]],
        model: Optional[str] = None,
        dimension: Optional[int] = None,
        input_type: Optional[str] = None,
        truncation: Optional[bool] = None,
        timeout: Optional[float] = None,
    ) -> EmbeddingResponse:
        """Create text embedding vectors

        Args:
            input: Input text (string or list of strings)
            model: Model name (octen-embedding-0.6b/4b/8b)
            dimension: Vector dimension
            input_type: Input type（query/document）
            truncation: Whether to truncate overly long input (default True)
            timeout: Request timeout (seconds), overrides default

        Returns:
            EmbeddingResponse: Embedding responseObject

        Raises:
            OctenValidationError: ParametersvalidateFailed
            OctenAPIError: API request failed
            OctenTimeoutError: Request timeout

        Example:
            >>> from octen import Octen
            >>> client = Octen(api_key="your-api-key")
            >>>
            >>> # Single text
            >>> response = client.embedding.create(
            ...     input="Hello, world!",
            ...     model="octen-embedding-4b"
            ... )
            >>> vector = response.get_first_embedding()
            >>> print(f"Dimension: {len(vector)}")
            >>>
            >>> # Batch texts
            >>> response = client.embedding.create(
            ...     input=["text 1", "text 2", "text 3"],
            ...     model="octen-embedding-8b"
            ... )
            >>> vectors = response.get_embeddings()
            >>> print(f"Generated {len(vectors)} vectors")
        """
        request = EmbeddingRequest(
            input=input,
            model=model,
            dimension=dimension,
            input_type=input_type,
            truncation=truncation,
        )

        response_data = self._client.request(
            method="POST",
            endpoint=ENDPOINT_EMBEDDING,
            json=request.model_dump(exclude_none=True),
            timeout=timeout,
        )

        return EmbeddingResponse(**response_data)

    def embed_query(
        self,
        text: str,
        model: Optional[str] = None,
        dimension: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> List[float]:
        """Embed query text (convenience method)

        Args:
            text: QueryText
            model: Model name
            dimension: Vector dimension
            timeout: Request timeout (seconds)

        Returns:
            VectorList

        Example:
            >>> vector = client.embedding.embed_query("search query")
        """
        response = self.create(
            input=[text],  # Fix: wrap as list
            model=model,
            dimension=dimension,
            input_type="query",
            timeout=timeout,
        )
        return response.get_first_embedding() or []

    def embed_documents(
        self,
        texts: List[str],
        model: Optional[str] = None,
        dimension: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> List[List[float]]:
        """Embed document text list (convenience method)

        Args:
            texts: DocumentTextList
            model: Model name
            dimension: Vector dimension
            timeout: Request timeout (seconds)

        Returns:
            List of vector lists

        Example:
            >>> vectors = client.embedding.embed_documents(
            ...     ["doc 1", "doc 2", "doc 3"]
            ... )
        """
        response = self.create(
            input=texts,
            model=model,
            dimension=dimension,
            input_type="document",
            timeout=timeout,
        )
        return response.get_embeddings()
