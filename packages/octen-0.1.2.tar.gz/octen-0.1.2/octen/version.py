"""Octen SDK version information"""

__version__ = "0.1.2"
__author__ = "Octen Team"
__license__ = "MIT"
