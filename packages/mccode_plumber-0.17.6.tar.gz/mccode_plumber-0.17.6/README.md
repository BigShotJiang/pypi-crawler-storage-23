# McCode Plumber
Setup, run, and teardown the infrastructure for splitrun McCode scans sending data through Kafka into NeXus
