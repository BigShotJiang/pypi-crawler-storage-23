len(1, 2)
# Raise=TypeError('len() takes exactly one argument (2 given)')
