d = {'a': 1, 'b': 2}
d.items()
# Return=dict_items([('a', 1), ('b', 2)])
