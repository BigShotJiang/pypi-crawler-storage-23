0**-1
# Raise=ZeroDivisionError('zero to a negative power')
