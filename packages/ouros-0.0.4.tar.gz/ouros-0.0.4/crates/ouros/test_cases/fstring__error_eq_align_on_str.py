# '=' alignment on string raises ValueError
f'{"hello":=10}'
# Raise=ValueError("'=' alignment not allowed in string format specifier")
