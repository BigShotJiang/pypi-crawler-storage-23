# xfail=cpython
id((1, 2)) == id((1, 2))
# Return=False
