def f():
    return 1


f(42)
# Raise=TypeError('f() takes 0 positional arguments but 1 was given')
