# raise exception type called via variable
a = ValueError
raise a('error message')
# Raise=ValueError('error message')
