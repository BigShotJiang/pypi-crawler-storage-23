x = {}
x.keys(1)
# Raise=TypeError('dict.keys() takes no arguments (1 given)')
