assert 1 == 2
# Raise=AssertionError()
