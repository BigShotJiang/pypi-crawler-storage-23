len()
# Raise=TypeError('len() takes exactly one argument (0 given)')
