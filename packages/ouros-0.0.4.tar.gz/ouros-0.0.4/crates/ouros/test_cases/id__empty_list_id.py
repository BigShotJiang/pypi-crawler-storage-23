# xfail=cpython
id([]) == id([])
# Return=False
