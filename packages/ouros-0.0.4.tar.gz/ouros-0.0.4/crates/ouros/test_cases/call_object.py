x = len
x('abc')
# Return=3
