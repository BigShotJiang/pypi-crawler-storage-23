1 // 0
# Raise=ZeroDivisionError('division by zero')
