isinstance(1, [int, str])
# Raise=TypeError('isinstance() arg 2 must be a type, a tuple of types, or a union')
