x = []
x.insert(1)
# Raise=TypeError('insert expected 2 arguments, got 1')
