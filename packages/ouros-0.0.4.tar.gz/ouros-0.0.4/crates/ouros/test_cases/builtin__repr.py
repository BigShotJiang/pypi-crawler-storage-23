# === repr of built-in functions ===
assert repr(len) == '<built-in function len>', 'repr(len)'
assert repr(print) == '<built-in function print>', 'repr(print)'
assert repr(type) == "<class 'type'>", 'repr(type)'
