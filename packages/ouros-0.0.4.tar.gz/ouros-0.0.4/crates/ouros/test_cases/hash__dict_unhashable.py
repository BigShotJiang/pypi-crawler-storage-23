hash({})
# Raise=TypeError("unhashable type: 'dict'")
