{}.popitem()
"""
TRACEBACK:
Traceback (most recent call last):
  File "dict__popitem_empty.py", line 1, in <module>
    {}.popitem()
    ~~~~~~~~~~~~
KeyError: 'popitem(): dictionary is empty'
"""
