d = {'a': 1, 'b': 2}
d.values()
# Return=dict_values([1, 2])
