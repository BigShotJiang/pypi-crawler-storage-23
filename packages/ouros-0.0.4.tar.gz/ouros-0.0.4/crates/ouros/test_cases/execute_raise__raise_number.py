raise 1 + 2
# Raise=TypeError('exceptions must derive from BaseException')
