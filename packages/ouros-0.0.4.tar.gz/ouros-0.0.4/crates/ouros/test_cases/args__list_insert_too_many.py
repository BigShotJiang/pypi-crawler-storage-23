x = []
x.insert(1, 2, 3)
# Raise=TypeError('insert expected 2 arguments, got 3')
