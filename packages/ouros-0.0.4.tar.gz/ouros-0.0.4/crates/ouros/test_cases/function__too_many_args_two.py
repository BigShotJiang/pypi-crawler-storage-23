def f(a, b):
    return a + b


f(1, 2, 3)
# Raise=TypeError('f() takes 2 positional arguments but 3 were given')
