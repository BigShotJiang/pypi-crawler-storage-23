x = {}
x.items(1)
# Raise=TypeError('dict.items() takes no arguments (1 given)')
