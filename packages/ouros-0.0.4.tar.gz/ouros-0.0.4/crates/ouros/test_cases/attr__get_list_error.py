x = [1, 2, 3]
x.foo
"""
TRACEBACK:
Traceback (most recent call last):
  File "attr__get_list_error.py", line 2, in <module>
    x.foo
AttributeError: 'list' object has no attribute 'foo'
"""
