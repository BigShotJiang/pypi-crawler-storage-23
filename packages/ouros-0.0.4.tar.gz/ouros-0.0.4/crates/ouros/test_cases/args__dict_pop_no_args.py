x = {}
x.pop()
# Raise=TypeError('pop expected at least 1 argument, got 0')
