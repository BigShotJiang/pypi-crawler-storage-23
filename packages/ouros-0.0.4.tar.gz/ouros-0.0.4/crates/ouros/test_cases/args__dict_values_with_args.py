x = {}
x.values(1)
# Raise=TypeError('dict.values() takes no arguments (1 given)')
