len + 1
# Raise=TypeError("unsupported operand type(s) for +: 'builtin_function_or_method' and 'int'")
