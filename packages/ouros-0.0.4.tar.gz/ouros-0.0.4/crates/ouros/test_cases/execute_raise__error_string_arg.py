raise TypeError('hello')
# Raise=TypeError('hello')
