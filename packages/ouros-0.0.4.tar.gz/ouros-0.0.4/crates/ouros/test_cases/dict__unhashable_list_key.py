{[1, 2]: 'value'}
# Raise=TypeError("cannot use 'list' as a dict key (unhashable type: 'list')")
