import nonexistent_module

"""
TRACEBACK:
Traceback (most recent call last):
  File "import__error_module_not_found.py", line 1, in <module>
    import nonexistent_module
ModuleNotFoundError: No module named 'nonexistent_module'
"""
