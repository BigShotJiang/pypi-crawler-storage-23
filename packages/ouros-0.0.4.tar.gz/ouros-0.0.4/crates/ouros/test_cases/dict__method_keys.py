d = {'a': 1, 'b': 2}
d.keys()
# Return=dict_keys(['a', 'b'])
