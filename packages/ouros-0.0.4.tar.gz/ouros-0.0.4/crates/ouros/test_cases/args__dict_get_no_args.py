x = {}
x.get()
# Raise=TypeError('get expected at least 1 argument, got 0')
