def f(x):
    return x


f(1, 2)
# Raise=TypeError('f() takes 1 positional argument but 2 were given')
