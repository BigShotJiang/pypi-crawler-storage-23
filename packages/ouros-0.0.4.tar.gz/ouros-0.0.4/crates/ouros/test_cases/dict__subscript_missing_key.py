d = {'a': 1}
d['missing']
# Raise=KeyError('missing')
