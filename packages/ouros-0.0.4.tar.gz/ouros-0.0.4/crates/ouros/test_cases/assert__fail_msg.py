assert False, 'custom message'
# Raise=AssertionError('custom message')
