x = {}
x.get(1, 2, 3)
# Raise=TypeError('get expected at most 2 arguments, got 3')
