# call-external
# External calls in subscript operations

# External call as subscript index
items = [10, 20, 30]
result = items[add_ints(0, 1)]
assert result == 20, 'ext call as subscript index'
