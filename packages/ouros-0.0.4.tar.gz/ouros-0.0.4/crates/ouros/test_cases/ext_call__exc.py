# call-external
# External call in raise statement
raise ValueError(return_value('foobar'))
# Raise=ValueError('foobar')
