hash([1, 2, 3])
# Raise=TypeError("unhashable type: 'list'")
