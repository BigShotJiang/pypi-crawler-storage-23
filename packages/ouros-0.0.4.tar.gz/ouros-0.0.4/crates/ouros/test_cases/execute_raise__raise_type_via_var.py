# raise exception type stored in a variable
a = ValueError
raise a
# Raise=ValueError()
