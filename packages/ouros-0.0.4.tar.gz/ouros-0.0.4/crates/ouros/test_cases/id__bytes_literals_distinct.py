# xfail=cpython
id(b'test') == id(b'test')
# Return=False
