x = 5
x.foo
"""
TRACEBACK:
Traceback (most recent call last):
  File "attr__get_int_error.py", line 2, in <module>
    x.foo
AttributeError: 'int' object has no attribute 'foo'
"""
