# raise exception instance stored in a variable
a = ValueError('instance error')
raise a
# Raise=ValueError('instance error')
