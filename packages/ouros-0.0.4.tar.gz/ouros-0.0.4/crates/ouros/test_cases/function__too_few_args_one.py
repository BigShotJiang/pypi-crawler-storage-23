def f(x):
    return x


f()
# Raise=TypeError("f() missing 1 required positional argument: 'x'")
