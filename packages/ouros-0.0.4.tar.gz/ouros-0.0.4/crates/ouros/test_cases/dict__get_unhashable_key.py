d = {}
d.get([], 'fallback')
# Raise=TypeError("cannot use 'list' as a dict key (unhashable type: 'list')")
