# value-based identity: same value = same identity
1 is 1
# Return=True
