from sys import nonexistent

"""
TRACEBACK:
Traceback (most recent call last):
  File "import__error_cannot_import.py", line 1, in <module>
    from sys import nonexistent
ImportError: cannot import name 'nonexistent' from 'sys' (unknown location)
"""
