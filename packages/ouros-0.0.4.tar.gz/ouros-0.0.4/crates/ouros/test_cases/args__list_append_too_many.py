x = []
x.append(1, 2)
# Raise=TypeError('list.append() takes exactly one argument (2 given)')
