import functools

# === reduce with lambda ===
result = functools.reduce(lambda a, b: a + b, [1, 2, 3, 4])
assert result == 10, 'reduce sum'

result = functools.reduce(lambda a, b: a * b, [1, 2, 3, 4])
assert result == 24, 'reduce product'

# === reduce with initial ===
result = functools.reduce(lambda a, b: a + b, [1, 2, 3], 10)
assert result == 16, 'reduce with initial'

# === reduce single element ===
result = functools.reduce(lambda a, b: a + b, [42])
assert result == 42, 'reduce single'

# === from import ===
from functools import reduce

assert reduce(lambda a, b: a + b, [1, 2]) == 3, 'from import reduce'
