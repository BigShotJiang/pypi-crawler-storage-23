x = {}
x.pop(1, 2, 3)
# Raise=TypeError('pop expected at most 2 arguments, got 3')
