# raise exception type directly
raise ValueError
# Raise=ValueError()
