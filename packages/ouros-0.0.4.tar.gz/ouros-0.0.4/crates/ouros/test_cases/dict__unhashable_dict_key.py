{{'a': 1}: 'value'}
# Raise=TypeError("cannot use 'dict' as a dict key (unhashable type: 'dict')")
