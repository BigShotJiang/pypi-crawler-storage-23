pow(0, -1)
"""
TRACEBACK:
Traceback (most recent call last):
  File "arith__pow_zero_neg_builtin.py", line 1, in <module>
    pow(0, -1)
    ~~~~~~~~~~
ZeroDivisionError: zero to a negative power
"""
