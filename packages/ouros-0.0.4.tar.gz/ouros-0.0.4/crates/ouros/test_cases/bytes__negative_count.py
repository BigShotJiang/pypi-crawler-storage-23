bytes(-1)
"""
TRACEBACK:
Traceback (most recent call last):
  File "bytes__negative_count.py", line 1, in <module>
    bytes(-1)
    ~~~~~~~~~
ValueError: negative count
"""
