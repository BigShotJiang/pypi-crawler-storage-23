# value-based identity: same value = same id
x = 100
y = x
id(x) == id(y)
# Return=True
