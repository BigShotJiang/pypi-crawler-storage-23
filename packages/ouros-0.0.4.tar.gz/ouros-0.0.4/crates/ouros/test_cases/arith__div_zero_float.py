1.0 / 0.0
# Raise=ZeroDivisionError('division by zero')
