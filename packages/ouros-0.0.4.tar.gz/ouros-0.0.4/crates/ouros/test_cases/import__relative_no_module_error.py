from . import foo

"""
TRACEBACK:
Traceback (most recent call last):
  File "import__relative_no_module_error.py", line 1, in <module>
    from . import foo
ImportError: attempted relative import with no known parent package
"""
