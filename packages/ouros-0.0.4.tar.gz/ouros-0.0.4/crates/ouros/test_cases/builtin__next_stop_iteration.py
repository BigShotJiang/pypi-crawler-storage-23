it = iter([])
next(it)
"""
TRACEBACK:
Traceback (most recent call last):
  File "builtin__next_stop_iteration.py", line 2, in <module>
    next(it)
    ~~~~~~~~
StopIteration
"""
