id(1, 2)
# Raise=TypeError('id() takes exactly one argument (2 given)')
