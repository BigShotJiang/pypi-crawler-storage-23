if True:
    raise ValueError('in if body')
"""
TRACEBACK:
Traceback (most recent call last):
  File "if__raise_if.py", line 2, in <module>
    raise ValueError('in if body')
ValueError: in if body
"""
