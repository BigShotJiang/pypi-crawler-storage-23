def f(a, b, c):
    return a + b + c


f()
# Raise=TypeError("f() missing 3 required positional arguments: 'a', 'b', and 'c'")
