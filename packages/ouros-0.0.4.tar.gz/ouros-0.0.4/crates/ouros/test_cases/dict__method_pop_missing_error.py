d = {'a': 1}
d.pop('missing')
# Raise=KeyError('missing')
