b = b'hello'
b[10]
"""
TRACEBACK:
Traceback (most recent call last):
  File "bytes__getitem_index_error.py", line 2, in <module>
    b[10]
    ~~~~~
IndexError: index out of range
"""
