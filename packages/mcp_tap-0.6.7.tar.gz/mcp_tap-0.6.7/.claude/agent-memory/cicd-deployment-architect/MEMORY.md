# CI/CD Deployment Architect Memory — mcp-tap

## Project: mcp-tap (Python MCP server, PyPI package)
- Build: hatchling
- Package: `mcp-tap` on PyPI
- Run: `uvx mcp-tap` or `python -m mcp_tap`
- No CI/CD pipeline yet. Fresh project.
