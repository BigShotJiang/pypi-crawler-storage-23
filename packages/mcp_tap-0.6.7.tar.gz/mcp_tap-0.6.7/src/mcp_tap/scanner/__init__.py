"""Project scanner — detect technologies and recommend MCP servers."""
