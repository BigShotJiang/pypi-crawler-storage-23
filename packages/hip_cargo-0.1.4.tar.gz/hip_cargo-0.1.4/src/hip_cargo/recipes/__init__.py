"""
Curated recipes for hip-cargo
"""
