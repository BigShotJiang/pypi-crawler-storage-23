"""Template files for hip-cargo init command."""

from pathlib import Path

TEMPLATES_DIR = Path(__file__).parent
