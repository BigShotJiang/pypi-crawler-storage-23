"""Core business logic for hip-cargo."""
