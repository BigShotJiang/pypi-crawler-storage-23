import sys
import click
import pysam
import json
import re

@click.command()
@click.option('--input', '-i', 'input_path', default="-", type=click.Path(allow_dash=True), help="Input file path. Use '-' for stdin.")
@click.option('--output', '-o', 'output_path', default="-", type=click.Path(allow_dash=True), help="Output file path. Use '-' for stdout.")
@click.option('--output-format', '-O', type=click.Choice(['SAM', 'BAM', 'CRAM'], case_sensitive=False), help="Explicit output format. Overrides file extension inference.")
@click.option('--uncompressed', '-u', is_flag=True, help="Output uncompressed BAM/CRAM. If outputting to stdout without explicit format, defaults to uncompressed BAM.")
@click.option('--locals-out', '-l', type=click.Path(writable=True), help="Output path for exported locals (JSON Lines format).")
@click.option('--export-key', '-k', multiple=True, help="Specific keys to extract from locals. Can be specified multiple times.")
@click.option('--threads-in', type=int, default=3, help="Number of decompression threads for reading.")
@click.option('--threads-out', type=int, default=8, help="Number of compression threads for writing.")
@click.option('--add-pg/--no-add-pg', default=True, help="Append execution command to SAM header PG tags.")
@click.argument('cmds', nargs=-1, required=True)
def run(input_path, output_path, output_format, uncompressed, locals_out, export_key, threads_in, threads_out, add_pg, cmds):
    """
    Executes sequential Python statements on SAM/BAM stream alignments.

    Alignments are exposed in the execution namespace as `seg` (pysam.AlignedSegment).
    The `re` module is exposed globally for regex operations.
    The namespace persists across the stream. Variables defined in `cmds` remain 
    accessible in subsequent iterations unless explicitly overwritten.

    Data export is strictly JSON Lines (JSONL). Target variables must be explicitly 
    declared via `-k` to be serialized.

    \b
    EXAMPLES:

    1. Inject a composite barcode tag (XZ) from existing CB and UB tags:
       python stream.py -i in.bam -O BAM -o out.bam \\
       "cb = seg.get_tag('CB') if seg.has_tag('CB') else ''" \\
       "ub = seg.get_tag('UB') if seg.has_tag('UB') else ''" \\
       "seg.set_tag('XZ', f'{cb}-{ub}') if cb and ub else None"

    2. Extract mapping quality and read name to a JSONL sidecar:
       python stream.py -i in.bam -l metrics.jsonl -k mq -k name \\
       "mq = seg.mapping_quality" \\
       "name = seg.query_name"

    3. Override a SAM flag conditionally using a one-line ternary:
       python stream.py -i in.bam -u -o - \\
       "seg.is_duplicate = True if seg.mapping_quality < 5 else seg.is_duplicate"
       
    4. Use regex to extract numeric parts of a read name:
       python stream.py -i in.bam -o out.bam \\
       "match = re.search(r'\d+', seg.query_name)" \\
       "seg.set_tag('XN', int(match.group())) if match else None"
    """
    in_mode = "r" if input_path == "-" or input_path.endswith(".sam") else "rb"
    
    if output_format:
        fmt = output_format.upper()
        if fmt == 'SAM':
            out_mode = "w"
        elif fmt == 'BAM':
            out_mode = "wb"
        elif fmt == 'CRAM':
            out_mode = "wc"
    else:
        out_mode = "w" if output_path == "-" or output_path.endswith(".sam") else "wb"

    if uncompressed:
        if out_mode == "w" and output_format != "SAM" and not output_path.endswith(".sam"):
            out_mode = "wbu"
        elif "b" in out_mode or "c" in out_mode:
            out_mode += "u"

    sam_input = pysam.AlignmentFile(input_path, mode=in_mode, threads=threads_in)
    
    if add_pg:
        header_dict = sam_input.header.to_dict()
        if 'PG' not in header_dict:
            header_dict['PG'] = []
            
        cl = " ".join(sys.argv)
        pg_id = "edit-sam"
        existing_ids = {pg.get('ID') for pg in header_dict.get('PG', [])}
        
        counter = 1
        while pg_id in existing_ids:
            pg_id = f"edit-sam.{counter}"
            counter += 1
            
        header_dict['PG'].append({
            'ID': pg_id,
            'PN': 'edit-sam',
            'CL': cl
        })
        out_header = pysam.AlignmentHeader.from_dict(header_dict)
        sam_output = pysam.AlignmentFile(output_path, mode=out_mode, header=out_header, threads=threads_out)
    else:
        sam_output = pysam.AlignmentFile(output_path, mode=out_mode, template=sam_input, threads=threads_out)
    
    json_fd = open(locals_out, 'w') if locals_out else None
    
    global_vars = {"re": re}
    local_vars = {}

    try:
        for seg in sam_input:
            local_vars["seg"] = seg
            
            for cmd in cmds:
                try:
                    exec(cmd, global_vars, local_vars)
                except Exception as e:
                    raise ValueError(f"{e}\nOn edit-sam command:\n{cmd}\nWith edit-sam local_vars:\n{local_vars}") from e
            
            sam_output.write(seg)
            
        if json_fd and export_key:
            export_data = {key: local_vars.get(key) for key in export_key}
            json_fd.write(json.dumps(export_data) + '\n')
    finally:
        sam_input.close()
        sam_output.close()
        if json_fd:
            json_fd.close()

if __name__ == '__main__':
    run()