"""
Quantlab - Quantitative analysis tools for the Laakhay ecosystem
"""

__author__ = "Laakhay Corporation"
__version__ = "0.1.0"
