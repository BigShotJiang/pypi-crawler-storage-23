"""CLI module for Schema Travels."""

from schema_travels.cli.main import cli

__all__ = ["cli"]
