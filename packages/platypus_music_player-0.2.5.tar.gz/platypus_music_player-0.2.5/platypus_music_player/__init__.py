from .main import *

if __name__ == "__main__":
    # Just call main(). It should return the App object, 
    # then we immediately start the loop.
    main().main_loop()