import toga
from toga.style import Pack
from toga.style.pack import COLUMN

async def select_file(widget):
    # Toga handles the thread switch for file dialogs automatically 
    # as long as we use 'await'
    selected_file = await widget.window.open_file_dialog(
        title="Select your .platypus file",
        file_types=["platypus"]
    )
    
    if selected_file is not None:
        # Access the label via the app object to ensure thread safety
        widget.app.path_label.text = f"Path: {selected_file}"

def build(app):
    # 1. We create the box first
    main_box = toga.Box(style=Pack(direction=COLUMN, margin=10))
    
    # 2. Attach the label to the 'app' so it's globally accessible but locally created
    app.path_label = toga.Label("No file selected", style=Pack(margin=(0, 5)))
    
    select_button = toga.Button(
        "Select Platypus File",
        on_press=select_file,
        style=Pack(margin=5)
    )
    
    # 3. Add them to the box
    main_box.add(select_button)
    main_box.add(app.path_label)
    
    return main_box

def main():
    # We return the App object without calling main_loop() inside here
    return toga.App("Platypus Player", "org.platypus.music", startup=build)

if __name__ == "__main__":
    # This is the standard way to launch on Windows
    app = main()
    app.main_loop()