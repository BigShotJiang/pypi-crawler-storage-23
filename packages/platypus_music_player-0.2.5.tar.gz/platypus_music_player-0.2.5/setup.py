from setuptools import setup, find_packages

setup(
    name="platypus_music_player",
    version="0.2.5",
    author="Bean The Platypus",
    description="its a music player in python",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/beantheplatypus/Platypus-Music-Player/",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
        'toga',
    ],
)