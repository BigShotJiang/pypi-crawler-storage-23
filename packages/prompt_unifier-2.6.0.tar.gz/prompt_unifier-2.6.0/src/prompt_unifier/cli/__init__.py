"""CLI command implementations using Typer framework."""
