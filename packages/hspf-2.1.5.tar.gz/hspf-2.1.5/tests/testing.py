
#%%

from hspf import reports
from pathlib import Path
from hspf.hspfModel import hspfModel


#%%

model = hspfModel('C:/Users/mfratki/Documents/Calibrations/BigFork/model/BigFork_0.uci')
uci = model.uci
hbn = model.hbns
# %%
'''
Filters: date range, operations, 
Temporal aggregation: monthly, yearly, simulation period
Spatial aggregation: by reach, by watershed, by landcover type




1. annual loading for entire watershed

2. monthly loading for entire watershed

'''

# Overal loading from perlands and implands to reaches
reports.loading.loading_summary(uci = uci,
                                hbn = hbn,
                                constituent = 'TSS',
                                start_year = 2018,
                                end_year = 2025,
                                reach_ids = None,
                                upstream_reach_ids = None,
                                drainage_area = None,
                                by_landcover = True,
                                simulation_period = 'yearly',
                                aggregation_period = 'yearly',
                                spatial_grouping = 'watershed')
#%% Scour report

reports.sediment.scour_report(uci,hbn,start_year = 2018, end_year = 2025)

reports.annual_sediment_budget(uci,hbn)

#hydrolgy reports

reports.hydrology.annual_implnd_water_budget(uci,hbn)

reports.hydrology.annual_perlnd_water_budget(uci,hbn)

#%%contributions

reports.contributions.catchment_contributions(uci,hbn,'TSS',target_reach_id = 550)
# %%
reports.total_contributions('TSS',uci,hbn,550)