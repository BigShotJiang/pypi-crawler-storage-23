import os
import torch
import numpy as np
from torch.utils.data import Dataset
from PIL import Image
import torchvision.transforms.functional as TF
import random
class DepthDataset(Dataset):
    def __init__(self, img_dir, depth_dir, transform=None):
        self.img_dir = img_dir
        self.depth_dir = depth_dir
        self.transform = transform
        self.images = sorted([f for f in os.listdir(img_dir) if not f.startswith('.')])
        self.depths = sorted([f for f in os.listdir(depth_dir) if not f.startswith('.')])
        assert len(self.images) == len(self.depths), "images == depths ( sổ ảnh phải bằng depths)"

    def __len__(self):
        return len(self.images)

    def __getitem__(self, index):
        img_path = os.path.join(self.img_dir, self.images[index])
        depth_path = os.path.join(self.depth_dir, self.depths[index])
        image = Image.open(img_path).convert('RGB')
        depth = Image.open(depth_path) 
        if self.transform:
            image = TF.resize(image, (256, 256))
            depth = TF.resize(depth, (256, 256), interpolation=TF.InterpolationMode.NEAREST)
            if random.random() > 0.5:
                image = TF.hflip(image)
                depth = TF.hflip(depth)
            image = TF.to_tensor(image)
        depth = np.array(depth).astype(np.float32)
        depth = torch.from_numpy(depth).unsqueeze(0)

        return image, depth