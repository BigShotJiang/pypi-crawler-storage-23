from .base_model import BaseModel
import numpy as np

class logistic(BaseModel):
    def __init__(self,lr=0.01,epochs=1000,out_loss=False,out_gradient=False,out_update=False,out_epoch=False,loss_step=1):
        self.lr = lr
        self.epochs = epochs
        self.out_loss = out_loss
        self.out_gradient = out_gradient
        self.out_update = out_update
        self.out_epoch = out_epoch
        self.weight = None
        self.bias = None
        self.loss_history = []
        self.loss_step = loss_step
    
    def sigmoid(self,z):
        return 1/(1+np.exp(-z))
    
    def fit(self,X,y):
        y = np.array(y)
        X=np.array(X)
        n_sample , n_feature = X.shape
        self.weight = np.zeros(n_feature)
        self.bias = 0
        self.loss_history = []
        if self.out_epoch:
            print("Model: Logistic Regression")
            print("y_pred = sigmoid(X·w + b)")
            print()
            print("Initial weight =",self.weight)
            print("Initial bias =",self.bias)
            print()
        X=np.array(X)
        for i in range(self.epochs):
            if self.out_epoch:
                print("------")
                print("Epoch",i+1)

            z = X.dot(self.weight) + self.bias
            y_pred = self.sigmoid(z)
            loss = (-1/n_sample) * np.sum(y*np.log(y_pred+1e-8) +(1-y)*np.log(1-y_pred+1e-8))
            self.loss_history.append(loss)
            dw = (1/n_sample)* X.T @ (y_pred-y)
            db = (1/n_sample) * np.sum(y_pred-y)
            if self.out_gradient:
                print("dw =",dw)
                print("db =",db)

            old_w = self.weight.copy()
            old_b = self.bias
            
            self.weight -= self.lr * dw
            self.bias -= self.lr * db
            if self.out_update:
                print("Weight update:")
                print(old_w,"->",self.weight)
                print("Bias update:")
                print(old_b,"->",self.bias)

        
        if self.out_loss:
            print("Loss history")
            for i in range(0,len(self.loss_history),self.loss_step):
                print(f"Epoch {i+1:3d} | Loss = {self.loss_history[i]:.6f}")
            print("Initial Loss =",self.loss_history[0])
            print("Final Loss =",self.loss_history[-1])
        
    
    def predict(self,X,explain=False):
        X = np.array(X)
        z = X.dot(self.weight) + self.bias
        y_prob = self.sigmoid(z)
        y_pred = (y_prob > 0.5).astype(int)
        if explain:
            print("Predict explain")
            print()
            print("z = X·w + b")
            print("=",z)
            print()
            print("sigmoid(z) =",y_prob)
            print()
            print("Threshold = 0.5")
            print("Prediction =",y_pred)
        return y_pred

    def score(self,X,y,explain=False):
        y = np.array(y)
        y_pred = self.predict(X)
        acc = np.mean(y_pred == y)
        if explain:
            print("Accuracy Explain")
            print()
            print("Correct =",np.sum(y_pred==y))
            print("Total =",len(y))
            print()
            print("Accuracy =",acc)
        return acc