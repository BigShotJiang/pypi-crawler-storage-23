import numpy as np
import pickle
class BaseModel:
    def fit(self, X, y):
        pass

    def predict(self, X):
        pass

    def score(self,X,y):
        y_pred = self.predict(X)
        return np.mean(y_pred == y)

    def save(self, path="model.best"):
        with open(path, "wb") as f:
            pickle.dump(self, f)

    @staticmethod
    def load(path="model.best"):
        with open(path, "rb") as f:
            return pickle.load(f)