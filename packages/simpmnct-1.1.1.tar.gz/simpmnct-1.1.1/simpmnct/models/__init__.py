from .linear import linear
from .logistic import logistic

__all__ = [ "linear",  "logistic"]