simpmnct là thư viện dành cho người mới học Machine Learning, tập trung vào việc giúp bạn hiểu bản chất mô hình thay vì chỉ gọi hàm có sẵn.

Thư viện xử lý được hầu hết các trường hợp cơ bản trong Machine Learning, nhưng nhiều bước được giữ lại để người học tự thao tác bằng tay, giúp hiểu rõ cách mô hình hoạt động thay vì phụ thuộc hoàn toàn vào các thư viện lớn.

Thư viện được xây dựng dựa trên:
numpy — tính toán ma trận và vector
pickle — lưu model
torch / torchvision — hỗ trợ mở rộng deep learning
pillow — xử lý ảnh
Một điểm đặc biệt của simpmnct là khả năng in chi tiết quá trình học của mô hình, bao gồm:

Các tham số out_* có thể hiển thị:
Loss theo từng epoch (out_loss)
Gradient của mô hình (out_gradient)
Quá trình cập nhật weight và bias (out_update)
Thông tin từng epoch (out_epoch)
Công thức mô hình (out_formula)
Thống kê dữ liệu (out_stat)
Dữ liệu trước và sau xử lý (out_data)
Quá trình chia train/test (out_split)
Kích thước dữ liệu (out_shape)
Index train/test (out_index)
Giải thích quá trình dự đoán (explain=True)
Người học có thể bật hoặc tắt từng phần để quan sát cách mô hình học từng bước.

Loss qua từng epoch
Gradient (dw, db)
Cập nhật weight và bias
Công thức mô hình
Quá trình predict từng bước

Thư viện hỗ trợ:
Linear Regression
Logistic Regression
Train/Test Split
Normalize dữ liệu (data)
Metrics cơ bản 
Save/Load model (.best)

simpmnct is a library for beginners in Machine Learning, focusing on helping you understand the fundamentals of the model rather than simply calling built-in functions.

The library handles most basic Machine Learning scenarios, but many steps are left to allow learners to manipulate them manually, helping them understand how the model works instead of relying entirely on large libraries.

The library is built on:
numpy — matrix and vector computation
pickle — model storage
torch / torchvision — support for deep learning extensions
pillow — image processing
A unique feature of simpmnct is its ability to print detailed model learning progress, including:

The out_* parameters can display:
Loss per epoch (out_loss)
Model gradient (out_gradient)
Weight and bias update process (out_update)
Information per epoch (out_epoch)
Model formula (out_formula)
Data statistics (out_stat)
Data before and after processing (out_data)
Train/test splitting process (out_split)
Data size (out_shape)
Train/test index (out_index)
Prediction process explanation (explain=True)
Learners can turn each part on or off to observe how the model learns step by step.

Loss at each epoch
Gradient (dw, db)
Update weights and biases
Model formulas
Step-by-step prediction process

Supported libraries:
Linear Regression
Logistic Regression
Train/Test Split
Normalize data
Basic Metrics
Save/Load model (.best)

Example 1 — Linear Regression_______
import numpy as np
from simpmnct.models.linear import Linear
from simpmnct.utils.train_test_split import train_test_split
# Generate data
X = np.random.rand(100,1)
y = 3*X + 2
# Split data
X_train, X_test, y_train, y_test = train_test_split(X,y)
# Train model
model = Linear(lr=0.01, epochs=1000,out_loss=True,
    out_gradient=True,
    out_update=True,
    out_epoch=True,
    loss_step=10)
model.fit(X_train,y_train)
# Predict
pred = model.predict(X_test)
print(pred[:5])

Example 2 — Logistic Regression----
import numpy as np
from simpmnct.models.logistic import Logistic
# Generate classification data
X = np.random.rand(100,2)
y = (X[:,0] + X[:,1] > 1).astype(int)
# Train model
model = Logistic(lr=0.1, epochs=1000,out_loss=True,
    out_gradient=True,
    out_update=False,
    out_epoch=True,
    loss_step=10)
model.fit(X,y)
# Predict
print(model.predict(X[:5]))

# Train/Test Split
from simpmnct.utils.train_test_split import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X,y)

# Normalize Data
from simpmnct.utils.normalize import normalize
X_norm = normalize(X)

# Metrics
from simpmnct.metrics.metrics import accuracy
from simpmnct.metrics.metrics import mse
print(accuracy(y_true,y_pred))
print(mse(y_true,y_pred))

Save Model:
model.save("model.best")

# Load Model
from simpmnct.models.linear import Linear
model = Linear.load("model.best")

# Dataset Loader (Depth Estimation):
from simpmnct.dataset.depth_dataset import DepthDataset
dataset = DepthDataset(img_dir="images",depth_dir="depth")
img, depth = dataset[0]

# Output:
image -> Tensor (3, H, W)
depth -> Tensor (1, H, W)

lưu ý : model này là do thằng sinh viên năm 2 viết ko dùng cho dự án lớn hay dẫn đường tên lửa , có thể sai số hoặc nhiều bug tiềm ẩn , chỉ sử dụng để học hoặc làm dự án nhỏ

Please note: this model was written by a second-year student and is not intended for large projects or missile guidance. It may contain errors or potential bugs; it is only for learning or small projects.