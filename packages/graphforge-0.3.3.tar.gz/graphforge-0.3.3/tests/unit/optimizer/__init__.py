"""Unit tests for optimizer module."""
