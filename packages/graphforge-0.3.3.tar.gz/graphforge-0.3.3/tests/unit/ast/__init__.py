"""Tests for AST nodes."""
