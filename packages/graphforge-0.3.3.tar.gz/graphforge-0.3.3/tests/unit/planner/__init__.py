"""Tests for query planner."""
