"""Tests for parser."""
