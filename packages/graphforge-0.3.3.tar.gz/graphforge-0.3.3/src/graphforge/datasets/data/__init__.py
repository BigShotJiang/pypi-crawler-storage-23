"""Dataset metadata files.

This directory contains JSON files with dataset metadata for various
public graph dataset repositories (SNAP, NetworkRepository, etc.).
"""
