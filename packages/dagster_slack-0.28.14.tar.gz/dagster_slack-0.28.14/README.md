# dagster-slack

The docs for `dagster-slack` can be found
[here](https://docs.dagster.io/integrations/libraries/slack/dagster-slack).
