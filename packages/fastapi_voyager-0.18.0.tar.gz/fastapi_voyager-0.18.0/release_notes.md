feat: add support for GraphQL queries and mutations in ER diagram and rendering

