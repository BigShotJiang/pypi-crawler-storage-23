"""
Django Ninja test examples and utilities.

This directory contains test applications and utilities specifically for Django Ninja framework testing.
"""
