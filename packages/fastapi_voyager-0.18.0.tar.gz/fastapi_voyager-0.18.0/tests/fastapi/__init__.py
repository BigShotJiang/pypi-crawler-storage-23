"""
FastAPI test examples and utilities.

This directory contains test applications and utilities specifically for FastAPI framework testing.
These can be used as examples or for testing the introspector implementation.
"""
