.. ############################################################
..  WARNING: This file is AUTO-GENERATED from README.rst.tpl.
..                  ⚠️ DO NOT EDIT MANUALLY ⚠️
.. ############################################################


PyMoDAQ Utils
#############

.. image:: https://img.shields.io/pypi/v/pymodaq_utils.svg
   :target: https://pypi.org/project/pymodaq_utils/
   :alt: Latest Version

.. image:: https://readthedocs.org/projects/pymodaq/badge/?version=malik-irain-patch-1
   :target: https://pymodaq.readthedocs.io/en/stable/?badge=malik-irain-patch-1
   :alt: Documentation Status

.. image:: https://codecov.io/gh/PyMoDAQ/PyMoDAQ/branch/malik-irain-patch-1/graph/badge.svg?token=IQNJRCQDM2 
 :target: https://codecov.io/gh/PyMoDAQ/PyMoDAQ

+-------------+-------------+---------------+
|             | Linux       | Windows       |
+=============+=============+===============+
| Python 3.10 | |310-linux| | |310-windows| |
+-------------+-------------+---------------+
| Python 3.11 | |311-linux| | |311-windows| |
+-------------+-------------+---------------+
| Python 3.12 | |312-linux| | |312-windows| |
+-------------+-------------+---------------+
| Python 3.13 | |313-linux| | |313-windows| |
+-------------+-------------+---------------+





.. |310-linux| image:: https://raw.githubusercontent.com/PyMoDAQ/PyMoDAQ/badges/pymodaq_utils/malik-irain-patch-1/tests_Linux_3.10.svg
    :target: https://github.com/PyMoDAQ/PyMoDAQ/actions/workflows/tests-utils.yml

.. |311-linux| image:: https://raw.githubusercontent.com/PyMoDAQ/PyMoDAQ/badges/pymodaq_utils/malik-irain-patch-1/tests_Linux_3.11.svg
    :target: https://github.com/PyMoDAQ/PyMoDAQ/actions/workflows/tests-utils.yml

.. |312-linux| image:: https://raw.githubusercontent.com/PyMoDAQ/PyMoDAQ/badges/pymodaq_utils/malik-irain-patch-1/tests_Linux_3.12.svg
    :target: https://github.com/PyMoDAQ/PyMoDAQ/actions/workflows/tests-utils.yml

.. |313-linux| image:: https://raw.githubusercontent.com/PyMoDAQ/PyMoDAQ/badges/pymodaq_utils/malik-irain-patch-1/tests_Linux_3.13.svg
    :target: https://github.com/PyMoDAQ/PyMoDAQ/actions/workflows/tests-utils.yml

.. |310-windows| image:: https://raw.githubusercontent.com/PyMoDAQ/PyMoDAQ/badges/pymodaq_utils/malik-irain-patch-1/tests_Windows_3.10.svg
    :target: https://github.com/PyMoDAQ/PyMoDAQ/actions/workflows/tests-utils.yml

.. |311-windows| image:: https://raw.githubusercontent.com/PyMoDAQ/PyMoDAQ/badges/pymodaq_utils/malik-irain-patch-1/tests_Windows_3.11.svg
    :target: https://github.com/PyMoDAQ/PyMoDAQ/actions/workflows/tests-utils.yml

.. |312-windows| image:: https://raw.githubusercontent.com/PyMoDAQ/PyMoDAQ/badges/pymodaq_utils/malik-irain-patch-1/tests_Windows_3.12.svg
    :target: https://github.com/PyMoDAQ/PyMoDAQ/actions/workflows/tests-utils.yml

.. |313-windows| image:: https://raw.githubusercontent.com/PyMoDAQ/PyMoDAQ/badges/pymodaq_utils/malik-irain-patch-1/tests_Windows_3.13.svg
    :target: https://github.com/PyMoDAQ/PyMoDAQ/actions/workflows/tests-utils.yml





.. figure:: http://pymodaq.cnrs.fr/en/latest/_static/splash.png
   :alt: shortcut


PyMoDAQ__, Modular Data Acquisition with Python, is a set of **python** modules used to interface any kind of
experiments. It simplifies the interaction with detector and actuator hardware to go straight to the data acquisition
of interest.

__ https://pymodaq.readthedocs.io/en/stable/?badge=latest

This present repository `pymodaq_utils` is a set of utilities (constants, methods and classes) that are used in the
various subpackages of PyMoDAQ (PyMoDAQ itself, but also plugins and data management and user interfaces modules)

PyMoDAQ Diagram:

.. figure:: http://pymodaq.cnrs.fr/en/latest/_images/pymodaq_diagram.png
   :alt: overview

   PyMoDAQ's Dashboard and its extensions: DAQ_Scan for automated acquisitions, DAQ_Logger for data logging and many other.


Published under the MIT FREE SOFTWARE LICENSE

GitHub repo: https://github.com/PyMoDAQ

Documentation: http://pymodaq.cnrs.fr/
