"""
pandoc_beamer_block package.
"""

from ._main import main

__all__ = ("main",)

if __name__ == "__main__":
    main()
