"""Tests for Phase 2 — Observability: logging, metrics, alerting."""

from __future__ import annotations

import logging
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from sonic.logging import _redact, tx_id_var, merchant_id_var, _ContextFilter, _RedactionFilter


# ---------------------------------------------------------------------------
# Secret redaction
# ---------------------------------------------------------------------------


class TestSecretRedaction:
    def test_redacts_stripe_key(self):
        assert "sk_live_[REDACTED]" == _redact("sk_live_abc123def456ghi789")

    def test_redacts_sonic_api_key(self):
        assert "sonic_key_[REDACTED]" == _redact("sonic_key_xyzabc123456")

    def test_redacts_bearer_token(self):
        result = _redact("Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.payload.sig")
        assert "[REDACTED]" in result
        assert "eyJhbGci" not in result

    def test_redacts_url_credentials(self):
        result = _redact("postgresql://user:secretpass@db:5432/sonic")
        assert "secretpass" not in result
        assert "[REDACTED]" in result

    def test_preserves_normal_text(self):
        text = "Transaction tx_abc123 settled successfully"
        assert _redact(text) == text


class TestContextFilter:
    def test_injects_context_vars(self):
        filt = _ContextFilter()
        record = logging.LogRecord("test", logging.INFO, "", 0, "msg", (), None)

        tx_token = tx_id_var.set("tx_test_001")
        merchant_token = merchant_id_var.set("merch_test_001")
        try:
            filt.filter(record)
            assert record.tx_id == "tx_test_001"  # type: ignore[attr-defined]
            assert record.merchant_id == "merch_test_001"  # type: ignore[attr-defined]
        finally:
            tx_id_var.reset(tx_token)
            merchant_id_var.reset(merchant_token)

    def test_defaults_to_dash(self):
        filt = _ContextFilter()
        record = logging.LogRecord("test", logging.INFO, "", 0, "msg", (), None)
        filt.filter(record)
        assert record.tx_id == "-"  # type: ignore[attr-defined]
        assert record.merchant_id == "-"  # type: ignore[attr-defined]


class TestRedactionFilter:
    def test_redacts_message(self):
        filt = _RedactionFilter()
        record = logging.LogRecord("test", logging.INFO, "", 0, "Key: sk_live_abc123def456ghi789", (), None)
        filt.filter(record)
        assert "abc123def456" not in record.msg

    def test_redacts_tuple_args(self):
        filt = _RedactionFilter()
        record = logging.LogRecord("test", logging.INFO, "", 0, "key=%s", ("sk_live_abc123def456ghi789",), None)
        filt.filter(record)
        assert "abc123def456" not in str(record.args)


# ---------------------------------------------------------------------------
# Alerting
# ---------------------------------------------------------------------------


class TestAlertState:
    @pytest.mark.asyncio
    async def test_dlq_alert_fires_above_threshold(self):
        from sonic.alerting import AlertState, DLQ_DEPTH_THRESHOLD

        state = AlertState()
        redis = AsyncMock()
        redis.llen = AsyncMock(return_value=DLQ_DEPTH_THRESHOLD + 5)

        with patch("sonic.alerting.logger") as mock_logger:
            await state.check_dlq(redis)
            mock_logger.warning.assert_called_once()
            assert "sbn_dlq_high" in str(mock_logger.warning.call_args)

    @pytest.mark.asyncio
    async def test_dlq_alert_clears_below_threshold(self):
        from sonic.alerting import AlertState

        state = AlertState()
        state._fired.add("sbn_dlq_high")
        redis = AsyncMock()
        redis.llen = AsyncMock(return_value=0)

        with patch("sonic.alerting.logger") as mock_logger:
            await state.check_dlq(redis)
            mock_logger.info.assert_called_once()
            assert "CLEARED" in str(mock_logger.info.call_args)

    @pytest.mark.asyncio
    async def test_sbn_backlog_alert(self):
        from sonic.alerting import AlertState, SBN_BACKLOG_THRESHOLD

        state = AlertState()
        attester = AsyncMock()
        attester.queue_depth = AsyncMock(return_value=SBN_BACKLOG_THRESHOLD + 50)

        with patch("sonic.alerting.logger") as mock_logger:
            await state.check_sbn_backlog(attester)
            mock_logger.warning.assert_called_once()

    def test_provider_degradation_fires_after_window(self):
        from sonic.alerting import AlertState, PROVIDER_FAILURE_WINDOW

        state = AlertState()
        with patch("sonic.alerting.logger") as mock_logger:
            for _ in range(PROVIDER_FAILURE_WINDOW - 1):
                state.check_provider_health("stripe_card", False)
            # Not yet fired
            mock_logger.warning.assert_not_called()

            # One more failure triggers alert
            state.check_provider_health("stripe_card", False)
            mock_logger.warning.assert_called_once()

    def test_provider_alert_clears_on_recovery(self):
        from sonic.alerting import AlertState, PROVIDER_FAILURE_WINDOW

        state = AlertState()
        for _ in range(PROVIDER_FAILURE_WINDOW):
            state.check_provider_health("stripe_card", False)

        with patch("sonic.alerting.logger") as mock_logger:
            state.check_provider_health("stripe_card", True)
            mock_logger.info.assert_called_once()
            assert "CLEARED" in str(mock_logger.info.call_args)

    def test_no_duplicate_alerts(self):
        from sonic.alerting import AlertState, PROVIDER_FAILURE_WINDOW

        state = AlertState()
        with patch("sonic.alerting.logger") as mock_logger:
            for _ in range(PROVIDER_FAILURE_WINDOW * 3):
                state.check_provider_health("stripe_card", False)
            # Only fires once
            assert mock_logger.warning.call_count == 1


# ---------------------------------------------------------------------------
# Metrics existence check
# ---------------------------------------------------------------------------

class TestMetricsExist:
    def test_new_metrics_importable(self):
        from sonic.metrics import (
            PROVIDER_LATENCY,
            PROVIDER_HEALTH,
            WEBHOOK_PROCESSING_DURATION,
            RECEIPT_TOTAL,
            SBN_QUEUE_DEPTH,
            SBN_DLQ_DEPTH,
            ANCHOR_QUEUE_DEPTH,
        )
        # Just check they are the right prometheus types
        assert PROVIDER_LATENCY._name == "sonic_provider_latency_seconds"
        assert PROVIDER_HEALTH._name == "sonic_provider_healthy"
        assert WEBHOOK_PROCESSING_DURATION._name == "sonic_webhook_processing_seconds"
        assert RECEIPT_TOTAL._name == "sonic_receipts"
        assert SBN_QUEUE_DEPTH._name == "sonic_sbn_attestation_queue_depth"
        assert SBN_DLQ_DEPTH._name == "sonic_sbn_dlq_depth"
        assert ANCHOR_QUEUE_DEPTH._name == "sonic_anchor_queue_depth"
