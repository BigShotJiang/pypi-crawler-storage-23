"""Prometheus metrics for Sonic.

Central registry of all application metrics. Import the counters /
histograms you need and call ``.inc()`` / ``.observe()`` at the
relevant callsites.

The ``/metrics`` endpoint is served by :func:`metrics_endpoint`
(mounted in ``app.py``).
"""

from __future__ import annotations

from prometheus_client import Counter, Gauge, Histogram

# ---------------------------------------------------------------------------
# HTTP request metrics (populated by RequestLoggingMiddleware)
# ---------------------------------------------------------------------------

HTTP_REQUEST_DURATION = Histogram(
    "sonic_http_request_duration_seconds",
    "HTTP request latency in seconds",
    labelnames=["method", "path", "status"],
    buckets=(0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0),
)

HTTP_REQUESTS_TOTAL = Counter(
    "sonic_http_requests_total",
    "Total HTTP requests",
    labelnames=["method", "path", "status"],
)

# ---------------------------------------------------------------------------
# Transaction lifecycle metrics
# ---------------------------------------------------------------------------

TX_CREATED = Counter(
    "sonic_transactions_created_total",
    "Transactions created (payments initiated)",
    labelnames=["rail", "currency"],
)

TX_STATE_TRANSITIONS = Counter(
    "sonic_tx_state_transitions_total",
    "Transaction state machine transitions",
    labelnames=["from_state", "to_state", "provider"],
)

# ---------------------------------------------------------------------------
# Payout metrics
# ---------------------------------------------------------------------------

PAYOUT_TOTAL = Counter(
    "sonic_payouts_total",
    "Payouts attempted",
    labelnames=["rail", "status"],
)

# ---------------------------------------------------------------------------
# Provider metrics
# ---------------------------------------------------------------------------

PROVIDER_ERRORS = Counter(
    "sonic_provider_errors_total",
    "Payment provider errors",
    labelnames=["provider", "retryable"],
)

PROVIDER_LATENCY = Histogram(
    "sonic_provider_latency_seconds",
    "Payment provider API call latency",
    labelnames=["provider", "operation"],
    buckets=(0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0),
)

PROVIDER_HEALTH = Gauge(
    "sonic_provider_healthy",
    "Payment provider health status (1=healthy, 0=unhealthy)",
    labelnames=["provider"],
)

# ---------------------------------------------------------------------------
# Webhook metrics
# ---------------------------------------------------------------------------

WEBHOOK_RECEIVED = Counter(
    "sonic_webhooks_received_total",
    "Webhooks received from payment providers",
    labelnames=["provider", "outcome"],
)

WEBHOOK_PROCESSING_DURATION = Histogram(
    "sonic_webhook_processing_seconds",
    "Time to process a webhook from receipt to response",
    labelnames=["provider"],
    buckets=(0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0),
)

# ---------------------------------------------------------------------------
# Receipt metrics
# ---------------------------------------------------------------------------

RECEIPT_TOTAL = Counter(
    "sonic_receipts_total",
    "Receipts created by verification tier",
    labelnames=["tier"],
)

# ---------------------------------------------------------------------------
# Queue depth gauges (set periodically from the drain loop)
# ---------------------------------------------------------------------------

SBN_QUEUE_DEPTH = Gauge(
    "sonic_sbn_attestation_queue_depth",
    "Current depth of SBN attestation queue",
)

SBN_DLQ_DEPTH = Gauge(
    "sonic_sbn_dlq_depth",
    "Current depth of SBN attestation dead-letter queue",
)

ANCHOR_QUEUE_DEPTH = Gauge(
    "sonic_anchor_queue_depth",
    "Current depth of blockchain anchor queue",
)
