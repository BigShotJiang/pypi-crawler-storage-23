"""Stripe provider adapter — card payments, ACH, and transfers."""

from __future__ import annotations

import logging
import time
from decimal import Decimal
from typing import Any

from sonic.providers.base import BaseProvider, ProviderError
from sonic.metrics import PROVIDER_LATENCY

logger = logging.getLogger(__name__)


class StripeProvider(BaseProvider):
    """Handles Stripe payment capture and payout transfers."""

    def __init__(self, secret_key: str):
        self._secret_key = secret_key
        self._client = None  # Lazy init: import stripe at runtime

    @property
    def name(self) -> str:
        return "stripe"

    def _get_client(self):
        if self._client is None:
            try:
                import stripe

                stripe.api_key = self._secret_key
                self._client = stripe
            except ImportError:
                raise ProviderError("stripe", "stripe package not installed")
        return self._client

    async def send_payout(
        self,
        *,
        recipient_id: str,
        amount: Decimal,
        currency: str,
        idempotency_key: str,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a Stripe Transfer to a connected account."""
        client = self._get_client()
        _start = time.perf_counter()
        try:
            transfer = client.Transfer.create(
                amount=int(amount * 100),  # Stripe uses cents
                currency=currency.lower(),
                destination=recipient_id,
                idempotency_key=idempotency_key,
                metadata=metadata or {},
            )
            return {"ref": transfer.id, "status": transfer.status}
        except client.error.StripeError as exc:
            logger.error("Stripe send_payout failed: %s", exc)
            raise ProviderError(
                "stripe",
                "Payout request failed",
                retryable=getattr(exc, "is_retryable", False),
            ) from exc
        finally:
            PROVIDER_LATENCY.labels(provider="stripe", operation="send_payout").observe(time.perf_counter() - _start)

    async def check_status(self, provider_ref: str) -> dict[str, Any]:
        client = self._get_client()
        _start = time.perf_counter()
        try:
            transfer = client.Transfer.retrieve(provider_ref)
            return {"ref": transfer.id, "status": transfer.status}
        except client.error.StripeError as exc:
            logger.error("Stripe check_status failed: %s", exc)
            raise ProviderError("stripe", "Status check failed") from exc
        finally:
            PROVIDER_LATENCY.labels(provider="stripe", operation="check_status").observe(time.perf_counter() - _start)

    async def health(self) -> bool:
        try:
            client = self._get_client()
            client.Account.retrieve()
            return True
        except Exception:
            return False
