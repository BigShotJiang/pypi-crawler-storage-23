"""Base provider interface — all payment rail adapters implement this."""

from __future__ import annotations

import abc
from decimal import Decimal
from typing import Any


class ProviderError(Exception):
    """Raised when a provider operation fails."""

    def __init__(self, provider: str, message: str, *, retryable: bool = False):
        self.provider = provider
        self.retryable = retryable
        super().__init__(f"[{provider}] {message}")


class BaseProvider(abc.ABC):
    """Abstract provider adapter."""

    @property
    @abc.abstractmethod
    def name(self) -> str:
        """Provider identifier (e.g. 'stripe', 'moov', 'circle')."""

    @abc.abstractmethod
    async def send_payout(
        self,
        *,
        recipient_id: str,
        amount: Decimal,
        currency: str,
        idempotency_key: str,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute a payout. Returns dict with at least {"ref": "provider_reference_id"}."""

    @abc.abstractmethod
    async def check_status(self, provider_ref: str) -> dict[str, Any]:
        """Check status of a previously submitted payout."""

    async def health(self) -> bool:
        """Health check — override if provider supports it."""
        return True
