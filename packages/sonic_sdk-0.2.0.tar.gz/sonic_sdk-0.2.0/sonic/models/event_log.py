"""Event log — immutable append-only ledger of all state transitions.

This is Sonic's internal audit trail. Every state change, every payout
attempt, every provider callback is recorded here. This table is
append-only — no updates, no deletes.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import DateTime, Index, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from sonic.models.base import Base


class EventLog(Base):
    __tablename__ = "event_log"

    id: Mapped[str] = mapped_column(
        String(64), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    tx_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    event_type: Mapped[str] = mapped_column(String(64), nullable=False)
    from_state: Mapped[str | None] = mapped_column(String(32))
    to_state: Mapped[str | None] = mapped_column(String(32))
    merchant_id: Mapped[str] = mapped_column(String(64), nullable=False)

    # Context
    provider: Mapped[str | None] = mapped_column(String(32))
    provider_ref: Mapped[str | None] = mapped_column(String(128))
    idempotency_key: Mapped[str | None] = mapped_column(String(128))
    receipt_hash: Mapped[str | None] = mapped_column(String(128))

    # Flexible payload for event-specific data
    payload: Mapped[dict | None] = mapped_column(JSONB)

    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), index=True
    )

    __table_args__ = (
        Index("ix_event_log_tx_ts", "tx_id", "timestamp"),
        Index("ix_event_log_merchant_ts", "merchant_id", "timestamp"),
    )
