"""PayStream model — windowed accrual streaming with risk-gated policy.

A PayStream represents an ongoing payment relationship where earnings accrue
over 30-minute labor-block windows. Micro-payouts are released per-window
according to the stream's risk policy state.

Lifecycle: ACTIVE → PAUSED → ACTIVE (manual)
                  → FROZEN → ACTIVE (policy-driven)
                  → CLOSED (terminal)

Each stream owns an SBN slot (via StreamSession) and tracks:
- Accrual windows (30-min labor blocks)
- Risk policy state (PRIME / NORMAL / RISK / FROZEN)
- g_ewma efficiency score
- Earned entitlement vs. disbursed amounts
- Per-payee-per-day epochs
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import DateTime, Index, Integer, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from sonic.models.base import Base


class PayStream(Base):
    __tablename__ = "pay_streams"

    id: Mapped[str] = mapped_column(
        String(64), primary_key=True, default=lambda: f"ps_{uuid.uuid4().hex[:24]}"
    )
    merchant_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)

    # Payer / payee relationship
    payer_id: Mapped[str] = mapped_column(String(128), nullable=False)
    payee_id: Mapped[str] = mapped_column(String(128), nullable=False)

    # SBN slot binding — delegates to StreamSession for slot lifecycle
    stream_session_id: Mapped[str | None] = mapped_column(String(64))
    sbn_slot_id: Mapped[str | None] = mapped_column(String(128))

    # Currency and rail
    currency: Mapped[str] = mapped_column(String(4), nullable=False, default="USD")
    rail: Mapped[str] = mapped_column(String(32), nullable=False, default="stripe_transfer")

    # Rate model: units * price per window
    rate_amount: Mapped[Decimal] = mapped_column(
        Numeric(18, 6), nullable=False, default=Decimal("0")
    )
    rate_unit: Mapped[str] = mapped_column(
        String(32), nullable=False, default="per_window"
    )  # per_window | per_hour | per_task

    # Stream lifecycle: active | paused | frozen | closed
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="active")

    # Risk policy state: prime | normal | risk | frozen
    policy_state: Mapped[str] = mapped_column(String(16), nullable=False, default="normal")

    # g_ewma — exponentially weighted moving average of GEC efficiency
    g_ewma: Mapped[Decimal] = mapped_column(
        Numeric(10, 6), nullable=False, default=Decimal("0.5")
    )
    g_ewma_alpha: Mapped[Decimal] = mapped_column(
        Numeric(6, 4), nullable=False, default=Decimal("0.3")
    )  # Smoothing factor

    # Hysteresis thresholds for policy transitions
    threshold_prime: Mapped[Decimal] = mapped_column(
        Numeric(6, 4), nullable=False, default=Decimal("0.85")
    )
    threshold_risk: Mapped[Decimal] = mapped_column(
        Numeric(6, 4), nullable=False, default=Decimal("0.40")
    )
    threshold_frozen: Mapped[Decimal] = mapped_column(
        Numeric(6, 4), nullable=False, default=Decimal("0.20")
    )

    # Policy knobs
    cadence_seconds: Mapped[int] = mapped_column(
        Integer, nullable=False, default=1800
    )  # Window size: 30 min = 1800s
    holdback_pct: Mapped[Decimal] = mapped_column(
        Numeric(5, 4), nullable=False, default=Decimal("0.0")
    )  # 0.0 = no holdback, 0.10 = 10% held
    instant_limit: Mapped[Decimal] = mapped_column(
        Numeric(18, 6), nullable=False, default=Decimal("10000.0")
    )  # Max per-window instant disbursement

    # Accrual tracking
    total_earned: Mapped[Decimal] = mapped_column(
        Numeric(18, 6), nullable=False, default=Decimal("0")
    )
    total_disbursed: Mapped[Decimal] = mapped_column(
        Numeric(18, 6), nullable=False, default=Decimal("0")
    )
    total_held: Mapped[Decimal] = mapped_column(
        Numeric(18, 6), nullable=False, default=Decimal("0")
    )
    window_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    # Current window tracking
    current_window_start: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    current_window_earned: Mapped[Decimal] = mapped_column(
        Numeric(18, 6), nullable=False, default=Decimal("0")
    )

    # Epoch tracking (per-payee-per-day)
    current_epoch_key: Mapped[str | None] = mapped_column(String(64))

    # Metadata
    metadata_json: Mapped[str | None] = mapped_column(Text)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )
    paused_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    frozen_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    __table_args__ = (
        Index("ix_pay_streams_merchant_status", "merchant_id", "status"),
        Index("ix_pay_streams_payee_status", "payee_id", "status"),
        Index("ix_pay_streams_payer_payee", "payer_id", "payee_id"),
        Index("ix_pay_streams_session", "stream_session_id"),
    )
