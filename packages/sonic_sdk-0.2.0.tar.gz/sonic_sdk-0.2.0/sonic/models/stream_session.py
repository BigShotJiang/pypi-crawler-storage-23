"""StreamSession model — maps a Dominion streaming session to an SBN slot."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import DateTime, Index, Integer, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from sonic.models.base import Base


class StreamSession(Base):
    __tablename__ = "stream_sessions"

    id: Mapped[str] = mapped_column(
        String(64), primary_key=True, default=lambda: f"strm_{uuid.uuid4().hex[:24]}"
    )
    merchant_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)

    # SBN slot binding — the slot opened for this stream
    sbn_slot_id: Mapped[str | None] = mapped_column(String(128))

    # Worker identity (passed through to SBN open_slot)
    worker_id: Mapped[str] = mapped_column(String(128), nullable=False)

    # Streaming parameters
    total_amount: Mapped[Decimal] = mapped_column(Numeric(18, 6), nullable=False)
    currency: Mapped[str] = mapped_column(String(4), nullable=False, default="USD")
    interval_seconds: Mapped[int] = mapped_column(Integer, nullable=False, default=60)
    duration_seconds: Mapped[int] = mapped_column(Integer, nullable=False, default=3600)

    # State: open -> closed | expired | failed
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="open")

    # Merkle root from SBN close_slot (populated on close)
    merkle_root: Mapped[str | None] = mapped_column(String(256))

    # Counters
    blocks_attested: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    # Metadata
    metadata_json: Mapped[str | None] = mapped_column(Text)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    __table_args__ = (
        Index("ix_stream_sessions_merchant_status", "merchant_id", "status"),
        Index("ix_stream_sessions_sbn_slot", "sbn_slot_id"),
    )
