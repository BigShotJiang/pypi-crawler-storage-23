"""Dashboard user model — separate from merchant API key auth."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import DateTime, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column

from sonic.models.base import Base


class DashboardUser(Base):
    __tablename__ = "dashboard_users"

    id: Mapped[str] = mapped_column(
        String(64), primary_key=True, default=lambda: f"user_{uuid.uuid4().hex[:16]}"
    )
    email: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[str] = mapped_column(String(16), default="merchant")  # merchant | admin

    # Links merchant users to their merchant account (null for admins)
    merchant_id: Mapped[str | None] = mapped_column(
        String(64), ForeignKey("merchants.id"), nullable=True
    )

    status: Mapped[str] = mapped_column(String(16), default="active")  # active | disabled

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
