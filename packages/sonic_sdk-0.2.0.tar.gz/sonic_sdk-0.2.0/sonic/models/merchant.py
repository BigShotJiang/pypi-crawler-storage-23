"""Merchant model."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import DateTime, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from sonic.models.base import Base


class Merchant(Base):
    __tablename__ = "merchants"

    id: Mapped[str] = mapped_column(
        String(64), primary_key=True, default=lambda: f"merch_{uuid.uuid4().hex[:16]}"
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    email: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    business_type: Mapped[str] = mapped_column(String(32), default="smb")
    status: Mapped[str] = mapped_column(String(16), default="active")

    # API key (Argon2id hash — never store plaintext)
    api_key_hash: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    api_key_prefix: Mapped[str] = mapped_column(String(20), nullable=False)

    # Key rotation: previous key stays valid during grace period
    prev_api_key_hash: Mapped[str | None] = mapped_column(String(255))
    prev_api_key_prefix: Mapped[str | None] = mapped_column(String(20))
    key_rotated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    # IP allowlist for API key auth (comma-separated CIDRs, e.g. "10.0.0.0/8,203.0.113.5/32")
    ip_allowlist: Mapped[str | None] = mapped_column(String(1024))

    # Payout preferences
    default_payout_currency: Mapped[str] = mapped_column(String(4), default="USD")
    default_payout_rail: Mapped[str] = mapped_column(String(32), default="stripe_card")

    # Provider account linkage
    stripe_account_id: Mapped[str | None] = mapped_column(String(64))
    moov_account_id: Mapped[str | None] = mapped_column(String(64))
    circle_wallet_id: Mapped[str | None] = mapped_column(String(64))

    # Plan tier for multi-tenant rate limiting (free | growth | enterprise)
    plan: Mapped[str] = mapped_column(String(16), default="free")

    # Blockchain anchor preferences (opt-in per merchant)
    anchor_chain: Mapped[str | None] = mapped_column(String(16))  # "hedera" | "solana" | None
    hedera_topic_id: Mapped[str | None] = mapped_column(String(32))  # "0.0.xxxxx"
    solana_program_id: Mapped[str | None] = mapped_column(String(64))

    # Scheduled payout configuration (JSON)
    payout_schedule: Mapped[dict | None] = mapped_column(JSONB)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )

    # Soft-delete: set to timestamp when merchant is deactivated (NULL = active)
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
