"""Stream policy engine — risk-gated streaming with g_ewma hysteresis.

Four policy states gate how earnings flow to the payee:

  PRIME   — full instant access, no holdback, fastest cadence
  NORMAL  — standard access, configurable holdback, standard cadence
  RISK    — throttled access, elevated holdback, slower cadence
  FROZEN  — all payouts held, stream paused pending review

State transitions are driven by g_ewma (exponentially weighted moving
average of GEC efficiency scores). Hysteresis prevents oscillation:
a stream must *sustain* good/bad scores to transition, not just
spike once.

The policy engine is purely functional — it computes the next state
and policy knobs given the current state and a new GEC observation.
It does not write to the database or trigger payouts.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass
from decimal import Decimal


class PolicyState(str, enum.Enum):
    PRIME = "prime"
    NORMAL = "normal"
    RISK = "risk"
    FROZEN = "frozen"


# Hysteresis band: to exit a state, you must pass the threshold
# by at least this margin (prevents rapid oscillation)
_HYSTERESIS_BAND = Decimal("0.05")


@dataclass(frozen=True)
class PolicyThresholds:
    """Configurable thresholds for policy state transitions.

    g_ewma >= prime    → PRIME
    prime > g_ewma >= risk  → NORMAL
    risk > g_ewma >= frozen → RISK
    g_ewma < frozen   → FROZEN
    """

    prime: Decimal = Decimal("0.85")
    risk: Decimal = Decimal("0.40")
    frozen: Decimal = Decimal("0.20")


@dataclass(frozen=True)
class PolicyKnobs:
    """Per-state payout parameters computed by the policy engine."""

    state: PolicyState
    cadence_seconds: int       # Window size / payout interval
    holdback_pct: Decimal      # Fraction of earned amount held back
    instant_limit: Decimal     # Max disbursement per window
    can_disburse: bool         # Whether payouts are allowed at all


# Default knobs per state
_STATE_KNOBS: dict[PolicyState, PolicyKnobs] = {
    PolicyState.PRIME: PolicyKnobs(
        state=PolicyState.PRIME,
        cadence_seconds=1800,       # 30 min (labor block)
        holdback_pct=Decimal("0"),
        instant_limit=Decimal("10000"),
        can_disburse=True,
    ),
    PolicyState.NORMAL: PolicyKnobs(
        state=PolicyState.NORMAL,
        cadence_seconds=1800,
        holdback_pct=Decimal("0.05"),   # 5% holdback
        instant_limit=Decimal("5000"),
        can_disburse=True,
    ),
    PolicyState.RISK: PolicyKnobs(
        state=PolicyState.RISK,
        cadence_seconds=3600,           # Doubled cadence (1 hour)
        holdback_pct=Decimal("0.20"),   # 20% holdback
        instant_limit=Decimal("1000"),
        can_disburse=True,
    ),
    PolicyState.FROZEN: PolicyKnobs(
        state=PolicyState.FROZEN,
        cadence_seconds=0,              # No cadence — payouts stopped
        holdback_pct=Decimal("1.0"),    # 100% held
        instant_limit=Decimal("0"),
        can_disburse=False,
    ),
}


def compute_g_ewma(
    current_ewma: Decimal,
    new_score: Decimal,
    alpha: Decimal = Decimal("0.3"),
) -> Decimal:
    """Update the exponentially weighted moving average.

    g_ewma_new = α * new_score + (1 - α) * g_ewma_old

    Higher α means more weight on recent observations (faster response).
    Lower α means more smoothing (slower response, more stable).
    """
    return (alpha * new_score + (Decimal("1") - alpha) * current_ewma).quantize(
        Decimal("0.000001")
    )


def evaluate_policy(
    current_state: PolicyState,
    g_ewma: Decimal,
    thresholds: PolicyThresholds | None = None,
) -> PolicyState:
    """Compute the next policy state given current state and g_ewma.

    Uses hysteresis: to *improve* (e.g., RISK → NORMAL), g_ewma must
    exceed the threshold by the hysteresis band. To *degrade* (e.g.,
    NORMAL → RISK), g_ewma must drop below the threshold by the band.

    This prevents rapid oscillation when g_ewma hovers near a boundary.
    """
    t = thresholds or PolicyThresholds()

    if current_state == PolicyState.FROZEN:
        # Escape frozen: must sustain above risk threshold + hysteresis
        if g_ewma >= t.risk + _HYSTERESIS_BAND:
            return PolicyState.RISK
        return PolicyState.FROZEN

    if current_state == PolicyState.RISK:
        # Upgrade: must pass risk threshold + hysteresis to reach NORMAL
        if g_ewma >= t.risk + _HYSTERESIS_BAND:
            return PolicyState.NORMAL
        # Degrade: drop below frozen threshold
        if g_ewma < t.frozen:
            return PolicyState.FROZEN
        return PolicyState.RISK

    if current_state == PolicyState.NORMAL:
        # Upgrade: must pass prime threshold to reach PRIME
        if g_ewma >= t.prime:
            return PolicyState.PRIME
        # Degrade: drop below risk threshold - hysteresis
        if g_ewma < t.risk - _HYSTERESIS_BAND:
            return PolicyState.RISK
        return PolicyState.NORMAL

    if current_state == PolicyState.PRIME:
        # Degrade: drop below prime threshold - hysteresis
        if g_ewma < t.prime - _HYSTERESIS_BAND:
            return PolicyState.NORMAL
        return PolicyState.PRIME

    return current_state


def get_policy_knobs(state: PolicyState) -> PolicyKnobs:
    """Get the payout parameters for a given policy state."""
    return _STATE_KNOBS[state]


def compute_disbursement(
    earned: Decimal,
    knobs: PolicyKnobs,
) -> tuple[Decimal, Decimal]:
    """Compute (disburse_amount, holdback_amount) for a window close.

    Returns the amount to pay out immediately and the amount to hold.
    """
    if not knobs.can_disburse or earned <= 0:
        return Decimal("0"), earned

    holdback = (earned * knobs.holdback_pct).quantize(Decimal("0.000001"))
    available = earned - holdback

    # Apply instant limit
    disbursed = min(available, knobs.instant_limit)
    # Anything over instant_limit goes to holdback
    excess = available - disbursed
    holdback += excess

    return disbursed, holdback
