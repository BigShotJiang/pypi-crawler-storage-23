"""Stuck-state sweeper — recovers transactions stuck in intermediate states.

Runs periodically in the drain loop. Finds transactions that have been
stuck in NORMALIZING or PAYOUT_PENDING for longer than the configured
timeout and advances them to FAILED with appropriate receipts.

This is a safety net: the normalizer does quote-first (no partial state
under normal operation), and the payout endpoint is synchronous. But
process crashes, OOM kills, or DB timeouts can leave orphaned records.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.core.engine import Transaction, TxState
from sonic.core.receipt_builder import ReceiptChain
from sonic.events.types import EventType
from sonic.models.event_log import EventLog
from sonic.models.receipt import ReceiptRecord
from sonic.models.transaction import TransactionRecord

logger = logging.getLogger(__name__)

# How long a transaction can sit in an intermediate state before
# the sweeper considers it stuck
_STUCK_NORMALIZING_MINUTES = 10
_STUCK_PAYOUT_PENDING_MINUTES = 30


class StuckSweeper:
    """Recovers transactions stuck in NORMALIZING or PAYOUT_PENDING."""

    def __init__(
        self,
        db_session_factory: Any,
        emitter: Any | None = None,
        *,
        normalizing_timeout_minutes: int | None = None,
        payout_pending_timeout_minutes: int | None = None,
    ) -> None:
        self._db = db_session_factory
        self._emitter = emitter
        self._normalizing_minutes = normalizing_timeout_minutes or _STUCK_NORMALIZING_MINUTES
        self._payout_pending_minutes = payout_pending_timeout_minutes or _STUCK_PAYOUT_PENDING_MINUTES

    async def sweep(self, max_batch: int = 20) -> int:
        """Find and fail stuck transactions. Returns count recovered."""
        recovered = 0
        recovered += await self._sweep_state(
            TxState.NORMALIZING,
            self._normalizing_minutes,
            max_batch,
        )
        recovered += await self._sweep_state(
            TxState.PAYOUT_PENDING,
            self._payout_pending_minutes,
            max_batch,
        )
        return recovered

    async def _sweep_state(
        self,
        stuck_state: TxState,
        max_age_minutes: int,
        max_batch: int,
    ) -> int:
        """Sweep a single stuck state."""
        cutoff = datetime.now(timezone.utc) - timedelta(minutes=max_age_minutes)

        async with self._db() as db:
            result = await db.execute(
                select(TransactionRecord.id)
                .where(
                    TransactionRecord.state == stuck_state.value,
                    TransactionRecord.updated_at < cutoff,
                )
                .limit(max_batch)
            )
            stuck_ids = [row[0] for row in result.all()]

        if not stuck_ids:
            return 0

        recovered = 0
        for tx_id in stuck_ids:
            try:
                if await self._fail_stuck(tx_id, stuck_state):
                    recovered += 1
            except Exception:
                logger.warning(
                    "Stuck sweep failed for tx %s", tx_id, exc_info=True
                )

        if recovered:
            logger.warning(
                "Stuck sweeper: recovered %d/%d transactions from %s",
                recovered, len(stuck_ids), stuck_state.value,
            )
        return recovered

    async def _fail_stuck(self, tx_id: str, stuck_state: TxState) -> bool:
        """Advance a single stuck transaction to FAILED."""
        async with self._db() as db:
            result = await db.execute(
                select(TransactionRecord).where(TransactionRecord.id == tx_id)
            )
            record = result.scalar_one_or_none()
            if not record or record.state != stuck_state.value:
                return False  # Already recovered or state changed

            tx = Transaction(
                tx_id=record.id,
                merchant_id=record.merchant_id,
                state=TxState(record.state),
                inbound_amount=record.inbound_amount,
                inbound_currency=record.inbound_currency,
                inbound_rail=record.inbound_rail,
                sequence=record.sequence,
            )

            event = tx.advance(
                TxState.FAILED,
                metadata={"reason": f"stuck_in_{stuck_state.value}", "sweeper": True},
            )

            record.state = TxState.FAILED.value
            record.sequence = tx.sequence

            # Build receipt
            prev_result = await db.execute(
                select(ReceiptRecord.receipt_hash)
                .where(ReceiptRecord.tx_id == record.id)
                .order_by(ReceiptRecord.sequence.desc())
                .limit(1)
            )
            prev_hash = prev_result.scalar_one_or_none()

            chain = ReceiptChain()
            chain._last_hash = prev_hash
            receipt = chain.build(
                event, merchant_id=record.merchant_id, direction="inbound"
            )

            db.add(ReceiptRecord(
                receipt_id=receipt.receipt_id,
                tx_id=record.id,
                event_type=receipt.event_type,
                sequence=receipt.sequence,
                amount=receipt.amount,
                currency=receipt.currency,
                rail=receipt.rail,
                direction=receipt.direction,
                receipt_hash=receipt.receipt_hash,
                prev_receipt_hash=receipt.prev_receipt_hash,
                idempotency_key=receipt.idempotency_key,
                merchant_id=record.merchant_id,
            ))

            db.add(EventLog(
                tx_id=record.id,
                event_type=EventType.PAYMENT_FAILED.value,
                from_state=stuck_state.value,
                to_state=TxState.FAILED.value,
                merchant_id=record.merchant_id,
                provider="sweeper",
                receipt_hash=receipt.receipt_hash,
                payload={
                    "reason": f"Transaction stuck in {stuck_state.value}",
                    "sweeper": True,
                },
            ))

            await db.commit()

        logger.warning(
            "Stuck sweeper: tx %s FAILED (was %s)", tx_id, stuck_state.value
        )

        # Emit event (non-blocking)
        if self._emitter is not None:
            try:
                await self._emitter.emit(EventType.PAYMENT_FAILED, {
                    "tx_id": tx_id,
                    "merchant_id": record.merchant_id,
                    "from_state": stuck_state.value,
                    "reason": "stuck_sweeper",
                })
            except Exception:
                pass

        return True
