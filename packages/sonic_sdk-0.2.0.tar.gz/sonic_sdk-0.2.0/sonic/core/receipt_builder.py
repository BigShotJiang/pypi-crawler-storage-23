"""Receipt builder — Sonic's three-tier immutable receipt chain.

Each state transition produces a receipt with:
- Canonical hash (SHA-256 over sorted JSON)
- Chain linkage (prev_receipt_hash)
- Idempotency key

Tier 1 — App chain: always available, never blocks.
Tier 2 — Combined chain: fuses app hash + SBN hash after async attestation.
Tier 3 — Blockchain anchor: optional per-merchant on-chain proof (Hedera/Solana).

SBN attestation is coupled asynchronously — the receipt exists
and is valid in Sonic's domain immediately. The combined hash
backfills when SBN attestation completes, creating the fused
immutable layer. Blockchain anchoring is opt-in on top.
"""

from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

from sonic.core.engine import TxEvent


def _json_default(obj: Any) -> Any:
    if isinstance(obj, Decimal):
        return str(obj)
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Not serializable: {type(obj)}")


def canonical_hash(data: dict[str, Any]) -> str:
    """SHA-256 over deterministically sorted JSON — same pattern as SBN SnapChore."""
    surface = json.dumps(data, sort_keys=True, default=_json_default, separators=(",", ":"))
    return hashlib.sha256(surface.encode()).hexdigest()


def combined_hash(app_hash: str, sbn_hash: str, prev_combined: str | None = None) -> str:
    """Fuse app-layer and SBN-layer hashes into a single combined proof.

    combined = SHA-256(app_hash || sbn_hash || prev_combined_hash)

    This creates a third chain that proves both layers agree AND preserves
    ordering. Once backfilled, tampering with either layer breaks the
    combined chain.
    """
    surface = f"{app_hash}:{sbn_hash}:{prev_combined or ''}"
    return hashlib.sha256(surface.encode()).hexdigest()


@dataclass
class SonicReceipt:
    """A single receipt in Sonic's chain."""

    receipt_id: str
    tx_id: str
    event_type: str
    sequence: int

    # Settlement data
    amount: Decimal
    currency: str
    rail: str
    direction: str  # "inbound" | "outbound"

    # Tier 1 — App chain (always populated, never blocks)
    receipt_hash: str
    prev_receipt_hash: str | None

    # Provenance
    idempotency_key: str
    merchant_id: str
    timestamp: datetime

    # Tier 2 — SBN coupling (filled asynchronously)
    sbn_receipt_hash: str | None = None
    sbn_attested_at: datetime | None = None

    # Tier 2 — Combined chain (filled when SBN attestation completes)
    combined_hash: str | None = None
    prev_combined_hash: str | None = None

    # Tier 3 — Blockchain anchor (filled when on-chain anchoring completes)
    anchor_chain: str | None = None  # "hedera" | "solana" | None
    anchor_tx_id: str | None = None
    anchor_consensus_ts: datetime | None = None
    anchored_at: datetime | None = None

    # Extra context
    metadata: dict[str, Any] = field(default_factory=dict)


class ReceiptChain:
    """Builds receipts and maintains the chain for a transaction."""

    def __init__(self):
        self._last_hash: str | None = None

    def build(self, event: TxEvent, *, merchant_id: str, direction: str) -> SonicReceipt:
        """Create a receipt from a transaction event.

        Only populates Tier 1 (app chain). Tiers 2 and 3 are
        backfilled asynchronously by the combined-hash worker
        and blockchain anchor service.
        """
        receipt_id = str(uuid.uuid4())

        # Build the hashable surface — everything that proves this event happened
        surface = {
            "receipt_id": receipt_id,
            "tx_id": event.tx_id,
            "event_type": event.event_type,
            "sequence": event.sequence,
            "from_state": event.from_state.value,
            "to_state": event.to_state.value,
            "amount": str(event.amount) if event.amount else "0",
            "currency": event.currency or "",
            "rail": event.rail or "",
            "direction": direction,
            "idempotency_key": event.idempotency_key or "",
            "merchant_id": merchant_id,
            "timestamp": event.timestamp.isoformat(),
            "prev_receipt_hash": self._last_hash or "",
        }

        receipt_hash = canonical_hash(surface)

        receipt = SonicReceipt(
            receipt_id=receipt_id,
            tx_id=event.tx_id,
            event_type=event.event_type,
            sequence=event.sequence,
            amount=event.amount or Decimal("0"),
            currency=event.currency or "",
            rail=event.rail or "",
            direction=direction,
            receipt_hash=receipt_hash,
            prev_receipt_hash=self._last_hash,
            idempotency_key=event.idempotency_key or receipt_id,
            merchant_id=merchant_id,
            timestamp=event.timestamp,
            metadata=event.metadata,
        )

        self._last_hash = receipt_hash
        return receipt
