"""Transaction archiver — marks old settled/failed transactions for cold storage.

Runs periodically in the drain loop. Finds terminal-state transactions older
than the configured retention period and stamps them with archived_at. Archived
transactions remain queryable but can be partitioned or moved to cold storage
by a separate process.

Terminal states eligible for archival: SETTLED, FAILED, REVERSED.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.config import settings
from sonic.core.engine import TxState
from sonic.models.transaction import TransactionRecord

logger = logging.getLogger(__name__)

_TERMINAL_STATES = {TxState.SETTLED.value, TxState.FAILED.value, TxState.REVERSED.value}


class TransactionArchiver:
    """Stamps old terminal transactions with archived_at for cold-storage migration."""

    def __init__(self, db_session_factory) -> None:
        self._db = db_session_factory

    async def sweep(self, max_batch: int | None = None) -> int:
        """Mark eligible transactions as archived. Returns count archived."""
        batch_size = max_batch or settings.archival_batch_size
        cutoff = datetime.now(timezone.utc) - timedelta(days=settings.archival_retention_days)
        now = datetime.now(timezone.utc)

        async with self._db() as db:
            # Find candidates: terminal state, older than cutoff, not yet archived
            result = await db.execute(
                select(TransactionRecord.id)
                .where(
                    TransactionRecord.state.in_(_TERMINAL_STATES),
                    TransactionRecord.updated_at < cutoff,
                    TransactionRecord.archived_at.is_(None),
                )
                .limit(batch_size)
            )
            tx_ids = [row[0] for row in result.all()]

            if not tx_ids:
                return 0

            # Bulk-stamp archived_at
            await db.execute(
                update(TransactionRecord)
                .where(TransactionRecord.id.in_(tx_ids))
                .values(archived_at=now)
            )
            await db.commit()

        logger.info("Archiver: stamped %d transactions (cutoff=%s)", len(tx_ids), cutoff.date())
        return len(tx_ids)
