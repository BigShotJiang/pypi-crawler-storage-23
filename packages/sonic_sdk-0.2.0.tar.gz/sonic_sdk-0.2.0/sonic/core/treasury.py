"""Treasury — USDC hub normalization and conversion logic.

All inbound payments normalize to USDC as the base treasury asset.
Outbound payouts convert from USDC to the target currency/rail.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from typing import Any


@dataclass
class ConversionQuote:
    """A quoted conversion rate with expiry."""

    from_currency: str
    to_currency: str
    rate: Decimal
    inverse_rate: Decimal
    fee_bps: int  # Basis points (1 bps = 0.01%)
    net_amount: Decimal
    gross_amount: Decimal
    fee_amount: Decimal
    provider: str
    quote_id: str | None = None
    expires_at: str | None = None


class Treasury:
    """Handles normalization to USDC and conversion quotes."""

    def __init__(self, base_asset: str = "USDC"):
        self.base_asset = base_asset

    def needs_conversion(self, currency: str) -> bool:
        return currency.upper() != self.base_asset.upper()

    def quote_inbound(
        self,
        amount: Decimal,
        from_currency: str,
        *,
        rate: Decimal | None = None,
        fee_bps: int = 30,
    ) -> ConversionQuote:
        """Quote inbound conversion: foreign currency → USDC.

        In production, `rate` comes from an FX provider (Circle, liquidity pool, etc.).
        For now, accept it as a parameter.
        """
        if not self.needs_conversion(from_currency):
            return ConversionQuote(
                from_currency=from_currency,
                to_currency=self.base_asset,
                rate=Decimal("1"),
                inverse_rate=Decimal("1"),
                fee_bps=0,
                gross_amount=amount,
                net_amount=amount,
                fee_amount=Decimal("0"),
                provider="passthrough",
            )

        if rate is None:
            raise ValueError(f"Exchange rate required for {from_currency} → {self.base_asset}")

        gross = (amount * rate).quantize(Decimal("0.000001"), rounding=ROUND_HALF_UP)
        fee = (gross * Decimal(fee_bps) / Decimal(10000)).quantize(
            Decimal("0.000001"), rounding=ROUND_HALF_UP
        )
        net = gross - fee

        return ConversionQuote(
            from_currency=from_currency,
            to_currency=self.base_asset,
            rate=rate,
            inverse_rate=(Decimal("1") / rate).quantize(
                Decimal("0.000001"), rounding=ROUND_HALF_UP
            ),
            fee_bps=fee_bps,
            gross_amount=gross,
            net_amount=net,
            fee_amount=fee,
            provider="sonic_treasury",
        )

    def quote_outbound(
        self,
        amount: Decimal,
        to_currency: str,
        *,
        rate: Decimal | None = None,
        fee_bps: int = 30,
    ) -> ConversionQuote:
        """Quote outbound conversion: USDC → target currency."""
        if not self.needs_conversion(to_currency):
            return ConversionQuote(
                from_currency=self.base_asset,
                to_currency=to_currency,
                rate=Decimal("1"),
                inverse_rate=Decimal("1"),
                fee_bps=0,
                gross_amount=amount,
                net_amount=amount,
                fee_amount=Decimal("0"),
                provider="passthrough",
            )

        if rate is None:
            raise ValueError(f"Exchange rate required for {self.base_asset} → {to_currency}")

        gross = (amount * rate).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        fee = (gross * Decimal(fee_bps) / Decimal(10000)).quantize(
            Decimal("0.01"), rounding=ROUND_HALF_UP
        )
        net = gross - fee

        return ConversionQuote(
            from_currency=self.base_asset,
            to_currency=to_currency,
            rate=rate,
            inverse_rate=(Decimal("1") / rate).quantize(
                Decimal("0.000001"), rounding=ROUND_HALF_UP
            ),
            fee_bps=fee_bps,
            gross_amount=gross,
            net_amount=net,
            fee_amount=fee,
            provider="sonic_treasury",
        )
