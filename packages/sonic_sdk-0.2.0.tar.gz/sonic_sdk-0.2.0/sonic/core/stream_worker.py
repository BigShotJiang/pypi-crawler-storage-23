"""Stream worker — manages windowed accrual and micro-payouts for PayStreams.

The stream worker is the accrual-first counterpart to Dominion's
decomposition-based streaming. Instead of splitting a known payout into
intervals, it accumulates work events into earned entitlements and
triggers micro-payouts at window boundaries.

Data flow:
  work_event → accrue() → window fills up
  window_close (30 min) → evaluate policy → compute disbursement
    → trigger micro-payout → emit receipt → update g_ewma

Key operations:
  open_stream()   — create PayStream + StreamSession + SBN slot
  accrue()        — record work event earnings into current window
  close_window()  — finalize window, evaluate policy, trigger payout
  pause()         — manual pause (e.g., break)
  resume()        — resume from pause
  freeze()        — policy-driven freeze (finish step, emit proof, hold)
  unfreeze()      — resume from freeze (new slot)
  close_stream()  — terminal: reconcile and close
  reconcile()     — fold windows vs. settlement confirmations
"""

from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.core.receipt_builder import canonical_hash
from sonic.core.stream_policy import (
    PolicyState,
    PolicyThresholds,
    compute_disbursement,
    compute_g_ewma,
    evaluate_policy,
    get_policy_knobs,
)
from sonic.models.pay_stream import PayStream
from sonic.models.receipt import ReceiptRecord
from sonic.models.stream_window import StreamWindow

logger = logging.getLogger(__name__)


class StreamWorker:
    """Manages PayStream lifecycle, windowed accrual, and micro-payouts."""

    def __init__(
        self,
        db_session_factory: Any,
        sbn_client: Any | None = None,
        payout_executor: Any | None = None,
        emitter: Any | None = None,
        treasury: Any | None = None,
        float_guard: Any | None = None,
    ) -> None:
        self._db = db_session_factory
        self._sbn = sbn_client
        self._executor = payout_executor
        self._emitter = emitter
        self._treasury = treasury
        self._float_guard = float_guard

    # ── Stream lifecycle ─────────────────────────────────────────────────

    async def open_stream(
        self,
        *,
        merchant_id: str,
        payer_id: str,
        payee_id: str,
        currency: str = "USD",
        rail: str = "stripe_transfer",
        rate_amount: Decimal = Decimal("0"),
        rate_unit: str = "per_window",
        cadence_seconds: int = 1800,
        metadata: dict[str, Any] | None = None,
    ) -> PayStream:
        """Create a new PayStream with an SBN-backed slot.

        Opens the underlying StreamSession and SBN slot, then creates
        the PayStream entity and its first accrual window.
        """
        async with self._db() as session:
            from sonic.models.stream_session import StreamSession

            # Open SBN slot via StreamSession
            sbn_slot_id: str | None = None
            stream_session = StreamSession(
                merchant_id=merchant_id,
                worker_id=payee_id,
                total_amount=Decimal("0"),  # Accrual-first: amount unknown upfront
                currency=currency,
                interval_seconds=cadence_seconds,
                duration_seconds=0,  # Open-ended
                status="open",
                metadata_json=json.dumps(metadata) if metadata else None,
            )

            if self._sbn and self._sbn.active:
                slot_result = self._sbn.open_slot(
                    worker_id=payee_id,
                    task_type="sonic.settlement",
                    metadata={
                        "stream": True,
                        "pay_stream": True,
                        "merchant_id": merchant_id,
                        "payer_id": payer_id,
                        "payee_id": payee_id,
                        "currency": currency,
                        "generation_interval": cadence_seconds,
                    },
                )
                if slot_result:
                    sbn_slot_id = slot_result.get("slot_id") or slot_result.get("id")
                    stream_session.sbn_slot_id = sbn_slot_id

            session.add(stream_session)
            await session.flush()

            now = datetime.now(timezone.utc)
            epoch_key = now.strftime("%Y-%m-%d")

            pay_stream = PayStream(
                merchant_id=merchant_id,
                payer_id=payer_id,
                payee_id=payee_id,
                stream_session_id=stream_session.id,
                sbn_slot_id=sbn_slot_id,
                currency=currency,
                rail=rail,
                rate_amount=rate_amount,
                rate_unit=rate_unit,
                status="active",
                policy_state=PolicyState.NORMAL.value,
                cadence_seconds=cadence_seconds,
                current_window_start=now,
                current_epoch_key=epoch_key,
                metadata_json=json.dumps(metadata) if metadata else None,
            )
            session.add(pay_stream)
            await session.flush()

            # Create the first window
            window = StreamWindow(
                pay_stream_id=pay_stream.id,
                window_number=0,
                epoch_key=epoch_key,
                window_start=now,
                status="open",
                currency=currency,
                sbn_slot_id=sbn_slot_id,
            )
            session.add(window)
            await session.commit()
            await session.refresh(pay_stream)

            logger.info(
                "PayStream opened: id=%s payer=%s payee=%s slot=%s",
                pay_stream.id, payer_id, payee_id, sbn_slot_id,
            )
            return pay_stream

    async def accrue(
        self,
        pay_stream_id: str,
        *,
        units: Decimal,
        unit_price: Decimal | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> StreamWindow:
        """Record work event earnings into the current open window.

        If unit_price is not provided, uses the stream's rate_amount.
        Returns the updated window.
        """
        async with self._db() as session:
            stream = await self._load_stream(session, pay_stream_id)
            if stream.status != "active":
                raise ValueError(f"Cannot accrue: stream {pay_stream_id} is {stream.status}")

            # Get current open window
            window = await self._current_window(session, pay_stream_id)
            if window is None:
                raise ValueError(f"No open window for stream {pay_stream_id}")

            price = unit_price if unit_price is not None else stream.rate_amount
            earned = (units * price).quantize(Decimal("0.000001"))

            window.units += units
            window.unit_price = price
            window.earned_amount += earned

            stream.current_window_earned += earned
            stream.total_earned += earned

            # Append to work_events_json
            events = json.loads(window.work_events_json) if window.work_events_json else []
            events.append({
                "units": str(units),
                "price": str(price),
                "earned": str(earned),
                "ts": datetime.now(timezone.utc).isoformat(),
                **(metadata or {}),
            })
            window.work_events_json = json.dumps(events)

            await session.commit()
            await session.refresh(window)

            logger.debug(
                "Accrued %.6f to stream %s window %d (total earned=%.6f)",
                earned, pay_stream_id, window.window_number, stream.total_earned,
            )
            return window

    async def close_window(
        self,
        pay_stream_id: str,
        *,
        gec_y: int = 0,
        gec_x: int = 0,
    ) -> dict[str, Any]:
        """Close the current window, evaluate policy, and trigger payout.

        Returns a dict with window details, policy state, and payout result.
        """
        async with self._db() as session:
            stream = await self._load_stream(session, pay_stream_id)
            if stream.status not in ("active", "paused"):
                raise ValueError(f"Cannot close window: stream is {stream.status}")

            window = await self._current_window(session, pay_stream_id)
            if window is None:
                raise ValueError(f"No open window for stream {pay_stream_id}")

            now = datetime.now(timezone.utc)

            # Validate GEC inputs
            if gec_y < 0 or gec_x < 0:
                raise ValueError("GEC counts must be non-negative")
            if gec_x > 0 and gec_y > gec_x:
                raise ValueError(
                    f"gec_y ({gec_y}) cannot exceed gec_x ({gec_x})"
                )

            # Compute GEC score for this window (clamped to [0, 1])
            if gec_x > 0:
                raw_score = Decimal(str(gec_y / gec_x))
                gec_score = max(Decimal("0"), min(Decimal("1"), raw_score))
            else:
                gec_score = Decimal("0.5")  # Neutral default

            window.gec_y = gec_y
            window.gec_x = gec_x
            window.gec_score = gec_score

            # Update g_ewma
            new_ewma = compute_g_ewma(stream.g_ewma, gec_score, stream.g_ewma_alpha)
            stream.g_ewma = new_ewma

            # Evaluate policy transition
            old_state = PolicyState(stream.policy_state)
            thresholds = PolicyThresholds(
                prime=stream.threshold_prime,
                risk=stream.threshold_risk,
                frozen=stream.threshold_frozen,
            )
            new_state = evaluate_policy(old_state, new_ewma, thresholds)

            # Compute disbursement based on new policy
            knobs = get_policy_knobs(new_state)
            disbursed, holdback = compute_disbursement(window.earned_amount, knobs)

            # Close the window
            window.status = "closed"
            window.window_end = now
            window.closed_at = now
            window.disbursed_amount = disbursed
            window.holdback_amount = holdback
            window.policy_state_at_close = new_state.value

            # Update stream totals
            stream.total_disbursed += disbursed
            stream.total_held += holdback
            stream.window_count += 1
            stream.policy_state = new_state.value
            stream.current_window_earned = Decimal("0")

            # Handle policy state change: freeze if needed
            payout_result = None
            if new_state == PolicyState.FROZEN and old_state != PolicyState.FROZEN:
                stream.status = "frozen"
                stream.frozen_at = now
                logger.warning(
                    "Stream %s FROZEN: g_ewma=%.4f (was %s)",
                    pay_stream_id, new_ewma, old_state.value,
                )

            # Trigger micro-payout if policy allows
            if disbursed > 0 and knobs.can_disburse:
                payout_result = await self._trigger_payout(
                    session, stream, window, disbursed,
                )

                # If payout failed, reverse disbursement to holdback
                if payout_result and payout_result.get("status") in ("failed", "error"):
                    stream.total_disbursed -= disbursed
                    stream.total_held += disbursed
                    window.holdback_amount += disbursed
                    window.disbursed_amount = Decimal("0")
                    disbursed = Decimal("0")
                    logger.warning(
                        "Payout reversed for stream %s window %d — moved to holdback for retry",
                        pay_stream_id, window.window_number,
                    )

            # Build receipt for window close (creates audit trail + SBN coupling)
            receipt_hash = await self._build_window_receipt(
                session, stream, window, disbursed, payout_result,
            )

            # Open the next window (unless frozen or closed)
            next_window = None
            if stream.status == "active":
                next_window = await self._open_next_window(session, stream, window, now)

            await session.commit()

            result = {
                "window_id": window.id,
                "window_number": window.window_number,
                "earned": str(window.earned_amount),
                "disbursed": str(disbursed),
                "holdback": str(holdback),
                "gec_score": str(gec_score),
                "g_ewma": str(new_ewma),
                "old_policy": old_state.value,
                "new_policy": new_state.value,
                "payout": payout_result,
                "receipt_hash": receipt_hash,
                "next_window_id": next_window.id if next_window else None,
            }

            logger.info(
                "Window %d closed for stream %s: earned=%.2f disbursed=%.2f "
                "policy=%s→%s g_ewma=%.4f receipt=%s",
                window.window_number, pay_stream_id,
                window.earned_amount, disbursed,
                old_state.value, new_state.value, new_ewma,
                receipt_hash,
            )

            if self._emitter:
                try:
                    from sonic.events.types import EventType
                    await self._emitter.emit(EventType.STREAM_WINDOW_CLOSED, result)
                except Exception:
                    pass  # Non-blocking

            return result

    async def pause(self, pay_stream_id: str) -> PayStream:
        """Manually pause the stream (e.g., worker taking a break)."""
        async with self._db() as session:
            stream = await self._load_stream(session, pay_stream_id)
            if stream.status != "active":
                raise ValueError(f"Cannot pause: stream is {stream.status}")

            now = datetime.now(timezone.utc)
            stream.status = "paused"
            stream.paused_at = now

            # Mark current window as skipped if no earnings
            window = await self._current_window(session, pay_stream_id)
            if window and window.earned_amount == 0:
                window.status = "skipped"
                window.window_end = now
                window.closed_at = now

            await session.commit()
            await session.refresh(stream)
            logger.info("Stream %s paused", pay_stream_id)
            return stream

    async def resume(self, pay_stream_id: str) -> PayStream:
        """Resume a paused stream."""
        async with self._db() as session:
            stream = await self._load_stream(session, pay_stream_id)
            if stream.status != "paused":
                raise ValueError(f"Cannot resume: stream is {stream.status}")

            now = datetime.now(timezone.utc)
            stream.status = "active"
            stream.paused_at = None

            # Open a fresh window
            last_window = await self._latest_window(session, pay_stream_id)
            window_num = (last_window.window_number + 1) if last_window else 0

            window = StreamWindow(
                pay_stream_id=pay_stream_id,
                window_number=window_num,
                epoch_key=now.strftime("%Y-%m-%d"),
                window_start=now,
                status="open",
                currency=stream.currency,
                sbn_slot_id=stream.sbn_slot_id,
            )
            session.add(window)
            stream.current_window_start = now
            stream.current_window_earned = Decimal("0")

            await session.commit()
            await session.refresh(stream)
            logger.info("Stream %s resumed, new window %d", pay_stream_id, window_num)
            return stream

    async def freeze(self, pay_stream_id: str, *, reason: str = "") -> dict[str, Any]:
        """Policy-driven freeze: finish current step, emit interruption proof, hold.

        Unlike pause (manual), freeze is triggered by the policy engine
        when g_ewma drops below the frozen threshold. The current window
        is closed with an interruption proof, and a new SBN slot will be
        opened on unfreeze.
        """
        async with self._db() as session:
            stream = await self._load_stream(session, pay_stream_id)
            if stream.status in ("frozen", "closed"):
                raise ValueError(f"Cannot freeze: stream is {stream.status}")

            now = datetime.now(timezone.utc)

            # Close current window with interruption marker
            window = await self._current_window(session, pay_stream_id)
            interruption_hash = None
            if window:
                window.status = "closed"
                window.window_end = now
                window.closed_at = now
                window.policy_state_at_close = PolicyState.FROZEN.value

                # Emit interruption proof to SBN
                if self._sbn and self._sbn.active and stream.sbn_slot_id:
                    try:
                        from sonic.core.receipt_builder import canonical_hash
                        proof_data = {
                            "type": "stream_interruption",
                            "pay_stream_id": pay_stream_id,
                            "window_number": window.window_number,
                            "earned_at_freeze": str(window.earned_amount),
                            "reason": reason,
                            "frozen_at": now.isoformat(),
                        }
                        interruption_hash = canonical_hash(proof_data)
                        window.sbn_block_hash = interruption_hash
                    except Exception:
                        logger.warning("Failed to compute interruption hash", exc_info=True)

            stream.status = "frozen"
            stream.frozen_at = now

            # Close the SBN slot early
            if self._sbn and self._sbn.active and stream.sbn_slot_id:
                try:
                    self._sbn.close_slot(stream.sbn_slot_id)
                except Exception:
                    logger.warning("Failed to close SBN slot on freeze", exc_info=True)

            await session.commit()
            logger.warning(
                "Stream %s FROZEN: reason=%s earned_at_freeze=%s",
                pay_stream_id, reason,
                str(window.earned_amount) if window else "0",
            )

            return {
                "pay_stream_id": pay_stream_id,
                "status": "frozen",
                "interruption_hash": interruption_hash,
                "frozen_at": now.isoformat(),
                "reason": reason,
            }

    async def unfreeze(self, pay_stream_id: str) -> PayStream:
        """Resume from freeze with a new SBN slot."""
        async with self._db() as session:
            stream = await self._load_stream(session, pay_stream_id)
            if stream.status != "frozen":
                raise ValueError(f"Cannot unfreeze: stream is {stream.status}")

            now = datetime.now(timezone.utc)

            # Open a new SBN slot
            new_slot_id: str | None = None
            if self._sbn and self._sbn.active:
                slot_result = self._sbn.open_slot(
                    worker_id=stream.payee_id,
                    task_type="sonic.settlement",
                    metadata={
                        "stream": True,
                        "pay_stream": True,
                        "pay_stream_id": pay_stream_id,
                        "unfrozen_at": now.isoformat(),
                        "generation_interval": stream.cadence_seconds,
                    },
                )
                if slot_result:
                    new_slot_id = slot_result.get("slot_id") or slot_result.get("id")

            stream.status = "active"
            stream.sbn_slot_id = new_slot_id
            stream.frozen_at = None

            # Open a fresh window
            last_window = await self._latest_window(session, pay_stream_id)
            window_num = (last_window.window_number + 1) if last_window else 0

            window = StreamWindow(
                pay_stream_id=pay_stream_id,
                window_number=window_num,
                epoch_key=now.strftime("%Y-%m-%d"),
                window_start=now,
                status="open",
                currency=stream.currency,
                sbn_slot_id=new_slot_id,
            )
            session.add(window)
            stream.current_window_start = now
            stream.current_window_earned = Decimal("0")

            await session.commit()
            await session.refresh(stream)
            logger.info(
                "Stream %s unfrozen, new slot=%s window=%d",
                pay_stream_id, new_slot_id, window_num,
            )
            return stream

    async def close_stream(self, pay_stream_id: str) -> dict[str, Any]:
        """Terminal close: finalize all windows, reconcile, close SBN slot.

        Returns reconciliation summary.
        """
        async with self._db() as session:
            stream = await self._load_stream(session, pay_stream_id)
            if stream.status == "closed":
                raise ValueError("Stream already closed")

            now = datetime.now(timezone.utc)

            # Close any open window
            window = await self._current_window(session, pay_stream_id)
            if window:
                window.status = "closed"
                window.window_end = now
                window.closed_at = now
                # Disburse remaining earned (use current policy)
                knobs = get_policy_knobs(PolicyState(stream.policy_state))
                disbursed, holdback = compute_disbursement(window.earned_amount, knobs)
                window.disbursed_amount = disbursed
                window.holdback_amount = holdback
                stream.total_disbursed += disbursed
                stream.total_held += holdback

            # Close SBN slot
            merkle_root = None
            if self._sbn and self._sbn.active and stream.sbn_slot_id:
                try:
                    close_result = self._sbn.close_slot(stream.sbn_slot_id)
                    if close_result:
                        merkle_root = close_result.get("merkle_root") or close_result.get("root_hash")
                except Exception:
                    logger.warning("Failed to close SBN slot on stream close", exc_info=True)

            # Close stream session
            from sonic.models.stream_session import StreamSession
            if stream.stream_session_id:
                sess_result = await session.execute(
                    select(StreamSession).where(StreamSession.id == stream.stream_session_id)
                )
                stream_session = sess_result.scalar_one_or_none()
                if stream_session and stream_session.status == "open":
                    stream_session.status = "closed"
                    stream_session.merkle_root = merkle_root
                    stream_session.closed_at = now

            stream.status = "closed"
            stream.closed_at = now

            # Reconciliation: count windows, compute delta
            windows_result = await session.execute(
                select(StreamWindow).where(
                    StreamWindow.pay_stream_id == pay_stream_id,
                    StreamWindow.status == "closed",
                )
            )
            all_windows = windows_result.scalars().all()
            total_window_earned = sum(w.earned_amount for w in all_windows)
            total_window_disbursed = sum(w.disbursed_amount for w in all_windows)
            total_window_held = sum(w.holdback_amount for w in all_windows)

            # Build reconciliation receipt — terminal summary of the stream
            reconciliation_delta = stream.total_earned - total_window_disbursed - total_window_held

            prev_result = await session.execute(
                select(ReceiptRecord.receipt_hash)
                .where(ReceiptRecord.tx_id == stream.id)
                .order_by(ReceiptRecord.sequence.desc())
                .limit(1)
            )
            prev_hash = prev_result.scalar_one_or_none()

            recon_receipt_id = f"rcpt_{uuid.uuid4().hex[:24]}"
            recon_surface = {
                "receipt_id": recon_receipt_id,
                "tx_id": stream.id,
                "event_type": "stream.closed",
                "sequence": stream.window_count,
                "from_state": "active",
                "to_state": "closed",
                "amount": str(stream.total_earned),
                "currency": stream.currency,
                "rail": stream.rail,
                "direction": "outbound",
                "idempotency_key": f"{stream.id}:close",
                "merchant_id": stream.merchant_id,
                "timestamp": now.isoformat(),
                "prev_receipt_hash": prev_hash or "",
                "windows_closed": len(all_windows),
                "total_disbursed": str(total_window_disbursed),
                "total_held": str(total_window_held),
                "reconciliation_delta": str(reconciliation_delta),
                "final_g_ewma": str(stream.g_ewma),
                "merkle_root": merkle_root or "",
            }
            recon_hash = canonical_hash(recon_surface)

            session.add(ReceiptRecord(
                receipt_id=recon_receipt_id,
                tx_id=stream.id,
                event_type="stream.closed",
                sequence=stream.window_count,
                amount=stream.total_earned,
                currency=stream.currency,
                rail=stream.rail,
                direction="outbound",
                receipt_hash=recon_hash,
                prev_receipt_hash=prev_hash,
                idempotency_key=f"{stream.id}:close",
                merchant_id=stream.merchant_id,
                couple_status="stream_coupled" if stream.sbn_slot_id else "pending",
                sbn_slot_id=stream.sbn_slot_id,
            ))

            await session.commit()

            # SBN slot was already closed pre-commit (to capture merkle_root).
            # Log the reconciliation receipt hash for audit trail.
            if merkle_root:
                logger.info(
                    "Stream %s SBN slot closed: merkle_root=%s recon_receipt=%s",
                    pay_stream_id, merkle_root, recon_hash,
                )

            summary = {
                "pay_stream_id": pay_stream_id,
                "status": "closed",
                "merkle_root": merkle_root,
                "reconciliation_receipt_hash": recon_hash,
                "windows_closed": len(all_windows),
                "total_earned": str(stream.total_earned),
                "total_disbursed": str(total_window_disbursed),
                "total_held": str(total_window_held),
                "reconciliation_delta": str(reconciliation_delta),
                "final_g_ewma": str(stream.g_ewma),
                "final_policy": stream.policy_state,
                "closed_at": now.isoformat(),
            }

            logger.info(
                "Stream %s closed: %d windows, earned=%.2f disbursed=%.2f held=%.2f "
                "recon_receipt=%s",
                pay_stream_id, len(all_windows),
                stream.total_earned, total_window_disbursed, total_window_held,
                recon_hash,
            )

            if self._emitter:
                try:
                    from sonic.events.types import EventType
                    await self._emitter.emit(EventType.STREAM_CLOSED, summary)
                except Exception:
                    pass  # Non-blocking

            return summary

    # ── Internal helpers ─────────────────────────────────────────────────

    async def _load_stream(self, session: AsyncSession, pay_stream_id: str) -> PayStream:
        result = await session.execute(
            select(PayStream).where(PayStream.id == pay_stream_id)
        )
        stream = result.scalar_one_or_none()
        if stream is None:
            raise ValueError(f"PayStream not found: {pay_stream_id}")
        return stream

    async def _current_window(
        self, session: AsyncSession, pay_stream_id: str
    ) -> StreamWindow | None:
        result = await session.execute(
            select(StreamWindow)
            .where(
                StreamWindow.pay_stream_id == pay_stream_id,
                StreamWindow.status == "open",
            )
            .order_by(StreamWindow.window_number.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()

    async def _latest_window(
        self, session: AsyncSession, pay_stream_id: str
    ) -> StreamWindow | None:
        result = await session.execute(
            select(StreamWindow)
            .where(StreamWindow.pay_stream_id == pay_stream_id)
            .order_by(StreamWindow.window_number.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()

    async def _open_next_window(
        self,
        session: AsyncSession,
        stream: PayStream,
        prev_window: StreamWindow,
        now: datetime,
    ) -> StreamWindow:
        """Open the next accrual window."""
        epoch_key = now.strftime("%Y-%m-%d")
        window = StreamWindow(
            pay_stream_id=stream.id,
            window_number=prev_window.window_number + 1,
            epoch_key=epoch_key,
            window_start=now,
            status="open",
            currency=stream.currency,
            sbn_slot_id=stream.sbn_slot_id,
        )
        session.add(window)
        stream.current_window_start = now
        stream.current_window_earned = Decimal("0")
        stream.current_epoch_key = epoch_key
        return window

    async def _trigger_payout(
        self,
        session: AsyncSession,
        stream: PayStream,
        window: StreamWindow,
        amount: Decimal,
    ) -> dict[str, Any] | None:
        """Trigger a micro-payout for a closed window.

        Handles treasury conversion if the stream currency differs from
        the base asset. Delegates to PayoutExecutor if available,
        otherwise records the intent for later reconciliation.
        """
        if self._executor is None:
            logger.info(
                "No payout executor — recording disbursement intent: "
                "stream=%s window=%d amount=%.6f",
                stream.id, window.window_number, amount,
            )
            return {"status": "recorded", "amount": str(amount)}

        # Treasury conversion for non-base-asset payouts
        payout_amount = amount
        payout_currency = stream.currency
        if self._treasury and self._treasury.needs_conversion(stream.currency):
            try:
                quote = self._treasury.quote_outbound(
                    amount, stream.currency, rate=Decimal("1"),
                )
                payout_amount = quote.net_amount
                payout_currency = quote.to_currency
            except Exception as exc:
                logger.warning(
                    "Treasury conversion failed for stream %s: %s",
                    stream.id, exc,
                )
                # Fall back to original currency — provider may handle it

        from sonic.core.payout_executor import PayoutInstruction as ExecInstruction

        instruction = ExecInstruction(
            tx_id=f"{stream.id}:w{window.window_number}",
            recipient_id=stream.payee_id,
            amount=payout_amount,
            currency=payout_currency,
            rail=stream.rail,
            idempotency_key=f"{stream.id}:w{window.window_number}",
            metadata={
                "pay_stream_id": stream.id,
                "window_number": window.window_number,
                "type": "stream_micro_payout",
            },
        )

        # Float guard gate — check treasury liquidity before disbursing
        float_committed = False
        if self._float_guard is not None:
            from sonic._vendor.dominion.core.float_guard import FloatStatus

            check = await self._float_guard.check(float(payout_amount))
            if check.status == FloatStatus.BLOCKED:
                logger.warning(
                    "Float BLOCKED for stream %s window %d: %s",
                    stream.id, window.window_number, check.reason,
                )
                return {
                    "status": "float_blocked",
                    "amount": str(payout_amount),
                    "reason": check.reason,
                }
            self._float_guard.commit(float(payout_amount))
            float_committed = True

        try:
            result = await self._executor.execute(instruction)
            if result.success:
                window.payout_tx_id = instruction.tx_id
            elif float_committed:
                # Release float on payout failure so it's not locked
                self._float_guard.release(float(payout_amount))

            return {
                "status": "success" if result.success else "failed",
                "amount": str(payout_amount),
                "currency": payout_currency,
                "provider": result.provider,
                "provider_ref": result.provider_ref,
                "error": result.error,
            }
        except Exception as exc:
            if float_committed:
                self._float_guard.release(float(payout_amount))
            logger.error(
                "Micro-payout failed for stream %s window %d: %s",
                stream.id, window.window_number, exc,
            )
            return {"status": "error", "amount": str(amount), "error": str(exc)}

    async def _build_window_receipt(
        self,
        session: AsyncSession,
        stream: PayStream,
        window: StreamWindow,
        disbursed: Decimal,
        payout_result: dict[str, Any] | None,
    ) -> str:
        """Build a cryptographic receipt for a closed window.

        Creates a ReceiptRecord chained to previous stream receipts,
        sets window.receipt_hash, and routes via couple_status for SBN.
        Returns the receipt hash.
        """
        # Load previous receipt in this stream's chain
        prev_result = await session.execute(
            select(ReceiptRecord.receipt_hash)
            .where(ReceiptRecord.tx_id == stream.id)
            .order_by(ReceiptRecord.sequence.desc())
            .limit(1)
        )
        prev_hash = prev_result.scalar_one_or_none()

        receipt_id = f"rcpt_{uuid.uuid4().hex[:24]}"
        now = datetime.now(timezone.utc)

        provider_ref = ""
        if payout_result and payout_result.get("provider_ref"):
            provider_ref = payout_result["provider_ref"]

        surface = {
            "receipt_id": receipt_id,
            "tx_id": stream.id,
            "event_type": "stream.window.closed",
            "sequence": window.window_number,
            "from_state": "window_open",
            "to_state": "window_closed",
            "amount": str(disbursed),
            "currency": stream.currency,
            "rail": stream.rail,
            "direction": "outbound",
            "idempotency_key": f"{stream.id}:w{window.window_number}",
            "merchant_id": stream.merchant_id,
            "timestamp": now.isoformat(),
            "prev_receipt_hash": prev_hash or "",
            "window_number": window.window_number,
            "earned_amount": str(window.earned_amount),
            "holdback_amount": str(window.holdback_amount),
            "policy_state": window.policy_state_at_close or "",
            "g_ewma": str(stream.g_ewma),
            "provider_ref": provider_ref,
        }

        receipt_hash = canonical_hash(surface)

        session.add(ReceiptRecord(
            receipt_id=receipt_id,
            tx_id=stream.id,
            event_type="stream.window.closed",
            sequence=window.window_number,
            amount=disbursed,
            currency=stream.currency,
            rail=stream.rail,
            direction="outbound",
            receipt_hash=receipt_hash,
            prev_receipt_hash=prev_hash,
            idempotency_key=f"{stream.id}:w{window.window_number}",
            merchant_id=stream.merchant_id,
            couple_status="stream_coupled" if stream.sbn_slot_id else "pending",
            sbn_slot_id=stream.sbn_slot_id,
        ))

        window.receipt_hash = receipt_hash
        return receipt_hash

    # ── Background tasks ─────────────────────────────────────────────────

    async def retry_failed_payouts(self, max_batch: int = 10) -> int:
        """Retry micro-payouts for windows where disbursement was reversed.

        Finds closed windows with earned_amount > 0, disbursed_amount == 0,
        and no successful payout_tx_id — these are windows where the payout
        failed and was reversed to holdback. Skips frozen streams.

        Called from the drain loop. Returns number of successful retries.
        """
        async with self._db() as session:
            result = await session.execute(
                select(StreamWindow.id, StreamWindow.pay_stream_id)
                .join(PayStream, PayStream.id == StreamWindow.pay_stream_id)
                .where(
                    StreamWindow.status == "closed",
                    StreamWindow.earned_amount > 0,
                    StreamWindow.disbursed_amount == 0,
                    StreamWindow.payout_tx_id.is_(None),
                    StreamWindow.holdback_amount > 0,
                    PayStream.status.notin_(["frozen", "closed"]),
                    PayStream.policy_state != PolicyState.FROZEN.value,
                )
                .limit(max_batch)
            )
            candidates = result.all()

        if not candidates:
            return 0

        retried = 0
        for window_id, stream_id in candidates:
            try:
                if await self._retry_single_payout(window_id, stream_id):
                    retried += 1
            except Exception:
                logger.warning(
                    "Payout retry failed: window=%s stream=%s",
                    window_id, stream_id, exc_info=True,
                )

        if retried:
            logger.info("Retried %d/%d failed micro-payouts", retried, len(candidates))
        return retried

    async def _retry_single_payout(self, window_id: str, stream_id: str) -> bool:
        """Retry a single failed micro-payout. Returns True on success."""
        async with self._db() as session:
            stream = await self._load_stream(session, stream_id)
            result = await session.execute(
                select(StreamWindow).where(StreamWindow.id == window_id)
            )
            window = result.scalar_one_or_none()
            if window is None or window.disbursed_amount > 0:
                return False  # Already retried or state changed

            # Re-evaluate: use current policy to compute what should be disbursed
            knobs = get_policy_knobs(PolicyState(stream.policy_state))
            if not knobs.can_disburse:
                return False  # Policy currently forbids payouts

            disbursed, holdback = compute_disbursement(window.earned_amount, knobs)
            if disbursed <= 0:
                return False

            payout_result = await self._trigger_payout(session, stream, window, disbursed)

            if payout_result and payout_result.get("status") == "success":
                # Move from holdback back to disbursed
                window.disbursed_amount = disbursed
                window.holdback_amount = window.earned_amount - disbursed
                stream.total_disbursed += disbursed
                stream.total_held -= disbursed
                await session.commit()

                logger.info(
                    "Payout retry succeeded: stream=%s window=%d amount=%.6f",
                    stream_id, window.window_number, disbursed,
                )
                return True

            return False

    async def release_holdback(self, pay_stream_id: str) -> dict[str, Any]:
        """Release accumulated holdback for a closed stream.

        Can only be called on a closed stream. Triggers a single payout
        for the total held amount, builds a receipt, and zeroes the holdback.

        Returns a summary dict with payout status and amounts.
        """
        async with self._db() as session:
            stream = await self._load_stream(session, pay_stream_id)
            if stream.status != "closed":
                raise ValueError(
                    f"Cannot release holdback: stream is {stream.status} (must be closed)"
                )
            if stream.total_held <= 0:
                raise ValueError("No holdback to release")

            held = stream.total_held
            now = datetime.now(timezone.utc)

            # Trigger payout for full holdback amount
            payout_result: dict[str, Any] | None = None
            if self._executor is not None:
                payout_amount = held
                payout_currency = stream.currency
                if self._treasury and self._treasury.needs_conversion(stream.currency):
                    try:
                        quote = self._treasury.quote_outbound(
                            held, stream.currency, rate=Decimal("1"),
                        )
                        payout_amount = quote.net_amount
                        payout_currency = quote.to_currency
                    except Exception as exc:
                        logger.warning(
                            "Treasury conversion failed for holdback release stream %s: %s",
                            pay_stream_id, exc,
                        )

                from sonic.core.payout_executor import PayoutInstruction as ExecInstruction

                instruction = ExecInstruction(
                    tx_id=f"{stream.id}:holdback_release",
                    recipient_id=stream.payee_id,
                    amount=payout_amount,
                    currency=payout_currency,
                    rail=stream.rail,
                    idempotency_key=f"{stream.id}:holdback_release",
                    metadata={
                        "pay_stream_id": stream.id,
                        "type": "holdback_release",
                        "amount_held": str(held),
                    },
                )

                try:
                    result = await self._executor.execute(instruction)
                    payout_result = {
                        "status": "success" if result.success else "failed",
                        "amount": str(payout_amount),
                        "currency": payout_currency,
                        "provider": result.provider,
                        "provider_ref": result.provider_ref,
                        "error": result.error,
                    }
                except Exception as exc:
                    payout_result = {"status": "error", "error": str(exc)}

                if payout_result.get("status") != "success":
                    raise ValueError(
                        f"Holdback release payout failed: {payout_result.get('error', 'unknown')}"
                    )
            else:
                payout_result = {"status": "recorded", "amount": str(held)}

            # Update stream totals
            stream.total_disbursed += held
            stream.total_held = Decimal("0")

            # Build holdback release receipt
            prev_result = await session.execute(
                select(ReceiptRecord.receipt_hash)
                .where(ReceiptRecord.tx_id == stream.id)
                .order_by(ReceiptRecord.sequence.desc())
                .limit(1)
            )
            prev_hash = prev_result.scalar_one_or_none()

            release_receipt_id = f"rcpt_{uuid.uuid4().hex[:24]}"
            surface = {
                "receipt_id": release_receipt_id,
                "tx_id": stream.id,
                "event_type": "stream.holdback_released",
                "sequence": stream.window_count + 1,
                "from_state": "closed",
                "to_state": "closed",
                "amount": str(held),
                "currency": stream.currency,
                "rail": stream.rail,
                "direction": "outbound",
                "idempotency_key": f"{stream.id}:holdback_release",
                "merchant_id": stream.merchant_id,
                "timestamp": now.isoformat(),
                "prev_receipt_hash": prev_hash or "",
                "provider_ref": payout_result.get("provider_ref", ""),
            }
            release_hash = canonical_hash(surface)

            session.add(ReceiptRecord(
                receipt_id=release_receipt_id,
                tx_id=stream.id,
                event_type="stream.holdback_released",
                sequence=stream.window_count + 1,
                amount=held,
                currency=stream.currency,
                rail=stream.rail,
                direction="outbound",
                receipt_hash=release_hash,
                prev_receipt_hash=prev_hash,
                idempotency_key=f"{stream.id}:holdback_release",
                merchant_id=stream.merchant_id,
                couple_status="stream_coupled" if stream.sbn_slot_id else "pending",
                sbn_slot_id=stream.sbn_slot_id,
            ))

            await session.commit()

            summary = {
                "pay_stream_id": pay_stream_id,
                "holdback_released": str(held),
                "receipt_hash": release_hash,
                "payout": payout_result,
                "total_disbursed": str(stream.total_disbursed),
                "total_held": str(stream.total_held),
            }

            logger.info(
                "Holdback released for stream %s: amount=%.6f receipt=%s",
                pay_stream_id, held, release_hash,
            )

            if self._emitter:
                try:
                    from sonic.events.types import EventType
                    await self._emitter.emit(EventType.STREAM_CLOSED, summary)
                except Exception:
                    pass

            return summary

    async def auto_close_expired_windows(self, max_batch: int = 20) -> int:
        """Close windows that have exceeded their stream's cadence time.

        Called from the drain loop. Returns the number of windows closed.
        """
        now = datetime.now(timezone.utc)

        async with self._db() as session:
            result = await session.execute(
                select(PayStream.id, PayStream.cadence_seconds, StreamWindow.window_start)
                .join(StreamWindow, StreamWindow.pay_stream_id == PayStream.id)
                .where(
                    PayStream.status == "active",
                    StreamWindow.status == "open",
                )
                .limit(max_batch)
            )
            candidates = result.all()

        closed = 0
        for stream_id, cadence, window_start in candidates:
            if window_start and now > window_start + timedelta(seconds=cadence):
                try:
                    await self.close_window(stream_id, gec_y=0, gec_x=0)
                    closed += 1
                except Exception:
                    logger.warning(
                        "Auto-close failed for stream %s", stream_id, exc_info=True
                    )

        if closed:
            logger.info("Auto-closed %d expired windows", closed)
        return closed
