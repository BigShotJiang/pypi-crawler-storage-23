"""Settlement state machine — the core of Sonic.

A transaction moves through states with strict, auditable transitions.
Each transition produces an immutable event that gets receipt-chained
and optionally attested by SBN.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any


class TxState(str, enum.Enum):
    """Transaction lifecycle states."""

    INITIATED = "initiated"
    RECEIVABLE_DETECTED = "receivable_detected"
    FINALITY_PENDING = "finality_pending"
    RECEIVABLE_CLEARED = "receivable_cleared"
    NORMALIZING = "normalizing"
    NORMALIZED = "normalized"
    PAYOUT_PENDING = "payout_pending"
    PAYOUT_EXECUTED = "payout_executed"
    SETTLED = "settled"
    FAILED = "failed"
    REVERSED = "reversed"


# Valid state transitions — anything not here is illegal.
TRANSITIONS: dict[TxState, set[TxState]] = {
    TxState.INITIATED: {TxState.RECEIVABLE_DETECTED, TxState.FAILED},
    TxState.RECEIVABLE_DETECTED: {TxState.FINALITY_PENDING, TxState.FAILED},
    TxState.FINALITY_PENDING: {TxState.RECEIVABLE_CLEARED, TxState.FAILED, TxState.REVERSED},
    TxState.RECEIVABLE_CLEARED: {TxState.NORMALIZING, TxState.PAYOUT_PENDING, TxState.FAILED},
    TxState.NORMALIZING: {TxState.NORMALIZED, TxState.FAILED},
    TxState.NORMALIZED: {TxState.PAYOUT_PENDING, TxState.FAILED},
    TxState.PAYOUT_PENDING: {TxState.PAYOUT_EXECUTED, TxState.FAILED},
    TxState.PAYOUT_EXECUTED: {TxState.SETTLED, TxState.FAILED},
    TxState.SETTLED: {TxState.REVERSED},
    TxState.FAILED: set(),
    TxState.REVERSED: set(),
}


class InvalidTransition(Exception):
    def __init__(self, current: TxState, target: TxState):
        self.current = current
        self.target = target
        super().__init__(f"Cannot transition from {current.value} to {target.value}")


@dataclass
class TxEvent:
    """Immutable record of a state transition."""

    tx_id: str
    event_type: str
    from_state: TxState
    to_state: TxState
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    amount: Decimal | None = None
    currency: str | None = None
    rail: str | None = None
    provider_ref: str | None = None  # External reference (Stripe charge ID, etc.)
    metadata: dict[str, Any] = field(default_factory=dict)
    idempotency_key: str | None = None
    sequence: int = 0


@dataclass
class Transaction:
    """Mutable transaction state — the working object.

    All mutations go through advance() which enforces the state machine.
    """

    tx_id: str
    merchant_id: str
    state: TxState = TxState.INITIATED
    inbound_amount: Decimal = Decimal("0")
    inbound_currency: str = "USD"
    inbound_rail: str = "stripe"
    outbound_amount: Decimal | None = None
    outbound_currency: str | None = None
    outbound_rail: str | None = None
    treasury_amount: Decimal | None = None
    treasury_asset: str = "USDC"
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    sequence: int = 0
    events: list[TxEvent] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def advance(
        self,
        to_state: TxState,
        *,
        amount: Decimal | None = None,
        currency: str | None = None,
        rail: str | None = None,
        provider_ref: str | None = None,
        idempotency_key: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> TxEvent:
        """Move to the next state. Raises InvalidTransition if illegal."""
        allowed = TRANSITIONS.get(self.state, set())
        if to_state not in allowed:
            raise InvalidTransition(self.state, to_state)

        event = TxEvent(
            tx_id=self.tx_id,
            event_type=f"tx.{to_state.value}",
            from_state=self.state,
            to_state=to_state,
            amount=amount or self.inbound_amount,
            currency=currency or self.inbound_currency,
            rail=rail or self.inbound_rail,
            provider_ref=provider_ref,
            idempotency_key=idempotency_key,
            metadata=metadata or {},
            sequence=self.sequence,
        )

        self.state = to_state
        self.sequence += 1
        self.updated_at = event.timestamp
        self.events.append(event)

        return event
