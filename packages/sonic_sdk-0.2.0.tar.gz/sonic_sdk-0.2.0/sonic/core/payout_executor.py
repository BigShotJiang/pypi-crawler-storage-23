"""Payout executor — dispatches payouts to the correct provider rail.

Supports failover: if the primary provider fails, falls back to alternates.
All execution is idempotent via provider-level idempotency keys.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from decimal import Decimal
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class PayoutInstruction:
    """What to pay, to whom, via which rail."""

    tx_id: str
    recipient_id: str
    amount: Decimal
    currency: str
    rail: str  # "stripe_transfer", "moov_ach", "circle_usdc", etc.
    idempotency_key: str
    metadata: dict[str, Any] | None = None


@dataclass
class PayoutResult:
    """Outcome of a payout attempt."""

    success: bool
    provider: str
    provider_ref: str | None = None  # External ID from the provider
    error: str | None = None
    retryable: bool = False


class PayoutExecutor:
    """Dispatches payouts with failover support."""

    def __init__(self, providers: dict[str, Any]):
        """providers: mapping of rail name → provider adapter instance."""
        self._providers = providers

    async def execute(
        self,
        instruction: PayoutInstruction,
        *,
        fallback_rails: list[str] | None = None,
    ) -> PayoutResult:
        """Execute payout on primary rail, falling back if needed."""
        rails_to_try = [instruction.rail]
        if fallback_rails:
            rails_to_try.extend(fallback_rails)

        last_error: str | None = None
        for rail in rails_to_try:
            provider = self._providers.get(rail)
            if not provider:
                logger.warning("No provider registered for rail: %s", rail)
                continue

            try:
                result = await provider.send_payout(
                    recipient_id=instruction.recipient_id,
                    amount=instruction.amount,
                    currency=instruction.currency,
                    idempotency_key=instruction.idempotency_key,
                    metadata=instruction.metadata,
                )
                return PayoutResult(
                    success=True,
                    provider=rail,
                    provider_ref=result.get("ref"),
                )
            except Exception as exc:
                last_error = f"{rail}: {exc}"
                logger.error("Payout failed on %s: %s", rail, exc)
                continue

        return PayoutResult(
            success=False,
            provider=instruction.rail,
            error=last_error or "No providers available",
            retryable=True,
        )
