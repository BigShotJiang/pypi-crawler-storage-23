"""Finality gate — rail-specific clearing rules.

Each payment rail has different finality characteristics.
The gate decides when a receivable can be considered "cleared"
and safe to release payout against.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass
from datetime import timedelta


class FinalityStatus(str, enum.Enum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    FINAL = "final"
    REVERSED = "reversed"


@dataclass(frozen=True)
class FinalityPolicy:
    """Defines when a rail considers a payment final."""

    rail: str
    hold_period: timedelta
    confirmation_source: str
    reversible_window: timedelta | None = None  # None = not reversible after final
    min_confirmations: int | None = None  # For blockchain rails

    @property
    def is_instant_final(self) -> bool:
        return self.hold_period == timedelta(0)


# Default policies per rail — overrideable per merchant/corridor.
DEFAULT_POLICIES: dict[str, FinalityPolicy] = {
    "stripe_card": FinalityPolicy(
        rail="stripe_card",
        hold_period=timedelta(hours=0),  # Stripe guarantees on capture
        confirmation_source="stripe_webhook",
        reversible_window=timedelta(days=120),  # Chargeback window
    ),
    "stripe_ach": FinalityPolicy(
        rail="stripe_ach",
        hold_period=timedelta(days=4),
        confirmation_source="stripe_webhook",
        reversible_window=timedelta(days=60),  # ACH return window
    ),
    "moov_ach": FinalityPolicy(
        rail="moov_ach",
        hold_period=timedelta(days=3),
        confirmation_source="moov_webhook",
        reversible_window=timedelta(days=60),
    ),
    "circle_usdc": FinalityPolicy(
        rail="circle_usdc",
        hold_period=timedelta(minutes=2),  # ~6 confirmations on Base/Ethereum
        confirmation_source="chain_confirmations",
        reversible_window=None,  # Blockchain finality = true finality
        min_confirmations=6,
    ),
    "circle_usdc_solana": FinalityPolicy(
        rail="circle_usdc_solana",
        hold_period=timedelta(seconds=30),
        confirmation_source="chain_confirmations",
        reversible_window=None,
        min_confirmations=32,
    ),
}


class FinalityGate:
    """Evaluates whether a receivable has reached finality."""

    def __init__(self, policy_overrides: dict[str, FinalityPolicy] | None = None):
        self._policies = {**DEFAULT_POLICIES}
        if policy_overrides:
            self._policies.update(policy_overrides)

    def get_policy(self, rail: str) -> FinalityPolicy:
        policy = self._policies.get(rail)
        if not policy:
            raise ValueError(f"No finality policy for rail: {rail}")
        return policy

    def evaluate(
        self,
        rail: str,
        *,
        provider_confirmed: bool = False,
        confirmations: int | None = None,
    ) -> FinalityStatus:
        """Determine finality status based on rail policy and current signals."""
        policy = self.get_policy(rail)

        if policy.min_confirmations is not None:
            # Blockchain rail — check confirmation count
            if confirmations is None:
                return FinalityStatus.PENDING
            if confirmations >= policy.min_confirmations:
                return FinalityStatus.FINAL
            return FinalityStatus.CONFIRMED

        if policy.is_instant_final and provider_confirmed:
            # Card rail with provider guarantee
            return FinalityStatus.FINAL

        if provider_confirmed:
            return FinalityStatus.CONFIRMED

        return FinalityStatus.PENDING
