"""Combined hash backfiller — fuses Tier 1 (app) and Tier 2 (SBN) into an immutable combined chain.

When SBN attestation completes for a receipt, this worker computes:

    combined_hash = SHA-256(app_hash || sbn_hash || prev_combined_hash)

This creates a third chain that cryptographically binds both layers.
The combined chain is eventually consistent — it backfills as SBN
attestations land — but once filled, it's as strong as if we'd
blocked on SBN synchronously.

The worker also triggers Tier 3 (blockchain anchoring) for merchants
that have opted in.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any

from sonic.core.receipt_builder import combined_hash

logger = logging.getLogger(__name__)


class CombinedHashBackfiller:
    """Processes SBN-attested receipts and computes combined hashes.

    Runs as an async background worker alongside the SBN attester.
    Picks up receipts that have ``sbn_receipt_hash`` set but
    ``combined_hash`` still NULL, computes the fused hash, and
    optionally enqueues blockchain anchoring.
    """

    def __init__(
        self,
        db_session_factory: Any,
        redis_client: Any,
        anchor_service: Any | None = None,
    ):
        self._db = db_session_factory
        self._redis = redis_client
        self._anchor = anchor_service
        self._queue_key = "sonic:combined:backfill_queue"

    async def enqueue(self, receipt_id: str, sbn_hash: str) -> None:
        """Signal that an SBN attestation completed for a receipt.

        Called by the attester/coupler after SBN backfill succeeds.
        """
        job = json.dumps({
            "receipt_id": receipt_id,
            "sbn_hash": sbn_hash,
        })
        await self._redis.lpush(self._queue_key, job)
        logger.debug("Enqueued combined-hash backfill for receipt %s", receipt_id)

    async def process_one(self) -> dict[str, Any] | None:
        """Pop one job and compute the combined hash.

        Returns a dict with receipt_id, combined_hash on success,
        or None if queue is empty.
        """
        raw = await self._redis.rpop(self._queue_key)
        if not raw:
            return None

        job = json.loads(raw)
        receipt_id = job["receipt_id"]
        sbn_hash = job["sbn_hash"]

        async with self._db() as session:
            from sonic.models.receipt import ReceiptRecord

            # Fetch the receipt
            result = await session.execute(
                ReceiptRecord.__table__.select().where(
                    ReceiptRecord.receipt_id == receipt_id
                )
            )
            row = result.mappings().first()

            if not row:
                logger.warning("Combined backfill: receipt %s not found", receipt_id)
                return None

            if row["combined_hash"] is not None:
                logger.debug("Combined backfill: receipt %s already has combined hash", receipt_id)
                return {"receipt_id": receipt_id, "combined_hash": row["combined_hash"]}

            app_hash = row["receipt_hash"]
            merchant_id = row["merchant_id"]
            tx_id = row["tx_id"]
            sequence = row["sequence"]

            # Find the previous combined hash in this tx's chain
            prev_combined = None
            if sequence > 0:
                prev_result = await session.execute(
                    ReceiptRecord.__table__.select()
                    .where(
                        ReceiptRecord.tx_id == tx_id,
                        ReceiptRecord.sequence < sequence,
                        ReceiptRecord.combined_hash.isnot(None),
                    )
                    .order_by(ReceiptRecord.sequence.desc())
                    .limit(1)
                )
                prev_row = prev_result.mappings().first()
                if prev_row:
                    prev_combined = prev_row["combined_hash"]

            # Compute the combined hash
            fused = combined_hash(app_hash, sbn_hash, prev_combined)

            # Update the receipt
            await session.execute(
                ReceiptRecord.__table__.update()
                .where(ReceiptRecord.receipt_id == receipt_id)
                .values(
                    combined_hash=fused,
                    prev_combined_hash=prev_combined,
                )
            )
            await session.commit()

        logger.info(
            "Combined hash backfilled: receipt=%s combined=%s",
            receipt_id,
            fused[:16] + "...",
        )

        # Trigger Tier 3 anchoring if merchant opted in
        if self._anchor is not None:
            try:
                await self._anchor.maybe_anchor(
                    receipt_id=receipt_id,
                    combined_hash=fused,
                    merchant_id=merchant_id,
                    tx_id=tx_id,
                )
            except Exception:
                logger.warning(
                    "Blockchain anchor enqueue failed for receipt %s",
                    receipt_id,
                    exc_info=True,
                )

        return {
            "receipt_id": receipt_id,
            "combined_hash": fused,
            "prev_combined_hash": prev_combined,
        }

    async def drain(self, max_batch: int = 50) -> int:
        """Process up to max_batch jobs. Returns count processed."""
        processed = 0
        for _ in range(max_batch):
            result = await self.process_one()
            if result is not None:
                processed += 1
            else:
                break
        return processed

    async def queue_depth(self) -> int:
        return await self._redis.llen(self._queue_key)
