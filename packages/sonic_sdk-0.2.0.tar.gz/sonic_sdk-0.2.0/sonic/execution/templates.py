"""
Sonic pgDAG Templates — reusable workflow definitions.

Each template maps to a core Sonic business operation.
Templates are product-specific; the execution engine is universal (pgdag kernel).

Sonic's settlement engine is event-driven (drain loops, Redis queues).
These templates provide proof-gated wrappers around the critical paths,
producing cryptographic evidence chains for every settlement, stream
window, epoch coupling, and receipt verification.
"""

from __future__ import annotations

from typing import Dict

from pgdag import DAGEdge, DAGNode, DAGTemplate


# ---------------------------------------------------------------------------
# Settlement Flow (payment → finality → normalize → payout → settle)
# ---------------------------------------------------------------------------

settlement_flow_template = DAGTemplate(
    name="settlement_flow",
    version="1.0",
    domain="sonic.settlement",
    nodes=[
        DAGNode(id="create_payment",       label="Create transaction (INITIATED)",          step_type="ingestion"),
        DAGNode(id="detect_receivable",    label="Detect inbound (RECEIVABLE_DETECTED)",    step_type="execution"),
        DAGNode(id="await_finality",       label="Wait for rail finality (FINALITY_PENDING)", step_type="validation"),
        DAGNode(id="clear_receivable",     label="Confirm final (RECEIVABLE_CLEARED)",      step_type="validation"),
        DAGNode(id="normalize_treasury",   label="FX normalize to USDC (NORMALIZING)",      step_type="computation"),
        DAGNode(id="execute_payout",       label="Dispatch payout to provider",             step_type="execution"),
        DAGNode(id="poll_settlement",      label="Poll provider for settlement",            step_type="execution"),
        DAGNode(id="build_receipt",        label="Build Tier 1 receipt chain",              step_type="execution"),
        DAGNode(id="attest_receipt",       label="SBN attestation (Tier 2)",                step_type="execution"),
        DAGNode(id="seal_settlement",      label="Seal settlement proof",                   step_type="execution"),
    ],
    metadata={
        "description": "Full payment-to-settlement with three-tier receipt chain",
        "frontier": "sonic.settlement.v1",
        "state_machine": [
            "INITIATED", "RECEIVABLE_DETECTED", "FINALITY_PENDING",
            "RECEIVABLE_CLEARED", "NORMALIZING", "NORMALIZED",
            "PAYOUT_PENDING", "PAYOUT_EXECUTED", "SETTLED",
        ],
    },
)


# ---------------------------------------------------------------------------
# Stream Lifecycle (windowed accrual with risk-gated policy)
# ---------------------------------------------------------------------------

stream_lifecycle_template = DAGTemplate(
    name="stream_lifecycle",
    version="1.0",
    domain="sonic.streaming",
    nodes=[
        DAGNode(id="open_stream",          label="Open PayStream + SBN slot",          step_type="execution"),
        DAGNode(id="accrue_window",        label="Accrue earnings into current window", step_type="computation"),
        DAGNode(id="close_window",         label="Close 30-min window boundary",        step_type="execution"),
        DAGNode(id="compute_gec",          label="Compute GEC score for window",        step_type="computation"),
        DAGNode(id="update_ewma",          label="Update g_ewma (alpha=0.3)",           step_type="computation"),
        DAGNode(id="evaluate_policy",      label="Evaluate policy state transition",     step_type="validation"),
        DAGNode(id="compute_disbursement", label="Compute holdback + disbursement",      step_type="computation"),
        DAGNode(id="execute_micropayout",  label="Execute micro-payout to payee",        step_type="execution"),
        DAGNode(id="emit_window_receipt",  label="Emit receipt + SBN block for window",  step_type="execution"),
        DAGNode(id="seal_window",          label="Seal window proof",                    step_type="execution"),
    ],
    edges=[
        DAGEdge(source="open_stream",          target="accrue_window"),
        DAGEdge(source="accrue_window",         target="close_window"),
        DAGEdge(source="close_window",          target="compute_gec"),
        DAGEdge(source="compute_gec",           target="update_ewma"),
        DAGEdge(source="update_ewma",           target="evaluate_policy"),
        # Parallel after policy: disbursement calc + receipt
        DAGEdge(source="evaluate_policy",       target="compute_disbursement"),
        DAGEdge(source="evaluate_policy",       target="emit_window_receipt"),
        # Micro-payout depends on disbursement calc
        DAGEdge(source="compute_disbursement",  target="execute_micropayout"),
        # Seal depends on both payout + receipt
        DAGEdge(source="execute_micropayout",   target="seal_window"),
        DAGEdge(source="emit_window_receipt",   target="seal_window"),
    ],
    metadata={
        "description": "PayStream windowed accrual with g_ewma risk-gated policy",
        "frontier": "sonic.streaming.v1",
        "policy_states": ["prime", "normal", "risk", "frozen"],
        "window_duration_seconds": 1800,
        "ewma_alpha": 0.3,
    },
)


# ---------------------------------------------------------------------------
# Epoch Coupling (Mode B: slot-based batch receipt coupling to SBN)
# ---------------------------------------------------------------------------

epoch_coupling_template = DAGTemplate(
    name="epoch_coupling",
    version="1.0",
    domain="sonic.coupling",
    nodes=[
        DAGNode(id="ensure_epoch",        label="Get or create SbnEpoch for today",    step_type="execution"),
        DAGNode(id="open_slot",           label="Open SBN slot for epoch",             step_type="execution"),
        DAGNode(id="claim_receipts",      label="Claim pending receipts from DB",      step_type="ingestion"),
        DAGNode(id="submit_blocks",       label="Submit SmartBlock per receipt",        step_type="execution"),
        DAGNode(id="backfill_combined",   label="Compute combined_hash per receipt",    step_type="computation"),
        DAGNode(id="close_slot",          label="Close SBN slot (get Merkle root)",     step_type="execution"),
        DAGNode(id="attest_epoch",        label="Request attestation on batch",         step_type="execution"),
        DAGNode(id="seal_epoch",          label="Seal epoch coupling proof",            step_type="execution"),
    ],
    edges=[
        DAGEdge(source="ensure_epoch",      target="open_slot"),
        DAGEdge(source="open_slot",         target="claim_receipts"),
        DAGEdge(source="claim_receipts",    target="submit_blocks"),
        # Parallel after block submission: backfill + close
        DAGEdge(source="submit_blocks",     target="backfill_combined"),
        DAGEdge(source="submit_blocks",     target="close_slot"),
        # Attest depends on close (needs Merkle root)
        DAGEdge(source="close_slot",        target="attest_epoch"),
        # Seal depends on both
        DAGEdge(source="backfill_combined", target="seal_epoch"),
        DAGEdge(source="attest_epoch",      target="seal_epoch"),
    ],
    metadata={
        "description": "Mode B slot-based batch coupling of receipts to SBN per epoch",
        "epoch_boundary": "daily",
        "batch_size": 50,
    },
)


# ---------------------------------------------------------------------------
# Receipt Verification (three-tier chain integrity check)
# ---------------------------------------------------------------------------

receipt_verification_template = DAGTemplate(
    name="receipt_verification",
    version="1.0",
    domain="sonic.verification",
    nodes=[
        DAGNode(id="load_receipts",       label="Load receipt chain for transaction",  step_type="ingestion"),
        DAGNode(id="verify_tier1",        label="Verify Tier 1 app hash chain",        step_type="validation"),
        DAGNode(id="verify_tier2",        label="Verify Tier 2 SBN attestation",       step_type="validation"),
        DAGNode(id="verify_combined",     label="Verify combined_hash fusion",          step_type="validation"),
        DAGNode(id="verify_tier3",        label="Verify Tier 3 blockchain anchor",      step_type="validation"),
        DAGNode(id="seal_verification",   label="Seal verification result",             step_type="execution"),
    ],
    edges=[
        DAGEdge(source="load_receipts",     target="verify_tier1"),
        DAGEdge(source="load_receipts",     target="verify_tier2"),
        # Combined depends on both tier 1 and tier 2
        DAGEdge(source="verify_tier1",      target="verify_combined"),
        DAGEdge(source="verify_tier2",      target="verify_combined"),
        # Tier 3 depends on combined
        DAGEdge(source="verify_combined",   target="verify_tier3"),
        # Seal depends on tier 3
        DAGEdge(source="verify_tier3",      target="seal_verification"),
    ],
    metadata={
        "description": "Three-tier receipt chain integrity verification",
        "tiers": ["app_chain", "sbn_attested", "combined", "anchored"],
    },
)


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

SONIC_TEMPLATES: Dict[str, DAGTemplate] = {
    "settlement_flow":      settlement_flow_template,
    "stream_lifecycle":     stream_lifecycle_template,
    "epoch_coupling":       epoch_coupling_template,
    "receipt_verification": receipt_verification_template,
}
