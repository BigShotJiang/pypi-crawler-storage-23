"""
Sonic Execution Layer — pgDAG templates + step functions.

Uses the universal pgdag kernel from smartblocks_v2/sdk/python/pgdag.
Sonic provides the templates (what to run) and step functions (the business logic).
The kernel provides the proof-gated execution engine.

Templates:
    settlement_flow      — full payment-to-settlement state machine
    stream_lifecycle     — PayStream windowed accrual with risk-gated policy
    epoch_coupling       — Mode B slot-based batch receipt coupling to SBN
    receipt_verification — three-tier receipt chain integrity check

Quick start:
    from pgdag import build
    from sonic.execution import SONIC_TEMPLATES, settlement_flow_steps

    layer = build(sbn_client=sbn, domain="sonic.settlement")
    layer.runner.register_steps(settlement_flow_steps(db, engine, providers, sbn_client))
    result = await layer.runner.execute(SONIC_TEMPLATES["settlement_flow"], inputs={...})
"""

from .templates import (
    SONIC_TEMPLATES,
    epoch_coupling_template,
    receipt_verification_template,
    settlement_flow_template,
    stream_lifecycle_template,
)

from .steps import (
    epoch_coupling_steps,
    receipt_verification_steps,
    settlement_flow_steps,
    stream_lifecycle_steps,
)

__all__ = [
    # Templates
    "SONIC_TEMPLATES",
    "settlement_flow_template",
    "stream_lifecycle_template",
    "epoch_coupling_template",
    "receipt_verification_template",
    # Step factory functions
    "settlement_flow_steps",
    "stream_lifecycle_steps",
    "epoch_coupling_steps",
    "receipt_verification_steps",
]
