"""Dominion database configuration from environment."""

from __future__ import annotations

import os


def dominion_database_url() -> str:
    """Resolve database URL for Dominion.

    Priority:
      1. DOMINION_DATABASE_URL (Dominion-specific)
      2. DATABASE_URL (shared fallback)
      3. SQLite default for local dev
    """
    return (
        os.getenv("DOMINION_DATABASE_URL")
        or os.getenv("DATABASE_URL")
        or "sqlite+aiosqlite:///dominion.db"
    )


def dominion_redis_url() -> str:
    """Resolve Redis URL for Dominion event bus."""
    return (
        os.getenv("DOMINION_REDIS_URL")
        or os.getenv("REDIS_URL")
        or "redis://localhost:6379/1"
    )
