"""
Dominion ORM models — Postgres-backed persistence for Phase 3.

Mirrors every in-memory store from Phase 1/2:
  - VaultJournal entries → DomJournalEntry
  - SnapChore receipts   → DomReceipt
  - Tax jurisdictions     → DomTaxJurisdiction / DomTaxCode / DomWorkerJurisdiction
  - Milestones            → DomMilestone
  - Contract locks        → DomContractLock
  - Float commitments     → DomFloatCommitment
  - Workflow state        → DomWorkflowRun / DomWorkflowStep
  - Agent bridge events   → DomBridgeEvent
  - Dead-letter queue     → DomDeadLetter

Follows the same type-decorator pattern as app.db.models (GUID, JSONBCompat).
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime

import sqlalchemy as sa
from sqlalchemy import (
    Boolean,
    CheckConstraint,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.types import TypeDecorator, JSON


# ---------------------------------------------------------------------------
# Type decorators (mirrored from app.db.models for standalone use)
# ---------------------------------------------------------------------------

class GUID(TypeDecorator):
    """Platform-independent UUID — native on Postgres, string elsewhere."""

    impl = String(36)
    cache_ok = True

    def load_dialect_impl(self, dialect):
        if dialect.name == "postgresql":
            return dialect.type_descriptor(UUID(as_uuid=True))
        return dialect.type_descriptor(String(36))

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        if isinstance(value, uuid.UUID):
            return value if dialect.name == "postgresql" else str(value)
        return str(uuid.UUID(str(value)))

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        return value if isinstance(value, uuid.UUID) else uuid.UUID(str(value))


class JSONBCompat(TypeDecorator):
    """JSONB on Postgres, JSON elsewhere."""

    impl = JSON
    cache_ok = True

    def load_dialect_impl(self, dialect):
        if dialect.name == "postgresql":
            return dialect.type_descriptor(JSONB())
        return dialect.type_descriptor(JSON())


# ---------------------------------------------------------------------------
# Declarative base
# ---------------------------------------------------------------------------

class DomBase(DeclarativeBase):
    pass


# ---------------------------------------------------------------------------
# Vault Journal
# ---------------------------------------------------------------------------

class DomJournalEntry(DomBase):
    __tablename__ = "dom_journal_entry"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    event_type: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    worker_id: Mapped[str] = mapped_column(String(128), nullable=False, default="", index=True)
    amount: Mapped[float | None] = mapped_column(Float, nullable=True)
    currency: Mapped[str] = mapped_column(String(8), nullable=False, default="USD")
    description: Mapped[str] = mapped_column(Text, nullable=False, default="")
    payload: Mapped[dict] = mapped_column(JSONBCompat(), nullable=False, server_default="{}")
    snapchore_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)
    gec_metrics: Mapped[dict | None] = mapped_column(JSONBCompat(), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )

    __table_args__ = (
        Index("ix_dom_journal_worker_type", "worker_id", "event_type"),
        Index("ix_dom_journal_created", "created_at"),
    )


# ---------------------------------------------------------------------------
# SnapChore Receipts
# ---------------------------------------------------------------------------

class DomReceipt(DomBase):
    __tablename__ = "dom_receipt"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    instruction_id: Mapped[str] = mapped_column(
        String(128), unique=True, nullable=False, index=True,
    )
    worker_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    amount: Mapped[float] = mapped_column(Float, nullable=False)
    currency: Mapped[str] = mapped_column(String(8), nullable=False, default="USD")
    tax_withheld: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    net_amount: Mapped[float] = mapped_column(Float, nullable=False)
    project_id: Mapped[str] = mapped_column(String(128), nullable=False, default="")
    sonic_tx_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    sonic_receipt_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)
    pay_stream_id: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    sbn_slot_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    snapchore_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)
    gec_metrics: Mapped[dict | None] = mapped_column(JSONBCompat(), nullable=True)
    metadata_: Mapped[dict] = mapped_column(
        "metadata", JSONBCompat(), nullable=False, server_default="{}",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )

    __table_args__ = (
        Index("ix_dom_receipt_worker", "worker_id"),
    )


# ---------------------------------------------------------------------------
# Tax Domain
# ---------------------------------------------------------------------------

class DomTaxJurisdiction(DomBase):
    __tablename__ = "dom_tax_jurisdiction"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    jurisdiction_id: Mapped[str] = mapped_column(
        String(128), unique=True, nullable=False,
    )
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    code: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    level: Mapped[str] = mapped_column(String(32), nullable=False, default="federal")
    country: Mapped[str] = mapped_column(String(8), nullable=False, default="US")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )

    tax_codes: Mapped[list["DomTaxCode"]] = relationship(
        back_populates="jurisdiction", cascade="all, delete-orphan",
    )


class DomTaxCode(DomBase):
    __tablename__ = "dom_tax_code"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    code_id: Mapped[str] = mapped_column(
        String(128), unique=True, nullable=False,
    )
    jurisdiction_pk: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("dom_tax_jurisdiction.id", ondelete="CASCADE"), nullable=False,
    )
    jurisdiction_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    tax_type: Mapped[str] = mapped_column(String(32), nullable=False)
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    rate: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    flat_amount: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    wage_base_limit: Mapped[float | None] = mapped_column(Float, nullable=True)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="active")
    effective_date: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    expiry_date: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    metadata_: Mapped[dict] = mapped_column(
        "metadata", JSONBCompat(), nullable=False, server_default="{}",
    )

    jurisdiction: Mapped["DomTaxJurisdiction"] = relationship(back_populates="tax_codes")

    __table_args__ = (
        Index("ix_dom_tax_code_jur", "jurisdiction_id"),
        Index("ix_dom_tax_code_type", "tax_type"),
    )


class DomWorkerJurisdiction(DomBase):
    """Maps workers to their assigned tax jurisdictions."""
    __tablename__ = "dom_worker_jurisdiction"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    worker_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    jurisdiction_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    assigned_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )

    __table_args__ = (
        sa.UniqueConstraint("worker_id", "jurisdiction_id", name="uq_worker_jurisdiction"),
    )


# ---------------------------------------------------------------------------
# Milestones
# ---------------------------------------------------------------------------

class DomMilestone(DomBase):
    __tablename__ = "dom_milestone"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    milestone_id: Mapped[str] = mapped_column(
        String(128), unique=True, nullable=False,
    )
    worker_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    milestone_type: Mapped[str] = mapped_column(String(32), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False, default="")
    bonus_amount: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    currency: Mapped[str] = mapped_column(String(8), nullable=False, default="USD")
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="scheduled", index=True)
    trigger_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    gec0_threshold: Mapped[float | None] = mapped_column(Float, nullable=True)
    trust_threshold: Mapped[float | None] = mapped_column(Float, nullable=True)
    contract_lock_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    metadata_: Mapped[dict] = mapped_column(
        "metadata", JSONBCompat(), nullable=False, server_default="{}",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )
    resolved_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    __table_args__ = (
        Index("ix_dom_milestone_worker_status", "worker_id", "status"),
    )


# ---------------------------------------------------------------------------
# Contract Locks (crypto milestone escrow)
# ---------------------------------------------------------------------------

class DomContractLock(DomBase):
    __tablename__ = "dom_contract_lock"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    lock_id: Mapped[str] = mapped_column(String(128), unique=True, nullable=False)
    milestone_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    worker_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    amount: Mapped[float] = mapped_column(Float, nullable=False)
    currency: Mapped[str] = mapped_column(String(8), nullable=False)
    chain: Mapped[str] = mapped_column(String(32), nullable=False)
    release_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    destination_wallet: Mapped[str] = mapped_column(String(256), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="pending")
    tx_hash: Mapped[str | None] = mapped_column(String(256), nullable=True)
    snapchore_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)
    metadata_: Mapped[dict] = mapped_column(
        "metadata", JSONBCompat(), nullable=False, server_default="{}",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )


# ---------------------------------------------------------------------------
# Float Commitments
# ---------------------------------------------------------------------------

class DomFloatCommitment(DomBase):
    """Tracks individual float reservations for in-flight payouts."""
    __tablename__ = "dom_float_commitment"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    instruction_id: Mapped[str] = mapped_column(
        String(128), unique=True, nullable=False, index=True,
    )
    amount: Mapped[float] = mapped_column(Float, nullable=False)
    currency: Mapped[str] = mapped_column(String(8), nullable=False, default="USD")
    status: Mapped[str] = mapped_column(
        String(32), nullable=False, default="committed", index=True,
    )  # committed | settled | released
    committed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )
    released_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )


# ---------------------------------------------------------------------------
# Workflow State (Lattice DAG execution)
# ---------------------------------------------------------------------------

class DomWorkflowRun(DomBase):
    """A single execution of the payroll DAG."""
    __tablename__ = "dom_workflow_run"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    workflow_id: Mapped[str] = mapped_column(
        String(128), unique=True, nullable=False,
    )
    lattice_workflow_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    batch_id: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    status: Mapped[str] = mapped_column(
        String(32), nullable=False, default="active", index=True,
    )  # active | completed | failed
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    steps: Mapped[list["DomWorkflowStep"]] = relationship(
        back_populates="run", cascade="all, delete-orphan",
    )


class DomWorkflowStep(DomBase):
    """Completion record for a single DAG node."""
    __tablename__ = "dom_workflow_step"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    run_pk: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("dom_workflow_run.id", ondelete="CASCADE"), nullable=False,
    )
    step_id: Mapped[str] = mapped_column(String(64), nullable=False)
    success: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    data: Mapped[dict | None] = mapped_column(JSONBCompat(), nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    snapchore_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)
    completed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )

    run: Mapped["DomWorkflowRun"] = relationship(back_populates="steps")

    __table_args__ = (
        sa.UniqueConstraint("run_pk", "step_id", name="uq_workflow_step"),
        Index("ix_dom_workflow_step_run", "run_pk"),
    )


# ---------------------------------------------------------------------------
# Agent Bridge Events
# ---------------------------------------------------------------------------

class DomBridgeEvent(DomBase):
    """Persisted event for the Dominion ↔ Agent bridge."""
    __tablename__ = "dom_bridge_event"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    event_type: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    data: Mapped[dict] = mapped_column(JSONBCompat(), nullable=False)
    consumed: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )
    consumed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    __table_args__ = (
        Index("ix_dom_bridge_unconsumed", "consumed", "created_at"),
    )


# ---------------------------------------------------------------------------
# Dead-Letter Queue
# ---------------------------------------------------------------------------

class DomDeadLetter(DomBase):
    """Failed SBN submissions queued for retry."""
    __tablename__ = "dom_dead_letter"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    operation: Mapped[str] = mapped_column(
        String(64), nullable=False, index=True,
    )  # seal | attestation | workflow | block
    payload: Mapped[dict] = mapped_column(JSONBCompat(), nullable=False)
    error_message: Mapped[str] = mapped_column(Text, nullable=False, default="")
    retry_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    max_retries: Mapped[int] = mapped_column(Integer, nullable=False, default=5)
    status: Mapped[str] = mapped_column(
        String(32), nullable=False, default="pending", index=True,
    )  # pending | retrying | succeeded | exhausted
    next_retry_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )
    last_attempt_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    __table_args__ = (
        Index("ix_dom_dlq_retry", "status", "next_retry_at"),
    )


# ---------------------------------------------------------------------------
# Party & Account (ISO 20022 structured identification)
# ---------------------------------------------------------------------------

class DomPartyAccount(DomBase):
    """Structured party identification and account details.

    Stores ISO 20022-compliant debtor/creditor information:
    - BIC, IBAN, LEI, routing numbers
    - Postal addresses
    - Wallet addresses (crypto mode)
    - Purpose code defaults

    Each worker or entity can have multiple accounts (bank, wallet, etc.).
    The ``primary`` flag identifies the default account for payouts.
    """
    __tablename__ = "dom_party_account"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    # Links to worker_id or entity_id across Dominion
    party_id: Mapped[str] = mapped_column(
        String(128), nullable=False, index=True,
    )
    party_type: Mapped[str] = mapped_column(
        String(32), nullable=False, default="worker",
    )  # worker | company | treasury | intermediary

    # Party identification
    name: Mapped[str] = mapped_column(String(140), nullable=False, default="")
    lei: Mapped[str | None] = mapped_column(String(20), nullable=True)
    bic: Mapped[str | None] = mapped_column(String(11), nullable=True)
    tax_id: Mapped[str | None] = mapped_column(String(35), nullable=True)
    registration_number: Mapped[str | None] = mapped_column(String(35), nullable=True)
    country_of_residence: Mapped[str | None] = mapped_column(String(2), nullable=True)

    # Postal address (structured)
    street_name: Mapped[str | None] = mapped_column(String(70), nullable=True)
    building_number: Mapped[str | None] = mapped_column(String(16), nullable=True)
    post_code: Mapped[str | None] = mapped_column(String(16), nullable=True)
    town_name: Mapped[str | None] = mapped_column(String(35), nullable=True)
    country_sub_division: Mapped[str | None] = mapped_column(String(35), nullable=True)
    country: Mapped[str | None] = mapped_column(String(2), nullable=True)

    # Account identification
    account_scheme: Mapped[str] = mapped_column(
        String(8), nullable=False, default="PROP",
    )  # IBAN | BBAN | PROP | WALLET | USABA
    account_value: Mapped[str] = mapped_column(
        String(256), nullable=False, default="",
    )  # IBAN value, wallet address, or opaque token
    routing_number: Mapped[str | None] = mapped_column(String(35), nullable=True)
    account_number: Mapped[str | None] = mapped_column(String(34), nullable=True)
    account_currency: Mapped[str] = mapped_column(
        String(8), nullable=False, default="USD",
    )
    account_type: Mapped[str | None] = mapped_column(
        String(4), nullable=True,
    )  # CACC (current), SVGS (savings), etc.

    # Agent (financial institution)
    agent_bic: Mapped[str | None] = mapped_column(String(11), nullable=True)
    agent_name: Mapped[str | None] = mapped_column(String(140), nullable=True)
    agent_clearing_system_code: Mapped[str | None] = mapped_column(
        String(5), nullable=True,
    )  # USABA, GBDSC, etc.
    agent_clearing_system_id: Mapped[str | None] = mapped_column(
        String(35), nullable=True,
    )  # Clearing member ID (e.g., ABA routing number)

    # Default purpose for payouts to this account
    default_purpose_code: Mapped[str | None] = mapped_column(
        String(4), nullable=True, default="SALA",
    )

    # Flags
    primary: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False,
    )
    active: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True,
    )

    # Metadata
    metadata_: Mapped[dict] = mapped_column(
        "metadata", JSONBCompat(), nullable=False, server_default="{}",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )
    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    __table_args__ = (
        Index("ix_dom_party_account_party", "party_id", "party_type"),
        Index("ix_dom_party_account_primary", "party_id", "primary"),
        Index("ix_dom_party_account_scheme", "account_scheme"),
    )


# ---------------------------------------------------------------------------
# Privacy: Consent Records (GDPR Art. 6-7, CCPA, LGPD, PDPA)
# ---------------------------------------------------------------------------

class DomConsent(DomBase):
    """Tracks data processing consent for each worker.

    Each record represents a worker's consent (or revocation) for a
    specific processing purpose under a specific jurisdiction.
    """
    __tablename__ = "dom_consent"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    consent_id: Mapped[str] = mapped_column(
        String(128), unique=True, nullable=False, index=True,
    )
    worker_id: Mapped[str] = mapped_column(
        String(128), nullable=False, index=True,
    )
    purpose: Mapped[str] = mapped_column(
        String(64), nullable=False,
    )  # ProcessingPurpose value
    scope: Mapped[str] = mapped_column(
        Text, nullable=False, default="",
    )
    status: Mapped[str] = mapped_column(
        String(32), nullable=False, default="granted", index=True,
    )  # granted | revoked | expired | pending
    jurisdiction: Mapped[str] = mapped_column(
        String(16), nullable=False, default="none",
    )  # PrivacyJurisdiction value
    version: Mapped[str] = mapped_column(
        String(16), nullable=False, default="1.0",
    )
    granted_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )
    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    revoked_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    metadata_: Mapped[dict] = mapped_column(
        "metadata", JSONBCompat(), nullable=False, server_default="{}",
    )

    __table_args__ = (
        Index("ix_dom_consent_worker_purpose", "worker_id", "purpose"),
        Index("ix_dom_consent_status", "status"),
    )


# ---------------------------------------------------------------------------
# Privacy: Data Access Audit Log
# ---------------------------------------------------------------------------

class DomAccessLog(DomBase):
    """Records every read/query of worker personal data.

    Distinct from DomJournalEntry (which logs data changes/events).
    This logs data ACCESS for GDPR Art. 30 compliance.
    """
    __tablename__ = "dom_access_log"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    entry_id: Mapped[str] = mapped_column(
        String(128), unique=True, nullable=False,
    )
    accessor_id: Mapped[str] = mapped_column(
        String(128), nullable=False, index=True,
    )  # Who accessed (user ID, service name)
    accessor_type: Mapped[str] = mapped_column(
        String(32), nullable=False, default="user",
    )  # user | service | admin | system
    worker_id: Mapped[str] = mapped_column(
        String(128), nullable=False, index=True,
    )  # Whose data was accessed
    access_type: Mapped[str] = mapped_column(
        String(32), nullable=False,
    )  # view | query | export | api_read | downstream | admin
    resource: Mapped[str] = mapped_column(
        String(128), nullable=False, default="",
    )  # Table/endpoint accessed
    fields_accessed: Mapped[dict] = mapped_column(
        JSONBCompat(), nullable=False, server_default="[]",
    )  # List of field names accessed
    purpose: Mapped[str] = mapped_column(
        String(256), nullable=False, default="",
    )
    ip_address: Mapped[str | None] = mapped_column(
        String(45), nullable=True,
    )  # IPv4 or IPv6
    metadata_: Mapped[dict] = mapped_column(
        "metadata", JSONBCompat(), nullable=False, server_default="{}",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )

    __table_args__ = (
        Index("ix_dom_access_log_worker", "worker_id", "created_at"),
        Index("ix_dom_access_log_accessor", "accessor_id", "created_at"),
        Index("ix_dom_access_log_type", "access_type"),
    )


# ---------------------------------------------------------------------------
# Privacy: DSAR Tracking
# ---------------------------------------------------------------------------

class DomDSAR(DomBase):
    """Tracks Data Subject Access Requests and their processing status."""
    __tablename__ = "dom_dsar"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    request_id: Mapped[str] = mapped_column(
        String(128), unique=True, nullable=False, index=True,
    )
    worker_id: Mapped[str] = mapped_column(
        String(128), nullable=False, index=True,
    )
    request_type: Mapped[str] = mapped_column(
        String(32), nullable=False,
    )  # access | export | erasure | rectification | restriction | objection
    status: Mapped[str] = mapped_column(
        String(32), nullable=False, default="received", index=True,
    )  # received | verified | processing | completed | denied | partially_completed
    jurisdiction: Mapped[str] = mapped_column(
        String(16), nullable=False, default="none",
    )
    requested_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )
    deadline: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    notes: Mapped[str] = mapped_column(
        Text, nullable=False, default="",
    )
    legal_holds: Mapped[dict] = mapped_column(
        JSONBCompat(), nullable=False, server_default="[]",
    )
    result_payload: Mapped[dict | None] = mapped_column(
        JSONBCompat(), nullable=True,
    )  # Erasure report or export summary

    __table_args__ = (
        Index("ix_dom_dsar_worker", "worker_id"),
        Index("ix_dom_dsar_status_deadline", "status", "deadline"),
    )


# ---------------------------------------------------------------------------
# Worker Identity (Phase 2 — Employee Management)
# ---------------------------------------------------------------------------

class DomWorker(DomBase):
    """Core employee/worker identity record.

    Distinct from ``DomPartyAccount`` (which stores bank/wallet details).
    A worker has one DomWorker identity and one or more DomPartyAccount
    records linked via ``worker_id == party_id``.

    Lifecycle: onboarding → active → offboarding → terminated
    """
    __tablename__ = "dom_worker"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    worker_id: Mapped[str] = mapped_column(
        String(128), unique=True, nullable=False, index=True,
    )
    external_id: Mapped[str | None] = mapped_column(
        String(128), nullable=True, index=True,
    )  # ID from external payroll system (ADP, QuickBooks, etc.)
    email: Mapped[str | None] = mapped_column(String(256), nullable=True, index=True)
    first_name: Mapped[str] = mapped_column(String(128), nullable=False, default="")
    last_name: Mapped[str] = mapped_column(String(128), nullable=False, default="")
    display_name: Mapped[str] = mapped_column(String(256), nullable=False, default="")

    # Employment details
    status: Mapped[str] = mapped_column(
        String(32), nullable=False, default="onboarding", index=True,
    )  # onboarding | active | offboarding | terminated | suspended
    department: Mapped[str] = mapped_column(String(128), nullable=False, default="")
    title: Mapped[str] = mapped_column(String(128), nullable=False, default="")
    manager_worker_id: Mapped[str | None] = mapped_column(
        String(128), ForeignKey("dom_worker.worker_id", ondelete="SET NULL"), nullable=True,
    )
    hire_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    termination_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Payroll configuration
    pay_currency: Mapped[str] = mapped_column(String(8), nullable=False, default="USD")
    pay_schedule: Mapped[str] = mapped_column(
        String(32), nullable=False, default="biweekly",
    )  # weekly | biweekly | semi_monthly | monthly
    default_rail: Mapped[str] = mapped_column(
        String(32), nullable=False, default="push_to_debit",
    )  # push_to_debit | ach | rtp | fednow | usdc | xrpl | xlm

    # Group membership
    payout_group_id: Mapped[str | None] = mapped_column(
        String(128), ForeignKey("dom_payout_group.group_id", ondelete="SET NULL"),
        nullable=True, index=True,
    )

    # Location / jurisdiction
    country: Mapped[str] = mapped_column(String(2), nullable=False, default="US")
    region: Mapped[str] = mapped_column(String(64), nullable=False, default="")

    # Onboarding checklist (JSONB — tracks completed steps)
    onboarding_steps: Mapped[dict] = mapped_column(
        JSONBCompat(), nullable=False, server_default="{}",
    )

    # Metadata
    tags: Mapped[dict] = mapped_column(
        JSONBCompat(), nullable=False, server_default="[]",
    )  # Freeform tags for filtering
    metadata_: Mapped[dict] = mapped_column(
        "metadata", JSONBCompat(), nullable=False, server_default="{}",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )
    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    __table_args__ = (
        Index("ix_dom_worker_status", "status"),
        Index("ix_dom_worker_group", "payout_group_id"),
        Index("ix_dom_worker_dept", "department"),
        Index("ix_dom_worker_country", "country", "region"),
    )


# ---------------------------------------------------------------------------
# Payout Groups (Phase 2 — batch operations, pay schedules)
# ---------------------------------------------------------------------------

class DomPayoutGroup(DomBase):
    """Groups of workers for batch payout operations.

    A group defines shared payout settings: schedule, default rail,
    currency, and employer-level rules that constrain worker choices.
    """
    __tablename__ = "dom_payout_group"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    group_id: Mapped[str] = mapped_column(
        String(128), unique=True, nullable=False, index=True,
    )
    name: Mapped[str] = mapped_column(String(256), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False, default="")

    # Pay schedule defaults
    pay_schedule: Mapped[str] = mapped_column(
        String(32), nullable=False, default="biweekly",
    )  # weekly | biweekly | semi_monthly | monthly
    default_currency: Mapped[str] = mapped_column(String(8), nullable=False, default="USD")
    default_rail: Mapped[str] = mapped_column(
        String(32), nullable=False, default="push_to_debit",
    )

    # Employer rules — constrain what workers in this group can choose
    allowed_rails: Mapped[dict] = mapped_column(
        JSONBCompat(), nullable=False, server_default='["push_to_debit", "ach"]',
    )  # List of rails employees can choose from
    max_crypto_split_pct: Mapped[float] = mapped_column(
        Float, nullable=False, default=0.0,
    )  # Max % of payout that can go to crypto (0 = disabled)
    sonic_enabled: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False,
    )

    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    metadata_: Mapped[dict] = mapped_column(
        "metadata", JSONBCompat(), nullable=False, server_default="{}",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )
    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )


# ---------------------------------------------------------------------------
# Payout Rules (Phase 2 — per-worker payout configuration)
# ---------------------------------------------------------------------------

class DomPayoutRule(DomBase):
    """Per-worker payout configuration rules.

    Each rule defines how a specific worker gets paid. Multiple rules
    can coexist (e.g., 70% to bank via ACH, 30% to USDC wallet).

    Rules are constrained by the worker's payout group settings.
    """
    __tablename__ = "dom_payout_rule"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    rule_id: Mapped[str] = mapped_column(
        String(128), unique=True, nullable=False, index=True,
    )
    worker_id: Mapped[str] = mapped_column(
        String(128), nullable=False, index=True,
    )

    # Split configuration
    split_pct: Mapped[float] = mapped_column(
        Float, nullable=False, default=100.0,
    )  # Percentage of payout going to this destination
    rail: Mapped[str] = mapped_column(
        String(32), nullable=False, default="push_to_debit",
    )
    destination_account_id: Mapped[str | None] = mapped_column(
        String(128), nullable=True,
    )  # Links to DomPartyAccount.party_id + specific account

    # Limits
    min_amount: Mapped[float | None] = mapped_column(Float, nullable=True)
    max_amount: Mapped[float | None] = mapped_column(Float, nullable=True)

    # Priority (for ordering splits)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    metadata_: Mapped[dict] = mapped_column(
        "metadata", JSONBCompat(), nullable=False, server_default="{}",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )
    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    __table_args__ = (
        Index("ix_dom_payout_rule_worker", "worker_id"),
        CheckConstraint("split_pct >= 0 AND split_pct <= 100", name="ck_split_pct_range"),
    )


# ---------------------------------------------------------------------------
# Sonic Payout Preferences (Phase 2 — employee payout adapter)
# ---------------------------------------------------------------------------

class DomSonicPreference(DomBase):
    """Employee-facing Sonic payout preferences.

    This is the "adapter" — the simple surface where employees choose
    how they want to get paid within the constraints set by their employer.
    """
    __tablename__ = "dom_sonic_preference"

    id: Mapped[uuid.UUID] = mapped_column(
        GUID(), primary_key=True, default=uuid.uuid4,
    )
    worker_id: Mapped[str] = mapped_column(
        String(128), unique=True, nullable=False, index=True,
    )

    # Preference selections
    preferred_rail: Mapped[str] = mapped_column(
        String(32), nullable=False, default="push_to_debit",
    )
    fiat_split_pct: Mapped[float] = mapped_column(
        Float, nullable=False, default=100.0,
    )
    crypto_split_pct: Mapped[float] = mapped_column(
        Float, nullable=False, default=0.0,
    )
    crypto_rail: Mapped[str | None] = mapped_column(
        String(32), nullable=True,
    )  # usdc | xrpl | xlm | hbar
    crypto_wallet_address: Mapped[str | None] = mapped_column(
        String(256), nullable=True,
    )

    # Speed preference
    speed_preference: Mapped[str] = mapped_column(
        String(32), nullable=False, default="standard",
    )  # standard | fast (RTP/FedNow) | instant (streaming)

    # Consent flag
    sonic_consent: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False,
    )
    consent_given_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    metadata_: Mapped[dict] = mapped_column(
        "metadata", JSONBCompat(), nullable=False, server_default="{}",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False,
    )
    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    __table_args__ = (
        CheckConstraint(
            "fiat_split_pct + crypto_split_pct <= 100.01",
            name="ck_sonic_split_total",
        ),
    )
