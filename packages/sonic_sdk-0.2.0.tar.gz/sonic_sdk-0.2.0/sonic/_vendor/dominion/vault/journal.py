"""
VaultJournal — Persistent audit trail of all Dominion payout events.

Every payout, trust shift, bonus claim, and float anomaly is logged
to the vault journal.  In Tier 2+, each entry is SnapChore-hashed
for tamper-evident audit compliance.

The journal serves:
- Internal audit (what happened, when, why)
- External compliance (regulators, auditors)
- NUMA governance (payout pattern analysis)
- Dispute resolution (cryptographic proof of events)
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class EventType(str, Enum):
    PAYOUT_SUBMITTED = "payout_submitted"
    PAYOUT_COMPLETED = "payout_completed"
    PAYOUT_HELD = "payout_held"
    PAYOUT_FAILED = "payout_failed"
    TAX_HOLD = "tax_hold"
    MILESTONE_TRIGGERED = "milestone_triggered"
    MILESTONE_PAID = "milestone_paid"
    FLOAT_ANOMALY = "float_anomaly"
    TRUST_SHIFT = "trust_shift"
    GEC_EVENT = "gec_event"
    LEGACY_IMPORT = "legacy_import"
    TAX_CODE_EXPIRING = "tax_code_expiring"
    SONIC_SETTLEMENT = "sonic_settlement"
    WORKFLOW_STEP = "workflow_step"


@dataclass
class JournalEntry:
    """A single vault journal entry."""
    entry_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    event_type: EventType = EventType.PAYOUT_SUBMITTED
    worker_id: str = ""
    amount: Optional[float] = None
    currency: str = "USD"
    description: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)
    snapchore_hash: Optional[str] = None    # SnapChore seal (Tier 2+)
    gec_metrics: Optional[Dict[str, Any]] = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class VaultJournal:
    """
    Append-only audit journal for Dominion operations.

    In Tier 2+, each entry is sealed via DominionSbnClient.

    Phase 3: When ``repo`` is provided, entries are persisted to Postgres
    via ``JournalRepo``.  The in-memory list is retained as a write-through
    cache for backward-compatible queries and testing.
    """

    def __init__(
        self,
        sbn_client: Optional[Any] = None,
        tier: int = 1,
        repo: Optional[Any] = None,
    ):
        self._sbn = sbn_client         # DominionSbnClient
        self._tier = tier
        self._repo = repo               # repos.JournalRepo (Phase 3)
        self._entries: List[JournalEntry] = []

    def log(self, entry: JournalEntry) -> JournalEntry:
        """Append an entry to the journal, sealing via SnapChore if Tier 2+."""
        # Seal via SnapChore
        if self._tier >= 2 and self._sbn is not None and self._sbn.active:
            seal_payload = {
                "type": "vault_journal",
                "entry_id": entry.entry_id,
                "event_type": entry.event_type.value,
                "worker_id": entry.worker_id,
                "amount": entry.amount,
                "currency": entry.currency,
                "timestamp": entry.created_at.isoformat(),
            }
            entry.snapchore_hash = self._sbn.seal(seal_payload)

        self._entries.append(entry)
        return entry

    async def log_persistent(self, entry: JournalEntry) -> JournalEntry:
        """Log to both in-memory and Postgres (Phase 3).

        Call this instead of ``log()`` from async code paths when a repo
        is available.  Falls back to in-memory-only if no repo is configured.
        """
        entry = self.log(entry)
        if self._repo is not None:
            await self._repo.append(
                entry_id=entry.entry_id,
                event_type=entry.event_type.value,
                worker_id=entry.worker_id,
                amount=entry.amount,
                currency=entry.currency,
                description=entry.description,
                payload=entry.payload,
                snapchore_hash=entry.snapchore_hash,
                gec_metrics=entry.gec_metrics,
            )
        return entry

    def log_payout(
        self,
        worker_id: str,
        amount: float,
        currency: str,
        status: str,
        snapchore_hash: Optional[str] = None,
        gec_metrics: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> JournalEntry:
        """Convenience: log a payout event."""
        event_map = {
            "completed": EventType.PAYOUT_COMPLETED,
            "held": EventType.PAYOUT_HELD,
            "failed": EventType.PAYOUT_FAILED,
            "tax_hold": EventType.TAX_HOLD,
        }
        entry = JournalEntry(
            event_type=event_map.get(status, EventType.PAYOUT_SUBMITTED),
            worker_id=worker_id,
            amount=amount,
            currency=currency,
            description=f"Payout {status}: {amount} {currency} to {worker_id}",
            payload=metadata or {},
            snapchore_hash=snapchore_hash,
            gec_metrics=gec_metrics,
        )
        return self.log(entry)

    def log_tax_hold(
        self,
        worker_id: str,
        amount: float,
        errors: List[str],
    ) -> JournalEntry:
        """Log a tax hold event (hard stop)."""
        entry = JournalEntry(
            event_type=EventType.TAX_HOLD,
            worker_id=worker_id,
            amount=amount,
            description=f"TAX HOLD: {'; '.join(errors)}",
            payload={"errors": errors},
        )
        return self.log(entry)

    def log_sonic_settlement(
        self,
        worker_id: str,
        amount: float,
        sonic_tx_id: str,
        receipt_hash: Optional[str] = None,
    ) -> JournalEntry:
        """Log a Sonic settlement confirmation."""
        entry = JournalEntry(
            event_type=EventType.SONIC_SETTLEMENT,
            worker_id=worker_id,
            amount=amount,
            description=f"Sonic settled: tx={sonic_tx_id}",
            payload={"sonic_tx_id": sonic_tx_id, "receipt_hash": receipt_hash},
        )
        return self.log(entry)

    def query(
        self,
        worker_id: Optional[str] = None,
        event_type: Optional[EventType] = None,
        since: Optional[datetime] = None,
        limit: int = 100,
    ) -> List[JournalEntry]:
        """Query journal entries with optional filters."""
        results = self._entries
        if worker_id:
            results = [e for e in results if e.worker_id == worker_id]
        if event_type:
            results = [e for e in results if e.event_type == event_type]
        if since:
            results = [e for e in results if e.created_at >= since]
        return results[-limit:]
