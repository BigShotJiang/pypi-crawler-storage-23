"""
ReceiptManager — Cryptographic payout receipts via SnapChore.

Every payout in Tier 2+ gets a SnapChore receipt:
- The receipt seals the payout amount, worker, timestamp, and GEC metrics
- Workers can verify their receipts independently
- Receipts are indexed for audit and dispute resolution
- The receipt hash is written to the vault journal

This is the "nobody else has this" feature:
Cryptographic proof of every task that generated a paycheck,
verifiable by the worker, employer, or any auditor.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class ReceiptManager:
    """
    Manages SnapChore receipt creation and retrieval for payouts.

    Uses DominionSbnClient for SnapChore sealing.
    Active in Tier 2+ only.  In Tier 1, all methods are no-ops.

    Phase 3: When ``repo`` is provided, receipts are persisted to Postgres
    via ``ReceiptRepo``.  The in-memory dict is retained as a write-through
    cache for fast lookups during a single request cycle.
    """

    def __init__(
        self,
        sbn_client: Optional[Any] = None,
        tier: int = 1,
        project_id: str = "",
        repo: Optional[Any] = None,
    ):
        self._sbn = sbn_client         # DominionSbnClient
        self._tier = tier
        self._project_id = project_id
        self._repo = repo               # repos.ReceiptRepo (Phase 3)
        self._receipts: Dict[str, Dict[str, Any]] = {}  # Local cache

    async def create_receipt(
        self,
        worker_id: str,
        amount: float,
        currency: str,
        instruction_id: str,
        sonic_tx_id: Optional[str] = None,
        sonic_receipt_hash: Optional[str] = None,
        gec_metrics: Optional[Dict[str, Any]] = None,
        tax_withheld: float = 0.0,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        Create a SnapChore receipt for a completed payout.

        Returns the receipt with snapchore_hash, or None in Tier 1.
        """
        if self._tier < 2:
            return None

        receipt_payload = {
            "type": "dominion_payout_receipt",
            "worker_id": worker_id,
            "amount": amount,
            "currency": currency,
            "instruction_id": instruction_id,
            "project_id": self._project_id,
            "sonic_tx_id": sonic_tx_id,
            "sonic_receipt_hash": sonic_receipt_hash,
            "tax_withheld": tax_withheld,
            "net_amount": amount - tax_withheld,
            "gec_metrics": gec_metrics,
            "metadata": metadata or {},
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        # Seal via SBN SDK
        snapchore_hash = None
        if self._sbn is not None and self._sbn.active:
            try:
                snapchore_hash = self._sbn.seal(receipt_payload)
            except Exception:
                logger.warning(
                    "Failed to create SnapChore receipt for %s",
                    instruction_id,
                    exc_info=True,
                )

        receipt = {
            **receipt_payload,
            "snapchore_hash": snapchore_hash,
        }

        self._receipts[instruction_id] = receipt

        # Persist to Postgres (Phase 3)
        if self._repo is not None:
            try:
                await self._repo.create(
                    instruction_id=instruction_id,
                    worker_id=worker_id,
                    amount=amount,
                    currency=currency,
                    tax_withheld=tax_withheld,
                    net_amount=amount - tax_withheld,
                    project_id=self._project_id,
                    sonic_tx_id=sonic_tx_id,
                    sonic_receipt_hash=sonic_receipt_hash,
                    snapchore_hash=snapchore_hash,
                    gec_metrics=gec_metrics,
                    metadata=metadata,
                )
            except Exception:
                logger.warning(
                    "Failed to persist receipt for %s to DB",
                    instruction_id,
                    exc_info=True,
                )

        return receipt

    async def verify_receipt(self, instruction_id: str) -> Optional[Dict[str, Any]]:
        """Verify a receipt via SnapChore and Sonic."""
        receipt = self._receipts.get(instruction_id)
        if not receipt:
            return None

        verification: Dict[str, Any] = {
            "instruction_id": instruction_id,
            "snapchore_valid": False,
            "sonic_valid": False,
        }

        # Verify SnapChore hash
        if receipt.get("snapchore_hash") and self._sbn is not None:
            result = self._sbn.verify(receipt["snapchore_hash"])
            verification["snapchore_valid"] = result is not None

        return verification

    async def get_receipt(self, instruction_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a receipt by instruction ID (cache → DB fallback)."""
        cached = self._receipts.get(instruction_id)
        if cached is not None:
            return cached
        if self._repo is not None:
            row = await self._repo.get_by_instruction(instruction_id)
            if row is not None:
                return {
                    "instruction_id": row.instruction_id,
                    "worker_id": row.worker_id,
                    "amount": row.amount,
                    "currency": row.currency,
                    "snapchore_hash": row.snapchore_hash,
                    "sonic_tx_id": row.sonic_tx_id,
                    "net_amount": row.net_amount,
                }
        return None

    async def get_worker_receipts(
        self,
        worker_id: str,
        limit: int = 50,
    ) -> List[Dict[str, Any]]:
        """Retrieve all receipts for a worker (DB-backed when available)."""
        if self._repo is not None:
            rows = await self._repo.get_worker_receipts(worker_id, limit=limit)
            return [
                {
                    "instruction_id": r.instruction_id,
                    "worker_id": r.worker_id,
                    "amount": r.amount,
                    "currency": r.currency,
                    "snapchore_hash": r.snapchore_hash,
                    "sonic_tx_id": r.sonic_tx_id,
                    "net_amount": r.net_amount,
                }
                for r in rows
            ]
        # Fallback to in-memory
        results = [
            r for r in self._receipts.values()
            if r.get("worker_id") == worker_id
        ]
        return results[-limit:]
