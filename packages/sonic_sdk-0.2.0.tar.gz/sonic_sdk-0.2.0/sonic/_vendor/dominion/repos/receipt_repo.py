"""Async repository for SnapChore payout receipts."""

from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db.models import DomReceipt


class ReceiptRepo:
    """Replaces the in-memory ``ReceiptManager._receipts`` dict."""

    def __init__(self, session: AsyncSession):
        self._session = session

    async def create(
        self,
        *,
        instruction_id: str,
        worker_id: str,
        amount: float,
        currency: str = "USD",
        tax_withheld: float = 0.0,
        net_amount: float,
        project_id: str = "",
        sonic_tx_id: str | None = None,
        sonic_receipt_hash: str | None = None,
        snapchore_hash: str | None = None,
        gec_metrics: Dict[str, Any] | None = None,
        metadata: Dict[str, Any] | None = None,
    ) -> DomReceipt:
        row = DomReceipt(
            id=uuid.uuid4(),
            instruction_id=instruction_id,
            worker_id=worker_id,
            amount=amount,
            currency=currency,
            tax_withheld=tax_withheld,
            net_amount=net_amount,
            project_id=project_id,
            sonic_tx_id=sonic_tx_id,
            sonic_receipt_hash=sonic_receipt_hash,
            snapchore_hash=snapchore_hash,
            gec_metrics=gec_metrics,
            metadata_=metadata or {},
        )
        self._session.add(row)
        await self._session.flush()
        return row

    async def get_by_instruction(self, instruction_id: str) -> DomReceipt | None:
        stmt = select(DomReceipt).where(DomReceipt.instruction_id == instruction_id)
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_worker_receipts(
        self, worker_id: str, limit: int = 50,
    ) -> List[DomReceipt]:
        stmt = (
            select(DomReceipt)
            .where(DomReceipt.worker_id == worker_id)
            .order_by(DomReceipt.created_at.desc())
            .limit(limit)
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())
