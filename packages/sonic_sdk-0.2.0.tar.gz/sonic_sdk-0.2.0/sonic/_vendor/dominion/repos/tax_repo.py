"""Async repository for Tax domain (jurisdictions, codes, worker assignments)."""

from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from sqlalchemy import delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ..db.models import DomTaxCode, DomTaxJurisdiction, DomWorkerJurisdiction


class TaxRepo:
    """Replaces the in-memory dicts in ``TaxCodeRegistry``."""

    def __init__(self, session: AsyncSession):
        self._session = session

    # ----- Jurisdiction CRUD -----

    async def upsert_jurisdiction(
        self,
        *,
        jurisdiction_id: str,
        name: str,
        code: str,
        level: str = "federal",
        country: str = "US",
    ) -> DomTaxJurisdiction:
        stmt = select(DomTaxJurisdiction).where(
            DomTaxJurisdiction.jurisdiction_id == jurisdiction_id,
        )
        result = await self._session.execute(stmt)
        row = result.scalar_one_or_none()

        if row is None:
            row = DomTaxJurisdiction(
                id=uuid.uuid4(),
                jurisdiction_id=jurisdiction_id,
                name=name,
                code=code,
                level=level,
                country=country,
            )
            self._session.add(row)
        else:
            row.name = name
            row.code = code
            row.level = level
            row.country = country

        await self._session.flush()
        return row

    async def get_jurisdiction(self, jurisdiction_id: str) -> DomTaxJurisdiction | None:
        stmt = (
            select(DomTaxJurisdiction)
            .options(selectinload(DomTaxJurisdiction.tax_codes))
            .where(DomTaxJurisdiction.jurisdiction_id == jurisdiction_id)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_jurisdictions(self) -> List[DomTaxJurisdiction]:
        stmt = (
            select(DomTaxJurisdiction)
            .options(selectinload(DomTaxJurisdiction.tax_codes))
            .order_by(DomTaxJurisdiction.code)
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())

    # ----- Tax Code CRUD -----

    async def upsert_tax_code(
        self,
        *,
        code_id: str,
        jurisdiction_pk: uuid.UUID,
        jurisdiction_id: str,
        tax_type: str,
        name: str,
        rate: float = 0.0,
        flat_amount: float = 0.0,
        wage_base_limit: float | None = None,
        status: str = "active",
        effective_date=None,
        expiry_date=None,
        metadata: Dict[str, Any] | None = None,
    ) -> DomTaxCode:
        stmt = select(DomTaxCode).where(DomTaxCode.code_id == code_id)
        result = await self._session.execute(stmt)
        row = result.scalar_one_or_none()

        if row is None:
            row = DomTaxCode(
                id=uuid.uuid4(),
                code_id=code_id,
                jurisdiction_pk=jurisdiction_pk,
                jurisdiction_id=jurisdiction_id,
                tax_type=tax_type,
                name=name,
                rate=rate,
                flat_amount=flat_amount,
                wage_base_limit=wage_base_limit,
                status=status,
                effective_date=effective_date,
                expiry_date=expiry_date,
                metadata_=metadata or {},
            )
            self._session.add(row)
        else:
            row.rate = rate
            row.flat_amount = flat_amount
            row.wage_base_limit = wage_base_limit
            row.status = status
            row.effective_date = effective_date
            row.expiry_date = expiry_date

        await self._session.flush()
        return row

    async def get_codes_for_jurisdiction(self, jurisdiction_id: str) -> List[DomTaxCode]:
        stmt = (
            select(DomTaxCode)
            .where(DomTaxCode.jurisdiction_id == jurisdiction_id)
            .order_by(DomTaxCode.tax_type)
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())

    # ----- Worker assignments -----

    async def assign_worker(self, worker_id: str, jurisdiction_ids: List[str]) -> None:
        """Replace worker's jurisdiction assignments."""
        await self._session.execute(
            delete(DomWorkerJurisdiction).where(
                DomWorkerJurisdiction.worker_id == worker_id,
            )
        )
        for jid in jurisdiction_ids:
            self._session.add(DomWorkerJurisdiction(
                id=uuid.uuid4(),
                worker_id=worker_id,
                jurisdiction_id=jid,
            ))
        await self._session.flush()

    async def get_worker_jurisdiction_ids(self, worker_id: str) -> List[str]:
        stmt = (
            select(DomWorkerJurisdiction.jurisdiction_id)
            .where(DomWorkerJurisdiction.worker_id == worker_id)
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())

    async def get_worker_jurisdictions(self, worker_id: str) -> List[DomTaxJurisdiction]:
        """Load full jurisdiction objects (with codes) for a worker."""
        jids = await self.get_worker_jurisdiction_ids(worker_id)
        if not jids:
            return []
        stmt = (
            select(DomTaxJurisdiction)
            .options(selectinload(DomTaxJurisdiction.tax_codes))
            .where(DomTaxJurisdiction.jurisdiction_id.in_(jids))
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())

    # ----- Health summary -----

    async def health_summary(self) -> Dict[str, Any]:
        """Aggregate stats for CSK E-dimension."""
        jurisdictions = await self.list_jurisdictions()
        total_codes = 0
        active_codes = 0
        expiring_codes = 0

        for jur in jurisdictions:
            for tc in jur.tax_codes:
                total_codes += 1
                if tc.status == "active":
                    active_codes += 1

        # Count workers without assignments
        stmt = select(func.count(func.distinct(DomWorkerJurisdiction.worker_id)))
        result = await self._session.execute(stmt)
        total_workers = result.scalar() or 0

        return {
            "total_jurisdictions": len(jurisdictions),
            "total_tax_codes": total_codes,
            "active_tax_codes": active_codes,
            "expiring_tax_codes": expiring_codes,
            "total_workers": total_workers,
            "registry_health": active_codes / max(total_codes, 1),
        }
