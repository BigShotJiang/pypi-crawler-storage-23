"""Async repository for Lattice payroll DAG execution state."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Dict, List, Optional

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ..db.models import DomWorkflowRun, DomWorkflowStep


class WorkflowRepo:
    """Replaces in-memory ``PayrollWorkflow._completed_steps`` / ``_step_results``."""

    def __init__(self, session: AsyncSession):
        self._session = session

    # ----- Run lifecycle -----

    async def create_run(
        self,
        *,
        workflow_id: str,
        lattice_workflow_id: str | None = None,
        batch_id: str | None = None,
    ) -> DomWorkflowRun:
        row = DomWorkflowRun(
            id=uuid.uuid4(),
            workflow_id=workflow_id,
            lattice_workflow_id=lattice_workflow_id,
            batch_id=batch_id,
            status="active",
        )
        self._session.add(row)
        await self._session.flush()
        return row

    async def get_run(self, workflow_id: str) -> DomWorkflowRun | None:
        stmt = (
            select(DomWorkflowRun)
            .options(selectinload(DomWorkflowRun.steps))
            .where(DomWorkflowRun.workflow_id == workflow_id)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def complete_run(self, workflow_id: str, status: str = "completed") -> None:
        await self._session.execute(
            update(DomWorkflowRun)
            .where(DomWorkflowRun.workflow_id == workflow_id)
            .values(status=status, completed_at=datetime.now(timezone.utc))
        )
        await self._session.flush()

    # ----- Step completion -----

    async def complete_step(
        self,
        *,
        run_pk: uuid.UUID,
        step_id: str,
        success: bool = True,
        data: dict | None = None,
        error: str | None = None,
        snapchore_hash: str | None = None,
    ) -> DomWorkflowStep:
        row = DomWorkflowStep(
            id=uuid.uuid4(),
            run_pk=run_pk,
            step_id=step_id,
            success=success,
            data=data,
            error=error,
            snapchore_hash=snapchore_hash,
        )
        self._session.add(row)
        await self._session.flush()
        return row

    async def get_completed_step_ids(self, run_pk: uuid.UUID) -> List[str]:
        stmt = (
            select(DomWorkflowStep.step_id)
            .where(DomWorkflowStep.run_pk == run_pk)
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())

    async def get_active_runs(self) -> List[DomWorkflowRun]:
        stmt = (
            select(DomWorkflowRun)
            .options(selectinload(DomWorkflowRun.steps))
            .where(DomWorkflowRun.status == "active")
            .order_by(DomWorkflowRun.created_at)
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())
