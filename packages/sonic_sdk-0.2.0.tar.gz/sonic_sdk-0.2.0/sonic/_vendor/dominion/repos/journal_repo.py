"""Async repository for VaultJournal entries."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db.models import DomJournalEntry


class JournalRepo:
    """Replaces the in-memory ``VaultJournal._entries`` list."""

    def __init__(self, session: AsyncSession):
        self._session = session

    async def append(
        self,
        *,
        entry_id: str | None = None,
        event_type: str,
        worker_id: str = "",
        amount: float | None = None,
        currency: str = "USD",
        description: str = "",
        payload: Dict[str, Any] | None = None,
        snapchore_hash: str | None = None,
        gec_metrics: Dict[str, Any] | None = None,
    ) -> DomJournalEntry:
        row = DomJournalEntry(
            id=uuid.UUID(entry_id) if entry_id else uuid.uuid4(),
            event_type=event_type,
            worker_id=worker_id,
            amount=amount,
            currency=currency,
            description=description,
            payload=payload or {},
            snapchore_hash=snapchore_hash,
            gec_metrics=gec_metrics,
        )
        self._session.add(row)
        await self._session.flush()
        return row

    async def query(
        self,
        *,
        worker_id: str | None = None,
        event_type: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> List[DomJournalEntry]:
        stmt = select(DomJournalEntry).order_by(DomJournalEntry.created_at.desc())
        if worker_id:
            stmt = stmt.where(DomJournalEntry.worker_id == worker_id)
        if event_type:
            stmt = stmt.where(DomJournalEntry.event_type == event_type)
        if since:
            stmt = stmt.where(DomJournalEntry.created_at >= since)
        stmt = stmt.limit(limit)
        result = await self._session.execute(stmt)
        return list(result.scalars().all())

    async def get(self, entry_id: str) -> DomJournalEntry | None:
        stmt = select(DomJournalEntry).where(
            DomJournalEntry.id == uuid.UUID(entry_id),
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()
