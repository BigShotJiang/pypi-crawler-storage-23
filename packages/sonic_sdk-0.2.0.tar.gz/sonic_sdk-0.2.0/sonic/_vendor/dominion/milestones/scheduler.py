"""
MilestoneScheduler — Time-based and performance-based bonus triggers.

Capabilities:
- Yearly / 5-year / project-based bonus triggers
- Zero-lag execution (guaranteed payout at milestone timestamp)
- Integration with GEC scoring for performance-based milestones
- SnapChore attestation of milestone fulfillment (Tier 2+)

Every milestone resolution is logged to the vault journal.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional


class MilestoneType(str, Enum):
    TIME_BASED = "time_based"             # Anniversary, yearly, tenure
    PERFORMANCE = "performance"           # GEC score threshold
    PROJECT_COMPLETION = "project_completion"
    CUSTOM = "custom"                     # Org-defined trigger


class MilestoneStatus(str, Enum):
    SCHEDULED = "scheduled"
    ELIGIBLE = "eligible"                 # Conditions met, awaiting payout
    PAID = "paid"
    EXPIRED = "expired"
    CANCELLED = "cancelled"


@dataclass
class Milestone:
    """A scheduled or conditional bonus milestone."""
    milestone_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    worker_id: str = ""
    milestone_type: MilestoneType = MilestoneType.TIME_BASED
    description: str = ""
    bonus_amount: float = 0.0
    currency: str = "USD"
    status: MilestoneStatus = MilestoneStatus.SCHEDULED

    # Time-based trigger
    trigger_at: Optional[datetime] = None

    # Performance-based trigger
    gec0_threshold: Optional[float] = None     # Minimum GEC₀ to qualify
    trust_threshold: Optional[float] = None    # Minimum trust score

    # Crypto lock (for future-dated smart contract payouts)
    contract_lock_id: Optional[str] = None

    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    resolved_at: Optional[datetime] = None


class MilestoneScheduler:
    """
    Manages milestone lifecycle: schedule, evaluate, trigger, attest.

    Phase 3: When ``repo`` is provided (MilestoneRepo), writes are
    persisted to Postgres.  The in-memory dict is retained as a
    write-through cache for the duration of a single batch.
    """

    def __init__(self, tier: int = 1, repo: Optional[Any] = None):
        self._tier = tier
        self._repo = repo  # repos.MilestoneRepo (Phase 3)
        self._milestones: Dict[str, Milestone] = {}

    def schedule(self, milestone: Milestone) -> Milestone:
        """Register a new milestone."""
        self._milestones[milestone.milestone_id] = milestone
        return milestone

    async def schedule_persistent(self, milestone: Milestone) -> Milestone:
        """Schedule and persist to Postgres (Phase 3)."""
        self.schedule(milestone)
        if self._repo is not None:
            await self._repo.create(
                milestone_id=milestone.milestone_id,
                worker_id=milestone.worker_id,
                milestone_type=milestone.milestone_type.value,
                description=milestone.description,
                bonus_amount=milestone.bonus_amount,
                currency=milestone.currency,
                trigger_at=milestone.trigger_at,
                gec0_threshold=milestone.gec0_threshold,
                trust_threshold=milestone.trust_threshold,
                contract_lock_id=milestone.contract_lock_id,
                metadata=milestone.metadata,
            )
        return milestone

    def resolve_due(
        self,
        worker_id: str,
        now: Optional[datetime] = None,
        gec0_score: Optional[float] = None,
        trust_score: Optional[float] = None,
    ) -> List[Milestone]:
        """
        Check all milestones for a worker and return those that are due.

        Time-based: trigger_at <= now
        Performance-based: gec0_score >= threshold AND trust >= threshold
        """
        now = now or datetime.now(timezone.utc)
        due: List[Milestone] = []

        for ms in self._milestones.values():
            if ms.worker_id != worker_id:
                continue
            if ms.status != MilestoneStatus.SCHEDULED:
                continue

            triggered = False

            if ms.milestone_type == MilestoneType.TIME_BASED:
                if ms.trigger_at is not None and ms.trigger_at <= now:
                    triggered = True

            elif ms.milestone_type == MilestoneType.PERFORMANCE:
                gec_ok = (
                    gec0_score is not None
                    and ms.gec0_threshold is not None
                    and gec0_score >= ms.gec0_threshold
                )
                trust_ok = (
                    ms.trust_threshold is None
                    or (trust_score is not None and trust_score >= ms.trust_threshold)
                )
                if gec_ok and trust_ok:
                    triggered = True

            elif ms.milestone_type == MilestoneType.PROJECT_COMPLETION:
                # Resolved externally via mark_eligible()
                pass

            if triggered:
                ms.status = MilestoneStatus.ELIGIBLE
                ms.resolved_at = now
                due.append(ms)

        return due

    def mark_paid(self, milestone_id: str) -> None:
        """Mark a milestone as paid after Sonic confirms the payout."""
        if milestone_id in self._milestones:
            self._milestones[milestone_id].status = MilestoneStatus.PAID

    async def mark_paid_persistent(self, milestone_id: str) -> None:
        """Mark paid in both memory and Postgres."""
        self.mark_paid(milestone_id)
        if self._repo is not None:
            await self._repo.mark_paid(milestone_id)

    def mark_eligible(self, milestone_id: str) -> None:
        """Externally mark a milestone as eligible (e.g., project completion)."""
        if milestone_id in self._milestones:
            ms = self._milestones[milestone_id]
            if ms.status == MilestoneStatus.SCHEDULED:
                ms.status = MilestoneStatus.ELIGIBLE
                ms.resolved_at = datetime.now(timezone.utc)

    async def mark_eligible_persistent(self, milestone_id: str) -> None:
        """Mark eligible in both memory and Postgres."""
        self.mark_eligible(milestone_id)
        if self._repo is not None:
            await self._repo.mark_eligible(milestone_id)
