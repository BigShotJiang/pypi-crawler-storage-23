"""Dominion messenger — secure message encoding for Sonic execution."""

from .sonic_protocol import DominionMessenger, PayoutMessage

__all__ = ["DominionMessenger", "PayoutMessage"]
