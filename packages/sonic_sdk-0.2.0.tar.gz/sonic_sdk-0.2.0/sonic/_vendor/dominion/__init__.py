"""Dominion — Sovereign Compression Payroll Router & Reflex Engine.

Dominion is a reflexive sovereign routing and compression layer that
orchestrates Smart Block-based payouts across fiat, crypto, and hybrid
treasury systems.  It is GEC-native: every payout operation emits y/x
efficiency metrics and optional CSK vectors into the SBN analytics
pipeline, making it a first-class participant in NUMA governance.

Tier model:
  Tier 1 — Legacy payroll processing (no SBN integration)
  Tier 2 — Legacy + SnapChore attestation + GEC scoring + Sonic settlement
  Tier 3 — Tier 2 + Lightweight Tower Agent + NUMA governance + Translation Rules

Division: Tower Technologies, Brooks Holdings Inc.

Clients:
  DominionSbnClient  — wraps SBN Python SDK for SnapChore, Lattice, GEC, NUMA
  DominionSonicClient — HTTP client to Sonic settlement engine

Hard Stops:
  Tax codes are user-programmable and required. No tax codes = no operations.

Usage::

    from dominion import DominionSbnClient, DominionSonicClient

    sbn = DominionSbnClient(
        base_url="https://api.smartblocks.network",
        api_key="sbn_live_...",
        project_id="proj-dominion",
        tier=2,
    )
    sonic = DominionSonicClient(base_url="https://sonic.example.com")
"""

from __future__ import annotations

from ._version import __version__

from .sbn_client import DominionSbnClient
from .sonic_client import DominionSonicClient
from .translation_rules import DominionTranslationRule, DOMINION_TRANSLATION_RULES

__all__ = [
    # Clients
    "DominionSbnClient",
    "DominionSonicClient",
    # Translation rules
    "DominionTranslationRule",
    "DOMINION_TRANSLATION_RULES",
]
