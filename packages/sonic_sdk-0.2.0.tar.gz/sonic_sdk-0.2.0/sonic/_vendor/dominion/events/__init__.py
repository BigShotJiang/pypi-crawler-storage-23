"""Dominion event bus — Redis pub/sub for Agent Bridge."""
