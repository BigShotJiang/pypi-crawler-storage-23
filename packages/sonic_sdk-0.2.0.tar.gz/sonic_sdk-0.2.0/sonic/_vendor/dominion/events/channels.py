"""Redis channel definitions for Dominion event bus."""

# Pub/sub channels
CHANNEL_BATCH_COMPLETE = "dominion:events:batch_complete"
CHANNEL_FLOAT_UPDATE = "dominion:events:float_update"
CHANNEL_MILESTONE = "dominion:events:milestone"
CHANNEL_TAX_HOLD = "dominion:events:tax_hold"
CHANNEL_SONIC_SETTLEMENT = "dominion:events:sonic_settlement"
CHANNEL_NUMA_HINT = "dominion:events:numa_hint"
CHANNEL_SONIC_STREAM = "dominion:events:sonic_stream"

# Stream keys (Redis Streams for durable delivery)
STREAM_BRIDGE_EVENTS = "dominion:stream:bridge_events"

# Key prefixes
KEY_LATEST_BATCH = "dominion:state:latest_batch"
KEY_LATEST_FLOAT = "dominion:state:latest_float"
KEY_TAX_HEALTH = "dominion:state:tax_health"

ALL_CHANNELS = [
    CHANNEL_BATCH_COMPLETE,
    CHANNEL_FLOAT_UPDATE,
    CHANNEL_MILESTONE,
    CHANNEL_TAX_HOLD,
    CHANNEL_SONIC_SETTLEMENT,
    CHANNEL_SONIC_STREAM,
    CHANNEL_NUMA_HINT,
]
