"""Dominion SBN bridge — communication layer between Dominion and the SBN network.

This package provides the client-side interfaces for Dominion to communicate
with SnapChore, NUMA, and Sonic without tight coupling.  Each client is
optional — in Tier 1, no SBN communication occurs.

The bridge is also what the lightweight Tower Agent consumes to get
Dominion operational data for suggestions and observations.
"""

from .snapchore_client import DominionSnapChoreClient
from .numa_reporter import DominionNUMAReporter
from .agent_bridge import DominionAgentBridge

__all__ = [
    "DominionSnapChoreClient",
    "DominionNUMAReporter",
    "DominionAgentBridge",
]
