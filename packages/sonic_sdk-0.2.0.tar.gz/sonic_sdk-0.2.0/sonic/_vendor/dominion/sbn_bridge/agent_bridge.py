"""
DominionAgentBridge — Communication interface between Dominion and Tower Agent.

This is the key integration point.  The bridge exposes Dominion's
operational state to the lightweight Tower Agent without tight coupling.

Communication pattern:
  Dominion Engine → (events) → AgentBridge → (context) → DominionAgent
  DominionAgent  → (queries) → AgentBridge → (API)     → Dominion Engine

Phase 3: The bridge now supports three backends (layered):
  1. In-memory buffer  — always available, used for tests / Tier 1
  2. Redis pub/sub      — real-time delivery (RedisBridge)
  3. Postgres table     — durable fallback (DomBridgeEvent via session)

When Redis is available, events are published there AND buffered locally.
When Redis is unavailable, events are written to Postgres for the agent
to poll from.  Both paths coexist.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class DominionAgentBridge:
    """
    Bidirectional bridge between the Dominion engine and Tower Agent.

    Dominion pushes:
    - Batch completion summaries
    - Float health updates
    - Milestone status changes
    - GEC metrics per batch
    - Tax hold events

    Agent pulls:
    - Pending events (drain)
    - Latest batch summary
    - Current float status
    - Tax registry health

    This decoupling means:
    - Dominion works without an agent (Tier 1/2)
    - The agent works without Dominion internals (just the bridge API)
    - Upgrade/downgrade doesn't break either side
    """

    def __init__(
        self,
        sbn_client: Optional[Any] = None,
        sonic_client: Optional[Any] = None,
        tax_registry: Optional[Any] = None,
        tier: int = 3,
        redis_bridge: Optional[Any] = None,
        session: Optional[Any] = None,
    ):
        self._sbn = sbn_client         # DominionSbnClient
        self._sonic = sonic_client      # DominionSonicClient
        self._tax = tax_registry        # TaxCodeRegistry
        self._tier = tier
        self._redis = redis_bridge      # events.RedisBridge (Phase 3)
        self._session = session         # AsyncSession (Phase 3)

        # Event buffer (always available as fallback)
        self._pending_events: List[Dict[str, Any]] = []
        self._latest_batch_summary: Optional[Dict[str, Any]] = None
        self._latest_float_health: Optional[Dict[str, Any]] = None

    # ------------------------------------------------------------------
    # Dominion → Agent (push events)
    # ------------------------------------------------------------------

    def push_batch_complete(
        self,
        batch_summary: Dict[str, Any],
    ) -> None:
        """Called by DominionRouter after a batch completes."""
        self._latest_batch_summary = batch_summary
        self._pending_events.append({
            "type": "batch_complete",
            "data": batch_summary,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

    async def push_batch_complete_persistent(
        self, batch_summary: Dict[str, Any],
    ) -> None:
        """Push to in-memory + Redis + DB (Phase 3)."""
        self.push_batch_complete(batch_summary)
        if self._redis is not None and self._redis.active:
            await self._redis.push_batch_complete(batch_summary)
        await self._persist_event("batch_complete", batch_summary)

    def push_float_update(
        self,
        float_health: Dict[str, Any],
    ) -> None:
        """Called by FloatGuard when float status changes."""
        self._latest_float_health = float_health
        self._pending_events.append({
            "type": "float_update",
            "data": float_health,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

    async def push_float_update_persistent(
        self, float_health: Dict[str, Any],
    ) -> None:
        """Push to in-memory + Redis + DB (Phase 3)."""
        self.push_float_update(float_health)
        if self._redis is not None and self._redis.active:
            await self._redis.push_float_update(float_health)
        await self._persist_event("float_update", float_health)

    def push_milestone_event(
        self,
        milestone_data: Dict[str, Any],
    ) -> None:
        """Called by MilestoneScheduler on milestone state change."""
        self._pending_events.append({
            "type": "milestone_event",
            "data": milestone_data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

    async def push_milestone_event_persistent(
        self, milestone_data: Dict[str, Any],
    ) -> None:
        self.push_milestone_event(milestone_data)
        if self._redis is not None and self._redis.active:
            await self._redis.push_milestone_event(milestone_data)
        await self._persist_event("milestone_event", milestone_data)

    def push_tax_hold(
        self,
        tax_hold_data: Dict[str, Any],
    ) -> None:
        """Called by DominionRouter when a tax hold occurs."""
        self._pending_events.append({
            "type": "tax_hold",
            "data": tax_hold_data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

    async def push_tax_hold_persistent(
        self, tax_hold_data: Dict[str, Any],
    ) -> None:
        self.push_tax_hold(tax_hold_data)
        if self._redis is not None and self._redis.active:
            await self._redis.push_tax_hold(tax_hold_data)
        await self._persist_event("tax_hold", tax_hold_data)

    # ------------------------------------------------------------------
    # Agent → Dominion (pull queries)
    # ------------------------------------------------------------------

    def drain_events(self) -> List[Dict[str, Any]]:
        """Pull all pending events from in-memory buffer."""
        events = self._pending_events.copy()
        self._pending_events.clear()
        return events

    async def drain_events_persistent(
        self, consumer_name: str = "agent-0",
    ) -> List[Dict[str, Any]]:
        """Pull events from Redis stream (Phase 3), fall back to in-memory."""
        if self._redis is not None and self._redis.active:
            return await self._redis.drain_events(consumer_name=consumer_name)
        return self.drain_events()

    def get_latest_batch_summary(self) -> Optional[Dict[str, Any]]:
        """Get the most recent batch summary."""
        return self._latest_batch_summary

    async def get_latest_batch_summary_persistent(self) -> Optional[Dict[str, Any]]:
        """Read from Redis (Phase 3), fall back to in-memory."""
        if self._redis is not None and self._redis.active:
            cached = await self._redis.get_latest_batch()
            if cached is not None:
                return cached
        return self._latest_batch_summary

    def get_latest_float_health(self) -> Optional[Dict[str, Any]]:
        """Get the most recent float health snapshot."""
        return self._latest_float_health

    async def get_latest_float_health_persistent(self) -> Optional[Dict[str, Any]]:
        if self._redis is not None and self._redis.active:
            cached = await self._redis.get_latest_float()
            if cached is not None:
                return cached
        return self._latest_float_health

    def get_tax_registry_health(self) -> Optional[Dict[str, Any]]:
        """Get tax registry health summary for agent context."""
        if self._tax is not None:
            return self._tax.health_summary()
        return None

    async def check_sonic_health(self) -> bool:
        """Check if Sonic settlement engine is healthy."""
        if self._sonic is not None and self._sonic.active:
            return await self._sonic.health()
        return False

    async def query_sonic_receipts(self, tx_id: str) -> List[Dict[str, Any]]:
        """Query Sonic for settlement receipts."""
        if self._sonic is not None and self._sonic.active:
            return await self._sonic.get_receipts(tx_id)
        return []

    # ------------------------------------------------------------------
    # Internal: DB persistence
    # ------------------------------------------------------------------

    async def _persist_event(
        self, event_type: str, data: Dict[str, Any],
    ) -> None:
        """Write event to Postgres DomBridgeEvent table."""
        if self._session is None:
            return
        try:
            import uuid
            from ..db.models import DomBridgeEvent
            row = DomBridgeEvent(
                id=uuid.uuid4(),
                event_type=event_type,
                data=data,
            )
            self._session.add(row)
            await self._session.flush()
        except Exception:
            logger.warning("Failed to persist bridge event: %s", event_type, exc_info=True)
