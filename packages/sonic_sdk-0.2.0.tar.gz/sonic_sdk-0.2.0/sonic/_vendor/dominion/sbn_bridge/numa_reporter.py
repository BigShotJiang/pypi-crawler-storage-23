"""
DominionNUMAReporter — Reports operational metrics to NUMA.

Sends Dominion's GEC data, float health, and payout patterns to NUMA
so the organizational intelligence layer can:
- Monitor payroll health across the org
- Detect anomalies (unusual payout patterns, float stress)
- Generate CSK intervention hints
- Coordinate cross-product signals

Uses ``POST /api/blocks`` to record each operational signal as a
SmartBlock (block type ``meta`` for system events, ``stimulus`` for
anomalies).  This is the correct SBN primitive for recording events
rather than ``POST /attest`` which is for slot summary attestation.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class DominionNUMAReporter:
    """
    Reports Dominion operational data to NUMA via SmartBlocks.

    Active in Tier 2+.  In Tier 3, also consumes NUMA signals
    (via the DominionAgent's NUMABridge).
    """

    def __init__(
        self,
        sbn_client: Optional[Any] = None,
        tier: int = 1,
        project_id: str = "",
    ):
        self._sbn = sbn_client         # DominionSbnClient
        self._tier = tier
        self._project_id = project_id

    async def report_batch_metrics(
        self,
        batch_summary: Dict[str, Any],
    ) -> None:
        """
        Report a completed batch's metrics to NUMA via a SmartBlock.

        Uses block type ``meta`` (metadata-only / system event) with
        the batch metrics in the payload metadata.
        """
        if self._tier < 2 or self._sbn is None or not self._sbn.active:
            return

        try:
            self._sbn.create_block(
                domain="finance.payroll",
                payload={
                    "type": "meta",
                    "domain": "finance.payroll",
                    "metadata": {
                        "source": "dominion.batch_metrics",
                        "project_id": self._project_id,
                        **batch_summary,
                    },
                },
            )
            logger.info("Batch metrics reported to NUMA via SmartBlock")
        except Exception:
            logger.warning("Failed to report batch metrics to NUMA", exc_info=True)

    async def report_float_anomaly(
        self,
        anomaly: Dict[str, Any],
    ) -> None:
        """Report a float anomaly to NUMA as a ``stimulus`` SmartBlock."""
        if self._tier < 2 or self._sbn is None or not self._sbn.active:
            return

        try:
            self._sbn.create_block(
                domain="finance.payroll",
                payload={
                    "type": "stimulus",
                    "domain": "finance.payroll",
                    "actions": [
                        {
                            "action": "float_anomaly_detected",
                            "reinforced": True,
                            "score": anomaly.get("severity", 0.5),
                        }
                    ],
                    "metadata": {
                        "source": "dominion.float_guard",
                        "project_id": self._project_id,
                        **anomaly,
                    },
                },
            )
            logger.info("Float anomaly reported to NUMA via SmartBlock")
        except Exception:
            logger.warning("Failed to report float anomaly to NUMA", exc_info=True)

    async def report_tax_event(
        self,
        event: Dict[str, Any],
    ) -> None:
        """Report a tax-related event as an ``audit`` SmartBlock."""
        if self._tier < 2 or self._sbn is None or not self._sbn.active:
            return

        try:
            self._sbn.create_block(
                domain="finance.payroll",
                payload={
                    "type": "audit",
                    "domain": "finance.payroll",
                    "actions": [
                        {
                            "action": event.get("event_type", "tax_event"),
                            "reinforced": True,
                            "score": 1.0,
                        }
                    ],
                    "metadata": {
                        "source": "dominion.tax_registry",
                        "project_id": self._project_id,
                        **event,
                    },
                },
            )
            logger.info("Tax event reported to NUMA via SmartBlock")
        except Exception:
            logger.warning("Failed to report tax event to NUMA", exc_info=True)
