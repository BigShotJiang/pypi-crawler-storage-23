"""
DominionSnapChoreClient — SnapChore integration for payout attestation.

Handles:
- Sealing payout receipts (Tier 2+)
- Creating audit chains per worker
- Verifying block completion proofs

Uses DominionSbnClient for all SnapChore operations.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class DominionSnapChoreClient:
    """
    Client interface to SBN SnapChore for Dominion operations.

    Delegates to DominionSbnClient.seal() and .verify().
    Active in Tier 2+ only.
    """

    def __init__(
        self,
        sbn_client: Optional[Any] = None,
        tier: int = 1,
        project_id: str = "",
    ):
        self._sbn = sbn_client         # DominionSbnClient
        self._tier = tier
        self._project_id = project_id
        self._worker_chains: Dict[str, str] = {}  # worker_id → chain_id

    async def seal_payout(
        self,
        payout_payload: Dict[str, Any],
    ) -> Optional[str]:
        """
        Seal a payout event via SnapChore and return the hash.

        The payload includes: worker, amount, GEC metrics, timestamp.
        Returns the snapchore_hash or None if Tier 1.
        """
        if self._tier < 2 or self._sbn is None:
            return None

        try:
            return self._sbn.seal(payout_payload)
        except Exception:
            logger.warning("Failed to seal payout via SnapChore", exc_info=True)
            return None

    async def seal_to_worker_chain(
        self,
        worker_id: str,
        payload: Dict[str, Any],
    ) -> Optional[str]:
        """Seal a payload to a worker's audit chain."""
        if self._tier < 2 or self._sbn is None:
            return None

        chain_id = self._worker_chains.get(worker_id)
        if chain_id:
            return self._sbn.seal_chain(chain_id, payload)

        # First seal for this worker — creates chain
        snap_hash = self._sbn.seal(payload)
        if snap_hash:
            self._worker_chains[worker_id] = f"chain_{worker_id}"
        return snap_hash

    async def verify_block(self, block_hash: str) -> bool:
        """Verify a Smart Block completion hash is valid."""
        if self._sbn is None or not self._sbn.active:
            return False

        try:
            result = self._sbn.verify(block_hash)
            return result is not None
        except Exception:
            logger.warning("Failed to verify block %s", block_hash, exc_info=True)
            return False
