"""
GECEmitter — Non-blocking emission of efficiency events to the SBN pipeline.

Every payout batch produces a GEC event with y/x metrics and optional CSK.
The emitter never blocks the payout pipeline — if SBN is unreachable,
events are logged for manual review.

Uses ``POST /api/gec/compute`` to delegate GEC math to the SBN server
rather than computing locally.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from .csk_provider import DominionCSKProvider, BatchTelemetry
from .frontier_config import DOMINION_FRONTIER

logger = logging.getLogger(__name__)


class GECEmitter:
    """
    Emits GEC efficiency events for Dominion payout operations.

    In Tier 2+, events are sent to SBN via ``POST /api/gec/compute``.
    In Tier 1, this is a no-op.

    Usage:
        emitter = GECEmitter(sbn_client=sbn, tier=2)
        await emitter.emit_batch(y=487, x=500, telemetry=batch_telemetry)
    """

    def __init__(
        self,
        sbn_client: Optional[Any] = None,
        tier: int = 1,
        project_id: str = "",
        api_key_id: str = "",
    ):
        self._sbn = sbn_client         # DominionSbnClient
        self._tier = tier
        self._project_id = project_id
        self._api_key_id = api_key_id
        self._csk_provider = DominionCSKProvider()
        self._frontier_id = DOMINION_FRONTIER["id"]

    async def emit_batch(
        self,
        y: int,
        x: int,
        telemetry: Optional[BatchTelemetry] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        Emit a GEC efficiency event for a payout batch.

        Calls ``POST /api/gec/compute`` on SBN rather than computing
        GEC locally.  The server resolves formulas, computes metrics,
        metallic classification, and attractor state.

        Parameters
        ----------
        y : int
            Payouts processed successfully.
        x : int
            Payouts submitted (total).
        telemetry : BatchTelemetry, optional
            Operational telemetry for CSK computation.

        Returns
        -------
        The SBN GEC compute response, or None if Tier 1 / SBN inactive.
        """
        if self._tier < 2:
            return None

        # Compute CSK if telemetry provided
        csk: Optional[Dict[str, float]] = None
        if telemetry is not None:
            csk = self._csk_provider.compute(telemetry)

        # Call POST /api/gec/compute — let SBN do the math
        try:
            if self._sbn is not None and self._sbn.active:
                # Use the gec.compute endpoint via the SDK
                request: Dict[str, Any] = {
                    "y": float(y),
                    "x": float(x),
                    "frontier_id": self._frontier_id,
                    "alpha": 0.05,
                }
                if csk is not None:
                    request["csk"] = csk

                result = self._sbn.raw.gec.compute(**request)
                logger.info(
                    "GEC computed via SBN: y=%d x=%d frontier=%s gec0=%s",
                    y, x, self._frontier_id,
                    result.get("gec0") if result else "n/a",
                )
                return result
            logger.debug("SBN inactive — GEC emission skipped")
        except Exception:
            # Never block payroll on analytics failure
            logger.warning(
                "Failed to compute GEC via SBN (logged for retry): y=%d x=%d",
                y, x,
                exc_info=True,
            )

        return None
