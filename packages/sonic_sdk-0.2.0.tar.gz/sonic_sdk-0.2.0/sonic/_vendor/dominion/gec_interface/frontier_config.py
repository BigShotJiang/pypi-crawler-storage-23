"""
Frontier configuration for Dominion's payroll domain.

Defines the finance.payroll frontier ceiling and policy thresholds.
These are registered with the GEC catalogue on startup (Tier 2+).
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Frontier definition — the theoretical performance ceiling for payroll.
#
# c_max = 0.98 because no payroll system achieves 100% accuracy sustained.
# Tax code changes, edge cases, timing drift, and schema evolution ensure
# that ~98% is the realistic frontier.  Scores above c_max trigger a
# frontier audit (GEC Theorem 3.2).
# ---------------------------------------------------------------------------

DOMINION_FRONTIER = {
    "id": "finance.payroll",
    "domain": "finance.payroll",
    "c_max": 0.98,
    "ci": [0.95, 1.00],
    "version": "v1",
    "notes": {
        "cmax_source": "empirical_payroll_2025",
        "confidence": 0.85,
        "description": (
            "Payroll processing accuracy and efficiency frontier. "
            "Measures records processed correctly vs. total submitted, "
            "inclusive of tax compliance, deduction accuracy, and timing."
        ),
        "source_refs": [
            {
                "title": "Dominion Payroll Efficiency Baseline",
                "note": "Derived from internal batch processing benchmarks.",
            },
        ],
    },
}


# ---------------------------------------------------------------------------
# Policy thresholds — stricter than general workloads because finance.
#
# min_accept_gec: 0.90 (vs. default 0.20 for ai.general)
# Payroll errors are expensive; we hold the bar high.
# ---------------------------------------------------------------------------

DOMINION_POLICY = {
    "min_accept_gec": 0.90,
    "min_confidence": 0.80,
    "max_anomaly_factor": 1.02,
}
