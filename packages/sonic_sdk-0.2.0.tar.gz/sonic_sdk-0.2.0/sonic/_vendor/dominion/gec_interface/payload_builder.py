"""
Payload builder — Constructs the ``POST /api/gec/compute`` request payload.

This builds the exact request shape the SBN GEC endpoint expects::

    { y, x, frontier_id, var_y?, var_x?, alpha?, csk? }

All GEC math (GEC₀, CI, metallic classification, attractor) is done
**server-side** by SBN.  This module only builds the request; it does
not compute GEC locally.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from .frontier_config import DOMINION_FRONTIER


def build_dominion_gec_payload(
    y: int,
    x: int,
    csk: Optional[Dict[str, float]] = None,
    cmax_override: Optional[float] = None,
    *,
    alpha: float = 0.05,
    var_y: Optional[float] = None,
    var_x: Optional[float] = None,
) -> Dict[str, Any]:
    """
    Build the ``POST /api/gec/compute`` request payload for a Dominion batch.

    The server resolves frontiers, computes GEC₀, CI, CSK health,
    metallic classification, and attractor state.  This function only
    builds the request — no local math.

    Parameters
    ----------
    y : int
        Successful payout count.
    x : int
        Total payouts submitted.
    csk : dict, optional
        CSK vector from DominionCSKProvider.
    cmax_override : float, optional
        Unused — retained for backward compatibility.  The server
        resolves c_max from the frontier registry.
    alpha : float
        Significance level for confidence interval (default 0.05).
    var_y : float, optional
        Variance of y (for CI computation).
    var_x : float, optional
        Variance of x (for CI computation).
    """
    result: Dict[str, Any] = {
        "y": float(y),
        "x": float(x),
        "frontier_id": DOMINION_FRONTIER["id"],
        "alpha": alpha,
    }
    if var_y is not None:
        result["var_y"] = var_y
    if var_x is not None:
        result["var_x"] = var_x
    if csk:
        result["csk"] = csk

    return result
