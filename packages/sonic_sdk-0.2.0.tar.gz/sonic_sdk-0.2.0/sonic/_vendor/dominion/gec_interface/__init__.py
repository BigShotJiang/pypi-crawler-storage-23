"""Dominion GEC interface — the layer that makes Dominion SBN-native.

This package handles all GEC compliance:
- Emitting y/x efficiency metrics per payout operation
- Computing application-level CSK vectors from operational data
- Building canonical GEC payloads for SnapChore hashing
- Registering the finance.payroll frontier

The GEC interface is inactive in Tier 1 (legacy mode).
In Tier 2+, every payout batch emits GEC metrics into the SBN pipeline.
"""

from .emitter import GECEmitter
from .csk_provider import DominionCSKProvider
from .payload_builder import build_dominion_gec_payload
from .frontier_config import DOMINION_FRONTIER, DOMINION_POLICY

__all__ = [
    "GECEmitter",
    "DominionCSKProvider",
    "build_dominion_gec_payload",
    "DOMINION_FRONTIER",
    "DOMINION_POLICY",
]
