"""
FiatStreamer — Real-time fiat pay streaming via ACH, RTP, FedNow.

Decomposes a payout into micro-payments streamed over a time window.
Workers earn and receive in near-real-time rather than waiting for
a bi-weekly batch.

Streaming eligibility requires:
- Worker trust score >= 0.7 (or default trust in legacy mode)
- Minimum payout amount ($10)
- FloatGuard HEALTHY status
- Routing source supports real-time rails (RTP/FedNow preferred)

Uses DominionSonicClient for actual disbursement.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum
from typing import Any, Dict, List, Optional


class FiatRail(str, Enum):
    ACH = "ach"                 # Next-day batch
    ACH_SAME_DAY = "ach_same_day"
    RTP = "rtp"                 # Real-Time Payments (instant)
    FEDNOW = "fednow"          # FedNow instant
    SEPA = "sepa"              # EU
    SWIFT = "swift"            # International wire
    PUSH_TO_DEBIT = "push_to_debit"  # Visa Direct / Mastercard Send


@dataclass
class StreamConfig:
    """Configuration for a fiat streaming session."""
    rail: FiatRail = FiatRail.RTP
    interval_seconds: int = 60          # Payout every N seconds
    duration_seconds: int = 3600        # Total streaming window
    min_micro_payment: float = 0.01     # Minimum per-interval amount


class FiatStreamer:
    """
    Manages fiat pay streaming sessions.

    Integrates with DominionSonicClient for actual disbursement.
    Each micro-payment is a separate Sonic payout for auditability.
    """

    def __init__(
        self,
        sonic_client: Optional[Any] = None,
        default_config: Optional[StreamConfig] = None,
    ):
        self._sonic = sonic_client      # DominionSonicClient
        self._config = default_config or StreamConfig()

    def plan_stream(
        self,
        total_amount: float,
        config: Optional[StreamConfig] = None,
    ) -> List[Dict[str, Any]]:
        """
        Plan a streaming session — returns the schedule of micro-payments.

        Does not execute; call execute_stream() to actually send.
        """
        cfg = config or self._config
        num_intervals = max(1, cfg.duration_seconds // cfg.interval_seconds)
        per_interval = total_amount / num_intervals

        if per_interval < cfg.min_micro_payment:
            # Amount too small to stream — fall back to single payment
            return [{"amount": total_amount, "interval": 0, "rail": cfg.rail.value}]

        return [
            {
                "amount": round(per_interval, 6),
                "interval": i,
                "offset_seconds": i * cfg.interval_seconds,
                "rail": cfg.rail.value,
            }
            for i in range(num_intervals)
        ]

    async def execute_stream(
        self,
        worker_id: str,
        plan: List[Dict[str, Any]],
        routing_source: str = "",
        destination: str = "",
    ) -> List[Dict[str, Any]]:
        """
        Execute a streaming plan by sending micro-payments via Sonic.

        Opens an SBN-backed stream before sending, routes every
        micro-payment into the same slot, then closes the stream
        to produce a Merkle root over all attested blocks.
        """
        results = []
        stream_id: Optional[str] = None

        if self._sonic is not None and self._sonic.active:
            # Open a stream so all micro-payments share one SBN slot
            from ..sonic_client import OpenStreamRequest

            total = sum(Decimal(str(s["amount"])) for s in plan)
            handle = await self._sonic.open_stream(OpenStreamRequest(
                worker_id=worker_id,
                total_amount=total,
                currency="USD",
                interval_seconds=self._config.interval_seconds,
                duration_seconds=self._config.duration_seconds,
                metadata={"type": "fiat_stream", "rail": self._config.rail.value},
            ))
            if handle.stream_id:
                stream_id = handle.stream_id

        for step in plan:
            if self._sonic is not None and self._sonic.active:
                from ..sonic_client import SonicPayoutRequest

                req = SonicPayoutRequest(
                    recipient_id=destination or worker_id,
                    amount=Decimal(str(step["amount"])),
                    currency="USD",
                    rail=self._rail_to_sonic(step.get("rail", "rtp")),
                    stream_id=stream_id,
                    metadata={
                        "stream_interval": step["interval"],
                        "worker_id": worker_id,
                        "type": "fiat_stream",
                    },
                )
                sonic_result = await self._sonic.execute_payout(req)
                results.append({
                    "worker_id": worker_id,
                    "amount": step["amount"],
                    "interval": step["interval"],
                    "status": "completed" if sonic_result.success else "failed",
                    "sonic_tx_id": sonic_result.tx_id,
                    "error": sonic_result.error,
                })
            else:
                results.append({
                    "worker_id": worker_id,
                    "amount": step["amount"],
                    "interval": step["interval"],
                    "status": "planned",
                })

        # Close the stream to compute Merkle root
        if stream_id and self._sonic is not None and self._sonic.active:
            receipt = await self._sonic.close_stream(stream_id)
            for r in results:
                r["stream_id"] = stream_id
                r["merkle_root"] = receipt.merkle_root

        return results

    @staticmethod
    def _rail_to_sonic(rail: str) -> str:
        """Map FiatRail to Sonic rail identifier."""
        mapping = {
            "rtp": "stripe_transfer",
            "fednow": "stripe_transfer",
            "ach": "moov_ach",
            "ach_same_day": "moov_ach",
            "push_to_debit": "stripe_transfer",
            "sepa": "stripe_transfer",
            "swift": "stripe_transfer",
        }
        return mapping.get(rail, "stripe_transfer")
