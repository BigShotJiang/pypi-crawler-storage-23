"""
CryptoStreamer — Real-time crypto pay streaming.

Supports: USDC, XLM, XRPL, HBAR
Delivers micro-payments on-chain at configurable intervals.

For crypto streaming, each micro-payment is an on-chain transaction.
Gas/fee optimization groups micro-payments when the chain supports
batched transactions (e.g., XRPL Payment Channels, XLM path payments).

Uses DominionSonicClient for actual disbursement.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum
from typing import Any, Dict, List, Optional


class CryptoChain(str, Enum):
    XRPL = "xrpl"
    XLM = "xlm"
    HBAR = "hbar"
    USDC_ETH = "usdc_eth"
    USDC_SOL = "usdc_sol"


@dataclass
class CryptoStreamConfig:
    """Configuration for a crypto streaming session."""
    chain: CryptoChain = CryptoChain.USDC_SOL
    interval_seconds: int = 60
    duration_seconds: int = 3600
    use_payment_channel: bool = True    # Use channels for fee optimization
    min_micro_payment: float = 0.001


class CryptoStreamer:
    """
    Manages crypto pay streaming sessions.

    Payment channel mode (XRPL, XLM):
      Opens a channel, streams off-chain claims, settles on close.
      Lower fees, higher throughput, but requires channel setup.

    Direct mode (all chains):
      Each micro-payment is an individual on-chain transaction.
      Higher fees but simpler and immediately settled.

    Uses DominionSonicClient for on-chain execution via Circle.
    """

    def __init__(
        self,
        sonic_client: Optional[Any] = None,
        default_config: Optional[CryptoStreamConfig] = None,
    ):
        self._sonic = sonic_client      # DominionSonicClient
        self._config = default_config or CryptoStreamConfig()

    def plan_stream(
        self,
        total_amount: float,
        destination_wallet: str,
        config: Optional[CryptoStreamConfig] = None,
    ) -> List[Dict[str, Any]]:
        """Plan a crypto streaming session."""
        cfg = config or self._config
        num_intervals = max(1, cfg.duration_seconds // cfg.interval_seconds)
        per_interval = total_amount / num_intervals

        if per_interval < cfg.min_micro_payment:
            return [{
                "amount": total_amount,
                "interval": 0,
                "chain": cfg.chain.value,
                "destination": destination_wallet,
                "mode": "direct",
            }]

        mode = "channel" if cfg.use_payment_channel else "direct"

        return [
            {
                "amount": round(per_interval, 6),
                "interval": i,
                "offset_seconds": i * cfg.interval_seconds,
                "chain": cfg.chain.value,
                "destination": destination_wallet,
                "mode": mode,
            }
            for i in range(num_intervals)
        ]

    async def execute_stream(
        self,
        worker_id: str,
        plan: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Execute a crypto streaming plan via Sonic.

        Opens an SBN-backed stream, routes every micro-payment into
        the same slot, then closes the stream for a Merkle root.
        """
        results = []
        stream_id: Optional[str] = None

        if self._sonic is not None and self._sonic.active:
            from ..sonic_client import OpenStreamRequest

            total = sum(Decimal(str(s["amount"])) for s in plan)
            handle = await self._sonic.open_stream(OpenStreamRequest(
                worker_id=worker_id,
                total_amount=total,
                currency="USDC",
                interval_seconds=self._config.interval_seconds,
                duration_seconds=self._config.duration_seconds,
                metadata={"type": "crypto_stream", "chain": self._config.chain.value},
            ))
            if handle.stream_id:
                stream_id = handle.stream_id

        for step in plan:
            if self._sonic is not None and self._sonic.active:
                from ..sonic_client import SonicPayoutRequest

                req = SonicPayoutRequest(
                    recipient_id=step.get("destination", ""),
                    amount=Decimal(str(step["amount"])),
                    currency="USDC",
                    rail="circle_usdc",
                    stream_id=stream_id,
                    metadata={
                        "stream_interval": step["interval"],
                        "worker_id": worker_id,
                        "chain": step["chain"],
                        "mode": step["mode"],
                        "type": "crypto_stream",
                    },
                )
                sonic_result = await self._sonic.execute_payout(req)
                results.append({
                    "worker_id": worker_id,
                    "amount": step["amount"],
                    "interval": step["interval"],
                    "chain": step["chain"],
                    "status": "completed" if sonic_result.success else "failed",
                    "sonic_tx_id": sonic_result.tx_id,
                    "error": sonic_result.error,
                })
            else:
                results.append({
                    "worker_id": worker_id,
                    "amount": step["amount"],
                    "interval": step["interval"],
                    "chain": step["chain"],
                    "status": "planned",
                })

        # Close the stream to compute Merkle root
        if stream_id and self._sonic is not None and self._sonic.active:
            receipt = await self._sonic.close_stream(stream_id)
            for r in results:
                r["stream_id"] = stream_id
                r["merkle_root"] = receipt.merkle_root

        return results
