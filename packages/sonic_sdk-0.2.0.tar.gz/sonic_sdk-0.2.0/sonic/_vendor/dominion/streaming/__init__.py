"""Dominion streaming — real-time pay streaming via Sonic PayStream.

PayStreamAdapter is the primary interface.  It delegates all streaming
to Sonic's server-side PayStream API (windowed accrual, g_ewma risk
policy, micro-payouts, SBN attestation).

FiatStreamer and CryptoStreamer are retained for backward compatibility
but are deprecated.  The fiat-vs-crypto distinction collapses into a
``rail`` parameter on the PayStream.
"""

from .pay_stream_adapter import PayStreamAdapter, StreamOpenResult

# Deprecated — use PayStreamAdapter instead
from .fiat_stream import FiatStreamer
from .crypto_stream import CryptoStreamer

__all__ = [
    "PayStreamAdapter",
    "StreamOpenResult",
    # Deprecated
    "FiatStreamer",
    "CryptoStreamer",
]
