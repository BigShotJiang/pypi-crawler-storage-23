"""
TaxCodeRegistry — User-programmable tax codes with hard-stop enforcement.

Every worker MUST have at least one tax jurisdiction assigned.
Every jurisdiction MUST have active, non-expired tax codes.
Missing or expired tax codes halt all payout operations for that worker.

Tax codes are configured via the Dominion user dashboard (Phase 4).
Until then, they are registered programmatically at startup.

This module provides:
- TaxCode: a single tax rule (federal, state, local, etc.)
- TaxJurisdiction: a geographic/legal tax authority
- WithholdingRule: computed withholding for a specific payout
- TaxCodeRegistry: the registry that validates and computes
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class TaxType(str, Enum):
    FEDERAL = "federal"
    STATE = "state"
    LOCAL = "local"
    FICA_SS = "fica_social_security"
    FICA_MEDICARE = "fica_medicare"
    UNEMPLOYMENT = "unemployment"
    CUSTOM = "custom"


class TaxStatus(str, Enum):
    ACTIVE = "active"
    EXPIRED = "expired"
    PENDING = "pending"     # Awaiting user configuration
    DISABLED = "disabled"


@dataclass
class TaxCode:
    """A single tax rule within a jurisdiction."""
    code_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    jurisdiction_id: str = ""
    tax_type: TaxType = TaxType.FEDERAL
    name: str = ""
    rate: float = 0.0                   # Percentage (e.g. 22.0 for 22%)
    flat_amount: float = 0.0            # Fixed deduction (if applicable)
    wage_base_limit: Optional[float] = None  # Max wages subject to this tax
    status: TaxStatus = TaxStatus.ACTIVE
    effective_date: Optional[date] = None
    expiry_date: Optional[date] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def is_active(self) -> bool:
        if self.status != TaxStatus.ACTIVE:
            return False
        today = date.today()
        if self.effective_date and today < self.effective_date:
            return False
        if self.expiry_date and today > self.expiry_date:
            return False
        return True

    @property
    def is_expiring_soon(self) -> bool:
        """True if expiry is within 30 days."""
        if not self.expiry_date:
            return False
        days_left = (self.expiry_date - date.today()).days
        return 0 < days_left <= 30


@dataclass
class TaxJurisdiction:
    """A tax authority (country/state/city) with its tax codes."""
    jurisdiction_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""                   # e.g. "US Federal", "California", "NYC"
    code: str = ""                   # e.g. "US", "US-CA", "US-CA-NYC"
    level: str = "federal"           # federal, state, local
    country: str = "US"
    tax_codes: List[TaxCode] = field(default_factory=list)

    @property
    def has_active_codes(self) -> bool:
        return any(tc.is_active for tc in self.tax_codes)

    @property
    def expiring_codes(self) -> List[TaxCode]:
        return [tc for tc in self.tax_codes if tc.is_expiring_soon]


@dataclass
class WithholdingRule:
    """Computed withholding for a specific payout."""
    tax_code_id: str = ""
    tax_type: TaxType = TaxType.FEDERAL
    jurisdiction_name: str = ""
    gross_amount: float = 0.0
    withheld_amount: float = 0.0
    effective_rate: float = 0.0      # Actual rate applied (may differ from code rate)
    note: str = ""


@dataclass
class TaxValidationResult:
    """Result of tax validation for a worker payout."""
    valid: bool = False
    worker_id: str = ""
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    withholdings: List[WithholdingRule] = field(default_factory=list)
    total_withheld: float = 0.0
    net_after_tax: float = 0.0


class TaxCodeRegistry:
    """Registry of tax codes and jurisdictions.

    This is the hard-stop enforcement point. Before any payout is
    processed, the registry validates:

    1. The worker has at least one jurisdiction assigned
    2. Every assigned jurisdiction has active, non-expired tax codes
    3. All required tax types are present (federal at minimum)

    If validation fails, the payout is placed in TAX_HOLD status
    and an event is logged to the vault journal.
    """

    def __init__(self) -> None:
        self._jurisdictions: Dict[str, TaxJurisdiction] = {}
        self._worker_jurisdictions: Dict[str, List[str]] = {}  # worker_id → [jurisdiction_ids]

    # ------------------------------------------------------------------
    # Jurisdiction management
    # ------------------------------------------------------------------

    def register_jurisdiction(self, jurisdiction: TaxJurisdiction) -> TaxJurisdiction:
        """Register a tax jurisdiction with its codes."""
        self._jurisdictions[jurisdiction.jurisdiction_id] = jurisdiction
        logger.info("Tax jurisdiction registered: %s (%s)", jurisdiction.name, jurisdiction.code)
        return jurisdiction

    def get_jurisdiction(self, jurisdiction_id: str) -> Optional[TaxJurisdiction]:
        return self._jurisdictions.get(jurisdiction_id)

    def list_jurisdictions(self) -> List[TaxJurisdiction]:
        return list(self._jurisdictions.values())

    # ------------------------------------------------------------------
    # Worker-jurisdiction assignment
    # ------------------------------------------------------------------

    def assign_worker(self, worker_id: str, jurisdiction_ids: List[str]) -> None:
        """Assign tax jurisdictions to a worker."""
        self._worker_jurisdictions[worker_id] = jurisdiction_ids
        logger.info(
            "Worker %s assigned to %d jurisdictions",
            worker_id,
            len(jurisdiction_ids),
        )

    def get_worker_jurisdictions(self, worker_id: str) -> List[TaxJurisdiction]:
        """Get all jurisdictions assigned to a worker."""
        jids = self._worker_jurisdictions.get(worker_id, [])
        return [self._jurisdictions[jid] for jid in jids if jid in self._jurisdictions]

    # ------------------------------------------------------------------
    # HARD STOP validation
    # ------------------------------------------------------------------

    def validate_worker(self, worker_id: str, gross_amount: float) -> TaxValidationResult:
        """Validate that a worker's tax setup is complete and compute withholdings.

        This is the HARD STOP gate. Returns ``valid=False`` if:
        - No jurisdictions assigned
        - Any jurisdiction has no active codes
        - Federal tax code is missing

        If valid, computes all applicable withholdings.
        """
        result = TaxValidationResult(worker_id=worker_id, gross_amount=gross_amount)

        # Check 1: Worker has jurisdictions assigned
        jurisdictions = self.get_worker_jurisdictions(worker_id)
        if not jurisdictions:
            result.errors.append(
                f"No tax jurisdictions assigned to worker {worker_id}. "
                "Configure tax codes in the Dominion dashboard before processing payouts."
            )
            return result

        # Check 2: Every jurisdiction has active codes
        has_federal = False
        for jur in jurisdictions:
            if not jur.has_active_codes:
                result.errors.append(
                    f"Jurisdiction '{jur.name}' ({jur.code}) has no active tax codes. "
                    "Update tax configuration before processing."
                )
                continue

            # Check for expiring codes (warning, not error)
            for tc in jur.expiring_codes:
                result.warnings.append(
                    f"Tax code '{tc.name}' in {jur.name} expires on {tc.expiry_date}. "
                    "Renew before expiry to avoid payout holds."
                )

            # Compute withholdings for active codes
            for tc in jur.tax_codes:
                if not tc.is_active:
                    continue

                if tc.tax_type == TaxType.FEDERAL:
                    has_federal = True

                withholding = self._compute_withholding(tc, gross_amount)
                if withholding.withheld_amount > 0:
                    result.withholdings.append(withholding)

        # Check 3: Federal tax must be present
        if not has_federal:
            result.errors.append(
                f"No active federal tax code found for worker {worker_id}. "
                "Federal withholding is required."
            )

        # Compute totals
        if not result.errors:
            result.valid = True
            result.total_withheld = sum(w.withheld_amount for w in result.withholdings)
            result.net_after_tax = gross_amount - result.total_withheld

        return result

    def _compute_withholding(self, code: TaxCode, gross_amount: float) -> WithholdingRule:
        """Compute withholding for a single tax code against gross amount."""
        taxable = gross_amount
        if code.wage_base_limit is not None:
            taxable = min(taxable, code.wage_base_limit)

        withheld = code.flat_amount + (taxable * code.rate / 100.0)

        return WithholdingRule(
            tax_code_id=code.code_id,
            tax_type=code.tax_type,
            jurisdiction_name="",  # Filled by caller
            gross_amount=gross_amount,
            withheld_amount=round(withheld, 2),
            effective_rate=round(withheld / gross_amount * 100, 4) if gross_amount > 0 else 0,
        )

    # ------------------------------------------------------------------
    # Registry health (feeds CSK E-dimension)
    # ------------------------------------------------------------------

    def health_summary(self) -> Dict[str, Any]:
        """Registry health for CSK E-dimension reporting."""
        total_codes = 0
        active_codes = 0
        expiring_codes = 0
        workers_with_no_jurisdictions = 0

        for jur in self._jurisdictions.values():
            total_codes += len(jur.tax_codes)
            active_codes += sum(1 for tc in jur.tax_codes if tc.is_active)
            expiring_codes += len(jur.expiring_codes)

        for worker_id, jids in self._worker_jurisdictions.items():
            if not jids:
                workers_with_no_jurisdictions += 1

        return {
            "total_jurisdictions": len(self._jurisdictions),
            "total_tax_codes": total_codes,
            "active_tax_codes": active_codes,
            "expiring_tax_codes": expiring_codes,
            "total_workers": len(self._worker_jurisdictions),
            "workers_without_jurisdictions": workers_with_no_jurisdictions,
            "registry_health": active_codes / max(total_codes, 1),
        }

    @property
    def has_any_codes(self) -> bool:
        """True if at least one active tax code exists anywhere."""
        return any(jur.has_active_codes for jur in self._jurisdictions.values())
