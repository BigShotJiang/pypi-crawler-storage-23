"""
FloatGuard — Validates payout velocity against treasury float.

Monitors treasury liquidity and gates disbursements:
- Slows or pauses payout under liquidity stress
- Flags float anomalies to NUMA & Sonic
- Provides GEC R-dimension (Resources) data for CSK computation

The float guard is the safety valve between Dominion's payout engine
and actual money movement.  It never blocks silently — every hold
generates an auditable event.

Tiered behaviour:
  - Tier 1: Standalone — local float tracking only.
  - Tier 2: Checks Sonic health before approving payouts.
  - Tier 3: Delegates float checks to Stillpoint treasury engine.
            Falls back to local if Stillpoint is unreachable.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class FloatStatus(str, Enum):
    HEALTHY = "healthy"           # Full velocity allowed
    THROTTLED = "throttled"       # Reduced velocity — spreading payouts
    BLOCKED = "blocked"           # Payouts held until float recovers
    UNKNOWN = "unknown"           # Unreachable — fail-safe


@dataclass
class LiquidityCheck:
    """Result of a float validation check."""
    status: FloatStatus = FloatStatus.UNKNOWN
    available_float: float = 0.0
    required_float: float = 0.0
    utilization_ratio: float = 0.0    # available / required → feeds GEC R
    reason: Optional[str] = None
    sonic_healthy: bool = False
    stillpoint_healthy: bool = False
    checked_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def resource_score(self) -> float:
        """CSK R-dimension value: how well-resourced is the float?

        Returns a [0, 1] score where 1.0 = ample liquidity, 0.0 = empty.
        """
        if self.required_float <= 0:
            return 1.0
        return min(1.0, max(0.0, self.available_float / self.required_float))


class FloatGuard:
    """
    Treasury float gatekeeper.

    In Tier 1 (standalone), uses configured float amount.
    In Tier 2+, checks Sonic health and queries configured float.
    In Tier 3, delegates float management to Stillpoint when available.

    Phase 3: When ``repo`` is provided (FloatRepo), commitments are
    persisted to Postgres per-instruction.  The in-memory scalar is
    retained for fast checks within a single batch cycle.
    """

    def __init__(
        self,
        sonic_client: Optional[Any] = None,
        configured_float: float = 100_000.0,
        min_float_ratio: float = 0.2,
        throttle_threshold: float = 0.4,
        tier: int = 1,
        repo: Optional[Any] = None,
        stillpoint_client: Optional[Any] = None,
    ):
        self._sonic = sonic_client      # DominionSonicClient
        self._stillpoint = stillpoint_client  # DominionStillpointClient
        self._configured_float = configured_float
        self._min_float_ratio = min_float_ratio
        self._throttle_threshold = throttle_threshold
        self._tier = tier
        self._repo = repo               # repos.FloatRepo (Phase 3)
        self._committed: float = 0.0    # Running total of committed payouts

    async def check(
        self,
        amount: float,
        currency: str = "USD",
        routing_source: str = "",
    ) -> LiquidityCheck:
        """
        Validate that sufficient float exists for a payout.

        In Tier 3 with an active Stillpoint client, delegates the headroom
        check to Stillpoint for an authoritative, cross-consumer answer.
        Falls back to local computation if Stillpoint is unreachable.
        """
        sonic_ok = await self._check_sonic_health()
        stillpoint_ok = await self._check_stillpoint_health()

        # Tier 3: delegate to Stillpoint if reachable
        if self._tier >= 3 and self._stillpoint_active and stillpoint_ok:
            result = await self._stillpoint.check_headroom(amount, currency)
            if result.success:
                if result.approved:
                    status = FloatStatus.HEALTHY
                    reason = None
                else:
                    status = FloatStatus.BLOCKED
                    reason = (
                        f"Stillpoint denied: headroom_after={result.headroom_after:.2f}, "
                        f"band={result.health_band_after}"
                    )
                return LiquidityCheck(
                    status=status,
                    available_float=result.headroom_after + amount if result.approved else result.headroom_after,
                    required_float=amount,
                    utilization_ratio=1.0 if not result.approved else 0.5,
                    reason=reason,
                    sonic_healthy=sonic_ok,
                    stillpoint_healthy=True,
                )
            # Stillpoint returned an error — fall through to local
            logger.warning("Stillpoint headroom check failed, falling back to local: %s", result.error)

        # Local float computation (Tier 1-2, or Tier 3 fallback)
        available = await self._get_available_float(currency, routing_source)
        ratio = available / amount if amount > 0 else 1.0

        if not sonic_ok and self._tier >= 2:
            status = FloatStatus.UNKNOWN
            reason = "Sonic settlement engine unreachable — fail-safe hold"
        elif not stillpoint_ok and self._tier >= 3:
            status = FloatStatus.UNKNOWN
            reason = "Stillpoint treasury unreachable — fail-safe hold"
        elif ratio < self._min_float_ratio:
            status = FloatStatus.BLOCKED
            reason = (
                f"Float utilization {ratio:.2%} below minimum "
                f"{self._min_float_ratio:.2%}"
            )
        elif ratio < self._throttle_threshold:
            status = FloatStatus.THROTTLED
            reason = (
                f"Float utilization {ratio:.2%} below throttle "
                f"threshold {self._throttle_threshold:.2%}"
            )
        else:
            status = FloatStatus.HEALTHY
            reason = None

        return LiquidityCheck(
            status=status,
            available_float=available,
            required_float=amount,
            utilization_ratio=ratio,
            reason=reason,
            sonic_healthy=sonic_ok,
            stillpoint_healthy=stillpoint_ok,
        )

    async def _get_available_float(
        self,
        currency: str,
        routing_source: str,
    ) -> float:
        """Get available float from configured treasury amount minus committed.

        Phase 3: When a repo is present, reads the authoritative committed
        total from Postgres instead of relying on the in-memory scalar.
        """
        if self._repo is not None:
            committed = await self._repo.total_committed(currency=currency)
        else:
            committed = self._committed
        return max(0.0, self._configured_float - committed)

    async def _check_sonic_health(self) -> bool:
        """Check if Sonic is reachable (Tier 2+ only)."""
        if self._tier < 2 or self._sonic is None:
            return True  # Tier 1: assume healthy
        try:
            return await self._sonic.health()
        except Exception:
            logger.warning("Sonic health check failed", exc_info=True)
            return False

    @property
    def _stillpoint_active(self) -> bool:
        """True if a Stillpoint client is configured and initialised."""
        return self._stillpoint is not None and getattr(self._stillpoint, "active", False)

    async def _check_stillpoint_health(self) -> bool:
        """Check if Stillpoint is reachable (Tier 3 only)."""
        if self._tier < 3 or not self._stillpoint_active:
            return True  # Tier 1-2: assume healthy (not used)
        try:
            return await self._stillpoint.health()
        except Exception:
            logger.warning("Stillpoint health check failed", exc_info=True)
            return False

    def commit(self, amount: float) -> None:
        """Reserve float for an in-flight payout."""
        self._committed += amount

    async def commit_persistent(
        self,
        instruction_id: str,
        amount: float,
        currency: str = "USD",
        *,
        pay_stream_id: Optional[str] = None,
        stream_window_seq: Optional[int] = None,
    ) -> None:
        """Reserve float and persist to Postgres (Phase 3).

        In Tier 3 with Stillpoint, also commits to Stillpoint's centralised
        ledger. Local persistence is always maintained as a fallback.
        """
        self.commit(amount)
        if self._repo is not None:
            await self._repo.commit(instruction_id, amount, currency)

        # Tier 3: also commit to Stillpoint (best-effort, local is primary)
        if self._stillpoint_active:
            result = await self._stillpoint.commit_float(
                instruction_id, amount, currency,
                pay_stream_id=pay_stream_id,
                stream_window_seq=stream_window_seq,
            )
            if not result.success:
                logger.warning(
                    "Stillpoint commit failed (local committed): %s",
                    result.error,
                )

    def release(self, amount: float) -> None:
        """Release float after settlement or cancellation."""
        self._committed = max(0.0, self._committed - amount)

    async def release_persistent(self, instruction_id: str, amount: float) -> None:
        """Release float and persist to Postgres (Phase 3).

        In Tier 3 with Stillpoint, also releases in Stillpoint.
        """
        self.release(amount)
        if self._repo is not None:
            await self._repo.release(instruction_id)

        # Tier 3: also release in Stillpoint (best-effort)
        if self._stillpoint_active:
            result = await self._stillpoint.release_float(instruction_id)
            if not result.success:
                logger.warning(
                    "Stillpoint release failed (local released): %s",
                    result.error,
                )

    async def get_float_health(self) -> Dict[str, Any]:
        """Aggregate float health for GEC CSK R-dimension reporting."""
        available = await self._get_available_float("USD", "")
        sonic_ok = await self._check_sonic_health()
        stillpoint_ok = await self._check_stillpoint_health()

        total = self._configured_float
        utilization = self._committed / total if total > 0 else 0.0

        health: Dict[str, Any] = {
            "total_available": available,
            "total_committed": self._committed,
            "total_configured": total,
            "utilization_ratio": round(utilization, 4),
            "sonic_healthy": sonic_ok,
            "status": (
                FloatStatus.HEALTHY.value if utilization < self._throttle_threshold
                else FloatStatus.THROTTLED.value if utilization < (1.0 - self._min_float_ratio)
                else FloatStatus.BLOCKED.value
            ),
        }

        if self._stillpoint_active:
            health["stillpoint_healthy"] = stillpoint_ok

        return health
