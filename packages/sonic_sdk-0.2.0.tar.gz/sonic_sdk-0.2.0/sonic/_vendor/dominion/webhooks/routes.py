"""
FastAPI webhook routes for Dominion.

Endpoints:
  POST /dominion/webhooks/sonic        — Sonic settlement callbacks
  POST /dominion/webhooks/sonic/stream — Sonic PayStream lifecycle events
  POST /dominion/webhooks/numa         — NUMA hint broadcasts
  GET  /dominion/webhooks/health       — Webhook receiver health check

These routes are mounted into the main app or run standalone.
Signature verification follows the SBN HMAC-SHA256 scheme.

Security (Phase 1):
  - HMAC-SHA256 signature verification (fail-closed)
  - Timestamp validation (±5 min window)
  - Replay/nonce deduplication
  - Pydantic payload validation
  - Idempotency enforcement
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import os
from typing import Any, Dict

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from pydantic import ValidationError
from sqlalchemy.ext.asyncio import AsyncSession

from ..db.session import get_session
from ..events.redis_bridge import RedisBridge
from ..security.idempotency import get_idempotency_registry
from ..security.replay_guard import get_replay_guard
from ..security.validation import validate_numa_hint, validate_sonic_settlement
from .handlers import handle_numa_hint, handle_sonic_settlement, handle_sonic_stream_event

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/dominion/webhooks", tags=["dominion-webhooks"])

# Shared bridge instance (initialized at startup)
_bridge: RedisBridge | None = None


def set_bridge(bridge: RedisBridge) -> None:
    global _bridge
    _bridge = bridge


def _verify_signature(
    body: bytes,
    signature: str | None,
    timestamp: str | None,
    secret: str,
) -> bool:
    """Verify HMAC-SHA256 signature: v1=hex(hmac(secret, timestamp.body))."""
    if not signature or not timestamp:
        return False
    expected = hmac.new(
        secret.encode(),
        f"{timestamp}.".encode() + body,
        hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(f"v1={expected}", signature)


# ---------------------------------------------------------------------------
# Sonic settlement callback
# ---------------------------------------------------------------------------

@router.post("/sonic")
async def sonic_webhook(
    request: Request,
    session: AsyncSession = Depends(get_session),
    x_sbn_signature: str | None = Header(None),
    x_sbn_timestamp: str | None = Header(None),
) -> Dict[str, str]:
    """Receive Sonic settlement.complete callback."""
    body = await request.body()

    # --- Phase 1B: Signature verification (fail-closed) ---
    secret = os.getenv("DOMINION_SONIC_WEBHOOK_SECRET", "")
    if not secret:
        logger.error("DOMINION_SONIC_WEBHOOK_SECRET not configured — rejecting Sonic webhook")
        raise HTTPException(status_code=503, detail="webhook_secret_not_configured")
    signature_valid = _verify_signature(body, x_sbn_signature, x_sbn_timestamp, secret)
    if not signature_valid:
        raise HTTPException(status_code=401, detail="invalid_signature")

    # --- Phase 1A: Replay guard (timestamp + nonce dedup) ---
    payload = await request.json()
    tx_id = payload.get("tx_id", "")

    replay_guard = get_replay_guard()
    replay_result = replay_guard.check(
        timestamp=x_sbn_timestamp,
        nonce=tx_id,
        signature_present=signature_valid,
        secret_configured=bool(secret),
    )
    if not replay_result.accepted:
        logger.warning(
            "Sonic webhook rejected by replay guard: tx=%s verdict=%s reason=%s",
            tx_id, replay_result.verdict.value, replay_result.reason,
        )
        if replay_result.verdict.value.startswith("reject_duplicate"):
            raise HTTPException(status_code=409, detail="duplicate_event")
        raise HTTPException(status_code=401, detail=replay_result.verdict.value)

    # --- Phase 1C: Input validation ---
    try:
        validated = validate_sonic_settlement(payload)
    except ValidationError as exc:
        logger.warning("Sonic webhook validation failed: %s", exc.errors())
        raise HTTPException(status_code=422, detail=str(exc.errors()))

    # --- Phase 1D: Idempotency check ---
    registry = get_idempotency_registry()
    existing = registry.check("sonic_settlement", tx_id)
    if existing is not None and existing.response is not None:
        logger.info("Sonic webhook idempotent hit: tx=%s", tx_id)
        return existing.response

    if not registry.claim("sonic_settlement", tx_id):
        raise HTTPException(status_code=409, detail="duplicate_event")

    # Process settlement
    try:
        result = await handle_sonic_settlement(
            validated.model_dump(), session, bridge=_bridge,
        )
        registry.complete("sonic_settlement", tx_id, response=result)
        return result
    except Exception:
        registry.fail("sonic_settlement", tx_id)
        raise


# ---------------------------------------------------------------------------
# Sonic PayStream lifecycle events
# ---------------------------------------------------------------------------

@router.post("/sonic/stream")
async def sonic_stream_webhook(
    request: Request,
    session: AsyncSession = Depends(get_session),
    x_sbn_signature: str | None = Header(None),
    x_sbn_timestamp: str | None = Header(None),
) -> Dict[str, str]:
    """Receive Sonic PayStream lifecycle events (window_closed, closed, policy_changed)."""
    body = await request.body()

    # --- Signature verification (same secret as settlement) ---
    secret = os.getenv("DOMINION_SONIC_WEBHOOK_SECRET", "")
    if not secret:
        logger.error("DOMINION_SONIC_WEBHOOK_SECRET not configured — rejecting stream webhook")
        raise HTTPException(status_code=503, detail="webhook_secret_not_configured")
    signature_valid = _verify_signature(body, x_sbn_signature, x_sbn_timestamp, secret)
    if not signature_valid:
        raise HTTPException(status_code=401, detail="invalid_signature")

    # --- Replay guard ---
    payload = await request.json()
    pay_stream_id = payload.get("pay_stream_id", "")
    event_type = payload.get("event_type", "")
    nonce = f"{pay_stream_id}:{event_type}:{x_sbn_timestamp or ''}"

    replay_guard = get_replay_guard()
    replay_result = replay_guard.check(
        timestamp=x_sbn_timestamp,
        nonce=nonce,
        signature_present=signature_valid,
        secret_configured=bool(secret),
    )
    if not replay_result.accepted:
        logger.warning(
            "Sonic stream webhook rejected by replay guard: stream=%s event=%s",
            pay_stream_id, event_type,
        )
        if replay_result.verdict.value.startswith("reject_duplicate"):
            raise HTTPException(status_code=409, detail="duplicate_event")
        raise HTTPException(status_code=401, detail=replay_result.verdict.value)

    # --- Idempotency check ---
    registry = get_idempotency_registry()
    idemp_key = f"{pay_stream_id}:{event_type}"
    existing = registry.check("sonic_stream", idemp_key)
    if existing is not None and existing.response is not None:
        logger.info("Sonic stream webhook idempotent hit: %s", idemp_key)
        return existing.response

    if not registry.claim("sonic_stream", idemp_key):
        raise HTTPException(status_code=409, detail="duplicate_event")

    # Process stream event
    try:
        result = await handle_sonic_stream_event(
            payload, session, bridge=_bridge,
        )
        registry.complete("sonic_stream", idemp_key, response=result)
        return result
    except Exception:
        registry.fail("sonic_stream", idemp_key)
        raise


# ---------------------------------------------------------------------------
# NUMA hint broadcast
# ---------------------------------------------------------------------------

@router.post("/numa")
async def numa_webhook(
    request: Request,
    session: AsyncSession = Depends(get_session),
    x_sbn_signature: str | None = Header(None),
    x_sbn_timestamp: str | None = Header(None),
) -> Dict[str, str]:
    """Receive NUMA hint broadcast."""
    body = await request.body()

    # --- Phase 1B: Signature verification (fail-closed) ---
    secret = os.getenv("DOMINION_NUMA_WEBHOOK_SECRET", "")
    if not secret:
        logger.error("DOMINION_NUMA_WEBHOOK_SECRET not configured — rejecting NUMA webhook")
        raise HTTPException(status_code=503, detail="webhook_secret_not_configured")
    signature_valid = _verify_signature(body, x_sbn_signature, x_sbn_timestamp, secret)
    if not signature_valid:
        raise HTTPException(status_code=401, detail="invalid_signature")

    # --- Phase 1A: Replay guard ---
    payload = await request.json()
    hint_id = payload.get("hint_id", "")

    replay_guard = get_replay_guard()
    replay_result = replay_guard.check(
        timestamp=x_sbn_timestamp,
        nonce=hint_id,
        signature_present=signature_valid,
        secret_configured=bool(secret),
    )
    if not replay_result.accepted:
        logger.warning(
            "NUMA webhook rejected by replay guard: hint=%s verdict=%s",
            hint_id, replay_result.verdict.value,
        )
        if replay_result.verdict.value.startswith("reject_duplicate"):
            raise HTTPException(status_code=409, detail="duplicate_event")
        raise HTTPException(status_code=401, detail=replay_result.verdict.value)

    # --- Phase 1C: Input validation ---
    try:
        validated = validate_numa_hint(payload)
    except ValidationError as exc:
        logger.warning("NUMA webhook validation failed: %s", exc.errors())
        raise HTTPException(status_code=422, detail=str(exc.errors()))

    # --- Phase 1D: Idempotency check ---
    registry = get_idempotency_registry()
    existing = registry.check("numa_hint", hint_id)
    if existing is not None and existing.response is not None:
        return existing.response

    if not registry.claim("numa_hint", hint_id):
        raise HTTPException(status_code=409, detail="duplicate_event")

    try:
        result = await handle_numa_hint(
            validated.model_dump(), session, bridge=_bridge,
        )
        registry.complete("numa_hint", hint_id, response=result)
        return result
    except Exception:
        registry.fail("numa_hint", hint_id)
        raise


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------

@router.get("/health")
async def webhook_health() -> Dict[str, Any]:
    """Report webhook receiver status."""
    replay_guard = get_replay_guard()
    registry = get_idempotency_registry()
    return {
        "status": "ok",
        "redis_bridge": _bridge.active if _bridge else False,
        "replay_guard_tracked": replay_guard.seen_count,
        "idempotency_entries": registry.entry_count,
    }
