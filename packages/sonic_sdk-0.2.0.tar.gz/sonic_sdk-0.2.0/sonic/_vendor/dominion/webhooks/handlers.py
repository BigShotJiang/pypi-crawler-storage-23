"""
Webhook event handlers — business logic for incoming callbacks.

Handlers are pure async functions that receive a parsed payload
and the session-scoped repos/bridge. They don't import FastAPI
so they're testable without HTTP.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict

from sqlalchemy.ext.asyncio import AsyncSession

from ..events.redis_bridge import RedisBridge
from ..repos.float_repo import FloatRepo
from ..repos.journal_repo import JournalRepo
from ..repos.receipt_repo import ReceiptRepo

logger = logging.getLogger(__name__)


async def handle_sonic_settlement(
    payload: Dict[str, Any],
    session: AsyncSession,
    bridge: RedisBridge | None = None,
) -> Dict[str, str]:
    """Process a ``settlement.complete`` callback from Sonic.

    Expected payload keys:
      - tx_id: str
      - status: str (settled | failed | reversed)
      - receipt_hash: str | None
      - amount: float
      - currency: str
      - metadata: dict (contains dominion_instruction_id, worker_id)
    """
    tx_id = payload.get("tx_id", "")
    status = payload.get("status", "")
    meta = payload.get("metadata", {})
    instruction_id = meta.get("dominion_instruction_id", "")
    worker_id = meta.get("worker_id", "")
    amount = payload.get("amount", 0.0)
    currency = payload.get("currency", "USD")
    receipt_hash = payload.get("receipt_hash")

    journal = JournalRepo(session)
    float_repo = FloatRepo(session)

    if status == "settled":
        # Release float commitment
        if instruction_id:
            await float_repo.settle(instruction_id)

        # Log to vault journal
        await journal.append(
            event_type="sonic_settlement",
            worker_id=worker_id,
            amount=amount,
            currency=currency,
            description=f"Sonic settled: tx={tx_id}",
            payload={
                "sonic_tx_id": tx_id,
                "receipt_hash": receipt_hash,
                "instruction_id": instruction_id,
            },
        )

        # Push to Redis bridge
        if bridge and bridge.active:
            await bridge.push_sonic_settlement({
                "tx_id": tx_id,
                "instruction_id": instruction_id,
                "worker_id": worker_id,
                "amount": amount,
                "status": "settled",
            })

    elif status in ("failed", "reversed"):
        # Release float on failure
        if instruction_id:
            await float_repo.release(instruction_id)

        await journal.append(
            event_type="payout_failed",
            worker_id=worker_id,
            amount=amount,
            currency=currency,
            description=f"Sonic {status}: tx={tx_id}",
            payload={"sonic_tx_id": tx_id, "reason": payload.get("reason", "")},
        )

    await session.commit()
    logger.info("Sonic settlement processed: tx=%s status=%s", tx_id, status)
    return {"status": "accepted", "tx_id": tx_id}


async def handle_sonic_stream_event(
    payload: Dict[str, Any],
    session: AsyncSession,
    bridge: RedisBridge | None = None,
) -> Dict[str, str]:
    """Process a PayStream lifecycle webhook from Sonic.

    Expected payload keys:
      - event_type: str (stream.window_closed | stream.closed | stream.policy_changed)
      - pay_stream_id: str
      - status: str (active | paused | frozen | closed)
      - policy_state: str (PRIME | NORMAL | RISK | FROZEN)
      - payer_id: str
      - payee_id: str
      - window: dict | None (window details for window_closed events)
      - totals: dict (total_earned, total_disbursed, total_held)
      - metadata: dict
    """
    event_type = payload.get("event_type", "")
    pay_stream_id = payload.get("pay_stream_id", "")
    status = payload.get("status", "")
    policy_state = payload.get("policy_state", "")
    meta = payload.get("metadata", {})
    worker_id = payload.get("payee_id", meta.get("worker_id", ""))
    totals = payload.get("totals", {})

    journal = JournalRepo(session)

    if event_type == "stream.window_closed":
        window = payload.get("window", {})
        await journal.append(
            event_type="stream_window_closed",
            worker_id=worker_id,
            amount=float(window.get("disbursed_amount", 0)),
            currency=payload.get("currency", "USD"),
            description=(
                f"PayStream window closed: stream={pay_stream_id} "
                f"window={window.get('window_id', '')}"
            ),
            payload={
                "pay_stream_id": pay_stream_id,
                "window": window,
                "policy_state": policy_state,
                "totals": totals,
            },
        )

    elif event_type == "stream.closed":
        await journal.append(
            event_type="stream_closed",
            worker_id=worker_id,
            amount=float(totals.get("total_disbursed", 0)),
            currency=payload.get("currency", "USD"),
            description=f"PayStream closed: stream={pay_stream_id}",
            payload={
                "pay_stream_id": pay_stream_id,
                "totals": totals,
                "merkle_root": payload.get("merkle_root"),
            },
        )

    elif event_type == "stream.policy_changed":
        await journal.append(
            event_type="stream_policy_changed",
            worker_id=worker_id,
            description=(
                f"PayStream policy changed: stream={pay_stream_id} "
                f"state={policy_state}"
            ),
            payload={
                "pay_stream_id": pay_stream_id,
                "policy_state": policy_state,
                "g_ewma": payload.get("g_ewma"),
                "previous_policy_state": payload.get("previous_policy_state"),
            },
        )

    else:
        logger.warning("Unknown stream event type: %s", event_type)
        await journal.append(
            event_type="stream_event_unknown",
            worker_id=worker_id,
            description=f"Unknown stream event: {event_type} stream={pay_stream_id}",
            payload=payload,
        )

    # Push to Redis bridge for agent consumption
    if bridge and bridge.active:
        await bridge.push_sonic_stream_event({
            "event_type": event_type,
            "pay_stream_id": pay_stream_id,
            "worker_id": worker_id,
            "status": status,
            "policy_state": policy_state,
            "totals": totals,
        })

    await session.commit()
    logger.info(
        "Sonic stream event processed: %s stream=%s status=%s",
        event_type,
        pay_stream_id,
        status,
    )
    return {"status": "accepted", "pay_stream_id": pay_stream_id}


async def handle_numa_hint(
    payload: Dict[str, Any],
    session: AsyncSession,
    bridge: RedisBridge | None = None,
) -> Dict[str, str]:
    """Process a NUMA hint broadcast.

    Expected payload keys:
      - hint_id: str
      - frontier_id: str
      - regime: str (gold | silver | bronze | iron)
      - signal: dict (CSK dimensions, recommendations)
      - timestamp: str
    """
    hint_id = payload.get("hint_id", "")
    frontier_id = payload.get("frontier_id", "")
    regime = payload.get("regime", "")
    signal = payload.get("signal", {})

    journal = JournalRepo(session)
    await journal.append(
        event_type="gec_event",
        description=f"NUMA hint: regime={regime} frontier={frontier_id}",
        payload={
            "hint_id": hint_id,
            "frontier_id": frontier_id,
            "regime": regime,
            "signal": signal,
        },
    )

    # Push to Redis bridge for agent consumption
    if bridge and bridge.active:
        await bridge.push_numa_hint({
            "hint_id": hint_id,
            "frontier_id": frontier_id,
            "regime": regime,
            "signal": signal,
        })

    await session.commit()
    logger.info("NUMA hint processed: %s regime=%s", hint_id, regime)
    return {"status": "accepted", "hint_id": hint_id}
