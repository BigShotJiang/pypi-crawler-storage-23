"""Vendored dependencies — sbn-sdk, snapchore-core, dominion-sdk."""
