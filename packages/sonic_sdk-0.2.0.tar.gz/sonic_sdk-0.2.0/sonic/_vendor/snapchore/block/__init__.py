"""SmartBlock — a lightweight, verifiable container for stateful events.

A SmartBlock wraps any payload with cryptographic integrity guarantees
via SnapChore hashing and moment authentication.  It is the universal
output artifact of the SnapChore protocol — usable standalone or within
the SBN attestation network.

Every ``seal()`` call captures device telemetry, authenticates the moment
(time freshness + system consistency), and stores the validation result
and moment hash on ``self.metadata`` — both non-volatile, so they enter
the hash surface as cryptographic proof of when and where sealing occurred.

SmartBlock is used by:
  - The ``/seal`` API endpoint (server-side seal for external callers)
  - ``provisioner.seal_receipt()`` (ACP receipt attestation)

For the full origin ceremony (moment auth + cryptographic signature) use
``SmartBlockBase.sign()`` in ``core.blocks.base``.

Example::

    from snapchore import SmartBlock

    block = SmartBlock(
        domain="ai.inference",
        payload={"model": "gpt-4", "tokens": 1500, "result": "..."},
    )
    block.seal()

    assert block.snapchore_hash is not None
    assert block.verify()
"""

from __future__ import annotations

import copy
import logging
import os
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional

_log = logging.getLogger(__name__)

from ..serialize import snapchore_hash, canonical_surface, CANON_VERSION
from ..snapchore import snapchore_capture, snapchore_verify


class SmartBlock:
    """A verifiable, tamper-evident container for any stateful event.

    Attributes
    ----------
    id : str
        Unique identifier (UUID4 by default).
    domain : str
        Classification domain (e.g. "ai.inference", "iot.sensor", "supply.step").
    block_type : str
        Block type (default "event").
    payload : dict
        The actual data being wrapped and protected.
    metadata : dict
        Mutable metadata (tags, labels, context).
    metrics : dict
        Computed metrics (trust scores, reflex, entropy, etc.).
    snapchore_hash : str or None
        The SnapChore hash, set after ``seal()`` is called.
    created_at : str
        ISO 8601 timestamp of creation.
    sealed : bool
        Whether the block has been sealed (hash computed).
    """

    __slots__ = (
        "id", "domain", "block_type", "payload", "metadata", "metrics",
        "snapchore_hash", "created_at", "sealed", "_seal_surface",
    )

    def __init__(
        self,
        *,
        domain: str = "general",
        block_type: str = "event",
        payload: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        metrics: Optional[Dict[str, Any]] = None,
        block_id: Optional[str] = None,
        created_at: Optional[str] = None,
    ) -> None:
        self.id = block_id or str(uuid.uuid4())
        self.domain = domain
        self.block_type = block_type
        self.payload = payload or {}
        self.metadata = metadata or {}
        self.metrics = metrics or {}
        self.snapchore_hash: Optional[str] = None
        self.created_at = created_at or datetime.now(timezone.utc).isoformat()
        self.sealed = False
        self._seal_surface: Optional[bytes] = None

    def to_dict(self) -> Dict[str, Any]:
        """Serialize the block to a plain dictionary."""
        d: Dict[str, Any] = {
            "id": self.id,
            "domain": self.domain,
            "type": self.block_type,
            "payload": copy.deepcopy(self.payload),
            "metadata": copy.deepcopy(self.metadata),
            "metrics": copy.deepcopy(self.metrics),
            "created_at": self.created_at,
        }
        if self.snapchore_hash:
            d["snapchore_hash"] = self.snapchore_hash
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SmartBlock":
        """Reconstruct a SmartBlock from a dictionary."""
        block = cls(
            domain=data.get("domain", "general"),
            block_type=data.get("type", "event"),
            payload=data.get("payload", {}),
            metadata=data.get("metadata", {}),
            metrics=data.get("metrics", {}),
            block_id=data.get("id"),
            created_at=data.get("created_at"),
        )
        block.snapchore_hash = data.get("snapchore_hash")
        block.sealed = block.snapchore_hash is not None
        return block

    def _hashing_surface(self) -> Dict[str, Any]:
        """Build the dict that gets hashed — everything except the hash itself."""
        return {
            "id": self.id,
            "domain": self.domain,
            "type": self.block_type,
            "payload": self.payload,
            "metadata": self.metadata,
            "metrics": self.metrics,
            "created_at": self.created_at,
        }

    def seal(self) -> str:
        """Compute and store the SnapChore hash, making the block immutable.

        Captures device telemetry, authenticates the moment (time freshness +
        system consistency), stores the validation result and moment hash in
        ``self.metadata`` (non-volatile — enters the hash surface), then
        computes the SnapChore hash.

        Returns the hex hash string.  Subsequent calls return the same hash
        without recomputing (idempotent).

        Raises
        ------
        RuntimeError
            If the block was already sealed and the content has been tampered
            with since sealing, or if moment authentication fails.
        """
        if self.sealed and self.snapchore_hash:
            # Verify integrity hasn't changed
            if not self.verify():
                raise RuntimeError("Block content changed after sealing — integrity violation")
            return self.snapchore_hash

        # Moment authentication — same pipeline as SmartBlockBase.sign()
        # and BitBlock.seal().  Proof enters metadata (non-volatile).
        skip_auth = os.getenv("SB_SNAPCHORE_SKIP_AUTH", "").lower() in ("1", "true", "yes")

        if not skip_auth:
            from ..capture import SnapChoreDeviceInterface
            from ..validator import authenticate_moment

            try:
                context = SnapChoreDeviceInterface().capture()
            except Exception as exc:
                raise RuntimeError(
                    "SnapChore device capture failed — cannot authenticate moment"
                ) from exc

            moment_result = authenticate_moment(context)
            if not moment_result["valid"]:
                raise RuntimeError(
                    "SnapChore moment authentication failed — refusing to seal. "
                    f"time_check={moment_result['time_check']}, "
                    f"consistency_check={moment_result['consistency_check']}"
                )

            _log.info("SnapChore moment authenticated: %s", moment_result["snapshot_hash"])

            # Store proof in metadata — non-volatile, enters hash surface.
            self.metadata["snapchore_moment_hash"] = moment_result["snapshot_hash"]
            self.metadata["snapchore_validation"] = moment_result

        surface = self._hashing_surface()
        self.snapchore_hash = snapchore_capture(surface)
        self._seal_surface = canonical_surface(surface)
        self.sealed = True
        return self.snapchore_hash  # type: ignore[return-value]

    def verify(self) -> bool:
        """Verify the block's integrity by recomputing the SnapChore hash.

        Returns True if the current content matches the stored hash.
        Returns False if no hash exists, content has been tampered with,
        or moment authentication proof is inconsistent.
        """
        if not self.snapchore_hash:
            return False
        surface = self._hashing_surface()
        if not snapchore_verify(surface, self.snapchore_hash):
            return False

        # Moment authentication verification
        moment_hash = self.metadata.get("snapchore_moment_hash")
        if moment_hash is not None:
            validation = self.metadata.get("snapchore_validation")
            if validation is None:
                _log.warning("[verify] SmartBlock %s has moment hash but no validation record", self.id)
                return False
            if not validation.get("valid"):
                return False
            if validation.get("snapshot_hash") != moment_hash:
                return False

        return True

    def update_metrics(self, **kwargs: Any) -> None:
        """Update metrics on an unsealed block.

        Raises RuntimeError if the block is already sealed.
        """
        if self.sealed:
            raise RuntimeError("Cannot modify a sealed SmartBlock — unseal first or create a new block")
        self.metrics.update(kwargs)

    def add_metadata(self, **kwargs: Any) -> None:
        """Add metadata to an unsealed block.

        Raises RuntimeError if the block is already sealed.
        """
        if self.sealed:
            raise RuntimeError("Cannot modify a sealed SmartBlock — unseal first or create a new block")
        self.metadata.update(kwargs)

    def __repr__(self) -> str:
        state = "sealed" if self.sealed else "unsealed"
        h = self.snapchore_hash[:12] + "..." if self.snapchore_hash else "none"
        return f"SmartBlock(id={self.id[:8]}..., domain={self.domain}, {state}, hash={h})"
