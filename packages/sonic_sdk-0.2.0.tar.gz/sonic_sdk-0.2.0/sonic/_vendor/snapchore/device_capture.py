"""Compatibility wrapper for SnapChore device capture."""

from __future__ import annotations

from typing import Any, Dict, Optional

from .capture import SnapChoreDeviceInterface


class DeviceCapture:
    """Provide the legacy DeviceCapture interface backed by the new pipeline."""

    def __init__(self, simulate: Optional[bool] = None) -> None:
        self._interface = SnapChoreDeviceInterface(simulate=simulate)

    def get_device_data(self) -> Dict[str, Any]:
        """Retrieve device data (simulated or real)."""

        return self._interface.capture()
