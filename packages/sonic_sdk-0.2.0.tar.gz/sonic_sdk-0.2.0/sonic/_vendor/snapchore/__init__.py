"""SnapChore — cryptographic integrity for stateful events.

SnapChore hashes, seals, and chains any stateful event into a tamper-evident
SmartBlock.  It is the proof layer of the SmartBlocks protocol but works as
a standalone library with zero network dependencies.

Quick start::

    from snapchore import SmartBlock, SnapChoreChain

    # Seal a single event
    block = SmartBlock(domain="ai.inference", payload={"tokens": 1500})
    block.seal()
    assert block.verify()

    # Chain multiple events into a tamper-evident ledger
    chain = SnapChoreChain()
    chain.append(block)

    block2 = SmartBlock(domain="ai.inference", payload={"tokens": 2300})
    block2.seal()
    chain.append(block2)
    assert chain.verify()

Lower-level API::

    from snapchore import snapchore_capture, snapchore_verify, snapchore_hash

    data = {"model": "gpt-4", "tokens": 1500}
    h = snapchore_capture(data)
    assert snapchore_verify(data, h)
"""

from __future__ import annotations

# ── Core hashing primitives ──────────────────────────────────────────────
from .serialize import (
    CANON_VERSION,
    canonical_serialize,
    canonical_surface,
    snapchore_hash,
    quantize_float,
    stable_timestamp,
)

# ── Capture / verify convenience functions ───────────────────────────────
from .snapchore import (
    snapchore_capture,
    snapchore_verify,
    snapchore_envelope,
    freeze_for_snap,
)

# ── SmartBlock container ─────────────────────────────────────────────────
from .block import SmartBlock

# ── SnapChoreChain (linked hash ledger) ──────────────────────────────────
from .chain import SnapChoreChain, ChainEntry

__all__ = [
    # Primitives
    "CANON_VERSION",
    "canonical_serialize",
    "canonical_surface",
    "snapchore_hash",
    "quantize_float",
    "stable_timestamp",
    # Capture / verify
    "snapchore_capture",
    "snapchore_verify",
    "snapchore_envelope",
    "freeze_for_snap",
    # SmartBlock
    "SmartBlock",
    # Chain
    "SnapChoreChain",
    "ChainEntry",
]

__version__ = "0.1.0"
