import logging
from typing import Union, Dict
from PIL import Image
from PIL.ExifTags import TAGS, GPSTAGS

logger = logging.getLogger(__name__)

def extract_metadata(input_data: Union[str, Dict]) -> Dict:
    """Extract metadata from image path or directly return system snapshot dict."""
    if isinstance(input_data, dict):
        logger.debug("Using provided snapshot dict as metadata.")
        return input_data
    elif isinstance(input_data, str):
        try:
            image = Image.open(input_data)
            exif_data = image._getexif()
            if not exif_data:
                logger.warning(f"No EXIF data found in {input_data}")
                return {}

            metadata = {}
            for tag_id, value in exif_data.items():
                tag = TAGS.get(tag_id, tag_id)
                metadata[tag] = value

            gps_info = {}
            if 'GPSInfo' in metadata:
                for key in metadata['GPSInfo'].keys():
                    decode = GPSTAGS.get(key, key)
                    gps_info[decode] = metadata['GPSInfo'][key]
                metadata['GPSInfo'] = gps_info

            return metadata
        except Exception as e:
            logger.error(f"Failed to extract metadata from {input_data}: {e}")
            return {}
    else:
        raise ValueError("Input must be an image path (str) or snapshot dict (dict)")
