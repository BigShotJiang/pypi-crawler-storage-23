"""Secrets manager abstraction — pluggable secret resolution.

By default secrets are loaded from environment variables (via pydantic-settings).
In production, operators can set ``SONIC_SECRETS_BACKEND`` to load secrets from
an external provider at startup, then overlay them onto the settings object.

Supported backends:
  - ``env``  (default) — no-op, secrets come from env vars
  - ``aws``  — AWS Secrets Manager (requires ``boto3``)

The :func:`resolve_secrets` function is called once at import time by
``sonic.config``. It mutates ``SonicSettings`` fields in-place so the rest of
the application is unaware of where the values came from.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

logger = logging.getLogger("sonic.secrets")

# Fields that can be loaded from a secrets backend.
SECRET_FIELDS = frozenset({
    "jwt_secret",
    "jwt_refresh_secret",
    "stripe_secret_key",
    "stripe_webhook_secret",
    "moov_api_key",
    "circle_api_key",
    "sbn_api_key",
    "database_url",
    "redis_url",
    "sentry_dsn",
    "hedera_operator_key",
    "solana_payer_key",
})


def resolve_secrets(settings: Any) -> None:
    """Overlay secrets from the configured backend onto *settings*.

    Called once during config initialisation.  ``SONIC_SECRETS_BACKEND``
    selects the provider:

    - ``env`` — (default) do nothing; pydantic already read env vars.
    - ``aws`` — read ``SONIC_SECRETS_AWS_SECRET_ID`` from AWS Secrets Manager,
      parse the JSON blob, and set matching fields.
    """
    backend = os.environ.get("SONIC_SECRETS_BACKEND", "env").lower()

    if backend == "env":
        return

    if backend == "aws":
        _resolve_aws(settings)
    else:
        raise ValueError(
            f"Unknown secrets backend: {backend!r}. "
            "Supported: env, aws"
        )


def _resolve_aws(settings: Any) -> None:
    """Pull secrets from AWS Secrets Manager and overlay onto settings."""
    secret_id = os.environ.get("SONIC_SECRETS_AWS_SECRET_ID", "sonic/production")
    region = os.environ.get("SONIC_SECRETS_AWS_REGION", "us-east-1")

    try:
        import boto3
    except ImportError:
        raise RuntimeError(
            "boto3 is required for the 'aws' secrets backend. "
            "Install it with: pip install boto3"
        )

    logger.info("Loading secrets from AWS Secrets Manager: %s (region=%s)", secret_id, region)
    client = boto3.client("secretsmanager", region_name=region)
    response = client.get_secret_value(SecretId=secret_id)

    payload: dict[str, str] = json.loads(response["SecretString"])

    applied = []
    for key, value in payload.items():
        # Normalise: AWS secret keys may use SONIC_ prefix or not
        field_name = key.lower().removeprefix("sonic_")
        if field_name in SECRET_FIELDS and value:
            setattr(settings, field_name, value)
            applied.append(field_name)

    logger.info("Resolved %d secret(s) from AWS: %s", len(applied), applied)
