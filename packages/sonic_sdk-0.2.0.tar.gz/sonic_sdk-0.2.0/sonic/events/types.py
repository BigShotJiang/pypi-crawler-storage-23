"""Event types — every state change in Sonic's domain."""

from __future__ import annotations

import enum


class EventType(str, enum.Enum):
    """All event types emitted by Sonic.

    Naming: {domain}.{action}
    Each event corresponds to a state transition or external signal.
    """

    # --- Payment lifecycle ---
    PAYMENT_INITIATED = "payment.initiated"
    PAYMENT_RECEIVED = "payment.received"
    PAYMENT_FAILED = "payment.failed"

    # --- Finality ---
    RECEIVABLE_DETECTED = "receivable.detected"
    FINALITY_PENDING = "finality.pending"
    RECEIVABLE_CLEARED = "receivable.cleared"
    RECEIVABLE_REVERSED = "receivable.reversed"

    # --- Treasury / Normalization ---
    NORMALIZE_STARTED = "normalize.started"
    NORMALIZE_COMPLETED = "normalize.completed"
    NORMALIZE_FAILED = "normalize.failed"

    # --- Payout ---
    PAYOUT_PENDING = "payout.pending"
    PAYOUT_EXECUTED = "payout.executed"
    PAYOUT_FAILED = "payout.failed"

    # --- Settlement ---
    SETTLEMENT_COMPLETE = "settlement.complete"

    # --- Provider callbacks ---
    PROVIDER_WEBHOOK = "provider.webhook"
    PROVIDER_STATUS_UPDATE = "provider.status_update"

    # --- Streaming ---
    STREAM_OPENED = "stream.opened"
    STREAM_WINDOW_CLOSED = "stream.window.closed"
    STREAM_PAUSED = "stream.paused"
    STREAM_RESUMED = "stream.resumed"
    STREAM_FROZEN = "stream.frozen"
    STREAM_UNFROZEN = "stream.unfrozen"
    STREAM_CLOSED = "stream.closed"

    # --- SBN attestation ---
    SBN_ATTESTATION_QUEUED = "sbn.attestation.queued"
    SBN_ATTESTATION_CONFIRMED = "sbn.attestation.confirmed"
    SBN_ATTESTATION_FAILED = "sbn.attestation.failed"
