"""Webhook dispatcher — delivers events to merchant webhook endpoints."""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
from datetime import datetime, timezone
from typing import Any

import httpx

logger = logging.getLogger(__name__)


class WebhookDispatcher:
    """Delivers Sonic events to merchant-configured webhook URLs.

    Signs each delivery with HMAC-SHA256 so merchants can verify authenticity.
    """

    def __init__(self, signing_secret: str):
        self._signing_secret = signing_secret

    def _sign(self, payload_bytes: bytes) -> str:
        return hmac.new(
            self._signing_secret.encode(),
            payload_bytes,
            hashlib.sha256,
        ).hexdigest()

    async def deliver(
        self,
        url: str,
        event_type: str,
        data: dict[str, Any],
        *,
        timeout: float = 10.0,
        merchant_id: str | None = None,
    ) -> bool:
        """Deliver a webhook event. Returns True on success."""
        payload = {
            "event": event_type,
            "merchant_id": merchant_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "data": data,
        }
        payload_bytes = json.dumps(payload, sort_keys=True).encode()
        signature = self._sign(payload_bytes)

        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                resp = await client.post(
                    url,
                    content=payload_bytes,
                    headers={
                        "Content-Type": "application/json",
                        "X-Sonic-Signature": signature,
                        "X-Sonic-Event": event_type,
                    },
                )
            if resp.status_code < 300:
                return True
            logger.warning("Webhook delivery failed: %s → HTTP %d", url, resp.status_code)
            return False
        except Exception as exc:
            logger.error("Webhook delivery error: %s → %s", url, exc)
            return False
