"""Event emitter — publishes events to internal bus and optional external sinks.

In-process event bus using simple callbacks. Can be extended to
publish to Redis Streams, webhooks, or external message brokers.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from typing import Any, Callable, Awaitable

from sonic.events.types import EventType

logger = logging.getLogger(__name__)

EventHandler = Callable[[EventType, dict[str, Any]], Awaitable[None]]


class EventEmitter:
    """Simple async event bus."""

    def __init__(self):
        self._handlers: dict[EventType | str, list[EventHandler]] = defaultdict(list)
        self._global_handlers: list[EventHandler] = []

    def on(self, event_type: EventType | str, handler: EventHandler) -> None:
        """Register a handler for a specific event type."""
        self._handlers[event_type].append(handler)

    def on_all(self, handler: EventHandler) -> None:
        """Register a handler that fires on every event."""
        self._global_handlers.append(handler)

    async def emit(self, event_type: EventType, data: dict[str, Any]) -> None:
        """Emit an event to all registered handlers."""
        logger.debug("Event: %s tx=%s", event_type.value, data.get("tx_id", "?"))

        for handler in self._global_handlers:
            try:
                await handler(event_type, data)
            except Exception:
                logger.exception("Global event handler failed for %s", event_type.value)

        for handler in self._handlers.get(event_type, []):
            try:
                await handler(event_type, data)
            except Exception:
                logger.exception("Event handler failed for %s", event_type.value)

        # Also fire for string key (allows wildcard-style subscriptions)
        prefix = event_type.value.rsplit(".", 1)[0] + ".*"
        for handler in self._handlers.get(prefix, []):
            try:
                await handler(event_type, data)
            except Exception:
                logger.exception("Wildcard handler failed for %s", event_type.value)
