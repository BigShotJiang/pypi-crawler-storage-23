"""Sonic configuration — loaded from environment variables."""

from __future__ import annotations

from pydantic_settings import BaseSettings


class SonicSettings(BaseSettings):
    model_config = {"env_prefix": "SONIC_", "env_file": ".env", "env_file_encoding": "utf-8"}

    # --- App ---
    app_name: str = "sonic"
    debug: bool = False
    environment: str = "development"  # development | staging | production

    # --- Database ---
    database_url: str = "postgresql+asyncpg://sonic:sonic@localhost:5432/sonic"
    database_read_url: str = ""  # Read replica URL (empty = use primary for reads)
    db_pool_size: int = 20
    db_max_overflow: int = 10
    db_pool_recycle: int = 1800  # Recycle connections after 30 min (prevent stale conns)
    db_pool_pre_ping: bool = True  # Validate connections before checkout
    db_pool_timeout: int = 30  # Seconds to wait for a connection from the pool
    db_statement_cache_size: int = 100  # asyncpg prepared statement cache (0 = disable)
    db_require_ssl: bool = False  # Set True in production for sslmode=require

    # --- Redis ---
    redis_url: str = "redis://localhost:6379/0"
    redis_require_tls: bool = False  # Set True in production (enforces rediss://)

    # --- SBN ---
    sbn_base_url: str = "http://localhost:8082"
    sbn_api_key: str = ""
    sbn_frontier_id: str = "sonic.settlement.v1"
    sbn_project_id: str = ""
    sbn_attestation_enabled: bool = True
    sbn_attestation_timeout: float = 10.0

    # --- SBN Coupler (Mode B: slot-based batch coupling) ---
    coupler_enabled: bool = True
    coupler_epoch_boundary: str = "daily"  # "daily" | "merchant_daily" | "batch"
    coupler_worker_id: str = "sonic-coupler"
    coupler_task_type: str = "sonic.settlement"
    coupler_domain: str = "sonic.settlement"
    coupler_batch_size: int = 50  # Max receipts to claim per cycle
    coupler_drain_interval: float = 2.0  # Seconds between drain cycles

    # --- Provider Rails ---
    stripe_secret_key: str = ""
    stripe_webhook_secret: str = ""
    moov_api_key: str = ""
    moov_account_id: str = ""
    circle_api_key: str = ""
    circle_environment: str = "sandbox"  # sandbox | production

    # --- Treasury ---
    base_treasury_asset: str = "USDC"
    auto_normalize: bool = True

    # --- Float Guard (opt-in payout gating) ---
    float_guard_enabled: bool = False  # Kill-switch — disabled by default for backward compat
    configured_float: float = 100_000.0  # Total treasury float available for payouts
    float_min_ratio: float = 0.2  # Block threshold (available/amount < 0.2 → BLOCKED)
    float_throttle_ratio: float = 0.4  # Throttle threshold (available/amount < 0.4 → THROTTLED)

    # --- Streaming ---
    settlement_poll_interval_cycles: int = 15  # Drain cycles between settlement polls (~30s at 2s interval)
    normalize_retry_max: int = 3  # Max retry attempts for failed normalization
    normalize_retry_delay_seconds: float = 5.0  # Delay between normalization retries
    payout_retry_interval_cycles: int = 30  # Drain cycles between payout retry sweeps (~1min)
    payout_retry_max_batch: int = 10  # Max failed payouts to retry per sweep
    stuck_sweeper_interval_cycles: int = 60  # Drain cycles between stuck-state sweeps (~2min)
    stuck_normalizing_minutes: int = 10  # Minutes before NORMALIZING is considered stuck
    stuck_payout_pending_minutes: int = 30  # Minutes before PAYOUT_PENDING is considered stuck
    stream_auto_close_max_batch: int = 20  # Max expired windows to auto-close per sweep

    # --- Blockchain Anchoring ---
    anchor_enabled: bool = False  # Global kill-switch for all anchoring
    # Hedera Consensus Service
    hedera_operator_id: str = ""  # "0.0.xxxxx" — operator account
    hedera_operator_key: str = ""  # ED25519 private key (DER hex)
    hedera_network: str = "testnet"  # testnet | mainnet
    hedera_default_topic_id: str = ""  # Shared topic if merchant has no per-merchant topic
    hedera_mirror_url: str = "https://mainnet.mirrornode.hedera.com"
    # Solana (alternative)
    solana_rpc_url: str = "https://api.devnet.solana.com"
    solana_payer_key: str = ""  # Base58 keypair
    solana_program_id: str = ""  # Memo program or custom anchor program

    # --- Checkout / Website Integration ---
    checkout_base_url: str = "http://localhost:3100"  # Hosted checkout page URL

    # --- CORS ---
    cors_origins: str = "http://localhost:3000,http://localhost:3100,http://localhost:5173"

    # --- Observability ---
    sentry_dsn: str = ""  # Leave empty to disable Sentry
    sentry_traces_sample_rate: float = 0.1  # 10% of transactions traced

    # --- Auth ---
    api_key_header: str = "x-sonic-api-key"
    jwt_secret: str = "change-me-in-production"
    jwt_refresh_secret: str = ""  # Separate secret for refresh tokens (defaults to jwt_secret if empty)
    jwt_algorithm: str = "HS256"
    jwt_expiry_seconds: int = 3600

    # --- Security ---
    max_request_body_bytes: int = 1_048_576  # 1 MB max request body
    api_key_rotation_grace_hours: int = 72  # Hours the old key stays valid after rotation
    ip_allowlist_enabled: bool = True  # Enforce merchant IP allowlists when set

    # --- Archival ---
    archival_enabled: bool = False  # Enable background archival of old transactions
    archival_retention_days: int = 90  # Days to keep transactions in hot storage
    archival_batch_size: int = 500  # Transactions to archive per sweep
    archival_interval_cycles: int = 300  # Drain cycles between archival sweeps (~10min)


settings = SonicSettings()


def _resolve_secrets() -> None:
    """Load secrets from the configured backend (env, aws, etc.)."""
    from sonic.secrets import resolve_secrets

    resolve_secrets(settings)


_resolve_secrets()


def _validate_settings() -> None:
    """Reject dangerous defaults outside of development."""
    if settings.environment != "development":
        if settings.jwt_secret == "change-me-in-production":
            raise RuntimeError(
                "SONIC_JWT_SECRET is still set to the default placeholder. "
                "Set a strong, unique secret via the SONIC_JWT_SECRET environment variable."
            )
        if len(settings.jwt_secret) < 32:
            raise RuntimeError(
                "SONIC_JWT_SECRET is too short (min 32 chars). "
                "Use a cryptographically random string."
            )

    # Default refresh secret to main secret if not explicitly set
    if not settings.jwt_refresh_secret:
        if settings.environment != "development":
            import logging
            logging.getLogger("sonic.config").warning(
                "SONIC_JWT_REFRESH_SECRET is not set — falling back to SONIC_JWT_SECRET. "
                "Set a separate refresh secret in production for proper token isolation."
            )
        settings.jwt_refresh_secret = settings.jwt_secret


_validate_settings()
