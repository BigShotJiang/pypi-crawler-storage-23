"""Dashboard data providers — one function per DataKey.

Each provider pulls from existing Sonic services and shapes data
for the Tower Agent dashboard descriptor. The descriptor defines widgets
that read from section_data[data_key] — we serve the matching shapes.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Optional

from . import DataKey

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Individual providers
# ---------------------------------------------------------------------------

def provide_brief(
    db: Any = None,
    float_guard: Any = None,
    settings: Any = None,
) -> dict[str, Any]:
    """DataKey.BRIEF — headline, settlement summary, key stats."""
    headline = "Settlement engine active"
    stream_count = 0
    merchant_count = 0

    if db is not None:
        try:
            from sqlalchemy import func, select
            from sonic.models.stream_session import StreamSession
            from sonic.models.merchant import Merchant

            stream_count = db.scalar(
                select(func.count()).select_from(StreamSession)
                .where(StreamSession.status == "open")
            ) or 0

            merchant_count = db.scalar(
                select(func.count()).select_from(Merchant)
                .where(Merchant.active.is_(True))
            ) or 0
        except Exception:
            pass

    headline = f"Settlement engine active — {stream_count} streams, {merchant_count} merchants"

    return {
        "headline": headline,
        "active_streams": stream_count,
        "active_merchants": merchant_count,
        "float_guard_enabled": settings.float_guard_enabled if settings else False,
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }


def provide_settlement_health(
    db: Any = None,
    sbn_client: Any = None,
    redis_client: Any = None,
    settings: Any = None,
) -> dict[str, Any]:
    """DataKey.SETTLEMENT_HEALTH — engine, coupler, and provider status.

    Reads from the existing health infrastructure and live component status.
    """
    components: dict[str, Any] = {}

    # Database check
    if db is not None:
        try:
            from sqlalchemy import text
            db.execute(text("SELECT 1"))
            components["database"] = {"status": "healthy"}
        except Exception as exc:
            components["database"] = {"status": "degraded", "error": str(exc)}
    else:
        components["database"] = {"status": "unknown"}

    # Redis check
    if redis_client is not None:
        try:
            redis_client.ping()
            components["redis"] = {"status": "healthy"}
        except Exception as exc:
            components["redis"] = {"status": "degraded", "error": str(exc)}
    else:
        components["redis"] = {"status": "not_configured"}

    # SBN check
    if sbn_client is not None and sbn_client.active:
        components["sbn"] = {"status": "healthy", "base_url": getattr(sbn_client, "_base_url", "")}
    elif sbn_client is not None:
        components["sbn"] = {"status": "inactive"}
    else:
        components["sbn"] = {"status": "not_configured"}

    # Coupler status from epoch table
    if db is not None:
        try:
            from sqlalchemy import select
            from sonic.models.epoch import SbnEpoch

            today_key = datetime.now(timezone.utc).strftime("%Y-%m-%d")
            epoch = db.scalars(
                select(SbnEpoch).where(SbnEpoch.epoch_key == today_key).limit(1)
            ).first()

            if epoch:
                components["coupler"] = {
                    "status": "healthy" if epoch.state in ("open", "closed", "attested") else "degraded",
                    "epoch_key": epoch.epoch_key,
                    "epoch_state": epoch.state,
                    "slot_id": epoch.slot_id,
                    "last_error": epoch.last_error,
                }
            else:
                components["coupler"] = {"status": "idle", "epoch_key": today_key}
        except Exception:
            components["coupler"] = {"status": "unknown"}

    # Transaction pipeline stats
    if db is not None:
        try:
            from sqlalchemy import func, select
            from sonic.models.transaction import TransactionRecord

            pipeline_states = db.execute(
                select(
                    TransactionRecord.state,
                    func.count(),
                ).group_by(TransactionRecord.state)
            ).all()

            components["pipeline"] = {
                "states": {row[0]: row[1] for row in pipeline_states},
                "total": sum(row[1] for row in pipeline_states),
            }
        except Exception:
            components["pipeline"] = {"states": {}, "total": 0}

    # Overall status
    degraded = [k for k, v in components.items() if v.get("status") == "degraded"]
    overall = "degraded" if degraded else "healthy"

    return {
        "status": overall,
        "engine_active": True,
        "coupler_enabled": settings.coupler_enabled if settings else True,
        "components": components,
        "degraded_components": degraded,
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }


def provide_stream_activity(db: Any = None) -> dict[str, Any]:
    """DataKey.STREAM_ACTIVITY — active PayStreams, volumes, frozen streams."""
    if db is None:
        return {"streams": [], "total": 0, "total_earned": 0.0}

    try:
        from sqlalchemy import func, select
        from sonic.models.stream_session import StreamSession

        total = db.scalar(
            select(func.count()).select_from(StreamSession)
        ) or 0

        active = db.scalar(
            select(func.count()).select_from(StreamSession)
            .where(StreamSession.status == "open")
        ) or 0

        paused = db.scalar(
            select(func.count()).select_from(StreamSession)
            .where(StreamSession.status == "paused")
        ) or 0

        closed = db.scalar(
            select(func.count()).select_from(StreamSession)
            .where(StreamSession.status == "closed")
        ) or 0

        return {
            "total": total,
            "active": active,
            "paused": paused,
            "closed": closed,
        }
    except Exception as exc:
        logger.warning("Stream activity provider failed: %s", exc)
        return {"total": 0, "active": 0, "paused": 0, "closed": 0, "error": str(exc)}


async def provide_float_status(float_guard: Any = None) -> dict[str, Any]:
    """DataKey.FLOAT_STATUS — float guard health (if enabled)."""
    if float_guard is None:
        return {"enabled": False, "status": "not_configured"}

    try:
        return await float_guard.get_float_health()
    except Exception as exc:
        logger.warning("Float status provider failed: %s", exc)
        return {"enabled": True, "status": "error", "error": str(exc)}


def provide_provider_health(
    providers: dict[str, Any] | None = None,
    settings: Any = None,
) -> dict[str, Any]:
    """DataKey.PROVIDER_HEALTH — per-provider status and configuration.

    Reads from the loaded provider map and config to report which
    rails are available and their basic health.
    """
    provider_list: list[dict[str, Any]] = []

    if providers:
        for rail, adapter in providers.items():
            status = "unknown"
            try:
                # Most adapters have a health() method
                if hasattr(adapter, "health"):
                    healthy = adapter.health()
                    status = "healthy" if healthy else "degraded"
                else:
                    status = "loaded"
            except Exception as exc:
                status = "error"
                logger.debug("Provider %s health check failed: %s", rail, exc)

            provider_list.append({
                "rail": rail,
                "status": status,
                "type": type(adapter).__name__,
            })
    else:
        # No providers loaded — report from settings what's configured
        rails = ["stripe_card", "stripe_ach", "stripe_transfer", "moov_ach",
                 "circle_usdc", "circle_usdc_solana"]
        for rail in rails:
            provider_list.append({"rail": rail, "status": "not_loaded"})

    healthy_count = sum(1 for p in provider_list if p["status"] in ("healthy", "loaded"))

    return {
        "providers": provider_list,
        "total": len(provider_list),
        "healthy": healthy_count,
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }


def provide_batch_payouts(db: Any = None) -> dict[str, Any]:
    """DataKey.BATCH_PAYOUTS — recent batch payout statistics."""
    if db is None:
        return {"recent": [], "total_24h": 0}

    try:
        from datetime import timedelta
        from sqlalchemy import func, select
        from sonic.core.engine import TxState
        from sonic.models.transaction import TransactionRecord

        since = datetime.now(timezone.utc) - timedelta(hours=24)

        total = db.scalar(
            select(func.count()).select_from(TransactionRecord)
            .where(TransactionRecord.created_at >= since)
        ) or 0

        completed = db.scalar(
            select(func.count()).select_from(TransactionRecord)
            .where(
                TransactionRecord.created_at >= since,
                TransactionRecord.state == TxState.PAYOUT_EXECUTED.value,
            )
        ) or 0

        failed = db.scalar(
            select(func.count()).select_from(TransactionRecord)
            .where(
                TransactionRecord.created_at >= since,
                TransactionRecord.state == TxState.FAILED.value,
            )
        ) or 0

        return {
            "total_24h": total,
            "completed_24h": completed,
            "failed_24h": failed,
            "success_rate": round(completed / total, 4) if total > 0 else 1.0,
        }
    except Exception as exc:
        logger.warning("Batch payouts provider failed: %s", exc)
        return {"total_24h": 0, "error": str(exc)}


def provide_suggestions() -> dict[str, Any]:
    """DataKey.SUGGESTIONS — active suggestions queue.

    Populated by Tower Agent via NUMA translation rules when connected.
    """
    return {
        "items": [],
        "count": 0,
        "has_escalations": False,
    }


def provide_translation_log() -> dict[str, Any]:
    """DataKey.TRANSLATION_LOG — NUMA signal → action translation trace."""
    return {
        "entries": [],
        "total": 0,
        "note": "Translation log active when NUMA channel is connected",
    }


# ---------------------------------------------------------------------------
# Master aggregator
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Provider registry
# ---------------------------------------------------------------------------

_SYNC_PROVIDERS: dict[str, Any] = {
    DataKey.BRIEF.value: provide_brief,
    DataKey.STREAM_ACTIVITY.value: provide_stream_activity,
    DataKey.BATCH_PAYOUTS.value: provide_batch_payouts,
    DataKey.SUGGESTIONS.value: provide_suggestions,
    DataKey.TRANSLATION_LOG.value: provide_translation_log,
}


def provide_section(
    data_key: str,
    *,
    db: Any = None,
    float_guard: Any = None,
    sbn_client: Any = None,
    redis_client: Any = None,
    providers: dict[str, Any] | None = None,
    settings: Any = None,
) -> dict[str, Any] | None:
    """Provide data for a single data_key. Returns None if key is unknown."""
    if data_key == DataKey.SETTLEMENT_HEALTH.value:
        return provide_settlement_health(db, sbn_client, redis_client, settings)
    if data_key == DataKey.PROVIDER_HEALTH.value:
        return provide_provider_health(providers, settings)
    if data_key == DataKey.BRIEF.value:
        return provide_brief(db, float_guard, settings)
    if data_key == DataKey.STREAM_ACTIVITY.value:
        return provide_stream_activity(db)
    if data_key == DataKey.BATCH_PAYOUTS.value:
        return provide_batch_payouts(db)
    if data_key == DataKey.SUGGESTIONS.value:
        return provide_suggestions()
    if data_key == DataKey.TRANSLATION_LOG.value:
        return provide_translation_log()
    # float_status is async — must be awaited externally
    return None


async def build_section_data(
    db: Any = None,
    float_guard: Any = None,
    sbn_client: Any = None,
    redis_client: Any = None,
    providers: dict[str, Any] | None = None,
    settings: Any = None,
) -> dict[str, Any]:
    """Build the full section_data dict for a DashboardSnapshot.

    Async because float_status needs to await.
    """
    return {
        DataKey.BRIEF.value: provide_brief(db, float_guard, settings),
        DataKey.SETTLEMENT_HEALTH.value: provide_settlement_health(
            db, sbn_client, redis_client, settings,
        ),
        DataKey.STREAM_ACTIVITY.value: provide_stream_activity(db),
        DataKey.FLOAT_STATUS.value: await provide_float_status(float_guard),
        DataKey.PROVIDER_HEALTH.value: provide_provider_health(providers, settings),
        DataKey.BATCH_PAYOUTS.value: provide_batch_payouts(db),
        DataKey.SUGGESTIONS.value: provide_suggestions(),
        DataKey.TRANSLATION_LOG.value: provide_translation_log(),
    }
