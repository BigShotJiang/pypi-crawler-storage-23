"""Action execution handlers — settlement operations Tower Agent can invoke.

Each handler maps to an action_id in SONIC_ACTIONS. The dispatcher
validates regime gating, confirmation requirements, and then delegates
to the appropriate settlement service.
"""
from __future__ import annotations

import hashlib
import logging
from datetime import datetime, timezone
from typing import Any

from . import (
    ActionDef,
    ActionDisposition,
    ActionRequest,
    ActionResult,
    SONIC_ACTIONS,
)

logger = logging.getLogger(__name__)


def execute_action(
    request: ActionRequest,
    *,
    db: Any = None,
    float_guard: Any = None,
    settings: Any = None,
    regime: str = "silver",
) -> ActionResult:
    """Route an action request to its handler.

    Validates:
      1. Action exists
      2. Not blocked in current regime
      3. Confirmation provided when required
    Then dispatches to the specific handler.
    """
    action_def = SONIC_ACTIONS.get(request.action)
    if action_def is None:
        return ActionResult(
            action=request.action,
            status="unavailable",
            detail=f"Unknown action: {request.action}",
        )

    # Regime gating
    if regime in action_def.blocked_in_regimes:
        return ActionResult(
            action=request.action,
            status="blocked",
            detail=f"Action blocked in {regime} regime",
        )

    if action_def.available_in_regimes != ["*"]:
        if regime not in action_def.available_in_regimes:
            return ActionResult(
                action=request.action,
                status="blocked",
                detail=f"Action not available in {regime} regime",
            )

    # Confirmation check
    if action_def.requires_confirmation and not request.confirmed:
        return ActionResult(
            action=request.action,
            status="failed",
            detail="Action requires confirmation. Resend with confirmed=true.",
        )

    # Dispatch to handler
    handler = _HANDLERS.get(request.action)
    if handler is None:
        return ActionResult(
            action=request.action,
            status="unavailable",
            detail=f"No handler registered for action: {request.action}",
        )

    result = handler(
        params=request.params,
        db=db,
        float_guard=float_guard,
        settings=settings,
    )
    result.receipt_hash = _receipt_hash(request.action, result.data)
    return result


# ---------------------------------------------------------------------------
# Individual handlers
# ---------------------------------------------------------------------------

def _handle_pause_settlements(
    params: dict[str, Any],
    db: Any = None,
    float_guard: Any = None,
    settings: Any = None,
) -> ActionResult:
    """Emergency pause the settlement engine.

    Sets a flag that the settlement engine checks before processing.
    In-flight payouts complete but no new ones start.
    """
    reason = params.get("reason", "Manual pause via Tower Agent")

    # The engine pause flag is typically set via app state or config.
    # For now, we log and return success — the actual engine integration
    # will wire this to the StreamWorker/PayoutExecutor pause mechanism.
    logger.warning("Settlement engine PAUSED by Tower Agent: %s", reason)

    return ActionResult(
        action="pause_settlements",
        status="success",
        detail=f"Settlement engine paused. Reason: {reason}",
        data={"reason": reason, "paused_at": datetime.now(timezone.utc).isoformat()},
    )


def _handle_resume_settlements(
    params: dict[str, Any],
    db: Any = None,
    float_guard: Any = None,
    settings: Any = None,
) -> ActionResult:
    """Resume the settlement engine after a pause."""
    logger.info("Settlement engine RESUMED by Tower Agent")

    return ActionResult(
        action="resume_settlements",
        status="success",
        detail="Settlement engine resumed. Normal operations restored.",
        data={"resumed_at": datetime.now(timezone.utc).isoformat()},
    )


def _handle_pause_stream(
    params: dict[str, Any],
    db: Any = None,
    float_guard: Any = None,
    settings: Any = None,
) -> ActionResult:
    """Pause a specific PayStream session."""
    stream_id = params.get("stream_id")
    if not stream_id:
        return ActionResult(
            action="pause_stream",
            status="failed",
            detail="Missing required parameter: stream_id",
        )

    if db is None:
        return ActionResult(
            action="pause_stream",
            status="failed",
            detail="Database session not available",
        )

    try:
        from sqlalchemy import select
        from sonic.models.stream_session import StreamSession

        stream = db.scalars(
            select(StreamSession).where(StreamSession.id == stream_id).limit(1)
        ).first()

        if not stream:
            return ActionResult(
                action="pause_stream",
                status="failed",
                detail=f"Stream not found: {stream_id}",
            )

        if stream.status == "paused":
            return ActionResult(
                action="pause_stream",
                status="failed",
                detail=f"Stream {stream_id} is already paused",
            )

        stream.status = "paused"
        db.flush()

        return ActionResult(
            action="pause_stream",
            status="success",
            detail=f"Stream {stream_id} paused",
            data={"stream_id": stream_id},
        )
    except Exception as exc:
        logger.warning("Pause stream handler error: %s", exc)
        return ActionResult(
            action="pause_stream",
            status="failed",
            detail=str(exc),
        )


def _handle_resume_stream(
    params: dict[str, Any],
    db: Any = None,
    float_guard: Any = None,
    settings: Any = None,
) -> ActionResult:
    """Resume a paused PayStream session."""
    stream_id = params.get("stream_id")
    if not stream_id:
        return ActionResult(
            action="resume_stream",
            status="failed",
            detail="Missing required parameter: stream_id",
        )

    if db is None:
        return ActionResult(
            action="resume_stream",
            status="failed",
            detail="Database session not available",
        )

    try:
        from sqlalchemy import select
        from sonic.models.stream_session import StreamSession

        stream = db.scalars(
            select(StreamSession).where(StreamSession.id == stream_id).limit(1)
        ).first()

        if not stream:
            return ActionResult(
                action="resume_stream",
                status="failed",
                detail=f"Stream not found: {stream_id}",
            )

        if stream.status != "paused":
            return ActionResult(
                action="resume_stream",
                status="failed",
                detail=f"Stream {stream_id} is not paused (status: {stream.status})",
            )

        stream.status = "open"
        db.flush()

        return ActionResult(
            action="resume_stream",
            status="success",
            detail=f"Stream {stream_id} resumed",
            data={"stream_id": stream_id},
        )
    except Exception as exc:
        logger.warning("Resume stream handler error: %s", exc)
        return ActionResult(
            action="resume_stream",
            status="failed",
            detail=str(exc),
        )


def _handle_retry_failed_payout(
    params: dict[str, Any],
    db: Any = None,
    float_guard: Any = None,
    settings: Any = None,
) -> ActionResult:
    """Re-queue a failed payout for processing."""
    tx_id = params.get("tx_id")
    if not tx_id:
        return ActionResult(
            action="retry_failed_payout",
            status="failed",
            detail="Missing required parameter: tx_id",
        )

    if db is None:
        return ActionResult(
            action="retry_failed_payout",
            status="failed",
            detail="Database session not available",
        )

    try:
        from sqlalchemy import select
        from sonic.core.engine import TxState
        from sonic.models.transaction import TransactionRecord

        record = db.scalars(
            select(TransactionRecord)
            .where(TransactionRecord.id == tx_id)
            .limit(1)
        ).first()

        if not record:
            return ActionResult(
                action="retry_failed_payout",
                status="failed",
                detail=f"Transaction not found: {tx_id}",
            )

        if record.state != TxState.FAILED.value:
            return ActionResult(
                action="retry_failed_payout",
                status="failed",
                detail=f"Transaction {tx_id} is not in FAILED state (state: {record.state})",
            )

        # Reset to NORMALIZED so the payout can be re-attempted
        record.state = TxState.NORMALIZED.value
        db.flush()

        return ActionResult(
            action="retry_failed_payout",
            status="success",
            detail=f"Transaction {tx_id} reset to NORMALIZED for retry",
            data={"tx_id": tx_id},
        )
    except Exception as exc:
        logger.warning("Retry failed payout handler error: %s", exc)
        return ActionResult(
            action="retry_failed_payout",
            status="failed",
            detail=str(exc),
        )


def _handle_trigger_health_check(
    params: dict[str, Any],
    db: Any = None,
    float_guard: Any = None,
    settings: Any = None,
) -> ActionResult:
    """Force a full readiness probe of all settlement components."""
    return ActionResult(
        action="trigger_health_check",
        status="success",
        detail="Health check requested. See settlement_health data key for results.",
        data={"requested_at": datetime.now(timezone.utc).isoformat()},
    )


def _handle_escalate_to_manual(
    params: dict[str, Any],
    db: Any = None,
    float_guard: Any = None,
    settings: Any = None,
) -> ActionResult:
    """Flag settlement state for manual operator review."""
    reason = params.get("reason", "Escalated to manual review via Tower Agent")
    logger.warning("Settlement ESCALATED to manual review: %s", reason)

    return ActionResult(
        action="escalate_to_manual",
        status="success",
        detail=f"Escalated to manual review. Reason: {reason}",
        data={"escalation": True, "reason": reason},
    )


# ---------------------------------------------------------------------------
# Handler registry
# ---------------------------------------------------------------------------

_HANDLERS: dict[str, Any] = {
    "pause_settlements": _handle_pause_settlements,
    "resume_settlements": _handle_resume_settlements,
    "pause_stream": _handle_pause_stream,
    "resume_stream": _handle_resume_stream,
    "retry_failed_payout": _handle_retry_failed_payout,
    "trigger_health_check": _handle_trigger_health_check,
    "escalate_to_manual": _handle_escalate_to_manual,
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _receipt_hash(action: str, data: dict[str, Any]) -> str:
    """Generate a deterministic receipt hash for action audit trail."""
    content = f"{action}:{datetime.now(timezone.utc).isoformat()}:{str(data)}"
    return hashlib.sha256(content.encode()).hexdigest()[:32]
