"""Alerting hooks — threshold-based checks run in the background drain loop.

Checks:
  - SBN dead-letter queue depth (> threshold → alert)
  - SBN attestation backlog (> threshold → alert)
  - Provider health degradation (>N consecutive failures → alert)

Alerts are emitted as WARNING log lines with a structured ``alert``
extra field so they can be routed by log-based alerting systems
(Datadog, PagerDuty, Grafana Loki, etc.).
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("sonic.alerting")

# Thresholds (can be overridden via config or environment)
DLQ_DEPTH_THRESHOLD = 10
SBN_BACKLOG_THRESHOLD = 100
PROVIDER_FAILURE_WINDOW = 5  # consecutive drain-loop cycles


class AlertState:
    """Tracks alert state to avoid repeated firing."""

    def __init__(self) -> None:
        self._fired: set[str] = set()
        self._provider_fail_counts: dict[str, int] = {}

    def _fire(self, alert_name: str, detail: dict[str, Any]) -> None:
        """Fire an alert (log once per alert name until cleared)."""
        if alert_name in self._fired:
            return
        self._fired.add(alert_name)
        logger.warning(
            "ALERT: %s",
            alert_name,
            extra={"alert": alert_name, **detail},
        )

    def _clear(self, alert_name: str) -> None:
        if alert_name in self._fired:
            self._fired.discard(alert_name)
            logger.info("ALERT CLEARED: %s", alert_name, extra={"alert": alert_name})

    # --- Check functions ---

    async def check_dlq(self, redis: Any, dlq_key: str = "sonic:sbn:attestation_queue:dead") -> None:
        """Alert if dead-letter queue depth exceeds threshold."""
        try:
            depth = await redis.llen(dlq_key)
        except Exception:
            return
        if depth >= DLQ_DEPTH_THRESHOLD:
            self._fire("sbn_dlq_high", {"dlq_depth": depth, "threshold": DLQ_DEPTH_THRESHOLD})
        else:
            self._clear("sbn_dlq_high")

    async def check_sbn_backlog(self, attester: Any) -> None:
        """Alert if SBN attestation queue is backed up."""
        try:
            depth = await attester.queue_depth()
        except Exception:
            return
        if depth >= SBN_BACKLOG_THRESHOLD:
            self._fire("sbn_backlog_high", {"queue_depth": depth, "threshold": SBN_BACKLOG_THRESHOLD})
        else:
            self._clear("sbn_backlog_high")

    def check_provider_health(self, rail: str, healthy: bool) -> None:
        """Track consecutive provider failures and alert on degradation."""
        if healthy:
            prev = self._provider_fail_counts.pop(rail, 0)
            if prev >= PROVIDER_FAILURE_WINDOW:
                self._clear(f"provider_degraded:{rail}")
            return

        count = self._provider_fail_counts.get(rail, 0) + 1
        self._provider_fail_counts[rail] = count
        if count >= PROVIDER_FAILURE_WINDOW:
            self._fire(f"provider_degraded:{rail}", {"provider": rail, "consecutive_failures": count})

    async def run_all(
        self,
        *,
        redis: Any | None = None,
        attester: Any | None = None,
        providers: dict[str, Any] | None = None,
    ) -> None:
        """Run all alert checks (called from the drain loop)."""
        if redis is not None:
            await self.check_dlq(redis)
        if attester is not None:
            await self.check_sbn_backlog(attester)
        if providers is not None:
            seen: set[int] = set()
            for rail, provider in providers.items():
                pid = id(provider)
                if pid in seen:
                    continue
                seen.add(pid)
                try:
                    healthy = await provider.health()
                except Exception:
                    healthy = False
                self.check_provider_health(rail, healthy)
