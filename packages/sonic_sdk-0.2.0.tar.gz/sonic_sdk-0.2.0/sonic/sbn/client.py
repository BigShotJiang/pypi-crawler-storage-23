"""Sonic-specific SBN client — thin wrapper around the official sbn-sdk.

Policy lives here; protocol lives in ``sbn``.

This client:
 - Reads Sonic config for SBN connection details
 - Wraps ``sbn.SbnClient`` for all SDK operations
 - Adds ``submit_pipeline()`` — attestation via ``gateway.request_attestation()``
 - Exposes ``active`` flag and Sonic-specific error types
"""

from __future__ import annotations

import logging
from typing import Any

from sonic.config import settings

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Sonic-specific error types
# ---------------------------------------------------------------------------


class SbnError(RuntimeError):
    """Raised when an SBN operation fails from Sonic's perspective."""

    def __init__(self, message: str, *, cause: Exception | None = None) -> None:
        super().__init__(message)
        self.cause = cause


class SbnQuotaExceeded(SbnError):
    """Raised when SBN responds with HTTP 429 / quota limit."""

    pass


# ---------------------------------------------------------------------------
# Sonic SBN Client
# ---------------------------------------------------------------------------


class SonicSbnClient:
    """Sonic's SBN integration point.

    Wraps the official ``sbn.SbnClient`` and adds Sonic-specific
    behaviour like ``submit_pipeline()``, config-driven auth, and
    Sonic error mapping.

    Usage::

        client = SonicSbnClient()     # reads from SONIC_SBN_* settings
        result = await client.submit_pipeline(snap_hash="sha256:abc...")
        client.close()
    """

    def __init__(self) -> None:
        self._base_url = settings.sbn_base_url
        self._api_key = settings.sbn_api_key
        self._project_id = settings.sbn_project_id
        self._timeout = settings.sbn_attestation_timeout

        # Initialise the official SDK client (or None if no API key)
        self._sdk: Any | None = None
        if self._api_key:
            try:
                from sbn import SbnClient as RawSbnClient

                sdk = RawSbnClient(base_url=self._base_url)
                sdk.authenticate_api_key(self._api_key)
                self._sdk = sdk
                logger.info("SBN SDK initialised: %s", self._base_url)
            except Exception:
                logger.warning("SBN SDK init failed — attestation disabled", exc_info=True)
        else:
            logger.info("SBN API key not configured — attestation disabled")

    # ── Properties ──────────────────────────────────────────────────────

    @property
    def active(self) -> bool:
        """True when the SDK is initialised and ready."""
        return self._sdk is not None

    @property
    def sdk(self) -> Any:
        """Direct access to the underlying ``sbn.SbnClient``.

        Raises SbnError if not active.
        """
        if self._sdk is None:
            raise SbnError("SBN client is not active — check configuration")
        return self._sdk

    # ── Submit pipeline ─────────────────────────────────────────────────

    async def submit_pipeline(
        self,
        *,
        snap_hash: str,
        domain: str = "sonic.settlement",
        block: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        metrics: dict[str, Any] | None = None,
        slot_id: str | None = None,
        seal: bool = True,
    ) -> dict[str, Any]:
        """Submit a receipt through the SBN attestation pipeline.

        Uses ``gateway.request_attestation()`` per the Agent SDK
        Developer Guide (POST /attest).

        Returns the SBN response dict with sbn_hash, snap_hash,
        block_id, slot_id etc.
        """
        if not self.active:
            raise SbnError("SBN client is not active — check configuration")

        # Ensure sha256: prefix
        if not snap_hash.startswith("sha256:"):
            snap_hash = f"sha256:{snap_hash}"

        # Build attestation summary per POST /attest schema
        summary: dict[str, Any] = {
            "snap_hash": snap_hash,
            "snap_version": "1",
        }
        if slot_id is not None:
            summary["slot_id"] = slot_id
        if metadata is not None:
            summary["metadata"] = metadata
        if metrics is not None:
            summary["metrics"] = metrics

        try:
            result = self._sdk.gateway.request_attestation(summary)
            return result
        except Exception as exc:
            msg = str(exc)
            if "429" in msg or "quota" in msg.lower():
                raise SbnQuotaExceeded(
                    "SBN quota exceeded", cause=exc
                ) from exc
            raise SbnError(
                f"SBN submit pipeline failed: {msg}", cause=exc
            ) from exc

    # ── Slot lifecycle ─────────────────────────────────────────────────

    def open_slot(
        self,
        *,
        worker_id: str,
        task_type: str = "sonic.settlement",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Open a new SBN slot for batch attestation.

        Returns dict with at least ``{"id": "<slot_id>"}``.
        """
        if not self.active:
            raise SbnError("SBN client is not active — check configuration")

        try:
            slot = self._sdk.gateway.create_slot(
                worker_id=worker_id,
                task_type=task_type,
                metadata=metadata or {},
            )
            slot_id = getattr(slot, "id", None) or (
                slot.get("id", "") if isinstance(slot, dict) else ""
            )
            logger.info("SBN slot opened: %s (worker=%s)", slot_id, worker_id)
            return {"id": slot_id, "raw": slot}
        except Exception as exc:
            raise SbnError(
                f"Failed to open SBN slot: {exc}", cause=exc
            ) from exc

    def close_slot(self, slot_id: str) -> dict[str, Any]:
        """Close an SBN slot and return the Merkle root.

        Returns dict with ``{"slot_id", "merkle_root", "receipt_id"}``.
        """
        if not self.active:
            raise SbnError("SBN client is not active — check configuration")

        try:
            closure = self._sdk.gateway.close_slot(slot_id)
            merkle_root = (
                getattr(closure, "merkle_root", None)
                or getattr(closure, "root", None)
                or (closure.get("merkle_root") if isinstance(closure, dict) else "")
            )
            receipt_id = (
                getattr(closure, "receipt_id", None)
                or (closure.get("receipt_id") if isinstance(closure, dict) else "")
            )
            logger.info(
                "SBN slot closed: %s (merkle_root=%s)", slot_id, merkle_root
            )
            return {
                "slot_id": slot_id,
                "merkle_root": merkle_root,
                "receipt_id": receipt_id,
                "raw": closure,
            }
        except Exception as exc:
            raise SbnError(
                f"Failed to close SBN slot {slot_id}: {exc}", cause=exc
            ) from exc

    # ── Convenience: discover a hash on SnapChore ──────────────────────

    def discover(self, snapchore_hash: str) -> dict[str, Any] | None:
        """Look up a hash on the SnapChore ledger. Returns None if not found."""
        if not self.active:
            return None
        try:
            return self._sdk.snapchore.discover(snapchore_hash)
        except Exception:
            return None

    # ── Lifecycle ───────────────────────────────────────────────────────

    # Back-compat alias: callers using the old name still work.
    verify = discover

    def close(self) -> None:
        if self._sdk is not None:
            self._sdk.close()


# Back-compat alias so ``from sonic.sbn.client import SbnClient`` still works.
SbnClient = SonicSbnClient
