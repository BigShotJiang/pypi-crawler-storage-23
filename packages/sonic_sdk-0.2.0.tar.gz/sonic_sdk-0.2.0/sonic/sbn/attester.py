"""SBN Attester — queues Sonic receipts for SBN attestation via the submit pipeline.

Flow:
  1. When a receipt is created, ``enqueue(receipt)`` pushes a job to Redis.
  2. The background drain loop calls ``process_one()`` which pops a job,
     calls ``SonicSbnClient.submit_pipeline()``, and returns the SBN result.
  3. On transient failure, the job is re-queued with an incremented attempt counter.
  4. After ``MAX_ATTEMPTS``, the job moves to a dead-letter queue.

The attester does NOT write back to the DB — that's the coupler's job.
The caller (drain loop or coupler) is responsible for persisting
``sbn_receipt_hash`` and triggering the combined-hash backfiller.
"""

from __future__ import annotations

import json
import logging
from decimal import Decimal
from typing import Any

from sonic.config import settings
from sonic.metrics import RECEIPT_TOTAL

logger = logging.getLogger(__name__)


class SbnAttester:
    """Queue-based SBN attestation worker."""

    MAX_ATTEMPTS = 5

    _queue_key = "sonic:sbn:attestation_queue"
    _dlq_key = "sonic:sbn:attestation_queue:dead"

    def __init__(self, sbn_client: Any, redis_client: Any) -> None:
        self._sbn = sbn_client
        self._redis = redis_client

    # ── Payload construction ────────────────────────────────────────────

    def _build_submit_payload(
        self,
        receipt: Any,
        *,
        slot_id: str | None = None,
    ) -> dict[str, Any]:
        """Build the submit pipeline payload from a Sonic receipt."""
        snap_hash = receipt.receipt_hash
        if not snap_hash.startswith("sha256:"):
            snap_hash = f"sha256:{snap_hash}"

        amount_float = float(receipt.amount) if isinstance(receipt.amount, Decimal) else float(receipt.amount)

        return {
            "snap_hash": snap_hash,
            "snap_version": "1",
            "domain": "sonic.settlement",
            "seal": True,
            "slot_id": slot_id,
            "block": {
                "type": "finance",
                "actions": [
                    {
                        "action": receipt.event_type,
                        "reinforced": False,
                        "score": 1.0,
                    }
                ],
                "events": {
                    "total": 1,
                    "hostile": 0,
                    "neutral": 0,
                    "friendly": 1,
                },
            },
            "metadata": {
                "source": "sonic-pay",
                "receipt_id": receipt.receipt_id,
                "tx_id": receipt.tx_id,
                "merchant_id": receipt.merchant_id,
                "currency": receipt.currency,
                "frontier_id": settings.sbn_frontier_id,
            },
            "metrics": {
                "yield": amount_float,
                "trust": 1.0,
            },
        }

    # ── Queue operations ────────────────────────────────────────────────

    async def enqueue(
        self,
        receipt: Any,
        *,
        slot_id: str | None = None,
    ) -> None:
        """Push a receipt onto the attestation queue.

        No-op when attestation is disabled.
        """
        if not settings.sbn_attestation_enabled:
            return

        payload = self._build_submit_payload(receipt, slot_id=slot_id)

        job = json.dumps({
            "receipt_id": receipt.receipt_id,
            "attempts": 0,
            "submit_payload": payload,
        })
        await self._redis.lpush(self._queue_key, job)
        logger.debug("Enqueued SBN attestation for receipt %s", receipt.receipt_id)

    async def process_one(self) -> dict[str, Any] | None:
        """Pop one job and submit through the SBN pipeline.

        Returns the result dict on success, None on empty queue or failure.
        """
        raw = await self._redis.rpop(self._queue_key)
        if not raw:
            return None

        job = json.loads(raw)
        receipt_id = job["receipt_id"]
        attempts = job["attempts"]
        submit_payload = job["submit_payload"]

        try:
            # Pass only POST /attest fields to submit_pipeline
            result = await self._sbn.submit_pipeline(
                snap_hash=submit_payload["snap_hash"],
                metadata=submit_payload.get("metadata"),
                metrics=submit_payload.get("metrics"),
                slot_id=submit_payload.get("slot_id"),
            )
        except Exception:
            logger.warning(
                "SBN attestation failed for receipt %s (attempt %d/%d)",
                receipt_id,
                attempts + 1,
                self.MAX_ATTEMPTS,
                exc_info=True,
            )

            attempts += 1
            job["attempts"] = attempts

            if attempts >= self.MAX_ATTEMPTS:
                await self._redis.lpush(self._dlq_key, json.dumps(job))
                logger.error(
                    "SBN attestation exhausted retries — moved to DLQ: %s",
                    receipt_id,
                )
            else:
                await self._redis.lpush(self._queue_key, json.dumps(job))

            return None

        sbn_hash = result.get("sbn_hash", "")
        snap_hash = result.get("snap_hash", "")
        block_id = result.get("block_id", "")
        slot_id = result.get("slot_id")

        RECEIPT_TOTAL.labels(tier="tier2").inc()
        logger.info(
            "SBN attestation succeeded: receipt=%s sbn_hash=%s",
            receipt_id,
            sbn_hash[:20] + "..." if len(sbn_hash) > 20 else sbn_hash,
        )

        return {
            "receipt_id": receipt_id,
            "sbn_hash": sbn_hash,
            "snap_hash": snap_hash,
            "block_id": block_id,
            "slot_id": slot_id,
        }

    async def drain(self, max_batch: int = 50) -> int:
        """Process up to max_batch jobs. Returns count processed."""
        processed = 0
        for _ in range(max_batch):
            result = await self.process_one()
            if result is not None:
                processed += 1
            else:
                break
        return processed

    async def queue_depth(self) -> int:
        return await self._redis.llen(self._queue_key)

    async def dlq_depth(self) -> int:
        return await self._redis.llen(self._dlq_key)
