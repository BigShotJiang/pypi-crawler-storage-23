"""Hedera Consensus Service (HCS) anchor provider.

Submits combined receipt hashes as HCS messages, providing:
- Append-only ordered messages with consensus timestamps
- Sub-cent cost per message
- 3-5 second finality via hashgraph consensus
- Public verifiability through Hedera mirror nodes

Each merchant can have a dedicated HCS topic, or share a global one.
Messages contain the combined_hash plus metadata for correlation.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any

from sonic.anchor.base import AnchorError, AnchorProvider, AnchorResult
from sonic.config import settings

logger = logging.getLogger(__name__)

# Hedera SDK is optional — graceful degradation if not installed
try:
    from hedera import (  # type: ignore[import-untyped]
        Client as HederaClient,
        AccountId,
        PrivateKey,
        TopicId,
        TopicMessageSubmitTransaction,
    )

    _HEDERA_SDK = True
except ImportError:
    _HEDERA_SDK = False


class HederaAnchorProvider(AnchorProvider):
    """Anchor receipts to Hedera Consensus Service (HCS).

    Submits a JSON message containing the combined_hash to an HCS topic.
    The consensus timestamp from Hedera serves as the tamper-evident
    proof that this hash existed at that point in time.

    Falls back gracefully if the Hedera SDK is not installed.
    """

    def __init__(
        self,
        operator_id: str | None = None,
        operator_key: str | None = None,
        network: str | None = None,
        default_topic_id: str | None = None,
        mirror_url: str | None = None,
    ):
        self._operator_id = operator_id or settings.hedera_operator_id
        self._operator_key = operator_key or settings.hedera_operator_key
        self._network = network or settings.hedera_network
        self._default_topic_id = default_topic_id or settings.hedera_default_topic_id
        self._mirror_url = mirror_url or settings.hedera_mirror_url
        self._client: Any = None

        if _HEDERA_SDK and self._operator_id and self._operator_key:
            try:
                if self._network == "mainnet":
                    self._client = HederaClient.forMainnet()
                else:
                    self._client = HederaClient.forTestnet()

                self._client.setOperator(
                    AccountId.fromString(self._operator_id),
                    PrivateKey.fromString(self._operator_key),
                )
                logger.info(
                    "Hedera HCS anchor initialized: operator=%s network=%s",
                    self._operator_id,
                    self._network,
                )
            except Exception:
                logger.warning("Hedera SDK initialization failed", exc_info=True)
                self._client = None
        elif not _HEDERA_SDK:
            logger.info("Hedera SDK not installed — HCS anchoring unavailable")

    @property
    def chain_name(self) -> str:
        return "hedera"

    @property
    def active(self) -> bool:
        return self._client is not None

    async def submit(
        self,
        combined_hash: str,
        *,
        receipt_id: str,
        tx_id: str,
        merchant_id: str,
        topic_id: str | None = None,
    ) -> AnchorResult:
        """Submit combined hash as an HCS message.

        The message is a compact JSON payload:
        {
            "v": 1,
            "h": "<combined_hash>",
            "r": "<receipt_id>",
            "t": "<tx_id>",
            "m": "<merchant_id>",
            "ts": "<iso_timestamp>"
        }
        """
        if not self.active:
            raise AnchorError("hedera", "Hedera client not initialized")

        resolved_topic = topic_id or self._default_topic_id
        if not resolved_topic:
            raise AnchorError("hedera", "No HCS topic ID configured")

        message = json.dumps({
            "v": 1,
            "h": combined_hash,
            "r": receipt_id,
            "t": tx_id,
            "m": merchant_id,
            "ts": datetime.now(timezone.utc).isoformat(),
        }, separators=(",", ":"))

        try:
            tx = (
                TopicMessageSubmitTransaction()
                .setTopicId(TopicId.fromString(resolved_topic))
                .setMessage(message.encode())
            )
            response = await tx.executeAsync(self._client)
            receipt = await response.getReceiptAsync(self._client)

            # Extract consensus timestamp and sequence number
            consensus_ts = None
            seq_number = str(receipt.topicSequenceNumber) if hasattr(receipt, "topicSequenceNumber") else ""

            if hasattr(response, "consensusTimestamp") and response.consensusTimestamp:
                consensus_ts = datetime.fromtimestamp(
                    float(str(response.consensusTimestamp)), tz=timezone.utc
                )

            anchor_tx_id = f"{resolved_topic}@{seq_number}"

            logger.info(
                "Hedera HCS anchor: topic=%s seq=%s hash=%s",
                resolved_topic,
                seq_number,
                combined_hash[:16] + "...",
            )

            return AnchorResult(
                chain="hedera",
                tx_id=anchor_tx_id,
                consensus_ts=consensus_ts,
                raw={
                    "topic_id": resolved_topic,
                    "sequence_number": seq_number,
                    "message": message,
                },
            )

        except Exception as exc:
            raise AnchorError("hedera", str(exc)) from exc

    async def verify(self, anchor_tx_id: str, expected_hash: str) -> bool:
        """Verify an anchor by querying the Hedera mirror node.

        Parses anchor_tx_id as "topic_id@sequence_number" and fetches
        the message from the mirror REST API.
        """
        if "@" not in anchor_tx_id:
            return False

        topic_id, seq_str = anchor_tx_id.split("@", 1)

        try:
            import httpx

            url = f"{self._mirror_url}/api/v1/topics/{topic_id}/messages/{seq_str}"
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(url)
                if resp.status_code != 200:
                    logger.warning("Hedera mirror returned %d for %s", resp.status_code, anchor_tx_id)
                    return False

                data = resp.json()
                # Mirror returns base64-encoded message
                import base64
                raw_message = base64.b64decode(data.get("message", "")).decode()
                message = json.loads(raw_message)
                return message.get("h") == expected_hash

        except ImportError:
            logger.warning("httpx not installed — cannot verify Hedera anchor")
            return False
        except Exception:
            logger.warning("Hedera mirror verification failed for %s", anchor_tx_id, exc_info=True)
            return False

    async def health(self) -> bool:
        if not self.active:
            return False
        try:
            import httpx

            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(f"{self._mirror_url}/api/v1/transactions?limit=1")
                return resp.status_code == 200
        except Exception:
            return False
