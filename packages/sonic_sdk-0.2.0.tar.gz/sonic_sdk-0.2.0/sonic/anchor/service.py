"""Blockchain anchor service — Tier 3 orchestration.

Routes anchor requests to the correct chain provider based on
merchant preference. Manages the anchor queue and backfills
anchor proof onto receipt records.

Flow:
  1. CombinedHashBackfiller computes combined_hash
  2. Calls AnchorService.maybe_anchor() — checks if merchant opted in
  3. If yes, enqueues anchor job
  4. Background worker submits to Hedera HCS or Solana
  5. Backfills anchor_tx_id, anchor_consensus_ts onto the receipt
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any

from sonic.anchor.base import AnchorError, AnchorProvider
from sonic.config import settings
from sonic.metrics import RECEIPT_TOTAL

logger = logging.getLogger(__name__)


class AnchorService:
    """Manages blockchain anchoring for Sonic receipts."""

    def __init__(
        self,
        db_session_factory: Any,
        redis_client: Any,
        providers: dict[str, AnchorProvider] | None = None,
    ):
        self._db = db_session_factory
        self._redis = redis_client
        self._providers: dict[str, AnchorProvider] = providers or {}
        self._queue_key = "sonic:anchor:queue"

    def register_provider(self, provider: AnchorProvider) -> None:
        """Register a blockchain anchor provider."""
        self._providers[provider.chain_name] = provider
        logger.info("Registered anchor provider: %s", provider.chain_name)

    def get_provider(self, chain: str) -> AnchorProvider | None:
        return self._providers.get(chain)

    async def maybe_anchor(
        self,
        *,
        receipt_id: str,
        combined_hash: str,
        merchant_id: str,
        tx_id: str,
    ) -> bool:
        """Check if merchant opted in and enqueue anchor if so.

        Returns True if an anchor job was enqueued.
        """
        if not settings.anchor_enabled:
            return False

        # Look up merchant anchor preference
        async with self._db() as session:
            from sonic.models.merchant import Merchant

            result = await session.execute(
                Merchant.__table__.select().where(Merchant.id == merchant_id)
            )
            merchant = result.mappings().first()

        if not merchant or not merchant.get("anchor_chain"):
            return False

        chain = merchant["anchor_chain"]
        if chain not in self._providers:
            logger.warning(
                "Merchant %s wants chain '%s' but no provider registered",
                merchant_id,
                chain,
            )
            return False

        # Resolve topic/program ID
        topic_id = None
        if chain == "hedera":
            topic_id = merchant.get("hedera_topic_id") or settings.hedera_default_topic_id
        elif chain == "solana":
            topic_id = merchant.get("solana_program_id") or settings.solana_program_id

        job = json.dumps({
            "receipt_id": receipt_id,
            "combined_hash": combined_hash,
            "merchant_id": merchant_id,
            "tx_id": tx_id,
            "chain": chain,
            "topic_id": topic_id,
        })
        await self._redis.lpush(self._queue_key, job)
        logger.debug(
            "Enqueued %s anchor for receipt %s (merchant %s)",
            chain,
            receipt_id,
            merchant_id,
        )
        return True

    async def process_one(self) -> dict[str, Any] | None:
        """Pop one anchor job and submit to the blockchain.

        On success, backfills anchor proof onto the receipt record.
        """
        raw = await self._redis.rpop(self._queue_key)
        if not raw:
            return None

        job = json.loads(raw)
        chain = job["chain"]
        provider = self._providers.get(chain)

        if not provider:
            logger.error("No provider for chain '%s' — dropping anchor job", chain)
            return None

        try:
            result = await provider.submit(
                job["combined_hash"],
                receipt_id=job["receipt_id"],
                tx_id=job["tx_id"],
                merchant_id=job["merchant_id"],
                topic_id=job.get("topic_id"),
            )
        except AnchorError as exc:
            logger.warning(
                "Anchor submission failed: chain=%s receipt=%s error=%s",
                chain,
                job["receipt_id"],
                exc.detail,
            )
            # Re-enqueue for retry (could add attempt counter like SbnAttester)
            await self._redis.lpush(self._queue_key, raw)
            return None

        # Backfill anchor proof onto receipt
        async with self._db() as session:
            from sonic.models.receipt import ReceiptRecord

            await session.execute(
                ReceiptRecord.__table__.update()
                .where(ReceiptRecord.receipt_id == job["receipt_id"])
                .values(
                    anchor_chain=result.chain,
                    anchor_tx_id=result.tx_id,
                    anchor_consensus_ts=result.consensus_ts,
                    anchored_at=datetime.now(timezone.utc),
                )
            )
            await session.commit()

        RECEIPT_TOTAL.labels(tier="tier3").inc()
        logger.info(
            "Anchor backfilled: chain=%s receipt=%s tx=%s",
            result.chain,
            job["receipt_id"],
            result.tx_id,
        )

        return {
            "receipt_id": job["receipt_id"],
            "chain": result.chain,
            "anchor_tx_id": result.tx_id,
            "consensus_ts": result.consensus_ts.isoformat() if result.consensus_ts else None,
        }

    async def drain(self, max_batch: int = 50) -> int:
        """Process up to max_batch anchor jobs."""
        processed = 0
        for _ in range(max_batch):
            result = await self.process_one()
            if result is not None:
                processed += 1
            else:
                break
        return processed

    async def queue_depth(self) -> int:
        return await self._redis.llen(self._queue_key)

    async def health(self) -> dict[str, bool]:
        """Health check for all registered providers."""
        results = {}
        for name, provider in self._providers.items():
            results[name] = await provider.health()
        return results
