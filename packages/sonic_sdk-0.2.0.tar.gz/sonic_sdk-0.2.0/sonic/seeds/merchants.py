"""Seed Sonic merchants for Grid operating companies.

Run: python -m sonic.seeds.merchants

Registers each operating company as a Sonic merchant so they can process
payments. API keys are printed to stdout — store them as env vars in
the corresponding docker-compose service.

Safe to re-run: skips merchants that already exist (by email).
"""
from __future__ import annotations

import asyncio
import logging

from sqlalchemy import select

from sonic.api.middleware.auth import generate_api_key
from sonic.models.base import async_session_factory, engine, Base
from sonic.models.merchant import Merchant

log = logging.getLogger("sonic.seeds")

# Operating companies to register as Sonic merchants
MERCHANTS = [
    {
        "name": "ICOD",
        "email": "icod@tower.tech",
        "business_type": "enterprise",
        "default_payout_currency": "USD",
        "default_payout_rail": "stripe_card",
    },
    {
        "name": "Atomic Rentals",
        "email": "atomic@tower.tech",
        "business_type": "enterprise",
        "default_payout_currency": "USD",
        "default_payout_rail": "stripe_card",
    },
    {
        "name": "SBN Gigs",
        "email": "sbngigs@tower.tech",
        "business_type": "enterprise",
        "default_payout_currency": "USD",
        "default_payout_rail": "stripe_card",
    },
]


async def seed_merchants() -> list[dict[str, str]]:
    """Register Grid operating companies as Sonic merchants.

    Returns list of {"name", "merchant_id", "api_key"} for newly created merchants.
    Skips any merchant whose email already exists.
    """
    results: list[dict[str, str]] = []

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with async_session_factory() as db:
        for merchant_data in MERCHANTS:
            # Check if already registered
            existing = await db.execute(
                select(Merchant).where(Merchant.email == merchant_data["email"])
            )
            if existing.scalar_one_or_none():
                log.info("Merchant %s already exists — skipping", merchant_data["name"])
                continue

            # Generate API key
            full_key, key_hash = generate_api_key()

            merchant = Merchant(
                name=merchant_data["name"],
                email=merchant_data["email"],
                business_type=merchant_data["business_type"],
                default_payout_currency=merchant_data["default_payout_currency"],
                default_payout_rail=merchant_data["default_payout_rail"],
                api_key_hash=key_hash,
                api_key_prefix=full_key[:20],
            )
            db.add(merchant)
            await db.flush()

            results.append({
                "name": merchant.name,
                "merchant_id": merchant.id,
                "api_key": full_key,
            })
            log.info("Created merchant %s → %s", merchant.name, merchant.id)

        await db.commit()

    return results


async def main():
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    results = await seed_merchants()
    if not results:
        print("\nAll merchants already registered. No new keys generated.")
        return

    print("\n" + "=" * 70)
    print("  SONIC MERCHANT KEYS — SAVE THESE (shown only once)")
    print("=" * 70)
    for r in results:
        print(f"\n  {r['name']}")
        print(f"    merchant_id : {r['merchant_id']}")
        print(f"    api_key     : {r['api_key']}")
        print(f"    env var     : ICOD_SONIC_API_KEY={r['api_key']}" if "ICOD" in r["name"] else "")
    print("\n" + "=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
