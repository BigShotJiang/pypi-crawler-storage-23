"""Sonic SDK client — typed Python interface to the Sonic settlement API.

Usage::

    from sonic.client import SonicClient

    sonic = SonicClient(base_url="https://api.sonic.tower.dev", api_key="sonic_live_...")

    payment = sonic.create_payment(amount="100.00", currency="USD", idempotency_key="inv-123")
    print(payment.tx_id, payment.receipt_hash)

    tx = sonic.get_transaction(payment.tx_id)
    print(tx.state)
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any

import httpx
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Response schemas — importable by consumers for type-checking
# ---------------------------------------------------------------------------


class PaymentResponse(BaseModel):
    tx_id: str
    status: str
    receipt_hash: str | None = None
    message: str = "Payment initiated"


class PayoutResponse(BaseModel):
    tx_id: str
    payout_status: str
    provider_ref: str | None = None
    receipt_hash: str | None = None


class TransactionResponse(BaseModel):
    tx_id: str
    merchant_id: str
    state: str
    sequence: int
    inbound_amount: Decimal
    inbound_currency: str
    inbound_rail: str
    inbound_provider_ref: str | None = None
    treasury_amount: Decimal | None = None
    treasury_asset: str = "USDC"
    outbound_amount: Decimal | None = None
    outbound_currency: str | None = None
    outbound_rail: str | None = None
    outbound_provider_ref: str | None = None
    customer_ref: str | None = None
    created_at: datetime
    updated_at: datetime


class TransactionListResponse(BaseModel):
    transactions: list[TransactionResponse]
    total: int
    limit: int
    offset: int


class EventResponse(BaseModel):
    id: str
    tx_id: str
    event_type: str
    from_state: str | None = None
    to_state: str | None = None
    provider: str | None = None
    provider_ref: str | None = None
    receipt_hash: str | None = None
    payload: dict | None = None
    timestamp: datetime


class FinalityResponse(BaseModel):
    tx_id: str
    state: str
    rail: str
    finality_status: str
    hold_period_seconds: int
    reversible: bool
    reversible_window_seconds: int | None = None
    min_confirmations: int | None = None


class ReceiptResponse(BaseModel):
    receipt_id: str
    tx_id: str
    event_type: str
    sequence: int
    amount: Decimal
    currency: str
    rail: str
    direction: str
    receipt_hash: str
    prev_receipt_hash: str | None = None
    merchant_id: str
    timestamp: datetime
    sbn_receipt_hash: str | None = None
    sbn_attested_at: datetime | None = None


class VerifyResponse(BaseModel):
    receipt_hash: str
    chain_valid: bool
    sbn_attested: bool
    sbn_receipt_hash: str | None = None
    tx_id: str
    event_type: str
    amount: Decimal
    currency: str
    merchant_id: str


class MerchantResponse(BaseModel):
    merchant_id: str
    name: str
    email: str
    business_type: str
    default_payout_currency: str
    default_payout_rail: str
    api_key: str | None = None
    status: str = "active"


class WebhookResponse(BaseModel):
    merchant_id: str
    webhook_url: str
    events: list[str]
    status: str = "registered"


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class SonicError(Exception):
    """Base exception for Sonic API errors."""

    def __init__(self, status_code: int, detail: str, response: httpx.Response | None = None):
        self.status_code = status_code
        self.detail = detail
        self.response = response
        super().__init__(f"[{status_code}] {detail}")


class SonicNotFound(SonicError):
    pass


class SonicConflict(SonicError):
    pass


class SonicAuthError(SonicError):
    pass


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class SonicClient:
    """Typed HTTP client for the Sonic settlement API.

    All methods return Pydantic models. Raises :class:`SonicError` subclasses
    on non-2xx responses.
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        *,
        timeout: float = 30.0,
        httpx_client: httpx.Client | None = None,
    ):
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._client = httpx_client or httpx.Client(
            base_url=f"{self._base_url}/v1",
            headers={"x-sonic-api-key": api_key},
            timeout=timeout,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> SonicClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # -- internal helpers --

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.is_success:
            return
        detail = resp.json().get("detail", resp.text) if resp.headers.get("content-type", "").startswith("application/json") else resp.text
        if resp.status_code == 401:
            raise SonicAuthError(resp.status_code, detail, resp)
        if resp.status_code == 404:
            raise SonicNotFound(resp.status_code, detail, resp)
        if resp.status_code == 409:
            raise SonicConflict(resp.status_code, detail, resp)
        raise SonicError(resp.status_code, detail, resp)

    # -------------------------------------------------------------------
    # Payments
    # -------------------------------------------------------------------

    def create_payment(
        self,
        *,
        amount: str | Decimal,
        currency: str,
        idempotency_key: str,
        rail: str = "stripe_card",
        customer_ref: str | None = None,
        metadata: dict | None = None,
    ) -> PaymentResponse:
        """Create an inbound payment."""
        body: dict[str, Any] = {
            "amount": str(amount),
            "currency": currency,
            "rail": rail,
            "idempotency_key": idempotency_key,
        }
        if customer_ref is not None:
            body["customer_ref"] = customer_ref
        if metadata is not None:
            body["metadata"] = metadata
        resp = self._client.post("/payments", json=body)
        self._raise_for_status(resp)
        return PaymentResponse.model_validate(resp.json())

    # -------------------------------------------------------------------
    # Payouts
    # -------------------------------------------------------------------

    def execute_payout(
        self,
        *,
        tx_id: str,
        recipient_id: str,
        idempotency_key: str,
        amount: str | Decimal | None = None,
        currency: str | None = None,
        rail: str | None = None,
    ) -> PayoutResponse:
        """Execute an outbound payout for a cleared transaction."""
        body: dict[str, Any] = {
            "tx_id": tx_id,
            "recipient_id": recipient_id,
            "idempotency_key": idempotency_key,
        }
        if amount is not None:
            body["amount"] = str(amount)
        if currency is not None:
            body["currency"] = currency
        if rail is not None:
            body["rail"] = rail
        resp = self._client.post("/payouts", json=body)
        self._raise_for_status(resp)
        return PayoutResponse.model_validate(resp.json())

    # -------------------------------------------------------------------
    # Transactions
    # -------------------------------------------------------------------

    def get_transaction(self, tx_id: str) -> TransactionResponse:
        """Get a single transaction by ID."""
        resp = self._client.get(f"/transactions/{tx_id}")
        self._raise_for_status(resp)
        return TransactionResponse.model_validate(resp.json())

    def list_transactions(
        self,
        *,
        state: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> TransactionListResponse:
        """List transactions with optional state filter."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if state is not None:
            params["state"] = state
        resp = self._client.get("/transactions", params=params)
        self._raise_for_status(resp)
        return TransactionListResponse.model_validate(resp.json())

    def get_transaction_events(self, tx_id: str) -> list[EventResponse]:
        """Get the full event log for a transaction."""
        resp = self._client.get(f"/transactions/{tx_id}/events")
        self._raise_for_status(resp)
        return [EventResponse.model_validate(e) for e in resp.json()]

    def get_transaction_finality(self, tx_id: str) -> FinalityResponse:
        """Get finality status for a transaction."""
        resp = self._client.get(f"/transactions/{tx_id}/finality")
        self._raise_for_status(resp)
        return FinalityResponse.model_validate(resp.json())

    # -------------------------------------------------------------------
    # Receipts
    # -------------------------------------------------------------------

    def get_receipts(self, tx_id: str) -> list[ReceiptResponse]:
        """Get all receipts for a transaction."""
        resp = self._client.get(f"/receipts/{tx_id}")
        self._raise_for_status(resp)
        return [ReceiptResponse.model_validate(r) for r in resp.json()]

    def verify_receipt(self, tx_id: str, sequence: int = 0) -> VerifyResponse:
        """Verify a receipt's chain integrity and SBN attestation."""
        resp = self._client.get(f"/receipts/{tx_id}/verify", params={"sequence": sequence})
        self._raise_for_status(resp)
        return VerifyResponse.model_validate(resp.json())

    def public_verify(self, receipt_hash: str) -> VerifyResponse:
        """Public verification — no auth required. Uses receipt hash directly."""
        resp = self._client.get(f"/verify/{receipt_hash}")
        self._raise_for_status(resp)
        return VerifyResponse.model_validate(resp.json())

    # -------------------------------------------------------------------
    # Merchants
    # -------------------------------------------------------------------

    def get_merchant(self, merchant_id: str) -> MerchantResponse:
        """Get merchant details."""
        resp = self._client.get(f"/merchants/{merchant_id}")
        self._raise_for_status(resp)
        return MerchantResponse.model_validate(resp.json())

    def register_webhook(
        self,
        merchant_id: str,
        *,
        url: str,
        events: list[str] | None = None,
    ) -> WebhookResponse:
        """Register a webhook URL for a merchant."""
        body: dict[str, Any] = {"url": url}
        if events is not None:
            body["events"] = events
        resp = self._client.post(f"/merchants/{merchant_id}/webhooks", json=body)
        self._raise_for_status(resp)
        return WebhookResponse.model_validate(resp.json())


# ---------------------------------------------------------------------------
# Async variant
# ---------------------------------------------------------------------------


class AsyncSonicClient:
    """Async variant of :class:`SonicClient` using ``httpx.AsyncClient``."""

    def __init__(
        self,
        base_url: str,
        api_key: str,
        *,
        timeout: float = 30.0,
        httpx_client: httpx.AsyncClient | None = None,
    ):
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._client = httpx_client or httpx.AsyncClient(
            base_url=f"{self._base_url}/v1",
            headers={"x-sonic-api-key": api_key},
            timeout=timeout,
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> AsyncSonicClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.is_success:
            return
        detail = resp.json().get("detail", resp.text) if resp.headers.get("content-type", "").startswith("application/json") else resp.text
        if resp.status_code == 401:
            raise SonicAuthError(resp.status_code, detail, resp)
        if resp.status_code == 404:
            raise SonicNotFound(resp.status_code, detail, resp)
        if resp.status_code == 409:
            raise SonicConflict(resp.status_code, detail, resp)
        raise SonicError(resp.status_code, detail, resp)

    # -------------------------------------------------------------------
    # Payments
    # -------------------------------------------------------------------

    async def create_payment(
        self,
        *,
        amount: str | Decimal,
        currency: str,
        idempotency_key: str,
        rail: str = "stripe_card",
        customer_ref: str | None = None,
        metadata: dict | None = None,
    ) -> PaymentResponse:
        body: dict[str, Any] = {
            "amount": str(amount),
            "currency": currency,
            "rail": rail,
            "idempotency_key": idempotency_key,
        }
        if customer_ref is not None:
            body["customer_ref"] = customer_ref
        if metadata is not None:
            body["metadata"] = metadata
        resp = await self._client.post("/payments", json=body)
        self._raise_for_status(resp)
        return PaymentResponse.model_validate(resp.json())

    # -------------------------------------------------------------------
    # Payouts
    # -------------------------------------------------------------------

    async def execute_payout(
        self,
        *,
        tx_id: str,
        recipient_id: str,
        idempotency_key: str,
        amount: str | Decimal | None = None,
        currency: str | None = None,
        rail: str | None = None,
    ) -> PayoutResponse:
        body: dict[str, Any] = {
            "tx_id": tx_id,
            "recipient_id": recipient_id,
            "idempotency_key": idempotency_key,
        }
        if amount is not None:
            body["amount"] = str(amount)
        if currency is not None:
            body["currency"] = currency
        if rail is not None:
            body["rail"] = rail
        resp = await self._client.post("/payouts", json=body)
        self._raise_for_status(resp)
        return PayoutResponse.model_validate(resp.json())

    # -------------------------------------------------------------------
    # Transactions
    # -------------------------------------------------------------------

    async def get_transaction(self, tx_id: str) -> TransactionResponse:
        resp = await self._client.get(f"/transactions/{tx_id}")
        self._raise_for_status(resp)
        return TransactionResponse.model_validate(resp.json())

    async def list_transactions(
        self,
        *,
        state: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> TransactionListResponse:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if state is not None:
            params["state"] = state
        resp = await self._client.get("/transactions", params=params)
        self._raise_for_status(resp)
        return TransactionListResponse.model_validate(resp.json())

    async def get_transaction_events(self, tx_id: str) -> list[EventResponse]:
        resp = await self._client.get(f"/transactions/{tx_id}/events")
        self._raise_for_status(resp)
        return [EventResponse.model_validate(e) for e in resp.json()]

    async def get_transaction_finality(self, tx_id: str) -> FinalityResponse:
        resp = await self._client.get(f"/transactions/{tx_id}/finality")
        self._raise_for_status(resp)
        return FinalityResponse.model_validate(resp.json())

    # -------------------------------------------------------------------
    # Receipts
    # -------------------------------------------------------------------

    async def get_receipts(self, tx_id: str) -> list[ReceiptResponse]:
        resp = await self._client.get(f"/receipts/{tx_id}")
        self._raise_for_status(resp)
        return [ReceiptResponse.model_validate(r) for r in resp.json()]

    async def verify_receipt(self, tx_id: str, sequence: int = 0) -> VerifyResponse:
        resp = await self._client.get(f"/receipts/{tx_id}/verify", params={"sequence": sequence})
        self._raise_for_status(resp)
        return VerifyResponse.model_validate(resp.json())

    async def public_verify(self, receipt_hash: str) -> VerifyResponse:
        resp = await self._client.get(f"/verify/{receipt_hash}")
        self._raise_for_status(resp)
        return VerifyResponse.model_validate(resp.json())

    # -------------------------------------------------------------------
    # Merchants
    # -------------------------------------------------------------------

    async def get_merchant(self, merchant_id: str) -> MerchantResponse:
        resp = await self._client.get(f"/merchants/{merchant_id}")
        self._raise_for_status(resp)
        return MerchantResponse.model_validate(resp.json())

    async def register_webhook(
        self,
        merchant_id: str,
        *,
        url: str,
        events: list[str] | None = None,
    ) -> WebhookResponse:
        body: dict[str, Any] = {"url": url}
        if events is not None:
            body["events"] = events
        resp = await self._client.post(f"/merchants/{merchant_id}/webhooks", json=body)
        self._raise_for_status(resp)
        return WebhookResponse.model_validate(resp.json())
