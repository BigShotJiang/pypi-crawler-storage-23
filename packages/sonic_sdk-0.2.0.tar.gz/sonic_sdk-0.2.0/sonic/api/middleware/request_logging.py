"""Request logging middleware — structured access logs with correlation IDs.

Emits one JSON log line per request containing:
  - method, path, status code, latency (ms)
  - client IP, user-agent
  - X-Request-ID (generated if not provided by caller)

The request ID is set in a ``ContextVar`` so every log message emitted
during request handling automatically includes it.

Also records Prometheus HTTP request metrics (duration histogram + counter).
"""

from __future__ import annotations

import logging
import time
import uuid

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

from sonic.logging import request_id_var
from sonic.metrics import HTTP_REQUEST_DURATION, HTTP_REQUESTS_TOTAL

logger = logging.getLogger("sonic.access")


def _normalize_path(path: str) -> str:
    """Collapse path IDs to reduce cardinality in metrics labels.

    /v1/transactions/abc123/events -> /v1/transactions/{id}/events
    /v1/merchants/xyz789           -> /v1/merchants/{id}
    """
    parts = path.strip("/").split("/")
    normalized = []
    prev_is_resource = False
    for part in parts:
        if prev_is_resource and part not in ("events", "webhooks", "receipts", "verify", "me"):
            normalized.append("{id}")
            prev_is_resource = False
        else:
            normalized.append(part)
            prev_is_resource = part in (
                "transactions", "merchants", "payments", "payouts",
                "receipts", "sessions", "payment-links",
            )
    return "/" + "/".join(normalized)


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Log every HTTP request and propagate a correlation ID."""

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        # Use caller-provided ID or generate one.
        rid = request.headers.get("x-request-id") or uuid.uuid4().hex[:16]
        token = request_id_var.set(rid)

        start = time.perf_counter()
        try:
            response = await call_next(request)
        except Exception:
            elapsed = (time.perf_counter() - start) * 1000
            logger.error(
                "request_error",
                extra={
                    "method": request.method,
                    "path": request.url.path,
                    "latency_ms": round(elapsed, 1),
                    "client": request.client.host if request.client else "-",
                },
                exc_info=True,
            )
            raise
        finally:
            request_id_var.reset(token)

        elapsed_s = time.perf_counter() - start
        elapsed_ms = elapsed_s * 1000

        # Attach correlation ID to the response so callers can trace it.
        response.headers["X-Request-ID"] = rid

        # --- Prometheus metrics ---
        label_path = _normalize_path(request.url.path)
        status = str(response.status_code)
        HTTP_REQUEST_DURATION.labels(
            method=request.method, path=label_path, status=status,
        ).observe(elapsed_s)
        HTTP_REQUESTS_TOTAL.labels(
            method=request.method, path=label_path, status=status,
        ).inc()

        logger.info(
            "request",
            extra={
                "method": request.method,
                "path": request.url.path,
                "status": response.status_code,
                "latency_ms": round(elapsed_ms, 1),
                "client": request.client.host if request.client else "-",
            },
        )

        return response
