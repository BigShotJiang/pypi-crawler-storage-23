"""Rate limiting middleware — token bucket per API key and per IP.

Protects against brute-force, DDoS, and abuse. Uses Redis for
distributed rate limiting across multiple Sonic instances.

Three tiers:
  - Global per-IP:     100 req/min (unauthenticated endpoints)
  - Per-merchant:      600 req/min (authenticated endpoints)
  - Sensitive ops:     10 req/min  (merchant creation, payout execution)
"""

from __future__ import annotations

import logging
import time
from typing import Any

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import JSONResponse

logger = logging.getLogger(__name__)

# Limits: (max_requests, window_seconds)
RATE_LIMITS: dict[str, tuple[int, int]] = {
    "global": (100, 60),       # 100 req/min per IP
    "merchant": (600, 60),     # 600 req/min per API key
    "sensitive": (10, 60),     # 10 req/min for sensitive ops
}

# Endpoints that use the "sensitive" limit
SENSITIVE_PATHS = {
    "/v1/merchants",       # merchant creation
    "/v1/payouts",         # payout execution
}


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Redis-backed sliding window rate limiter."""

    def __init__(self, app: Any, redis_client: Any | None = None):
        super().__init__(app)
        self._redis = redis_client

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        if self._redis is None:
            return await call_next(request)

        client_ip = request.client.host if request.client else "unknown"
        api_key_prefix = self._extract_key_prefix(request)
        path = request.url.path

        # Check global IP rate limit
        exceeded, retry_after = await self._check_limit(
            f"sonic:rl:ip:{client_ip}",
            *RATE_LIMITS["global"],
        )
        if exceeded:
            return self._rate_limit_response(retry_after)

        # Check merchant rate limit (if authenticated)
        if api_key_prefix:
            exceeded, retry_after = await self._check_limit(
                f"sonic:rl:key:{api_key_prefix}",
                *RATE_LIMITS["merchant"],
            )
            if exceeded:
                return self._rate_limit_response(retry_after)

        # Check sensitive endpoint limit
        if request.method == "POST" and path in SENSITIVE_PATHS:
            limit_key = f"sonic:rl:sensitive:{api_key_prefix or client_ip}"
            exceeded, retry_after = await self._check_limit(
                limit_key,
                *RATE_LIMITS["sensitive"],
            )
            if exceeded:
                return self._rate_limit_response(retry_after)

        response = await call_next(request)
        return response

    async def _check_limit(
        self, key: str, max_requests: int, window_seconds: int
    ) -> tuple[bool, int]:
        """Sliding window counter using Redis INCR + EXPIRE.

        Returns (exceeded: bool, retry_after_seconds: int).
        """
        try:
            current = await self._redis.incr(key)
            if current == 1:
                await self._redis.expire(key, window_seconds)

            if current > max_requests:
                ttl = await self._redis.ttl(key)
                return True, max(ttl, 1)

            return False, 0
        except Exception:
            # If Redis is down, fail open — don't block requests
            logger.warning("Rate limit check failed (Redis unavailable)", exc_info=True)
            return False, 0

    def _extract_key_prefix(self, request: Request) -> str | None:
        """Extract API key prefix from request header."""
        key = request.headers.get("x-sonic-api-key", "")
        return key[:20] if len(key) >= 20 else None

    def _rate_limit_response(self, retry_after: int) -> JSONResponse:
        return JSONResponse(
            status_code=429,
            content={
                "detail": "Rate limit exceeded",
                "retry_after": retry_after,
            },
            headers={"Retry-After": str(retry_after)},
        )
