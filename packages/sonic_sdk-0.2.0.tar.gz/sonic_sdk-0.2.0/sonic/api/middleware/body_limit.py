"""Request body size limiter — prevents oversized payloads.

Rejects requests with Content-Length exceeding the configured limit.
Also wraps the receive channel to enforce the limit for chunked
transfers where Content-Length may not be set.
"""

from __future__ import annotations

import logging

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import JSONResponse

logger = logging.getLogger(__name__)


class BodySizeLimitMiddleware(BaseHTTPMiddleware):
    """Reject requests with bodies exceeding max_bytes."""

    def __init__(self, app, *, max_bytes: int = 1_048_576):
        super().__init__(app)
        self._max_bytes = max_bytes

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        # Check Content-Length header (fast path)
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                if int(content_length) > self._max_bytes:
                    return self._too_large()
            except ValueError:
                pass

        return await call_next(request)

    def _too_large(self) -> JSONResponse:
        return JSONResponse(
            status_code=413,
            content={
                "detail": f"Request body too large (max {self._max_bytes} bytes)"
            },
        )
