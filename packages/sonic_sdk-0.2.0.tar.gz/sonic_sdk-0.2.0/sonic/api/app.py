"""Sonic FastAPI application."""

from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI

from sonic.config import settings
from sonic.logging import setup_logging
from sonic.metrics import SBN_QUEUE_DEPTH, SBN_DLQ_DEPTH, ANCHOR_QUEUE_DEPTH, PROVIDER_HEALTH

logger = logging.getLogger("sonic.app")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup / shutdown hooks — initialize services, yield, then tear down."""

    # --- Redis ---
    redis_client = None
    try:
        from redis.asyncio import from_url as redis_from_url

        redis_url = settings.redis_url
        # Enforce TLS in production: upgrade redis:// to rediss://
        if settings.redis_require_tls and redis_url.startswith("redis://"):
            redis_url = "rediss://" + redis_url[len("redis://"):]
            logger.info("Redis TLS enforced (redis_require_tls=True)")

        redis_client = redis_from_url(redis_url, decode_responses=True)
        await redis_client.ping()
        logger.info("Redis connected: %s", redis_url.split("@")[-1])  # Log host only, not creds
    except Exception:
        logger.warning("Redis unavailable — idempotency and SBN queue disabled", exc_info=True)
        redis_client = None

    app.state.redis = redis_client

    # --- Inject Redis into rate-limit middleware (mounted at app creation time) ---
    if redis_client:
        from sonic.api.middleware.rate_limit import RateLimitMiddleware

        walker = app.middleware_stack
        while walker is not None:
            if isinstance(walker, RateLimitMiddleware):
                walker._redis = redis_client
                logger.info("Rate limiter activated (Redis-backed)")
                break
            walker = getattr(walker, "app", None)

    # --- SBN client ---
    from sonic.sbn.client import SonicSbnClient

    sbn_client = SonicSbnClient()
    app.state.sbn = sbn_client

    # --- SBN attester (requires Redis) ---
    from sonic.sbn.attester import SbnAttester

    app.state.attester = SbnAttester(sbn_client, redis_client) if redis_client else None

    # --- Blockchain anchor service ---
    from sonic.models.base import async_session_factory
    from sonic.anchor.service import AnchorService

    anchor_service = None
    if settings.anchor_enabled and redis_client:
        anchor_service = AnchorService(async_session_factory, redis_client)

        if settings.hedera_operator_id:
            from sonic.anchor.hedera import HederaAnchorProvider

            hedera = HederaAnchorProvider()
            if hedera.active:
                anchor_service.register_provider(hedera)

        if settings.solana_payer_key:
            from sonic.anchor.solana import SolanaAnchorProvider

            solana = SolanaAnchorProvider()
            if solana.active:
                anchor_service.register_provider(solana)

    app.state.anchor_service = anchor_service

    # --- Combined hash backfiller ---
    from sonic.core.combined_backfiller import CombinedHashBackfiller

    combined_backfiller = None
    if redis_client:
        combined_backfiller = CombinedHashBackfiller(
            async_session_factory, redis_client, anchor_service=anchor_service,
        )
    app.state.combined_backfiller = combined_backfiller

    # --- Receipt coupler ---
    from sonic.sbn.receipt_coupler import ReceiptCoupler

    app.state.coupler = ReceiptCoupler(
        sbn_client, async_session_factory, combined_backfiller=combined_backfiller,
    )

    # --- Receipt verifier ---
    from sonic.core.receipt_verifier import ReceiptVerifier

    app.state.verifier = ReceiptVerifier(
        async_session_factory, sbn_client=sbn_client, anchor_service=anchor_service,
    )

    # --- Provider adapters ---
    providers: dict[str, object] = {}

    if settings.stripe_secret_key:
        from sonic.providers.stripe_provider import StripeProvider

        providers["stripe_card"] = StripeProvider(settings.stripe_secret_key)
        providers["stripe_ach"] = providers["stripe_card"]
        providers["stripe_transfer"] = providers["stripe_card"]

    if settings.moov_api_key:
        from sonic.providers.moov_provider import MoovProvider

        providers["moov_ach"] = MoovProvider(settings.moov_api_key, settings.moov_account_id)

    if settings.circle_api_key:
        from sonic.providers.circle_provider import CircleProvider

        providers["circle_usdc"] = CircleProvider(settings.circle_api_key, settings.circle_environment)
        providers["circle_usdc_solana"] = providers["circle_usdc"]

    app.state.providers = providers

    # --- Payout executor ---
    from sonic.core.payout_executor import PayoutExecutor

    app.state.payout_executor = PayoutExecutor(providers)

    # --- Treasury ---
    from sonic.core.treasury import Treasury

    app.state.treasury = Treasury(base_asset=settings.base_treasury_asset)

    # --- Finality gate ---
    from sonic.core.finality_gate import FinalityGate

    app.state.finality_gate = FinalityGate()

    # --- Event emitter ---
    from sonic.events.emitter import EventEmitter

    app.state.emitter = EventEmitter()

    # --- Float guard (optional — gates payouts against treasury float) ---
    float_guard = None
    if settings.float_guard_enabled:
        from sonic._vendor.dominion.core.float_guard import FloatGuard

        float_guard = FloatGuard(
            configured_float=settings.configured_float,
            min_float_ratio=settings.float_min_ratio,
            throttle_threshold=settings.float_throttle_ratio,
            tier=1,
        )
        logger.info(
            "Float guard enabled: configured=%.0f min_ratio=%.2f throttle=%.2f",
            settings.configured_float, settings.float_min_ratio, settings.float_throttle_ratio,
        )
    app.state.float_guard = float_guard

    # --- Stream worker (PayStream windowed accrual) ---
    from sonic.core.stream_worker import StreamWorker

    app.state.stream_worker = StreamWorker(
        db_session_factory=async_session_factory,
        sbn_client=sbn_client if sbn_client.active else None,
        payout_executor=app.state.payout_executor,
        emitter=app.state.emitter,
        treasury=app.state.treasury,
        float_guard=float_guard,
    )

    # --- Normalizer ---
    from sonic.core.normalizer import Normalizer

    app.state.normalizer = Normalizer(app.state.treasury)

    # --- Settlement poller ---
    from sonic.core.settlement_poller import SettlementPoller

    app.state.settlement_poller = SettlementPoller(
        db_session_factory=async_session_factory,
        providers=providers,
        emitter=app.state.emitter,
        attester=app.state.attester,
    )

    # --- Stuck-state sweeper ---
    from sonic.core.stuck_sweeper import StuckSweeper

    app.state.stuck_sweeper = StuckSweeper(
        db_session_factory=async_session_factory,
        emitter=app.state.emitter,
        normalizing_timeout_minutes=settings.stuck_normalizing_minutes,
        payout_pending_timeout_minutes=settings.stuck_payout_pending_minutes,
    )

    # --- Idempotency store ---
    if redis_client:
        from sonic.api.middleware.idempotency import IdempotencyStore

        app.state.idempotency = IdempotencyStore(redis_client)
    else:
        app.state.idempotency = None

    # --- Transaction archiver ---
    from sonic.core.archiver import TransactionArchiver

    app.state.archiver = TransactionArchiver(async_session_factory) if settings.archival_enabled else None

    # --- pgDAG execution layer (proof-gated workflow engine) ---
    execution_layer = None
    try:
        from pgdag import build as pgdag_build
        from sonic.execution import SONIC_TEMPLATES
        from sonic.execution.steps import (
            settlement_flow_steps,
            stream_lifecycle_steps,
            epoch_coupling_steps,
            receipt_verification_steps,
        )

        execution_layer = pgdag_build(
            sbn_client=sbn_client if sbn_client.active else None,
            domain="sonic.settlement",
        )

        # Register all step factories with live service dependencies
        execution_layer.runner.register_steps(settlement_flow_steps(
            db=async_session_factory,
            payout_executor=app.state.payout_executor,
            treasury=app.state.treasury,
            sbn_client=sbn_client if sbn_client.active else None,
            receipt_builder=None,  # Uses inline receipt logic
            attester=app.state.attester,
            finality_gate=app.state.finality_gate,
            settlement_poller=app.state.settlement_poller,
        ))
        execution_layer.runner.register_steps(stream_lifecycle_steps(
            db=async_session_factory,
            stream_worker=app.state.stream_worker,
            policy_engine=None,  # Uses inline policy logic
            payout_executor=app.state.payout_executor,
            sbn_client=sbn_client if sbn_client.active else None,
        ))
        execution_layer.runner.register_steps(epoch_coupling_steps(
            db=async_session_factory,
            sbn_client=sbn_client if sbn_client.active else None,
            backfiller=combined_backfiller,
        ))
        execution_layer.runner.register_steps(receipt_verification_steps(
            db=async_session_factory,
            receipt_verifier=app.state.verifier,
            sbn_client=sbn_client if sbn_client.active else None,
            anchor_service=anchor_service,
        ))

        logger.info(
            "pgDAG execution layer ready: %d templates, %d step functions",
            len(SONIC_TEMPLATES),
            sum(len(t.nodes) for t in SONIC_TEMPLATES.values()),
        )
    except ImportError:
        logger.info("pgDAG not installed — execution layer disabled")
    except Exception:
        logger.warning("pgDAG initialization failed", exc_info=True)

    app.state.execution_layer = execution_layer
    app.state.sonic_templates = None
    try:
        from sonic.execution import SONIC_TEMPLATES as _tmpl
        app.state.sonic_templates = _tmpl
    except ImportError:
        pass

    logger.info(
        "Sonic started: providers=%s sbn=%s redis=%s anchor=%s coupler=%s pgdag=%s",
        list(providers.keys()),
        sbn_client.active,
        redis_client is not None,
        anchor_service is not None,
        settings.coupler_enabled,
        execution_layer is not None,
    )

    # --- Background drain loop — process SBN attestation, coupler, and backfill queues ---
    drain_task: asyncio.Task | None = None

    async def _drain_loop() -> None:
        """Continuously drain worker queues in the background."""
        from sonic.alerting import AlertState

        alert_state = AlertState()
        attester = app.state.attester
        backfiller = app.state.combined_backfiller
        anchor = app.state.anchor_service
        coupler = app.state.coupler
        poller = app.state.settlement_poller
        stream_worker = app.state.stream_worker
        sweeper = app.state.stuck_sweeper
        archiver = app.state.archiver
        cycle = 0
        while True:
            try:
                if attester is not None:
                    await attester.drain(max_batch=20)
                if coupler is not None:
                    await coupler.drain()
                if backfiller is not None:
                    await backfiller.drain(max_batch=20)
                if anchor is not None:
                    await anchor.drain(max_batch=10)
                # Settlement poll + window auto-close (configurable interval)
                if cycle % settings.settlement_poll_interval_cycles == 0:
                    if poller is not None:
                        await poller.poll(max_batch=20)
                    if stream_worker is not None:
                        await stream_worker.auto_close_expired_windows(
                            max_batch=settings.stream_auto_close_max_batch,
                        )
                # Retry failed micro-payouts (configurable interval)
                if cycle % settings.payout_retry_interval_cycles == 0:
                    if stream_worker is not None:
                        await stream_worker.retry_failed_payouts(
                            max_batch=settings.payout_retry_max_batch,
                        )
                # Close stale epochs + sweep stuck txns (configurable interval)
                cycle += 1
                if cycle % settings.stuck_sweeper_interval_cycles == 0:
                    if coupler is not None:
                        await coupler.maybe_close_previous_epochs()
                    if sweeper is not None:
                        await sweeper.sweep()
                # Archive old terminal transactions (configurable interval)
                if cycle % settings.archival_interval_cycles == 0:
                    if archiver is not None:
                        await archiver.sweep()
                # Update queue depth gauges for Prometheus (every cycle)
                if attester is not None:
                    SBN_QUEUE_DEPTH.set(await attester.queue_depth())
                    SBN_DLQ_DEPTH.set(await attester.dlq_depth())
                if anchor is not None:
                    ANCHOR_QUEUE_DEPTH.set(await anchor.queue_depth())
                # Update provider health gauges + alerting (every 10 cycles)
                if cycle % 10 == 0:
                    providers = app.state.providers
                    seen_pids: set[int] = set()
                    for rail, provider in providers.items():
                        pid = id(provider)
                        if pid in seen_pids:
                            continue
                        seen_pids.add(pid)
                        try:
                            healthy = await provider.health()
                        except Exception:
                            healthy = False
                        PROVIDER_HEALTH.labels(provider=rail).set(1 if healthy else 0)
                        alert_state.check_provider_health(rail, healthy)
                    # Run non-provider alerts (DLQ, SBN backlog)
                    await alert_state.run_all(
                        redis=app.state.redis,
                        attester=attester,
                    )
            except Exception:
                logger.warning("Background drain error", exc_info=True)
            await asyncio.sleep(settings.coupler_drain_interval)

    if redis_client:
        drain_task = asyncio.create_task(_drain_loop())
        logger.info("Background drain loop started")

    yield

    # --- Shutdown ---
    if drain_task is not None:
        drain_task.cancel()
        try:
            await drain_task
        except asyncio.CancelledError:
            pass
        logger.info("Background drain loop stopped")

    sbn_client.close()
    if redis_client:
        await redis_client.aclose()
    logger.info("Sonic shutdown complete")


def create_app() -> FastAPI:
    # --- Structured logging (must happen before any log calls) ---
    setup_logging(
        level="DEBUG" if settings.debug else "INFO",
        json_output=not settings.debug,
    )

    # --- Sentry error tracking (no-op when DSN is empty) ---
    if settings.sentry_dsn:
        import sentry_sdk

        sentry_sdk.init(
            dsn=settings.sentry_dsn,
            environment=settings.environment,
            traces_sample_rate=settings.sentry_traces_sample_rate,
            send_default_pii=False,
        )
        logger.info("Sentry initialized: environment=%s", settings.environment)

    from sonic._version import __version__

    app = FastAPI(
        title="Sonic",
        description="Multi-currency settlement engine with cryptographic receipts",
        version=__version__,
        lifespan=lifespan,
    )

    # --- Request logging middleware (outermost — wraps everything) ---
    from sonic.api.middleware.request_logging import RequestLoggingMiddleware

    app.add_middleware(RequestLoggingMiddleware)

    # --- Rate limiting middleware (Redis-backed, fails-open when Redis is unavailable) ---
    from sonic.api.middleware.rate_limit import RateLimitMiddleware

    app.add_middleware(RateLimitMiddleware)

    # --- Security middleware ---
    from sonic.api.middleware.security_headers import SecurityHeadersMiddleware

    app.add_middleware(SecurityHeadersMiddleware)

    # --- CSRF middleware (double-submit cookie for browser sessions) ---
    from sonic.api.middleware.csrf import CsrfMiddleware

    app.add_middleware(CsrfMiddleware)

    # --- Request body size limit ---
    from sonic.api.middleware.body_limit import BodySizeLimitMiddleware

    app.add_middleware(BodySizeLimitMiddleware, max_bytes=settings.max_request_body_bytes)

    # --- ProviderError handler — never leak raw provider details to clients ---
    from fastapi import Request
    from fastapi.responses import JSONResponse
    from sonic.metrics import PROVIDER_ERRORS
    from sonic.providers.base import ProviderError

    @app.exception_handler(ProviderError)
    async def provider_error_handler(request: Request, exc: ProviderError) -> JSONResponse:
        PROVIDER_ERRORS.labels(provider=exc.provider, retryable=str(exc.retryable)).inc()
        logger.error("Provider error [%s]: %s", exc.provider, exc, exc_info=True)
        status = 502 if exc.retryable else 400
        return JSONResponse(
            status_code=status,
            content={"detail": "Payment provider error — please retry or contact support"},
        )

    # --- CORS (configurable via SONIC_CORS_ORIGINS) ---
    from fastapi.middleware.cors import CORSMiddleware

    cors_origins = [o.strip() for o in settings.cors_origins.split(",") if o.strip()]
    # Always include checkout_base_url
    if settings.checkout_base_url not in cors_origins:
        cors_origins.append(settings.checkout_base_url)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=[
            "Authorization",
            "Content-Type",
            "X-Sonic-Api-Key",
            "X-Idempotency-Key",
        ],
    )

    # --- Routes ---
    from sonic.api.routes import (
        admin, admin_v2, api_keys, auth, batch_payouts, compliance, exports,
        fx, health, merchants, pay_streams, payment_links, payments, payouts,
        receipts, registration, sessions, streams, transactions, tower_agent,
        webhook_mgmt, webhooks,
    )

    app.include_router(auth.router, tags=["auth"])
    app.include_router(registration.router, tags=["registration"])
    app.include_router(health.router, tags=["health"])
    app.include_router(tower_agent.router, tags=["tower-agent"])
    app.include_router(payments.router, prefix="/v1", tags=["payments"])
    app.include_router(payouts.router, prefix="/v1", tags=["payouts"])
    app.include_router(batch_payouts.router, prefix="/v1", tags=["payouts"])
    app.include_router(transactions.router, prefix="/v1", tags=["transactions"])
    app.include_router(exports.router, prefix="/v1", tags=["exports"])
    app.include_router(receipts.router, prefix="/v1", tags=["receipts"])
    app.include_router(merchants.router, prefix="/v1", tags=["merchants"])
    app.include_router(api_keys.router, prefix="/v1", tags=["api-keys"])
    app.include_router(webhooks.router, prefix="/v1", tags=["webhooks"])
    app.include_router(webhook_mgmt.router, prefix="/v1", tags=["webhook-management"])
    app.include_router(fx.router, prefix="/v1", tags=["fx"])
    app.include_router(streams.router, prefix="/v1", tags=["streams"])
    app.include_router(pay_streams.router, prefix="/v1", tags=["pay-streams"])
    app.include_router(sessions.router, prefix="/v1", tags=["checkout"])
    app.include_router(payment_links.router, prefix="/v1", tags=["checkout"])
    app.include_router(admin.router, prefix="/v1", tags=["admin"])
    app.include_router(admin_v2.router, prefix="/v1", tags=["admin"])
    app.include_router(compliance.router, prefix="/v1", tags=["compliance"])

    return app
