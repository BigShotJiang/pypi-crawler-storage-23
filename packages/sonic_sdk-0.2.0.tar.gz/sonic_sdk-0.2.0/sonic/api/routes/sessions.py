"""Checkout session endpoints — hosted checkout for website integration.

Flow:
1. Merchant server calls POST /v1/sessions with amount + redirect URLs
2. Gets back { session_id, checkout_url }
3. Redirect customer to checkout_url (or use the embed widget)
4. Customer pays on Sonic-hosted page
5. Sonic creates the payment, redirects to success_url
6. Merchant receives webhook notification

This mirrors Stripe Checkout's redirect model.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import get_db, get_merchant, get_emitter, get_attester, get_idempotency
from sonic.config import settings
from sonic.core.engine import Transaction, TxState
from sonic.core.receipt_builder import ReceiptChain
from sonic.events.types import EventType
from sonic.models.checkout_session import CheckoutSession
from sonic.models.event_log import EventLog
from sonic.models.merchant import Merchant
from sonic.models.receipt import ReceiptRecord
from sonic.models.transaction import TransactionRecord

log = logging.getLogger("sonic.sessions")

router = APIRouter()

VALID_RAILS = {"stripe_card", "stripe_ach", "moov_ach", "circle_usdc", "circle_usdc_solana"}
SESSION_TTL_MINUTES = 30


# --- Request / Response schemas ---


class CreateSessionRequest(BaseModel):
    amount: Decimal = Field(..., gt=0, description="Payment amount")
    currency: str = Field(default="USD", min_length=3, max_length=4)
    rail: str | None = Field(default=None, description="Payment rail (null = customer chooses)")
    success_url: str = Field(..., description="Redirect URL after successful payment")
    cancel_url: str | None = Field(default=None, description="Redirect URL if customer cancels")
    customer_ref: str | None = Field(default=None, description="Your order/invoice reference")
    description: str | None = Field(default=None, max_length=500)
    metadata: dict | None = None
    expires_in_minutes: int = Field(default=SESSION_TTL_MINUTES, ge=5, le=1440)

    @field_validator("rail")
    @classmethod
    def validate_rail(cls, v: str | None) -> str | None:
        if v is not None and v not in VALID_RAILS:
            raise ValueError(f"Invalid rail. Must be one of: {', '.join(sorted(VALID_RAILS))}")
        return v


class SessionResponse(BaseModel):
    session_id: str
    checkout_url: str
    status: str
    amount: str
    currency: str
    expires_at: str


class SessionStatusResponse(BaseModel):
    session_id: str
    status: str
    tx_id: str | None = None
    receipt_hash: str | None = None


class CompleteSessionRequest(BaseModel):
    rail: str = Field(..., description="Payment rail selected by customer")

    @field_validator("rail")
    @classmethod
    def validate_rail(cls, v: str) -> str:
        if v not in VALID_RAILS:
            raise ValueError(f"Invalid rail. Must be one of: {', '.join(sorted(VALID_RAILS))}")
        return v


# --- Endpoints ---


@router.post("/sessions", response_model=SessionResponse, status_code=201)
async def create_session(
    body: CreateSessionRequest,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
):
    """Create a checkout session.

    Returns a checkout_url the merchant should redirect their customer to.
    The session expires after `expires_in_minutes` (default 30).
    """
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=body.expires_in_minutes)

    session = CheckoutSession(
        merchant_id=merchant.id,
        amount=body.amount,
        currency=body.currency.upper(),
        rail=body.rail,
        status="open",
        success_url=body.success_url,
        cancel_url=body.cancel_url,
        customer_ref=body.customer_ref,
        description=body.description,
        metadata_json=json.dumps(body.metadata) if body.metadata else None,
        expires_at=expires_at,
    )

    db.add(session)
    await db.commit()
    await db.refresh(session)

    checkout_base = settings.checkout_base_url.rstrip("/")
    checkout_url = f"{checkout_base}/pay/{session.id}"

    log.info(
        "Checkout session created: session=%s merchant=%s amount=%s %s",
        session.id, merchant.id, body.amount, body.currency,
    )

    return SessionResponse(
        session_id=session.id,
        checkout_url=checkout_url,
        status=session.status,
        amount=str(session.amount),
        currency=session.currency,
        expires_at=session.expires_at.isoformat(),
    )


@router.get("/sessions/{session_id}", response_model=SessionStatusResponse)
async def get_session(
    session_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Get session status — public endpoint (no auth required).

    Used by the checkout page and merchants polling for completion.
    """
    result = await db.execute(
        select(CheckoutSession).where(CheckoutSession.id == session_id)
    )
    session = result.scalar_one_or_none()

    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")

    # Auto-expire
    if session.status == "open" and datetime.now(timezone.utc) > session.expires_at:
        session.status = "expired"
        await db.commit()

    receipt_hash = None
    if session.tx_id:
        tx_result = await db.execute(
            select(TransactionRecord).where(TransactionRecord.id == session.tx_id)
        )
        tx = tx_result.scalar_one_or_none()
        if tx:
            # Get the receipt hash from the first receipt
            from sonic.models.receipt import ReceiptRecord
            receipt_result = await db.execute(
                select(ReceiptRecord.receipt_hash)
                .where(ReceiptRecord.tx_id == session.tx_id)
                .order_by(ReceiptRecord.sequence)
                .limit(1)
            )
            receipt_hash = receipt_result.scalar_one_or_none()

    return SessionStatusResponse(
        session_id=session.id,
        status=session.status,
        tx_id=session.tx_id,
        receipt_hash=receipt_hash,
    )


@router.post("/sessions/{session_id}/complete", response_model=SessionStatusResponse)
async def complete_session(
    session_id: str,
    body: CompleteSessionRequest,
    db: AsyncSession = Depends(get_db),
    emitter: Any = Depends(get_emitter),
    attester: Any = Depends(get_attester),
    idempotency_store: Any = Depends(get_idempotency),
):
    """Complete a checkout session — called by the hosted checkout page.

    This is a public endpoint (authenticated by session_id, not API key).
    Creates the actual payment and advances the session to 'completed'.
    """
    result = await db.execute(
        select(CheckoutSession).where(CheckoutSession.id == session_id)
    )
    session = result.scalar_one_or_none()

    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    if session.status != "open":
        raise HTTPException(status_code=409, detail=f"Session is {session.status}, cannot complete")
    if datetime.now(timezone.utc) > session.expires_at:
        session.status = "expired"
        await db.commit()
        raise HTTPException(status_code=410, detail="Session has expired")

    # Create the payment (same logic as POST /v1/payments)
    idempotency_key = f"session_{session.id}"
    rail = body.rail

    tx = Transaction(
        tx_id="",
        merchant_id=session.merchant_id,
        inbound_amount=session.amount,
        inbound_currency=session.currency,
        inbound_rail=rail,
    )

    record = TransactionRecord(
        merchant_id=session.merchant_id,
        state=TxState.INITIATED.value,
        inbound_amount=session.amount,
        inbound_currency=session.currency,
        inbound_rail=rail,
        customer_ref=session.customer_ref,
        idempotency_key=idempotency_key,
    )
    db.add(record)
    await db.flush()

    tx.tx_id = record.id
    event = tx.advance(
        TxState.RECEIVABLE_DETECTED,
        amount=session.amount,
        currency=session.currency,
        rail=rail,
        idempotency_key=idempotency_key,
    )

    record.state = TxState.RECEIVABLE_DETECTED.value
    record.sequence = tx.sequence

    chain = ReceiptChain()
    receipt = chain.build(event, merchant_id=session.merchant_id, direction="inbound")

    receipt_record = ReceiptRecord(
        receipt_id=receipt.receipt_id,
        tx_id=record.id,
        event_type=receipt.event_type,
        sequence=receipt.sequence,
        amount=receipt.amount,
        currency=receipt.currency,
        rail=receipt.rail,
        direction=receipt.direction,
        receipt_hash=receipt.receipt_hash,
        prev_receipt_hash=receipt.prev_receipt_hash,
        idempotency_key=receipt.idempotency_key,
        merchant_id=session.merchant_id,
    )
    db.add(receipt_record)

    db.add(EventLog(
        tx_id=record.id,
        event_type=EventType.RECEIVABLE_DETECTED.value,
        from_state=TxState.INITIATED.value,
        to_state=TxState.RECEIVABLE_DETECTED.value,
        merchant_id=session.merchant_id,
        provider=rail.split("_")[0],
        idempotency_key=idempotency_key,
        receipt_hash=receipt.receipt_hash,
        payload={
            "amount": str(session.amount),
            "currency": session.currency,
            "rail": rail,
            "session_id": session.id,
        },
    ))

    # Update session
    session.status = "completed"
    session.tx_id = record.id

    await db.commit()
    await db.refresh(record)

    log.info(
        "Checkout session completed: session=%s tx=%s merchant=%s",
        session.id, record.id, session.merchant_id,
    )

    # Async SBN attestation
    if attester is not None:
        try:
            await attester.enqueue(receipt)
        except Exception:
            log.warning("SBN attestation enqueue failed for session %s", session.id, exc_info=True)

    # Emit event
    try:
        await emitter.emit(EventType.RECEIVABLE_DETECTED, {
            "tx_id": record.id,
            "merchant_id": session.merchant_id,
            "amount": str(session.amount),
            "currency": session.currency,
            "rail": rail,
            "receipt_hash": receipt.receipt_hash,
            "session_id": session.id,
        })
    except Exception:
        log.warning("Event emission failed for session %s", session.id, exc_info=True)

    return SessionStatusResponse(
        session_id=session.id,
        status="completed",
        tx_id=record.id,
        receipt_hash=receipt.receipt_hash,
    )
