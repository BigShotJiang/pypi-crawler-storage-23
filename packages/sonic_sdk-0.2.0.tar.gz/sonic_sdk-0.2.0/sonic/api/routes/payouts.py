"""Payout endpoints — execute outbound payouts."""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import (
    get_db,
    get_merchant,
    get_emitter,
    get_attester,
    get_payout_executor,
    get_treasury,
    get_idempotency,
)
from sonic.core.engine import Transaction, TxState
from sonic.core.payout_executor import PayoutInstruction
from sonic.core.receipt_builder import ReceiptChain
from sonic.events.types import EventType
from sonic.models.event_log import EventLog
from sonic.models.merchant import Merchant
from sonic.metrics import PAYOUT_TOTAL
from sonic.models.receipt import ReceiptRecord
from sonic.models.transaction import TransactionRecord

log = logging.getLogger("sonic.payouts")

router = APIRouter()


class PayoutRequest(BaseModel):
    tx_id: str = Field(..., description="Transaction ID to pay out from")
    recipient_id: str = Field(..., description="Recipient account/wallet ID")
    amount: Decimal | None = Field(default=None, description="Override amount (default: full)")
    currency: str | None = Field(default=None, description="Target currency (default: merchant pref)")
    rail: str | None = Field(default=None, description="Payout rail (default: merchant pref)")
    idempotency_key: str = Field(..., description="Client-provided idempotency key")
    stream_id: str | None = Field(default=None, description="Active stream ID — routes attestation into the stream's SBN slot")


class PayoutResponse(BaseModel):
    tx_id: str
    payout_status: str
    provider_ref: str | None = None
    receipt_hash: str | None = None


@router.post("/payouts", response_model=PayoutResponse)
async def execute_payout(
    body: PayoutRequest,
    request: Request,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
    emitter: Any = Depends(get_emitter),
    attester: Any = Depends(get_attester),
    payout_executor: Any = Depends(get_payout_executor),
    treasury: Any = Depends(get_treasury),
    idempotency_store: Any = Depends(get_idempotency),
):
    """Execute an outbound payout for a cleared transaction.

    The transaction must be in RECEIVABLE_CLEARED or NORMALIZED state.
    """
    # Idempotency check
    if idempotency_store is not None:
        cached = await idempotency_store.check(body.idempotency_key)
        if cached is not None:
            return PayoutResponse(**cached)

    # Load transaction
    result = await db.execute(
        select(TransactionRecord).where(
            TransactionRecord.id == body.tx_id,
            TransactionRecord.merchant_id == merchant.id,
        )
    )
    record = result.scalar_one_or_none()
    if record is None:
        raise HTTPException(status_code=404, detail="Transaction not found")

    # Validate state — must be NORMALIZED (normalization populates treasury fields)
    if record.state != TxState.NORMALIZED.value:
        detail = f"Transaction in state '{record.state}' — must be normalized for payout"
        if record.state == TxState.RECEIVABLE_CLEARED.value:
            detail += " (trigger normalization first, or ensure auto_normalize is enabled)"
        raise HTTPException(status_code=409, detail=detail)

    # Resolve stream → SBN slot early so receipts skip the coupler
    sbn_slot_id: str | None = None
    if body.stream_id:
        from sonic.models.stream_session import StreamSession

        stream_result = await db.execute(
            select(StreamSession).where(
                StreamSession.id == body.stream_id,
                StreamSession.merchant_id == merchant.id,
                StreamSession.status == "open",
            )
        )
        stream = stream_result.scalar_one_or_none()
        if stream and stream.sbn_slot_id:
            sbn_slot_id = stream.sbn_slot_id

    # Resolve payout parameters
    payout_amount = body.amount or record.treasury_amount or record.inbound_amount
    payout_currency = (body.currency or merchant.default_payout_currency).upper()
    payout_rail = body.rail or merchant.default_payout_rail

    # Treasury conversion if target currency differs from base asset
    if treasury.needs_conversion(payout_currency):
        source_amount = record.treasury_amount or record.inbound_amount
        quote = treasury.quote_outbound(source_amount, payout_currency, rate=Decimal("1"))
        payout_amount = quote.net_amount

    # Rebuild in-memory transaction from persisted state
    tx = Transaction(
        tx_id=record.id,
        merchant_id=merchant.id,
        state=TxState(record.state),
        inbound_amount=record.inbound_amount,
        inbound_currency=record.inbound_currency,
        inbound_rail=record.inbound_rail,
        sequence=record.sequence,
    )

    # Advance: CLEARED/NORMALIZED -> PAYOUT_PENDING
    event_pending = tx.advance(
        TxState.PAYOUT_PENDING,
        amount=payout_amount,
        currency=payout_currency,
        rail=payout_rail,
        idempotency_key=body.idempotency_key,
    )

    record.state = TxState.PAYOUT_PENDING.value
    record.outbound_amount = payout_amount
    record.outbound_currency = payout_currency
    record.outbound_rail = payout_rail
    record.sequence = tx.sequence

    # Load previous receipt hash for chain continuity
    prev_receipt_result = await db.execute(
        select(ReceiptRecord.receipt_hash)
        .where(ReceiptRecord.tx_id == record.id)
        .order_by(ReceiptRecord.sequence.desc())
        .limit(1)
    )
    prev_hash = prev_receipt_result.scalar_one_or_none()

    chain = ReceiptChain()
    chain._last_hash = prev_hash
    receipt_pending = chain.build(event_pending, merchant_id=merchant.id, direction="outbound")

    db.add(ReceiptRecord(
        receipt_id=receipt_pending.receipt_id,
        tx_id=record.id,
        event_type=receipt_pending.event_type,
        sequence=receipt_pending.sequence,
        amount=receipt_pending.amount,
        currency=receipt_pending.currency,
        rail=receipt_pending.rail,
        direction=receipt_pending.direction,
        receipt_hash=receipt_pending.receipt_hash,
        prev_receipt_hash=receipt_pending.prev_receipt_hash,
        idempotency_key=receipt_pending.idempotency_key,
        merchant_id=merchant.id,
        couple_status="stream_coupled" if sbn_slot_id else "pending",
        sbn_slot_id=sbn_slot_id,
    ))

    db.add(EventLog(
        tx_id=record.id,
        event_type=EventType.PAYOUT_PENDING.value,
        from_state=event_pending.from_state.value,
        to_state=TxState.PAYOUT_PENDING.value,
        merchant_id=merchant.id,
        provider=payout_rail.split("_")[0],
        idempotency_key=body.idempotency_key,
        receipt_hash=receipt_pending.receipt_hash,
        payload={
            "amount": str(payout_amount),
            "currency": payout_currency,
            "rail": payout_rail,
            "recipient_id": body.recipient_id,
        },
    ))

    await db.flush()

    # -- Float guard gate (optional, same pattern as stream_worker) --
    float_guard = getattr(request.app.state, "float_guard", None)
    float_committed = False
    if float_guard is not None:
        from sonic._vendor.dominion.core.float_guard import FloatStatus

        check = await float_guard.check(float(payout_amount))
        if check.status == FloatStatus.BLOCKED:
            raise HTTPException(
                status_code=503,
                detail=(
                    f"Float guard blocked payout: "
                    f"available={check.available}, requested={float(payout_amount)}"
                ),
            )
        float_guard.commit(float(payout_amount))
        float_committed = True

    # Dispatch payout to provider
    instruction = PayoutInstruction(
        tx_id=record.id,
        recipient_id=body.recipient_id,
        amount=payout_amount,
        currency=payout_currency,
        rail=payout_rail,
        idempotency_key=body.idempotency_key,
    )

    payout_result = await payout_executor.execute(instruction)

    if payout_result.success:
        # Advance: PAYOUT_PENDING -> PAYOUT_EXECUTED
        event_executed = tx.advance(
            TxState.PAYOUT_EXECUTED,
            amount=payout_amount,
            currency=payout_currency,
            rail=payout_rail,
            provider_ref=payout_result.provider_ref,
            idempotency_key=body.idempotency_key,
        )

        record.state = TxState.PAYOUT_EXECUTED.value
        record.outbound_provider_ref = payout_result.provider_ref
        record.sequence = tx.sequence

        receipt_executed = chain.build(event_executed, merchant_id=merchant.id, direction="outbound")

        db.add(ReceiptRecord(
            receipt_id=receipt_executed.receipt_id,
            tx_id=record.id,
            event_type=receipt_executed.event_type,
            sequence=receipt_executed.sequence,
            amount=receipt_executed.amount,
            currency=receipt_executed.currency,
            rail=receipt_executed.rail,
            direction=receipt_executed.direction,
            receipt_hash=receipt_executed.receipt_hash,
            prev_receipt_hash=receipt_executed.prev_receipt_hash,
            idempotency_key=receipt_executed.idempotency_key,
            merchant_id=merchant.id,
            couple_status="stream_coupled" if sbn_slot_id else "pending",
            sbn_slot_id=sbn_slot_id,
        ))

        db.add(EventLog(
            tx_id=record.id,
            event_type=EventType.PAYOUT_EXECUTED.value,
            from_state=TxState.PAYOUT_PENDING.value,
            to_state=TxState.PAYOUT_EXECUTED.value,
            merchant_id=merchant.id,
            provider=payout_rail.split("_")[0],
            provider_ref=payout_result.provider_ref,
            idempotency_key=body.idempotency_key,
            receipt_hash=receipt_executed.receipt_hash,
        ))

        final_receipt = receipt_executed
        final_status = TxState.PAYOUT_EXECUTED.value
        event_type = EventType.PAYOUT_EXECUTED
    else:
        # Release float on failure
        if float_committed and float_guard is not None:
            float_guard.release(float(payout_amount))
            float_committed = False

        # Payout failed
        event_failed = tx.advance(
            TxState.FAILED,
            amount=payout_amount,
            currency=payout_currency,
            rail=payout_rail,
            idempotency_key=body.idempotency_key,
            metadata={"error": payout_result.error},
        )

        record.state = TxState.FAILED.value
        record.sequence = tx.sequence

        receipt_failed = chain.build(event_failed, merchant_id=merchant.id, direction="outbound")

        db.add(ReceiptRecord(
            receipt_id=receipt_failed.receipt_id,
            tx_id=record.id,
            event_type=receipt_failed.event_type,
            sequence=receipt_failed.sequence,
            amount=receipt_failed.amount,
            currency=receipt_failed.currency,
            rail=receipt_failed.rail,
            direction=receipt_failed.direction,
            receipt_hash=receipt_failed.receipt_hash,
            prev_receipt_hash=receipt_failed.prev_receipt_hash,
            idempotency_key=receipt_failed.idempotency_key,
            merchant_id=merchant.id,
            couple_status="stream_coupled" if sbn_slot_id else "pending",
            sbn_slot_id=sbn_slot_id,
        ))

        db.add(EventLog(
            tx_id=record.id,
            event_type=EventType.PAYOUT_FAILED.value,
            from_state=TxState.PAYOUT_PENDING.value,
            to_state=TxState.FAILED.value,
            merchant_id=merchant.id,
            provider=payout_rail.split("_")[0],
            idempotency_key=body.idempotency_key,
            receipt_hash=receipt_failed.receipt_hash,
            payload={"error": payout_result.error},
        ))

        final_receipt = receipt_failed
        final_status = TxState.FAILED.value
        event_type = EventType.PAYOUT_FAILED

    await db.commit()

    PAYOUT_TOTAL.labels(
        rail=payout_rail,
        status="success" if payout_result.success else "failed",
    ).inc()
    log.info(
        "Payout %s: tx=%s provider_ref=%s",
        final_status, record.id, payout_result.provider_ref,
    )

    # Increment stream block counter after main commit
    if body.stream_id and sbn_slot_id:
        from sonic.models.stream_session import StreamSession

        stream_result = await db.execute(
            select(StreamSession).where(StreamSession.id == body.stream_id)
        )
        stream = stream_result.scalar_one_or_none()
        if stream:
            stream.blocks_attested += 1
            await db.commit()

    # Enqueue SBN attestation (with slot_id if stream is active)
    if attester is not None:
        try:
            await attester.enqueue(final_receipt, slot_id=sbn_slot_id)
        except Exception:
            log.warning("SBN attestation enqueue failed for receipt %s", final_receipt.receipt_id, exc_info=True)

    # Emit event
    try:
        await emitter.emit(event_type, {
            "tx_id": record.id,
            "merchant_id": merchant.id,
            "amount": str(payout_amount),
            "currency": payout_currency,
            "rail": payout_rail,
            "provider_ref": payout_result.provider_ref,
            "receipt_hash": final_receipt.receipt_hash,
        })
    except Exception:
        log.warning("Event emission failed for tx %s", record.id, exc_info=True)

    response_data = {
        "tx_id": record.id,
        "payout_status": final_status,
        "provider_ref": payout_result.provider_ref,
        "receipt_hash": final_receipt.receipt_hash,
    }

    # Cache for idempotency
    if idempotency_store is not None:
        try:
            await idempotency_store.store(body.idempotency_key, response_data)
        except Exception:
            log.warning("Idempotency store failed for key %s", body.idempotency_key, exc_info=True)

    return PayoutResponse(**response_data)
