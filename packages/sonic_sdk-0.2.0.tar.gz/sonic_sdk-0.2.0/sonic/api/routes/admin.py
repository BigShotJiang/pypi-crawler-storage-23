"""Admin-only endpoints — system stats, merchant listing, receipt stats, audit export."""

from __future__ import annotations

import csv
import io
from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import get_db, get_read_db
from sonic.api.routes.auth import get_current_user
from sonic.models.event_log import EventLog
from sonic.models.merchant import Merchant
from sonic.models.pay_stream import PayStream
from sonic.models.receipt import ReceiptRecord
from sonic.models.stream_window import StreamWindow
from sonic.models.transaction import TransactionRecord
from sonic.models.user import DashboardUser

router = APIRouter()


# --- Admin guard ---


async def require_admin(user: DashboardUser = Depends(get_current_user)) -> DashboardUser:
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


# --- Response schemas ---


class AdminStatsResponse(BaseModel):
    total_merchants: int
    total_transactions: int
    volume_24h: str
    active_providers: int


class AdminMerchantResponse(BaseModel):
    merchant_id: str
    name: str
    email: str
    status: str
    business_type: str
    tx_count: int
    volume: str
    anchor_chain: str | None
    created_at: str


class AdminMerchantListResponse(BaseModel):
    merchants: list[AdminMerchantResponse]
    total: int


class ReceiptStatsResponse(BaseModel):
    tier1_total: int
    tier1_verified: int
    tier2_total: int
    tier2_verified: int
    tier3_total: int
    tier3_verified: int


# --- Endpoints ---


@router.get("/admin/stats", response_model=AdminStatsResponse)
async def get_admin_stats(
    _admin: DashboardUser = Depends(require_admin),
    db: AsyncSession = Depends(get_read_db),
):
    """Aggregate system stats for the admin dashboard."""
    # Merchant count (exclude soft-deleted)
    m_result = await db.execute(
        select(func.count()).select_from(Merchant).where(Merchant.deleted_at.is_(None))
    )
    total_merchants = m_result.scalar_one()

    # Transaction count (exclude archived)
    tx_result = await db.execute(
        select(func.count()).select_from(TransactionRecord).where(TransactionRecord.archived_at.is_(None))
    )
    total_transactions = tx_result.scalar_one()

    # 24h volume (exclude archived)
    from datetime import datetime, timezone, timedelta
    cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
    vol_result = await db.execute(
        select(func.coalesce(func.sum(TransactionRecord.inbound_amount), 0))
        .where(TransactionRecord.created_at >= cutoff, TransactionRecord.archived_at.is_(None))
    )
    volume_24h = vol_result.scalar_one()

    return AdminStatsResponse(
        total_merchants=total_merchants,
        total_transactions=total_transactions,
        volume_24h=f"${float(volume_24h):,.2f}",
        active_providers=3,  # Derive from app.state in production
    )


@router.get("/admin/merchants", response_model=AdminMerchantListResponse)
async def list_all_merchants(
    _admin: DashboardUser = Depends(require_admin),
    db: AsyncSession = Depends(get_read_db),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
):
    """List all merchants with their transaction stats (excludes soft-deleted)."""
    from sqlalchemy.orm import aliased

    # Total count
    count_result = await db.execute(
        select(func.count()).select_from(Merchant).where(Merchant.deleted_at.is_(None))
    )
    total = count_result.scalar_one()

    # Aggregate tx stats per merchant in a single query (no N+1)
    tx_stats = (
        select(
            TransactionRecord.merchant_id,
            func.count().label("tx_count"),
            func.coalesce(func.sum(TransactionRecord.inbound_amount), 0).label("volume"),
        )
        .group_by(TransactionRecord.merchant_id)
        .subquery()
    )

    result = await db.execute(
        select(
            Merchant,
            func.coalesce(tx_stats.c.tx_count, 0).label("tx_count"),
            func.coalesce(tx_stats.c.volume, 0).label("volume"),
        )
        .outerjoin(tx_stats, Merchant.id == tx_stats.c.merchant_id)
        .where(Merchant.deleted_at.is_(None))
        .order_by(Merchant.created_at.desc())
        .offset(offset)
        .limit(limit)
    )
    rows = result.all()

    items = []
    for m, tx_count, volume in rows:
        items.append(AdminMerchantResponse(
            merchant_id=m.id,
            name=m.name,
            email=m.email,
            status=m.status,
            business_type=m.business_type,
            tx_count=tx_count,
            volume=f"${float(volume):,.2f}",
            anchor_chain=m.anchor_chain,
            created_at=m.created_at.isoformat(),
        ))

    return AdminMerchantListResponse(merchants=items, total=total)


@router.get("/admin/receipt-stats", response_model=ReceiptStatsResponse)
async def get_receipt_stats(
    _admin: DashboardUser = Depends(require_admin),
    db: AsyncSession = Depends(get_read_db),
):
    """Receipt chain statistics across all three tiers."""
    # Tier 1: all receipts (app chain hash always populated)
    t1_result = await db.execute(select(func.count()).select_from(ReceiptRecord))
    tier1_total = t1_result.scalar_one()

    # Tier 2: receipts with combined_hash (SBN fused)
    t2_result = await db.execute(
        select(func.count()).select_from(ReceiptRecord)
        .where(ReceiptRecord.combined_hash.isnot(None))
    )
    tier2_total = t2_result.scalar_one()

    # Tier 3: receipts with anchor_tx_id (blockchain anchored)
    t3_result = await db.execute(
        select(func.count()).select_from(ReceiptRecord)
        .where(ReceiptRecord.anchor_tx_id.isnot(None))
    )
    tier3_total = t3_result.scalar_one()

    return ReceiptStatsResponse(
        tier1_total=tier1_total,
        tier1_verified=tier1_total,  # App chain is always verified if hash exists
        tier2_total=tier2_total,
        tier2_verified=tier2_total,
        tier3_total=tier3_total,
        tier3_verified=tier3_total,
    )


# --- Audit export ---


class AuditEventResponse(BaseModel):
    id: str
    tx_id: str
    event_type: str
    from_state: str | None
    to_state: str | None
    merchant_id: str
    provider: str | None
    provider_ref: str | None
    idempotency_key: str | None
    receipt_hash: str | None
    timestamp: str


class AuditExportResponse(BaseModel):
    events: list[AuditEventResponse]
    total: int
    has_more: bool


_AUDIT_EXPORT_LIMIT = 1000  # Max rows per request


@router.get("/admin/audit", response_model=AuditExportResponse)
async def export_audit_log(
    _admin: DashboardUser = Depends(require_admin),
    db: AsyncSession = Depends(get_read_db),
    start: Optional[str] = Query(default=None, description="ISO-8601 start datetime"),
    end: Optional[str] = Query(default=None, description="ISO-8601 end datetime"),
    merchant_id: Optional[str] = Query(default=None, description="Filter by merchant"),
    event_type: Optional[str] = Query(default=None, description="Filter by event type"),
    limit: int = Query(default=200, ge=1, le=_AUDIT_EXPORT_LIMIT),
    offset: int = Query(default=0, ge=0),
):
    """Export audit log events (JSON). Admin-only, paginated."""
    query = select(EventLog).order_by(EventLog.timestamp.desc())

    if start:
        query = query.where(EventLog.timestamp >= datetime.fromisoformat(start))
    if end:
        query = query.where(EventLog.timestamp <= datetime.fromisoformat(end))
    if merchant_id:
        query = query.where(EventLog.merchant_id == merchant_id)
    if event_type:
        query = query.where(EventLog.event_type == event_type)

    # Total count (same filters, no pagination)
    count_query = select(func.count()).select_from(query.subquery())
    total = (await db.execute(count_query)).scalar_one()

    # Paginate
    result = await db.execute(query.offset(offset).limit(limit))
    rows = result.scalars().all()

    events = [
        AuditEventResponse(
            id=e.id,
            tx_id=e.tx_id,
            event_type=e.event_type,
            from_state=e.from_state,
            to_state=e.to_state,
            merchant_id=e.merchant_id,
            provider=e.provider,
            provider_ref=e.provider_ref,
            idempotency_key=e.idempotency_key,
            receipt_hash=e.receipt_hash,
            timestamp=e.timestamp.isoformat(),
        )
        for e in rows
    ]

    return AuditExportResponse(events=events, total=total, has_more=(offset + limit) < total)


@router.get("/admin/audit/csv", include_in_schema=False)
async def export_audit_csv(
    _admin: DashboardUser = Depends(require_admin),
    db: AsyncSession = Depends(get_read_db),
    start: Optional[str] = Query(default=None),
    end: Optional[str] = Query(default=None),
    merchant_id: Optional[str] = Query(default=None),
    event_type: Optional[str] = Query(default=None),
    limit: int = Query(default=_AUDIT_EXPORT_LIMIT, ge=1, le=10000),
):
    """Export audit log as CSV download. Admin-only."""
    query = select(EventLog).order_by(EventLog.timestamp.desc())

    if start:
        query = query.where(EventLog.timestamp >= datetime.fromisoformat(start))
    if end:
        query = query.where(EventLog.timestamp <= datetime.fromisoformat(end))
    if merchant_id:
        query = query.where(EventLog.merchant_id == merchant_id)
    if event_type:
        query = query.where(EventLog.event_type == event_type)

    result = await db.execute(query.limit(limit))
    rows = result.scalars().all()

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow([
        "id", "tx_id", "event_type", "from_state", "to_state",
        "merchant_id", "provider", "provider_ref", "idempotency_key",
        "receipt_hash", "timestamp",
    ])
    for e in rows:
        writer.writerow([
            e.id, e.tx_id, e.event_type, e.from_state or "", e.to_state or "",
            e.merchant_id, e.provider or "", e.provider_ref or "",
            e.idempotency_key or "", e.receipt_hash or "", e.timestamp.isoformat(),
        ])

    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=sonic-audit-export.csv"},
    )


# --- Stream health ---


class StreamHealthSummary(BaseModel):
    total_streams: int
    active: int
    paused: int
    frozen: int
    closed: int
    total_earned: str
    total_disbursed: str
    total_held: str
    open_windows: int
    failed_payout_windows: int
    avg_g_ewma: str


class StreamHealthEntry(BaseModel):
    pay_stream_id: str
    merchant_id: str
    payee_id: str
    status: str
    policy_state: str
    g_ewma: str
    total_earned: str
    total_disbursed: str
    total_held: str
    window_count: int
    open_window_age_seconds: int | None = None


class StreamHealthResponse(BaseModel):
    summary: StreamHealthSummary
    flagged: list[StreamHealthEntry]


@router.get("/admin/streams/health", response_model=StreamHealthResponse)
async def get_stream_health(
    _admin: DashboardUser = Depends(require_admin),
    db: AsyncSession = Depends(get_read_db),
):
    """Stream health dashboard: aggregate metrics and flagged streams.

    Flagged streams are those in frozen state or with failed (un-retried)
    payout windows.
    """
    from datetime import timedelta

    # Aggregate counts by status
    status_result = await db.execute(
        select(PayStream.status, func.count())
        .group_by(PayStream.status)
    )
    status_counts = {row[0]: row[1] for row in status_result.all()}

    total_streams = sum(status_counts.values())
    active = status_counts.get("active", 0)
    paused = status_counts.get("paused", 0)
    frozen = status_counts.get("frozen", 0)
    closed = status_counts.get("closed", 0)

    # Aggregate financials
    fin_result = await db.execute(
        select(
            func.coalesce(func.sum(PayStream.total_earned), 0),
            func.coalesce(func.sum(PayStream.total_disbursed), 0),
            func.coalesce(func.sum(PayStream.total_held), 0),
        )
    )
    fin_row = fin_result.one()

    # Average g_ewma for non-closed streams
    ewma_result = await db.execute(
        select(func.coalesce(func.avg(PayStream.g_ewma), 0))
        .where(PayStream.status != "closed")
    )
    avg_ewma = ewma_result.scalar_one()

    # Open windows count
    open_win_result = await db.execute(
        select(func.count())
        .select_from(StreamWindow)
        .where(StreamWindow.status == "open")
    )
    open_windows = open_win_result.scalar_one()

    # Failed payout windows (earned > 0, disbursed == 0, no payout_tx_id, closed)
    failed_win_result = await db.execute(
        select(func.count())
        .select_from(StreamWindow)
        .where(
            StreamWindow.status == "closed",
            StreamWindow.earned_amount > 0,
            StreamWindow.disbursed_amount == 0,
            StreamWindow.payout_tx_id.is_(None),
        )
    )
    failed_payout_windows = failed_win_result.scalar_one()

    summary = StreamHealthSummary(
        total_streams=total_streams,
        active=active,
        paused=paused,
        frozen=frozen,
        closed=closed,
        total_earned=f"{float(fin_row[0]):,.6f}",
        total_disbursed=f"{float(fin_row[1]):,.6f}",
        total_held=f"{float(fin_row[2]):,.6f}",
        open_windows=open_windows,
        failed_payout_windows=failed_payout_windows,
        avg_g_ewma=f"{float(avg_ewma):.6f}",
    )

    # Flagged streams: frozen OR streams with failed payout windows
    now = datetime.now(timezone.utc)

    # Frozen streams
    frozen_result = await db.execute(
        select(PayStream).where(PayStream.status == "frozen").limit(50)
    )
    frozen_streams = frozen_result.scalars().all()

    # Streams with failed payout windows (not frozen, not closed — these are active with issues)
    failed_stream_ids_result = await db.execute(
        select(StreamWindow.pay_stream_id)
        .where(
            StreamWindow.status == "closed",
            StreamWindow.earned_amount > 0,
            StreamWindow.disbursed_amount == 0,
            StreamWindow.payout_tx_id.is_(None),
        )
        .distinct()
        .limit(50)
    )
    failed_stream_ids = [r[0] for r in failed_stream_ids_result.all()]
    # Exclude already-frozen ones
    already_flagged = {s.id for s in frozen_streams}
    extra_ids = [sid for sid in failed_stream_ids if sid not in already_flagged]

    extra_streams = []
    if extra_ids:
        extra_result = await db.execute(
            select(PayStream).where(PayStream.id.in_(extra_ids))
        )
        extra_streams = extra_result.scalars().all()

    flagged = []
    for s in list(frozen_streams) + extra_streams:
        # Check for open window age
        open_win_age = None
        ow_result = await db.execute(
            select(StreamWindow.window_start)
            .where(
                StreamWindow.pay_stream_id == s.id,
                StreamWindow.status == "open",
            )
            .order_by(StreamWindow.window_number.desc())
            .limit(1)
        )
        ow_start = ow_result.scalar_one_or_none()
        if ow_start:
            open_win_age = int((now - ow_start).total_seconds())

        flagged.append(StreamHealthEntry(
            pay_stream_id=s.id,
            merchant_id=s.merchant_id,
            payee_id=s.payee_id,
            status=s.status,
            policy_state=s.policy_state,
            g_ewma=str(s.g_ewma),
            total_earned=str(s.total_earned),
            total_disbursed=str(s.total_disbursed),
            total_held=str(s.total_held),
            window_count=s.window_count,
            open_window_age_seconds=open_win_age,
        ))

    return StreamHealthResponse(summary=summary, flagged=flagged)
