"""Stream endpoints — SBN slot-backed streaming sessions.

A stream maps 1:1 to an SBN SmartSlot. Dominion (or any client) opens
a stream before sending micro-payments, then closes it when done.
All payout receipts created while the stream is open are attested into
the same SBN slot, producing a single Merkle root on close.

Endpoints:
  POST /v1/streams          — open a stream (opens an SBN slot)
  POST /v1/streams/{id}/close — close the stream (closes the SBN slot)
  GET  /v1/streams/{id}     — inspect stream state
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import get_db, get_merchant, get_sbn
from sonic.models.merchant import Merchant
from sonic.models.stream_session import StreamSession

log = logging.getLogger("sonic.streams")

router = APIRouter()


# -- Request / Response schemas ------------------------------------------------


class OpenStreamRequest(BaseModel):
    worker_id: str = Field(..., description="Worker/agent ID (forwarded to SBN slot)")
    total_amount: Decimal = Field(..., gt=0, description="Total stream amount")
    currency: str = Field(default="USD", max_length=4)
    interval_seconds: int = Field(default=60, ge=1, description="Seconds between micro-payments")
    duration_seconds: int = Field(default=3600, ge=1, description="Total streaming window")
    metadata: dict[str, Any] | None = Field(default=None)


class OpenStreamResponse(BaseModel):
    stream_id: str
    sbn_slot_id: str | None = None
    status: str
    worker_id: str
    total_amount: str
    currency: str
    interval_seconds: int
    duration_seconds: int
    created_at: str


class CloseStreamResponse(BaseModel):
    stream_id: str
    sbn_slot_id: str | None = None
    status: str
    merkle_root: str | None = None
    blocks_attested: int
    closed_at: str | None = None


class StreamDetailResponse(BaseModel):
    stream_id: str
    sbn_slot_id: str | None = None
    status: str
    worker_id: str
    total_amount: str
    currency: str
    interval_seconds: int
    duration_seconds: int
    merkle_root: str | None = None
    blocks_attested: int
    created_at: str
    closed_at: str | None = None


# -- Routes --------------------------------------------------------------------


@router.post("/streams", response_model=OpenStreamResponse, status_code=201)
async def open_stream(
    body: OpenStreamRequest,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
    sbn: Any = Depends(get_sbn),
):
    """Open a streaming session backed by an SBN SmartSlot.

    The returned ``stream_id`` should be passed on subsequent payout
    requests (via the ``stream_id`` field) so their receipts attest
    into the same slot.
    """
    # Open SBN slot with generation_interval matching the stream cadence
    sbn_slot_id: str | None = None
    if sbn.active:
        slot_result = sbn.open_slot(
            worker_id=body.worker_id,
            task_type="sonic.settlement",
            generation_interval=body.interval_seconds,
            metadata={
                "stream": True,
                "merchant_id": merchant.id,
                "total_amount": str(body.total_amount),
                "currency": body.currency,
            },
        )
        if slot_result:
            sbn_slot_id = slot_result.get("slot_id") or slot_result.get("id")
            log.info("SBN slot opened for stream: slot=%s worker=%s", sbn_slot_id, body.worker_id)

    session = StreamSession(
        merchant_id=merchant.id,
        sbn_slot_id=sbn_slot_id,
        worker_id=body.worker_id,
        total_amount=body.total_amount,
        currency=body.currency,
        interval_seconds=body.interval_seconds,
        duration_seconds=body.duration_seconds,
        status="open",
        metadata_json=json.dumps(body.metadata) if body.metadata else None,
    )
    db.add(session)
    await db.commit()
    await db.refresh(session)

    log.info("Stream opened: id=%s slot=%s merchant=%s", session.id, sbn_slot_id, merchant.id)

    return OpenStreamResponse(
        stream_id=session.id,
        sbn_slot_id=session.sbn_slot_id,
        status=session.status,
        worker_id=session.worker_id,
        total_amount=str(session.total_amount),
        currency=session.currency,
        interval_seconds=session.interval_seconds,
        duration_seconds=session.duration_seconds,
        created_at=session.created_at.isoformat(),
    )


@router.post("/streams/{stream_id}/close", response_model=CloseStreamResponse)
async def close_stream(
    stream_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
    sbn: Any = Depends(get_sbn),
):
    """Close a streaming session and its underlying SBN slot.

    Returns the Merkle root computed over all blocks attested during
    the stream's lifetime.
    """
    result = await db.execute(
        select(StreamSession).where(
            StreamSession.id == stream_id,
            StreamSession.merchant_id == merchant.id,
        )
    )
    session = result.scalar_one_or_none()
    if session is None:
        raise HTTPException(status_code=404, detail="Stream not found")

    if session.status != "open":
        raise HTTPException(
            status_code=409,
            detail=f"Stream already in state '{session.status}' — only open streams can be closed",
        )

    # Close SBN slot → Merkle root
    merkle_root: str | None = None
    if sbn.active and session.sbn_slot_id:
        close_result = sbn.close_slot(session.sbn_slot_id)
        if close_result:
            merkle_root = close_result.get("merkle_root") or close_result.get("root_hash")
            log.info("SBN slot closed: slot=%s merkle=%s", session.sbn_slot_id, merkle_root)

    now = datetime.now(timezone.utc)
    session.status = "closed"
    session.merkle_root = merkle_root
    session.closed_at = now
    await db.commit()

    log.info("Stream closed: id=%s merkle=%s blocks=%d", session.id, merkle_root, session.blocks_attested)

    return CloseStreamResponse(
        stream_id=session.id,
        sbn_slot_id=session.sbn_slot_id,
        status=session.status,
        merkle_root=session.merkle_root,
        blocks_attested=session.blocks_attested,
        closed_at=session.closed_at.isoformat() if session.closed_at else None,
    )


@router.get("/streams/{stream_id}", response_model=StreamDetailResponse)
async def get_stream(
    stream_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
):
    """Inspect a streaming session."""
    result = await db.execute(
        select(StreamSession).where(
            StreamSession.id == stream_id,
            StreamSession.merchant_id == merchant.id,
        )
    )
    session = result.scalar_one_or_none()
    if session is None:
        raise HTTPException(status_code=404, detail="Stream not found")

    return StreamDetailResponse(
        stream_id=session.id,
        sbn_slot_id=session.sbn_slot_id,
        status=session.status,
        worker_id=session.worker_id,
        total_amount=str(session.total_amount),
        currency=session.currency,
        interval_seconds=session.interval_seconds,
        duration_seconds=session.duration_seconds,
        merkle_root=session.merkle_root,
        blocks_attested=session.blocks_attested,
        created_at=session.created_at.isoformat(),
        closed_at=session.closed_at.isoformat() if session.closed_at else None,
    )
