"""Tower Agent dashboard routes — snapshot, section refresh, actions, events.

Mirrors the Stillpoint pattern:
  GET  /dashboard/snapshot          — full initial render
  GET  /dashboard/section/{key}     — single widget refresh
  GET  /actions                     — list available actions with regime gating
  POST /actions/execute             — execute an action
  POST /suggestions/dismiss         — dismiss a suggestion
  WS   /events/stream               — real-time WebSocket events
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, Request, WebSocket, WebSocketDisconnect
from pydantic import BaseModel

from sonic.config import settings
from sonic.tower_agent import (
    ActionRequest,
    DataKey,
    DashboardEvent,
    DashboardSnapshot,
    EventKind,
    EventPriority,
    METALLIC_LABELS,
    SONIC_ACTIONS,
    make_event,
    regime_headline,
)
from sonic.tower_agent.handlers import execute_action
from sonic.tower_agent.providers import build_section_data, provide_float_status, provide_section

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/tower")


# ---------------------------------------------------------------------------
# Dependency helpers — pull services from app.state
# ---------------------------------------------------------------------------

def _get_db(request: Request):
    """Yield a sync database session from the app's session factory."""
    session_factory = getattr(request.app.state, "session_factory", None)
    if session_factory is None:
        return None
    db = session_factory()
    try:
        yield db
    finally:
        db.close()


def _app_state(request: Request) -> dict[str, Any]:
    """Pull live service references from app.state."""
    state = request.app.state
    return {
        "db": getattr(state, "_sync_session", None),
        "float_guard": getattr(state, "float_guard", None),
        "sbn_client": getattr(state, "sbn", None),
        "redis_client": getattr(state, "redis", None),
        "providers": getattr(state, "providers", None),
        "settings": settings,
    }


# ---------------------------------------------------------------------------
# GET /dashboard/snapshot — full initial render
# ---------------------------------------------------------------------------


@router.get("/dashboard/snapshot")
async def get_dashboard_snapshot(request: Request) -> dict[str, Any]:
    """Return the complete dashboard snapshot for initial render."""
    ctx = _app_state(request)

    section_data = await build_section_data(
        db=ctx["db"],
        float_guard=ctx["float_guard"],
        sbn_client=ctx["sbn_client"],
        redis_client=ctx["redis_client"],
        providers=ctx["providers"],
        settings=ctx["settings"],
    )

    suggestions_data = section_data.get(DataKey.SUGGESTIONS.value, {})
    suggestions = suggestions_data.get("items", [])
    has_escalations = suggestions_data.get("has_escalations", False)

    # Derive health_score from settlement_health status
    settlement = section_data.get(DataKey.SETTLEMENT_HEALTH.value, {})
    degraded = settlement.get("degraded_components", [])
    components = settlement.get("components", {})
    total = max(len(components), 1)
    healthy_count = total - len(degraded)
    health_score = round(healthy_count / total, 4)

    # Regime — defaults to "silver" (stable) until NUMA is connected
    regime = "silver"

    ds = DashboardSnapshot(
        product_id="sonic",
        regime=regime,
        regime_label=METALLIC_LABELS.get(regime, "Unknown"),
        headline=regime_headline(regime, health_score),
        health_score=health_score,
        section_data=section_data,
        suggestions=suggestions,
        suggestion_count=len(suggestions),
        escalation_required=has_escalations,
    )

    return ds.to_dict()


# ---------------------------------------------------------------------------
# GET /dashboard/section/{data_key} — single widget refresh
# ---------------------------------------------------------------------------


@router.get("/dashboard/section/{data_key}")
async def get_dashboard_section(
    data_key: str,
    request: Request,
) -> dict[str, Any]:
    """Return data for a single dashboard widget."""
    valid_keys = {k.value for k in DataKey}
    if data_key not in valid_keys:
        return {"error": f"Unknown data_key: {data_key}", "valid_keys": sorted(valid_keys)}

    ctx = _app_state(request)

    # float_status is async — handle separately
    if data_key == DataKey.FLOAT_STATUS.value:
        data = await provide_float_status(ctx["float_guard"])
    else:
        data = provide_section(
            data_key,
            db=ctx["db"],
            float_guard=ctx["float_guard"],
            sbn_client=ctx["sbn_client"],
            redis_client=ctx["redis_client"],
            providers=ctx["providers"],
            settings=ctx["settings"],
        )

    if data is None:
        return {"error": f"No provider for data_key: {data_key}"}

    return {
        "data_key": data_key,
        "data": data,
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }


# ---------------------------------------------------------------------------
# GET /actions — list available actions with regime gating
# ---------------------------------------------------------------------------


class ActionListItem(BaseModel):
    action_id: str
    label: str
    description: str
    disposition: str
    requires_confirmation: bool
    available: bool
    blocked_reason: str | None = None


@router.get("/actions")
def list_actions() -> dict[str, Any]:
    """List all available actions with regime-gated availability."""
    current_regime = "silver"  # Default until NUMA connected

    actions: list[dict[str, Any]] = []
    for action_id, action_def in SONIC_ACTIONS.items():
        blocked = current_regime in action_def.blocked_in_regimes
        available_check = (
            action_def.available_in_regimes == ["*"]
            or current_regime in action_def.available_in_regimes
        )

        blocked_reason = None
        if blocked:
            blocked_reason = f"Blocked in {current_regime} regime"
        elif not available_check:
            blocked_reason = f"Not available in {current_regime} regime"

        actions.append(
            ActionListItem(
                action_id=action_def.action_id,
                label=action_def.label,
                description=action_def.description,
                disposition=action_def.disposition.value,
                requires_confirmation=action_def.requires_confirmation,
                available=available_check and not blocked,
                blocked_reason=blocked_reason,
            ).model_dump()
        )

    return {
        "regime": current_regime,
        "actions": actions,
    }


# ---------------------------------------------------------------------------
# POST /actions/execute — execute an action
# ---------------------------------------------------------------------------


class ActionExecuteRequest(BaseModel):
    action: str
    params: dict[str, Any] = {}
    confirmed: bool = False


@router.post("/actions/execute")
async def execute_dashboard_action(
    body: ActionExecuteRequest,
    request: Request,
) -> dict[str, Any]:
    """Execute an operator action and broadcast result to WebSocket subscribers."""
    ctx = _app_state(request)

    action_req = ActionRequest(
        action=body.action,
        params=body.params,
        confirmed=body.confirmed,
    )

    result = execute_action(
        action_req,
        db=ctx["db"],
        float_guard=ctx["float_guard"],
        settings=ctx["settings"],
    )

    # Broadcast event to WebSocket subscribers on success
    if result.status == "success":
        event_spec = _ACTION_EVENT_MAP.get(body.action)
        if event_spec:
            kind, priority, toast = event_spec
            event = make_event(
                kind=kind,
                data={"action": body.action, "detail": result.detail},
                priority=priority,
                toast=toast,
            )
            await broadcast_event(event)

    return result.to_dict()


# Action → Event mapping
_ACTION_EVENT_MAP: dict[str, tuple[EventKind, EventPriority, bool]] = {
    "pause_settlements": (EventKind.ESCALATION, EventPriority.CRITICAL, True),
    "resume_settlements": (EventKind.SETTLEMENT_COMPLETE, EventPriority.NORMAL, True),
    "pause_stream": (EventKind.STREAM_STATE_CHANGE, EventPriority.NORMAL, True),
    "resume_stream": (EventKind.STREAM_STATE_CHANGE, EventPriority.NORMAL, True),
    "retry_failed_payout": (EventKind.PAYOUT_FAILED, EventPriority.NORMAL, True),
    "trigger_health_check": (EventKind.SETTLEMENT_COMPLETE, EventPriority.LOW, False),
    "escalate_to_manual": (EventKind.ESCALATION, EventPriority.CRITICAL, True),
}


# ---------------------------------------------------------------------------
# POST /suggestions/dismiss — dismiss a suggestion
# ---------------------------------------------------------------------------


class SuggestionDismissRequest(BaseModel):
    suggestion_id: str
    reason: str = ""


@router.post("/suggestions/dismiss")
async def dismiss_suggestion(body: SuggestionDismissRequest) -> dict[str, Any]:
    """Dismiss a suggestion from the queue.

    Placeholder — will wire to Tower Agent suggestion store when NUMA connected.
    """
    logger.info(
        "Suggestion dismissed: id=%s reason=%s",
        body.suggestion_id,
        body.reason,
    )
    return {
        "status": "dismissed",
        "suggestion_id": body.suggestion_id,
        "dismissed_at": datetime.now(timezone.utc).isoformat(),
    }


# ---------------------------------------------------------------------------
# WS /events/stream — real-time WebSocket events
# ---------------------------------------------------------------------------

_ws_subscribers: list[WebSocket] = []


@router.websocket("/events/stream")
async def event_stream(websocket: WebSocket) -> None:
    """WebSocket endpoint for real-time dashboard events."""
    await websocket.accept()
    _ws_subscribers.append(websocket)
    logger.info("Tower Agent WebSocket connected (total=%d)", len(_ws_subscribers))

    try:
        while True:
            data = await websocket.receive_json()
            if data.get("type") == "ping":
                await websocket.send_json({"type": "pong"})
    except WebSocketDisconnect:
        pass
    finally:
        if websocket in _ws_subscribers:
            _ws_subscribers.remove(websocket)
        logger.info("Tower Agent WebSocket disconnected (total=%d)", len(_ws_subscribers))


async def broadcast_event(event: DashboardEvent) -> int:
    """Broadcast a dashboard event to all WebSocket subscribers."""
    payload = event.to_dict()
    sent = 0
    dead: list[WebSocket] = []

    for ws in _ws_subscribers:
        try:
            await ws.send_json(payload)
            sent += 1
        except Exception:
            dead.append(ws)

    for ws in dead:
        if ws in _ws_subscribers:
            _ws_subscribers.remove(ws)

    return sent
