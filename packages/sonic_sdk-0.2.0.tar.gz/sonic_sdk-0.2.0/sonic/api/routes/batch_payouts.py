"""Phase 4.3 — Batch payouts and scheduled payouts."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import get_db, get_read_db, get_merchant, get_payout_executor
from sonic.models.merchant import Merchant
from sonic.models.transaction import TransactionRecord

router = APIRouter()


# ---------------------------------------------------------------------------
# Batch payouts
# ---------------------------------------------------------------------------


class BatchPayoutItem(BaseModel):
    tx_id: str
    recipient_id: str
    amount: Decimal | None = None
    currency: str | None = None
    rail: str | None = None


class BatchPayoutRequest(BaseModel):
    items: list[BatchPayoutItem] = Field(..., min_length=1, max_length=100)
    idempotency_key: str = Field(..., min_length=1, max_length=128)


class BatchPayoutItemResult(BaseModel):
    tx_id: str
    status: str  # queued | failed
    error: str | None = None


class BatchPayoutResponse(BaseModel):
    batch_id: str
    merchant_id: str
    total_items: int
    queued: int
    failed: int
    results: list[BatchPayoutItemResult]
    created_at: str


@router.post("/payouts/batch", response_model=BatchPayoutResponse, status_code=201)
async def create_batch_payout(
    body: BatchPayoutRequest,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
):
    """Submit a batch of payouts for atomic execution.

    All items are validated first. If any item fails validation,
    none are executed. Successfully validated items are queued
    for execution.
    """
    batch_id = f"batch_{uuid.uuid4().hex[:16]}"
    results: list[BatchPayoutItemResult] = []
    queued = 0
    failed = 0

    # Validate all items first
    for item in body.items:
        tx_result = await db.execute(
            select(TransactionRecord).where(
                TransactionRecord.id == item.tx_id,
                TransactionRecord.merchant_id == merchant.id,
            )
        )
        tx = tx_result.scalar_one_or_none()

        if not tx:
            results.append(BatchPayoutItemResult(
                tx_id=item.tx_id, status="failed", error="Transaction not found",
            ))
            failed += 1
            continue

        if tx.state not in ("normalized", "receivable_cleared"):
            results.append(BatchPayoutItemResult(
                tx_id=item.tx_id, status="failed",
                error=f"Transaction in state '{tx.state}' — must be 'normalized' or 'receivable_cleared'",
            ))
            failed += 1
            continue

        # Mark as queued (actual execution happens asynchronously)
        tx.state = "payout_pending"
        tx.outbound_rail = item.rail or merchant.default_payout_rail
        tx.outbound_currency = item.currency or merchant.default_payout_currency
        results.append(BatchPayoutItemResult(tx_id=item.tx_id, status="queued"))
        queued += 1

    await db.commit()

    return BatchPayoutResponse(
        batch_id=batch_id,
        merchant_id=merchant.id,
        total_items=len(body.items),
        queued=queued,
        failed=failed,
        results=results,
        created_at=datetime.now(timezone.utc).isoformat(),
    )


# ---------------------------------------------------------------------------
# Scheduled payouts (settlement windows)
# ---------------------------------------------------------------------------


class ScheduledPayoutConfig(BaseModel):
    frequency: str = Field(
        ..., pattern="^(daily|weekly|biweekly|monthly)$",
        description="Payout schedule frequency",
    )
    day_of_week: int | None = Field(
        default=None, ge=0, le=6,
        description="Day of week for weekly/biweekly (0=Monday)",
    )
    day_of_month: int | None = Field(
        default=None, ge=1, le=28,
        description="Day of month for monthly payouts",
    )
    min_amount: Decimal = Field(
        default=Decimal("1.00"),
        description="Minimum accumulated amount before payout triggers",
    )
    auto_payout_rail: str | None = None
    auto_payout_currency: str | None = None


class ScheduledPayoutConfigResponse(BaseModel):
    merchant_id: str
    schedule: ScheduledPayoutConfig
    next_payout_at: str | None
    pending_amount: str
    status: str


# In-memory schedule store (production would persist to DB)
_scheduled_configs: dict[str, dict] = {}


@router.put("/merchants/me/payout-schedule", response_model=ScheduledPayoutConfigResponse)
async def set_payout_schedule(
    body: ScheduledPayoutConfig,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_read_db),
):
    """Configure automatic scheduled payouts for the merchant."""
    # Calculate pending amount
    result = await db.execute(
        select(func.coalesce(func.sum(TransactionRecord.treasury_amount), 0))
        .where(
            TransactionRecord.merchant_id == merchant.id,
            TransactionRecord.state.in_(["normalized", "receivable_cleared"]),
        )
    )
    pending = result.scalar_one()

    _scheduled_configs[merchant.id] = body.model_dump()

    return ScheduledPayoutConfigResponse(
        merchant_id=merchant.id,
        schedule=body,
        next_payout_at=None,  # Computed by background scheduler
        pending_amount=f"{float(pending):,.6f}",
        status="active",
    )


@router.get("/merchants/me/payout-schedule", response_model=ScheduledPayoutConfigResponse)
async def get_payout_schedule(
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_read_db),
):
    """Get the merchant's current payout schedule configuration."""
    config = _scheduled_configs.get(merchant.id)

    result = await db.execute(
        select(func.coalesce(func.sum(TransactionRecord.treasury_amount), 0))
        .where(
            TransactionRecord.merchant_id == merchant.id,
            TransactionRecord.state.in_(["normalized", "receivable_cleared"]),
        )
    )
    pending = result.scalar_one()

    if not config:
        return ScheduledPayoutConfigResponse(
            merchant_id=merchant.id,
            schedule=ScheduledPayoutConfig(frequency="daily", min_amount=Decimal("1.00")),
            next_payout_at=None,
            pending_amount=f"{float(pending):,.6f}",
            status="not_configured",
        )

    return ScheduledPayoutConfigResponse(
        merchant_id=merchant.id,
        schedule=ScheduledPayoutConfig(**config),
        next_payout_at=None,
        pending_amount=f"{float(pending):,.6f}",
        status="active",
    )
