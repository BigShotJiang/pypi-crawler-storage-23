"""Receipt endpoints — merchant-facing receipt retrieval and multi-tier verification."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import get_db, get_merchant, get_verifier
from sonic.core.receipt_builder import canonical_hash
from sonic.models.merchant import Merchant
from sonic.models.receipt import ReceiptRecord

router = APIRouter()


class ReceiptResponse(BaseModel):
    receipt_id: str
    tx_id: str
    event_type: str
    sequence: int
    amount: Decimal
    currency: str
    rail: str
    direction: str
    receipt_hash: str
    prev_receipt_hash: str | None
    merchant_id: str
    timestamp: datetime
    # Product-visible proof grade: app_only | sbn_attested | combined | anchored
    proof_grade: str
    # Tier 2: SBN
    sbn_receipt_hash: str | None = None
    sbn_attested_at: datetime | None = None
    # Tier 2: Combined
    combined_hash: str | None = None
    prev_combined_hash: str | None = None
    # Tier 3: Blockchain anchor
    anchor_chain: str | None = None
    anchor_tx_id: str | None = None
    anchor_consensus_ts: datetime | None = None
    anchored_at: datetime | None = None


class TierDetail(BaseModel):
    tier: str
    verified: bool
    detail: str
    evidence: dict[str, Any] = {}


class VerifyResponse(BaseModel):
    receipt_hash: str
    chain_valid: bool
    sbn_attested: bool
    sbn_receipt_hash: str | None = None
    combined_hash: str | None = None
    anchor_chain: str | None = None
    anchor_tx_id: str | None = None
    tx_id: str
    event_type: str
    amount: Decimal
    currency: str
    merchant_id: str
    # Multi-tier verification (populated when verifier is available)
    tiers: list[TierDetail] | None = None
    fully_verified: bool | None = None
    max_tier_verified: int | None = None


@router.get("/receipts/{tx_id}", response_model=list[ReceiptResponse])
async def get_transaction_receipts(
    tx_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
):
    """Get all receipts for a transaction.

    Returns the full event chain with SBN attestation, combined chain,
    and blockchain anchor status for each event.
    """
    result = await db.execute(
        select(ReceiptRecord)
        .where(ReceiptRecord.tx_id == tx_id, ReceiptRecord.merchant_id == merchant.id)
        .order_by(ReceiptRecord.sequence)
    )
    receipts = result.scalars().all()

    if not receipts:
        raise HTTPException(status_code=404, detail="No receipts found for this transaction")

    return [
        ReceiptResponse(
            receipt_id=r.receipt_id,
            tx_id=r.tx_id,
            event_type=r.event_type,
            sequence=r.sequence,
            amount=r.amount,
            currency=r.currency,
            rail=r.rail,
            direction=r.direction,
            receipt_hash=r.receipt_hash,
            prev_receipt_hash=r.prev_receipt_hash,
            merchant_id=r.merchant_id,
            timestamp=r.timestamp,
            proof_grade=r.proof_grade,
            sbn_receipt_hash=r.sbn_receipt_hash,
            sbn_attested_at=r.sbn_attested_at,
            combined_hash=r.combined_hash,
            prev_combined_hash=r.prev_combined_hash,
            anchor_chain=r.anchor_chain,
            anchor_tx_id=r.anchor_tx_id,
            anchor_consensus_ts=r.anchor_consensus_ts,
            anchored_at=r.anchored_at,
        )
        for r in receipts
    ]


@router.get("/receipts/{tx_id}/verify", response_model=VerifyResponse)
async def verify_receipt(
    tx_id: str,
    sequence: int = Query(default=0, description="Event sequence number to verify"),
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
    verifier: Any = Depends(get_verifier),
):
    """Verify a specific receipt across all three tiers.

    Tier 1: App chain integrity (always available)
    Tier 2: Combined hash verification (when SBN attested)
    Tier 3: Blockchain anchor verification (when merchant opted in)
    """
    result = await db.execute(
        select(ReceiptRecord).where(
            ReceiptRecord.tx_id == tx_id,
            ReceiptRecord.sequence == sequence,
            ReceiptRecord.merchant_id == merchant.id,
        )
    )
    receipt = result.scalar_one_or_none()
    if not receipt:
        raise HTTPException(status_code=404, detail="Receipt not found")

    chain_valid = True
    if receipt.prev_receipt_hash:
        prev = await db.execute(
            select(ReceiptRecord).where(
                ReceiptRecord.receipt_hash == receipt.prev_receipt_hash
            )
        )
        if not prev.scalar_one_or_none():
            chain_valid = False

    response = VerifyResponse(
        receipt_hash=receipt.receipt_hash,
        chain_valid=chain_valid,
        sbn_attested=receipt.sbn_receipt_hash is not None,
        sbn_receipt_hash=receipt.sbn_receipt_hash,
        combined_hash=receipt.combined_hash,
        anchor_chain=receipt.anchor_chain,
        anchor_tx_id=receipt.anchor_tx_id,
        tx_id=receipt.tx_id,
        event_type=receipt.event_type,
        amount=receipt.amount,
        currency=receipt.currency,
        merchant_id=receipt.merchant_id,
    )

    if verifier is not None:
        report = await verifier.verify_receipt(receipt.receipt_id)
        response.tiers = [
            TierDetail(
                tier=t.tier,
                verified=t.verified,
                detail=t.detail,
                evidence=t.evidence,
            )
            for t in report.tiers
        ]
        response.fully_verified = report.fully_verified
        response.max_tier_verified = report.max_tier_verified

    return response


@router.get("/verify/{receipt_hash}", response_model=VerifyResponse)
async def public_verify(
    receipt_hash: str,
    db: AsyncSession = Depends(get_db),
    verifier: Any = Depends(get_verifier),
):
    """Public verification endpoint — no auth required.

    Anyone with a receipt hash can verify it across all three tiers.
    This is the link merchants share with their customers / auditors.
    """
    result = await db.execute(
        select(ReceiptRecord).where(ReceiptRecord.receipt_hash == receipt_hash)
    )
    receipt = result.scalar_one_or_none()
    if not receipt:
        raise HTTPException(status_code=404, detail="Receipt not found")

    chain_valid = True
    if receipt.prev_receipt_hash:
        prev = await db.execute(
            select(ReceiptRecord).where(
                ReceiptRecord.receipt_hash == receipt.prev_receipt_hash
            )
        )
        if not prev.scalar_one_or_none():
            chain_valid = False

    response = VerifyResponse(
        receipt_hash=receipt.receipt_hash,
        chain_valid=chain_valid,
        sbn_attested=receipt.sbn_receipt_hash is not None,
        sbn_receipt_hash=receipt.sbn_receipt_hash,
        combined_hash=receipt.combined_hash,
        anchor_chain=receipt.anchor_chain,
        anchor_tx_id=receipt.anchor_tx_id,
        tx_id=receipt.tx_id,
        event_type=receipt.event_type,
        amount=receipt.amount,
        currency=receipt.currency,
        merchant_id=receipt.merchant_id,
    )

    if verifier is not None:
        report = await verifier.verify_receipt(receipt.receipt_id)
        response.tiers = [
            TierDetail(
                tier=t.tier,
                verified=t.verified,
                detail=t.detail,
                evidence=t.evidence,
            )
            for t in report.tiers
        ]
        response.fully_verified = report.fully_verified
        response.max_tier_verified = report.max_tier_verified

    return response
