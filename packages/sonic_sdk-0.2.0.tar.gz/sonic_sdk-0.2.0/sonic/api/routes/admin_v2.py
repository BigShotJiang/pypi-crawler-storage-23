"""Phase 4.2 — Admin capabilities: suspension, disputes, cross-merchant search, circuit breaker, audit viewer."""

from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select, func, or_
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import get_db, get_read_db
from sonic.api.routes.admin import require_admin
from sonic.models.dispute import Dispute
from sonic.models.event_log import EventLog
from sonic.models.merchant import Merchant
from sonic.models.transaction import TransactionRecord
from sonic.models.user import DashboardUser

router = APIRouter()


# ---------------------------------------------------------------------------
# 4.2.1 Merchant suspension / reactivation
# ---------------------------------------------------------------------------


class MerchantSuspendRequest(BaseModel):
    reason: str = Field(..., min_length=1, max_length=500)


class MerchantSuspendResponse(BaseModel):
    merchant_id: str
    status: str
    action: str
    reason: str
    acted_by: str
    timestamp: str


@router.post("/admin/merchants/{merchant_id}/suspend", response_model=MerchantSuspendResponse)
async def suspend_merchant(
    merchant_id: str,
    body: MerchantSuspendRequest,
    admin: DashboardUser = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """Suspend a merchant account. API key auth is rejected for suspended merchants."""
    result = await db.execute(select(Merchant).where(Merchant.id == merchant_id))
    merchant = result.scalar_one_or_none()
    if not merchant:
        raise HTTPException(status_code=404, detail="Merchant not found")
    if merchant.status == "suspended":
        raise HTTPException(status_code=400, detail="Merchant is already suspended")

    merchant.status = "suspended"

    # Audit trail
    db.add(EventLog(
        tx_id=f"admin_suspend_{merchant_id}",
        event_type="admin.merchant.suspended",
        merchant_id=merchant_id,
        payload={"reason": body.reason, "acted_by": admin.id},
    ))
    await db.commit()

    return MerchantSuspendResponse(
        merchant_id=merchant_id,
        status="suspended",
        action="suspend",
        reason=body.reason,
        acted_by=admin.id,
        timestamp=datetime.now(timezone.utc).isoformat(),
    )


@router.post("/admin/merchants/{merchant_id}/reactivate", response_model=MerchantSuspendResponse)
async def reactivate_merchant(
    merchant_id: str,
    body: MerchantSuspendRequest,
    admin: DashboardUser = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """Reactivate a suspended merchant account."""
    result = await db.execute(select(Merchant).where(Merchant.id == merchant_id))
    merchant = result.scalar_one_or_none()
    if not merchant:
        raise HTTPException(status_code=404, detail="Merchant not found")
    if merchant.status == "active":
        raise HTTPException(status_code=400, detail="Merchant is already active")

    merchant.status = "active"

    db.add(EventLog(
        tx_id=f"admin_reactivate_{merchant_id}",
        event_type="admin.merchant.reactivated",
        merchant_id=merchant_id,
        payload={"reason": body.reason, "acted_by": admin.id},
    ))
    await db.commit()

    return MerchantSuspendResponse(
        merchant_id=merchant_id,
        status="active",
        action="reactivate",
        reason=body.reason,
        acted_by=admin.id,
        timestamp=datetime.now(timezone.utc).isoformat(),
    )


# ---------------------------------------------------------------------------
# 4.2.2 Dispute / chargeback workflow
# ---------------------------------------------------------------------------


class DisputeCreateRequest(BaseModel):
    tx_id: str
    reason: str = Field(..., pattern="^(fraud|duplicate|not_received|other)$")
    amount: Decimal
    currency: str = Field(..., max_length=4)
    description: str | None = None
    provider: str | None = None
    provider_dispute_id: str | None = None


class DisputeUpdateRequest(BaseModel):
    status: str = Field(..., pattern="^(under_review|won|lost|closed)$")
    resolution_note: str | None = None


class DisputeResponse(BaseModel):
    id: str
    tx_id: str
    merchant_id: str
    reason: str
    amount: str
    currency: str
    description: str | None
    status: str
    resolved_by: str | None
    resolution_note: str | None
    provider: str | None
    provider_dispute_id: str | None
    created_at: str
    updated_at: str


class DisputeListResponse(BaseModel):
    disputes: list[DisputeResponse]
    total: int
    has_more: bool


def _dispute_to_response(d: Dispute) -> DisputeResponse:
    return DisputeResponse(
        id=d.id,
        tx_id=d.tx_id,
        merchant_id=d.merchant_id,
        reason=d.reason,
        amount=str(d.amount),
        currency=d.currency,
        description=d.description,
        status=d.status,
        resolved_by=d.resolved_by,
        resolution_note=d.resolution_note,
        provider=d.provider,
        provider_dispute_id=d.provider_dispute_id,
        created_at=d.created_at.isoformat(),
        updated_at=d.updated_at.isoformat(),
    )


@router.post("/admin/disputes", response_model=DisputeResponse, status_code=201)
async def create_dispute(
    body: DisputeCreateRequest,
    admin: DashboardUser = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """Open a dispute/chargeback for a transaction."""
    # Verify transaction exists
    tx_result = await db.execute(
        select(TransactionRecord).where(TransactionRecord.id == body.tx_id)
    )
    tx = tx_result.scalar_one_or_none()
    if not tx:
        raise HTTPException(status_code=404, detail="Transaction not found")

    dispute = Dispute(
        tx_id=body.tx_id,
        merchant_id=tx.merchant_id,
        reason=body.reason,
        amount=body.amount,
        currency=body.currency,
        description=body.description,
        provider=body.provider,
        provider_dispute_id=body.provider_dispute_id,
    )
    db.add(dispute)

    # Audit trail
    db.add(EventLog(
        tx_id=body.tx_id,
        event_type="admin.dispute.opened",
        merchant_id=tx.merchant_id,
        payload={"dispute_reason": body.reason, "amount": str(body.amount), "opened_by": admin.id},
    ))
    await db.commit()
    await db.refresh(dispute)

    return _dispute_to_response(dispute)


@router.get("/admin/disputes", response_model=DisputeListResponse)
async def list_disputes(
    admin: DashboardUser = Depends(require_admin),
    db: AsyncSession = Depends(get_read_db),
    status: Optional[str] = Query(default=None),
    merchant_id: Optional[str] = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
):
    """List disputes with optional filters."""
    query = select(Dispute)
    count_query = select(func.count()).select_from(Dispute)

    if status:
        query = query.where(Dispute.status == status)
        count_query = count_query.where(Dispute.status == status)
    if merchant_id:
        query = query.where(Dispute.merchant_id == merchant_id)
        count_query = count_query.where(Dispute.merchant_id == merchant_id)

    total = (await db.execute(count_query)).scalar_one()

    result = await db.execute(
        query.order_by(Dispute.created_at.desc()).offset(offset).limit(limit)
    )
    disputes = result.scalars().all()

    return DisputeListResponse(
        disputes=[_dispute_to_response(d) for d in disputes],
        total=total,
        has_more=(offset + limit) < total,
    )


@router.patch("/admin/disputes/{dispute_id}", response_model=DisputeResponse)
async def update_dispute(
    dispute_id: str,
    body: DisputeUpdateRequest,
    admin: DashboardUser = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """Update dispute status (resolve, close, etc.)."""
    result = await db.execute(select(Dispute).where(Dispute.id == dispute_id))
    dispute = result.scalar_one_or_none()
    if not dispute:
        raise HTTPException(status_code=404, detail="Dispute not found")

    dispute.status = body.status
    dispute.resolved_by = admin.id
    if body.resolution_note:
        dispute.resolution_note = body.resolution_note

    db.add(EventLog(
        tx_id=dispute.tx_id,
        event_type=f"admin.dispute.{body.status}",
        merchant_id=dispute.merchant_id,
        payload={"dispute_id": dispute_id, "new_status": body.status, "resolved_by": admin.id},
    ))
    await db.commit()
    await db.refresh(dispute)

    return _dispute_to_response(dispute)


# ---------------------------------------------------------------------------
# 4.2.3 System-wide transaction search (cross-merchant)
# ---------------------------------------------------------------------------


class CrossMerchantTxResponse(BaseModel):
    tx_id: str
    merchant_id: str
    merchant_name: str
    state: str
    inbound_amount: str
    inbound_currency: str
    inbound_rail: str
    customer_ref: str | None
    created_at: str


class CrossMerchantSearchResponse(BaseModel):
    results: list[CrossMerchantTxResponse]
    total: int
    has_more: bool


@router.get("/admin/transactions/search", response_model=CrossMerchantSearchResponse)
async def search_transactions_cross_merchant(
    admin: DashboardUser = Depends(require_admin),
    db: AsyncSession = Depends(get_read_db),
    q: Optional[str] = Query(default=None, description="Search by tx_id, customer_ref, or provider_ref"),
    merchant_id: Optional[str] = Query(default=None),
    state: Optional[str] = Query(default=None),
    rail: Optional[str] = Query(default=None),
    min_amount: Optional[float] = Query(default=None),
    max_amount: Optional[float] = Query(default=None),
    start: Optional[str] = Query(default=None),
    end: Optional[str] = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
):
    """Cross-merchant transaction search. Admin only."""
    # Build merchant name lookup subquery
    merchant_names = (
        select(Merchant.id, Merchant.name)
        .subquery()
    )

    query = (
        select(
            TransactionRecord,
            func.coalesce(merchant_names.c.name, "Unknown").label("merchant_name"),
        )
        .outerjoin(merchant_names, TransactionRecord.merchant_id == merchant_names.c.id)
    )
    count_base = select(func.count()).select_from(TransactionRecord)

    filters = []
    if q:
        filters.append(or_(
            TransactionRecord.id.ilike(f"%{q}%"),
            TransactionRecord.customer_ref.ilike(f"%{q}%"),
            TransactionRecord.inbound_provider_ref.ilike(f"%{q}%"),
            TransactionRecord.outbound_provider_ref.ilike(f"%{q}%"),
        ))
    if merchant_id:
        filters.append(TransactionRecord.merchant_id == merchant_id)
    if state:
        filters.append(TransactionRecord.state == state)
    if rail:
        filters.append(TransactionRecord.inbound_rail == rail)
    if min_amount is not None:
        filters.append(TransactionRecord.inbound_amount >= Decimal(str(min_amount)))
    if max_amount is not None:
        filters.append(TransactionRecord.inbound_amount <= Decimal(str(max_amount)))
    if start:
        filters.append(TransactionRecord.created_at >= datetime.fromisoformat(start))
    if end:
        filters.append(TransactionRecord.created_at <= datetime.fromisoformat(end))

    for f in filters:
        query = query.where(f)
        count_base = count_base.where(f)

    total = (await db.execute(count_base)).scalar_one()

    result = await db.execute(
        query.order_by(TransactionRecord.created_at.desc()).offset(offset).limit(limit)
    )
    rows = result.all()

    return CrossMerchantSearchResponse(
        results=[
            CrossMerchantTxResponse(
                tx_id=tx.id,
                merchant_id=tx.merchant_id,
                merchant_name=mname,
                state=tx.state,
                inbound_amount=str(tx.inbound_amount),
                inbound_currency=tx.inbound_currency,
                inbound_rail=tx.inbound_rail,
                customer_ref=tx.customer_ref,
                created_at=tx.created_at.isoformat(),
            )
            for tx, mname in rows
        ],
        total=total,
        has_more=(offset + limit) < total,
    )


# ---------------------------------------------------------------------------
# 4.2.4 Provider circuit breaker
# ---------------------------------------------------------------------------


class CircuitBreakerState(BaseModel):
    provider: str
    status: str  # open | closed | half_open
    reason: str | None = None
    disabled_by: str | None = None
    disabled_at: str | None = None


class CircuitBreakerListResponse(BaseModel):
    providers: list[CircuitBreakerState]


class CircuitBreakerToggleRequest(BaseModel):
    status: str = Field(..., pattern="^(open|closed)$")
    reason: str | None = None


# In-memory circuit breaker state (production would use Redis)
_circuit_breaker_state: dict[str, dict] = {}


@router.get("/admin/providers/circuit-breakers", response_model=CircuitBreakerListResponse)
async def list_circuit_breakers(
    admin: DashboardUser = Depends(require_admin),
):
    """List circuit breaker state for all providers."""
    providers = ["stripe_card", "stripe_ach", "moov_ach", "circle_usdc", "circle_usdc_solana"]
    states = []
    for p in providers:
        cb = _circuit_breaker_state.get(p, {})
        states.append(CircuitBreakerState(
            provider=p,
            status=cb.get("status", "closed"),
            reason=cb.get("reason"),
            disabled_by=cb.get("disabled_by"),
            disabled_at=cb.get("disabled_at"),
        ))
    return CircuitBreakerListResponse(providers=states)


@router.post("/admin/providers/{provider}/circuit-breaker", response_model=CircuitBreakerState)
async def toggle_circuit_breaker(
    provider: str,
    body: CircuitBreakerToggleRequest,
    admin: DashboardUser = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """Manually open/close a provider's circuit breaker."""
    _circuit_breaker_state[provider] = {
        "status": body.status,
        "reason": body.reason,
        "disabled_by": admin.id,
        "disabled_at": datetime.now(timezone.utc).isoformat(),
    }

    db.add(EventLog(
        tx_id=f"circuit_breaker_{provider}",
        event_type=f"admin.circuit_breaker.{'opened' if body.status == 'open' else 'closed'}",
        merchant_id="system",
        payload={"provider": provider, "status": body.status, "reason": body.reason, "by": admin.id},
    ))
    await db.commit()

    cb = _circuit_breaker_state[provider]
    return CircuitBreakerState(
        provider=provider,
        status=cb["status"],
        reason=cb.get("reason"),
        disabled_by=cb.get("disabled_by"),
        disabled_at=cb.get("disabled_at"),
    )


# ---------------------------------------------------------------------------
# 4.2.5 Audit log viewer (paginated, filterable)
# ---------------------------------------------------------------------------


class AuditEntry(BaseModel):
    id: str
    tx_id: str
    event_type: str
    from_state: str | None
    to_state: str | None
    merchant_id: str
    provider: str | None
    provider_ref: str | None
    receipt_hash: str | None
    payload: dict | None
    timestamp: str


class AuditViewerResponse(BaseModel):
    entries: list[AuditEntry]
    total: int
    has_more: bool
    event_types: list[str]


@router.get("/admin/audit/viewer", response_model=AuditViewerResponse)
async def audit_log_viewer(
    admin: DashboardUser = Depends(require_admin),
    db: AsyncSession = Depends(get_read_db),
    event_type: Optional[str] = Query(default=None),
    merchant_id: Optional[str] = Query(default=None),
    tx_id: Optional[str] = Query(default=None),
    start: Optional[str] = Query(default=None),
    end: Optional[str] = Query(default=None),
    q: Optional[str] = Query(default=None, description="Search in tx_id, provider_ref"),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
):
    """Audit log viewer with rich filtering. Admin only."""
    query = select(EventLog)
    count_query = select(func.count()).select_from(EventLog)

    if event_type:
        query = query.where(EventLog.event_type == event_type)
        count_query = count_query.where(EventLog.event_type == event_type)
    if merchant_id:
        query = query.where(EventLog.merchant_id == merchant_id)
        count_query = count_query.where(EventLog.merchant_id == merchant_id)
    if tx_id:
        query = query.where(EventLog.tx_id == tx_id)
        count_query = count_query.where(EventLog.tx_id == tx_id)
    if start:
        query = query.where(EventLog.timestamp >= datetime.fromisoformat(start))
        count_query = count_query.where(EventLog.timestamp >= datetime.fromisoformat(start))
    if end:
        query = query.where(EventLog.timestamp <= datetime.fromisoformat(end))
        count_query = count_query.where(EventLog.timestamp <= datetime.fromisoformat(end))
    if q:
        query = query.where(or_(
            EventLog.tx_id.ilike(f"%{q}%"),
            EventLog.provider_ref.ilike(f"%{q}%"),
        ))
        count_query = count_query.where(or_(
            EventLog.tx_id.ilike(f"%{q}%"),
            EventLog.provider_ref.ilike(f"%{q}%"),
        ))

    total = (await db.execute(count_query)).scalar_one()

    result = await db.execute(
        query.order_by(EventLog.timestamp.desc()).offset(offset).limit(limit)
    )
    events = result.scalars().all()

    # Get distinct event types for filter dropdown
    types_result = await db.execute(
        select(EventLog.event_type).distinct().order_by(EventLog.event_type).limit(100)
    )
    event_types = [r[0] for r in types_result.all()]

    return AuditViewerResponse(
        entries=[
            AuditEntry(
                id=e.id,
                tx_id=e.tx_id,
                event_type=e.event_type,
                from_state=e.from_state,
                to_state=e.to_state,
                merchant_id=e.merchant_id,
                provider=e.provider,
                provider_ref=e.provider_ref,
                receipt_hash=e.receipt_hash,
                payload=e.payload,
                timestamp=e.timestamp.isoformat(),
            )
            for e in events
        ],
        total=total,
        has_more=(offset + limit) < total,
        event_types=event_types,
    )
