"""PayStream endpoints — windowed accrual streaming with risk-gated policy.

Endpoints:
  POST   /v1/pay-streams              — open a new pay stream
  POST   /v1/pay-streams/{id}/accrue  — record work event earnings
  POST   /v1/pay-streams/{id}/close-window — close current window, trigger payout
  POST   /v1/pay-streams/{id}/pause   — manually pause
  POST   /v1/pay-streams/{id}/resume  — resume from pause
  POST   /v1/pay-streams/{id}/freeze  — policy-driven freeze
  POST   /v1/pay-streams/{id}/unfreeze — resume from freeze (new slot)
  POST   /v1/pay-streams/{id}/close   — terminal close + reconciliation
  GET    /v1/pay-streams/{id}         — inspect stream state
  GET    /v1/pay-streams/{id}/windows — list accrual windows
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import get_db, get_read_db, get_merchant, get_stream_worker
from sonic.models.merchant import Merchant
from sonic.models.pay_stream import PayStream
from sonic.models.stream_window import StreamWindow

log = logging.getLogger("sonic.pay_streams")

router = APIRouter()


# ── Request / Response schemas ───────────────────────────────────────────


class OpenPayStreamRequest(BaseModel):
    payer_id: str = Field(..., description="Payer entity ID (employer, platform)")
    payee_id: str = Field(..., description="Payee entity ID (worker, contractor)")
    currency: str = Field(default="USD", max_length=4)
    rail: str = Field(default="stripe_transfer")
    rate_amount: Decimal = Field(default=Decimal("0"), ge=0, description="Rate per window/hour/task")
    rate_unit: str = Field(default="per_window", description="per_window | per_hour | per_task")
    cadence_seconds: int = Field(default=1800, ge=60, description="Window size in seconds (default: 1800 = 30 min)")
    metadata: dict[str, Any] | None = None


class AccrueRequest(BaseModel):
    units: Decimal = Field(..., gt=0, description="Work units completed")
    unit_price: Decimal | None = Field(default=None, ge=0, description="Price per unit (default: stream rate)")
    metadata: dict[str, Any] | None = None


class CloseWindowRequest(BaseModel):
    gec_y: int = Field(default=0, ge=0, description="GEC successful count")
    gec_x: int = Field(default=0, ge=0, description="GEC submitted count")


class FreezeRequest(BaseModel):
    reason: str = Field(default="", description="Reason for freeze")


class PayStreamResponse(BaseModel):
    pay_stream_id: str
    status: str
    policy_state: str
    payer_id: str
    payee_id: str
    currency: str
    rail: str
    rate_amount: str
    cadence_seconds: int
    g_ewma: str
    total_earned: str
    total_disbursed: str
    total_held: str
    window_count: int
    sbn_slot_id: str | None = None
    created_at: str
    closed_at: str | None = None


class PayStreamListResponse(BaseModel):
    streams: list[PayStreamResponse]
    total: int
    has_more: bool


class WindowResponse(BaseModel):
    window_id: str
    window_number: int
    status: str
    earned_amount: str
    disbursed_amount: str
    holdback_amount: str
    gec_score: str
    policy_state_at_close: str | None = None
    window_start: str
    window_end: str | None = None


# ── Helpers ──────────────────────────────────────────────────────────────


def _stream_response(s: PayStream) -> PayStreamResponse:
    return PayStreamResponse(
        pay_stream_id=s.id,
        status=s.status,
        policy_state=s.policy_state,
        payer_id=s.payer_id,
        payee_id=s.payee_id,
        currency=s.currency,
        rail=s.rail,
        rate_amount=str(s.rate_amount),
        cadence_seconds=s.cadence_seconds,
        g_ewma=str(s.g_ewma),
        total_earned=str(s.total_earned),
        total_disbursed=str(s.total_disbursed),
        total_held=str(s.total_held),
        window_count=s.window_count,
        sbn_slot_id=s.sbn_slot_id,
        created_at=s.created_at.isoformat(),
        closed_at=s.closed_at.isoformat() if s.closed_at else None,
    )


# ── Routes ───────────────────────────────────────────────────────────────


@router.get("/pay-streams", response_model=PayStreamListResponse)
async def list_pay_streams(
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_read_db),
    status: str | None = Query(default=None, description="Filter by status (active, paused, frozen, closed)"),
    payee_id: str | None = Query(default=None, description="Filter by payee"),
    payer_id: str | None = Query(default=None, description="Filter by payer"),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
):
    """List pay streams for the authenticated merchant."""
    query = (
        select(PayStream)
        .where(PayStream.merchant_id == merchant.id)
        .order_by(PayStream.created_at.desc())
    )
    if status:
        query = query.where(PayStream.status == status)
    if payee_id:
        query = query.where(PayStream.payee_id == payee_id)
    if payer_id:
        query = query.where(PayStream.payer_id == payer_id)

    from sqlalchemy import func as sa_func
    count_q = select(sa_func.count()).select_from(query.subquery())
    total = (await db.execute(count_q)).scalar_one()

    result = await db.execute(query.offset(offset).limit(limit))
    streams = result.scalars().all()

    return PayStreamListResponse(
        streams=[_stream_response(s) for s in streams],
        total=total,
        has_more=(offset + limit) < total,
    )


@router.post("/pay-streams", response_model=PayStreamResponse, status_code=201)
async def open_pay_stream(
    body: OpenPayStreamRequest,
    merchant: Merchant = Depends(get_merchant),
    worker: Any = Depends(get_stream_worker),
):
    if worker is None:
        raise HTTPException(status_code=503, detail="Stream worker not available")

    stream = await worker.open_stream(
        merchant_id=merchant.id,
        payer_id=body.payer_id,
        payee_id=body.payee_id,
        currency=body.currency,
        rail=body.rail,
        rate_amount=body.rate_amount,
        rate_unit=body.rate_unit,
        cadence_seconds=body.cadence_seconds,
        metadata=body.metadata,
    )
    return _stream_response(stream)


@router.post("/pay-streams/{pay_stream_id}/accrue", response_model=WindowResponse)
async def accrue_earnings(
    pay_stream_id: str,
    body: AccrueRequest,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
    worker: Any = Depends(get_stream_worker),
):
    if worker is None:
        raise HTTPException(status_code=503, detail="Stream worker not available")

    # Verify ownership
    result = await db.execute(
        select(PayStream).where(
            PayStream.id == pay_stream_id,
            PayStream.merchant_id == merchant.id,
        )
    )
    if result.scalar_one_or_none() is None:
        raise HTTPException(status_code=404, detail="PayStream not found")

    try:
        window = await worker.accrue(
            pay_stream_id,
            units=body.units,
            unit_price=body.unit_price,
            metadata=body.metadata,
        )
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))

    return WindowResponse(
        window_id=window.id,
        window_number=window.window_number,
        status=window.status,
        earned_amount=str(window.earned_amount),
        disbursed_amount=str(window.disbursed_amount),
        holdback_amount=str(window.holdback_amount),
        gec_score=str(window.gec_score),
        policy_state_at_close=window.policy_state_at_close,
        window_start=window.window_start.isoformat(),
        window_end=window.window_end.isoformat() if window.window_end else None,
    )


@router.post("/pay-streams/{pay_stream_id}/close-window")
async def close_window(
    pay_stream_id: str,
    body: CloseWindowRequest,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
    worker: Any = Depends(get_stream_worker),
):
    if worker is None:
        raise HTTPException(status_code=503, detail="Stream worker not available")

    result = await db.execute(
        select(PayStream).where(
            PayStream.id == pay_stream_id,
            PayStream.merchant_id == merchant.id,
        )
    )
    if result.scalar_one_or_none() is None:
        raise HTTPException(status_code=404, detail="PayStream not found")

    try:
        return await worker.close_window(
            pay_stream_id,
            gec_y=body.gec_y,
            gec_x=body.gec_x,
        )
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@router.post("/pay-streams/{pay_stream_id}/pause", response_model=PayStreamResponse)
async def pause_stream(
    pay_stream_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
    worker: Any = Depends(get_stream_worker),
):
    if worker is None:
        raise HTTPException(status_code=503, detail="Stream worker not available")

    result = await db.execute(
        select(PayStream).where(
            PayStream.id == pay_stream_id,
            PayStream.merchant_id == merchant.id,
        )
    )
    if result.scalar_one_or_none() is None:
        raise HTTPException(status_code=404, detail="PayStream not found")

    try:
        stream = await worker.pause(pay_stream_id)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))

    return _stream_response(stream)


@router.post("/pay-streams/{pay_stream_id}/resume", response_model=PayStreamResponse)
async def resume_stream(
    pay_stream_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
    worker: Any = Depends(get_stream_worker),
):
    if worker is None:
        raise HTTPException(status_code=503, detail="Stream worker not available")

    result = await db.execute(
        select(PayStream).where(
            PayStream.id == pay_stream_id,
            PayStream.merchant_id == merchant.id,
        )
    )
    if result.scalar_one_or_none() is None:
        raise HTTPException(status_code=404, detail="PayStream not found")

    try:
        stream = await worker.resume(pay_stream_id)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))

    return _stream_response(stream)


@router.post("/pay-streams/{pay_stream_id}/freeze")
async def freeze_stream(
    pay_stream_id: str,
    body: FreezeRequest,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
    worker: Any = Depends(get_stream_worker),
):
    if worker is None:
        raise HTTPException(status_code=503, detail="Stream worker not available")

    result = await db.execute(
        select(PayStream).where(
            PayStream.id == pay_stream_id,
            PayStream.merchant_id == merchant.id,
        )
    )
    if result.scalar_one_or_none() is None:
        raise HTTPException(status_code=404, detail="PayStream not found")

    try:
        return await worker.freeze(pay_stream_id, reason=body.reason)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@router.post("/pay-streams/{pay_stream_id}/unfreeze", response_model=PayStreamResponse)
async def unfreeze_stream(
    pay_stream_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
    worker: Any = Depends(get_stream_worker),
):
    if worker is None:
        raise HTTPException(status_code=503, detail="Stream worker not available")

    result = await db.execute(
        select(PayStream).where(
            PayStream.id == pay_stream_id,
            PayStream.merchant_id == merchant.id,
        )
    )
    if result.scalar_one_or_none() is None:
        raise HTTPException(status_code=404, detail="PayStream not found")

    try:
        stream = await worker.unfreeze(pay_stream_id)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))

    return _stream_response(stream)


@router.post("/pay-streams/{pay_stream_id}/close")
async def close_pay_stream(
    pay_stream_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
    worker: Any = Depends(get_stream_worker),
):
    if worker is None:
        raise HTTPException(status_code=503, detail="Stream worker not available")

    result = await db.execute(
        select(PayStream).where(
            PayStream.id == pay_stream_id,
            PayStream.merchant_id == merchant.id,
        )
    )
    if result.scalar_one_or_none() is None:
        raise HTTPException(status_code=404, detail="PayStream not found")

    try:
        return await worker.close_stream(pay_stream_id)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@router.post("/pay-streams/{pay_stream_id}/release-holdback")
async def release_holdback(
    pay_stream_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
    worker: Any = Depends(get_stream_worker),
):
    if worker is None:
        raise HTTPException(status_code=503, detail="Stream worker not available")

    result = await db.execute(
        select(PayStream).where(
            PayStream.id == pay_stream_id,
            PayStream.merchant_id == merchant.id,
        )
    )
    if result.scalar_one_or_none() is None:
        raise HTTPException(status_code=404, detail="PayStream not found")

    try:
        return await worker.release_holdback(pay_stream_id)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@router.get("/pay-streams/{pay_stream_id}", response_model=PayStreamResponse)
async def get_pay_stream(
    pay_stream_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_read_db),
):
    result = await db.execute(
        select(PayStream).where(
            PayStream.id == pay_stream_id,
            PayStream.merchant_id == merchant.id,
        )
    )
    stream = result.scalar_one_or_none()
    if stream is None:
        raise HTTPException(status_code=404, detail="PayStream not found")

    return _stream_response(stream)


@router.get("/pay-streams/{pay_stream_id}/windows", response_model=list[WindowResponse])
async def list_windows(
    pay_stream_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_read_db),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
):
    # Verify ownership
    stream_result = await db.execute(
        select(PayStream).where(
            PayStream.id == pay_stream_id,
            PayStream.merchant_id == merchant.id,
        )
    )
    if stream_result.scalar_one_or_none() is None:
        raise HTTPException(status_code=404, detail="PayStream not found")

    result = await db.execute(
        select(StreamWindow)
        .where(StreamWindow.pay_stream_id == pay_stream_id)
        .order_by(StreamWindow.window_number)
        .offset(offset)
        .limit(limit)
    )
    windows = result.scalars().all()

    return [
        WindowResponse(
            window_id=w.id,
            window_number=w.window_number,
            status=w.status,
            earned_amount=str(w.earned_amount),
            disbursed_amount=str(w.disbursed_amount),
            holdback_amount=str(w.holdback_amount),
            gec_score=str(w.gec_score),
            policy_state_at_close=w.policy_state_at_close,
            window_start=w.window_start.isoformat(),
            window_end=w.window_end.isoformat() if w.window_end else None,
        )
        for w in windows
    ]
