"""Payment link endpoints — reusable, shareable payment URLs.

Payment links are persistent URLs that merchants can share via email,
social media, or embed on their website. Each visit creates a new
checkout session, so the same link can be used for multiple payments.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import get_db, get_merchant
from sonic.config import settings
from sonic.models.checkout_session import CheckoutSession
from sonic.models.merchant import Merchant
from sonic.models.payment_link import PaymentLink

log = logging.getLogger("sonic.payment_links")

router = APIRouter()

VALID_RAILS = {"stripe_card", "stripe_ach", "moov_ach", "circle_usdc", "circle_usdc_solana"}


# --- Schemas ---


class CreatePaymentLinkRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=255, description="Display name for this link")
    amount: Decimal = Field(..., gt=0)
    currency: str = Field(default="USD", min_length=3, max_length=4)
    rail: str | None = Field(default=None, description="Lock to specific rail, or null for customer choice")
    description: str | None = Field(default=None, max_length=500)
    success_url: str | None = Field(default=None, description="Redirect after payment (optional)")

    @field_validator("rail")
    @classmethod
    def validate_rail(cls, v: str | None) -> str | None:
        if v is not None and v not in VALID_RAILS:
            raise ValueError(f"Invalid rail. Must be one of: {', '.join(sorted(VALID_RAILS))}")
        return v


class PaymentLinkResponse(BaseModel):
    link_id: str
    url: str
    slug: str
    name: str
    amount: str
    currency: str
    status: str
    total_payments: int
    created_at: str


class PaymentLinkListResponse(BaseModel):
    links: list[PaymentLinkResponse]
    total: int


# --- Endpoints ---


@router.post("/payment-links", response_model=PaymentLinkResponse, status_code=201)
async def create_payment_link(
    body: CreatePaymentLinkRequest,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
):
    """Create a reusable payment link."""
    link = PaymentLink(
        merchant_id=merchant.id,
        name=body.name,
        amount=body.amount,
        currency=body.currency.upper(),
        rail=body.rail,
        description=body.description,
        success_url=body.success_url,
    )

    db.add(link)
    await db.commit()
    await db.refresh(link)

    checkout_base = settings.checkout_base_url.rstrip("/")
    url = f"{checkout_base}/link/{link.slug}"

    log.info("Payment link created: link=%s merchant=%s slug=%s", link.id, merchant.id, link.slug)

    return PaymentLinkResponse(
        link_id=link.id,
        url=url,
        slug=link.slug,
        name=link.name,
        amount=str(link.amount),
        currency=link.currency,
        status=link.status,
        total_payments=link.total_payments,
        created_at=link.created_at.isoformat(),
    )


@router.get("/payment-links", response_model=PaymentLinkListResponse)
async def list_payment_links(
    limit: int = 50,
    offset: int = 0,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
):
    """List merchant's payment links."""
    count_result = await db.execute(
        select(func.count(PaymentLink.id)).where(PaymentLink.merchant_id == merchant.id)
    )
    total = count_result.scalar_one()

    result = await db.execute(
        select(PaymentLink)
        .where(PaymentLink.merchant_id == merchant.id)
        .order_by(PaymentLink.created_at.desc())
        .limit(limit)
        .offset(offset)
    )
    links = result.scalars().all()

    checkout_base = settings.checkout_base_url.rstrip("/")

    return PaymentLinkListResponse(
        links=[
            PaymentLinkResponse(
                link_id=link.id,
                url=f"{checkout_base}/link/{link.slug}",
                slug=link.slug,
                name=link.name,
                amount=str(link.amount),
                currency=link.currency,
                status=link.status,
                total_payments=link.total_payments,
                created_at=link.created_at.isoformat(),
            )
            for link in links
        ],
        total=total,
    )


@router.get("/payment-links/{link_id}", response_model=PaymentLinkResponse)
async def get_payment_link(
    link_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
):
    """Get a payment link by ID."""
    result = await db.execute(
        select(PaymentLink).where(
            PaymentLink.id == link_id,
            PaymentLink.merchant_id == merchant.id,
        )
    )
    link = result.scalar_one_or_none()

    if link is None:
        raise HTTPException(status_code=404, detail="Payment link not found")

    checkout_base = settings.checkout_base_url.rstrip("/")

    return PaymentLinkResponse(
        link_id=link.id,
        url=f"{checkout_base}/link/{link.slug}",
        slug=link.slug,
        name=link.name,
        amount=str(link.amount),
        currency=link.currency,
        status=link.status,
        total_payments=link.total_payments,
        created_at=link.created_at.isoformat(),
    )


@router.delete("/payment-links/{link_id}", status_code=204)
async def deactivate_payment_link(
    link_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_db),
):
    """Deactivate a payment link (soft delete)."""
    result = await db.execute(
        select(PaymentLink).where(
            PaymentLink.id == link_id,
            PaymentLink.merchant_id == merchant.id,
        )
    )
    link = result.scalar_one_or_none()

    if link is None:
        raise HTTPException(status_code=404, detail="Payment link not found")

    link.status = "inactive"
    await db.commit()

    log.info("Payment link deactivated: link=%s merchant=%s", link.id, merchant.id)


@router.get("/pay/link/{slug}")
async def resolve_payment_link(
    slug: str,
    db: AsyncSession = Depends(get_db),
):
    """Resolve a payment link slug — public endpoint (no auth).

    Called by the checkout frontend when a customer visits a payment link URL.
    Creates a checkout session from the link's config and returns session details.
    """
    result = await db.execute(
        select(PaymentLink).where(PaymentLink.slug == slug, PaymentLink.status == "active")
    )
    link = result.scalar_one_or_none()

    if link is None:
        raise HTTPException(status_code=404, detail="Payment link not found or inactive")

    # Create a checkout session from this link
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=30)

    session = CheckoutSession(
        merchant_id=link.merchant_id,
        amount=link.amount,
        currency=link.currency,
        rail=link.rail,
        status="open",
        success_url=link.success_url or "",
        description=link.description,
        payment_link_id=link.id,
        expires_at=expires_at,
    )

    db.add(session)

    # Increment usage counter
    link.total_payments += 1

    await db.commit()
    await db.refresh(session)

    return {
        "session_id": session.id,
        "name": link.name,
        "description": link.description,
        "amount": str(link.amount),
        "currency": link.currency,
        "rail": link.rail,
        "expires_at": session.expires_at.isoformat(),
    }
