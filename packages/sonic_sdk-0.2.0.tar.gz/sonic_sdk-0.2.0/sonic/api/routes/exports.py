"""Transaction export and settlement reports — CSV/JSON with date filters."""

from __future__ import annotations

import csv
import io
from datetime import datetime, timezone
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy import select, func, case
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import get_read_db, get_merchant
from sonic.models.merchant import Merchant
from sonic.models.transaction import TransactionRecord

router = APIRouter()


# --- Transaction export ---


class TransactionExportRow(BaseModel):
    tx_id: str
    state: str
    inbound_amount: str
    inbound_currency: str
    inbound_rail: str
    treasury_amount: str | None
    treasury_asset: str
    outbound_amount: str | None
    outbound_currency: str | None
    outbound_rail: str | None
    customer_ref: str | None
    created_at: str
    updated_at: str


class TransactionExportResponse(BaseModel):
    transactions: list[TransactionExportRow]
    total: int
    exported_at: str
    filters: dict


@router.get("/transactions/export")
async def export_transactions(
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_read_db),
    format: str = Query(default="json", description="Export format: json or csv"),
    start: Optional[str] = Query(default=None, description="ISO-8601 start date"),
    end: Optional[str] = Query(default=None, description="ISO-8601 end date"),
    state: Optional[str] = Query(default=None, description="Filter by state"),
    currency: Optional[str] = Query(default=None, description="Filter by inbound currency"),
    limit: int = Query(default=5000, ge=1, le=10000),
):
    """Export transactions as JSON or CSV with date range and state filters."""
    query = select(TransactionRecord).where(
        TransactionRecord.merchant_id == merchant.id,
        TransactionRecord.archived_at.is_(None),
    )

    filters: dict = {}
    if start:
        query = query.where(TransactionRecord.created_at >= datetime.fromisoformat(start))
        filters["start"] = start
    if end:
        query = query.where(TransactionRecord.created_at <= datetime.fromisoformat(end))
        filters["end"] = end
    if state:
        query = query.where(TransactionRecord.state == state)
        filters["state"] = state
    if currency:
        query = query.where(TransactionRecord.inbound_currency == currency)
        filters["currency"] = currency

    result = await db.execute(
        query.order_by(TransactionRecord.created_at.desc()).limit(limit)
    )
    records = result.scalars().all()

    if format == "csv":
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow([
            "tx_id", "state", "inbound_amount", "inbound_currency", "inbound_rail",
            "treasury_amount", "treasury_asset", "outbound_amount", "outbound_currency",
            "outbound_rail", "customer_ref", "created_at", "updated_at",
        ])
        for r in records:
            writer.writerow([
                r.id, r.state, str(r.inbound_amount), r.inbound_currency, r.inbound_rail,
                str(r.treasury_amount) if r.treasury_amount else "",
                r.treasury_asset, str(r.outbound_amount) if r.outbound_amount else "",
                r.outbound_currency or "", r.outbound_rail or "",
                r.customer_ref or "", r.created_at.isoformat(), r.updated_at.isoformat(),
            ])
        buf.seek(0)
        return StreamingResponse(
            buf,
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=sonic-transactions-export.csv"},
        )

    # JSON format
    rows = [
        TransactionExportRow(
            tx_id=r.id,
            state=r.state,
            inbound_amount=str(r.inbound_amount),
            inbound_currency=r.inbound_currency,
            inbound_rail=r.inbound_rail,
            treasury_amount=str(r.treasury_amount) if r.treasury_amount else None,
            treasury_asset=r.treasury_asset,
            outbound_amount=str(r.outbound_amount) if r.outbound_amount else None,
            outbound_currency=r.outbound_currency,
            outbound_rail=r.outbound_rail,
            customer_ref=r.customer_ref,
            created_at=r.created_at.isoformat(),
            updated_at=r.updated_at.isoformat(),
        )
        for r in records
    ]

    return TransactionExportResponse(
        transactions=rows,
        total=len(rows),
        exported_at=datetime.now(timezone.utc).isoformat(),
        filters=filters,
    )


# --- Multi-currency settlement report ---


class CurrencyBreakdown(BaseModel):
    currency: str
    total_transactions: int
    total_inbound: str
    total_treasury: str
    total_outbound: str
    states: dict[str, int]


class SettlementReportResponse(BaseModel):
    merchant_id: str
    report_period: dict
    currencies: list[CurrencyBreakdown]
    totals: dict


@router.get("/reports/settlement", response_model=SettlementReportResponse)
async def get_settlement_report(
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_read_db),
    start: Optional[str] = Query(default=None, description="ISO-8601 start date"),
    end: Optional[str] = Query(default=None, description="ISO-8601 end date"),
):
    """Multi-currency settlement report with breakdowns by currency and state."""
    base_filter = [
        TransactionRecord.merchant_id == merchant.id,
        TransactionRecord.archived_at.is_(None),
    ]

    if start:
        base_filter.append(TransactionRecord.created_at >= datetime.fromisoformat(start))
    if end:
        base_filter.append(TransactionRecord.created_at <= datetime.fromisoformat(end))

    # Currency breakdown aggregation
    result = await db.execute(
        select(
            TransactionRecord.inbound_currency,
            TransactionRecord.state,
            func.count().label("count"),
            func.coalesce(func.sum(TransactionRecord.inbound_amount), 0).label("total_inbound"),
            func.coalesce(func.sum(TransactionRecord.treasury_amount), 0).label("total_treasury"),
            func.coalesce(func.sum(TransactionRecord.outbound_amount), 0).label("total_outbound"),
        )
        .where(*base_filter)
        .group_by(TransactionRecord.inbound_currency, TransactionRecord.state)
    )
    rows = result.all()

    # Build per-currency breakdown
    currency_data: dict[str, dict] = {}
    for currency, state, count, inbound, treasury, outbound in rows:
        if currency not in currency_data:
            currency_data[currency] = {
                "total_transactions": 0,
                "total_inbound": Decimal(0),
                "total_treasury": Decimal(0),
                "total_outbound": Decimal(0),
                "states": {},
            }
        cd = currency_data[currency]
        cd["total_transactions"] += count
        cd["total_inbound"] += inbound
        cd["total_treasury"] += treasury
        cd["total_outbound"] += outbound
        cd["states"][state] = count

    currencies = [
        CurrencyBreakdown(
            currency=cur,
            total_transactions=data["total_transactions"],
            total_inbound=f"{float(data['total_inbound']):,.6f}",
            total_treasury=f"{float(data['total_treasury']):,.6f}",
            total_outbound=f"{float(data['total_outbound']):,.6f}",
            states=data["states"],
        )
        for cur, data in sorted(currency_data.items())
    ]

    grand_tx = sum(c.total_transactions for c in currencies)
    grand_inbound = sum(float(data["total_inbound"]) for data in currency_data.values())
    grand_outbound = sum(float(data["total_outbound"]) for data in currency_data.values())

    return SettlementReportResponse(
        merchant_id=merchant.id,
        report_period={"start": start, "end": end},
        currencies=currencies,
        totals={
            "total_transactions": grand_tx,
            "total_inbound": f"{grand_inbound:,.6f}",
            "total_outbound": f"{grand_outbound:,.6f}",
        },
    )
