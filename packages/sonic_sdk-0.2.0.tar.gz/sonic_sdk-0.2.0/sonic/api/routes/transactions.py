"""Transaction endpoints — read transaction state, events, and finality."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.deps import get_db, get_read_db, get_merchant, get_finality_gate
from sonic.core.engine import TxState
from sonic.core.finality_gate import FinalityStatus
from sonic.models.event_log import EventLog
from sonic.models.merchant import Merchant
from sonic.models.transaction import TransactionRecord

router = APIRouter()


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class TransactionResponse(BaseModel):
    tx_id: str
    merchant_id: str
    state: str
    sequence: int
    inbound_amount: Decimal
    inbound_currency: str
    inbound_rail: str
    inbound_provider_ref: str | None = None
    treasury_amount: Decimal | None = None
    treasury_asset: str = "USDC"
    outbound_amount: Decimal | None = None
    outbound_currency: str | None = None
    outbound_rail: str | None = None
    outbound_provider_ref: str | None = None
    customer_ref: str | None = None
    created_at: datetime
    updated_at: datetime
    archived_at: datetime | None = None


class TransactionListResponse(BaseModel):
    transactions: list[TransactionResponse]
    total: int
    limit: int
    offset: int


class EventResponse(BaseModel):
    id: str
    tx_id: str
    event_type: str
    from_state: str | None = None
    to_state: str | None = None
    provider: str | None = None
    provider_ref: str | None = None
    receipt_hash: str | None = None
    payload: dict | None = None
    timestamp: datetime


class FinalityResponse(BaseModel):
    tx_id: str
    state: str
    rail: str
    finality_status: str
    hold_period_seconds: int
    reversible: bool
    reversible_window_seconds: int | None = None
    min_confirmations: int | None = None


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/transactions", response_model=TransactionListResponse)
async def list_transactions(
    state: str | None = Query(default=None, description="Filter by state"),
    include_archived: bool = Query(default=False, description="Include archived transactions"),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_read_db),
):
    """List transactions for the authenticated merchant."""
    query = select(TransactionRecord).where(
        TransactionRecord.merchant_id == merchant.id
    )
    count_query = select(func.count()).select_from(TransactionRecord).where(
        TransactionRecord.merchant_id == merchant.id
    )

    if state:
        query = query.where(TransactionRecord.state == state)
        count_query = count_query.where(TransactionRecord.state == state)

    if not include_archived:
        query = query.where(TransactionRecord.archived_at.is_(None))
        count_query = count_query.where(TransactionRecord.archived_at.is_(None))

    total_result = await db.execute(count_query)
    total = total_result.scalar_one()

    query = query.order_by(TransactionRecord.created_at.desc()).offset(offset).limit(limit)
    result = await db.execute(query)
    records = result.scalars().all()

    return TransactionListResponse(
        transactions=[
            TransactionResponse(
                tx_id=r.id,
                merchant_id=r.merchant_id,
                state=r.state,
                sequence=r.sequence,
                inbound_amount=r.inbound_amount,
                inbound_currency=r.inbound_currency,
                inbound_rail=r.inbound_rail,
                inbound_provider_ref=r.inbound_provider_ref,
                treasury_amount=r.treasury_amount,
                treasury_asset=r.treasury_asset,
                outbound_amount=r.outbound_amount,
                outbound_currency=r.outbound_currency,
                outbound_rail=r.outbound_rail,
                outbound_provider_ref=r.outbound_provider_ref,
                customer_ref=r.customer_ref,
                created_at=r.created_at,
                updated_at=r.updated_at,
                archived_at=r.archived_at,
            )
            for r in records
        ],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get("/transactions/{tx_id}", response_model=TransactionResponse)
async def get_transaction(
    tx_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_read_db),
):
    """Get a single transaction by ID."""
    result = await db.execute(
        select(TransactionRecord).where(
            TransactionRecord.id == tx_id,
            TransactionRecord.merchant_id == merchant.id,
        )
    )
    record = result.scalar_one_or_none()
    if record is None:
        raise HTTPException(status_code=404, detail="Transaction not found")

    return TransactionResponse(
        tx_id=record.id,
        merchant_id=record.merchant_id,
        state=record.state,
        sequence=record.sequence,
        inbound_amount=record.inbound_amount,
        inbound_currency=record.inbound_currency,
        inbound_rail=record.inbound_rail,
        inbound_provider_ref=record.inbound_provider_ref,
        treasury_amount=record.treasury_amount,
        treasury_asset=record.treasury_asset,
        outbound_amount=record.outbound_amount,
        outbound_currency=record.outbound_currency,
        outbound_rail=record.outbound_rail,
        outbound_provider_ref=record.outbound_provider_ref,
        customer_ref=record.customer_ref,
        created_at=record.created_at,
        updated_at=record.updated_at,
        archived_at=record.archived_at,
    )


@router.get("/transactions/{tx_id}/events", response_model=list[EventResponse])
async def get_transaction_events(
    tx_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_read_db),
):
    """Get the full event log for a transaction."""
    # Verify the transaction belongs to this merchant
    tx_result = await db.execute(
        select(TransactionRecord.id).where(
            TransactionRecord.id == tx_id,
            TransactionRecord.merchant_id == merchant.id,
        )
    )
    if tx_result.scalar_one_or_none() is None:
        raise HTTPException(status_code=404, detail="Transaction not found")

    result = await db.execute(
        select(EventLog)
        .where(EventLog.tx_id == tx_id)
        .order_by(EventLog.timestamp)
    )
    events = result.scalars().all()

    return [
        EventResponse(
            id=e.id,
            tx_id=e.tx_id,
            event_type=e.event_type,
            from_state=e.from_state,
            to_state=e.to_state,
            provider=e.provider,
            provider_ref=e.provider_ref,
            receipt_hash=e.receipt_hash,
            payload=e.payload,
            timestamp=e.timestamp,
        )
        for e in events
    ]


@router.get("/transactions/{tx_id}/finality", response_model=FinalityResponse)
async def get_transaction_finality(
    tx_id: str,
    merchant: Merchant = Depends(get_merchant),
    db: AsyncSession = Depends(get_read_db),
    finality_gate: Any = Depends(get_finality_gate),
):
    """Get finality status for a transaction based on its rail policy."""
    result = await db.execute(
        select(TransactionRecord).where(
            TransactionRecord.id == tx_id,
            TransactionRecord.merchant_id == merchant.id,
        )
    )
    record = result.scalar_one_or_none()
    if record is None:
        raise HTTPException(status_code=404, detail="Transaction not found")

    policy = finality_gate.get_policy(record.inbound_rail)

    # Determine current finality based on state
    state = TxState(record.state)
    if state in (TxState.RECEIVABLE_CLEARED, TxState.NORMALIZED, TxState.PAYOUT_PENDING,
                 TxState.PAYOUT_EXECUTED, TxState.SETTLED):
        finality_status = FinalityStatus.FINAL
    elif state == TxState.FINALITY_PENDING:
        finality_status = FinalityStatus.CONFIRMED
    elif state == TxState.REVERSED:
        finality_status = FinalityStatus.REVERSED
    else:
        finality_status = FinalityStatus.PENDING

    return FinalityResponse(
        tx_id=record.id,
        state=record.state,
        rail=record.inbound_rail,
        finality_status=finality_status.value,
        hold_period_seconds=int(policy.hold_period.total_seconds()),
        reversible=policy.reversible_window is not None,
        reversible_window_seconds=(
            int(policy.reversible_window.total_seconds()) if policy.reversible_window else None
        ),
        min_confirmations=policy.min_confirmations,
    )
