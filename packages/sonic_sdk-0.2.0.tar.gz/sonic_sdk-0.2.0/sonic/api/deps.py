"""Shared FastAPI dependencies for Sonic routes."""

from __future__ import annotations

import ipaddress
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from fastapi import Depends, Header, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from sonic.api.middleware.auth import verify_api_key, needs_rehash
from sonic.config import settings
from sonic.models.base import async_session_factory, read_session_factory
from sonic.models.merchant import Merchant
from sonic.models.user import DashboardUser

_deps_logger = logging.getLogger("sonic.deps")


async def get_db() -> AsyncSession:  # type: ignore[misc]
    """Yield an async DB session, auto-close on exit."""
    async with async_session_factory() as session:
        yield session


async def get_read_db() -> AsyncSession:  # type: ignore[misc]
    """Yield a read-only DB session (routes to replica when configured)."""
    async with read_session_factory() as session:
        yield session


async def get_merchant(
    request: Request,
    x_sonic_api_key: Optional[str] = Header(default=None, alias="x-sonic-api-key"),
    authorization: Optional[str] = Header(default=None),
    db: AsyncSession = Depends(get_db),
) -> Merchant:
    """Authenticate via API key OR JWT Bearer token and return the merchant.

    Supports two auth methods:
    - x-sonic-api-key header (server-to-server / SDK)
    - Authorization: Bearer <jwt> (dashboard sessions)
    """
    # --- Try JWT Bearer token first (dashboard auth) ---
    if authorization and authorization.startswith("Bearer "):
        import jwt as pyjwt

        token = authorization[7:]
        try:
            payload = pyjwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
        except pyjwt.ExpiredSignatureError:
            raise HTTPException(status_code=401, detail="Token expired")
        except pyjwt.InvalidTokenError:
            raise HTTPException(status_code=401, detail="Invalid token")

        # Reject refresh tokens used as access tokens
        if payload.get("type") not in (None, "access"):
            raise HTTPException(status_code=401, detail="Invalid token type")

        merchant_id = payload.get("merchant_id")
        if not merchant_id:
            raise HTTPException(status_code=403, detail="Token has no merchant_id — admin tokens cannot access merchant routes")

        result = await db.execute(
            select(Merchant).where(Merchant.id == merchant_id, Merchant.deleted_at.is_(None))
        )
        merchant = result.scalar_one_or_none()

        if merchant is None:
            raise HTTPException(status_code=404, detail="Merchant not found")
        if merchant.status != "active":
            raise HTTPException(status_code=403, detail="Merchant account is not active")

        return merchant

    # --- Fall back to API key auth ---
    if not x_sonic_api_key:
        raise HTTPException(status_code=401, detail="Missing authentication — provide x-sonic-api-key or Authorization header")

    prefix = x_sonic_api_key[:20]

    result = await db.execute(
        select(Merchant).where(Merchant.api_key_prefix == prefix, Merchant.deleted_at.is_(None))
    )
    merchant = result.scalar_one_or_none()

    # Try current key first
    key_valid = merchant is not None and verify_api_key(x_sonic_api_key, merchant.api_key_hash)

    # If current key fails, try the previous key (grace period rotation)
    if not key_valid and merchant is None:
        # Look up by prev_api_key_prefix (indexed, no full-table scan)
        prev_result = await db.execute(
            select(Merchant).where(
                Merchant.prev_api_key_prefix == prefix,
                Merchant.deleted_at.is_(None),
            )
        )
        prev_merchant = prev_result.scalar_one_or_none()
        if (
            prev_merchant
            and prev_merchant.prev_api_key_hash
            and verify_api_key(x_sonic_api_key, prev_merchant.prev_api_key_hash)
        ):
            if prev_merchant.key_rotated_at:
                grace_end = prev_merchant.key_rotated_at + timedelta(hours=settings.api_key_rotation_grace_hours)
                if datetime.now(timezone.utc) <= grace_end:
                    merchant = prev_merchant
                    key_valid = True
    elif not key_valid and merchant is not None and merchant.prev_api_key_hash:
        # Prefix matched but current key didn't — try previous key
        if verify_api_key(x_sonic_api_key, merchant.prev_api_key_hash):
            if merchant.key_rotated_at:
                grace_end = merchant.key_rotated_at + timedelta(hours=settings.api_key_rotation_grace_hours)
                if datetime.now(timezone.utc) <= grace_end:
                    key_valid = True
                else:
                    # Grace period expired — clear old key
                    merchant.prev_api_key_hash = None
                    merchant.prev_api_key_prefix = None
                    merchant.key_rotated_at = None
                    await db.commit()

    if not key_valid or merchant is None:
        raise HTTPException(status_code=401, detail="Invalid API key")

    if merchant.status != "active":
        raise HTTPException(status_code=403, detail="Merchant account is not active")

    # IP allowlist enforcement
    if settings.ip_allowlist_enabled and merchant.ip_allowlist:
        client_ip = request.client.host if request.client else None
        if not client_ip:
            raise HTTPException(status_code=403, detail="Cannot determine client IP for allowlist check")
        if client_ip:
            allowed = False
            for cidr in merchant.ip_allowlist.split(","):
                cidr = cidr.strip()
                if not cidr:
                    continue
                try:
                    if ipaddress.ip_address(client_ip) in ipaddress.ip_network(cidr, strict=False):
                        allowed = True
                        break
                except ValueError:
                    continue
            if not allowed:
                _deps_logger.warning(
                    "IP %s not in allowlist for merchant %s", client_ip, merchant.id
                )
                raise HTTPException(status_code=403, detail="Request IP not in allowlist")

    # Auto-rehash: upgrade legacy SHA-256 hashes to Argon2id on successful auth
    if needs_rehash(merchant.api_key_hash):
        try:
            from argon2 import PasswordHasher

            ph = PasswordHasher(time_cost=2, memory_cost=65536, parallelism=1, hash_len=32, salt_len=16)
            merchant.api_key_hash = ph.hash(x_sonic_api_key)
            await db.commit()
        except Exception:
            pass  # Non-critical — will retry next auth

    return merchant


# --- Service accessors (from app.state, populated by lifespan) ---


def get_emitter(request: Request) -> Any:
    return request.app.state.emitter


def get_attester(request: Request) -> Any | None:
    return getattr(request.app.state, "attester", None)


def get_payout_executor(request: Request) -> Any:
    return request.app.state.payout_executor


def get_treasury(request: Request) -> Any:
    return request.app.state.treasury


def get_finality_gate(request: Request) -> Any:
    return request.app.state.finality_gate


def get_providers(request: Request) -> dict[str, Any]:
    return request.app.state.providers


def get_redis(request: Request) -> Any | None:
    return getattr(request.app.state, "redis", None)


def get_idempotency(request: Request) -> Any | None:
    return getattr(request.app.state, "idempotency", None)


def get_sbn(request: Request) -> Any:
    return request.app.state.sbn


def get_verifier(request: Request) -> Any | None:
    return getattr(request.app.state, "verifier", None)


def get_anchor_service(request: Request) -> Any | None:
    return getattr(request.app.state, "anchor_service", None)


def get_combined_backfiller(request: Request) -> Any | None:
    return getattr(request.app.state, "combined_backfiller", None)


def get_coupler(request: Request) -> Any | None:
    return getattr(request.app.state, "coupler", None)


def get_stream_worker(request: Request) -> Any | None:
    return getattr(request.app.state, "stream_worker", None)


def get_normalizer(request: Request) -> Any | None:
    return getattr(request.app.state, "normalizer", None)


def get_settlement_poller(request: Request) -> Any | None:
    return getattr(request.app.state, "settlement_poller", None)


def get_execution_layer(request: Request) -> Any | None:
    """pgDAG execution layer (proof-gated workflow engine)."""
    return getattr(request.app.state, "execution_layer", None)


def get_runner(request: Request) -> Any | None:
    """pgDAG runner (shortcut to execution_layer.runner)."""
    layer = getattr(request.app.state, "execution_layer", None)
    return layer.runner if layer else None


def get_sonic_templates(request: Request) -> dict | None:
    """SONIC_TEMPLATES registry (DAGTemplate by name)."""
    return getattr(request.app.state, "sonic_templates", None)
