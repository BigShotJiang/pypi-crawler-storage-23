from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ExperimentCalendarDestroyRequest(_message.Message):
    __slots__ = ("experimentcalendar_id",)
    EXPERIMENTCALENDAR_ID_FIELD_NUMBER: _ClassVar[int]
    experimentcalendar_id: str
    def __init__(self, experimentcalendar_id: _Optional[str] = ...) -> None: ...

class ExperimentCalendarListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExperimentCalendarListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ExperimentCalendarResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ExperimentCalendarResponse, _Mapping]]] = ...) -> None: ...

class ExperimentCalendarPartialUpdateRequest(_message.Message):
    __slots__ = ("experimentcalendar_id", "user", "location", "geolocation", "project", "tags", "attendees", "_partial_update_fields", "name_display", "calendar_url", "summary", "description", "color", "ics", "datetime_start", "datetime_end", "duration", "all_day", "created", "datetime_last_modified", "timestamp", "conference_url", "range", "related", "role", "tzid", "offset_utc", "alarm_repeat_json", "event_repeat", "event_repeat_json", "search_vector", "experiment")
    EXPERIMENTCALENDAR_ID_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    GEOLOCATION_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    ATTENDEES_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    CALENDAR_URL_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    ICS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    ALL_DAY_FIELD_NUMBER: _ClassVar[int]
    CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    CONFERENCE_URL_FIELD_NUMBER: _ClassVar[int]
    RANGE_FIELD_NUMBER: _ClassVar[int]
    RELATED_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    TZID_FIELD_NUMBER: _ClassVar[int]
    OFFSET_UTC_FIELD_NUMBER: _ClassVar[int]
    ALARM_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
    experimentcalendar_id: str
    user: str
    location: str
    geolocation: str
    project: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    attendees: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    calendar_url: str
    summary: str
    description: str
    color: str
    ics: str
    datetime_start: str
    datetime_end: str
    duration: str
    all_day: bool
    created: str
    datetime_last_modified: str
    timestamp: str
    conference_url: str
    range: str
    related: str
    role: str
    tzid: str
    offset_utc: int
    alarm_repeat_json: _struct_pb2.Struct
    event_repeat: str
    event_repeat_json: _struct_pb2.Struct
    search_vector: str
    experiment: str
    def __init__(self, experimentcalendar_id: _Optional[str] = ..., user: _Optional[str] = ..., location: _Optional[str] = ..., geolocation: _Optional[str] = ..., project: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., attendees: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., calendar_url: _Optional[str] = ..., summary: _Optional[str] = ..., description: _Optional[str] = ..., color: _Optional[str] = ..., ics: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., duration: _Optional[str] = ..., all_day: bool = ..., created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., timestamp: _Optional[str] = ..., conference_url: _Optional[str] = ..., range: _Optional[str] = ..., related: _Optional[str] = ..., role: _Optional[str] = ..., tzid: _Optional[str] = ..., offset_utc: _Optional[int] = ..., alarm_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., event_repeat: _Optional[str] = ..., event_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., experiment: _Optional[str] = ...) -> None: ...

class ExperimentCalendarRequest(_message.Message):
    __slots__ = ("experimentcalendar_id", "user", "location", "geolocation", "project", "tags", "attendees", "name_display", "calendar_url", "summary", "description", "color", "ics", "datetime_start", "datetime_end", "duration", "all_day", "created", "datetime_last_modified", "timestamp", "conference_url", "range", "related", "role", "tzid", "offset_utc", "alarm_repeat_json", "event_repeat", "event_repeat_json", "search_vector", "experiment")
    EXPERIMENTCALENDAR_ID_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    GEOLOCATION_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    ATTENDEES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    CALENDAR_URL_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    ICS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    ALL_DAY_FIELD_NUMBER: _ClassVar[int]
    CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    CONFERENCE_URL_FIELD_NUMBER: _ClassVar[int]
    RANGE_FIELD_NUMBER: _ClassVar[int]
    RELATED_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    TZID_FIELD_NUMBER: _ClassVar[int]
    OFFSET_UTC_FIELD_NUMBER: _ClassVar[int]
    ALARM_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
    experimentcalendar_id: str
    user: str
    location: str
    geolocation: str
    project: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    attendees: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    calendar_url: str
    summary: str
    description: str
    color: str
    ics: str
    datetime_start: str
    datetime_end: str
    duration: str
    all_day: bool
    created: str
    datetime_last_modified: str
    timestamp: str
    conference_url: str
    range: str
    related: str
    role: str
    tzid: str
    offset_utc: int
    alarm_repeat_json: _struct_pb2.Struct
    event_repeat: str
    event_repeat_json: _struct_pb2.Struct
    search_vector: str
    experiment: str
    def __init__(self, experimentcalendar_id: _Optional[str] = ..., user: _Optional[str] = ..., location: _Optional[str] = ..., geolocation: _Optional[str] = ..., project: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., attendees: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., calendar_url: _Optional[str] = ..., summary: _Optional[str] = ..., description: _Optional[str] = ..., color: _Optional[str] = ..., ics: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., duration: _Optional[str] = ..., all_day: bool = ..., created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., timestamp: _Optional[str] = ..., conference_url: _Optional[str] = ..., range: _Optional[str] = ..., related: _Optional[str] = ..., role: _Optional[str] = ..., tzid: _Optional[str] = ..., offset_utc: _Optional[int] = ..., alarm_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., event_repeat: _Optional[str] = ..., event_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., experiment: _Optional[str] = ...) -> None: ...

class ExperimentCalendarResponse(_message.Message):
    __slots__ = ("experimentcalendar_id", "user", "location", "geolocation", "project", "tags", "attendees", "name_display", "calendar_url", "summary", "description", "color", "ics", "datetime_start", "datetime_end", "duration", "all_day", "created", "datetime_last_modified", "timestamp", "conference_url", "range", "related", "role", "tzid", "offset_utc", "alarm_repeat_json", "event_repeat", "event_repeat_json", "search_vector", "experiment")
    EXPERIMENTCALENDAR_ID_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    GEOLOCATION_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    ATTENDEES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    CALENDAR_URL_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    ICS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    ALL_DAY_FIELD_NUMBER: _ClassVar[int]
    CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    CONFERENCE_URL_FIELD_NUMBER: _ClassVar[int]
    RANGE_FIELD_NUMBER: _ClassVar[int]
    RELATED_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    TZID_FIELD_NUMBER: _ClassVar[int]
    OFFSET_UTC_FIELD_NUMBER: _ClassVar[int]
    ALARM_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
    experimentcalendar_id: str
    user: str
    location: str
    geolocation: str
    project: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    attendees: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    calendar_url: str
    summary: str
    description: str
    color: str
    ics: str
    datetime_start: str
    datetime_end: str
    duration: str
    all_day: bool
    created: str
    datetime_last_modified: str
    timestamp: str
    conference_url: str
    range: str
    related: str
    role: str
    tzid: str
    offset_utc: int
    alarm_repeat_json: _struct_pb2.Struct
    event_repeat: str
    event_repeat_json: _struct_pb2.Struct
    search_vector: str
    experiment: str
    def __init__(self, experimentcalendar_id: _Optional[str] = ..., user: _Optional[str] = ..., location: _Optional[str] = ..., geolocation: _Optional[str] = ..., project: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., attendees: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., calendar_url: _Optional[str] = ..., summary: _Optional[str] = ..., description: _Optional[str] = ..., color: _Optional[str] = ..., ics: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., duration: _Optional[str] = ..., all_day: bool = ..., created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., timestamp: _Optional[str] = ..., conference_url: _Optional[str] = ..., range: _Optional[str] = ..., related: _Optional[str] = ..., role: _Optional[str] = ..., tzid: _Optional[str] = ..., offset_utc: _Optional[int] = ..., alarm_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., event_repeat: _Optional[str] = ..., event_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., experiment: _Optional[str] = ...) -> None: ...

class ExperimentCalendarRetrieveRequest(_message.Message):
    __slots__ = ("experimentcalendar_id",)
    EXPERIMENTCALENDAR_ID_FIELD_NUMBER: _ClassVar[int]
    experimentcalendar_id: str
    def __init__(self, experimentcalendar_id: _Optional[str] = ...) -> None: ...

class ExperimentCalendarStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExperimentDestroyRequest(_message.Message):
    __slots__ = ("experiment_id",)
    EXPERIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    experiment_id: str
    def __init__(self, experiment_id: _Optional[str] = ...) -> None: ...

class ExperimentListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExperimentListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ExperimentResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ExperimentResponse, _Mapping]]] = ...) -> None: ...

class ExperimentPartialUpdateRequest(_message.Message):
    __slots__ = ("experiment_id", "namespace", "entities", "groups", "parent", "experiment_design", "experiment_base", "status", "outcome", "data", "evaluations", "method_instances", "process_instances", "procedure_instances", "substance_instances", "polymer_instances", "mixture_instances", "organism_instances", "part_instances", "device_instances", "device_setup_instances", "labware_instances", "samples", "reference_experiment", "resources_external", "tags", "_partial_update_fields", "name_display", "name", "version", "pac_id", "acl", "hash_sha256", "datetime_start", "datetime_added", "datetime_end", "datetime_last_modified", "priority", "timeline", "milestones", "description", "hypothesis_json", "hypothesis", "objectives_json", "risks_json", "budget", "results_json", "remarks", "color", "iri", "pid", "search_vector", "parameters", "observations", "observations_json", "tasks")
    EXPERIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    PARENT_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_DESIGN_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_BASE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    EVALUATIONS_FIELD_NUMBER: _ClassVar[int]
    METHOD_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PROCESS_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PART_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUP_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    REFERENCE_EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    ACL_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ADDED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    TIMELINE_FIELD_NUMBER: _ClassVar[int]
    MILESTONES_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    HYPOTHESIS_JSON_FIELD_NUMBER: _ClassVar[int]
    HYPOTHESIS_FIELD_NUMBER: _ClassVar[int]
    OBJECTIVES_JSON_FIELD_NUMBER: _ClassVar[int]
    RISKS_JSON_FIELD_NUMBER: _ClassVar[int]
    BUDGET_FIELD_NUMBER: _ClassVar[int]
    RESULTS_JSON_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    OBSERVATIONS_FIELD_NUMBER: _ClassVar[int]
    OBSERVATIONS_JSON_FIELD_NUMBER: _ClassVar[int]
    TASKS_FIELD_NUMBER: _ClassVar[int]
    experiment_id: str
    namespace: str
    entities: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    parent: str
    experiment_design: str
    experiment_base: str
    status: str
    outcome: str
    data: _containers.RepeatedScalarFieldContainer[str]
    evaluations: _containers.RepeatedScalarFieldContainer[str]
    method_instances: _containers.RepeatedScalarFieldContainer[str]
    process_instances: _containers.RepeatedScalarFieldContainer[str]
    procedure_instances: _containers.RepeatedScalarFieldContainer[str]
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    part_instances: _containers.RepeatedScalarFieldContainer[str]
    device_instances: _containers.RepeatedScalarFieldContainer[str]
    device_setup_instances: _containers.RepeatedScalarFieldContainer[str]
    labware_instances: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    reference_experiment: str
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    version: str
    pac_id: str
    acl: _struct_pb2.Struct
    hash_sha256: str
    datetime_start: str
    datetime_added: str
    datetime_end: str
    datetime_last_modified: str
    priority: float
    timeline: _struct_pb2.Struct
    milestones: _struct_pb2.Struct
    description: str
    hypothesis_json: _struct_pb2.Struct
    hypothesis: str
    objectives_json: _struct_pb2.Struct
    risks_json: _struct_pb2.Struct
    budget: _struct_pb2.Struct
    results_json: _struct_pb2.Struct
    remarks: str
    color: str
    iri: str
    pid: str
    search_vector: str
    parameters: _struct_pb2.Struct
    observations: str
    observations_json: _struct_pb2.Struct
    tasks: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, experiment_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entities: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., parent: _Optional[str] = ..., experiment_design: _Optional[str] = ..., experiment_base: _Optional[str] = ..., status: _Optional[str] = ..., outcome: _Optional[str] = ..., data: _Optional[_Iterable[str]] = ..., evaluations: _Optional[_Iterable[str]] = ..., method_instances: _Optional[_Iterable[str]] = ..., process_instances: _Optional[_Iterable[str]] = ..., procedure_instances: _Optional[_Iterable[str]] = ..., substance_instances: _Optional[_Iterable[str]] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., organism_instances: _Optional[_Iterable[str]] = ..., part_instances: _Optional[_Iterable[str]] = ..., device_instances: _Optional[_Iterable[str]] = ..., device_setup_instances: _Optional[_Iterable[str]] = ..., labware_instances: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., reference_experiment: _Optional[str] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., version: _Optional[str] = ..., pac_id: _Optional[str] = ..., acl: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_added: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., priority: _Optional[float] = ..., timeline: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., milestones: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., hypothesis_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hypothesis: _Optional[str] = ..., objectives_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., risks_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., budget: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., results_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., remarks: _Optional[str] = ..., color: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., search_vector: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., observations: _Optional[str] = ..., observations_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., tasks: _Optional[_Iterable[str]] = ...) -> None: ...

class ExperimentRequest(_message.Message):
    __slots__ = ("experiment_id", "namespace", "entities", "groups", "parent", "experiment_design", "experiment_base", "status", "outcome", "data", "evaluations", "method_instances", "process_instances", "procedure_instances", "substance_instances", "polymer_instances", "mixture_instances", "organism_instances", "part_instances", "device_instances", "device_setup_instances", "labware_instances", "samples", "reference_experiment", "resources_external", "tags", "name_display", "name", "version", "pac_id", "acl", "hash_sha256", "datetime_start", "datetime_added", "datetime_end", "datetime_last_modified", "priority", "timeline", "milestones", "description", "hypothesis_json", "hypothesis", "objectives_json", "risks_json", "budget", "results_json", "remarks", "color", "iri", "pid", "search_vector", "parameters", "observations", "observations_json", "tasks")
    EXPERIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    PARENT_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_DESIGN_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_BASE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    EVALUATIONS_FIELD_NUMBER: _ClassVar[int]
    METHOD_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PROCESS_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PART_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUP_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    REFERENCE_EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    ACL_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ADDED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    TIMELINE_FIELD_NUMBER: _ClassVar[int]
    MILESTONES_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    HYPOTHESIS_JSON_FIELD_NUMBER: _ClassVar[int]
    HYPOTHESIS_FIELD_NUMBER: _ClassVar[int]
    OBJECTIVES_JSON_FIELD_NUMBER: _ClassVar[int]
    RISKS_JSON_FIELD_NUMBER: _ClassVar[int]
    BUDGET_FIELD_NUMBER: _ClassVar[int]
    RESULTS_JSON_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    OBSERVATIONS_FIELD_NUMBER: _ClassVar[int]
    OBSERVATIONS_JSON_FIELD_NUMBER: _ClassVar[int]
    TASKS_FIELD_NUMBER: _ClassVar[int]
    experiment_id: str
    namespace: str
    entities: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    parent: str
    experiment_design: str
    experiment_base: str
    status: str
    outcome: str
    data: _containers.RepeatedScalarFieldContainer[str]
    evaluations: _containers.RepeatedScalarFieldContainer[str]
    method_instances: _containers.RepeatedScalarFieldContainer[str]
    process_instances: _containers.RepeatedScalarFieldContainer[str]
    procedure_instances: _containers.RepeatedScalarFieldContainer[str]
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    part_instances: _containers.RepeatedScalarFieldContainer[str]
    device_instances: _containers.RepeatedScalarFieldContainer[str]
    device_setup_instances: _containers.RepeatedScalarFieldContainer[str]
    labware_instances: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    reference_experiment: str
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    version: str
    pac_id: str
    acl: _struct_pb2.Struct
    hash_sha256: str
    datetime_start: str
    datetime_added: str
    datetime_end: str
    datetime_last_modified: str
    priority: float
    timeline: _struct_pb2.Struct
    milestones: _struct_pb2.Struct
    description: str
    hypothesis_json: _struct_pb2.Struct
    hypothesis: str
    objectives_json: _struct_pb2.Struct
    risks_json: _struct_pb2.Struct
    budget: _struct_pb2.Struct
    results_json: _struct_pb2.Struct
    remarks: str
    color: str
    iri: str
    pid: str
    search_vector: str
    parameters: _struct_pb2.Struct
    observations: str
    observations_json: _struct_pb2.Struct
    tasks: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, experiment_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entities: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., parent: _Optional[str] = ..., experiment_design: _Optional[str] = ..., experiment_base: _Optional[str] = ..., status: _Optional[str] = ..., outcome: _Optional[str] = ..., data: _Optional[_Iterable[str]] = ..., evaluations: _Optional[_Iterable[str]] = ..., method_instances: _Optional[_Iterable[str]] = ..., process_instances: _Optional[_Iterable[str]] = ..., procedure_instances: _Optional[_Iterable[str]] = ..., substance_instances: _Optional[_Iterable[str]] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., organism_instances: _Optional[_Iterable[str]] = ..., part_instances: _Optional[_Iterable[str]] = ..., device_instances: _Optional[_Iterable[str]] = ..., device_setup_instances: _Optional[_Iterable[str]] = ..., labware_instances: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., reference_experiment: _Optional[str] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., version: _Optional[str] = ..., pac_id: _Optional[str] = ..., acl: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_added: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., priority: _Optional[float] = ..., timeline: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., milestones: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., hypothesis_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hypothesis: _Optional[str] = ..., objectives_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., risks_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., budget: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., results_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., remarks: _Optional[str] = ..., color: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., search_vector: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., observations: _Optional[str] = ..., observations_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., tasks: _Optional[_Iterable[str]] = ...) -> None: ...

class ExperimentResponse(_message.Message):
    __slots__ = ("experiment_id", "namespace", "entities", "groups", "parent", "experiment_design", "experiment_base", "status", "outcome", "data", "evaluations", "method_instances", "process_instances", "procedure_instances", "substance_instances", "polymer_instances", "mixture_instances", "organism_instances", "part_instances", "device_instances", "device_setup_instances", "labware_instances", "samples", "reference_experiment", "resources_external", "tags", "name_display", "name", "version", "pac_id", "acl", "hash_sha256", "datetime_start", "datetime_added", "datetime_end", "datetime_last_modified", "priority", "timeline", "milestones", "description", "hypothesis_json", "hypothesis", "objectives_json", "risks_json", "budget", "results_json", "remarks", "color", "iri", "pid", "search_vector", "parameters", "observations", "observations_json", "lft", "rght", "tree_id", "level", "tasks")
    EXPERIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    PARENT_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_DESIGN_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_BASE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    EVALUATIONS_FIELD_NUMBER: _ClassVar[int]
    METHOD_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PROCESS_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PART_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUP_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    REFERENCE_EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    ACL_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ADDED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    TIMELINE_FIELD_NUMBER: _ClassVar[int]
    MILESTONES_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    HYPOTHESIS_JSON_FIELD_NUMBER: _ClassVar[int]
    HYPOTHESIS_FIELD_NUMBER: _ClassVar[int]
    OBJECTIVES_JSON_FIELD_NUMBER: _ClassVar[int]
    RISKS_JSON_FIELD_NUMBER: _ClassVar[int]
    BUDGET_FIELD_NUMBER: _ClassVar[int]
    RESULTS_JSON_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    OBSERVATIONS_FIELD_NUMBER: _ClassVar[int]
    OBSERVATIONS_JSON_FIELD_NUMBER: _ClassVar[int]
    LFT_FIELD_NUMBER: _ClassVar[int]
    RGHT_FIELD_NUMBER: _ClassVar[int]
    TREE_ID_FIELD_NUMBER: _ClassVar[int]
    LEVEL_FIELD_NUMBER: _ClassVar[int]
    TASKS_FIELD_NUMBER: _ClassVar[int]
    experiment_id: str
    namespace: str
    entities: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    parent: str
    experiment_design: str
    experiment_base: str
    status: str
    outcome: str
    data: _containers.RepeatedScalarFieldContainer[str]
    evaluations: _containers.RepeatedScalarFieldContainer[str]
    method_instances: _containers.RepeatedScalarFieldContainer[str]
    process_instances: _containers.RepeatedScalarFieldContainer[str]
    procedure_instances: _containers.RepeatedScalarFieldContainer[str]
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    part_instances: _containers.RepeatedScalarFieldContainer[str]
    device_instances: _containers.RepeatedScalarFieldContainer[str]
    device_setup_instances: _containers.RepeatedScalarFieldContainer[str]
    labware_instances: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    reference_experiment: str
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    version: str
    pac_id: str
    acl: _struct_pb2.Struct
    hash_sha256: str
    datetime_start: str
    datetime_added: str
    datetime_end: str
    datetime_last_modified: str
    priority: float
    timeline: _struct_pb2.Struct
    milestones: _struct_pb2.Struct
    description: str
    hypothesis_json: _struct_pb2.Struct
    hypothesis: str
    objectives_json: _struct_pb2.Struct
    risks_json: _struct_pb2.Struct
    budget: _struct_pb2.Struct
    results_json: _struct_pb2.Struct
    remarks: str
    color: str
    iri: str
    pid: str
    search_vector: str
    parameters: _struct_pb2.Struct
    observations: str
    observations_json: _struct_pb2.Struct
    lft: int
    rght: int
    tree_id: int
    level: int
    tasks: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, experiment_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entities: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., parent: _Optional[str] = ..., experiment_design: _Optional[str] = ..., experiment_base: _Optional[str] = ..., status: _Optional[str] = ..., outcome: _Optional[str] = ..., data: _Optional[_Iterable[str]] = ..., evaluations: _Optional[_Iterable[str]] = ..., method_instances: _Optional[_Iterable[str]] = ..., process_instances: _Optional[_Iterable[str]] = ..., procedure_instances: _Optional[_Iterable[str]] = ..., substance_instances: _Optional[_Iterable[str]] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., organism_instances: _Optional[_Iterable[str]] = ..., part_instances: _Optional[_Iterable[str]] = ..., device_instances: _Optional[_Iterable[str]] = ..., device_setup_instances: _Optional[_Iterable[str]] = ..., labware_instances: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., reference_experiment: _Optional[str] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., version: _Optional[str] = ..., pac_id: _Optional[str] = ..., acl: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_added: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., priority: _Optional[float] = ..., timeline: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., milestones: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., hypothesis_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hypothesis: _Optional[str] = ..., objectives_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., risks_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., budget: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., results_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., remarks: _Optional[str] = ..., color: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., search_vector: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., observations: _Optional[str] = ..., observations_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., lft: _Optional[int] = ..., rght: _Optional[int] = ..., tree_id: _Optional[int] = ..., level: _Optional[int] = ..., tasks: _Optional[_Iterable[str]] = ...) -> None: ...

class ExperimentRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ExperimentRetrieveRequest(_message.Message):
    __slots__ = ("experiment_id",)
    EXPERIMENT_ID_FIELD_NUMBER: _ClassVar[int]
    experiment_id: str
    def __init__(self, experiment_id: _Optional[str] = ...) -> None: ...

class ExperimentStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExperimentsSubsetDestroyRequest(_message.Message):
    __slots__ = ("experimentselection_id",)
    EXPERIMENTSELECTION_ID_FIELD_NUMBER: _ClassVar[int]
    experimentselection_id: str
    def __init__(self, experimentselection_id: _Optional[str] = ...) -> None: ...

class ExperimentsSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExperimentsSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ExperimentsSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ExperimentsSubsetResponse, _Mapping]]] = ...) -> None: ...

class ExperimentsSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("experimentselection_id", "namespace", "entity", "selected_items", "_partial_update_fields", "name_display", "name", "description", "datetime_last_modified", "group", "tags")
    EXPERIMENTSELECTION_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    SELECTED_ITEMS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    experimentselection_id: str
    namespace: str
    entity: str
    selected_items: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    description: str
    datetime_last_modified: str
    group: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, experimentselection_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entity: _Optional[str] = ..., selected_items: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., group: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ...) -> None: ...

class ExperimentsSubsetRequest(_message.Message):
    __slots__ = ("experimentselection_id", "namespace", "entity", "selected_items", "name_display", "name", "description", "datetime_last_modified", "group", "tags")
    EXPERIMENTSELECTION_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    SELECTED_ITEMS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    experimentselection_id: str
    namespace: str
    entity: str
    selected_items: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    description: str
    datetime_last_modified: str
    group: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, experimentselection_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entity: _Optional[str] = ..., selected_items: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., group: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ...) -> None: ...

class ExperimentsSubsetResponse(_message.Message):
    __slots__ = ("experimentselection_id", "namespace", "entity", "selected_items", "name_display", "name", "description", "datetime_last_modified", "group", "tags", "experiments")
    EXPERIMENTSELECTION_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    SELECTED_ITEMS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENTS_FIELD_NUMBER: _ClassVar[int]
    experimentselection_id: str
    namespace: str
    entity: str
    selected_items: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    description: str
    datetime_last_modified: str
    group: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    experiments: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, experimentselection_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entity: _Optional[str] = ..., selected_items: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., group: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., experiments: _Optional[_Iterable[str]] = ...) -> None: ...

class ExperimentsSubsetRetrieveRequest(_message.Message):
    __slots__ = ("experimentselection_id",)
    EXPERIMENTSELECTION_ID_FIELD_NUMBER: _ClassVar[int]
    experimentselection_id: str
    def __init__(self, experimentselection_id: _Optional[str] = ...) -> None: ...

class ExperimentsSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class FileDownloadChunk(_message.Message):
    __slots__ = ("filename", "data", "success")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename: str
    data: bytes
    success: bool
    def __init__(self, filename: _Optional[str] = ..., data: _Optional[bytes] = ..., success: bool = ...) -> None: ...

class FileDownloadInfo(_message.Message):
    __slots__ = ("item_id", "chunk_size")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: _Optional[str] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class FileUploadChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class FileUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class ImageDownloadChunk(_message.Message):
    __slots__ = ("filename_image", "data", "success")
    FILENAME_IMAGE_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename_image: str
    data: bytes
    success: bool
    def __init__(self, filename_image: _Optional[str] = ..., data: _Optional[bytes] = ..., success: bool = ...) -> None: ...

class ImageDownloadInfo(_message.Message):
    __slots__ = ("item_id", "chunk_size")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: _Optional[str] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class ImageUploadChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class ImageUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class ProjectCalendarDestroyRequest(_message.Message):
    __slots__ = ("projectcalendar_id",)
    PROJECTCALENDAR_ID_FIELD_NUMBER: _ClassVar[int]
    projectcalendar_id: str
    def __init__(self, projectcalendar_id: _Optional[str] = ...) -> None: ...

class ProjectCalendarListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProjectCalendarListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ProjectCalendarResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ProjectCalendarResponse, _Mapping]]] = ...) -> None: ...

class ProjectCalendarPartialUpdateRequest(_message.Message):
    __slots__ = ("projectcalendar_id", "user", "location", "geolocation", "project", "tags", "attendees", "_partial_update_fields", "name_display", "calendar_url", "summary", "description", "color", "ics", "datetime_start", "datetime_end", "duration", "all_day", "created", "datetime_last_modified", "timestamp", "conference_url", "range", "related", "role", "tzid", "offset_utc", "alarm_repeat_json", "event_repeat", "event_repeat_json", "search_vector")
    PROJECTCALENDAR_ID_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    GEOLOCATION_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    ATTENDEES_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    CALENDAR_URL_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    ICS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    ALL_DAY_FIELD_NUMBER: _ClassVar[int]
    CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    CONFERENCE_URL_FIELD_NUMBER: _ClassVar[int]
    RANGE_FIELD_NUMBER: _ClassVar[int]
    RELATED_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    TZID_FIELD_NUMBER: _ClassVar[int]
    OFFSET_UTC_FIELD_NUMBER: _ClassVar[int]
    ALARM_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    projectcalendar_id: str
    user: str
    location: str
    geolocation: str
    project: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    attendees: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    calendar_url: str
    summary: str
    description: str
    color: str
    ics: str
    datetime_start: str
    datetime_end: str
    duration: str
    all_day: bool
    created: str
    datetime_last_modified: str
    timestamp: str
    conference_url: str
    range: str
    related: str
    role: str
    tzid: str
    offset_utc: int
    alarm_repeat_json: _struct_pb2.Struct
    event_repeat: str
    event_repeat_json: _struct_pb2.Struct
    search_vector: str
    def __init__(self, projectcalendar_id: _Optional[str] = ..., user: _Optional[str] = ..., location: _Optional[str] = ..., geolocation: _Optional[str] = ..., project: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., attendees: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., calendar_url: _Optional[str] = ..., summary: _Optional[str] = ..., description: _Optional[str] = ..., color: _Optional[str] = ..., ics: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., duration: _Optional[str] = ..., all_day: bool = ..., created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., timestamp: _Optional[str] = ..., conference_url: _Optional[str] = ..., range: _Optional[str] = ..., related: _Optional[str] = ..., role: _Optional[str] = ..., tzid: _Optional[str] = ..., offset_utc: _Optional[int] = ..., alarm_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., event_repeat: _Optional[str] = ..., event_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ProjectCalendarRequest(_message.Message):
    __slots__ = ("projectcalendar_id", "user", "location", "geolocation", "project", "tags", "attendees", "name_display", "calendar_url", "summary", "description", "color", "ics", "datetime_start", "datetime_end", "duration", "all_day", "created", "datetime_last_modified", "timestamp", "conference_url", "range", "related", "role", "tzid", "offset_utc", "alarm_repeat_json", "event_repeat", "event_repeat_json", "search_vector")
    PROJECTCALENDAR_ID_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    GEOLOCATION_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    ATTENDEES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    CALENDAR_URL_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    ICS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    ALL_DAY_FIELD_NUMBER: _ClassVar[int]
    CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    CONFERENCE_URL_FIELD_NUMBER: _ClassVar[int]
    RANGE_FIELD_NUMBER: _ClassVar[int]
    RELATED_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    TZID_FIELD_NUMBER: _ClassVar[int]
    OFFSET_UTC_FIELD_NUMBER: _ClassVar[int]
    ALARM_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    projectcalendar_id: str
    user: str
    location: str
    geolocation: str
    project: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    attendees: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    calendar_url: str
    summary: str
    description: str
    color: str
    ics: str
    datetime_start: str
    datetime_end: str
    duration: str
    all_day: bool
    created: str
    datetime_last_modified: str
    timestamp: str
    conference_url: str
    range: str
    related: str
    role: str
    tzid: str
    offset_utc: int
    alarm_repeat_json: _struct_pb2.Struct
    event_repeat: str
    event_repeat_json: _struct_pb2.Struct
    search_vector: str
    def __init__(self, projectcalendar_id: _Optional[str] = ..., user: _Optional[str] = ..., location: _Optional[str] = ..., geolocation: _Optional[str] = ..., project: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., attendees: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., calendar_url: _Optional[str] = ..., summary: _Optional[str] = ..., description: _Optional[str] = ..., color: _Optional[str] = ..., ics: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., duration: _Optional[str] = ..., all_day: bool = ..., created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., timestamp: _Optional[str] = ..., conference_url: _Optional[str] = ..., range: _Optional[str] = ..., related: _Optional[str] = ..., role: _Optional[str] = ..., tzid: _Optional[str] = ..., offset_utc: _Optional[int] = ..., alarm_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., event_repeat: _Optional[str] = ..., event_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ProjectCalendarResponse(_message.Message):
    __slots__ = ("projectcalendar_id", "user", "location", "geolocation", "project", "tags", "attendees", "name_display", "calendar_url", "summary", "description", "color", "ics", "datetime_start", "datetime_end", "duration", "all_day", "created", "datetime_last_modified", "timestamp", "conference_url", "range", "related", "role", "tzid", "offset_utc", "alarm_repeat_json", "event_repeat", "event_repeat_json", "search_vector")
    PROJECTCALENDAR_ID_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    GEOLOCATION_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    ATTENDEES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    CALENDAR_URL_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    ICS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DURATION_FIELD_NUMBER: _ClassVar[int]
    ALL_DAY_FIELD_NUMBER: _ClassVar[int]
    CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    CONFERENCE_URL_FIELD_NUMBER: _ClassVar[int]
    RANGE_FIELD_NUMBER: _ClassVar[int]
    RELATED_FIELD_NUMBER: _ClassVar[int]
    ROLE_FIELD_NUMBER: _ClassVar[int]
    TZID_FIELD_NUMBER: _ClassVar[int]
    OFFSET_UTC_FIELD_NUMBER: _ClassVar[int]
    ALARM_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    projectcalendar_id: str
    user: str
    location: str
    geolocation: str
    project: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    attendees: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    calendar_url: str
    summary: str
    description: str
    color: str
    ics: str
    datetime_start: str
    datetime_end: str
    duration: str
    all_day: bool
    created: str
    datetime_last_modified: str
    timestamp: str
    conference_url: str
    range: str
    related: str
    role: str
    tzid: str
    offset_utc: int
    alarm_repeat_json: _struct_pb2.Struct
    event_repeat: str
    event_repeat_json: _struct_pb2.Struct
    search_vector: str
    def __init__(self, projectcalendar_id: _Optional[str] = ..., user: _Optional[str] = ..., location: _Optional[str] = ..., geolocation: _Optional[str] = ..., project: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., attendees: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., calendar_url: _Optional[str] = ..., summary: _Optional[str] = ..., description: _Optional[str] = ..., color: _Optional[str] = ..., ics: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., duration: _Optional[str] = ..., all_day: bool = ..., created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., timestamp: _Optional[str] = ..., conference_url: _Optional[str] = ..., range: _Optional[str] = ..., related: _Optional[str] = ..., role: _Optional[str] = ..., tzid: _Optional[str] = ..., offset_utc: _Optional[int] = ..., alarm_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., event_repeat: _Optional[str] = ..., event_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ProjectCalendarRetrieveRequest(_message.Message):
    __slots__ = ("projectcalendar_id",)
    PROJECTCALENDAR_ID_FIELD_NUMBER: _ClassVar[int]
    projectcalendar_id: str
    def __init__(self, projectcalendar_id: _Optional[str] = ...) -> None: ...

class ProjectCalendarStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProjectDestroyRequest(_message.Message):
    __slots__ = ("project_id",)
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    def __init__(self, project_id: _Optional[str] = ...) -> None: ...

class ProjectListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProjectListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ProjectResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ProjectResponse, _Mapping]]] = ...) -> None: ...

class ProjectPartialUpdateRequest(_message.Message):
    __slots__ = ("project_id", "namespace", "entities", "groups", "parent", "status", "outcome", "experiments", "resources_external", "tags", "_partial_update_fields", "name_display", "name", "version", "pac_id", "acl", "hash_sha256", "datetime_start", "datetime_added", "datetime_end", "datetime_last_modified", "priority", "timeline", "milestones", "description", "hypothesis_json", "hypothesis", "objectives_json", "risks_json", "budget", "results_json", "remarks", "color", "iri", "pid", "search_vector", "project_base", "tasks", "data", "evaluations")
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    PARENT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENTS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    ACL_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ADDED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    TIMELINE_FIELD_NUMBER: _ClassVar[int]
    MILESTONES_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    HYPOTHESIS_JSON_FIELD_NUMBER: _ClassVar[int]
    HYPOTHESIS_FIELD_NUMBER: _ClassVar[int]
    OBJECTIVES_JSON_FIELD_NUMBER: _ClassVar[int]
    RISKS_JSON_FIELD_NUMBER: _ClassVar[int]
    BUDGET_FIELD_NUMBER: _ClassVar[int]
    RESULTS_JSON_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PROJECT_BASE_FIELD_NUMBER: _ClassVar[int]
    TASKS_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    EVALUATIONS_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    namespace: str
    entities: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    parent: str
    status: str
    outcome: str
    experiments: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    version: str
    pac_id: str
    acl: _struct_pb2.Struct
    hash_sha256: str
    datetime_start: str
    datetime_added: str
    datetime_end: str
    datetime_last_modified: str
    priority: float
    timeline: _struct_pb2.Struct
    milestones: _struct_pb2.Struct
    description: str
    hypothesis_json: _struct_pb2.Struct
    hypothesis: str
    objectives_json: _struct_pb2.Struct
    risks_json: _struct_pb2.Struct
    budget: _struct_pb2.Struct
    results_json: _struct_pb2.Struct
    remarks: str
    color: str
    iri: str
    pid: str
    search_vector: str
    project_base: str
    tasks: _containers.RepeatedScalarFieldContainer[str]
    data: _containers.RepeatedScalarFieldContainer[str]
    evaluations: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, project_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entities: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., parent: _Optional[str] = ..., status: _Optional[str] = ..., outcome: _Optional[str] = ..., experiments: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., version: _Optional[str] = ..., pac_id: _Optional[str] = ..., acl: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_added: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., priority: _Optional[float] = ..., timeline: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., milestones: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., hypothesis_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hypothesis: _Optional[str] = ..., objectives_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., risks_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., budget: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., results_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., remarks: _Optional[str] = ..., color: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., search_vector: _Optional[str] = ..., project_base: _Optional[str] = ..., tasks: _Optional[_Iterable[str]] = ..., data: _Optional[_Iterable[str]] = ..., evaluations: _Optional[_Iterable[str]] = ...) -> None: ...

class ProjectRequest(_message.Message):
    __slots__ = ("project_id", "namespace", "entities", "groups", "parent", "status", "outcome", "experiments", "resources_external", "tags", "name_display", "name", "version", "pac_id", "acl", "hash_sha256", "datetime_start", "datetime_added", "datetime_end", "datetime_last_modified", "priority", "timeline", "milestones", "description", "hypothesis_json", "hypothesis", "objectives_json", "risks_json", "budget", "results_json", "remarks", "color", "iri", "pid", "search_vector", "project_base", "tasks", "data", "evaluations")
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    PARENT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENTS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    ACL_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ADDED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    TIMELINE_FIELD_NUMBER: _ClassVar[int]
    MILESTONES_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    HYPOTHESIS_JSON_FIELD_NUMBER: _ClassVar[int]
    HYPOTHESIS_FIELD_NUMBER: _ClassVar[int]
    OBJECTIVES_JSON_FIELD_NUMBER: _ClassVar[int]
    RISKS_JSON_FIELD_NUMBER: _ClassVar[int]
    BUDGET_FIELD_NUMBER: _ClassVar[int]
    RESULTS_JSON_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PROJECT_BASE_FIELD_NUMBER: _ClassVar[int]
    TASKS_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    EVALUATIONS_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    namespace: str
    entities: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    parent: str
    status: str
    outcome: str
    experiments: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    version: str
    pac_id: str
    acl: _struct_pb2.Struct
    hash_sha256: str
    datetime_start: str
    datetime_added: str
    datetime_end: str
    datetime_last_modified: str
    priority: float
    timeline: _struct_pb2.Struct
    milestones: _struct_pb2.Struct
    description: str
    hypothesis_json: _struct_pb2.Struct
    hypothesis: str
    objectives_json: _struct_pb2.Struct
    risks_json: _struct_pb2.Struct
    budget: _struct_pb2.Struct
    results_json: _struct_pb2.Struct
    remarks: str
    color: str
    iri: str
    pid: str
    search_vector: str
    project_base: str
    tasks: _containers.RepeatedScalarFieldContainer[str]
    data: _containers.RepeatedScalarFieldContainer[str]
    evaluations: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, project_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entities: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., parent: _Optional[str] = ..., status: _Optional[str] = ..., outcome: _Optional[str] = ..., experiments: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., version: _Optional[str] = ..., pac_id: _Optional[str] = ..., acl: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_added: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., priority: _Optional[float] = ..., timeline: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., milestones: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., hypothesis_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hypothesis: _Optional[str] = ..., objectives_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., risks_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., budget: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., results_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., remarks: _Optional[str] = ..., color: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., search_vector: _Optional[str] = ..., project_base: _Optional[str] = ..., tasks: _Optional[_Iterable[str]] = ..., data: _Optional[_Iterable[str]] = ..., evaluations: _Optional[_Iterable[str]] = ...) -> None: ...

class ProjectResponse(_message.Message):
    __slots__ = ("project_id", "namespace", "entities", "groups", "parent", "status", "outcome", "experiments", "resources_external", "tags", "name_display", "name", "version", "pac_id", "acl", "hash_sha256", "datetime_start", "datetime_added", "datetime_end", "datetime_last_modified", "priority", "timeline", "milestones", "description", "hypothesis_json", "hypothesis", "objectives_json", "risks_json", "budget", "results_json", "remarks", "color", "iri", "pid", "search_vector", "lft", "rght", "tree_id", "level", "project_base", "tasks", "data", "evaluations")
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    PARENT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENTS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    ACL_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ADDED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    TIMELINE_FIELD_NUMBER: _ClassVar[int]
    MILESTONES_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    HYPOTHESIS_JSON_FIELD_NUMBER: _ClassVar[int]
    HYPOTHESIS_FIELD_NUMBER: _ClassVar[int]
    OBJECTIVES_JSON_FIELD_NUMBER: _ClassVar[int]
    RISKS_JSON_FIELD_NUMBER: _ClassVar[int]
    BUDGET_FIELD_NUMBER: _ClassVar[int]
    RESULTS_JSON_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    LFT_FIELD_NUMBER: _ClassVar[int]
    RGHT_FIELD_NUMBER: _ClassVar[int]
    TREE_ID_FIELD_NUMBER: _ClassVar[int]
    LEVEL_FIELD_NUMBER: _ClassVar[int]
    PROJECT_BASE_FIELD_NUMBER: _ClassVar[int]
    TASKS_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    EVALUATIONS_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    namespace: str
    entities: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    parent: str
    status: str
    outcome: str
    experiments: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    version: str
    pac_id: str
    acl: _struct_pb2.Struct
    hash_sha256: str
    datetime_start: str
    datetime_added: str
    datetime_end: str
    datetime_last_modified: str
    priority: float
    timeline: _struct_pb2.Struct
    milestones: _struct_pb2.Struct
    description: str
    hypothesis_json: _struct_pb2.Struct
    hypothesis: str
    objectives_json: _struct_pb2.Struct
    risks_json: _struct_pb2.Struct
    budget: _struct_pb2.Struct
    results_json: _struct_pb2.Struct
    remarks: str
    color: str
    iri: str
    pid: str
    search_vector: str
    lft: int
    rght: int
    tree_id: int
    level: int
    project_base: str
    tasks: _containers.RepeatedScalarFieldContainer[str]
    data: _containers.RepeatedScalarFieldContainer[str]
    evaluations: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, project_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entities: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., parent: _Optional[str] = ..., status: _Optional[str] = ..., outcome: _Optional[str] = ..., experiments: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., version: _Optional[str] = ..., pac_id: _Optional[str] = ..., acl: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_added: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., priority: _Optional[float] = ..., timeline: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., milestones: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., hypothesis_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hypothesis: _Optional[str] = ..., objectives_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., risks_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., budget: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., results_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., remarks: _Optional[str] = ..., color: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., search_vector: _Optional[str] = ..., lft: _Optional[int] = ..., rght: _Optional[int] = ..., tree_id: _Optional[int] = ..., level: _Optional[int] = ..., project_base: _Optional[str] = ..., tasks: _Optional[_Iterable[str]] = ..., data: _Optional[_Iterable[str]] = ..., evaluations: _Optional[_Iterable[str]] = ...) -> None: ...

class ProjectRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ProjectRetrieveRequest(_message.Message):
    __slots__ = ("project_id",)
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    project_id: str
    def __init__(self, project_id: _Optional[str] = ...) -> None: ...

class ProjectStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProjectSyncStatusDestroyRequest(_message.Message):
    __slots__ = ("syncstatus_id",)
    SYNCSTATUS_ID_FIELD_NUMBER: _ClassVar[int]
    syncstatus_id: str
    def __init__(self, syncstatus_id: _Optional[str] = ...) -> None: ...

class ProjectSyncStatusListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProjectSyncStatusListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ProjectSyncStatusResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ProjectSyncStatusResponse, _Mapping]]] = ...) -> None: ...

class ProjectSyncStatusPartialUpdateRequest(_message.Message):
    __slots__ = ("syncstatus_id", "server", "projects", "status", "_partial_update_fields", "datetime_last_synced")
    SYNCSTATUS_ID_FIELD_NUMBER: _ClassVar[int]
    SERVER_FIELD_NUMBER: _ClassVar[int]
    PROJECTS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_SYNCED_FIELD_NUMBER: _ClassVar[int]
    syncstatus_id: str
    server: str
    projects: _containers.RepeatedScalarFieldContainer[str]
    status: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    datetime_last_synced: str
    def __init__(self, syncstatus_id: _Optional[str] = ..., server: _Optional[str] = ..., projects: _Optional[_Iterable[str]] = ..., status: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., datetime_last_synced: _Optional[str] = ...) -> None: ...

class ProjectSyncStatusRequest(_message.Message):
    __slots__ = ("syncstatus_id", "server", "projects", "status", "datetime_last_synced")
    SYNCSTATUS_ID_FIELD_NUMBER: _ClassVar[int]
    SERVER_FIELD_NUMBER: _ClassVar[int]
    PROJECTS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_SYNCED_FIELD_NUMBER: _ClassVar[int]
    syncstatus_id: str
    server: str
    projects: _containers.RepeatedScalarFieldContainer[str]
    status: str
    datetime_last_synced: str
    def __init__(self, syncstatus_id: _Optional[str] = ..., server: _Optional[str] = ..., projects: _Optional[_Iterable[str]] = ..., status: _Optional[str] = ..., datetime_last_synced: _Optional[str] = ...) -> None: ...

class ProjectSyncStatusResponse(_message.Message):
    __slots__ = ("syncstatus_id", "server", "projects", "status", "datetime_last_synced")
    SYNCSTATUS_ID_FIELD_NUMBER: _ClassVar[int]
    SERVER_FIELD_NUMBER: _ClassVar[int]
    PROJECTS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_SYNCED_FIELD_NUMBER: _ClassVar[int]
    syncstatus_id: str
    server: str
    projects: _containers.RepeatedScalarFieldContainer[str]
    status: str
    datetime_last_synced: str
    def __init__(self, syncstatus_id: _Optional[str] = ..., server: _Optional[str] = ..., projects: _Optional[_Iterable[str]] = ..., status: _Optional[str] = ..., datetime_last_synced: _Optional[str] = ...) -> None: ...

class ProjectSyncStatusRetrieveRequest(_message.Message):
    __slots__ = ("syncstatus_id",)
    SYNCSTATUS_ID_FIELD_NUMBER: _ClassVar[int]
    syncstatus_id: str
    def __init__(self, syncstatus_id: _Optional[str] = ...) -> None: ...

class ProjectSyncStatusStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProjectSynchronisationDestroyRequest(_message.Message):
    __slots__ = ("sync_id",)
    SYNC_ID_FIELD_NUMBER: _ClassVar[int]
    sync_id: str
    def __init__(self, sync_id: _Optional[str] = ...) -> None: ...

class ProjectSynchronisationListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProjectSynchronisationListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ProjectSynchronisationResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ProjectSynchronisationResponse, _Mapping]]] = ...) -> None: ...

class ProjectSynchronisationPartialUpdateRequest(_message.Message):
    __slots__ = ("sync_id", "namespace", "server_target", "status", "projects", "_partial_update_fields", "name", "datetime_start", "datetime_end", "mode", "update_policy", "event_repeat", "event_repeat_json", "config_json", "logs", "log_file", "description")
    SYNC_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SERVER_TARGET_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PROJECTS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    UPDATE_POLICY_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    CONFIG_JSON_FIELD_NUMBER: _ClassVar[int]
    LOGS_FIELD_NUMBER: _ClassVar[int]
    LOG_FILE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    sync_id: str
    namespace: str
    server_target: str
    status: str
    projects: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    datetime_start: str
    datetime_end: str
    mode: str
    update_policy: str
    event_repeat: str
    event_repeat_json: _struct_pb2.Struct
    config_json: _struct_pb2.Struct
    logs: _struct_pb2.Struct
    log_file: str
    description: str
    def __init__(self, sync_id: _Optional[str] = ..., namespace: _Optional[str] = ..., server_target: _Optional[str] = ..., status: _Optional[str] = ..., projects: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., mode: _Optional[str] = ..., update_policy: _Optional[str] = ..., event_repeat: _Optional[str] = ..., event_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., config_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., logs: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., log_file: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class ProjectSynchronisationRequest(_message.Message):
    __slots__ = ("sync_id", "namespace", "server_target", "status", "projects", "name", "datetime_start", "datetime_end", "mode", "update_policy", "event_repeat", "event_repeat_json", "config_json", "logs", "log_file", "description")
    SYNC_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SERVER_TARGET_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PROJECTS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    UPDATE_POLICY_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    CONFIG_JSON_FIELD_NUMBER: _ClassVar[int]
    LOGS_FIELD_NUMBER: _ClassVar[int]
    LOG_FILE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    sync_id: str
    namespace: str
    server_target: str
    status: str
    projects: _containers.RepeatedScalarFieldContainer[str]
    name: str
    datetime_start: str
    datetime_end: str
    mode: str
    update_policy: str
    event_repeat: str
    event_repeat_json: _struct_pb2.Struct
    config_json: _struct_pb2.Struct
    logs: _struct_pb2.Struct
    log_file: str
    description: str
    def __init__(self, sync_id: _Optional[str] = ..., namespace: _Optional[str] = ..., server_target: _Optional[str] = ..., status: _Optional[str] = ..., projects: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., mode: _Optional[str] = ..., update_policy: _Optional[str] = ..., event_repeat: _Optional[str] = ..., event_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., config_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., logs: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., log_file: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class ProjectSynchronisationResponse(_message.Message):
    __slots__ = ("sync_id", "namespace", "server_target", "status", "projects", "name", "datetime_start", "datetime_end", "mode", "update_policy", "event_repeat", "event_repeat_json", "config_json", "logs", "log_file", "description")
    SYNC_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SERVER_TARGET_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PROJECTS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    UPDATE_POLICY_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_FIELD_NUMBER: _ClassVar[int]
    EVENT_REPEAT_JSON_FIELD_NUMBER: _ClassVar[int]
    CONFIG_JSON_FIELD_NUMBER: _ClassVar[int]
    LOGS_FIELD_NUMBER: _ClassVar[int]
    LOG_FILE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    sync_id: str
    namespace: str
    server_target: str
    status: str
    projects: _containers.RepeatedScalarFieldContainer[str]
    name: str
    datetime_start: str
    datetime_end: str
    mode: str
    update_policy: str
    event_repeat: str
    event_repeat_json: _struct_pb2.Struct
    config_json: _struct_pb2.Struct
    logs: _struct_pb2.Struct
    log_file: str
    description: str
    def __init__(self, sync_id: _Optional[str] = ..., namespace: _Optional[str] = ..., server_target: _Optional[str] = ..., status: _Optional[str] = ..., projects: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., mode: _Optional[str] = ..., update_policy: _Optional[str] = ..., event_repeat: _Optional[str] = ..., event_repeat_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., config_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., logs: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., log_file: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class ProjectSynchronisationRetrieveRequest(_message.Message):
    __slots__ = ("sync_id",)
    SYNC_ID_FIELD_NUMBER: _ClassVar[int]
    sync_id: str
    def __init__(self, sync_id: _Optional[str] = ...) -> None: ...

class ProjectSynchronisationStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProjectsSubsetDestroyRequest(_message.Message):
    __slots__ = ("projectselection_id",)
    PROJECTSELECTION_ID_FIELD_NUMBER: _ClassVar[int]
    projectselection_id: str
    def __init__(self, projectselection_id: _Optional[str] = ...) -> None: ...

class ProjectsSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProjectsSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ProjectsSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ProjectsSubsetResponse, _Mapping]]] = ...) -> None: ...

class ProjectsSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("projectselection_id", "namespace", "entity", "selected_items", "_partial_update_fields", "name_display", "name", "description", "datetime_last_modified", "group", "tags")
    PROJECTSELECTION_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    SELECTED_ITEMS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    projectselection_id: str
    namespace: str
    entity: str
    selected_items: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    description: str
    datetime_last_modified: str
    group: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, projectselection_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entity: _Optional[str] = ..., selected_items: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., group: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ...) -> None: ...

class ProjectsSubsetRequest(_message.Message):
    __slots__ = ("projectselection_id", "namespace", "entity", "selected_items", "name_display", "name", "description", "datetime_last_modified", "group", "tags")
    PROJECTSELECTION_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    SELECTED_ITEMS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    projectselection_id: str
    namespace: str
    entity: str
    selected_items: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    description: str
    datetime_last_modified: str
    group: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, projectselection_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entity: _Optional[str] = ..., selected_items: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., group: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ...) -> None: ...

class ProjectsSubsetResponse(_message.Message):
    __slots__ = ("projectselection_id", "namespace", "entity", "selected_items", "name_display", "name", "description", "datetime_last_modified", "group", "tags", "projects")
    PROJECTSELECTION_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    SELECTED_ITEMS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    PROJECTS_FIELD_NUMBER: _ClassVar[int]
    projectselection_id: str
    namespace: str
    entity: str
    selected_items: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    description: str
    datetime_last_modified: str
    group: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    projects: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, projectselection_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entity: _Optional[str] = ..., selected_items: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., group: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., projects: _Optional[_Iterable[str]] = ...) -> None: ...

class ProjectsSubsetRetrieveRequest(_message.Message):
    __slots__ = ("projectselection_id",)
    PROJECTSELECTION_ID_FIELD_NUMBER: _ClassVar[int]
    projectselection_id: str
    def __init__(self, projectselection_id: _Optional[str] = ...) -> None: ...

class ProjectsSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class TaskDestroyRequest(_message.Message):
    __slots__ = ("task_id",)
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    def __init__(self, task_id: _Optional[str] = ...) -> None: ...

class TaskListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class TaskListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[TaskResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[TaskResponse, _Mapping]]] = ...) -> None: ...

class TaskPartialUpdateRequest(_message.Message):
    __slots__ = ("task_id", "namespace", "entities", "task_base", "status", "_partial_update_fields", "name_display", "name", "description", "datetime_start", "datetime_added", "datetime_end", "datetime_last_modified", "priority", "search_vector")
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_FIELD_NUMBER: _ClassVar[int]
    TASK_BASE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ADDED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    namespace: str
    entities: _containers.RepeatedScalarFieldContainer[str]
    task_base: str
    status: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    description: str
    datetime_start: str
    datetime_added: str
    datetime_end: str
    datetime_last_modified: str
    priority: float
    search_vector: str
    def __init__(self, task_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entities: _Optional[_Iterable[str]] = ..., task_base: _Optional[str] = ..., status: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_added: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., priority: _Optional[float] = ..., search_vector: _Optional[str] = ...) -> None: ...

class TaskRequest(_message.Message):
    __slots__ = ("task_id", "namespace", "entities", "task_base", "status", "name_display", "name", "description", "datetime_start", "datetime_added", "datetime_end", "datetime_last_modified", "priority", "search_vector")
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_FIELD_NUMBER: _ClassVar[int]
    TASK_BASE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ADDED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    namespace: str
    entities: _containers.RepeatedScalarFieldContainer[str]
    task_base: str
    status: str
    name_display: str
    name: str
    description: str
    datetime_start: str
    datetime_added: str
    datetime_end: str
    datetime_last_modified: str
    priority: float
    search_vector: str
    def __init__(self, task_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entities: _Optional[_Iterable[str]] = ..., task_base: _Optional[str] = ..., status: _Optional[str] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_added: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., priority: _Optional[float] = ..., search_vector: _Optional[str] = ...) -> None: ...

class TaskResponse(_message.Message):
    __slots__ = ("task_id", "namespace", "entities", "task_base", "status", "name_display", "name", "description", "datetime_start", "datetime_added", "datetime_end", "datetime_last_modified", "priority", "search_vector")
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_FIELD_NUMBER: _ClassVar[int]
    TASK_BASE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ADDED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    namespace: str
    entities: _containers.RepeatedScalarFieldContainer[str]
    task_base: str
    status: str
    name_display: str
    name: str
    description: str
    datetime_start: str
    datetime_added: str
    datetime_end: str
    datetime_last_modified: str
    priority: float
    search_vector: str
    def __init__(self, task_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entities: _Optional[_Iterable[str]] = ..., task_base: _Optional[str] = ..., status: _Optional[str] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_added: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., priority: _Optional[float] = ..., search_vector: _Optional[str] = ...) -> None: ...

class TaskRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class TaskRetrieveRequest(_message.Message):
    __slots__ = ("task_id",)
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    def __init__(self, task_id: _Optional[str] = ...) -> None: ...

class TaskStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
