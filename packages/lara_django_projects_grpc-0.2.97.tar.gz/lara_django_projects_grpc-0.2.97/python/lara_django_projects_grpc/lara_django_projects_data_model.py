from __future__ import annotations 

import re
import sys
from datetime import (
    date,
    datetime,
    time
)
from decimal import Decimal 
from enum import Enum 
from typing import (
    Any,
    ClassVar,
    Dict,
    List,
    Literal,
    Optional,
    Union
)

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    RootModel,
    field_validator
)


metamodel_version = "None"
version = "None"


class ConfiguredBaseModel(BaseModel):
    model_config = ConfigDict(
        validate_assignment = True,
        validate_default = True,
        extra = "forbid",
        arbitrary_types_allowed = True,
        use_enum_values = True,
        strict = False,
    )
    pass




class LinkMLMeta(RootModel):
    root: Dict[str, Any] = {}
    model_config = ConfigDict(frozen=True)

    def __getattr__(self, key:str):
        return getattr(self.root, key)

    def __getitem__(self, key:str):
        return self.root[key]

    def __setitem__(self, key:str, value):
        self.root[key] = value

    def __contains__(self, key:str) -> bool:
        return key in self.root


linkml_meta = LinkMLMeta({'default_prefix': 'lara',
     'default_range': 'string',
     'id': 'https://w3id.org/lara/lara_django_projects',
     'imports': ['linkml:types'],
     'name': 'lara_django_projects',
     'prefixes': {'lara': {'prefix_prefix': 'lara',
                           'prefix_reference': 'http://w3id.org/lara/'},
                  'linkml': {'prefix_prefix': 'linkml',
                             'prefix_reference': 'https://w3id.org/linkml/'},
                  'oso': {'prefix_prefix': 'oso',
                          'prefix_reference': 'http://w3id.org/oso/'}},
     'source_file': 'lara_django_projects_schema.yaml',
     'types': {'FileField': {'base': 'str',
                             'description': 'A file field',
                             'from_schema': 'https://w3id.org/lara/lara_django_projects',
                             'name': 'FileField',
                             'uri': 'https://w3id.org/lara/FileField'},
               'ImageField': {'base': 'str',
                              'description': 'An image field',
                              'from_schema': 'https://w3id.org/lara/lara_django_projects',
                              'name': 'ImageField',
                              'uri': 'https://w3id.org/lara/ImageField'},
               'JSON': {'base': 'string',
                        'description': 'A JSON object',
                        'from_schema': 'https://w3id.org/lara/lara_django_projects',
                        'name': 'JSON',
                        'repr': 'dict',
                        'uri': 'https://json.org'},
               'UUID': {'base': 'str',
                        'description': 'A UUID',
                        'from_schema': 'https://w3id.org/lara/lara_django_projects',
                        'name': 'UUID',
                        'pattern': '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
                        'uri': 'https://datatracker.ietf.org/doc/html/rfc9562'}}} )


class ProcedureInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_processes.models.ProcedureInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class ItemStatus(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.ItemStatus'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class OrganismInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_organisms_store.models.OrganismInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class MixtureInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_substances_store.models.MixtureInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class ExternalResource(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.ExternalResource'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class DeviceSetupInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_material_store.models.device_models.DeviceSetupInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class DeviceInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_material_store.models.device_models.DeviceInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class Group(ConfiguredBaseModel):
    """
    <class 'lara_django_people.models.Group'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class PolymerInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_substances_store.models.PolymerInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class EntityRole(ConfiguredBaseModel):
    """
    <class 'lara_django_people.models.EntityRole'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class Entity(ConfiguredBaseModel):
    """
    <class 'lara_django_people.models.Entity'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class LabwareInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_material_store.models.labware_models.LabwareInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class Data(ConfiguredBaseModel):
    """
    <class 'lara_django_data.models.Data'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class Evaluation(ConfiguredBaseModel):
    """
    <class 'lara_django_data.models.Evaluation'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class PartInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_material_store.models.part_models.PartInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class Location(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Location'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class SubstanceInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_substances_store.models.SubstanceInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class GeoLocation(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.GeoLocation'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class MethodInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_processes.models.MethodInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class LaraUser(ConfiguredBaseModel):
    """
    <class 'lara_django_people.models.LaraUser'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class LARASyncServer(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.LARASyncServer'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class Tag(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Tag'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class Sample(ConfiguredBaseModel):
    """
    <class 'lara_django_samples.models.Sample'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class Namespace(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Namespace'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class ProcessInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_processes.models.ProcessInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    pass


class Task(ConfiguredBaseModel):
    """
    \" This class stores all details of a task. A task are associated with projects, experiments and workpackages.
        They can be used as workpackages or ToDo list items, e.g.
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:projects/Tasks',
         'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    task_id: Optional[str] = Field(None, description="""Task - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'task_id',
         'domain_of': ['Task'],
         'slot_uri': 'lara:projects/Tasks/task_id'} })
    namespace: str = Field(..., description="""namespace of task""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""human readable task title - to be displayed in the web frontend""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/Tasks/name_display'} })
    name: Optional[str] = Field(None, description="""name of the task, should not contain whitespaces""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/Tasks/name'} })
    task_base: Optional[str] = Field(None, description="""base task - this can be, e.g., used as a template task""", json_schema_extra = { "linkml_meta": {'alias': 'task_base', 'domain_of': ['Task'], 'slot_uri': 'lara:projects/Tasks'} })
    description: Optional[str] = Field(None, description="""task description""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/Tasks/description'} })
    datetime_start: Optional[str] = Field(None, description="""start of task""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_start',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/Tasks/datetime_start'} })
    datetime_added: Optional[str] = Field(None, description="""datetime task added to LARA""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_added',
         'domain_of': ['Task', 'Project', 'Experiment'],
         'slot_uri': 'lara:projects/Tasks/datetime_added'} })
    datetime_end: Optional[str] = Field(None, description="""end of task""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_end',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/Tasks/datetime_end'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when task was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/Tasks/datetime_last_modified'} })
    priority: Optional[float] = Field(None, description="""priority of the task, between 0 and 1""", json_schema_extra = { "linkml_meta": {'alias': 'priority',
         'domain_of': ['Task', 'Project', 'Experiment'],
         'slot_uri': 'lara:projects/Tasks/priority'} })
    status: Optional[str] = Field(None, description="""task status classifier: planned, started, in_progess, finished.It also contains a numeric value for quantifying the progress""", json_schema_extra = { "linkml_meta": {'alias': 'status',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectSynchronisation',
                       'ProjectSyncStatus'],
         'slot_uri': 'lara:base/ItemStatus'} })
    entities: Optional[List[str]] = Field(None, description="""entities with given roles in the task""", json_schema_extra = { "linkml_meta": {'alias': 'entities',
         'domain_of': ['Task', 'Project', 'Experiment'],
         'slot_uri': 'lara:people/Entity'} })


class Project(ConfiguredBaseModel):
    """
    \" This class stores all details of a project with its underlying experiments.
        Project information is designed to be lean. All data and evaluations related information is stored in the experiments.
        A project can have many subprojects which uses the MPTTModel to build a tree structure.
        A project can have many experiments which are stored in the experiments field.
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:projects/Project',
         'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    namespace: str = Field(..., description="""namespace of project""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""human readable project/experiment title - to be displayed in the web frontend""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/Project/name_display'} })
    name: Optional[str] = Field(None, description="""name of the project or experiment, should not contain whitespaces""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/Project/name'} })
    version: Optional[str] = Field(None, description="""version of the project or experiment""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/version'} })
    pac_id: Optional[str] = Field(None, description="""Publicly Addressable Content IDentifier is a globally unique identifier that operates independently of a central registry.""", json_schema_extra = { "linkml_meta": {'alias': 'pac_id',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/pac_id'} })
    acl: Optional[dict] = Field(None, description="""access control list - fine grained data access control""", json_schema_extra = { "linkml_meta": {'alias': 'acl',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/acl'} })
    parent: Optional[str] = Field(None, description="""mptt - parent projects""", json_schema_extra = { "linkml_meta": {'alias': 'parent',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project'} })
    hash_sha256: Optional[str] = Field(None, description="""SHA256 experiment hash""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha256',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/hash_sha256'} })
    datetime_start: Optional[str] = Field(None, description="""start of project / experiment""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_start',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/Project/datetime_start'} })
    datetime_added: Optional[str] = Field(None, description="""datetime project / experiment added to LARA""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_added',
         'domain_of': ['Task', 'Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/datetime_added'} })
    datetime_end: Optional[str] = Field(None, description="""end of project / experiment""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_end',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/Project/datetime_end'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when project / experiment was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/Project/datetime_last_modified'} })
    priority: Optional[float] = Field(None, description="""priority of the project / experiment, between 0 and 1""", json_schema_extra = { "linkml_meta": {'alias': 'priority',
         'domain_of': ['Task', 'Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/priority'} })
    status: Optional[str] = Field(None, description="""experiment status classifier: planned, started, in_progess, finished, it also contains a numeric value for quantifying the progress""", json_schema_extra = { "linkml_meta": {'alias': 'status',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectSynchronisation',
                       'ProjectSyncStatus'],
         'slot_uri': 'lara:base/ItemStatus'} })
    timeline: Optional[dict] = Field(None, description="""timeline of the project / experiment""", json_schema_extra = { "linkml_meta": {'alias': 'timeline',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/timeline'} })
    milestones: Optional[dict] = Field(None, description="""milestones of the project / experiment""", json_schema_extra = { "linkml_meta": {'alias': 'milestones',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/milestones'} })
    description: Optional[str] = Field(None, description="""project / experiment description""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/Project/description'} })
    hypothesis_json: Optional[dict] = Field(None, description="""hypothesis in machine understandable JSON-LD format.""", json_schema_extra = { "linkml_meta": {'alias': 'hypothesis_json',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/hypothesis_json'} })
    hypothesis: Optional[str] = Field(None, description="""human readable hypothesis of the experiment / project""", json_schema_extra = { "linkml_meta": {'alias': 'hypothesis',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/hypothesis'} })
    objectives_json: Optional[dict] = Field(None, description="""objectives and goals in machine understandable JSON-LD format.""", json_schema_extra = { "linkml_meta": {'alias': 'objectives_json',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/objectives_json'} })
    risks_json: Optional[dict] = Field(None, description="""risks in machine understandable JSON-LD format.""", json_schema_extra = { "linkml_meta": {'alias': 'risks_json',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/risks_json'} })
    budget: Optional[dict] = Field(None, description="""budget/costs/actual costs of the project / experiment in JSON-LD format""", json_schema_extra = { "linkml_meta": {'alias': 'budget',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/budget'} })
    results_json: Optional[dict] = Field(None, description="""results in machine understandable JSON-LD format.""", json_schema_extra = { "linkml_meta": {'alias': 'results_json',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/results_json'} })
    outcome: Optional[str] = Field(None, description="""project / experiment outcome classifier, e.g., preliminary, statistically_confirmed""", json_schema_extra = { "linkml_meta": {'alias': 'outcome',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:base/ItemStatus'} })
    remarks: Optional[str] = Field(None, description="""remarks to the project / experiment""", json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/remarks'} })
    color: Optional[str] = Field(None, description="""GUI colour representation of the project/experiment, can be used in calendars, or gui elements like frames.""", json_schema_extra = { "linkml_meta": {'alias': 'color',
         'domain_of': ['Project',
                       'Experiment',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/Project/color'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/iri'} })
    pid: Optional[str] = Field(None, description="""Persitent Identifier [PID/handle URI](https://www.handle.net/)""", json_schema_extra = { "linkml_meta": {'alias': 'pid',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/pid'} })
    project_id: Optional[str] = Field(None, description="""Project - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'project_id',
         'domain_of': ['Project'],
         'slot_uri': 'lara:projects/Project/project_id'} })
    project_base: Optional[str] = Field(None, description="""base project - this can be, e.g., used as a template project""", json_schema_extra = { "linkml_meta": {'alias': 'project_base',
         'domain_of': ['Project'],
         'slot_uri': 'lara:projects/Project'} })
    lft: Optional[int] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'lft',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/lft'} })
    rght: Optional[int] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'rght',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/rght'} })
    tree_id: Optional[int] = Field(None,  json_schema_extra = { "linkml_meta": {'alias': 'tree_id',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Project/tree_id'} })
    level: Optional[int] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'level',
          'domain_of': ['Project', 'Experiment'],
          'slot_uri': 'lara:projects/Project/level'} })
    groups: Optional[List[str]] = Field(None, description="""groups of this data""", json_schema_extra = { "linkml_meta": {'alias': 'groups',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:people/Group'} })
    tasks: Optional[List[str]] = Field(None, description="""tasks of this project or experiment""", json_schema_extra = { "linkml_meta": {'alias': 'tasks',
         'domain_of': ['Project', 'Experiment', 'Container'],
         'slot_uri': 'lara:projects/Tasks'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:base/ExternalResource'} })
    tags: Optional[List[str]] = Field(None, description="""project / experiment tags, for easier identification""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:base/Tag'} })
    entities: Optional[List[str]] = Field(None, description="""entities with given roles in the project""", json_schema_extra = { "linkml_meta": {'alias': 'entities',
         'domain_of': ['Task', 'Project', 'Experiment'],
         'slot_uri': 'lara:people/Entity'} })
    experiments: Optional[List[str]] = Field(None, description="""link to all experiments of a project""", json_schema_extra = { "linkml_meta": {'alias': 'experiments',
         'domain_of': ['Project', 'ExperimentsSubset', 'Container'],
         'slot_uri': 'lara:projects/Experiment'} })
    data: Optional[List[str]] = Field(None, description="""data of this project""", json_schema_extra = { "linkml_meta": {'alias': 'data',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:data/Data'} })
    evaluations: Optional[List[str]] = Field(None, description="""evaluations of this project""", json_schema_extra = { "linkml_meta": {'alias': 'evaluations',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:data/Evaluation'} })


class RoledProjectEntities(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between Entity and Project.
        This class can be used to store the current role of an entity in a project
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:projects/RoledProjectEntities',
         'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    roledprojectentities_id: Optional[str] = Field(None, description="""RoledProjectEntities - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'roledprojectentities_id',
         'domain_of': ['RoledProjectEntities'],
         'slot_uri': 'lara:projects/RoledProjectEntities/roledprojectentities_id'} })
    entity: str = Field(..., description="""entity in the project""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['RoledProjectEntities',
                       'ProjectsSubset',
                       'RoledExperimentEntities',
                       'ExperimentsSubset'],
         'slot_uri': 'lara:people/Entity'} })
    project: str = Field(..., description="""project""", json_schema_extra = { "linkml_meta": {'alias': 'project',
         'domain_of': ['RoledProjectEntities',
                       'OrderedProjectsSubset',
                       'ProjectCalendar'],
         'slot_uri': 'lara:projects/Project'} })
    role: str = Field(..., description="""current role of an entity in the project""", json_schema_extra = { "linkml_meta": {'alias': 'role',
         'domain_of': ['RoledProjectEntities',
                       'RoledExperimentEntities',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:people/EntityRole'} })


class ProjectsSubset(ConfiguredBaseModel):
    """
    \" User or group defined selection of projects \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:projects/ProjectsSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectsSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectsSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['RoledProjectEntities',
                       'ProjectsSubset',
                       'RoledExperimentEntities',
                       'ExperimentsSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['ProjectsSubset', 'ExperimentsSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectsSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectsSubset/datetime_last_modified'} })
    projectselection_id: Optional[str] = Field(None, description="""ProjectsSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'projectselection_id',
         'domain_of': ['ProjectsSubset'],
         'slot_uri': 'lara:projects/ProjectsSubset/projectselection_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:base/Tag'} })
    projects: Optional[List[str]] = Field(None, description="""User or group selected projects""", json_schema_extra = { "linkml_meta": {'alias': 'projects',
         'domain_of': ['ProjectsSubset',
                       'ProjectSynchronisation',
                       'ProjectSyncStatus',
                       'Container'],
         'slot_uri': 'lara:projects/Project'} })


class OrderedProjectsSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between ProjectsSubset and Project.
        This class can be used to store the order of projects in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:projects/OrderedProjectsSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    orderedprojectssubset_id: Optional[str] = Field(None, description="""OrderedProjectsSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedprojectssubset_id',
         'domain_of': ['OrderedProjectsSubset'],
         'slot_uri': 'lara:projects/OrderedProjectsSubset/orderedprojectssubset_id'} })
    project: str = Field(..., description="""project in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'project',
         'domain_of': ['RoledProjectEntities',
                       'OrderedProjectsSubset',
                       'ProjectCalendar'],
         'slot_uri': 'lara:projects/Project'} })
    projects_subset: str = Field(..., description="""subset of projects""", json_schema_extra = { "linkml_meta": {'alias': 'projects_subset',
         'domain_of': ['OrderedProjectsSubset'],
         'slot_uri': 'lara:projects/ProjectsSubset'} })
    order: int = Field(..., description="""order of project in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedProjectsSubset', 'OrderedExperimentsSubset'],
         'slot_uri': 'lara:projects/OrderedProjectsSubset/order'} })


class Experiment(ConfiguredBaseModel):
    """
    \" this class stores all details of an LARA experiment
        - mind the time when data and evaluations are added: data might be added before an evaluation has been defined and vice versa
          finding related experiments: just look at children of an exp in tree or exp, that have this as parent
          some of the fields are only used by experiments.
          An experiment can have many sub-experiments which uses the MPTTModel to build a tree structure.
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:projects/Experiment',
         'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    namespace: str = Field(..., description="""namespace of project""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""human readable project/experiment title - to be displayed in the web frontend""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/Experiment/name_display'} })
    name: Optional[str] = Field(None, description="""name of the project or experiment, should not contain whitespaces""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/Experiment/name'} })
    version: Optional[str] = Field(None, description="""version of the project or experiment""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/version'} })
    pac_id: Optional[str] = Field(None, description="""Publicly Addressable Content IDentifier is a globally unique identifier that operates independently of a central registry.""", json_schema_extra = { "linkml_meta": {'alias': 'pac_id',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/pac_id'} })
    acl: Optional[dict] = Field(None, description="""access control list - fine grained data access control""", json_schema_extra = { "linkml_meta": {'alias': 'acl',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/acl'} })
    parent: Optional[str] = Field(None, description="""mptt - parent projects""", json_schema_extra = { "linkml_meta": {'alias': 'parent',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment'} })
    hash_sha256: Optional[str] = Field(None, description="""SHA256 experiment hash""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha256',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/hash_sha256'} })
    datetime_start: Optional[str] = Field(None, description="""start of project / experiment""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_start',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/Experiment/datetime_start'} })
    datetime_added: Optional[str] = Field(None, description="""datetime project / experiment added to LARA""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_added',
         'domain_of': ['Task', 'Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/datetime_added'} })
    datetime_end: Optional[str] = Field(None, description="""end of project / experiment""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_end',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/Experiment/datetime_end'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when project / experiment was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/Experiment/datetime_last_modified'} })
    priority: Optional[float] = Field(None, description="""priority of the project / experiment, between 0 and 1""", json_schema_extra = { "linkml_meta": {'alias': 'priority',
         'domain_of': ['Task', 'Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/priority'} })
    status: Optional[str] = Field(None, description="""experiment status classifier: planned, started, in_progess, finished, it also contains a numeric value for quantifying the progress""", json_schema_extra = { "linkml_meta": {'alias': 'status',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectSynchronisation',
                       'ProjectSyncStatus'],
         'slot_uri': 'lara:base/ItemStatus'} })
    timeline: Optional[dict] = Field(None, description="""timeline of the project / experiment""", json_schema_extra = { "linkml_meta": {'alias': 'timeline',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/timeline'} })
    milestones: Optional[dict] = Field(None, description="""milestones of the project / experiment""", json_schema_extra = { "linkml_meta": {'alias': 'milestones',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/milestones'} })
    description: Optional[str] = Field(None, description="""project / experiment description""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/Experiment/description'} })
    hypothesis_json: Optional[dict] = Field(None, description="""hypothesis in machine understandable JSON-LD format.""", json_schema_extra = { "linkml_meta": {'alias': 'hypothesis_json',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/hypothesis_json'} })
    hypothesis: Optional[str] = Field(None, description="""human readable hypothesis of the experiment / project""", json_schema_extra = { "linkml_meta": {'alias': 'hypothesis',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/hypothesis'} })
    objectives_json: Optional[dict] = Field(None, description="""objectives and goals in machine understandable JSON-LD format.""", json_schema_extra = { "linkml_meta": {'alias': 'objectives_json',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/objectives_json'} })
    risks_json: Optional[dict] = Field(None, description="""risks in machine understandable JSON-LD format.""", json_schema_extra = { "linkml_meta": {'alias': 'risks_json',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/risks_json'} })
    budget: Optional[dict] = Field(None, description="""budget/costs/actual costs of the project / experiment in JSON-LD format""", json_schema_extra = { "linkml_meta": {'alias': 'budget',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/budget'} })
    results_json: Optional[dict] = Field(None, description="""results in machine understandable JSON-LD format.""", json_schema_extra = { "linkml_meta": {'alias': 'results_json',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/results_json'} })
    outcome: Optional[str] = Field(None, description="""project / experiment outcome classifier, e.g., preliminary, statistically_confirmed""", json_schema_extra = { "linkml_meta": {'alias': 'outcome',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:base/ItemStatus'} })
    remarks: Optional[str] = Field(None, description="""remarks to the project / experiment""", json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/remarks'} })
    color: Optional[str] = Field(None, description="""GUI colour representation of the project/experiment, can be used in calendars, or gui elements like frames.""", json_schema_extra = { "linkml_meta": {'alias': 'color',
         'domain_of': ['Project',
                       'Experiment',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/Experiment/color'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/iri'} })
    pid: Optional[str] = Field(None, description="""Persitent Identifier [PID/handle URI](https://www.handle.net/)""", json_schema_extra = { "linkml_meta": {'alias': 'pid',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/pid'} })
    experiment_id: Optional[str] = Field(None, description="""Experiment - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'experiment_id',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:projects/Experiment/experiment_id'} })
    experiment_design: Optional[str] = Field(None, description="""process/procedure describing the experimental design, e.g. via machine learning or doi""", json_schema_extra = { "linkml_meta": {'alias': 'experiment_design',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:processes/ProcessInstance'} })
    experiment_base: Optional[str] = Field(None, description="""base experiment - this can be, e.g., used as a template experiment""", json_schema_extra = { "linkml_meta": {'alias': 'experiment_base',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:projects/Experiment'} })
    parameters: Optional[dict] = Field(None, description="""experimental parameters in JSON format, experimental parameters, like temperature, pH, recommended format: SciDat""", json_schema_extra = { "linkml_meta": {'alias': 'parameters',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:projects/Experiment/parameters'} })
    reference_experiment: Optional[str] = Field(None, description="""pointer to experiment with reference data""", json_schema_extra = { "linkml_meta": {'alias': 'reference_experiment',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:projects/Experiment'} })
    observations: Optional[str] = Field(None, description="""human readable observations during the experiment""", json_schema_extra = { "linkml_meta": {'alias': 'observations',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:projects/Experiment/observations'} })
    observations_json: Optional[dict] = Field(None, description="""observations in machine understandable JSON-LD format.""", json_schema_extra = { "linkml_meta": {'alias': 'observations_json',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:projects/Experiment/observations_json'} })
    lft: int = Field(..., json_schema_extra = { "linkml_meta": {'alias': 'lft',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/lft'} })
    rght: int = Field(..., json_schema_extra = { "linkml_meta": {'alias': 'rght',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/rght'} })
    tree_id: int = Field(..., json_schema_extra = { "linkml_meta": {'alias': 'tree_id',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/tree_id'} })
    level: int = Field(..., json_schema_extra = { "linkml_meta": {'alias': 'level',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/level'} })
    groups: Optional[List[str]] = Field(None, description="""groups of this data""", json_schema_extra = { "linkml_meta": {'alias': 'groups',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:people/Group'} })
    tasks: Optional[List[str]] = Field(None, description="""tasks of this project or experiment""", json_schema_extra = { "linkml_meta": {'alias': 'tasks',
         'domain_of': ['Project', 'Experiment', 'Container'],
         'slot_uri': 'lara:projects/Tasks'} })
    entities: Optional[List[str]] = Field(None, description="""entities with given roles in the experiment""", json_schema_extra = { "linkml_meta": {'alias': 'entities',
         'domain_of': ['Task', 'Project', 'Experiment'],
         'slot_uri': 'lara:people/Entity'} })
    data: Optional[List[str]] = Field(None, description="""link to all data of this experiment""", json_schema_extra = { "linkml_meta": {'alias': 'data',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:data/Data'} })
    evaluations: Optional[List[str]] = Field(None, description="""all evaluations of this experiment""", json_schema_extra = { "linkml_meta": {'alias': 'evaluations',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:data/Evaluation'} })
    method_instances: Optional[List[str]] = Field(None, description="""method for measuring, should be replaced by lara_process.method""", json_schema_extra = { "linkml_meta": {'alias': 'method_instances',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:processes/MethodInstance'} })
    process_instances: Optional[List[str]] = Field(None, description="""process""", json_schema_extra = { "linkml_meta": {'alias': 'process_instances',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:processes/ProcessInstance'} })
    procedure_instances: Optional[List[str]] = Field(None, description="""procedure""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_instances',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:processes/ProcedureInstance'} })
    substance_instances: Optional[List[str]] = Field(None, description="""substances used in experiment""", json_schema_extra = { "linkml_meta": {'alias': 'substance_instances',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:substances-store/SubstanceInstance'} })
    polymer_instances: Optional[List[str]] = Field(None, description="""polymers used in experiment""", json_schema_extra = { "linkml_meta": {'alias': 'polymer_instances',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:substances-store/PolymerInstance'} })
    mixture_instances: Optional[List[str]] = Field(None, description="""mixtures used in experiment""", json_schema_extra = { "linkml_meta": {'alias': 'mixture_instances',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:substances-store/MixtureInstance'} })
    organism_instances: Optional[List[str]] = Field(None, description="""organisms used in experiment""", json_schema_extra = { "linkml_meta": {'alias': 'organism_instances',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:organisms-store/OrganismInstance'} })
    part_instances: Optional[List[str]] = Field(None, description="""parts used in experiment""", json_schema_extra = { "linkml_meta": {'alias': 'part_instances',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:material_store/PartInstance'} })
    device_instances: Optional[List[str]] = Field(None, description="""devices used in experiment""", json_schema_extra = { "linkml_meta": {'alias': 'device_instances',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:material_store/DeviceInstance'} })
    device_setup_instances: Optional[List[str]] = Field(None, description="""device setups used in experiment""", json_schema_extra = { "linkml_meta": {'alias': 'device_setup_instances',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:material_store/DeviceSetupInstance'} })
    labware_instances: Optional[List[str]] = Field(None, description="""labware used in experiment""", json_schema_extra = { "linkml_meta": {'alias': 'labware_instances',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:material_store/LabwareInstance'} })
    samples: Optional[List[str]] = Field(None, description="""samples used in experiment""", json_schema_extra = { "linkml_meta": {'alias': 'samples',
         'domain_of': ['Experiment'],
         'slot_uri': 'lara:samples/Sample'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:base/ExternalResource'} })
    tags: Optional[List[str]] = Field(None, description="""experiment tags, for easier identification""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:base/Tag'} })
    search_vector: Optional[str] = Field(None, description="""search vector for full text search""", json_schema_extra = { "linkml_meta": {'alias': 'search_vector',
         'domain_of': ['Project', 'Experiment'],
         'slot_uri': 'lara:projects/Experiment/search_vector'} })


class RoledExperimentEntities(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between Entity and Experiment.
        This class can be used to store the current role of an entity in an experiment
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:projects/RoledExperimentEntities',
         'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    roledexperimententities_id: Optional[str] = Field(None, description="""RoledExperimentEntities - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'roledexperimententities_id',
         'domain_of': ['RoledExperimentEntities'],
         'slot_uri': 'lara:projects/RoledExperimentEntities/roledexperimententities_id'} })
    entity: str = Field(..., description="""entity in the experiment""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['RoledProjectEntities',
                       'ProjectsSubset',
                       'RoledExperimentEntities',
                       'ExperimentsSubset'],
         'slot_uri': 'lara:people/Entity'} })
    experiment: str = Field(..., description="""experiment""", json_schema_extra = { "linkml_meta": {'alias': 'experiment',
         'domain_of': ['RoledExperimentEntities',
                       'OrderedExperimentsSubset',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/Experiment'} })
    role: str = Field(..., description="""current role of an entity in the experiment""", json_schema_extra = { "linkml_meta": {'alias': 'role',
         'domain_of': ['RoledProjectEntities',
                       'RoledExperimentEntities',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:people/EntityRole'} })


class ExperimentsSubset(ConfiguredBaseModel):
    """
    \" User or group defined selection of experiments \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:projects/ExperimentsSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentsSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ExperimentsSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['RoledProjectEntities',
                       'ProjectsSubset',
                       'RoledExperimentEntities',
                       'ExperimentsSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['ProjectsSubset', 'ExperimentsSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ExperimentsSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentsSubset/datetime_last_modified'} })
    experimentselection_id: Optional[str] = Field(None, description="""ExperimentsSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'experimentselection_id',
         'domain_of': ['ExperimentsSubset'],
         'slot_uri': 'lara:projects/ExperimentsSubset/experimentselection_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:base/Tag'} })
    experiments: Optional[List[str]] = Field(None, description="""User or group selected experiments""", json_schema_extra = { "linkml_meta": {'alias': 'experiments',
         'domain_of': ['Project', 'ExperimentsSubset', 'Container'],
         'slot_uri': 'lara:projects/Experiment'} })


class OrderedExperimentsSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between ExperimentsSubset and Experiment.
        This class can be used to store the order of experiments in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:projects/OrderedExperimentsSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    orderedexperimentssubset_id: Optional[str] = Field(None, description="""OrderedExperimentsSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedexperimentssubset_id',
         'domain_of': ['OrderedExperimentsSubset'],
         'slot_uri': 'lara:projects/OrderedExperimentsSubset/orderedexperimentssubset_id'} })
    experiment: str = Field(..., description="""experiment in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'experiment',
         'domain_of': ['RoledExperimentEntities',
                       'OrderedExperimentsSubset',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/Experiment'} })
    experiments_subset: str = Field(..., description="""subset of experiments""", json_schema_extra = { "linkml_meta": {'alias': 'experiments_subset',
         'domain_of': ['OrderedExperimentsSubset'],
         'slot_uri': 'lara:projects/ExperimentsSubset'} })
    order: int = Field(..., description="""order of experiment in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedProjectsSubset', 'OrderedExperimentsSubset'],
         'slot_uri': 'lara:projects/OrderedExperimentsSubset/order'} })


class ProjectCalendar(ConfiguredBaseModel):
    """
    \" Project Calendar \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:projects/ProjectCalendar',
         'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    name_display: str = Field(..., description="""title of the calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/name_display'} })
    calendar_url: Optional[str] = Field(None, description="""Universal Resource Locator (URL), to google calendar, iCalendar, .... """, json_schema_extra = { "linkml_meta": {'alias': 'calendar_url',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/calendar_url'} })
    summary: Optional[str] = Field(None, description="""short summary text of the calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'summary',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/summary'} })
    description: Optional[str] = Field(None, description="""text of the calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectCalendar/description'} })
    color: Optional[str] = Field(None, description="""text of the calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'color',
         'domain_of': ['Project',
                       'Experiment',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/color'} })
    ics: Optional[str] = Field(None, description="""iCalendar entry in (RFC 5545) file format""", json_schema_extra = { "linkml_meta": {'alias': 'ics',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/ics'} })
    datetime_start: str = Field(..., description="""start date & time of the event. RFC 5545 - DTSTART""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_start',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectCalendar/datetime_start'} })
    datetime_end: str = Field(..., description="""end datetime of the event. RFC 5545 - DTEND""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_end',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectCalendar/datetime_end'} })
    duration: Optional[str] = Field(None, description=""" This value type is used to identify properties that contain a duration of time. RFC 5545 - DURATION""", json_schema_extra = { "linkml_meta": {'alias': 'duration',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/duration'} })
    all_day: bool = Field(..., description="""All day event ? (boolean)""", json_schema_extra = { "linkml_meta": {'alias': 'all_day',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/all_day'} })
    created: str = Field(..., description="""end datetime of the event""", json_schema_extra = { "linkml_meta": {'alias': 'created',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/created'} })
    datetime_last_modified: str = Field(..., description="""date and time when calendar entry was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/datetime_last_modified'} })
    timestamp: str = Field(..., description="""timestamp of the event""", json_schema_extra = { "linkml_meta": {'alias': 'timestamp',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/timestamp'} })
    location: Optional[str] = Field(None, description="""location""", json_schema_extra = { "linkml_meta": {'alias': 'location',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:base/Location'} })
    geolocation: Optional[str] = Field(None, description="""GEO location""", json_schema_extra = { "linkml_meta": {'alias': 'geolocation',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:base/GeoLocation'} })
    conference_url: Optional[str] = Field(None, description="""audio/video conference/meeting Universal Resource Locator (URL), e.g. zoom, jitsi, meet, ...""", json_schema_extra = { "linkml_meta": {'alias': 'conference_url',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/conference_url'} })
    range: Optional[str] = Field(None, description="""To specify the effective range of recurrence instances from the instance specified by the recurrence identifier specified by the property. RFC 5545 - RANGE """, json_schema_extra = { "linkml_meta": {'alias': 'range',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/range'} })
    related: Optional[str] = Field(None, description="""To specify the relationship of the alarm trigger with respect to the start or end of the calendar component. RFC 5545 - RELATED""", json_schema_extra = { "linkml_meta": {'alias': 'related',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/related'} })
    role: Optional[str] = Field(None, description="""To specify the participation role for the calendar user specified by the property. RFC 5545 - ROLE""", json_schema_extra = { "linkml_meta": {'alias': 'role',
         'domain_of': ['RoledProjectEntities',
                       'RoledExperimentEntities',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/role'} })
    tzid: Optional[str] = Field(None, description="""To specify the identifier for the time zone definition for a time component in the property value. RFC 5545 - TZID""", json_schema_extra = { "linkml_meta": {'alias': 'tzid',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/tzid'} })
    offset_utc: Optional[int] = Field(None, description=""" This value type is used to identify properties that contain an offset from UTC to local time (+ or - num. hours) . RFC 5545 -  UTC-OFFSET""", json_schema_extra = { "linkml_meta": {'alias': 'offset_utc',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/offset_utc'} })
    alarm_repeat_json: Optional[dict] = Field(None, description="""advanced alarm repeat expressions possible, e.g. for uneven occurrences""", json_schema_extra = { "linkml_meta": {'alias': 'alarm_repeat_json',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/alarm_repeat_json'} })
    event_repeat: Optional[str] = Field(None, description="""apache airflow ('@daily', '@weekly') or cron expression like entry: '12 23 * * *' : every day at 23:12h do this task""", json_schema_extra = { "linkml_meta": {'alias': 'event_repeat',
         'domain_of': ['ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectCalendar/event_repeat'} })
    event_repeat_json: Optional[dict] = Field(None, description="""advanced event repeat expressions possible, e.g. for uneven occurrences""", json_schema_extra = { "linkml_meta": {'alias': 'event_repeat_json',
         'domain_of': ['ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectCalendar/event_repeat_json'} })
    projectcalendar_id: Optional[str] = Field(None, description="""ProjectCalendar - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'projectcalendar_id',
         'domain_of': ['ProjectCalendar'],
         'slot_uri': 'lara:projects/ProjectCalendar/projectcalendar_id'} })
    user: Optional[str] = Field(None, description="""LARA User, who created the calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'user',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:people/LaraUser'} })
    project: Optional[str] = Field(None, description="""project to be scheduled""", json_schema_extra = { "linkml_meta": {'alias': 'project',
         'domain_of': ['RoledProjectEntities',
                       'OrderedProjectsSubset',
                       'ProjectCalendar'],
         'slot_uri': 'lara:projects/Project'} })
    tags: Optional[List[str]] = Field(None, description="""tags of calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:base/Tag'} })
    attendees: Optional[List[str]] = Field(None, description="""attendees of the meeting""", json_schema_extra = { "linkml_meta": {'alias': 'attendees',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:people/LaraUser'} })


class ExperimentCalendar(ConfiguredBaseModel):
    """
    \" Experiment Calendar \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:projects/ExperimentCalendar',
         'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    name_display: str = Field(..., description="""title of the calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/name_display'} })
    calendar_url: Optional[str] = Field(None, description="""Universal Resource Locator (URL), to google calendar, iCalendar, .... """, json_schema_extra = { "linkml_meta": {'alias': 'calendar_url',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/calendar_url'} })
    summary: Optional[str] = Field(None, description="""short summary text of the calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'summary',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/summary'} })
    description: Optional[str] = Field(None, description="""text of the calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ExperimentCalendar/description'} })
    color: Optional[str] = Field(None, description="""text of the calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'color',
         'domain_of': ['Project',
                       'Experiment',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/color'} })
    ics: Optional[str] = Field(None, description="""iCalendar entry in (RFC 5545) file format""", json_schema_extra = { "linkml_meta": {'alias': 'ics',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/ics'} })
    datetime_start: str = Field(..., description="""start date & time of the event. RFC 5545 - DTSTART""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_start',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ExperimentCalendar/datetime_start'} })
    datetime_end: str = Field(..., description="""end datetime of the event. RFC 5545 - DTEND""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_end',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ExperimentCalendar/datetime_end'} })
    duration: Optional[str] = Field(None, description=""" This value type is used to identify properties that contain a duration of time. RFC 5545 - DURATION""", json_schema_extra = { "linkml_meta": {'alias': 'duration',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/duration'} })
    all_day: bool = Field(..., description="""All day event ? (boolean)""", json_schema_extra = { "linkml_meta": {'alias': 'all_day',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/all_day'} })
    created: str = Field(..., description="""end datetime of the event""", json_schema_extra = { "linkml_meta": {'alias': 'created',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/created'} })
    datetime_last_modified: str = Field(..., description="""date and time when calendar entry was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/datetime_last_modified'} })
    timestamp: str = Field(..., description="""timestamp of the event""", json_schema_extra = { "linkml_meta": {'alias': 'timestamp',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/timestamp'} })
    location: Optional[str] = Field(None, description="""location""", json_schema_extra = { "linkml_meta": {'alias': 'location',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:base/Location'} })
    geolocation: Optional[str] = Field(None, description="""GEO location""", json_schema_extra = { "linkml_meta": {'alias': 'geolocation',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:base/GeoLocation'} })
    conference_url: Optional[str] = Field(None, description="""audio/video conference/meeting Universal Resource Locator (URL), e.g. zoom, jitsi, meet, ...""", json_schema_extra = { "linkml_meta": {'alias': 'conference_url',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/conference_url'} })
    range: Optional[str] = Field(None, description="""To specify the effective range of recurrence instances from the instance specified by the recurrence identifier specified by the property. RFC 5545 - RANGE """, json_schema_extra = { "linkml_meta": {'alias': 'range',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/range'} })
    related: Optional[str] = Field(None, description="""To specify the relationship of the alarm trigger with respect to the start or end of the calendar component. RFC 5545 - RELATED""", json_schema_extra = { "linkml_meta": {'alias': 'related',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/related'} })
    role: Optional[str] = Field(None, description="""To specify the participation role for the calendar user specified by the property. RFC 5545 - ROLE""", json_schema_extra = { "linkml_meta": {'alias': 'role',
         'domain_of': ['RoledProjectEntities',
                       'RoledExperimentEntities',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/role'} })
    tzid: Optional[str] = Field(None, description="""To specify the identifier for the time zone definition for a time component in the property value. RFC 5545 - TZID""", json_schema_extra = { "linkml_meta": {'alias': 'tzid',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/tzid'} })
    offset_utc: Optional[int] = Field(None, description=""" This value type is used to identify properties that contain an offset from UTC to local time (+ or - num. hours) . RFC 5545 -  UTC-OFFSET""", json_schema_extra = { "linkml_meta": {'alias': 'offset_utc',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/offset_utc'} })
    alarm_repeat_json: Optional[dict] = Field(None, description="""advanced alarm repeat expressions possible, e.g. for uneven occurrences""", json_schema_extra = { "linkml_meta": {'alias': 'alarm_repeat_json',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/alarm_repeat_json'} })
    event_repeat: Optional[str] = Field(None, description="""apache airflow ('@daily', '@weekly') or cron expression like entry: '12 23 * * *' : every day at 23:12h do this task""", json_schema_extra = { "linkml_meta": {'alias': 'event_repeat',
         'domain_of': ['ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ExperimentCalendar/event_repeat'} })
    event_repeat_json: Optional[dict] = Field(None, description="""advanced event repeat expressions possible, e.g. for uneven occurrences""", json_schema_extra = { "linkml_meta": {'alias': 'event_repeat_json',
         'domain_of': ['ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ExperimentCalendar/event_repeat_json'} })
    experimentcalendar_id: Optional[str] = Field(None, description="""ExperimentCalendar - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'experimentcalendar_id',
         'domain_of': ['ExperimentCalendar'],
         'slot_uri': 'lara:projects/ExperimentCalendar/experimentcalendar_id'} })
    user: Optional[str] = Field(None, description="""LARA User, who created the calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'user',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:people/LaraUser'} })
    experiment: Optional[str] = Field(None, description="""experiment to be scheduled""", json_schema_extra = { "linkml_meta": {'alias': 'experiment',
         'domain_of': ['RoledExperimentEntities',
                       'OrderedExperimentsSubset',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:projects/Experiment'} })
    tags: Optional[List[str]] = Field(None, description="""tags of calendar entry""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar'],
         'slot_uri': 'lara:base/Tag'} })
    attendees: Optional[List[str]] = Field(None, description="""attendees of the meeting""", json_schema_extra = { "linkml_meta": {'alias': 'attendees',
         'domain_of': ['ProjectCalendar', 'ExperimentCalendar'],
         'slot_uri': 'lara:people/LaraUser'} })


class ProjectSynchronisation(ConfiguredBaseModel):
    """
    \" Synchronisation settings for (recursive) LARA projects synchronisation with other LARA systems

        :param models: _description_
        :type models: _type_
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:projects/ProjectSynchronisation',
         'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    sync_id: Optional[str] = Field(None, description="""ProjectSynchronisation - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'sync_id',
         'domain_of': ['ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectSynchronisation/sync_id'} })
    namespace: Optional[str] = Field(None, description="""namespace of synchronisation""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:base/Namespace'} })
    name: Optional[str] = Field(None, description="""name of the synchronisaton""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectSynchronisation/name'} })
    server_target: Optional[str] = Field(None, description="""LARA server to be synchronised with""", json_schema_extra = { "linkml_meta": {'alias': 'server_target',
         'domain_of': ['ProjectSynchronisation'],
         'slot_uri': 'lara:base/LARASyncServer'} })
    datetime_start: str = Field(..., description="""synchronisation start""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_start',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectSynchronisation/datetime_start'} })
    datetime_end: str = Field(..., description="""synchronisation end""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_end',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectSynchronisation/datetime_end'} })
    mode: str = Field(..., description="""synchronisation mode: full, incremental""", json_schema_extra = { "linkml_meta": {'alias': 'mode',
         'domain_of': ['ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectSynchronisation/mode'} })
    update_policy: str = Field(..., description="""update policy: source, target, merge""", json_schema_extra = { "linkml_meta": {'alias': 'update_policy',
         'domain_of': ['ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectSynchronisation/update_policy'} })
    event_repeat: Optional[str] = Field(None, description="""prefect / apache airflow ('@daily', '@weekly') or cron expressionlike entry: '12 23 * * *' :  every day at 23:12h do this task""", json_schema_extra = { "linkml_meta": {'alias': 'event_repeat',
         'domain_of': ['ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectSynchronisation/event_repeat'} })
    event_repeat_json: Optional[dict] = Field(None, description="""advanced repeat expressions possible, e.g. for uneven occurrences""", json_schema_extra = { "linkml_meta": {'alias': 'event_repeat_json',
         'domain_of': ['ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectSynchronisation/event_repeat_json'} })
    config_json: Optional[dict] = Field(None, description="""advanced configuration settings in JSON format,e.g., for advanced settings like filters, mappings, ...""", json_schema_extra = { "linkml_meta": {'alias': 'config_json',
         'domain_of': ['ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectSynchronisation/config_json'} })
    logs: Optional[dict] = Field(None, description="""logs of the synchronisation""", json_schema_extra = { "linkml_meta": {'alias': 'logs',
         'domain_of': ['ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectSynchronisation/logs'} })
    status: Optional[str] = Field(None, description="""synchronisation status classifier: planned, started, in_progress, finished""", json_schema_extra = { "linkml_meta": {'alias': 'status',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectSynchronisation',
                       'ProjectSyncStatus'],
         'slot_uri': 'lara:base/ItemStatus'} })
    log_file: Optional[str] = Field(None, description="""log file with rel. path/filename""", json_schema_extra = { "linkml_meta": {'alias': 'log_file',
         'domain_of': ['ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectSynchronisation/log_file'} })
    description: Optional[str] = Field(None, description="""description of extra data type""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['Task',
                       'Project',
                       'ProjectsSubset',
                       'Experiment',
                       'ExperimentsSubset',
                       'ProjectCalendar',
                       'ExperimentCalendar',
                       'ProjectSynchronisation'],
         'slot_uri': 'lara:projects/ProjectSynchronisation/description'} })
    projects: Optional[List[str]] = Field(None, description="""projects""", json_schema_extra = { "linkml_meta": {'alias': 'projects',
         'domain_of': ['ProjectsSubset',
                       'ProjectSynchronisation',
                       'ProjectSyncStatus',
                       'Container'],
         'slot_uri': 'lara:projects/Project'} })


class ProjectSyncStatus(ConfiguredBaseModel):
    """
    \" Synchronisation status for (recursive) LARA projects synchronisation with other LARA systems \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:projects/ProjectSyncStatus',
         'from_schema': 'https://w3id.org/lara/lara_django_projects'})

    syncstatus_id: Optional[str] = Field(None, description="""ProjectSyncStatus - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'syncstatus_id',
         'domain_of': ['ProjectSyncStatus'],
         'slot_uri': 'lara:projects/ProjectSyncStatus/syncstatus_id'} })
    status: Optional[str] = Field(None, description="""scheduled, in-progress, interrupted, completed""", json_schema_extra = { "linkml_meta": {'alias': 'status',
         'domain_of': ['Task',
                       'Project',
                       'Experiment',
                       'ProjectSynchronisation',
                       'ProjectSyncStatus'],
         'slot_uri': 'lara:base/ItemStatus'} })
    server: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'server',
         'domain_of': ['ProjectSyncStatus'],
         'slot_uri': 'lara:base/LARASyncServer'} })
    datetime_last_synced: str = Field(..., description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_synced',
         'domain_of': ['ProjectSyncStatus'],
         'slot_uri': 'lara:projects/ProjectSyncStatus/datetime_last_synced'} })
    projects: Optional[List[str]] = Field(None, description="""projects""", json_schema_extra = { "linkml_meta": {'alias': 'projects',
         'domain_of': ['ProjectsSubset',
                       'ProjectSynchronisation',
                       'ProjectSyncStatus',
                       'Container'],
         'slot_uri': 'lara:projects/Project'} })


class Container(ConfiguredBaseModel):
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_projects', 'tree_root': True})

    tasks: Optional[List[Task]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'tasks', 'domain_of': ['Project', 'Experiment', 'Container']} })
    projects: Optional[List[Project]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'projects',
         'domain_of': ['ProjectsSubset',
                       'ProjectSynchronisation',
                       'ProjectSyncStatus',
                       'Container']} })
    roledprojectentitiess: Optional[List[RoledProjectEntities]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'roledprojectentitiess', 'domain_of': ['Container']} })
    projectssubsets: Optional[List[ProjectsSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'projectssubsets', 'domain_of': ['Container']} })
    orderedprojectssubsets: Optional[List[OrderedProjectsSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedprojectssubsets', 'domain_of': ['Container']} })
    experiments: Optional[List[Experiment]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'experiments',
         'domain_of': ['Project', 'ExperimentsSubset', 'Container']} })
    roledexperimententitiess: Optional[List[RoledExperimentEntities]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'roledexperimententitiess', 'domain_of': ['Container']} })
    experimentssubsets: Optional[List[ExperimentsSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'experimentssubsets', 'domain_of': ['Container']} })
    orderedexperimentssubsets: Optional[List[OrderedExperimentsSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedexperimentssubsets', 'domain_of': ['Container']} })
    projectcalendars: Optional[List[ProjectCalendar]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'projectcalendars', 'domain_of': ['Container']} })
    experimentcalendars: Optional[List[ExperimentCalendar]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'experimentcalendars', 'domain_of': ['Container']} })
    projectsynchronisations: Optional[List[ProjectSynchronisation]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'projectsynchronisations', 'domain_of': ['Container']} })
    projectsyncstatuss: Optional[List[ProjectSyncStatus]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'projectsyncstatuss', 'domain_of': ['Container']} })


# Model rebuild
# see https://pydantic-docs.helpmanual.io/usage/models/#rebuilding-a-model
ProcedureInstance.model_rebuild()
ItemStatus.model_rebuild()
OrganismInstance.model_rebuild()
MixtureInstance.model_rebuild()
ExternalResource.model_rebuild()
DeviceSetupInstance.model_rebuild()
DeviceInstance.model_rebuild()
Group.model_rebuild()
PolymerInstance.model_rebuild()
EntityRole.model_rebuild()
Entity.model_rebuild()
LabwareInstance.model_rebuild()
Data.model_rebuild()
Evaluation.model_rebuild()
PartInstance.model_rebuild()
Location.model_rebuild()
SubstanceInstance.model_rebuild()
GeoLocation.model_rebuild()
MethodInstance.model_rebuild()
LaraUser.model_rebuild()
LARASyncServer.model_rebuild()
Tag.model_rebuild()
Sample.model_rebuild()
Namespace.model_rebuild()
ProcessInstance.model_rebuild()
Task.model_rebuild()
Project.model_rebuild()
RoledProjectEntities.model_rebuild()
ProjectsSubset.model_rebuild()
OrderedProjectsSubset.model_rebuild()
Experiment.model_rebuild()
RoledExperimentEntities.model_rebuild()
ExperimentsSubset.model_rebuild()
OrderedExperimentsSubset.model_rebuild()
ProjectCalendar.model_rebuild()
ExperimentCalendar.model_rebuild()
ProjectSynchronisation.model_rebuild()
ProjectSyncStatus.model_rebuild()
Container.model_rebuild()

