"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_projects high_level_interface *

:details: lara_django_projects high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_projects
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc
from typing import Union

from google.protobuf.struct_pb2 import Struct
from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_projects_grpc.v1.lara_django_projects_pb2 as lara_django_projects_pb2
import lara_django_projects_grpc.v1.lara_django_projects_pb2_grpc as lara_django_projects_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if
from  lara_django_base_grpc.abstract_interface import LARAInterface, GRPCChannelSingleton, import_model_instance_from_file, export_model_instance_to_file, upload_file, download_file, update_file, upload_image, update_image, download_image, id_cache

import  lara_django_projects_grpc.lara_django_projects_data_model as projects_dm

logger = logging.getLogger(__name__)



#_________________  Task  ______________________


class TaskInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.task_class_client = (
        #     lara_django_projects_pb2_grpc.TaskclassByIRIControllerStub(channel)
        # )

        self.task_client = lara_django_projects_pb2_grpc.TaskControllerStub(channel)
        

        # self.task_full_client = lara_django_projects_pb2_grpc.TaskFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  tasks:  list[projects_dm.Task] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[projects_dm.Task]]:
        """ create a list of task instances,
               returns a list of task data model objects or ids_only

        :param tasks: list of task data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of task data model objects or ids_only
        """
        taskclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if task_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.task_class_client.Retrieve(
        #         lara_django_projects_pb2.TaskclassRetrieveRequest(iri=task_class_iri)
        #     )
        #     taskclass_id = res.taskclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving taskclass_id: {e}")
        for task in tasks:
            if task.namespace == "" or task.namespace == "default":
                    task.namespace = namespace_id
            # task.task_class = taskclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.task_client.Create(lara_django_projects_pb2.TaskRequest(**task.model_dump(exclude_unset=True))) for task in tasks )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("task_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating task: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        task_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[projects_dm.Task]:
        """ retrieve a list of task instances by task_id, name or filter_dict,
               returns a list of task data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  task_id is not None:
            try:
                res =  await self.task_client.Retrieve(
                    lara_django_projects_pb2.TaskRetrieveRequest(task_id=task_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( projects_dm.Task(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving task_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.task_client.List(
                    lara_django_projects_pb2.TaskListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ projects_dm.Task(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving task name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the task_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].task_id
        else:
            raise ValueError(f"Error retrieving task_id - no or too many results found.")
    
    async def get_by_id(self, task_id: str = None, id_only: bool = False) -> projects_dm.Task:
        """ retrieve a task data model by task_id """
        try:
            res = await self.task_client.Retrieve(
                lara_django_projects_pb2.TaskRetrieveRequest(task_id=task_id)
            )
            item = projects_dm.Task(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.task_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving task_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> projects_dm.Task | str:
        """ retrieve a task data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.task_client.RetrieveByNameNamespace(
                lara_django_projects_pb2.TaskRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["task_id"]
            if id_only:
                return self.item_id
            else:
                return projects_dm.Task(**item)
        except Exception as e:
            logger.error(f"Error retrieving task name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all tasks """
        if filter_dict is None:
            res = await self.task_client.List(lara_django_projects_pb2.TaskListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.task_client.List(
                lara_django_projects_pb2.TaskListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.task_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all tasks """
        if self.task_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.task_full_client.List(
                lara_django_projects_pb2.TaskFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.task_full_client.List(
                lara_django_projects_pb2.TaskFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, task : projects_dm.Task = None) -> None:
        """ update a task model instance """
        try:
            res = await self.task_client.Update(
                lara_django_projects_pb2.TaskRequest(**task.model_dump(exclude_unset=True)
            ))
        except Exception as e:
            logger.error(f"Error updating task_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a task by task_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.task_client.Destroy(lara_django_projects_pb2.TaskDestroyRequest(task_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting task_id: {e}")

#_________________  Project  ______________________


class ProjectInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.project_class_client = (
        #     lara_django_projects_pb2_grpc.ProjectclassByIRIControllerStub(channel)
        # )

        self.project_client = lara_django_projects_pb2_grpc.ProjectControllerStub(channel)
        

        # self.project_full_client = lara_django_projects_pb2_grpc.ProjectFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  projects:  list[projects_dm.Project] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[projects_dm.Project]]:
        """ create a list of project instances,
               returns a list of project data model objects or ids_only

        :param projects: list of project data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of project data model objects or ids_only
        """
        projectclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if project_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.project_class_client.Retrieve(
        #         lara_django_projects_pb2.ProjectclassRetrieveRequest(iri=project_class_iri)
        #     )
        #     projectclass_id = res.projectclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving projectclass_id: {e}")
        for project in projects:
            if project.namespace == "" or project.namespace == "default":
                    project.namespace = namespace_id
            # project.project_class = projectclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.project_client.Create(lara_django_projects_pb2.ProjectRequest(**project.model_dump(exclude_unset=True))) for project in projects )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("project_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating project: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        project_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[projects_dm.Project]:
        """ retrieve a list of project instances by project_id, name or filter_dict,
               returns a list of project data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  project_id is not None:
            try:
                res =  await self.project_client.Retrieve(
                    lara_django_projects_pb2.ProjectRetrieveRequest(project_id=project_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( projects_dm.Project(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving project_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.project_client.List(
                    lara_django_projects_pb2.ProjectListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ projects_dm.Project(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving project name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the project_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].project_id
        else:
            raise ValueError(f"Error retrieving project_id - no or too many results found.")
    
    async def get_by_id(self, project_id: str = None, id_only: bool = False) -> projects_dm.Project:
        """ retrieve a project data model by project_id """
        try:
            res = await self.project_client.Retrieve(
                lara_django_projects_pb2.ProjectRetrieveRequest(project_id=project_id)
            )
            item = projects_dm.Project(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.project_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving project_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> projects_dm.Project | str:
        """ retrieve a project data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.project_client.RetrieveByNameNamespace(
                lara_django_projects_pb2.ProjectRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["project_id"]
            if id_only:
                return self.item_id
            else:
                return projects_dm.Project(**item)
        except Exception as e:
            logger.error(f"Error retrieving project name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all projects """
        if filter_dict is None:
            res = await self.project_client.List(lara_django_projects_pb2.ProjectListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.project_client.List(
                lara_django_projects_pb2.ProjectListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.project_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all projects """
        if self.project_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.project_full_client.List(
                lara_django_projects_pb2.ProjectFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.project_full_client.List(
                lara_django_projects_pb2.ProjectFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, project : projects_dm.Project = None) -> None:
        """ update a project model instance """
        try:
            res = await self.project_client.Update(
                lara_django_projects_pb2.ProjectRequest(**project.model_dump(exclude_unset=True)
            ))
        except Exception as e:
            logger.error(f"Error updating project_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a project by project_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.project_client.Destroy(lara_django_projects_pb2.ProjectDestroyRequest(project_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting project_id: {e}")

#_________________  RoledProjectEntities  ______________________


class RoledProjectEntitiesInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.roledprojectentities_client = lara_django_projects_pb2_grpc.RoledProjectEntitiesControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  roledprojectentitiess:  list[projects_dm.RoledProjectEntities] = None,  ids_only: bool = False) -> Union[list[str], list[projects_dm.RoledProjectEntities]]:
        try:
            create_coroutines = ( self.roledprojectentities_client.Create(lara_django_projects_pb2.RoledProjectEntitiesRequest(**roledprojectentities.model_dump(exclude_unset=True))) for roledprojectentities in roledprojectentitiess )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.roledprojectentities_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating roledprojectentities: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        roledprojectentities_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[projects_dm.RoledProjectEntities]:
        """ retrieve a list of roledprojectentities instances by roledprojectentities_id, name or filter_dict,
               returns a list of roledprojectentities data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  roledprojectentities_id is not None:
            try:
                res =  await self.roledprojectentities_client.Retrieve(
                    lara_django_projects_pb2.RoledProjectEntitiesRetrieveRequest(roledprojectentities_id=roledprojectentities_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( projects_dm.RoledProjectEntities(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving roledprojectentities_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.roledprojectentities_client.List(
                    lara_django_projects_pb2.RoledProjectEntitiesListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ projects_dm.RoledProjectEntities(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving roledprojectentities name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the roledprojectentities_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].roledprojectentities_id
        else:
            raise ValueError(f"Error retrieving roledprojectentities_id - no or too many results found.")
    
    async def get_by_id(self, roledprojectentities_id: str = None) -> projects_dm.RoledProjectEntities:
        """ retrieve a roledprojectentities data model by roledprojectentities_id """
        try:
            res = await self.roledprojectentities_client.Retrieve(
                lara_django_projects_pb2.RoledProjectEntitiesRetrieveRequest(roledprojectentities_id=roledprojectentities_id)
            )
            return projects_dm.RoledProjectEntities(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving roledprojectentities_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> projects_dm.RoledProjectEntities | str:
        """ retrieve a roledprojectentities data model by name """
        try:
            res = await self.roledprojectentities_client.RetrieveByNameNamespace(
                lara_django_projects_pb2.RoledProjectEntitiesRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["roledprojectentities_id"]
            else:
                return projects_dm.RoledProjectEntities(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving roledprojectentities name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all roledprojectentitiess """
        if filter_dict is None:
            res = await self.roledprojectentities_client.List(lara_django_projects_pb2.RoledProjectEntitiesListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.roledprojectentities_client.List(
                lara_django_projects_pb2.RoledProjectEntitiesListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.roledprojectentities_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all roledprojectentitiess """
        if self.roledprojectentities_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.roledprojectentities_full_client.List(
                lara_django_projects_pb2.RoledProjectEntitiesFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.roledprojectentities_full_client.List(
                lara_django_projects_pb2.RoledProjectEntitiesFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, roledprojectentities : projects_dm.RoledProjectEntities = None) -> None:
        """ update a roledprojectentities model instance """
        try:
            res = await self.roledprojectentities_client.Update(
                lara_django_projects_pb2.RoledProjectEntitiesRequest(**roledprojectentities.model_dump(exclude_unset=True)
            ))
        except Exception as e:
            logger.error(f"Error updating roledprojectentities_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a roledprojectentities by roledprojectentities_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.roledprojectentities_client.Destroy(lara_django_projects_pb2.RoledProjectEntitiesDestroyRequest(roledprojectentities_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting roledprojectentities_id: {e}")

#_________________  ProjectsSubset  ______________________


class ProjectsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.projectssubset_class_client = (
        #     lara_django_projects_pb2_grpc.ProjectsSubsetclassByIRIControllerStub(channel)
        # )

        self.projectssubset_client = lara_django_projects_pb2_grpc.ProjectsSubsetControllerStub(channel)
        

        # self.projectssubset_full_client = lara_django_projects_pb2_grpc.ProjectsSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  projectssubsets:  list[projects_dm.ProjectsSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[projects_dm.ProjectsSubset]]:
        """ create a list of projectssubset instances,
               returns a list of projectssubset data model objects or ids_only

        :param projectssubsets: list of projectssubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of projectssubset data model objects or ids_only
        """
        projectssubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if projectssubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.projectssubset_class_client.Retrieve(
        #         lara_django_projects_pb2.ProjectsSubsetclassRetrieveRequest(iri=projectssubset_class_iri)
        #     )
        #     projectssubsetclass_id = res.projectssubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving projectssubsetclass_id: {e}")
        for projectssubset in projectssubsets:
            if projectssubset.namespace == "" or projectssubset.namespace == "default":
                    projectssubset.namespace = namespace_id
            # projectssubset.projectssubset_class = projectssubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.projectssubset_client.Create(lara_django_projects_pb2.ProjectsSubsetRequest(**projectssubset.model_dump(exclude_unset=True))) for projectssubset in projectssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("projectssubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating projectssubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        projectssubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[projects_dm.ProjectsSubset]:
        """ retrieve a list of projectssubset instances by projectssubset_id, name or filter_dict,
               returns a list of projectssubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  projectssubset_id is not None:
            try:
                res =  await self.projectssubset_client.Retrieve(
                    lara_django_projects_pb2.ProjectsSubsetRetrieveRequest(projectssubset_id=projectssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( projects_dm.ProjectsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving projectssubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.projectssubset_client.List(
                    lara_django_projects_pb2.ProjectsSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ projects_dm.ProjectsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving projectssubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the projectssubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].projectssubset_id
        else:
            raise ValueError(f"Error retrieving projectssubset_id - no or too many results found.")
    
    async def get_by_id(self, projectssubset_id: str = None, id_only: bool = False) -> projects_dm.ProjectsSubset:
        """ retrieve a projectssubset data model by projectssubset_id """
        try:
            res = await self.projectssubset_client.Retrieve(
                lara_django_projects_pb2.ProjectsSubsetRetrieveRequest(projectssubset_id=projectssubset_id)
            )
            item = projects_dm.ProjectsSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.projectssubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving projectssubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> projects_dm.ProjectsSubset | str:
        """ retrieve a projectssubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.projectssubset_client.RetrieveByNameNamespace(
                lara_django_projects_pb2.ProjectsSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["projectssubset_id"]
            if id_only:
                return self.item_id
            else:
                return projects_dm.ProjectsSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving projectssubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all projectssubsets """
        if filter_dict is None:
            res = await self.projectssubset_client.List(lara_django_projects_pb2.ProjectsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.projectssubset_client.List(
                lara_django_projects_pb2.ProjectsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.projectssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all projectssubsets """
        if self.projectssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.projectssubset_full_client.List(
                lara_django_projects_pb2.ProjectsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.projectssubset_full_client.List(
                lara_django_projects_pb2.ProjectsSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, projectssubset : projects_dm.ProjectsSubset = None) -> None:
        """ update a projectssubset model instance """
        try:
            res = await self.projectssubset_client.Update(
                lara_django_projects_pb2.ProjectsSubsetRequest(**projectssubset.model_dump(exclude_unset=True)
            ))
        except Exception as e:
            logger.error(f"Error updating projectssubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a projectssubset by projectssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.projectssubset_client.Destroy(lara_django_projects_pb2.ProjectsSubsetDestroyRequest(projectssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting projectssubset_id: {e}")

#_________________  OrderedProjectsSubset  ______________________


class OrderedProjectsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedprojectssubset_client = lara_django_projects_pb2_grpc.OrderedProjectsSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  orderedprojectssubsets:  list[projects_dm.OrderedProjectsSubset] = None,  ids_only: bool = False) -> Union[list[str], list[projects_dm.OrderedProjectsSubset]]:
        try:
            create_coroutines = ( self.orderedprojectssubset_client.Create(lara_django_projects_pb2.OrderedProjectsSubsetRequest(**orderedprojectssubset.model_dump(exclude_unset=True))) for orderedprojectssubset in orderedprojectssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedprojectssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedprojectssubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedprojectssubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[projects_dm.OrderedProjectsSubset]:
        """ retrieve a list of orderedprojectssubset instances by orderedprojectssubset_id, name or filter_dict,
               returns a list of orderedprojectssubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedprojectssubset_id is not None:
            try:
                res =  await self.orderedprojectssubset_client.Retrieve(
                    lara_django_projects_pb2.OrderedProjectsSubsetRetrieveRequest(orderedprojectssubset_id=orderedprojectssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( projects_dm.OrderedProjectsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedprojectssubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedprojectssubset_client.List(
                    lara_django_projects_pb2.OrderedProjectsSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ projects_dm.OrderedProjectsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedprojectssubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedprojectssubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedprojectssubset_id
        else:
            raise ValueError(f"Error retrieving orderedprojectssubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedprojectssubset_id: str = None) -> projects_dm.OrderedProjectsSubset:
        """ retrieve a orderedprojectssubset data model by orderedprojectssubset_id """
        try:
            res = await self.orderedprojectssubset_client.Retrieve(
                lara_django_projects_pb2.OrderedProjectsSubsetRetrieveRequest(orderedprojectssubset_id=orderedprojectssubset_id)
            )
            return projects_dm.OrderedProjectsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedprojectssubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> projects_dm.OrderedProjectsSubset | str:
        """ retrieve a orderedprojectssubset data model by name """
        try:
            res = await self.orderedprojectssubset_client.RetrieveByNameNamespace(
                lara_django_projects_pb2.OrderedProjectsSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedprojectssubset_id"]
            else:
                return projects_dm.OrderedProjectsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedprojectssubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedprojectssubsets """
        if filter_dict is None:
            res = await self.orderedprojectssubset_client.List(lara_django_projects_pb2.OrderedProjectsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedprojectssubset_client.List(
                lara_django_projects_pb2.OrderedProjectsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedprojectssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedprojectssubsets """
        if self.orderedprojectssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedprojectssubset_full_client.List(
                lara_django_projects_pb2.OrderedProjectsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedprojectssubset_full_client.List(
                lara_django_projects_pb2.OrderedProjectsSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, orderedprojectssubset : projects_dm.OrderedProjectsSubset = None) -> None:
        """ update a orderedprojectssubset model instance """
        try:
            res = await self.orderedprojectssubset_client.Update(
                lara_django_projects_pb2.OrderedProjectsSubsetRequest(**orderedprojectssubset.model_dump(exclude_unset=True)
            ))
        except Exception as e:
            logger.error(f"Error updating orderedprojectssubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedprojectssubset by orderedprojectssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedprojectssubset_client.Destroy(lara_django_projects_pb2.OrderedProjectsSubsetDestroyRequest(orderedprojectssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedprojectssubset_id: {e}")

#_________________  Experiment  ______________________


class ExperimentInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.experiment_class_client = (
        #     lara_django_projects_pb2_grpc.ExperimentclassByIRIControllerStub(channel)
        # )

        self.experiment_client = lara_django_projects_pb2_grpc.ExperimentControllerStub(channel)
        

        # self.experiment_full_client = lara_django_projects_pb2_grpc.ExperimentFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  experiments:  list[projects_dm.Experiment] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[projects_dm.Experiment]]:
        """ create a list of experiment instances,
               returns a list of experiment data model objects or ids_only

        :param experiments: list of experiment data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of experiment data model objects or ids_only
        """
        experimentclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if experiment_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.experiment_class_client.Retrieve(
        #         lara_django_projects_pb2.ExperimentclassRetrieveRequest(iri=experiment_class_iri)
        #     )
        #     experimentclass_id = res.experimentclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving experimentclass_id: {e}")
        for experiment in experiments:
            if experiment.namespace == "" or experiment.namespace == "default":
                    experiment.namespace = namespace_id
            # experiment.experiment_class = experimentclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.experiment_client.Create(lara_django_projects_pb2.ExperimentRequest(**experiment.model_dump(exclude_unset=True))) for experiment in experiments )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("experiment_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating experiment: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        experiment_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[projects_dm.Experiment]:
        """ retrieve a list of experiment instances by experiment_id, name or filter_dict,
               returns a list of experiment data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  experiment_id is not None:
            try:
                res =  await self.experiment_client.Retrieve(
                    lara_django_projects_pb2.ExperimentRetrieveRequest(experiment_id=experiment_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( projects_dm.Experiment(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving experiment_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.experiment_client.List(
                    lara_django_projects_pb2.ExperimentListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ projects_dm.Experiment(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving experiment name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the experiment_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].experiment_id
        else:
            raise ValueError(f"Error retrieving experiment_id - no or too many results found.")
    
    async def get_by_id(self, experiment_id: str = None, id_only: bool = False) -> projects_dm.Experiment:
        """ retrieve a experiment data model by experiment_id """
        try:
            res = await self.experiment_client.Retrieve(
                lara_django_projects_pb2.ExperimentRetrieveRequest(experiment_id=experiment_id)
            )
            item = projects_dm.Experiment(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.experiment_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving experiment_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> projects_dm.Experiment | str:
        """ retrieve a experiment data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.experiment_client.RetrieveByNameNamespace(
                lara_django_projects_pb2.ExperimentRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["experiment_id"]
            if id_only:
                return self.item_id
            else:
                return projects_dm.Experiment(**item)
        except Exception as e:
            logger.error(f"Error retrieving experiment name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all experiments """
        if filter_dict is None:
            res = await self.experiment_client.List(lara_django_projects_pb2.ExperimentListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.experiment_client.List(
                lara_django_projects_pb2.ExperimentListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.experiment_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all experiments """
        if self.experiment_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.experiment_full_client.List(
                lara_django_projects_pb2.ExperimentFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.experiment_full_client.List(
                lara_django_projects_pb2.ExperimentFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, experiment : projects_dm.Experiment = None) -> None:
        """ update a experiment model instance """
        try:
            res = await self.experiment_client.Update(
                lara_django_projects_pb2.ExperimentRequest(**experiment.model_dump(exclude_unset=True)
            ))
        except Exception as e:
            logger.error(f"Error updating experiment_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a experiment by experiment_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.experiment_client.Destroy(lara_django_projects_pb2.ExperimentDestroyRequest(experiment_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting experiment_id: {e}")

#_________________  RoledExperimentEntities  ______________________


class RoledExperimentEntitiesInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.roledexperimententities_client = lara_django_projects_pb2_grpc.RoledExperimentEntitiesControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  roledexperimententitiess:  list[projects_dm.RoledExperimentEntities] = None,  ids_only: bool = False) -> Union[list[str], list[projects_dm.RoledExperimentEntities]]:
        try:
            create_coroutines = ( self.roledexperimententities_client.Create(lara_django_projects_pb2.RoledExperimentEntitiesRequest(**roledexperimententities.model_dump(exclude_unset=True))) for roledexperimententities in roledexperimententitiess )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.roledexperimententities_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating roledexperimententities: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        roledexperimententities_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[projects_dm.RoledExperimentEntities]:
        """ retrieve a list of roledexperimententities instances by roledexperimententities_id, name or filter_dict,
               returns a list of roledexperimententities data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  roledexperimententities_id is not None:
            try:
                res =  await self.roledexperimententities_client.Retrieve(
                    lara_django_projects_pb2.RoledExperimentEntitiesRetrieveRequest(roledexperimententities_id=roledexperimententities_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( projects_dm.RoledExperimentEntities(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving roledexperimententities_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.roledexperimententities_client.List(
                    lara_django_projects_pb2.RoledExperimentEntitiesListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ projects_dm.RoledExperimentEntities(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving roledexperimententities name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the roledexperimententities_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].roledexperimententities_id
        else:
            raise ValueError(f"Error retrieving roledexperimententities_id - no or too many results found.")
    
    async def get_by_id(self, roledexperimententities_id: str = None) -> projects_dm.RoledExperimentEntities:
        """ retrieve a roledexperimententities data model by roledexperimententities_id """
        try:
            res = await self.roledexperimententities_client.Retrieve(
                lara_django_projects_pb2.RoledExperimentEntitiesRetrieveRequest(roledexperimententities_id=roledexperimententities_id)
            )
            return projects_dm.RoledExperimentEntities(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving roledexperimententities_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> projects_dm.RoledExperimentEntities | str:
        """ retrieve a roledexperimententities data model by name """
        try:
            res = await self.roledexperimententities_client.RetrieveByNameNamespace(
                lara_django_projects_pb2.RoledExperimentEntitiesRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["roledexperimententities_id"]
            else:
                return projects_dm.RoledExperimentEntities(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving roledexperimententities name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all roledexperimententitiess """
        if filter_dict is None:
            res = await self.roledexperimententities_client.List(lara_django_projects_pb2.RoledExperimentEntitiesListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.roledexperimententities_client.List(
                lara_django_projects_pb2.RoledExperimentEntitiesListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.roledexperimententities_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all roledexperimententitiess """
        if self.roledexperimententities_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.roledexperimententities_full_client.List(
                lara_django_projects_pb2.RoledExperimentEntitiesFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.roledexperimententities_full_client.List(
                lara_django_projects_pb2.RoledExperimentEntitiesFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, roledexperimententities : projects_dm.RoledExperimentEntities = None) -> None:
        """ update a roledexperimententities model instance """
        try:
            res = await self.roledexperimententities_client.Update(
                lara_django_projects_pb2.RoledExperimentEntitiesRequest(**roledexperimententities.model_dump(exclude_unset=True)
            ))
        except Exception as e:
            logger.error(f"Error updating roledexperimententities_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a roledexperimententities by roledexperimententities_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.roledexperimententities_client.Destroy(lara_django_projects_pb2.RoledExperimentEntitiesDestroyRequest(roledexperimententities_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting roledexperimententities_id: {e}")

#_________________  ExperimentsSubset  ______________________


class ExperimentsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.experimentssubset_class_client = (
        #     lara_django_projects_pb2_grpc.ExperimentsSubsetclassByIRIControllerStub(channel)
        # )

        self.experimentssubset_client = lara_django_projects_pb2_grpc.ExperimentsSubsetControllerStub(channel)
        

        # self.experimentssubset_full_client = lara_django_projects_pb2_grpc.ExperimentsSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  experimentssubsets:  list[projects_dm.ExperimentsSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[projects_dm.ExperimentsSubset]]:
        """ create a list of experimentssubset instances,
               returns a list of experimentssubset data model objects or ids_only

        :param experimentssubsets: list of experimentssubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of experimentssubset data model objects or ids_only
        """
        experimentssubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if experimentssubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.experimentssubset_class_client.Retrieve(
        #         lara_django_projects_pb2.ExperimentsSubsetclassRetrieveRequest(iri=experimentssubset_class_iri)
        #     )
        #     experimentssubsetclass_id = res.experimentssubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving experimentssubsetclass_id: {e}")
        for experimentssubset in experimentssubsets:
            if experimentssubset.namespace == "" or experimentssubset.namespace == "default":
                    experimentssubset.namespace = namespace_id
            # experimentssubset.experimentssubset_class = experimentssubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.experimentssubset_client.Create(lara_django_projects_pb2.ExperimentsSubsetRequest(**experimentssubset.model_dump(exclude_unset=True))) for experimentssubset in experimentssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("experimentssubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating experimentssubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        experimentssubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[projects_dm.ExperimentsSubset]:
        """ retrieve a list of experimentssubset instances by experimentssubset_id, name or filter_dict,
               returns a list of experimentssubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  experimentssubset_id is not None:
            try:
                res =  await self.experimentssubset_client.Retrieve(
                    lara_django_projects_pb2.ExperimentsSubsetRetrieveRequest(experimentssubset_id=experimentssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( projects_dm.ExperimentsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving experimentssubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.experimentssubset_client.List(
                    lara_django_projects_pb2.ExperimentsSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ projects_dm.ExperimentsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving experimentssubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the experimentssubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].experimentssubset_id
        else:
            raise ValueError(f"Error retrieving experimentssubset_id - no or too many results found.")
    
    async def get_by_id(self, experimentssubset_id: str = None, id_only: bool = False) -> projects_dm.ExperimentsSubset:
        """ retrieve a experimentssubset data model by experimentssubset_id """
        try:
            res = await self.experimentssubset_client.Retrieve(
                lara_django_projects_pb2.ExperimentsSubsetRetrieveRequest(experimentssubset_id=experimentssubset_id)
            )
            item = projects_dm.ExperimentsSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.experimentssubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving experimentssubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> projects_dm.ExperimentsSubset | str:
        """ retrieve a experimentssubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.experimentssubset_client.RetrieveByNameNamespace(
                lara_django_projects_pb2.ExperimentsSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["experimentssubset_id"]
            if id_only:
                return self.item_id
            else:
                return projects_dm.ExperimentsSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving experimentssubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all experimentssubsets """
        if filter_dict is None:
            res = await self.experimentssubset_client.List(lara_django_projects_pb2.ExperimentsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.experimentssubset_client.List(
                lara_django_projects_pb2.ExperimentsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.experimentssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all experimentssubsets """
        if self.experimentssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.experimentssubset_full_client.List(
                lara_django_projects_pb2.ExperimentsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.experimentssubset_full_client.List(
                lara_django_projects_pb2.ExperimentsSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, experimentssubset : projects_dm.ExperimentsSubset = None) -> None:
        """ update a experimentssubset model instance """
        try:
            res = await self.experimentssubset_client.Update(
                lara_django_projects_pb2.ExperimentsSubsetRequest(**experimentssubset.model_dump(exclude_unset=True)
            ))
        except Exception as e:
            logger.error(f"Error updating experimentssubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a experimentssubset by experimentssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.experimentssubset_client.Destroy(lara_django_projects_pb2.ExperimentsSubsetDestroyRequest(experimentssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting experimentssubset_id: {e}")

#_________________  OrderedExperimentsSubset  ______________________


class OrderedExperimentsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedexperimentssubset_client = lara_django_projects_pb2_grpc.OrderedExperimentsSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  orderedexperimentssubsets:  list[projects_dm.OrderedExperimentsSubset] = None,  ids_only: bool = False) -> Union[list[str], list[projects_dm.OrderedExperimentsSubset]]:
        try:
            create_coroutines = ( self.orderedexperimentssubset_client.Create(lara_django_projects_pb2.OrderedExperimentsSubsetRequest(**orderedexperimentssubset.model_dump(exclude_unset=True))) for orderedexperimentssubset in orderedexperimentssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedexperimentssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedexperimentssubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedexperimentssubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[projects_dm.OrderedExperimentsSubset]:
        """ retrieve a list of orderedexperimentssubset instances by orderedexperimentssubset_id, name or filter_dict,
               returns a list of orderedexperimentssubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedexperimentssubset_id is not None:
            try:
                res =  await self.orderedexperimentssubset_client.Retrieve(
                    lara_django_projects_pb2.OrderedExperimentsSubsetRetrieveRequest(orderedexperimentssubset_id=orderedexperimentssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( projects_dm.OrderedExperimentsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedexperimentssubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedexperimentssubset_client.List(
                    lara_django_projects_pb2.OrderedExperimentsSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ projects_dm.OrderedExperimentsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedexperimentssubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedexperimentssubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedexperimentssubset_id
        else:
            raise ValueError(f"Error retrieving orderedexperimentssubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedexperimentssubset_id: str = None) -> projects_dm.OrderedExperimentsSubset:
        """ retrieve a orderedexperimentssubset data model by orderedexperimentssubset_id """
        try:
            res = await self.orderedexperimentssubset_client.Retrieve(
                lara_django_projects_pb2.OrderedExperimentsSubsetRetrieveRequest(orderedexperimentssubset_id=orderedexperimentssubset_id)
            )
            return projects_dm.OrderedExperimentsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedexperimentssubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> projects_dm.OrderedExperimentsSubset | str:
        """ retrieve a orderedexperimentssubset data model by name """
        try:
            res = await self.orderedexperimentssubset_client.RetrieveByNameNamespace(
                lara_django_projects_pb2.OrderedExperimentsSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedexperimentssubset_id"]
            else:
                return projects_dm.OrderedExperimentsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedexperimentssubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedexperimentssubsets """
        if filter_dict is None:
            res = await self.orderedexperimentssubset_client.List(lara_django_projects_pb2.OrderedExperimentsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedexperimentssubset_client.List(
                lara_django_projects_pb2.OrderedExperimentsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedexperimentssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedexperimentssubsets """
        if self.orderedexperimentssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedexperimentssubset_full_client.List(
                lara_django_projects_pb2.OrderedExperimentsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedexperimentssubset_full_client.List(
                lara_django_projects_pb2.OrderedExperimentsSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, orderedexperimentssubset : projects_dm.OrderedExperimentsSubset = None) -> None:
        """ update a orderedexperimentssubset model instance """
        try:
            res = await self.orderedexperimentssubset_client.Update(
                lara_django_projects_pb2.OrderedExperimentsSubsetRequest(**orderedexperimentssubset.model_dump(exclude_unset=True)
            ))
        except Exception as e:
            logger.error(f"Error updating orderedexperimentssubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedexperimentssubset by orderedexperimentssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedexperimentssubset_client.Destroy(lara_django_projects_pb2.OrderedExperimentsSubsetDestroyRequest(orderedexperimentssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedexperimentssubset_id: {e}")

#_________________  ProjectCalendar  ______________________


class ProjectCalendarInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.projectcalendar_client = lara_django_projects_pb2_grpc.ProjectCalendarControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  projectcalendars:  list[projects_dm.ProjectCalendar] = None,  ids_only: bool = False) -> Union[list[str], list[projects_dm.ProjectCalendar]]:
        try:
            create_coroutines = ( self.projectcalendar_client.Create(lara_django_projects_pb2.ProjectCalendarRequest(**projectcalendar.model_dump(exclude_unset=True))) for projectcalendar in projectcalendars )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.projectcalendar_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating projectcalendar: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        projectcalendar_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[projects_dm.ProjectCalendar]:
        """ retrieve a list of projectcalendar instances by projectcalendar_id, name or filter_dict,
               returns a list of projectcalendar data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  projectcalendar_id is not None:
            try:
                res =  await self.projectcalendar_client.Retrieve(
                    lara_django_projects_pb2.ProjectCalendarRetrieveRequest(projectcalendar_id=projectcalendar_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( projects_dm.ProjectCalendar(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving projectcalendar_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.projectcalendar_client.List(
                    lara_django_projects_pb2.ProjectCalendarListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ projects_dm.ProjectCalendar(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving projectcalendar name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the projectcalendar_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].projectcalendar_id
        else:
            raise ValueError(f"Error retrieving projectcalendar_id - no or too many results found.")
    
    async def get_by_id(self, projectcalendar_id: str = None) -> projects_dm.ProjectCalendar:
        """ retrieve a projectcalendar data model by projectcalendar_id """
        try:
            res = await self.projectcalendar_client.Retrieve(
                lara_django_projects_pb2.ProjectCalendarRetrieveRequest(projectcalendar_id=projectcalendar_id)
            )
            return projects_dm.ProjectCalendar(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving projectcalendar_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> projects_dm.ProjectCalendar | str:
        """ retrieve a projectcalendar data model by name """
        try:
            res = await self.projectcalendar_client.RetrieveByNameNamespace(
                lara_django_projects_pb2.ProjectCalendarRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["projectcalendar_id"]
            else:
                return projects_dm.ProjectCalendar(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving projectcalendar name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all projectcalendars """
        if filter_dict is None:
            res = await self.projectcalendar_client.List(lara_django_projects_pb2.ProjectCalendarListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.projectcalendar_client.List(
                lara_django_projects_pb2.ProjectCalendarListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.projectcalendar_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all projectcalendars """
        if self.projectcalendar_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.projectcalendar_full_client.List(
                lara_django_projects_pb2.ProjectCalendarFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.projectcalendar_full_client.List(
                lara_django_projects_pb2.ProjectCalendarFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, projectcalendar : projects_dm.ProjectCalendar = None) -> None:
        """ update a projectcalendar model instance """
        try:
            res = await self.projectcalendar_client.Update(
                lara_django_projects_pb2.ProjectCalendarRequest(**projectcalendar.model_dump(exclude_unset=True)
            ))
        except Exception as e:
            logger.error(f"Error updating projectcalendar_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a projectcalendar by projectcalendar_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.projectcalendar_client.Destroy(lara_django_projects_pb2.ProjectCalendarDestroyRequest(projectcalendar_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting projectcalendar_id: {e}")

#_________________  ExperimentCalendar  ______________________


class ExperimentCalendarInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.experimentcalendar_client = lara_django_projects_pb2_grpc.ExperimentCalendarControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  experimentcalendars:  list[projects_dm.ExperimentCalendar] = None,  ids_only: bool = False) -> Union[list[str], list[projects_dm.ExperimentCalendar]]:
        try:
            create_coroutines = ( self.experimentcalendar_client.Create(lara_django_projects_pb2.ExperimentCalendarRequest(**experimentcalendar.model_dump(exclude_unset=True))) for experimentcalendar in experimentcalendars )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.experimentcalendar_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating experimentcalendar: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        experimentcalendar_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[projects_dm.ExperimentCalendar]:
        """ retrieve a list of experimentcalendar instances by experimentcalendar_id, name or filter_dict,
               returns a list of experimentcalendar data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  experimentcalendar_id is not None:
            try:
                res =  await self.experimentcalendar_client.Retrieve(
                    lara_django_projects_pb2.ExperimentCalendarRetrieveRequest(experimentcalendar_id=experimentcalendar_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( projects_dm.ExperimentCalendar(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving experimentcalendar_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.experimentcalendar_client.List(
                    lara_django_projects_pb2.ExperimentCalendarListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ projects_dm.ExperimentCalendar(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving experimentcalendar name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the experimentcalendar_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].experimentcalendar_id
        else:
            raise ValueError(f"Error retrieving experimentcalendar_id - no or too many results found.")
    
    async def get_by_id(self, experimentcalendar_id: str = None) -> projects_dm.ExperimentCalendar:
        """ retrieve a experimentcalendar data model by experimentcalendar_id """
        try:
            res = await self.experimentcalendar_client.Retrieve(
                lara_django_projects_pb2.ExperimentCalendarRetrieveRequest(experimentcalendar_id=experimentcalendar_id)
            )
            return projects_dm.ExperimentCalendar(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving experimentcalendar_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> projects_dm.ExperimentCalendar | str:
        """ retrieve a experimentcalendar data model by name """
        try:
            res = await self.experimentcalendar_client.RetrieveByNameNamespace(
                lara_django_projects_pb2.ExperimentCalendarRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["experimentcalendar_id"]
            else:
                return projects_dm.ExperimentCalendar(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving experimentcalendar name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all experimentcalendars """
        if filter_dict is None:
            res = await self.experimentcalendar_client.List(lara_django_projects_pb2.ExperimentCalendarListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.experimentcalendar_client.List(
                lara_django_projects_pb2.ExperimentCalendarListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.experimentcalendar_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all experimentcalendars """
        if self.experimentcalendar_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.experimentcalendar_full_client.List(
                lara_django_projects_pb2.ExperimentCalendarFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.experimentcalendar_full_client.List(
                lara_django_projects_pb2.ExperimentCalendarFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, experimentcalendar : projects_dm.ExperimentCalendar = None) -> None:
        """ update a experimentcalendar model instance """
        try:
            res = await self.experimentcalendar_client.Update(
                lara_django_projects_pb2.ExperimentCalendarRequest(**experimentcalendar.model_dump(exclude_unset=True)
            ))
        except Exception as e:
            logger.error(f"Error updating experimentcalendar_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a experimentcalendar by experimentcalendar_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.experimentcalendar_client.Destroy(lara_django_projects_pb2.ExperimentCalendarDestroyRequest(experimentcalendar_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting experimentcalendar_id: {e}")

#_________________  ProjectSynchronisation  ______________________


class ProjectSynchronisationInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.projectsynchronisation_class_client = (
        #     lara_django_projects_pb2_grpc.ProjectSynchronisationclassByIRIControllerStub(channel)
        # )

        self.projectsynchronisation_client = lara_django_projects_pb2_grpc.ProjectSynchronisationControllerStub(channel)
        
        self.item_id = None
        self.update_item_id = "projectsynchronisation_id"
        self.stub = self.projectsynchronisation_client

        self.file_download_info = lara_django_projects_pb2.FileDownloadInfo
        self.file_upload_chunk = lara_django_projects_pb2.FileUploadChunk


        # self.projectsynchronisation_full_client = lara_django_projects_pb2_grpc.ProjectSynchronisationFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    @upload_file  # needed for file upload
    async def create(self,  projectsynchronisations:  list[projects_dm.ProjectSynchronisation] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[projects_dm.ProjectSynchronisation]]:
        """ create a list of projectsynchronisation instances,
               returns a list of projectsynchronisation data model objects or ids_only

        :param projectsynchronisations: list of projectsynchronisation data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of projectsynchronisation data model objects or ids_only
        """
        projectsynchronisationclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if projectsynchronisation_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.projectsynchronisation_class_client.Retrieve(
        #         lara_django_projects_pb2.ProjectSynchronisationclassRetrieveRequest(iri=projectsynchronisation_class_iri)
        #     )
        #     projectsynchronisationclass_id = res.projectsynchronisationclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving projectsynchronisationclass_id: {e}")
        for projectsynchronisation in projectsynchronisations:
            if projectsynchronisation.namespace == "" or projectsynchronisation.namespace == "default":
                    projectsynchronisation.namespace = namespace_id
            # projectsynchronisation.projectsynchronisation_class = projectsynchronisationclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.projectsynchronisation_client.Create(lara_django_projects_pb2.ProjectSynchronisationRequest(**projectsynchronisation.model_dump(exclude_unset=True))) for projectsynchronisation in projectsynchronisations )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("projectsynchronisation_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating projectsynchronisation: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        projectsynchronisation_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[projects_dm.ProjectSynchronisation]:
        """ retrieve a list of projectsynchronisation instances by projectsynchronisation_id, name or filter_dict,
               returns a list of projectsynchronisation data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  projectsynchronisation_id is not None:
            try:
                res =  await self.projectsynchronisation_client.Retrieve(
                    lara_django_projects_pb2.ProjectSynchronisationRetrieveRequest(projectsynchronisation_id=projectsynchronisation_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( projects_dm.ProjectSynchronisation(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving projectsynchronisation_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.projectsynchronisation_client.List(
                    lara_django_projects_pb2.ProjectSynchronisationListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ projects_dm.ProjectSynchronisation(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving projectsynchronisation name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the projectsynchronisation_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].projectsynchronisation_id
        else:
            raise ValueError(f"Error retrieving projectsynchronisation_id - no or too many results found.")
    
    @download_file  # needed for file download
    async def get_by_id(self, projectsynchronisation_id: str = None, id_only: bool = False) -> projects_dm.ProjectSynchronisation:
        """ retrieve a projectsynchronisation data model by projectsynchronisation_id """
        try:
            res = await self.projectsynchronisation_client.Retrieve(
                lara_django_projects_pb2.ProjectSynchronisationRetrieveRequest(projectsynchronisation_id=projectsynchronisation_id)
            )
            item = projects_dm.ProjectSynchronisation(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.projectsynchronisation_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving projectsynchronisation_id: {e}")
    
    @download_file  # needed for file download
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> projects_dm.ProjectSynchronisation | str:
        """ retrieve a projectsynchronisation data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.projectsynchronisation_client.RetrieveByNameNamespace(
                lara_django_projects_pb2.ProjectSynchronisationRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["projectsynchronisation_id"]
            if id_only:
                return self.item_id
            else:
                return projects_dm.ProjectSynchronisation(**item)
        except Exception as e:
            logger.error(f"Error retrieving projectsynchronisation name: {e}")
   
    
    @download_file  # needed for file download
    async def get_file(self, projectsynchronisation_id : str = None, id_only : bool = True ) -> bytes | None:
        """ retrieve a file by data_id """
        self.item_id = projectsynchronisation_id
        
    
    async def get_file_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                filename_target : str = None,
                                as_byte_str : bool = None ) -> bytes | None:
        """ retrieve a file by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            # logger.warning(f"no namespace_uri provided, using default namespace: {namespace_uri}")
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            projectsynchronisation_id = await self.get_by_name(name=name, namespace_uri=namespace_uri, id_only=True)
            return await self.get_file(projectsynchronisation_id=projectsynchronisation_id, filename_target=filename_target, as_byte_str=as_byte_str, get_file=True)
        except Exception as e:
            logger.error(f"Error retrieving projectsynchronisation name: {e}")
        
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all projectsynchronisations """
        if filter_dict is None:
            res = await self.projectsynchronisation_client.List(lara_django_projects_pb2.ProjectSynchronisationListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.projectsynchronisation_client.List(
                lara_django_projects_pb2.ProjectSynchronisationListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.projectsynchronisation_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all projectsynchronisations """
        if self.projectsynchronisation_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.projectsynchronisation_full_client.List(
                lara_django_projects_pb2.ProjectSynchronisationFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.projectsynchronisation_full_client.List(
                lara_django_projects_pb2.ProjectSynchronisationFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    @update_file  # needed for file update
    async def update(self, projectsynchronisation : projects_dm.ProjectSynchronisation = None) -> None:
        """ update a projectsynchronisation model instance """
        try:
            res = await self.projectsynchronisation_client.Update(
                lara_django_projects_pb2.ProjectSynchronisationRequest(**projectsynchronisation.model_dump(exclude_unset=True)
            ))
        except Exception as e:
            logger.error(f"Error updating projectsynchronisation_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a projectsynchronisation by projectsynchronisation_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.projectsynchronisation_client.Destroy(lara_django_projects_pb2.ProjectSynchronisationDestroyRequest(projectsynchronisation_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting projectsynchronisation_id: {e}")

#_________________  ProjectSyncStatus  ______________________


class ProjectSyncStatusInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.projectsyncstatus_client = lara_django_projects_pb2_grpc.ProjectSyncStatusControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  projectsyncstatus:  list[projects_dm.ProjectSyncStatus] = None,  ids_only: bool = False) -> Union[list[str], list[projects_dm.ProjectSyncStatus]]:
        try:
            create_coroutines = ( self.projectsyncstatus_client.Create(lara_django_projects_pb2.ProjectSyncStatusRequest(**projectsyncstatus.model_dump(exclude_unset=True))) for projectsyncstatus in projectsyncstatus )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.projectsyncstatus_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating projectsyncstatus: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        projectsyncstatus_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[projects_dm.ProjectSyncStatus]:
        """ retrieve a list of projectsyncstatus instances by projectsyncstatus_id, name or filter_dict,
               returns a list of projectsyncstatus data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  projectsyncstatus_id is not None:
            try:
                res =  await self.projectsyncstatus_client.Retrieve(
                    lara_django_projects_pb2.ProjectSyncStatusRetrieveRequest(projectsyncstatus_id=projectsyncstatus_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( projects_dm.ProjectSyncStatus(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving projectsyncstatus_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.projectsyncstatus_client.List(
                    lara_django_projects_pb2.ProjectSyncStatusListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ projects_dm.ProjectSyncStatus(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving projectsyncstatus name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the projectsyncstatus_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].projectsyncstatus_id
        else:
            raise ValueError(f"Error retrieving projectsyncstatus_id - no or too many results found.")
    
    async def get_by_id(self, projectsyncstatus_id: str = None) -> projects_dm.ProjectSyncStatus:
        """ retrieve a projectsyncstatus data model by projectsyncstatus_id """
        try:
            res = await self.projectsyncstatus_client.Retrieve(
                lara_django_projects_pb2.ProjectSyncStatusRetrieveRequest(projectsyncstatus_id=projectsyncstatus_id)
            )
            return projects_dm.ProjectSyncStatus(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving projectsyncstatus_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> projects_dm.ProjectSyncStatus | str:
        """ retrieve a projectsyncstatus data model by name """
        try:
            res = await self.projectsyncstatus_client.RetrieveByNameNamespace(
                lara_django_projects_pb2.ProjectSyncStatusRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["projectsyncstatus_id"]
            else:
                return projects_dm.ProjectSyncStatus(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving projectsyncstatus name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all projectsyncstatuss """
        if filter_dict is None:
            res = await self.projectsyncstatus_client.List(lara_django_projects_pb2.ProjectSyncStatusListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.projectsyncstatus_client.List(
                lara_django_projects_pb2.ProjectSyncStatusListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.projectsyncstatus_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all projectsyncstatuss """
        if self.projectsyncstatus_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.projectsyncstatus_full_client.List(
                lara_django_projects_pb2.ProjectSyncStatusFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.projectsyncstatus_full_client.List(
                lara_django_projects_pb2.ProjectSyncStatusFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, projectsyncstatus : projects_dm.ProjectSyncStatus = None) -> None:
        """ update a projectsyncstatus model instance """
        try:
            res = await self.projectsyncstatus_client.Update(
                lara_django_projects_pb2.ProjectSyncStatusRequest(**projectsyncstatus.model_dump(exclude_unset=True)
            ))
        except Exception as e:
            logger.error(f"Error updating projectsyncstatus_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a projectsyncstatus by projectsyncstatus_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.projectsyncstatus_client.Destroy(lara_django_projects_pb2.ProjectSyncStatusDestroyRequest(projectsyncstatus_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting projectsyncstatus_id: {e}")

