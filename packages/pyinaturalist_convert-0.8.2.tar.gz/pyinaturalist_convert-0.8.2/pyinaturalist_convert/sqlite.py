"""Helper utilities to load data directly from CSV into a SQLite database"""

import sqlite3
from collections.abc import Callable
from contextlib import nullcontext
from csv import reader as csv_reader
from logging import getLogger
from operator import itemgetter
from pathlib import Path
from time import time
from typing import Optional

from .constants import DB_PATH, PathOrStr
from .download import MultiProgress, get_progress_spinner

logger = getLogger(__name__)


class ChunkReader:
    """A CSV reader that yields chunks of rows, with optional per-row transforms.

    Args:
        chunk_size: Number of rows to yield at a time
        fields: List of fields to include in each chunk
        transform: Optional callback ``(row: list, field_index: dict[str, int]) -> list``
            that modifies each row in place. ``field_index`` maps CSV column names to list
            positions. For extra fields listed in *fields* but absent from the CSV header,
            the transform should append values in the order they appear.
    """

    def __init__(
        self,
        f,
        chunk_size: int = 2000,
        fields: Optional[list[str]] = None,
        transform: Optional[Callable] = None,
        **kwargs,
    ):
        self.reader = csv_reader(f, **kwargs)
        self._chunk_size = chunk_size
        self.transform = transform
        self._getter = self._build_getter(fields)

    def _build_getter(self, fields: Optional[list[str]]) -> Optional[Callable]:
        """Build a column extractor function on to avoid unnecessary overhead from function calls
        and single-use data structures
        """
        # Determine which fields to include (by index)
        field_names = next(self.reader)

        if self.transform and fields:
            # Build field name -> index mapping for transforms
            self._field_index: Optional[dict[str, int]] = {
                name: i for i, name in enumerate(field_names)
            }
            # Extra fields that transforms will append (not in CSV header)
            n = len(field_names)
            for name in fields:
                if name not in self._field_index:
                    self._field_index[name] = n
                    n += 1
            include_idx: Optional[list] = [self._field_index[k] for k in fields]
        else:
            self._field_index = None
            include_idx = [field_names.index(k) for k in fields] if fields else None

        # Make the column extractor function
        getter: Optional[Callable] = None
        if include_idx:
            if len(include_idx) == 1:
                _ig = itemgetter(include_idx[0])
                getter = lambda row: (_ig(row),)
            else:
                getter = itemgetter(*include_idx)
        return getter

    def __iter__(self):
        return self

    def __next__(self):
        chunk: list[tuple] = []
        append = chunk.append

        try:
            for _ in range(self._chunk_size):
                row = self.reader.__next__()
                if self.transform:
                    row = self.transform(row, self._field_index)
                append(self._getter(row) if self._getter else tuple(row))
        except StopIteration:
            # Ignore first StopIteration to return final chunk
            if not chunk:
                raise
        return chunk


def get_fields(csv_path: PathOrStr, delimiter: str = ',') -> list[str]:
    with open(csv_path, encoding='utf-8') as f:
        reader = csv_reader(f, delimiter=delimiter)
        return next(reader)


def load_table(
    csv_path: PathOrStr,
    db_path: PathOrStr,
    table_name: Optional[str] = None,
    column_map: Optional[dict] = None,
    pk: str = 'id',
    progress: Optional[MultiProgress] = None,
    delimiter: str = ',',
    transform: Optional[Callable] = None,
    clear: bool = False,
    fast: bool = False,
):
    """Load a CSV file into a sqlite3 table.
    This is less efficient than the sqlite3 shell ``.import`` command, but easier to use.

    Example:
        # Minimal example to load data into a 'taxon' table in 'my_database.db'
        >>> from pyinaturalist_convert import load_table
        >>> load_table('taxon.csv', 'my_database.db')

    Args:
        csv_path: Path to CSV file
        db_path: Path to SQLite database
        table_name: Name of table to load into (defaults to csv_path basename)
        column_map: Dictionary mapping CSV column names to SQLite column names. And columns not
            listed will be ignored.
        pk: Primary key column name
        progress: Progress bar, if tracking loading from multiple files
        transform: Callback to transform a row before inserting into the database
        clear: Whether to clear existing data from the table before loading
        fast: Optimize for throughput rather than safety. Recommended only for single-threaded manual data load.
    """
    csv_path = Path(csv_path).expanduser()
    db_path = Path(db_path).expanduser()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    logger.info(f'Loading {csv_path} into {db_path}')

    # Use mapping from CSV to SQLite column names, if provided; otherwise use CSV names as-is
    if not column_map:
        csv_cols = db_cols = get_fields(csv_path, delimiter)
    else:
        csv_cols = list(column_map.keys())
        db_cols = list(column_map.values())

    table_name = table_name or csv_path.stem
    non_pk_cols = [k for k in db_cols if k != pk]
    table_cols = [f'{pk} INTEGER PRIMARY KEY'] + [f'{k} TEXT' for k in non_pk_cols]
    columns_str = ', '.join(db_cols)
    # Convert empty strings to null in SQL instead of python
    placeholders = ','.join(["NULLIF(?,'')"] * len(csv_cols))

    start = time()

    if progress:
        progress.start_job(csv_path)

    with sqlite3.connect(db_path, isolation_level=None if fast else 'DEFERRED') as conn:
        if fast:
            conn.execute('PRAGMA synchronous = OFF')
            conn.execute('PRAGMA journal_mode = OFF')
            conn.execute('PRAGMA cache_size = -64000')  # 64MB page cache
            conn.execute('PRAGMA mmap_size = 268435456')  # 256MB memory-mapped I/O
            conn.execute('PRAGMA temp_store = MEMORY')
            conn.execute('PRAGMA threads = 4')
        else:
            conn.execute('PRAGMA journal_mode = WAL')
            conn.execute('PRAGMA synchronous = NORMAL')  # Crash-safe with WAL
            conn.execute('PRAGMA busy_timeout = 5000')  # Avoid immediate SQLITE_BUSY errors
            conn.execute('PRAGMA cache_size = -16000')

        # Create table if it doesn't exist, and optionally clear it if it does
        conn.execute(f'CREATE TABLE IF NOT EXISTS {table_name} ({", ".join(table_cols)});')
        if clear:
            conn.execute(f'DELETE FROM {table_name}')

        stmt = f'INSERT INTO {table_name} ({columns_str}) VALUES ({placeholders})'
        with open(csv_path, encoding='utf-8', buffering=2**20) as f:
            reader = ChunkReader(
                f, chunk_size=50000, fields=csv_cols, delimiter=delimiter, transform=transform
            )

            if fast:
                conn.execute('BEGIN')
            for chunk in reader:
                conn.executemany(stmt, chunk)
                if progress:
                    progress.advance(len(chunk))

        conn.commit()

    logger.info(f'Completed in {time() - start:.2f}s')


def vacuum_analyze(
    table_names: list[str],
    db_path: PathOrStr = DB_PATH,
    show_spinner: bool = False,
    fast: bool = False,
):
    """Vacuum a SQLite database and analyze one or more tables. If loading multiple tables, this
    should be done once after loading all of them.

    Args:
        fast: Optimize connection settings for VACUUM throughput (large cache, temp tables in RAM)
    """
    msg = f'Vacuuming and analyzing {",".join(table_names)}'
    if show_spinner:
        spinner = get_progress_spinner(msg)
    else:
        logger.info(msg)
        spinner = nullcontext()

    with spinner, sqlite3.connect(db_path) as conn:
        if fast:
            conn.execute('PRAGMA cache_size = -64000')  # 64MB page cache
            conn.execute('PRAGMA temp_store = MEMORY')
            conn.execute('PRAGMA threads = 4')
        conn.execute('VACUUM')
        for table_name in table_names:
            conn.execute(f'ANALYZE {table_name}')


def _table_exists(conn, table_name):
    row = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table_name,)
    ).fetchone()
    return row is not None


def _create_table(conn, table_name, non_pk_cols, pk):
    # Assume an integer primary key and text columns for the rest
    table_cols = [f'{pk} INTEGER PRIMARY KEY'] + [f'{k} TEXT' for k in non_pk_cols]
    conn.execute(f'CREATE TABLE IF NOT EXISTS {table_name} ({", ".join(table_cols)});')
