"""Configuration module for FastMCP2 Drive Upload Server."""
