"""Google Docs tools package for FastMCP2."""
