from sweep_autocomplete.config import NEXT_EDIT_AUTOCOMPLETE_ENDPOINT


class NextEditAutocompleteService:
    active_endpoint = NEXT_EDIT_AUTOCOMPLETE_ENDPOINT


next_edit_autocomplete_service = NextEditAutocompleteService()
