from typing import Any


def not_none(argument: Any) -> bool:
    return argument is not None
