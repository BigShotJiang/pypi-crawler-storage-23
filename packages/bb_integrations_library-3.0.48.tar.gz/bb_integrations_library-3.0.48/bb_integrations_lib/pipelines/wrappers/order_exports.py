from typing import Type
from loguru import logger

from pydantic import BaseModel

from bb_integrations_lib.gravitate.rita_api import GravitateRitaAPI
from bb_integrations_lib.gravitate.sd_api import GravitateSDAPI
from bb_integrations_lib.pipelines.steps.exporting.bbd_export_order_bols_and_drops_step import BBDExportBolsAndDrops
from bb_integrations_lib.pipelines.steps.exporting.bbd_export_order_sftp import BBDExportOrderSFTPStep
from bb_integrations_lib.pipelines.steps.exporting.bbd_get_orders_to_export_step import BBDGetOrdersToExportStep
from bb_integrations_lib.pipelines.steps.exporting.bbd_set_order_export_status import BBDSetExportOrderStatus
from bb_integrations_lib.pipelines.steps.importing.load_file_to_dataframe_step import LoadFileToDataFrameStep
from bb_integrations_lib.protocols.pipelines import JobPipeline, Parser
from bb_integrations_lib.provider.ftp.client import FTPIntegrationClient
from bb_integrations_lib.shared.model import ERPStatus, FileType


class OrderExportConfig(BaseModel):
    file_base_name: str = "Gravitate-Order-Export"
    ftp_directory_path: str


class GenericOrderExportPipeline(JobPipeline):
    """
    Reusable order export pipeline.
    """

    @classmethod
    async def create(
        cls,
        config_id: str,
        tenant_name: str,
        sd_client: GravitateSDAPI,
        rita_client: GravitateRitaAPI,
        ftp_client: FTPIntegrationClient,
        secret_provider,
        export_config: OrderExportConfig,
        parser: Type[Parser],
        parser_kwargs: dict | None = None,
        include_allocation_matching: bool = True,
        send_reports: bool = True,
        test_order_numbers: list[str] | None = None,
    ):
        is_test = test_order_numbers is not None
        logger.info(f"Running in Test(={is_test}). May save files locally")

        steps = [
            {
                "id": "get_orders_to_export",
                "parent_id": None,
                "step": BBDGetOrdersToExportStep(
                    sd_client=sd_client,
                    step_key="Order Numbers To Export",
                    test_order_numbers=test_order_numbers,
                )
            },
        ]

        if not is_test:
            steps.append({
                "id": "stage_orders",
                "parent_id": "get_orders_to_export",
                "step": BBDSetExportOrderStatus(
                    sd_client=sd_client,
                    step_key="Stage Orders",
                    global_status_override=ERPStatus.staged
                )
            })

        steps.append({
            "id": "run_export",
            "parent_id": "stage_orders" if not is_test else "get_orders_to_export",
            "step": BBDExportBolsAndDrops(
                sd_client=sd_client,
                include_allocation_matching=include_allocation_matching,
                step_key="Format Orders for Export",
                file_base_name=export_config.file_base_name,
                parser=parser,
                parser_kwargs=parser_kwargs
            )
        })

        if is_test:
            steps.append({
                "id": "load_to_dataframe",
                "parent_id": "run_export",
                "step": LoadFileToDataFrameStep(
                    file_type=FileType.csv,
                    save_to="samples"
                )
            })
        else:
            steps.append({
                "id": "upload_report_to_ftp",
                "parent_id": "run_export",
                "step": BBDExportOrderSFTPStep(
                    sd_client=sd_client,
                    ftp_client=ftp_client,
                    ftp_destination_dir=export_config.ftp_directory_path,
                )
            })

        return cls(
            job_steps=steps,
            rita_client=rita_client,
            pipeline_name=f"{tenant_name} Order Export",
            pipeline_config_id=config_id,
            secret_provider=secret_provider,
            send_reports=send_reports,
        )

    async def run(self):
        """Execute the pipeline."""
        await self.execute()
