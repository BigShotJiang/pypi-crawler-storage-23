# This module previously contained PricingIntegrationGetter which has been removed.
# Client creation is now handled via APIFactory and clients are passed directly to PriceMapper.

raise DeprecationWarning("PricingIntegrationGetter has been removed.", )
