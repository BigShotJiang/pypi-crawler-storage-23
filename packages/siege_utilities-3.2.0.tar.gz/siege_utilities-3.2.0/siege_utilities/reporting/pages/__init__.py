"""
Pages submodule - OOP page hierarchy for reports
"""
from .page_models import Page, TitlePage, TableOfContentsPage, ContentPage

__all__ = ['Page', 'TitlePage', 'TableOfContentsPage', 'ContentPage']


