"""Tests for data_io utility functions."""

import os
import tempfile
import pytest
import numpy as np
from unittest.mock import MagicMock

from hivetracered.pipeline.utils.data_io import (
    get_filename_timestamp,
    is_parquet_serializable,
    make_parquet_compatible,
    save_to_csv,
    load_from_csv,
    save_to_parquet,
    load_from_parquet,
    save_to_json,
    load_from_json,
    save_to_xlsx,
    load_from_xlsx,
    save_pipeline_results,
    _prepare_filepath,
    _data_to_dataframe,
    _dataframe_to_data,
)


# --- Fixtures ---

@pytest.fixture
def tmp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d


@pytest.fixture
def simple_dict():
    return {"name": "test", "value": 42, "flag": True}


@pytest.fixture
def list_of_dicts():
    return [
        {"prompt": "hello", "response": "world", "score": 0.9},
        {"prompt": "foo", "response": "bar", "score": 0.5},
    ]


@pytest.fixture
def nested_dict():
    return {"config": {"model": "gpt-4", "temp": 0.7}, "results": [1, 2, 3]}


# --- get_filename_timestamp ---

def test_get_filename_timestamp_format():
    ts = get_filename_timestamp()
    assert len(ts) == 15  # YYYYMMDD_HHMMSS
    assert ts[8] == "_"
    assert ts.replace("_", "").isdigit()


# --- is_parquet_serializable ---

def test_parquet_serializable_primitives():
    assert is_parquet_serializable(42)
    assert is_parquet_serializable("hello")
    assert is_parquet_serializable(3.14)
    assert is_parquet_serializable(True)
    assert is_parquet_serializable(None)


def test_parquet_serializable_complex():
    assert not is_parquet_serializable(object())


# --- make_parquet_compatible ---

def test_make_parquet_compatible_primitives():
    assert make_parquet_compatible(42) == 42
    assert make_parquet_compatible("hello") == "hello"
    assert make_parquet_compatible(None) is None
    assert make_parquet_compatible(True) is True


def test_make_parquet_compatible_list():
    assert make_parquet_compatible([1, 2, 3]) == [1, 2, 3]


def test_make_parquet_compatible_numpy_array():
    arr = np.array([1, 2, 3])
    result = make_parquet_compatible(arr)
    assert result == [1, 2, 3]


def test_make_parquet_compatible_tuple():
    assert make_parquet_compatible((1, "a")) == (1, "a")


def test_make_parquet_compatible_set():
    result = make_parquet_compatible({1, 2})
    assert isinstance(result, set)
    assert result == {1, 2}


def test_make_parquet_compatible_dict():
    data = {"a": 1, "b": "hello"}
    assert make_parquet_compatible(data) == {"a": 1, "b": "hello"}


def test_make_parquet_compatible_empty_nested_dict():
    data = {"a": 1, "empty": {}}
    result = make_parquet_compatible(data)
    assert result == {"a": 1, "empty": None}


def test_make_parquet_compatible_model():
    mock_model = MagicMock()
    mock_model.__class__ = type("MockModel", (), {})
    # Make it pass isinstance(value, Model) by patching
    from hivetracered.models.base_model import Model
    mock_model_instance = MagicMock(spec=Model)
    mock_model_instance.get_params.return_value = {"model_name": "test"}
    result = make_parquet_compatible(mock_model_instance)
    assert result == {"model_name": "test"}


def test_make_parquet_compatible_attack():
    from hivetracered.attacks.base_attack import BaseAttack
    mock_attack = MagicMock(spec=BaseAttack)
    mock_attack.get_params.return_value = {"attack_type": "template"}
    result = make_parquet_compatible(mock_attack)
    assert result == {"attack_type": "template"}


def test_make_parquet_compatible_custom_object():
    class CustomObj:
        def __init__(self):
            self.x = 10
            self.y = "hello"
            self._private = "skip"
    result = make_parquet_compatible(CustomObj())
    assert result == {"CustomObj": {"x": 10, "y": "hello"}}


# --- _prepare_filepath ---

def test_prepare_filepath_creates_dir(tmp_dir):
    subdir = os.path.join(tmp_dir, "sub")
    path = _prepare_filepath(subdir, "test_123", ".csv")
    assert os.path.isdir(subdir)
    assert path.endswith(".csv")
    assert "test_123" in path


def test_prepare_filepath_adds_timestamp(tmp_dir):
    path = _prepare_filepath(tmp_dir, "nodigits", ".csv")
    # Should have added a timestamp (digits)
    basename = os.path.basename(path)
    assert basename.startswith("nodigits_")
    assert basename.endswith(".csv")


def test_prepare_filepath_strips_extension(tmp_dir):
    path = _prepare_filepath(tmp_dir, "file_123.csv", ".csv")
    assert not path.endswith(".csv.csv")
    assert path.endswith(".csv")


# --- _data_to_dataframe ---

def test_data_to_dataframe_list_of_dicts(list_of_dicts):
    df = _data_to_dataframe(list_of_dicts)
    assert list(df.columns) == ["prompt", "response", "score"]
    assert len(df) == 2


def test_data_to_dataframe_simple_dict(simple_dict):
    df = _data_to_dataframe(simple_dict)
    assert len(df) == 1
    assert "name" in df.columns


def test_data_to_dataframe_nested_dict(nested_dict):
    df = _data_to_dataframe(nested_dict)
    assert "data" in df.columns


# --- _dataframe_to_data ---

def test_dataframe_to_data_single_row():
    import pandas as pd
    df = pd.DataFrame([{"a": 1, "b": 2}])
    result = _dataframe_to_data(df)
    assert result == {"a": 1, "b": 2}


def test_dataframe_to_data_multiple_rows():
    import pandas as pd
    df = pd.DataFrame([{"a": 1}, {"a": 2}])
    result = _dataframe_to_data(df)
    assert result == [{"a": 1}, {"a": 2}]


def test_dataframe_to_data_data_column():
    import pandas as pd
    df = pd.DataFrame({"data": ["value"]})
    result = _dataframe_to_data(df)
    assert result == "value"


# --- CSV round-trip ---

def test_save_load_csv_simple(tmp_dir, simple_dict):
    path = save_to_csv(simple_dict, tmp_dir, "test_001")
    assert path.endswith(".csv")
    assert os.path.exists(path)
    loaded = load_from_csv(path)
    assert loaded["name"] == "test"
    assert loaded["value"] == 42


def test_save_load_csv_list_of_dicts(tmp_dir, list_of_dicts):
    path = save_to_csv(list_of_dicts, tmp_dir, "test_002")
    assert os.path.exists(path)
    loaded = load_from_csv(path)
    assert len(loaded) == 2
    assert loaded[0]["prompt"] == "hello"


# --- Parquet round-trip ---

def test_save_load_parquet_simple(tmp_dir, simple_dict):
    path = save_to_parquet(simple_dict, tmp_dir, "test_001")
    assert path.endswith(".parquet")
    assert os.path.exists(path)
    loaded = load_from_parquet(path)
    assert loaded["name"] == "test"
    assert loaded["value"] == 42


def test_save_load_parquet_list_of_dicts(tmp_dir, list_of_dicts):
    path = save_to_parquet(list_of_dicts, tmp_dir, "test_002")
    assert os.path.exists(path)
    loaded = load_from_parquet(path)
    assert len(loaded) == 2
    assert loaded[0]["prompt"] == "hello"


# --- JSON round-trip ---

def test_save_load_json_simple(tmp_dir, simple_dict):
    path = save_to_json(simple_dict, tmp_dir, "test_001")
    assert path.endswith(".json")
    assert os.path.exists(path)
    loaded = load_from_json(path)
    assert loaded["name"] == "test"


def test_save_load_json_list_of_dicts(tmp_dir, list_of_dicts):
    path = save_to_json(list_of_dicts, tmp_dir, "test_002")
    assert os.path.exists(path)
    loaded = load_from_json(path)
    assert len(loaded) == 2


# --- XLSX round-trip ---

def test_save_load_xlsx_simple(tmp_dir, simple_dict):
    path = save_to_xlsx(simple_dict, tmp_dir, "test_001")
    assert path.endswith(".xlsx")
    assert os.path.exists(path)
    loaded = load_from_xlsx(path)
    assert loaded["name"] == "test"
    assert loaded["value"] == 42


def test_save_load_xlsx_list_of_dicts(tmp_dir, list_of_dicts):
    path = save_to_xlsx(list_of_dicts, tmp_dir, "test_002")
    assert os.path.exists(path)
    loaded = load_from_xlsx(path)
    assert len(loaded) == 2
    assert loaded[0]["prompt"] == "hello"


# --- save_pipeline_results ---

def test_save_pipeline_results_csv(tmp_dir, simple_dict):
    result = save_pipeline_results(simple_dict, tmp_dir, "eval", format="csv")
    assert result["path"].endswith(".csv")
    assert os.path.exists(result["path"])
    assert "timestamp" in result


def test_save_pipeline_results_parquet(tmp_dir, simple_dict):
    result = save_pipeline_results(simple_dict, tmp_dir, "eval", format="parquet")
    assert result["path"].endswith(".parquet")
    assert os.path.exists(result["path"])


def test_save_pipeline_results_xlsx(tmp_dir, simple_dict):
    result = save_pipeline_results(simple_dict, tmp_dir, "eval", format="xlsx")
    assert result["path"].endswith(".xlsx")
    assert os.path.exists(result["path"])


def test_save_pipeline_results_default_format(tmp_dir, simple_dict):
    result = save_pipeline_results(simple_dict, tmp_dir, "eval")
    assert result["path"].endswith(".csv")


# --- Error handling ---

def test_load_csv_nonexistent():
    result = load_from_csv("/nonexistent/path.csv")
    assert result == {}


def test_load_parquet_nonexistent():
    result = load_from_parquet("/nonexistent/path.parquet")
    assert result == {}


def test_load_json_nonexistent():
    result = load_from_json("/nonexistent/path.json")
    assert result == {}


def test_load_xlsx_nonexistent():
    result = load_from_xlsx("/nonexistent/path.xlsx")
    assert result == {}
