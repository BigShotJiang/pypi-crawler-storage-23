# Logging

::: majordomo_llm.logging.LoggingLLM

::: majordomo_llm.logging.adapters.PostgresAdapter

::: majordomo_llm.logging.adapters.SqliteAdapter

::: majordomo_llm.logging.adapters.MySQLAdapter

::: majordomo_llm.logging.adapters.S3Adapter

::: majordomo_llm.logging.adapters.FileStorageAdapter
