# Base Classes

::: majordomo_llm.base.LLM

::: majordomo_llm.base.LLMResponse

::: majordomo_llm.base.LLMStreamResponse

::: majordomo_llm.base.LLMJSONResponse

::: majordomo_llm.base.LLMStructuredResponse
