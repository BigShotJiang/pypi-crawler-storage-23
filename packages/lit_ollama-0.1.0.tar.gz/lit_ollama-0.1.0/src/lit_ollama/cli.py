from lit_ollama.__about__ import __version__


def main():
    print(f"lit-ollama v{__version__}!")
