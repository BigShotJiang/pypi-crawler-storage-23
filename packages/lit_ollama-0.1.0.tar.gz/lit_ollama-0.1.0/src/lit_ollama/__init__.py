from lit_ollama.__about__ import __version__
