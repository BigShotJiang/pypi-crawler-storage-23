=======
History
=======

0.4.1 (2026-02-19)
------------------

* Major refactoring of Parcellation class with improved attribute handling
* Enhanced color table loading and export with multiple format support
* Added region adjacency computation to Parcellation
* Improved BIDS file entity extraction with parallel processing
* Added DiffusionScheme class for gradient visualization
* Enhanced Connectome class initialization and metrics computation
* Added derivatives inventory functionality
* Improved surface tools with PyVista fallback support
* Added usage examples notebooks
* Multiple bug fixes in mask handling, color processing, and data type conversion
* Improved documentation and code organization

0.3.4 (2025-01-09)
------------------

* Enhanced documentation and ReadTheDocs configuration
* Moved region growing method to imagetools module  
* Improved Sphinx autodoc configuration for better API documentation
* Multiple improvements to surface visualization and plotting functionality
* Added new morphometry and connectivity analysis tools
* Enhanced BIDS dataset handling and entity management
* Improved surface mesh operations and color mapping
* Added network analysis tools and visualization capabilities

0.3.1 (2025-05-22)
------------------

* Fourth release on PyPI. 
