# Copyright Kevin Deldycke <kevin@deldycke.com> and contributors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Definitions of ready-to-use groups.

This module contains all predefined :class:`~extra_platforms.Group` instances and
frozenset collections that organize traits into logical categories.
"""

from __future__ import annotations

from .agent_data import (
    CLAUDE_CODE,
    CLINE,
    CURSOR,
    UNKNOWN_AGENT,
)
from .architecture_data import (
    AARCH64,
    ARM,
    ARMV5TEL,
    ARMV6L,
    ARMV7L,
    ARMV8L,
    I386,
    I586,
    I686,
    LOONGARCH64,
    MIPS,
    MIPS64,
    MIPS64EL,
    MIPSEL,
    PPC,
    PPC64,
    PPC64LE,
    RISCV32,
    RISCV64,
    S390X,
    SPARC,
    SPARC64,
    UNKNOWN_ARCHITECTURE,
    WASM32,
    WASM64,
    X86_64,
)
from .ci_data import (
    AZURE_PIPELINES,
    BAMBOO,
    BUILDKITE,
    CIRCLE_CI,
    CIRRUS_CI,
    CODEBUILD,
    GITHUB_CI,
    GITLAB_CI,
    HEROKU_CI,
    TEAMCITY,
    TRAVIS_CI,
    UNKNOWN_CI,
)
from .group import Group
from .platform_data import (
    AIX,
    ALPINE,
    ALTLINUX,
    AMZN,
    ANDROID,
    ARCH,
    BUILDROOT,
    CACHYOS,
    CENTOS,
    CLOUDLINUX,
    CYGWIN,
    DEBIAN,
    DRAGONFLY_BSD,
    EXHERBO,
    FEDORA,
    FREEBSD,
    GENERIC_LINUX,
    GENTOO,
    GUIX,
    HAIKU,
    HURD,
    IBM_POWERKVM,
    ILLUMOS,
    KALI,
    KVMIBM,
    LINUXMINT,
    MACOS,
    MAGEIA,
    MANDRIVA,
    MANJARO,
    MIDNIGHTBSD,
    NETBSD,
    NOBARA,
    OPENBSD,
    OPENSUSE,
    OPENWRT,
    ORACLE,
    PARALLELS,
    PIDORA,
    RASPBIAN,
    RHEL,
    ROCKY,
    SCIENTIFIC,
    SLACKWARE,
    SLES,
    SOLARIS,
    SUNOS,
    TUMBLEWEED,
    TUXEDO,
    UBUNTU,
    ULTRAMARINE,
    UNKNOWN_PLATFORM,
    WINDOWS,
    WSL1,
    WSL2,
    XENSERVER,
)
from .shell_data import (
    ASH,
    BASH,
    CMD,
    CSH,
    DASH,
    FISH,
    KSH,
    NUSHELL,
    POWERSHELL,
    TCSH,
    UNKNOWN_SHELL,
    XONSH,
    ZSH,
)
from .terminal_data import (
    ALACRITTY,
    APPLE_TERMINAL,
    CONTOUR,
    FOOT,
    GHOSTTY,
    GNOME_TERMINAL,
    GNU_SCREEN,
    HYPER,
    ITERM2,
    KITTY,
    KONSOLE,
    RIO,
    TABBY,
    TILIX,
    TMUX,
    UNKNOWN_TERMINAL,
    VSCODE_TERMINAL,
    WEZTERM,
    WINDOWS_TERMINAL,
    XTERM,
    ZELLIJ,
)

# =============================================================================
# Architecture groups
# =============================================================================

ALL_ARCHITECTURES: Group = Group(
    "all_architectures",
    "All architectures",
    "🏛️",
    (
        AARCH64,
        ARM,
        ARMV5TEL,
        ARMV6L,
        ARMV7L,
        ARMV8L,
        I386,
        I586,
        I686,
        LOONGARCH64,
        MIPS,
        MIPS64,
        MIPS64EL,
        MIPSEL,
        PPC,
        PPC64,
        PPC64LE,
        RISCV32,
        RISCV64,
        S390X,
        SPARC,
        SPARC64,
        WASM32,
        WASM64,
        X86_64,
    ),
)
"""All recognized architectures.

.. caution::
    This group does not contain the :data:`~extra_platforms.UNKNOWN_ARCHITECTURE` trait.
"""


ALL_ARM = Group(
    "all_arm",
    "ARM architectures",
    "📱",
    (AARCH64, ARM, ARMV5TEL, ARMV6L, ARMV7L, ARMV8L),
)
"""All ARM-based architectures."""


X86 = Group(
    "x86",
    "x86 family",
    "𝘅",
    (I386, I586, I686, X86_64),
)
"""All x86-based architectures (Intel-compatible)."""


LOONGARCH = Group(
    "loongarch",
    "LoongArch",
    "🐉",
    (LOONGARCH64,),
)
"""LoongArch architecture."""


ALL_MIPS = Group(
    "all_mips",
    "MIPS architectures",
    "🔲",
    (MIPS, MIPS64, MIPS64EL, MIPSEL),
)
"""All MIPS-based architectures."""


POWERPC = Group(
    "powerpc",
    "PowerPC family",
    "⚡",
    (PPC, PPC64, PPC64LE),
)
"""All PowerPC-based architectures."""


RISCV = Group(
    "riscv",
    "RISC-V family",
    "Ⅴ",
    (RISCV32, RISCV64),
)
"""All RISC-V-based architectures."""


ALL_SPARC = Group(
    "all_sparc",
    "SPARC architectures",
    "☀️",
    (SPARC, SPARC64),
)
"""All SPARC-based architectures."""


IBM_MAINFRAME = Group(
    "ibm_mainframe",
    "IBM mainframe",
    "🏢",
    (S390X,),
)
"""IBM mainframe architectures."""


WEBASSEMBLY = Group(
    "webassembly",
    "WebAssembly",
    "🌐",
    (WASM32, WASM64),
)
"""WebAssembly architectures."""


ARCH_64_BIT = Group(
    "arch_64_bit",
    "64-bit architectures",
    "⁶⁴",
    (
        AARCH64,
        LOONGARCH64,
        MIPS64,
        MIPS64EL,
        PPC64,
        PPC64LE,
        RISCV64,
        S390X,
        SPARC64,
        WASM64,
        X86_64,
    ),
)
"""All 64-bit architectures."""


ARCH_32_BIT = Group(
    "arch_32_bit",
    "32-bit architectures",
    "³²",
    (
        ARM,
        ARMV5TEL,
        ARMV6L,
        ARMV7L,
        ARMV8L,
        I386,
        I586,
        I686,
        MIPS,
        MIPSEL,
        PPC,
        RISCV32,
        SPARC,
        WASM32,
    ),
)
"""All 32-bit architectures."""


BIG_ENDIAN = Group(
    "big_endian",
    "Big-endian architectures",
    "⬆️",
    (
        MIPS,
        MIPS64,
        PPC,
        PPC64,
        S390X,
        SPARC,
        SPARC64,
    ),
)
"""All big-endian architectures."""


LITTLE_ENDIAN = Group(
    "little_endian",
    "Little-endian architectures",
    "⬇️",
    (
        AARCH64,
        ARM,
        ARMV5TEL,
        ARMV6L,
        ARMV7L,
        ARMV8L,
        I386,
        I586,
        I686,
        LOONGARCH64,
        MIPS64EL,
        MIPSEL,
        PPC64LE,
        RISCV32,
        RISCV64,
        WASM32,
        WASM64,
        X86_64,
    ),
)
"""All little-endian architectures."""


# =============================================================================
# Platform groups
# =============================================================================

ALL_PLATFORMS: Group = Group(
    "all_platforms",
    "All platforms",
    "⚙️",
    (
        AIX,
        ALPINE,
        ALTLINUX,
        AMZN,
        ANDROID,
        ARCH,
        BUILDROOT,
        CACHYOS,
        CENTOS,
        CLOUDLINUX,
        CYGWIN,
        DEBIAN,
        DRAGONFLY_BSD,
        EXHERBO,
        FEDORA,
        FREEBSD,
        GENERIC_LINUX,
        GENTOO,
        GUIX,
        HAIKU,
        HURD,
        IBM_POWERKVM,
        ILLUMOS,
        KALI,
        KVMIBM,
        LINUXMINT,
        MACOS,
        MAGEIA,
        MANDRIVA,
        MANJARO,
        MIDNIGHTBSD,
        NETBSD,
        NOBARA,
        OPENBSD,
        OPENSUSE,
        OPENWRT,
        ORACLE,
        PARALLELS,
        PIDORA,
        RASPBIAN,
        RHEL,
        ROCKY,
        SCIENTIFIC,
        SLACKWARE,
        SLES,
        SOLARIS,
        SUNOS,
        TUMBLEWEED,
        TUXEDO,
        UBUNTU,
        ULTRAMARINE,
        WINDOWS,
        WSL1,
        WSL2,
        XENSERVER,
    ),
)
"""All recognized platforms.

.. caution::
    This group does not contain the :data:`~extra_platforms.UNKNOWN_PLATFORM` trait.
"""


ALL_WINDOWS = Group(
    "all_windows",
    "All Windows",
    "🪟",
    (WINDOWS,),
)
"""All Windows operating systems."""


UNIX = Group(
    "unix",
    "All Unix",
    "⨷",
    tuple(ALL_PLATFORMS - ALL_WINDOWS),
)
"""All Unix-like operating systems and compatibility layers."""


UNIX_WITHOUT_MACOS = Group(
    "unix_without_macos",
    "All Unix excluding macOS",
    "⨂",
    tuple(UNIX - MACOS),
)
"""All Unix platforms, without macOS.

This is useful to avoid macOS-specific workarounds on Unix platforms.
"""


BSD = Group(
    "bsd",
    "All BSD",
    "Ⓑ",
    (DRAGONFLY_BSD, FREEBSD, MACOS, MIDNIGHTBSD, NETBSD, OPENBSD, SUNOS),
)
"""All BSD platforms.

.. note::
    Are considered of this family (`according Wikipedia
    <https://en.wikipedia.org/wiki/Template:Unix>`_):

    - `386BSD` (`FreeBSD`, `NetBSD`, `OpenBSD`, `DragonFly BSD`)
    - `NeXTSTEP`
    - `Darwin` (`macOS`, `iOS`, `audioOS`, `iPadOS`, `tvOS`, `watchOS`, `bridgeOS`)
    - `SunOS`
    - `Ultrix`
"""


BSD_WITHOUT_MACOS = Group(
    "bsd_without_macos",
    "All BSD excluding macOS",
    "🅱️",
    tuple(BSD - MACOS),
)
"""All BSD platforms, without macOS.

This is useful to avoid macOS-specific workarounds on BSD platforms.
"""


LINUX = Group(
    "linux",
    "Linux distributions",
    "🐧",
    (
        ALPINE,
        ALTLINUX,
        AMZN,
        ANDROID,
        ARCH,
        BUILDROOT,
        CACHYOS,
        CENTOS,
        CLOUDLINUX,
        DEBIAN,
        EXHERBO,
        FEDORA,
        GENERIC_LINUX,
        GENTOO,
        GUIX,
        IBM_POWERKVM,
        KALI,
        KVMIBM,
        LINUXMINT,
        MAGEIA,
        MANDRIVA,
        MANJARO,
        NOBARA,
        OPENSUSE,
        OPENWRT,
        ORACLE,
        PARALLELS,
        PIDORA,
        RASPBIAN,
        RHEL,
        ROCKY,
        SCIENTIFIC,
        SLACKWARE,
        SLES,
        TUMBLEWEED,
        TUXEDO,
        UBUNTU,
        ULTRAMARINE,
        XENSERVER,
    ),
)
"""All distributions based on a Linux kernel.

.. note::
    Are considered of this family (`according Wikipedia
    <https://en.wikipedia.org/wiki/Template:Unix>`_):

    - `Android`
    - `ChromeOS`
    - any other distribution
"""


LINUX_LAYERS = Group(
    "linux_layers",
    "Linux compatibility layers",
    "≚",
    (WSL1, WSL2),
)
"""Interfaces that allows Linux binaries to run on a different host system.

.. note::
    Are considered of this family (`according Wikipedia
    <https://en.wikipedia.org/wiki/Template:Unix>`_):

    - `Windows Subsystem for Linux`
"""


LINUX_LIKE = Group(
    "linux_like",
    "All Linux & compatibility layers",
    "🐣",
    tuple(LINUX | LINUX_LAYERS),
)
"""Sum of all Linux distributions and Linux compatibility layers."""


SYSTEM_V = Group(
    "system_v",
    "AT&T System Five",
    "𝐕",
    (AIX, ILLUMOS, SOLARIS),
)
"""All Unix platforms derived from AT&T System Five.

.. note::
    Are considered of this family (`according Wikipedia
    <https://en.wikipedia.org/wiki/Template:Unix>`_):

    - `A/UX`
    - `AIX`
    - `HP-UX`
    - `IRIX`
    - `OpenServer`
    - `Solaris`
    - `OpenSolaris`
    - `Illumos`
    - `Tru64`
    - `UNIX`
    - `UnixWare`
"""


UNIX_LAYERS = Group(
    "unix_layers",
    "Unix compatibility layers",
    "≛",
    (CYGWIN,),
)
"""Interfaces that allows Unix binaries to run on a different host system.

.. note::
    Are considered of this family (`according Wikipedia
    <https://en.wikipedia.org/wiki/Template:Unix>`_):

    - `Cygwin`
    - `Darling`
    - `Eunice`
    - `GNV`
    - `Interix`
    - `MachTen`
    - `Microsoft POSIX subsystem`
    - `MKS Toolkit`
    - `PASE`
    - `P.I.P.S.`
    - `PWS/VSE-AF`
    - `UNIX System Services`
    - `UserLAnd Technologies`
    - `Windows Services for UNIX`
"""


OTHER_POSIX = Group(
    "other_posix",
    "Other POSIX-compliant platforms",
    "🅟",
    tuple(UNIX - BSD - LINUX - LINUX_LAYERS - SYSTEM_V - UNIX_LAYERS),
)
"""All other UNIX-like or POSIX-compliant platforms.

.. note::
    Are considered of this family (`according Wikipedia
    <https://en.wikipedia.org/wiki/Template:Unix>`_):

    - `Coherent`
    - `GNU/Hurd`
    - `HarmonyOS`
    - `LiteOS`
    - `LynxOS`
    - `Minix`
    - `MOS`
    - `OSF/1`
    - `QNX`
    - `BlackBerry 10`
    - `Research Unix`
    - `SerenityOS`
"""


# =============================================================================
# Shell groups
# =============================================================================

ALL_SHELLS: Group = Group(
    "all_shells",
    "All shells",
    "🐚",
    (ASH, BASH, CMD, CSH, DASH, FISH, KSH, NUSHELL, POWERSHELL, TCSH, XONSH, ZSH),
)
"""All recognized shells.

.. caution::
    This group does not contain the :data:`~extra_platforms.UNKNOWN_SHELL` trait.
"""


BOURNE_SHELLS = Group(
    "bourne_shells",
    "Bourne-compatible shells",
    "💲",
    (ASH, BASH, DASH, KSH, ZSH),
)
"""All Bourne-compatible shells."""


C_SHELLS = Group(
    "c_shells",
    "C shells",
    "🅲",
    (CSH, TCSH),
)
"""C shell family."""


OTHER_SHELLS = Group(
    "other_shells",
    "Other shells",
    "◇",
    (FISH, NUSHELL, XONSH),
)
"""Other non-traditional shells."""


WINDOWS_SHELLS = Group(
    "windows_shells",
    "Windows shells",
    "⌨️",
    (CMD, POWERSHELL),
)
"""Windows-native shells."""


# =============================================================================
# Terminal groups
# =============================================================================

ALL_TERMINALS: Group = Group(
    "all_terminals",
    "All terminals",
    "💻",
    (
        ALACRITTY,
        APPLE_TERMINAL,
        CONTOUR,
        FOOT,
        GHOSTTY,
        GNOME_TERMINAL,
        GNU_SCREEN,
        HYPER,
        ITERM2,
        KITTY,
        KONSOLE,
        RIO,
        TABBY,
        TILIX,
        TMUX,
        VSCODE_TERMINAL,
        WEZTERM,
        WINDOWS_TERMINAL,
        XTERM,
        ZELLIJ,
    ),
)
"""All recognized terminals.

.. caution::
    This group does not contain the :data:`~extra_platforms.UNKNOWN_TERMINAL` trait.
"""


GPU_TERMINALS = Group(
    "gpu_terminals",
    "GPU-accelerated terminals",
    "🎮",
    (ALACRITTY, CONTOUR, FOOT, GHOSTTY, KITTY, RIO, WEZTERM),
)
"""GPU-accelerated terminal emulators."""


MULTIPLEXERS = Group(
    "multiplexers",
    "Terminal multiplexers",
    "⧉",
    (GNU_SCREEN, TMUX, ZELLIJ),
)
"""Terminal multiplexers that can host other terminals."""


NATIVE_TERMINALS = Group(
    "native_terminals",
    "Native terminal emulators",
    "▦",
    (APPLE_TERMINAL, GNOME_TERMINAL, ITERM2, KONSOLE, TILIX, WINDOWS_TERMINAL, XTERM),
)
"""Platform-native terminal emulators built with traditional GUI toolkits."""


WEB_TERMINALS = Group(
    "web_terminals",
    "Web-based terminals",
    "⬢",
    (HYPER, TABBY, VSCODE_TERMINAL),
)
"""Terminal emulators built on web technologies (Electron, xterm.js)."""


# =============================================================================
# CI groups
# =============================================================================

ALL_CI = Group(
    "all_ci",
    "CI systems",
    "♺",
    (
        AZURE_PIPELINES,
        BAMBOO,
        BUILDKITE,
        CIRCLE_CI,
        CIRRUS_CI,
        CODEBUILD,
        GITHUB_CI,
        GITLAB_CI,
        HEROKU_CI,
        TEAMCITY,
        TRAVIS_CI,
    ),
)
"""All recognized Continuous Integration systems.

.. caution::
    This group does not contain the :data:`~extra_platforms.UNKNOWN_CI` trait.

.. seealso::
    `List of known CI systems
    <https://adamj.eu/tech/2020/03/09/detect-if-your-tests-are-running-on-ci/>`_.
"""


# =============================================================================
# Agent groups
# =============================================================================

ALL_AGENTS = Group(
    "all_agents",
    "AI coding agents",
    "🧠",
    (
        CLAUDE_CODE,
        CLINE,
        CURSOR,
    ),
)
"""All recognized AI coding agents.

.. caution::
    This group does not contain the :data:`~extra_platforms.UNKNOWN_AGENT` trait.
"""


# =============================================================================
# Mixed groups
# =============================================================================

UNKNOWN = Group(
    "unknown",
    "Unknown",
    "❓",
    (
        UNKNOWN_ARCHITECTURE,
        UNKNOWN_PLATFORM,
        UNKNOWN_SHELL,
        UNKNOWN_TERMINAL,
        UNKNOWN_CI,
        UNKNOWN_AGENT,
    ),
)
"""Unknown or unrecognized traits."""


ALL_TRAITS = Group(
    "all_traits",
    "All architectures, platforms, shells, terminals, CI systems, and agents",
    "⁕",
    tuple(
        ALL_ARCHITECTURES
        | ALL_PLATFORMS
        | ALL_SHELLS
        | ALL_TERMINALS
        | ALL_CI
        | ALL_AGENTS
        | UNKNOWN
    ),
)
"""All predefined architectures, platforms, shells, terminals, CI systems, and agents.

.. hint::
    This group includes all ``UNKNOWN_*`` traits.
"""


# =============================================================================
# Collections of groups
# =============================================================================

#: All groups whose members are :class:`~extra_platforms.Architecture`.
ALL_ARCHITECTURE_GROUPS: frozenset[Group] = frozenset(
    (
        ALL_ARCHITECTURES,
        ALL_ARM,
        X86,
        LOONGARCH,
        ALL_MIPS,
        POWERPC,
        RISCV,
        ALL_SPARC,
        IBM_MAINFRAME,
        WEBASSEMBLY,
        ARCH_64_BIT,
        ARCH_32_BIT,
        BIG_ENDIAN,
        LITTLE_ENDIAN,
    ),
)


#: All groups whose members are :class:`~extra_platforms.Platform`.
ALL_PLATFORM_GROUPS: frozenset[Group] = frozenset(
    (
        ALL_PLATFORMS,
        ALL_WINDOWS,
        UNIX,
        UNIX_WITHOUT_MACOS,
        BSD,
        BSD_WITHOUT_MACOS,
        LINUX,
        LINUX_LAYERS,
        LINUX_LIKE,
        SYSTEM_V,
        UNIX_LAYERS,
        OTHER_POSIX,
    ),
)


#: All groups whose members are :class:`~extra_platforms.Shell`.
ALL_SHELL_GROUPS: frozenset[Group] = frozenset(
    (
        ALL_SHELLS,
        BOURNE_SHELLS,
        C_SHELLS,
        OTHER_SHELLS,
        WINDOWS_SHELLS,
    ),
)


#: All groups whose members are :class:`~extra_platforms.Terminal`.
ALL_TERMINAL_GROUPS: frozenset[Group] = frozenset(
    (
        ALL_TERMINALS,
        GPU_TERMINALS,
        MULTIPLEXERS,
        NATIVE_TERMINALS,
        WEB_TERMINALS,
    ),
)


#: All groups whose members are :class:`~extra_platforms.CI`.
#:
#: .. note::
#:     Not that useful as there is only one CI group, but provided for symmetry with
#:     :data:`ALL_ARCHITECTURE_GROUPS` and :data:`ALL_PLATFORM_GROUPS`.
ALL_CI_GROUPS: frozenset[Group] = frozenset((ALL_CI,))


#: All groups whose members are :class:`~extra_platforms.Agent`.
#:
#: .. note::
#:     Not that useful as there is only one agent group, but provided for symmetry with
#:     :data:`ALL_ARCHITECTURE_GROUPS` and :data:`ALL_PLATFORM_GROUPS`.
ALL_AGENT_GROUPS: frozenset[Group] = frozenset((ALL_AGENTS,))


#: Non-overlapping groups.
#:
#: .. hint::
#:     These groups together cover all :class:`~extra_platforms.Architecture`,
#:     :class:`~extra_platforms.Platform`, :class:`~extra_platforms.CI`,
#:     and :class:`~extra_platforms.Agent` traits,
#:     including traits from the :data:`~extra_platforms.UNKNOWN` group.
#:
#:     All groups in this collection are marked as :attr:`~extra_platforms.Group.canonical`.
NON_OVERLAPPING_GROUPS: frozenset[Group] = frozenset(
    (
        # Architecture groups.
        ALL_ARM,
        X86,
        LOONGARCH,
        ALL_MIPS,
        POWERPC,
        RISCV,
        ALL_SPARC,
        IBM_MAINFRAME,
        WEBASSEMBLY,
        # Platform groups.
        ALL_WINDOWS,
        BSD,
        LINUX,
        LINUX_LAYERS,
        OTHER_POSIX,
        SYSTEM_V,
        UNIX_LAYERS,
        # Shell groups.
        BOURNE_SHELLS,
        C_SHELLS,
        OTHER_SHELLS,
        WINDOWS_SHELLS,
        # Terminal groups.
        GPU_TERMINALS,
        MULTIPLEXERS,
        NATIVE_TERMINALS,
        WEB_TERMINALS,
        # CI groups.
        ALL_CI,
        # Agent groups.
        ALL_AGENTS,
        # Mixed groups.
        UNKNOWN,
    ),
)


#: Overlapping groups, defined for convenience.
#:
#: .. hint::
#:     None of these groups are marked as :attr:`~extra_platforms.Group.canonical`.
EXTRA_GROUPS: frozenset[Group] = frozenset(
    (
        ALL_TRAITS,
        # Architecture groups.
        ALL_ARCHITECTURES,
        ARCH_64_BIT,
        ARCH_32_BIT,
        BIG_ENDIAN,
        LITTLE_ENDIAN,
        # Platform groups.
        ALL_PLATFORMS,
        UNIX,
        UNIX_WITHOUT_MACOS,
        BSD_WITHOUT_MACOS,
        LINUX_LIKE,
        # Shell groups.
        ALL_SHELLS,
        # Terminal groups.
        ALL_TERMINALS,
    ),
)


#: All predefined groups.
#:
#: .. hint::
#:     This collection contains both :attr:`~extra_platforms.Group.canonical` and
#:     non-canonical groups, including the :data:`~extra_platforms.UNKNOWN` group.
ALL_GROUPS: frozenset[Group] = frozenset(NON_OVERLAPPING_GROUPS | EXTRA_GROUPS)


# =============================================================================
# ID collections
# =============================================================================

#: A :class:`frozenset` of all recognized traits IDs.
#:
#: .. attention::
#:     This collection does not contain all the ``UNKNOWN_*`` traits.
ALL_TRAIT_IDS: frozenset[str] = frozenset(p.id for p in ALL_TRAITS - UNKNOWN)


#: A :class:`frozenset` of all recognized group IDs.
#:
#: .. attention::
#:     This collection does not contain the :data:`~extra_platforms.UNKNOWN` group.
ALL_GROUP_IDS: frozenset[str] = frozenset(p.id for p in ALL_GROUPS - {UNKNOWN})


#: A :class:`frozenset` of all recognized traits and group IDs.
#:
#: .. attention::
#:     This collection does not contain all the ``UNKNOWN_*`` traits and the
#:     :data:`~extra_platforms.UNKNOWN` group.
ALL_IDS: frozenset[str] = ALL_TRAIT_IDS | ALL_GROUP_IDS
