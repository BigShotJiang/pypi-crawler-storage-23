def test_check_fixture(check):
    check.equal(1, 1)
