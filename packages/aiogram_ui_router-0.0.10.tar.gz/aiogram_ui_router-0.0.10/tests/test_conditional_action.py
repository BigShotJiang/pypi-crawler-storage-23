from unittest.mock import AsyncMock, MagicMock

import pytest

from ui_router.execution.actions import ActionExecutor, ContentResolver
from ui_router.schema import (
    ActionType,
    ConditionalAction,
    BusinessAction,
    GotoSceneAction,
    RuleCondition,
    ConditionOperator,
    UIRouter,
    Scene,
    Handler,
    GlobalHandler,
    EventType,
    Filter,
    MessageContent,
    SendMessageAction,
)
from ui_router.validator import SchemaValidator, ValidationCategory


class TestConditionalActionSchema:
    def test_parse_conditional_action(self):
        action = ConditionalAction(
            conditions=[RuleCondition(variable="new_user", operator=ConditionOperator.EQ, value=True)],
            then_actions=[BusinessAction(business_action="create_demo_key")],
            else_actions=[],
        )
        assert action.type == ActionType.CONDITIONAL
        assert len(action.conditions) == 1
        assert len(action.then_actions) == 1
        assert len(action.else_actions) == 0

    def test_parse_from_dict(self):
        data = {
            "type": "conditional",
            "conditions": [{"variable": "active", "operator": "eq", "value": True}],
            "then_actions": [{"type": "goto_scene", "scene_id": "main"}],
            "else_actions": [{"type": "goto_scene", "scene_id": "onboarding"}],
        }
        action = ConditionalAction.model_validate(data)
        assert action.type == ActionType.CONDITIONAL
        assert isinstance(action.then_actions[0], GotoSceneAction)
        assert isinstance(action.else_actions[0], GotoSceneAction)

    def test_nested_conditional(self):
        action = ConditionalAction(
            conditions=[RuleCondition(variable="a", operator=ConditionOperator.EQ, value=1)],
            then_actions=[
                ConditionalAction(
                    conditions=[RuleCondition(variable="b", operator=ConditionOperator.EQ, value=2)],
                    then_actions=[BusinessAction(business_action="inner")],
                ),
            ],
        )
        assert action.then_actions[0].type == ActionType.CONDITIONAL

    def test_empty_conditions_defaults(self):
        action = ConditionalAction()
        assert action.conditions == []
        assert action.then_actions == []
        assert action.else_actions == []


def make_context(flags=None, user_id=1, chat_id=1, scene_id="test"):
    ctx = MagicMock()
    flags = flags or {}
    ctx.get_flag.side_effect = lambda name, default=None: flags.get(name, default)
    ctx.get_all_flags.return_value = flags
    ctx.set_flag = MagicMock()
    ctx.user_id = user_id
    ctx.chat_id = chat_id
    ctx.scene_id = scene_id
    ctx.bot = AsyncMock()
    ctx.bot.id = 1
    ctx.bot.send_message = AsyncMock()
    ctx.navigation_state = MagicMock()
    ctx.navigation_state.user_input = {}
    ctx.save_user_input = MagicMock()
    ctx.get_user_input = MagicMock(return_value=None)
    ctx.clear_user_input = MagicMock()
    ctx.event_data = {}
    ctx.get_from_event.return_value = None
    return ctx


def make_callback_manager():
    cm = AsyncMock()
    cm.encode = AsyncMock(return_value="cb_data")
    return cm


def make_content_resolver():
    return ContentResolver(callback_manager=make_callback_manager())


def make_executor(**kwargs):
    defaults = {
        "content_resolver": make_content_resolver(),
        "registry": MagicMock(),
        "event_bus": AsyncMock(),
        "event_scheduler": AsyncMock(),
        "variable_repository": AsyncMock(),
    }
    defaults.update(kwargs)
    return ActionExecutor(**defaults)


class TestConditionalActionExecution:
    @pytest.mark.asyncio
    async def test_condition_true_executes_then_actions(self):
        ctx = make_context(flags={"new_user": True})
        executor = make_executor()
        executor.registry.business_actions.execute = AsyncMock()

        action = ConditionalAction(
            conditions=[RuleCondition(variable="new_user", operator=ConditionOperator.EQ, value=True)],
            then_actions=[BusinessAction(business_action="on_true")],
            else_actions=[BusinessAction(business_action="on_false")],
        )
        event = MagicMock()
        await executor.execute(action, ctx, event)

        executor.registry.business_actions.execute.assert_called_once()
        call_kwargs = executor.registry.business_actions.execute.call_args
        assert call_kwargs.kwargs.get("action_name") == "on_true" or call_kwargs[1].get("action_name") == "on_true"

    @pytest.mark.asyncio
    async def test_condition_false_executes_else_actions(self):
        ctx = make_context(flags={"new_user": False})
        executor = make_executor()
        executor.registry.business_actions.execute = AsyncMock()

        action = ConditionalAction(
            conditions=[RuleCondition(variable="new_user", operator=ConditionOperator.EQ, value=True)],
            then_actions=[BusinessAction(business_action="on_true")],
            else_actions=[BusinessAction(business_action="on_false")],
        )
        event = MagicMock()
        await executor.execute(action, ctx, event)

        executor.registry.business_actions.execute.assert_called_once()
        call_kwargs = executor.registry.business_actions.execute.call_args
        assert call_kwargs.kwargs.get("action_name") == "on_false" or call_kwargs[1].get("action_name") == "on_false"

    @pytest.mark.asyncio
    async def test_condition_false_empty_else_does_nothing(self):
        ctx = make_context(flags={"new_user": False})
        executor = make_executor()
        executor.registry.business_actions.execute = AsyncMock()

        action = ConditionalAction(
            conditions=[RuleCondition(variable="new_user", operator=ConditionOperator.EQ, value=True)],
            then_actions=[BusinessAction(business_action="on_true")],
            else_actions=[],
        )
        event = MagicMock()
        await executor.execute(action, ctx, event)

        executor.registry.business_actions.execute.assert_not_called()

    @pytest.mark.asyncio
    async def test_multiple_conditions_and_logic(self):
        ctx = make_context(flags={"a": True, "b": False})
        executor = make_executor()
        executor.registry.business_actions.execute = AsyncMock()

        action = ConditionalAction(
            conditions=[
                RuleCondition(variable="a", operator=ConditionOperator.EQ, value=True),
                RuleCondition(variable="b", operator=ConditionOperator.EQ, value=True),
            ],
            then_actions=[BusinessAction(business_action="both_true")],
            else_actions=[BusinessAction(business_action="not_both")],
        )
        event = MagicMock()
        await executor.execute(action, ctx, event)

        call_kwargs = executor.registry.business_actions.execute.call_args
        assert call_kwargs.kwargs.get("action_name") == "not_both" or call_kwargs[1].get("action_name") == "not_both"

    @pytest.mark.asyncio
    async def test_nested_conditional(self):
        ctx = make_context(flags={"outer": True, "inner": True})
        executor = make_executor()
        executor.registry.business_actions.execute = AsyncMock()

        action = ConditionalAction(
            conditions=[RuleCondition(variable="outer", operator=ConditionOperator.EQ, value=True)],
            then_actions=[
                ConditionalAction(
                    conditions=[RuleCondition(variable="inner", operator=ConditionOperator.EQ, value=True)],
                    then_actions=[BusinessAction(business_action="nested_true")],
                ),
            ],
        )
        event = MagicMock()
        await executor.execute(action, ctx, event)

        executor.registry.business_actions.execute.assert_called_once()
        call_kwargs = executor.registry.business_actions.execute.call_args
        assert (
            call_kwargs.kwargs.get("action_name") == "nested_true" or call_kwargs[1].get("action_name") == "nested_true"
        )

    @pytest.mark.asyncio
    async def test_flag_not_found_falls_back_to_variable_repository(self):
        ctx = make_context(flags={})
        variable_repo = AsyncMock()
        variable_repo.get = AsyncMock(return_value=True)
        ctx.get_from_event.return_value = MagicMock(variables=[])
        executor = make_executor(variable_repository=variable_repo)
        executor.registry.business_actions.execute = AsyncMock()

        action = ConditionalAction(
            conditions=[RuleCondition(variable="stored_var", operator=ConditionOperator.EQ, value=True)],
            then_actions=[BusinessAction(business_action="from_var")],
            else_actions=[],
        )
        event = MagicMock()
        await executor.execute(action, ctx, event)

        variable_repo.get.assert_called()
        executor.registry.business_actions.execute.assert_called_once()

    @pytest.mark.asyncio
    async def test_empty_conditions_always_executes_then(self):
        ctx = make_context()
        executor = make_executor()
        executor.registry.business_actions.execute = AsyncMock()

        action = ConditionalAction(
            conditions=[],
            then_actions=[BusinessAction(business_action="always")],
            else_actions=[BusinessAction(business_action="never")],
        )
        event = MagicMock()
        await executor.execute(action, ctx, event)

        call_kwargs = executor.registry.business_actions.execute.call_args
        assert call_kwargs.kwargs.get("action_name") == "always" or call_kwargs[1].get("action_name") == "always"


def _make_scene(scene_id, *, handlers=None, on_enter=None):
    return Scene(id=scene_id, name=scene_id, handlers=handlers or [], on_enter=on_enter or [])


def _handler(name, actions, *, event_type=EventType.CALLBACK):
    return Handler(
        name=name,
        event_type=event_type,
        actions=actions,
        filters=[Filter(type="text", text="x")] if event_type == EventType.MESSAGE else [],
    )


def _make_schema(scenes, *, initial_scene="main", global_handlers=None):
    return UIRouter(
        name="test",
        scenes=scenes,
        initial_scene=initial_scene,
        global_handlers=global_handlers or [],
    )


class TestValidatorConditionalAction:
    def test_broken_ref_inside_then_actions(self):
        schema = _make_schema([
            _make_scene(
                "main",
                handlers=[
                    _handler(
                        "h",
                        [
                            ConditionalAction(
                                conditions=[RuleCondition(variable="x", operator=ConditionOperator.EQ, value=1)],
                                then_actions=[GotoSceneAction(scene_id="nonexistent")],
                            ),
                        ],
                    ),
                ],
            ),
        ])
        validator = SchemaValidator()
        report = validator.validate(schema)
        broken = [i for i in report.issues if i.category == ValidationCategory.BROKEN_SCENE_REF]
        assert len(broken) >= 1
        assert "nonexistent" in broken[0].message

    def test_broken_ref_inside_else_actions(self):
        schema = _make_schema([
            _make_scene(
                "main",
                handlers=[
                    _handler(
                        "h",
                        [
                            ConditionalAction(
                                conditions=[],
                                else_actions=[GotoSceneAction(scene_id="missing")],
                            ),
                        ],
                    ),
                ],
            ),
        ])
        validator = SchemaValidator()
        report = validator.validate(schema)
        broken = [i for i in report.issues if i.category == ValidationCategory.BROKEN_SCENE_REF]
        assert len(broken) >= 1
        assert "missing" in broken[0].message

    def test_nested_conditional_broken_ref(self):
        schema = _make_schema([
            _make_scene(
                "main",
                handlers=[
                    _handler(
                        "h",
                        [
                            ConditionalAction(
                                conditions=[],
                                then_actions=[
                                    ConditionalAction(
                                        conditions=[],
                                        then_actions=[GotoSceneAction(scene_id="deep_missing")],
                                    ),
                                ],
                            ),
                        ],
                    ),
                ],
            ),
        ])
        validator = SchemaValidator()
        report = validator.validate(schema)
        broken = [i for i in report.issues if i.category == ValidationCategory.BROKEN_SCENE_REF]
        assert len(broken) >= 1
        assert "deep_missing" in broken[0].message

    def test_conditional_in_global_handler_detected(self):
        schema = _make_schema(
            [_make_scene("main", handlers=[_handler("h", [GotoSceneAction(scene_id="main")])])],
            global_handlers=[
                GlobalHandler(
                    name="g",
                    event_type=EventType.MESSAGE,
                    filters=[Filter(type="command", commands=["start"])],
                    actions=[
                        ConditionalAction(
                            conditions=[],
                            then_actions=[GotoSceneAction(scene_id="nowhere")],
                        ),
                    ],
                ),
            ],
        )
        validator = SchemaValidator()
        report = validator.validate(schema)
        broken = [i for i in report.issues if i.category == ValidationCategory.BROKEN_SCENE_REF]
        assert any("nowhere" in i.message for i in broken)

    def test_conditional_itself_not_flagged_as_incompatible(self):
        schema = _make_schema(
            [_make_scene("main", handlers=[_handler("h", [GotoSceneAction(scene_id="main")])])],
            global_handlers=[
                GlobalHandler(
                    name="g",
                    event_type=EventType.MESSAGE,
                    filters=[Filter(type="command", commands=["start"])],
                    actions=[
                        ConditionalAction(
                            conditions=[],
                            then_actions=[SendMessageAction(content=MessageContent(text="ok"))],
                        ),
                    ],
                ),
            ],
        )
        validator = SchemaValidator()
        report = validator.validate(schema)
        compat_issues = [i for i in report.issues if i.category == ValidationCategory.INCOMPATIBLE_ACTION]
        conditional_issues = [i for i in compat_issues if "conditional" in i.message]
        assert not conditional_issues
