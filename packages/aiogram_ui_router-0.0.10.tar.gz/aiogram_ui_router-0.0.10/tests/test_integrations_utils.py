from datetime import timedelta

import pytest

from ui_router.exceptions import EventSchedulingError
from ui_router.integrations._utils import parse_delay


class TestParseDelay:
    def test_seconds(self):
        assert parse_delay("30s") == timedelta(seconds=30)

    def test_minutes(self):
        assert parse_delay("10m") == timedelta(minutes=10)

    def test_hours(self):
        assert parse_delay("2h") == timedelta(hours=2)

    def test_days(self):
        assert parse_delay("5d") == timedelta(days=5)

    def test_large_value(self):
        assert parse_delay("999s") == timedelta(seconds=999)

    def test_single_digit(self):
        assert parse_delay("1m") == timedelta(minutes=1)

    def test_invalid_format_no_unit(self):
        with pytest.raises(EventSchedulingError, match="Invalid delay format"):
            parse_delay("10")

    def test_invalid_format_no_number(self):
        with pytest.raises(EventSchedulingError, match="Invalid delay format"):
            parse_delay("m")

    def test_invalid_format_empty(self):
        with pytest.raises(EventSchedulingError, match="Invalid delay format"):
            parse_delay("")

    def test_invalid_format_unknown_unit(self):
        with pytest.raises(EventSchedulingError, match="Invalid delay format"):
            parse_delay("10x")

    def test_invalid_format_float(self):
        with pytest.raises(EventSchedulingError, match="Invalid delay format"):
            parse_delay("1.5m")

    def test_invalid_format_negative(self):
        with pytest.raises(EventSchedulingError, match="Invalid delay format"):
            parse_delay("-5m")

    def test_invalid_format_spaces(self):
        with pytest.raises(EventSchedulingError, match="Invalid delay format"):
            parse_delay("10 m")
