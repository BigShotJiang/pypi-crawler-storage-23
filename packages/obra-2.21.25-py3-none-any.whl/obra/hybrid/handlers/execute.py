"""Execute handler for Hybrid Orchestrator.

This module handles the EXECUTE action from the server. It executes a plan item
by deploying an implementation agent (Claude Code, etc.).

The execution process:
    1. Receive ExecutionRequest with plan item to execute
    2. Prepare execution context (files, dependencies)
    3. Deploy implementation agent
    4. Collect execution results (files changed, tests, etc.)
    5. Return ExecutionResult to report to server

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 2
    - obra/api/protocol.py
    - obra/hybrid/orchestrator.py
"""

import logging
import os
import shlex
import subprocess
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

from obra.api.protocol import ExecutionRequest, ExecutionStatus
from obra.config import (
    get_agent_execution_timeout,
    get_heartbeat_initial_delay,
    get_heartbeat_interval,
    get_llm_api_timeout,
)
from obra.config.loaders import (
    get_decomposition_duration_threshold_s,
    get_decomposition_summary_max_chars,
    get_decomposition_warning_threshold_s,
    get_execute_parallel_workers,
    get_interactive_guard_retry_max,
    get_interactive_guard_rollback_codes,
    get_interactive_guard_rollback_enabled,
    get_timeout,
    is_decomposition_enabled,
    load_layered_config,
)
from obra.constants import LIVENESS_CHECK_INTERVAL_S
from obra.display import print_error, print_info, print_warning
from obra.display.observability import (
    ObservabilityConfig,
    ProgressEmitter,
    VerbosityLevel,
)
from obra.hybrid.handlers.base import ObservabilityContextMixin
from obra.hybrid.prompt_enricher import PromptEnricher
from obra.llm.interactive_guard import (
    extract_interactive_failure,
    sanitize_interactive_line,
)
from obra.messages import get_message
from obra.monitoring.hang_investigator import HangClassification, HangInvestigator
from obra.monitoring.liveness_monitor import LivenessMonitor, LivenessStatus
from obra.observability.production_logger import get_production_logger
from obra.prompts.fragments.recovery import build_interactive_recovery_banner
from obra.utils.file_tracker import FileSnapshot, FileStateTracker
from obra.utils.workspace_rollback import WorkspaceRollbackStore
from obra.validation.verification_tools import resolve_verification_tools

logger = logging.getLogger(__name__)

# Type alias for streaming callback
StreamCallback = Callable[[str, str], None] | None


class _MonitoringEventAdapter:
    """Adapter to emit monitoring events via log_event callback."""

    def __init__(self, log_event: Callable[..., None] | None) -> None:
        self._log_event = log_event

    def _emit(self, event_type: str, **kwargs: Any) -> None:
        if self._log_event:
            self._log_event(event_type, **kwargs)

    def log_liveness_check(
        self,
        session_id: str,
        task_id: int,
        status: str,
        alive_count: int,
        total_indicators: int,
        indicators: dict[str, bool],
    ) -> None:
        self._emit(
            "liveness_check",
            session_id=session_id,
            task_id=task_id,
            status=status,
            alive_count=alive_count,
            total_indicators=total_indicators,
            indicators=indicators,
        )

    def log_hang_investigation_started(
        self,
        session_id: str,
        task_id: int,
        pid: int,
    ) -> None:
        self._emit(
            "hang_investigation_started",
            session_id=session_id,
            task_id=task_id,
            pid=pid,
        )

    def log_hang_investigation_complete(
        self,
        session_id: str,
        task_id: int,
        pid: int,
        classification: str,
        confidence: float,
        action_recommended: str,
        evidence: dict[str, Any],
    ) -> None:
        self._emit(
            "hang_investigation_complete",
            session_id=session_id,
            task_id=task_id,
            pid=pid,
            classification=classification,
            confidence=confidence,
            action_recommended=action_recommended,
            evidence=evidence,
        )

    def log_timeout_extended(
        self,
        session_id: str,
        task_id: int,
        pid: int,
        reason: str,
        old_timeout: float,
        new_timeout: float,
        justification: str,
    ) -> None:
        self._emit(
            "timeout_extended",
            session_id=session_id,
            task_id=task_id,
            pid=pid,
            reason=reason,
            old_timeout=old_timeout,
            new_timeout=new_timeout,
            justification=justification,
        )

    def log_hang_detected(
        self,
        session_id: str,
        task_id: int,
        pid: int,
        classification: str,
        signal_sent: str,
        confidence: float,
    ) -> None:
        self._emit(
            "hang_detected",
            session_id=session_id,
            task_id=task_id,
            pid=pid,
            classification=classification,
            signal_sent=signal_sent,
            confidence=confidence,
        )


@dataclass
class FileChangeSet:
    """Represents a set of file changes detected in the working directory.

    Attributes:
        added: Set of filepaths for newly created files
        modified: Set of filepaths for modified existing files
        count: Total number of changed files (added + modified)
    """

    added: set[str]
    modified: set[str]
    count: int


class FileChangeTracker:
    """Tracks file changes between polls, returning only new changes.

    This class maintains state of previously seen file changes and returns
    only the delta (new changes) on each poll() call.

    Attributes:
        _handler: ExecuteHandler instance for file change detection
        _previous_added: Previously seen added files
        _previous_modified: Previously seen modified files
    """

    def __init__(self, handler: "ExecuteHandler") -> None:
        """Initialize the tracker.

        Args:
            handler: ExecuteHandler instance that provides _get_file_changes()
        """
        self._handler = handler
        self._previous_added: set[str] = set()
        self._previous_modified: set[str] = set()

    def poll(self) -> FileChangeSet:
        """Poll for new file changes since last poll.

        Returns:
            FileChangeSet containing only files that changed since the last poll
        """
        # Get current file changes
        current = self._handler._get_file_changes()

        # Calculate delta - only new files since last poll
        new_added = current.added - self._previous_added
        new_modified = current.modified - self._previous_modified

        # Update tracked state
        self._previous_added = current.added
        self._previous_modified = current.modified

        # Return only the delta
        new_count = len(new_added) + len(new_modified)
        return FileChangeSet(added=new_added, modified=new_modified, count=new_count)


class HeartbeatThread(threading.Thread):
    """Background thread that emits heartbeat messages during long-running execution.

    This thread runs alongside subprocess execution, periodically emitting
    heartbeat messages via ProgressEmitter to show execution is still active.
    It also monitors file changes and emits file events when detected.
    Additionally, it emits liveness_check events via log_event callback.

    Attributes:
        _item_id: ID of the plan item being executed
        _emitter: ProgressEmitter for output
        _file_tracker: FileChangeTracker for detecting file changes
        _handler: ExecuteHandler for line counting
        _interval: Seconds between heartbeats (scaled by verbosity)
        _initial_delay: Seconds to wait before first heartbeat
        _stop_event: Event signaling thread should stop
        _log_event: Optional callback for emitting liveness_check events
        _session_id: Optional session ID for trace correlation
        _trace_id: Optional trace ID for distributed tracing
        _start_time: Timestamp when execution started
        _alive_count: Counter for number of liveness checks emitted
    """

    def __init__(
        self,
        item_id: str,
        emitter: ProgressEmitter,
        file_tracker: FileChangeTracker,
        handler: "ExecuteHandler",
        interval: int,
        initial_delay: int,
        stop_event: threading.Event,
        log_event: Callable[..., None] | None = None,
        session_id: str | None = None,
        trace_id: str | None = None,
    ) -> None:
        """Initialize HeartbeatThread.

        Args:
            item_id: ID of the plan item being executed
            emitter: ProgressEmitter for output
            file_tracker: FileChangeTracker for detecting file changes
            handler: ExecuteHandler for line counting
            interval: Base interval between heartbeats (seconds)
            initial_delay: Delay before first heartbeat (seconds)
            stop_event: Event to signal thread should stop
            log_event: Optional callback for emitting liveness_check events
            session_id: Optional session ID for trace correlation
            trace_id: Optional trace ID for distributed tracing
        """
        super().__init__(daemon=True)
        self._item_id = item_id
        self._emitter = emitter
        self._file_tracker = file_tracker
        self._handler = handler
        self._interval = interval
        self._initial_delay = initial_delay
        self._stop_event = stop_event
        self._log_event = log_event
        self._session_id = session_id
        self._trace_id = trace_id
        self._start_time = time.time()
        self._alive_count = 0

    def run(self) -> None:
        """Main thread loop - emits heartbeats and file events until stopped.

        Waits for initial_delay, then emits heartbeats every interval seconds.
        On each iteration, also polls for file changes and emits file events.
        Every 180 seconds, emits liveness_check event via log_event callback.
        """
        # Wait for initial delay before first heartbeat
        self._stop_event.wait(self._initial_delay)

        # Track last liveness check time
        last_liveness_check = time.time()

        # Main heartbeat loop
        while not self._stop_event.is_set():
            # Calculate elapsed time since execution started
            elapsed = int(time.time() - self._start_time)

            # Get current file count for heartbeat
            file_count = self._get_file_count()

            # S4.T1: Get liveness indicators at DETAIL verbosity level
            liveness_indicators = None
            if self._emitter.config.verbosity >= VerbosityLevel.DETAIL:
                liveness_indicators = self._get_liveness_indicators()

            # Emit heartbeat with liveness indicators at DETAIL level
            self._emitter.item_heartbeat(self._item_id, elapsed, file_count, liveness_indicators)

            # S3.T1: Emit liveness_check event every LIVENESS_CHECK_INTERVAL_S
            current_time = time.time()
            if (
                self._log_event
                and (current_time - last_liveness_check) >= LIVENESS_CHECK_INTERVAL_S
            ):
                indicators = self._get_liveness_indicators()
                # Calculate status: "active" if any indicator is True, else "idle"
                status = "active" if any(indicators.values()) else "idle"
                self._alive_count += 1

                self._log_event(
                    "liveness_check",
                    status=status,
                    alive_count=self._alive_count,
                    indicators=indicators,
                    elapsed_seconds=elapsed,
                    session_id=self._session_id,
                    trace_id=self._trace_id,
                )
                last_liveness_check = current_time

            # Poll for file changes and emit file events
            changes = self._file_tracker.poll()
            if changes.count > 0:
                # Emit events for new files
                for filepath in changes.added:
                    line_count = self._handler._count_lines(filepath)
                    self._emitter.file_event(filepath, "new", line_count)

                # Emit events for modified files
                for filepath in changes.modified:
                    line_count = self._handler._count_lines(filepath)
                    self._emitter.file_event(filepath, "modified", line_count)

            # Wait for next interval (or until stop event)
            self._stop_event.wait(self._interval)

    def _get_file_count(self) -> int:
        """Get current count of changed files.

        Returns:
            Number of files changed since execution started
        """
        return self._handler._count_file_changes()

    def _get_liveness_indicators(self) -> dict[str, bool]:
        """Get liveness indicators showing agent activity.

        Returns a dict with boolean indicators for:
        - files: Files being modified in workspace
        - log: Log files being written to
        - proc: Process is running
        - cpu: CPU activity (requires psutil, graceful degradation)
        - db: Database updates (placeholder for future implementation)

        Returns:
            Dict mapping indicator names to boolean active status
        """
        indicators = {
            "files": False,
            "log": False,
            "proc": True,  # If we're in heartbeat loop, process is running
            "cpu": False,  # Requires psutil, graceful degradation
            "db": False,  # Placeholder - would need StateManager integration
        }

        # Check if files have been modified
        file_count = self._get_file_count()
        indicators["files"] = file_count > 0

        # Check if log files have been written to recently
        # Look for .log or .jsonl files modified in the last interval
        try:
            working_dir = self._handler._working_dir
            current_time = time.time()
            log_activity = False

            # Check common log file patterns
            for pattern in ["*.log", "*.jsonl"]:
                for log_file in working_dir.glob(f"**/{pattern}"):
                    if log_file.is_file():
                        # Check if modified within last interval (+ some buffer)
                        mtime = log_file.stat().st_mtime
                        if current_time - mtime < (self._interval * 2):
                            log_activity = True
                            break
                if log_activity:
                    break

            indicators["log"] = log_activity
        except Exception:
            # If log checking fails, just report False
            pass

        # S3.T2: Check CPU activity via psutil (optional dependency)
        try:
            import psutil  # type: ignore[import-untyped]

            # Get CPU usage over a short interval
            # cpu_percent() with interval returns average CPU usage over that period
            # Using 0.1 seconds to avoid blocking the heartbeat thread
            cpu_percent = psutil.cpu_percent(interval=0.1)
            # Consider CPU active if usage is above 5% (low threshold for any activity)
            indicators["cpu"] = cpu_percent > 5.0
        except ImportError:
            # psutil not available - graceful degradation
            pass
        except Exception:
            # Any other error - graceful degradation
            pass

        return indicators

    def stop(self) -> None:
        """Signal the thread to stop and wait for it to exit.

        This method is thread-safe and can be called multiple times.
        """
        self._stop_event.set()
        # Wait for thread to finish using configured timeout
        self.join(timeout=get_timeout("handler", "thread_join_s"))


class ExecuteHandler(ObservabilityContextMixin):
    """Handler for EXECUTE action.

    Executes a plan item using an implementation agent (e.g., Claude Code CLI).
    Returns execution results including files changed and test results.

    ## Architecture Context (ADR-035)

    This handler implements the unified hybrid architecture where:
    - **Server (Tier 1)**: Generates strategic base prompts with execution instructions
    - **Client (Tier 2)**: Enriches base prompts with local tactical context

    **Implementation Flow**:
    1. Server sends ExecutionRequest with base_prompt containing execution instructions
    2. Client enriches base_prompt via PromptEnricher (adds file structure, git log)
    3. Client invokes implementation agent (e.g., Claude Code CLI) via subprocess
    4. Client runs tests locally and reports results back to server

    ## IP Protection

    Strategic execution patterns (best practices, quality standards) stay on server.
    This protects Obra's proprietary implementation guidance from client-side inspection.

    ## Privacy Protection

    Tactical context (file contents, git messages, errors) never sent to server.
    Only execution results (summary, files changed, test results) is transmitted.

    See: docs/decisions/ADR-035-unified-hybrid-architecture.md

    Example:
        >>> handler = ExecuteHandler(Path("/path/to/project"))
        >>> request = ExecutionRequest(
        ...     plan_items=[{"id": "T1", "title": "Create models", ...}],
        ...     execution_index=0
        ... )
        >>> result = handler.handle(request)
        >>> print(result["status"])
    """

    def __init__(
        self,
        working_dir: Path,
        llm_config: dict[str, str] | None = None,
        session_id: str | None = None,
        log_file: Path | None = None,
        trace_id: str | None = None,
        log_event: Any | None = None,
        parent_span_id: str | None = None,
        observability_config: ObservabilityConfig | None = None,
        progress_emitter: ProgressEmitter | None = None,
        on_stream: StreamCallback = None,
        process_registry: Any | None = None,
        monitoring_context: dict[str, Any] | None = None,
    ) -> None:
        """Initialize ExecuteHandler.

        Args:
            working_dir: Working directory for file access
            llm_config: Optional LLM configuration (S6.T1)
            session_id: Optional session ID for trace correlation
            log_file: Optional log file path for event emission
            trace_id: Optional trace ID for distributed tracing
            log_event: Optional event logging callback
            parent_span_id: Optional parent span ID for tracing
            observability_config: Optional observability configuration for progress visibility
            progress_emitter: Optional progress emitter for heartbeat and file events
            on_stream: Optional callback for LLM streaming output (event_type, chunk)
            process_registry: Optional ProcessRegistry for subprocess lifecycle management
                             (FEAT-PROCESS-LIFECYCLE-001)
            monitoring_context: Optional monitoring context for liveness checks
        """
        self._working_dir = working_dir
        self._llm_config = llm_config or {}
        self._session_id = session_id
        self._log_file = log_file
        self._trace_id = trace_id
        self._log_event = log_event
        self._parent_span_id = parent_span_id
        self._observability_config = observability_config
        self._progress_emitter = progress_emitter
        self._on_stream = on_stream
        self._process_registry = process_registry
        self._monitoring_context = dict(monitoring_context) if monitoring_context else None
        if self._monitoring_context is not None:
            if "production_logger" not in self._monitoring_context:
                self._monitoring_context["production_logger"] = _MonitoringEventAdapter(
                    self._log_event
                )
            if "session_id" not in self._monitoring_context and self._session_id:
                self._monitoring_context["session_id"] = self._session_id
        self._file_tracker = FileStateTracker(working_dir)
        # Two-level baseline tracking:
        # - _session_baseline: Immutable snapshot at session start (for closeout summaries)
        # - _task_baseline: Updated after each task (for per-task new vs modified)
        initial_snapshot = self._file_tracker.snapshot()
        self._session_baseline = initial_snapshot
        self._task_baseline = initial_snapshot
        self._execution_start_time: float | None = None
        self._parallel_requested = os.environ.get("OBRA_PARALLEL_EXECUTION", "").lower() in (
            "1",
            "true",
        )
        self._parallel_enabled = False
        self._parallel_max_workers = 1
        self._parallel_logged = False
        if self._parallel_requested:
            try:
                from obra.config.loaders import load_layered_config

                config, _, _ = load_layered_config(include_defaults=True)
                parallel_cfg = config.get("execution", {}).get("parallel", {})
                self._parallel_enabled = bool(parallel_cfg.get("enabled", False))
                self._parallel_max_workers = get_execute_parallel_workers()
            except Exception as exc:
                logger.debug("Failed to load parallel execution config: %s", exc)

    def handle(self, request: ExecutionRequest) -> dict[str, Any]:
        """Handle EXECUTE action.

        Args:
            request: ExecutionRequest from server with base_prompt

        Returns:
            Dict with item_id, status, summary, files_changed, etc.

        Raises:
            ValueError: If request.base_prompt is None (server must provide base_prompt)
        """
        if not request.current_item:
            logger.error("No current item to execute")
            return {
                "item_id": "",
                "status": ExecutionStatus.FAILURE.value,
                "summary": "No item to execute",
                "files_changed": 0,
                "tests_passed": False,
                "test_count": 0,
                "coverage_delta": 0.0,
            }

        # Validate base_prompt (server-side prompting required)
        if request.base_prompt is None:
            error_msg = (
                "ExecutionRequest.base_prompt is None. Server must provide base prompt (ADR-035)."
            )
            logger.error(error_msg)
            raise ValueError(error_msg)

        if self._parallel_requested and not self._parallel_logged:
            self._parallel_logged = True
            if self._parallel_enabled:
                logger.info(
                    "Parallel execution enabled (max_workers=%d)",
                    self._parallel_max_workers,
                )
            else:
                logger.info("Parallel execution requested but disabled by config.")

        item = request.current_item
        item_id = str(item.get("id", "unknown"))
        title = str(item.get("title", "Untitled"))

        logger.info(f"Executing item {item_id}: {title}")
        show_exec_info = self._progress_emitter is None
        if self._observability_config and self._observability_config.verbosity >= VerbosityLevel.DETAIL:
            show_exec_info = True
        if show_exec_info:
            print_info(f"Executing: {item_id} - {title}")

        # Skip container items (non-leaf nodes) in hierarchical plans
        if request.plan_items and self._has_children(item_id, request.plan_items):
            logger.info("Skipping non-leaf container item: %s", item_id)
            # Update baseline snapshot even for skipped items
            self._task_baseline = self._file_tracker.snapshot()
            return {
                "item_id": item_id,
                "status": ExecutionStatus.SUCCESS.value,
                "summary": f"Skipped container item: {title}",
                "files_changed": 0,
                "tests_passed": True,
                "test_count": 0,
                "coverage_delta": 0.0,
            }

        ancestor_context = self._build_ancestor_context(item, request.plan_items)
        base_prompt = request.base_prompt
        if ancestor_context:
            base_prompt = f"{base_prompt}\n\n## Ancestor Context\n{ancestor_context}\n"
        item_context_block = self._build_item_context(item)
        if item_context_block:
            base_prompt = f"{base_prompt}\n\n{item_context_block}"
        base_prompt = self._inject_verification_notes(base_prompt, item)

        # Enrich base prompt with local tactical context
        enricher = PromptEnricher(self._working_dir)
        enriched_prompt = enricher.enrich(base_prompt)

        # Execute via implementation agent
        result = self._execute_item(item, enriched_prompt, request)

        # Log result
        status = result.get("status", ExecutionStatus.FAILURE.value)
        if status == ExecutionStatus.SUCCESS.value:
            print_info(f"  Completed: {result.get('summary', 'Success')[:50]}")
        elif status == ExecutionStatus.PARTIAL.value:
            print_warning(f"  Partial: {result.get('summary', 'Partial completion')[:50]}")
        else:
            print_error(f"  Failed: {result.get('summary', 'Execution failed')[:50]}")

        return result

    def _has_children(self, item_id: str, plan_items: list[dict[str, Any]]) -> bool:
        """Check if a plan item has children in the plan."""
        return any(candidate.get("parent_id") == item_id for candidate in plan_items)

    @staticmethod
    def _inject_verification_notes(base_prompt: str, item: dict[str, Any]) -> str:
        """Append warning context for V1/V2 verification notes on the current task."""
        verification_notes = item.get("context", {}).get("verification_notes", [])
        if not isinstance(verification_notes, list) or not verification_notes:
            return base_prompt

        note_lines: list[str] = []
        for note in verification_notes:
            if not isinstance(note, dict):
                continue
            severity = str(note.get("severity", "P2"))
            check = str(note.get("check", "C?"))
            description = str(note.get("description", "")).strip()
            if not description:
                continue
            note_lines.append(f"  - [{severity}/{check}] {description}")

        if not note_lines:
            return base_prompt

        warning_block = "WARNING: Verification notes for this task:\n" + "\n".join(note_lines)
        return f"{base_prompt}\n\n{warning_block}\n"

    @staticmethod
    def _build_item_context(item: dict[str, Any]) -> str:
        """Format the current item's acceptance criteria for inclusion in the execution prompt.

        The ancestor context provides parent-level criteria and sibling awareness,
        but the current item's own acceptance criteria are not included there.
        This method closes that gap so the LLM knows what success looks like
        for the specific task it's executing.
        """
        criteria = item.get("acceptance_criteria", [])
        if not isinstance(criteria, list) or not criteria:
            return ""

        lines = ["## Current Task Requirements"]
        for criterion in criteria:
            text = str(criterion).strip()
            if text:
                lines.append(f"- {text}")

        if len(lines) == 1:
            return ""

        return "\n".join(lines)

    def _build_ancestor_context(
        self,
        item: dict[str, Any],
        plan_items: list[dict[str, Any]],
        max_chars: int = 1500,
    ) -> str:
        """Build ancestor context chain for a plan item, including sibling awareness.

        The executor LLM receives this context to understand:
        1. The hierarchy (Epic → Story) with acceptance criteria
        2. What other tasks exist in the same story (sibling awareness)

        Sibling awareness helps the executor understand what work preceded it
        and what will follow, enabling better coordination without explicit
        dependencies in the task description.
        """
        if not plan_items:
            return ""

        id_map = {candidate.get("id"): candidate for candidate in plan_items if candidate.get("id")}
        chain: list[dict[str, Any]] = []
        current = item
        seen: set[str] = set()

        while current.get("parent_id"):
            parent_id = current.get("parent_id")
            if not parent_id or parent_id in seen:
                break
            seen.add(parent_id)
            parent = id_map.get(parent_id)
            if not parent:
                break
            chain.append(parent)
            current = parent

        if not chain:
            return ""

        chain.reverse()
        lines: list[str] = []
        for ancestor in chain:
            label = str(ancestor.get("item_type", "parent")).upper()
            title = ancestor.get("title", "Untitled")
            lines.append(f"{label}: {title}")
            criteria = ancestor.get("acceptance_criteria", [])
            if criteria:
                criteria_text = "; ".join(str(c) for c in criteria)
                lines.append(f"Acceptance: {criteria_text}")

        # Add sibling task awareness
        item_id = item.get("id")
        parent_id = item.get("parent_id")
        if parent_id:
            # Find all tasks with the same parent (siblings + self)
            siblings = [p for p in plan_items if p.get("parent_id") == parent_id]
            # Sort by ID for consistent ordering (E1.S1.T1, E1.S1.T2, etc.)
            siblings.sort(key=lambda x: x.get("id", ""))

            if len(siblings) > 1:  # Only show if there are actual siblings
                lines.append("")
                lines.append("Tasks in this story:")
                for sib in siblings:
                    sib_id = sib.get("id", "")
                    sib_title = sib.get("title", "Untitled")
                    if sib_id == item_id:
                        lines.append(f"  - {sib_id}: {sib_title}  <-- current")
                    else:
                        lines.append(f"  - {sib_id}: {sib_title}")

        context = "\n".join(lines)
        if len(context) > max_chars:
            context = context[: max_chars - 3].rstrip() + "..."
        return context

    def _execute_item(
        self, item: dict[str, Any], enriched_prompt: str, request: ExecutionRequest
    ) -> dict[str, Any]:
        """Execute a single plan item.

        Args:
            item: Plan item to execute
            enriched_prompt: Enriched execution prompt from server
            request: ExecutionRequest payload with full plan context

        Returns:
            Execution result dictionary
        """
        item_id = item.get("id", "unknown")
        title = item.get("title", "Untitled")

        # Try to deploy implementation agent with enriched prompt
        try:
            before_state = self._capture_file_state()
            result = self._deploy_agent(enriched_prompt, request)
            files_modified = self._detect_modifications(before_state)
            boundary_check = self._validate_project_boundary(files_modified)
            if boundary_check["has_violations"]:
                logger.warning(
                    "Execution boundary violation for %s: %s",
                    item_id,
                    boundary_check["violations"],
                )
                return {
                    "item_id": item_id,
                    "status": ExecutionStatus.FAILURE.value,
                    "summary": (
                        "Execution wrote files outside the target directory. "
                        f"Violations: {', '.join(boundary_check['violations'])}"
                    ),
                    "files_changed": 0,
                    "changed_file_paths": [],
                    "tests_passed": False,
                    "test_count": 0,
                    "coverage_delta": 0.0,
                }

            # Count files changed (would be from git diff in production)
            files_changed = result.get("files_changed", 0)

            status = result.get("status", ExecutionStatus.SUCCESS.value)
            if status == ExecutionStatus.PARTIAL.value and result.get("decomposition_suggested"):
                tests_passed, test_count = False, 0
            else:
                # Run tests if present
                tests_passed, test_count = self._run_tests()

            verification_tools = self._discover_verification_tools()
            result_payload = {
                "item_id": item_id,
                "status": status,
                "summary": result.get("summary", f"Executed: {title}"),
                "files_changed": files_changed,
                "changed_file_paths": files_modified,
                "tests_passed": tests_passed,
                "test_count": test_count,
                "coverage_delta": 0.0,  # Would be calculated from coverage reports
            }
            if verification_tools:
                result_payload["verification_tools"] = verification_tools
            if result.get("decomposition_suggested") is not None:
                result_payload["decomposition_suggested"] = bool(
                    result.get("decomposition_suggested")
                )
                result_payload["decomposition_reason"] = result.get("decomposition_reason")
                result_payload["partial_work_summary"] = result.get("partial_work_summary")

            return result_payload

        except Exception as e:
            logger.exception(f"Execution failed for {item_id}: {e}")
            return {
                "item_id": item_id,
                "status": ExecutionStatus.FAILURE.value,
                "summary": f"Execution failed: {e!s}",
                "files_changed": 0,
                "changed_file_paths": [],
                "tests_passed": False,
                "test_count": 0,
                "coverage_delta": 0.0,
            }

    def _capture_file_state(self) -> FileSnapshot:
        """Capture current file state for diff detection."""
        return self._file_tracker.snapshot()

    def _detect_modifications(self, before_state: FileSnapshot) -> list[str]:
        """Detect files modified since before_state was captured."""
        changes = self._file_tracker.diff(before_state)
        return changes.all_changed_files

    def _build_partial_work_summary(
        self,
        max_chars: int,
    ) -> tuple[str | None, int]:
        """Build a partial work summary for decomposition responses."""
        changes = self._file_tracker.diff(self._task_baseline)
        changed_files = changes.added + changes.modified
        if not changed_files:
            return None, 0

        after_snapshot = self._file_tracker.snapshot()
        size_delta = 0
        for path in changed_files:
            after_state = after_snapshot.files.get(path)
            if not after_state:
                continue
            before_state = self._task_baseline.files.get(path)
            before_size = before_state.size if before_state else 0
            size_delta += after_state.size - before_size

        lines_added = self._file_tracker.count_lines(changed_files)
        file_list = ", ".join(changed_files)
        summary = (
            f"Files modified: {len(changed_files)} ({file_list}). "
            f"Lines added: {lines_added}. "
            f"Size delta: {size_delta} bytes."
        )

        if max_chars > 0 and len(summary) > max_chars:
            summary = summary[: max_chars - 3].rstrip() + "..."

        return summary, len(changed_files)

    def _validate_project_boundary(self, files_modified: list[str]) -> dict[str, Any]:
        """Validate all modifications are within project directory."""
        if not files_modified:
            return {"has_violations": False, "violations": []}

        project_root = self._working_dir.resolve()
        violations: list[str] = []

        for file_path in files_modified:
            try:
                resolved = (project_root / file_path).resolve()
                resolved.relative_to(project_root)
            except ValueError:
                violations.append(file_path)
                logger.exception("Project boundary violation")

        if violations:
            logger.error(
                "Execute handler modified %d file(s) outside project: %s",
                len(violations),
                violations,
            )

        return {"has_violations": bool(violations), "violations": violations}

    def _deploy_agent(self, prompt: str, request: ExecutionRequest) -> dict[str, Any]:
        """Deploy implementation agent via subprocess.

        Delegates to unified LLM subprocess runner for command building,
        execution, retry logic, and error handling.

        Args:
            prompt: Execution prompt
            request: ExecutionRequest payload with plan items

        Returns:
            Agent result dictionary with status, summary, files_changed
        """
        from obra.llm.subprocess_runner import LLMSubprocessConfig, run_llm_subprocess

        logger.debug("Deploying implementation agent")

        # ISSUE-SAAS-050: Capture HEAD SHA before execution to detect git operations
        # that modify repository state without changing working tree files
        start_head = self._get_head_sha()
        self._execution_start_time = time.monotonic()
        decomposition_enabled = is_decomposition_enabled()
        duration_threshold_s = get_decomposition_duration_threshold_s()
        warning_threshold_s = get_decomposition_warning_threshold_s()
        summary_max_chars = get_decomposition_summary_max_chars()
        decomposition_task_id = "execution"
        if request.current_item:
            decomposition_task_id = str(request.current_item.get("id", "execution"))
        cancellation_event = threading.Event()
        watchdog_thread: threading.Thread | None = None
        watchdog_stop_event = threading.Event()
        liveness_monitor: LivenessMonitor | None = None
        liveness_config: dict[str, Any] | None = None
        decomposition_logger = None
        if decomposition_enabled:
            try:
                decomposition_logger = get_production_logger(session_id=self._session_id)
            except Exception as exc:
                logger.debug("Failed to init production logger for decomposition: %s", exc)

        if decomposition_enabled:
            try:
                liveness_config, _, _ = load_layered_config(include_defaults=True)
            except Exception as exc:
                logger.debug("Failed to load liveness config: %s", exc)
                liveness_config = None
            if liveness_config:
                task_seed = "0"
                if request.current_item:
                    task_seed = str(request.current_item.get("id", "0"))
                task_id = abs(hash(f"{self._session_id}:{task_seed}")) % 1_000_000
                production_logger = None
                if self._monitoring_context:
                    production_logger = self._monitoring_context.get("production_logger")
                if production_logger is None:
                    production_logger = _MonitoringEventAdapter(self._log_event)
                liveness_monitor = LivenessMonitor(
                    task_id=task_id,
                    config=liveness_config,
                    workspace_path=self._working_dir,
                    production_logger=production_logger,
                    log_path=self._log_file,
                    state_manager=None,
                    process_pid=None,
                )
                liveness_monitor.capture_baseline()

        # Extract provider and model from config
        bypass_sandbox = False
        approval_mode: str | None = None
        from obra.config.llm import DEFAULT_REASONING_LEVEL

        if self._llm_config:
            provider = self._llm_config.get("provider", "anthropic")
            model = self._llm_config.get("model", "default")
            reasoning_level = self._llm_config.get("reasoning_level", DEFAULT_REASONING_LEVEL)
            auth_method = self._llm_config.get("auth_method", "oauth")
            # BUG-11ff06b1: skip_git_check only applies to OpenAI Codex
            # For other providers, always False
            if provider == "openai":
                git_config: dict[str, Any] = cast(dict, self._llm_config.get("git", {}))
                skip_git_check = git_config.get("skip_check", True)  # Default True for OpenAI
                # BUG-a377298b: Extract codex config to pass approval_mode
                # Without this, Codex may use approval_policy=never which forces read-only sandbox
                codex_config: dict[str, Any] = cast(dict, self._llm_config.get("codex", {}))
                bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
                approval_mode = codex_config.get("approval_mode")
            else:
                skip_git_check = False  # Not applicable to non-OpenAI providers
        else:
            # Fallback to defaults if no config
            provider = "anthropic"
            model = "default"
            reasoning_level = DEFAULT_REASONING_LEVEL
            auth_method = "oauth"
            skip_git_check = False

        item = request.current_item
        item_id = str(item.get("id", "unknown"))

        error_message: str | None = None

        # S2.T2: Set up heartbeat thread if progress emitter is available
        heartbeat_thread: HeartbeatThread | None = None
        stop_event: threading.Event | None = None

        if self._progress_emitter and self._observability_config:
            # Total tasks is set by versioned plan_total events from the server.
            # No redundant set_total_tasks call here — the version guard in
            # ProgressEmitter ensures the latest plan version's count is used.
            # Calculate scaled interval based on verbosity
            # QUIET (0): 3x base, PROGRESS (1): 1x base, DETAIL (2+): 0.5x base
            base_interval = get_heartbeat_interval()
            verbosity = self._observability_config.verbosity

            inline_heartbeat = False
            if hasattr(self._progress_emitter, "use_inline_heartbeat"):
                inline_heartbeat = bool(self._progress_emitter.use_inline_heartbeat())

            if verbosity == 0:  # QUIET
                scaled_interval = base_interval * 3
            elif verbosity == 1:  # PROGRESS
                scaled_interval = 1 if inline_heartbeat else base_interval
            else:  # DETAIL (2+)
                scaled_interval = int(base_interval * 0.5)

            # Get initial delay
            initial_delay = get_heartbeat_initial_delay()

            # Create file change tracker
            file_tracker = FileChangeTracker(self)

            # Create and start heartbeat thread
            stop_event = threading.Event()
            # Use the current task id so heartbeat logs show a meaningful label.
            # S3.T3: Pass log_event, session_id, trace_id to HeartbeatThread
            heartbeat_thread = HeartbeatThread(
                item_id=item_id,
                emitter=self._progress_emitter,
                file_tracker=file_tracker,
                handler=self,
                interval=scaled_interval,
                initial_delay=initial_delay,
                stop_event=stop_event,
                log_event=self._log_event,
                session_id=self._session_id,
                trace_id=self._trace_id,
            )
            heartbeat_thread.start()
            logger.debug(
                f"Started heartbeat thread: interval={scaled_interval}s, "
                f"initial_delay={initial_delay}s, verbosity={verbosity}"
            )

        def _investigate_liveness() -> bool:
            if not liveness_config:
                return False
            if not self._process_registry:
                return False
            tracked = self._process_registry.tracked_pids
            if not tracked:
                return False
            pid = tracked[-1]
            production_logger = None
            if self._monitoring_context:
                production_logger = self._monitoring_context.get("production_logger")
            if production_logger is None:
                production_logger = _MonitoringEventAdapter(self._log_event)
            investigator = HangInvestigator(
                pid=pid,
                config=liveness_config,
                workspace_path=self._working_dir,
                production_logger=production_logger,
                task_id=abs(hash(f"{self._session_id}:{pid}")) % 1_000_000,
            )
            evidence = investigator.investigate(session_id=self._session_id)
            return evidence.classification != HangClassification.REAL_HANG

        def _liveness_allows_decomposition() -> bool:
            status: LivenessStatus | None = None
            investigation_not_hung: bool | None = None
            if self._monitoring_context:
                monitor_thread = self._monitoring_context.get("monitor_thread")
                if monitor_thread is not None and hasattr(
                    monitor_thread, "get_last_liveness_status"
                ):
                    status = monitor_thread.get_last_liveness_status()
                    investigation_not_hung = monitor_thread.get_last_investigation_not_hung()
            if status is None and liveness_monitor:
                status = liveness_monitor.check_liveness(session_id=self._session_id)
                if status == LivenessStatus.INVESTIGATE:
                    investigation_not_hung = _investigate_liveness()

            if status == LivenessStatus.ALIVE:
                return True
            if status == LivenessStatus.INVESTIGATE and investigation_not_hung:
                return True
            return False

        def _duration_watchdog() -> None:
            warning_emitted = False
            while not watchdog_stop_event.is_set() and not cancellation_event.is_set():
                if watchdog_stop_event.wait(timeout=30):
                    break
                if self._execution_start_time is None:
                    continue
                elapsed = time.monotonic() - self._execution_start_time
                if (
                    not warning_emitted
                    and warning_threshold_s > 0
                    and elapsed >= warning_threshold_s
                ):
                    warning_emitted = True
                    if self._progress_emitter:
                        self._progress_emitter.decomposition_warning(
                            int(elapsed),
                            warning_threshold_s,
                            duration_threshold_s,
                        )
                    if decomposition_logger:
                        decomposition_logger.log_decomposition_warning(
                            task_id=decomposition_task_id,
                            elapsed_s=int(elapsed),
                            threshold_s=warning_threshold_s,
                        )
                if duration_threshold_s > 0 and elapsed >= duration_threshold_s:
                    if _liveness_allows_decomposition():
                        if self._progress_emitter:
                            self._progress_emitter.decomposition_triggered()
                        if decomposition_logger:
                            decomposition_logger.log_decomposition_triggered(
                                task_id=decomposition_task_id,
                                elapsed_s=int(elapsed),
                                threshold_s=duration_threshold_s,
                            )
                        cancellation_event.set()
                    break

        if decomposition_enabled and duration_threshold_s > 0:
            watchdog_thread = threading.Thread(
                target=_duration_watchdog,
                daemon=True,
                name="decomposition-watchdog",
            )
            watchdog_thread.start()

        rollback_enabled = get_interactive_guard_rollback_enabled()
        rollback_codes = get_interactive_guard_rollback_codes()
        retry_max = max(0, get_interactive_guard_retry_max())
        rollback_store = None
        rollback_snapshot = None

        if rollback_enabled:
            rollback_store = WorkspaceRollbackStore(
                self._working_dir,
                run_id=self._session_id or "execute",
            )
            rollback_snapshot = rollback_store.capture()

        try:
            # Adapter for on_stream callback: subprocess_runner expects (line),
            # but execute.py's self._on_stream expects (event_type, line)
            def stream_adapter(line: str) -> None:
                if self._on_stream:
                    self._on_stream("llm_streaming", line.rstrip("\n"))

            attempt = 0
            current_prompt = prompt
            while True:
                # Build configuration for shared subprocess runner
                config = LLMSubprocessConfig(
                    prompt=current_prompt,
                    cwd=self._working_dir,
                    provider=provider,
                    model=model,
                    reasoning_level=reasoning_level,
                    auth_method=auth_method,
                    timeout_s=get_agent_execution_timeout(),
                    skip_git_check=skip_git_check,
                    bypass_sandbox=bypass_sandbox,
                    approval_mode=approval_mode,
                    retry_enabled=True,
                    streaming=True,  # Execute handler always uses streaming
                    # Disable stream idle timeout during execution to avoid
                    # preempting adaptive decomposition and liveness-based detection.
                    stream_idle_timeout_s=0,
                    on_stream=stream_adapter if self._on_stream else None,
                    log_event=self._log_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    call_site="execute",
                    monitoring_context=self._monitoring_context,
                    session_id=self._session_id,
                    run_id=self._session_id,
                    process_registry=self._process_registry,  # FEAT-PROCESS-LIFECYCLE-001
                    mode="execute",  # ISSUE-EXEC-003: Execute mode - no --print, allows file writes
                    cancellation_event=cancellation_event if decomposition_enabled else None,
                )

                # Execute via shared subprocess runner
                result = run_llm_subprocess(config)

                # Check result
                if result.cancelled:
                    if decomposition_logger:
                        elapsed = 0
                        if self._execution_start_time is not None:
                            elapsed = int(time.monotonic() - self._execution_start_time)
                        decomposition_logger.log_decomposition_complete(
                            task_id=decomposition_task_id,
                            elapsed_s=elapsed,
                            threshold_s=duration_threshold_s,
                        )
                    summary, files_changed = self._build_partial_work_summary(summary_max_chars)
                    return {
                        "status": ExecutionStatus.PARTIAL.value,
                        "summary": "Execution cancelled after duration threshold",
                        "files_changed": files_changed,
                        "decomposition_suggested": True,
                        "decomposition_reason": "duration_threshold",
                        "partial_work_summary": summary,
                    }
                if result.success:
                    # ISSUE-SAAS-046 FIX: Count actual file changes via git diff
                    files_changed = self._count_file_changes()

                    # ISSUE-SAAS-046 FIX: Zero-Output Validation Gate
                    # Fail fast when execution claims success but produced no output.
                    # This prevents false-positive quality scores on empty work.
                    if files_changed == 0:
                        # ISSUE-SAAS-050 FIX: Zero-output exemptions
                        # Exemption 1: Git operations
                        # Git commit/merge operations modify .git/ but not working tree,
                        # causing false positives. Detect by comparing HEAD before/after.
                        current_head = self._get_head_sha()
                        if start_head and current_head and current_head != start_head:
                            logger.debug(
                                f"Git operation detected: HEAD changed from {start_head[:8]} "
                                f"to {current_head[:8]}"
                            )
                            # Update baseline snapshot for next task
                            self._task_baseline = self._file_tracker.snapshot()
                            return {
                                "status": ExecutionStatus.SUCCESS.value,
                                "summary": "Task executed successfully (repository updated)",
                                "files_changed": 0,
                            }

                        # Exemption 2: Infrastructure-focused tasks
                        # Tasks like Intent Reconciliation (IR) only produce .obra/ artifacts,
                        # which are filtered out. This is expected behavior, not a failure.
                        item_id = request.current_item.get("id", "") if request.current_item else ""
                        if self._is_infrastructure_task(item_id):
                            logger.info(
                                f"Infrastructure task {item_id} produced only .obra/ artifacts "
                                f"(expected behavior for intent reconciliation tasks)"
                            )
                            # Update baseline snapshot for next task
                            self._task_baseline = self._file_tracker.snapshot()
                            return {
                                "status": ExecutionStatus.SUCCESS.value,
                                "summary": "Infrastructure task completed (artifacts updated)",
                                "files_changed": 0,
                            }

                        error_message = "No files written to target directory"
                        logger.warning(
                            f"Zero-output detected: LLM exited successfully but no files changed. "
                            f"working_dir={self._working_dir}"
                        )
                        return {
                            "status": ExecutionStatus.FAILURE.value,
                            "summary": (
                                "Execution completed but no files were written to the target directory. "
                                "Likely causes: (1) Working directory not writable or path mismatch, "
                                "(2) LLM decided no changes were needed (check review findings), "
                                f"(3) Provider CLI misconfigured ({get_message('recovery.config.doctor')}), "
                                "(4) Task prompt too vague for actionable output. "
                                "Check provider CLI logs and retry with more specific instructions."
                            ),
                            "files_changed": 0,
                        }

                    # BUG-a377298b: Validate deliverables have meaningful content
                    # Even if files exist, verify they contain actual content and match
                    # expected extensions (if configured in .obra/config.yaml)
                    changed_files = self._get_file_changes()
                    all_changed = changed_files.added | changed_files.modified
                    valid_files, validation_warnings = self._validate_deliverables(all_changed)

                    # Log any validation warnings
                    for warning in validation_warnings:
                        logger.warning(f"Deliverable validation: {warning}")

                    # If no valid deliverables after validation, fail
                    if len(valid_files) == 0 and len(all_changed) > 0:
                        error_message = "No valid deliverables created"
                        logger.warning(
                            f"Deliverable validation failed: {len(all_changed)} files changed but "
                            f"none passed validation. working_dir={self._working_dir}"
                        )
                        return {
                            "status": ExecutionStatus.FAILURE.value,
                            "summary": (
                                f"Execution created {len(all_changed)} file(s) but none are valid deliverables. "
                                + "; ".join(validation_warnings)
                                + " Check .obra/config.yaml validation settings if this is unexpected."
                            ),
                            "files_changed": 0,
                        }

                    # Update baseline snapshot for next task
                    # This ensures files created/modified in this task are correctly
                    # identified as "modified" (not "new") in subsequent tasks
                    self._task_baseline = self._file_tracker.snapshot()

                    return {
                        "status": ExecutionStatus.SUCCESS.value,
                        "summary": "Task executed successfully",
                        "files_changed": len(valid_files),
                    }
                # Execution failed
                error_message = result.error or "Unknown error"
                if result.error_details and result.error_details.request_id:
                    if "request_id=" not in error_message:
                        error_message = (
                            f"{error_message} (request_id={result.error_details.request_id})"
                        )
                if result.retry_count and "retries=" not in error_message:
                    error_message = f"{error_message} (retries={result.retry_count})"
                matched_code, matched_line = self._match_rollback_code(
                    error_message,
                    rollback_codes,
                )
                interactive_failure = result.interactive_failure
                if not interactive_failure:
                    interactive_failure = extract_interactive_failure(error_message, None)
                sanitized_line = sanitize_interactive_line(
                    interactive_failure.line if interactive_failure else None
                )
                if interactive_failure:
                    message = "Interactive guard blocked an interactive prompt."
                    if sanitized_line:
                        message = f"{message} ({sanitized_line.line})"
                    if self._log_event:
                        self._log_event(
                            "interactive_guard_triggered",
                            code=interactive_failure.code,
                            pattern_id=interactive_failure.pattern_id,
                            matched_line=sanitized_line.line if sanitized_line else "",
                            line_redacted=(sanitized_line.redacted if sanitized_line else False),
                            line_truncated=(sanitized_line.truncated if sanitized_line else False),
                            source=interactive_failure.source,
                            handler="execute",
                            attempt=attempt,
                            attempt_number=attempt + 1,
                            retry_max=retry_max,
                            rollback_enabled=rollback_enabled,
                            rollback_code_matched=bool(matched_code),
                            will_retry=bool(
                                matched_code and rollback_enabled and attempt < retry_max
                            ),
                            message=message,
                            session_id=self._session_id,
                            trace_id=self._trace_id,
                        )
                    logger.warning(
                        "Interactive guard triggered in execute: code=%s attempt=%d/%d line=%s",
                        interactive_failure.code,
                        attempt,
                        retry_max,
                        sanitized_line.line if sanitized_line else "",
                    )
                    if self._progress_emitter:
                        self._progress_emitter.interactive_guard_notice(message)
                if rollback_enabled and rollback_store and rollback_snapshot and matched_code:
                    rollback_store.restore(rollback_snapshot)
                    if self._log_event:
                        changes = rollback_snapshot.changes
                        self._log_event(
                            "interactive_guard_rollback",
                            code=matched_code,
                            pattern_id=(
                                interactive_failure.pattern_id if interactive_failure else None
                            ),
                            matched_line=sanitized_line.line if sanitized_line else "",
                            line_redacted=(sanitized_line.redacted if sanitized_line else False),
                            line_truncated=(sanitized_line.truncated if sanitized_line else False),
                            source=(interactive_failure.source if interactive_failure else None),
                            handler="execute",
                            attempt=attempt,
                            attempt_number=attempt + 1,
                            retry_max=retry_max,
                            added_count=len(changes.added) if changes else 0,
                            modified_count=len(changes.modified) if changes else 0,
                            deleted_count=len(changes.deleted) if changes else 0,
                            session_id=self._session_id,
                            trace_id=self._trace_id,
                            message="Workspace rolled back after interactive prompt.",
                        )
                    if self._progress_emitter:
                        self._progress_emitter.interactive_guard_notice(
                            "Interactive guard triggered; workspace rolled back."
                        )
                    if attempt < retry_max:
                        recovery_banner = build_interactive_recovery_banner(
                            interactive_failure.line if interactive_failure else matched_line
                        )
                        current_prompt = f"{recovery_banner}\n\n{prompt}"
                        if self._log_event:
                            self._log_event(
                                "interactive_guard_retry",
                                code=matched_code,
                                pattern_id=(
                                    interactive_failure.pattern_id if interactive_failure else None
                                ),
                                matched_line=(sanitized_line.line if sanitized_line else ""),
                                line_redacted=(
                                    sanitized_line.redacted if sanitized_line else False
                                ),
                                line_truncated=(
                                    sanitized_line.truncated if sanitized_line else False
                                ),
                                source=(
                                    interactive_failure.source if interactive_failure else None
                                ),
                                handler="execute",
                                attempt=attempt + 1,
                                attempt_number=attempt + 2,
                                retry_max=retry_max,
                                session_id=self._session_id,
                                trace_id=self._trace_id,
                                message=f"Retrying after interactive guard ({attempt + 1}/{retry_max}).",
                            )
                        if self._progress_emitter:
                            self._progress_emitter.interactive_guard_notice(
                                f"Retrying after interactive guard ({attempt + 1}/{retry_max})."
                            )
                        attempt += 1
                        continue
                return {
                    "status": ExecutionStatus.FAILURE.value,
                    "summary": f"Execution failed: {error_message}",
                    "files_changed": 0,
                }

        except Exception as e:
            logger.exception(f"Agent deployment failed: {e}")
            error_message = str(e)
            return {
                "status": ExecutionStatus.FAILURE.value,
                "summary": f"Deployment failed: {e!s}",
                "files_changed": 0,
            }
        finally:
            # S2.T2: Stop heartbeat thread if it was started
            if heartbeat_thread and stop_event:
                logger.debug("Stopping heartbeat thread")
                heartbeat_thread.stop()
            if watchdog_thread:
                watchdog_stop_event.set()
                watchdog_thread.join(timeout=2)
            self._execution_start_time = None

    def _match_rollback_code(
        self,
        error_message: str,
        rollback_codes: list[str],
    ) -> tuple[str | None, str | None]:
        """Extract rollback code and matched line from error message."""
        for code in rollback_codes:
            if error_message.startswith(code):
                remainder = error_message[len(code) :].lstrip(": ").strip()
                if not remainder:
                    return code, ""
                parts = remainder.split(":", 1)
                if len(parts) == 2:
                    return code, parts[1].strip()
                return code, remainder.strip()
        return None, None

    def _is_git_repository(self) -> bool:
        """Check if working directory is within a git repository.

        ISSUE-SAAS-049: Smart git detection following pattern from cli_runner.py.

        Returns:
            True if working directory is inside a git repository, False otherwise.
        """
        path = self._working_dir.resolve()
        if (path / ".git").exists():
            return True
        return any((parent / ".git").exists() for parent in path.parents)

    def _get_head_sha(self) -> str | None:
        """Get current HEAD commit SHA.

        ISSUE-SAAS-050: Used to detect git operations that modify repository
        state without changing working tree files (e.g., git commit).

        Returns:
            The current HEAD commit SHA, or None if not a git repository
            or if an error occurs.
        """
        if not self._is_git_repository():
            return None
        try:
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=self._working_dir,
                capture_output=True,
                text=True,
                timeout=int(get_timeout("handler", "subprocess_s")),
                check=False,
            )
            return result.stdout.strip() if result.returncode == 0 else None
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return None
        except Exception as e:
            logger.debug(f"Failed to get HEAD SHA: {e}")
            return None

    @staticmethod
    def _is_infrastructure_task(item_id: str) -> bool:
        """Check if task ID indicates an infrastructure-focused task.

        Infrastructure tasks are expected to only produce .obra/ artifacts
        (e.g., intent documents, reconciliation records) rather than
        code deliverables. They should be exempt from zero-output validation.

        Task ID prefixes:
            IR: Intent Reconciliation - documents intent changes

        Args:
            item_id: Task/item identifier (e.g., "IR1", "S1", "S1.T1")

        Returns:
            True if task is infrastructure-focused (should skip zero-output check)
        """
        if not item_id:
            return False

        # Infrastructure task prefixes
        infrastructure_prefixes = ("IR",)  # Intent Reconciliation

        # Check if item_id starts with any infrastructure prefix
        upper_id = item_id.upper()
        return any(upper_id.startswith(prefix) for prefix in infrastructure_prefixes)

    def _get_validation_config(self) -> dict[str, Any]:
        """Load deliverable validation config from .obra/config.yaml.

        Returns:
            Dict with validation settings:
                - min_file_size: Minimum bytes for meaningful content (default: 10)
                - expected_extensions: Optional list of expected file extensions
        """
        defaults = {
            "min_file_size": 10,
            "expected_extensions": None,  # None means any extension is valid
        }

        config_path = self._working_dir / ".obra" / "config.yaml"
        if not config_path.exists():
            return defaults

        try:
            import yaml

            with config_path.open(encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}

            validation = config.get("validation", {})
            if not isinstance(validation, dict):
                return defaults

            return {
                "min_file_size": validation.get("min_file_size", defaults["min_file_size"]),
                "expected_extensions": validation.get("expected_extensions"),
            }
        except Exception as e:
            logger.debug(f"Failed to load validation config: {e}")
            return defaults

    def _has_meaningful_content(self, filepath: str, min_size: int = 10) -> bool:
        """Check if a file has meaningful content (not empty or trivially small).

        Args:
            filepath: Relative path to file from working directory
            min_size: Minimum file size in bytes to be considered meaningful

        Returns:
            True if file exists and has at least min_size bytes
        """
        try:
            file_path = self._working_dir / filepath
            if not file_path.exists() or not file_path.is_file():
                return False
            return file_path.stat().st_size >= min_size
        except Exception as e:
            logger.debug(f"Failed to check file size for {filepath}: {e}")
            return False

    def _matches_expected_extensions(
        self, filepath: str, expected_extensions: list[str] | None
    ) -> bool:
        """Check if file matches expected extensions (if configured).

        Args:
            filepath: File path to check
            expected_extensions: List of expected extensions (e.g., [".py", ".ts"])
                               If None, any extension is valid.

        Returns:
            True if no expected_extensions configured, or file matches one
        """
        if not expected_extensions:
            return True  # No restriction configured

        normalized = filepath.lower()
        return any(normalized.endswith(ext.lower()) for ext in expected_extensions)

    def _validate_deliverables(self, paths: set[str]) -> tuple[set[str], list[str]]:
        """Validate that paths contain meaningful deliverables.

        BUG-a377298b: Enhanced validation to catch silent failures.

        Args:
            paths: Set of file paths (already filtered for infrastructure)

        Returns:
            Tuple of (valid_paths, validation_warnings)
            - valid_paths: Files that pass all validation checks
            - validation_warnings: List of warning messages for failed checks
        """
        config = self._get_validation_config()
        min_size = config["min_file_size"]
        expected_extensions = config["expected_extensions"]

        valid_paths: set[str] = set()
        warnings: list[str] = []

        empty_files: list[str] = []
        wrong_extension_files: list[str] = []

        for path in paths:
            # Check meaningful content
            if not self._has_meaningful_content(path, min_size):
                empty_files.append(path)
                continue

            # Check expected extensions (if configured)
            if not self._matches_expected_extensions(path, expected_extensions):
                wrong_extension_files.append(path)
                continue

            valid_paths.add(path)

        # Build warnings
        if empty_files:
            warnings.append(
                f"{len(empty_files)} file(s) have no meaningful content (<{min_size} bytes): "
                f"{', '.join(empty_files[:3])}{'...' if len(empty_files) > 3 else ''}"
            )

        if wrong_extension_files and expected_extensions:
            warnings.append(
                f"{len(wrong_extension_files)} file(s) don't match expected extensions "
                f"{expected_extensions}: {', '.join(wrong_extension_files[:3])}"
                f"{'...' if len(wrong_extension_files) > 3 else ''}"
            )

        return valid_paths, warnings

    def _count_file_changes(self) -> int:
        """Count files in working directory using FileStateTracker.

        Uses git-independent file tracking. Respects IGNORE_DIRS patterns
        to exclude infrastructure files (.obra/, node_modules/, etc.).

        Returns:
            Number of trackable files in working directory.
            Returns 0 only if directory is truly empty or an error occurs.
        """
        try:
            files = self._file_tracker.get_all_files()
            file_count = len(files)
            logger.debug(f"FileStateTracker found {file_count} files in {self._working_dir}")
            return file_count
        except OSError as e:
            logger.warning(f"File tracking failed: {e}")
            return 0

    def _get_file_changes(self) -> FileChangeSet:
        """Get file changes since last task completed.

        Compares current state against task baseline to properly differentiate
        between added and modified files within the current task.

        Returns:
            FileChangeSet with added, modified files and total count
        """
        try:
            changes = self._file_tracker.diff(self._task_baseline)
            total_count = len(changes.added) + len(changes.modified)
            logger.debug(
                f"FileStateTracker: {len(changes.added)} added, {len(changes.modified)} modified"
            )
            return FileChangeSet(
                added=set(changes.added),
                modified=set(changes.modified),
                count=total_count,
            )
        except OSError as e:
            logger.warning(f"File tracking failed: {e}")
            return FileChangeSet(added=set(), modified=set(), count=0)

    def get_session_file_changes(self) -> FileChangeSet:
        """Get file changes since session started.

        Compares current state against session baseline (captured at handler init)
        to get the complete picture of files created/modified across all tasks.

        Used by orchestrator for closeout summaries.

        Returns:
            FileChangeSet with added, modified files and total count
        """
        try:
            changes = self._file_tracker.diff(self._session_baseline)
            total_count = len(changes.added) + len(changes.modified)
            logger.debug(
                f"Session file changes: {len(changes.added)} added, {len(changes.modified)} modified"
            )
            return FileChangeSet(
                added=set(changes.added),
                modified=set(changes.modified),
                count=total_count,
            )
        except OSError as e:
            logger.warning(f"Session file tracking failed: {e}")
            return FileChangeSet(added=set(), modified=set(), count=0)

    def _count_lines(self, filepath: str) -> int | None:
        """Count lines in a file, handling binary files gracefully.

        Args:
            filepath: Relative path to file from working directory

        Returns:
            Number of lines in the file, or None if file is binary or unreadable
        """
        try:
            file_path = self._working_dir / filepath

            # Read file and count lines
            with file_path.open(encoding="utf-8") as f:
                return sum(1 for _ in f)

        except UnicodeDecodeError:
            # Binary file - return None
            logger.debug(f"Binary file detected: {filepath}")
            return None
        except FileNotFoundError:
            logger.debug(f"File not found: {filepath}")
            return None
        except Exception as e:
            logger.debug(f"Failed to count lines in {filepath}: {e}")
            return None

    def _run_tests(self) -> tuple[bool, int]:
        """Run project tests.

        Returns:
            Tuple of (tests_passed, test_count)
        """
        from obra.config.loaders import (
            get_verification_discovery_enabled,
            get_verification_force_refresh,
            load_layered_config,
        )
        from obra.hybrid.tooling_discovery import ToolingDiscovery

        test_command = None
        try:
            config, _, _ = load_layered_config(include_defaults=True)
            tools = config.get("fix", {}).get("verification", {}).get("tools", [])
            if isinstance(tools, list):
                for tool in tools:
                    if isinstance(tool, dict) and tool.get("category") == "tests":
                        test_command = tool.get("command")
                        break
        except Exception as exc:
            logger.debug(f"Failed to load verification tools config: {exc}")

        if not test_command and get_verification_discovery_enabled():
            discovery = ToolingDiscovery(self._working_dir, self._llm_config)
            tooling = discovery.discover(force_refresh=get_verification_force_refresh())
            test_command = (
                tooling.get("verification", {}).get("test", {}).get("command")
                if isinstance(tooling, dict)
                else None
            )

        if not test_command:
            return True, 0

        try:
            formatted = test_command.format(files="", paths="")
            cmd = shlex.split(formatted)
        except ValueError as exc:
            logger.warning("Invalid test command format: %s", exc)
            return True, 0

        try:
            logger.debug(f"Running tests with command: {formatted}")
            result = subprocess.run(
                cmd,
                check=False,
                capture_output=True,
                timeout=get_llm_api_timeout(),
                cwd=self._working_dir,
            )
            passed = result.returncode == 0
            output = result.stdout.decode("utf-8", errors="ignore")
            test_count = output.count("passed") + output.count("PASS")
            return passed, max(test_count, 1 if passed else 0)
        except subprocess.TimeoutExpired:
            logger.warning("Test timeout with command: %s", formatted)
        except FileNotFoundError:
            logger.warning("Test command not found: %s", formatted)
        except Exception as exc:
            logger.debug(f"Test runner failed: {exc}")

        # No tests found or run
        return True, 0  # Assume success if no tests

    def _discover_verification_tools(self) -> dict[str, Any]:
        """Discover verification tools for server-side FIX enforcement.

        Returns:
            Dict with available tools, missing tools, and discovery source
        """
        try:
            from obra.config.loaders import load_layered_config

            config, _, _ = load_layered_config(include_defaults=True)
            return resolve_verification_tools(
                self._working_dir,
                self._llm_config,
                config,
                prefer_existing=False,
            )
        except Exception as exc:
            logger.warning("Failed to discover verification tools: %s", exc)
            return {}


__all__ = ["ExecuteHandler"]
