"""Stage handler for custom pipeline stages.

This module handles the PIPELINE_STAGE action from the server. It executes
custom review agents at configurable trigger points in the orchestration flow.

The stage execution process:
    1. Receive PipelineStageRequest with stage config and content
    2. Resolve agent via AgentRegistry (built-in or plug-in)
    3. Prepare input based on input_type
    4. Execute agent with timeout
    5. Parse result for verdict and issues
    6. Return PipelineStageResult to server

Related:
    - docs/design/prds/DYNAMIC_PIPELINE_PRD.md
    - obra/api/protocol.py
    - obra/hybrid/orchestrator.py
    - functions/src/pipeline/stage_executor.py
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.agents import AgentDeployer
from obra.agents.base import BaseAgent
from obra.agents.registry import get_registry
from obra.api.protocol import AgentType, PipelineStageRequest, PipelineStageResult

logger = logging.getLogger(__name__)


class StageHandler:
    """Handler for PIPELINE_STAGE action.

    Executes custom pipeline stages by deploying configured agents at
    trigger points in the orchestration flow. Supports both built-in
    agents (via AgentType) and plug-in agents (via AgentRegistry).

    Example:
        >>> handler = StageHandler(Path("/path/to/project"), llm_config=llm_config)
        >>> request = PipelineStageRequest(
        ...     stage_name="plan_validation",
        ...     trigger="after_derivation",
        ...     agent="sense_check",
        ...     input_type="derived_plan",
        ...     content={"plan_items": [...]},
        ...     iteration=0,
        ...     max_iterations=3,
        ...     timeout_s=300
        ... )
        >>> result = handler.handle(request)
        >>> print(result.verdict)  # "sound" or "issues"
    """

    def __init__(
        self,
        working_dir: Path,
        *,
        llm_config: dict[str, Any] | None = None,
        log_event: Callable[..., None] | None = None,
    ) -> None:
        """Initialize StageHandler.

        Args:
            working_dir: Working directory for file access
            llm_config: Optional LLM configuration dict for agent analysis
            log_event: Optional callback for logging stage events
        """
        self._working_dir = working_dir
        self._llm_config = llm_config
        self._log_event = log_event

        # Initialize AgentDeployer for agent execution
        # Use sequential execution for pipeline stages (not parallel)
        self._deployer = AgentDeployer(
            working_dir,
            llm_config=llm_config,
            parallel=False,  # Pipeline stages run sequentially
            max_workers=1,
        )
        logger.info("StageHandler initialized with AgentDeployer")

    def handle(self, request: PipelineStageRequest) -> PipelineStageResult:
        """Handle PIPELINE_STAGE action.

        Executes the configured agent and returns results for routing decisions.

        Args:
            request: PipelineStageRequest from server

        Returns:
            PipelineStageResult with verdict and issues

        Raises:
            ValueError: If agent resolution or input preparation fails
        """
        start_time = time.time()

        # Log stage start
        self._log_stage_event(
            "stage_start",
            stage_name=request.stage_name,
            trigger=request.trigger,
            agent=request.agent,
            iteration=request.iteration,
        )

        try:
            # Try to resolve as AgentType for built-in agents
            try:
                _agent_type = AgentType(request.agent)
                is_builtin = True
            except ValueError:
                # Not a built-in agent, use string name
                is_builtin = False

            logger.info(
                f"Executing {'built-in' if is_builtin else 'plug-in'} agent "
                f"'{request.agent}' for stage '{request.stage_name}' "
                f"(iteration {request.iteration}/{request.max_iterations})"
            )

            # Resolve agent and instantiate
            agent = self._resolve_agent(request.agent)

            # Prepare input based on input_type
            prepared_input = self._prepare_input(request.input_type, request.content)

            # Extract changed_files from prepared input if available
            changed_files = prepared_input.get("files_changed", [])

            # Execute agent with BaseAgent interface
            # Convert timeout from seconds to milliseconds
            timeout_ms = request.timeout_s * 1000

            # Use stage_name as item_id for tracking
            item_id = f"{request.stage_name}_{request.iteration}"

            agent_result = agent.analyze(
                item_id=item_id,
                changed_files=changed_files if changed_files else None,
                timeout_ms=timeout_ms,
            )

            # Parse result for verdict and issues
            # AgentResult has .issues attribute (list[AgentIssue])
            # Convert AgentIssue objects to dicts for protocol
            issues_list = []
            if hasattr(agent_result, "issues") and agent_result.issues:
                issues_list = [issue.to_dict() for issue in agent_result.issues]

            verdict = "sound" if not issues_list else "issues"

            duration_s = time.time() - start_time

            # Log stage complete
            self._log_stage_event(
                "stage_complete",
                stage_name=request.stage_name,
                verdict=verdict,
                issue_count=len(issues_list),
                duration_s=duration_s,
            )

            return PipelineStageResult(
                stage_name=request.stage_name,
                verdict=verdict,
                issues=issues_list,
                iteration=request.iteration,
                duration_s=duration_s,
            )

        except Exception as e:
            duration_s = time.time() - start_time
            logger.exception(f"Stage execution failed: {e}")

            # Log stage error
            self._log_stage_event(
                "stage_error",
                stage_name=request.stage_name,
                error=str(e),
            )

            # Re-raise to let orchestrator handle escalation
            raise

    def _resolve_agent(self, agent_name: str) -> BaseAgent:
        """Resolve agent by name via AgentRegistry.

        Attempts to resolve agent_name by:
        1. First trying built-in agents via AgentType lookup
        2. Then falling back to AgentRegistry for plug-in agents (future)

        Args:
            agent_name: Agent name or ID (e.g., "sense_check", "compliance-agent")

        Returns:
            BaseAgent instance ready for execution

        Raises:
            ValueError: If agent_name not found in registry
        """
        registry = get_registry()

        # Try to resolve as built-in agent via AgentType
        try:
            agent_type = AgentType(agent_name)
            logger.debug(f"Resolved '{agent_name}' as built-in agent: {agent_type}")

            # Use create_agent which handles lazy loading
            agent = registry.create_agent(
                agent_type,
                working_dir=self._working_dir,
                llm_config=self._llm_config,
                log_event=self._log_event,
            )

            if agent is None:
                msg = (
                    f"Failed to create agent '{agent_name}'. "
                    f"Available agents: {[a.value for a in AgentType]}"
                )
                raise ValueError(msg)

            logger.info(f"Resolved built-in agent '{agent_name}' to {agent.__class__.__name__}")
            return agent

        except ValueError as e:
            # Not a built-in agent, treat as plug-in ID
            logger.debug(f"'{agent_name}' is not a built-in agent, checking plug-in registry")

            # Note: Current AgentRegistry only supports AgentType enum agents
            # Plug-in agent support would require registry enhancements
            agent_class = registry.get_agent_by_name(agent_name)

            if agent_class is None:
                msg = (
                    f"Agent '{agent_name}' not found in registry. "
                    f"Available built-in agents: {[a.value for a in AgentType]}"
                )
                raise ValueError(msg) from e

            # Instantiate agent with working_dir and llm_config
            agent = agent_class(
                working_dir=self._working_dir,
                llm_config=self._llm_config,
            )

            logger.info(f"Resolved plug-in agent '{agent_name}' to {agent_class.__name__}")
            return agent

    def _prepare_input(self, input_type: str, content: dict[str, Any]) -> dict[str, Any]:
        """Prepare input for agent based on input_type.

        Transforms the raw content dict into the structure expected by the agent
        for the given input_type.

        Args:
            input_type: Type of input content
            content: Raw content from server

        Returns:
            Prepared input dict for agent.analyze()

        Raises:
            ValueError: If input_type is unknown
        """
        if input_type == "intent_document":
            return {
                "objective": content.get("objective"),
                "context": content.get("context"),
            }

        if input_type == "derived_plan":
            return {
                "plan_items": content.get("plan_items", []),
                "metadata": content.get("metadata", {}),
            }

        if input_type == "plan_step":
            return {
                "step_id": content.get("step_id"),
                "step_definition": content.get("definition"),
            }

        if input_type == "step_result":
            return {
                "step_id": content.get("step_id"),
                "result": content.get("result"),
                "files_changed": content.get("files_changed", []),
            }

        if input_type == "implementation":
            return {
                "files_changed": content.get("files_changed", []),
                "diffs": content.get("diffs", {}),
            }

        if input_type == "review_reports":
            return {
                "agent_reports": content.get("agent_reports", []),
            }

        msg = f"Unknown input_type: {input_type}"
        raise ValueError(msg)

    def _log_stage_event(self, event_type: str, **kwargs: Any) -> None:
        """Log stage event via callback if configured.

        Args:
            event_type: Event type (stage_start, stage_complete, stage_error)
            **kwargs: Event-specific data
        """
        if self._log_event is None:
            return

        event_data = {
            "event": event_type,
            **kwargs,
        }

        try:
            self._log_event(**event_data)
        except Exception as e:
            logger.warning(f"Failed to log stage event: {e}")
