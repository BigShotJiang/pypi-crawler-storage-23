"""Intake flow for detecting and routing UserPlan input.

This module provides the intake flow that detects whether input is structured
(valid YAML/JSON with UserPlan fields) or unstructured (plain text intent),
and routes accordingly:

- Structured input: Passes through unchanged as UserPlan
- Unstructured input: Routes to IntentToUserPlanGenerator for first-pass generation

Detection Heuristics:
    - Structured: Valid YAML/JSON with required UserPlan fields (id, steps, source)
    - Unstructured: Plain text without recognizable structure

Storage Integration (S1.T6):
    Generated UserPlans are persisted to server storage BEFORE derivation.
    Storage is performed via a UserPlanStorageProtocol implementation.

Example:
    >>> from obra.execution.intake import UserPlanIntake
    >>> intake = UserPlanIntake(storage=state_manager)
    >>> userplan = await intake.process("Add user authentication with JWT")
    >>> assert userplan.source.generated is True  # Generated from intent
    >>> # UserPlan is now persisted to server storage

Related:
    - obra/execution/intent_to_userplan.py (IntentToUserPlanGenerator)
    - obra/schemas/userplan_schema.py (UserPlan schema)
    - obra/intent/detection.py (input type detection patterns)
    - functions/src/state/cloud_functions_state_manager.py (storage implementation)
"""

import json
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

import yaml

from obra.execution.userplan_cache import write_userplan_cache, write_userplan_mapping
from obra.execution.userplan_metrics import emit_userplan_source_metric
from obra.schemas.userplan_schema import (
    SourceType,
    UserPlan,
)

if TYPE_CHECKING:
    from obra.llm.invoker import LLMInvoker


@runtime_checkable
class UserPlanStorageProtocol(Protocol):
    """Protocol for UserPlan storage operations.

    Implementations must provide create_userplan and get_userplan methods.
    The CloudFunctionsStateManager satisfies this protocol.

    Example:
        >>> class MyStorage:
        ...     def create_userplan(self, userplan_id, project_id, source, steps, **kwargs):
        ...         # Store to database
        ...         return {"id": userplan_id, ...}
        ...     def get_userplan(self, plan_id):
        ...         # Retrieve from database
        ...         return {...} or None
    """

    def create_userplan(
        self,
        userplan_id: str,
        project_id: str,
        source: dict[str, Any],
        steps: list[dict[str, Any]],
        session_id: str | None = None,
        status: str = "draft",
        quality_score: float | None = None,
        quality_status: str = "not_assessed",
        work_type: str | None = None,
        context: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new UserPlan in storage."""
        ...

    def get_userplan(self, plan_id: str) -> dict[str, Any] | None:
        """Get a UserPlan by ID from storage."""
        ...


logger = logging.getLogger(__name__)

# Fields that indicate a valid UserPlan structure
USERPLAN_REQUIRED_FIELDS = {"id", "steps", "project_id"}
USERPLAN_OPTIONAL_INDICATOR_FIELDS = {
    "source",
    "version",
    "status",
    "created_at",
    "updated_at",
}

# Minimum fields to consider input as structured UserPlan
USERPLAN_MIN_FIELDS_FOR_DETECTION = 2  # At least 2 of the required/indicator fields


@dataclass
class IntakeResult:
    """Result from intake processing.

    Attributes:
        userplan: The resulting UserPlan (either passed through or generated)
        was_generated: True if UserPlan was generated from unstructured input
        input_type: Classification of the input ('structured' or 'unstructured')
        raw_input: Original input string
        stored: True if UserPlan was persisted to storage (S1.T6)
        storage_error: Error message if storage failed, None if successful
    """

    userplan: UserPlan
    was_generated: bool
    input_type: str
    raw_input: str
    stored: bool = False
    storage_error: str | None = None


class UserPlanIntake:
    """Intake handler for UserPlan input detection and routing.

    Detects whether input is structured (valid UserPlan YAML/JSON) or
    unstructured (plain text intent), and routes accordingly.

    Storage Integration (S1.T6):
        When a storage instance is provided, generated UserPlans are persisted
        to server storage BEFORE the derivation step. This ensures UserPlans
        exist in storage before any derive calls.

    Example:
        >>> intake = UserPlanIntake(llm_invoker=invoker, storage=state_manager)
        >>> result = await intake.process(
        ...     input_text="Add user authentication",
        ...     project_id="my-project"
        ... )
        >>> if result.was_generated:
        ...     print("Generated from intent")
        >>> if result.stored:
        ...     print(f"UserPlan {result.userplan.id} stored successfully")
        >>> print(result.userplan.steps[0].title)

    Thread-safety:
        Thread-safe through IntentToUserPlanGenerator's thread safety guarantees.
    """

    # Type alias for progress callback function
    # Signature: on_progress(action: str, payload: dict) -> None
    ProgressCallback = Callable[[str, dict], None]

    def __init__(
        self,
        llm_invoker: "LLMInvoker | None" = None,
        thinking_enabled: bool = True,
        reasoning_level: str = "high",
        provider: str = "anthropic",
        storage: UserPlanStorageProtocol | None = None,
        on_progress: "UserPlanIntake.ProgressCallback | None" = None,
        log_event: Any | None = None,
    ) -> None:
        """Initialize UserPlanIntake.

        Args:
            llm_invoker: LLMInvoker instance for LLM calls (required for generation)
            thinking_enabled: Whether to use extended thinking for generation
            reasoning_level: Reasoning level for LLM calls
            provider: LLM provider to use
            storage: Optional storage implementation for persisting UserPlans.
                    When provided, generated UserPlans are stored before derivation.
                    Must implement UserPlanStorageProtocol (e.g., CloudFunctionsStateManager).
            on_progress: Optional callback for progress events (S1.T7 two-step feedback).
                        Receives (action, payload) where action is "phase_started" or
                        "phase_completed" and payload contains phase-specific data.
            log_event: Optional event logger callback for metrics emission.
        """
        self._llm_invoker = llm_invoker
        self._thinking_enabled = thinking_enabled
        self._reasoning_level = reasoning_level
        self._provider = provider
        self._storage = storage
        self._on_progress = on_progress
        self._log_event = log_event

        # Lazy import to avoid circular dependency
        self._generator = None

        logger.debug(
            "UserPlanIntake initialized (storage=%s)",
            "enabled" if storage else "disabled",
        )

    def _emit_progress(self, action: str, payload: dict[str, Any]) -> None:
        """Emit progress event if callback is registered.

        S1.T7: Support two-step generation feedback via progress callback.

        Args:
            action: Event type (e.g., "phase_started", "phase_completed")
            payload: Event-specific data
        """
        if self._on_progress is not None:
            try:
                self._on_progress(action, payload)
            except Exception:
                # Don't let progress callback failures break intake flow
                logger.debug("Progress callback failed", exc_info=True)

    def _get_generator(self):
        """Get or create IntentToUserPlanGenerator instance."""
        if self._generator is None:
            from obra.execution.intent_to_userplan import IntentToUserPlanGenerator

            self._generator = IntentToUserPlanGenerator(
                llm_invoker=self._llm_invoker,
                thinking_enabled=self._thinking_enabled,
                reasoning_level=self._reasoning_level,
                provider=self._provider,
            )
        return self._generator

    async def process(
        self,
        input_text: str,
        project_id: str = "default",
        session_id: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> IntakeResult:
        """Process input and return UserPlan.

        Detects input type and either parses structured UserPlan or generates
        from unstructured intent. Generated UserPlans are persisted to storage
        (if configured) BEFORE returning, ensuring they exist before derivation.

        Storage Flow (S1.T6):
            1. Detect input type (structured vs unstructured)
            2. For unstructured: generate UserPlan via LLM
            3. Persist generated UserPlan to storage (before derivation)
            4. Return IntakeResult with stored=True on success

        Args:
            input_text: Input string (YAML/JSON UserPlan or plain text intent)
            project_id: Project identifier for generated UserPlans
            session_id: Optional session identifier
            context: Optional context dictionary for generation

        Returns:
            IntakeResult with UserPlan and metadata.
            - stored=True if UserPlan was successfully persisted
            - storage_error contains error message if persistence failed

        Raises:
            ValueError: If structured input is invalid UserPlan
        """
        if not input_text or not input_text.strip():
            msg = "Input cannot be empty"
            raise ValueError(msg)

        input_text = input_text.strip()

        # Detect input type
        input_type = self.detect_input_type(input_text)
        logger.info("Detected input type: %s", input_type)

        if input_type == "structured":
            # Parse and validate structured UserPlan
            raw_data = self._try_parse_structured(input_text) or {}
            userplan = self._parse_structured_userplan(input_text)
            logger.info("Parsed structured UserPlan: %s", userplan.id)

            # Emit source type metric for structured input
            emit_userplan_source_metric(
                source_type=userplan.source.type,
                userplan_id=userplan.id,
                project_id=userplan.project_id,
                is_generated=userplan.source.generated,
                log_event=self._log_event,
            )

            source_metadata = {
                "type": userplan.source.type.value,
                "path": userplan.source.path,
            }
            if isinstance(raw_data, dict):
                source_metadata["steps"] = raw_data.get("steps", [])
                if "id" in raw_data:
                    source_metadata["id"] = raw_data.get("id")

            logger.info("Writing local cache for UserPlan %s", userplan.id)
            cache_ok, cache_error = write_userplan_cache(userplan, userplan.project_id)
            mapping_ok, mapping_error = write_userplan_mapping(
                userplan, userplan.project_id, source_metadata
            )
            if not cache_ok:
                logger.warning("UserPlan cache write failed: %s", cache_error)
            if not mapping_ok:
                logger.warning("UserPlan mapping write failed: %s", mapping_error)

            return IntakeResult(
                userplan=userplan,
                was_generated=False,
                input_type="structured",
                raw_input=input_text,
                stored=False,  # Structured input is not auto-stored
            )

        # Generate UserPlan from unstructured intent
        # S1.T7: Emit USERPLAN_GENERATION phase_started event
        generation_start_time = time.time()
        self._emit_progress("phase_started", {"phase": "USERPLAN_GENERATION"})

        logger.info("Generating UserPlan from unstructured intent")
        generator = self._get_generator()
        userplan = await generator.generate(
            intent=input_text,
            context=context,
            project_id=project_id,
            session_id=session_id,
        )

        # S1.T7: Emit USERPLAN_GENERATION phase_completed event
        generation_duration_ms = int((time.time() - generation_start_time) * 1000)
        # Extract title from metadata (set by IntentToUserPlanGenerator)
        userplan_title = (
            userplan.metadata.get("title", "UserPlan") if userplan.metadata else "UserPlan"
        )
        self._emit_progress(
            "phase_completed",
            {
                "phase": "USERPLAN_GENERATION",
                "result": {"title": userplan_title},
                "duration_ms": generation_duration_ms,
            },
        )

        logger.info(
            "Generated UserPlan: %s with %d steps",
            userplan.id,
            len(userplan.steps),
        )

        # Emit source type metric for generated UserPlan
        emit_userplan_source_metric(
            source_type=userplan.source.type,
            userplan_id=userplan.id,
            project_id=userplan.project_id,
            is_generated=userplan.source.generated,
            log_event=self._log_event,
        )

        source_metadata = {
            "type": userplan.source.type.value,
            "path": userplan.source.path,
            "raw_objective": userplan.source.raw_objective,
        }
        logger.info("Writing local cache for UserPlan %s", userplan.id)
        cache_ok, cache_error = write_userplan_cache(userplan, userplan.project_id)
        mapping_ok, mapping_error = write_userplan_mapping(
            userplan, userplan.project_id, source_metadata
        )
        if not cache_ok:
            logger.warning("UserPlan cache write failed: %s", cache_error)
        if not mapping_ok:
            logger.warning("UserPlan mapping write failed: %s", mapping_error)

        # S1.T6: Persist generated UserPlan to storage BEFORE derivation
        stored = False
        storage_error: str | None = None

        if self._storage is not None:
            stored, storage_error = self._store_userplan(userplan)

        return IntakeResult(
            userplan=userplan,
            was_generated=True,
            input_type="unstructured",
            raw_input=input_text,
            stored=stored,
            storage_error=storage_error,
        )

    def _store_userplan(self, userplan: UserPlan) -> tuple[bool, str | None]:
        """Persist UserPlan to storage.

        S1.T6: Stores the generated UserPlan to server storage before derivation.

        Args:
            userplan: UserPlan to persist

        Returns:
            Tuple of (success: bool, error_message: str | None)
        """
        if self._storage is None:
            return False, "Storage not configured"

        try:
            # Convert UserPlan to storage format
            source_dict = {
                "type": userplan.source.type.value,
                "path": userplan.source.path,
                "raw_objective": userplan.source.raw_objective,
                "generated": userplan.source.generated,
                "generated_at": (
                    userplan.source.generated_at.isoformat()
                    if userplan.source.generated_at
                    else None
                ),
            }

            steps_list = [
                {
                    "id": step.id,
                    "index": step.index,
                    "title": step.title,
                    "description": step.description,
                    "raw_text": step.raw_text,
                    "derivation_status": step.derivation_status.value,
                    "context": step.context.model_dump() if step.context else None,
                    "inherited_keys": step.inherited_keys,
                    "inherited_context": step.inherited_context,
                }
                for step in userplan.steps
            ]

            context_dict = userplan.context.model_dump() if userplan.context else None

            # Call storage API
            self._storage.create_userplan(
                userplan_id=userplan.id,
                project_id=userplan.project_id,
                source=source_dict,
                steps=steps_list,
                session_id=userplan.session_id,
                status=userplan.status.value,
                quality_score=userplan.quality_score,
                quality_status=userplan.quality_status.value,
                work_type=userplan.work_type.value if userplan.work_type else None,
                context=context_dict,
                metadata=userplan.metadata,
            )

            logger.info(
                "Stored UserPlan %s to server storage (project=%s)",
                userplan.id,
                userplan.project_id,
            )
        except Exception as exc:
            error_msg = f"Failed to store UserPlan: {exc}"
            logger.exception(error_msg)
            return False, error_msg
        else:
            return True, None

    def detect_input_type(self, input_text: str) -> str:
        """Detect whether input is structured or unstructured.

        Detection heuristics:
        - Structured: Valid YAML/JSON with required UserPlan fields
        - Unstructured: Plain text without recognizable structure

        Args:
            input_text: Input string to classify

        Returns:
            'structured' if valid UserPlan YAML/JSON, 'unstructured' otherwise
        """
        # Try to parse as YAML/JSON
        data = self._try_parse_structured(input_text)
        if data is None:
            return "unstructured"

        # Check if data has UserPlan-like structure
        if self._is_userplan_structure(data):
            return "structured"

        return "unstructured"

    def _try_parse_structured(self, input_text: str) -> dict[str, Any] | None:
        """Try to parse input as YAML or JSON.

        Args:
            input_text: Input string to parse

        Returns:
            Parsed dictionary or None if parsing fails
        """
        # Try JSON first (stricter)
        if input_text.lstrip().startswith("{"):
            try:
                data = json.loads(input_text.strip())
                if isinstance(data, dict):
                    return data
            except json.JSONDecodeError:
                pass

        # Try YAML
        try:
            data = yaml.safe_load(input_text)
            if isinstance(data, dict):
                return data
        except yaml.YAMLError:
            pass

        return None

    def _is_userplan_structure(self, data: dict[str, Any]) -> bool:
        """Check if data has UserPlan-like structure.

        Args:
            data: Parsed dictionary to check

        Returns:
            True if data has enough UserPlan fields to be considered structured
        """
        # Count how many UserPlan fields are present
        all_indicator_fields = USERPLAN_REQUIRED_FIELDS | USERPLAN_OPTIONAL_INDICATOR_FIELDS
        present_fields = set(data.keys()) & all_indicator_fields

        # Need at least USERPLAN_MIN_FIELDS_FOR_DETECTION fields
        if len(present_fields) < USERPLAN_MIN_FIELDS_FOR_DETECTION:
            return False

        # Must have 'steps' field with a list
        if "steps" not in data:
            return False

        steps = data.get("steps")
        if not isinstance(steps, list):
            return False

        # Steps must have at least one item with title/description
        if not steps:
            return False

        first_step = steps[0]
        if not isinstance(first_step, dict):
            return False

        # Step should have at least title or description
        return "title" in first_step or "description" in first_step

    def _ensure_defaults(self, data: dict[str, Any]) -> None:
        """Ensure data has required default values in place.

        Mutates data in place to add missing required fields.
        """
        from datetime import UTC, datetime

        # Generate ID from first step title if missing
        if "id" not in data:
            first_step = data.get("steps", [{}])[0]
            title = first_step.get("title", "userplan")
            slug = UserPlan.slugify(title)
            data["id"] = UserPlan.generate_id(slug)

        if "project_id" not in data:
            data["project_id"] = "default"

        # Ensure source is present
        if "source" not in data:
            data["source"] = {
                "type": SourceType.STRUCTURED.value,
                "generated": False,
            }
        elif isinstance(data["source"], dict) and "type" not in data["source"]:
            data["source"]["type"] = SourceType.STRUCTURED.value

        # Ensure timestamps are present
        now = datetime.now(UTC).isoformat()
        if "created_at" not in data:
            data["created_at"] = now
        if "updated_at" not in data:
            data["updated_at"] = now

    def _process_step(self, step: dict[str, Any], index: int, userplan_id: str) -> dict[str, Any]:
        """Process a single step to ensure it has required fields.

        Args:
            step: Raw step data
            index: 1-based step index
            userplan_id: Parent UserPlan ID

        Returns:
            Processed step data with required fields
        """
        step_data = {
            "id": step.get("id", UserPlan.generate_step_id(userplan_id, index)),
            "index": step.get("index", index),
            "title": step.get("title", step.get("description", f"Step {index}")[:100]),
            "description": step.get("description", step.get("title", f"Step {index}")),
        }

        # Copy optional fields
        for field in ("derivation_status", "context", "raw_text"):
            if field in step:
                step_data[field] = step[field]

        return step_data

    def _parse_structured_userplan(self, input_text: str) -> UserPlan:
        """Parse and validate structured UserPlan input.

        Args:
            input_text: YAML/JSON string containing UserPlan

        Returns:
            Validated UserPlan object

        Raises:
            ValueError: If parsing or validation fails
        """
        data = self._try_parse_structured(input_text)
        if data is None:
            msg = "Failed to parse input as YAML or JSON"
            raise ValueError(msg)

        # Ensure required fields have defaults
        self._ensure_defaults(data)

        # Process steps to ensure valid IDs
        steps = data.get("steps", [])
        userplan_id = data["id"]
        processed_steps = [
            self._process_step(step, i, userplan_id)
            for i, step in enumerate(steps, start=1)
            if isinstance(step, dict)
        ]
        data["steps"] = processed_steps

        # Validate using Pydantic model
        try:
            return UserPlan.model_validate(data)
        except Exception as e:
            msg = f"Invalid UserPlan structure: {e}"
            raise ValueError(msg) from e


def create_userplan_from_plan_file(
    plan_context: dict[str, Any],
    project_id: str,
    plan_file_path: str | None = None,
    session_id: str | None = None,
    log_event: Any | None = None,
) -> UserPlan:
    """Create a UserPlan from plan file context (epics only).

    This function converts a plan file (YAML/JSON with epics) into a UserPlan
    for the S2.T3 requirement: plan-file import must create UserPlan before derivation.

    The plan file stories are mapped to UserPlan steps, preserving the original
    structure as much as possible for traceability.

    Args:
        plan_context: Dict with "epics" array from plan file
        project_id: Project identifier
        plan_file_path: Optional path to source plan file
        session_id: Optional session identifier
        log_event: Optional event logger callback for metrics emission

    Returns:
        UserPlan object ready for storage

    Raises:
        ValueError: If plan_context is invalid or has no epics

    Example:
        >>> plan_context = {"epics": [{"id": "E1", "title": "Auth", "stories": [...]}]}
        >>> userplan = create_userplan_from_plan_file(plan_context, "my-project")
        >>> userplan.source.type == SourceType.PLAN_FILE
        True
    """
    from datetime import UTC, datetime

    from obra.schemas.userplan_schema import (
        DerivationStatus,
        UserPlan,
        UserPlanSource,
        UserPlanStep,
        UserPlanStepContext,
    )

    stories = _extract_stories_from_plan_context(plan_context)
    if not stories:
        msg = "Plan file must contain a non-empty 'epics' array"
        raise ValueError(msg)

    # Generate UserPlan ID from first story title
    first_story = stories[0]
    first_title = first_story.get("title", first_story.get("desc", "plan-import"))
    slug = UserPlan.slugify(first_title)
    userplan_id = UserPlan.generate_id(slug)
    now = datetime.now(UTC).isoformat()

    # Build steps from stories
    steps: list[UserPlanStep] = []
    for i, story in enumerate(stories, start=1):
        if not isinstance(story, dict):
            continue

        story_title: str = str(story.get("title", story.get("desc", f"Story {i}")))
        story_description: str = str(story.get("description", story_title))

        # Extract tasks as deliverables (they will be used in derivation)
        tasks = story.get("tasks", [])
        deliverables = []
        if isinstance(tasks, list):
            for task in tasks:
                if isinstance(task, dict):
                    task_title = task.get("title", task.get("desc", ""))
                    if task_title:
                        deliverables.append(task_title)
                elif isinstance(task, str):
                    deliverables.append(task)

        # Build step context from story metadata
        # Convert verify list to string for success_criteria
        verify = story.get("verify", [])
        success_criteria_str: str | None = None
        if isinstance(verify, list) and verify:
            success_criteria_str = "; ".join(str(v) for v in verify)
        elif isinstance(verify, str):
            success_criteria_str = verify

        step_context = UserPlanStepContext(
            deliverables=deliverables,
            success_criteria=success_criteria_str,
            constraints=(
                story.get("constraints", []) if isinstance(story.get("constraints"), list) else []
            ),
        )

        step_id = UserPlan.generate_step_id(userplan_id, i)
        step = UserPlanStep(
            id=step_id,
            index=i,
            title=story_title,
            description=story_description,
            raw_text=json.dumps(story),  # Preserve original story data
            derivation_status=DerivationStatus.NOT_DERIVED,
            context=step_context,
        )
        steps.append(step)

    # Create source metadata
    source = UserPlanSource(
        type=SourceType.PLAN_FILE,
        path=plan_file_path,
        raw_objective=None,  # Plan files don't have a raw objective
        generated=False,  # User provided this via plan file
    )

    # Create the UserPlan
    userplan = UserPlan(
        id=userplan_id,
        project_id=project_id,
        session_id=session_id,
        version=1,
        created_at=now,
        updated_at=now,
        source=source,
        steps=steps,
        metadata={
            "plan_file_source": plan_file_path,
            "story_count": len(stories),
        },
    )

    # Emit source type metric for plan file UserPlan
    emit_userplan_source_metric(
        source_type=SourceType.PLAN_FILE,
        userplan_id=userplan_id,
        project_id=project_id,
        is_generated=False,  # Plan files are user-provided
        log_event=log_event,
    )

    return userplan


def _extract_stories_from_plan_context(
    plan_context: dict[str, Any],
) -> list[dict[str, Any]]:
    """Extract stories from a plan context with epics."""
    epics = plan_context.get("epics")
    if not isinstance(epics, list) or not epics:
        return []

    extracted: list[dict[str, Any]] = []
    for epic in epics:
        if not isinstance(epic, dict):
            continue
        epic_stories = epic.get("stories", [])
        if not isinstance(epic_stories, list):
            continue
        extracted.extend([story for story in epic_stories if isinstance(story, dict)])

    return extracted


def validate_objective(
    objective: str,
    min_words: int = 3,
    garbage_patterns: list[str] | None = None,
) -> tuple[bool, list[str]]:
    """Validate objective quality before creating UserPlan.

    Checks if objective is too vague or matches garbage patterns.
    This validation runs before LLM enrichment to fail fast on bad input.

    Args:
        objective: The raw objective string to validate
        min_words: Minimum number of words required (default: 3)
        garbage_patterns: List of patterns to reject (e.g., "do it", "help")

    Returns:
        Tuple of (is_valid, missing_elements):
        - is_valid: True if objective passes validation
        - missing_elements: List of issues found (empty if valid)

    Example:
        >>> is_valid, issues = validate_objective("do stuff")
        >>> is_valid
        False
        >>> "Matches garbage pattern" in issues[0]
        True
    """
    if garbage_patterns is None:
        garbage_patterns = ["do it", "do stuff", "help", "fix it", "make it work"]

    missing_elements: list[str] = []
    objective_lower = objective.lower().strip()
    words = objective.split()
    word_count = len(words)

    # Check minimum word count
    if word_count < min_words:
        missing_elements.append(
            f"Too short ({word_count} words, minimum {min_words}). "
            "Add more detail about what you want to accomplish."
        )

    # Check garbage patterns
    for pattern in garbage_patterns:
        if objective_lower == pattern.lower() or objective_lower.startswith(pattern.lower() + " "):
            missing_elements.append(
                f"Matches garbage pattern '{pattern}'. "
                "Please provide a specific, actionable objective."
            )
            break

    return len(missing_elements) == 0, missing_elements


def _load_intake_validation_config() -> tuple[bool, int, list[str]]:
    """Load intake validation config from layered config.

    Returns:
        Tuple of (enabled, min_words, garbage_patterns)
    """
    try:
        from obra.config.loaders import get_intake_config, load_layered_config

        cfg, _, _ = load_layered_config(include_defaults=True)
        intake_cfg = cfg.get("features", {}).get("intake", {}).get("validation", {})
        enabled = intake_cfg.get("enabled", True)

        # Use config getter for min_words (CHORE-CONFIG-DEFAULTS-001-E3 S2.T3)
        intake_config = get_intake_config()
        min_words = intake_config["min_words"]

        garbage_patterns = intake_cfg.get(
            "garbage_patterns", ["do it", "do stuff", "help", "fix it", "make it work"]
        )
        return enabled, min_words, garbage_patterns
    except Exception:
        # Default if config loading fails
        return True, 3, ["do it", "do stuff", "help", "fix it", "make it work"]


def create_userplan_from_objective(
    objective: str,
    project_id: str,
    session_id: str | None = None,
    log_event: Any | None = None,
) -> UserPlan:
    """Create a UserPlan from a free-form objective string.

    This function creates a minimal UserPlan from a raw objective for the
    requirement that all derivation flows must go through UserPlan.

    For free-form objectives (no plan file), we create a single-step UserPlan
    where the step represents the entire objective. The derivation process
    will then expand this into a proper execution plan.

    Args:
        objective: The raw objective/intent string from the user
        project_id: Project identifier
        session_id: Optional session identifier
        log_event: Optional event logger callback for metrics emission

    Returns:
        UserPlan object ready for storage

    Raises:
        ValueError: If objective is empty or whitespace-only

    Example:
        >>> userplan = create_userplan_from_objective(
        ...     "Add user authentication with JWT",
        ...     "my-project"
        ... )
        >>> userplan.source.type == SourceType.INTENT
        True
        >>> userplan.source.raw_objective == "Add user authentication with JWT"
        True
    """
    from datetime import UTC, datetime

    from obra.schemas.userplan_schema import (
        DerivationStatus,
        UserPlan,
        UserPlanSource,
        UserPlanStep,
        UserPlanStepContext,
    )

    if not objective or not objective.strip():
        msg = "Objective cannot be empty"
        raise ValueError(msg)

    objective = objective.strip()

    # Validate objective quality (ISSUE-HYBRID-004)
    # Reject garbage objectives before wasting LLM calls on enrichment
    from obra.exceptions import ObjectiveTooVagueError

    enabled, min_words, garbage_patterns = _load_intake_validation_config()
    if enabled:
        is_valid, missing_elements = validate_objective(
            objective, min_words=min_words, garbage_patterns=garbage_patterns
        )
        if not is_valid:
            raise ObjectiveTooVagueError(
                message=f"Objective is too vague: {missing_elements[0]}",
                objective=objective,
                word_count=len(objective.split()),
                min_words=min_words,
                missing_elements=missing_elements,
            )

    # Generate UserPlan ID from objective
    # Truncate long objectives for the slug
    slug_source = objective[:50] if len(objective) > 50 else objective
    slug = UserPlan.slugify(slug_source)
    userplan_id = UserPlan.generate_id(slug)
    now = datetime.now(UTC).isoformat()

    # Create a single step representing the entire objective
    # The derivation process will expand this into detailed steps
    step_id = UserPlan.generate_step_id(userplan_id, 1)
    step = UserPlanStep(
        id=step_id,
        index=1,
        title=objective[:100] if len(objective) > 100 else objective,
        description=objective,
        raw_text=objective,
        derivation_status=DerivationStatus.NOT_DERIVED,
        context=UserPlanStepContext(
            deliverables=[],
            success_criteria=None,
            constraints=[],
        ),
    )

    # Create source metadata indicating this is from raw intent
    source = UserPlanSource(
        type=SourceType.INTENT,
        path=None,
        raw_objective=objective,
        generated=True,  # Obra generated this UserPlan structure from raw objective
    )

    # Create the UserPlan
    userplan = UserPlan(
        id=userplan_id,
        project_id=project_id,
        session_id=session_id,
        version=1,
        created_at=now,
        updated_at=now,
        source=source,
        steps=[step],
        metadata={
            "source_type": "free_form_objective",
            "objective_length": len(objective),
        },
    )

    # Emit source type metric for intent-based UserPlan
    emit_userplan_source_metric(
        source_type=SourceType.INTENT,
        userplan_id=userplan_id,
        project_id=project_id,
        is_generated=True,  # Obra generated this UserPlan structure from raw objective
        log_event=log_event,
    )

    return userplan


__all__ = [
    "USERPLAN_OPTIONAL_INDICATOR_FIELDS",
    "USERPLAN_REQUIRED_FIELDS",
    "IntakeResult",
    "UserPlanIntake",
    "UserPlanStorageProtocol",
    "create_userplan_from_objective",
    "create_userplan_from_plan_file",
    "validate_objective",
]
