"""Story 0 state models for environment preparation and resume."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from pathlib import Path

import yaml  # type: ignore[import-untyped]
from pydantic import BaseModel, ConfigDict, Field, ValidationError

__all__ = [
    "Prerequisite",
    "PrerequisiteCategory",
    "PrerequisiteSource",
    "PrerequisiteStatus",
    "Story0State",
    "Story0Status",
    "load_story0_state",
]


class PrerequisiteCategory(str, Enum):
    """Category for Story 0 prerequisites."""

    AUTO = "AUTO"
    AUTO_CONFIRM = "AUTO_CONFIRM"
    CREDENTIAL = "CREDENTIAL"
    SERVICE = "SERVICE"
    USER_ACTION = "USER_ACTION"
    ACCOUNT = "ACCOUNT"
    LOCAL_CAPABILITY = "LOCAL_CAPABILITY"


class PrerequisiteSource(str, Enum):
    """Origin for a prerequisite (manifest-derived or inferred)."""

    MANIFEST = "MANIFEST"
    INFERRED = "INFERRED"


class PrerequisiteStatus(str, Enum):
    """Status for individual prerequisites."""

    PENDING = "pending"
    INSTALLED = "installed"
    MOCKED = "mocked"
    SKIPPED = "skipped"
    FAILED = "failed"


class Story0Status(str, Enum):
    """Status for Story 0 environment preparation."""

    PENDING = "pending"
    PARTIAL = "partial"
    COMPLETE = "complete"
    FAILED = "failed"


class Prerequisite(BaseModel):
    """Story 0 prerequisite entry."""

    id: str = Field(
        ...,
        min_length=1,
        description="Stable identifier for the prerequisite (e.g., package name or env var)",
    )
    category: PrerequisiteCategory = Field(
        ...,
        description="Automation category for handling",
    )
    name: str = Field(
        ...,
        min_length=1,
        description="Human-readable name",
    )
    source: PrerequisiteSource = Field(
        ...,
        description="Where the prerequisite was discovered",
    )
    reason: str = Field(
        ...,
        min_length=1,
        description="Why this prerequisite is required",
    )
    status: PrerequisiteStatus | None = Field(
        default=None,
        description="Current status",
    )
    mock_type: str | None = Field(
        default=None,
        description="Mocking method if applicable (stub, fixture, emulator)",
    )
    container_name: str | None = Field(
        default=None,
        description="Docker container name if a service was started",
    )
    port: int | None = Field(
        default=None,
        ge=1,
        le=65535,
        description="Service port if applicable",
    )

    ecosystem: str | None = Field(
        default=None,
        description="Package ecosystem (python, node, rust, go, ruby) for install resolution",
    )

    strategy: str | None = Field(
        default=None,
        description="Execution strategy: install, probe, service, manual",
    )
    automatable: bool | None = Field(
        default=None,
        description="Whether this can be executed without user interaction",
    )
    classification_trace: str | None = Field(
        default=None,
        description="Decision trace for strategy assignment",
    )

    model_config = ConfigDict(extra="forbid")


class Story0State(BaseModel):
    """Persisted Story 0 state used for resume and validation."""

    version: int = Field(
        default=1,
        ge=1,
        description="Schema version for future migrations",
    )
    status: Story0Status = Field(
        ...,
        description="State status (complete, partial, failed)",
    )
    reason: str | None = Field(
        default=None,
        description="Reason for failure or resume context",
    )
    completed_at: datetime | None = Field(
        default=None,
        description="Timestamp when Story 0 completed",
    )
    objective_hash: str = Field(
        ...,
        min_length=1,
        description="Hash of objective to detect changes",
    )
    manifest_hash: str | None = Field(
        default=None,
        description="Hash of dependency manifest to detect drift",
    )
    prerequisites: list[Prerequisite] = Field(
        default_factory=list,
        description="Prerequisites identified by Story 0",
    )
    containers: list[dict[str, str | int | bool | None]] = Field(
        default_factory=list,
        description="Docker containers started for services",
    )
    mocked_credentials: list[str] = Field(
        default_factory=list,
        description="Credential identifiers that were mocked",
    )
    automation_mode_effective: str | None = Field(
        default=None,
        description="Automation mode used after any fallbacks",
    )
    automation_mode_requested: str | None = Field(
        default=None,
        description="Automation mode requested by configuration",
    )
    env_setup_performed: bool = Field(
        default=False,
        description="Whether Story 0 performed environment setup (manifest generation)",
    )
    generated_manifest_type: str | None = Field(
        default=None,
        description="Primary generated manifest type (if single)",
    )
    generated_manifest_paths: list[str] = Field(
        default_factory=list,
        description="Relative paths to generated manifests",
    )
    installs_by_source: dict[str, list[str]] = Field(
        default_factory=lambda: {"manifest": list[str](), "inferred": list[str]()},
        description="Installed packages grouped by MANIFEST vs INFERRED",
    )
    verification_tools: dict[str, list[str] | str] = Field(
        default_factory=dict,
        description="Verification tools discovered/installed during Story 0",
    )
    dependency_manifest: dict | None = Field(
        default=None,
        description="Serialized DependencyManifest for session resume",
    )

    model_config = ConfigDict(extra="forbid")


def _migrate_story0_state(data: dict) -> dict:
    """Apply lightweight migrations to older Story 0 state payloads."""
    version = data.get("version", 1)
    if not isinstance(version, int):
        version = 1

    version = max(version, 1)

    if "version" not in data:
        data["version"] = version

    containers = data.get("containers")
    if isinstance(containers, list) and containers and isinstance(containers[0], str):
        data["containers"] = [{"name": name} for name in containers]

    data.setdefault("automation_mode_effective", None)
    data.setdefault("automation_mode_requested", None)
    data.setdefault("env_setup_performed", False)
    data.setdefault("generated_manifest_type", None)
    data.setdefault("generated_manifest_paths", [])
    data.setdefault("installs_by_source", {"manifest": [], "inferred": []})
    data.setdefault("verification_tools", {})
    data.setdefault("dependency_manifest", None)

    # Migrate legacy field names
    if "scaffolding_performed" in data:
        data["env_setup_performed"] = data.pop("scaffolding_performed")
    if "scaffolded_manifest_type" in data:
        data["generated_manifest_type"] = data.pop("scaffolded_manifest_type")
    if "scaffolded_manifest_paths" in data:
        data["generated_manifest_paths"] = data.pop("scaffolded_manifest_paths")

    # Migrate prerequisites: add strategy/automatable/classification_trace fields
    for prereq in data.get("prerequisites", []):
        if isinstance(prereq, dict):
            prereq.setdefault("strategy", None)
            prereq.setdefault("automatable", None)
            prereq.setdefault("classification_trace", None)

    return data


def load_story0_state(path: Path) -> Story0State:
    """Load Story 0 state from disk with graceful fallback on errors.

    Args:
        path: Path to .obra/story0_state.yaml

    Returns:
        Story0State instance (failed with reason=state_corrupted on errors).
    """
    try:
        raw = path.read_text(encoding="utf-8")
        if not raw.strip():
            msg = "Empty Story 0 state"
            raise ValueError(msg)
        data = yaml.safe_load(raw)
        if data is None:
            msg = "Empty Story 0 state"
            raise ValueError(msg)
        if not isinstance(data, dict):
            msg = "Invalid Story 0 state payload"
            raise ValueError(msg)
        migrated = _migrate_story0_state(data)
        return Story0State.model_validate(migrated)
    except (OSError, yaml.YAMLError, ValidationError, ValueError):
        return Story0State(
            status=Story0Status.FAILED,
            reason="state_corrupted",
            objective_hash="unknown",
        )
