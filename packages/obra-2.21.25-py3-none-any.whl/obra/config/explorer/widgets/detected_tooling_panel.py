"""Detected Tooling Panel widget for Config Explorer.

Shows detected project tooling: manifests, languages, and verification commands
with source badges and refresh capability.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Button, LoadingIndicator, Static

logger = logging.getLogger(__name__)


class DetectedToolingPanel(Static):
    """Panel showing detected project tooling from ToolingDiscovery cache.

    Displays:
    - Detected manifest files (pyproject.toml, package.json, etc.)
    - Primary and secondary languages
    - Verification tool commands with source badges (discovery vs config override)
    - Last discovery timestamp
    - Quick Scan (heuristic) and Deep Scan (LLM) buttons

    Handles graceful degradation for:
    - No working_dir (no project selected)
    - No llm_config (Deep Scan disabled)
    - No cache (not yet discovered)
    - Corrupted cache (error with retry)
    """

    DEFAULT_CSS = """
    DetectedToolingPanel {
        width: 100%;
        padding: 1;
        margin-bottom: 1;
    }

    DetectedToolingPanel .detected-panel {
        background: $surface;
        border: solid $primary-background;
        padding: 1;
        width: 100%;
        height: auto;
    }

    DetectedToolingPanel .panel-title {
        text-style: bold;
        margin-bottom: 1;
    }

    DetectedToolingPanel .no-project-warning {
        background: $warning-darken-3;
        color: $warning;
        padding: 1;
        width: 100%;
    }

    DetectedToolingPanel .manifest-list {
        margin-left: 2;
    }

    DetectedToolingPanel .tool-table {
        width: 100%;
        margin-top: 1;
    }

    DetectedToolingPanel .timestamp {
        color: $text-muted;
        margin-top: 1;
    }

    DetectedToolingPanel .error-message {
        color: $error;
        margin: 1 0;
    }

    DetectedToolingPanel .help-text {
        color: $text-muted;
        margin-top: 1;
    }

    DetectedToolingPanel .scan-buttons {
        margin-top: 1;
        height: auto;
    }

    DetectedToolingPanel .scan-buttons Button {
        margin-right: 1;
    }

    DetectedToolingPanel .loading-container {
        height: 3;
        margin: 1 0;
    }

    DetectedToolingPanel .status-text {
        color: $text-muted;
        text-style: italic;
        margin-top: 1;
    }

    DetectedToolingPanel .source-heuristic {
        color: $warning;
    }

    DetectedToolingPanel .source-llm {
        color: $success;
    }
    """

    def __init__(
        self,
        working_dir: Path | None,
        llm_config: dict[str, Any] | None = None,
        **kwargs,
    ) -> None:
        """Initialize the DetectedToolingPanel.

        Args:
            working_dir: Project working directory, or None for no-project state.
            llm_config: LLM configuration for ToolingDiscovery, or None.
        """
        super().__init__(**kwargs)
        self._working_dir = working_dir
        self._llm_config = llm_config or {}
        self._cache_data: dict[str, Any] | None = None
        self._discovery_in_progress = False
        self._discovery_type: str = ""  # "quick" or "deep"
        self._last_error: str | None = None

    def compose(self) -> ComposeResult:
        """Create the panel content."""
        with Vertical(classes="detected-panel"):
            yield Static("Detected Project Tooling", classes="panel-title")

            # No project selected state
            if self._working_dir is None:
                yield from self._compose_no_project()
                return

            # Load cache and render based on state
            self._cache_data = self._load_cache()

            if self._discovery_in_progress:
                yield from self._compose_loading()
            elif self._last_error:
                yield from self._compose_error()
            elif self._cache_data is None:
                yield from self._compose_no_cache()
            else:
                yield from self._compose_cached_data()

    def _compose_no_project(self) -> ComposeResult:
        """Compose no-project guidance (D5 from brief)."""
        yield Static(
            "No Project Selected\n\n"
            "Open Config Explorer from within a project directory to see detected "
            "tooling. Obra analyzes manifest files (pyproject.toml, package.json, etc.) "
            "to detect languages and verification tools.",
            classes="no-project-warning",
        )

    def _compose_loading(self) -> ComposeResult:
        """Compose loading state with indicator and status."""
        with Vertical(classes="loading-container"):
            yield LoadingIndicator()

        if self._discovery_type == "quick":
            yield Static("Scanning manifests...", classes="status-text")
        else:
            yield Static(
                "Analyzing project with LLM (this may take a moment)...",
                classes="status-text",
            )

    def _compose_no_cache(self) -> ComposeResult:
        """Compose not-yet-discovered state."""
        yield Static(
            "Tooling not yet discovered. Run a scan to analyze your project.",
            classes="help-text",
        )
        yield from self._compose_scan_buttons()

    def _compose_error(self) -> ComposeResult:
        """Compose error state with retry."""
        yield Static(f"Error: {self._last_error}", classes="error-message")
        yield Static("Try scanning again.", classes="help-text")
        yield from self._compose_scan_buttons()

    def _compose_cached_data(self) -> ComposeResult:
        """Compose panel with cached discovery data."""
        # Manifests section
        yield from self._render_manifests()

        # Languages section
        yield from self._render_languages()

        # Tools section
        yield from self._render_tools()

        # Scan buttons
        yield from self._compose_scan_buttons()

    def _compose_scan_buttons(self) -> ComposeResult:
        """Compose scan buttons with appropriate state."""
        # Source indicator from cache
        source = ""
        if self._cache_data:
            meta = self._cache_data.get("_meta", {})
            source = meta.get("source", "")

        with Horizontal(classes="scan-buttons"):
            # Quick Scan is always available when there's a working_dir
            yield Button(
                "Quick Scan",
                id="quick-scan",
                variant="default",
                disabled=self._discovery_in_progress,
            )

            # Deep Scan requires LLM config
            if self._llm_config:
                yield Button(
                    "Deep Scan (LLM)",
                    id="deep-scan",
                    variant="primary",
                    disabled=self._discovery_in_progress,
                )
            else:
                yield Button(
                    "Deep Scan (LLM)",
                    id="deep-scan",
                    variant="default",
                    disabled=True,
                )

        # Help text based on state
        if source == "heuristic":
            yield Static(
                "Quick Scan complete. Use Deep Scan for more accurate detection.",
                classes="help-text source-heuristic",
            )
        elif source == "llm":
            yield Static(
                "Deep Scan complete (LLM-powered).",
                classes="help-text source-llm",
            )
        elif not self._llm_config:
            yield Static(
                "Deep Scan disabled: Configure an LLM provider in Menu 3.",
                classes="help-text",
            )

    def _load_cache(self) -> dict[str, Any] | None:
        """Load tooling discovery cache without triggering discovery."""
        if self._working_dir is None:
            return None

        try:
            from obra.hybrid.tooling_discovery import ToolingDiscovery

            discovery = ToolingDiscovery(self._working_dir, self._llm_config)
            return discovery.load_cache()
        except Exception as exc:
            logger.warning("Failed to load tooling cache: %s", exc)
            self._last_error = str(exc)
            return None

    def _render_manifests(self) -> ComposeResult:
        """Render detected manifest files."""
        if not self._cache_data:
            return

        languages = self._cache_data.get("languages", {})
        primary = languages.get("primary", "")
        secondary = languages.get("secondary", [])

        # Build reverse mapping from language to manifest
        from obra.hybrid.tooling_discovery import ToolingDiscovery

        manifest_files = ToolingDiscovery.MANIFEST_FILES
        language_to_manifest: dict[str, list[str]] = {}
        for manifest, lang in manifest_files.items():
            language_to_manifest.setdefault(lang, []).append(manifest)

        # Collect manifests for detected languages
        manifests: list[str] = []
        all_langs = [primary] + (secondary if isinstance(secondary, list) else [])
        for lang in all_langs:
            if lang and lang.lower() in language_to_manifest:
                for manifest in language_to_manifest[lang.lower()]:
                    manifests.append(f"{manifest} ({lang})")

        if manifests:
            yield Static("Manifests:", classes="panel-title")
            manifest_text = "\n".join(f"  - {m}" for m in manifests)
            yield Static(manifest_text, classes="manifest-list")
        else:
            yield Static("No manifests detected", classes="help-text")

    def _render_languages(self) -> ComposeResult:
        """Render detected languages."""
        if not self._cache_data:
            return

        languages = self._cache_data.get("languages", {})
        primary = languages.get("primary", "")
        secondary = languages.get("secondary", [])

        if primary:
            lang_parts = [f"{primary} (primary)"]
            if secondary and isinstance(secondary, list):
                for lang in secondary:
                    if lang:
                        lang_parts.append(lang)
            yield Static(f"Languages: {', '.join(lang_parts)}")
        else:
            yield Static("Languages: Not detected", classes="help-text")

    def _render_tools(self) -> ComposeResult:
        """Render verification tools with source badges."""
        if not self._cache_data:
            return

        from obra.config.loaders import get_verification_tools_config

        verification = self._cache_data.get("verification", {})
        user_tools = get_verification_tools_config()

        yield Static("Verification Tools:", classes="panel-title")

        categories = ["test", "lint", "typecheck", "format"]
        tool_lines: list[str] = []

        for category in categories:
            cache_entry = verification.get(category, {})
            cache_cmd = cache_entry.get("command", "") if isinstance(cache_entry, dict) else ""

            user_entry = user_tools.get(category, {})
            user_cmd = user_entry.get("command", "") if isinstance(user_entry, dict) else ""

            # Determine source and display command
            if user_cmd and user_cmd != cache_cmd:
                display_cmd = user_cmd
                source = "\\[config]"  # Escaped for Rich markup
            elif cache_cmd:
                display_cmd = cache_cmd
                source = "\\[discovery]"  # Escaped for Rich markup
            else:
                display_cmd = "(not detected)"
                source = ""

            # Build line with source badge - use wider command width to ensure badge fits
            # Format: "  category   command                    [source]"
            if source:
                tool_lines.append(f"  {category:<10} {display_cmd:<25} {source}")
            else:
                tool_lines.append(f"  {category:<10} {display_cmd}")

        yield Static("\n".join(tool_lines), classes="tool-table")

        # Timestamp
        meta = self._cache_data.get("_meta", {})
        discovered_at = meta.get("discovered_at", "")
        if discovered_at:
            # Format timestamp nicely
            try:
                from datetime import datetime

                dt = datetime.fromisoformat(discovered_at.replace("Z", "+00:00"))
                formatted = dt.strftime("%Y-%m-%d %H:%M")
                yield Static(f"Last discovered: {formatted}", classes="timestamp")
            except (ValueError, AttributeError):
                yield Static(f"Last discovered: {discovered_at}", classes="timestamp")

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle scan button press."""
        if event.button.id not in ("quick-scan", "deep-scan"):
            return

        if self._discovery_in_progress:
            return

        self._discovery_in_progress = True
        self._discovery_type = "quick" if event.button.id == "quick-scan" else "deep"
        self._last_error = None

        # Recompose to show loading state
        self.refresh(recompose=True)

        # Run discovery in worker thread to avoid blocking UI
        if self._discovery_type == "quick":
            self.run_worker(self._run_quick_scan_worker, exclusive=True)
        else:
            self.run_worker(self._run_deep_scan_worker, exclusive=True)

    def _run_quick_scan_worker(self) -> dict[str, Any] | None:
        """Run fast heuristic discovery in background thread."""
        from obra.hybrid.tooling_discovery import ToolingDiscovery

        if self._working_dir is None:
            return None

        try:
            discovery = ToolingDiscovery(self._working_dir, self._llm_config)
            return discovery.discover_fast()
        except Exception as exc:
            logger.warning("Quick scan failed: %s", exc)
            self._last_error = str(exc)
            return None

    def _run_deep_scan_worker(self) -> dict[str, Any] | None:
        """Run LLM-powered discovery in background thread."""
        from obra.hybrid.tooling_discovery import ToolingDiscovery

        if self._working_dir is None:
            return None

        if not self._llm_config:
            self._last_error = "No LLM configured for deep scan"
            return None

        try:
            discovery = ToolingDiscovery(self._working_dir, self._llm_config)
            return discovery.discover(force_refresh=True)
        except Exception as exc:
            logger.warning("Deep scan failed: %s", exc)
            self._last_error = str(exc)
            return None

    def on_worker_state_changed(self, event: Any) -> None:
        """Handle worker completion."""
        from textual.worker import WorkerState

        if event.state == WorkerState.SUCCESS:
            self._cache_data = event.worker.result
            self._last_error = None
        elif event.state == WorkerState.ERROR:
            self._last_error = str(event.worker.error)

        if event.state in (
            WorkerState.SUCCESS,
            WorkerState.ERROR,
            WorkerState.CANCELLED,
        ):
            self._discovery_in_progress = False
            self._discovery_type = ""
            # Refresh the panel
            self.refresh(recompose=True)
