"""Specialized Agents View widget.

Provides an interface for enabling/disabling review agents
that provide specialized analysis during Obra sessions.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from textual.app import ComposeResult
from textual.containers import Horizontal, ScrollableContainer, Vertical
from textual.message import Message
from textual.widgets import Collapsible, Select, Static, Switch

from obra.config.explorer.llm_registry import (
    get_model_cost,
    get_model_default_reasoning,
    get_models,
    get_providers,
    resolve_tier_model_display,
    supports_thinking,
)
from obra.config.explorer.widgets.llm_custom_view import REASONING_LEVELS
from obra.config.explorer.widgets.navigation_menu import get_menu_info
from obra.config.explorer.widgets.saveable_view import SaveableViewMixin

LLM_FIELDS = ("provider", "model", "model_tier", "reasoning_level")

# SenseCheck Pipeline Stage definitions
# These run at different points in the pipeline, separate from the review-phase agent
SENSECHECK_PIPELINE_STAGES: list[dict[str, str]] = [
    {
        "id": "intent",
        "name": "Intent Validation",
        "description": "Validates objective before derivation to prevent overengineering",
        "config_path": "review.sense_check.pipeline.intent.enabled",
    },
    {
        "id": "plan",
        "name": "Plan Validation",
        "description": "Validates plan after derivation to simplify bloated plans",
        "config_path": "review.sense_check.pipeline.plan.enabled",
    },
    {
        "id": "review_filter",
        "name": "Review Filter",
        "description": "Filters review findings to remove false positives",
        "config_path": "review.sense_check.pipeline.review_filter.enabled",
    },
]

# Framework master toggle for pipeline
SENSECHECK_FRAMEWORK_PATH = "review.sense_check.pipeline.framework.enabled"


@dataclass
class AgentInfo:
    """Metadata for a specialized agent."""

    id: str
    name: str
    description: str
    trigger: str
    enabled_path: str
    llm_config_path: str | None
    llm_capable: bool


# Agent definitions with canonical config paths.
# IMPORTANT: Use canonical paths (features.quality_automation.agents.*)
# NOT shortcut paths (agents.*) which are semantic overlays.
AGENTS: list[AgentInfo] = [
    AgentInfo(
        id="rca_agent",
        name="RCA Agent",
        description="Root cause analysis for bugs and issues",
        trigger="Activated on bug/issue keywords in objective",
        enabled_path="features.quality_automation.agents.rca_agent.enabled",
        llm_config_path="features.quality_automation.agents.rca_agent.llm",
        llm_capable=True,
    ),
    AgentInfo(
        id="code_review",
        name="Code Review Agent",
        description="Architecture and quality review",
        trigger="Runs during review phase on modified files",
        enabled_path="features.quality_automation.agents.code_review.enabled",
        llm_config_path="features.quality_automation.agents.code_review.llm",
        llm_capable=True,
    ),
    AgentInfo(
        id="security_audit",
        name="Security Audit Agent",
        description="OWASP vulnerability scanning",
        trigger="Activated on security-related files (.py, .js, .ts)",
        enabled_path="features.quality_automation.agents.security_audit.enabled",
        llm_config_path="features.quality_automation.agents.security_audit.llm",
        llm_capable=True,
    ),
    AgentInfo(
        id="test_generation",
        name="Test Generation Agent",
        description="Intelligent test generation",
        trigger="Runs when new code is created without tests",
        enabled_path="features.quality_automation.agents.test_generation.enabled",
        llm_config_path="features.quality_automation.agents.test_generation.llm",
        llm_capable=True,
    ),
    AgentInfo(
        id="test_execution",
        name="Test Execution Agent",
        description="Run tests during review",
        trigger="Runs existing tests after code changes",
        enabled_path="features.quality_automation.agents.test_execution.enabled",
        llm_config_path="features.quality_automation.agents.test_execution.llm",
        llm_capable=True,
    ),
    AgentInfo(
        id="doc_audit",
        name="Doc Audit Agent",
        description="Documentation freshness checks",
        trigger="Activated on *.md files and doc directories",
        enabled_path="features.quality_automation.agents.doc_audit.enabled",
        llm_config_path="features.quality_automation.agents.doc_audit.llm",
        llm_capable=True,
    ),
    AgentInfo(
        id="sense_check",
        name="SenseCheck Agent",
        description="Semantic validation and root cause verification",
        trigger="Runs during review for complex fixes",
        enabled_path="features.quality_automation.agents.sense_check.enabled",
        llm_config_path="features.quality_automation.agents.sense_check.llm",
        llm_capable=True,
    ),
    AgentInfo(
        id="code_verify",
        name="CodeVerify Agent",
        description="Plan/code verification before execution",
        trigger="Runs post-derive and as Story Pre-flight for Story 2+",
        enabled_path="features.quality_automation.agents.code_verify.enabled",
        llm_config_path="features.quality_automation.agents.code_verify.llm",
        llm_capable=True,
    ),
]


class SpecializedAgentsView(SaveableViewMixin, Static):
    """Specialized agents configuration view.

    Shows a list of specialized review agents that can be enabled/disabled.
    Each agent has a toggle switch, description, and trigger condition.

    Emits:
        Changed: When an agent toggle state changes.
        LLMChanged: When an agent LLM setting changes.
    """

    DEFAULT_CSS = """
    SpecializedAgentsView {
        width: 100%;
        height: 100%;
        padding: 1 2;
    }

    SpecializedAgentsView > Vertical {
        width: 100%;
        height: 100%;
    }

    SpecializedAgentsView #content-scroll {
        width: 100%;
        height: 1fr;
        min-height: 10;
    }

    SpecializedAgentsView .header {
        text-style: bold;
        text-align: center;
        margin-bottom: 1;
        width: 100%;
    }

    SpecializedAgentsView .description {
        color: $text-muted;
        text-align: center;
        margin-bottom: 2;
        width: 100%;
    }

    SpecializedAgentsView .agent-row {
        width: 100%;
        height: auto;
        padding: 1;
        margin-bottom: 1;
        background: $surface;
        border: solid $primary-background;
    }

    SpecializedAgentsView .agent-row:focus-within {
        border: solid $primary;
    }

    SpecializedAgentsView .agent-info {
        width: 2fr;
        height: auto;
    }

    SpecializedAgentsView .agent-name {
        text-style: bold;
    }

    SpecializedAgentsView .agent-description {
        color: $text-muted;
    }

    SpecializedAgentsView .agent-trigger {
        color: $text-disabled;
        text-style: italic;
        margin-top: 1;
    }

    SpecializedAgentsView .agent-control {
        width: auto;
        height: auto;
        align: right middle;
        padding-right: 1;
    }

    SpecializedAgentsView .llm-section {
        width: 100%;
        height: auto;
        margin-top: 1;
    }

    SpecializedAgentsView .llm-fields {
        width: 100%;
        height: auto;
        padding: 0 1;
    }

    SpecializedAgentsView .llm-field-container {
        width: 100%;
        height: auto;
    }

    SpecializedAgentsView .llm-row {
        width: 100%;
        height: auto;
        margin-top: 1;
    }

    SpecializedAgentsView .llm-label {
        width: 16;
        text-style: bold;
    }

    SpecializedAgentsView .llm-select {
        width: 1fr;
    }

    SpecializedAgentsView .llm-hint {
        color: $text-muted;
        margin-left: 16;
        margin-bottom: 1;
    }

    SpecializedAgentsView .llm-na {
        color: $text-disabled;
        margin-top: 1;
        text-style: italic;
    }

    SpecializedAgentsView Switch {
        width: auto;
    }

    SpecializedAgentsView .help-text {
        color: $text-muted;
        margin-top: 2;
        text-align: center;
        width: 100%;
    }

    SpecializedAgentsView .pipeline-section {
        width: 100%;
        height: auto;
        margin-top: 1;
        padding: 1;
        background: $surface-darken-1;
    }

    SpecializedAgentsView .pipeline-header {
        text-style: bold;
        margin-bottom: 1;
    }

    SpecializedAgentsView .pipeline-stage-row {
        width: 100%;
        height: auto;
        margin-bottom: 1;
        align: left middle;
    }

    SpecializedAgentsView .pipeline-stage-label {
        width: 1fr;
    }
    """

    class Changed(Message):
        """Message emitted when an agent toggle changes."""

        def __init__(self, agent_id: str, config_path: str, enabled: bool) -> None:
            """Initialize the Changed message.

            Args:
                agent_id: ID of the agent that changed
                config_path: Canonical config path for the agent
                enabled: New enabled state
            """
            super().__init__()
            self.agent_id = agent_id
            self.config_path = config_path
            self.enabled = enabled

    class LLMChanged(Message):
        """Message emitted when an agent LLM setting changes."""

        def __init__(self, config_path: str, value: Any) -> None:
            super().__init__()
            self.config_path = config_path
            self.value = value

    def __init__(
        self,
        current_values: dict[str, Any] | None = None,
        implementation_provider: str = "anthropic",
        implementation_tiers: dict[str, str] | None = None,
        implementation_reasoning_level: str = "medium",
        review_tier: str = "high",
        **kwargs,
    ) -> None:
        """Initialize the SpecializedAgentsView.

        Args:
            current_values: Dict mapping canonical config paths to current values
            implementation_provider: Provider used by Review role's profile
            implementation_tiers: Tier model mapping for Review role's profile
            implementation_reasoning_level: Reasoning level for Review role's profile
            review_tier: The tier used by Review role (agents inherit this)
        """
        super().__init__(**kwargs)
        self._current_values: dict[str, Any] = current_values.copy() if current_values else {}
        self._implementation_provider = implementation_provider
        self._implementation_tiers = implementation_tiers or {
            "fast": "default",
            "medium": "default",
            "high": "default",
        }
        self._implementation_reasoning_level = implementation_reasoning_level
        self._review_tier = review_tier  # All agents inherit this tier from Review role

        # Normalize defaults for missing paths
        self._ensure_default_values()

        # Suppress change emissions during initial mount
        self._initializing = True
        # Take snapshot for dirty tracking
        self._snapshot_state()

    def on_mount(self) -> None:
        """Allow change emissions after mount completes."""
        from obra.config.explorer.debug import is_debug_enabled, log_action

        def finish_initialization() -> None:
            # Refresh hints before enabling change emissions
            self._refresh_llm_hints()
            self._initializing = False
            # Re-snapshot state AFTER all mount events are processed
            self._snapshot_state()
            if is_debug_enabled():
                log_action(
                    "SpecializedAgentsView.on_mount.finish_init",
                    f"_initializing={self._initializing}, snapshot taken",
                )

        self.call_after_refresh(finish_initialization)

    def compose(self) -> ComposeResult:
        """Create the view content."""
        menu_info = get_menu_info("agents")
        with Vertical():
            yield Static(menu_info["label"], classes="header")
            yield Static(menu_info["subtitle"], classes="description")

            # Scrollable container for agent rows
            with ScrollableContainer(id="content-scroll"):
                # Render each agent row
                for agent in AGENTS:
                    yield from self._compose_agent_row(agent)

            yield Static(
                "Changes are applied when you save. Use 's' to save.",
                classes="help-text",
            )

    def _compose_agent_row(self, agent: AgentInfo) -> ComposeResult:
        """Compose a single agent configuration row.

        Args:
            agent: Agent metadata
        """
        current_value = bool(self._current_values.get(agent.enabled_path, False))

        with Horizontal(classes="agent-row", id=f"agent-{agent.id}"):
            # Left: Agent info
            with Vertical(classes="agent-info"):
                yield Static(agent.name, classes="agent-name")
                yield Static(agent.description, classes="agent-description")
                yield Static(f"Triggers: {agent.trigger}", classes="agent-trigger")

                if agent.llm_capable and agent.llm_config_path:
                    yield from self._compose_llm_section(agent)
                else:
                    yield Static(
                        "LLM overrides are not available for this agent.",
                        classes="llm-na",
                    )

                # Add pipeline stages section for SenseCheck agent
                if agent.id == "sense_check":
                    yield from self._compose_pipeline_section()

            # Right: Toggle switch
            with Vertical(classes="agent-control"):
                yield Switch(
                    value=current_value,
                    id=f"switch-{agent.id}",
                )

    def _compose_llm_section(self, agent: AgentInfo) -> ComposeResult:
        """Compose the LLM configuration section for an agent."""
        llm_path = agent.llm_config_path
        if not llm_path:
            return

        provider_value = self._normalize_select_value(
            self._current_values.get(f"{llm_path}.provider", "inherit")
        )
        model_value = self._normalize_select_value(
            self._current_values.get(f"{llm_path}.model", "inherit")
        )
        tier_value = self._normalize_select_value(
            self._current_values.get(f"{llm_path}.model_tier", "inherit")
        )
        reasoning_value = self._normalize_select_value(
            self._current_values.get(f"{llm_path}.reasoning_level", "inherit")
        )

        effective_provider = (
            self._implementation_provider if provider_value == "inherit" else provider_value
        )
        model_options = self._build_model_options(effective_provider, include_inherit=True)
        model_values = {value for _label, value in model_options}
        if model_value not in model_values:
            model_value = "inherit"
            self._current_values[f"{llm_path}.model"] = model_value

        reasoning_options = self._build_reasoning_options(
            effective_provider,
            self._effective_model_for_reasoning(agent, provider_value, model_value, tier_value),
        )
        reasoning_values = {value for _label, value in reasoning_options}
        if reasoning_value not in reasoning_values:
            reasoning_value = "inherit"
            self._current_values[f"{llm_path}.reasoning_level"] = reasoning_value

        with Collapsible(title="LLM Configuration", classes="llm-section"):
            with Vertical(classes="llm-fields"):
                yield from self._compose_llm_field(
                    label="Provider",
                    select_id=f"provider-{agent.id}",
                    options=self._build_provider_options(include_inherit=True),
                    value=provider_value,
                    hint_id=f"provider-hint-{agent.id}",
                )
                yield from self._compose_llm_field(
                    label="Model",
                    select_id=f"model-{agent.id}",
                    options=model_options,
                    value=model_value,
                    hint_id=f"model-hint-{agent.id}",
                )
                yield from self._compose_llm_field(
                    label="Tier",
                    select_id=f"tier-{agent.id}",
                    options=self._build_tier_options(),
                    value=tier_value,
                    hint_id=f"tier-hint-{agent.id}",
                )
                yield from self._compose_llm_field(
                    label="Reasoning",
                    select_id=f"reasoning-{agent.id}",
                    options=reasoning_options,
                    value=reasoning_value,
                    hint_id=f"reasoning-hint-{agent.id}",
                )

    def _compose_pipeline_section(self) -> ComposeResult:
        """Compose the SenseCheck pipeline stages section.

        Shows toggles for intent, plan, and review_filter stages that
        run at different points in the pipeline, separate from the
        review-phase agent.
        """
        with Collapsible(
            title="Pipeline Stages (Pre/Post Processing)",
            classes="pipeline-section",
            collapsed=False,
        ):
            yield Static(
                "SenseCheck can also run at these pipeline stages:",
                classes="pipeline-header",
            )

            # Intent stage
            intent_value = bool(
                self._current_values.get("review.sense_check.pipeline.intent.enabled", False)
            )
            with Horizontal(classes="pipeline-stage-row"):
                yield Static(
                    "Intent Validation - Validates objective before derivation",
                    classes="pipeline-stage-label",
                )
                yield Switch(value=intent_value, id="pipeline-switch-intent")

            # Plan stage
            plan_value = bool(
                self._current_values.get("review.sense_check.pipeline.plan.enabled", False)
            )
            with Horizontal(classes="pipeline-stage-row"):
                yield Static(
                    "Plan Validation - Validates plan after derivation",
                    classes="pipeline-stage-label",
                )
                yield Switch(value=plan_value, id="pipeline-switch-plan")

            # Review filter stage
            filter_value = bool(
                self._current_values.get("review.sense_check.pipeline.review_filter.enabled", False)
            )
            with Horizontal(classes="pipeline-stage-row"):
                yield Static(
                    "Review Filter - Filters false positives from review",
                    classes="pipeline-stage-label",
                )
                yield Switch(value=filter_value, id="pipeline-switch-review_filter")

    def _compose_llm_field(
        self,
        label: str,
        select_id: str,
        options: list[tuple[str, str]],
        value: str,
        hint_id: str,
    ) -> ComposeResult:
        # Ensure value is valid - default to "inherit" if not in options
        valid_values = {opt_value for _label, opt_value in options}
        if value not in valid_values:
            value = (
                "inherit"
                if "inherit" in valid_values
                else (next(iter(valid_values)) if valid_values else Select.BLANK)
            )

        with Vertical(classes="llm-field-container"):
            with Horizontal(classes="llm-row"):
                yield Static(label, classes="llm-label")
                yield Select(
                    options=options,
                    value=value,
                    id=select_id,
                    allow_blank=False,
                    classes="llm-select",
                )
            yield Static("", id=hint_id, classes="llm-hint")

    def _build_provider_options(self, include_inherit: bool = False) -> list[tuple[str, str]]:
        options: list[tuple[str, str]] = []
        if include_inherit:
            options.append(("Inherit", "inherit"))
        for provider_id, display_name, _description in get_providers():
            options.append((display_name, provider_id))
        return options

    def _build_model_options(
        self,
        provider: str,
        include_inherit: bool = False,
    ) -> list[tuple[str, str]]:
        options: list[tuple[str, str]] = []
        if include_inherit:
            options.append(("Inherit", "inherit"))
        models = get_models().get(provider, get_models().get("anthropic", []))
        for model_id, display, _tier in models:
            cost = get_model_cost(provider, model_id)
            label = f"★  {display}" if model_id == "default" else f"{cost} {display}"
            options.append((label, model_id))
        return options

    def _build_tier_options(self) -> list[tuple[str, str]]:
        return [
            ("Inherit", "inherit"),
            ("Fast", "fast"),
            ("Medium", "medium"),
            ("High", "high"),
        ]

    def _build_reasoning_options(
        self,
        provider: str,
        model: str | None = None,
    ) -> list[tuple[str, str]]:
        """Build abstract reasoning level options for agent config.

        Agents use abstract levels (off/low/medium/high/maximum) that get
        resolved to provider-specific values by resolve_tier_config downstream.
        """
        if model is not None and model != "inherit" and not supports_thinking(provider, model):
            return [("N/A (no effect)", "inherit")]

        options: list[tuple[str, str]] = [("Inherit", "inherit")]
        for level in REASONING_LEVELS:
            if level == "maximum":
                label = "Max"
            else:
                label = level.capitalize()
            options.append((label, level))
        return options

    def _normalize_select_value(self, value: Any) -> str:
        # Handle Select.BLANK sentinel object
        if value is Select.BLANK:
            return "inherit"
        if value is None:
            return "inherit"
        if isinstance(value, str):
            normalized = value.strip()
            # Also handle string representation of Select.BLANK
            if not normalized or normalized == "Select.BLANK":
                return "inherit"
            return normalized
        return str(value)

    def _default_tier_for_agent(self, agent_id: str) -> str:
        """Get the default tier for an agent when set to 'inherit'.

        All agents inherit from the Review role's tier (Menu 3 → Review).
        """
        # All agents inherit from Review role's tier - no per-agent overrides
        return self._review_tier

    def _effective_model_for_reasoning(
        self,
        agent: AgentInfo,
        provider_value: str,
        model_value: str,
        tier_value: str,
    ) -> str:
        if model_value != "inherit":
            return model_value
        if provider_value == "inherit":
            return self._inherited_model_id(agent, tier_value)
        return "default"

    def _inherited_model_id(self, agent: AgentInfo, tier_value: str) -> str:
        tier = tier_value if tier_value != "inherit" else self._default_tier_for_agent(agent.id)
        return self._implementation_tiers.get(tier, "default")

    def _resolve_provider_display(self, provider_id: str) -> str:
        for pid, display_name, _desc in get_providers():
            if pid == provider_id:
                return display_name
        return provider_id

    def _refresh_llm_hints(self) -> None:
        for agent in AGENTS:
            if agent.llm_capable and agent.llm_config_path:
                self._update_llm_controls(agent)

    def _update_llm_controls(self, agent: AgentInfo) -> None:
        llm_path = agent.llm_config_path
        if not llm_path:
            return

        provider_value = self._normalize_select_value(
            self._current_values.get(f"{llm_path}.provider", "inherit")
        )
        model_value = self._normalize_select_value(
            self._current_values.get(f"{llm_path}.model", "inherit")
        )
        tier_value = self._normalize_select_value(
            self._current_values.get(f"{llm_path}.model_tier", "inherit")
        )
        reasoning_value = self._normalize_select_value(
            self._current_values.get(f"{llm_path}.reasoning_level", "inherit")
        )

        effective_provider = (
            self._implementation_provider if provider_value == "inherit" else provider_value
        )
        model_options = self._build_model_options(effective_provider, include_inherit=True)
        reasoning_options = self._build_reasoning_options(
            effective_provider,
            self._effective_model_for_reasoning(agent, provider_value, model_value, tier_value),
        )

        try:
            model_select = self.query_one(f"#model-{agent.id}", Select)
            model_select.set_options(model_options)
        except Exception:
            pass

        try:
            reasoning_select = self.query_one(f"#reasoning-{agent.id}", Select)
            reasoning_select.set_options(reasoning_options)
        except Exception:
            pass

        self._update_llm_hints(agent, tier_value)

        # Ensure reasoning stays valid
        reasoning_values = {value for _label, value in reasoning_options}
        if reasoning_value not in reasoning_values:
            self._set_llm_value(agent, "reasoning_level", "inherit")

        model_values = {value for _label, value in model_options}
        if model_value not in model_values:
            self._set_llm_value(agent, "model", "inherit")

    def _update_llm_hints(self, agent: AgentInfo, tier_value: str) -> None:
        if not agent.llm_config_path:
            return

        provider_hint = self._resolve_provider_display(self._implementation_provider)
        tier_hint = self._default_tier_for_agent(agent.id)
        inherited_model_id = self._inherited_model_id(agent, tier_value)
        model_hint = resolve_tier_model_display(
            self._implementation_provider,
            "implementation",
            tier_hint if tier_value == "inherit" else tier_value,
            inherited_model_id,
        )
        reasoning_hint = self._implementation_reasoning_level
        if reasoning_hint == "default":
            reasoning_hint = get_model_default_reasoning(
                self._implementation_provider,
                inherited_model_id,
                fallback_reasoning="default",
                role="implementation",
                tier=tier_hint if tier_value == "inherit" else tier_value,
            )

        self._set_hint_text(f"provider-hint-{agent.id}", f"Inherit: {provider_hint}")
        self._set_hint_text(f"tier-hint-{agent.id}", f"Inherit: {tier_hint.capitalize()}")
        self._set_hint_text(f"model-hint-{agent.id}", f"Inherit: {model_hint}")
        self._set_hint_text(
            f"reasoning-hint-{agent.id}",
            f"Inherit: {reasoning_hint.capitalize()}",
        )

    def _set_hint_text(self, hint_id: str, text: str) -> None:
        try:
            hint = self.query_one(f"#{hint_id}", Static)
            hint.update(text)
        except Exception:
            pass

    def _set_llm_value(self, agent: AgentInfo, field: str, value: str) -> None:
        if not agent.llm_config_path:
            return
        path = f"{agent.llm_config_path}.{field}"
        self._current_values[path] = value
        if not self._initializing:
            self.post_message(self.LLMChanged(config_path=path, value=value))

        select_id = f"{field.replace('model_tier', 'tier')}-{agent.id}"
        if field == "model_tier":
            select_id = f"tier-{agent.id}"
        elif field == "reasoning_level":
            select_id = f"reasoning-{agent.id}"
        elif field == "provider":
            select_id = f"provider-{agent.id}"
        elif field == "model":
            select_id = f"model-{agent.id}"

        try:
            select = self.query_one(f"#{select_id}", Select)
            select.value = value
        except Exception:
            pass

    def _ensure_default_values(self) -> None:
        for agent in AGENTS:
            if agent.enabled_path not in self._current_values:
                self._current_values[agent.enabled_path] = False
            if agent.llm_capable and agent.llm_config_path:
                for field in LLM_FIELDS:
                    path = f"{agent.llm_config_path}.{field}"
                    value = self._current_values.get(path)
                    # Ensure we have a valid value - treat None, empty string,
                    # and Select.BLANK as needing the default "inherit" value
                    if value is None or value == "" or value is Select.BLANK:
                        self._current_values[path] = "inherit"
                    elif isinstance(value, str) and value.strip() == "":
                        self._current_values[path] = "inherit"

        # Ensure SenseCheck pipeline stage defaults
        if SENSECHECK_FRAMEWORK_PATH not in self._current_values:
            self._current_values[SENSECHECK_FRAMEWORK_PATH] = True  # Enabled by default
        for stage in SENSECHECK_PIPELINE_STAGES:
            if stage["config_path"] not in self._current_values:
                # All stages enabled by default
                self._current_values[stage["config_path"]] = True

    def on_switch_changed(self, event: Switch.Changed) -> None:
        """Handle switch toggle changes."""
        if self._initializing:
            return

        switch_id = event.switch.id
        if not switch_id:
            return

        # Handle pipeline stage switches
        if switch_id.startswith("pipeline-switch-"):
            stage_id = switch_id.replace("pipeline-switch-", "")
            for stage in SENSECHECK_PIPELINE_STAGES:
                if stage["id"] == stage_id:
                    self._current_values[stage["config_path"]] = event.value
                    self.post_message(
                        self.Changed(
                            agent_id=f"pipeline_{stage_id}",
                            config_path=stage["config_path"],
                            enabled=event.value,
                        )
                    )
                    break
            return

        # Handle agent switches
        if not switch_id.startswith("switch-"):
            return

        agent_id = switch_id.replace("switch-", "")
        for agent in AGENTS:
            if agent.id == agent_id:
                self._current_values[agent.enabled_path] = event.value
                self.post_message(
                    self.Changed(
                        agent_id=agent_id,
                        config_path=agent.enabled_path,
                        enabled=event.value,
                    )
                )
                break

    def on_select_changed(self, event: Select.Changed) -> None:
        """Handle select widget changes."""
        if self._initializing:
            return

        select_id = event.select.id
        if not select_id:
            return

        # Handle Select.BLANK sentinel as "inherit" before string conversion
        value = "inherit" if event.value is Select.BLANK else str(event.value)

        if select_id.startswith("provider-"):
            agent_id = select_id.replace("provider-", "")
            self._handle_provider_change(agent_id, value)
        elif select_id.startswith("model-"):
            agent_id = select_id.replace("model-", "")
            self._handle_model_change(agent_id, value)
        elif select_id.startswith("tier-"):
            agent_id = select_id.replace("tier-", "")
            self._handle_tier_change(agent_id, value)
        elif select_id.startswith("reasoning-"):
            agent_id = select_id.replace("reasoning-", "")
            self._handle_reasoning_change(agent_id, value)

    def _handle_provider_change(self, agent_id: str, new_provider: str) -> None:
        agent = next((agent for agent in AGENTS if agent.id == agent_id), None)
        if not agent or not agent.llm_config_path:
            return

        provider_value = self._normalize_select_value(new_provider)
        provider_path = f"{agent.llm_config_path}.provider"
        self._current_values[provider_path] = provider_value
        self.post_message(self.LLMChanged(config_path=provider_path, value=provider_value))

        effective_provider = (
            self._implementation_provider if provider_value == "inherit" else provider_value
        )
        model_options = self._build_model_options(effective_provider, include_inherit=True)
        model_values = {value for _label, value in model_options}
        model_path = f"{agent.llm_config_path}.model"
        model_value = self._normalize_select_value(self._current_values.get(model_path, "inherit"))
        if model_value not in model_values:
            model_value = "inherit"
            self._current_values[model_path] = model_value
            self.post_message(self.LLMChanged(config_path=model_path, value=model_value))

        try:
            model_select = self.query_one(f"#model-{agent.id}", Select)
            model_select.set_options(model_options)
            model_select.value = model_value
        except Exception:
            pass

        self._update_reasoning_options(agent, provider_value, model_value)
        self._update_llm_hints(
            agent,
            self._normalize_select_value(
                self._current_values.get(f"{agent.llm_config_path}.model_tier", "inherit")
            ),
        )

    def _handle_model_change(self, agent_id: str, new_model: str) -> None:
        agent = next((agent for agent in AGENTS if agent.id == agent_id), None)
        if not agent or not agent.llm_config_path:
            return

        model_value = self._normalize_select_value(new_model)
        model_path = f"{agent.llm_config_path}.model"
        self._current_values[model_path] = model_value
        self.post_message(self.LLMChanged(config_path=model_path, value=model_value))

        provider_value = self._normalize_select_value(
            self._current_values.get(f"{agent.llm_config_path}.provider", "inherit")
        )

        self._update_reasoning_options(agent, provider_value, model_value)
        self._update_llm_hints(
            agent,
            self._normalize_select_value(
                self._current_values.get(f"{agent.llm_config_path}.model_tier", "inherit")
            ),
        )

    def _handle_tier_change(self, agent_id: str, new_tier: str) -> None:
        agent = next((agent for agent in AGENTS if agent.id == agent_id), None)
        if not agent or not agent.llm_config_path:
            return

        tier_value = self._normalize_select_value(new_tier)
        tier_path = f"{agent.llm_config_path}.model_tier"
        self._current_values[tier_path] = tier_value
        self.post_message(self.LLMChanged(config_path=tier_path, value=tier_value))

        provider_value = self._normalize_select_value(
            self._current_values.get(f"{agent.llm_config_path}.provider", "inherit")
        )
        model_value = self._normalize_select_value(
            self._current_values.get(f"{agent.llm_config_path}.model", "inherit")
        )
        self._update_reasoning_options(agent, provider_value, model_value, tier_value)
        self._update_llm_hints(agent, tier_value)

    def _handle_reasoning_change(self, agent_id: str, new_reasoning: str) -> None:
        agent = next((agent for agent in AGENTS if agent.id == agent_id), None)
        if not agent or not agent.llm_config_path:
            return

        reasoning_value = self._normalize_select_value(new_reasoning)
        reasoning_path = f"{agent.llm_config_path}.reasoning_level"
        self._current_values[reasoning_path] = reasoning_value
        self.post_message(self.LLMChanged(config_path=reasoning_path, value=reasoning_value))

    def _update_reasoning_options(
        self,
        agent: AgentInfo,
        provider_value: str,
        model_value: str,
        tier_value: str | None = None,
    ) -> None:
        effective_provider = (
            self._implementation_provider if provider_value == "inherit" else provider_value
        )
        effective_tier = tier_value or self._normalize_select_value(
            self._current_values.get(f"{agent.llm_config_path}.model_tier", "inherit")
        )
        effective_model = self._effective_model_for_reasoning(
            agent,
            provider_value,
            model_value,
            effective_tier,
        )
        reasoning_options = self._build_reasoning_options(effective_provider, effective_model)
        reasoning_values = {value for _label, value in reasoning_options}

        reasoning_path = f"{agent.llm_config_path}.reasoning_level"
        reasoning_value = self._normalize_select_value(
            self._current_values.get(reasoning_path, "inherit")
        )
        if reasoning_value not in reasoning_values:
            reasoning_value = "inherit"
            self._current_values[reasoning_path] = reasoning_value
            self.post_message(self.LLMChanged(config_path=reasoning_path, value=reasoning_value))

        try:
            reasoning_select = self.query_one(f"#reasoning-{agent.id}", Select)
            reasoning_select.set_options(reasoning_options)
            reasoning_select.value = reasoning_value
        except Exception:
            pass

    def get_current_values(self) -> dict[str, Any]:
        """Get all current agent values.

        Returns:
            Dict mapping canonical config paths to current values
        """
        return self._current_values.copy()

    def update_values(self, values: dict[str, Any]) -> None:
        """Update agent values from a config dict.

        Args:
            values: Dict mapping config paths to values
        """
        for key, value in values.items():
            self._current_values[key] = value

        for agent in AGENTS:
            if agent.enabled_path in self._current_values:
                try:
                    switch = self.query_one(f"#switch-{agent.id}", Switch)
                    switch.value = bool(self._current_values[agent.enabled_path])
                except Exception:
                    pass

            if agent.llm_capable and agent.llm_config_path:
                for field in LLM_FIELDS:
                    path = f"{agent.llm_config_path}.{field}"
                    if path in self._current_values:
                        select_id = None
                        if field == "provider":
                            select_id = f"provider-{agent.id}"
                        elif field == "model":
                            select_id = f"model-{agent.id}"
                        elif field == "model_tier":
                            select_id = f"tier-{agent.id}"
                        elif field == "reasoning_level":
                            select_id = f"reasoning-{agent.id}"
                        if select_id:
                            try:
                                select = self.query_one(f"#{select_id}", Select)
                                select.value = self._normalize_select_value(
                                    self._current_values[path]
                                )
                            except Exception:
                                pass
                self._update_llm_controls(agent)

        # Update SenseCheck pipeline stage switches
        for stage in SENSECHECK_PIPELINE_STAGES:
            if stage["config_path"] in self._current_values:
                try:
                    switch = self.query_one(f"#pipeline-switch-{stage['id']}", Switch)
                    switch.value = bool(self._current_values[stage["config_path"]])
                except Exception:
                    pass

    # --- SaveableViewMixin implementation ---

    def _get_saveable_state(self) -> dict[str, Any]:
        """Get current state for dirty tracking.

        Returns config paths mapped to current values.
        """
        return dict(self._current_values)

    def _restore_state(self, state: dict[str, Any]) -> None:
        """Restore state from snapshot and update UI."""
        self._current_values = {k: v for k, v in state.items()}
        for agent in AGENTS:
            if agent.enabled_path in self._current_values:
                try:
                    switch = self.query_one(f"#switch-{agent.id}", Switch)
                    switch.value = bool(self._current_values[agent.enabled_path])
                except Exception:
                    pass
            if agent.llm_capable and agent.llm_config_path:
                for field in LLM_FIELDS:
                    path = f"{agent.llm_config_path}.{field}"
                    if path in self._current_values:
                        select_id = None
                        if field == "provider":
                            select_id = f"provider-{agent.id}"
                        elif field == "model":
                            select_id = f"model-{agent.id}"
                        elif field == "model_tier":
                            select_id = f"tier-{agent.id}"
                        elif field == "reasoning_level":
                            select_id = f"reasoning-{agent.id}"
                        if select_id:
                            try:
                                select = self.query_one(f"#{select_id}", Select)
                                select.value = self._normalize_select_value(
                                    self._current_values[path]
                                )
                            except Exception:
                                pass
                self._update_llm_controls(agent)

        # Restore SenseCheck pipeline stage switches
        for stage in SENSECHECK_PIPELINE_STAGES:
            if stage["config_path"] in self._current_values:
                try:
                    switch = self.query_one(f"#pipeline-switch-{stage['id']}", Switch)
                    switch.value = bool(self._current_values[stage["config_path"]])
                except Exception:
                    pass
