# Muxwell

[![PyPI - Version](https://img.shields.io/pypi/v/muxwell)](https://pypi.org/project/muxwell/)
[![GitHub License](https://img.shields.io/github/license/mdaubie/muxwell)](https://github.com/mdaubie/muxwell/blob/HEAD/LICENSE)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/muxwell)](https://pypi.org/project/muxwell/)
[![codecov](https://codecov.io/gh/mdaubie/muxwell/graph/badge.svg)](https://codecov.io/gh/mdaubie/muxwell)
[![GitHub default check runs](https://img.shields.io/github/check-runs/mdaubie/muxwell/HEAD)](https://github.com/mdaubie/muxwell/actions/workflows/check.yml)
[![Release Status](https://img.shields.io/github/actions/workflow/status/mdaubie/muxwell/release.yml)](https://github.com/mdaubie/muxwell/actions/workflows/release.yml)

Muxwell is a command-line tool for managing MKV files and subtitles with batch operations support.

## Prerequisites

- Python 3.10 or higher
- [MKVToolNix](https://mkvtoolnix.download/)

## Installation

With pipx:

```bash
pipx install muxwell
```

With uv:

```bash
uv tool install muxwell
```
