"""Muxwell: A command-line tool for managing MKV files and subtitles with batch operations support."""

from __future__ import annotations

__version__ = "0.8.0"
__author__ = "Matthieu Daubie"
__email__ = "matthieu.daubie@outlook.com"
