"""Gnosis MCP -- Zero-config MCP server for searchable documentation."""

__version__ = "0.9.13"

__all__ = ["__version__"]
