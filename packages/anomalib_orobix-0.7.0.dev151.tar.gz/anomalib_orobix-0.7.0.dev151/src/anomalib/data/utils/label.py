from enum import Enum


class LabelName(int, Enum):
    """Name of label."""

    NORMAL = 0
    ABNORMAL = 1
