"""Anomalib CLI."""

# Copyright (C) 2022 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

from .cli import AnomalibCLI

__all__ = ["AnomalibCLI"]
