# Bloom Documentation

Welcome to the Bloom documentation! For basic setup, see the [main README](https://github.com/Ilm-Alan/bloom-cli#readme).

## Available Documentation

- **[ACP Setup](acp-setup.md)** - Setup instructions for using Bloom with various editors and IDEs that support the Agent Client Protocol.
