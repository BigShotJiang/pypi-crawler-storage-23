# What's New in Bloom 0.1.1

- **Welcome to Bloom** — Pollinations' open-source AI coding assistant, ready for your terminal.

- **New mascot** — Say hello to the animated bee in the banner.

- **Multi-model support** — Switch between models on the fly with /config.

- **Docs refresh** — README and ACP setup docs were updated for current Bloom CLI behavior.
