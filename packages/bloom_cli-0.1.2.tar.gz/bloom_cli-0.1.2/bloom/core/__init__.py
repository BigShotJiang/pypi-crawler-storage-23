from __future__ import annotations

__all__ = ["run_programmatic"]

from bloom.core.programmatic import run_programmatic
