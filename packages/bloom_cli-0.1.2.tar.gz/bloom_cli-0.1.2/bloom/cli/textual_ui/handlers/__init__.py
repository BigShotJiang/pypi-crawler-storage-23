from __future__ import annotations

from bloom.cli.textual_ui.handlers.event_handler import EventHandler

__all__ = ["EventHandler"]
