import json
from collections.abc import Callable
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

from prime_mcp.operations import (
    ChecklistItem,
    DocumentGovernanceModel,
    GuidelineItem,
    IncidentTypeItem,
    PurposeAndScopeModel,
)

COMPANY_GUIDELINES = Path(__file__).parent / "company_guidelines"

GUIDELINE_FILES = [
    "agent_behavior_and_autonomy_controls.json",
    "audit_logging_and_monitoring.json",
    "authentication_and_authorization.json",
    "data_protection_and_privacy.json",
    "input_validation_and_prompt_security.json",
    "mcp_supply_chain_and_third_party_risk.json",
    "mcp_transport_and_connection_security.json",
    "security_testing_requirements.json",
]


def _load_json(filename: str) -> dict[str, Any]:
    return json.loads((COMPANY_GUIDELINES / filename).read_text())


async def main():
    mcp = FastMCP("Prime-MCP")

    for filename in GUIDELINE_FILES:
        meta = _load_json(filename)
        tool_name = Path(filename).stem
        title = meta.get("title", tool_name)
        description = meta.get("description") or title

        def _make_tool(fn: str) -> Callable[[], list[GuidelineItem]]:
            def tool() -> list[GuidelineItem]:
                data = _load_json(fn)
                return [
                    GuidelineItem.model_validate(item) for item in data["guidelines"]
                ]

            return tool

        tool_fn = _make_tool(filename)
        tool_fn.__name__ = tool_name
        tool_fn.__doc__ = f"{title}\n\n{description}"
        mcp.tool(name=tool_name)(tool_fn)

    @mcp.tool()
    def incident_response() -> list[IncidentTypeItem]:
        """Incident Response for MCP & AI Agent Systems

        MCP-integrated agents introduce new incident categories that traditional runbooks
        may not cover. This section defines response procedures for agent-specific security events.
        """
        data = _load_json("incident_response.json")
        return [
            IncidentTypeItem.model_validate(item) for item in data["incident_types"]
        ]

    @mcp.tool()
    def developer_compliance_checklist() -> list[ChecklistItem]:
        """Developer Compliance Checklist

        Use this checklist before submitting any MCP-integrated feature for security review.
        All MUST items must be checked. SHOULD items require documented risk acceptance if skipped.
        """
        data = _load_json("developer_compliance_checklist.json")
        items: list[ChecklistItem] = []
        for category, entries in data["checklist"].items():
            items.extend(
                ChecklistItem(id=entry["id"], item=entry["item"], category=category)
                for entry in entries
            )
        return items

    @mcp.tool()
    def purpose_and_scope() -> PurposeAndScopeModel:
        """Purpose & Scope

        This document establishes mandatory security guidelines for the secure development,
        deployment, and operation of systems that integrate with the Model Context Protocol (MCP)
        and AI agent architectures. It provides developers with actionable controls, their security
        rationale, and traceability to recognized industry frameworks and standards.
        """
        data = _load_json("purpose_and_scope.json")
        return PurposeAndScopeModel.model_validate(data)

    @mcp.tool()
    def document_governance() -> DocumentGovernanceModel:
        """Document Governance"""
        data = _load_json("document_governance.json")
        return DocumentGovernanceModel.model_validate(data)

    await mcp.run_stdio_async()
