Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0)

Este software é disponibilizado sob a licença **CC BY-NC 4.0**, o que significa:

- Você **pode** usar, modificar e distribuir este software **apenas para fins não comerciais**, desde que forneça os devidos créditos.
- O uso para **fins comerciais** requer uma licença específica da Automate Brasil.
- Este software é fornecido "como está", sem garantias.

Para mais detalhes, consulte a licença completa: https://creativecommons.org/licenses/by-nc/4.0/
