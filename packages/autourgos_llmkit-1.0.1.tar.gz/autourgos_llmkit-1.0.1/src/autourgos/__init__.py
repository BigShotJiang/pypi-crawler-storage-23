"""
Autourgos - AI Engineering Toolkit
"""

__version__ = "1.0.1"
