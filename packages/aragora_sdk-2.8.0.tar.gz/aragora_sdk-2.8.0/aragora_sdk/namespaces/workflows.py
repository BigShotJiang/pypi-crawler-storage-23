"""
Workflows Namespace API

Provides methods for creating and executing automated workflows.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..client import AragoraAsyncClient, AragoraClient

_List = list  # Preserve builtin list for type annotations


class WorkflowsAPI:
    """
    Synchronous Workflows API.

    Example:
        >>> client = AragoraClient(base_url="https://api.aragora.ai")
        >>> execution = client.workflows.execute("workflow-123", {"input": "value"})
    """

    def __init__(self, client: AragoraClient):
        self._client = client

    def list(
        self,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """
        List all workflows.

        Args:
            limit: Maximum number of workflows to return
            offset: Number of workflows to skip

        Returns:
            List of workflows
        """
        return self._client.request(
            "GET",
            "/api/v1/workflows",
            params={"limit": limit, "offset": offset},
        )

    def get(self, workflow_id: str) -> dict[str, Any]:
        """
        Get a workflow by ID.

        Args:
            workflow_id: The workflow ID

        Returns:
            Workflow details
        """
        return self._client.request("GET", f"/api/v1/workflows/{workflow_id}")

    def create(
        self,
        name: str,
        steps: _List[dict[str, Any]],
        description: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Create a new workflow.

        Args:
            name: Workflow name
            steps: List of workflow steps
            description: Optional description
            **kwargs: Additional workflow options

        Returns:
            Created workflow
        """
        data = {"name": name, "steps": steps, **kwargs}
        if description:
            data["description"] = description

        return self._client.request("POST", "/api/v1/workflows", json=data)

    def update(
        self,
        workflow_id: str,
        **updates: Any,
    ) -> dict[str, Any]:
        """
        Update a workflow.

        Args:
            workflow_id: The workflow ID
            **updates: Fields to update

        Returns:
            Updated workflow
        """
        return self._client.request(
            "PUT",
            f"/api/v1/workflows/{workflow_id}",
            json=updates,
        )

    def delete(self, workflow_id: str) -> dict[str, Any]:
        """
        Delete a workflow.

        Args:
            workflow_id: The workflow ID

        Returns:
            Deletion result
        """
        return self._client.request("DELETE", f"/api/v1/workflows/{workflow_id}")

    def get_execution(self, execution_id: str) -> dict[str, Any]:
        """
        Get workflow execution status.

        Args:
            execution_id: The execution ID

        Returns:
            Execution details
        """
        return self._client.request("GET", f"/api/v1/workflow-executions/{execution_id}")

    def list_executions(
        self,
        workflow_id: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """
        List workflow executions.

        Args:
            workflow_id: Optional filter by workflow ID
            limit: Maximum number of executions to return
            offset: Number of executions to skip

        Returns:
            List of executions
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if workflow_id:
            params["workflow_id"] = workflow_id

        return self._client.request(
            "GET",
            "/api/v1/workflow-executions",
            params=params,
        )

    def cancel_execution(self, execution_id: str) -> dict[str, Any]:
        """
        Cancel a workflow execution.

        Args:
            execution_id: The execution ID

        Returns:
            Cancellation result
        """
        return self._client.request(
            "DELETE",
            f"/api/v1/workflow-executions/{execution_id}",
        )

    def list_templates(self) -> dict[str, Any]:
        """
        List available workflow templates.

        Returns:
            List of templates
        """
        return self._client.request("GET", "/api/v1/workflow-templates")

    def list_library_templates(self, **params: Any) -> dict[str, Any]:
        """List workflow library templates (/api/v1/workflow/templates)."""
        return self._client.request("GET", "/api/v1/workflow/templates", params=params)

    def get_library_template(self, template_id: str) -> dict[str, Any]:
        """Get a workflow library template."""
        return self._client.request("GET", f"/api/v1/workflow/templates/{template_id}")

    def get_library_package(self, template_id: str) -> dict[str, Any]:
        """Get a workflow library template package."""
        return self._client.request("GET", f"/api/v1/workflow/templates/{template_id}/package")

    def list_template_categories(self) -> dict[str, Any]:
        """List workflow template categories."""
        return self._client.request("GET", "/api/v1/workflow/categories")

    def list_template_patterns(self) -> dict[str, Any]:
        """List workflow template patterns."""
        return self._client.request("GET", "/api/v1/workflow/patterns")

    def list_pattern_templates(self) -> dict[str, Any]:
        """List workflow pattern templates."""
        return self._client.request("GET", "/api/v1/workflow/pattern-templates")

    def get_pattern_template(self, template_id: str) -> dict[str, Any]:
        """Get a workflow pattern template by ID."""
        return self._client.request("GET", f"/api/v1/workflow/pattern-templates/{template_id}")

    # =========================================================================
    # Workflows/Templates & Workflows/Executions (alternate paths)
    # =========================================================================

    def list_workflow_templates(self, **params: Any) -> dict[str, Any]:
        """
        List workflow templates via /workflows/templates path.

        GET /api/v1/workflows/templates

        Returns:
            List of workflow templates
        """
        return self._client.request("GET", "/api/v1/workflows/templates", params=params or None)

    def get_workflow_template(self, template_id: str) -> dict[str, Any]:
        """
        Get a workflow template by ID via /workflows/templates path.

        GET /api/v1/workflows/templates/:template_id

        Args:
            template_id: Template identifier

        Returns:
            Template details
        """
        return self._client.request("GET", f"/api/v1/workflows/templates/{template_id}")

    def list_workflow_executions(
        self,
        *,
        workflow_id: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """
        List workflow executions via /workflows/executions path.

        GET /api/v1/workflows/executions

        Args:
            workflow_id: Optional filter by workflow ID
            limit: Maximum executions to return
            offset: Pagination offset

        Returns:
            List of executions
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if workflow_id:
            params["workflow_id"] = workflow_id
        return self._client.request("GET", "/api/v1/workflows/executions", params=params)

    def get_workflow_execution(self, execution_id: str) -> dict[str, Any]:
        """
        Get a workflow execution by ID via /workflows/executions path.

        GET /api/v1/workflows/executions/:execution_id

        Args:
            execution_id: Execution identifier

        Returns:
            Execution details including status and steps
        """
        return self._client.request("GET", f"/api/v1/workflows/executions/{execution_id}")

    def execute(
        self,
        workflow_id: str,
        inputs: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Execute a workflow.

        Args:
            workflow_id: The workflow ID to execute.
            inputs: Optional dict of input parameters for the workflow.

        Returns:
            Execution result including execution_id and status.
        """
        body: dict[str, Any] = {}
        if inputs is not None:
            body["inputs"] = inputs
        return self._client.request(
            "POST", f"/api/v1/workflows/{workflow_id}/execute", json=body or None
        )

    def simulate(
        self,
        workflow_id: str,
        inputs: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Simulate a workflow without executing (dry-run).

        Returns an execution plan with validation results and estimated steps
        without actually running the workflow.

        Args:
            workflow_id: The workflow ID to simulate.
            inputs: Optional dict of input parameters for the simulation.

        Returns:
            Dict with validation results and execution plan including:
            - is_valid: Whether the workflow definition is valid
            - validation_errors: List of validation errors
            - execution_plan: Ordered list of steps that would execute
            - estimated_steps: Total number of steps
        """
        body: dict[str, Any] = {}
        if inputs is not None:
            body["inputs"] = inputs
        return self._client.request(
            "POST", f"/api/v1/workflows/{workflow_id}/simulate", json=body or None
        )

    def get_status(self, workflow_id: str) -> dict[str, Any]:
        """
        Get the execution status of a workflow.

        Returns the most recent execution status for the given workflow.

        Args:
            workflow_id: The workflow ID.

        Returns:
            Dict with execution status or a no_executions indicator.
        """
        return self._client.request("GET", f"/api/v1/workflows/{workflow_id}/status")

    def get_versions(self, workflow_id: str) -> dict[str, Any]:
        """
        Get workflow version history.

        Args:
            workflow_id: The workflow ID.

        Returns:
            Dict with version list and workflow_id.
        """
        return self._client.request("GET", f"/api/v1/workflows/{workflow_id}/versions")

    def restore_version(
        self,
        workflow_id: str,
        version: str | int,
    ) -> dict[str, Any]:
        """
        Restore a workflow to a specific previous version.

        Args:
            workflow_id: The workflow ID.
            version: The version identifier to restore.

        Returns:
            Dict with restored workflow data.
        """
        return self._client.request(
            "POST", f"/api/v1/workflows/{workflow_id}/versions/{version}/restore"
        )

    # =========================================================================
    # Approvals
    # =========================================================================

    def list_approvals(
        self,
        workflow_id: str | None = None,
        tenant_id: str | None = None,
    ) -> dict[str, Any]:
        """
        List pending workflow approval requests.

        Args:
            workflow_id: Optional filter by workflow ID.
            tenant_id: Optional tenant identifier.

        Returns:
            Dict with list of pending approvals and count.
        """
        params: dict[str, Any] = {}
        if workflow_id:
            params["workflow_id"] = workflow_id
        if tenant_id:
            params["tenant_id"] = tenant_id
        return self._client.request("GET", "/api/v1/workflow-approvals", params=params or None)

    def resolve_approval(
        self,
        request_id: str,
        status: str = "approved",
        notes: str = "",
        checklist: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Resolve a pending workflow approval request.

        Args:
            request_id: The approval request ID.
            status: Resolution status ('approved' or 'rejected').
            notes: Optional notes from the approver.
            checklist: Optional checklist updates.

        Returns:
            Dict with resolution result.
        """
        body: dict[str, Any] = {"status": status, "notes": notes}
        if checklist is not None:
            body["checklist"] = checklist
        return self._client.request(
            "POST", f"/api/v1/workflow-approvals/{request_id}/resolve", json=body
        )

    def run_template(self, template_id: str) -> dict[str, Any]:
        """Run a workflow template."""
        return self._client.request("POST", f"/api/v1/workflow/templates/{template_id}/run")

    # =========================================================================
    # Generation & Validation
    # =========================================================================

    def auto_layout(self, **kwargs: Any) -> dict[str, Any]:
        """
        Auto-layout a workflow graph for visualization.

        Args:
            **kwargs: Workflow nodes and edges to layout.

        Returns:
            Dict with positioned nodes and edges.
        """
        return self._client.request("POST", "/api/workflows/auto-layout", json=kwargs)

    def from_pattern(self, **kwargs: Any) -> dict[str, Any]:
        """
        Generate a workflow from a named pattern.

        Args:
            **kwargs: Pattern parameters (pattern_name, config, etc.)

        Returns:
            Dict with generated workflow definition.
        """
        return self._client.request("POST", "/api/workflows/from-pattern", json=kwargs)

    def generate(self, **kwargs: Any) -> dict[str, Any]:
        """
        Generate a workflow from a natural-language description.

        Args:
            **kwargs: Generation parameters (description, constraints, etc.)

        Returns:
            Dict with AI-generated workflow definition.
        """
        return self._client.request("POST", "/api/workflows/generate", json=kwargs)

    def list_step_types(self) -> dict[str, Any]:
        """
        List available workflow step types.

        Returns:
            Dict with step type definitions and their schemas.
        """
        return self._client.request("GET", "/api/workflows/step-types")

    def validate(self, **kwargs: Any) -> dict[str, Any]:
        """
        Validate a workflow definition before execution.

        Args:
            **kwargs: Workflow definition to validate.

        Returns:
            Dict with validation result (valid, errors, warnings).
        """
        return self._client.request("POST", "/api/workflows/validate", json=kwargs)

    def replay(self, workflow_id: str) -> dict[str, Any]:
        """
        Replay a completed workflow execution.

        Args:
            workflow_id: The workflow ID to replay.

        Returns:
            Dict with new execution details.
        """
        return self._client.request("POST", f"/api/workflows/{workflow_id}/replay")


class AsyncWorkflowsAPI:
    """
    Asynchronous Workflows API.

    Example:
        >>> async with AragoraAsyncClient(base_url="https://api.aragora.ai") as client:
        ...     execution = await client.workflows.execute("workflow-123", {"input": "value"})
    """

    def __init__(self, client: AragoraAsyncClient):
        self._client = client

    async def list(
        self,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List all workflows."""
        return await self._client.request(
            "GET",
            "/api/v1/workflows",
            params={"limit": limit, "offset": offset},
        )

    async def get(self, workflow_id: str) -> dict[str, Any]:
        """Get a workflow by ID."""
        return await self._client.request("GET", f"/api/v1/workflows/{workflow_id}")

    async def create(
        self,
        name: str,
        steps: _List[dict[str, Any]],
        description: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create a new workflow."""
        data = {"name": name, "steps": steps, **kwargs}
        if description:
            data["description"] = description

        return await self._client.request("POST", "/api/v1/workflows", json=data)

    async def update(
        self,
        workflow_id: str,
        **updates: Any,
    ) -> dict[str, Any]:
        """Update a workflow."""
        return await self._client.request(
            "PUT",
            f"/api/v1/workflows/{workflow_id}",
            json=updates,
        )

    async def delete(self, workflow_id: str) -> dict[str, Any]:
        """Delete a workflow."""
        return await self._client.request("DELETE", f"/api/v1/workflows/{workflow_id}")

    async def get_execution(self, execution_id: str) -> dict[str, Any]:
        """Get workflow execution status."""
        return await self._client.request("GET", f"/api/v1/workflow-executions/{execution_id}")

    async def list_executions(
        self,
        workflow_id: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List workflow executions."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if workflow_id:
            params["workflow_id"] = workflow_id

        return await self._client.request(
            "GET",
            "/api/v1/workflow-executions",
            params=params,
        )

    async def cancel_execution(self, execution_id: str) -> dict[str, Any]:
        """Cancel a workflow execution."""
        return await self._client.request(
            "DELETE",
            f"/api/v1/workflow-executions/{execution_id}",
        )

    async def list_templates(self) -> dict[str, Any]:
        """List available workflow templates."""
        return await self._client.request("GET", "/api/v1/workflow-templates")

    async def list_library_templates(self, **params: Any) -> dict[str, Any]:
        """List workflow library templates (/api/v1/workflow/templates)."""
        return await self._client.request("GET", "/api/v1/workflow/templates", params=params)

    async def get_library_template(self, template_id: str) -> dict[str, Any]:
        """Get a workflow library template."""
        return await self._client.request("GET", f"/api/v1/workflow/templates/{template_id}")

    async def get_library_package(self, template_id: str) -> dict[str, Any]:
        """Get a workflow library template package."""
        return await self._client.request(
            "GET", f"/api/v1/workflow/templates/{template_id}/package"
        )

    async def list_template_categories(self) -> dict[str, Any]:
        """List workflow template categories."""
        return await self._client.request("GET", "/api/v1/workflow/categories")

    async def list_template_patterns(self) -> dict[str, Any]:
        """List workflow template patterns."""
        return await self._client.request("GET", "/api/v1/workflow/patterns")

    async def list_pattern_templates(self) -> dict[str, Any]:
        """List workflow pattern templates."""
        return await self._client.request("GET", "/api/v1/workflow/pattern-templates")

    async def get_pattern_template(self, template_id: str) -> dict[str, Any]:
        """Get a workflow pattern template by ID."""
        return await self._client.request(
            "GET", f"/api/v1/workflow/pattern-templates/{template_id}"
        )

    # =========================================================================
    # Workflows/Templates & Workflows/Executions (alternate paths)
    # =========================================================================

    async def list_workflow_templates(self, **params: Any) -> dict[str, Any]:
        """List workflow templates. GET /api/v1/workflows/templates"""
        return await self._client.request(
            "GET", "/api/v1/workflows/templates", params=params or None
        )

    async def get_workflow_template(self, template_id: str) -> dict[str, Any]:
        """Get a workflow template by ID. GET /api/v1/workflows/templates/:template_id"""
        return await self._client.request("GET", f"/api/v1/workflows/templates/{template_id}")

    async def list_workflow_executions(
        self,
        *,
        workflow_id: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List workflow executions. GET /api/v1/workflows/executions"""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if workflow_id:
            params["workflow_id"] = workflow_id
        return await self._client.request("GET", "/api/v1/workflows/executions", params=params)

    async def get_workflow_execution(self, execution_id: str) -> dict[str, Any]:
        """Get a workflow execution. GET /api/v1/workflows/executions/:execution_id"""
        return await self._client.request("GET", f"/api/v1/workflows/executions/{execution_id}")

    async def execute(
        self,
        workflow_id: str,
        inputs: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute a workflow.

        Args:
            workflow_id: The workflow ID to execute.
            inputs: Optional dict of input parameters for the workflow.

        Returns:
            Execution result including execution_id and status.
        """
        body: dict[str, Any] = {}
        if inputs is not None:
            body["inputs"] = inputs
        return await self._client.request(
            "POST", f"/api/v1/workflows/{workflow_id}/execute", json=body or None
        )

    async def simulate(
        self,
        workflow_id: str,
        inputs: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Simulate a workflow without executing (dry-run).

        Args:
            workflow_id: The workflow ID to simulate.
            inputs: Optional dict of input parameters for the simulation.

        Returns:
            Dict with validation results and execution plan.
        """
        body: dict[str, Any] = {}
        if inputs is not None:
            body["inputs"] = inputs
        return await self._client.request(
            "POST", f"/api/v1/workflows/{workflow_id}/simulate", json=body or None
        )

    async def get_status(self, workflow_id: str) -> dict[str, Any]:
        """Get the execution status of a workflow.

        Args:
            workflow_id: The workflow ID.

        Returns:
            Dict with execution status or a no_executions indicator.
        """
        return await self._client.request("GET", f"/api/v1/workflows/{workflow_id}/status")

    async def get_versions(self, workflow_id: str) -> dict[str, Any]:
        """Get workflow version history.

        Args:
            workflow_id: The workflow ID.

        Returns:
            Dict with version list and workflow_id.
        """
        return await self._client.request("GET", f"/api/v1/workflows/{workflow_id}/versions")

    async def restore_version(
        self,
        workflow_id: str,
        version: str | int,
    ) -> dict[str, Any]:
        """Restore a workflow to a specific previous version.

        Args:
            workflow_id: The workflow ID.
            version: The version identifier to restore.

        Returns:
            Dict with restored workflow data.
        """
        return await self._client.request(
            "POST",
            f"/api/v1/workflows/{workflow_id}/versions/{version}/restore",
        )

    # =========================================================================
    # Approvals
    # =========================================================================

    async def list_approvals(
        self,
        workflow_id: str | None = None,
        tenant_id: str | None = None,
    ) -> dict[str, Any]:
        """List pending workflow approval requests.

        Args:
            workflow_id: Optional filter by workflow ID.
            tenant_id: Optional tenant identifier.

        Returns:
            Dict with list of pending approvals and count.
        """
        params: dict[str, Any] = {}
        if workflow_id:
            params["workflow_id"] = workflow_id
        if tenant_id:
            params["tenant_id"] = tenant_id
        return await self._client.request(
            "GET", "/api/v1/workflow-approvals", params=params or None
        )

    async def resolve_approval(
        self,
        request_id: str,
        status: str = "approved",
        notes: str = "",
        checklist: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Resolve a pending workflow approval request.

        Args:
            request_id: The approval request ID.
            status: Resolution status ('approved' or 'rejected').
            notes: Optional notes from the approver.
            checklist: Optional checklist updates.

        Returns:
            Dict with resolution result.
        """
        body: dict[str, Any] = {"status": status, "notes": notes}
        if checklist is not None:
            body["checklist"] = checklist
        return await self._client.request(
            "POST",
            f"/api/v1/workflow-approvals/{request_id}/resolve",
            json=body,
        )

    async def run_template(self, template_id: str) -> dict[str, Any]:
        """Run a workflow template."""
        return await self._client.request("POST", f"/api/v1/workflow/templates/{template_id}/run")

    # =========================================================================
    # Generation & Validation
    # =========================================================================

    async def auto_layout(self, **kwargs: Any) -> dict[str, Any]:
        """Auto-layout a workflow graph for visualization."""
        return await self._client.request("POST", "/api/workflows/auto-layout", json=kwargs)

    async def from_pattern(self, **kwargs: Any) -> dict[str, Any]:
        """Generate a workflow from a named pattern."""
        return await self._client.request("POST", "/api/workflows/from-pattern", json=kwargs)

    async def generate(self, **kwargs: Any) -> dict[str, Any]:
        """Generate a workflow from a natural-language description."""
        return await self._client.request("POST", "/api/workflows/generate", json=kwargs)

    async def list_step_types(self) -> dict[str, Any]:
        """List available workflow step types."""
        return await self._client.request("GET", "/api/workflows/step-types")

    async def validate(self, **kwargs: Any) -> dict[str, Any]:
        """Validate a workflow definition before execution."""
        return await self._client.request("POST", "/api/workflows/validate", json=kwargs)

    async def replay(self, workflow_id: str) -> dict[str, Any]:
        """Replay a completed workflow execution."""
        return await self._client.request("POST", f"/api/workflows/{workflow_id}/replay")
