"""Tests for SSO namespace API."""

from __future__ import annotations
