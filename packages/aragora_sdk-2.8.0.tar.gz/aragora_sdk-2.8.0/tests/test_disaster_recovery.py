"""Tests for Disaster Recovery namespace API."""

from __future__ import annotations
