"""Tests for Control Plane namespace API."""

from __future__ import annotations
