"""Tests for Notifications namespace API."""

from __future__ import annotations
