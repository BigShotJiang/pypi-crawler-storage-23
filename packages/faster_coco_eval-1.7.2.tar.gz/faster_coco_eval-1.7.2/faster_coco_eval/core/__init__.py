from .coco import COCO
from .faster_eval_api import COCOeval_faster

__all__ = ["COCO", "COCOeval_faster"]
