from jb_drf_auth.views.account_management import AccountUpdateView, delete_account
from jb_drf_auth.views.email_confirmation import (
    AccountConfirmEmailView,
    ResendConfirmationEmailView,
)
from jb_drf_auth.views.login import BasicLoginView, SwitchProfileView
from jb_drf_auth.views.me import MeView
from jb_drf_auth.views.otp import RequestOtpCodeView, VerifyOtpCodeView
from jb_drf_auth.views.password_reset import (
    PasswordChangeView,
    PasswordResetConfirmView,
    PasswordResetRequestView,
)
from jb_drf_auth.views.profile import ProfilePictureUpdateView, ProfileViewSet
from jb_drf_auth.views.register import RegisterView
from jb_drf_auth.views.social_auth import (
    SocialLinkView,
    SocialLoginView,
    SocialPrecheckView,
    SocialUnlinkView,
)
from jb_drf_auth.views.user_admin import CreateStaffUserView, CreateSuperUserView

__all__ = [
    "delete_account",
    "AccountUpdateView",
    "AccountConfirmEmailView",
    "ResendConfirmationEmailView",
    "BasicLoginView",
    "SwitchProfileView",
    "MeView",
    "RequestOtpCodeView",
    "VerifyOtpCodeView",
    "PasswordChangeView",
    "PasswordResetConfirmView",
    "PasswordResetRequestView",
    "ProfileViewSet",
    "ProfilePictureUpdateView",
    "RegisterView",
    "SocialLoginView",
    "SocialPrecheckView",
    "SocialLinkView",
    "SocialUnlinkView",
    "CreateStaffUserView",
    "CreateSuperUserView",
]
