from jb_drf_auth.providers.oidc import OidcSocialProvider


class AppleOidcProvider(OidcSocialProvider):
    pass
