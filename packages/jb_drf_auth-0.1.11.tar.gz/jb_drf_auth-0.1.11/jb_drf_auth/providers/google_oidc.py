from jb_drf_auth.providers.oidc import OidcSocialProvider


class GoogleOidcProvider(OidcSocialProvider):
    pass
