from pathlib import Path
from setuptools import setup, find_packages

base_dir = Path(__file__).resolve().parent
readme_path = base_dir / "README.md"

setup(
    name="geekerwan2026",
    version="0.1.1",
    description="极客湾手机大横评 2026",
    long_description=readme_path.read_text(encoding="utf-8"),
    long_description_content_type="text/markdown",
    packages=find_packages(include=["geekerwan2026", "geekerwan2026.*"]),
    install_requires=[
        "geekerwan2026-data1==0.1.1",
        "geekerwan2026-data2==0.1.1",
        "geekerwan2026-data3==0.1.1",
    ],
    python_requires=">=3.9",
)
