from importlib import resources

_DATA_PACKAGES = [
    "geekerwan2026_data1.data",
    "geekerwan2026_data2.data",
    "geekerwan2026_data3.data",
]


def list_data_packages():
    return list(_DATA_PACKAGES)


def missing_data_packages():
    missing = []
    for pkg in _DATA_PACKAGES:
        try:
            resources.files(pkg)
        except ModuleNotFoundError:
            missing.append(pkg)
    return missing


def shard_names():
    names = []
    for pkg in _DATA_PACKAGES:
        files = resources.files(pkg).iterdir()
        for f in files:
            if f.suffix == ".py" and f.name != "__init__.py":
                names.append(f.stem)
    return sorted(names)


def shard_count():
    return len(shard_names())


def has_shard(name: str) -> bool:
    for pkg in _DATA_PACKAGES:
        try:
            files = resources.files(pkg).iterdir()
        except ModuleNotFoundError:
            continue
        for f in files:
            if f.suffix == ".py" and f.stem == name:
                return True
    return False
