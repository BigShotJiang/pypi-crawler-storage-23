import base64
import hashlib
import importlib
from importlib import resources
from pathlib import Path

_KEY = hashlib.sha256(b"geekerwan2026").digest()
_DATA_PACKAGES = [
    "geekerwan2026_data1.data",
    "geekerwan2026_data2.data",
    "geekerwan2026_data3.data",
]


def _xor(data: bytes) -> bytes:
    key = _KEY
    klen = len(key)
    return bytes(b ^ key[i % klen] for i, b in enumerate(data))


def OutputGKWVideo(output_path=None):
    if output_path is None:
        output_path = Path.cwd() / "geekerwan2026.mp4"
    else:
        output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    missing = []
    shards = []
    for pkg in _DATA_PACKAGES:
        try:
            files = resources.files(pkg).iterdir()
        except ModuleNotFoundError:
            missing.append(pkg)
            continue
        for f in files:
            if f.suffix == ".py" and f.name != "__init__.py":
                shards.append((f.stem, pkg))

    if missing:
        raise RuntimeError(f"missing data packages: {', '.join(missing)}")
    if not shards:
        raise RuntimeError("no data shards found")

    shards.sort(key=lambda item: item[0])
    seen = set()
    for name, _ in shards:
        if name in seen:
            raise RuntimeError(f"duplicate shard: {name}")
        seen.add(name)

    with open(output_path, "wb") as out:
        for name, pkg in shards:
            mod = importlib.import_module(f"{pkg}.{name}")
            enc = base64.b85decode(mod.DATA)
            out.write(_xor(enc))

    return str(output_path)
