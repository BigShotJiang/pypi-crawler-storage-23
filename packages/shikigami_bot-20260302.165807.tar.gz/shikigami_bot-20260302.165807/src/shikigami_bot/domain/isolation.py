"""Content isolation result model — output of the isolation sub-agent.

The isolation sub-agent receives untrusted user input and returns only
a structured summary. Raw text never leaves the isolation boundary.
"""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class IsolatedContent(BaseModel):
    """Structured summary produced by the content isolation sub-agent.

    This is the ONLY representation of user input that downstream
    stages (relay, LLM) ever see. Raw user text never leaves the
    isolation boundary.
    """

    summary: str = Field(max_length=200, description="Factual paraphrase of user intent")
    intent: str = "other"
    language: str = "en"
    categories: list[str] = []
    contains_code: bool = False
    contains_url: bool = False
    sentiment: Literal["positive", "neutral", "negative"] = "neutral"
    safety_flags: list[str] = []
    original_length: int = 0
    raw_text: str = ""
