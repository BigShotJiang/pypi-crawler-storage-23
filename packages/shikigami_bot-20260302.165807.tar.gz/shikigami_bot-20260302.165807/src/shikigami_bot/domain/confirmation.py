"""Domain models for the confirmation system.

Confirmation requests are created when an agent action requires human approval.
The confirmation level determines how much verification is needed:
- ACKNOWLEDGE: simple "got it" confirmation
- APPROVE: explicit approval with reason displayed
- TWO_FACTOR: approval + TOTP verification for critical actions
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum


class ConfirmationLevel(Enum):
    """Level of confirmation required for an agent action.

    Higher levels require more user interaction to approve.
    """

    ACKNOWLEDGE = "acknowledge"
    APPROVE = "approve"
    TWO_FACTOR = "two_factor"


@dataclass(frozen=True)
class ConfirmationRequest:
    """A pending confirmation request from an agent to the operator.

    Attributes:
        request_id: Unique identifier (UUID).
        session_id: Claude CLI session for agent mapping.
        agent_name: Verified by the bot, not self-reported by the agent.
        action: Human-readable description of the action to be performed.
        reason: Why the agent wants to perform this action.
        level: How much verification is required.
        chat_id: Telegram chat of the user who must confirm.
        created_at: UTC timestamp of creation.
        timeout_seconds: Seconds before the request expires.
    """

    request_id: str
    session_id: str
    agent_name: str
    action: str
    reason: str
    level: ConfirmationLevel
    chat_id: str
    created_at: datetime
    timeout_seconds: int = 120


@dataclass(frozen=True)
class ConfirmationResult:
    """Outcome of a confirmation request.

    Attributes:
        request_id: The confirmation request this result belongs to.
        approved: Whether the user approved the action.
        verified_at: UTC timestamp of verification, None if not yet verified.
        totp_verified: Whether TOTP was verified (only for TWO_FACTOR level).
    """

    request_id: str
    approved: bool
    verified_at: datetime | None
    totp_verified: bool = False
