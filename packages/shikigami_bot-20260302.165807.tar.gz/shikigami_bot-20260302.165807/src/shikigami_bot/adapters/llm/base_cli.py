"""Base CLI adapter — shared subprocess logic for all CLI-based LLM backends.

Provides:
- Explicit env allowlist construction (parameterized per backend)
- Timeout with process group kill (SIGTERM → grace → SIGKILL)
- Error pattern matching framework

Subclasses implement:
- _build_command() / _build_command_streaming() — CLI-specific args
- _parse_output() — CLI-specific JSON parsing
- _build_system_prompt() — prompt construction
"""
from __future__ import annotations

import asyncio
import logging
import os
import signal
from typing import Final

logger = logging.getLogger(__name__)

# Grace period (seconds) between SIGTERM and SIGKILL on timeout.
_KILL_GRACE_SECONDS: Final[float] = 5.0


class BaseCLIAdapter:
    """Base class for CLI-subprocess-based LLM adapters.

    Handles:
    - Environment allowlist construction
    - Process lifecycle (spawn, timeout, kill)
    - Error pattern detection
    """

    def __init__(
        self,
        *,
        cli_path: str,
        timeout_seconds: int = 300,
        error_patterns: list[str] | None = None,
        env_vars: dict[str, str] | None = None,
    ) -> None:
        self._cli_path = cli_path
        self._timeout_seconds = timeout_seconds
        self._error_patterns: list[str] = error_patterns or []
        self._extra_env: dict[str, str] = env_vars or {}

    @property
    def timeout_seconds(self) -> int:
        return self._timeout_seconds

    def _build_env(self) -> dict[str, str]:
        """Build an explicit env allowlist. NEVER pass os.environ through.

        Always includes PATH and HOME. Subclasses add backend-specific keys
        via the env_vars constructor parameter.
        """
        env = {
            "PATH": os.environ.get("PATH", ""),
            "HOME": os.environ.get("HOME", ""),
        }
        env.update(self._extra_env)
        return env

    def _is_error_response(self, text: str) -> bool:
        """Detect known error patterns in backend output."""
        return any(pattern in text for pattern in self._error_patterns)

    @staticmethod
    async def _kill_process(proc: asyncio.subprocess.Process) -> None:
        """Kill a process group: SIGTERM, wait grace period, then SIGKILL."""
        try:
            pgid = os.getpgid(proc.pid)
            os.killpg(pgid, signal.SIGTERM)
        except (ProcessLookupError, OSError):
            return

        # Wait for graceful shutdown
        try:
            await asyncio.wait_for(proc.wait(), timeout=_KILL_GRACE_SECONDS)
        except asyncio.TimeoutError:
            try:
                pgid = os.getpgid(proc.pid)
                os.killpg(pgid, signal.SIGKILL)
            except (ProcessLookupError, OSError):
                pass
