"""
Category-aware retrieval reranker.

This module provides functionality to rerank retrieved chunks based on
category relevance to the user's query. Categories less relevant to the
query have their chunks penalized (higher distance).
"""

import math

from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from loguru import logger

# =============================================================================
# Constants
# These are tunables that should later be pwnd off to experiemnt planner
# For now since we have benchmark crunch they're hardcoded consts
# I think the values should be decent to start with
# =============================================================================
SOFTMAX_TEMPERATURE = 0.07  # Temperature for softmax probability calculation
CATEGORY_FACTOR_ALPHA = 0.8  # Alpha for category factor calculation
RETRIEVAL_MULTIPLIER = 10  # Retrieve top_k * 10 initially for reranking


class CategoryReranker:
    """
    Reranks chunks based on category relevance to query.

    Distance adjustment formula (small is good):
    - cat_factor = alpha + (1-alpha) * p(c) where p(c) is softmax probability
    - adjusted_distance = original_distance / cat_factor
    - Dividing by factor < 1 INCREASES distance for worse-matching categories
    Ideally we should use a bigger-better scoring so the math is cleaner, but oh well

    Example with alpha=0.8:
    - Best category (p=1.0): factor=1.0, distance unchanged
    - Worst category (p=0.0): factor=0.8, distance increased by 25%
    - Medium category (p=0.5): factor=0.9, distance increased by 11%
    """

    def __init__(self, embeddings: Embeddings):
        self.embeddings = embeddings

    async def rerank_by_category(
        self,
        query: str,
        chunks: list[Document],
        category_embeddings: dict[str, list[float]],
        original_top_k: int,
    ) -> list[Document]:
        """
        Rerank chunks by category relevance to the query.

        Algo:
        1. Get unique categories from chunks. NOT FROM THE ENTIRE DB. JUST THE RETRIEVED CHUNKS
        2. Compute query embedding
        3. Compute cosine similarity between query and each category embedding
        4. Apply softmax (temp tunable up top. Lower temp - higher spread between probs) to get probabilities
        5. Compute cat_factor = alpha + (1-alpha) * p(c) for each category
        6. Adjust distance: new_distance = distance / cat_factor
        7. Re-sort by adjusted distance (ascending)
        8. Return top original_top_k chunks

        Args:
            query: The user's query string.
            chunks: List of retrieved Document chunks.
            category_embeddings: Dict mapping category name to embedding vector.
            original_top_k: The original top-k value to return.

        Returns:
            List of reranked Document chunks (top original_top_k).
        """
        if not chunks or not category_embeddings:
            return chunks[:original_top_k]

        # Step 1: Get unique categories from chunks that have category embeddings
        chunk_categories = set()
        for chunk in chunks:
            category = chunk.metadata.get("source_document_category")
            if category and category in category_embeddings:
                chunk_categories.add(category)

        if not chunk_categories:
            logger.debug("No matching category embeddings found for retrieved chunks")
            return chunks[:original_top_k]

        # Step 2: Compute query embedding
        query_embedding = await self.embeddings.aembed_query(query)

        # Step 3: Compute cosine similarity between query and each category
        similarities: dict[str, float] = {}
        for category in chunk_categories:
            cat_embedding = category_embeddings[category]
            similarities[category] = self.cosine_similarity(
                query_embedding, cat_embedding
            )

        # Step 4: Apply softmax with temperature to get probabilities
        probabilities = self.softmax_with_temp(similarities, SOFTMAX_TEMPERATURE)

        # Step 5: Compute cat_factor for each category
        factor_by_category: dict[str, float] = {}
        for category, prob in probabilities.items():
            factor_by_category[category] = (
                CATEGORY_FACTOR_ALPHA + (1 - CATEGORY_FACTOR_ALPHA) * prob
            )

        logger.info(
            f"Category reranking - similarities: {similarities}, "
            f"probabilities: {probabilities}, factors: {factor_by_category}"
        )

        # Step 6: Adjust distance for each chunk using chunk's OWN category
        for chunk in chunks:
            category = chunk.metadata.get("source_document_category")
            # Default factor of 1.0 if category not found (no adjustment)
            factor = factor_by_category.get(category, 1.0)
            original_distance = chunk.metadata.get("DISTANCE", 1.0)
            # Divide by factor: smaller factor = larger adjusted distance (worse)
            chunk.metadata["DISTANCE"] = original_distance / factor
            chunk.metadata["_original_distance"] = original_distance
            chunk.metadata["_category_factor"] = factor
            logger.info(
                f"Chunk adjusted score: {chunk.metadata['DISTANCE']}, original score: {chunk.metadata['_original_distance']}"
            )
        # Step 7: Re-sort by adjusted distance (ascending - smaller is better)
        chunks.sort(key=lambda d: d.metadata.get("DISTANCE", 1.0))

        # Step 8: Return top original_top_k chunks
        return chunks[:original_top_k]

    @staticmethod
    def cosine_similarity(a: list[float], b: list[float]) -> float:
        """
        Compute cosine similarity between two vectors.

        Args:
            a: First vector.
            b: Second vector.

        Returns:
            Cosine similarity value between -1 and 1.
        """
        if len(a) != len(b):
            raise ValueError(f"Vector dimensions don't match: {len(a)} vs {len(b)}")

        dot_product = sum(x * y for x, y in zip(a, b))
        norm_a = math.sqrt(sum(x * x for x in a))
        norm_b = math.sqrt(sum(x * x for x in b))

        if norm_a == 0 or norm_b == 0:
            return 0.0

        return dot_product / (norm_a * norm_b)

    @staticmethod
    def softmax_with_temp(
        similarities: dict[str, float], temp: float = SOFTMAX_TEMPERATURE
    ) -> dict[str, float]:
        """
        Apply softmax with temperature to similarity scores.

        Args:
            similarities: Dict mapping category to similarity score.
            temp: Temperature parameter (lower = sharper distribution).

        Returns:
            Dict mapping category to probability (sums to 1.0).
        """
        if not similarities:
            return {}

        categories = list(similarities.keys())
        values = [similarities[c] / temp for c in categories]

        # Subtract max for numerical stability
        max_val = max(values)
        exp_vals = [math.exp(v - max_val) for v in values]
        total = sum(exp_vals)

        return {cat: exp_vals[i] / total for i, cat in enumerate(categories)}
