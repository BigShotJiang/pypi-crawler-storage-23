# chemlog-extra
Extension of ChemLog to a broad range of ChEBI classes 
