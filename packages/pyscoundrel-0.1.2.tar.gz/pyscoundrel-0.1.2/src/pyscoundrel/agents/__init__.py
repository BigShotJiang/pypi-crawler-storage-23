"""Agents for automated PyScoundrel gameplay."""

from .base import Agent

__all__ = ["Agent"]
