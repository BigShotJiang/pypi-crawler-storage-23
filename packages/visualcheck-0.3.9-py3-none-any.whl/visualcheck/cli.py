from __future__ import annotations

import json
import webbrowser
from pathlib import Path
from typing import Optional

import typer
import yaml
from rich.console import Console
from rich.table import Table

from .config import load_config
from .figma import figma_sync_baselines
from .runner import run_visualcheck
from .diff_engine import diff_folders
from .baseline import approve_current_as_runtime, cleanup_visual_runs

app = typer.Typer(add_completion=False, help="visualcheck: visual regression checking")
console = Console()


@app.command()
def run(
    env: str = typer.Option(..., help="Environment key from visualcheck.yaml (e.g. qa/prod)"),
    config: Path = typer.Option(Path("visualcheck.yaml"), help="Path to visualcheck.yaml"),
    run_id: Optional[str] = typer.Option(None, help="Override run id (default: timestamp)"),
    headed: bool = typer.Option(False, help="Run browser headed"),
    slow_mo_ms: int = typer.Option(0, help="Slow motion in ms for Playwright actions"),
    workers: int = typer.Option(1, help="Parallel workers for capture (1 recommended for stability)"),
    force_reset_figma_baseline: bool = typer.Option(
        False,
        "--force-reset-figma-baseline",
        help="Force refresh of matched Figma baselines during baseline resolution",
    ),
    open_report: bool = typer.Option(
        True,
        "--open-report/--no-open-report",
        help="Open generated HTML report in default browser",
    ),
):
    """Capture + baseline resolve + diff + HTML report."""
    cfg = load_config(config)
    cfg["__disable_env_report_open__"] = True
    if force_reset_figma_baseline:
        cfg.setdefault("baseline", {})
        cfg["baseline"]["force_reset_figma_baseline"] = True
    result = run_visualcheck(cfg, env=env, run_id=run_id, headed=headed, slow_mo_ms=slow_mo_ms, workers=workers)

    table = Table(title=f"visualcheck results ({result['status']})")
    table.add_column("id")
    table.add_column("view")
    table.add_column("status")
    table.add_column("pixel_diff_%", justify="right")
    table.add_column("ssim", justify="right")

    for r in result["results"]:
        table.add_row(
            r["snapshot_id"],
            r["view_id"],
            r["status"],
            f"{r.get('pixel_diff_pct', 0):.4f}",
            f"{r.get('ssim', 0):.6f}",
        )

    console.print(table)
    console.print(f"Report: {result['report_html']}")
    if result.get("report_junit_xml"):
        console.print(f"JUnit:  {result['report_junit_xml']}")
    if open_report:
        try:
            webbrowser.open_new_tab(Path(result["report_html"]).resolve().as_uri())
        except Exception as exc:
            console.print(f"[yellow]Could not open browser automatically: {exc}[/yellow]")


@app.command()
def capture(
    env: str = typer.Option(..., help="Environment key from visualcheck.yaml"),
    config: Path = typer.Option(Path("visualcheck.yaml"), help="Path to visualcheck.yaml"),
    out: Path = typer.Option(Path("current"), help="Output folder for screenshots"),
    headed: bool = typer.Option(False, help="Run browser headed"),
    slow_mo_ms: int = typer.Option(0, help="Slow motion in ms for Playwright actions"),
    workers: int = typer.Option(1, help="Parallel workers for capture"),
):
    """Capture-only mode (no baseline/diff/report)."""
    cfg = load_config(config)
    result = run_visualcheck(
        cfg,
        env=env,
        run_id="capture_only",
        headed=headed,
        slow_mo_ms=slow_mo_ms,
        workers=workers,
        capture_only=True,
        capture_out=out,
    )
    console.print(json.dumps(result, indent=2))


@app.command("figma-sync")
def figma_sync(
    config: Path = typer.Option(Path("visualcheck.yaml"), help="Path to visualcheck.yaml"),
    force: bool = typer.Option(False, help="Overwrite existing figma baseline PNGs"),
    only: Optional[str] = typer.Option(
        None,
        help="Comma-separated snapshot ids to sync (example: home,pricing)",
    ),
    match_by_name: bool = typer.Option(
        False,
        help="Auto-map page/flow snapshot ids to Figma frame names when possible",
    ),
):
    """Sync Figma frames into figma baseline folder."""
    cfg = load_config(config)
    only_ids = [x.strip() for x in (only or "").split(",") if x.strip()]
    summary = figma_sync_baselines(cfg, force=force, only_ids=only_ids, match_by_name=match_by_name)
    console.print(json.dumps(summary, indent=2))


@app.command()
def diff(
    baseline: Path = typer.Option(..., help="Baseline folder (pngs, nested ok)"),
    current: Path = typer.Option(..., help="Current screenshots folder (pngs, nested ok)"),
    out: Path = typer.Option(Path("report"), help="Output report folder"),
    max_pixel_diff_pct: float = typer.Option(0.10, help="Max allowed pixel diff percent"),
    min_ssim: float = typer.Option(0.995, help="Min allowed SSIM"),
    resize_on_mismatch: bool = typer.Option(True, help="Resize current to baseline size when different"),
    mismatch_level: str = typer.Option("WARN", help="WARN or FAIL"),
):
    """Diff-only mode across two folders."""
    out.mkdir(parents=True, exist_ok=True)
    result = diff_folders(
        baseline_dir=baseline,
        current_dir=current,
        out_dir=out,
        thresholds={"max_pixel_diff_pct": max_pixel_diff_pct, "min_ssim": min_ssim},
        resize_on_mismatch=resize_on_mismatch,
        mismatch_level=mismatch_level,
    )
    console.print(json.dumps(result, indent=2))


@app.command()
def approve(
    env: str = typer.Option(..., help="Environment key from visualcheck.yaml"),
    config: Path = typer.Option(Path("visualcheck.yaml"), help="Path to visualcheck.yaml"),
    run_id: str = typer.Option(..., help="Run id that produced current screenshots"),
    force: bool = typer.Option(False, help="Overwrite existing runtime baselines"),
):
    """Promote a run's current screenshots to runtime baselines (explicit action)."""
    cfg = load_config(config)
    summary = approve_current_as_runtime(cfg, env=env, run_id=run_id, force=force)
    console.print(json.dumps(summary, indent=2))


@app.command("validate-config")
def validate_config_cmd(
    config: Path = typer.Option(Path("visualcheck.yaml"), help="Path to visualcheck.yaml"),
):
    """Validate config file against schema and print normalized metadata."""
    cfg = load_config(config)
    summary = {
        "status": "VALID",
        "config": str(config),
        "project": cfg.get("project"),
        "suite": cfg.get("suite"),
        "envs": sorted((cfg.get("envs") or {}).keys()),
        "pages": len(cfg.get("pages") or []),
        "flows": len(cfg.get("flows") or []),
    }
    console.print(json.dumps(summary, indent=2))


@app.command("cleanup")
def cleanup(
    config: Path = typer.Option(Path("visualcheck.yaml"), help="Path to visualcheck.yaml"),
    keep_last: int = typer.Option(10, help="Keep the N most recent visual run folders"),
    dry_run: bool = typer.Option(False, help="Only print what would be deleted"),
):
    """Delete old visual run folders under test_report/<project>/visual_runs."""
    cfg = load_config(config)
    summary = cleanup_visual_runs(cfg, keep_last=keep_last, dry_run=dry_run)
    console.print(json.dumps(summary, indent=2))


@app.command("quarantine-list")
def quarantine_list(
    config: Path = typer.Option(Path("visualcheck.yaml"), help="Path to visualcheck.yaml"),
):
    """List quarantined snapshot ids."""
    cfg = load_config(config)
    snaps = sorted(set(((cfg.get("quarantine") or {}).get("snapshots") or [])))
    console.print(json.dumps({"config": str(config), "snapshots": snaps}, indent=2))


@app.command("quarantine-add")
def quarantine_add(
    snapshot: str = typer.Option(..., help="Snapshot id to quarantine"),
    config: Path = typer.Option(Path("visualcheck.yaml"), help="Path to visualcheck.yaml"),
):
    """Add snapshot id to quarantine list in config file."""
    data = yaml.safe_load(config.read_text()) or {}
    q = data.setdefault("quarantine", {})
    snaps = set(q.get("snapshots") or [])
    snaps.add(snapshot)
    q["snapshots"] = sorted(snaps)
    config.write_text(yaml.safe_dump(data, sort_keys=False))
    console.print(json.dumps({"status": "OK", "added": snapshot, "total": len(q["snapshots"])}, indent=2))


@app.command("quarantine-remove")
def quarantine_remove(
    snapshot: str = typer.Option(..., help="Snapshot id to remove from quarantine"),
    config: Path = typer.Option(Path("visualcheck.yaml"), help="Path to visualcheck.yaml"),
):
    """Remove snapshot id from quarantine list in config file."""
    data = yaml.safe_load(config.read_text()) or {}
    q = data.setdefault("quarantine", {})
    snaps = set(q.get("snapshots") or [])
    snaps.discard(snapshot)
    q["snapshots"] = sorted(snaps)
    config.write_text(yaml.safe_dump(data, sort_keys=False))
    console.print(json.dumps({"status": "OK", "removed": snapshot, "total": len(q["snapshots"])}, indent=2))


@app.command("figma-diff")
def figma_diff(
    env: str = typer.Option(..., help="Environment key from visualcheck.yaml (e.g. qa/prod)"),
    config: Path = typer.Option(Path("visualcheck.yaml"), help="Path to visualcheck.yaml"),
    run_id: Optional[str] = typer.Option(None, help="Override run id (default: timestamp)"),
    headed: bool = typer.Option(False, help="Run browser headed"),
    slow_mo_ms: int = typer.Option(0, help="Slow motion in ms for Playwright actions"),
    workers: int = typer.Option(1, help="Parallel workers for capture"),
    force_sync: bool = typer.Option(False, help="Force overwrite when running pre-sync"),
    open_report: bool = typer.Option(
        True,
        "--open-report/--no-open-report",
        help="Open generated HTML report in default browser",
    ),
):
    """Compare current screenshots strictly against Figma baselines."""
    cfg = load_config(config)
    cfg["__disable_env_report_open__"] = True
    cfg["baseline"]["priority"] = ["figma"]
    cfg["baseline"]["create_if_missing"] = False
    if cfg.get("figma"):
        figma_sync_baselines(cfg, force=force_sync, match_by_name=True)
    result = run_visualcheck(cfg, env=env, run_id=run_id, headed=headed, slow_mo_ms=slow_mo_ms, workers=workers)
    console.print(json.dumps({"status": result["status"], "report_html": result["report_html"]}, indent=2))
    if open_report:
        try:
            webbrowser.open_new_tab(Path(result["report_html"]).resolve().as_uri())
        except Exception as exc:
            console.print(f"[yellow]Could not open browser automatically: {exc}[/yellow]")
