"""AtlasBridge Expert Agent — platform-native operational agent."""
