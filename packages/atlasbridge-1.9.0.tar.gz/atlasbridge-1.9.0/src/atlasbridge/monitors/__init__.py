"""AtlasBridge monitors — capture AI conversations from desktop apps, VS Code, and more."""
