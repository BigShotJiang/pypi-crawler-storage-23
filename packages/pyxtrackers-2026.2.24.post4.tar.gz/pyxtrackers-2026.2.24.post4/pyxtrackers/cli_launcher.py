"""Python launcher for environments that require a .py entrypoint."""

from pyxtrackers.cli import main


if __name__ == "__main__":
    main()
