# Changelog for SecretZero

## 0.1.3

- Initial release