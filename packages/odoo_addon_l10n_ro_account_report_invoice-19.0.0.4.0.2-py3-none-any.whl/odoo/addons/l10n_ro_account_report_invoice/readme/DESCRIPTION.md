This module adds a comment in invoice about the stamp and signature
according to law. It also adds the total amounts in company currency if
the currency is different than the company currency.
