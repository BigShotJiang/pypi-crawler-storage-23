"""root of sotkalib library"""
