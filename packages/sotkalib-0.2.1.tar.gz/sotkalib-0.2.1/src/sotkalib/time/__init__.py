from .dtfunc import now, utcnow

__all__ = ["utcnow", "now"]
