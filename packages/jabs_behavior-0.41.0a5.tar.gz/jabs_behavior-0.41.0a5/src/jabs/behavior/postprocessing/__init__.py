"""jabs.behavior.postprocessing package."""

from .pipeline import PostprocessingPipeline

__all__ = ["PostprocessingPipeline"]
