"""Entry point for running devsync as a module."""

from devsync.cli.main import app

if __name__ == "__main__":
    app()
