"""TUI (Text User Interface) components for DevSync."""

from devsync.tui.installer import show_installer_tui

__all__ = ["show_installer_tui"]
