"""Tests for upload logic — file walking, sync comparison, routing."""

import os
import platform

import pytest

from evercoast_cli.upload import (
    compute_upload_plan,
    format_size,
    resolve_destination,
    walk_local_files,
)


class TestWalkLocalFiles:
    def test_walks_all_files(self, sample_dir):
        files = walk_local_files(str(sample_dir))
        filenames = [os.path.basename(f) for f in files]
        assert "file1.txt" in filenames
        assert "file2.log" in filenames
        assert ".DS_Store" in filenames
        assert "file3.txt" in filenames
        assert "file4.tmp" in filenames
        assert "file5.exr" in filenames
        assert len(files) == 6

    def test_exclude_by_extension(self, sample_dir):
        files = walk_local_files(str(sample_dir), exclude_patterns=["*.log"])
        filenames = [os.path.basename(f) for f in files]
        assert "file2.log" not in filenames
        assert "file1.txt" in filenames

    def test_exclude_by_filename(self, sample_dir):
        files = walk_local_files(str(sample_dir), exclude_patterns=[".DS_Store"])
        filenames = [os.path.basename(f) for f in files]
        assert ".DS_Store" not in filenames

    def test_exclude_multiple_patterns(self, sample_dir):
        files = walk_local_files(
            str(sample_dir),
            exclude_patterns=["*.log", "*.tmp", ".DS_Store"],
        )
        filenames = [os.path.basename(f) for f in files]
        assert "file2.log" not in filenames
        assert "file4.tmp" not in filenames
        assert ".DS_Store" not in filenames
        assert "file1.txt" in filenames
        assert "file3.txt" in filenames
        assert "file5.exr" in filenames

    def test_returns_absolute_paths(self, sample_dir):
        files = walk_local_files(str(sample_dir))
        for f in files:
            assert os.path.isabs(f)

    def test_returns_sorted(self, sample_dir):
        files = walk_local_files(str(sample_dir))
        assert files == sorted(files)

    def test_empty_directory(self, tmp_path):
        empty = tmp_path / "empty"
        empty.mkdir()
        files = walk_local_files(str(empty))
        assert files == []

    def test_no_exclude(self, sample_dir):
        files = walk_local_files(str(sample_dir), exclude_patterns=None)
        assert len(files) == 6


class TestComputeUploadPlan:
    def test_all_new_files(self, sample_dir):
        remote = {}
        to_upload, skipped = compute_upload_plan(str(sample_dir), remote)
        assert skipped == 0
        assert len(to_upload) == 6

    def test_skip_matching_files(self, sample_dir):
        # file1.txt has content "hello" = 5 bytes
        remote = {"file1.txt": 5}
        to_upload, skipped = compute_upload_plan(str(sample_dir), remote)
        assert skipped == 1
        names = [os.path.basename(f[0]) for f in to_upload]
        assert "file1.txt" not in names

    def test_reupload_size_mismatch(self, sample_dir):
        # file1.txt is 5 bytes, but remote says 999
        remote = {"file1.txt": 999}
        to_upload, skipped = compute_upload_plan(str(sample_dir), remote)
        assert skipped == 0
        names = [os.path.basename(f[0]) for f in to_upload]
        assert "file1.txt" in names

    def test_all_already_uploaded(self, sample_dir):
        # Build remote dict matching all local files
        remote = {}
        for filepath in walk_local_files(str(sample_dir)):
            rel = os.path.relpath(filepath, str(sample_dir)).replace(os.sep, "/")
            remote[rel] = os.path.getsize(filepath)

        to_upload, skipped = compute_upload_plan(str(sample_dir), remote)
        assert len(to_upload) == 0
        assert skipped == 6

    def test_with_excludes(self, sample_dir):
        remote = {}
        to_upload, skipped = compute_upload_plan(
            str(sample_dir), remote, exclude_patterns=["*.log", "*.tmp"]
        )
        assert skipped == 0
        names = [os.path.basename(f[0]) for f in to_upload]
        assert "file2.log" not in names
        assert "file4.tmp" not in names

    def test_upload_tuple_structure(self, sample_dir):
        remote = {}
        to_upload, _ = compute_upload_plan(str(sample_dir), remote)
        for filepath, s3_key, size in to_upload:
            assert os.path.isabs(filepath)
            assert os.path.exists(filepath)
            assert isinstance(s3_key, str)
            assert "/" not in s3_key or s3_key.count("/") <= 2  # relative path
            assert isinstance(size, int)
            assert size > 0

    def test_s3_keys_use_forward_slashes(self, sample_dir):
        remote = {}
        to_upload, _ = compute_upload_plan(str(sample_dir), remote)
        for _, s3_key, _ in to_upload:
            assert "\\" not in s3_key


class TestResolveDestination:
    def test_takes_directory(self):
        result = resolve_destination("takes", "/data/session-42", "client-uploads/", is_dir=True)
        assert result == "client-uploads/takes/session-42/"

    def test_renders_directory(self):
        result = resolve_destination("renders", "/data/meshes", "client-uploads/", is_dir=True)
        assert result == "client-uploads/renders/meshes/"

    def test_other_directory(self):
        result = resolve_destination("other", "/data/stuff", "client-uploads/", is_dir=True)
        assert result == "client-uploads/stuff/"

    def test_takes_single_file(self):
        result = resolve_destination("takes", "/data/capture.zip", "client-uploads/", is_dir=False)
        assert result == "client-uploads/takes/capture.zip"

    def test_renders_single_file(self):
        result = resolve_destination("renders", "/data/mesh.ply", "client-uploads/", is_dir=False)
        assert result == "client-uploads/renders/mesh.ply"

    def test_other_single_file(self):
        result = resolve_destination("other", "/data/notes.txt", "client-uploads/", is_dir=False)
        assert result == "client-uploads/notes.txt"

    def test_custom_dest_overrides_type(self):
        result = resolve_destination(
            "takes", "/data/x", "client-uploads/", is_dir=True, custom_dest="my/custom/path"
        )
        assert result == "client-uploads/my/custom/path/"

    def test_custom_dest_strips_slashes(self):
        result = resolve_destination(
            "takes", "/data/x", "client-uploads/", is_dir=True, custom_dest="/my/path/"
        )
        assert result == "client-uploads/my/path/"

    def test_upload_path_without_trailing_slash(self):
        result = resolve_destination("takes", "/data/session", "client-uploads", is_dir=True)
        assert result == "client-uploads/takes/session/"

    def test_trailing_slash_in_source(self):
        result = resolve_destination("takes", "/data/session/", "client-uploads/", is_dir=True)
        assert result == "client-uploads/takes/session/"

    @pytest.mark.skipif(platform.system() != "Windows", reason="Windows paths")
    def test_windows_backslash_source(self):
        result = resolve_destination("takes", "C:\\data\\session", "client-uploads/", is_dir=True)
        assert result == "client-uploads/takes/session/"


class TestFormatSize:
    def test_bytes(self):
        assert format_size(500) == "500 B"

    def test_kilobytes(self):
        assert format_size(1536) == "1.5 KB"

    def test_megabytes(self):
        assert format_size(5 * 1024 * 1024) == "5.0 MB"

    def test_gigabytes(self):
        assert format_size(23_410_000_000) == "21.80 GB"

    def test_zero(self):
        assert format_size(0) == "0 B"
