"""Agent Service — Production agentic loop backend."""
