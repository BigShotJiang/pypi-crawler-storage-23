"""Shared test fixtures."""

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

from kubera.api.deps import get_db
from kubera.api.main import create_app
from kubera.core.config import Settings
from kubera.core.models import Base

TEST_TOKEN = "test-token-123"


@pytest.fixture()
def engine():
    """In-memory SQLite engine for testing."""
    eng = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )

    @event.listens_for(eng, "connect")
    def _set_wal(dbapi_conn, connection_record):
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.close()

    Base.metadata.create_all(eng)
    yield eng
    Base.metadata.drop_all(eng)
    eng.dispose()


@pytest.fixture()
def db(engine):
    """Database session for direct model tests."""
    session = sessionmaker(bind=engine)()
    yield session
    session.close()


@pytest.fixture()
def app(engine):
    """FastAPI app wired to test database."""
    settings = Settings(_env_file=None, database_url="sqlite:///:memory:", secret_token=TEST_TOKEN)
    application = create_app(settings)
    session_factory = sessionmaker(bind=engine)

    def override_db():
        session = session_factory()
        try:
            yield session
        finally:
            session.close()

    application.dependency_overrides[get_db] = override_db
    return application


@pytest.fixture()
def client(app):
    """Test HTTP client."""
    return TestClient(app)


@pytest.fixture()
def auth_headers():
    """Authorization headers for protected endpoints."""
    return {"Authorization": f"Bearer {TEST_TOKEN}"}
