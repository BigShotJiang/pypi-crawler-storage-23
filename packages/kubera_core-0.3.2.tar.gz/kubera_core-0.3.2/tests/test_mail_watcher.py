"""Tests for MailWatcher: IMAP mail watcher module."""

from __future__ import annotations

import datetime as _dt
import email
import email.mime.multipart
from email.mime.base import MIMEBase
from email import encoders
import imaplib
import zipfile
from io import BytesIO
from typing import Any
from unittest.mock import MagicMock, patch, call

import pytest

from kubera.api.errors import KuberaError
from kubera.core.snapshot.mail_watcher import (
    MailWatcher,
    _decode_header_value,
    _extract_first_zip,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

IMAP_CONFIG = {
    "imap_host": "imap.example.com",
    "imap_port": "993",
    "email": "user@example.com",
    "password": "secret",
    "sender_filter": "banksalad",
}

SUBJECT_MATCH = "뱅크샐러드 엑셀 내보내기 2024-01"
SUBJECT_NO_MATCH = "Hello from someone else"


def _make_zip_bytes(filename_inside: str = "data.xlsx") -> bytes:
    buf = BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr(filename_inside, b"fake-excel-content")
    return buf.getvalue()


def _build_email(subject: str, with_zip: bool = True, zip_filename: str = "export.zip") -> bytes:
    """Build a minimal RFC822 email with optional .zip attachment."""
    msg = email.mime.multipart.MIMEMultipart()
    msg["Subject"] = subject
    msg["From"] = "noreply@banksalad.com"
    msg["To"] = "user@example.com"

    if with_zip:
        part = MIMEBase("application", "zip")
        part.set_payload(_make_zip_bytes())
        encoders.encode_base64(part)
        part.add_header("Content-Disposition", "attachment", filename=zip_filename)
        msg.attach(part)

    return msg.as_bytes()


def _make_imap_mock(msg_ids: list[bytes], raw_email: bytes | None = None) -> MagicMock:
    """Return a mock IMAP4_SSL instance with preset search/fetch responses."""
    imap = MagicMock(spec=imaplib.IMAP4_SSL)
    imap.login.return_value = ("OK", [b"Logged in"])
    imap.select.return_value = ("OK", [b"INBOX"])

    search_data = b" ".join(msg_ids) if msg_ids else b""
    imap.search.return_value = ("OK", [search_data])

    if raw_email is not None and msg_ids:
        imap.fetch.return_value = ("OK", [(None, raw_email)])

    imap.store.return_value = ("OK", [b""])
    imap.logout.return_value = ("BYE", [b""])
    return imap


def _make_watcher(db=None):
    db_factory = MagicMock(return_value=db or MagicMock())
    return MailWatcher(db_factory, IMAP_CONFIG, zip_password=None)


def _make_watcher_with_db():
    db_session = MagicMock()
    db_session.scalar.return_value = None  # no latest snapshot by default
    db_factory = MagicMock(return_value=db_session)
    watcher = MailWatcher(db_factory, IMAP_CONFIG, zip_password="pass123")
    return watcher, db_session


# ---------------------------------------------------------------------------
# Unit tests: _decode_header_value
# ---------------------------------------------------------------------------

class TestDecodeHeaderValue:
    def test_plain_ascii(self):
        assert _decode_header_value("Hello") == "Hello"

    def test_empty(self):
        assert _decode_header_value("") == ""

    def test_encoded_utf8(self):
        # RFC2047 encoded word
        encoded = "=?UTF-8?b?7uaA7YCs?="
        result = _decode_header_value(encoded)
        assert isinstance(result, str)


# ---------------------------------------------------------------------------
# Unit tests: _extract_first_zip
# ---------------------------------------------------------------------------

class TestExtractFirstZip:
    def test_returns_zip_attachment(self):
        raw = _build_email(SUBJECT_MATCH, with_zip=True, zip_filename="export.zip")
        msg = email.message_from_bytes(raw)
        data, filename = _extract_first_zip(msg)
        assert data is not None
        assert filename == "export.zip"

    def test_no_attachment_returns_none(self):
        raw = _build_email(SUBJECT_MATCH, with_zip=False)
        msg = email.message_from_bytes(raw)
        data, filename = _extract_first_zip(msg)
        assert data is None
        assert filename == ""

    def test_non_zip_attachment_skipped(self):
        msg = email.mime.multipart.MIMEMultipart()
        msg["Subject"] = SUBJECT_MATCH
        part = MIMEBase("application", "octet-stream")
        part.set_payload(b"not a zip")
        encoders.encode_base64(part)
        part.add_header("Content-Disposition", "attachment", filename="file.xlsx")
        msg.attach(part)

        data, filename = _extract_first_zip(msg)
        assert data is None


# ---------------------------------------------------------------------------
# Unit tests: MailWatcher.check — email filtering
# ---------------------------------------------------------------------------

class TestMailWatcherFiltering:
    def test_no_messages_returns_zero(self):
        watcher = _make_watcher()
        imap_mock = _make_imap_mock(msg_ids=[])

        with patch("imaplib.IMAP4_SSL", return_value=imap_mock):
            result = watcher.check()

        assert result == 0
        imap_mock.fetch.assert_not_called()

    def test_subject_mismatch_skips_email(self):
        raw = _build_email(SUBJECT_NO_MATCH, with_zip=True)
        imap_mock = _make_imap_mock(msg_ids=[b"1"], raw_email=raw)

        watcher = _make_watcher()
        with patch("imaplib.IMAP4_SSL", return_value=imap_mock):
            result = watcher.check()

        assert result == 0

    def test_no_zip_attachment_skips_email(self):
        raw = _build_email(SUBJECT_MATCH, with_zip=False)
        imap_mock = _make_imap_mock(msg_ids=[b"1"], raw_email=raw)

        watcher = _make_watcher()
        with patch("imaplib.IMAP4_SSL", return_value=imap_mock):
            result = watcher.check()

        assert result == 0

    def test_connection_failure_returns_zero(self):
        watcher = _make_watcher()
        with patch("imaplib.IMAP4_SSL", side_effect=OSError("refused")):
            result = watcher.check()

        assert result == 0


# ---------------------------------------------------------------------------
# Unit tests: MailWatcher.check — SINCE date filtering
# ---------------------------------------------------------------------------

class TestMailWatcherSinceFilter:
    def test_no_snapshots_searches_all(self):
        """When DB has no snapshots, search all emails from sender."""
        watcher, db_session = _make_watcher_with_db()
        db_session.scalar.return_value = None
        imap_mock = _make_imap_mock(msg_ids=[])

        with patch("imaplib.IMAP4_SSL", return_value=imap_mock):
            watcher.check()

        search_criterion = imap_mock.search.call_args.args[1]
        assert "banksalad" in search_criterion
        assert "SINCE" not in search_criterion

    def test_with_snapshot_searches_since_date(self):
        """When DB has snapshots, search emails SINCE latest date."""
        watcher, db_session = _make_watcher_with_db()
        # First call: _get_latest_snapshot_date, second call: _process_message
        db_session.scalar.return_value = _dt.date(2026, 2, 20)
        imap_mock = _make_imap_mock(msg_ids=[])

        with patch("imaplib.IMAP4_SSL", return_value=imap_mock):
            watcher.check()

        search_criterion = imap_mock.search.call_args.args[1]
        assert "banksalad" in search_criterion
        assert "SINCE" in search_criterion
        assert "20-Feb-2026" in search_criterion


# ---------------------------------------------------------------------------
# Unit tests: MailWatcher — SnapshotService integration
# ---------------------------------------------------------------------------

class TestMailWatcherImport:
    def test_successful_import_returns_one(self):
        raw = _build_email(SUBJECT_MATCH, with_zip=True)
        imap_mock = _make_imap_mock(msg_ids=[b"1"], raw_email=raw)

        watcher, db_session = _make_watcher_with_db()

        with patch("imaplib.IMAP4_SSL", return_value=imap_mock), \
             patch("kubera.core.snapshot.mail_watcher.SnapshotService") as MockSvc:
            mock_svc = MockSvc.return_value
            mock_svc.import_from_bytes.return_value = MagicMock()

            result = watcher.check()

        assert result == 1
        mock_svc.import_from_bytes.assert_called_once()
        call_args = mock_svc.import_from_bytes.call_args
        assert call_args.kwargs.get("password") == "pass123" or call_args.args[2] == "pass123"
        # Attachment filename should end with .zip
        filename_arg = call_args.args[1] if len(call_args.args) > 1 else call_args.kwargs.get("filename")
        assert filename_arg.endswith(".zip")
        db_session.close.assert_called()

    def test_duplicate_snapshot_returns_zero(self):
        raw = _build_email(SUBJECT_MATCH, with_zip=True)
        imap_mock = _make_imap_mock(msg_ids=[b"1"], raw_email=raw)

        watcher, db_session = _make_watcher_with_db()

        with patch("imaplib.IMAP4_SSL", return_value=imap_mock), \
             patch("kubera.core.snapshot.mail_watcher.SnapshotService") as MockSvc:
            mock_svc = MockSvc.return_value
            mock_svc.import_from_bytes.side_effect = KuberaError(
                "Snapshot already exists for this date and source",
                code="SNAPSHOT_DUPLICATE",
                status=409,
            )

            result = watcher.check()

        assert result == 0
        db_session.close.assert_called()

    def test_parse_error_returns_zero(self):
        raw = _build_email(SUBJECT_MATCH, with_zip=True)
        imap_mock = _make_imap_mock(msg_ids=[b"1"], raw_email=raw)

        watcher, db_session = _make_watcher_with_db()

        with patch("imaplib.IMAP4_SSL", return_value=imap_mock), \
             patch("kubera.core.snapshot.mail_watcher.SnapshotService") as MockSvc:
            mock_svc = MockSvc.return_value
            mock_svc.import_from_bytes.side_effect = KuberaError(
                "Invalid zip format",
                code="PARSE_ERROR",
                status=422,
            )

            result = watcher.check()

        assert result == 0
        db_session.close.assert_called()

    def test_multiple_emails_processed_independently(self):
        raw_match = _build_email(SUBJECT_MATCH, with_zip=True)
        raw_no_match = _build_email(SUBJECT_NO_MATCH, with_zip=True)

        imap_mock = _make_imap_mock(msg_ids=[b"1", b"2"])
        # msg 1 matches, msg 2 does not
        imap_mock.fetch.side_effect = [
            ("OK", [(None, raw_match)]),
            ("OK", [(None, raw_no_match)]),
        ]

        watcher, db_session = _make_watcher_with_db()

        with patch("imaplib.IMAP4_SSL", return_value=imap_mock), \
             patch("kubera.core.snapshot.mail_watcher.SnapshotService") as MockSvc:
            mock_svc = MockSvc.return_value
            mock_svc.import_from_bytes.return_value = MagicMock()

            result = watcher.check()

        assert result == 1
        assert mock_svc.import_from_bytes.call_count == 1

    def test_search_uses_sender_filter(self):
        imap_mock = _make_imap_mock(msg_ids=[])

        watcher, _ = _make_watcher_with_db()

        with patch("imaplib.IMAP4_SSL", return_value=imap_mock):
            watcher.check()

        imap_mock.search.assert_called_once()
        search_criterion = imap_mock.search.call_args.args[1]
        assert "banksalad" in search_criterion


# ---------------------------------------------------------------------------
# Unit tests: MailWatcher.stop
# ---------------------------------------------------------------------------

class TestMailWatcherStop:
    def test_stop_sets_running_false(self):
        watcher = MailWatcher(MagicMock(), IMAP_CONFIG)
        watcher._running = True
        watcher.stop()
        assert watcher._running is False

    def test_start_exits_after_stop(self):
        """start() should exit when stop() is called between iterations."""
        watcher = MailWatcher(MagicMock(), IMAP_CONFIG)
        watcher.check = MagicMock(side_effect=lambda: (watcher.stop(), 0)[1])  # type: ignore[method-assign]

        with patch("time.sleep"):
            watcher.start(interval=1)

        watcher.check.assert_called_once()
        assert watcher._running is False
