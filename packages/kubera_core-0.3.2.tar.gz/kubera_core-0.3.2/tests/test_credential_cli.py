"""Tests for credential CLI commands (mail provider)."""

from __future__ import annotations

import argparse
import json


class TestMailCredentialAdd:
    def test_add_mail_credential(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from unittest.mock import patch, MagicMock

        monkeypatch.setattr("builtins.input", lambda _: "user@gmail.com")
        monkeypatch.setattr("getpass.getpass", lambda _: "apppassword")

        mock_imap = MagicMock()
        mock_imap.login.return_value = ("OK", [])
        mock_imap.logout.return_value = ("BYE", [])

        from kubera.cli.commands import _cmd_credential_add

        with patch("imaplib.IMAP4_SSL", return_value=mock_imap):
            args = argparse.Namespace(provider="mail")
            _cmd_credential_add(args)

        cred_file = tmp_path / ".kubera" / "credentials.json"
        assert cred_file.exists()
        data = json.loads(cred_file.read_text())
        assert len(data) == 1
        cred = data[0]
        assert cred["provider"] == "mail"
        assert cred["imap_host"] == "imap.gmail.com"
        assert cred["email"] == "user@gmail.com"
        assert cred["password"] == "apppassword"

    def test_add_mail_uses_defaults(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from unittest.mock import patch, MagicMock

        monkeypatch.setattr("builtins.input", lambda _: "user@gmail.com")
        monkeypatch.setattr("getpass.getpass", lambda _: "mypassword")

        mock_imap = MagicMock()
        mock_imap.login.return_value = ("OK", [])
        mock_imap.logout.return_value = ("BYE", [])

        from kubera.cli.commands import _cmd_credential_add

        with patch("imaplib.IMAP4_SSL", return_value=mock_imap):
            args = argparse.Namespace(provider="mail")
            _cmd_credential_add(args)

        data = json.loads((tmp_path / ".kubera" / "credentials.json").read_text())
        cred = data[0]
        assert cred["imap_port"] == "993"
        assert cred["sender_filter"] == "banksalad"

    def test_add_unsupported_provider(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        import pytest
        from kubera.cli.commands import _cmd_credential_add

        args = argparse.Namespace(provider="unknown_provider")
        with pytest.raises(SystemExit):
            _cmd_credential_add(args)

    def test_add_replaces_existing(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from unittest.mock import patch, MagicMock

        mock_imap = MagicMock()
        mock_imap.login.return_value = ("OK", [])
        mock_imap.logout.return_value = ("BYE", [])

        from kubera.cli.commands import _cmd_credential_add

        # First add
        monkeypatch.setattr("builtins.input", lambda _: "old@gmail.com")
        monkeypatch.setattr("getpass.getpass", lambda _: "pass1")

        with patch("imaplib.IMAP4_SSL", return_value=mock_imap):
            _cmd_credential_add(argparse.Namespace(provider="mail"))

        # Second add (replace)
        monkeypatch.setattr("builtins.input", lambda _: "new@gmail.com")
        monkeypatch.setattr("getpass.getpass", lambda _: "pass2")

        with patch("imaplib.IMAP4_SSL", return_value=mock_imap):
            _cmd_credential_add(argparse.Namespace(provider="mail"))

        data = json.loads((tmp_path / ".kubera" / "credentials.json").read_text())
        assert len(data) == 1
        assert data[0]["email"] == "new@gmail.com"


class TestUpbitCredentialAdd:
    def test_add_upbit_credential(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        keys = iter(["test-access-key", "test-secret-key"])
        monkeypatch.setattr("getpass.getpass", lambda _: next(keys))

        from kubera.cli.commands import _cmd_credential_add

        args = argparse.Namespace(provider="upbit")
        _cmd_credential_add(args)

        data = json.loads((tmp_path / ".kubera" / "credentials.json").read_text())
        assert len(data) == 1
        cred = data[0]
        assert cred["provider"] == "upbit"
        assert cred["access_key"] == "test-access-key"
        assert cred["secret_key"] == "test-secret-key"

    def test_list_masks_upbit_keys(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".kubera").mkdir()
        cred_file = tmp_path / ".kubera" / "credentials.json"
        cred_file.write_text(json.dumps([{
            "provider": "upbit",
            "access_key": "my-access-key",
            "secret_key": "my-secret-key",
        }]))

        from kubera.cli.commands import _cmd_credential_list

        _cmd_credential_list()
        out = capsys.readouterr().out
        assert "upbit" in out
        assert "my-access-key" not in out
        assert "my-secret-key" not in out
        assert "***" in out


class TestMailCredentialList:
    def test_list_empty(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        from kubera.cli.commands import _cmd_credential_list

        _cmd_credential_list()
        out = capsys.readouterr().out
        assert "No credentials" in out

    def test_list_shows_mail(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".kubera").mkdir()
        cred_file = tmp_path / ".kubera" / "credentials.json"
        cred_file.write_text(json.dumps([{
            "provider": "mail",
            "imap_host": "imap.gmail.com",
            "imap_port": "993",
            "email": "user@gmail.com",
            "password": "secret",
            "sender_filter": "banksalad",
        }]))

        from kubera.cli.commands import _cmd_credential_list

        _cmd_credential_list()
        out = capsys.readouterr().out
        assert "mail" in out
        assert "user@gmail.com" in out
        # Password must be masked
        assert "secret" not in out
        assert "***" in out


class TestMailCredentialRemove:
    def test_remove_existing(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".kubera").mkdir()
        cred_file = tmp_path / ".kubera" / "credentials.json"
        cred_file.write_text(json.dumps([{
            "provider": "mail",
            "imap_host": "imap.gmail.com",
            "email": "user@gmail.com",
            "password": "secret",
        }]))

        from kubera.cli.commands import _cmd_credential_remove

        _cmd_credential_remove(argparse.Namespace(provider="mail"))
        data = json.loads(cred_file.read_text())
        assert data == []

    def test_remove_nonexistent(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        import pytest
        from kubera.cli.commands import _cmd_credential_remove

        with pytest.raises(SystemExit):
            _cmd_credential_remove(argparse.Namespace(provider="mail"))
