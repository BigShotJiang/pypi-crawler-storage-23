# kubera-core

## API Contract First
- When adding or changing API endpoints, **define schemas first** before implementation
- Order: schema design → export openapi.json → create kubera-web issue → implement
- Finalize and share response schemas early so web can develop in parallel
- Schemas must clearly specify all fields, types, nullable, and nested structures

## Security
- Credential keys: CLI only for input/viewing. API returns status only.

## Deployment Constraints
- Runs on user's PC (self-hosted) — not a managed server
- Must work cross-platform: Windows, macOS, Linux
- Zero-config ideal: `pip install kubera-core && kubera-core start`
- SQLite default — no external services required
- Keep dependencies minimal and cross-platform compatible

## Build & Test
- Package manager: `uv`
- Run tests: `uv run pytest`
- Run single test: `uv run pytest tests/test_xxx.py`
- Export OpenAPI: `uv run python scripts/export_openapi.py`
- Dev server: `uv run kubera-core start`
