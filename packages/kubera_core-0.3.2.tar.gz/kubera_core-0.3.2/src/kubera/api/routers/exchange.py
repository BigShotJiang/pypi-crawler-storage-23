"""Exchange router."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from kubera.api.auth import verify_token
from kubera.api.errors import KuberaError
from kubera.api.schemas.exchange import UpbitBalanceResponse
from kubera.core.credentials import get_credential
from kubera.core.exchange.upbit import UpbitClient

router = APIRouter(
    prefix="/api/v1/exchange", tags=["exchange"], dependencies=[Depends(verify_token)]
)


@router.get("/upbit/balances", response_model=list[UpbitBalanceResponse])
def get_upbit_balances():
    credential = get_credential("upbit")
    if not credential:
        raise KuberaError(
            "Upbit credential not configured. Run 'kubera-core credential add upbit'.",
            code="CREDENTIAL_NOT_FOUND",
            status=400,
        )
    client = UpbitClient(
        access_key=credential["access_key"],
        secret_key=credential["secret_key"],
    )
    raw = client.get_accounts()
    return [UpbitBalanceResponse(**item) for item in raw]
