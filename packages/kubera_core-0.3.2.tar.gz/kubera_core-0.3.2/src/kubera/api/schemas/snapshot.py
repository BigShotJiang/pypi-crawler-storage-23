"""Snapshot schemas."""

from __future__ import annotations

from datetime import date, datetime, time
from decimal import Decimal

from pydantic import BaseModel


class AssetEntryCreate(BaseModel):
    category: str
    product_name: str
    amount: Decimal


class AssetEntryResponse(BaseModel):
    id: int
    category: str
    product_name: str
    amount: Decimal

    model_config = {"from_attributes": True}


class InvestmentEntryResponse(BaseModel):
    id: int
    broker: str
    product_name: str
    invested_amount: Decimal
    current_value: Decimal
    return_rate: Decimal | None

    model_config = {"from_attributes": True}


class LoanEntryResponse(BaseModel):
    id: int
    lender: str
    product_name: str
    principal: Decimal
    balance: Decimal
    interest_rate: Decimal | None
    start_date: date | None
    end_date: date | None

    model_config = {"from_attributes": True}


class InsuranceEntryResponse(BaseModel):
    id: int
    insurer: str
    product_name: str
    status: str
    total_paid: Decimal
    start_date: date | None
    end_date: date | None

    model_config = {"from_attributes": True}


class LedgerEntryResponse(BaseModel):
    id: int
    entry_date: date
    entry_time: time | None
    entry_type: str
    major_category: str
    minor_category: str | None
    description: str | None
    amount: Decimal
    currency: str
    payment_method: str | None
    memo: str | None

    model_config = {"from_attributes": True}


class SnapshotSummaryResponse(BaseModel):
    id: int
    user_id: str
    snapshot_date: datetime
    source: str
    credit_score: int | None
    total_assets: Decimal
    total_liabilities: Decimal
    net_worth: Decimal
    filename_stem: str | None
    created_at: datetime

    model_config = {"from_attributes": True}


class SnapshotDetailResponse(SnapshotSummaryResponse):
    asset_entries: list[AssetEntryResponse]
    investment_entries: list[InvestmentEntryResponse]
    loan_entries: list[LoanEntryResponse]
    insurance_entries: list[InsuranceEntryResponse]
    ledger_entries: list[LedgerEntryResponse]


class TrendPointResponse(BaseModel):
    snapshot_date: datetime
    credit_score: int | None
    total_assets: Decimal
    total_liabilities: Decimal
    net_worth: Decimal


class SnapshotDiff(BaseModel):
    credit_score: int
    total_assets: Decimal
    total_liabilities: Decimal
    net_worth: Decimal


class CompareResponse(BaseModel):
    from_date: datetime
    to_date: datetime
    diff: SnapshotDiff
