"""Application settings with layered config: defaults -> settings.yaml -> .env -> env vars."""

from __future__ import annotations

import secrets
from functools import lru_cache
from pathlib import Path
from typing import Any, Tuple, Type

import yaml
from pydantic import Field
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
)


def kubera_dir() -> Path:
    """Return the .kubera data directory, creating it if needed."""
    d = Path(".kubera")
    d.mkdir(exist_ok=True)
    return d


def _load_yaml_settings() -> dict:
    """Load settings from .kubera/settings.yaml if it exists."""
    path = kubera_dir() / "settings.yaml"
    if path.exists():
        with open(path) as f:
            data = yaml.safe_load(f)
            return data if data else {}
    return {}


class YamlSettingsSource(PydanticBaseSettingsSource):
    """Custom settings source that loads from settings.yaml."""

    def get_field_value(self, field: Any, field_name: str) -> Tuple[Any, str, bool]:
        yaml_data = _load_yaml_settings()
        val = yaml_data.get(field_name)
        return val, field_name, val is not None

    def __call__(self) -> dict[str, Any]:
        yaml_data = _load_yaml_settings()
        return {k: v for k, v in yaml_data.items() if v is not None}


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="KUBERA_",
        env_file=".kubera/.env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    database_url: str = "sqlite:///.kubera/kubera.db"
    host: str = "0.0.0.0"
    port: int = 8000
    secret_token: str | None = None
    cors_origins: list[str] = ["*"]
    debug: bool = False
    mail_watch_interval: int = 300
    snapshot_zip_password: str | None = None

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: Type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> Tuple[PydanticBaseSettingsSource, ...]:
        # Priority (highest first): init kwargs > env vars > .env > yaml > defaults
        return (
            init_settings,
            env_settings,
            dotenv_settings,
            YamlSettingsSource(settings_cls),
            file_secret_settings,
        )

    def ensure_token(self) -> str:
        """Return existing token or generate and persist a new one."""
        if self.secret_token:
            return self.secret_token
        token = secrets.token_urlsafe(32)
        self.secret_token = token
        self._write_token_to_env(token)
        return token

    @staticmethod
    def _write_token_to_env(token: str) -> None:
        """Write token to .env file."""
        env_path = kubera_dir() / ".env"
        lines: list[str] = []
        found = False
        if env_path.exists():
            lines = env_path.read_text().splitlines()
            for i, line in enumerate(lines):
                if line.startswith("KUBERA_SECRET_TOKEN="):
                    lines[i] = f"KUBERA_SECRET_TOKEN={token}"
                    found = True
                    break
        if not found:
            lines.append(f"KUBERA_SECRET_TOKEN={token}")
        env_path.write_text("\n".join(lines) + "\n")


@lru_cache
def get_settings() -> Settings:
    return Settings()
