"""IMAP mail watcher: monitors inbox for Banksalad export emails and imports them."""

from __future__ import annotations

import datetime as _dt
import email
import gc
import imaplib
import logging
import time
import zipfile
from email.message import Message
from io import BytesIO
from typing import Callable

from sqlalchemy import select, func

from kubera.api.errors import KuberaError
from kubera.core.snapshot.models import Snapshot
from kubera.core.snapshot.service import SnapshotService

logger = logging.getLogger(__name__)

SUBJECT_KEYWORD = "뱅크샐러드 엑셀 내보내기"


class MailWatcher:
    """Polls an IMAP inbox for Banksalad export emails and imports them as snapshots."""

    def __init__(
        self,
        db_factory: Callable,
        imap_config: dict,
        zip_password: str | None = None,
    ) -> None:
        """
        Args:
            db_factory: zero-arg callable that returns a SQLAlchemy Session.
            imap_config: dict with keys: imap_host, imap_port, email, password,
                         and optionally sender_filter.
            zip_password: password for encrypted zip attachments.
        """
        self.db_factory = db_factory
        self.imap_config = imap_config
        self.zip_password = zip_password
        self._running = False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start(self, interval: int = 300) -> None:
        """Blocking polling loop. Calls check() every `interval` seconds."""
        self._running = True
        logger.info("MailWatcher started (interval=%ds)", interval)
        while self._running:
            try:
                count = self.check()
                if count:
                    logger.info("Imported %d snapshot(s) from mail", count)
            except Exception:
                logger.exception("Unexpected error during mail check; will retry next interval")
            if self._running:
                time.sleep(interval)
        logger.info("MailWatcher stopped")

    def check(self) -> int:
        """Connect to IMAP, search emails since latest snapshot, return import count."""
        host = self.imap_config["imap_host"]
        port = int(self.imap_config.get("imap_port", 993))
        user = self.imap_config["email"]
        password = self.imap_config["password"]
        sender_filter = self.imap_config.get("sender_filter", "banksalad")

        try:
            imap = imaplib.IMAP4_SSL(host, port)
        except OSError:
            logger.warning("IMAP connection failed to %s:%d", host, port)
            return 0

        try:
            imap.login(user, password)
            imap.select("INBOX")

            since_date = self._get_latest_snapshot_date()
            if since_date:
                # IMAP SINCE uses dd-Mon-yyyy format
                since_str = since_date.strftime("%d-%b-%Y")
                search_criterion = f'(FROM "{sender_filter}" SINCE {since_str})'
                logger.info("Checking mail from %s (since %s)...", host, since_date)
            else:
                search_criterion = f'(FROM "{sender_filter}")'
                logger.info("Checking mail from %s (all)...", host)

            status, data = imap.search(None, search_criterion)
            if status != "OK" or not data or not data[0]:
                logger.info("No matching emails found")
                return 0

            msg_ids = data[0].split()
            logger.info("Found %d email(s) to process", len(msg_ids))
            imported = 0

            for msg_id in msg_ids:
                imported += self._process_message(imap, msg_id)
                gc.collect()

            return imported
        finally:
            try:
                imap.logout()
            except Exception:
                pass

    def stop(self) -> None:
        """Signal the polling loop to exit after the current sleep."""
        self._running = False

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _mark_seen(imap: imaplib.IMAP4_SSL, msg_id: bytes) -> None:
        """Mark an email as read (\\Seen) so users can see it was processed."""
        try:
            imap.store(msg_id, "+FLAGS", "\\Seen")
        except Exception:
            logger.debug("Failed to mark message %s as seen", msg_id)

    def _get_latest_snapshot_date(self) -> _dt.date | None:
        """Query DB for the most recent snapshot date (date portion only for IMAP SINCE)."""
        db = self.db_factory()
        try:
            result = db.scalar(
                select(func.max(Snapshot.snapshot_date))
            )
            if result is None:
                return None
            if isinstance(result, _dt.datetime):
                return result.date()
            return result
        finally:
            db.close()

    def _process_message(self, imap: imaplib.IMAP4_SSL, msg_id: bytes) -> int:
        """Fetch, validate, and import a single email. Returns 1 on success, 0 otherwise."""
        status, msg_data = imap.fetch(msg_id, "(RFC822)")
        if status != "OK" or not msg_data or msg_data[0] is None:
            return 0

        raw = msg_data[0][1]
        msg: Message = email.message_from_bytes(raw)
        del raw  # free raw email bytes early

        subject = _decode_header_value(msg.get("Subject", ""))
        if SUBJECT_KEYWORD not in subject:
            logger.debug("Skipping email — subject does not match: %r", subject)
            return 0

        zip_bytes, filename = _extract_first_zip(msg)
        del msg  # free parsed email structure
        if zip_bytes is None:
            logger.debug("Skipping email — no .zip attachment found (subject=%r)", subject)
            return 0

        db = self.db_factory()
        try:
            svc = SnapshotService(db)
            svc.import_from_bytes(zip_bytes, filename, password=self.zip_password)
            del zip_bytes  # free ZIP bytes after import
            logger.info("Imported snapshot from attachment %r", filename)
            self._mark_seen(imap, msg_id)
            return 1
        except KuberaError as exc:
            if exc.code == "SNAPSHOT_DUPLICATE":
                logger.info("Duplicate snapshot in %r — skipped", filename)
                self._mark_seen(imap, msg_id)
                return 0
            logger.warning("Parse/import error for %r: %s", filename, exc.detail)
            return 0
        except Exception:
            logger.warning("Unexpected error processing %r", filename, exc_info=True)
            return 0
        finally:
            db.close()


# ------------------------------------------------------------------
# Module-level utilities (not part of public class API)
# ------------------------------------------------------------------

def _decode_header_value(raw: str) -> str:
    """Decode an RFC2047-encoded email header value to a plain string."""
    parts = email.header.decode_header(raw)
    decoded_parts = []
    for part, charset in parts:
        if isinstance(part, bytes):
            decoded_parts.append(part.decode(charset or "utf-8", errors="replace"))
        else:
            decoded_parts.append(part)
    return "".join(decoded_parts)


def _extract_first_zip(msg: Message) -> tuple[bytes | None, str]:
    """Walk MIME parts and return (bytes, filename) for the first .zip attachment."""
    for part in msg.walk():
        content_disposition = part.get("Content-Disposition", "")
        if "attachment" not in content_disposition.lower():
            continue
        filename_raw = part.get_filename() or ""
        filename = _decode_header_value(filename_raw)
        if filename.lower().endswith(".zip"):
            payload = part.get_payload(decode=True)
            if payload:
                return payload, filename
    return None, ""
