"""Banksalad snapshot models."""

from __future__ import annotations

import datetime as _dt
from decimal import Decimal

from sqlalchemy import Date, DateTime, ForeignKey, Numeric, String, Time, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from kubera.core.models.base import Base, TimestampMixin


class Snapshot(TimestampMixin, Base):
    __tablename__ = "snapshots"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(String(64), default="default")
    snapshot_date: Mapped[_dt.datetime] = mapped_column(DateTime)
    source: Mapped[str] = mapped_column(String(32))
    credit_score: Mapped[int | None] = mapped_column(default=None)
    total_assets: Mapped[Decimal] = mapped_column(Numeric(20, 4), default=Decimal("0"))
    total_liabilities: Mapped[Decimal] = mapped_column(Numeric(20, 4), default=Decimal("0"))
    net_worth: Mapped[Decimal] = mapped_column(Numeric(20, 4), default=Decimal("0"))
    filename_stem: Mapped[str | None] = mapped_column(String(128), default=None)

    asset_entries: Mapped[list[AssetEntry]] = relationship(
        back_populates="snapshot", cascade="all, delete-orphan"
    )
    investment_entries: Mapped[list[InvestmentEntry]] = relationship(
        back_populates="snapshot", cascade="all, delete-orphan"
    )
    loan_entries: Mapped[list[LoanEntry]] = relationship(
        back_populates="snapshot", cascade="all, delete-orphan"
    )
    insurance_entries: Mapped[list[InsuranceEntry]] = relationship(
        back_populates="snapshot", cascade="all, delete-orphan"
    )
    ledger_entries: Mapped[list[LedgerEntry]] = relationship(
        back_populates="snapshot", cascade="all, delete-orphan"
    )

    __table_args__ = (
        UniqueConstraint("user_id", "filename_stem", "source", name="uq_snapshot_user_filename_source"),
    )


class AssetEntry(TimestampMixin, Base):
    __tablename__ = "snapshot_asset_entries"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    snapshot_id: Mapped[int] = mapped_column(ForeignKey("snapshots.id", ondelete="CASCADE"))
    category: Mapped[str] = mapped_column(String(64))
    product_name: Mapped[str] = mapped_column(String(255))
    amount: Mapped[Decimal] = mapped_column(Numeric(20, 4), default=Decimal("0"))

    snapshot: Mapped[Snapshot] = relationship(back_populates="asset_entries")


class InvestmentEntry(TimestampMixin, Base):
    __tablename__ = "snapshot_investment_entries"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    snapshot_id: Mapped[int] = mapped_column(ForeignKey("snapshots.id", ondelete="CASCADE"))
    broker: Mapped[str] = mapped_column(String(128))
    product_name: Mapped[str] = mapped_column(String(255))
    invested_amount: Mapped[Decimal] = mapped_column(Numeric(20, 4), default=Decimal("0"))
    current_value: Mapped[Decimal] = mapped_column(Numeric(20, 4), default=Decimal("0"))
    return_rate: Mapped[Decimal | None] = mapped_column(Numeric(10, 4), default=None)

    snapshot: Mapped[Snapshot] = relationship(back_populates="investment_entries")


class LoanEntry(TimestampMixin, Base):
    __tablename__ = "snapshot_loan_entries"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    snapshot_id: Mapped[int] = mapped_column(ForeignKey("snapshots.id", ondelete="CASCADE"))
    lender: Mapped[str] = mapped_column(String(128))
    product_name: Mapped[str] = mapped_column(String(255))
    principal: Mapped[Decimal] = mapped_column(Numeric(20, 4), default=Decimal("0"))
    balance: Mapped[Decimal] = mapped_column(Numeric(20, 4), default=Decimal("0"))
    interest_rate: Mapped[Decimal | None] = mapped_column(Numeric(10, 4), default=None)
    start_date: Mapped[_dt.date | None] = mapped_column(Date, default=None)
    end_date: Mapped[_dt.date | None] = mapped_column(Date, default=None)

    snapshot: Mapped[Snapshot] = relationship(back_populates="loan_entries")


class InsuranceEntry(TimestampMixin, Base):
    __tablename__ = "snapshot_insurance_entries"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    snapshot_id: Mapped[int] = mapped_column(ForeignKey("snapshots.id", ondelete="CASCADE"))
    insurer: Mapped[str] = mapped_column(String(128))
    product_name: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(32))
    total_paid: Mapped[Decimal] = mapped_column(Numeric(20, 4), default=Decimal("0"))
    start_date: Mapped[_dt.date | None] = mapped_column(Date, default=None)
    end_date: Mapped[_dt.date | None] = mapped_column(Date, default=None)

    snapshot: Mapped[Snapshot] = relationship(back_populates="insurance_entries")


class LedgerEntry(TimestampMixin, Base):
    __tablename__ = "snapshot_ledger_entries"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    snapshot_id: Mapped[int] = mapped_column(ForeignKey("snapshots.id", ondelete="CASCADE"))
    entry_date: Mapped[_dt.date] = mapped_column(Date)
    entry_time: Mapped[_dt.time | None] = mapped_column(Time, default=None)
    entry_type: Mapped[str] = mapped_column(String(16))
    major_category: Mapped[str] = mapped_column(String(64))
    minor_category: Mapped[str | None] = mapped_column(String(64), default=None)
    description: Mapped[str | None] = mapped_column(String(255), default=None)
    amount: Mapped[Decimal] = mapped_column(Numeric(20, 4))
    currency: Mapped[str] = mapped_column(String(8), default="KRW")
    payment_method: Mapped[str | None] = mapped_column(String(64), default=None)
    memo: Mapped[str | None] = mapped_column(String(255), default=None)

    snapshot: Mapped[Snapshot] = relationship(back_populates="ledger_entries")
