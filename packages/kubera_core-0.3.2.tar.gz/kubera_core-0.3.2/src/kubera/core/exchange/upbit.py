"""Upbit exchange API client."""

from __future__ import annotations

import uuid

import httpx
import jwt

from kubera.api.errors import KuberaError


class UpbitClient:
    BASE_URL = "https://api.upbit.com"

    def __init__(self, access_key: str, secret_key: str):
        self.access_key = access_key
        self.secret_key = secret_key

    def _create_token(self) -> str:
        payload = {
            "access_key": self.access_key,
            "nonce": uuid.uuid4().hex,
        }
        return jwt.encode(payload, self.secret_key, algorithm="HS256")

    def get_accounts(self) -> list[dict]:
        """GET /v1/accounts — returns list of balance dicts."""
        token = self._create_token()
        headers = {"Authorization": f"Bearer {token}"}
        response = httpx.get(
            f"{self.BASE_URL}/v1/accounts",
            headers=headers,
            timeout=10.0,
        )
        if response.status_code != 200:
            raise KuberaError(
                f"Upbit API error: {response.status_code}",
                code="UPBIT_API_ERROR",
                status=502,
            )
        return response.json()
