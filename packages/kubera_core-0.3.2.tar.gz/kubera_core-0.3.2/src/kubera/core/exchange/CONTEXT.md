# exchange

External exchange API integrations. Live balance queries (no DB storage).

## Upbit

- Auth: JWT (HS256) with access_key + uuid4 nonce, signed by secret_key
- Client: `UpbitClient(access_key, secret_key).get_accounts()`
- Endpoint: `GET /api/v1/exchange/upbit/balances`

Credentials stored via `kubera-core credential add upbit` (CLI only).

| Decision | Choice | Reason |
|----------|--------|--------|
| No DB storage | Live-only | Keep simple; snapshot feature can be added later |
| httpx (sync) | Not aiohttp | Sync matches existing SQLAlchemy patterns |
| String balances | Not Decimal | Match Upbit API response format; avoid lossy conversion |
