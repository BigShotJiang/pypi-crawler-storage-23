"""Kubera CLI entry point."""

from __future__ import annotations

import argparse

from importlib.metadata import version as get_version


def main() -> None:
    parser = argparse.ArgumentParser(prog="kubera-core", description="Kubera - Personal asset management")
    parser.add_argument("-V", "--version", action="version", version=f"kubera-core {get_version('kubera-core')}")
    subparsers = parser.add_subparsers(dest="command")

    # kubera-core start
    start_parser = subparsers.add_parser("start", help="Start the server")
    start_parser.add_argument("--host", type=str, default=None, help="Bind host (default: 0.0.0.0)")
    start_parser.add_argument("--port", type=int, default=None, help="Bind port (default: 8000)")
    start_parser.add_argument("--no-mail-watch", action="store_true", help="Disable automatic IMAP mail watcher")

    # kubera-core mail-watch
    subparsers.add_parser("mail-watch", help="Run IMAP mail watcher (foreground)")

    # kubera-core token
    token_parser = subparsers.add_parser("token", help="Show or refresh auth token")
    token_parser.add_argument("--refresh", action="store_true", help="Generate a new token")

    # kubera-core snapshot
    snap_parser = subparsers.add_parser("snapshot", help="Manage financial snapshots")
    snap_sub = snap_parser.add_subparsers(dest="snap_command")

    import_parser = snap_sub.add_parser("import", help="Import Banksalad Excel export")
    import_parser.add_argument("file", type=str, help="Path to .xlsx or .zip file")
    import_parser.add_argument("--password", type=str, default=None, help="ZIP password")
    import_parser.add_argument("--force", action="store_true", help="Overwrite existing snapshot for same file")

    snap_sub.add_parser("list", help="List snapshots")

    # kubera-core credential
    cred_parser = subparsers.add_parser("credential", help="Manage credentials")
    cred_sub = cred_parser.add_subparsers(dest="cred_command")

    cred_add = cred_sub.add_parser("add", help="Add a credential")
    cred_add.add_argument("provider", type=str, help="Provider name (e.g. mail)")

    cred_sub.add_parser("list", help="List credentials")

    cred_remove = cred_sub.add_parser("remove", help="Remove a credential")
    cred_remove.add_argument("provider", type=str, help="Provider name")

    args = parser.parse_args()

    if args.command == "start":
        from kubera.cli.commands import cmd_start
        cmd_start(args)
    elif args.command == "token":
        from kubera.cli.commands import cmd_token
        cmd_token(args)
    elif args.command == "snapshot":
        from kubera.cli.commands import cmd_snapshot
        cmd_snapshot(args)
    elif args.command == "credential":
        from kubera.cli.commands import cmd_credential
        cmd_credential(args)
    elif args.command == "mail-watch":
        from kubera.cli.commands import cmd_mail_watch
        cmd_mail_watch(args)
    else:
        parser.print_help()
