"""CLI subcommands."""

from __future__ import annotations

import argparse
import logging
import os
import sys

GMAIL_IMAP = {"imap_host": "imap.gmail.com", "imap_port": "993"}

PROVIDER_FIELDS: dict[str, list[dict]] = {
    "mail": [
        {"name": "email", "required": True, "prompt": "Gmail address"},
        {"name": "password", "required": True, "prompt": "App password", "secret": True},
        {"name": "zip_password", "required": False, "prompt": "ZIP password", "secret": True},
    ],
    "upbit": [
        {"name": "access_key", "required": True, "prompt": "Upbit Access Key", "secret": True},
        {"name": "secret_key", "required": True, "prompt": "Upbit Secret Key", "secret": True},
    ],
}


def cmd_start(args: argparse.Namespace) -> None:
    """Start the Kubera server."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(name)s  %(message)s",
        datefmt="%H:%M:%S",
    )

    from kubera.core.config import get_settings

    settings = get_settings()
    token = settings.ensure_token()

    host = args.host or settings.host
    port = args.port or settings.port

    # Run Alembic migrations if alembic.ini exists
    _run_migrations(settings.database_url)

    _check_update()

    from importlib.metadata import version as get_version
    current_version = get_version("kubera-core")

    os.system("cls" if os.name == "nt" else "clear")
    print(f"Kubera v{current_version}")
    print(f"Server: http://{host}:{port}")
    print(f"Docs:   http://{host}:{port}/docs")
    print(f"Token:  {token}")

    if not getattr(args, "no_mail_watch", False):
        from kubera.core.credentials import get_credential
        mail_config = get_credential("mail")
        if mail_config is not None:
            import threading
            from kubera.core.models import get_engine, get_session
            from kubera.core.snapshot.mail_watcher import MailWatcher

            engine = get_engine(settings.database_url)
            zip_pw = mail_config.get("zip_password") or settings.snapshot_zip_password
            watcher = MailWatcher(
                db_factory=lambda: get_session(engine),
                imap_config=mail_config,
                zip_password=zip_pw,
            )
            thread = threading.Thread(target=watcher.start, kwargs={"interval": settings.mail_watch_interval}, daemon=True)
            thread.start()
            print(f"Mail watcher enabled (interval: {settings.mail_watch_interval}s)")

    import uvicorn
    from kubera.api.main import create_app

    app = create_app(settings)
    uvicorn.run(app, host=host, port=port)


def cmd_token(args: argparse.Namespace) -> None:
    """Show or refresh the auth token."""
    from kubera.core.config import Settings

    settings = Settings()

    if args.refresh:
        import secrets
        token = secrets.token_urlsafe(32)
        settings.secret_token = token
        settings._write_token_to_env(token)
        print(f"New token: {token}")
    else:
        token = settings.ensure_token()
        print(token)


def cmd_snapshot(args: argparse.Namespace) -> None:
    """Manage financial snapshots."""
    if args.snap_command == "import":
        _cmd_snapshot_import(args)
    elif args.snap_command == "list":
        _cmd_snapshot_list()
    else:
        print("Usage: kubera-core snapshot {import,list}")


def _cmd_snapshot_import(args: argparse.Namespace) -> None:
    """Import a Banksalad Excel export."""
    from pathlib import Path

    from kubera.core.config import Settings
    from kubera.core.models import Base, get_engine, get_session
    from kubera.core.snapshot.service import SnapshotService

    file_path = Path(args.file)
    if not file_path.exists():
        print(f"Error: file not found: {file_path}")
        sys.exit(1)

    settings = Settings()
    engine = get_engine(settings.database_url)
    Base.metadata.create_all(engine)
    session = get_session(engine)
    try:
        svc = SnapshotService(session)
        snapshot = svc.import_from_file(file_path, password=args.password, force=args.force)
        print(f"Imported snapshot: {snapshot.snapshot_date} (source={snapshot.source})")
        print(f"  Credit score: {snapshot.credit_score}")
        print(f"  Total assets: {snapshot.total_assets:,.0f}")
        print(f"  Total liabilities: {snapshot.total_liabilities:,.0f}")
        print(f"  Net worth: {snapshot.net_worth:,.0f}")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
    finally:
        session.close()


def _cmd_snapshot_list() -> None:
    """List snapshots."""
    from kubera.core.config import Settings
    from kubera.core.models import Base, get_engine, get_session
    from kubera.core.snapshot.service import SnapshotService

    settings = Settings()
    engine = get_engine(settings.database_url)
    Base.metadata.create_all(engine)
    session = get_session(engine)
    try:
        svc = SnapshotService(session)
        items, total = svc.list_snapshots()
        if not items:
            print("No snapshots found.")
            return
        print(f"{'Date':<14} {'Source':<12} {'Net Worth':>16} {'Credit':>8}")
        print("-" * 52)
        for s in items:
            credit = str(s.credit_score) if s.credit_score else "-"
            print(f"{s.snapshot_date!s:<14} {s.source:<12} {s.net_worth:>16,.0f} {credit:>8}")
        print(f"\nTotal: {total} snapshot(s)")
    finally:
        session.close()


def cmd_credential(args: argparse.Namespace) -> None:
    """Manage credentials."""
    if args.cred_command == "add":
        _cmd_credential_add(args)
    elif args.cred_command == "list":
        _cmd_credential_list()
    elif args.cred_command == "remove":
        _cmd_credential_remove(args)
    else:
        print("Usage: kubera-core credential {add,list,remove}")


def _cmd_credential_add(args: argparse.Namespace) -> None:
    """Interactively add a credential for a provider."""
    import getpass

    provider = args.provider
    if provider not in PROVIDER_FIELDS:
        print(f"Error: unsupported provider '{provider}'. Supported: {', '.join(PROVIDER_FIELDS)}")
        sys.exit(1)

    fields = PROVIDER_FIELDS[provider]
    credential: dict[str, str] = {"provider": provider}

    # Mail provider: Gmail-only flow
    if provider == "mail":
        credential["imap_host"] = GMAIL_IMAP["imap_host"]
        credential["imap_port"] = GMAIL_IMAP["imap_port"]
        credential["sender_filter"] = "banksalad"

        print()
        addr = input("Enter Gmail address: ").strip()
        if not addr:
            print("\nError: email is required.")
            sys.exit(1)
        if not addr.lower().endswith("@gmail.com"):
            print("\nError: only Gmail addresses (@gmail.com) are supported.")
            sys.exit(1)
        credential["email"] = addr
        print()

        print("  Generate app password here:")
        print("  https://myaccount.google.com/apppasswords")
        print("  App name: kubera-core")
        print()
        password = getpass.getpass("Enter app password: ")
        if not password:
            print("\nError: password is required.")
            sys.exit(1)
        credential["password"] = password
        print(f"  -> {len(password)} chars")
        print()

        zip_pw = getpass.getpass("Enter Banksalad ZIP password: ")
        if zip_pw:
            credential["zip_password"] = zip_pw
            print(f"  -> {len(zip_pw)} chars")
        else:
            print("  -> skipped (no ZIP password)")
        print()
    else:
        for field in fields:
            default = field.get("default")
            prompt = field["prompt"]
            if default:
                prompt = f"{prompt} [{default}]"
            prompt += ": "
            if field.get("secret"):
                value = getpass.getpass(prompt)
                if value:
                    print(f"  -> {len(value)} chars")
            else:
                value = input(prompt)
            if not value and default is not None:
                value = default
            if field["required"] and not value:
                print(f"Error: '{field['name']}' is required.")
                sys.exit(1)
            if value:
                credential[field["name"]] = value

    # Mail provider: verify IMAP connection before saving
    if provider == "mail":
        import imaplib

        host = credential.get("imap_host", "")
        port = int(credential.get("imap_port", "993"))
        email = credential.get("email", "")
        password = credential.get("password", "")

        print("Verifying connection...", end=" ", flush=True)
        try:
            imap = imaplib.IMAP4_SSL(host, port)
            imap.login(email, password)
            imap.logout()
            print("OK")
        except Exception as e:
            print(f"FAILED\nError: {e}")
            sys.exit(1)

    from kubera.core.credentials import save_credential
    save_credential(credential)
    print(f"\nCredential for '{provider}' saved.")


def _cmd_credential_list() -> None:
    """List saved credentials."""
    from kubera.core.credentials import load_credentials

    credentials = load_credentials()
    if not credentials:
        print("No credentials stored.")
        return

    secret_fields = set()
    for fields in PROVIDER_FIELDS.values():
        for f in fields:
            if f.get("secret"):
                secret_fields.add(f["name"])

    print(f"{'Provider':<12} {'Key':<20} {'Value'}")
    print("-" * 50)
    for cred in credentials:
        provider = cred.get("provider", "")
        for key, value in cred.items():
            if key == "provider":
                continue
            display = "***" if key in secret_fields else value
            print(f"{provider:<12} {key:<20} {display}")
            provider = ""  # only show provider on first row


def _cmd_credential_remove(args: argparse.Namespace) -> None:
    """Remove credentials for a provider."""
    from kubera.core.credentials import remove_credential

    provider = args.provider
    if not remove_credential(provider):
        print(f"No credential found for provider '{provider}'.")
        sys.exit(1)
    print(f"Credential for '{provider}' removed.")


def cmd_mail_watch(args: argparse.Namespace) -> None:
    """Run IMAP mail watcher in foreground."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(name)s  %(message)s",
        datefmt="%H:%M:%S",
    )

    from kubera.core.config import get_settings
    from kubera.core.credentials import get_credential
    from kubera.core.models import get_engine, get_session
    from kubera.core.snapshot.mail_watcher import MailWatcher

    mail_config = get_credential("mail")
    if mail_config is None:
        print("Error: no mail credential configured.")
        print("Run 'kubera-core credential add mail' first.")
        sys.exit(1)

    settings = get_settings()
    engine = get_engine(settings.database_url)

    zip_pw = mail_config.get("zip_password") or settings.snapshot_zip_password
    watcher = MailWatcher(
        db_factory=lambda: get_session(engine),
        imap_config=mail_config,
        zip_password=zip_pw,
    )

    print(f"Starting mail watcher (interval: {settings.mail_watch_interval}s)")
    print("Press Ctrl+C to stop.")
    try:
        watcher.start(interval=settings.mail_watch_interval)
    except KeyboardInterrupt:
        watcher.stop()
        print("\nMail watcher stopped.")



def _check_update() -> None:
    """Check PyPI for a newer version and print a notice if available."""
    try:
        from importlib.metadata import version as get_version

        import httpx

        current = get_version("kubera-core")
        resp = httpx.get("https://pypi.org/pypi/kubera-core/json", timeout=3.0)
        if resp.status_code != 200:
            return
        latest = resp.json()["info"]["version"]
        if latest != current:
            print(f"Update available: {current} -> {latest}")
            print("Run 'uv tool upgrade kubera-core' to update.\n")
    except Exception:
        pass


def _run_migrations(database_url: str) -> None:
    """Run Alembic migrations if configured."""
    from pathlib import Path

    if not Path("alembic.ini").exists():
        return

    try:
        from alembic.config import Config
        from alembic import command

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", database_url)
        command.upgrade(alembic_cfg, "head")
    except Exception:
        # If no migrations exist yet, just skip
        pass
