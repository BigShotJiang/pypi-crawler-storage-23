# kubera-core

Personal asset management backend, distributed via PyPI.

## Release

Trigger: GitHub Release creation → `publish.yml` → PyPI upload (Trusted Publisher)

Steps:
1. Bump `version` in `pyproject.toml`
2. Commit and push
3. `gh release create v{version}` (or create via GitHub UI)

PyPI package: https://pypi.org/project/kubera-core/

## Versioning

Independent semver. API URL version (`/api/v1/`) is the cross-repo contract.

| Decision | Choice | Reason |
|----------|--------|--------|
| Package registry | PyPI | `pip install kubera-core` one-liner |
| Build backend | hatchling | Minimal config, PEP 621 native |
| CI publish | Trusted Publisher (OIDC) | No API tokens to manage |
| Tunnel | Cloudflare Tunnel (user-managed) | Zero dependency on kubera-core code |
