"""Change snapshot_date from Date to DateTime for intraday granularity.

Revision ID: 001
Create Date: 2026-02-22
"""

from alembic import op
import sqlalchemy as sa

revision = "001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # SQLite does not support ALTER COLUMN; use batch mode to recreate the table.
    with op.batch_alter_table("snapshots") as batch_op:
        batch_op.alter_column(
            "snapshot_date",
            existing_type=sa.Date(),
            type_=sa.DateTime(),
            existing_nullable=False,
        )


def downgrade() -> None:
    with op.batch_alter_table("snapshots") as batch_op:
        batch_op.alter_column(
            "snapshot_date",
            existing_type=sa.DateTime(),
            type_=sa.Date(),
            existing_nullable=False,
        )
