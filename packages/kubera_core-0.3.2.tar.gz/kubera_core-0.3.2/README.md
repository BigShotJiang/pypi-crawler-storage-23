# Kubera Core

Personal asset management backend. All financial data stays on your machine.

## Install & Run

```bash
pip install pipx
pipx ensurepath     # restart terminal after this
pipx install kubera-core
kubera-core start
```

Or with pip:

```bash
pip install kubera-core
```

- API docs: http://localhost:8000/docs
- Auth token is auto-generated and printed on first start

## Options

```bash
kubera-core start --host 127.0.0.1 --port 3000
kubera-core token                    # show current token
kubera-core token --refresh          # generate new token
```

## Credential Management

API keys for financial services are managed via CLI only (never through web).

```bash
kubera-core credential add upbit     # interactive masked input
kubera-core credential list          # show status
kubera-core credential remove upbit
```

Supported providers: upbit, kis, binance, codef

## Remote Access

Expose your local server to the internet using [Cloudflare Tunnel](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/) (free, no account required):

```bash
# install cloudflared (one-time)
# Windows: winget install cloudflare.cloudflared
# macOS:   brew install cloudflared
# Linux:   https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/

# start tunnel (run alongside kubera-core)
cloudflared tunnel --url http://localhost:8000
```

The command prints a public URL like `https://xxx.trycloudflare.com`. Use this as the API server address in kubera-web.

## Tech Stack

FastAPI, SQLAlchemy (SQLite), Pydantic, cryptography (Fernet)

## Related

- [kubera-web](https://github.com/oh-my-kubera/kubera-web) — Next.js dashboard (PWA)

## License

MIT
