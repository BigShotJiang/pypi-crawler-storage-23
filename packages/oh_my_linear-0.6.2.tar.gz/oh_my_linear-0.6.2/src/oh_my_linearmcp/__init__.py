"""Compatibility package for running OhMyLinear by distribution-aligned module name."""

from oh_my_linear import main

__all__ = ["main"]
