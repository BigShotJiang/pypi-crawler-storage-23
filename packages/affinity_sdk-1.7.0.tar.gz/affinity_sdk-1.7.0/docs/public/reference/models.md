# Models

::: affinity.models

## FieldResolver

::: affinity.field_resolver.FieldResolver
