"""
Affinity CLI (optional).

This package is only intended to be used when installing `affinity-sdk[cli]`.
"""

from __future__ import annotations

from .main import cli

__all__ = ["cli"]
