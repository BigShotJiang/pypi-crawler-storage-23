
---

## Installation

### One-click install (Claude Desktop)
Download `xaffinity-mcp-*.mcpb` and double-click or drag to Claude Desktop.

### Claude Code
```bash
/plugin marketplace add yaniv-golan/affinity-sdk
/plugin install mcp@xaffinity
```

### Manual configuration
Download `xaffinity-mcp-plugin.zip` and configure your MCP client manually.
See [documentation](https://yaniv-golan.github.io/affinity-sdk/latest/mcp/) for details.
