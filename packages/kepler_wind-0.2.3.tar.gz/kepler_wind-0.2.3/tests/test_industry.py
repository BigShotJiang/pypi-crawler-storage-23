"""
行业 API 测试
"""

import pytest
from kepler.wind import Wind


@pytest.fixture(scope="module")
def w():
    """Wind 实例"""
    return Wind()


class TestIndustryAPI:
    """A股行业 API 测试"""

    def test_on_level1(self, w):
        """测试 level=1 行业查询"""
        df = w.industry.on("20240101", level=1)
        assert len(df) > 0
        assert "ind" in df.columns
        # 检查常见行业
        industries = df["ind"].tolist()
        assert "银行" in industries or "房地产" in industries

    def test_on_level2(self, w):
        """测试 level=2 行业查询"""
        df = w.industry.on("20240101", level=2)
        assert len(df) > 0
        assert "ind" in df.columns
        # level=2 应该有更细分的行业
        industries = df["ind"].tolist()
        assert any("银行" in ind or "房地产" in ind for ind in industries)

    def test_of_single_stock(self, w):
        """测试单只股票行业查询"""
        df = w.industry.of("000001.SZ", date="20240101")
        assert len(df) == 1
        assert df.loc["000001.SZ", "ind"] == "银行"

    def test_of_multiple_stocks(self, w):
        """测试多只股票行业查询"""
        df = w.industry.of(["000001.SZ", "000002.SZ"], date="20240101")
        assert len(df) == 2
        assert df.loc["000001.SZ", "ind"] == "银行"
        assert df.loc["000002.SZ", "ind"] == "房地产"

    def test_date_filter(self, w):
        """测试日期过滤"""
        # 000004.SZ 在 20221212 从医药变更为计算机
        df1 = w.industry.of("000004.SZ", date="20221201")
        assert df1.loc["000004.SZ", "ind"] == "医药"

        df2 = w.industry.of("000004.SZ", date="20221213")
        assert df2.loc["000004.SZ", "ind"] == "计算机"


class TestIndustryHKAPI:
    """港股行业 API 测试"""

    def test_on_zx(self, w):
        """测试港股中信行业查询"""
        df = w.industry_hk.on("20240101", source="zx")
        assert len(df) > 0
        assert "ind" in df.columns

    def test_on_wind_level1(self, w):
        """测试港股Wind一级行业查询"""
        df = w.industry_hk.on("20240101", source="wind", level=1)
        assert len(df) > 0
        assert "ind" in df.columns

    def test_on_wind_level2(self, w):
        """测试港股Wind二级行业查询"""
        df = w.industry_hk.on("20240101", source="wind", level=2)
        assert len(df) > 0
        assert "ind" in df.columns

    def test_of_single_stock(self, w):
        """测试单只港股行业查询"""
        df = w.industry_hk.of("0001.HK", date="20240101")
        assert len(df) == 1
        assert "ind" in df.columns

    def test_of_multiple_stocks(self, w):
        """测试多只港股行业查询"""
        df = w.industry_hk.of(["0001.HK", "0005.HK"], date="20240101")
        assert len(df) == 2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
