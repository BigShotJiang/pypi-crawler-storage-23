"""
交易日历模块

提供 A 股和港股的交易日历功能。
"""

from typing import Optional

from kepler.pulse import Calendar


class CalendarAPI:
    """交易日历 API

    提供 A 股和港股的交易日历功能。
    """

    def __init__(self, db):
        self.db = db
        self._cn_calendar: Optional[Calendar] = None
        self._hk_calendar: Optional[Calendar] = None

    def _load_cn_trade_dates(self):
        """加载 A 股交易日"""
        table = self.db.asharecalendar
        df = self.db.query(
            table.trade_days.label('t')
        ).filter(
            table.s_info_exchmarket == 'SSE'
        ).order_by(
            table.trade_days
        ).to_df()
        return df['t'].to_list()

    def _load_hk_trade_dates(self):
        """加载港股交易日"""
        table = self.db.hkexcalendar
        df = self.db.query(
            table.trade_days.label('t')
        ).filter(
            table.s_info_exchmarket == 'HKEX'
        ).order_by(
            table.trade_days
        ).to_df()
        return df['t'].to_list()

    @property
    def cn(self) -> Calendar:
        """A 股日历"""
        if self._cn_calendar is None:
            self._cn_calendar = Calendar(self._load_cn_trade_dates())
        return self._cn_calendar

    @property
    def hk(self) -> Calendar:
        """港股日历"""
        if self._hk_calendar is None:
            self._hk_calendar = Calendar(self._load_hk_trade_dates())
        return self._hk_calendar

    # 便捷方法：直接访问 A 股日历
    def __getattr__(self, name):
        return getattr(self.cn, name)

    def __repr__(self):
        return f"CalendarAPI(cn={self.cn}, hk={self.hk})"


__all__ = ['CalendarAPI']
