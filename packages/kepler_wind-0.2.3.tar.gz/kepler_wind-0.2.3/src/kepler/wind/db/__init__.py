"""
数据库配置模块

提供 Wind 数据库连接。
"""

from pathlib import Path
from typing import Any, Dict, Optional

import tomllib
from kepler.atlas import DataBase
from sqlalchemy import create_engine


class ConfigManager:
    """配置管理器"""

    def __init__(self, config_dir: Optional[str] = None):
        self.config_dir = Path(config_dir) if config_dir else Path.home() / ".kepler" / "wind"
        self.config_file = self.config_dir / "wind.toml"
        self._config = None

    @property
    def config(self) -> Optional[Dict[str, Any]]:
        if self._config is None:
            self._config = self._load_config()
        return self._config

    def _load_config(self) -> Optional[Dict[str, Any]]:
        if not self.config_file.exists():
            return None
        try:
            with open(self.config_file, 'rb') as f:
                return tomllib.load(f)
        except (IOError, tomllib.TOMLDecodeError) as e:
            raise ValueError(f"Failed to load config file {self.config_file}: {e}")

    def get_database_config(self) -> Optional[Dict[str, Optional[str]]]:
        section = self.config.get("wind") if self.config else None
        if section is None:
            return None
        schema = section.get('schema', '') or None
        return {
            'engine': section.get('engine'),
            'schema': schema
        }


# 全局数据库连接（延迟初始化）
_db: Optional[DataBase] = None


def set_db(db: DataBase) -> None:
    """设置全局数据库连接"""
    global _db
    _db = db


def init_db(url: str, schema: Optional[str] = None) -> DataBase:
    """初始化数据库连接

    Args:
        url: 数据库连接URL，如 "mysql+pymysql://user:pass@host:3306/db"
        schema: 数据库schema，MySQL 通常为 None，PostgreSQL 为 "public"

    Returns:
        DataBase 实例
    """
    global _db
    _db = DataBase(create_engine(url), schema)
    return _db


def get_db(url: Optional[str] = None, schema: Optional[str] = None) -> DataBase:
    """获取数据库连接

    优先级：
    1. 传入的 url 参数
    2. 已通过 init_db() 设置的连接
    3. 配置文件 ~/.kepler/wind/wind.toml

    Raises:
        ValueError: 当没有配置时
    """
    global _db

    # 优先使用传入的 url
    if url is not None:
        return DataBase(create_engine(url), schema)

    # 使用已初始化的连接
    if _db is not None:
        return _db

    # 尝试从配置文件加载
    config = ConfigManager()
    db_config = config.get_database_config()

    if db_config and db_config['engine']:
        _db = DataBase(create_engine(db_config['engine']), db_config['schema'])
        return _db

    # 没有配置，报错
    config_path = config.config_file
    raise ValueError(
        f"数据库未配置。请设置配置文件 {config_path}:\n"
        f"```toml\n"
        f"[wind]\n"
        f"engine = \"mysql+pymysql://user:pass@host:3306/db\"\n"
        f"schema = \"\"  # MySQL 留空，PostgreSQL 填 \"public\"\n"
        f"```\n"
        f"或在 Wind 初始化时传入 url 参数:\n"
        f"  w = Wind(url='mysql+pymysql://user:pass@host:3306/db')"
    )


__all__ = ['ConfigManager', 'init_db', 'get_db', 'set_db']
