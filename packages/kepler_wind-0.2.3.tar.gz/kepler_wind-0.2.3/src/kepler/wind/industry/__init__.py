"""
行业模块

提供行业分类的截面和时序查询功能。

Examples:
    >>> from kepler.wind import Wind
    >>> w = Wind()
    >>> w.industry.on("20240101")                  # 截面：某日所有股票行业
    >>> w.industry.of("000001.SZ")                 # 单股行业
"""

import re
from functools import lru_cache
from typing import Optional, Union, List, Set

import pandas as pd
from sqlalchemy import func


class IndustryAPI:
    """A股行业 API

    提供行业分类的截面和时序查询功能。
    """

    # 类级别的正则表达式，去除非中文字符
    CHINESE_PATTERN = re.compile(r"[^\u4e00-\u9fa5]")

    def __init__(self, db):
        self.db = db

    def on(
        self,
        date: str,
        sid: Optional[Union[str, List[str], Set[str]]] = None,
        level: int = 1,
        source: str = "zx"
    ) -> pd.DataFrame:
        """截面：某日所有股票的行业分类

        Args:
            date: 交易日期
            sid: 股票代码（可选，用于筛选）
            level: 行业级别 (1, 2, 3)
            source: 数据源 ("zx" 中信, "wind" Wind)

        Returns:
            DataFrame: sid → industry

        Examples:
            >>> w.industry.on("20240101")
            >>> w.industry.on("20240101", level=2)
        """
        date = str(date).replace("-", "")

        if source == "zx":
            return self._get_zx_industry(date, sid, level)
        elif source == "wind":
            return self._get_wind_industry(date, sid, level)
        else:
            raise ValueError(f"Unknown source: {source}")

    def of(
        self,
        sid: Union[str, List[str], Set[str]],
        date: Optional[str] = None,
        level: int = 1,
        source: str = "zx"
    ) -> pd.DataFrame:
        """获取股票的行业分类

        Args:
            sid: 股票代码
            date: 交易日期，None 表示当前
            level: 行业级别
            source: 数据源

        Returns:
            DataFrame

        Examples:
            >>> w.industry.of("000001.SZ")
            >>> w.industry.of("000001.SZ", date="20240101")
        """
        if date is None:
            date = "20990101"
        return self.on(date, sid=sid, level=level, source=source)

    def _get_zx_industry(
        self,
        date: str,
        sid: Optional[Union[str, List[str], Set[str]]],
        level: int
    ) -> pd.DataFrame:
        """中信行业分类"""
        df = self._get_zx_all(level).copy()

        # 过滤日期
        df = df.loc[
            (df["entry_dt"] <= date) &
            ((df["out_dt"] >= date) | (df["out_dt"].isnull()))
        ]

        # 过滤股票
        if sid is not None:
            if isinstance(sid, str):
                sid = {sid}
            else:
                sid = set(sid)
            df = df[df["sid"].isin(sid)]

        return df.set_index("sid")[["ind"]].copy()

    @lru_cache(maxsize=4)
    def _get_zx_all(self, level: int) -> pd.DataFrame:
        """获取所有中信行业数据

        中信行业代码格式：
        - 分类表: b101010100 (8位小写)
        - 代码表: b101000000000000 (16位小写)
        level 1 匹配前4位，level 2 匹配前6位，level 3 匹配前8位
        """
        table = self.db.ashareindustriesclasscitics
        code_table = self.db.ashareindustriescode

        # 中信行业代码以 b1 开头
        prefix_len = 2 + 2 * level  # 4, 6, 8

        df = self.db.query(
            table.s_info_windcode.label("sid"),
            table.entry_dt,
            table.remove_dt.label("out_dt"),
            code_table.industriesname.label("ind")
        ).filter(
            code_table.levelnum == level + 1,
            func.substr(table.citics_ind_code, 1, prefix_len) == func.substr(code_table.industriescode, 1, prefix_len),
            code_table.industriescode.like("b1%")
        ).to_df()

        # 去除行业名称中的非中文字符（如罗马数字）
        df["ind"] = df["ind"].str.replace(self.CHINESE_PATTERN, "", regex=True)

        return df

    def _get_wind_industry(
        self,
        date: str,
        sid: Optional[Union[str, List[str], Set[str]]],
        level: int
    ) -> pd.DataFrame:
        """Wind行业分类"""
        df = self._get_wind_all(level).copy()

        # 过滤日期
        df = df.loc[
            (df["entry_dt"] <= date) &
            ((df["out_dt"] >= date) | (df["out_dt"].isnull()))
        ]

        # 过滤股票
        if sid is not None:
            if isinstance(sid, str):
                sid = {sid}
            else:
                sid = set(sid)
            df = df[df["sid"].isin(sid)]

        return df.set_index("sid")[["ind"]].copy()

    @lru_cache(maxsize=4)
    def _get_wind_all(self, level: int) -> pd.DataFrame:
        """获取所有Wind行业数据

        Wind行业代码格式：
        - 分类表: wind_ind_code
        - 代码表: industriescode
        """
        table = self.db.ashareindustriesclass
        code_table = self.db.ashareindustriescode

        prefix_len = 2 + 2 * level

        df = self.db.query(
            table.s_info_windcode.label("sid"),
            table.entry_dt,
            table.remove_dt.label("out_dt"),
            code_table.industriesname.label("ind")
        ).filter(
            code_table.levelnum == level,
            func.substr(table.wind_ind_code, 1, prefix_len) == func.substr(code_table.industriescode, 1, prefix_len),
            code_table.industriescode.like("04%")  # Wind行业分类以04开头
        ).to_df()

        # 去除行业名称中的非中文字符
        df["ind"] = df["ind"].str.replace(self.CHINESE_PATTERN, "", regex=True)

        return df


class IndustryHKAPI:
    """港股行业 API"""

    CHINESE_PATTERN = re.compile(r"[^\u4e00-\u9fa5]")

    def __init__(self, db):
        self.db = db

    def on(
        self,
        date: str,
        sid: Optional[Union[str, List[str], Set[str]]] = None,
        level: int = 2,
        source: str = "zx"
    ) -> pd.DataFrame:
        """截面：某日所有港股的行业分类

        Args:
            date: 交易日期
            sid: 股票代码（可选）
            level: 行业级别 (1, 2, 3)，仅 Wind 行业有效
            source: 数据源 ("zx" 中信, "wind" Wind)

        Returns:
            DataFrame: sid → industry
        """
        date = str(date).replace("-", "")

        if source == "zx":
            return self._get_hk_citics_industry(date, sid)
        elif source == "wind":
            return self._get_hk_wind_industry(date, sid, level)
        else:
            raise ValueError(f"Unknown source: {source}")

    def of(
        self,
        sid: Union[str, List[str], Set[str]],
        date: Optional[str] = None,
        level: int = 2,
        source: str = "zx"
    ) -> pd.DataFrame:
        """获取港股的行业分类

        Args:
            sid: 股票代码
            date: 交易日期，None 表示当前
            level: 行业级别 (1, 2, 3)，仅 Wind 行业有效
            source: 数据源 ("zx" 中信, "wind" Wind)

        Returns:
            DataFrame
        """
        if date is None:
            date = "20990101"
        return self.on(date, sid=sid, level=level, source=source)

    def _get_hk_citics_industry(
        self,
        date: str,
        sid: Optional[Union[str, List[str], Set[str]]]
    ) -> pd.DataFrame:
        """港股中信行业分类"""
        df = self._get_hk_citics_all().copy()

        # 过滤股票
        if sid is not None:
            if isinstance(sid, str):
                sid = {sid}
            else:
                sid = set(sid)
            df = df[df["sid"].isin(sid)]

        # 过滤日期：取每个股票在指定日期之前最新的行业
        df = df[df["change_dt"] <= date].copy()
        df.sort_values(["sid", "change_dt"], inplace=True)
        df.drop_duplicates("sid", keep="last", inplace=True)

        return df.set_index("sid")[["ind"]].copy()

    @lru_cache(maxsize=1)
    def _get_hk_citics_all(self) -> pd.DataFrame:
        """获取所有港股中信行业数据"""
        table = self.db.hksharesciticsindustriesclass

        df = self.db.query(
            table.s_info_windcode.label("sid"),
            table.change_dt,
            table.citics_ind_name.label("ind")
        ).filter(
            table.change_type == 1  # 只取入行记录
        ).to_df()

        # 去除行业名称后缀（如"（中信）"）
        df["ind"] = df["ind"].str.slice(0, -7)
        # 去除非中文字符
        df["ind"] = df["ind"].str.replace(self.CHINESE_PATTERN, "", regex=True)

        return df

    def _get_hk_wind_industry(
        self,
        date: str,
        sid: Optional[Union[str, List[str], Set[str]]],
        level: int = 1
    ) -> pd.DataFrame:
        """港股Wind行业分类"""
        df = self._get_hk_wind_all(level).copy()

        # 过滤日期
        df = df.loc[
            (df["entry_dt"] <= date) &
            ((df["out_dt"] >= date) | (df["out_dt"].isnull()))
        ]

        # 过滤股票
        if sid is not None:
            if isinstance(sid, str):
                sid = {sid}
            else:
                sid = set(sid)
            df = df[df["sid"].isin(sid)]

        # 去重：一个股票可能有多条有效记录，按 entry_dt 排序取最新
        df.sort_values(["sid", "entry_dt"], inplace=True)
        df.drop_duplicates("sid", keep="last", inplace=True)

        return df.set_index("sid")[["ind"]].copy()

    @lru_cache(maxsize=4)
    def _get_hk_wind_all(self, level: int) -> pd.DataFrame:
        """获取所有港股Wind行业数据

        Wind港股行业代码格式：10位数字，以62开头
        使用与 sangreal_wind 相同的 prefix_len 计算方式
        只保留标准港股股票代码（4位数字 + .HK）
        """
        table = self.db.hkstockwindindustriesmembers
        code_table = self.db.hkstockindustriescode

        # 与 sangreal_wind 保持一致
        prefix_len = 2 + 2 * level  # level 1 = 4, level 2 = 6, level 3 = 8

        df = self.db.query(
            table.s_info_windcode.label("sid"),
            table.entry_dt,
            table.remove_dt.label("out_dt"),
            code_table.industriesname.label("ind")
        ).filter(
            code_table.levelnum == level,
            code_table.industriesclass == "Wind行业分类",
            func.substr(table.wind_ind_code, 1, prefix_len) == func.substr(code_table.industriescode, 1, prefix_len),
            # 只保留标准港股股票代码（4位数字 + .HK = 7位）
            func.length(table.s_info_windcode) == 7
        ).to_df()

        # 去除非中文字符
        df["ind"] = df["ind"].str.replace(self.CHINESE_PATTERN, "", regex=True)

        return df


__all__ = ['IndustryAPI', 'IndustryHKAPI']
