"""Core engine — snapshot, schema validation, DOM diffing, drift tracking, and classification."""
