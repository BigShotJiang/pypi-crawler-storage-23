"""Click-based CLI interface for ScraperGuard."""
