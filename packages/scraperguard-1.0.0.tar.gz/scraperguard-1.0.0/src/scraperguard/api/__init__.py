"""FastAPI-based REST API — health reports, drift data, and dashboard endpoints."""

from scraperguard.api.app import create_app

__all__ = ["create_app"]
