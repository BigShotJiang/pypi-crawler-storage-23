"""Syrin CLI entry point for `python -m syrin`."""

import sys

from syrin.cli import main

if __name__ == "__main__":
    sys.exit(main())
