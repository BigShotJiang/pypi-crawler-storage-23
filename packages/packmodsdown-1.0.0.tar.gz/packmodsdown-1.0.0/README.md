# PackModsDown

Batch download mods from CurseForge modpack zip files.

## Install

```bash
pip install packmodsdown
```

## Usage

```bash
pmd -m <modpack.zip> -o <output_dir> -k <api_key>
```

Or use the full name:

```bash
packmodsdown -m <modpack.zip> -o <output_dir> -k <api_key> [-c <concurrency>]
```

## Options

| Flag                | Description              | Default  |
| ------------------- | ------------------------ | -------- |
| `-m, --modpack`     | Path to modpack `.zip`   | required |
| `-o, --output`      | Output directory         | `./mods` |
| `-k, --api-key`     | CurseForge API key       | required |
| `-c, --concurrency` | Max concurrent downloads | `10`     |
