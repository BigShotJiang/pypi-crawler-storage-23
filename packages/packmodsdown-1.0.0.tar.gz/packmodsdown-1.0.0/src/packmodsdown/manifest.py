"""
Parse CurseForge modpack zip files and extract manifest information.
"""

from __future__ import annotations

import json
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class ModFileEntry:
    """
    Represents a single mod file entry from the manifest.

    Args:
        project_id: The CurseForge project (mod) ID.
        file_id: The CurseForge file ID.
        required: Whether this mod is required by the modpack.
    """

    project_id: int
    file_id: int
    required: bool = True


@dataclass(frozen=True)
class ModpackManifest:
    """
    Parsed CurseForge modpack manifest data.

    Args:
        name: Modpack display name.
        version: Modpack version string.
        author: Modpack author.
        minecraft_version: Target Minecraft version.
        mod_loaders: List of mod loader descriptors (e.g. forge-47.3.0).
        files: List of mod file entries to download.
        overrides: Name of the overrides directory inside the zip.
    """

    name: str
    version: str
    author: str
    minecraft_version: str
    mod_loaders: list[str] = field(default_factory=list)
    files: list[ModFileEntry] = field(default_factory=list)
    overrides: str = "overrides"


def parse_manifest(modpack_path: str | Path) -> ModpackManifest:
    """
    Extract and parse manifest.json from a CurseForge modpack zip.

    Args:
        modpack_path: Path to the modpack .zip file.

    Returns:
        A ModpackManifest containing all parsed data.

    Raises:
        FileNotFoundError: If the modpack file does not exist.
        KeyError: If manifest.json is not found inside the zip.
        ValueError: If the manifest JSON is malformed.
    """
    modpack_path = Path(modpack_path)
    if not modpack_path.exists():
        raise FileNotFoundError(f"Modpack file not found: {modpack_path}")

    with zipfile.ZipFile(modpack_path, "r") as zf:
        manifest_name = _find_manifest(zf)
        raw: dict[str, Any] = json.loads(zf.read(manifest_name))

    return _build_manifest(raw)


def _find_manifest(zf: zipfile.ZipFile) -> str:
    """
    Locate manifest.json inside the zip archive.

    Args:
        zf: An opened ZipFile object.

    Returns:
        The archive-internal path to manifest.json.

    Raises:
        KeyError: If no manifest.json is found.
    """
    for name in zf.namelist():
        basename = name.rsplit("/", 1)[-1] if "/" in name else name
        if basename.lower() == "manifest.json":
            return name
    raise KeyError("manifest.json not found in modpack archive")


def _build_manifest(raw: dict[str, Any]) -> ModpackManifest:
    """
    Convert raw JSON dict into a ModpackManifest dataclass.

    Args:
        raw: Parsed JSON from manifest.json.

    Returns:
        A populated ModpackManifest.

    Raises:
        ValueError: If required fields are missing.
    """
    minecraft_block = raw.get("minecraft", {})
    mc_version = minecraft_block.get("version", "unknown")

    mod_loaders: list[str] = []
    for loader in minecraft_block.get("modLoaders", []):
        loader_id = loader.get("id", "")
        if loader_id:
            mod_loaders.append(loader_id)

    files: list[ModFileEntry] = []
    for entry in raw.get("files", []):
        project_id = entry.get("projectID")
        file_id = entry.get("fileID")
        if project_id is None or file_id is None:
            continue
        files.append(
            ModFileEntry(
                project_id=int(project_id),
                file_id=int(file_id),
                required=bool(entry.get("required", True)),
            )
        )

    if not files:
        raise ValueError("Manifest contains no mod file entries")

    return ModpackManifest(
        name=raw.get("name", "Unknown Modpack"),
        version=raw.get("version", "0.0.0"),
        author=raw.get("author", "Unknown"),
        minecraft_version=mc_version,
        mod_loaders=mod_loaders,
        files=files,
        overrides=raw.get("overrides", "overrides"),
    )
