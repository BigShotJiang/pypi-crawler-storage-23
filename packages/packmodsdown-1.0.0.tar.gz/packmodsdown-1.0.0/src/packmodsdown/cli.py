"""
CLI entry point for the CurseForge modpack mod downloader.
"""

from __future__ import annotations

import argparse
import asyncio
import sys

from packmodsdown.downloader import download_modpack


def main() -> None:
    """
    Parse command-line arguments and launch the modpack download process.
    """
    parser = argparse.ArgumentParser(
        prog="pmd",
        description="Download all mods from a CurseForge modpack zip file.",
    )
    parser.add_argument(
        "-m",
        "--modpack",
        required=True,
        help="Path to the CurseForge modpack .zip file.",
    )
    parser.add_argument(
        "-o",
        "--output",
        default="./mods",
        help="Output directory for downloaded mod files (default: ./mods).",
    )
    parser.add_argument(
        "-k",
        "--api-key",
        required=True,
        help="CurseForge API key for authentication.",
    )
    parser.add_argument(
        "-c",
        "--concurrency",
        type=int,
        default=10,
        help="Maximum number of concurrent downloads (default: 10).",
    )
    args = parser.parse_args()

    try:
        asyncio.run(
            download_modpack(
                modpack_path=args.modpack,
                output_dir=args.output,
                api_key=args.api_key,
                max_concurrency=args.concurrency,
            )
        )
    except FileNotFoundError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    except KeyError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nDownload cancelled by user.", file=sys.stderr)
        sys.exit(130)


if __name__ == "__main__":
    main()
