"""
Async CurseForge API client using httpx.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx

BASE_URL = "https://api.curseforge.com"


@dataclass(frozen=True)
class FileInfo:
    """
    Metadata for a single mod file returned by the CurseForge API.

    Args:
        file_id: The file ID.
        mod_id: The parent mod (project) ID.
        display_name: Human-readable file display name.
        file_name: Actual filename for download.
        download_url: Direct download URL, may be None if restricted.
    """

    file_id: int
    mod_id: int
    display_name: str
    file_name: str
    download_url: str | None


class CurseForgeClient:
    """
    Async HTTP client for the CurseForge API.

    Args:
        api_key: CurseForge API key for authentication.
        timeout: Request timeout in seconds.
    """

    def __init__(self, api_key: str, timeout: float = 30.0) -> None:
        self._client = httpx.AsyncClient(
            base_url=BASE_URL,
            headers={
                "x-api-key": api_key,
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )

    async def close(self) -> None:
        """
        Close the underlying HTTP client.
        """
        await self._client.aclose()

    async def __aenter__(self) -> CurseForgeClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def get_files(self, file_ids: list[int]) -> list[FileInfo]:
        """
        Batch-fetch file metadata via POST /v1/mods/files.

        Args:
            file_ids: List of CurseForge file IDs to look up.

        Returns:
            List of FileInfo objects with download metadata.

        Raises:
            httpx.HTTPStatusError: On non-2xx responses.
        """
        resp = await self._client.post(
            "/v1/mods/files",
            json={"fileIds": file_ids},
        )
        resp.raise_for_status()
        data: list[dict[str, Any]] = resp.json().get("data", [])
        return [_parse_file_info(item) for item in data]

    async def get_mod_file_download_url(self, mod_id: int, file_id: int) -> str | None:
        """
        Fetch the download URL for a specific file as a fallback.

        Uses GET /v1/mods/{modId}/files/{fileId}/download-url.

        Args:
            mod_id: The mod (project) ID.
            file_id: The file ID.

        Returns:
            The download URL string, or None if unavailable.

        Raises:
            httpx.HTTPStatusError: On non-2xx responses.
        """
        resp = await self._client.get(f"/v1/mods/{mod_id}/files/{file_id}/download-url")
        resp.raise_for_status()
        return resp.json().get("data")

    async def get_mod_file(self, mod_id: int, file_id: int) -> FileInfo:
        """
        Fetch metadata for a single mod file.

        Uses GET /v1/mods/{modId}/files/{fileId}.

        Args:
            mod_id: The mod (project) ID.
            file_id: The file ID.

        Returns:
            FileInfo object with download metadata.

        Raises:
            httpx.HTTPStatusError: On non-2xx responses.
        """
        resp = await self._client.get(f"/v1/mods/{mod_id}/files/{file_id}")
        resp.raise_for_status()
        data: dict[str, Any] = resp.json().get("data", {})
        return _parse_file_info(data)


def _parse_file_info(item: dict[str, Any]) -> FileInfo:
    """
    Parse a raw API file object into a FileInfo dataclass.

    Args:
        item: Raw JSON dict from the API response.

    Returns:
        Parsed FileInfo.
    """
    return FileInfo(
        file_id=item.get("id", 0),
        mod_id=item.get("modId", 0),
        display_name=item.get("displayName", ""),
        file_name=item.get("fileName", ""),
        download_url=item.get("downloadUrl"),
    )
