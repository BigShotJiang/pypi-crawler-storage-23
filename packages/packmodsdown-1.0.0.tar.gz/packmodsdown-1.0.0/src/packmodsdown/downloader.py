"""
Core download orchestration for CurseForge modpack mods.
"""

from __future__ import annotations

import asyncio
import shutil
import zipfile
from pathlib import Path


import httpx
from rich.console import Console
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeRemainingColumn,
)

from packmodsdown.api import CurseForgeClient, FileInfo
from packmodsdown.manifest import ModFileEntry, ModpackManifest, parse_manifest

console = Console()


async def download_modpack(
    modpack_path: str | Path,
    output_dir: str | Path,
    api_key: str,
    max_concurrency: int = 10,
) -> None:
    """
    Parse a CurseForge modpack and download all mod files.

    Args:
        modpack_path: Path to the modpack .zip file.
        output_dir: Directory to save downloaded mod files.
        api_key: CurseForge API key.
        max_concurrency: Maximum number of concurrent downloads.
    """
    manifest = parse_manifest(modpack_path)
    _print_modpack_info(manifest)

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)

    async with CurseForgeClient(api_key) as client:
        file_infos = await _resolve_file_infos(client, manifest)
        await _download_all(client, file_infos, manifest.files, output, max_concurrency)

    _extract_overrides_mods(modpack_path, manifest.overrides, output)


def _extract_overrides_mods(
    modpack_path: str | Path,
    overrides_dir: str,
    output: Path,
) -> None:
    """
    Extract mod files from the overrides/mods directory in the modpack zip.

    Args:
        modpack_path: Path to the modpack .zip file.
        overrides_dir: Name of the overrides directory in the manifest.
        output: Output directory for mod files.
    """
    prefix = f"{overrides_dir}/mods/"
    count = 0

    with zipfile.ZipFile(modpack_path, "r") as zf:
        for entry in zf.namelist():
            if not entry.startswith(prefix):
                continue
            basename = entry.rsplit("/", 1)[-1]
            if not basename:
                continue
            dest = output / basename
            if dest.exists():
                continue
            with zf.open(entry) as src, open(dest, "wb") as dst:
                shutil.copyfileobj(src, dst)
            count += 1

    if count:
        console.print(f"[bold cyan]Overrides:[/] copied {count} files from {prefix}")


def _print_modpack_info(manifest: ModpackManifest) -> None:
    """
    Display modpack metadata to the console.

    Args:
        manifest: Parsed modpack manifest.
    """
    console.print()
    console.print(f"[bold cyan]Modpack:[/]  {manifest.name} v{manifest.version}")
    console.print(f"[bold cyan]Author:[/]   {manifest.author}")
    console.print(f"[bold cyan]MC:[/]       {manifest.minecraft_version}")
    if manifest.mod_loaders:
        console.print(f"[bold cyan]Loaders:[/]  {', '.join(manifest.mod_loaders)}")
    console.print(f"[bold cyan]Mods:[/]     {len(manifest.files)} files to download")
    console.print()


async def _resolve_file_infos(
    client: CurseForgeClient,
    manifest: ModpackManifest,
) -> dict[int, FileInfo]:
    """
    Batch-fetch file metadata from the CurseForge API.

    Args:
        client: Authenticated CurseForge API client.
        manifest: Parsed modpack manifest with file entries.

    Returns:
        Dict mapping file_id to FileInfo.
    """
    file_ids = [f.file_id for f in manifest.files]

    all_infos: list[FileInfo] = []
    batch_size = 50
    for i in range(0, len(file_ids), batch_size):
        batch = file_ids[i : i + batch_size]
        console.print(
            f"[dim]Fetching file info batch "
            f"{i // batch_size + 1}/{(len(file_ids) + batch_size - 1) // batch_size}"
            f" ({len(batch)} files)...[/]"
        )
        try:
            infos = await client.get_files(batch)
            all_infos.extend(infos)
        except httpx.HTTPStatusError as exc:
            console.print(
                f"[bold red]API error fetching batch: {exc.response.status_code}[/]"
            )

    return {info.file_id: info for info in all_infos}


async def _download_all(
    client: CurseForgeClient,
    file_infos: dict[int, FileInfo],
    entries: list[ModFileEntry],
    output: Path,
    max_concurrency: int,
) -> None:
    """
    Download all mod files concurrently with progress tracking.

    Args:
        client: Authenticated CurseForge API client.
        file_infos: Pre-fetched file metadata keyed by file_id.
        entries: Original manifest file entries.
        output: Output directory for downloads.
        max_concurrency: Maximum concurrent downloads.
    """
    semaphore = asyncio.Semaphore(max_concurrency)
    success = 0
    failed = 0
    skipped = 0

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TimeRemainingColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Downloading mods", total=len(entries))

        async def _download_one(entry: ModFileEntry) -> None:
            nonlocal success, failed, skipped

            async with semaphore:
                result = await _download_single_file(client, file_infos, entry, output)

            if result == "success":
                success += 1
            elif result == "skipped":
                skipped += 1
            else:
                failed += 1
            progress.advance(task)

        await asyncio.gather(*[_download_one(e) for e in entries])

    console.print()
    console.print(f"[bold green]Success:[/] {success}")
    if skipped:
        console.print(f"[bold yellow]Skipped:[/] {skipped}")
    if failed:
        console.print(f"[bold red]Failed:[/]  {failed}")
    console.print()


async def _download_single_file(
    client: CurseForgeClient,
    file_infos: dict[int, FileInfo],
    entry: ModFileEntry,
    output: Path,
) -> str:
    """
    Download a single mod file.

    Args:
        client: Authenticated CurseForge API client.
        file_infos: Pre-fetched file metadata.
        entry: The manifest file entry to download.
        output: Output directory.

    Returns:
        "success", "skipped", or "failed".
    """
    info = file_infos.get(entry.file_id)

    if info is None:
        try:
            info = await client.get_mod_file(entry.project_id, entry.file_id)
        except httpx.HTTPStatusError:
            console.print(
                f"[red]X Could not resolve file info: "
                f"project={entry.project_id} file={entry.file_id}[/]"
            )
            return "failed"

    file_name = info.file_name or f"{entry.project_id}_{entry.file_id}.jar"

    if file_name.lower().endswith(".zip"):
        return "skipped"

    dest = output / file_name

    if dest.exists():
        return "skipped"

    download_url = info.download_url
    if not download_url:
        try:
            download_url = await client.get_mod_file_download_url(
                entry.project_id, entry.file_id
            )
        except httpx.HTTPStatusError:
            pass

    if not download_url:
        download_url = _construct_edge_url(entry.project_id, entry.file_id, file_name)

    try:
        async with httpx.AsyncClient(follow_redirects=True, timeout=60.0) as dl_client:
            async with dl_client.stream("GET", download_url) as resp:
                resp.raise_for_status()
                with open(dest, "wb") as f:
                    async for chunk in resp.aiter_bytes(chunk_size=65536):
                        f.write(chunk)
        return "success"
    except (httpx.HTTPStatusError, httpx.RequestError) as exc:
        console.print(f"[red]X Failed to download {file_name}: {exc}[/]")
        if dest.exists():
            dest.unlink()
        return "failed"


def _construct_edge_url(project_id: int, file_id: int, file_name: str) -> str:
    """
    Construct a CurseForge Edge CDN URL as a last-resort fallback.

    The CDN URL pattern is:
    https://edge.forgecdn.net/files/{first4}/{last3}/{fileName}

    Args:
        project_id: The mod project ID (unused but kept for consistency).
        file_id: The file ID.
        file_name: The filename.

    Returns:
        Constructed CDN URL string.
    """
    file_id_str = str(file_id)
    first_part = file_id_str[:4]
    second_part = file_id_str[4:]
    return f"https://edge.forgecdn.net/files/{first_part}/{second_part}/{file_name}"
