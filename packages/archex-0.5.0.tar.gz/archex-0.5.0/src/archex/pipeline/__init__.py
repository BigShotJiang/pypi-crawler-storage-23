"""Internal pipeline package."""
