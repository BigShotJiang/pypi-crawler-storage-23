"""
앙상블 모듈
"""

from .variabilityEnsemble import VariabilityPreservingEnsemble

__all__ = ["VariabilityPreservingEnsemble"]
