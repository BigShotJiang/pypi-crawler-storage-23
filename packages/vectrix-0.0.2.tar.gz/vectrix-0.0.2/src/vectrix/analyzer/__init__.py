"""
데이터 분석 모듈
"""

from .autoAnalyzer import AutoAnalyzer

__all__ = ["AutoAnalyzer"]
