"""配置模块"""

from cn_pii_anonymization.config.settings import Settings, settings

__all__ = [
    "Settings",
    "settings",
]
