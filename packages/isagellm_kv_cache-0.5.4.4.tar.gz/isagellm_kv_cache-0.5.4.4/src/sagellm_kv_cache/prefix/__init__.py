"""Prefix cache indexing primitives."""

from __future__ import annotations

from .fingerprint import (
    AdaptiveHashComputer,
    BaseFingerprintComputer,
    FingerprintComputer,
    FingerprintConfig,
    FingerprintStrategy,
    SegmentedHashComputer,
    SimpleHashComputer,
    WeightedHashComputer,
)
from .grouping import (
    CIPrefixGrouper,
    GroupingConfig,
    PrefixGrouper,
    Request,
    RequestGroup,
)
from .index import PrefixIndex

__all__ = [
    "PrefixIndex",
    # Fingerprint
    "FingerprintStrategy",
    "FingerprintConfig",
    "BaseFingerprintComputer",
    "SimpleHashComputer",
    "SegmentedHashComputer",
    "WeightedHashComputer",
    "AdaptiveHashComputer",
    "FingerprintComputer",
    # Grouping
    "GroupingConfig",
    "Request",
    "RequestGroup",
    "PrefixGrouper",
    "CIPrefixGrouper",
]
