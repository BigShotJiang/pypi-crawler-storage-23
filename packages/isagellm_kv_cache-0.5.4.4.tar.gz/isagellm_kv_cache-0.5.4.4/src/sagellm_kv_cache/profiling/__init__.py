"""KV Cache Profiling Module

This module provides tools for profiling and analyzing KV cache access patterns.
"""

from __future__ import annotations

from .access_stats import TIME_WINDOWS, AccessStatsCollector

__all__ = ["AccessStatsCollector", "TIME_WINDOWS"]
