---
name: Question
about: When you need help with something.
title: ''
labels: question
assignees: ''
---

Please submit new issues for new feature requests and bug reports only.
For questions please join Apify Discord. You could get help from Apify team members and the community there.

- [Discord](https://discord.gg/jyEM2PRvMU)

Please also make sure that you visit all the relevant information sources and use search there.

- [SDK Documentation](https://sdk.apify.com)
- [Our Stack Overflow](https://stackoverflow.com/tags/apify/)
- [Apify Platform Docs](https://docs.apify.com)
- [Apify Help](https://help.apify.com)
