export const STRINGIFIED_PREFIX = '*STRINGIFIED*' as const;
export const MISSING_VALUE_DATASET_TOKEN = '*MISSING_VALUE*' as const;
