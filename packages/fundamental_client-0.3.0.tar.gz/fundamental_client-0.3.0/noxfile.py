import subprocess

import nox

nox.options.default_venv_backend = "uv"


@nox.session(python=["3.10", "3.13"])
@nox.parametrize("deps", ["minimum", "normal"])
def tests(session: nox.Session, deps: str) -> None:
    session.env.pop("VIRTUAL_ENV", None)
    if deps == "normal":
        session.run("uv", "pip", "install", "--upgrade", "-e", ".[dev]", external=True)
    else:
        session.run("uv", "pip", "install", "-e", ".[dev]", external=True)
    if deps == "minimum":
        # Get minimum dependencies and install them (downgrades to minimum versions)
        result = subprocess.run(
            ["uv", "run", "minimum_dependencies", "fundamental-client"],
            capture_output=True,
            text=True,
        )
        min_deps = result.stdout.strip().split("\n")
        session.run("uv", "pip", "install", *min_deps, external=True)
    session.run("uv", "pip", "show", "scikit-learn", external=True)

    # Check for scope argument, default to unit tests
    if session.posargs and session.posargs[0] == "all":
        test_path = "tests/"
    elif session.posargs and session.posargs[0] == "integration":
        test_path = "tests/integration/"
    else:  # Default to unit tests
        test_path = "tests/unit/"

    session.run("pytest", test_path, "-v")
