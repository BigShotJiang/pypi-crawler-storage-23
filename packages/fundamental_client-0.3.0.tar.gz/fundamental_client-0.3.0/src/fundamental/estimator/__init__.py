"""
NEXUS Estimators Module

This module provides scikit-learn compatible estimators for the NEXUS foundation
model, organized by task type.

Note: Deprecated FTMClassifier/FTMRegressor aliases are available from `fundamental` package.
"""

from fundamental.estimator.classification import NEXUSClassifier
from fundamental.estimator.regression import NEXUSRegressor

__all__ = [
    "NEXUSClassifier",
    "NEXUSRegressor",
]
