"""
Polling utilities for task status checks.
"""

import logging
import time

from fundamental.clients.base import BaseClient
from fundamental.exceptions import (
    NEXUSError,
    RequestTimeoutError,
    ServerError,
)
from fundamental.models import TaskStatus, TaskStatusResponse
from fundamental.utils.http import api_call

logger = logging.getLogger(__name__)


def _raise_exception_with_trace(
    exception_class: type[NEXUSError],
    message: str,
    client: BaseClient,
) -> None:
    trace_dict = client.get_trace_dict()
    trace_id = trace_dict.get("trace_id") if trace_dict else None
    raise exception_class(message=message, trace_id=trace_id)


def wait_for_task_status(
    client: BaseClient,
    status_url: str,
    timeout: float,
    polling_interval: float,
    polling_requests_without_delay: int = 0,
    wait_for_completion: bool = True,
) -> TaskStatusResponse:
    """
    Poll for task status until completion or timeout.

    Parameters
    ----------
    client : BaseClient
        The client instance.
    status_url : str
        The URL to poll for status.
    timeout : float
        Maximum time to wait in seconds.
    polling_interval : float
        Time between polling requests in seconds.
    polling_requests_without_delay : int, default=0
        Number of initial requests without delay.
    wait_for_completion : bool, default=True
        Whether to wait for completion or return immediately on in_progress.

    Returns
    -------
    TaskStatusResponse
        The task status response.

    Raises
    ------
    RequestTimeoutError
        If the request times out.
    ServerError
        If the server returns an error.
    ValidationError
        If the request fails validation.
    """
    start_time = time.perf_counter()
    request_counter = 0
    logger.debug("Polling %s (timeout=%ss)", status_url, timeout)

    while True:
        elapsed = time.perf_counter() - start_time
        if elapsed > timeout:
            logger.debug(
                "Polling timed out after %.1fs (%d requests)",
                elapsed,
                request_counter,
            )
            _raise_exception_with_trace(
                RequestTimeoutError,
                message=f"Request timed out after {timeout}s",
                client=client,
            )

        response = api_call(method="GET", full_url=status_url, client=client)
        status_response = TaskStatusResponse(**response.json())
        logger.debug(
            "Poll #%d: status=%s elapsed=%.1fs",
            request_counter + 1,
            status_response.status,
            elapsed,
        )

        if status_response.status == TaskStatus.SUCCESS:
            return status_response

        if status_response.status == TaskStatus.IN_PROGRESS:
            if not wait_for_completion:
                return status_response
            if request_counter > polling_requests_without_delay:
                time.sleep(polling_interval)
        else:
            # Unexpected state
            _raise_exception_with_trace(
                ServerError,
                message=f"Unexpected task status: {status_response.status}",
                client=client,
            )

        request_counter += 1
