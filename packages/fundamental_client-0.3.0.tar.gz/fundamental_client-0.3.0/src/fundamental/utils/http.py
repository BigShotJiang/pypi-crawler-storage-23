"""Simple HTTP utilities for NEXUS client."""

import json as json_lib
import logging
import random
import time
from typing import Any, Dict, Optional

import httpx

from fundamental.clients.base import BaseClient
from fundamental.config import Config
from fundamental.constants import DEFAULT_TIMEOUT_SECONDS, SIGV4_SERVICE_NAME
from fundamental.exceptions import (
    AuthenticationError,
    AuthorizationError,
    HTTPError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    RequestTimeoutError,
    ServerError,
    ValidationError,
)

logger = logging.getLogger(__name__)
logging.getLogger("httpx").setLevel(logging.WARNING)


def _sign_request_sigv4(
    method: str,
    url: str,
    headers: Dict[str, str],
    body: Optional[bytes],
    region: str,
) -> Dict[str, str]:
    try:
        import boto3  # pyright: ignore[reportMissingImports]
        from botocore.auth import SigV4Auth  # pyright: ignore[reportMissingImports]
        from botocore.awsrequest import AWSRequest  # pyright: ignore[reportMissingImports]
    except ImportError as e:
        raise ImportError(
            "boto3 is required for AWS Marketplace/SigV4 authentication."
            'Install it with: pip install "fundamental-client[aws-marketplace]" '
            'or: uv add "fundamental-client[aws-marketplace]"'
        ) from e

    session = boto3.Session()
    credentials = session.get_credentials()

    if credentials is None:
        raise AuthenticationError(
            message="AWS credentials not found. Configure AWS credentials via "
            "environment variables, AWS config file, or IAM role."
        )

    aws_request = AWSRequest(method=method, url=url, headers=headers, data=body or b"")

    SigV4Auth(credentials, SIGV4_SERVICE_NAME, region).add_auth(aws_request)

    return dict(aws_request.headers)


def _prepare_request(
    method: str,
    url: str,
    client_config: Config,
    trace_dict: Optional[Dict[str, str]] = None,
    extra_headers: Optional[Dict[str, str]] = None,
    content: Optional[bytes] = None,
    json: Optional[Dict[str, Any]] = None,
) -> tuple[Dict[str, str], Optional[bytes]]:
    """Prepare headers and body for an API request.

    Returns:
        Tuple of (headers, body_bytes)
    """
    headers: Dict[str, str] = {
        "User-Agent": f"NEXUS-Client-SDK/{client_config.get_version()}",
    }

    if trace_dict:
        trace_id = trace_dict.get("trace_id")
        span_id = trace_dict.get("span_id")
        if trace_id:
            headers["x-datadog-trace-id"] = trace_id
        if span_id:
            headers["x-datadog-parent-id"] = span_id

    if extra_headers:
        headers.update(extra_headers)

    # Serialize JSON to bytes
    body = content
    if json is not None:
        body = json_lib.dumps(json).encode("utf-8")
        headers["Content-Type"] = "application/json"

    if client_config.use_sigv4_auth:
        headers = _sign_request_sigv4(
            method=method,
            url=url,
            headers=headers,
            body=body,
            region=client_config.aws_region,
        )
    else:
        headers["x-api-key"] = f"{client_config.get_api_key()}"

    return headers, body


def _calculate_backoff(attempt: int) -> float:
    """Calculate exponential backoff delay with jitter."""
    delay = min(2**attempt, 10)  # Cap at 10 seconds
    jitter = random.uniform(0.1, 0.3) * delay
    return float(delay + jitter)


def _handle_response_error(response: httpx.Response, trace_id: Optional[str] = None) -> None:
    """Handle HTTP error responses by raising appropriate exceptions."""
    try:
        error_data = response.json()
        detail = error_data.get("detail", response.text[:200])
    except ValueError:
        detail = response.text[:200] or f"HTTP error {response.status_code}"

    if response.status_code == 400:
        raise ValidationError(
            message=f"Invalid request. Error: {detail}",
            trace_id=trace_id,
        )
    if response.status_code == 401:
        raise AuthenticationError(
            message="Invalid API key. Check your credentials.",
            trace_id=trace_id,
        )
    if response.status_code == 403:
        raise AuthorizationError(
            message="Access denied. Check your API permissions.",
            trace_id=trace_id,
        )
    if response.status_code == 404:
        raise NotFoundError(
            message=f"Resource not found. Error: {detail}",
            trace_id=trace_id,
        )
    if response.status_code == 429:
        retry_after = response.headers.get("Retry-After")
        raise RateLimitError(
            message=f"Rate limit exceeded. Retry after {retry_after} seconds.",
            trace_id=trace_id,
        )
    if response.status_code >= 500:
        raise ServerError(
            message="Internal server error.",
            trace_id=trace_id,
        )
    http_error = HTTPError(message=f"Request failed: {detail}", trace_id=trace_id)
    http_error.status_code = response.status_code
    raise http_error


def api_call(
    method: str,
    full_url: str,
    client: BaseClient,
    files: Optional[Dict] = None,
    content: Optional[bytes] = None,
    data: Optional[Dict[str, Any]] = None,
    json: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: Optional[float] = DEFAULT_TIMEOUT_SECONDS,
    max_retries: Optional[int] = None,
) -> httpx.Response:
    """Make HTTP request to the api.

    Args:
        method: HTTP method (GET, POST, etc.)
        full_url: Complete URL for the request
        client: Client instance
        files: Files to upload
        content: Raw content bytes
        data: Form data
        json: JSON payload
        headers: Additional headers
        timeout: Request timeout in seconds
        max_retries: Number of retries

    Returns:
        httpx.Response object

    Raises:
        Various HTTP exceptions based on response status
    """
    client_config = client.config
    trace_dict = client.get_trace_dict()
    if max_retries is None:
        max_retries = client_config.retries

    # Only add auth for requests to our API, not external URLs (e.g., S3)
    is_api_request = full_url.startswith(client_config.api_url)
    merged_headers = headers or {}

    if is_api_request:
        # _prepare_request serializes JSON to bytes (content) so SigV4 can sign the exact body.
        # For API key auth this is harmless - we're just doing what httpx does behind the scenes.
        # We set json=None so httpx doesn't re-serialize it.
        merged_headers, content = _prepare_request(
            method=method,
            url=full_url,
            client_config=client_config,
            trace_dict=trace_dict,
            extra_headers=headers,
            content=content,
            json=json,
        )
        json = None

    trace_id = trace_dict.get("trace_id") if trace_dict else None
    with httpx.Client(
        timeout=httpx.Timeout(timeout, connect=5.0),
        follow_redirects=True,
        verify=client_config.verify_ssl,
    ) as http_client:
        for attempt in range(max_retries + 1):
            try:
                logger.debug(f"Attempt {attempt + 1} of {max_retries + 1} to {method} {full_url}")
                response = http_client.request(
                    method=method,
                    url=full_url,
                    files=files,
                    headers=merged_headers,
                    content=content,
                    data=data,
                    json=json,
                )

                if 200 <= response.status_code < 300:
                    logger.debug(
                        "%s %s -> %d (%d bytes)",
                        method,
                        full_url,
                        response.status_code,
                        len(response.content),
                    )
                    return response

                # Handle non-retryable errors immediately
                if 400 <= response.status_code < 500 and response.status_code != 429:
                    _handle_response_error(response, trace_id=trace_id)

                # Handle retryable errors (429, 5xx)
                if attempt < max_retries and response.status_code in (
                    429,
                    500,
                    502,
                    503,
                    504,
                ):
                    wait_time = _calculate_backoff(attempt)
                    logger.debug(
                        "Retryable %d on %s %s, waiting %.1fs (attempt %d/%d)",
                        response.status_code,
                        method,
                        full_url,
                        wait_time,
                        attempt + 1,
                        max_retries + 1,
                    )

                    # Use Retry-After header for rate limiting
                    if response.status_code == 429:
                        retry_after = response.headers.get("Retry-After")
                        if retry_after:
                            try:
                                wait_time = float(retry_after)
                            except ValueError:
                                pass

                    time.sleep(wait_time)
                    continue

                # Final attempt failed
                _handle_response_error(response, trace_id=trace_id)

            except (httpx.TimeoutException, httpx.RequestError) as e:
                if attempt < max_retries:
                    wait_time = _calculate_backoff(attempt)
                    logger.debug(f"Network error, retrying in {wait_time:.1f}s")
                    time.sleep(wait_time)
                    continue

                # Final attempt failed
                if isinstance(e, httpx.TimeoutException):
                    raise RequestTimeoutError(
                        message="Request timed out. Check your connection or try again.",
                        trace_id=trace_id,
                    ) from e
                if "Connection refused" in str(e):
                    raise NetworkError(
                        message="Connection refused, cannot connect to api server. \n"
                        "Check your connection or try again.",
                        trace_id=trace_id,
                    ) from e
                raise NetworkError(
                    message="Network error occurred. Please try again.",
                    trace_id=trace_id,
                ) from e

    raise RuntimeError("Network error occurred. Please try again.")
