# Environment variable names
ENV_API_KEY = "FUNDAMENTAL_API_KEY"
ENV_API_URL = "FUNDAMENTAL_API_URL"

API_URL = "https://api.fundamental.tech"
FIT_PATH = "/api/v1/model/fit"
PREDICT_PATH = "/api/v1/model/predict"
FIT_STATUS_PATH = "/api/v1/model/fit/status"
PREDICT_STATUS_PATH = "/api/v1/model/predict/status"
FEATURE_IMPORTANCE_PATH = "/api/v1/model/feature-importance"
FEATURE_IMPORTANCE_STATUS_PATH = "/api/v1/model/feature-importance/status"
FEATURE_IMPORTANCE_MODEL_METADATA_GENERATE_PATH = "/api/v1/model/feature-importance/create-metadata"
MODEL_MANAGEMENT_PATH = "/api/v1/model-management/trained-models"
FIT_MODEL_METADATA_GENERATE_PATH = "/api/v1/model/fit/create-metadata"
PREDICT_MODEL_METADATA_GENERATE_PATH = "/api/v1/model/predict/create-metadata"
COMPLETE_MULTIPART_UPLOAD_PATH = "/api/v1/model/complete-multipart-upload"

DEFAULT_TIMEOUT_SECONDS = 30
DEFAULT_RETRIES_COUNT = 1

# Shared default constants
DEFAULT_POLLING_INTERVAL_SECONDS = 2
DEFAULT_SUBMIT_REQUEST_TIMEOUT_SECONDS = 30
DEFAULT_DOWNLOAD_RESULT_TIMEOUT_SECONDS = 60 * 60 * 3  # 3 hours
DEFAULT_MODEL_METADATA_UPLOAD_TIMEOUT_SECONDS = 60 * 60 * 1  # 1 hour
DEFAULT_COMPLETE_MULTIPART_UPLOAD_TIMEOUT_SECONDS = 30
DEFAULT_MODEL_METADATA_GENERATE_TIMEOUT_SECONDS = 30

# Predict-specific
DEFAULT_PREDICT_POLLING_REQUESTS_WITHOUT_DELAY = 100
DEFAULT_PREDICT_TIMEOUT_SECONDS = 60 * 60  # 1 hour

# Feature importance-specific
DEFAULT_FEATURE_IMPORTANCE_TIMEOUT_SECONDS = 60 * 60 * 24  # 24 hours

# Fit-specific
DEFAULT_FIT_TIMEOUT_SECONDS = 60 * 60 * 3  # 3 hours


X_TRAIN_FILE_NAME = "x_train_file"
Y_TRAIN_FILE_NAME = "y_train_file"
X_TEST_FILE_NAME = "x_test_file"

# AWS Marketplace/SigV4 authentication
SIGV4_SERVICE_NAME = "execute-api"
