"""
Deprecated aliases for backward compatibility.

This module contains deprecated estimator class aliases that will be removed in a future version.
Estimator classes emit FutureWarning when instantiated.

Note: FTMError alias is in fundamental.exceptions (not here) to avoid circular imports.

TO REMOVE:
1. Delete this file
2. Remove imports from fundamental/__init__.py
"""

import warnings
from typing import Literal

from fundamental.estimator.classification import NEXUSClassifier
from fundamental.estimator.regression import NEXUSRegressor


def _deprecation_warning(old_name: str, new_name: str) -> None:
    """Emit a FutureWarning for renamed classes."""
    warnings.warn(
        f"{old_name} is deprecated. Use {new_name} instead.",
        FutureWarning,
        stacklevel=3,
    )


class FTMClassifier(NEXUSClassifier):
    """Deprecated: Use NEXUSClassifier instead."""

    def __init__(self, mode: Literal["quality", "speed"] = "quality"):
        _deprecation_warning("FTMClassifier", "NEXUSClassifier")
        super().__init__(mode=mode)


class FTMRegressor(NEXUSRegressor):
    """Deprecated: Use NEXUSRegressor instead."""

    def __init__(self, mode: Literal["quality", "speed"] = "quality"):
        _deprecation_warning("FTMRegressor", "NEXUSRegressor")
        super().__init__(mode=mode)
