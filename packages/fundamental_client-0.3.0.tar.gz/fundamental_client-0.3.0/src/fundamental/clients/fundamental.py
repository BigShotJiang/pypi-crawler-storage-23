"""Fundamental client implementation."""

from typing import Any

from fundamental.clients.base import BaseClient
from fundamental.config import Config


class Fundamental(BaseClient):
    """Default client for Fundamental API interactions."""

    def __init__(
        self,
        **kwargs: Any,  # noqa: ANN401
    ):
        """Initialize the Fundamental client."""
        cfg = Config(
            **kwargs,
        )
        super().__init__(config=cfg)
