"""Model management services for NEXUS client."""

import base64
import logging
from typing import Any, Dict

from pydantic import BaseModel
from typing_extensions import TypeAlias

from fundamental.clients.base import BaseClient
from fundamental.exceptions import ValidationError
from fundamental.models import (
    DeleteTrainedModelResponse,
    TrainedModelMetadata,
    UpdateAttributesResponse,
)
from fundamental.utils.http import api_call
from fundamental.utils.safetensors_deserialize import load_estimator_fields_from_bytes

logger = logging.getLogger(__name__)

TrainedModelsListResponse: TypeAlias = list[str]


class LoadedModelResponse(BaseModel):
    estimator_fields: Dict[str, Any]


class ModelsService:
    """Service for model management operations."""

    def __init__(self, client: BaseClient) -> None:
        """Initialize the models service.

        Args:
            client: Client instance
        """
        self.client = client

    def _validate_model_id(self, model_id: str) -> None:
        if not model_id or not model_id.strip():
            raise ValidationError("model_id cannot be empty. Please provide a valid model_id.")

    def list(self) -> TrainedModelsListResponse:
        """
        List all trained models.

        Returns
        -------
        TrainedModelsListResponse
            List of trained model IDs.
        """
        response = api_call(
            method="GET",
            full_url=self.client.config.get_full_model_management_url(),
            client=self.client,
        )

        res: list[str] = response.json()
        return res

    def delete(self, model_id: str) -> DeleteTrainedModelResponse:
        """
        Delete a specific trained model.

        Parameters
        ----------
        model_id : str
            The ID of the model to delete.

        Returns
        -------
        DeleteTrainedModelResponse
            Response from the deletion operation.

        Raises
        ------
        ValidationError
            If model_id is empty or invalid.
        """
        self._validate_model_id(model_id)
        logger.debug("Deleting model %s", model_id)

        response = api_call(
            method="DELETE",
            full_url=f"{self.client.config.get_full_model_management_url()}/{model_id}",
            client=self.client,
        )

        return DeleteTrainedModelResponse(**response.json())

    def get(self, model_id: str) -> TrainedModelMetadata:
        """
        Get information about a specific trained model.

        Parameters
        ----------
        model_id : str
            The ID of the model to retrieve.

        Returns
        -------
        TrainedModelMetadata
            Model information dictionary.

        Raises
        ------
        ValidationError
            If model_id is empty or invalid.
        """
        self._validate_model_id(model_id)

        response = api_call(
            method="GET",
            full_url=f"{self.client.config.get_full_model_management_url()}/{model_id}",
            client=self.client,
            max_retries=3,
        )

        return TrainedModelMetadata(**response.json())

    def set_attributes(
        self,
        model_id: str,
        attributes: dict[str, str],
    ) -> UpdateAttributesResponse:
        """
        Set attributes for a specific trained model.

        Parameters
        ----------
        model_id : str
            The ID of the model to update.
        attributes : dict[str, str]
            The attributes to set.

        Returns
        -------
        UpdateAttributesResponse
            Response containing the updated attributes.

        Raises
        ------
        ValidationError
            If model_id is empty or invalid.
        """
        self._validate_model_id(model_id)

        response = api_call(
            method="PATCH",
            full_url=f"{self.client.config.get_full_model_management_url()}/{model_id}/attributes",
            client=self.client,
            json={"attributes": attributes},
        )

        return UpdateAttributesResponse(**response.json())

    def load(
        self,
        trained_model_id: str,
    ) -> LoadedModelResponse:
        """
        Load a specific trained model.

        Parameters
        ----------
        trained_model_id : str
            The ID of the model to load.

        Returns
        -------
        LoadedModelResponse
            Model information dictionary.
        """
        self._validate_model_id(trained_model_id)

        response = api_call(
            method="GET",
            full_url=f"{self.client.config.get_full_model_management_url()}/{trained_model_id}/load_model",
            client=self.client,
        )
        response_json = response.json()
        raw_bytes = base64.b64decode(response_json["estimator_fields"], validate=True)
        logger.debug("Loaded model %s (%d bytes)", trained_model_id, len(raw_bytes))
        estimator_fields = load_estimator_fields_from_bytes(raw_bytes)
        return LoadedModelResponse(
            estimator_fields=estimator_fields,
        )
