"""Configuration management for Fundamental SDK."""

import os
from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version
from typing import Optional

from fundamental.constants import (
    API_URL,
    COMPLETE_MULTIPART_UPLOAD_PATH,
    DEFAULT_DOWNLOAD_RESULT_TIMEOUT_SECONDS,
    DEFAULT_FEATURE_IMPORTANCE_TIMEOUT_SECONDS,
    DEFAULT_FIT_TIMEOUT_SECONDS,
    DEFAULT_PREDICT_TIMEOUT_SECONDS,
    DEFAULT_RETRIES_COUNT,
    DEFAULT_TIMEOUT_SECONDS,
    ENV_API_KEY,
    ENV_API_URL,
    FEATURE_IMPORTANCE_MODEL_METADATA_GENERATE_PATH,
    FEATURE_IMPORTANCE_PATH,
    FEATURE_IMPORTANCE_STATUS_PATH,
    FIT_MODEL_METADATA_GENERATE_PATH,
    FIT_PATH,
    FIT_STATUS_PATH,
    MODEL_MANAGEMENT_PATH,
    PREDICT_MODEL_METADATA_GENERATE_PATH,
    PREDICT_PATH,
    PREDICT_STATUS_PATH,
)


@dataclass(frozen=True)
class Config:
    """Immutable configuration for Fundamental SDK.

    Attributes:
        api_key: API key for authentication (defaults to FUNDAMENTAL_API_KEY env var)
        api_url: Base URL for the API (defaults to FUNDAMENTAL_API_URL env var or API_URL)
        retries: Number of retries for failed requests
        timeout: Default timeout in seconds
        fit_timeout: Timeout for fit operations
        predict_timeout: Timeout for predict operations
        feature_importance_timeout: Timeout for feature importance operations
        download_prediction_result_timeout: Timeout for downloading prediction results
        download_feature_importance_result_timeout: Timeout for downloading feature
            importance results
        use_sigv4_auth: Use AWS SigV4 authentication instead of API key (for private deployment)
        aws_region: AWS region for SigV4 signing (required when use_sigv4_auth=True)
        verify_ssl: Whether to verify SSL certificates (default: True)
    """

    api_key: str = ""
    api_url: str = ""
    retries: int = DEFAULT_RETRIES_COUNT
    timeout: int = DEFAULT_TIMEOUT_SECONDS
    fit_timeout: int = DEFAULT_FIT_TIMEOUT_SECONDS
    predict_timeout: int = DEFAULT_PREDICT_TIMEOUT_SECONDS
    feature_importance_timeout: int = DEFAULT_FEATURE_IMPORTANCE_TIMEOUT_SECONDS
    download_prediction_result_timeout: int = DEFAULT_DOWNLOAD_RESULT_TIMEOUT_SECONDS
    download_feature_importance_result_timeout: int = DEFAULT_DOWNLOAD_RESULT_TIMEOUT_SECONDS
    use_sigv4_auth: bool = False
    aws_region: str = ""
    verify_ssl: bool = True

    def __post_init__(self) -> None:
        """Initialize config with environment variables if not provided."""
        api_key: Optional[str] = self.api_key or os.getenv(ENV_API_KEY)
        object.__setattr__(self, "api_key", api_key)
        url: str = self.api_url or os.getenv(ENV_API_URL) or API_URL
        object.__setattr__(self, "api_url", url)

        if self.use_sigv4_auth:
            # Validate AWS region is provided when using SigV4 auth
            if not self.aws_region:
                raise ValueError(
                    "AWS region is required when using SigV4 authentication. "
                    "Please provide it via aws_region parameter."
                )
        else:
            # Validate API key when not using SigV4 auth
            _ = self.get_api_key()  # quick fail on missing api keys

    def get_api_key(self) -> str:
        """Get the API key, raising an error if not set."""
        if not self.api_key:
            raise ValueError(
                "API key is required. Please provide it via:\n"
                "1. Fundamental(api_key='your-key')\n"
                f"2. Set {ENV_API_KEY} environment variable"
            )
        return self.api_key

    def get_full_fit_url(self) -> str:
        """Get the complete URL for the fit endpoint."""
        return f"{self.api_url.rstrip('/')}{FIT_PATH}"

    def get_full_predict_url(self) -> str:
        """Get the complete URL for the predict endpoint."""
        return f"{self.api_url.rstrip('/')}{PREDICT_PATH}"

    def get_full_model_management_url(self) -> str:
        """Get the complete URL for the model management endpoint."""
        return f"{self.api_url.rstrip('/')}{MODEL_MANAGEMENT_PATH}"

    def get_full_fit_model_metadata_generate_url(self) -> str:
        """Get the complete URL for the model metadata generation endpoint."""
        return f"{self.api_url.rstrip('/')}{FIT_MODEL_METADATA_GENERATE_PATH}"

    def get_full_predict_model_metadata_generate_url(self) -> str:
        """Get the complete URL for the predict metadata generation endpoint."""
        return f"{self.api_url.rstrip('/')}{PREDICT_MODEL_METADATA_GENERATE_PATH}"

    def get_full_complete_multipart_upload_url(self) -> str:
        """Get the complete URL for the complete multipart upload endpoint."""
        return f"{self.api_url.rstrip('/')}{COMPLETE_MULTIPART_UPLOAD_PATH}"

    def get_full_fit_status_url(self) -> str:
        """Get the complete URL for the fit status endpoint."""
        return f"{self.api_url.rstrip('/')}{FIT_STATUS_PATH}"

    def get_full_predict_status_url(self) -> str:
        """Get the complete URL for the predict status endpoint."""
        return f"{self.api_url.rstrip('/')}{PREDICT_STATUS_PATH}"

    def get_full_feature_importance_url(self) -> str:
        """Get the complete URL for the feature importance endpoint."""
        return f"{self.api_url.rstrip('/')}{FEATURE_IMPORTANCE_PATH}"

    def get_full_feature_importance_status_url(self) -> str:
        """Get the complete URL for the feature importance status endpoint."""
        return f"{self.api_url.rstrip('/')}{FEATURE_IMPORTANCE_STATUS_PATH}"

    def get_full_feature_importance_model_metadata_generate_url(self) -> str:
        """Get the complete URL for the feature importance metadata generation endpoint."""
        return f"{self.api_url.rstrip('/')}{FEATURE_IMPORTANCE_MODEL_METADATA_GENERATE_PATH}"

    def get_version(self) -> str:
        """Get the SDK version."""
        try:
            return version("fundamental-client")
        except PackageNotFoundError:
            return "unknown"
