# CHANGELOG

<!-- version list -->

## [0.3.0](https://github.com/Fundamental-Technologies/fundamental-client/compare/0.2.7...0.3.0) (2026-02-23)


### Features

* add time series support to NEXUSRegressor  ([#80](https://github.com/Fundamental-Technologies/fundamental-client/issues/80)) ([b8ddff6](https://github.com/Fundamental-Technologies/fundamental-client/commit/b8ddff6b34db311aa180bda35dc91335fffa755d))

## [0.2.7](https://github.com/Fundamental-Technologies/fundamental-client/compare/0.2.6...0.2.7) (2026-02-12)


### Bug Fixes

* eng-650 diagnose context manager hotfix ([#78](https://github.com/Fundamental-Technologies/fundamental-client/issues/78)) ([2cde8ed](https://github.com/Fundamental-Technologies/fundamental-client/commit/2cde8ed451c1e7a6fd90f373ef980c5cfc2efc04))

## [0.2.6](https://github.com/Fundamental-Technologies/fundamental-client/compare/0.2.5...0.2.6) (2026-02-12)


### Performance Improvements

* reduce memory by avoiding data copying in Parquet serialization ([#75](https://github.com/Fundamental-Technologies/fundamental-client/issues/75)) ([e48ae8a](https://github.com/Fundamental-Technologies/fundamental-client/commit/e48ae8a609aabcc80095d088b9e6449f4a318c62))

## [0.2.5](https://github.com/Fundamental-Technologies/fundamental-client/compare/0.2.4...0.2.5) (2026-02-05)


### Bug Fixes

* improve README and version reporting (ENG-594) ([#68](https://github.com/Fundamental-Technologies/fundamental-client/issues/68)) ([2c1bfc5](https://github.com/Fundamental-Technologies/fundamental-client/commit/2c1bfc5795203ef70cc066352d35f1b775e92b65))

## [0.2.4](https://github.com/Fundamental-Technologies/fundamental-client/compare/0.2.3...0.2.4) (2026-02-04)


### Bug Fixes

* eng-575-user-facing-readme ([#64](https://github.com/Fundamental-Technologies/fundamental-client/issues/64)) ([591bcce](https://github.com/Fundamental-Technologies/fundamental-client/commit/591bccefed4abeaeddca9b8a03d81044d2d4bb25))
* update documentation URL in pyproject.toml ([#66](https://github.com/Fundamental-Technologies/fundamental-client/issues/66)) ([1d21409](https://github.com/Fundamental-Technologies/fundamental-client/commit/1d214095abdb61a47abaecde66e5cee9a69a7ba3))

## [0.2.3](https://github.com/Fundamental-Technologies/fundamental-client/compare/0.2.2...0.2.3) (2026-02-03)


### Features

* **ci:** add production PyPI publishing workflow (ENG-573) ([#62](https://github.com/Fundamental-Technologies/fundamental-client/issues/62)) ([6940225](https://github.com/Fundamental-Technologies/fundamental-client/commit/6940225ceb5ac777217c7dd280d5f53bae799c1a))

## [0.2.2](https://github.com/Fundamental-Technologies/fundamental-client/compare/0.2.1...0.2.2) (2026-02-03)


### Bug Fixes

* **ci:** correct TestPyPI workflow job name and environment URL (ENG-572) ([#61](https://github.com/Fundamental-Technologies/fundamental-client/issues/61)) ([d7ab9e1](https://github.com/Fundamental-Technologies/fundamental-client/commit/d7ab9e17ad44242c6a26400675680942767e9302))
* **estimator-fields:** addressing additional PR comments (ENG-549) ([#59](https://github.com/Fundamental-Technologies/fundamental-client/issues/59)) ([eb3103a](https://github.com/Fundamental-Technologies/fundamental-client/commit/eb3103abdd29d79df703eab3add835dd7ce4bc8d))

## [0.2.1](https://github.com/Fundamental-Technologies/fundamental-client/compare/0.2.0...0.2.1) (2026-02-02)


### Bug Fixes

* **estimator-fields:** use safetensors instead of pickle (ENG-549) ([#57](https://github.com/Fundamental-Technologies/fundamental-client/issues/57)) ([17f8c5f](https://github.com/Fundamental-Technologies/fundamental-client/commit/17f8c5f960e60dc45942477c20d848ad86b19d73))

## [0.2.0](https://github.com/Fundamental-Technologies/fundamental-client/compare/0.1.9...0.2.0) (2026-01-29)


### Features

* add advanced visibility for fitted models public name and attr ([#52](https://github.com/Fundamental-Technologies/fundamental-client/issues/52)) ([2aa71f9](https://github.com/Fundamental-Technologies/fundamental-client/commit/2aa71f9f29383e9d991ad98ece47f0836432f05f))
* add E2E tests triggered by PR comments in GitHub Actions workflow ([#41](https://github.com/Fundamental-Technologies/fundamental-client/issues/41)) ([6f1a694](https://github.com/Fundamental-Technologies/fundamental-client/commit/6f1a69492f580847d65e32f445715a174b8c0686))
* ENG-471/support-authentication-in-the-ec2-marketplace-offering ([#45](https://github.com/Fundamental-Technologies/fundamental-client/issues/45)) ([693f285](https://github.com/Fundamental-Technologies/fundamental-client/commit/693f2854b47687f8003fbcfee9ee1ff7d691ec73))
* rename Nexus classes to NEXUS names in capitals ([#55](https://github.com/Fundamental-Technologies/fundamental-client/issues/55)) ([8481252](https://github.com/Fundamental-Technologies/fundamental-client/commit/84812521e657dad2c9f35a429338da0ae4f5eb41))


### Bug Fixes

* Inf 470/dependabot GitHub update ([#44](https://github.com/Fundamental-Technologies/fundamental-client/issues/44)) ([029ba2a](https://github.com/Fundamental-Technologies/fundamental-client/commit/029ba2ad2f0a3be6158e75f1dd0c31b67581ffed))

## [0.1.9](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/compare/0.1.8...0.1.9) (2026-01-09)


### Bug Fixes

* sklearn downgrade (INF-461) ([#42](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/issues/42)) ([f6acd49](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/commit/f6acd495bb2f9c7ed25a2997b332f680293a97ea))

## [0.1.8](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/compare/0.1.7...0.1.8) (2026-01-01)


### Features

* add asynchronous training support with submit_fit_task and poll_fit_result methods ([#36](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/issues/36)) ([8e86eba](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/commit/8e86eba50f62c3a713e0b228b7172b765400cf28))


### Bug Fixes

* inf-446-fix-nox-matrix-compability-check ([#37](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/issues/37)) ([ba27c4a](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/commit/ba27c4a9606eba3a3ca302c46797b3d077819570))
* skip private attributes in _load_estimator_fields method to adhe… ([#39](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/issues/39)) ([ee3dbc4](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/commit/ee3dbc44963efdad1a55fe0f3cdb160124ae7f2f))

## [0.1.7](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/compare/0.1.6...0.1.7) (2025-12-25)


### Bug Fixes

* Inf 419/sdk make sdk compatible with scikit learn api ([#27](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/issues/27)) ([4a727ec](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/commit/4a727ecda6972623bd4b55a6b5ae5fabaa5f5d4d))
* Inf 439/sdk use api base url in integration test ([#28](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/issues/28)) ([42ff5f9](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/commit/42ff5f91a7f87cd16c0dde28e7ee0367c48fb415))

## [0.1.6](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/compare/0.1.5...0.1.6) (2025-12-12)


### Bug Fixes

* inf 299/sdk update readme file to describe new release flows ([#20](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/issues/20)) ([f72c41b](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/commit/f72c41bc7abf1b3a4da3cf88b711eb8e9fe3375c))
* inf 301 sdk fix integration tests ([#21](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/issues/21)) ([9253993](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/commit/92539938352078440aa35efbb5bb3958a288dcee))
* Inf 365/sdk integrate datamodel code generator ([#25](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/issues/25)) ([c854187](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/commit/c8541877156a9eb19b8888d3a54f8188c39c4c54))

## [0.1.5](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/compare/0.1.4...0.2.0) (2025-12-03)


### Features

* INF-257-sdk-implement-feature-importance-api. ([#11](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/issues/11)) ([ef67482](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/commit/ef6748295a018a3e88d887a08cb984fdad10bf44))


### Bug Fixes

* Inf 284/sdk migrate to release please ([#18](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/issues/18)) ([5f8bedf](https://github.com/Fundamental-Technologies/pre-release-fundamental-client/commit/5f8bedf946a5073f256ca66eac4777099381adec))

## v0.0.0 (2025-11-06)

- Initial Release

## v0.1.0 (2025-10-13)

- Initial Release
