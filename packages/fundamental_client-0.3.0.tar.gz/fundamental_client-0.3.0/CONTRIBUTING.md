# Contributing to Fundamental Python SDK

We welcome contributions to the Fundamental Python SDK! Whether it's a bug fix, documentation improvement, or additional tests, your help is appreciated.

## Reporting Issues

Go to this repository's [issues page](https://github.com/Fundamental-Technologies/fundamental-client/issues) and click "New Issue". Please check if the issue has already been reported before creating a new one.

Include the following information:

- Describe what you expected to happen
- If possible, include a [minimal reproducible example](https://stackoverflow.com/help/minimal-reproducible-example)
- Describe what actually happened, including the full traceback if there was an exception
- List your Python version and SDK version

## Development Setup

Fork the repository and clone it locally:

```bash
git clone https://github.com/YOUR-USERNAME/fundamental-client
cd fundamental-client
git checkout -b my-feature-branch main
```

### Quick Setup

We recommend using our bootstrap script for easy setup:

```bash
./scripts/bootstrap
```

### Manual Installation

```bash
# Install with development dependencies using uv (recommended)
uv sync --extra dev

# Or (pip-compatible) install in editable mode
uv pip install -e ".[dev]"

# Or with pip
pip install -e ".[dev]"
```

## Making Changes

1. Make your changes
2. Format code: `./scripts/format`
3. Check linting: `./scripts/lint`
4. Run tests: `./scripts/test`

## Testing

We use [pytest](https://docs.pytest.org/) for testing. To run tests:

```bash
# Run all tests using the test script
./scripts/test

# Or run directly with nox for all Python versions
uv run nox -s tests

# Run tests for specific Python version
uv run nox -s tests-3.10

# Run tests with minimum dependencies
uv run nox -s tests-3.10 -- minimum

# Run specific test file directly
uv run pytest tests/unit/test_estimators.py -v
```

When adding new tests, place them in the `tests/` directory following the same structure as the source code.

## Code Quality

```bash
# Format code using the format script
./scripts/format

# Run all linting checks using the lint script
./scripts/lint

# Or run individual checks:
# Ruff check
uv run ruff check .

# Type checking with pyright
uv run pyright

# Type checking with mypy
uv run mypy .

# Run all pre-commit hooks
uv run pre-commit run --all-files
```

## Generating API Models

The SDK uses auto-generated Pydantic models from the Fundamental API's OpenAPI specification. This ensures type safety and keeps the client in sync with the API.

```bash
# Regenerate models from the OpenAPI spec
./scripts/generate-models

# Use a different OpenAPI URL (e.g., production)
OPENAPI_URL=https://api.fundamental-dev.tech/openapi.json ./scripts/generate-models
```

Generated models are placed in `src/fundamental/models/generated.py` and can be imported from `fundamental.models`:

```python
from fundamental.models import (
    FitRequest,
    FitResponse,
    TaskStatus,
    TaskStatusResponse,
)
```

When the API changes, simply re-run the generation script to update the models.

## Versioning and Release Flow

This package follows [SemVer](https://semver.org/spec/v2.0.0.html) conventions. We use [Release Please](https://github.com/googleapis/release-please) for automated versioning and changelog generation.

**Main Branch (Stable Releases):**
1. Push to `main` triggers Release Please to create/update a Release PR
2. Merging the Release PR creates a GitHub Release
3. The GitHub Release triggers publishing to CodeArtifact and TestPyPI

**Feature Branches (Dev Releases):**
1. Push to any non-main branch publishes a dev version to CodeArtifact
2. Dev version format: `X.Y.Z.dev0+<commit-hash>`

> **Note:** CodeArtifact may show dev versions as "Latest", but `pip install fundamental-client` will install the stable version. Use `--pre` to install dev versions.

## Opening a Pull Request

Push your branch and open a pull request against the `main` branch. Include:

- Clear title following Conventional Commits format
- Description of what you changed and why
- Reference any related issues

Make sure all CI checks pass before requesting review.

## Getting Help

- **Issues**: [GitHub Issues](https://github.com/Fundamental-Technologies/fundamental-client/issues) for bugs and feature requests
- **Email**: support@fundamental.tech for questions
- **Documentation**: See README.md for usage examples

We appreciate all contributions and will provide constructive feedback on pull requests. Thank you for helping improve the Fundamental Python SDK!
