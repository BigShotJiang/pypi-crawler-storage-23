"""
Tests for safetensors serialization/deserialization utilities.
"""

import json

import numpy as np
from safetensors.numpy import save

from fundamental.utils.safetensors_deserialize import (
    load_estimator_fields_from_bytes,
)


def _serialize_fields_for_test(fields: dict) -> bytes:
    """Helper to serialize fields for testing (mirrors controller logic)."""
    tensors = {}
    metadata = {}

    def _is_numeric_array(arr: np.ndarray) -> bool:
        return np.issubdtype(arr.dtype, np.number) or np.issubdtype(arr.dtype, np.bool_)

    for k, v in fields.items():
        if isinstance(v, np.ndarray):
            if _is_numeric_array(v):
                tensors[k] = v
            else:
                metadata[k] = json.dumps({"value": v.tolist(), "type": "string_array"})
        elif isinstance(v, list) and len(v) > 0 and isinstance(v[0], np.ndarray):
            metadata[k] = json.dumps({"type": "array_list", "length": len(v)})
            for i, arr in enumerate(v):
                if _is_numeric_array(arr):
                    tensors[f"{k}::{i}"] = arr
                else:
                    metadata[f"{k}::{i}"] = json.dumps(
                        {"value": arr.tolist(), "type": "string_array"}
                    )
        else:
            metadata[k] = json.dumps({"value": v})

    return save(tensors, metadata=metadata)


class TestDeserializeFields:
    """Test field deserialization."""

    def test_numeric_array(self):
        """Test deserializing numeric arrays."""
        original = {"classes_": np.array([0, 1, 2])}
        data = _serialize_fields_for_test(original)
        result = load_estimator_fields_from_bytes(data)

        np.testing.assert_array_equal(result["classes_"], original["classes_"])

    def test_float_array(self):
        """Test deserializing float arrays."""
        original = {"weights": np.array([0.1, 0.5, 0.4])}
        data = _serialize_fields_for_test(original)
        result = load_estimator_fields_from_bytes(data)

        np.testing.assert_array_almost_equal(result["weights"], original["weights"])

    def test_bool_array(self):
        """Test deserializing boolean arrays."""
        original = {"mask": np.array([True, False, True])}
        data = _serialize_fields_for_test(original)
        result = load_estimator_fields_from_bytes(data)

        np.testing.assert_array_equal(result["mask"], original["mask"])

    def test_string_array(self):
        """Test deserializing string arrays (stored in metadata)."""
        original = {"feature_names": np.array(["feat1", "feat2", "feat3"])}
        data = _serialize_fields_for_test(original)
        result = load_estimator_fields_from_bytes(data)

        np.testing.assert_array_equal(result["feature_names"], original["feature_names"])

    def test_scalar_int(self):
        """Test deserializing scalar integers."""
        original = {"n_features_in_": 5}
        data = _serialize_fields_for_test(original)
        result = load_estimator_fields_from_bytes(data)

        assert result["n_features_in_"] == 5

    def test_scalar_string(self):
        """Test deserializing scalar strings."""
        original = {"mode": "quality"}
        data = _serialize_fields_for_test(original)
        result = load_estimator_fields_from_bytes(data)

        assert result["mode"] == "quality"

    def test_list_of_numeric_arrays(self):
        """Test deserializing list of numeric arrays (multi-output)."""
        original = {
            "classes_list": [
                np.array([0, 1]),
                np.array([0, 1, 2]),
            ]
        }
        data = _serialize_fields_for_test(original)
        result = load_estimator_fields_from_bytes(data)

        assert len(result["classes_list"]) == 2
        np.testing.assert_array_equal(result["classes_list"][0], original["classes_list"][0])
        np.testing.assert_array_equal(result["classes_list"][1], original["classes_list"][1])

    def test_list_of_string_arrays(self):
        """Test deserializing list of string arrays."""
        original = {
            "label_names": [
                np.array(["a", "b"]),
                np.array(["x", "y", "z"]),
            ]
        }
        data = _serialize_fields_for_test(original)
        result = load_estimator_fields_from_bytes(data)

        assert len(result["label_names"]) == 2
        np.testing.assert_array_equal(result["label_names"][0], original["label_names"][0])
        np.testing.assert_array_equal(result["label_names"][1], original["label_names"][1])

    def test_full_classifier_fields(self):
        """Test deserializing full classifier fields structure."""
        original = {
            "classes_": np.array([0, 1, 2]),
            "n_features_in_": 10,
            "n_outputs_": 1,
            "feature_names_in_": np.array(
                ["f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10"]
            ),
        }
        data = _serialize_fields_for_test(original)
        result = load_estimator_fields_from_bytes(data)

        np.testing.assert_array_equal(result["classes_"], original["classes_"])
        assert result["n_features_in_"] == 10
        assert result["n_outputs_"] == 1
        np.testing.assert_array_equal(result["feature_names_in_"], original["feature_names_in_"])

    def test_full_classifier_with_mode(self):
        """Test deserializing classifier fields with mode."""
        original = {
            "classes_": np.array([0, 1]),
            "n_features_in_": 5,
            "mode": "quality",
        }
        data = _serialize_fields_for_test(original)
        result = load_estimator_fields_from_bytes(data)

        np.testing.assert_array_equal(result["classes_"], original["classes_"])
        assert result["n_features_in_"] == 5
        assert result["mode"] == "quality"
