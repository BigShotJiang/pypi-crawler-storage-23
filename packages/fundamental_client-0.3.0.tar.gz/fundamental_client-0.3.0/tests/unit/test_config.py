"""
Tests for configuration management.
"""

import os
from unittest.mock import patch

import pytest

from fundamental.config import Config


class TestConfig:
    """Test configuration management."""

    @patch.dict(
        os.environ,
        {"FUNDAMENTAL_API_KEY": "dummy_key", "FUNDAMENTAL_API_URL": "https://api.fundamental.tech"},
        clear=False,
    )
    def test_config_init_defaults(self):
        """Test config initialization with default values."""
        config = Config()

        assert config.api_url == "https://api.fundamental.tech"
        assert config.api_key == "dummy_key"

    @patch.dict(
        os.environ,
        {"FUNDAMENTAL_API_KEY": "test_token", "FUNDAMENTAL_API_URL": "https://test.com"},
    )
    def test_config_from_env_vars(self):
        """Test config loading from environment variables."""
        config = Config()

        assert config.api_key == "test_token"
        assert config.api_url == "https://test.com"

    def test_config_init_with_params(self):
        """Test config initialization with parameters."""
        config = Config(api_key="test_key")

        assert config.api_key == "test_key"

    def test_config_programmatic_override(self):
        """Test programmatic configuration override."""
        config = Config(api_key="manual_token")

        assert config.api_key == "manual_token"

    def test_get_full_fit_url(self):
        """Test full fit URL generation."""
        config = Config()

        # Test URL generation with current config
        expected = f"{config.api_url}/api/v1/model/fit"
        assert config.get_full_fit_url() == expected

    def test_get_full_predict_url(self):
        """Test full predict URL generation."""
        config = Config()

        # Test URL generation with current config
        expected = f"{config.api_url}/api/v1/model/predict"
        assert config.get_full_predict_url() == expected

    def test_get_full_model_management_url(self):
        """Test full model management URL generation."""
        config = Config()

        # Test URL generation with current config
        expected = f"{config.api_url}/api/v1/model-management/trained-models"
        assert config.get_full_model_management_url() == expected

    def test_get_api_key_with_token(self):
        """Test API key retrieval with token."""
        config = Config(api_key="test_token")

        assert config.get_api_key() == "test_token"

    @patch.dict(os.environ, {"FUNDAMENTAL_API_KEY": ""}, clear=False)
    def test_get_api_key_without_token(self):
        """Test API key retrieval without token raises error."""
        with pytest.raises(ValueError):  # noqa: PT011
            Config()

    @patch.dict(
        os.environ,
        {"FUNDAMENTAL_API_KEY": "dummy_key", "FUNDAMENTAL_API_URL": "https://api.fundamental.tech"},
        clear=False,
    )
    def test_config_no_env_vars(self):
        """Test config behavior when environment variables are cleared."""
        config = Config()

        assert config.api_key == "dummy_key"
        assert config.api_url == "https://api.fundamental.tech"
