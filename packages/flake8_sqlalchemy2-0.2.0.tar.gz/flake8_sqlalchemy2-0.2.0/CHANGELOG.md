# Changelog

## 0.1.0 (15.02.2026)

Initial release, including first rule (SA201).
