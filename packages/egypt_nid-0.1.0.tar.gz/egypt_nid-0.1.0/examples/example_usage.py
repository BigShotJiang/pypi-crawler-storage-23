"""
egypt-nid – Example Usage Script
=================================

Run this file to see the library in action:

    python examples/example_usage.py
"""

from __future__ import annotations

import sys
import os

# Allow running from project root without installing
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from egypt_nid import (
    NationalID,
    compute_stats,
    filter_adults,
    filter_by_age_range,
    filter_by_gender,
    parse,
    parse_bulk,
    parse_lenient,
)
from egypt_nid.exceptions import ChecksumError, EgyptNIDError
from egypt_nid.utils import luhn_checksum


# ---------------------------------------------------------------------------
# Build a few deterministic valid NIDs for the demo
# ---------------------------------------------------------------------------

def _make_nid(century, yy, mm, dd, gov, seq):
    payload = f"{century}{yy:02d}{mm:02d}{dd:02d}{gov}{seq:04d}"
    check = luhn_checksum(payload)
    return payload + str(check)


NID_CAIRO_MALE    = _make_nid(3, 1, 5, 15, "01", 123)   # 2001-05-15 Cairo
NID_ALEX_FEMALE   = _make_nid(2, 90, 8, 20, "02", 124)  # 1990-08-20 Alexandria
NID_FOREIGN       = _make_nid(3, 5, 3, 10, "88", 100)   # 2005-03-10 Foreign


def section(title: str) -> None:
    print(f"\n{'=' * 60}")
    print(f"  {title}")
    print(f"{'=' * 60}")


# ---------------------------------------------------------------------------
# 1. Basic parsing
# ---------------------------------------------------------------------------

section("1. Basic Parsing")

nid = parse(NID_CAIRO_MALE)
print(f"Raw (masked)       : {nid.masked()}")
print(f"Birth date         : {nid.birth_date}")
print(f"Age                : {nid.age}")
print(f"Gender             : {nid.gender}")
print(f"Governorate (EN)   : {nid.governorate_name_en}")
print(f"Governorate (AR)   : {nid.governorate_name_ar}")
print(f"Is adult           : {nid.is_adult()}")
print(f"Born outside Egypt : {nid.born_outside_egypt}")


# ---------------------------------------------------------------------------
# 2. Serialisation
# ---------------------------------------------------------------------------

section("2. Serialisation")

print("to_dict():")
import json
print(json.dumps(nid.to_dict(), ensure_ascii=False, indent=2))

print("\nto_dict(include_birth_date=False, locale='ar'):")
print(json.dumps(nid.to_dict(include_birth_date=False, locale="ar"), ensure_ascii=False, indent=2))


# ---------------------------------------------------------------------------
# 3. Error handling – strict mode
# ---------------------------------------------------------------------------

section("3. Error Handling (Strict Mode)")

for bad in ["123", "abcdefghijklmn", "30113150101230", NID_CAIRO_MALE[:-1] + "0"]:
    try:
        parse(bad)
    except EgyptNIDError as exc:
        print(f"  {type(exc).__name__}: {exc}")


# ---------------------------------------------------------------------------
# 4. Lenient mode
# ---------------------------------------------------------------------------

section("4. Lenient Mode")

bad_checksum = NID_CAIRO_MALE[:-1] + str((int(NID_CAIRO_MALE[-1]) + 1) % 10)
model, result = parse_lenient(bad_checksum)

print(f"valid  : {result.valid}")
print(f"warnings: {result.warnings}")
if model:
    print(f"Model still returned: {model!r}")


# ---------------------------------------------------------------------------
# 5. Bulk operations
# ---------------------------------------------------------------------------

section("5. Bulk Operations")

raw_ids = [NID_CAIRO_MALE, NID_ALEX_FEMALE, NID_FOREIGN, "bad_nid"]
parsed = parse_bulk(raw_ids, skip_errors=True)
print(f"Parsed {len(parsed)} of {len(raw_ids)} (bad skipped)")

males   = filter_by_gender(parsed, "male")
females = filter_by_gender(parsed, "female")
print(f"Males: {len(males)}, Females: {len(females)}")

stats = compute_stats(parsed)
print(f"\nBulkStats:")
print(json.dumps(stats.to_dict(), ensure_ascii=False, indent=2))


# ---------------------------------------------------------------------------
# 6. Custom governorates
# ---------------------------------------------------------------------------

section("6. Custom Governorate Map")

custom_gov = {
    "01": ("Capital", "العاصمة"),
    "88": ("Foreign", "خارج الجمهورية"),
}
nid_custom = parse(NID_CAIRO_MALE, custom_governorates=custom_gov)
print(f"Custom governorate name: {nid_custom.governorate_name_en}")


print("\n\nAll examples completed successfully.\n")



