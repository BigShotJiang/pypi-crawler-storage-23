"""Utility helpers shared across the egypt-nid package.

These are internal implementation details and are **not** part of the
public API.
"""

from __future__ import annotations

import datetime
from typing import Optional


def luhn_checksum(digits: str) -> int:
    """Compute the Luhn check digit for *digits*.

    The standard Luhn algorithm is applied to the first ``len(digits)``
    characters; the returned value is the single check digit that makes
    the full number pass the Luhn test.

    Args:
        digits: The payload digits (without the check digit), e.g. the first
                13 characters of an Egyptian National ID.

    Returns:
        An integer 0-9 representing the valid check digit.

    Examples:
        >>> luhn_checksum("300000000000")
        # returns the expected check digit
    """
    total = 0
    # Process payload digits right-to-left, alternating double/single
    for i, ch in enumerate(reversed(digits)):
        n = int(ch)
        if i % 2 == 0:          # every even position from the right → double
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return (10 - (total % 10)) % 10


def is_valid_luhn(nid: str) -> bool:
    """Return *True* if *nid* passes the Luhn check.

    Args:
        nid: Full 14-digit National ID string.

    Returns:
        ``True`` when the 14th digit is the correct Luhn check digit.
    """
    payload = nid[:13]
    expected = luhn_checksum(payload)
    return int(nid[13]) == expected


def build_birth_date(century_digit: str, year: str, month: str, day: str) -> Optional[datetime.date]:
    """Construct a :class:`datetime.date` from NID components.

    Args:
        century_digit: Single character ``"2"`` or ``"3"``.
        year: Two-digit year string, e.g. ``"01"``.
        month: Two-digit month string.
        day: Two-digit day string.

    Returns:
        A :class:`datetime.date` if the combination is valid, otherwise
        ``None``.
    """
    from egypt_nid.constants import CENTURY_MAP  # local to avoid circular

    base_year = CENTURY_MAP.get(century_digit)
    if base_year is None:
        return None
    full_year = base_year + int(year)
    try:
        return datetime.date(full_year, int(month), int(day))
    except ValueError:
        return None


def calculate_age(birth_date: datetime.date, reference: Optional[datetime.date] = None) -> int:
    """Return the age in whole years as of *reference* (default: today).

    Args:
        birth_date: The person's date of birth.
        reference: The date to compute age relative to.  Defaults to
                   :func:`datetime.date.today`.

    Returns:
        Age in complete years (non-negative integer).
    """
    today = reference or datetime.date.today()
    age = today.year - birth_date.year
    # Subtract one year if the birthday hasn't occurred yet this year
    if (today.month, today.day) < (birth_date.month, birth_date.day):
        age -= 1
    return max(age, 0)


def mask_nid(nid: str) -> str:
    """Return a masked representation of *nid*.

    The century digit and the last 6 digits are shown; everything else
    is replaced with ``*``.

    Args:
        nid: Full 14-digit National ID string.

    Returns:
        A masked string such as ``"3** ** ** 01 2345"``.

    Examples:
        >>> mask_nid("30105150123456")
        '3** ** ** 01 2345 6'
    """
    if len(nid) != 14:
        return nid
    # Format: C YY MM DD GGGG CC  (century, year, month, day, seq, check)
    # Show century (index 0) and last 6 chars (index 8-13)
    masked = (
        nid[0]
        + "* ** **"
        + " "
        + "*" * 4
        + " "
        + nid[8:10]
        + nid[10:14]
    )
    return masked
