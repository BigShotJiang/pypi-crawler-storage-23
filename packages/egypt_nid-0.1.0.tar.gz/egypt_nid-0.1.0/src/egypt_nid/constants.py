"""Static data constants for egypt-nid.

Governorate mappings are versioned so future official changes can be
introduced without breaking existing consumers.  Select a version via the
``GOVERNORATE_VERSION`` configuration key (default ``"v1"``).
"""

from __future__ import annotations

from typing import Dict, Tuple

# ---------------------------------------------------------------------------
# Governorate code → (English name, Arabic name)
# ---------------------------------------------------------------------------

_GOV_V1: Dict[str, Tuple[str, str]] = {
    "01": ("Cairo", "القاهرة"),
    "02": ("Alexandria", "الإسكندرية"),
    "03": ("Port Said", "بورسعيد"),
    "04": ("Suez", "السويس"),
    "11": ("Damietta", "دمياط"),
    "12": ("Dakahlia", "الدقهلية"),
    "13": ("Sharkia", "الشرقية"),
    "14": ("Kaliobeya", "القليوبية"),
    "15": ("Kafr El-Sheikh", "كفر الشيخ"),
    "16": ("Gharbia", "الغربية"),
    "17": ("Menoufia", "المنوفية"),
    "18": ("Beheira", "البحيرة"),
    "19": ("Ismailia", "الإسماعيلية"),
    "21": ("Giza", "الجيزة"),
    "22": ("Beni Suef", "بني سويف"),
    "23": ("Fayoum", "الفيوم"),
    "24": ("Menia", "المنيا"),
    "25": ("Assiut", "أسيوط"),
    "26": ("Sohag", "سوهاج"),
    "27": ("Qena", "قنا"),
    "28": ("Aswan", "أسوان"),
    "29": ("Luxor", "الأقصر"),
    "31": ("Red Sea", "البحر الأحمر"),
    "32": ("New Valley", "الوادي الجديد"),
    "33": ("Matrouh", "مطروح"),
    "34": ("North Sinai", "شمال سيناء"),
    "35": ("South Sinai", "جنوب سيناء"),
    "88": ("Foreign", "خارج الجمهورية"),
}

GOVERNORATES_V1: Dict[str, Tuple[str, str]] = _GOV_V1

# All versioned maps – add future versions here
GOVERNORATE_VERSIONS: Dict[str, Dict[str, Tuple[str, str]]] = {
    "v1": GOVERNORATES_V1,
}

DEFAULT_GOVERNORATE_VERSION: str = "v1"

# The code used to indicate birth outside Egypt
FOREIGN_GOVERNORATE_CODE: str = "88"

# ---------------------------------------------------------------------------
# Gender
# ---------------------------------------------------------------------------

GENDER_MALE: str = "male"
GENDER_FEMALE: str = "female"

# ---------------------------------------------------------------------------
# Adulthood
# ---------------------------------------------------------------------------

DEFAULT_ADULT_AGE: int = 18

# ---------------------------------------------------------------------------
# Locale keys
# ---------------------------------------------------------------------------

LOCALE_EN: str = "en"
LOCALE_AR: str = "ar"

SUPPORTED_LOCALES: Tuple[str, ...] = (LOCALE_EN, LOCALE_AR)

# ---------------------------------------------------------------------------
# ID structural positions (0-indexed slices)
# ---------------------------------------------------------------------------

SLICE_CENTURY = slice(0, 1)         # 1 digit
SLICE_YEAR = slice(1, 3)            # 2 digits
SLICE_MONTH = slice(3, 5)           # 2 digits
SLICE_DAY = slice(5, 7)             # 2 digits
SLICE_GOVERNORATE = slice(7, 9)     # 2 digits
SLICE_SEQUENCE = slice(9, 13)       # 4 digits  (last digit encodes gender)
SLICE_CHECKSUM = slice(13, 14)      # 1 digit

NID_LENGTH: int = 14
CHECKSUM_POSITION: int = 13         # 0-indexed position of the check digit

# ---------------------------------------------------------------------------
# Century mapping: century digit → 4-digit year prefix
# ---------------------------------------------------------------------------

CENTURY_MAP: Dict[str, int] = {
    "2": 1900,
    "3": 2000,
}
