"""Filtering helpers for bulk :class:`~egypt_nid.models.NationalID` collections.

All functions accept an iterable and return a list for predictable, typed results.
"""

from __future__ import annotations

from typing import Iterable, List, Optional

from egypt_nid.constants import DEFAULT_ADULT_AGE, GENDER_FEMALE, GENDER_MALE
from egypt_nid.models import NationalID


def by_gender(nids: Iterable[NationalID], gender: str) -> List[NationalID]:
    """Filter *nids* to those matching *gender*.

    Args:
        nids: Iterable of :class:`NationalID` objects.
        gender: ``"male"`` or ``"female"``.

    Returns:
        List of matching :class:`NationalID` objects.

    Raises:
        ValueError: If *gender* is not ``"male"`` or ``"female"``.
    """
    if gender not in (GENDER_MALE, GENDER_FEMALE):
        raise ValueError(f"gender must be 'male' or 'female', got {gender!r}")
    return [n for n in nids if n.gender == gender]


def by_governorate(nids: Iterable[NationalID], code: str) -> List[NationalID]:
    """Filter *nids* to those born in governorate *code*.

    Args:
        nids: Iterable of :class:`NationalID` objects.
        code: Two-digit governorate code (e.g. ``"01"``).

    Returns:
        List of matching :class:`NationalID` objects.
    """
    return [n for n in nids if n.governorate_code == code]


def by_age_range(
    nids: Iterable[NationalID],
    min_age: int,
    max_age: int,
) -> List[NationalID]:
    """Filter *nids* to those whose age falls within [*min_age*, *max_age*].

    Args:
        nids: Iterable of :class:`NationalID` objects.
        min_age: Minimum age (inclusive).
        max_age: Maximum age (inclusive).

    Returns:
        List of matching :class:`NationalID` objects.

    Raises:
        ValueError: If *min_age* > *max_age*.
    """
    if min_age > max_age:
        raise ValueError(f"min_age ({min_age}) must be <= max_age ({max_age})")
    return [n for n in nids if min_age <= n.age <= max_age]


def adults(
    nids: Iterable[NationalID],
    minimum_age: int = DEFAULT_ADULT_AGE,
) -> List[NationalID]:
    """Return only adults from *nids*.

    Args:
        nids: Iterable of :class:`NationalID` objects.
        minimum_age: Adulthood threshold (default 18).

    Returns:
        List of adult :class:`NationalID` objects.
    """
    return [n for n in nids if n.is_adult(minimum_age)]


def minors(
    nids: Iterable[NationalID],
    minimum_age: int = DEFAULT_ADULT_AGE,
) -> List[NationalID]:
    """Return only minors (non-adults) from *nids*.

    Args:
        nids: Iterable of :class:`NationalID` objects.
        minimum_age: Adulthood threshold (default 18).

    Returns:
        List of minor :class:`NationalID` objects.
    """
    return [n for n in nids if not n.is_adult(minimum_age)]


def born_outside_egypt(nids: Iterable[NationalID]) -> List[NationalID]:
    """Return only those born outside Egypt.

    Args:
        nids: Iterable of :class:`NationalID` objects.

    Returns:
        List of foreign-born :class:`NationalID` objects.
    """
    return [n for n in nids if n.born_outside_egypt]
