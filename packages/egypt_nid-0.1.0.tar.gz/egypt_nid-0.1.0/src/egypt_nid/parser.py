"""Factory responsible for parsing Egyptian National ID strings.

:func:`parse` is the primary public entry-point; it delegates validation to
the chosen strategy then constructs an immutable :class:`~egypt_nid.models.NationalID`.

Results for valid IDs are cached with :func:`functools.lru_cache` so that
repeated lookups of the same string are essentially free.
"""

from __future__ import annotations

import functools
from typing import Dict, Optional, Tuple

from egypt_nid.constants import (
    DEFAULT_GOVERNORATE_VERSION,
    GOVERNORATE_VERSIONS,
    SLICE_CENTURY,
    SLICE_CHECKSUM,
    SLICE_DAY,
    SLICE_GOVERNORATE,
    SLICE_MONTH,
    SLICE_SEQUENCE,
    SLICE_YEAR,
)
from egypt_nid.exceptions import ConfigurationError, ParseError
from egypt_nid.models import NationalID
from egypt_nid.utils import build_birth_date
from egypt_nid.validator import LenientValidator, StrictValidator, ValidationResult


def _get_governorate_map(
    version: str,
    custom_map: Optional[Dict[str, Tuple[str, str]]],
) -> Dict[str, Tuple[str, str]]:
    if custom_map is not None:
        return custom_map
    gov_map = GOVERNORATE_VERSIONS.get(version)
    if gov_map is None:
        raise ConfigurationError(
            f"Unknown governorate version {version!r}. "
            f"Available: {list(GOVERNORATE_VERSIONS)}"
        )
    return gov_map


def _build_nid_object(
    nid: str,
    governorates: Dict[str, Tuple[str, str]],
) -> NationalID:
    """Construct a :class:`NationalID` from a *validated* NID string.

    Args:
        nid: A 14-digit string that has already passed validation.
        governorates: Governorate code mapping.

    Returns:
        A populated :class:`NationalID` instance.

    Raises:
        ParseError: If a structural inconsistency is detected (should not
                    happen after validation).
    """
    century = nid[SLICE_CENTURY]
    year = nid[SLICE_YEAR]
    month = nid[SLICE_MONTH]
    day = nid[SLICE_DAY]
    gov_code = nid[SLICE_GOVERNORATE]
    sequence = nid[SLICE_SEQUENCE]
    check = nid[SLICE_CHECKSUM]

    birth_date = build_birth_date(century, year, month, day)
    if birth_date is None:
        raise ParseError(f"Failed to construct birth date from NID {nid!r}")

    gov_names = governorates.get(gov_code, ("Unknown", "غير معروف"))

    return NationalID(
        raw=nid,
        century_digit=century,
        birth_date=birth_date,
        governorate_code=gov_code,
        governorate_name_en=gov_names[0],
        governorate_name_ar=gov_names[1],
        sequence=sequence,
        checksum_digit=check,
    )


# ---------------------------------------------------------------------------
# LRU-cached inner worker (uses hashable arguments only)
# ---------------------------------------------------------------------------

@functools.lru_cache(maxsize=4096)
def _cached_parse_strict(
    nid: str,
    version: str,
) -> NationalID:
    """Cached strict parse with *version* key.

    Args:
        nid: 14-digit string.
        version: Governorate version key.

    Returns:
        A :class:`NationalID` instance.
    """
    governorates = GOVERNORATE_VERSIONS[version]
    validator = StrictValidator(governorates)
    validator.validate(nid)
    return _build_nid_object(nid, governorates)


# ---------------------------------------------------------------------------
# Public factory functions
# ---------------------------------------------------------------------------

def parse(
    nid: str,
    *,
    version: str = DEFAULT_GOVERNORATE_VERSION,
    custom_governorates: Optional[Dict[str, Tuple[str, str]]] = None,
) -> NationalID:
    """Parse and validate an Egyptian National ID in **strict** mode.

    Args:
        nid: The 14-digit National ID string.
        version: Governorate version to use (default ``"v1"``).
        custom_governorates: Override the built-in governorate mapping.
                              Must be ``{code: (en_name, ar_name)}``.

    Returns:
        A populated, immutable :class:`~egypt_nid.models.NationalID`.

    Raises:
        LengthError: If ``len(nid) != 14``.
        NonNumericError: If *nid* contains non-digit characters.
        CenturyError: If the century digit is not ``2`` or ``3``.
        BirthDateError: If the birth date is invalid or in the future.
        GovernorateError: If the governorate code is unrecognised.
        ChecksumError: If the Luhn check digit is wrong.

    Examples:
        >>> from egypt_nid import parse
        >>> nid = parse("30105150123456")
        >>> nid.gender
        'male'
    """
    governorates = _get_governorate_map(version, custom_governorates)

    if custom_governorates is not None:
        # Custom map – cannot cache (not hashable as frozen)
        validator = StrictValidator(governorates)
        validator.validate(nid)
        return _build_nid_object(nid, governorates)

    return _cached_parse_strict(nid, version)


def parse_lenient(
    nid: str,
    *,
    version: str = DEFAULT_GOVERNORATE_VERSION,
    custom_governorates: Optional[Dict[str, Tuple[str, str]]] = None,
) -> Tuple[Optional[NationalID], ValidationResult]:
    """Parse a National ID in **lenient** mode.

    All validation checks are run even if earlier ones fail; each failure
    is recorded as a warning in the returned :class:`ValidationResult`.

    Args:
        nid: The raw National ID string.
        version: Governorate version to use.
        custom_governorates: Override the built-in governorate mapping.

    Returns:
        A 2-tuple ``(NationalID | None, ValidationResult)``.
        The first element is ``None`` when any critical check fails
        (e.g. wrong length, non-numeric).

    Examples:
        >>> nid, result = parse_lenient("30105150123457")  # bad checksum
        >>> result.valid
        False
        >>> "checksum" in result.warnings
        True
    """
    governorates = _get_governorate_map(version, custom_governorates)
    validator = LenientValidator(governorates)
    result = validator.validate(nid)

    if not result.valid:
        # Try to build model anyway if only checksum is wrong
        critical_keys = {"length", "numeric", "century", "birth_date"}
        has_critical = bool(critical_keys & set(result.warnings))
        if has_critical:
            return None, result

    try:
        model = _build_nid_object(nid, governorates)
    except Exception:
        return None, result

    return model, result
