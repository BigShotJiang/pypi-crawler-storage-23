"""Custom exception hierarchy for egypt-nid.

This module defines all exceptions raised by the library, organized
in a clear hierarchy for fine-grained error handling.
"""

from __future__ import annotations


class EgyptNIDError(Exception):
    """Base exception for all egypt-nid errors.

    All library exceptions inherit from this class, allowing callers
    to catch all library errors with a single ``except EgyptNIDError``.
    """


class ValidationError(EgyptNIDError):
    """Raised when a National ID fails validation.

    Args:
        message: Human-readable error description.
        field: The field or segment of the ID that caused the error.
        value: The offending value, if applicable.

    Examples:
        >>> raise ValidationError("Invalid length", field="nid", value="123")
        Traceback (most recent call last):
            ...
        egypt_nid.exceptions.ValidationError: Invalid length (field='nid', value='123')
    """

    def __init__(
        self,
        message: str,
        *,
        field: str = "nid",
        value: object = None,
    ) -> None:
        self.field = field
        self.value = value
        super().__init__(message)

    def __str__(self) -> str:  # noqa: D105
        parts = [super().__str__()]
        if self.field:
            parts.append(f"field={self.field!r}")
        if self.value is not None:
            parts.append(f"value={self.value!r}")
        return f"{parts[0]} ({', '.join(parts[1:])})" if len(parts) > 1 else parts[0]


class LengthError(ValidationError):
    """Raised when the ID does not have exactly 14 digits."""


class NonNumericError(ValidationError):
    """Raised when the ID contains non-digit characters."""


class CenturyError(ValidationError):
    """Raised when the century digit is not 2 or 3."""


class BirthDateError(ValidationError):
    """Raised when the encoded birth date is invalid or in the future."""


class GovernorateError(ValidationError):
    """Raised when the governorate code is unrecognised."""


class ChecksumError(ValidationError):
    """Raised when the Luhn checksum digit does not match."""


class ParseError(EgyptNIDError):
    """Raised when parsing fails for an unexpected structural reason."""


class ConfigurationError(EgyptNIDError):
    """Raised when the library is misconfigured."""
