"""Command-line interface for egypt-nid.

Usage::

    egypt-nid 30105150123456
    egypt-nid --json 30105150123456
    egypt-nid --bulk ids.txt
    egypt-nid --bulk ids.txt --json

Exit codes
----------
* 0 – success
* 1 – validation error
* 2 – usage / argument error
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import List, Optional, Sequence

from egypt_nid.exceptions import EgyptNIDError
from egypt_nid.parser import parse, parse_lenient
from egypt_nid.statistics import compute_stats


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def _pretty_output(nid_str: str) -> None:
    """Print a pretty human-readable summary for a single NID."""
    from egypt_nid.parser import parse as _parse

    try:
        nid = _parse(nid_str)
    except EgyptNIDError as exc:
        print(f"  \033[31m✗ {exc}\033[0m", file=sys.stderr)
        return

    print(f"\n  \033[32m✓ Valid National ID\033[0m")
    print(f"  {'Raw (masked)':<22}: {nid.masked()}")
    print(f"  {'Birth date':<22}: {nid.birth_date.isoformat()}")
    print(f"  {'Age':<22}: {nid.age}")
    print(f"  {'Gender':<22}: {nid.gender}")
    print(f"  {'Governorate (EN)':<22}: {nid.governorate_name_en}")
    print(f"  {'Governorate (AR)':<22}: {nid.governorate_name_ar}")
    print(f"  {'Is adult':<22}: {nid.is_adult()}")
    print(f"  {'Born outside Egypt':<22}: {nid.born_outside_egypt}")
    print()


def _json_output(nid_str: str, *, include_raw: bool = False) -> None:
    """Print JSON output for a single NID."""
    try:
        nid = parse(nid_str)
        data = nid.to_dict(include_raw=include_raw)
        data["valid"] = True
        data["warnings"] = {}
    except EgyptNIDError as exc:
        # Lenient fallback for JSON mode to at least report warnings
        model, result = parse_lenient(nid_str)
        if model:
            data = model.to_dict(include_raw=include_raw)
        else:
            data = {}
        data["valid"] = result.valid
        data["warnings"] = result.warnings
        data["error"] = str(exc)

    print(json.dumps(data, ensure_ascii=False, indent=2))


# ---------------------------------------------------------------------------
# Bulk helpers
# ---------------------------------------------------------------------------

def _bulk_process(path: Path, *, as_json: bool, lenient: bool) -> int:
    """Process a file of NIDs, one per line.

    Args:
        path: Path to the text file containing NIDs.
        as_json: Output JSON instead of pretty print.
        lenient: Use lenient validation.

    Returns:
        Exit code (0 on success, 1 on any error).
    """
    lines = [ln.strip() for ln in path.read_text().splitlines() if ln.strip()]
    parsed = []
    errors = []

    for raw in lines:
        try:
            nid = parse(raw)
            parsed.append(nid)
        except EgyptNIDError as exc:
            errors.append({"nid": raw, "error": str(exc)})

    if as_json:
        stats = compute_stats(parsed)
        output = {
            "total": len(lines),
            "valid_count": len(parsed),
            "error_count": len(errors),
            "stats": stats.to_dict(),
            "errors": errors,
        }
        print(json.dumps(output, ensure_ascii=False, indent=2))
    else:
        print(f"\nProcessed {len(lines)} IDs:")
        print(f"  Valid  : {len(parsed)}")
        print(f"  Errors : {len(errors)}")
        if parsed:
            stats = compute_stats(parsed)
            print(f"\nStatistics:")
            print(f"  Average age         : {stats.average_age}")
            print(f"  Gender distribution : {dict(stats.gender_distribution)}")
            print(f"  Foreign-born        : {stats.born_outside_egypt_count}")
        if errors:
            print("\nErrors:")
            for e in errors:
                print(f"  {e['nid']}: {e['error']}")

    return 1 if errors else 0


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main(argv: Optional[Sequence[str]] = None) -> int:
    """Parse arguments and execute the CLI.

    Args:
        argv: Override ``sys.argv`` for testing.

    Returns:
        Integer exit code.
    """
    parser = argparse.ArgumentParser(
        prog="egypt-nid",
        description="Parse and validate Egyptian National ID numbers.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
examples:
  egypt-nid 30105150123456
  egypt-nid --json 30105150123456
  egypt-nid --bulk ids.txt
  egypt-nid --bulk ids.txt --json
        """,
    )
    parser.add_argument(
        "nid",
        nargs="?",
        help="14-digit National ID to parse.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        default=False,
        help="Output results as JSON.",
    )
    parser.add_argument(
        "--bulk",
        metavar="FILE",
        help="Path to a text file containing one NID per line.",
    )
    parser.add_argument(
        "--lenient",
        action="store_true",
        default=False,
        help="Use lenient validation (collect warnings instead of raising).",
    )
    parser.add_argument(
        "--version",
        action="version",
        version="egypt-nid 0.1.0",
    )

    args = parser.parse_args(argv)

    if args.bulk:
        bulk_path = Path(args.bulk)
        if not bulk_path.is_file():
            print(f"error: file not found: {args.bulk}", file=sys.stderr)
            return 2
        return _bulk_process(bulk_path, as_json=args.json, lenient=args.lenient)

    if not args.nid:
        parser.print_help()
        return 2

    if args.json:
        _json_output(args.nid)
    else:
        if args.lenient:
            model, result = parse_lenient(args.nid)
            if model:
                print(f"\n  \033[33m⚠ Lenient parse (warnings present)\033[0m")
                for field, msg in result.warnings.items():
                    print(f"  Warning [{field}]: {msg}")
                _pretty_output(args.nid)
            else:
                print(f"  \033[31m✗ Could not parse: {result.warnings}\033[0m", file=sys.stderr)
                return 1
        else:
            try:
                _pretty_output(args.nid)
            except SystemExit:
                return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
