"""egypt-nid – Egyptian National ID parser and validator.

Public API
----------
The recommended entry points are:

* :func:`parse` – strict mode, raises on any error.
* :func:`parse_lenient` – lenient mode, returns warnings.
* :func:`parse_bulk` – parse a list of ID strings efficiently.
* :class:`NationalID` – the immutable value object returned by parsers.
* :func:`compute_stats` – aggregate statistics over a collection.
* :func:`filter_by_gender`, :func:`filter_by_age_range`, etc. – filtering helpers.

Quick start::

    from egypt_nid import parse

    nid = parse("30105150123456")
    print(nid.gender)          # 'male'
    print(nid.birth_date)      # datetime.date(2001, 5, 15)
    print(nid.governorate_name)  # 'Cairo'
    print(nid.masked())        # '3** ** ** **** 3456'
    print(nid.to_json())

"""

from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Tuple

from egypt_nid.exceptions import (
    BirthDateError,
    CenturyError,
    ChecksumError,
    ConfigurationError,
    EgyptNIDError,
    GovernorateError,
    LengthError,
    NonNumericError,
    ParseError,
    ValidationError,
)
from egypt_nid.filters import (
    adults,
    born_outside_egypt,
    by_age_range,
    by_gender,
    by_governorate,
    minors,
)
from egypt_nid.models import NationalID
from egypt_nid.parser import parse, parse_lenient
from egypt_nid.statistics import BulkStats, compute_stats
from egypt_nid.validator import ValidationResult


def parse_bulk(
    nid_strings: Iterable[str],
    *,
    skip_errors: bool = True,
    version: str = "v1",
) -> List[NationalID]:
    """Parse a collection of National ID strings.

    Args:
        nid_strings: Any iterable of raw ID strings.
        skip_errors: If ``True`` (default), invalid IDs are silently skipped.
                     If ``False``, the first error is re-raised.
        version: Governorate version to use.

    Returns:
        List of successfully parsed :class:`NationalID` objects.

    Examples:
        >>> ids = ["30105150123456", "bad"]
        >>> results = parse_bulk(ids)
        >>> len(results)
        1
    """
    results: List[NationalID] = []
    for raw in nid_strings:
        try:
            results.append(parse(raw, version=version))
        except EgyptNIDError:
            if not skip_errors:
                raise
    return results


# Convenience filter aliases exposed at package level
filter_by_gender = by_gender
filter_by_governorate = by_governorate
filter_by_age_range = by_age_range
filter_adults = adults
filter_minors = minors
filter_born_outside_egypt = born_outside_egypt

__all__ = [
    # Core
    "parse",
    "parse_lenient",
    "parse_bulk",
    "NationalID",
    "ValidationResult",
    "BulkStats",
    "compute_stats",
    # Filters
    "filter_by_gender",
    "filter_by_governorate",
    "filter_by_age_range",
    "filter_adults",
    "filter_minors",
    "filter_born_outside_egypt",
    # Exceptions
    "EgyptNIDError",
    "ValidationError",
    "LengthError",
    "NonNumericError",
    "CenturyError",
    "BirthDateError",
    "GovernorateError",
    "ChecksumError",
    "ParseError",
    "ConfigurationError",
]

__version__ = "0.1.0"
__author__ = "egypt-nid contributors"
