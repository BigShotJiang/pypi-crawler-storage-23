"""Core data model for a parsed Egyptian National ID.

:class:`NationalID` is an immutable value object that exposes structured,
typed attributes for every semantic component of the ID.  Lazy properties
avoid redundant computation while remaining thread-safe.
"""

from __future__ import annotations

import datetime
import json
from typing import Any, Dict, Optional, Tuple

from egypt_nid.constants import (
    DEFAULT_ADULT_AGE,
    FOREIGN_GOVERNORATE_CODE,
    GENDER_FEMALE,
    GENDER_MALE,
    LOCALE_AR,
    LOCALE_EN,
    SUPPORTED_LOCALES,
)
from egypt_nid.utils import calculate_age, mask_nid


class NationalID:
    """Immutable value object representing a parsed Egyptian National ID.

    Do **not** construct this class directly; use :func:`egypt_nid.parse`
    or :func:`egypt_nid.parse_lenient` instead.

    Args:
        raw: The original 14-digit string (stored verbatim).
        century_digit: ``"2"`` for 1900s, ``"3"`` for 2000s.
        birth_date: Decoded date of birth.
        governorate_code: Two-digit governorate code.
        governorate_name_en: English governorate name.
        governorate_name_ar: Arabic governorate name.
        sequence: Four-digit sequence component (positions 10–13).
        checksum_digit: The 14th (Luhn check) digit.
    """

    __slots__ = (
        "_raw",
        "_century_digit",
        "_birth_date",
        "_governorate_code",
        "_governorate_name_en",
        "_governorate_name_ar",
        "_sequence",
        "_checksum_digit",
        "_age_cache",
    )

    def __init__(
        self,
        *,
        raw: str,
        century_digit: str,
        birth_date: datetime.date,
        governorate_code: str,
        governorate_name_en: str,
        governorate_name_ar: str,
        sequence: str,
        checksum_digit: str,
    ) -> None:
        object.__setattr__(self, "_raw", raw)
        object.__setattr__(self, "_century_digit", century_digit)
        object.__setattr__(self, "_birth_date", birth_date)
        object.__setattr__(self, "_governorate_code", governorate_code)
        object.__setattr__(self, "_governorate_name_en", governorate_name_en)
        object.__setattr__(self, "_governorate_name_ar", governorate_name_ar)
        object.__setattr__(self, "_sequence", sequence)
        object.__setattr__(self, "_checksum_digit", checksum_digit)
        object.__setattr__(self, "_age_cache", None)

    def __setattr__(self, name: str, value: object) -> None:  # type: ignore[override]
        raise AttributeError("NationalID is immutable")

    def __delattr__(self, name: str) -> None:
        raise AttributeError("NationalID is immutable")

    # ------------------------------------------------------------------
    # Core attributes
    # ------------------------------------------------------------------

    @property
    def raw(self) -> str:
        """The original 14-digit string as provided by the caller."""
        return self._raw  # type: ignore[return-value]

    @property
    def birth_date(self) -> datetime.date:
        """Date of birth decoded from the National ID."""
        return self._birth_date  # type: ignore[return-value]

    @property
    def governorate_code(self) -> str:
        """Two-digit governorate code (e.g. ``"01"`` for Cairo)."""
        return self._governorate_code  # type: ignore[return-value]

    @property
    def governorate_name(self) -> str:
        """English governorate name (alias for :attr:`governorate_name_en`)."""
        return self._governorate_name_en  # type: ignore[return-value]

    @property
    def governorate_name_en(self) -> str:
        """Governorate name in English."""
        return self._governorate_name_en  # type: ignore[return-value]

    @property
    def governorate_name_ar(self) -> str:
        """Governorate name in Arabic."""
        return self._governorate_name_ar  # type: ignore[return-value]

    @property
    def sequence(self) -> str:
        """Four-digit sequence component from positions 10–13."""
        return self._sequence  # type: ignore[return-value]

    @property
    def checksum_digit(self) -> str:
        """The Luhn check digit (position 14)."""
        return self._checksum_digit  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # Derived / lazy-computed attributes
    # ------------------------------------------------------------------

    @property
    def gender(self) -> str:
        """``"male"`` when the last digit of sequence is odd, ``"female"`` otherwise."""
        # The 13th character (index 12) encodes gender
        return GENDER_MALE if int(self._raw[12]) % 2 != 0 else GENDER_FEMALE  # type: ignore[index]

    @property
    def age(self) -> int:
        """Exact age in complete years, lazily computed and cached."""
        cached = object.__getattribute__(self, "_age_cache")
        if cached is None:
            val = calculate_age(self._birth_date)  # type: ignore[arg-type]
            object.__setattr__(self, "_age_cache", val)
            return val
        return cached  # type: ignore[return-value]

    @property
    def born_outside_egypt(self) -> bool:
        """``True`` when the governorate code is ``"88"`` (foreign)."""
        return self._governorate_code == FOREIGN_GOVERNORATE_CODE  # type: ignore[comparison-overlap]

    def is_adult(self, minimum_age: int = DEFAULT_ADULT_AGE) -> bool:
        """Return ``True`` when :attr:`age` >= *minimum_age*.

        Args:
            minimum_age: The threshold for adulthood.  Defaults to 18.

        Returns:
            ``True`` if the person is at least *minimum_age* years old.
        """
        return self.age >= minimum_age

    def governorate_name_localized(self, locale: str = LOCALE_EN) -> str:
        """Return the governorate name in the requested *locale*.

        Args:
            locale: ``"en"`` for English (default) or ``"ar"`` for Arabic.

        Returns:
            Localised governorate name.

        Raises:
            ValueError: If *locale* is not supported.
        """
        if locale not in SUPPORTED_LOCALES:
            raise ValueError(f"Unsupported locale {locale!r}. Choose from {SUPPORTED_LOCALES}")
        return self._governorate_name_en if locale == LOCALE_EN else self._governorate_name_ar  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # Masking
    # ------------------------------------------------------------------

    def masked(self) -> str:
        """Return a masked National ID string for safe display.

        Only the century digit and the last 6 digits are exposed.

        Returns:
            A masked string, e.g. ``"3** ** ** **** 3456"``.

        Examples:
            >>> nid = parse("30105150123456")
            >>> nid.masked()
            '3** ** ** **** 3456'
        """
        return mask_nid(self._raw)  # type: ignore[arg-type]

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(
        self,
        *,
        locale: str = LOCALE_EN,
        include_birth_date: bool = True,
        include_raw: bool = False,
        minimum_age: int = DEFAULT_ADULT_AGE,
    ) -> Dict[str, Any]:
        """Serialise the NationalID to a plain dictionary.

        Args:
            locale: Language for governorate name (``"en"`` or ``"ar"``).
            include_birth_date: Set to ``False`` to omit :attr:`birth_date`
                                from the output (privacy/masking).
            include_raw: Set to ``True`` to include the raw 14-digit string.
            minimum_age: Age threshold for the ``is_adult`` field.

        Returns:
            A ``dict`` containing all (optionally masked) fields.
        """
        data: Dict[str, Any] = {
            "gender": self.gender,
            "governorate_code": self.governorate_code,
            "governorate_name": self.governorate_name_localized(locale),
            "born_outside_egypt": self.born_outside_egypt,
            "age": self.age,
            "is_adult": self.is_adult(minimum_age),
        }
        if include_birth_date:
            data["birth_date"] = self.birth_date.isoformat()
        else:
            data["birth_date"] = None
        if include_raw:
            data["raw"] = self.raw
        return data

    def to_json(
        self,
        *,
        locale: str = LOCALE_EN,
        include_birth_date: bool = True,
        include_raw: bool = False,
        minimum_age: int = DEFAULT_ADULT_AGE,
        indent: Optional[int] = 2,
    ) -> str:
        """Serialise the NationalID to a JSON string.

        Args:
            locale: Language for governorate name.
            include_birth_date: Whether to include the birth date.
            include_raw: Whether to include the raw ID string.
            minimum_age: Age threshold for ``is_adult``.
            indent: JSON indentation level.  ``None`` for compact output.

        Returns:
            A JSON-encoded string.
        """
        return json.dumps(
            self.to_dict(
                locale=locale,
                include_birth_date=include_birth_date,
                include_raw=include_raw,
                minimum_age=minimum_age,
            ),
            ensure_ascii=False,
            indent=indent,
        )

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"NationalID("
            f"raw={self._raw!r}, "
            f"birth_date={self._birth_date!r}, "
            f"gender={self.gender!r}, "
            f"governorate={self._governorate_name_en!r}, "
            f"age={self.age}"
            f")"
        )

    def __eq__(self, other: object) -> bool:
        if isinstance(other, NationalID):
            return self._raw == other._raw
        return NotImplemented

    def __hash__(self) -> int:
        return hash(self._raw)
