"""Statistical aggregation helpers for collections of :class:`~egypt_nid.models.NationalID`.

All functions return typed, structured results for programmatic use.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence

from egypt_nid.models import NationalID


@dataclass(frozen=True)
class BulkStats:
    """Aggregated statistics over a collection of parsed National IDs.

    Attributes:
        count: Total number of IDs in the collection.
        average_age: Mean age across all IDs (``None`` if *count* is 0).
        gender_distribution: Mapping of gender → count.
        governorate_distribution: Mapping of governorate code → count.
        born_outside_egypt_count: Number of foreign-born IDs.
    """

    count: int
    average_age: Optional[float]
    gender_distribution: Dict[str, int]
    governorate_distribution: Dict[str, int]
    born_outside_egypt_count: int

    def to_dict(self) -> Dict[str, object]:
        """Return a plain-dict representation suitable for JSON serialisation.

        Returns:
            Dictionary with all statistical fields.
        """
        return {
            "count": self.count,
            "average_age": self.average_age,
            "gender_distribution": dict(self.gender_distribution),
            "governorate_distribution": dict(self.governorate_distribution),
            "born_outside_egypt_count": self.born_outside_egypt_count,
        }


def compute_stats(nids: Iterable[NationalID]) -> BulkStats:
    """Compute aggregate statistics for *nids*.

    Args:
        nids: Any iterable of :class:`~egypt_nid.models.NationalID` objects.

    Returns:
        A :class:`BulkStats` instance with counts, averages, and distributions.

    Examples:
        >>> stats = compute_stats(parsed_list)
        >>> stats.average_age
        34.7
    """
    items: List[NationalID] = list(nids)

    if not items:
        return BulkStats(
            count=0,
            average_age=None,
            gender_distribution={},
            governorate_distribution={},
            born_outside_egypt_count=0,
        )

    ages = [n.age for n in items]
    avg_age = sum(ages) / len(ages)

    gender_counts: Counter[str] = Counter(n.gender for n in items)
    gov_counts: Counter[str] = Counter(n.governorate_code for n in items)
    foreign_count = sum(1 for n in items if n.born_outside_egypt)

    return BulkStats(
        count=len(items),
        average_age=round(avg_age, 2),
        gender_distribution=dict(gender_counts),
        governorate_distribution=dict(gov_counts),
        born_outside_egypt_count=foreign_count,
    )
