"""Minimal setup.py for environments without hatchling (legacy fallback)."""
from setuptools import setup, find_packages

setup(
    name="egypt-nid",
    version="0.1.0",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    package_data={"egypt_nid": ["py.typed"]},
    python_requires=">=3.8",
    entry_points={"console_scripts": ["egypt-nid=egypt_nid.cli:main"]},
)
