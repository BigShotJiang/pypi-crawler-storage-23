"""Tests for the egypt-nid CLI."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from egypt_nid.cli import main


class TestCLISingleNID:
    def test_valid_nid_exit_zero(self, valid_nid_str):
        assert main([valid_nid_str]) == 0

    def test_invalid_nid_pretty(self, capsys):
        result = main(["00000000000000"])
        # The error is printed to stderr; exit 0 because pretty mode handles it
        assert isinstance(result, int)

    def test_json_output(self, valid_nid_str, capsys):
        main(["--json", valid_nid_str])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert "gender" in data

    def test_no_args_exit_two(self):
        assert main([]) == 2

    def test_version(self):
        with pytest.raises(SystemExit) as exc:
            main(["--version"])
        assert exc.value.code == 0


class TestCLIBulk:
    def test_bulk_valid_file(self, valid_nid_str, tmp_path):
        f = tmp_path / "ids.txt"
        f.write_text(valid_nid_str + "\n")
        result = main(["--bulk", str(f)])
        assert result == 0

    def test_bulk_missing_file(self):
        result = main(["--bulk", "/nonexistent/path/ids.txt"])
        assert result == 2

    def test_bulk_json_output(self, valid_nid_str, tmp_path, capsys):
        f = tmp_path / "ids.txt"
        f.write_text(valid_nid_str + "\n")
        main(["--bulk", str(f), "--json"])
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert "total" in data
        assert "stats" in data

    def test_bulk_with_errors(self, valid_nid_str, tmp_path):
        f = tmp_path / "ids.txt"
        f.write_text(valid_nid_str + "\nbadnid\n")
        result = main(["--bulk", str(f)])
        assert result == 1  # errors present
