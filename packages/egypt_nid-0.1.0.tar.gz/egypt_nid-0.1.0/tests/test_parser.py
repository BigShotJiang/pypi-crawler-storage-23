"""Tests for egypt_nid.parser."""

from __future__ import annotations

import pytest

from egypt_nid import parse, parse_lenient
from egypt_nid.exceptions import ChecksumError, EgyptNIDError


class TestParse:
    def test_valid(self, valid_nid_str):
        nid = parse(valid_nid_str)
        assert nid.raw == valid_nid_str

    def test_caching(self, valid_nid_str):
        a = parse(valid_nid_str)
        b = parse(valid_nid_str)
        assert a is b  # same cached object

    def test_invalid_raises(self):
        with pytest.raises(EgyptNIDError):
            parse("00000000000000")

    def test_custom_governorates(self, valid_nid_str):
        from egypt_nid.constants import GOVERNORATES_V1
        nid = parse(valid_nid_str, custom_governorates=GOVERNORATES_V1)
        assert nid is not None

    def test_bad_version(self, valid_nid_str):
        from egypt_nid.exceptions import ConfigurationError
        with pytest.raises(ConfigurationError):
            parse(valid_nid_str, version="v999")


class TestParseLenient:
    def test_valid_returns_model(self, valid_nid_str):
        nid, result = parse_lenient(valid_nid_str)
        assert nid is not None
        assert result.valid

    def test_bad_checksum_returns_model_with_warning(self, valid_nid_str):
        bad = valid_nid_str[:-1] + str((int(valid_nid_str[-1]) + 1) % 10)
        nid, result = parse_lenient(bad)
        assert nid is not None  # lenient builds model despite bad checksum
        assert not result.valid
        assert "checksum" in result.warnings

    def test_critical_error_returns_none(self):
        nid, result = parse_lenient("123")
        assert nid is None
        assert not result.valid
