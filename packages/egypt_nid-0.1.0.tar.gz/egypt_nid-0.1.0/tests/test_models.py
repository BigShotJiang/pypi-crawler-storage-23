"""Tests for egypt_nid.models.NationalID."""

from __future__ import annotations

import json
import datetime

import pytest

from egypt_nid import parse
from egypt_nid.models import NationalID


class TestNationalIDAttributes:
    def test_birth_date(self, nid_male_cairo):
        assert nid_male_cairo.birth_date == datetime.date(2001, 5, 15)

    def test_gender_male(self, nid_male_cairo):
        assert nid_male_cairo.gender == "male"

    def test_gender_female(self, nid_female_alex):
        assert nid_female_alex.gender == "female"

    def test_governorate_en(self, nid_male_cairo):
        assert nid_male_cairo.governorate_name_en == "Cairo"

    def test_governorate_ar(self, nid_male_cairo):
        assert nid_male_cairo.governorate_name_ar == "القاهرة"

    def test_born_outside_egypt_false(self, nid_male_cairo):
        assert not nid_male_cairo.born_outside_egypt

    def test_born_outside_egypt_true(self, nid_foreign):
        assert nid_foreign.born_outside_egypt

    def test_age_is_non_negative(self, nid_male_cairo):
        assert nid_male_cairo.age >= 0

    def test_is_adult_default(self, nid_female_alex):
        # Born 1990 → definitely adult
        assert nid_female_alex.is_adult()

    def test_is_adult_custom_threshold(self, nid_female_alex):
        assert nid_female_alex.is_adult(minimum_age=80) is False

    def test_governorate_localized_en(self, nid_male_cairo):
        assert nid_male_cairo.governorate_name_localized("en") == "Cairo"

    def test_governorate_localized_ar(self, nid_male_cairo):
        assert nid_male_cairo.governorate_name_localized("ar") == "القاهرة"

    def test_governorate_localized_invalid(self, nid_male_cairo):
        with pytest.raises(ValueError):
            nid_male_cairo.governorate_name_localized("fr")


class TestImmutability:
    def test_cannot_set_attribute(self, nid_male_cairo):
        with pytest.raises(AttributeError):
            nid_male_cairo.gender = "female"  # type: ignore[misc]

    def test_cannot_delete_attribute(self, nid_male_cairo):
        with pytest.raises(AttributeError):
            del nid_male_cairo._raw


class TestMasked:
    def test_starts_with_century(self, nid_male_cairo):
        masked = nid_male_cairo.masked()
        assert masked.startswith("3")

    def test_contains_stars(self, nid_male_cairo):
        assert "*" in nid_male_cairo.masked()


class TestToDict:
    def test_contains_expected_keys(self, nid_male_cairo):
        d = nid_male_cairo.to_dict()
        assert "birth_date" in d
        assert "gender" in d
        assert "governorate_name" in d
        assert "age" in d
        assert "is_adult" in d
        assert "born_outside_egypt" in d

    def test_birth_date_masked(self, nid_male_cairo):
        d = nid_male_cairo.to_dict(include_birth_date=False)
        assert d["birth_date"] is None

    def test_include_raw(self, nid_male_cairo):
        d = nid_male_cairo.to_dict(include_raw=True)
        assert "raw" in d

    def test_arabic_locale(self, nid_male_cairo):
        d = nid_male_cairo.to_dict(locale="ar")
        assert d["governorate_name"] == "القاهرة"


class TestToJson:
    def test_valid_json(self, nid_male_cairo):
        j = nid_male_cairo.to_json()
        data = json.loads(j)
        assert data["gender"] == "male"

    def test_compact_json(self, nid_male_cairo):
        j = nid_male_cairo.to_json(indent=None)
        assert "\n" not in j


class TestEquality:
    def test_equal_same_raw(self, valid_nid_str):
        a = parse(valid_nid_str)
        b = parse(valid_nid_str)
        assert a == b

    def test_not_equal_different(self, nid_male_cairo, nid_female_alex):
        assert nid_male_cairo != nid_female_alex

    def test_hash_consistency(self, valid_nid_str):
        a = parse(valid_nid_str)
        b = parse(valid_nid_str)
        assert hash(a) == hash(b)


class TestRepr:
    def test_repr_contains_raw(self, nid_male_cairo, valid_nid_str):
        r = repr(nid_male_cairo)
        assert valid_nid_str in r
        assert "NationalID" in r
