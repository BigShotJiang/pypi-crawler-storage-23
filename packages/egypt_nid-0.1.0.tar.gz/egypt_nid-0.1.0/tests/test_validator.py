"""Tests for egypt_nid.validator."""

from __future__ import annotations

import pytest

from egypt_nid.constants import GOVERNORATES_V1
from egypt_nid.exceptions import (
    BirthDateError,
    CenturyError,
    ChecksumError,
    GovernorateError,
    LengthError,
    NonNumericError,
)
from egypt_nid.validator import LenientValidator, StrictValidator

GOVS = GOVERNORATES_V1


def make_strict() -> StrictValidator:
    return StrictValidator(GOVS)


def make_lenient() -> LenientValidator:
    return LenientValidator(GOVS)


# ---------------------------------------------------------------------------
# StrictValidator
# ---------------------------------------------------------------------------

class TestStrictValidatorLength:
    def test_short(self):
        with pytest.raises(LengthError):
            make_strict().validate("123")

    def test_long(self):
        with pytest.raises(LengthError):
            make_strict().validate("1" * 15)


class TestStrictValidatorNumeric:
    def test_alpha(self):
        with pytest.raises(NonNumericError):
            make_strict().validate("3010515010123X")


class TestStrictValidatorCentury:
    def test_bad_century(self):
        with pytest.raises(CenturyError):
            make_strict().validate("10105150101230")


class TestStrictValidatorBirthDate:
    def test_invalid_month(self):
        # month 13
        with pytest.raises(BirthDateError):
            make_strict().validate("30113150101230")

    def test_future_date(self):
        # year 2099 in 2000s century → definitely future
        with pytest.raises(BirthDateError):
            make_strict().validate("39901010101230")


class TestStrictValidatorGovernorate:
    def test_unknown_code(self):
        # Code 99 is not in the map
        with pytest.raises(GovernorateError):
            make_strict().validate("30105159901230")


class TestStrictValidatorChecksum:
    def test_wrong_checksum(self, valid_nid_str):
        # Flip the last digit
        bad = valid_nid_str[:-1] + str((int(valid_nid_str[-1]) + 1) % 10)
        with pytest.raises(ChecksumError):
            make_strict().validate(bad)


# ---------------------------------------------------------------------------
# LenientValidator
# ---------------------------------------------------------------------------

class TestLenientValidator:
    def test_collects_all_warnings(self):
        # Length error should short-circuit
        result = make_lenient().validate("123")
        assert not result.valid
        assert "length" in result.warnings

    def test_valid_nid_no_warnings(self, valid_nid_str):
        result = make_lenient().validate(valid_nid_str)
        assert result.valid
        assert result.warnings == {}

    def test_bad_checksum_warning(self, valid_nid_str):
        bad = valid_nid_str[:-1] + str((int(valid_nid_str[-1]) + 1) % 10)
        result = make_lenient().validate(bad)
        assert not result.valid
        assert "checksum" in result.warnings

    def test_warning_message_content(self, valid_nid_str):
        bad = valid_nid_str[:-1] + str((int(valid_nid_str[-1]) + 1) % 10)
        result = make_lenient().validate(bad)
        assert "typo" in result.warnings["checksum"].lower() or "checksum" in result.warnings["checksum"].lower()
