"""Shared pytest fixtures for the egypt-nid test suite."""

from __future__ import annotations

import datetime

import pytest

from egypt_nid import NationalID, parse


# ---------------------------------------------------------------------------
# Known-good NIDs used across multiple test modules
# ---------------------------------------------------------------------------

# We construct a valid NID:
#   3 = century (2000s)
#   01 = year 2001
#   05 = month May
#   15 = day 15
#   01 = Cairo
#   0123 = sequence (last digit odd → male)
#   ? = Luhn check digit (computed below)

def _compute_luhn(payload: str) -> str:
    from egypt_nid.utils import luhn_checksum
    return str(luhn_checksum(payload))


# Build a valid Cairo male born 2001-05-15
_PAYLOAD_MALE_CAIRO = "3010515010123"   # 13 digits
VALID_NID_MALE_CAIRO = _PAYLOAD_MALE_CAIRO + _compute_luhn(_PAYLOAD_MALE_CAIRO)

# Build a valid Alexandria female born 1990-08-20
_PAYLOAD_FEMALE_ALEX = "2900820020124"  # 13 digits
VALID_NID_FEMALE_ALEX = _PAYLOAD_FEMALE_ALEX + _compute_luhn(_PAYLOAD_FEMALE_ALEX)

# Foreign-born NID (governorate 88)
_PAYLOAD_FOREIGN = "3010515880123"
VALID_NID_FOREIGN = _PAYLOAD_FOREIGN + _compute_luhn(_PAYLOAD_FOREIGN)


@pytest.fixture
def nid_male_cairo() -> NationalID:
    """A valid NID for a male born in Cairo on 2001-05-15."""
    return parse(VALID_NID_MALE_CAIRO)


@pytest.fixture
def nid_female_alex() -> NationalID:
    """A valid NID for a female born in Alexandria on 1990-08-20."""
    return parse(VALID_NID_FEMALE_ALEX)


@pytest.fixture
def nid_foreign() -> NationalID:
    """A valid NID for someone born outside Egypt (code 88)."""
    return parse(VALID_NID_FOREIGN)


@pytest.fixture
def valid_nid_str() -> str:
    """Return the raw string for the Cairo male NID."""
    return VALID_NID_MALE_CAIRO
