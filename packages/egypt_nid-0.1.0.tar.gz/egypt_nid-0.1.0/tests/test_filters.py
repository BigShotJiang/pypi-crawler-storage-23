"""Tests for egypt_nid.filters."""

from __future__ import annotations

import pytest

from egypt_nid import (
    filter_adults,
    filter_by_age_range,
    filter_by_gender,
    filter_by_governorate,
    filter_minors,
)


@pytest.fixture
def three_nids(nid_male_cairo, nid_female_alex, nid_foreign):
    return [nid_male_cairo, nid_female_alex, nid_foreign]


class TestFilterByGender:
    def test_male(self, three_nids, nid_male_cairo):
        result = filter_by_gender(three_nids, "male")
        assert nid_male_cairo in result

    def test_female(self, three_nids, nid_female_alex):
        result = filter_by_gender(three_nids, "female")
        assert nid_female_alex in result

    def test_invalid_gender(self, three_nids):
        with pytest.raises(ValueError):
            filter_by_gender(three_nids, "other")


class TestFilterByGovernorate:
    def test_cairo(self, three_nids, nid_male_cairo):
        result = filter_by_governorate(three_nids, "01")
        assert nid_male_cairo in result

    def test_unknown_code_returns_empty(self, three_nids):
        assert filter_by_governorate(three_nids, "99") == []


class TestFilterByAgeRange:
    def test_basic(self, three_nids, nid_female_alex):
        result = filter_by_age_range(three_nids, 30, 60)
        assert nid_female_alex in result

    def test_invalid_range(self, three_nids):
        with pytest.raises(ValueError):
            filter_by_age_range(three_nids, 50, 10)


class TestAdultsMinors:
    def test_adults(self, three_nids):
        result = filter_adults(three_nids)
        assert len(result) > 0

    def test_minors_empty_for_older_people(self, three_nids):
        # All our fixtures should be adults by default
        result = filter_minors(three_nids)
        # May or may not be empty depending on test date, but shouldn't error
        assert isinstance(result, list)
