"""Tests for egypt_nid.utils."""

from __future__ import annotations

import datetime

import pytest

from egypt_nid.utils import (
    build_birth_date,
    calculate_age,
    is_valid_luhn,
    luhn_checksum,
    mask_nid,
)


class TestLuhnChecksum:
    def test_known_values(self):
        # For payload of 13 zeros, check digit should be 0
        assert luhn_checksum("0" * 13) == 0

    def test_type_is_int(self):
        result = luhn_checksum("1234567890123")
        assert isinstance(result, int)
        assert 0 <= result <= 9


class TestIsValidLuhn:
    def test_valid_all_zeros(self):
        # 13 zeros + 0 passes Luhn
        assert is_valid_luhn("0" * 13 + "0")

    def test_invalid_wrong_digit(self):
        nid = "0" * 13 + "1"  # check digit wrong
        assert not is_valid_luhn(nid)


class TestBuildBirthDate:
    def test_valid_2000s(self):
        d = build_birth_date("3", "01", "05", "15")
        assert d == datetime.date(2001, 5, 15)

    def test_valid_1900s(self):
        d = build_birth_date("2", "90", "08", "20")
        assert d == datetime.date(1990, 8, 20)

    def test_invalid_month(self):
        assert build_birth_date("3", "01", "13", "01") is None

    def test_invalid_day(self):
        assert build_birth_date("3", "01", "02", "30") is None

    def test_invalid_century(self):
        assert build_birth_date("1", "01", "01", "01") is None


class TestCalculateAge:
    def test_simple(self):
        ref = datetime.date(2024, 1, 1)
        birth = datetime.date(2000, 1, 1)
        assert calculate_age(birth, reference=ref) == 24

    def test_birthday_not_yet(self):
        ref = datetime.date(2024, 6, 1)
        birth = datetime.date(2000, 12, 31)
        assert calculate_age(birth, reference=ref) == 23

    def test_birthday_today(self):
        today = datetime.date.today()
        birth = datetime.date(today.year - 30, today.month, today.day)
        assert calculate_age(birth) == 30

    def test_zero_age(self):
        today = datetime.date.today()
        assert calculate_age(today) == 0


class TestMaskNid:
    def test_masks_middle(self):
        raw = "30105150123456"
        masked = mask_nid(raw)
        assert masked.startswith("3")
        assert "****" in masked
        assert len(masked) > 10

    def test_short_passthrough(self):
        assert mask_nid("123") == "123"
