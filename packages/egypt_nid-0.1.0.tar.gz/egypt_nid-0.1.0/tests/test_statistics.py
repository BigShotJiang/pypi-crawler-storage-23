"""Tests for egypt_nid.statistics."""

from __future__ import annotations

import pytest

from egypt_nid import compute_stats


class TestComputeStats:
    def test_empty(self):
        stats = compute_stats([])
        assert stats.count == 0
        assert stats.average_age is None
        assert stats.gender_distribution == {}

    def test_count(self, nid_male_cairo, nid_female_alex):
        stats = compute_stats([nid_male_cairo, nid_female_alex])
        assert stats.count == 2

    def test_gender_distribution(self, nid_male_cairo, nid_female_alex):
        stats = compute_stats([nid_male_cairo, nid_female_alex])
        assert stats.gender_distribution.get("male", 0) >= 1
        assert stats.gender_distribution.get("female", 0) >= 1

    def test_average_age(self, nid_male_cairo):
        stats = compute_stats([nid_male_cairo])
        assert stats.average_age == float(nid_male_cairo.age)

    def test_born_outside_count(self, nid_male_cairo, nid_foreign):
        stats = compute_stats([nid_male_cairo, nid_foreign])
        assert stats.born_outside_egypt_count == 1

    def test_to_dict(self, nid_male_cairo):
        stats = compute_stats([nid_male_cairo])
        d = stats.to_dict()
        assert "count" in d
        assert "average_age" in d
        assert "gender_distribution" in d
