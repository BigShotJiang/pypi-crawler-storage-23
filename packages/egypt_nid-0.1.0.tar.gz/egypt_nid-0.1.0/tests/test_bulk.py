"""Tests for parse_bulk and framework integration helpers."""

from __future__ import annotations

import pytest

from egypt_nid import parse_bulk
from egypt_nid.exceptions import EgyptNIDError


class TestParseBulk:
    def test_all_valid(self, valid_nid_str):
        results = parse_bulk([valid_nid_str, valid_nid_str])
        assert len(results) == 2

    def test_skip_errors_default(self, valid_nid_str):
        results = parse_bulk([valid_nid_str, "badnid"])
        assert len(results) == 1

    def test_skip_errors_false(self, valid_nid_str):
        with pytest.raises(EgyptNIDError):
            parse_bulk([valid_nid_str, "badnid"], skip_errors=False)

    def test_empty_input(self):
        assert parse_bulk([]) == []

    def test_returns_list(self, valid_nid_str):
        result = parse_bulk([valid_nid_str])
        assert isinstance(result, list)


class TestFrameworkIntegrationReadiness:
    """Smoke tests demonstrating framework-friendly usage patterns."""

    def test_django_style_validator(self, valid_nid_str):
        """Demonstrates use as a Django field validator."""
        from egypt_nid import parse
        from egypt_nid.exceptions import EgyptNIDError

        def validate_nid(value: str) -> None:
            try:
                parse(value)
            except EgyptNIDError as exc:
                raise ValueError(str(exc)) from exc

        # Valid – should not raise
        validate_nid(valid_nid_str)

        # Invalid – should raise ValueError
        with pytest.raises(ValueError):
            validate_nid("bad")

    def test_pandas_style_apply(self, valid_nid_str):
        """Demonstrates use in a pandas-like apply pattern."""
        from egypt_nid import parse
        from egypt_nid.exceptions import EgyptNIDError

        def extract_gender(nid_str: str) -> str:
            try:
                return parse(nid_str).gender
            except EgyptNIDError:
                return "unknown"

        data = [valid_nid_str, "bad"]
        genders = [extract_gender(d) for d in data]
        assert genders[0] in ("male", "female")
        assert genders[1] == "unknown"
