"""Property-based tests using Hypothesis.

These tests verify that the library behaves correctly across a wide
space of generated inputs, not just hand-crafted examples.
"""

from __future__ import annotations

import datetime

import pytest
from hypothesis import given, settings, assume
from hypothesis import strategies as st

from egypt_nid import parse
from egypt_nid.exceptions import EgyptNIDError
from egypt_nid.utils import calculate_age, luhn_checksum


# ---------------------------------------------------------------------------
# Helper to build a syntactically valid NID
# ---------------------------------------------------------------------------

def _build_valid_nid(century: str, year: int, month: int, day: int, gov: str, seq: int) -> str:
    """Construct a Luhn-valid NID from components."""
    year_s = f"{year:02d}"
    month_s = f"{month:02d}"
    day_s = f"{day:02d}"
    seq_s = f"{seq:04d}"
    payload = f"{century}{year_s}{month_s}{day_s}{gov}{seq_s}"
    check = luhn_checksum(payload)
    return payload + str(check)


VALID_GOVS = [
    "01", "02", "03", "04", "11", "12", "13", "14", "15",
    "16", "17", "18", "19", "21", "22", "23", "24", "25",
    "26", "27", "28", "29", "31", "32", "33", "34", "35", "88",
]


@st.composite
def valid_nid_strategy(draw):
    century = draw(st.sampled_from(["2", "3"]))
    if century == "2":
        year = draw(st.integers(min_value=0, max_value=99))
        # Ensure not future: if year >= current_year's last 2 digits,
        # it would be 1900+year which is always in the past
        full_year = 1900 + year
    else:
        # 2000+year – must not be in the future
        current_year_last2 = datetime.date.today().year - 2000
        year = draw(st.integers(min_value=0, max_value=current_year_last2))
        full_year = 2000 + year

    # Generate a valid month/day combo
    month = draw(st.integers(min_value=1, max_value=12))
    import calendar
    max_day = calendar.monthrange(full_year, month)[1]
    day = draw(st.integers(min_value=1, max_value=max_day))

    # Ensure not in the future
    born = datetime.date(full_year, month, day)
    assume(born <= datetime.date.today())

    gov = draw(st.sampled_from(VALID_GOVS))
    seq = draw(st.integers(min_value=0, max_value=9999))

    return _build_valid_nid(century, year, month, day, gov, seq)


class TestPropertyBasedParsing:
    @given(valid_nid_strategy())
    @settings(max_examples=200)
    def test_valid_nid_always_parses(self, nid_str):
        """Any correctly constructed NID should parse without error."""
        nid = parse(nid_str)
        assert nid is not None
        assert nid.raw == nid_str

    @given(valid_nid_strategy())
    @settings(max_examples=100)
    def test_age_non_negative(self, nid_str):
        nid = parse(nid_str)
        assert nid.age >= 0

    @given(valid_nid_strategy())
    @settings(max_examples=100)
    def test_gender_is_valid(self, nid_str):
        nid = parse(nid_str)
        assert nid.gender in ("male", "female")

    @given(valid_nid_strategy())
    @settings(max_examples=100)
    def test_to_dict_roundtrip(self, nid_str):
        nid = parse(nid_str)
        d = nid.to_dict()
        assert isinstance(d, dict)
        assert "gender" in d

    @given(valid_nid_strategy())
    @settings(max_examples=100)
    def test_masked_preserves_century(self, nid_str):
        nid = parse(nid_str)
        assert nid.masked()[0] == nid_str[0]


class TestPropertyBasedInvalidInputs:
    @given(st.text(min_size=0, max_size=30))
    @settings(max_examples=200)
    def test_random_strings_never_crash(self, text):
        """Parsing arbitrary strings should raise EgyptNIDError, not crash."""
        try:
            parse(text)
        except EgyptNIDError:
            pass  # expected
        except Exception as exc:
            pytest.fail(f"Unexpected exception {type(exc).__name__}: {exc}")

    @given(st.integers(min_value=0, max_value=9))
    def test_luhn_check_digit_in_range(self, _):
        """Luhn check digit is always 0–9."""
        import random
        payload = "".join(str(random.randint(0, 9)) for _ in range(13))
        result = luhn_checksum(payload)
        assert 0 <= result <= 9


class TestCalculateAgeProperty:
    @given(
        st.dates(
            min_value=datetime.date(1900, 1, 1),
            max_value=datetime.date.today(),
        )
    )
    def test_age_always_non_negative(self, birth_date):
        assert calculate_age(birth_date) >= 0

    @given(
        st.dates(
            min_value=datetime.date(1900, 1, 1),
            max_value=datetime.date.today(),
        )
    )
    def test_age_reasonable_upper_bound(self, birth_date):
        # Nobody is older than 130 years in our data
        assert calculate_age(birth_date) <= 130
