# Contributing to egypt-nid

Thank you for your interest in contributing! This document describes the process and standards.

## Development Setup

```bash
git clone https://github.com/Mohamed-omara-alt/egypt-nid.git
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
pre-commit install
```

## Running Tests

```bash
# All tests
pytest

# With coverage
pytest --cov=egypt_nid --cov-report=term-missing

# Property-based tests only
pytest tests/test_property_based.py -v
```

## Code Quality

Before opening a PR, ensure all checks pass:

```bash
ruff check src/ tests/
black --check src/ tests/
mypy src/egypt_nid --strict
```

## Standards

- All public functions and classes must have Google-style docstrings with `Args`, `Returns`, `Raises`, and `Examples`.
- New features require corresponding unit tests and, where applicable, Hypothesis property tests.
- Type annotations are mandatory; `mypy --strict` must pass.
- Code is formatted with `black` (line length 99) and linted with `ruff`.

## Pull Request Process

1. Fork the repository and create a feature branch.
2. Write tests for new behaviour.
3. Ensure all CI checks pass.
4. Update `CHANGELOG.md` under `[Unreleased]`.
5. Open a pull request with a clear description.

## Reporting Bugs

Please open a GitHub Issue with:
- Python version
- egypt-nid version
- Minimal reproducible example
- Expected vs. actual behaviour
