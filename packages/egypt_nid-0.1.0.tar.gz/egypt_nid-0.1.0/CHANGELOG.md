# Changelog

All notable changes to **egypt-nid** are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and the project adheres to [Semantic Versioning](https://semver.org/).

---

## [Unreleased]

## [0.1.0] – 2024-01-01

### Added
- Initial release.
- Full 14-digit NID validation: length, numeric, century, birth date, governorate, Luhn checksum.
- Strict mode (`parse`) and lenient mode (`parse_lenient`).
- Immutable `NationalID` value object with rich repr, `to_dict()`, `to_json()`, `masked()`.
- Governorate names in English and Arabic with locale support (`"en"` / `"ar"`).
- Versioned governorate maps (`GOVERNORATES_V1`) with custom override support.
- `parse_bulk` for efficient list processing with `skip_errors` option.
- Filtering helpers: `filter_by_gender`, `filter_by_governorate`, `filter_by_age_range`, `filter_adults`, `filter_minors`, `filter_born_outside_egypt`.
- `compute_stats` returning `BulkStats` with average age, gender distribution, governorate distribution, foreign-born count.
- CLI tool `egypt-nid` with pretty output, JSON output, bulk mode, lenient mode.
- LRU cache (4096 entries) for repeated parses.
- `py.typed` marker for PEP 561 compliance.
- Full test suite: unit tests, property-based tests (Hypothesis), CLI tests.
- GitHub Actions CI/CD workflow.
- Pre-commit hooks configuration.
