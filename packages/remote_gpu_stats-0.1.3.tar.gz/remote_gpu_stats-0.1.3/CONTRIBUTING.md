# Run locally

`uv run remote-gpu-stats <username>`

# Publish to PyPI

`uv version --bump <patch|minor|major>`
`uv build`
`uv publish`