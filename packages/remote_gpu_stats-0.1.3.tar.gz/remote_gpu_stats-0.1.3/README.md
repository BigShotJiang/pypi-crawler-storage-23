# Usage

`uvx remote-gpu-stats <username>` where `<username>` is your SSH username for the informatik pcs.

# Example

![Example Screenshot](example.png)