sphinx-gallery
==============

Sphinx extension for generating example galleries from Python scripts.

- **Documentation**: https://sphinx-gallery.github.io/
- **Source Code**: https://github.com/sphinx-gallery/sphinx-gallery

Example
-------

The examples below demonstrate various sphinx-gallery features and provide
visual elements for theme styling purposes.
