# sphinxcontrib-youtube

Sphinx extension that enables embedding of videos from YouTube.

- **Documentation**: [https://sphinxcontrib-youtube.readthedocs.io/](https://sphinxcontrib-youtube.readthedocs.io/)
- **Source Code**: [https://github.com/sphinx-contrib/youtube](https://github.com/sphinx-contrib/youtube)

## Example

```{youtube} dQw4w9WgXcQ
:width: 100%
```
