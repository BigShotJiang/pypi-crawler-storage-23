# sphinxcontrib-video

Sphinx extension that enables embedding of HTML5 videos.

- **Documentation**: [https://sphinxcontrib-video.readthedocs.io/](https://sphinxcontrib-video.readthedocs.io/)
- **Source Code**: [https://github.com/sphinx-contrib/video](https://github.com/sphinx-contrib/video)

## Example

```{video} https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm
```
