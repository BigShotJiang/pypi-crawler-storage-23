"""
drayage: OCI registry pull-through cache.
"""

try:
    from importlib.metadata import version
    __version__ = version("drayage")
except ImportError:
    from importlib_metadata import version
    __version__ = version("drayage")
