"""IMAGIN Docs MCP Local - Local MCP server for CDN documentation RAG."""

__version__ = "0.1.0"
