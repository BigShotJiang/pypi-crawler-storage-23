"""Version information for anymap-ts."""

__version__ = "0.10.1"
