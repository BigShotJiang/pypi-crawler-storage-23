"""Allow running plutus as `python -m plutus`."""

from plutus.cli import main

main()
