"""OpenAI 클라이언트 팩토리 (Gemini Vision API용, 3-tier 키 해석)."""

from __future__ import annotations

import os

from dotenv import load_dotenv
from openai import OpenAI

from readitdown.exceptions import APIKeyMissingError

GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"


def create_client(api_key: str | None = None) -> OpenAI:
    """OpenAI 클라이언트를 생성합니다.

    API 키 해석 순서:
      1. 명시적 파라미터
      2. 환경변수 GEMINI_API_KEY
      3. .env 파일 (python-dotenv)
    """
    if api_key is None:
        api_key = os.environ.get("GEMINI_API_KEY")

    if api_key is None:
        load_dotenv()
        api_key = os.environ.get("GEMINI_API_KEY")

    if not api_key:
        raise APIKeyMissingError()

    return OpenAI(api_key=api_key, base_url=GEMINI_BASE_URL)
