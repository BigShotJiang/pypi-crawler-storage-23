"""메인 변환 라우터."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from openai import OpenAI

from readitdown.client import create_client
from readitdown.exceptions import UnsupportedFormatError

HWP_EXTENSIONS = {".hwp", ".hwpx", ".hwt", ".hml", ".hwx", ".gul"}
MARKITDOWN_EXTENSIONS = {".docx", ".pptx", ".doc", ".ppt"}
VISION_EXTENSIONS = {".pdf", ".jpg", ".jpeg", ".png"}
EXCEL_EXTENSIONS = {".xlsx", ".xls"}
SUPPORTED_EXTENSIONS = HWP_EXTENSIONS | MARKITDOWN_EXTENSIONS | VISION_EXTENSIONS | EXCEL_EXTENSIONS


@dataclass
class ConvertStats:
    """디렉토리 변환 통계."""

    success: int = 0
    skipped: int = 0
    failed: int = 0
    errors: list[tuple[str, str]] = field(default_factory=list)


def convert_file(
    file_path: str | Path,
    *,
    api_key: str | None = None,
    client: OpenAI | None = None,
    on_page: Callable[[int, int], None] | None = None,
) -> str:
    """단일 파일을 마크다운으로 변환합니다.

    Args:
        file_path: 변환할 파일 경로
        api_key: Gemini API 키 (없으면 환경변수/.env에서 탐색)
        client: 기존 OpenAI 클라이언트 (재사용 시)
        on_page: PDF 페이지 진행 콜백 (current, total)

    Returns:
        변환된 마크다운 문자열

    Raises:
        UnsupportedFormatError: 지원하지 않는 형식
        ConversionError: 변환 실패
        APIKeyMissingError: API 키 미설정 (Vision 백엔드 필요 시)
    """
    file_path = Path(file_path)
    ext = file_path.suffix.lower()

    if ext not in SUPPORTED_EXTENSIONS:
        raise UnsupportedFormatError(ext)

    # Vision 백엔드가 필요한 형식은 클라이언트 생성
    needs_vision = ext in (HWP_EXTENSIONS | VISION_EXTENSIONS)
    if needs_vision and client is None:
        client = create_client(api_key)

    if ext in HWP_EXTENSIONS:
        from readitdown.backends.hwp import convert_hwp

        return convert_hwp(client, file_path, on_page=on_page)
    elif ext == ".pdf":
        from readitdown.backends.vision import convert_pdf

        return convert_pdf(client, file_path, on_page=on_page)
    elif ext in {".jpg", ".jpeg", ".png"}:
        from readitdown.backends.vision import convert_image

        return convert_image(client, file_path)
    elif ext in EXCEL_EXTENSIONS:
        from readitdown.backends.office import convert_excel

        return convert_excel(file_path)
    elif ext in MARKITDOWN_EXTENSIONS:
        from readitdown.backends.office import convert_office

        return convert_office(file_path)

    raise UnsupportedFormatError(ext)


def convert_dir(
    input_dir: str | Path,
    output_dir: str | Path,
    *,
    api_key: str | None = None,
    skip_existing: bool = False,
    only: str | None = None,
    on_file: Callable[[Path, str], None] | None = None,
    on_page: Callable[[int, int], None] | None = None,
    on_error: Callable[[Path, Exception], None] | None = None,
) -> ConvertStats:
    """디렉토리 내 모든 지원 파일을 일괄 변환합니다.

    Args:
        input_dir: 원본 파일 디렉토리
        output_dir: 변환 결과 저장 디렉토리
        api_key: Gemini API 키
        skip_existing: 이미 변환된 파일 건너뛰기
        only: 파일명 필터 문자열
        on_file: 파일 처리 콜백 (path, status)
        on_page: PDF 페이지 진행 콜백 (current, total)
        on_error: 오류 발생 콜백 (path, exception)

    Returns:
        ConvertStats 통계 객체
    """
    input_dir = Path(input_dir)
    output_dir = Path(output_dir)
    stats = ConvertStats()

    # 파일 수집
    files = sorted(
        f
        for f in input_dir.rglob("*")
        if f.is_file() and f.suffix.lower() in SUPPORTED_EXTENSIONS
    )

    if only:
        files = [f for f in files if only in str(f)]

    if not files:
        return stats

    client = create_client(api_key)

    for file_path in files:
        rel = file_path.relative_to(input_dir)
        out_path = output_dir / rel.with_suffix(".md")

        if skip_existing and out_path.exists():
            if on_file:
                on_file(file_path, "skipped")
            stats.skipped += 1
            continue

        if on_file:
            on_file(file_path, "converting")

        out_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            result = convert_file(
                file_path, client=client, on_page=on_page
            )
            out_path.write_text(result, encoding="utf-8")
            if on_file:
                on_file(file_path, f"done:{len(result)}")
            stats.success += 1
        except Exception as e:
            if on_error:
                on_error(file_path, e)
            stats.failed += 1
            stats.errors.append((str(rel), str(e)))

    return stats


def supported_formats() -> dict[str, list[str]]:
    """지원 형식을 카테고리별로 반환합니다."""
    return {
        "HWP (LibreOffice)": sorted(HWP_EXTENSIONS),
        "PDF (Gemini Vision)": sorted(VISION_EXTENSIONS - {".jpg", ".jpeg", ".png"}),
        "이미지 (Gemini Vision)": sorted({".jpg", ".jpeg", ".png"}),
        "Excel (markitdown)": sorted(EXCEL_EXTENSIONS),
        "Office (markitdown)": sorted(MARKITDOWN_EXTENSIONS),
    }
