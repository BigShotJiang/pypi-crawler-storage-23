"""doc2md 커스텀 예외."""


class Doc2mdError(Exception):
    """doc2md 기본 예외."""


class APIKeyMissingError(Doc2mdError):
    """API 키가 설정되지 않았을 때 발생."""

    def __init__(self, msg: str = "GEMINI_API_KEY가 설정되지 않았습니다."):
        super().__init__(msg)


class ConversionError(Doc2mdError):
    """문서 변환 중 오류 발생."""


class UnsupportedFormatError(Doc2mdError):
    """지원하지 않는 파일 형식."""

    def __init__(self, ext: str):
        super().__init__(f"지원하지 않는 형식입니다: {ext}")
        self.ext = ext


class LibreOfficeNotFoundError(Doc2mdError):
    """LibreOffice가 설치되지 않았을 때 발생."""

    def __init__(self):
        super().__init__(
            "LibreOffice를 찾을 수 없습니다. 설치하세요: brew install --cask libreoffice"
        )
