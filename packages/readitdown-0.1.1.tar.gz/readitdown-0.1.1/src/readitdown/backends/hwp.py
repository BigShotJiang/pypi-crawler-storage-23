"""HWP/HWPX 백엔드 (LibreOffice 기반, 실험적)."""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Callable

from readitdown.exceptions import ConversionError, LibreOfficeNotFoundError

if TYPE_CHECKING:
    from openai import OpenAI

HWP_EXTENSIONS = {".hwp", ".hwpx", ".hwt", ".hml", ".hwx", ".gul"}

SOFFICE_PATHS = [
    "/Applications/LibreOffice.app/Contents/MacOS/soffice",
    shutil.which("soffice") or "",
    shutil.which("libreoffice") or "",
]


def _find_soffice() -> str:
    for p in SOFFICE_PATHS:
        if p and os.path.isfile(p):
            return p
    raise LibreOfficeNotFoundError()


def hwp_to_pdf(hwp_path: Path, output_path: Path) -> Path:
    """HWP/HWPX 파일을 PDF로 변환합니다.

    Args:
        hwp_path: 변환할 HWP/HWPX 파일 경로
        output_path: 저장할 PDF 경로

    Returns:
        저장된 PDF 파일 경로
    """
    hwp_path = hwp_path.resolve()
    if not hwp_path.exists():
        raise FileNotFoundError(f"파일을 찾을 수 없습니다: {hwp_path}")

    soffice = _find_soffice()
    output_path = output_path.resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # LibreOffice는 출력 디렉토리만 지정 가능 → 임시 디렉토리 사용 후 이동
    with tempfile.TemporaryDirectory() as tmpdir:
        result = subprocess.run(
            [
                soffice,
                "--headless",
                "--convert-to",
                "pdf",
                "--outdir",
                tmpdir,
                str(hwp_path),
            ],
            capture_output=True,
            text=True,
            timeout=300,
        )

        if result.returncode != 0:
            raise ConversionError(f"LibreOffice 변환 실패: {result.stderr.strip()}")

        generated_pdf = Path(tmpdir) / hwp_path.with_suffix(".pdf").name
        if not generated_pdf.exists():
            raise ConversionError(
                "PDF 파일이 생성되지 않았습니다. "
                "H2Orestart 확장이 설치되어 있는지 확인하세요: unopkg list"
            )

        shutil.move(str(generated_pdf), str(output_path))

    return output_path


def convert_hwp(
    client: OpenAI,
    file_path: Path,
    *,
    on_page: Callable[[int, int], None] | None = None,
) -> str:
    """HWP/HWPX → PDF 변환 후 PDF → 마크다운 변환.

    Args:
        client: OpenAI 클라이언트
        file_path: HWP/HWPX 파일 경로
        on_page: 페이지 진행 콜백 (current, total)
    """
    from readitdown.backends.vision import convert_pdf

    with tempfile.TemporaryDirectory() as tmpdir:
        pdf_path = Path(tmpdir) / file_path.with_suffix(".pdf").name
        hwp_to_pdf(file_path, pdf_path)
        return convert_pdf(client, pdf_path, on_page=on_page)
