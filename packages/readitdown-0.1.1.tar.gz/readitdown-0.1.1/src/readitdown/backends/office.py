"""Office 문서 백엔드 (markitdown 기반)."""

from __future__ import annotations

from pathlib import Path


def convert_office(file_path: Path) -> str:
    """Office 문서(docx, pptx, doc, ppt)를 마크다운으로 변환합니다."""
    from markitdown import MarkItDown

    md = MarkItDown()
    result = md.convert(str(file_path))
    if result.text_content and len(result.text_content.strip()) > 10:
        return result.text_content
    return f"<!-- {file_path.name} - markitdown 변환 결과 없음 -->\n"


def convert_excel(file_path: Path) -> str:
    """Excel 파일을 markitdown으로 변환합니다."""
    try:
        from markitdown import MarkItDown

        md = MarkItDown()
        result = md.convert(str(file_path))
        if result.text_content and len(result.text_content.strip()) > 50:
            return result.text_content
    except Exception:
        pass

    return f"<!-- Excel 파일: {file_path.name} - markitdown 변환 실패 -->\n"
