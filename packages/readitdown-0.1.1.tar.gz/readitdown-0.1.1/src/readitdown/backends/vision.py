"""Gemini Vision 백엔드 (PDF, 이미지)."""

from __future__ import annotations

import base64
from pathlib import Path
from typing import TYPE_CHECKING, Callable

import fitz  # pymupdf

from readitdown.prompts import PROMPT_IMAGE, PROMPT_PDF

if TYPE_CHECKING:
    from openai import OpenAI

GEMINI_MODEL = "gemini-2.0-flash"


def _image_to_base64(img_bytes: bytes) -> str:
    return base64.b64encode(img_bytes).decode("utf-8")


def _call_gemini(client: OpenAI, b64_img: str, prompt: str) -> str:
    response = client.chat.completions.create(
        model=GEMINI_MODEL,
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/png;base64,{b64_img}"},
                    },
                ],
            }
        ],
        max_tokens=4096,
    )
    return response.choices[0].message.content


def convert_pdf(
    client: OpenAI,
    pdf_path: Path,
    *,
    on_page: Callable[[int, int], None] | None = None,
) -> str:
    """PDF 파일을 마크다운으로 변환합니다.

    Args:
        client: OpenAI 클라이언트
        pdf_path: PDF 파일 경로
        on_page: 페이지 진행 콜백 (current, total)
    """
    doc = fitz.open(str(pdf_path))
    pages_md = []
    total = len(doc)

    for i, page in enumerate(doc):
        if on_page:
            on_page(i + 1, total)
        mat = fitz.Matrix(2, 2)
        pix = page.get_pixmap(matrix=mat)
        b64 = _image_to_base64(pix.tobytes("png"))
        md = _call_gemini(client, b64, PROMPT_PDF)
        pages_md.append(f"<!-- Page {i + 1} -->\n{md}")

    doc.close()
    return "\n\n---\n\n".join(pages_md)


def convert_image(client: OpenAI, img_path: Path) -> str:
    """이미지 파일을 마크다운으로 변환합니다."""
    img_bytes = img_path.read_bytes()
    b64 = _image_to_base64(img_bytes)
    return _call_gemini(client, b64, PROMPT_IMAGE)
