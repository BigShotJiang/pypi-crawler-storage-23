"""readitdown CLI (Click 기반)."""

from __future__ import annotations

from pathlib import Path

import click

from readitdown.converter import convert_dir, convert_file, supported_formats


@click.group()
def main():
    """readitdown - 문서를 마크다운으로 변환합니다."""


@main.command()
@click.argument("path", type=click.Path(exists=True, path_type=Path))
@click.option("-o", "--output", type=click.Path(path_type=Path), default=None, help="출력 파일 경로")
@click.option("--api-key", envvar="GEMINI_API_KEY", default=None, help="Gemini API 키")
def file(path: Path, output: Path | None, api_key: str | None):
    """단일 파일을 마크다운으로 변환합니다.

    \b
    옵션:
      -o, --output   변환 결과를 저장할 파일 경로 (미지정 시 stdout 출력)
      --api-key      Gemini API 키 (환경변수 GEMINI_API_KEY로도 설정 가능)

    \b
    예시:
      readitdown file document.pdf
      readitdown file document.pdf -o output.md
    """

    def on_page(current: int, total: int):
        click.echo(f"  페이지 {current}/{total}...", nl=False)

    try:
        result = convert_file(path, api_key=api_key, on_page=on_page)
    except Exception as e:
        raise click.ClickException(str(e)) from e

    click.echo()

    if output:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(result, encoding="utf-8")
        click.echo(f"저장: {output} ({len(result):,}자)")
    else:
        click.echo(result)


@main.command()
@click.argument("input_dir", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.argument("output_dir", type=click.Path(path_type=Path))
@click.option("--skip-existing", is_flag=True, help="이미 변환된 파일 건너뛰기")
@click.option("--only", type=str, default=None, help="파일명 필터 (예: '경기도')")
@click.option("--api-key", envvar="GEMINI_API_KEY", default=None, help="Gemini API 키")
def dir(input_dir: Path, output_dir: Path, skip_existing: bool, only: str | None, api_key: str | None):
    """디렉토리 내 모든 문서를 일괄 변환합니다.

    \b
    옵션:
      --skip-existing  출력 디렉토리에 이미 .md 파일이 존재하면 건너뜁니다
      --only           파일명에 해당 문자열이 포함된 파일만 변환합니다
      --api-key        Gemini API 키 (환경변수 GEMINI_API_KEY로도 설정 가능)

    \b
    예시:
      readitdown dir ./docs ./output
      readitdown dir ./docs ./output --skip-existing
      readitdown dir ./docs ./output --only '경기도'
    """

    def on_file(path: Path, status: str):
        name = path.name
        if status == "skipped":
            click.echo(f"[건너뜀] {name}")
        elif status == "converting":
            click.echo(f"[변환중] {name}")
        elif status.startswith("done:"):
            chars = int(status.split(":")[1])
            click.echo(f"  → 완료 ({chars:,}자)")

    def on_page(current: int, total: int):
        click.echo(f"  페이지 {current}/{total}...", nl=False)

    def on_error(path: Path, error: Exception):
        click.echo(f"  → 오류: {error}", err=True)

    stats = convert_dir(
        input_dir,
        output_dir,
        api_key=api_key,
        skip_existing=skip_existing,
        only=only,
        on_file=on_file,
        on_page=on_page,
        on_error=on_error,
    )

    click.echo(f"\n완료: 성공 {stats.success}, 건너뜀 {stats.skipped}, 실패 {stats.failed}")


@main.command()
def formats():
    """지원하는 파일 형식을 출력합니다."""
    for category, exts in supported_formats().items():
        click.echo(f"{category}:")
        for ext in exts:
            click.echo(f"  {ext}")
        click.echo()
