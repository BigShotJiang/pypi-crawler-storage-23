# HotDot

A Python CLI tool that visualizes Graphviz DOT files as interactive, self-contained HTML pages. Designed for viewing control-flow graphs (CFGs) from compiler IR output.

## Install

```bash
pip install hotdot
```

## Usage

```bash
hotdot input.dot                    # generates input.html
hotdot input.dot -o output.html     # custom output path
hotdot input.dot --open             # open in browser after generating
hotdot input.dot --title "My Graph" # override graph title
```

## Features

- **Offline**: Generated HTML works completely offline — all JS is inlined
- **Interactive**: Click nodes to highlight connections, search by instruction text, zoom, expand/collapse
- **Dark theme**: Polished dark UI with monospace font for IR code
- **Hierarchical layout**: Top-to-bottom dagre layout for clean CFG visualization
- **Minimap**: Overview map for navigating large graphs
- **Keyboard shortcuts**: `f` fit, `Esc` deselect, `/` search

## Requirements

- Python 3.10+
- No Graphviz system install needed (uses pydot for parsing only)
