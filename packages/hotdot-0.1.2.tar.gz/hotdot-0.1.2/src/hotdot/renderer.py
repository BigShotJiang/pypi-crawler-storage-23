"""HTML renderer module.

Takes a ParsedGraph and produces a self-contained HTML string with
Cytoscape.js visualization inlined. All JS assets are read from the
vendored assets/ directory and embedded directly into the HTML.
"""

from __future__ import annotations

import json
from importlib import resources
from typing import Any

from hotdot.parser import Edge, Node, ParsedGraph


def _load_asset(filename: str) -> str:
    """Load a vendored JS asset file from the assets directory.

    Args:
        filename: Name of the JS file in the assets/ directory.

    Returns:
        The file contents as a string.
    """
    assets = resources.files("hotdot") / "assets"
    return (assets / filename).read_text(encoding="utf-8")


def _build_cytoscape_elements(graph: ParsedGraph) -> list[dict[str, Any]]:
    """Convert a ParsedGraph into Cytoscape.js elements JSON.

    Args:
        graph: The parsed graph to convert.

    Returns:
        A list of Cytoscape.js element dictionaries.
    """
    elements: list[dict[str, Any]] = []

    for node in graph.nodes:
        # Split label into first line (title) and rest (body)
        lines = node.label.split("\n")
        title = lines[0].strip() if lines else node.id
        body = "\n".join(lines[1:]).strip() if len(lines) > 1 else ""

        el: dict[str, Any] = {
            "group": "nodes",
            "data": {
                "id": node.id,
                "label": title if title else node.id,
                "fullLabel": node.label,
                "body": body,
            },
        }
        # Pass through relevant attributes
        for attr in ("shape", "style", "color", "fillcolor"):
            if attr in node.attributes:
                el["data"][attr] = node.attributes[attr]
        elements.append(el)

    for i, edge in enumerate(graph.edges):
        el = {
            "group": "edges",
            "data": {
                "id": f"e{i}",
                "source": edge.source,
                "target": edge.target,
                "label": edge.label,
            },
        }
        for attr in ("style", "color"):
            if attr in edge.attributes:
                el["data"][attr] = edge.attributes[attr]
        elements.append(el)

    return elements


def _build_html_template(
    graph_name: str,
    node_count: int,
    edge_count: int,
    elements_json: str,
    cytoscape_js: str,
    dagre_js: str,
    cytoscape_dagre_js: str,
    is_directed: bool,
) -> str:
    """Build the complete HTML string with all assets inlined.

    Args:
        graph_name: Name of the graph for the header.
        node_count: Number of nodes.
        edge_count: Number of edges.
        elements_json: JSON string of Cytoscape elements.
        cytoscape_js: Inlined cytoscape.min.js content.
        dagre_js: Inlined dagre.min.js content.
        cytoscape_dagre_js: Inlined cytoscape-dagre.js content.
        is_directed: Whether edges are directed.

    Returns:
        Complete self-contained HTML string.
    """
    arrow_shape = "triangle" if is_directed else "none"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HotDot - {_html_escape(graph_name)}</title>
<style>
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{ background: #1a1a2e; color: #e0e0e0; font-family: 'Consolas', 'Courier New', monospace; overflow: hidden; height: 100vh; display: flex; flex-direction: column; }}
#header {{ background: #0f0f23; padding: 8px 16px; display: flex; align-items: center; gap: 16px; border-bottom: 1px solid #0f3460; flex-shrink: 0; z-index: 10; }}
#header .brand {{ font-size: 18px; font-weight: bold; color: #e94560; white-space: nowrap; }}
#header .graph-info {{ color: #8899aa; font-size: 13px; white-space: nowrap; }}
#header .graph-info span {{ color: #00b4d8; }}
#search-box {{ background: #16213e; border: 1px solid #0f3460; color: #e0e0e0; padding: 4px 8px; border-radius: 4px; font-family: inherit; font-size: 13px; width: 200px; }}
#search-box::placeholder {{ color: #556677; }}
#search-box:focus {{ outline: none; border-color: #4a90d9; }}
.btn {{ background: #16213e; border: 1px solid #0f3460; color: #e0e0e0; padding: 4px 10px; border-radius: 4px; cursor: pointer; font-family: inherit; font-size: 13px; }}
.btn:hover {{ background: #0f3460; }}
.btn:active {{ background: #4a90d9; }}
#main {{ display: flex; flex: 1; overflow: hidden; position: relative; }}
#cy {{ flex: 1; background: #1a1a2e; }}
#info-panel {{ width: 320px; background: #0f0f23; border-left: 1px solid #0f3460; padding: 16px; overflow-y: auto; display: none; flex-shrink: 0; }}
#info-panel h3 {{ color: #e94560; margin-bottom: 8px; font-size: 14px; }}
#info-panel pre {{ color: #e0e0e0; font-size: 12px; white-space: pre-wrap; word-break: break-all; line-height: 1.5; }}
#info-panel .info-section {{ margin-bottom: 12px; }}
#info-panel .info-label {{ color: #8899aa; font-size: 11px; text-transform: uppercase; margin-bottom: 4px; }}
#minimap {{ position: absolute; bottom: 12px; right: 12px; width: 180px; height: 140px; background: #0f0f23; border: 1px solid #0f3460; border-radius: 4px; z-index: 5; }}
.controls {{ display: flex; align-items: center; gap: 4px; }}
.spacer {{ flex: 1; }}
</style>
</head>
<body>
<div id="header">
  <div class="brand">\U0001f525 HotDot</div>
  <div class="graph-info">{_html_escape(graph_name)} &mdash; <span>{node_count}</span> nodes, <span>{edge_count}</span> edges</div>
  <div class="spacer"></div>
  <input type="text" id="search-box" placeholder="Search nodes... (/)" />
  <div class="controls">
    <button class="btn" id="btn-zin" title="Zoom in">+</button>
    <button class="btn" id="btn-zout" title="Zoom out">&minus;</button>
    <button class="btn" id="btn-fit" title="Fit to screen (f)">Fit</button>
    <button class="btn" id="btn-toggle" title="Expand/Collapse all">Expand All</button>
  </div>
</div>
<div id="main">
  <div id="cy"></div>
  <div id="info-panel">
    <div class="info-section">
      <div class="info-label">Node</div>
      <h3 id="info-title"></h3>
    </div>
    <div class="info-section">
      <div class="info-label">Content</div>
      <pre id="info-content"></pre>
    </div>
    <div class="info-section">
      <div class="info-label">Connections</div>
      <pre id="info-connections"></pre>
    </div>
  </div>
  <div id="minimap"></div>
</div>

<script>{cytoscape_js}</script>
<script>{dagre_js}</script>
<script>{cytoscape_dagre_js}</script>
<script>
(function() {{
  "use strict";
  var elements = {elements_json};
  var allExpanded = false;

  var cy = cytoscape({{
    container: document.getElementById('cy'),
    elements: elements,
    style: [
      {{
        selector: 'node',
        style: {{
          'shape': 'round-rectangle',
          'background-color': '#16213e',
          'border-color': '#0f3460',
          'border-width': 2,
          'label': 'data(label)',
          'color': '#e0e0e0',
          'font-family': '"Consolas", "Courier New", monospace',
          'font-size': '11px',
          'text-wrap': 'wrap',
          'text-max-width': '300px',
          'text-valign': 'center',
          'text-halign': 'center',
          'padding': '10px',
          'width': 'label',
          'height': 'label',
          'min-width': '60px',
          'min-height': '30px'
        }}
      }},
      {{
        selector: 'node.highlighted',
        style: {{
          'border-color': '#e94560',
          'border-width': 3,
          'background-color': '#1e2a45'
        }}
      }},
      {{
        selector: 'node.searched',
        style: {{
          'border-color': '#00b4d8',
          'border-width': 3,
          'background-color': '#0a2a3e'
        }}
      }},
      {{
        selector: 'node.dimmed',
        style: {{
          'opacity': 0.3
        }}
      }},
      {{
        selector: 'node.neighbor',
        style: {{
          'border-color': '#00b4d8',
          'border-width': 2
        }}
      }},
      {{
        selector: 'edge',
        style: {{
          'width': 2,
          'line-color': '#4a90d9',
          'target-arrow-color': '#4a90d9',
          'target-arrow-shape': '{arrow_shape}',
          'curve-style': 'bezier',
          'label': 'data(label)',
          'font-size': '10px',
          'color': '#8899aa',
          'text-rotation': 'autorotate',
          'text-margin-y': -10,
          'font-family': '"Consolas", "Courier New", monospace'
        }}
      }},
      {{
        selector: 'edge.highlighted',
        style: {{
          'line-color': '#e94560',
          'target-arrow-color': '#e94560',
          'width': 3
        }}
      }},
      {{
        selector: 'edge.dimmed',
        style: {{
          'opacity': 0.2
        }}
      }},
      {{
        selector: 'edge[?style]',
        style: {{
          'line-style': 'data(style)'
        }}
      }},
      {{
        selector: 'edge[color]',
        style: {{
          'line-color': 'data(color)',
          'target-arrow-color': 'data(color)'
        }}
      }}
    ],
    layout: {{
      name: 'dagre',
      rankDir: 'TB',
      nodeSep: 50,
      rankSep: 80,
      edgeSep: 20,
      animate: false
    }},
    wheelSensitivity: 0.3
  }});

  // Edge count badges
  cy.nodes().forEach(function(n) {{
    var indeg = n.indegree();
    var outdeg = n.outdegree();
    if (indeg > 0 || outdeg > 0) {{
      var lbl = n.data('label');
      n.data('label', lbl + '\\n[in:' + indeg + ' out:' + outdeg + ']');
    }}
  }});

  // Click to select node
  cy.on('tap', 'node', function(evt) {{
    var node = evt.target;
    cy.elements().removeClass('highlighted neighbor dimmed');

    node.addClass('highlighted');
    var connected = node.connectedEdges();
    connected.addClass('highlighted');
    connected.connectedNodes().not(node).addClass('neighbor');

    // Expand this node
    var full = node.data('fullLabel');
    if (full) {{
      node.data('label', full.replace(/\\n/g, '\\n'));
      var indeg = node.indegree();
      var outdeg = node.outdegree();
      node.data('label', node.data('label') + '\\n[in:' + indeg + ' out:' + outdeg + ']');
    }}

    // Info panel
    var panel = document.getElementById('info-panel');
    panel.style.display = 'block';
    document.getElementById('info-title').textContent = node.data('id');
    document.getElementById('info-content').textContent = node.data('fullLabel') || node.data('id');
    var preds = node.incomers('node').map(function(n) {{ return n.data('id'); }});
    var succs = node.outgoers('node').map(function(n) {{ return n.data('id'); }});
    document.getElementById('info-connections').textContent =
      'Predecessors: ' + (preds.length ? preds.join(', ') : 'none') +
      '\\nSuccessors: ' + (succs.length ? succs.join(', ') : 'none');
  }});

  // Click background to deselect
  cy.on('tap', function(evt) {{
    if (evt.target === cy) {{
      cy.elements().removeClass('highlighted neighbor dimmed searched');
      document.getElementById('info-panel').style.display = 'none';
      // Collapse all nodes back
      if (!allExpanded) {{
        cy.nodes().forEach(function(n) {{
          var lines = (n.data('fullLabel') || n.data('id')).split('\\n');
          var title = lines[0] || n.data('id');
          var indeg = n.indegree();
          var outdeg = n.outdegree();
          n.data('label', title + '\\n[in:' + indeg + ' out:' + outdeg + ']');
        }});
      }}
    }}
  }});

  // Search
  var searchBox = document.getElementById('search-box');
  searchBox.addEventListener('input', function() {{
    var q = this.value.toLowerCase().trim();
    cy.elements().removeClass('searched dimmed');
    if (!q) return;
    cy.nodes().forEach(function(n) {{
      var full = (n.data('fullLabel') || '').toLowerCase();
      if (full.indexOf(q) >= 0) {{
        n.addClass('searched');
      }} else {{
        n.addClass('dimmed');
      }}
    }});
    cy.edges().forEach(function(e) {{
      var src = e.source();
      var tgt = e.target();
      if (!src.hasClass('searched') && !tgt.hasClass('searched')) {{
        e.addClass('dimmed');
      }}
    }});
  }});

  // Zoom controls
  document.getElementById('btn-zin').addEventListener('click', function() {{
    cy.zoom({{ level: cy.zoom() * 1.3, renderedPosition: {{ x: cy.width()/2, y: cy.height()/2 }} }});
  }});
  document.getElementById('btn-zout').addEventListener('click', function() {{
    cy.zoom({{ level: cy.zoom() / 1.3, renderedPosition: {{ x: cy.width()/2, y: cy.height()/2 }} }});
  }});
  document.getElementById('btn-fit').addEventListener('click', function() {{
    cy.fit(undefined, 40);
  }});

  // Expand/Collapse toggle
  var toggleBtn = document.getElementById('btn-toggle');
  toggleBtn.addEventListener('click', function() {{
    allExpanded = !allExpanded;
    toggleBtn.textContent = allExpanded ? 'Collapse All' : 'Expand All';
    cy.nodes().forEach(function(n) {{
      var indeg = n.indegree();
      var outdeg = n.outdegree();
      var badge = '\\n[in:' + indeg + ' out:' + outdeg + ']';
      if (allExpanded) {{
        n.data('label', (n.data('fullLabel') || n.data('id')) + badge);
      }} else {{
        var lines = (n.data('fullLabel') || n.data('id')).split('\\n');
        n.data('label', (lines[0] || n.data('id')) + badge);
      }}
    }});
  }});

  // Keyboard shortcuts
  document.addEventListener('keydown', function(e) {{
    if (e.target.tagName === 'INPUT') {{
      if (e.key === 'Escape') {{ e.target.blur(); }}
      return;
    }}
    if (e.key === 'f') {{ cy.fit(undefined, 40); }}
    if (e.key === 'Escape') {{
      cy.elements().removeClass('highlighted neighbor dimmed searched');
      document.getElementById('info-panel').style.display = 'none';
    }}
    if (e.key === '/') {{
      e.preventDefault();
      searchBox.focus();
    }}
  }});

  // Minimap (simple navigator using a second small cy instance)
  try {{
    var mmContainer = document.getElementById('minimap');
    var mmCy = cytoscape({{
      container: mmContainer,
      elements: JSON.parse(JSON.stringify(elements)),
      style: [
        {{ selector: 'node', style: {{ 'background-color': '#4a90d9', 'width': 8, 'height': 6, 'label': '' }} }},
        {{ selector: 'edge', style: {{ 'width': 0.5, 'line-color': '#2a4a6a', 'target-arrow-shape': 'none' }} }}
      ],
      layout: {{ name: 'dagre', rankDir: 'TB', nodeSep: 5, rankSep: 8, edgeSep: 2, animate: false }},
      userZoomingEnabled: false,
      userPanningEnabled: false,
      boxSelectionEnabled: false,
      autoungrabify: true
    }});
    mmCy.fit(undefined, 4);
  }} catch(ex) {{}}
}})();
</script>
</body>
</html>"""


def _html_escape(text: str) -> str:
    """Escape HTML special characters in text.

    Args:
        text: The text to escape.

    Returns:
        HTML-safe string.
    """
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def render_html(graph: ParsedGraph) -> str:
    """Render a ParsedGraph as a self-contained HTML string.

    Reads vendored Cytoscape.js, dagre, and cytoscape-dagre JS files
    from the assets directory and inlines them into the output HTML.

    Args:
        graph: The parsed graph to render.

    Returns:
        A complete self-contained HTML string with all JS inlined.
    """
    # Load vendored JS assets
    cytoscape_js = _load_asset("cytoscape.min.js")
    dagre_js = _load_asset("dagre.min.js")
    cytoscape_dagre_js = _load_asset("cytoscape-dagre.js")

    # Build Cytoscape elements
    elements = _build_cytoscape_elements(graph)
    elements_json = json.dumps(elements, ensure_ascii=False)

    return _build_html_template(
        graph_name=graph.name,
        node_count=len(graph.nodes),
        edge_count=len(graph.edges),
        elements_json=elements_json,
        cytoscape_js=cytoscape_js,
        dagre_js=dagre_js,
        cytoscape_dagre_js=cytoscape_dagre_js,
        is_directed=graph.is_directed,
    )
