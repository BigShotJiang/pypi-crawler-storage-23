"""DOT file parser module.

Uses pydot to parse Graphviz DOT files and extract a normalized
intermediate representation suitable for rendering.
"""

from __future__ import annotations

import sys
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator

import pydot  # type: ignore[import-untyped]


@dataclass
class Node:
    """A single node in the parsed graph.

    Attributes:
        id: The node identifier from the DOT file.
        label: Full label text, with DOT escape sequences resolved.
        attributes: All other DOT attributes (shape, style, color, etc.).
    """

    id: str
    label: str
    attributes: dict[str, str] = field(default_factory=dict)


@dataclass
class Edge:
    """A directed or undirected edge in the parsed graph.

    Attributes:
        source: Source node ID.
        target: Target node ID.
        label: Edge label if present, empty string otherwise.
        attributes: All other DOT attributes.
    """

    source: str
    target: str
    label: str = ""
    attributes: dict[str, str] = field(default_factory=dict)


@dataclass
class ParsedGraph:
    """Normalized intermediate representation of a parsed DOT graph.

    Attributes:
        name: Graph name from the DOT file.
        nodes: All nodes found in the graph.
        edges: All edges found in the graph.
        is_directed: True for digraph, False for graph.
    """

    name: str
    nodes: list[Node] = field(default_factory=list)
    edges: list[Edge] = field(default_factory=list)
    is_directed: bool = True


@contextmanager
def _raised_recursion_limit(limit: int = 10_000) -> Iterator[None]:
    """Temporarily raise Python's recursion limit for pydot/pyparsing."""
    old = sys.getrecursionlimit()
    if old < limit:
        sys.setrecursionlimit(limit)
    try:
        yield
    finally:
        sys.setrecursionlimit(old)


def _strip_quotes(s: str) -> str:
    """Remove surrounding double quotes from a string if present."""
    if s and len(s) >= 2 and s[0] == '"' and s[-1] == '"':
        return s[1:-1]
    return s


def _unescape_dot_label(label: str) -> str:
    r"""Process DOT escape sequences in a label string.

    Handles \l (left-justified newline), \n (centered newline),
    \r (right-justified newline), \" (literal double quote),
    and \\ (literal backslash).  Strips the trailing newline that
    commonly results from a final \l.
    """
    result = label.replace("\\l", "\n")
    result = result.replace("\\n", "\n")
    result = result.replace("\\r", "\n")
    result = result.replace('\\"', '"')
    result = result.replace("\\\\", "\\")
    # Strip trailing newline produced by a trailing \l
    return result.rstrip("\n")


def _clean_label(raw: str) -> str:
    """Strip quotes from a raw DOT label and unescape it."""
    label = _strip_quotes(raw)
    # HTML-like labels are wrapped in angle brackets
    if label.startswith("<") and label.endswith(">"):
        label = label[1:-1]
    return _unescape_dot_label(label)


def _extract_nodes_edges(
    graph: pydot.Dot | pydot.Subgraph,
    nodes_by_id: dict[str, Node],
    edges: list[Edge],
    default_node_attrs: dict[str, str],
    default_edge_attrs: dict[str, str],
) -> None:
    """Extract nodes and edges from a graph, flattening all subgraphs.

    Uses an iterative stack to avoid recursion depth issues with
    deeply nested subgraphs in large DOT files.

    Args:
        graph: A pydot graph or subgraph to extract from.
        nodes_by_id: Accumulator dict mapping node IDs to Node objects.
        edges: Accumulator list of Edge objects.
        default_node_attrs: Current default node attributes.
        default_edge_attrs: Current default edge attributes.
    """
    stack = [graph]

    while stack:
        current = stack.pop()

        for node in current.get_nodes():
            raw_name = _strip_quotes(node.get_name())
            if raw_name in ("node", "edge", "graph", ""):
                if raw_name == "node":
                    for k, v in node.obj_dict.get("attributes", {}).items():
                        default_node_attrs[k] = _strip_quotes(str(v))
                elif raw_name == "edge":
                    for k, v in node.obj_dict.get("attributes", {}).items():
                        default_edge_attrs[k] = _strip_quotes(str(v))
                continue

            attrs: dict[str, str] = {}
            attrs.update(default_node_attrs)
            for k, v in node.obj_dict.get("attributes", {}).items():
                attrs[k] = _strip_quotes(str(v))

            raw_label = attrs.pop("label", None)
            if raw_label is not None and raw_label != "":
                label = _clean_label(raw_label)
            elif raw_label == "":
                label = ""
            else:
                label = raw_name

            if raw_name not in nodes_by_id:
                nodes_by_id[raw_name] = Node(
                    id=raw_name, label=label, attributes=attrs
                )
            else:
                nodes_by_id[raw_name].label = label
                nodes_by_id[raw_name].attributes.update(attrs)

        for edge in current.get_edges():
            src = _strip_quotes(edge.get_source())
            dst = _strip_quotes(edge.get_destination())

            attrs = {}
            attrs.update(default_edge_attrs)
            for k, v in edge.obj_dict.get("attributes", {}).items():
                attrs[k] = _strip_quotes(str(v))

            raw_label = attrs.pop("label", "")
            label = _clean_label(raw_label) if raw_label else ""

            edges.append(
                Edge(source=src, target=dst, label=label, attributes=attrs)
            )

            for nid in (src, dst):
                if nid not in nodes_by_id:
                    nodes_by_id[nid] = Node(id=nid, label=nid, attributes={})

        # Push subgraphs onto the stack instead of recursing
        stack.extend(current.get_subgraphs())


def parse_dot_file(path: str | Path) -> ParsedGraph:
    """Parse a DOT file and return a ParsedGraph.

    Args:
        path: Path to the DOT file.

    Returns:
        A ParsedGraph with all nodes and edges extracted.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the file cannot be parsed.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"DOT file not found: {path}")

    with _raised_recursion_limit():
        graphs = pydot.graph_from_dot_file(str(path))
    if not graphs:
        raise ValueError(f"Could not parse DOT file: {path}")

    graph = graphs[0]
    name = _strip_quotes(graph.get_name() or "unnamed")
    is_directed = graph.get_type() == "digraph"

    nodes_by_id: dict[str, Node] = {}
    edges_list: list[Edge] = []
    default_node_attrs: dict[str, str] = {}
    default_edge_attrs: dict[str, str] = {}

    _extract_nodes_edges(
        graph, nodes_by_id, edges_list, default_node_attrs, default_edge_attrs
    )

    return ParsedGraph(
        name=name,
        nodes=list(nodes_by_id.values()),
        edges=edges_list,
        is_directed=is_directed,
    )


def parse_dot_string(dot_string: str) -> ParsedGraph:
    """Parse a DOT string and return a ParsedGraph.

    Args:
        dot_string: A string containing DOT graph notation.

    Returns:
        A ParsedGraph with all nodes and edges extracted.

    Raises:
        ValueError: If the string cannot be parsed as valid DOT.
    """
    with _raised_recursion_limit():
        graphs = pydot.graph_from_dot_data(dot_string)
    if not graphs:
        raise ValueError("Failed to parse DOT string")

    graph = graphs[0]
    name = _strip_quotes(graph.get_name() or "unnamed")
    is_directed = graph.get_type() == "digraph"

    nodes_by_id: dict[str, Node] = {}
    edges_list: list[Edge] = []
    default_node_attrs: dict[str, str] = {}
    default_edge_attrs: dict[str, str] = {}

    _extract_nodes_edges(
        graph, nodes_by_id, edges_list, default_node_attrs, default_edge_attrs
    )

    return ParsedGraph(
        name=name,
        nodes=list(nodes_by_id.values()),
        edges=edges_list,
        is_directed=is_directed,
    )
