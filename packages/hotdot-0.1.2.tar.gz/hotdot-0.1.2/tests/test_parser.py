"""Tests for the hotdot DOT parser module."""

from __future__ import annotations

from pathlib import Path

import pytest

from hotdot.parser import (
    Edge,
    Node,
    ParsedGraph,
    parse_dot_file,
    parse_dot_string,
)

FIXTURES = Path(__file__).parent / "fixtures"


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _node_ids(graph: ParsedGraph) -> set[str]:
    """Return the set of node IDs in a parsed graph."""
    return {n.id for n in graph.nodes}


def _node_by_id(graph: ParsedGraph, node_id: str) -> Node:
    """Look up a node by ID, raising if not found."""
    for n in graph.nodes:
        if n.id == node_id:
            return n
    raise KeyError(f"Node {node_id!r} not found in graph")


def _edges_from(graph: ParsedGraph, src: str) -> list[Edge]:
    """Return all edges originating from *src*."""
    return [e for e in graph.edges if e.source == src]


# ===================================================================
# simple.dot — 4 nodes, 4 edges, digraph
# ===================================================================

class TestSimpleDot:
    """Tests against tests/fixtures/simple.dot."""

    @pytest.fixture(autouse=True)
    def _parse(self) -> None:
        self.graph = parse_dot_file(FIXTURES / "simple.dot")

    def test_graph_name(self) -> None:
        assert self.graph.name == "simple_cfg"

    def test_is_directed(self) -> None:
        assert self.graph.is_directed is True

    def test_node_count(self) -> None:
        assert len(self.graph.nodes) == 4

    def test_edge_count(self) -> None:
        assert len(self.graph.edges) == 4

    def test_node_ids(self) -> None:
        assert _node_ids(self.graph) == {"entry", "then", "else", "end"}

    def test_entry_label_has_instructions(self) -> None:
        node = _node_by_id(self.graph, "entry")
        assert "entry:" in node.label
        assert "%x = load i32" in node.label

    def test_label_unescape_newlines(self) -> None:
        """Labels with \\l should become newlines."""
        node = _node_by_id(self.graph, "entry")
        assert "\n" in node.label

    def test_edge_labels(self) -> None:
        entry_edges = _edges_from(self.graph, "entry")
        labels = {e.label for e in entry_edges}
        assert "true" in labels
        assert "false" in labels

    def test_edge_without_label(self) -> None:
        then_edges = _edges_from(self.graph, "then")
        assert len(then_edges) == 1
        assert then_edges[0].label == ""
        assert then_edges[0].target == "end"


# ===================================================================
# loop.dot — 4 nodes, 4 edges, quoted node IDs with dots
# ===================================================================

class TestLoopDot:
    """Tests against tests/fixtures/loop.dot."""

    @pytest.fixture(autouse=True)
    def _parse(self) -> None:
        self.graph = parse_dot_file(FIXTURES / "loop.dot")

    def test_node_count(self) -> None:
        assert len(self.graph.nodes) == 4

    def test_edge_count(self) -> None:
        assert len(self.graph.edges) == 4

    def test_quoted_node_ids(self) -> None:
        """Node IDs with dots (quoted in DOT) should be unquoted."""
        ids = _node_ids(self.graph)
        assert "loop.header" in ids
        assert "loop.body" in ids

    def test_back_edge_attributes(self) -> None:
        """The back-edge from loop.body -> loop.header should carry style and color."""
        back_edges = [
            e for e in self.graph.edges
            if e.source == "loop.body" and e.target == "loop.header"
        ]
        assert len(back_edges) == 1
        edge = back_edges[0]
        assert edge.label == "back-edge"
        assert edge.attributes.get("style") == "dashed"
        assert edge.attributes.get("color") == "red"

    def test_entry_label(self) -> None:
        node = _node_by_id(self.graph, "entry")
        assert "alloca i32" in node.label


# ===================================================================
# complex.dot — 7 nodes, 7 edges, default edge/node attributes
# ===================================================================

class TestComplexDot:
    """Tests against tests/fixtures/complex.dot."""

    @pytest.fixture(autouse=True)
    def _parse(self) -> None:
        self.graph = parse_dot_file(FIXTURES / "complex.dot")

    def test_node_count(self) -> None:
        assert len(self.graph.nodes) == 7

    def test_edge_count(self) -> None:
        assert len(self.graph.edges) == 7

    def test_node_ids(self) -> None:
        expected = {f"BB{i}" for i in range(7)}
        assert _node_ids(self.graph) == expected

    def test_bb0_label(self) -> None:
        node = _node_by_id(self.graph, "BB0")
        assert "BB0: entry" in node.label
        assert "s_load_dword" in node.label

    def test_bb6_unreachable(self) -> None:
        node = _node_by_id(self.graph, "BB6")
        assert "unreachable" in node.label

    def test_default_node_attrs_applied(self) -> None:
        """Nodes should inherit the default fontname from `node [fontname=...]`."""
        node = _node_by_id(self.graph, "BB0")
        assert node.attributes.get("fontname") == "Courier"
        assert node.attributes.get("shape") == "box"

    def test_edge_labels(self) -> None:
        bb0_edges = _edges_from(self.graph, "BB0")
        labels = {e.label for e in bb0_edges}
        assert "fallthrough" in labels
        assert "vccnz" in labels

    def test_isolated_node_bb6(self) -> None:
        """BB6 has no outgoing or incoming edges but should still be a node."""
        assert "BB6" in _node_ids(self.graph)


# ===================================================================
# edgecases.dot — 5 nodes, 5 edges, special characters
# ===================================================================

class TestEdgecasesDot:
    """Tests against tests/fixtures/edgecases.dot."""

    @pytest.fixture(autouse=True)
    def _parse(self) -> None:
        self.graph = parse_dot_file(FIXTURES / "edgecases.dot")

    def test_graph_name(self) -> None:
        assert self.graph.name == "edge cases"

    def test_node_count(self) -> None:
        assert len(self.graph.nodes) == 5

    def test_edge_count(self) -> None:
        assert len(self.graph.edges) == 5

    def test_node_with_spaces(self) -> None:
        node = _node_by_id(self.graph, "node with spaces")
        assert "Block A:" in node.label

    def test_quoted_strings_in_label(self) -> None:
        """Escaped quotes in labels should be unescaped."""
        node = _node_by_id(self.graph, "node with spaces")
        assert '"quoted"' in node.label

    def test_node_with_dashes(self) -> None:
        node = _node_by_id(self.graph, "node-with-dashes")
        assert "header" in node.label

    def test_record_style_label(self) -> None:
        """Record-style label {header | body} should be preserved."""
        node = _node_by_id(self.graph, "node-with-dashes")
        assert "{header |" in node.label or "header" in node.label

    def test_simple_node_fallback_label(self) -> None:
        """A node declared without a label should use its ID as the label."""
        node = _node_by_id(self.graph, "simple_node")
        assert node.label == "simple_node"

    def test_empty_label(self) -> None:
        node = _node_by_id(self.graph, "empty_label")
        assert node.label == ""

    def test_unicode_label(self) -> None:
        node = _node_by_id(self.graph, "unicode_node")
        assert "←" in node.label
        assert "→" in node.label

    def test_nodes_only_in_edges(self) -> None:
        """simple_node appears only as a bare declaration and in edges;
        it must still be in the node list."""
        assert "simple_node" in _node_ids(self.graph)

    def test_dotted_edge_attributes(self) -> None:
        back = [
            e for e in self.graph.edges
            if e.source == "empty_label" and e.target == "node with spaces"
        ]
        assert len(back) == 1
        assert back[0].attributes.get("style") == "dotted"
        assert back[0].label == "back"

    def test_chained_edges(self) -> None:
        """'node-with-dashes' -> unicode_node -> empty_label produces 2 edges."""
        chain = [
            e for e in self.graph.edges
            if (e.source == "node-with-dashes" and e.target == "unicode_node")
            or (e.source == "unicode_node" and e.target == "empty_label")
        ]
        assert len(chain) == 2


# ===================================================================
# parse_dot_string — inline DOT parsing
# ===================================================================

class TestParseDotString:
    """Tests for parsing DOT strings directly."""

    def test_undirected_graph(self) -> None:
        result = parse_dot_string("graph G { a -- b; }")
        assert result.is_directed is False
        assert result.name == "G"
        assert len(result.nodes) == 2
        assert len(result.edges) == 1

    def test_subgraph_flattened(self) -> None:
        dot = """
        digraph G {
            subgraph cluster_0 {
                a [label="A"];
                b [label="B"];
                a -> b;
            }
            c [label="C"];
            b -> c;
        }
        """
        result = parse_dot_string(dot)
        ids = _node_ids(result)
        assert "a" in ids
        assert "b" in ids
        assert "c" in ids
        assert len(result.edges) == 2

    def test_comments_are_ignored(self) -> None:
        dot = """
        digraph G {
            // This is a comment
            /* This is a
               multi-line comment */
            a -> b;
        }
        """
        result = parse_dot_string(dot)
        assert len(result.edges) == 1

    def test_html_like_label(self) -> None:
        dot = 'digraph G { a [label=<<b>Bold</b>>]; }'
        result = parse_dot_string(dot)
        node = _node_by_id(result, "a")
        assert "<b>Bold</b>" in node.label


# ===================================================================
# Error handling
# ===================================================================

class TestErrors:
    """Parser error-handling tests."""

    def test_file_not_found(self) -> None:
        with pytest.raises(FileNotFoundError):
            parse_dot_file("/nonexistent/path.dot")

    def test_invalid_dot_string(self) -> None:
        with pytest.raises((ValueError, Exception)):
            parse_dot_string("")
