"""Tests for the hotdot HTML renderer module."""

from __future__ import annotations

import json
import re

import pytest

from hotdot.parser import Edge, Node, ParsedGraph
from hotdot.renderer import _build_cytoscape_elements, render_html


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def simple_graph() -> ParsedGraph:
    """A small directed graph with 4 nodes and 4 edges."""
    return ParsedGraph(
        name="simple_cfg",
        nodes=[
            Node(id="entry", label="entry:\n  %x = load i32\n  br i1 %cond"),
            Node(id="then", label="then:\n  %y = add i32 %x, 1"),
            Node(id="else", label="else:\n  %z = sub i32 %x, 1"),
            Node(id="end", label="end:\n  ret i32 %result"),
        ],
        edges=[
            Edge(source="entry", target="then", label="true"),
            Edge(source="entry", target="else", label="false"),
            Edge(source="then", target="end"),
            Edge(source="else", target="end"),
        ],
        is_directed=True,
    )


@pytest.fixture
def minimal_graph() -> ParsedGraph:
    """A trivial single-node graph."""
    return ParsedGraph(
        name="minimal",
        nodes=[Node(id="only", label="only node")],
        edges=[],
        is_directed=True,
    )


@pytest.fixture
def styled_edges_graph() -> ParsedGraph:
    """Graph with styled edges (dashed, dotted, colored)."""
    return ParsedGraph(
        name="styled",
        nodes=[
            Node(id="A", label="A"),
            Node(id="B", label="B"),
            Node(id="C", label="C"),
        ],
        edges=[
            Edge(source="A", target="B", label="normal"),
            Edge(
                source="B",
                target="C",
                label="back-edge",
                attributes={"style": "dashed", "color": "red"},
            ),
            Edge(
                source="C",
                target="A",
                label="dotted",
                attributes={"style": "dotted"},
            ),
        ],
        is_directed=True,
    )


# ---------------------------------------------------------------------------
# Tests: HTML structure
# ---------------------------------------------------------------------------


class TestHTMLStructure:
    """Verify the rendered HTML has the expected structural elements."""

    def test_contains_doctype(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        assert "<!DOCTYPE html>" in html

    def test_contains_html_tag(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        assert "<html" in html
        assert "</html>" in html

    def test_contains_body_tag(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        assert "<body>" in html
        assert "</body>" in html

    def test_contains_head_tag(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        assert "<head>" in html
        assert "</head>" in html

    def test_contains_title(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        assert "<title>" in html
        assert "simple_cfg" in html

    def test_valid_html_structure(self, simple_graph: ParsedGraph) -> None:
        """Verify basic HTML nesting order."""
        html = render_html(simple_graph)
        doctype_pos = html.index("<!DOCTYPE html>")
        html_pos = html.index("<html")
        head_pos = html.index("<head>")
        body_pos = html.index("<body>")
        assert doctype_pos < html_pos < head_pos < body_pos


# ---------------------------------------------------------------------------
# Tests: Inlined JS assets
# ---------------------------------------------------------------------------


class TestInlinedAssets:
    """Verify JS assets are present inline in the HTML output."""

    def test_cytoscape_js_inlined(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        assert "cytoscape" in html.lower()
        # The minified cytoscape source contains this marker
        assert "<script>" in html

    def test_dagre_js_inlined(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        # dagre.min.js defines the dagre module
        assert "dagre" in html

    def test_no_external_urls(self, simple_graph: ParsedGraph) -> None:
        """The output must be fully self-contained — no CDN or external resource references."""
        html = render_html(simple_graph)
        # No external script/link/img tags — URLs inside inlined JS comments are fine
        import re
        assert not re.search(r'<script\s+src\s*=\s*["\']https?://', html)
        assert not re.search(r'<link\s+.*href\s*=\s*["\']https?://', html)

    def test_multiple_script_tags(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        # At least 4 script tags: cytoscape, dagre, cytoscape-dagre, app code
        assert html.count("<script>") >= 4


# ---------------------------------------------------------------------------
# Tests: Cytoscape elements JSON
# ---------------------------------------------------------------------------


class TestCytoscapeElements:
    """Verify Cytoscape elements JSON contains all nodes and edges."""

    def test_all_nodes_present(self, simple_graph: ParsedGraph) -> None:
        elements = _build_cytoscape_elements(simple_graph)
        node_ids = {
            el["data"]["id"] for el in elements if el["group"] == "nodes"
        }
        assert node_ids == {"entry", "then", "else", "end"}

    def test_all_edges_present(self, simple_graph: ParsedGraph) -> None:
        elements = _build_cytoscape_elements(simple_graph)
        edge_pairs = {
            (el["data"]["source"], el["data"]["target"])
            for el in elements
            if el["group"] == "edges"
        }
        expected = {
            ("entry", "then"),
            ("entry", "else"),
            ("then", "end"),
            ("else", "end"),
        }
        assert edge_pairs == expected

    def test_edge_labels_preserved(self, simple_graph: ParsedGraph) -> None:
        elements = _build_cytoscape_elements(simple_graph)
        edge_labels = {
            el["data"]["label"]
            for el in elements
            if el["group"] == "edges" and el["data"]["label"]
        }
        assert "true" in edge_labels
        assert "false" in edge_labels

    def test_node_ids_in_html(self, simple_graph: ParsedGraph) -> None:
        """All node IDs should appear somewhere in the rendered HTML."""
        html = render_html(simple_graph)
        for node in simple_graph.nodes:
            assert node.id in html

    def test_edge_sources_targets_in_html(
        self, simple_graph: ParsedGraph
    ) -> None:
        """All edge source/target IDs appear in the rendered HTML."""
        html = render_html(simple_graph)
        for edge in simple_graph.edges:
            assert edge.source in html
            assert edge.target in html

    def test_node_full_label_in_data(self, simple_graph: ParsedGraph) -> None:
        elements = _build_cytoscape_elements(simple_graph)
        node_els = [el for el in elements if el["group"] == "nodes"]
        for el in node_els:
            assert "fullLabel" in el["data"]

    def test_styled_edge_attributes(
        self, styled_edges_graph: ParsedGraph
    ) -> None:
        """Edge style and color attributes are forwarded to elements."""
        elements = _build_cytoscape_elements(styled_edges_graph)
        edges = [el for el in elements if el["group"] == "edges"]

        # Find the dashed back-edge
        dashed = [e for e in edges if e["data"].get("style") == "dashed"]
        assert len(dashed) == 1
        assert dashed[0]["data"]["color"] == "red"

        # Find the dotted edge
        dotted = [e for e in edges if e["data"].get("style") == "dotted"]
        assert len(dotted) == 1

    def test_minimal_graph(self, minimal_graph: ParsedGraph) -> None:
        elements = _build_cytoscape_elements(minimal_graph)
        assert len(elements) == 1
        assert elements[0]["group"] == "nodes"
        assert elements[0]["data"]["id"] == "only"


# ---------------------------------------------------------------------------
# Tests: Output file size
# ---------------------------------------------------------------------------


class TestOutputSize:
    """Verify the rendered HTML is a reasonable size."""

    def test_output_size_reasonable(self, simple_graph: ParsedGraph) -> None:
        """With vendored JS assets, expect 500KB to 1.5MB total."""
        html = render_html(simple_graph)
        size = len(html.encode("utf-8"))
        # JS assets alone are ~730KB, so total should be at least 500KB
        assert size >= 500_000, f"HTML too small: {size} bytes"
        assert size <= 1_500_000, f"HTML too large: {size} bytes"


# ---------------------------------------------------------------------------
# Tests: Interactive features present in HTML
# ---------------------------------------------------------------------------


class TestInteractiveFeatures:
    """Verify interactive UI elements are present in the HTML."""

    def test_search_box(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        assert 'id="search-box"' in html

    def test_zoom_controls(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        assert 'id="btn-zin"' in html
        assert 'id="btn-zout"' in html
        assert 'id="btn-fit"' in html

    def test_expand_collapse_toggle(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        assert 'id="btn-toggle"' in html

    def test_info_panel(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        assert 'id="info-panel"' in html

    def test_minimap(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        assert 'id="minimap"' in html

    def test_keyboard_shortcuts(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        assert "keydown" in html

    def test_header_branding(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        assert "HotDot" in html

    def test_node_edge_counts_in_header(
        self, simple_graph: ParsedGraph
    ) -> None:
        html = render_html(simple_graph)
        assert "4</span> nodes" in html
        assert "4</span> edges" in html

    def test_dagre_layout_config(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        assert "rankDir: 'TB'" in html
        assert "nodeSep: 50" in html
        assert "rankSep: 80" in html

    def test_dark_theme_colors(self, simple_graph: ParsedGraph) -> None:
        html = render_html(simple_graph)
        assert "#1a1a2e" in html
        assert "#16213e" in html
        assert "#0f3460" in html
        assert "#e94560" in html
        assert "#4a90d9" in html
