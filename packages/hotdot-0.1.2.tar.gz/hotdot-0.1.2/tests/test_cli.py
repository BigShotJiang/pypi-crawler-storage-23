"""Tests for the hotdot CLI module."""

from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest

FIXTURES_DIR = Path(__file__).parent / "fixtures"


def run_hotdot(*args: str, check: bool = False) -> subprocess.CompletedProcess[str]:
    """Run the hotdot CLI as a subprocess and return the result."""
    return subprocess.run(
        [sys.executable, "-m", "hotdot.cli", *args],
        capture_output=True,
        text=True,
        check=check,
    )


class TestHelpAndVersion:
    """Tests for --help and --version flags."""

    def test_help_exits_zero(self) -> None:
        result = run_hotdot("--help")
        assert result.returncode == 0
        assert "hotdot" in result.stdout.lower()

    def test_version_prints_version(self) -> None:
        result = run_hotdot("--version")
        assert result.returncode == 0
        from hotdot import __version__
        assert __version__ in result.stdout


class TestBasicGeneration:
    """Tests for basic HTML generation from DOT files."""

    def test_simple_dot_produces_html(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            output = Path(tmpdir) / "simple.html"
            result = run_hotdot(
                str(FIXTURES_DIR / "simple.dot"), "-o", str(output)
            )
            assert result.returncode == 0, f"stderr: {result.stderr}"
            assert output.exists()
            html = output.read_text(encoding="utf-8")
            assert "<!DOCTYPE html>" in html
            assert "Generated" in result.stdout

    def test_output_to_specified_path(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            output = Path(tmpdir) / "test_output.html"
            result = run_hotdot(
                str(FIXTURES_DIR / "simple.dot"), "-o", str(output)
            )
            assert result.returncode == 0, f"stderr: {result.stderr}"
            assert output.exists()
            assert str(output) in result.stdout

    def test_default_output_name(self) -> None:
        """Without -o, output should be <input_stem>.html in cwd."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = subprocess.run(
                [sys.executable, "-m", "hotdot.cli", str(FIXTURES_DIR / "simple.dot")],
                capture_output=True,
                text=True,
                cwd=tmpdir,
            )
            assert result.returncode == 0, f"stderr: {result.stderr}"
            expected = Path(tmpdir) / "simple.html"
            assert expected.exists()


class TestFixtureFiles:
    """Tests that each fixture file produces HTML containing expected node IDs."""

    @pytest.mark.parametrize(
        "fixture,expected_nodes",
        [
            ("simple.dot", ["entry", "then", "else", "end"]),
            ("loop.dot", ["entry", "loop.header", "loop.body", "exit"]),
            (
                "complex.dot",
                ["BB0", "BB1", "BB2", "BB3", "BB4", "BB5", "BB6"],
            ),
            (
                "edgecases.dot",
                [
                    "node with spaces",
                    "simple_node",
                    "node-with-dashes",
                    "unicode_node",
                    "empty_label",
                ],
            ),
        ],
    )
    def test_fixture_contains_node_ids(
        self, fixture: str, expected_nodes: list[str]
    ) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            output = Path(tmpdir) / f"{fixture}.html"
            result = run_hotdot(
                str(FIXTURES_DIR / fixture), "-o", str(output)
            )
            assert result.returncode == 0, f"stderr: {result.stderr}"
            html = output.read_text(encoding="utf-8")
            for node_id in expected_nodes:
                assert node_id in html, (
                    f"Node ID '{node_id}' not found in output for {fixture}"
                )


class TestErrorHandling:
    """Tests for error handling in the CLI."""

    def test_nonexistent_file_error(self) -> None:
        result = run_hotdot("/nonexistent/path/fake.dot")
        assert result.returncode != 0
        assert "error" in result.stderr.lower() or "not found" in result.stderr.lower()

    def test_no_input_exits_nonzero(self) -> None:
        result = run_hotdot()
        assert result.returncode != 0

    def test_non_dot_extension_warns(self) -> None:
        """A file with a non-.dot extension should produce a warning but still work."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a valid DOT file with a .txt extension
            txt_file = Path(tmpdir) / "graph.txt"
            txt_file.write_text(
                'digraph test { a -> b; }', encoding="utf-8"
            )
            output = Path(tmpdir) / "graph.html"
            result = run_hotdot(str(txt_file), "-o", str(output))
            assert result.returncode == 0, f"stderr: {result.stderr}"
            assert output.exists()
            assert "warning" in result.stderr.lower()


class TestSummaryOutput:
    """Tests for the summary line printed after generation."""

    def test_summary_contains_counts(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            output = Path(tmpdir) / "simple.html"
            result = run_hotdot(
                str(FIXTURES_DIR / "simple.dot"), "-o", str(output)
            )
            assert result.returncode == 0
            # simple.dot has 4 nodes and 4 edges
            assert "4 nodes" in result.stdout
            assert "4 edges" in result.stdout
            assert "Generated" in result.stdout
