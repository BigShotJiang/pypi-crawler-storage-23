"""Tests for the GPU compute router resolver functions."""

import pytest

from metaflow_extensions.greatsky.compute_router import (
    ComputeRouterError,
    _build_result,
    _resolve_by_device,
    _resolve_by_pool,
    _resolve_by_vram,
)

SAMPLE_CONFIG = {
    "default_device": "l4",
    "devices": {
        "l4": {
            "vram_gb": 24,
            "node_selector": {"compute": "gpu", "gpu-type": "l4"},
            "tolerations": [{"key": "nvidia.com/gpu", "operator": "Exists", "effect": "NoSchedule"}],
            "queue": "gpu",
            "cpu_per_gpu": 12,
            "mem_mb_per_gpu": 24576,
            "instance_type": "g6.12xlarge",
            "gpus_per_node": 4,
        },
        "h100": {
            "vram_gb": 80,
            "node_selector": {"compute": "gpu", "gpu-type": "h100"},
            "tolerations": [{"key": "nvidia.com/gpu", "operator": "Exists", "effect": "NoSchedule"}],
            "queue": "gpu",
            "cpu_per_gpu": 24,
            "mem_mb_per_gpu": 262144,
            "instance_type": "p5.48xlarge",
            "gpus_per_node": 8,
        },
    },
    "pools": {
        "gpu": {
            "queue": "gpu",
            "devices": ["l4", "h100"],
        },
    },
}


# ---------------------------------------------------------------------------
# _resolve_by_device
# ---------------------------------------------------------------------------


class TestResolveByDevice:
    def test_known_device(self):
        result = _resolve_by_device("l4", SAMPLE_CONFIG, gpu_count=1)
        assert result["node_selector"] == {"compute": "gpu", "gpu-type": "l4"}
        assert len(result["tolerations"]) == 1
        assert result["queue"] == "gpu"
        assert result["cpu_per_gpu"] == 12
        assert result["mem_mb_per_gpu"] == 24576

    def test_h100_device(self):
        result = _resolve_by_device("h100", SAMPLE_CONFIG, gpu_count=2)
        assert result["node_selector"]["gpu-type"] == "h100"
        assert result["cpu_per_gpu"] == 24
        assert result["mem_mb_per_gpu"] == 262144

    def test_unknown_device_lists_available(self):
        with pytest.raises(ComputeRouterError, match="Unknown device 'a10'"):
            _resolve_by_device("a10", SAMPLE_CONFIG, gpu_count=1)

    def test_unknown_device_error_shows_options(self):
        with pytest.raises(ComputeRouterError, match="h100") as exc_info:
            _resolve_by_device("a10", SAMPLE_CONFIG, gpu_count=1)
        assert "l4" in str(exc_info.value)

    def test_empty_devices(self):
        config = {"devices": {}}
        with pytest.raises(ComputeRouterError, match="none configured"):
            _resolve_by_device("l4", config, gpu_count=1)


# ---------------------------------------------------------------------------
# _resolve_by_vram
# ---------------------------------------------------------------------------


class TestResolveByVram:
    def test_exact_match(self):
        result = _resolve_by_vram(24, SAMPLE_CONFIG, gpu_count=1)
        assert result["node_selector"]["gpu-type"] == "l4"

    def test_picks_smallest_sufficient(self):
        result = _resolve_by_vram(25, SAMPLE_CONFIG, gpu_count=1)
        assert result["node_selector"]["gpu-type"] == "h100"

    def test_large_vram_picks_h100(self):
        result = _resolve_by_vram(80, SAMPLE_CONFIG, gpu_count=1)
        assert result["node_selector"]["gpu-type"] == "h100"

    def test_too_large_vram_raises(self):
        with pytest.raises(ComputeRouterError, match="No device with >= 128GB VRAM"):
            _resolve_by_vram(128, SAMPLE_CONFIG, gpu_count=1)

    def test_error_lists_options_with_vram(self):
        with pytest.raises(ComputeRouterError) as exc_info:
            _resolve_by_vram(128, SAMPLE_CONFIG, gpu_count=1)
        msg = str(exc_info.value)
        assert "l4 (24GB)" in msg
        assert "h100 (80GB)" in msg

    def test_empty_devices(self):
        config = {"devices": {}}
        with pytest.raises(ComputeRouterError, match="none configured"):
            _resolve_by_vram(24, config, gpu_count=1)


# ---------------------------------------------------------------------------
# _resolve_by_pool
# ---------------------------------------------------------------------------


class TestResolveByPool:
    def test_known_pool(self):
        result = _resolve_by_pool("gpu", SAMPLE_CONFIG, gpu_count=1)
        assert result["queue"] == "gpu"

    def test_pool_uses_first_device(self):
        result = _resolve_by_pool("gpu", SAMPLE_CONFIG, gpu_count=1)
        assert result["node_selector"]["gpu-type"] == "l4"

    def test_unknown_pool_lists_available(self):
        with pytest.raises(ComputeRouterError, match="Unknown pool 'training'"):
            _resolve_by_pool("training", SAMPLE_CONFIG, gpu_count=1)

    def test_unknown_pool_shows_options(self):
        with pytest.raises(ComputeRouterError, match="gpu"):
            _resolve_by_pool("training", SAMPLE_CONFIG, gpu_count=1)

    def test_empty_pools(self):
        config = {"pools": {}, "devices": {}}
        with pytest.raises(ComputeRouterError, match="none configured"):
            _resolve_by_pool("gpu", config, gpu_count=1)


# ---------------------------------------------------------------------------
# _build_result
# ---------------------------------------------------------------------------


class TestBuildResult:
    def test_copies_node_selector(self):
        spec = {"node_selector": {"a": "b"}, "tolerations": [], "queue": "q", "cpu_per_gpu": 4, "mem_mb_per_gpu": 8192}
        result = _build_result(spec, gpu_count=1)
        assert result["node_selector"] == {"a": "b"}
        result["node_selector"]["c"] = "d"
        assert "c" not in spec["node_selector"]

    def test_copies_tolerations(self):
        tol = [{"key": "k", "operator": "Exists", "effect": "NoSchedule"}]
        spec = {"node_selector": {}, "tolerations": tol, "queue": "q", "cpu_per_gpu": 4, "mem_mb_per_gpu": 8192}
        result = _build_result(spec, gpu_count=1)
        assert len(result["tolerations"]) == 1
        result["tolerations"].append({"key": "extra"})
        assert len(tol) == 1

    def test_defaults_on_missing_keys(self):
        result = _build_result({}, gpu_count=1)
        assert result["cpu_per_gpu"] == 4
        assert result["mem_mb_per_gpu"] == 8192


# ---------------------------------------------------------------------------
# CPU / Memory scaling
# ---------------------------------------------------------------------------


class TestCpuMemoryScaling:
    def test_l4_single_gpu_scaling(self):
        result = _resolve_by_device("l4", SAMPLE_CONFIG, gpu_count=1)
        max_cpu = int(result["cpu_per_gpu"] * 1 * 0.9)
        max_mem = int(result["mem_mb_per_gpu"] * 1 * 0.9)
        assert max_cpu == 10
        assert max_mem == 22118

    def test_h100_8gpu_scaling(self):
        result = _resolve_by_device("h100", SAMPLE_CONFIG, gpu_count=8)
        max_cpu = int(result["cpu_per_gpu"] * 8 * 0.9)
        max_mem = int(result["mem_mb_per_gpu"] * 8 * 0.9)
        assert max_cpu == 172
        assert max_mem == 1887436


# ---------------------------------------------------------------------------
# Mutual exclusivity
# ---------------------------------------------------------------------------


class TestMutualExclusivity:
    """The mutual exclusivity check happens in the patched init(), but we
    can test the logic directly: only one of device, vram, pool should be set."""

    def test_only_one_mode_allowed(self):
        modes = [("l4", None, None), (None, 24, None), (None, None, "gpu")]
        for device, vram, pool in modes:
            count = sum(bool(x) for x in [device, vram, pool])
            assert count == 1

    def test_multiple_modes_detected(self):
        count = sum(bool(x) for x in ["l4", 24, None])
        assert count == 2

        count = sum(bool(x) for x in ["l4", 24, "gpu"])
        assert count == 3


# ---------------------------------------------------------------------------
# Config parsing edge cases
# ---------------------------------------------------------------------------


class TestConfigEdgeCases:
    def test_empty_config_device(self):
        with pytest.raises(ComputeRouterError):
            _resolve_by_device("l4", {}, gpu_count=1)

    def test_empty_config_vram(self):
        with pytest.raises(ComputeRouterError):
            _resolve_by_vram(24, {}, gpu_count=1)

    def test_empty_config_pool(self):
        with pytest.raises(ComputeRouterError):
            _resolve_by_pool("gpu", {}, gpu_count=1)

    def test_device_missing_some_fields(self):
        config = {
            "devices": {
                "t4": {"vram_gb": 16, "node_selector": {"gpu-type": "t4"}},
            }
        }
        result = _resolve_by_device("t4", config, gpu_count=1)
        assert result["node_selector"] == {"gpu-type": "t4"}
        assert result["tolerations"] == []
        assert result["cpu_per_gpu"] == 4
        assert result["mem_mb_per_gpu"] == 8192

    def test_pool_with_empty_devices_list(self):
        config = {
            "devices": {"l4": SAMPLE_CONFIG["devices"]["l4"]},
            "pools": {"empty": {"queue": "q", "devices": []}},
        }
        result = _resolve_by_pool("empty", config, gpu_count=1)
        assert result.get("queue") == "q"

    def test_load_config_returns_empty_when_unavailable(self, monkeypatch):
        import metaflow_extensions.greatsky.compute_router as cr

        monkeypatch.setattr(cr, "_load_compute_config", lambda: {})
        assert cr._load_compute_config() == {}


# ---------------------------------------------------------------------------
# Error message detail
# ---------------------------------------------------------------------------


class TestErrorMessages:
    def test_device_error_is_descriptive(self):
        with pytest.raises(ComputeRouterError) as exc_info:
            _resolve_by_device("v100", SAMPLE_CONFIG, gpu_count=1)
        msg = str(exc_info.value)
        assert "Unknown device 'v100'" in msg
        assert "h100" in msg
        assert "l4" in msg

    def test_vram_error_includes_all_options(self):
        with pytest.raises(ComputeRouterError) as exc_info:
            _resolve_by_vram(256, SAMPLE_CONFIG, gpu_count=1)
        msg = str(exc_info.value)
        assert "l4 (24GB)" in msg
        assert "h100 (80GB)" in msg

    def test_pool_error_lists_pools(self):
        with pytest.raises(ComputeRouterError) as exc_info:
            _resolve_by_pool("inference", SAMPLE_CONFIG, gpu_count=1)
        msg = str(exc_info.value)
        assert "Unknown pool 'inference'" in msg
        assert "gpu" in msg
