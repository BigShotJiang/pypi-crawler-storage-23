"""Tests that gsm login writes a minimal 2-field config.json to the GSM directory."""

from click.testing import CliRunner

from greatsky_internal_metaflow import config
from greatsky_internal_metaflow.cli import cli


def _setup_gsm(tmp_path, monkeypatch):
    gsm_dir = tmp_path / ".greatsky_gsm"
    gsm_dir.mkdir()
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: gsm_dir)
    monkeypatch.setattr(config, "write_target_dir", lambda: gsm_dir)
    return gsm_dir


def test_minimal_config_written(tmp_path, monkeypatch):
    """After login, config.json should contain only GSM_AUTH_API and METAFLOW_SERVICE_AUTH_KEY."""
    _setup_gsm(tmp_path, monkeypatch)

    config.write_config(
        {
            "GSM_AUTH_API": "https://auth.gr8sky.dev",
            "METAFLOW_SERVICE_AUTH_KEY": "gsk_abc123",
        }
    )

    gsm_config = config.read_config()
    assert set(gsm_config.keys()) == {"GSM_AUTH_API", "METAFLOW_SERVICE_AUTH_KEY"}
    assert gsm_config["GSM_AUTH_API"] == "https://auth.gr8sky.dev"
    assert gsm_config["METAFLOW_SERVICE_AUTH_KEY"] == "gsk_abc123"


def test_credentials_still_full(tmp_path, monkeypatch):
    """credentials.json should still contain full user metadata."""
    _setup_gsm(tmp_path, monkeypatch)

    config.write_credentials(
        api_key="gsk_abc123",
        expires_at="2026-03-05T00:00:00Z",
        github_user="wade",
        name="Wade",
        access_type="org_member",
    )

    creds = config.read_credentials()
    assert creds["api_key"] == "gsk_abc123"
    assert creds["github_user"] == "wade"
    assert creds["name"] == "Wade"
    assert creds["access_type"] == "org_member"
    assert creds["expires_at"] == "2026-03-05T00:00:00Z"


def test_logout_still_works(tmp_path, monkeypatch):
    """Logout should clear config and credentials from the resolved GSM directory."""
    _setup_gsm(tmp_path, monkeypatch)

    config.write_config(
        {
            "GSM_AUTH_API": "https://auth.gr8sky.dev",
            "METAFLOW_SERVICE_AUTH_KEY": "gsk_test",
        }
    )
    config.write_credentials(
        api_key="gsk_test",
        expires_at="2026-03-05",
        github_user="wade",
        name="Wade",
        access_type="org_member",
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["logout"])
    assert result.exit_code == 0
    assert "Logged out" in result.output
    assert config.read_config() is None
    assert config.read_credentials() is None
