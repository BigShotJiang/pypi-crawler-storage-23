"""GreatSky Metaflow extension package.

Config injection is handled by the config/ subpackage, which Metaflow's
extension loader discovers and processes inside metaflow_config.py.

GPU compute routing is applied via the plugins/ subpackage, which
Metaflow discovers during plugin loading (before flow files are parsed).
"""
