"""Skills catalog example package."""
