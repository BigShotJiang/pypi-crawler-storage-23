"""Quality tier abstractions for review scoring.

This module provides domain constants for issue-count-based quality scoring
and configurable quality gate thresholds. Issue count tiers are domain constants
(not configurable), while pass/warn thresholds are loaded from configuration.

See ADR-068 for the architectural decision behind these abstractions.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Mapping
    from typing import Any


class IssueCountTier(Enum):
    """Domain constants for issue-count-based quality scoring.

    Each tier defines a range of issue counts and the base score for that range.
    These are domain constants, not configurable parameters.

    Attributes:
        min_count: Minimum issue count (inclusive) for this tier.
        max_count: Maximum issue count (inclusive) for this tier, or None for unbounded.
        base_score: Quality score (0.0-1.0) assigned to this tier.
    """

    NONE = (0, 0, 1.0)
    MINOR = (1, 1, 0.8)
    MODERATE = (2, 2, 0.6)
    MAJOR = (3, 4, 0.4)
    CRITICAL = (5, None, 0.2)

    def __init__(self, min_count: int, max_count: int | None, base_score: float) -> None:
        """Initialize tier with count range and base score."""
        self.min_count = min_count
        self.max_count = max_count
        self.base_score = base_score

    @classmethod
    def from_count(cls, count: int) -> IssueCountTier:
        """Get the tier for a given issue count.

        Args:
            count: Number of issues found.

        Returns:
            The IssueCountTier matching the count.
        """
        for tier in cls:
            if tier.max_count is None:
                # Unbounded upper tier (CRITICAL)
                if count >= tier.min_count:
                    return tier
            elif tier.min_count <= count <= tier.max_count:
                return tier
        # Should never reach here, but default to CRITICAL for safety
        return cls.CRITICAL


class QualityDecision(Enum):
    """Quality gate decision outcomes.

    Values:
        PASS: Score meets or exceeds pass threshold.
        WARN: Score is between warn and pass thresholds (permissive mode only).
        REVIEW: Score is between warn and pass thresholds (strict mode).
        FAIL: Score is below warn threshold.
    """

    PASS = "pass"
    WARN = "warn"
    REVIEW = "review"
    FAIL = "fail"


@dataclass
class QualityGate:
    """Configurable quality gate thresholds.

    Attributes:
        pass_threshold: Minimum score to pass quality gate (default: 0.7).
        warn_threshold: Minimum score before warning (default: 0.5).
        permissive: If True, scores between warn and pass trigger WARN instead of REVIEW.
    """

    pass_threshold: float
    warn_threshold: float
    permissive: bool = False

    @classmethod
    def from_config(cls, *, permissive: bool = False) -> QualityGate:
        """Load quality gate thresholds from configuration.

        Args:
            permissive: Override permissive mode setting.

        Returns:
            QualityGate with thresholds from config or defaults.
        """
        from obra.config.loaders import load_layered_config

        config, _, _ = load_layered_config()
        orchestration: Mapping[str, Any] = config.get("orchestration", {})
        quality_config: Mapping[str, Any] = orchestration.get("quality", {})

        pass_threshold = quality_config.get("pass_threshold", 0.7)
        warn_threshold = quality_config.get("warn_threshold", 0.5)

        return cls(
            pass_threshold=float(pass_threshold),
            warn_threshold=float(warn_threshold),
            permissive=permissive,
        )

    def evaluate(self, score: float, issue_count: int = 0) -> QualityDecision:
        """Evaluate a quality score against the gate thresholds.

        The score is adjusted based on the issue count tier, capping it at
        the tier's base score. This ensures high issue counts result in
        lower effective scores even if the raw score is high.

        Args:
            score: Raw quality score (0.0-1.0).
            issue_count: Number of issues found.

        Returns:
            QualityDecision based on adjusted score vs thresholds.
        """
        tier = IssueCountTier.from_count(issue_count)
        adjusted_score = min(score, tier.base_score)

        if adjusted_score >= self.pass_threshold:
            return QualityDecision.PASS
        if adjusted_score >= self.warn_threshold:
            return QualityDecision.WARN if self.permissive else QualityDecision.REVIEW
        return QualityDecision.FAIL


__all__ = [
    "IssueCountTier",
    "QualityDecision",
    "QualityGate",
]
