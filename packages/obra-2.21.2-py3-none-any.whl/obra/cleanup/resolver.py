"""Interactive and automated skip resolution utilities."""

from __future__ import annotations

import json
import time
from datetime import UTC, datetime
from typing import Any

import typer

from obra.config import load_config
from obra.config.loaders import get_cleanup_sleep_cap_s
from obra.execution.skip_record import (
    SkipReason,
    SkipRecord,
    SkipStatus,
    persist_skip_record,
)


def _resolution_prompt(skip: SkipRecord) -> tuple[str, dict[str, str]]:
    if skip.reason == SkipReason.MISSING_SECRET:
        return "Select resolution: [1] resolve [2] defer [3] wont_fix", {
            "1": "resolved",
            "2": "deferred",
            "3": "wont_fix",
        }
    if skip.reason == SkipReason.DESIGN_DECISION:
        return "Select resolution: [1] resolved [2] defer [3] wont_fix", {
            "1": "resolved",
            "2": "deferred",
            "3": "wont_fix",
        }
    if skip.reason == SkipReason.DEFERRED_CONCERN:
        return "Select resolution: [1] resolve [2] defer [3] wont_fix", {
            "1": "resolved",
            "2": "deferred",
            "3": "wont_fix",
        }
    return "Select resolution: [1] resolved [2] deferred [3] wont_fix", {
        "1": "resolved",
        "2": "deferred",
        "3": "wont_fix",
    }


def resolve_skips_interactively(
    skip_records: list[SkipRecord],
    base_dir: str | None = None,
) -> list[SkipRecord]:
    """Resolve skips interactively via terminal prompts."""
    resolved: list[SkipRecord] = []
    if not skip_records:
        return resolved

    for skip in skip_records:
        typer.echo()
        typer.echo(f"Skip {skip.id} ({skip.source.value} / {skip.reason.value})")
        typer.echo(skip.description)
        prompt, choices = _resolution_prompt(skip)
        choice = typer.prompt(prompt, default="2").strip()
        status_value = choices.get(choice, "deferred")
        skip.status = SkipStatus(status_value)
        notes = typer.prompt("Resolution notes (optional)", default="", show_default=False)
        if notes:
            skip.resolution_notes = notes
        skip.resolved_at = datetime.now(UTC).isoformat()
        skip.resolved_by = "user"
        persist_skip_record(skip, base_dir=base_dir)
        resolved.append(skip)

    return resolved


def auto_retry_skips(
    skip_records: list[SkipRecord],
    base_dir: str | None = None,
) -> list[SkipRecord]:
    """Auto-retry transient skips with caps/backoff from config.

    This performs a best-effort retry only when a retry_command is provided
    in skip.source_context. Otherwise, marks the skip as deferred.
    """
    config = load_config()
    cleanup_config = config.get("orchestration", {}).get("cleanup", {})
    retry_sources = set(cleanup_config.get("auto_retry_sources", []))
    max_attempts = int(cleanup_config.get("auto_retry_max_attempts", 2))
    backoff_seconds = float(cleanup_config.get("auto_retry_backoff_seconds", 2))

    resolved: list[SkipRecord] = []
    for skip in skip_records:
        if skip.reason.value not in retry_sources:
            continue

        attempts = 0
        success = False
        retry_command = (
            skip.source_context.get("retry_command")
            if isinstance(skip.source_context, dict)
            else None
        )
        while attempts < max_attempts and retry_command:
            attempts += 1
            # Cap sleep to configured limit for constrained environments
            sleep_cap_s = get_cleanup_sleep_cap_s()
            time.sleep(min(backoff_seconds, sleep_cap_s))
            result = _run_retry_command(retry_command)
            if result:
                success = True
                break

        if success:
            skip.status = SkipStatus.AUTO_RESOLVED
            skip.resolution_notes = (
                skip.resolution_notes + "\n" if skip.resolution_notes else ""
            ) + f"Auto-retry succeeded after {attempts} attempt(s)."
        else:
            skip.status = SkipStatus.DEFERRED
            skip.resolution_notes = (
                skip.resolution_notes + "\n" if skip.resolution_notes else ""
            ) + "Auto-retry not executed or failed."

        skip.resolved_at = datetime.now(UTC).isoformat()
        skip.resolved_by = "auto-retry"
        persist_skip_record(skip, base_dir=base_dir)
        resolved.append(skip)

    return resolved


def _run_retry_command(command: str) -> bool:
    """Best-effort retry using a command string.

    Uses shlex.split() to safely parse the command without shell=True,
    avoiding potential command injection risks (CWE-78).
    """
    try:
        import shlex
        import subprocess

        result = subprocess.run(
            shlex.split(command),
            capture_output=True,
            text=True,
            check=False,
        )
    except Exception:
        return False
    else:
        return result.returncode == 0


def parse_resolution_context(raw_context: str | None) -> dict[str, Any] | None:
    if not raw_context:
        return None
    try:
        return json.loads(raw_context)
    except json.JSONDecodeError:
        return None


__all__ = [
    "auto_retry_skips",
    "parse_resolution_context",
    "resolve_skips_interactively",
]
