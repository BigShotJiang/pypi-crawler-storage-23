"""Memory bus or interconnect model; reserved for Python-side bus configuration."""
