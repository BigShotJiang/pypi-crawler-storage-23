"""DRAM or main memory model; reserved for Python-side memory configuration."""
