"""
Core simulation infrastructure (events, params, sim objects).

Reserved for shared base classes and utilities used by CPU, memory, and device models.
"""
