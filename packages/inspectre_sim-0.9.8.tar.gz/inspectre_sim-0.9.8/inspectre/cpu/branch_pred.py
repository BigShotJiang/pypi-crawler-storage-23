"""Branch predictor configuration or metrics; reserved for Python-side BP abstraction."""
