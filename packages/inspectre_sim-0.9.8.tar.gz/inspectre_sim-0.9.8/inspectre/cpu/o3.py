"""Out-of-order or advanced pipeline model; reserved for future use."""
