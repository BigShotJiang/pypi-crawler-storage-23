"""
CPU and pipeline models (base, atomic, branch predictor, O3).

Reserved for Python-side CPU/pipeline abstractions that mirror or configure the Rust core.
"""
