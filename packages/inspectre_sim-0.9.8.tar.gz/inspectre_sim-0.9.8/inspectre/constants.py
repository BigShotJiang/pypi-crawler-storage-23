"""
Reserved for shared numeric or string constants used across the Python API.

Currently unused; the main configuration and ISA constants live in config and isa modules.
"""
