//! # Device Tests
//!
//! Unit tests for SoC peripheral devices.

pub mod plic_tests;
