"""Ninja API — thin FastAPI composition shell."""
