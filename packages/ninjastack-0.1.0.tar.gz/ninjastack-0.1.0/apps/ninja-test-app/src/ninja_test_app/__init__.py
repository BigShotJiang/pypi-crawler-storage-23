"""ninja-test-app — thin composition shell. No business logic here."""
