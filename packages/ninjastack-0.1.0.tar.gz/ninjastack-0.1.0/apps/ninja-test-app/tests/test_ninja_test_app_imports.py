def test_ninja_test_app_imports():
    import ninja_test_app

    assert ninja_test_app is not None
