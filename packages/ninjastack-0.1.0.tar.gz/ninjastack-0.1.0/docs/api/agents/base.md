# Base Agents

::: ninja_agents.base
    options:
      members:
        - DataAgent
        - DomainAgent
        - CoordinatorAgent
        - create_domain_agent
        - create_coordinator_agent
