# Persistence API

::: ninja_persistence
    options:
      show_if_no_docstring: true
