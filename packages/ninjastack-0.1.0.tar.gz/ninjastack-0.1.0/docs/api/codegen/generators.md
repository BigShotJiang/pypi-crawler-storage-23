# Code Generators

## Models Generator
::: ninja_codegen.generators.models

## Agents Generator
::: ninja_codegen.generators.agents

## GraphQL Generator
::: ninja_codegen.generators.graphql

## App Shell Generator
::: ninja_codegen.generators.apps
