# Introspection API

::: ninja_introspect
    options:
      show_if_no_docstring: true
