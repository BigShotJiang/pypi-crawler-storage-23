# Auth Strategies

## OAuth2
::: ninja_auth.strategies.oauth2

## Bearer (JWT)
::: ninja_auth.strategies.bearer

## API Key
::: ninja_auth.strategies.apikey

## Built-in Identity
::: ninja_auth.strategies.identity
