# GraphQL API

::: ninja_gql
    options:
      show_if_no_docstring: true
