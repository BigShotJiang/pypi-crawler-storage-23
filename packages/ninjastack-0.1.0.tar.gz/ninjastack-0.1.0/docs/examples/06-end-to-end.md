# Example 6: End-to-End

Full pipeline from schema definition to authenticated agent queries.

```python title="examples/bookstore/06_end_to_end.py"
--8<-- "examples/bookstore/06_end_to_end.py"
```

## Run It

```bash
PYTHONPATH=examples/bookstore uv run python examples/bookstore/06_end_to_end.py
```
