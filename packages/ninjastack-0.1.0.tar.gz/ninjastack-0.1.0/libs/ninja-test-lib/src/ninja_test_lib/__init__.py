"""ninja-test-lib library."""
