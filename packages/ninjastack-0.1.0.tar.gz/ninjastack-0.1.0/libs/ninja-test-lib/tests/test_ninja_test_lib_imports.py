def test_ninja_test_lib_imports():
    import ninja_test_lib

    assert ninja_test_lib is not None
