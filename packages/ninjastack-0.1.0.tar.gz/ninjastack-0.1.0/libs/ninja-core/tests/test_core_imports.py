def test_ninja_core_imports():
    import ninja_core

    assert ninja_core is not None
