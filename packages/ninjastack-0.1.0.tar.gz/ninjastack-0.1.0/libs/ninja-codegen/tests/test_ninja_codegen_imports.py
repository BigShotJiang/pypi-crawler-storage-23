def test_ninja_codegen_imports():
    import ninja_codegen

    assert ninja_codegen is not None
