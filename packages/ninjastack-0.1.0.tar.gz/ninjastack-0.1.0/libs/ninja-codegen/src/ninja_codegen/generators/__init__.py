"""Code generators for the ninja-codegen sync engine."""
