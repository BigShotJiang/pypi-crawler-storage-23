def test_ninja_models_imports():
    import ninja_models

    assert ninja_models is not None
