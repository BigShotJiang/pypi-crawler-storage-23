def test_ninja_boundary_imports():
    import ninja_boundary

    assert ninja_boundary is not None
