"""Persistence adapters for each storage engine."""
