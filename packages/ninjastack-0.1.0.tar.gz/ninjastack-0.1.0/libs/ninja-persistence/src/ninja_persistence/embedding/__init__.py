"""Embedding generation and strategy module."""
