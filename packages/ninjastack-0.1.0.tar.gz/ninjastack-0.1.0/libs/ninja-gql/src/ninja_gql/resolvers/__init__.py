"""GraphQL resolver implementations."""
