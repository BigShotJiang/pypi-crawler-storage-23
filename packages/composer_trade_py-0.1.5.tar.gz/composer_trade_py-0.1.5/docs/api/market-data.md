# Market Data

## Market Data Resource

::: composer.resources.market_data.MarketData
    options:
      show_root_heading: true
      show_category_heirarchy: true

## Quotes Resource

::: composer.resources.quotes.Quotes
    options:
      show_root_heading: true
      show_category_heirarchy: true
