"""Property-based tests for deployer branch filtering.

# Feature: git-catcher, Property 6: Branch filtering
**Validates: Requirements 4.1, 4.2**
"""
from hypothesis import given, settings
from hypothesis import strategies as st

from git_catcher.deployer import should_deploy

# Strategy: branch names — safe characters usable in git branch names
_branch_chars = (
    "abcdefghijklmnopqrstuvwxyz"
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "0123456789"
    "-_/"
)
branch_strategy = (
    st.text(alphabet=_branch_chars, min_size=1, max_size=80)
    .filter(lambda b: not b.startswith("/"))
    .filter(lambda b: not b.endswith("/"))
    .filter(lambda b: "//" not in b)
)

# Strategy: allowed branch list — 0 to 10 branch names
allowed_branches_strategy = st.lists(branch_strategy, min_size=0, max_size=10)


@given(branch=branch_strategy, allowed=allowed_branches_strategy)
@settings(max_examples=200)
def test_should_deploy_iff_branch_in_allowed(branch: str, allowed: list[str]):
    """Property 6: Branch filtering

    # Feature: git-catcher, Property 6: Branch filtering
    **Validates: Requirements 4.1, 4.2**

    For any branch name and allowed branch list,
    the return value of should_deploy must be equivalent to whether
    the branch is contained in the allowed list.
    """
    result = should_deploy(branch, allowed)

    assert result == (branch in allowed)


# ---------------------------------------------------------------------------
# Feature: git-catcher, Property 7: Abort on git command failure
# ---------------------------------------------------------------------------

import subprocess
from unittest.mock import patch, MagicMock
from pathlib import Path

from hypothesis import strategies as st

from git_catcher.config import DeployConfig


def _make_config(repo_path: str) -> DeployConfig:
    """Create a DeployConfig for testing."""
    return DeployConfig(
        smee_url="https://smee.io/test",
        webhook_secret="",
        repo_path=repo_path,
        allowed_branches=["main"],
        post_pull_command="",
        reconnect_delay=5,
        max_reconnect_delay=300,
    )


# Strategy for failure step index: 0(fetch), 1(checkout), 2(pull)
fail_step_strategy = st.integers(min_value=0, max_value=2)


@given(branch=branch_strategy, fail_at=fail_step_strategy)
@settings(max_examples=200)
def test_git_pull_stops_on_failure(branch: str, fail_at: int):
    """Property 7: Abort on git command failure

    # Feature: git-catcher, Property 7: Abort on git command failure
    **Validates: Requirements 4.4**

    For any 3-step git command sequence (fetch, checkout, pull),
    if step k fails, steps k+1 and beyond must not execute,
    and git_pull must return False.
    """
    import asyncio
    import tempfile
    from git_catcher.deployer import git_pull

    with tempfile.TemporaryDirectory() as tmp_dir:
        config = _make_config(tmp_dir)
        call_count = 0

        async def mock_run_command(cmd, cwd):
            nonlocal call_count
            idx = call_count
            call_count += 1
            if idx == fail_at:
                return (1, "", "error")
            return (0, "ok", "")

        with patch("git_catcher.deployer.run_command", side_effect=mock_run_command):
            result = asyncio.run(git_pull(config, branch))

        # git_pull must return False
        assert result is False, f"fail_at={fail_at}, branch={branch!r}"

        # Only steps up to and including the failing one should have been called
        assert call_count == fail_at + 1, (
            f"expected {fail_at + 1} calls, got {call_count}"
        )


# ---------------------------------------------------------------------------
# Unit tests: deployer edge cases (Task 5.4)
# ---------------------------------------------------------------------------

import tempfile


class TestRunPostPullSkipsWhenEmpty:
    """Req 4.6: run_command must not be called and True returned when post_pull_command is empty."""

    def test_empty_string_skips(self, tmp_path):
        """Empty post_pull_command should skip and return True."""
        import asyncio
        from git_catcher.deployer import run_post_pull

        config = _make_config(str(tmp_path))
        assert config.post_pull_command == ""

        with patch("git_catcher.deployer.run_command") as mock_cmd:
            result = asyncio.run(run_post_pull(config))

        assert result is True
        mock_cmd.assert_not_called()


class TestGitPullRepoNotExists:
    """Req 4.4: Return False immediately if the repository path does not exist."""

    def test_nonexistent_path_returns_false(self):
        """Non-existent path → git_pull returns False, run_command not called."""
        import asyncio
        from git_catcher.deployer import git_pull

        config = _make_config("/nonexistent/path/that/does/not/exist")

        with patch("git_catcher.deployer.run_command") as mock_cmd:
            result = asyncio.run(git_pull(config, "main"))

        assert result is False
        mock_cmd.assert_not_called()


class TestGitCommandOrder:
    """Req 4.3: git commands must execute in fetch → checkout → pull order."""

    def test_commands_execute_in_order(self, tmp_path):
        """When all git commands succeed, verify fetch → checkout → pull order."""
        import asyncio
        from unittest.mock import AsyncMock
        from git_catcher.deployer import git_pull

        config = _make_config(str(tmp_path))
        ok = (0, "ok", "")

        with patch("git_catcher.deployer.run_command", new_callable=AsyncMock, return_value=ok) as mock_cmd:
            result = asyncio.run(git_pull(config, "main"))

        assert result is True
        assert mock_cmd.call_count == 3

        calls = mock_cmd.call_args_list
        assert calls[0].args[0] == ["git", "fetch", "origin"]
        assert calls[1].args[0] == ["git", "checkout", "main"]
        assert calls[2].args[0] == ["git", "pull", "origin", "main"]

        # Verify cwd is repo_path for all calls
        for call in calls:
            assert call.kwargs["cwd"] == str(tmp_path)
