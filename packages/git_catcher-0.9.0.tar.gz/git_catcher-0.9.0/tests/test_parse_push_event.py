"""Property-based tests for parse_push_event.

# Feature: git-catcher, Property 4: Push event parsing round-trip
**Validates: Requirements 3.1, 3.3**
"""
from hypothesis import given, settings
from hypothesis import strategies as st

from git_catcher.smee_client import parse_push_event

# Strategy: valid git branch names (non-empty, slashes allowed, following git ref rules)
# For round-trip to hold after stripping refs/heads/, use safe printable ASCII characters
_branch_chars = st.sampled_from(
    "abcdefghijklmnopqrstuvwxyz"
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "0123456789"
    "-_/"
)
branch_strategy = (
    st.text(alphabet=_branch_chars, min_size=1, max_size=100)
    .filter(lambda b: not b.startswith("/"))
    .filter(lambda b: not b.endswith("/"))
    .filter(lambda b: "//" not in b)
)

# Strategy: commit messages (arbitrary text, non-empty — real commits require a message)
message_strategy = st.text(min_size=1, max_size=500)


@given(branch=branch_strategy, message=message_strategy)
@settings(max_examples=200)
def test_push_event_parsing_roundtrip(branch: str, message: str):
    """Property 4: Push event parsing round-trip

    # Feature: git-catcher, Property 4: Push event parsing round-trip
    **Validates: Requirements 3.1, 3.3**

    For any valid branch name and commit message,
    passing {"ref": "refs/heads/<branch>", "head_commit": {"message": "<message>"}}
    to parse_push_event must return the (branch, message) tuple.
    """
    # Arrange: build push event payload
    payload = {
        "ref": f"refs/heads/{branch}",
        "head_commit": {"message": message},
    }

    # Act
    result = parse_push_event(payload)

    # Assert: round-trip holds — input branch and message are returned as-is
    assert result is not None
    assert result == (branch, message)


# --- Property 5: Ignore non-branch refs ---

# Strategy: ref strings that do NOT start with refs/heads/
_non_branch_prefixes = st.sampled_from(["refs/tags/", "refs/pull/", "refs/remotes/", ""])
_suffix = st.text(min_size=0, max_size=100)
non_branch_ref_strategy = st.one_of(
    # Known non-branch prefix + arbitrary suffix
    st.tuples(_non_branch_prefixes, _suffix).map(lambda t: t[0] + t[1]),
    # Fully arbitrary text that does not start with refs/heads/
    st.text(min_size=0, max_size=200).filter(lambda s: not s.startswith("refs/heads/")),
)


@given(ref=non_branch_ref_strategy)
@settings(max_examples=200)
def test_non_branch_ref_ignored(ref: str):
    """Property 5: Ignore non-branch refs

    # Feature: git-catcher, Property 5: Ignore non-branch refs
    **Validates: Requirements 3.2**

    For any ref string that does not start with refs/heads/,
    parse_push_event must return None.
    """
    payload = {"ref": ref, "head_commit": {"message": "some commit"}}

    result = parse_push_event(payload)

    assert result is None
