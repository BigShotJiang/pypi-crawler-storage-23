"""Git Auto Deploy — Smee.io-based auto-deploy entry point (async)"""
import asyncio
import logging
import socket
import sys
from datetime import datetime, timezone

import httpx

from .config import DeployConfig, detect_repo_name
from .deployer import check_behind, deploy, should_deploy
from .smee_client import listen
from . import __version__

logger = logging.getLogger("auto-deploy")

# External IP APIs — fallback once if the first fails
_EXTERNAL_IP_APIS = [
    "https://api.ipify.org",
    "https://checkip.amazonaws.com",
]


async def fetch_external_ip() -> str:
    """Fetch the external IP. Falls back once on failure; returns 'unknown' if all fail."""
    async with httpx.AsyncClient(timeout=5) as client:
        for url in _EXTERNAL_IP_APIS:
            try:
                resp = await client.get(url)
                resp.raise_for_status()
                return resp.text.strip()
            except Exception:
                continue
    return "unknown"


async def notify_slack(
    config: DeployConfig, repo: str, branch: str, message: str,
    success: bool, trigger: str = "push",
):
    """Send a Block Kit deploy notification to Slack Incoming Webhook (async).

    trigger: "push" | "catch-up" | "poll" | "start"
    """
    if not config.slack_webhook_url:
        return

    emoji = "✅" if success else "❌"
    status = "Success" if success else "Failed"
    trigger_labels = {
        "push": "Push",
        "catch-up": "🔄 Catch-up",
        "poll": "⏰ Poll",
        "start": "🚀 Start",
    }
    trigger_label = trigger_labels.get(trigger, trigger)

    hostname = socket.gethostname()
    external_ip = await fetch_external_ip()
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    blocks = [
        {
            "type": "header",
            "text": {"type": "plain_text", "text": f"{emoji} Deploy {status}", "emoji": True},
        },
        {"type": "divider"},
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Repository*\n{repo}"},
                {"type": "mrkdwn", "text": f"*Branch*\n{branch}"},
            ],
        },
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Commit*\n{message}"},
                {"type": "mrkdwn", "text": f"*Trigger*\n{trigger_label}"},
            ],
        },
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Host*\n`{hostname}`"},
                {"type": "mrkdwn", "text": f"*IP*\n`{external_ip}`"},
            ],
        },
        {
            "type": "context",
            "elements": [{"type": "mrkdwn", "text": f"🕐 {now}"}],
        },
    ]

    fallback = f"{emoji} Deploy {status} [{trigger_label}] | {repo}/{branch} | {hostname}({external_ip})"

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(
                config.slack_webhook_url,
                json={"text": fallback, "blocks": blocks},
            )
    except Exception as e:
        logger.warning(f"Slack notification failed: {e}")


async def notify_slack_start(config: DeployConfig, repo: str):
    """Send a Slack notification on startup."""
    if not config.slack_webhook_url or not config.notify_on_start:
        return

    hostname = socket.gethostname()
    external_ip = await fetch_external_ip()
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    blocks = [
        {
            "type": "header",
            "text": {"type": "plain_text", "text": "🚀 git-catcher Started", "emoji": True},
        },
        {"type": "divider"},
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Repository*\n{repo}"},
                {"type": "mrkdwn", "text": f"*Branches*\n{', '.join(config.allowed_branches)}"},
            ],
        },
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Host*\n`{hostname}`"},
                {"type": "mrkdwn", "text": f"*IP*\n`{external_ip}`"},
            ],
        },
        {
            "type": "context",
            "elements": [{"type": "mrkdwn", "text": f"🕐 {now}"}],
        },
    ]

    fallback = f"🚀 git-catcher Started | {repo} | {hostname}({external_ip})"

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(
                config.slack_webhook_url,
                json={"text": fallback, "blocks": blocks},
            )
    except Exception as e:
        logger.warning(f"Slack start notification failed: {e}")


LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
LOG_DATEFMT = "%Y-%m-%d %H:%M:%S"


def setup_logging(level: str = "INFO", log_file: str | None = None):
    """Configure stdout (rich) + file handler logging.

    level: DEBUG, INFO, WARNING, ERROR
    """
    from rich.logging import RichHandler
    from rich.text import Text

    root = logging.getLogger()
    root.handlers.clear()

    log_level = getattr(logging, level.upper(), logging.INFO)
    root.setLevel(log_level)

    def _fmt_time(dt):
        return Text(dt.strftime("%H:%M:%S.") + f"{dt.microsecond // 1000:03d}")

    console = RichHandler(
        rich_tracebacks=True,
        show_time=True,
        show_path=True,
        markup=False,
        log_time_format=_fmt_time,
    )
    console.setLevel(log_level)
    root.addHandler(console)

    # File handler (plain text, always DEBUG)
    if log_file:
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setFormatter(logging.Formatter(LOG_FORMAT, datefmt=LOG_DATEFMT))
        fh.setLevel(logging.DEBUG)
        root.addHandler(fh)
        logger.info(f"Log file: {log_file}")


async def async_main(config: DeployConfig):
    """Async main loop — SSE subscription + catch-up + poll + Slack notifications."""

    # Auto-detect repo from REPO_PATH if ALLOWED_REPOS is not set
    if not config.allowed_repos:
        detected = detect_repo_name(config.repo_path)
        if detected:
            config.allowed_repos = [detected]
            logger.info(f"Repository auto-detected: {detected}")

    # Validate required configuration
    if "YOUR_CHANNEL_ID" in config.smee_url:
        logger.error("Please set SMEE_URL. Create a channel at https://smee.io/new")
        sys.exit(1)

    repo_name = config.allowed_repos[0] if config.allowed_repos else ""

    logger.info(f"Target repository: {config.repo_path}")
    logger.info(f"Allowed branches: {config.allowed_branches}")
    logger.info(f"Allowed repos: {config.allowed_repos or '(all)'}")
    logger.info(f"Smee channel: {config.smee_url}")
    if config.poll_interval > 0:
        logger.info(f"Git polling enabled: every {config.poll_interval}s")

    # Send startup notification
    await notify_slack_start(config, repo_name)

    async def deploy_if_behind(trigger: str):
        """For each allowed branch, deploy if behind origin."""
        for branch in config.allowed_branches:
            is_behind, message = await check_behind(config, branch)
            if not is_behind:
                logger.info(f"({trigger}) [{branch}] already up to date")
                continue
            logger.info(f"Starting deploy ({trigger}): [{branch}] {message}")
            success = await deploy(config, branch)
            logger.info(f"Deploy {'succeeded' if success else 'failed'} ({trigger}): [{branch}]")
            await notify_slack(config, repo_name, branch, message, success, trigger)

    async def on_connect():
        """Run catch-up deploy on SSE connection."""
        await deploy_if_behind("catch-up")

    async def on_push(branch: str, commit_message: str, push_repo: str = ""):
        if not should_deploy(branch, config.allowed_branches):
            logger.info(f"Branch [{branch}] not in allowed list — skipping")
            return
        logger.info(f"Starting deploy (push): [{branch}] {commit_message}")
        success = await deploy(config, branch)
        logger.info(f"Deploy {'succeeded' if success else 'failed'} (push): [{branch}]")
        await notify_slack(config, push_repo or repo_name, branch, commit_message, success, "push")

    async def poll_loop():
        """Periodically check git status to catch missed pushes."""
        while True:
            await asyncio.sleep(config.poll_interval)
            logger.debug("poll: comparing local vs origin...")
            await deploy_if_behind("poll")

    # Run poll loop as a background task if poll_interval > 0
    if config.poll_interval > 0:
        asyncio.create_task(poll_loop())

    # Start SSE stream subscription (async, auto-reconnect, catch-up on connect)
    await listen(config, on_push, on_connect)


def main(argv=None):
    import argparse

    parser = argparse.ArgumentParser(
        description="Git Auto Deploy — Smee.io-based auto-deploy",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # init subcommand
    init_parser = subparsers.add_parser("init", help="Interactive initial setup")
    init_parser.add_argument(
        "--non-interactive", action="store_true",
        help="Auto-generate with defaults (skip interactive prompts)",
    )
    init_parser.add_argument(
        "--template", choices=["docker", "bare"], default="docker",
        help="Template to generate (docker: includes docker-compose.yml, bare: .env only)",
    )

    # setup subcommand
    subparsers.add_parser("setup", help="Check SSH connectivity (host + container)")

    # run subcommand (default behavior)
    run_parser = subparsers.add_parser("run", help="Run git-catcher (default)")
    run_parser.add_argument(
        "-v", "--verbose", action="count", default=0,
        help="Log verbosity (-v: DEBUG). Takes precedence over --log-level",
    )
    run_parser.add_argument(
        "--log-level", default=None,
        help="Log level (DEBUG, INFO, WARNING, ERROR). Takes precedence over LOG_LEVEL env var",
    )
    run_parser.add_argument(
        "--log-file", default=None,
        help="Log file path. Takes precedence over LOG_FILE env var",
    )
    run_parser.add_argument(
        "--show-all-events", action="store_true", default=None,
        help="Log all push events. Takes precedence over SHOW_ALL_EVENTS env var",
    )

    # Treat bare invocation (no subcommand) as "run"
    args = parser.parse_args(argv)
    if args.command is None:
        args.command = "run"
        args.verbose = 0
        args.log_level = None
        args.log_file = None
        args.show_all_events = None

    if args.command == "init":
        from .cli.init import run_init
        run_init(non_interactive=args.non_interactive, template=args.template)
        return

    if args.command == "setup":
        from .cli.setup import run_setup
        run_setup()
        return

    # run command
    config = DeployConfig()

    # Priority: -v > --log-level > LOG_LEVEL env var
    if args.verbose >= 1:
        log_level = "DEBUG"
    else:
        log_level = args.log_level or config.log_level
    log_file = args.log_file or config.log_file or None
    if args.show_all_events is not None:
        config.show_all_events = args.show_all_events

    setup_logging(level=log_level, log_file=log_file)

    # ASCII art + version
    print("""
   _____ _ _            _____      _       _
  / ____(_) |          / ____|    | |     | |
 | |  __ _| |_ ______ | |     __ _| |_ ___| |__   ___ _ __
 | | |_ | | __|______|| |    / _` | __/ __| '_ \\ / _ \\ '__|
 | |__| | | |_        | |___| (_| | || (__| | | |  __/ |
  \\_____|_|\\__|        \\_____\\__,_|\\__\\___|_| |_|\\___|_|
    """)
    logger.info(f"git-catcher v{__version__}")
    asyncio.run(async_main(config))


if __name__ == "__main__":
    main()
