"""Smee.io SSE client — receive webhook events in real time (async)"""
import asyncio
import hashlib
import hmac
import json
import logging

import httpx

from .config import DeployConfig

logger = logging.getLogger(__name__)


def verify_signature(payload: bytes, signature: str, secret: str) -> bool:
    """Verify GitHub webhook HMAC-SHA256 signature."""
    if not secret:
        logger.warning("webhook_secret not set — skipping signature verification")
        return True

    expected = "sha256=" + hmac.new(
        secret.encode(), payload, hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature)


def parse_push_event(data: dict) -> tuple[str, str] | None:
    """Extract (branch, commit_message) from a push event. Returns None if not a push."""
    ref = data.get("ref", "")
    if not ref.startswith("refs/heads/"):
        return None

    branch = ref.removeprefix("refs/heads/")
    head_commit = data.get("head_commit") or {}
    message = head_commit.get("message", "(no message)")
    return branch, message

def calculate_backoff(attempt: int, initial_delay: int, max_delay: int) -> int:
    """Calculate the wait time for the nth reconnect attempt.

    delay = min(initial_delay * 2^attempt, max_delay)
    """
    return min(initial_delay * (2 ** attempt), max_delay)


async def listen(config: DeployConfig, on_push, on_connect=None):
    """
    Subscribe to the Smee.io SSE stream and invoke the on_push callback on push events.
    Reconnects with exponential backoff on disconnection.
    If on_connect is provided, it is called each time the SSE connection is established.

    on_push(branch: str, commit_message: str, repo_name: str) -> None (async)
    on_connect() -> None (async, optional)
    """
    attempt = 0
    state = {"last_event_id": None}

    while True:
        try:
            logger.info(f"Connecting to Smee.io: {config.smee_url}")
            await _stream_events(config, on_push, state, on_connect)
            logger.info("SSE stream ended — reconnecting immediately")
            attempt = 0
            continue
        except (httpx.ConnectError, httpx.ReadTimeout, httpx.ReadError,
                httpx.RemoteProtocolError) as e:
            logger.warning(f"Connection error: {e}")
        except httpx.HTTPStatusError as e:
            logger.warning(f"HTTP error {e.response.status_code}: {e}")
        except Exception as e:
            logger.error(f"Unexpected error: {e}", exc_info=True)

        delay = calculate_backoff(attempt, config.reconnect_delay, config.max_reconnect_delay)
        logger.info(f"Reconnecting in {delay}s (attempt #{attempt + 1})...")
        await asyncio.sleep(delay)
        attempt += 1


async def _stream_events(config: DeployConfig, on_push, state: dict, on_connect=None):
    """Internal function that reads the SSE stream and processes events. Updates state['last_event_id']."""
    headers = {"Accept": "text/event-stream"}
    if state["last_event_id"]:
        headers["Last-Event-ID"] = state["last_event_id"]
        logger.info(f"Resuming from Last-Event-ID: {state['last_event_id']}")

    # read=90s: Smee.io sends a ping ~every 30s; treat as dead connection after 2 missed pings
    timeout = httpx.Timeout(connect=10.0, read=90.0, write=10.0, pool=10.0)

    async with httpx.AsyncClient(timeout=timeout) as client:
        async with client.stream("GET", config.smee_url, headers=headers) as resp:
            resp.raise_for_status()
            logger.info("SSE stream connected")

            # On connect, run catch-up in background to avoid blocking the SSE stream
            if on_connect:
                asyncio.create_task(on_connect())

            buffer = ""
            async for chunk in resp.aiter_text():
                buffer += chunk
                while "\n\n" in buffer:
                    raw_event, buffer = buffer.split("\n\n", 1)
                    event_id = await _handle_raw_event(raw_event, config, on_push)
                    if event_id is not None:
                        state["last_event_id"] = event_id


async def _handle_raw_event(raw: str, config: DeployConfig, on_push) -> str | None:
    """Parse and process a raw SSE event. Returns the event ID."""
    if config.verbose >= 4:
        logger.debug(f"[RAW WEBHOOK]\n{raw}")

    data_lines = []
    event_type = "message"
    event_id = None

    for line in raw.strip().split("\n"):
        if line.startswith("data:"):
            data_lines.append(line[5:].strip())
        elif line.startswith("event:"):
            event_type = line[6:].strip()
        elif line.startswith("id:"):
            event_id = line[3:].strip()

    if not data_lines or event_type in ("ping", "ready"):
        return None

    raw_data = "\n".join(data_lines)
    try:
        data = json.loads(raw_data)
    except json.JSONDecodeError:
        logger.debug(f"JSON parse failed (ignored): {raw_data[:100]}")
        return event_id

    # Signature verification — Smee.io re-serializes the body as JSON, so original bytes cannot be recovered
    is_smee = "smee.io" in config.smee_url
    signature = data.get("x-hub-signature-256", "")
    body = data.get("body", {})

    # Preserve original body bytes: if it's a string, signature verification is possible
    if isinstance(body, str):
        body_bytes = body.encode()
        try:
            body = json.loads(body)
        except json.JSONDecodeError:
            return event_id
    else:
        body_bytes = json.dumps(body, separators=(",", ":")).encode()

    logger.debug(f"Event received: type={event_type}, signature={signature[:30]}...")
    logger.debug(f"body keys: {list(body.keys()) if isinstance(body, dict) else 'N/A'}")

    if is_smee:
        if config.webhook_secret and signature:
            logger.debug("Smee.io proxy — skipping signature verification (original bytes unavailable)")
    elif not verify_signature(body_bytes, signature, config.webhook_secret):
        logger.warning("Signature verification failed — ignoring event")
        logger.debug(f"payload_bytes length: {len(body_bytes)}, signature: {signature}")
        return event_id

    # Repository filtering + push event handling
    repo_name = (body.get("repository") or {}).get("full_name", "")
    result = parse_push_event(body)

    # --show-all-events: log all push events
    if result and config.show_all_events:
        branch, message = result
        logger.info(f"[ALL] [{repo_name}] [{branch}] {message}")

    if config.allowed_repos and repo_name not in config.allowed_repos:
        logger.debug(f"Repository [{repo_name}] not in allowed list — skipping")
        return event_id

    if result:
        branch, message = result
        logger.info(f"Push detected: [{repo_name}] [{branch}] {message}")
        await on_push(branch, message, repo_name)

    return event_id
