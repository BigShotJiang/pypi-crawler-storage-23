"""Deployment configuration"""
import logging
import os
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

# Load .env only from the current working directory (prevent traversal to parent dirs)
load_dotenv(dotenv_path=Path.cwd() / ".env", verbose=False)

logger = logging.getLogger(__name__)


def parse_allowed_branches(raw: str) -> list[str]:
    """Parse a comma-separated branch string and return a list.

    Strips leading/trailing whitespace from each branch name and filters out empty strings.
    """
    return [b.strip() for b in raw.split(",") if b.strip()]


@dataclass
class DeployConfig:
    # Smee.io channel URL (create one at https://smee.io/new)
    smee_url: str = os.getenv("SMEE_URL", "https://smee.io/YOUR_CHANNEL_ID")

    # GitHub Webhook Secret (must match the value entered in GitHub webhook settings)
    webhook_secret: str = os.getenv("WEBHOOK_SECRET", "")

    # Local path to the target Git repository
    repo_path: str = os.getenv("REPO_PATH", "/path/to/your/repo")

    # List of allowed branches (deploy only when a push targets one of these)
    allowed_branches: list[str] = field(
        default_factory=lambda: parse_allowed_branches(
            os.getenv("ALLOWED_BRANCHES", "main,master")
        )
    )

    # Shell command to run after git pull (skipped if empty)
    post_pull_command: str = os.getenv("POST_PULL_COMMAND", "")

    # SSE reconnect wait time (seconds)
    reconnect_delay: int = int(os.getenv("RECONNECT_DELAY", "1"))

    # List of allowed repositories (owner/repo format; empty list allows all)
    allowed_repos: list[str] = field(
        default_factory=lambda: parse_allowed_branches(
            os.getenv("ALLOWED_REPOS", "")
        )
    )

    # Slack Incoming Webhook URL (notifications skipped if empty)
    slack_webhook_url: str = os.getenv("SLACK_WEBHOOK_URL", "")

    # Maximum reconnect wait time (seconds; upper bound for exponential backoff)
    max_reconnect_delay: int = int(os.getenv("MAX_RECONNECT_DELAY", "300"))

    # Git status polling interval (seconds; 0 disables polling)
    poll_interval: int = int(os.getenv("POLL_INTERVAL", "0"))

    # Log level (DEBUG, INFO, WARNING, ERROR)
    log_level: str = os.getenv("LOG_LEVEL", "INFO")

    # Log file path (file logging disabled if empty)
    log_file: str = os.getenv("LOG_FILE", "")

    # Log all push events (deployment is still filtered)
    show_all_events: bool = os.getenv("SHOW_ALL_EVENTS", "").lower() in ("true", "1", "yes")

    # Whether to send a Slack notification on startup
    notify_on_start: bool = os.getenv("NOTIFY_ON_START", "true").lower() in ("true", "1", "yes")

    # CLI verbose level (deprecated; use log_level instead)
    verbose: int = 0


def detect_repo_name(repo_path: str) -> str:
    """Extract owner/repo from the git remote origin URL of REPO_PATH.

    SSH: git@github.com:owner/repo.git → owner/repo
    HTTPS: https://github.com/owner/repo.git → owner/repo
    Returns an empty string on failure.
    """
    try:
        url = subprocess.run(
            ["git", "-C", repo_path, "remote", "get-url", "origin"],
            capture_output=True, text=True, timeout=5,
        ).stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return ""

    if not url:
        return ""

    # SSH: git@github.com:owner/repo.git
    m = re.search(r"[:/]([^/]+/[^/]+?)(?:\.git)?$", url)
    return m.group(1) if m else ""
