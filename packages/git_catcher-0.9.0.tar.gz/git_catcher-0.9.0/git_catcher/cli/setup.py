"""git-catcher setup — SSH connectivity check (host + container)"""
import os
import subprocess


def _test_ssh_github() -> tuple[bool, str]:
    """Run ssh -T git@github.com and return (success, output)."""
    result = subprocess.run(
        ["ssh", "-T", "-o", "StrictHostKeyChecking=no", "git@github.com"],
        capture_output=True, text=True,
    )
    output = (result.stdout + result.stderr).strip()
    ok = "Hi " in output or "successfully authenticated" in output
    return ok, output


def run_setup():
    """Check SSH connectivity on the host and inside the Docker container."""
    print("\n🔧 git-catcher SSH setup check\n")

    # 1. SSH_AUTH_SOCK
    ssh_sock = os.environ.get("SSH_AUTH_SOCK")
    if not ssh_sock:
        print("❌ SSH_AUTH_SOCK not set.")
        print("   Run: eval $(ssh-agent) && ssh-add ~/.ssh/id_ed25519")
        return
    print(f"✅ SSH agent socket: {ssh_sock}")

    # 2. Host SSH test
    print("\n[1/2] Testing SSH on host...")
    ok, output = _test_ssh_github()
    if ok:
        print(f"✅ Host SSH OK: {output}")
    else:
        print(f"❌ Host SSH failed: {output}")
        print("   Make sure your key is added: ssh-add ~/.ssh/id_ed25519")
        return

    # 3. Container SSH test
    print("\n[2/2] Testing SSH inside Docker container (git-catcher:latest)...")
    result = subprocess.run(
        [
            "docker", "run", "--rm",
            "-e", "SSH_AUTH_SOCK=/ssh-agent",
            "-v", f"{ssh_sock}:/ssh-agent",
            "git-catcher:latest",
            "ssh", "-T", "-o", "StrictHostKeyChecking=no", "git@github.com",
        ],
        capture_output=True, text=True,
    )
    output = (result.stdout + result.stderr).strip()
    ok = "Hi " in output or "successfully authenticated" in output
    if ok:
        print(f"✅ Container SSH OK: {output}")
    else:
        print(f"❌ Container SSH failed: {output}")
        print("   Make sure the image is built: make docker-build")
        return

    print("\n🎉 SSH setup verified. You're good to go.")
