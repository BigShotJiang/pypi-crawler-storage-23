"""git-catcher init — Interactive setup"""
import os
import secrets
import webbrowser
from pathlib import Path

from InquirerPy.resolver import prompt
from InquirerPy.validator import PathValidator

from git_catcher import __version__

def load_existing_env(env_path: Path | None = None) -> dict[str, str]:
    """Read configuration from an existing .env file and environment variables.

    Priority: environment variables > .env file values
    """
    existing: dict[str, str] = {}
    path = env_path or Path(".env")

    # Parse .env file
    if path.exists():
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                key, _, value = line.partition("=")
                existing[key.strip()] = value.strip()

    # Override with environment variables (env vars take priority)
    env_overrides = []
    for key in (
        "SMEE_URL", "WEBHOOK_SECRET", "REPO_PATH", "ALLOWED_BRANCHES",
        "POST_PULL_COMMAND", "SLACK_WEBHOOK_URL", "POLL_INTERVAL",
    ):
        env_val = os.environ.get(key)
        if env_val is not None:
            existing[key] = env_val
            env_overrides.append(key)

    # Notify about env var overrides
    if env_overrides:
        print()
        print(f"⚠️  Items overridden by environment variables: {', '.join(env_overrides)}")

    return existing


def generate_secret() -> str:
    """Generate a random webhook secret."""
    return secrets.token_urlsafe(32)


def run_init(non_interactive: bool = False, template: str = "docker"):
    """Interactive setup for git-catcher"""
    # Load configuration from existing .env / environment variables
    existing = load_existing_env()
    has_existing = bool(existing)
    print(f"\n\n Git Catcher version => {__version__}")
    print("\n🚀 Starting git-catcher initial setup.")
    if has_existing:
        print("📋 Existing configuration detected. Values will be used as defaults.\n")
    else:
        print()

    if non_interactive:
        # Use existing values first, fall back to defaults
        config = {
            "smee_url": existing.get("SMEE_URL", "https://smee.io/YOUR_CHANNEL_ID"),
            "webhook_secret": existing.get("WEBHOOK_SECRET") or generate_secret(),
            "repo_path": existing.get("REPO_PATH", "./repo"),
            "allowed_branches": existing.get("ALLOWED_BRANCHES", "main,master"),
            "post_pull_command": existing.get("POST_PULL_COMMAND", ""),
            "slack_webhook_url": existing.get("SLACK_WEBHOOK_URL", ""),
            "poll_interval": existing.get("POLL_INTERVAL", "0"),
        }
    else:
        # --- REPO_PATH: confirm first if an existing value is present ---
        existing_repo = existing.get("REPO_PATH")
        if existing_repo:
            use_existing = prompt([{
                "type": "confirm",
                "name": "use",
                "message": f"Use REPO_PATH={existing_repo}?",
                "default": True,
            }])["use"]
            if use_existing:
                repo_path = existing_repo
            else:
                repo_path = prompt([{
                    "type": "filepath",
                    "name": "path",
                    "message": "Target repository path:",
                    "default": existing_repo,
                    "validate": PathValidator(is_dir=True, message="Please enter a valid directory"),
                }])["path"]
        else:
            repo_path = prompt([{
                "type": "filepath",
                "name": "path",
                "message": "Target repository path:",
                "default": str(Path.cwd()),
                "validate": PathValidator(is_dir=True, message="Please enter a valid directory"),
            }])["path"]

        # --- Smee.io URL ---
        existing_smee = existing.get("SMEE_URL", "")
        is_real_smee = existing_smee.startswith("https://smee.io/") and "YOUR_CHANNEL_ID" not in existing_smee

        if is_real_smee:
            smee_choice = prompt([{
                "type": "list",
                "name": "smee_choice",
                "message": f"Smee.io URL (current: {existing_smee}):",
                "choices": [
                    {"name": f"Keep existing ({existing_smee})", "value": "keep"},
                    {"name": "Create new (open in browser)", "value": "new"},
                    {"name": "Enter manually", "value": "manual"},
                ],
            }])["smee_choice"]
        else:
            smee_choice = prompt([{
                "type": "list",
                "name": "smee_choice",
                "message": "Smee.io URL:",
                "choices": [
                    {"name": "Create new (open in browser)", "value": "new"},
                    {"name": "Enter manually", "value": "manual"},
                ],
            }])["smee_choice"]

        if smee_choice == "keep":
            smee_url = existing_smee
        elif smee_choice == "new":
            print("Opening https://smee.io/new in your browser...")
            webbrowser.open("https://smee.io/new")
            smee_url = prompt([{
                "type": "input",
                "name": "url",
                "message": "Enter the generated Smee.io URL:",
                "validate": lambda x: x.startswith("https://smee.io/") or "Must start with https://smee.io/",
            }])["url"]
        else:
            smee_url = prompt([{
                "type": "input",
                "name": "url",
                "message": "Smee.io URL:",
                "default": existing_smee or "https://smee.io/YOUR_CHANNEL_ID",
            }])["url"]

        # --- Webhook Secret ---
        existing_secret = existing.get("WEBHOOK_SECRET", "")
        if existing_secret:
            secret_choice = prompt([{
                "type": "list",
                "name": "choice",
                "message": f"Webhook Secret (current: {existing_secret[:8]}...):",
                "choices": [
                    {"name": "Keep existing", "value": "keep"},
                    {"name": "Regenerate randomly", "value": "random"},
                    {"name": "Enter manually", "value": "manual"},
                ],
            }])["choice"]
        else:
            secret_choice = prompt([{
                "type": "list",
                "name": "choice",
                "message": "Webhook Secret:",
                "choices": [
                    {"name": "Generate randomly (recommended)", "value": "random"},
                    {"name": "Enter manually", "value": "manual"},
                ],
            }])["choice"]

        if secret_choice == "keep":
            webhook_secret = existing_secret
        elif secret_choice == "random":
            webhook_secret = generate_secret()
        else:
            webhook_secret = prompt([{
                "type": "input",
                "name": "secret",
                "message": "Enter Webhook Secret:",
            }])["secret"]

        # --- Allowed Branches ---
        existing_branches = existing.get("ALLOWED_BRANCHES", "")
        existing_branch_list = [b.strip() for b in existing_branches.split(",") if b.strip()] if existing_branches else []

        # Base choices + any existing branches not already in the list
        base_choices = ["main", "master", "develop", "devel"]
        extra_branches = [b for b in existing_branch_list if b not in base_choices]
        default_selected = set(existing_branch_list) if existing_branch_list else {"main"}

        all_choices = [
            {"name": b, "value": b, "enabled": b in default_selected}
            for b in base_choices + extra_branches
        ] + [{"name": "Custom input", "value": "custom", "enabled": False}]

        branches_result = prompt([{
            "type": "checkbox",
            "name": "branches",
            "message": "Allowed branches (space to select, enter to confirm):",
            "choices": all_choices,
        }])["branches"]

        allowed_branches_list: list[str] = []
        if isinstance(branches_result, list):
            allowed_branches_list = [str(b) for b in branches_result]
        else:
            allowed_branches_list = [str(branches_result)]

        if "custom" in allowed_branches_list:
            allowed_branches_list.remove("custom")
            custom = prompt([{
                "type": "input",
                "name": "custom",
                "message": "Custom branches (comma-separated):",
            }])["custom"]
            if isinstance(custom, str):
                allowed_branches_list.extend([b.strip() for b in custom.split(",") if b.strip()])

        allowed_branches = ",".join(allowed_branches_list)

        # --- Post Pull Command ---
        post_pull_command = prompt([{
            "type": "input",
            "name": "cmd",
            "message": "Deploy command (leave empty for git pull only):",
            "default": existing.get("POST_PULL_COMMAND", ""),
        }])["cmd"]

        # --- Slack Webhook URL ---
        slack_webhook_url = prompt([{
            "type": "input",
            "name": "url",
            "message": "Slack Webhook URL (optional):",
            "default": existing.get("SLACK_WEBHOOK_URL", ""),
        }])["url"]

        # --- Poll Interval ---
        poll_interval = prompt([{
            "type": "input",
            "name": "interval",
            "message": "Git poll interval in seconds (0=disabled):",
            "default": existing.get("POLL_INTERVAL", "0"),
            "validate": lambda x: x.isdigit() or "Please enter a number",
        }])["interval"]

        config = {
            "smee_url": smee_url,
            "webhook_secret": webhook_secret,
            "repo_path": repo_path,
            "allowed_branches": allowed_branches,
            "post_pull_command": post_pull_command,
            "slack_webhook_url": slack_webhook_url,
            "poll_interval": poll_interval,
        }

    # Generate .env file
    env_path = Path(".env")
    skip_env = False
    if env_path.exists():
        overwrite = non_interactive or prompt([{
            "type": "confirm",
            "name": "overwrite",
            "message": ".env file already exists. Overwrite?",
            "default": False,
        }])["overwrite"]
        if not overwrite:
            print("⏭️  Skipping .env (keeping existing).")
            skip_env = True

    if not skip_env:
        env_content = f"""# git-catcher configuration
SMEE_URL={config['smee_url']}
WEBHOOK_SECRET={config['webhook_secret']}
REPO_PATH={config['repo_path']}
ALLOWED_BRANCHES={config['allowed_branches']}
POST_PULL_COMMAND={config['post_pull_command']}
SLACK_WEBHOOK_URL={config['slack_webhook_url']}
NOTIFY_ON_START=true
POLL_INTERVAL={config['poll_interval']}
LOG_LEVEL=INFO
LOG_FILE=
SHOW_ALL_EVENTS=false
"""
        env_path.write_text(env_content)
        print(f"✅ .env file created: {env_path.absolute()}")

    # Generate docker-compose.yml (optional)
    if template == "docker":
        create_compose = non_interactive or prompt([{
            "type": "confirm",
            "name": "create",
            "message": "Generate docker-compose.yml?",
            "default": True,
        }])["create"]

        if create_compose:
            compose_path = Path("docker-compose.yml")
            if compose_path.exists():
                overwrite = non_interactive or prompt([{
                    "type": "confirm",
                    "name": "overwrite",
                    "message": "docker-compose.yml already exists. Overwrite?",
                    "default": False,
                }])["overwrite"]
                if not overwrite:
                    print("❌ Skipping docker-compose.yml creation.")
                    return

            compose_content = f"""services:
  git-catcher:
    image: git-catcher:latest
    volumes:
      - {config['repo_path']}:/repo
      - ./.env:/app/.env:ro
      - ${{SSH_AUTH_SOCK}}:/ssh-agent
    restart: unless-stopped
    environment:
      - REPO_PATH=/repo
      - COLUMNS=220
      - SSH_AUTH_SOCK=/ssh-agent
"""

            compose_path.write_text(compose_content)
            print(f"✅ docker-compose.yml created: {compose_path.absolute()}")

    print("\n🎉 Initial setup complete!")
    print("\nNext steps:")
    print("1. Configure webhook on GitHub (Payload URL: Smee.io URL, Secret: WEBHOOK_SECRET)")
    print("2. Run git-catcher: python -m git_catcher.main")
    if template == "docker":
        print("   Or with Docker: docker compose up -d")
