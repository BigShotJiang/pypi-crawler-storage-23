# Code of Conduct

## Our pledge

We pledge to make participation in this project a harassment-free experience
for everyone, regardless of age, body size, visible or invisible disability,
ethnicity, sex characteristics, gender identity and expression, level of
experience, education, socioeconomic status, nationality, personal appearance,
race, religion, or sexual identity and orientation.

## Our standards

Examples of behavior that contributes to a positive environment include:

- Demonstrating empathy and kindness
- Being respectful of differing opinions and experiences
- Giving and accepting constructive feedback
- Taking responsibility for mistakes and learning from them
- Focusing on what is best for the community

Examples of unacceptable behavior include:

- Sexualized language or imagery and unwelcome sexual attention
- Trolling, insulting or derogatory comments, and personal attacks
- Public or private harassment
- Publishing others' private information without explicit permission
- Other conduct that could reasonably be considered inappropriate

## Enforcement responsibilities

Project maintainers are responsible for clarifying and enforcing standards of
acceptable behavior and may take appropriate and fair corrective action in
response to unacceptable behavior.

## Scope

This Code of Conduct applies in all project spaces and whenever someone is
officially representing the project in public spaces.

## Reporting

Instances of abusive, harassing, or otherwise unacceptable behavior may be
reported to:

- `schuler.nicolas@proton.me`

All reports will be reviewed and investigated promptly and fairly.

## Enforcement guidelines

Maintainers may use the following enforcement levels:

1. Correction: private, written warning for minor first-time violations.
2. Warning: formal warning with requested behavior change.
3. Temporary ban: temporary ban from interaction or participation.
4. Permanent ban: permanent ban for severe or repeated violations.

## Attribution

This Code of Conduct is adapted from the Contributor Covenant, version 2.1:

https://www.contributor-covenant.org/version/2/1/code_of_conduct/
