a = [*map(int, input().split())]
a[a[a[0]]]
