S = input()
T = input()
A = ["R G B", "B R G", "G B R"]
if S in A == T in A:
    print("Yes")
else:
    print("No")
