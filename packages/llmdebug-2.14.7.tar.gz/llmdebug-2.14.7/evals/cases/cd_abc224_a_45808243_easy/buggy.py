A = input()
if A[len(A) - 1] == "r":
    print("er")
else:
    print("st")
