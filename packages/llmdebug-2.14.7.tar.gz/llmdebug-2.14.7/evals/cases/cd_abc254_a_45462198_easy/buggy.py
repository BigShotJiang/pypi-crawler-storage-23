print(int(input()) % 100)
