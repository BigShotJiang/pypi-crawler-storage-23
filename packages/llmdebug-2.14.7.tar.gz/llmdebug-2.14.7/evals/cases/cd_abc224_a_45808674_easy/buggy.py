s = input()
a = len(s)
if s[a - 2 : a - 1] == "er":
    print("er")
else:
    print("ist")
