from pandas._libs.tslibs import NaT
from ppinot4py.model import *
from ppinot4py.computers import *
from datetime import time
import holidays as pyholidays
import datetime
import pandas as pd
import pytest
import numpy as np
import math


@pytest.fixture
def log_for_time():
    IdCase1 = '1-364285768'
    IdCase2 = '2-364285768'
    IdCase3 = '3-364285768'

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2011, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2012, 4, 6, 16, 44, 7)
    time4 = datetime.datetime(2013, 4, 6, 16, 44, 7)
    time5 = datetime.datetime(2014, 5, 6, 16, 44, 7)
    time6 = datetime.datetime(2015, 6, 6, 16, 44, 7)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase2, IdCase2, IdCase3, IdCase3],
            'time:timestamp': [time1, time2, time3, time4, time5, time6],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment']}

    dataframeLinear = pd.DataFrame(data)

    return dataframeLinear


@pytest.fixture
def log_config():

    return LogConfiguration()


def test_aggregated_compute_time_grouped(log_for_time, log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True)

    aggregatedMeasure = AggregatedMeasure(
        base_measure=timeMeasureLinearA,
        single_instance_agg_function='SUM')

    timeResult1 = datetime.timedelta(days=365, minutes=46, seconds=6)

    var = measure_computer(aggregatedMeasure, log_for_time,
                           log_config, time_grouper=pd.Grouper(freq='1YE'))

    assert var.size == 5
    assert var.iloc[0] == timeResult1
    assert pd.isnull(var.iloc[1])
    assert var.iloc[2] == datetime.timedelta(days=365)




def test_aggregated_compute_time_no_group(log_for_time, log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True)

    aggregatedMeasure = AggregatedMeasure(
        base_measure=timeMeasureLinearA,
        single_instance_agg_function='SUM')

    var = measure_computer(aggregatedMeasure, log_for_time, log_config)

    assert var == datetime.timedelta(days=1126, minutes=46, seconds=6)

def test_aggregated_compute_time_no_group_min(log_for_time, log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True)

    aggregatedMeasure = AggregatedMeasure(
        base_measure=timeMeasureLinearA,
        single_instance_agg_function='MIN')

    var = measure_computer(aggregatedMeasure, log_for_time, log_config)

    assert var == datetime.timedelta(days=365)    

def test_aggregated_compute_time_no_group_median(log_for_time, log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True)

    aggregatedMeasure = AggregatedMeasure(
        base_measure=timeMeasureLinearA,
        single_instance_agg_function='MEDIAN')

    var = measure_computer(aggregatedMeasure, log_for_time, log_config)

    assert var == datetime.timedelta(days=365, minutes=46, seconds=6)

def test_aggregated_compute_time_no_group_p90(log_for_time, log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True)

    aggregatedMeasure = AggregatedMeasure(
        base_measure=timeMeasureLinearA,
        single_instance_agg_function='P90')

    var = measure_computer(aggregatedMeasure, log_for_time, log_config)

    durations = [
        datetime.timedelta(days=365, minutes=46, seconds=6).total_seconds(),
        datetime.timedelta(days=365).total_seconds(),
        datetime.timedelta(days=396).total_seconds()
    ]
    expected_seconds = np.quantile(durations, 0.9)

    assert math.isclose(var.total_seconds(), expected_seconds, rel_tol=0, abs_tol=1e-6)

def test_aggregated_compute_time_no_group_invalid_percentile(log_for_time, log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True)

    aggregatedMeasure = AggregatedMeasure(
        base_measure=timeMeasureLinearA,
        single_instance_agg_function='P100')

    with pytest.raises(ValueError):
        measure_computer(aggregatedMeasure, log_for_time, log_config)


def test_derived_compute_time_condition(log_for_time, log_config):
    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True)

    derivedMeasure = DerivedMeasure("time < days366",
                                    {"time": timeMeasureLinearA,
                                     "days366": pd.Timedelta(days=366)})

    var = measure_computer(derivedMeasure, log_for_time, log_config)

    assert var.size == 3
    assert var.iloc[0]
    assert var.iloc[1]
    assert not var.iloc[2]


def test_derived_aggregated_time(log_for_time, log_config):
    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True)

    aggregatedMeasure = AggregatedMeasure(
        base_measure=timeMeasureLinearA,
        single_instance_agg_function='SUM')

    derivedMeasure = DerivedMeasure("time < days366",
                                    {"time": aggregatedMeasure,
                                     "days366": pd.Timedelta(days=366)})

    var = measure_computer(derivedMeasure, log_for_time,
                           log_config, time_grouper=pd.Grouper(freq='1YE'))

    assert var.size == 5
    assert np.all(var == [True, False, True, False, False])


def test_count_compute(log_config):

    countMeasure = CountMeasure('`lifecycle:transition` == "In Progress"')

    IdCase1 = '1-364285768'

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(countMeasure, dataframeLinear, log_config)

    assert var.iloc[0] == 2


def test_count_compute_not_appear(log_config):

    countMeasure = CountMeasure('`lifecycle:transition` == "Closed"')

    IdCase1 = '1-364285768'

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(countMeasure, dataframeLinear, log_config)

    assert var.iloc[0] == 0


def test_count_compute_instances(log_config):

    countMeasure = CountMeasure('`lifecycle:transition` == "In Progress"')

    IdCase1 = '1-364285768'
    idCase2 = '2-364285768'

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, idCase2, idCase2, idCase2],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress', 'In Progress', 'In Progress', 'In Progress']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(countMeasure, dataframeLinear, log_config)

    assert var.iloc[0] == 2
    assert var.iloc[1] == 1


def test_count_compute_data_condition_raw_events(log_config):

    count_measure = CountMeasure(
        when=DataCondition(condition="`org:resource`=='SYSTEM'")
    )

    id_case_1 = '1-364285768'
    id_case_2 = '2-364285768'

    data = {
        'case:concept:name': [id_case_1, id_case_1, id_case_1, id_case_2, id_case_2],
        'org:resource': ['SYSTEM', 'USER', 'SYSTEM', 'SYSTEM', 'SYSTEM']
    }

    dataframe_linear = pd.DataFrame(data)
    var = measure_computer(count_measure, dataframe_linear, log_config)

    assert var.loc[id_case_1] == 2
    assert var.loc[id_case_2] == 2


def test_count_compute_data_condition_true_counts_all_events(log_config):

    count_measure = CountMeasure(
        when=DataCondition(condition="True")
    )

    id_case_1 = '1-364285768'
    id_case_2 = '2-364285768'

    data = {
        'case:concept:name': [id_case_1, id_case_1, id_case_1, id_case_2, id_case_2],
        'org:resource': ['SYSTEM', 'USER', 'SYSTEM', 'SYSTEM', 'SYSTEM']
    }

    dataframe_linear = pd.DataFrame(data)
    var = measure_computer(count_measure, dataframe_linear, log_config)

    assert var.loc[id_case_1] == 3
    assert var.loc[id_case_2] == 2


def test_count_compute_data_condition_boolean_true_counts_all_events(log_config):

    count_measure = CountMeasure(
        when=DataCondition(condition=True)
    )

    id_case_1 = '1-364285768'
    id_case_2 = '2-364285768'

    data = {
        'case:concept:name': [id_case_1, id_case_1, id_case_1, id_case_2, id_case_2],
        'org:resource': ['SYSTEM', 'USER', 'SYSTEM', 'SYSTEM', 'SYSTEM']
    }

    dataframe_linear = pd.DataFrame(data)
    var = measure_computer(count_measure, dataframe_linear, log_config)

    assert var.loc[id_case_1] == 3
    assert var.loc[id_case_2] == 2


def test_data_computer(log_config):

    dataMeasure = DataMeasure(
        data_content_selection="lifecycle:transition",
        first=False)

    IdCase1 = '1-364285768'

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1],
            'concept:name': ['Queued', 'Queued', 'Not queued'],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'Completed']}

    dataframeLinear = pd.DataFrame(data)
    result = measure_computer(dataMeasure, dataframeLinear, log_config)

    assert result.iloc[0] == 'Completed'


def test_data_computer_precondition(log_config):

    dataMeasure = DataMeasure(
        precondition="`concept:name` == 'Queued'",
        data_content_selection="lifecycle:transition",
        first=False)

    IdCase1 = '1-364285768'

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1],
            'concept:name': ['Queued', 'Queued', 'Not queued'],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress']}

    dataframeLinear = pd.DataFrame(data)
    result = measure_computer(dataMeasure, dataframeLinear, log_config)

    assert result.iloc[0] == 'In Progress'


def test_time_linear_instances(log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True)

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)

    IdCase1 = '1-364285768'

    timeResult = datetime.timedelta(minutes=46, seconds=6)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1],
            'time:timestamp': [time1, time2, time3],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        timeMeasureLinearA, dataframeLinear, log_config)
    assert var.iloc[0] == timeResult


def test_time_linear_instances_with_several_from(log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=False)

    IdCase1 = '1-364285768'

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)
    time4 = datetime.datetime(2012, 4, 6, 16, 44, 7)
    time5 = datetime.datetime(2012, 5, 6, 16, 44, 7)
    time6 = datetime.datetime(2012, 6, 6, 16, 44, 7)

    timeResult = datetime.timedelta(minutes=46, seconds=6)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1],
            'time:timestamp': [time1, time2, time3, time4, time5, time6],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress', 'In Progress', 'In Progress', 'In Progress']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        timeMeasureLinearA, dataframeLinear, log_config)
    assert var.iloc[0] == timeResult


def test_time_linear_instances_WithSeveralToAndFirstTo(log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True)

    IdCase1 = '1-364285768'

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)
    time4 = datetime.datetime(2012, 4, 6, 16, 44, 7)
    time5 = datetime.datetime(2012, 5, 6, 16, 44, 7)
    time6 = datetime.datetime(2012, 6, 6, 16, 44, 7)

    timeResult = datetime.timedelta(minutes=46, seconds=6)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1],
            'time:timestamp': [time1, time2, time3, time4, time5, time6],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress', 'In Progress', 'In Progress', 'In Progress']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        timeMeasureLinearA, dataframeLinear, log_config)
    assert var.iloc[0] == timeResult


def test_time_linear_instances_WithSeveralToAndNotFirstTo(log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=False)

    IdCase1 = '1-364285768'

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)
    time4 = datetime.datetime(2012, 4, 6, 16, 44, 7)
    time5 = datetime.datetime(2012, 5, 6, 16, 44, 7)
    time6 = datetime.datetime(2012, 6, 6, 16, 44, 7)

    timeResult = datetime.timedelta(days=797, hours=23, minutes=44, seconds=25)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1],
            'time:timestamp': [time1, time2, time3, time4, time5, time6],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        timeMeasureLinearA, dataframeLinear, log_config)
    assert var.iloc[0] == timeResult


def test_time_linear_instances_WithSeveralFromAndToAndFirstTo2(log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=False)

    IdCase1 = '1-364285768'

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)
    time4 = datetime.datetime(2012, 4, 6, 16, 44, 7)
    time5 = datetime.datetime(2012, 5, 1, 16, 44, 7)
    time6 = datetime.datetime(2012, 5, 2, 16, 44, 7)
    time7 = datetime.datetime(2012, 5, 3, 16, 44, 7)
    time8 = datetime.datetime(2012, 6, 6, 16, 44, 7)

    timeResult = datetime.timedelta(days=797, hours=23, minutes=44, seconds=25)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1],
            'time:timestamp': [time1, time2, time3, time4, time5, time6, time7, time8],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        timeMeasureLinearA, dataframeLinear, log_config)
    assert var.iloc[0] == timeResult


def test_time_cyclic_SumInstances(log_config):

    timeMeasureCyclic = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        single_instance_agg_function='SUM',
        time_measure_type='CYCLIC')

    IdCase1 = '1-364285768'
    IdCase2 = '2-364285768'

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)
    time4 = datetime.datetime(2012, 4, 6, 16, 44, 7)
    time5 = datetime.datetime(2012, 5, 1, 16, 44, 7)
    time6 = datetime.datetime(2012, 5, 2, 16, 44, 7)
    time7 = datetime.datetime(2012, 5, 3, 16, 44, 7)
    time8 = datetime.datetime(2012, 6, 6, 16, 44, 7)

    timeResult = datetime.timedelta(days=732, minutes=46, seconds=6)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase2, IdCase1],
            'time:timestamp': [time1, time2, time3, time4, time5, time6, time7, time8],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        timeMeasureCyclic, dataframeLinear, log_config)

    assert var.iloc[0] == timeResult


def test_time_cyclic_MaxInstances(log_config):

    timeMeasureCyclic = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        single_instance_agg_function='MAX',
        time_measure_type='CYCLIC')

    IdCase1 = '1-364285768'
    IdCase2 = '2-364285768'

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)
    time4 = datetime.datetime(2012, 4, 6, 16, 44, 7)
    time5 = datetime.datetime(2012, 5, 1, 16, 44, 7)
    time6 = datetime.datetime(2012, 5, 2, 16, 44, 7)
    time7 = datetime.datetime(2012, 5, 3, 16, 44, 7)
    time8 = datetime.datetime(2012, 6, 6, 16, 44, 7)

    timeResult = datetime.timedelta(days=731)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase2, IdCase1],
            'time:timestamp': [time1, time2, time3, time4, time5, time6, time7, time8],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        timeMeasureCyclic, dataframeLinear, log_config)

    assert var.iloc[0] == timeResult


def test_time_cyclic_AvgInstances(log_config):

    timeMeasureCyclic = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        single_instance_agg_function='AVG',
        time_measure_type='CYCLIC')

    IdCase1 = '1-364285768'

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)
    time4 = datetime.datetime(2012, 4, 6, 16, 44, 7)
    time5 = datetime.datetime(2012, 5, 1, 16, 44, 7)
    time6 = datetime.datetime(2012, 5, 2, 16, 44, 7)
    time7 = datetime.datetime(2012, 5, 3, 16, 44, 7)
    time8 = datetime.datetime(2012, 6, 6, 16, 44, 7)

    timeResult = datetime.timedelta(
        days=191, hours=12, minutes=11, seconds=31.5)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1],
            'time:timestamp': [time1, time2, time3, time4, time5, time6, time7, time8],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        timeMeasureCyclic, dataframeLinear, log_config)

    assert var.iloc[0] == timeResult

def test_time_cyclic_lowercase_type(log_config):

    timeMeasureCyclic = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        single_instance_agg_function='AVG',
        time_measure_type='cyclic')

    IdCase1 = '1-364285768'

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)
    time4 = datetime.datetime(2012, 4, 6, 16, 44, 7)
    time5 = datetime.datetime(2012, 5, 1, 16, 44, 7)
    time6 = datetime.datetime(2012, 5, 2, 16, 44, 7)
    time7 = datetime.datetime(2012, 5, 3, 16, 44, 7)
    time8 = datetime.datetime(2012, 6, 6, 16, 44, 7)

    timeResult = datetime.timedelta(
        days=191, hours=12, minutes=11, seconds=31.5)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1],
            'time:timestamp': [time1, time2, time3, time4, time5, time6, time7, time8],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        timeMeasureCyclic, dataframeLinear, log_config)

    assert var.iloc[0] == timeResult


def test_derived_instances(log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True)

    timeMeasureLinearB = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Closed"',
        first_to=True)

    timeMeasureLinearC = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Pending"',
        first_to=True)

    measure_dictionary = {'ProgressTime': timeMeasureLinearA,
                          'ClosedTime': timeMeasureLinearB, 'PendingTime': timeMeasureLinearC}
    derived_measure = DerivedMeasure(
        function_expression='(ProgressTime + ClosedTime) + PendingTime',
        measure_map=measure_dictionary)

    IdCase1 = '1-364285768'

    time_result = datetime.timedelta(days=3360, minutes=14, seconds=56)

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2011, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2012, 4, 6, 16, 44, 7)
    time4 = datetime.datetime(2013, 4, 6, 16, 44, 7)
    time5 = datetime.datetime(2014, 5, 6, 16, 44, 7)
    time6 = datetime.datetime(2015, 6, 6, 16, 44, 7)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1],
            'time:timestamp': [time1, time2, time3, time4, time5, time6],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress', 'Closed', 'In Progress', 'Pending']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(derived_measure, dataframeLinear, log_config)

    assert var.iloc[0] == time_result

def test_kpi_duplicate_request_payment_ratio(log_config):
    cnt_request = CountMeasure('`concept:name` == "Request Payment"')

    den_has_request = DerivedMeasure(
        'cnt_request >= 1', {'cnt_request': cnt_request})
    num_duplicate = DerivedMeasure(
        'cnt_request >= 2', {'cnt_request': cnt_request})

    # Numerator: count cases with duplicates
    num_cases = AggregatedMeasure(num_duplicate, 'SUM')
    # Denominator: count cases with at least one request
    den_cases = AggregatedMeasure(den_has_request, 'SUM')

    kpi_metric = DerivedMeasure(
        'num_cases / den_cases',
        {
            'num_cases': num_cases,
            'den_cases': den_cases
        }
    )

    data = {'case:concept:name': ['c1', 'c1', 'c2', 'c2', 'c2', 'c3', 'c4', 'c4', 'c4', 'c4', 'c4'],
            'concept:name': ['Request Payment', 'Other', 'Request Payment', 'Other', 'Request Payment',
                             'Other', 'Request Payment', 'Other', 'Request Payment', 'Other', 'Request Payment'],
            'time:timestamp': [
                datetime.datetime(2020, 1, 1, 10, 0, 0),
                datetime.datetime(2020, 1, 1, 11, 0, 0),
                datetime.datetime(2020, 1, 2, 10, 0, 0),
                datetime.datetime(2020, 1, 2, 11, 0, 0),
                datetime.datetime(2020, 1, 2, 12, 0, 0),
                datetime.datetime(2020, 1, 3, 10, 0, 0),
                datetime.datetime(2020, 1, 4, 10, 0, 0),
                datetime.datetime(2020, 1, 4, 11, 0, 0),
                datetime.datetime(2020, 1, 4, 12, 0, 0),
                datetime.datetime(2020, 1, 4, 13, 0, 0),
                datetime.datetime(2020, 1, 4, 14, 0, 0),
            ]}

    dataframe = pd.DataFrame(data)

    result = measure_computer(kpi_metric, dataframe, log_config, time_grouper=pd.Grouper(freq='1YE'))

    assert result.size == 1
    assert result.iloc[0] == pytest.approx(2 / 3)

def test_kpi_duplicate_request_payment_ratio_no_grouper(log_config):
    cnt_request = CountMeasure('`concept:name` == "Request Payment"')

    den_has_request = DerivedMeasure(
        'cnt_request >= 1', {'cnt_request': cnt_request})
    num_duplicate = DerivedMeasure(
        'cnt_request >= 2', {'cnt_request': cnt_request})

    num_cases = AggregatedMeasure(num_duplicate, 'SUM')
    den_cases = AggregatedMeasure(den_has_request, 'SUM')

    kpi_metric = DerivedMeasure(
        'num_cases / den_cases',
        {
            'num_cases': num_cases,
            'den_cases': den_cases
        }
    )

    data = {'case:concept:name': ['c1', 'c1', 'c2', 'c2', 'c2', 'c3', 'c4', 'c4', 'c4', 'c4', 'c4'],
            'concept:name': ['Request Payment', 'Other', 'Request Payment', 'Other', 'Request Payment',
                             'Other', 'Request Payment', 'Other', 'Request Payment', 'Other', 'Request Payment'],
            'time:timestamp': [
                datetime.datetime(2020, 1, 1, 10, 0, 0),
                datetime.datetime(2020, 1, 1, 11, 0, 0),
                datetime.datetime(2020, 1, 2, 10, 0, 0),
                datetime.datetime(2020, 1, 2, 11, 0, 0),
                datetime.datetime(2020, 1, 2, 12, 0, 0),
                datetime.datetime(2020, 1, 3, 10, 0, 0),
                datetime.datetime(2020, 1, 4, 10, 0, 0),
                datetime.datetime(2020, 1, 4, 11, 0, 0),
                datetime.datetime(2020, 1, 4, 12, 0, 0),
                datetime.datetime(2020, 1, 4, 13, 0, 0),
                datetime.datetime(2020, 1, 4, 14, 0, 0),
            ]}

    dataframe = pd.DataFrame(data)

    result = measure_computer(kpi_metric, dataframe, log_config)

    assert result == pytest.approx(2 / 3)


def test_time_linear_instances_businessDuration_from_7_to_17(log_config):

    business = BusinessDuration(
        business_start=time(7, 0, 0),
        business_end=time(17, 0, 0),
        weekend_list=[5, 6],
        holiday_list=pyholidays.ES(prov='AN')
    )

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True,
        business_duration=business)

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)

    IdCase1 = '1-364285768'

    timeResult = pd.Timedelta(seconds=18)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1],
            'time:timestamp': [time1, time2, time3],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        timeMeasureLinearA, dataframeLinear, log_config)
    assert var.iloc[0] == timeResult


def test_time_linear_instances_businessDuration_from_7_to_17_severalFrom(log_config):

    business = BusinessDuration(
        business_start=time(7, 0, 0),
        business_end=time(17, 0, 0),
        weekend_list=[5, 6],
        holiday_list=pyholidays.ES(prov='AN')
    )

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=False,
        business_duration=business)

    IdCase1 = '1-364285768'

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)
    time4 = datetime.datetime(2012, 4, 6, 16, 44, 7)
    time5 = datetime.datetime(2012, 5, 6, 16, 44, 7)
    time6 = datetime.datetime(2012, 6, 6, 16, 44, 7)

    timeResult = pd.Timedelta(seconds=18)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1],
            'time:timestamp': [time1, time2, time3, time4, time5, time6],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress', 'In Progress', 'In Progress', 'In Progress']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        timeMeasureLinearA, dataframeLinear, log_config)
    assert var.iloc[0] == timeResult


def test_time_cyclic_SumInstances_businessDuration(log_config):

    business = BusinessDuration(
        business_start=time(7, 0, 0),
        business_end=time(17, 0, 0),
        weekend_list=[5, 6],
        holiday_list=pyholidays.ES(prov='AN')
    )

    timeMeasureCyclic = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        single_instance_agg_function='SUM',
        time_measure_type='CYCLIC',
        business_duration=business)

    IdCase1 = '1-364285768'
    IdCase2 = '2-364285768'

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)
    time4 = datetime.datetime(2012, 4, 6, 16, 44, 7)
    time5 = datetime.datetime(2012, 5, 1, 16, 44, 7)
    time6 = datetime.datetime(2012, 5, 2, 16, 44, 7)
    time7 = datetime.datetime(2012, 5, 3, 16, 44, 7)
    time8 = datetime.datetime(2012, 6, 6, 16, 44, 7)

    timeResult = pd.Timedelta(days=209, hours=14, seconds=18)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase2, IdCase1],
            'time:timestamp': [time1, time2, time3, time4, time5, time6, time7, time8],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        timeMeasureCyclic, dataframeLinear, log_config)

    assert var.iloc[0] == timeResult


def test_time_cyclic_MaxInstances_businessDuration(log_config):

    business = BusinessDuration(
        business_start=time(7, 0, 0),
        business_end=time(17, 0, 0),
        weekend_list=[5, 6],
        holiday_list=pyholidays.ES(prov='AN')
    )

    timeMeasureCyclic = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        single_instance_agg_function='MAX',
        time_measure_type='CYCLIC',
        business_duration=business)

    IdCase1 = '1-364285768'
    IdCase2 = '2-364285768'

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)
    time4 = datetime.datetime(2012, 4, 6, 16, 44, 7)
    time5 = datetime.datetime(2012, 5, 1, 16, 44, 7)
    time6 = datetime.datetime(2012, 5, 2, 16, 44, 7)
    time7 = datetime.datetime(2012, 5, 3, 16, 44, 7)
    time8 = datetime.datetime(2012, 6, 6, 16, 44, 7)

    timeResult = datetime.timedelta(days=209, hours=4, minutes=15, seconds=53)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase2, IdCase1],
            'time:timestamp': [time1, time2, time3, time4, time5, time6, time7, time8],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        timeMeasureCyclic, dataframeLinear, log_config)

    assert var.iloc[0] == timeResult


def test_time_cyclic_AVGInstances_businessDuration(log_config):

    business = BusinessDuration(
        business_start=time(7, 0, 0),
        business_end=time(17, 0, 0),
        weekend_list=[5, 6],
        holiday_list=pyholidays.ES(prov='AN')
    )

    timeMeasureCyclic = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        single_instance_agg_function='AVG',
        time_measure_type='CYCLIC',
        business_duration=business)

    IdCase1 = '1-364285768'
    IdCase2 = '2-364285768'

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)
    time4 = datetime.datetime(2012, 4, 6, 16, 44, 7)
    time5 = datetime.datetime(2012, 5, 1, 16, 44, 7)
    time6 = datetime.datetime(2012, 5, 2, 16, 44, 7)
    time7 = datetime.datetime(2012, 5, 3, 16, 44, 7)
    time8 = datetime.datetime(2012, 6, 6, 16, 44, 7)

    timeResult = datetime.timedelta(days=69, hours=20, minutes=40, seconds=6)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase1, IdCase2, IdCase1],
            'time:timestamp': [time1, time2, time3, time4, time5, time6, time7, time8],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment', 'In Progress', 'Awaiting Assignment']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        timeMeasureCyclic, dataframeLinear, log_config)

    assert var.iloc[0] == timeResult

def test_time_linear_instances_global_businessDuration_default(log_config):

    business = BusinessDuration(
        business_start=time(7, 0, 0),
        business_end=time(17, 0, 0),
        weekend_list=[5, 6],
        holiday_list=pyholidays.ES(prov='AN')
    )

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True
    )

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)

    IdCase1 = '1-364285768'

    expected_result = pd.Timedelta(seconds=18)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1],
            'time:timestamp': [time1, time2, time3],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        timeMeasureLinearA, dataframeLinear, log_config, business_duration=business)
    assert var.iloc[0] == expected_result

def test_time_linear_instances_measure_businessDuration_overrides_global(log_config):

    business_in_measure = BusinessDuration(
        business_start=time(7, 0, 0),
        business_end=time(17, 0, 0),
        weekend_list=[5, 6],
        holiday_list=pyholidays.ES(prov='AN')
    )
    business_global = BusinessDuration(
        business_start=time(17, 30, 0),
        business_end=time(18, 0, 0),
        weekend_list=[5, 6],
        holiday_list=pyholidays.ES(prov='AN')
    )

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True,
        business_duration=business_in_measure
    )

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)

    IdCase1 = '1-364285768'

    expected_result = pd.Timedelta(seconds=18)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1],
            'time:timestamp': [time1, time2, time3],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        timeMeasureLinearA, dataframeLinear, log_config, business_duration=business_global)
    assert var.iloc[0] == expected_result

def test_aggregated_time_uses_global_businessDuration_default(log_config):

    business = BusinessDuration(
        business_start=time(7, 0, 0),
        business_end=time(17, 0, 0),
        weekend_list=[5, 6],
        holiday_list=pyholidays.ES(prov='AN')
    )

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True
    )

    aggregatedMeasure = AggregatedMeasure(
        base_measure=timeMeasureLinearA,
        single_instance_agg_function='SUM')

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)

    IdCase1 = '1-364285768'

    expected_result = pd.Timedelta(seconds=18)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1],
            'time:timestamp': [time1, time2, time3],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'In Progress']}

    dataframeLinear = pd.DataFrame(data)
    var = measure_computer(
        aggregatedMeasure, dataframeLinear, log_config, business_duration=business)
    assert var == expected_result


def test_data_computer_precondition_predefined_log_values(log_config):

    precondition = TimeInstantCondition(
        "'Awaiting Assignment'", AppliesTo.ACTIVITY, "'Queued'")

    dataMeasure = DataMeasure(
        data_content_selection="lifecycle:transition",
        precondition=precondition,
        first=False)

    IdCase1 = '1-364285768'
    IdCase2 = '1-364285769'

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, IdCase2, IdCase1],
            'concept:name': ['Queued', 'Queued', 'Not queued', 'Queued', 'Not queued'],
            'lifecycle:transition': ['In Progress', 'Awaiting Assignment', 'Completed', 'Awaiting Assignment', 'Completed']}

    dataframeLinear = pd.DataFrame(data)

    result = measure_computer(dataMeasure, dataframeLinear, log_config)

    assert result.iloc[0] == 'Awaiting Assignment'


def test_data_computer_precondition_non_predefined_log_values(log_config):

    precondition = TimeInstantCondition(
        "'Awaiting Assignment'", AppliesTo.ACTIVITY, "'Queued'")

    log = LogConfiguration(
        id_case='case:concept:name',
        time_column='time:timestamp',
        transition_column='lifecycle:transition:transition',
        activity_column='concept:name:non:predefined')

    dataMeasure = DataMeasure(
        data_content_selection="lifecycle:transition:transition",
        precondition=precondition,
        first=False)

    IdCase1 = '1-364285768'
    IdCase2 = '1-364285769'

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, IdCase2, IdCase1],
            'concept:name:non:predefined': ['Queued', 'Queued', 'Not queued', 'Queued', 'Not queued'],
            'lifecycle:transition:transition': ['In Progress', 'Awaiting Assignment', 'Completed', 'Awaiting Assignment', 'Completed']}

    dataframeLinear = pd.DataFrame(data)

    result = measure_computer(dataMeasure, dataframeLinear, log)

    assert result.iloc[0] == 'Awaiting Assignment'

def test_data_computer_timestamp_precondition_activity_timeinstant(log_config):

    precondition = TimeInstantCondition(
        RuntimeState.START, AppliesTo.ACTIVITY, "'Queued'")

    dataMeasure = DataMeasure(
        data_content_selection="time:timestamp",
        precondition=precondition,
        first=False)

    IdCase1 = '1-364285768'
    IdCase2 = '1-364285769'

    time1 = datetime.datetime(2010, 3, 31, 16, 59, 42)
    time2 = datetime.datetime(2010, 3, 31, 17, 45, 48)
    time3 = datetime.datetime(2010, 4, 6, 16, 44, 7)
    time4 = datetime.datetime(2012, 4, 6, 16, 44, 7)

    data = {'case:concept:name': [IdCase1, IdCase1, IdCase1, IdCase2],
            'concept:name': ['Queued', 'Queued', 'Not queued', 'Queued'],
            'time:timestamp': [time1, time2, time3, time4],
            'lifecycle:transition': ['Assigned', 'Awaiting Assignment', 'Completed', 'Assigned']}

    dataframeLinear = pd.DataFrame(data)

    result = measure_computer(dataMeasure, dataframeLinear, log_config)

    assert result.loc[IdCase1] == time1
    assert result.loc[IdCase2] == time4

def test_aggregated_compute_time_rolling_base_date_window_800_days_sum_to_cases(log_for_time, log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"', 
        first_to=True)

    aggregatedMeasure = AggregatedMeasure(
        base_measure=timeMeasureLinearA, 
        single_instance_agg_function='SUM')

    rolling = RollingWindow(
      window = "800D",
      apply_to_cases=True
    )
    
    var = measure_computer(aggregatedMeasure, log_for_time, log_config, time_grouper=rolling)
    
    assert var.size == 3
    assert var.iloc[0] == datetime.timedelta(days=365, minutes=46, seconds=6)
    assert var.iloc[1] == datetime.timedelta(days=730, minutes=46, seconds=6)
    assert var.iloc[2] == datetime.timedelta(days=761)

def test_aggregated_compute_time_rolling_base_date_window_800_days_sum(log_for_time, log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"', 
        first_to=True)

    aggregatedMeasure = AggregatedMeasure(
        base_measure=timeMeasureLinearA, 
        single_instance_agg_function='SUM')

    rolling = RollingWindow(
      window = "800D"
    )
    
    var = measure_computer(aggregatedMeasure, log_for_time, log_config, time_grouper=rolling)

    counts = var.value_counts()
    
    assert var.size == 1529
    assert counts.index[0] == datetime.timedelta(days=365, minutes=46, seconds=6)
    assert counts.index[1] == datetime.timedelta(days=365)
    assert counts.index[2] == datetime.timedelta(days=730, minutes=46, seconds=6)
    assert counts.index[3] == datetime.timedelta(days=761)

def test_aggregated_compute_time_rolling_base_date_window_800_days_avg(log_for_time, log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"', 
        first_to=True)

    aggregatedMeasure = AggregatedMeasure(
        base_measure=timeMeasureLinearA, 
        single_instance_agg_function='AVG')

    rolling = RollingWindow(
      window = "800D"
    )
    
    var = measure_computer(aggregatedMeasure, log_for_time, log_config, time_grouper=rolling)

    counts = var.value_counts()
    
    assert var.size == 1529
    assert counts.index[0] == datetime.timedelta(days=365, minutes=46, seconds=6)
    assert counts.index[1] == datetime.timedelta(days=365)
    assert counts.index[2] == datetime.timedelta(days=365, minutes=23, seconds=3)
    assert counts.index[3] == datetime.timedelta(days=380, hours=12)

def test_aggregated_compute_time_rolling_base_date_window_800_days_p90_not_supported(log_for_time, log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"', 
        first_to=True)

    aggregatedMeasure = AggregatedMeasure(
        base_measure=timeMeasureLinearA,
        single_instance_agg_function='P90')

    rolling = RollingWindow(
      window = "800D"
    )

    with pytest.raises(ValueError):
        measure_computer(aggregatedMeasure, log_for_time, log_config, time_grouper=rolling)

def test_aggregated_compute_time_rolling_base_numeric_window_3_center_sum(log_for_time, log_config):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"', 
        first_to=True)

    aggregatedMeasure = AggregatedMeasure(
        base_measure=timeMeasureLinearA, 
        single_instance_agg_function='SUM')

    rolling = RollingWindow(
      window = 2,
      apply_to_cases=True
    )
    
    var = measure_computer(aggregatedMeasure, log_for_time, log_config, time_grouper=rolling)
    
    assert var.size == 3
    assert pd.isnull(var.iloc[0])
    assert var.iloc[1] == datetime.timedelta(days=730, minutes=46, seconds=6)
    assert var.iloc[2] == datetime.timedelta(days=761)

def test_time_computer_different_time_units_weeks(log_for_time):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True,
        time_unit=TimeUnit.WEEK)

    aggregatedMeasure = AggregatedMeasure(
        base_measure=timeMeasureLinearA,
        single_instance_agg_function='SUM')

    timeResult1 = 52.14743055555556
    timeResult2 = 52.142857142857146

    var = measure_computer(aggregatedMeasure, log_for_time,
                           LogConfiguration(), time_grouper=pd.Grouper(freq='1YE'))

    assert var.size == 5
    assert var.iloc[0] == timeResult1
    assert pd.isnull(var.iloc[1])
    assert var.iloc[2] == timeResult2


def test_time_computer_different_time_units_days(log_for_time):

    timeMeasureLinearA = TimeMeasure(
        from_condition='`lifecycle:transition` == "In Progress"',
        to_condition='`lifecycle:transition` == "Awaiting Assignment"',
        first_to=True,
        time_unit=TimeUnit.DAY)

    aggregatedMeasure = AggregatedMeasure(
        base_measure=timeMeasureLinearA,
        single_instance_agg_function='SUM')

    timeResult1 = 365.0320138888889
    timeResult2 = 365.0

    var = measure_computer(aggregatedMeasure, log_for_time,
                           LogConfiguration(), time_grouper=pd.Grouper(freq='1YE'))

    assert var.size == 5
    assert var.iloc[0] == timeResult1
    assert pd.isnull(var.iloc[1])
    assert var.iloc[2] == timeResult2
