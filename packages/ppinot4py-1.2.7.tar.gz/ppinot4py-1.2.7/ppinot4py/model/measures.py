from .conditions import DataCondition, SeriesCondition, TimeInstantCondition
import enum
import re

def _time_instance_auto_wrap(condition):
    if condition is None:
        return None

    if isinstance(condition, str):
        condition = TimeInstantCondition(condition)
    
    return condition

def _name_of_data_selection(selection):
    if selection == "concept:name":
        return "activity"
    if selection == "lifecycle:transition":
        return "lifecycle transition"
    if selection == "time:timestamp":
        return "timestamp"
    return selection

def _name_of_aggregation(agg):
    if not isinstance(agg, str):
        return str(agg)

    normalized_agg = agg.strip().upper()

    if normalized_agg == "AVG":
        return "average"
    if normalized_agg == "MIN":
        return "minimum"
    if normalized_agg == "MAX":
        return "maximum"
    if normalized_agg == "SUM":
        return "sum"
    if normalized_agg == "MEDIAN":
        return "median"

    percentile_match = re.fullmatch(r"P(\d{1,3})", normalized_agg)
    if percentile_match:
        percentile = int(percentile_match.group(1))
        if 1 <= percentile <= 99:
            return f"{percentile} percentile"

    return agg

class BusinessDuration():
    
    def __init__(self, business_start, business_end, weekend_list=[5,6], holiday_list=None):
        super().__init__()
        
        self.business_start = business_start
        self.business_end = business_end
        self.weekend_list = weekend_list
        self.holiday_list = holiday_list

class TimeUnit(enum.Enum):
    WEEK = "W"
    DAY = "D"
    HOUR = "h"
    MINUTE = "m"
    SECOND = "s"

class _MeasureDefinition():
    def __init__(self):
        super().__init__()
        self.id = None

class CountMeasure(_MeasureDefinition):
    """Measure to calc how many times a condition happened.
    
    Args:    
            - when: Condition that you want to count
    """

    def __init__(self, when: str | TimeInstantCondition | DataCondition | SeriesCondition):
        super().__init__()
        self.when = _time_instance_auto_wrap(when)
    
    def __repr__(self):
        return f"CountMeasure ( {self.when} )"

    def __str__(self):
        return f"the number of times {self.when}"

class DataMeasure(_MeasureDefinition):
    """Measure that returns a data from specific filter.
    
    Args:
            - data_content_selection: Column you want to select
            - precondition: Condition (Time Instance Condition by default) to apply to data
            - first: True if you want to select first data, False if you want to select last
    """
    
    def __init__(self, 
                 data_content_selection: str, 
                 precondition: TimeInstantCondition | DataCondition | SeriesCondition | None=None, 
                 first: bool=False):
        super().__init__()
       
        self.data_content_selection = data_content_selection
        self.precondition = _time_instance_auto_wrap(precondition)
        self.first = first

    def __str__(self):
        first_text = "first" if self.first else "last"
        precondition_text = f" when {self.precondition}" if self.precondition is not None else ""
        selection_text = _name_of_data_selection(self.data_content_selection)
        return f"the {first_text} value of {selection_text}{precondition_text}"

class TimeMeasure(_MeasureDefinition):
    """Measure to calc the time elapsed between A condition and B condition.
    
    Args:    
        - from_condition: Condition where you want to start counting, defined as A
        - to_condition: End condition, defined as B
        - time_measure_type: Linear in case just want a simple A-B calc, Cyclic in case you want to count 
            all pairs A-B appearances
        - single_instance_agg_function: Only in Cyclic mode. Type of operation applied to our dataset, 
            can be MAX, MIN, SUM, AVG, MEDIAN or PXX (where XX is 1..99). 
        - first_to: Only in Linear mode. True to take first appareance of B, false to take last appareance of B
        - precondition: Filter to previusly apply to our dataset. Note that, in this case, this precondition
                        is not a time instant condition, but a data condition (i.e., it is directly checked with
                        the values of the attributes of each event)
        - business_duration: Business days and hours specification
        - time_unit: The time unit used to return the value.
    """

    def __init__(self, 
                 from_condition: TimeInstantCondition | DataCondition | SeriesCondition, 
                 to_condition: TimeInstantCondition | DataCondition | SeriesCondition, 
                 time_measure_type: str = 'LINEAR', 
                 single_instance_agg_function: str = 'SUM', 
                 first_to: bool=False,
                 precondition: str | None = None, 
                 business_duration: BusinessDuration | None = None, 
                 time_unit: TimeUnit | None = None):
        super().__init__()
  
        self.from_condition = _time_instance_auto_wrap(from_condition)
        self.to_condition = _time_instance_auto_wrap(to_condition)
        self.time_measure_type = time_measure_type
        self.single_instance_agg_function = single_instance_agg_function
        self.precondition = precondition
        self.first_to = first_to
        self.business_duration = business_duration
        self.time_unit = time_unit
        
    def __repr__(self):
        return f"TimeMeasure ( from={self.from_condition}, to={self.to_condition} )"

    def __str__(self):
        precon_text = f" if {self.precondition}" if self.precondition is not None else ""
        first_to_text = "first" if self.first_to else "last"
        duration_text = "business duration" if self.business_duration is not None else "duration"

        if self.time_measure_type.upper() == 'LINEAR':
            text = f"the {duration_text} between the first time instant when {self.from_condition} and the {first_to_text} time instant when {self.to_condition}{precon_text}"
        else:
            agg_text = _name_of_aggregation(self.single_instance_agg_function)
            text = f"the {agg_text} {duration_text} between the pairs of time instants when {self.from_condition} and when {self.to_condition}{precon_text}"
        return text


class AggregatedMeasure(_MeasureDefinition):
    """Measure to group a dataset by certain time interval.
    
    Args:
    
            - base_measure: Measure that is being aggregated.
            - single_instance_agg_function: Type of operation applied to our dataset, 
                can be MAX, MIN, SUM, AVG, MEDIAN, PXX (where XX is 1..99) or GROUPBY.
            - grouper: Array of measures for grouping.
            - filter_to_apply: Measure applied to the dataset to filter specific cases. The measure
                               must resolve to either true or false for each case.
    """
    def __init__(self, base_measure, single_instance_agg_function, grouper=None, filter_to_apply=None):
        super().__init__()
  
        self.base_measure = base_measure
        self.filter_to_apply = filter_to_apply
        self.single_instance_agg_function = single_instance_agg_function
        if grouper is None:
            self.grouper = []
        elif isinstance(grouper, _MeasureDefinition):
            self.grouper = [grouper]
        else:
            self.grouper = grouper

    def __str__(self):
        result =  f"the {_name_of_aggregation(self.single_instance_agg_function)} of {self.base_measure}"
        if len(self.grouper) > 0:
            grouper_text = ", ".join([f"{g}" for g in self.grouper])
            result = f"{result} grouped by {grouper_text}"
        if self.filter_to_apply is not None:
            result = f"{result} filtered by {self.filter_to_apply}"

        return result
        
 
class DerivedMeasure(_MeasureDefinition):
    """Measure that applies an operation to a group of measures.
    
    Args:
    
            - function_expression: Aritmathical or logical expresion as String
            - measure_map: Map of {name_of_measure: Measure}
    """
    
    def __init__(self, function_expression, measure_map):
        super().__init__()
      
        self.function_expression = function_expression
        self.measure_map = measure_map

    def __str__(self):
        variables = ", ".join([f"{m} is {self.measure_map[m]}" for m in self.measure_map])

        return f"the function {self.function_expression} where {variables}"

class RollingWindow():
    """Window applied to the data to group with a moving window.
    
    Args:
        - window: Size of the moving window, could be a number or a time expression ('7D'). If it is a number, then apply_to_cases must be true.
        - apply_to_cases: Returns the moving window for each case instead of based on the window frequency.
        - min_period: Minimum number of observations in window required to have a value 
        - closed: Make the interval closed on the ‘right’, ‘left’, ‘both’ or ‘neither’ endpoints.
    """
    def __init__(self, window, apply_to_cases=False, min_period=None, closed=None):
        if (isinstance(window, int) or (isinstance(window,float) and window.is_integer())) and not apply_to_cases:
            raise ValueError('If window is an integer, apply_to_cases must be True')

        self.window = window
        self.apply_to_cases = apply_to_cases
        self.min_period = min_period
        self.closed = closed



 
        
