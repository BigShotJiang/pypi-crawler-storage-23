"""Tests for PEP 594 dead batteries migration recipes."""

from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.cgi_migrations import (
    FindCgiModule,
    FindCgitbModule,
)
from openrewrite_migrate_python.migrate.telnetlib_migrations import FindTelnetlibModule
from openrewrite_migrate_python.migrate.nntplib_migrations import FindNntplibModule
from openrewrite_migrate_python.migrate.pipes_migrations import FindPipesModule
from openrewrite_migrate_python.migrate.uu_migrations import FindUuModule


class TestFindCgiModule:
    """Tests for the FindCgiModule recipe."""

    def test_finds_import_cgi(self):
        spec = RecipeSpec(recipe=FindCgiModule())
        spec.rewrite_run(
            python(
                "import cgi",
                "/*~~(The `cgi` module was removed in Python 3.13. Use urllib.parse for query parsing, html.escape() for escaping.)~~>*/import cgi",
            )
        )

    def test_no_change_when_no_cgi(self):
        spec = RecipeSpec(recipe=FindCgiModule())
        spec.rewrite_run(
            python("import urllib.parse")
        )


class TestFindCgitbModule:
    """Tests for the FindCgitbModule recipe."""

    def test_finds_import_cgitb(self):
        spec = RecipeSpec(recipe=FindCgitbModule())
        spec.rewrite_run(
            python(
                "import cgitb",
                "/*~~(The `cgitb` module was removed in Python 3.13. Use logging and traceback modules instead.)~~>*/import cgitb",
            )
        )

    def test_no_change_when_no_cgitb(self):
        spec = RecipeSpec(recipe=FindCgitbModule())
        spec.rewrite_run(
            python("import logging")
        )


class TestFindTelnetlibModule:
    """Tests for the FindTelnetlibModule recipe."""

    def test_finds_import_telnetlib(self):
        spec = RecipeSpec(recipe=FindTelnetlibModule())
        spec.rewrite_run(
            python(
                "import telnetlib",
                "/*~~(The `telnetlib` module was removed in Python 3.13. Consider using telnetlib3 from PyPI or SSH alternatives.)~~>*/import telnetlib",
            )
        )

    def test_no_change_when_no_telnetlib(self):
        spec = RecipeSpec(recipe=FindTelnetlibModule())
        spec.rewrite_run(
            python("import socket")
        )


class TestFindNntplibModule:
    """Tests for the FindNntplibModule recipe."""

    def test_finds_import_nntplib(self):
        spec = RecipeSpec(recipe=FindNntplibModule())
        spec.rewrite_run(
            python(
                "import nntplib",
                "/*~~(The `nntplib` module was removed in Python 3.13. NNTP is largely obsolete.)~~>*/import nntplib",
            )
        )

    def test_no_change_when_no_nntplib(self):
        spec = RecipeSpec(recipe=FindNntplibModule())
        spec.rewrite_run(
            python("import http.client")
        )


class TestFindPipesModule:
    """Tests for the FindPipesModule recipe."""

    def test_finds_import_pipes(self):
        spec = RecipeSpec(recipe=FindPipesModule())
        spec.rewrite_run(
            python(
                "import pipes",
                "/*~~(The `pipes` module was removed in Python 3.13. Use subprocess with shlex.quote() instead.)~~>*/import pipes",
            )
        )

    def test_no_change_when_no_pipes(self):
        spec = RecipeSpec(recipe=FindPipesModule())
        spec.rewrite_run(
            python("import subprocess")
        )


class TestFindUuModule:
    """Tests for the FindUuModule recipe."""

    def test_finds_import_uu(self):
        spec = RecipeSpec(recipe=FindUuModule())
        spec.rewrite_run(
            python(
                "import uu",
                "/*~~(The `uu` module was removed in Python 3.13. Use the base64 module instead.)~~>*/import uu",
            )
        )

    def test_no_change_when_no_uu(self):
        spec = RecipeSpec(recipe=FindUuModule())
        spec.rewrite_run(
            python("import base64")
        )
