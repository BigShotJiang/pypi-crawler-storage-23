"""Tests for locale.getdefaultlocale() deprecation recipe."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.locale_getdefaultlocale_deprecation import (
    FindLocaleGetdefaultlocale,
)


class TestFindLocaleGetdefaultlocale:
    """Tests for FindLocaleGetdefaultlocale recipe."""

    def test_finds_locale_getdefaultlocale(self):
        spec = RecipeSpec(recipe=FindLocaleGetdefaultlocale())
        spec.rewrite_run(
            python(
                "lang, enc = locale.getdefaultlocale()",
                "lang, enc = /*~~(locale.getdefaultlocale() was deprecated in Python 3.11. Use locale.setlocale(), locale.getlocale(), or locale.getpreferredencoding(False) instead.)~~>*/locale.getdefaultlocale()",
            )
        )

    def test_no_change_when_using_getlocale(self):
        spec = RecipeSpec(recipe=FindLocaleGetdefaultlocale())
        spec.rewrite_run(
            python("lang, enc = locale.getlocale()")
        )
