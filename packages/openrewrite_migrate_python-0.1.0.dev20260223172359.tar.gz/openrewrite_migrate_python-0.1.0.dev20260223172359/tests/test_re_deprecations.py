"""Tests for re.template() / re.TEMPLATE deprecation recipe."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.re_deprecations import FindReTemplate


class TestFindReTemplate:
    """Tests for FindReTemplate recipe."""

    def test_finds_re_template_call(self):
        spec = RecipeSpec(recipe=FindReTemplate())
        spec.rewrite_run(
            python(
                "pattern = re.template(r'\\d+')",
                "pattern = /*~~(re.template() was deprecated in Python 3.11 and removed in 3.13.)~~>*/re.template(r'\\d+')",
            )
        )

    def test_finds_re_TEMPLATE_constant(self):
        spec = RecipeSpec(recipe=FindReTemplate())
        spec.rewrite_run(
            python(
                "flags = re.TEMPLATE",
                "flags = /*~~(re.TEMPLATE was deprecated in Python 3.11 and removed in 3.13.)~~>*/re.TEMPLATE",
            )
        )

    def test_no_change_when_using_compile(self):
        spec = RecipeSpec(recipe=FindReTemplate())
        spec.rewrite_run(
            python("pattern = re.compile(r'\\d+')")
        )
