"""Tests for AST deprecation migration recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.ast_deprecations import (
    ReplaceAstNum,
    ReplaceAstStr,
    ReplaceAstBytes,
    ReplaceAstNameConstant,
    ReplaceAstEllipsis,
)


@pytest.mark.requires_dev_openrewrite
class TestReplaceAstNum:
    """Tests for the ReplaceAstNum recipe."""

    def test_replaces_ast_num(self):
        """Test that ast.Num is replaced with ast.Constant."""
        spec = RecipeSpec(recipe=ReplaceAstNum())
        spec.rewrite_run(
            python(
                """
                import ast
                if isinstance(node, ast.Num):
                    pass
                """,
                """
                import ast
                if isinstance(node, ast.Constant):
                    pass
                """,
            )
        )

    def test_no_change_when_ast_constant(self):
        """Test that ast.Constant is not modified."""
        spec = RecipeSpec(recipe=ReplaceAstNum())
        spec.rewrite_run(
            python(
                """
                import ast
                if isinstance(node, ast.Constant):
                    pass
                """
            )
        )

    def test_replaces_in_assignment(self):
        """Test replacement in assignment context."""
        spec = RecipeSpec(recipe=ReplaceAstNum())
        spec.rewrite_run(
            python(
                """
                import ast
                x = ast.Num
                """,
                """
                import ast
                x = ast.Constant
                """,
            )
        )


@pytest.mark.requires_dev_openrewrite
class TestReplaceAstStr:
    """Tests for the ReplaceAstStr recipe."""

    def test_replaces_ast_str(self):
        """Test that ast.Str is replaced with ast.Constant."""
        spec = RecipeSpec(recipe=ReplaceAstStr())
        spec.rewrite_run(
            python(
                """
                import ast
                if isinstance(node, ast.Str):
                    pass
                """,
                """
                import ast
                if isinstance(node, ast.Constant):
                    pass
                """,
            )
        )


@pytest.mark.requires_dev_openrewrite
class TestReplaceAstBytes:
    """Tests for the ReplaceAstBytes recipe."""

    def test_replaces_ast_bytes(self):
        """Test that ast.Bytes is replaced with ast.Constant."""
        spec = RecipeSpec(recipe=ReplaceAstBytes())
        spec.rewrite_run(
            python(
                """
                import ast
                if isinstance(node, ast.Bytes):
                    pass
                """,
                """
                import ast
                if isinstance(node, ast.Constant):
                    pass
                """,
            )
        )


@pytest.mark.requires_dev_openrewrite
class TestReplaceAstNameConstant:
    """Tests for the ReplaceAstNameConstant recipe."""

    def test_replaces_ast_nameconstant(self):
        """Test that ast.NameConstant is replaced with ast.Constant."""
        spec = RecipeSpec(recipe=ReplaceAstNameConstant())
        spec.rewrite_run(
            python(
                """
                import ast
                if isinstance(node, ast.NameConstant):
                    pass
                """,
                """
                import ast
                if isinstance(node, ast.Constant):
                    pass
                """,
            )
        )


@pytest.mark.requires_dev_openrewrite
class TestReplaceAstEllipsis:
    """Tests for the ReplaceAstEllipsis recipe."""

    def test_replaces_ast_ellipsis(self):
        """Test that ast.Ellipsis is replaced with ast.Constant."""
        spec = RecipeSpec(recipe=ReplaceAstEllipsis())
        spec.rewrite_run(
            python(
                """
                import ast
                if isinstance(node, ast.Ellipsis):
                    pass
                """,
                """
                import ast
                if isinstance(node, ast.Constant):
                    pass
                """,
            )
        )
