"""Tests for shutil.rmtree(onerror=) deprecation recipe."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.shutil_deprecations import (
    FindShutilRmtreeOnerror,
)


class TestFindShutilRmtreeOnerror:
    """Tests for FindShutilRmtreeOnerror recipe."""

    def test_finds_rmtree_with_three_args(self):
        spec = RecipeSpec(recipe=FindShutilRmtreeOnerror())
        spec.rewrite_run(
            python(
                "shutil.rmtree(path, True, handler)",
                "/*~~(shutil.rmtree() `onerror` parameter was deprecated in Python 3.12. Use `onexc` instead. Note: the callback signature differs.)~~>*/shutil.rmtree(path, True, handler)",
            )
        )

    def test_no_change_when_simple_rmtree(self):
        spec = RecipeSpec(recipe=FindShutilRmtreeOnerror())
        spec.rewrite_run(
            python("shutil.rmtree(path)")
        )
