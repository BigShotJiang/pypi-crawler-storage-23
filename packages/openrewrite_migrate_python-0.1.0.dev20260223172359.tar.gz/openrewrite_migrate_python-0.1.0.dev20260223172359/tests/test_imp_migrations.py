"""Tests for imp module deprecation migration recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.imp_migrations import (
    FindImpUsage,
)


class TestFindImpUsage:
    """Tests for the FindImpUsage recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_import_imp(self):
        """Test that 'import imp' is found and marked."""
        spec = RecipeSpec(recipe=FindImpUsage())
        spec.rewrite_run(
            python(
                """
                import imp
                """,
                """
                /*~~(imp module is deprecated: Migrate to importlib (removed in Python 3.12))~~>*/import imp
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_finds_from_imp_import_reload(self):
        """Test that 'from imp import reload' is found and marked."""
        spec = RecipeSpec(recipe=FindImpUsage())
        spec.rewrite_run(
            python(
                """
                from imp import reload
                """,
                """
                /*~~(imp module is deprecated: Migrate to importlib (removed in Python 3.12))~~>*/from imp import reload
                """,
            )
        )

    def test_no_change_when_importlib(self):
        """Test that importlib imports are not marked."""
        spec = RecipeSpec(recipe=FindImpUsage())
        spec.rewrite_run(
            python(
                """
                import importlib
                from importlib import reload
                """
            )
        )

    def test_no_change_when_other_imports(self):
        """Test that unrelated imports are not marked."""
        spec = RecipeSpec(recipe=FindImpUsage())
        spec.rewrite_run(
            python(
                """
                import os
                from typing import List
                import simple
                """
            )
        )
