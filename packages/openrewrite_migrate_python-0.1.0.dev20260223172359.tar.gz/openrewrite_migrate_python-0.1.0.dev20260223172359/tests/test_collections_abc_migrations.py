"""Tests for collections.abc migration recipe."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.collections_abc_migrations import (
    ReplaceCollectionsAbcImports,
)


class TestReplaceCollectionsAbcImports:
    """Tests for the ReplaceCollectionsAbcImports recipe."""

    def test_replaces_callable_import(self):
        """Test that from collections import Callable is migrated."""
        spec = RecipeSpec(recipe=ReplaceCollectionsAbcImports())
        spec.rewrite_run(
            python(
                """
                from collections import Callable
                """,
                """
                from collections.abc import Callable
                """,
            )
        )

    def test_replaces_multiple_abc_imports(self):
        """Test that multiple ABC class imports are migrated."""
        spec = RecipeSpec(recipe=ReplaceCollectionsAbcImports())
        spec.rewrite_run(
            python(
                """
                from collections import Callable, Mapping, Sequence
                """,
                """
                from collections.abc import Callable, Mapping, Sequence
                """,
            )
        )

    def test_replaces_iterable_import(self):
        """Test that from collections import Iterable is migrated."""
        spec = RecipeSpec(recipe=ReplaceCollectionsAbcImports())
        spec.rewrite_run(
            python(
                """
                from collections import Iterable
                """,
                """
                from collections.abc import Iterable
                """,
            )
        )

    def test_replaces_iterator_import(self):
        """Test that from collections import Iterator is migrated."""
        spec = RecipeSpec(recipe=ReplaceCollectionsAbcImports())
        spec.rewrite_run(
            python(
                """
                from collections import Iterator
                """,
                """
                from collections.abc import Iterator
                """,
            )
        )

    def test_replaces_mapping_import(self):
        """Test that from collections import Mapping is migrated."""
        spec = RecipeSpec(recipe=ReplaceCollectionsAbcImports())
        spec.rewrite_run(
            python(
                """
                from collections import Mapping
                """,
                """
                from collections.abc import Mapping
                """,
            )
        )

    def test_replaces_mutable_mapping_import(self):
        """Test that from collections import MutableMapping is migrated."""
        spec = RecipeSpec(recipe=ReplaceCollectionsAbcImports())
        spec.rewrite_run(
            python(
                """
                from collections import MutableMapping
                """,
                """
                from collections.abc import MutableMapping
                """,
            )
        )

    def test_replaces_sequence_import(self):
        """Test that from collections import Sequence is migrated."""
        spec = RecipeSpec(recipe=ReplaceCollectionsAbcImports())
        spec.rewrite_run(
            python(
                """
                from collections import Sequence
                """,
                """
                from collections.abc import Sequence
                """,
            )
        )

    def test_replaces_set_import(self):
        """Test that from collections import Set is migrated."""
        spec = RecipeSpec(recipe=ReplaceCollectionsAbcImports())
        spec.rewrite_run(
            python(
                """
                from collections import Set
                """,
                """
                from collections.abc import Set
                """,
            )
        )

    def test_no_change_when_collections_abc(self):
        """Test that from collections.abc import ... is not modified."""
        spec = RecipeSpec(recipe=ReplaceCollectionsAbcImports())
        spec.rewrite_run(
            python(
                """
                from collections.abc import Callable
                """
            )
        )

    def test_no_change_when_non_abc_imports(self):
        """Test that non-ABC collections imports are not modified."""
        spec = RecipeSpec(recipe=ReplaceCollectionsAbcImports())
        spec.rewrite_run(
            python(
                """
                from collections import defaultdict, OrderedDict
                """
            )
        )

    def test_no_change_when_other_module(self):
        """Test that imports from other modules are not modified."""
        spec = RecipeSpec(recipe=ReplaceCollectionsAbcImports())
        spec.rewrite_run(
            python(
                """
                from typing import Callable
                """
            )
        )

    def test_no_change_for_plain_import(self):
        """Test that 'import collections' is not modified."""
        spec = RecipeSpec(recipe=ReplaceCollectionsAbcImports())
        spec.rewrite_run(
            python(
                """
                import collections
                """
            )
        )
