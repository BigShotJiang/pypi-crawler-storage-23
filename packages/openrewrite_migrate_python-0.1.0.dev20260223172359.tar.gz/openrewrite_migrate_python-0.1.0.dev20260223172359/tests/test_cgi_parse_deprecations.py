"""Tests for cgi parse function deprecation migration recipes."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.cgi_parse_deprecations import (
    FindCgiParseQs,
    FindCgiParseQsl,
)


class TestFindCgiParseQs:
    """Tests for FindCgiParseQs recipe."""

    def test_finds_cgi_parse_qs(self):
        spec = RecipeSpec(recipe=FindCgiParseQs())
        spec.rewrite_run(
            python(
                "params = cgi.parse_qs(query)",
                "params = /*~~(cgi.parse_qs() was removed in Python 3.8. Use urllib.parse.parse_qs() instead.)~~>*/cgi.parse_qs(query)",
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=FindCgiParseQs())
        spec.rewrite_run(
            python("params = other.parse_qs(query)")
        )


class TestFindCgiParseQsl:
    """Tests for FindCgiParseQsl recipe."""

    def test_finds_cgi_parse_qsl(self):
        spec = RecipeSpec(recipe=FindCgiParseQsl())
        spec.rewrite_run(
            python(
                "params = cgi.parse_qsl(query)",
                "params = /*~~(cgi.parse_qsl() was removed in Python 3.8. Use urllib.parse.parse_qsl() instead.)~~>*/cgi.parse_qsl(query)",
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=FindCgiParseQsl())
        spec.rewrite_run(
            python("params = other.parse_qsl(query)")
        )
