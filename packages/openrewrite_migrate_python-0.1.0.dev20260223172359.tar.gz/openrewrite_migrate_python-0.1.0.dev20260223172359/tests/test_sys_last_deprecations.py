"""Tests for sys.last_type/value/traceback deprecation recipe."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.sys_last_deprecations import (
    FindSysLastExcInfo,
)


class TestFindSysLastExcInfo:
    """Tests for FindSysLastExcInfo recipe."""

    def test_finds_sys_last_type(self):
        spec = RecipeSpec(recipe=FindSysLastExcInfo())
        spec.rewrite_run(
            python(
                "t = sys.last_type",
                "t = /*~~(sys.last_type was deprecated in Python 3.12. Use sys.last_exc instead.)~~>*/sys.last_type",
            )
        )

    def test_finds_sys_last_value(self):
        spec = RecipeSpec(recipe=FindSysLastExcInfo())
        spec.rewrite_run(
            python(
                "v = sys.last_value",
                "v = /*~~(sys.last_value was deprecated in Python 3.12. Use sys.last_exc instead.)~~>*/sys.last_value",
            )
        )

    def test_no_change_when_using_last_exc(self):
        spec = RecipeSpec(recipe=FindSysLastExcInfo())
        spec.rewrite_run(
            python("exc = sys.last_exc")
        )
