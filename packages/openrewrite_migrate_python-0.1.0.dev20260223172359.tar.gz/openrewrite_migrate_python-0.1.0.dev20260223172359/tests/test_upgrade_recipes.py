"""Tests for composite upgrade recipes."""

import pytest
from openrewrite_migrate_python.migrate import (
    UpgradeToPython38,
    UpgradeToPython39,
    UpgradeToPython310,
    UpgradeToPython311,
    UpgradeToPython312,
    UpgradeToPython313,
    UpgradeToPython314,
)


class TestUpgradeRecipeChaining:
    """Tests for verifying upgrade recipe chaining."""

    def test_upgrade_to_python39_includes_python38(self):
        """Test that UpgradeToPython39 chains to UpgradeToPython38."""
        recipe = UpgradeToPython39()
        recipe_list = recipe.recipe_list()
        recipe_names = [r.name for r in recipe_list]
        assert "org.openrewrite.python.migrate.UpgradeToPython38" in recipe_names

    def test_upgrade_to_python310_includes_python39(self):
        """Test that UpgradeToPython310 chains to UpgradeToPython39."""
        recipe = UpgradeToPython310()
        recipe_list = recipe.recipe_list()
        recipe_names = [r.name for r in recipe_list]
        assert "org.openrewrite.python.migrate.UpgradeToPython39" in recipe_names

    def test_upgrade_to_python311_includes_python310(self):
        """Test that UpgradeToPython311 chains to UpgradeToPython310."""
        recipe = UpgradeToPython311()
        recipe_list = recipe.recipe_list()
        recipe_names = [r.name for r in recipe_list]
        assert "org.openrewrite.python.migrate.UpgradeToPython310" in recipe_names

    def test_upgrade_to_python312_includes_python311(self):
        """Test that UpgradeToPython312 chains to UpgradeToPython311."""
        recipe = UpgradeToPython312()
        recipe_list = recipe.recipe_list()
        recipe_names = [r.name for r in recipe_list]
        assert "org.openrewrite.python.migrate.UpgradeToPython311" in recipe_names

    def test_upgrade_to_python313_includes_python312(self):
        """Test that UpgradeToPython313 chains to UpgradeToPython312."""
        recipe = UpgradeToPython313()
        recipe_list = recipe.recipe_list()
        recipe_names = [r.name for r in recipe_list]
        assert "org.openrewrite.python.migrate.UpgradeToPython312" in recipe_names

    def test_upgrade_to_python314_includes_python313(self):
        """Test that UpgradeToPython314 chains to UpgradeToPython313."""
        recipe = UpgradeToPython314()
        recipe_list = recipe.recipe_list()
        recipe_names = [r.name for r in recipe_list]
        assert "org.openrewrite.python.migrate.UpgradeToPython313" in recipe_names

    def test_upgrade_to_python314_full_chain(self):
        """Test that UpgradeToPython314 eventually includes all previous versions."""
        # Recursively collect all recipe names
        def collect_recipe_names(recipe, collected=None):
            if collected is None:
                collected = set()
            collected.add(recipe.name)
            if hasattr(recipe, 'recipe_list'):
                for sub_recipe in recipe.recipe_list():
                    collect_recipe_names(sub_recipe, collected)
            return collected

        recipe = UpgradeToPython314()
        all_names = collect_recipe_names(recipe)

        # Should include all upgrade recipes in the chain
        assert "org.openrewrite.python.migrate.UpgradeToPython314" in all_names
        assert "org.openrewrite.python.migrate.UpgradeToPython313" in all_names
        assert "org.openrewrite.python.migrate.UpgradeToPython312" in all_names
        assert "org.openrewrite.python.migrate.UpgradeToPython311" in all_names
        assert "org.openrewrite.python.migrate.UpgradeToPython310" in all_names
        assert "org.openrewrite.python.migrate.UpgradeToPython39" in all_names
        assert "org.openrewrite.python.migrate.UpgradeToPython38" in all_names


class TestUpgradeRecipeMetadata:
    """Tests for upgrade recipe metadata."""

    def test_upgrade_to_python38_metadata(self):
        """Test UpgradeToPython38 has correct metadata."""
        recipe = UpgradeToPython38()
        assert recipe.name == "org.openrewrite.python.migrate.UpgradeToPython38"
        assert recipe.display_name == "Upgrade to Python 3.8"
        assert "3.8" in recipe.tags

    def test_upgrade_to_python39_metadata(self):
        """Test UpgradeToPython39 has correct metadata."""
        recipe = UpgradeToPython39()
        assert recipe.name == "org.openrewrite.python.migrate.UpgradeToPython39"
        assert recipe.display_name == "Upgrade to Python 3.9"
        assert "3.9" in recipe.tags

    def test_upgrade_to_python310_metadata(self):
        """Test UpgradeToPython310 has correct metadata."""
        recipe = UpgradeToPython310()
        assert recipe.name == "org.openrewrite.python.migrate.UpgradeToPython310"
        assert recipe.display_name == "Upgrade to Python 3.10"
        assert "3.10" in recipe.tags

    def test_upgrade_to_python311_metadata(self):
        """Test UpgradeToPython311 has correct metadata."""
        recipe = UpgradeToPython311()
        assert recipe.name == "org.openrewrite.python.migrate.UpgradeToPython311"
        assert recipe.display_name == "Upgrade to Python 3.11"
        assert "3.11" in recipe.tags

    def test_upgrade_to_python312_metadata(self):
        """Test UpgradeToPython312 has correct metadata."""
        recipe = UpgradeToPython312()
        assert recipe.name == "org.openrewrite.python.migrate.UpgradeToPython312"
        assert recipe.display_name == "Upgrade to Python 3.12"
        assert "3.12" in recipe.tags

    def test_upgrade_to_python313_metadata(self):
        """Test UpgradeToPython313 has correct metadata."""
        recipe = UpgradeToPython313()
        assert recipe.name == "org.openrewrite.python.migrate.UpgradeToPython313"
        assert recipe.display_name == "Upgrade to Python 3.13"
        assert "3.13" in recipe.tags

    def test_upgrade_to_python314_metadata(self):
        """Test UpgradeToPython314 has correct metadata."""
        recipe = UpgradeToPython314()
        assert recipe.name == "org.openrewrite.python.migrate.UpgradeToPython314"
        assert recipe.display_name == "Upgrade to Python 3.14"
        assert "3.14" in recipe.tags
