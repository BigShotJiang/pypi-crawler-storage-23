"""Composite recipe for upgrading from Python 3.12 to Python 3.13."""

from typing import List

from rewrite import Recipe
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python

# Define category path: Python > Migrate
_Migrate = [*Python, CategoryDescriptor(display_name="Migrate")]


@categorize(_Migrate)
class UpgradeToPython313(Recipe):
    """
    Migrate deprecated and removed APIs for Python 3.13 compatibility.

    This composite recipe applies all necessary migrations for code
    running on Python 3.12 to be compatible with Python 3.13.

    Key changes in Python 3.13 (PEP 594 "dead batteries" removals):
    - `cgi` and `cgitb` modules removed
    - `telnetlib` module removed
    - `nntplib` module removed
    - `pipes` module removed
    - `uu` module removed
    - Many other legacy modules removed (aifc, audioop, chunk, crypt,
      imghdr, mailcap, msilib, nis, ossaudiodev, sndhdr, spwd, sunau, xdrlib)
    - `configparser.readfp()` removed (deprecated since 3.2)

    See: https://docs.python.org/3/whatsnew/3.13.html
    See: https://peps.python.org/pep-0594/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.UpgradeToPython313"

    @property
    def display_name(self) -> str:
        return "Upgrade to Python 3.13"

    @property
    def description(self) -> str:
        return (
            "Migrate deprecated and removed APIs for Python 3.13 compatibility. "
            "This includes detecting usage of modules removed in PEP 594 "
            "('dead batteries') and other API changes between Python 3.12 and 3.13."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.13"]

    def recipe_list(self) -> List[Recipe]:
        """Return the list of recipes to apply for Python 3.13 upgrade."""
        # Import here to avoid circular imports
        from .aifc_migrations import (
            FindAifcModule,
            FindAudioopModule,
            FindChunkModule,
            FindImghdrModule,
            FindSndhdrModule,
            FindSunauModule,
        )
        from .cgi_migrations import FindCgiModule, FindCgitbModule
        from .locale_deprecations import ReplaceLocaleResetlocale
        from .mailcap_migrations import FindMailcapModule
        from .nntplib_migrations import FindNntplibModule
        from .pep594_system_migrations import (
            FindCryptModule,
            FindMsilibModule,
            FindNisModule,
            FindOssaudiodevModule,
            FindSpwdModule,
        )
        from .pipes_migrations import FindPipesModule
        from .telnetlib_migrations import FindTelnetlibModule
        from .upgrade_to_python312 import UpgradeToPython312
        from .uu_migrations import FindUuModule
        from .xdrlib_migrations import FindXdrlibModule

        return [
            # First apply all Python 3.12 upgrades (which includes 3.11 and 3.10)
            UpgradeToPython312(),
            # locale.resetlocale() removed in 3.13 (deprecated in 3.11)
            ReplaceLocaleResetlocale(),
            # PEP 594 "dead batteries" - removed modules (detection only)
            FindAifcModule(),
            FindAudioopModule(),
            FindCgiModule(),
            FindCgitbModule(),
            FindChunkModule(),
            FindCryptModule(),
            FindImghdrModule(),
            FindMailcapModule(),
            FindMsilibModule(),
            FindNisModule(),
            FindNntplibModule(),
            FindOssaudiodevModule(),
            FindPipesModule(),
            FindSndhdrModule(),
            FindSpwdModule(),
            FindSunauModule(),
            FindTelnetlibModule(),
            FindUuModule(),
            FindXdrlibModule(),
        ]
