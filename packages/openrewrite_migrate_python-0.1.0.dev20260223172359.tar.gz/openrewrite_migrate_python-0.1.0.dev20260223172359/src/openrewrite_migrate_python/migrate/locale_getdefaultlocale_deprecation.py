"""
Recipe for finding deprecated locale.getdefaultlocale() usage.

locale.getdefaultlocale() was deprecated in Python 3.11 and will be
removed in Python 3.15.

See: https://docs.python.org/3/whatsnew/3.11.html#deprecated
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.11
_Python311 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.11"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python311)
class FindLocaleGetdefaultlocale(Recipe):
    """
    Find usages of deprecated `locale.getdefaultlocale()`.

    `locale.getdefaultlocale()` was deprecated in Python 3.11 and will be
    removed in Python 3.15. Use `locale.setlocale()`, `locale.getlocale()`,
    or `locale.getpreferredencoding(False)` instead.

    Example:
        Before:
            import locale
            lang, encoding = locale.getdefaultlocale()

        After:
            import locale
            locale.setlocale(locale.LC_ALL, '')
            lang, encoding = locale.getlocale()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindLocaleGetdefaultlocale"

    @property
    def display_name(self) -> str:
        return "Find deprecated `locale.getdefaultlocale()` usage"

    @property
    def description(self) -> str:
        return (
            "`locale.getdefaultlocale()` was deprecated in Python 3.11. "
            "Use `locale.setlocale()`, `locale.getlocale()`, or "
            "`locale.getpreferredencoding(False)` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.11", "locale"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "getdefaultlocale":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "locale":
                    return method

                return _mark_deprecated(
                    method,
                    "locale.getdefaultlocale() was deprecated in Python 3.11. "
                    "Use locale.setlocale(), locale.getlocale(), or "
                    "locale.getpreferredencoding(False) instead."
                )

        return Visitor()
