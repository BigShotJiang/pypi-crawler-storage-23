"""
Recipes for migrating deprecated asyncio module patterns.

The @asyncio.coroutine decorator was deprecated in Python 3.8 and removed in
Python 3.11. It should be replaced with async/await syntax:

    @asyncio.coroutine
    def my_func():
        yield from something()

becomes:

    async def my_func():
        await something()

See: https://docs.python.org/3/library/asyncio-task.html
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation, FieldAccess
from rewrite.utils import random_id

# Define category path: Python > Migrate > Python 3.11
_Python311 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.11"),
]


def _mark_deprecated(tree: Any, message: str, detail: Optional[str] = None) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    full_message = f"{message}: {detail}" if detail else message
    search_marker = SearchResult(random_id(), full_message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


def _is_asyncio_coroutine_access(node: Any) -> bool:
    """Check if this is an asyncio.coroutine access."""
    # Check for asyncio.coroutine pattern
    if isinstance(node, FieldAccess):
        name = node.name
        target = node.target
        if (isinstance(name, Identifier) and name.simple_name == "coroutine" and
            isinstance(target, Identifier) and target.simple_name == "asyncio"):
            return True
    return False


@categorize(_Python311)
class FindAsyncioCoroutineDecorator(Recipe):
    """
    Find usage of the deprecated @asyncio.coroutine decorator.

    The @asyncio.coroutine decorator was deprecated in Python 3.8 and removed
    in Python 3.11. Functions using this decorator should be converted to
    use `async def` syntax instead.

    Note: This recipe only finds usages. Manual migration is required because
    the transformation also involves changing `yield from` to `await`.

    Example migration:
        Before:
            @asyncio.coroutine
            def fetch_data():
                result = yield from get_data()
                return result

        After:
            async def fetch_data():
                result = await get_data()
                return result
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindAsyncioCoroutineDecorator"

    @property
    def display_name(self) -> str:
        return "Find deprecated `@asyncio.coroutine` decorator"

    @property
    def description(self) -> str:
        return (
            "Find usage of the deprecated `@asyncio.coroutine` decorator which was "
            "removed in Python 3.11. Convert to `async def` syntax with `await` "
            "instead of `yield from`."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_field_access(
                self, field_access: FieldAccess, p: ExecutionContext
            ) -> Optional[FieldAccess]:
                field_access = super().visit_field_access(field_access, p)

                if _is_asyncio_coroutine_access(field_access):
                    return _mark_deprecated(
                        field_access,
                        "@asyncio.coroutine is deprecated",
                        "Use 'async def' instead (removed in Python 3.11)"
                    )

                return field_access

        return Visitor()
