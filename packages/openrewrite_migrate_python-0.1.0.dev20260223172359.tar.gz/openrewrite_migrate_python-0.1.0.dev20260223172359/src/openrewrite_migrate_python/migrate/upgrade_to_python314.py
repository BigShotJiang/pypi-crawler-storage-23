"""Composite recipe for upgrading from Python 3.13 to Python 3.14."""

from typing import List

from rewrite import Recipe
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python

# Define category path: Python > Migrate
_Migrate = [*Python, CategoryDescriptor(display_name="Migrate")]


@categorize(_Migrate)
class UpgradeToPython314(Recipe):
    """
    Migrate deprecated and removed APIs for Python 3.14 compatibility.

    This composite recipe applies all necessary migrations for code
    running on Python 3.13 to be compatible with Python 3.14.

    Key changes in Python 3.14:
    - `ast.Num`, `ast.Str`, `ast.Bytes`, `ast.NameConstant`, `ast.Ellipsis`
      removed (deprecated since 3.8, use `ast.Constant` instead)
    - `array.tostring()` / `fromstring()` removed (use tobytes/frombytes)
    - `tempfile.mktemp()` removed (security issue, use mkstemp)
    - Various urllib.parse split functions removed

    See: https://docs.python.org/3/whatsnew/3.14.html
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.UpgradeToPython314"

    @property
    def display_name(self) -> str:
        return "Upgrade to Python 3.14"

    @property
    def description(self) -> str:
        return (
            "Migrate deprecated and removed APIs for Python 3.14 compatibility. "
            "This includes replacing deprecated AST node types with `ast.Constant` "
            "and other API changes between Python 3.13 and 3.14."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.14"]

    def recipe_list(self) -> List[Recipe]:
        """Return the list of recipes to apply for Python 3.14 upgrade."""
        # Import here to avoid circular imports
        from .array_deprecations import ReplaceArrayFromstring, ReplaceArrayTostring
        from .ast_deprecations import (
            ReplaceAstBytes,
            ReplaceAstEllipsis,
            ReplaceAstNameConstant,
            ReplaceAstNum,
            ReplaceAstStr,
        )
        from .tempfile_deprecations import FindTempfileMktemp
        from .upgrade_to_python313 import UpgradeToPython313
        from .urllib_deprecations import (
            FindUrllibParseSplitFunctions,
            FindUrllibParseToBytes,
        )

        return [
            # First apply all Python 3.13 upgrades (which includes 3.12, 3.11, 3.10)
            UpgradeToPython313(),
            # Array methods removed in 3.14 (deprecated since 3.2)
            ReplaceArrayTostring(),  # tostring() -> tobytes()
            ReplaceArrayFromstring(),  # fromstring() -> frombytes()
            # ast.Num, ast.Str, etc. removed in 3.14 (deprecated since 3.8)
            ReplaceAstNum(),
            ReplaceAstStr(),
            ReplaceAstBytes(),
            ReplaceAstNameConstant(),
            ReplaceAstEllipsis(),
            # tempfile.mktemp() removed (security issue)
            FindTempfileMktemp(),
            # urllib.parse split functions removed
            FindUrllibParseSplitFunctions(),
            FindUrllibParseToBytes(),
        ]
