"""
Recipes for migrating from deprecated system/platform modules (PEP 594).

The following modules were deprecated in Python 3.11 (PEP 594) and removed
in Python 3.13:
- crypt (use bcrypt, argon2-cffi, or passlib)
- msilib (Windows MSI support, no direct replacement)
- nis (NIS/YP support, no direct replacement)
- ossaudiodev (OSS audio, no direct replacement)
- spwd (shadow password database, no direct replacement)

See: https://peps.python.org/pep-0594/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport, Import
from rewrite.java.tree import Identifier, FieldAccess

# Define category path: Python > Migrate > Python 3.13
_Python313 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.13"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


def _get_import_name(import_node: Any) -> Optional[str]:
    """Extract the module name from an import node's qualid."""
    qualid = import_node.qualid
    if isinstance(qualid, FieldAccess):
        return qualid.name.simple_name
    if isinstance(qualid, Identifier):
        return qualid.simple_name
    return None


@categorize(_Python313)
class FindCryptModule(Recipe):
    """
    Find imports of the deprecated `crypt` module.

    The `crypt` module was deprecated in Python 3.11 and removed in
    Python 3.13 as part of PEP 594 ("Removing dead batteries").

    Alternatives:
    - Use `bcrypt` library for password hashing
    - Use `argon2-cffi` for Argon2 password hashing
    - Use `passlib` for a comprehensive password hashing framework

    See: https://peps.python.org/pep-0594/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindCryptModule"

    @property
    def display_name(self) -> str:
        return "Find deprecated `crypt` module usage"

    @property
    def description(self) -> str:
        return (
            "The `crypt` module was deprecated in Python 3.11 and removed in "
            "Python 3.13. Use `bcrypt`, `argon2-cffi`, or `passlib` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.13", "PEP 594"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == "crypt":
                        return _mark_deprecated(
                            multi,
                            "The `crypt` module was removed in Python 3.13. "
                            "Use `bcrypt`, `argon2-cffi`, or `passlib` instead."
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == "crypt":
                            return _mark_deprecated(
                                multi,
                                "The `crypt` module was removed in Python 3.13. "
                                "Use `bcrypt`, `argon2-cffi`, or `passlib` instead."
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == "crypt":
                    return _mark_deprecated(
                        import_stmt,
                        "The `crypt` module was removed in Python 3.13. "
                        "Use `bcrypt`, `argon2-cffi`, or `passlib` instead."
                    )
                return import_stmt

        return Visitor()


@categorize(_Python313)
class FindMsilibModule(Recipe):
    """
    Find imports of the deprecated `msilib` module.

    The `msilib` module was deprecated in Python 3.11 and removed in
    Python 3.13 as part of PEP 594 ("Removing dead batteries").

    This was a Windows-only module for creating MSI installer packages.

    See: https://peps.python.org/pep-0594/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindMsilibModule"

    @property
    def display_name(self) -> str:
        return "Find deprecated `msilib` module usage"

    @property
    def description(self) -> str:
        return (
            "The `msilib` module was deprecated in Python 3.11 and removed in "
            "Python 3.13. Use platform-specific tools for MSI creation."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.13", "PEP 594"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == "msilib":
                        return _mark_deprecated(
                            multi,
                            "The `msilib` module was removed in Python 3.13."
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == "msilib":
                            return _mark_deprecated(
                                multi,
                                "The `msilib` module was removed in Python 3.13."
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == "msilib":
                    return _mark_deprecated(
                        import_stmt,
                        "The `msilib` module was removed in Python 3.13."
                    )
                return import_stmt

        return Visitor()


@categorize(_Python313)
class FindNisModule(Recipe):
    """
    Find imports of the deprecated `nis` module.

    The `nis` module was deprecated in Python 3.11 and removed in
    Python 3.13 as part of PEP 594 ("Removing dead batteries").

    This module provided NIS (Network Information Service, formerly YP)
    support on Unix systems.

    See: https://peps.python.org/pep-0594/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindNisModule"

    @property
    def display_name(self) -> str:
        return "Find deprecated `nis` module usage"

    @property
    def description(self) -> str:
        return (
            "The `nis` module was deprecated in Python 3.11 and removed in "
            "Python 3.13. There is no direct replacement."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.13", "PEP 594"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == "nis":
                        return _mark_deprecated(
                            multi,
                            "The `nis` module was removed in Python 3.13."
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == "nis":
                            return _mark_deprecated(
                                multi,
                                "The `nis` module was removed in Python 3.13."
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == "nis":
                    return _mark_deprecated(
                        import_stmt,
                        "The `nis` module was removed in Python 3.13."
                    )
                return import_stmt

        return Visitor()


@categorize(_Python313)
class FindOssaudiodevModule(Recipe):
    """
    Find imports of the deprecated `ossaudiodev` module.

    The `ossaudiodev` module was deprecated in Python 3.11 and removed in
    Python 3.13 as part of PEP 594 ("Removing dead batteries").

    This module provided access to OSS (Open Sound System) audio devices
    on Linux and some other Unix systems.

    See: https://peps.python.org/pep-0594/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindOssaudiodevModule"

    @property
    def display_name(self) -> str:
        return "Find deprecated `ossaudiodev` module usage"

    @property
    def description(self) -> str:
        return (
            "The `ossaudiodev` module was deprecated in Python 3.11 and removed in "
            "Python 3.13. There is no direct replacement."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.13", "PEP 594"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == "ossaudiodev":
                        return _mark_deprecated(
                            multi,
                            "The `ossaudiodev` module was removed in Python 3.13."
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == "ossaudiodev":
                            return _mark_deprecated(
                                multi,
                                "The `ossaudiodev` module was removed in Python 3.13."
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == "ossaudiodev":
                    return _mark_deprecated(
                        import_stmt,
                        "The `ossaudiodev` module was removed in Python 3.13."
                    )
                return import_stmt

        return Visitor()


@categorize(_Python313)
class FindSpwdModule(Recipe):
    """
    Find imports of the deprecated `spwd` module.

    The `spwd` module was deprecated in Python 3.11 and removed in
    Python 3.13 as part of PEP 594 ("Removing dead batteries").

    This module provided access to the Unix shadow password database.

    See: https://peps.python.org/pep-0594/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindSpwdModule"

    @property
    def display_name(self) -> str:
        return "Find deprecated `spwd` module usage"

    @property
    def description(self) -> str:
        return (
            "The `spwd` module was deprecated in Python 3.11 and removed in "
            "Python 3.13. There is no direct replacement."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.13", "PEP 594"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == "spwd":
                        return _mark_deprecated(
                            multi,
                            "The `spwd` module was removed in Python 3.13."
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == "spwd":
                            return _mark_deprecated(
                                multi,
                                "The `spwd` module was removed in Python 3.13."
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == "spwd":
                    return _mark_deprecated(
                        import_stmt,
                        "The `spwd` module was removed in Python 3.13."
                    )
                return import_stmt

        return Visitor()
