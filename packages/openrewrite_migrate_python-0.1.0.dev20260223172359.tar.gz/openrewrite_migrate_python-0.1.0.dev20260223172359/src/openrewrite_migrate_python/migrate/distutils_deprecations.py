"""
Recipes for finding deprecated distutils module usage.

The distutils module was deprecated in Python 3.10 and removed in Python 3.12.
Users should migrate to setuptools or other build tools.

Common migrations:
- distutils.core.setup → setuptools.setup
- distutils.core.Extension → setuptools.Extension
- distutils.command.* → setuptools.command.*
- distutils.util.strtobool → Use a custom implementation

See: https://peps.python.org/pep-0632/
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport
from rewrite.utils import random_id

# Define category path: Python > Migrate > Python 3.12
_Python312 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.12"),
]


def _mark_deprecated(tree: Any, message: str, detail: Optional[str] = None) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    full_message = f"{message}: {detail}" if detail else message
    search_marker = SearchResult(random_id(), full_message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python312)
class FindDistutilsUsage(Recipe):
    """
    Find imports of the deprecated distutils module.

    The distutils module was deprecated in Python 3.10 (PEP 632) and removed
    in Python 3.12. Projects should migrate to setuptools or other modern
    build tools.

    Common migrations:
    - distutils.core.setup → setuptools.setup
    - distutils.core.Extension → setuptools.Extension
    - distutils.util.strtobool → custom implementation

    Note: This recipe only finds usages. Manual migration is required because
    the replacement depends on your specific use case.

    Example migration:
        Before:
            from distutils.core import setup, Extension

        After:
            from setuptools import setup, Extension
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindDistutilsUsage"

    @property
    def display_name(self) -> str:
        return "Find deprecated distutils module usage"

    @property
    def description(self) -> str:
        return (
            "Find imports of the deprecated `distutils` module which was removed "
            "in Python 3.12. Migrate to `setuptools` or other modern build tools."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                # Check the 'from' part for 'from distutils.* import ...'
                # e.g., 'from distutils.core import setup'
                from_part = multi.from_
                if from_part is not None:
                    # Get the string representation of the from part
                    from_str = from_part.print_all() if hasattr(from_part, 'print_all') else str(from_part)
                    if 'distutils' in from_str:
                        return _mark_deprecated(
                            multi,
                            "distutils is deprecated",
                            "Migrate to setuptools (removed in Python 3.12)"
                        )

                return multi

        return Visitor()
