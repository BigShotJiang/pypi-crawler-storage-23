"""
Recipes for migrating deprecated tarfile module attributes.

The following attribute was undocumented, deprecated since Python 3.3,
and removed in Python 3.8:
- tarfile.filemode

See: https://docs.python.org/3/whatsnew/3.8.html#api-and-feature-removals
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import FieldAccess, Identifier

# Define category path: Python > Migrate > Python 3.8
_Python38 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.8"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python38)
class FindTarfileFilemode(Recipe):
    """
    Find usages of removed `tarfile.filemode`.

    `tarfile.filemode` was undocumented, deprecated since Python 3.3,
    and removed in Python 3.8. Use `stat.filemode()` instead.

    Example:
        Before:
            import tarfile
            mode_str = tarfile.filemode(mode)

        After:
            import stat
            mode_str = stat.filemode(mode)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindTarfileFilemode"

    @property
    def display_name(self) -> str:
        return "Find removed `tarfile.filemode` usage"

    @property
    def description(self) -> str:
        return (
            "`tarfile.filemode` was removed in Python 3.8. "
            "Use `stat.filemode()` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.8", "tarfile"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(self, method, p: ExecutionContext):
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "filemode":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "tarfile":
                    return method

                return _mark_deprecated(
                    method,
                    "tarfile.filemode was removed in Python 3.8. "
                    "Use stat.filemode() instead."
                )

            def visit_field_access(
                self, field_access: FieldAccess, p: ExecutionContext
            ) -> Optional[FieldAccess]:
                field_access = super().visit_field_access(field_access, p)

                if not isinstance(field_access.name, Identifier):
                    return field_access
                if field_access.name.simple_name != "filemode":
                    return field_access

                target = field_access.target
                if not isinstance(target, Identifier):
                    return field_access
                if target.simple_name != "tarfile":
                    return field_access

                return _mark_deprecated(
                    field_access,
                    "tarfile.filemode was removed in Python 3.8. "
                    "Use stat.filemode() instead."
                )

        return Visitor()
