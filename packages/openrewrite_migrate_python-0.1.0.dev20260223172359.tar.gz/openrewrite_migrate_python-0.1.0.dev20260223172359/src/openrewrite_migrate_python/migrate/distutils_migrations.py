"""
Recipes for migrating deprecated distutils.version module to packaging.version.

The distutils module was deprecated in Python 3.10 and removed in Python 3.12.
The distutils.version module provided LooseVersion and StrictVersion classes
for version comparison.

Migration path:
- distutils.version.LooseVersion -> packaging.version.Version
- distutils.version.StrictVersion -> packaging.version.Version

Note: packaging.version.Version is not a drop-in replacement. It has stricter
parsing rules and different comparison semantics. Manual review is required
during migration.

See: https://peps.python.org/pep-0632/
See: https://packaging.pypa.io/en/stable/version.html
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport
from rewrite.utils import random_id

# Define category path: Python > Migrate > Python 3.12
_Python312 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.12"),
]


def _mark_deprecated(tree: Any, message: str, detail: Optional[str] = None) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    full_message = f"{message}: {detail}" if detail else message
    search_marker = SearchResult(random_id(), full_message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python312)
class ReplaceDistutilsVersion(Recipe):
    """
    Detect usage of deprecated distutils.version classes.

    The distutils module was deprecated in Python 3.10 (PEP 632) and removed
    in Python 3.12. The distutils.version module provided LooseVersion and
    StrictVersion classes for version parsing and comparison.

    Migration to packaging.version.Version:
    - distutils.version.LooseVersion -> packaging.version.Version
    - distutils.version.StrictVersion -> packaging.version.Version

    Important: packaging.version.Version is NOT a drop-in replacement.
    - LooseVersion was very permissive and accepted almost any string
    - StrictVersion required a specific format (e.g., "1.2.3")
    - packaging.version.Version follows PEP 440 versioning

    Manual migration is required because:
    1. Version strings that worked with LooseVersion may not parse with Version
    2. Comparison semantics differ between the implementations
    3. You may need to add error handling for invalid version strings

    Example migration:
        Before:
            from distutils.version import LooseVersion
            if LooseVersion("1.2.3") < LooseVersion("1.10.0"):
                ...

        After:
            from packaging.version import Version
            if Version("1.2.3") < Version("1.10.0"):
                ...
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceDistutilsVersion"

    @property
    def display_name(self) -> str:
        return "Replace deprecated distutils.version usage"

    @property
    def description(self) -> str:
        return (
            "Detect usage of deprecated `distutils.version.LooseVersion` and "
            "`distutils.version.StrictVersion`. These should be migrated to "
            "`packaging.version.Version`. Note: Manual migration is required as "
            "`packaging.version.Version` is not a drop-in replacement."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                # Check the 'from' part for 'from distutils.version import ...'
                from_part = multi.from_
                if from_part is not None:
                    from_str = from_part.print_all() if hasattr(from_part, 'print_all') else str(from_part)
                    if 'distutils.version' in from_str:
                        # Check what's being imported
                        imports_str = multi.print_all() if hasattr(multi, 'print_all') else str(multi)
                        if 'LooseVersion' in imports_str or 'StrictVersion' in imports_str:
                            return _mark_deprecated(
                                multi,
                                "distutils.version is deprecated",
                                "Migrate to packaging.version.Version (removed in Python 3.12). "
                                "Note: packaging.version.Version is not a drop-in replacement."
                            )

                return multi

        return Visitor()
