"""Composite recipe for upgrading to LangChain 0.2."""

from typing import List

from rewrite import Recipe
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python

_Migrate = [*Python, CategoryDescriptor(display_name="Migrate")]


@categorize(_Migrate)
class UpgradeToLangChain02(Recipe):
    """
    Migrate to LangChain 0.2.

    This composite recipe applies all necessary migrations for code using
    LangChain 0.1 to be compatible with LangChain 0.2.

    Key changes in LangChain 0.2:
    - Third-party integrations moved from `langchain` to `langchain_community`
    - Provider-specific classes should use dedicated packages (e.g. `langchain_openai`)

    See: https://python.langchain.com/v0.2/docs/versions/v0_2/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.langchain.UpgradeToLangChain02"

    @property
    def display_name(self) -> str:
        return "Upgrade to LangChain 0.2"

    @property
    def description(self) -> str:
        return (
            "Migrate to LangChain 0.2 by updating imports from `langchain` "
            "to `langchain_community` and provider-specific packages."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "langchain", "0.2"]

    def recipe_list(self) -> List[Recipe]:
        from .langchain_community_imports import ReplaceLangchainCommunityImports
        from .langchain_provider_imports import ReplaceLangchainProviderImports

        return [
            # First move langchain -> langchain_community
            ReplaceLangchainCommunityImports(),
            # Then move langchain_community -> provider packages where possible
            ReplaceLangchainProviderImports(),
        ]
