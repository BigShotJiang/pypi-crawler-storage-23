"""
Recipe for finding deprecated re.template() and re.TEMPLATE usage.

re.template() and re.TEMPLATE were deprecated in Python 3.11 and
removed in Python 3.13.

See: https://docs.python.org/3/whatsnew/3.11.html#deprecated
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import FieldAccess, Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.11
_Python311 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.11"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python311)
class FindReTemplate(Recipe):
    """
    Find usages of deprecated `re.template()` and `re.TEMPLATE`.

    `re.template()` and `re.TEMPLATE` (aka `re.T`) were deprecated in
    Python 3.11 and removed in Python 3.13. The template flag made
    patterns match differently but was rarely useful.

    Example:
        Before:
            import re
            pattern = re.template(r'\\d+')
            flags = re.TEMPLATE

        After:
            import re
            pattern = re.compile(r'\\d+')
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindReTemplate"

    @property
    def display_name(self) -> str:
        return "Find deprecated `re.template()` / `re.TEMPLATE` usage"

    @property
    def description(self) -> str:
        return (
            "`re.template()` and `re.TEMPLATE` were deprecated in Python 3.11 "
            "and removed in 3.13."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.11", "re"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "template":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "re":
                    return method

                return _mark_deprecated(
                    method,
                    "re.template() was deprecated in Python 3.11 and removed in 3.13."
                )

            def visit_field_access(
                self, field_access: FieldAccess, p: ExecutionContext
            ) -> Optional[FieldAccess]:
                field_access = super().visit_field_access(field_access, p)

                if not isinstance(field_access.name, Identifier):
                    return field_access
                if field_access.name.simple_name not in ("TEMPLATE", "T"):
                    return field_access

                target = field_access.target
                if not isinstance(target, Identifier):
                    return field_access
                if target.simple_name != "re":
                    return field_access

                return _mark_deprecated(
                    field_access,
                    f"re.{field_access.name.simple_name} was deprecated in Python 3.11 "
                    "and removed in 3.13."
                )

        return Visitor()
