"""GAIA benchmark integration."""

from .adapter import GaiaAdapter, load_gaia_tasks

__all__ = ["GaiaAdapter", "load_gaia_tasks"]
