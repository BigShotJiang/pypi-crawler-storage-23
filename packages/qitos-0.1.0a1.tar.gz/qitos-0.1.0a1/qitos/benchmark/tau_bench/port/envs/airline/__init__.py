"""Vendored Tau airline assets."""
