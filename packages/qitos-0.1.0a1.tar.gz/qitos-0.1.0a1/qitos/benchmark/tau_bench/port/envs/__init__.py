"""Vendored Tau-Bench env assets (retail/airline)."""
