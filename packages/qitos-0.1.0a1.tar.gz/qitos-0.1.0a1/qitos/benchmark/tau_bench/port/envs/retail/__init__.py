"""Vendored Tau retail assets."""
