"""Vendored Tau-Bench runtime assets for self-contained QitOS evaluation."""
