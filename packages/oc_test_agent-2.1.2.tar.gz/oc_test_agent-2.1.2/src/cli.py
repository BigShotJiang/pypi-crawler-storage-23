"""Test-Agent CLI入口点。"""

import click
import json
import os
import sys
from pathlib import Path

from src.core import ProjectManager, AgentManager, ExecutionEngine, DatabaseManager

# 环境变量配置
OC_STATE_DIR = os.environ.get('OC_STATE_DIR', 'state')
OC_CONFIG_DIR = os.environ.get('OC_CONFIG_DIR', 'config')


@click.group()
@click.version_option(version="1.2.0")
def cli():
    """Test-Agent: Docker-based Test Execution System."""
    pass


# v1.2 commands
from src.cli.execute import execute
from src.cli.build import build
from src.cli.query import query
from src.cli.report import report
from src.cli.cancel import cancel
from src.cli.cleanup import cleanup
from src.cli.init import init

cli.add_command(execute)
cli.add_command(build)
cli.add_command(query)
cli.add_command(report)
cli.add_command(cancel)
cli.add_command(cleanup)
cli.add_command(init)


@cli.command()
@click.option('--force', is_flag=True, help='强制初始化')
def init(force):
    """初始化测试环境。"""
    click.echo("初始化测试环境...")
    
    dirs = [
        "state/projects",
        "state/agents",
        "state/test_logs",
        "state/test_repos",
        "state/test_temp"
    ]
    
    for d in dirs:
        Path(d).mkdir(parents=True, exist_ok=True)
    
    click.echo(f"✅ 初始化完成，创建了 {len(dirs)} 个目录")


@cli.group()
def project():
    """项目管理命令。"""
    pass


@project.command('create')
@click.option('--id', 'project_id', required=True, help='项目ID（必须以test_开头）')
@click.option('--name', required=True, help='项目名称')
@click.option('--config', help='项目配置（JSON格式）')
def project_create(project_id, name, config):
    """创建测试项目。"""
    pm = ProjectManager()
    
    try:
        config_dict = json.loads(config) if config else None
        success, message = pm.create(project_id, name, config_dict)
        
        if success:
            click.echo(f"✅ {message}")
        else:
            click.echo(f"❌ {message}")
            sys.exit(1)
            
    except Exception as e:
        click.echo(f"❌ 错误: {str(e)}")
        sys.exit(1)


@project.command('list')
def project_list():
    """列出所有测试项目。"""
    pm = ProjectManager()
    
    try:
        projects = pm.list_all()
        
        if not projects:
            click.echo("暂无测试项目")
            return
        
        click.echo(f"\n共 {len(projects)} 个项目:\n")
        
        for p in projects:
            click.echo(f"  - {p['project_id']}: {p.get('name', 'N/A')}")
            
    except Exception as e:
        click.echo(f"❌ 错误: {str(e)}")
        sys.exit(1)


@project.command('delete')
@click.option('--id', 'project_id', required=True, help='项目ID')
@click.option('--force', is_flag=True, help='强制删除')
def project_delete(project_id, force):
    """删除测试项目。"""
    pm = ProjectManager()
    
    try:
        if not force:
            click.confirm(f"确定要删除项目 {project_id} 吗？", abort=True)
        
        success, message = pm.delete(project_id)
        
        if success:
            click.echo(f"✅ {message}")
            
    except Exception as e:
        click.echo(f"❌ 错误: {str(e)}")
        sys.exit(1)


@cli.group()
def agent():
    """Agent管理命令。"""
    pass


@agent.command('register')
@click.option('--id', 'agent_id', required=True, help='Agent ID（必须以test_开头）')
@click.option('--name', help='Agent名称')
@click.option('--metadata', help='Agent元数据（JSON格式）')
def agent_register(agent_id, name, metadata):
    """注册测试Agent。"""
    am = AgentManager()
    
    try:
        metadata_dict = json.loads(metadata) if metadata else {"name": name or agent_id}
        
        success, message = am.register(agent_id, metadata_dict)
        
        if success:
            click.echo(f"✅ {message}")
        else:
            click.echo(f"❌ {message}")
            sys.exit(1)
            
    except Exception as e:
        click.echo(f"❌ 错误: {str(e)}")
        sys.exit(1)


@agent.command('status')
@click.option('--id', 'agent_id', help='Agent ID，不指定则列出所有')
def agent_status(agent_id):
    """查看Agent状态。"""
    am = AgentManager()
    
    try:
        if agent_id:
            status = am.get_status(agent_id)
            click.echo(f"Agent {agent_id}: {status}")
        else:
            agents = am.list_all()
            
            if not agents:
                click.echo("暂无注册的Agent")
                return
            
            click.echo(f"\n共 {len(agents)} 个Agent:\n")
            
            for a in agents:
                click.echo(f"  - {a['agent_id']}: {a['status']}")
            
            pool_status = am.get_pool_status()
            click.echo(f"\n进程池: {pool_status['running']}/{pool_status['max_workers']} 运行中")
            
    except Exception as e:
        click.echo(f"❌ 错误: {str(e)}")
        sys.exit(1)


@agent.command('unregister')
@click.option('--id', 'agent_id', required=True, help='Agent ID')
def agent_unregister(agent_id):
    """注销Agent。"""
    am = AgentManager()
    
    try:
        success, message = am.unregister(agent_id)
        
        if success:
            click.echo(f"✅ {message}")
            
    except Exception as e:
        click.echo(f"❌ 错误: {str(e)}")
        sys.exit(1)


@cli.command()
@click.option('--project', required=True, help='项目ID')
@click.option('--agents', help='Agent ID列表（逗号分隔）')
@click.option('--commands', help='测试命令列表（逗号分隔）')
def run(project, agents, commands):
    """执行测试。"""
    pm = ProjectManager()
    
    try:
        project_config = pm.get(project)
        click.echo(f"开始执行测试: {project}")
        
    except Exception:
        click.echo(f"❌ 项目 {project} 不存在")
        sys.exit(1)
    
    agent_ids = agents.split(',') if agents else []
    test_commands = commands.split(',') if commands else ['echo "test"']
    
    engine = ExecutionEngine(project, max_workers=5)
    
    try:
        result = engine.run(agent_ids, test_commands)
        
        click.echo(f"\n执行完成: {result['execution_id']}")
        click.echo(f"状态: {result['status']}")
        
        summary = result.get('summary', {})
        click.echo(f"\n结果统计:")
        click.echo(f"  通过: {summary.get('passed', 0)}")
        click.echo(f"  失败: {summary.get('failed', 0)}")
        click.echo(f"  错误: {summary.get('error', 0)}")
        
    except Exception as e:
        click.echo(f"❌ 执行错误: {str(e)}")
        sys.exit(1)
    finally:
        engine.cleanup()


@cli.command()
def isolate():
    """检查数据隔离状态。"""
    db_manager = DatabaseManager()
    
    click.echo("检查数据隔离状态...\n")
    
    state_dir = Path(OC_STATE_DIR)
    db_files = list(state_dir.glob("todos_test_*.db"))
    
    click.echo(f"测试数据库: {len(db_files)} 个")
    for db in db_files:
        click.echo(f"  - {db.name}")
    
    click.echo(f"\n✅ 隔离检查完成")


@cli.command()
@click.option('--project', required=True, help='项目ID')
@click.option('--dry-run', is_flag=True, help='仅显示待删除内容')
def cleanup(project, dry_run):
    """清理测试数据。"""
    import shutil
    
    click.echo(f"清理项目 {project} 的测试数据...")
    
    dirs_to_clean = [
        f"{OC_STATE_DIR}/projects/{project}",
        f"{OC_STATE_DIR}/test_logs/{project}",
        f"{OC_STATE_DIR}/test_repos/test_{project}",
    ]
    
    for d in dirs_to_clean:
        path = Path(d)
        if path.exists():
            if dry_run:
                click.echo(f"  [dry-run] 将删除: {d}")
            else:
                shutil.rmtree(path)
                click.echo(f"  ✅ 已删除: {d}")
    
    db_manager = DatabaseManager()
    db_manager.cleanup_namespace(project)
    
    if not dry_run:
        click.echo(f"\n✅ 清理完成")
    else:
        click.echo(f"\n[dry-run] 预览完成，实际执行请去掉 --dry-run 参数")


if __name__ == '__main__':
    cli()
