"""错误码定义模块。"""


class TestAgentError(Exception):
    """Test-Agent基础异常。"""
    pass


class ConfigParseError(TestAgentError):
    """配置解析错误。"""
    pass


class ValidationError(TestAgentError):
    """参数验证错误。"""
    pass


class ProjectExistsError(TestAgentError):
    """项目已存在错误。"""
    pass


class ProjectNotFoundError(TestAgentError):
    """项目不存在错误。"""
    pass


class AgentExistsError(TestAgentError):
    """Agent已注册错误。"""
    pass


class AgentNotFoundError(TestAgentError):
    """Agent未注册错误。"""
    pass


class PoolFullError(TestAgentError):
    """Agent池已满错误。"""
    pass


class ProcessStartError(TestAgentError):
    """进程启动失败错误。"""
    pass


class DatabaseError(TestAgentError):
    """数据库操作错误。"""
    pass


class DiskSpaceError(TestAgentError):
    """磁盘空间不足错误。"""
    pass


class SyncStateError(TestAgentError):
    """状态同步错误。"""
    pass


ERROR_CODES = {
    "T001": "无效的项目ID：必须以test_开头",
    "T002": "项目不存在",
    "T003": "项目已存在",
    "T004": "无效的Agent ID：必须以test_开头",
    "T005": "Agent未注册",
    "T006": "Agent已注册",
    "T007": "Agent池已满",
    "T008": "进程启动失败",
    "T009": "进程执行超时",
    "T010": "数据库错误",
    "T011": "配置解析失败",
    "T012": "StateNotifier同步失败",
    "T013": "磁盘空间不足",
    "T014": "权限不足",
    "T015": "PM-Agent调用失败",
}


def get_error_message(code: str) -> str:
    """获取错误码对应的消息。"""
    return ERROR_CODES.get(code, "未知错误")
