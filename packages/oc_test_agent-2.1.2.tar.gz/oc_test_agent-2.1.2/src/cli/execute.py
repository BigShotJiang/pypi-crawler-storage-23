import click
import logging

from ..db.database import Database, TEST_RESULTS_DB_PATH
from ..core.test_executor import TestExecutor

logger = logging.getLogger(__name__)


@click.command()
@click.option('--project', required=True, help='项目名')
@click.option('--project-path', default=None, help='项目代码路径')
@click.option('--version', required=True, help='版本号')
@click.option('--test-type', default='all',
              type=click.Choice(['unit', 'integration', 'e2e', 'all']),
              help='测试类型')
@click.option('--test-type-filter', default='directory',
              type=click.Choice(['directory', 'marker']),
              help='测试过滤方式')
@click.option('--dependencies', default='', help='依赖项目(格式: name:path)')
@click.option('--timeout', default=300, type=int, help='超时时间(秒)')
@click.option('--tag', default='latest', help='镜像标签')
def execute(project, project_path, version, test_type, test_type_filter, dependencies, timeout, tag):
    """在 Docker 容器内执行测试"""
    
    db = Database.get_instance(TEST_RESULTS_DB_PATH)
    db.init_schema()
    
    if not project_path:
        from ..core.config_service import ConfigService
        config_svc = ConfigService()
        project_path = config_svc.get_project_path(project)
    
    if not project_path:
        click.echo(f"Error: 项目路径未指定，请使用 --project-path 或配置 projects.yaml", err=True)
        return
    
    try:
        executor = TestExecutor(
            project=project,
            version=version,
            project_path=project_path,
            test_type=test_type,
            test_type_filter=test_type_filter,
            timeout=timeout,
            tag=tag
        )
        
        click.echo(f"Starting test: {executor.id}")
        
        result = executor.execute()
        
        click.echo(f"\nTest ID: {result.id}")
        click.echo(f"Status: {result.status.value}")
        click.echo(f"Passed: {result.passed}")
        click.echo(f"Failed: {result.failed}")
        click.echo(f"Errors: {result.errors}")
        if result.duration:
            click.echo(f"Duration: {result.duration:.2f}s")
        
        if result.report_path:
            click.echo(f"Report: {result.report_path}")
        
    except Exception as e:
        logger.error(f"Test execution failed: {e}")
        click.echo(f"Error: {e}", err=True)
