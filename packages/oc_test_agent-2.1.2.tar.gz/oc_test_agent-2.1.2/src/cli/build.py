import click
import logging

from ..core.docker_service import DockerService
from ..core.config_service import ConfigService

logger = logging.getLogger(__name__)


@click.command()
@click.option('--project', required=True, help='项目名')
@click.option('--project-path', default=None, help='项目代码路径')
@click.option('--dockerfile', default='Dockerfile.test', help='Dockerfile路径')
@click.option('--no-cache', is_flag=True, help='不使用缓存')
@click.option('--tag', default='latest', help='镜像标签')
def build(project, project_path, dockerfile, no_cache, tag):
    """构建 Docker 测试镜像"""
    
    docker = DockerService()
    
    if not docker.is_available():
        click.echo("Error: Docker is not available", err=True)
        return
    
    if not project_path:
        config_svc = ConfigService()
        project_path = config_svc.get_project_path(project)
    
    if not project_path:
        click.echo(f"Error: 项目路径未指定，请使用 --project-path 或配置 projects.yaml", err=True)
        return
    
    image_tag = f"{project}:{tag}"
    
    click.echo(f"Building image: {image_tag}")
    
    success = docker.build_image(
        project_path=project_path,
        dockerfile=dockerfile,
        tag=image_tag,
        nocache=no_cache
    )
    
    if success:
        click.echo(f"Image built successfully: {image_tag}")
    else:
        click.echo(f"Failed to build image", err=True)
