"""
ConfMan API Client for test-agent to interact with conf-man HTTP API.

This client provides configuration and version management via conf-man HTTP API.
"""

import os
import json
import logging
from typing import Optional, List, Dict, Any

logger = logging.getLogger(__name__)


class ConfManAPIError(Exception):
    """Exception raised for conf-man API errors."""
    pass


class ConfManClient:
    """Client for interacting with conf-man HTTP API."""
    
    DEFAULT_BASE_URL = "http://localhost:8000"
    
    def __init__(self, base_url: Optional[str] = None, api_key: Optional[str] = None, timeout: int = 30):
        """
        Initialize ConfManClient.
        
        Args:
            base_url: Base URL for conf-man API. Defaults to localhost:8000
            api_key: API key for authentication
            timeout: Request timeout in seconds
        """
        self.base_url = base_url or os.environ.get('CONF_MAN_API_URL', self.DEFAULT_BASE_URL)
        self.api_key = api_key or os.environ.get('CONF_MAN_API_KEY', '')
        self.timeout = timeout
        self._session = None
    
    def _get_session(self):
        """Get or create HTTP session."""
        if self._session is None:
            import requests
            self._session = requests.Session()
            self._session.headers.update({
                'Content-Type': 'application/json',
                'User-Agent': 'test-agent/1.0'
            })
            if self.api_key:
                self._session.headers['X-API-Key'] = self.api_key
        return self._session
    
    def _request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Make HTTP request to conf-man API."""
        import requests
        
        url = f"{self.base_url}{endpoint}"
        try:
            response = self._session.request(
                method, url, timeout=self.timeout, **kwargs
            )
            response.raise_for_status()
            return response.json() if response.content else {}
        except requests.exceptions.ConnectionError:
            raise ConfManAPIError(f"Cannot connect to conf-man API at {self.base_url}")
        except requests.exceptions.Timeout:
            raise ConfManAPIError(f"Request to {url} timed out")
        except requests.exceptions.HTTPError as e:
            raise ConfManAPIError(f"HTTP error: {e}")
        except Exception as e:
            raise ConfManAPIError(f"Request failed: {e}")
    
    # Health Check
    
    def health_check(self) -> bool:
        """
        Check if conf-man API is available.
        
        Returns:
            True if API is reachable
        """
        try:
            import requests
            response = requests.get(f"{self.base_url}/health", timeout=5)
            return response.status_code == 200
        except Exception:
            return False
    
    # Version API Methods
    
    def list_versions(self, project_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List versions.
        
        Args:
            project_id: Filter by project ID
            
        Returns:
            List of version objects
        """
        params = {}
        if project_id:
            params['project_id'] = project_id
        
        result = self._request('GET', '/api/v1/versions', params=params)
        return result.get('versions', [])
    
    def get_version(self, version_id: str) -> Dict[str, Any]:
        """
        Get a specific version by ID.
        
        Args:
            version_id: Version ID
            
        Returns:
            Version object
        """
        result = self._request('GET', f'/api/v1/versions/{version_id}')
        return result
    
    def create_version(
        self,
        version: str,
        project_id: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Create a new version.
        
        Args:
            version: Version string (e.g., "v1.0")
            project_id: Project ID
            metadata: Additional metadata
            
        Returns:
            Created version object
        """
        data = {
            'version': version,
            'project_id': project_id
        }
        if metadata:
            data['metadata'] = metadata
        
        result = self._request('POST', '/api/v1/versions', json=data)
        return result
    
    def update_version(
        self,
        version_id: str,
        version: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Update a version.
        
        Args:
            version_id: Version ID
            version: New version string (optional)
            metadata: New metadata (optional)
            
        Returns:
            Updated version object
        """
        data = {}
        if version:
            data['version'] = version
        if metadata:
            data['metadata'] = metadata
        
        result = self._request('PUT', f'/api/v1/versions/{version_id}', json=data)
        return result
    
    def delete_version(self, version_id: str) -> bool:
        """
        Delete a version.
        
        Args:
            version_id: Version ID
            
        Returns:
            True if successful
        """
        self._request('DELETE', f'/api/v1/versions/{version_id}')
        return True
    
    # Project API Methods
    
    def list_projects(self) -> List[Dict[str, Any]]:
        """
        List all projects.
        
        Returns:
            List of project objects
        """
        result = self._request('GET', '/api/v1/projects')
        return result.get('projects', [])
    
    def get_project(self, project_id: str) -> Dict[str, Any]:
        """
        Get a specific project by ID.
        
        Args:
            project_id: Project ID
            
        Returns:
            Project object
        """
        result = self._request('GET', f'/api/v1/projects/{project_id}')
        return result
    
    def create_project(
        self,
        name: str,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Create a new project.
        
        Args:
            name: Project name
            description: Project description
            metadata: Additional metadata
            
        Returns:
            Created project object
        """
        data = {'name': name}
        if description:
            data['description'] = description
        if metadata:
            data['metadata'] = metadata
        
        result = self._request('POST', '/api/v1/projects', json=data)
        return result
    
    def update_project(
        self,
        project_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Update a project.
        
        Args:
            project_id: Project ID
            name: New name (optional)
            description: New description (optional)
            metadata: New metadata (optional)
            
        Returns:
            Updated project object
        """
        data = {}
        if name:
            data['name'] = name
        if description:
            data['description'] = description
        if metadata:
            data['metadata'] = metadata
        
        result = self._request('PUT', f'/api/v1/projects/{project_id}', json=data)
        return result
    
    def delete_project(self, project_id: str) -> bool:
        """
        Delete a project.
        
        Args:
            project_id: Project ID
            
        Returns:
            True if successful
        """
        self._request('DELETE', f'/api/v1/projects/{project_id}')
        return True
    
    # Secrets API Methods
    
    def get_secret(self, key: str) -> Optional[str]:
        """
        Get a secret value.
        
        Args:
            key: Secret key
            
        Returns:
            Secret value or None
        """
        result = self._request('GET', f'/api/v1/secrets/{key}')
        return result.get('value')
    
    def set_secret(self, key: str, value: str) -> bool:
        """
        Set a secret value.
        
        Args:
            key: Secret key
            value: Secret value
            
        Returns:
            True if successful
        """
        data = {'value': value}
        self._request('POST', f'/api/v1/secrets/{key}', json=data)
        return True
    
    def delete_secret(self, key: str) -> bool:
        """
        Delete a secret.
        
        Args:
            key: Secret key
            
        Returns:
            True if successful
        """
        self._request('DELETE', f'/api/v1/secrets/{key}')
        return True
    
    def list_secrets(self) -> List[Dict[str, Any]]:
        """
        List all secrets (without values).
        
        Returns:
            List of secret objects
        """
        result = self._request('GET', '/api/v1/secrets')
        return result.get('secrets', [])


def get_conf_man_client() -> ConfManClient:
    """Get ConfManClient instance."""
    return ConfManClient()
