"""
Version Client for test-agent to interact with conf-man version management via HTTP API.
"""

import json
import logging
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime

from ..models.test_report import TestReport, TestReportStatus
from .conf_man_client import ConfManClient, get_conf_man_client, ConfManAPIError

logger = logging.getLogger(__name__)


class VersionClient:
    """Client for interacting with conf-man version management via HTTP API."""
    
    def __init__(self, base_url: Optional[str] = None, api_key: Optional[str] = None):
        """
        Initialize VersionClient.
        
        Args:
            base_url: Base URL for conf-man API
            api_key: API key for authentication
        """
        self.base_url = base_url
        self.api_key = api_key
        self._client = None
    
    def _get_client(self) -> ConfManClient:
        """Get or create ConfManClient instance."""
        if self._client is None:
            if self.base_url or self.api_key:
                self._client = ConfManClient(base_url=self.base_url, api_key=self.api_key)
            else:
                self._client = get_conf_man_client()
        return self._client
    
    def register(
        self,
        version: str,
        manifest_path: str,
        test_report: TestReport,
        project: Optional[str] = None
    ) -> bool:
        """
        Register a version with conf-man.
        
        Args:
            version: Version string (e.g., "v2.4.0")
            manifest_path: Path to version manifest file
            test_report: TestReport object
            project: Optional project name
            
        Returns:
            True if registration succeeded
        """
        test_report_path = self._save_test_report(test_report, version)
        
        manifest_content = ""
        if manifest_path and Path(manifest_path).exists():
            with open(manifest_path, 'r') as f:
                manifest_content = f.read()
        
        metadata = {
            "manifest_path": manifest_path,
            "test_report_path": test_report_path,
            "test_report_status": test_report.status.value if test_report.status else "unknown"
        }
        
        try:
            client = self._get_client()
            result = client.create_version(
                version=version,
                project_id=project or "test-agent",
                metadata=metadata
            )
            
            if result:
                logger.info(f"Successfully registered version {version}")
                return True
            else:
                logger.error(f"Failed to register version {version}")
                return False
                
        except ConfManAPIError as e:
            logger.error(f"Failed to register version {version}: {e}")
            return False
    
    def _save_test_report(self, test_report: TestReport, version: str) -> str:
        """Save test report to temporary file and return path"""
        import tempfile
        
        report_data = test_report.to_yaml_dict()
        
        fd, path = tempfile.mkstemp(suffix=".yaml", prefix="test_report_")
        with open(path, 'w') as f:
            import yaml
            yaml.dump(report_data, f, default_flow_style=False)
        
        logger.info(f"Test report saved to {path}")
        return path
    
    def list_versions(self, project_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all registered versions"""
        try:
            client = self._get_client()
            versions = client.list_versions(project_id=project_id)
            return versions
        except ConfManAPIError as e:
            logger.error(f"Failed to list versions: {e}")
            return []
    
    def show_version(self, version_id: str) -> Optional[Dict[str, Any]]:
        """Get details of a specific version"""
        try:
            client = self._get_client()
            version = client.get_version(version_id)
            return version
        except ConfManAPIError as e:
            logger.error(f"Failed to show version {version_id}: {e}")
            return None
    
    def release_version(self, version_id: str) -> bool:
        """Trigger release for a version"""
        try:
            client = self._get_client()
            
            version = client.get_version(version_id)
            if not version:
                logger.error(f"Version {version_id} not found")
                return False
            
            url = f"{client.base_url}/api/v1/versions/{version_id}/release"
            session = client._get_session()
            response = session.post(url)
            
            if response.status_code == 200:
                logger.info(f"Successfully triggered release for {version_id}")
                return True
            else:
                logger.error(f"Failed to release version {version_id}: {response.text}")
                return False
                
        except ConfManAPIError as e:
            logger.error(f"Failed to release version {version_id}: {e}")
            return False
        except Exception as e:
            logger.error(f"Failed to release version {version_id}: {e}")
            return False
    
    def get_dependencies(self, version_id: str) -> List[str]:
        """Get dependencies for a version"""
        try:
            client = self._get_client()
            
            url = f"{client.base_url}/api/v1/dependencies?version_id={version_id}"
            session = client._get_session()
            response = session.get(url)
            
            if response.status_code == 200:
                data = response.json()
                deps = data.get("dependencies", [])
                return [d.get("name") for d in deps]
            return []
            
        except Exception as e:
            logger.error(f"Failed to get dependencies for {version_id}: {e}")
            return []
    
    def lock_dependencies(self, version_id: str) -> bool:
        """Lock dependencies for a version"""
        try:
            client = self._get_client()
            
            url = f"{client.base_url}/api/v1/versions/{version_id}/lock"
            session = client._get_session()
            response = session.post(url)
            
            if response.status_code == 200:
                logger.info(f"Successfully locked dependencies for {version_id}")
                return True
            else:
                logger.error(f"Failed to lock dependencies: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Failed to lock dependencies for {version_id}: {e}")
            return False


class AutoRegisterMixin:
    """Mixin for automatic version registration after test execution"""
    
    def __init__(self):
        self.version_client = VersionClient()
    
    def auto_register_version(
        self,
        version: str,
        manifest_path: str,
        test_report: TestReport,
        auto_release: bool = False,
        project: Optional[str] = None
    ) -> bool:
        """
        Automatically register version after test execution.
        
        Args:
            version: Version to register
            manifest_path: Path to manifest file
            test_report: Test report from test execution
            auto_release: Whether to automatically release after registration
            project: Optional project name
            
        Returns:
            True if registration succeeded
        """
        success = self.version_client.register(
            version=version,
            manifest_path=manifest_path,
            test_report=test_report,
            project=project
        )
        
        if success and auto_release:
            version_id = f"ver-{version}"  
            self.version_client.release_version(version_id)
        
        return success
