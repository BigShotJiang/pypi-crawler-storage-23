"""
Webhook通知模块
"""

import asyncio
import hashlib
import hmac
import json
from datetime import datetime
from typing import List, Optional, Dict, Any
from dataclasses import dataclass, field
import aiohttp


@dataclass
class WebhookConfig:
    """Webhook配置"""
    id: str
    url: str
    events: List[str]
    timeout: int = 30
    secret: Optional[str] = None
    retry_config: Dict[str, int] = field(default_factory=lambda: {"max_attempts": 3, "interval": 5})
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class WebhookPayload:
    """Webhook负载"""
    event: str
    test_id: str
    project: str
    version: str
    status: str
    passed: int
    failed: int
    errors: int
    duration: float
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat() + "Z")
    metadata: Dict[str, Any] = field(default_factory=dict)


class WebhookManager:
    """Webhook通知管理器"""
    
    def __init__(self):
        self.webhooks: List[WebhookConfig] = []
        self._enabled = True
    
    def add_webhook(self, config: WebhookConfig):
        """添加webhook"""
        self.webhooks.append(config)
    
    def remove_webhook(self, webhook_id: str) -> bool:
        """移除webhook"""
        for i, wh in enumerate(self.webhooks):
            if wh.id == webhook_id:
                self.webhooks.pop(i)
                return True
        return False
    
    def get_webhooks(self) -> List[WebhookConfig]:
        """获取所有webhook"""
        return self.webhooks
    
    def should_send(self, webhook: WebhookConfig, event: str) -> bool:
        """检查是否应该发送"""
        if event in webhook.events:
            return True
        if "*" in webhook.events:
            return True
        # 支持命名空间通配符 test.*
        for e in webhook.events:
            if e.endswith(".*"):
                namespace = e[:-1]
                if event.startswith(namespace):
                    return True
        return False
    
    def build_payload(self, test_result: Any) -> WebhookPayload:
        """构建webhook负载"""
        return WebhookPayload(
            event=f"test.{test_result.status.value}",
            test_id=test_result.id,
            project=test_result.project,
            version=test_result.version,
            status=test_result.status.value,
            passed=test_result.passed,
            failed=test_result.failed,
            errors=test_result.errors,
            duration=test_result.duration or 0.0
        )
    
    async def notify(self, test_result: Any):
        """发送通知（不阻塞主流程）"""
        if not self._enabled:
            return
        
        payload = self.build_payload(test_result)
        
        asyncio.create_task(self._send_notifications(payload))
    
    async def _send_notifications(self, payload: WebhookPayload):
        """异步发送所有webhook通知"""
        for webhook in self.webhooks:
            if self.should_send(webhook, payload.event):
                try:
                    await self._send_with_retry(webhook, payload)
                except Exception as e:
                    print(f"Webhook通知失败: {webhook.url}, error: {e}")
    
    async def _send_with_retry(self, webhook: WebhookConfig, payload: WebhookPayload):
        """带重试的发送"""
        max_attempts = webhook.retry_config.get("max_attempts", 3)
        interval = webhook.retry_config.get("interval", 5)
        
        for attempt in range(max_attempts):
            try:
                await self._send_webhook(webhook, payload)
                return
            except Exception as e:
                if attempt < max_attempts - 1:
                    await asyncio.sleep(interval * (2 ** attempt))
                else:
                    raise e
    
    async def _send_webhook(self, webhook: WebhookConfig, payload: WebhookPayload):
        """发送单个webhook"""
        payload_dict = {
            "event": payload.event,
            "test_id": payload.test_id,
            "project": payload.project,
            "version": payload.version,
            "status": payload.status,
            "passed": payload.passed,
            "failed": payload.failed,
            "errors": payload.errors,
            "duration": payload.duration,
            "timestamp": payload.timestamp,
            "metadata": payload.metadata
        }
        
        headers = {"Content-Type": "application/json"}
        
        if webhook.secret:
            signature = hmac.new(
                webhook.secret.encode(),
                json.dumps(payload_dict).encode(),
                hashlib.sha256
            ).hexdigest()
            headers["X-Webhook-Signature"] = signature
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                webhook.url,
                json=payload_dict,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=webhook.timeout)
            ) as resp:
                resp.raise_for_status()


_notification_manager: Optional[WebhookManager] = None


def get_notification_manager() -> WebhookManager:
    """获取通知管理器单例"""
    global _notification_manager
    if _notification_manager is None:
        _notification_manager = WebhookManager()
    return _notification_manager
