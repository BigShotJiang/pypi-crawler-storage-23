"""进程间通信模块。"""

import multiprocessing
import queue
from typing import Any, Optional
from datetime import datetime


class IPCManager:
    """进程间通信管理器。"""
    
    def __init__(self, namespace: str):
        self.namespace = namespace
        self._queues: dict[str, multiprocessing.Queue] = {}
        self._message_counters: dict[str, int] = {}
    
    def create_queue(self, queue_id: str) -> multiprocessing.Queue:
        """创建通信队列。
        
        Args:
            queue_id: 队列ID
            
        Returns:
            队列实例
        """
        if queue_id not in self._queues:
            self._queues[queue_id] = multiprocessing.Queue()
            self._message_counters[queue_id] = 0
        return self._queues[queue_id]
    
    def get_queue(self, queue_id: str) -> Optional[multiprocessing.Queue]:
        """获取已存在的队列。
        
        Args:
            queue_id: 队列ID
            
        Returns:
            队列实例，不存在则返回None
        """
        return self._queues.get(queue_id)
    
    def send(self, queue_id: str, message: dict, timeout: float = 10.0) -> bool:
        """发送消息。
        
        Args:
            queue_id: 队列ID
            message: 消息内容
            timeout: 超时时间
            
        Returns:
            发送成功标志
        """
        if queue_id not in self._queues:
            self.create_queue(queue_id)
        
        wrapped_message = {
            "namespace": self.namespace,
            "queue_id": queue_id,
            "message": message,
            "timestamp": datetime.utcnow().isoformat(),
            "seq": self._message_counters.get(queue_id, 0)
        }
        
        try:
            self._queues[queue_id].put(wrapped_message, timeout=timeout)
            self._message_counters[queue_id] = self._message_counters.get(queue_id, 0) + 1
            return True
        except queue.Full:
            return False
    
    def receive(self, queue_id: str, timeout: float = 10.0) -> Optional[dict]:
        """接收消息。
        
        Args:
            queue_id: 队列ID
            timeout: 超时时间
            
        Returns:
            消息内容，超时则返回None
        """
        if queue_id not in self._queues:
            return None
        
        try:
            return self._queues[queue_id].get(timeout=timeout)
        except queue.Empty:
            return None
    
    def broadcast(self, message: dict, timeout: float = 10.0) -> int:
        """广播消息到所有队列。
        
        Args:
            message: 消息内容
            timeout: 超时时间
            
        Returns:
            成功发送的队列数量
        """
        success_count = 0
        for queue_id in self._queues:
            if self.send(queue_id, message, timeout):
                success_count += 1
        return success_count
    
    def clear_queue(self, queue_id: str) -> None:
        """清空队列。
        
        Args:
            queue_id: 队列ID
        """
        if queue_id in self._queues:
            while True:
                try:
                    self._queues[queue_id].get_nowait()
                except queue.Empty:
                    break
            # 重新创建队列以确保完全清空
            self._queues[queue_id] = multiprocessing.Queue()
            self._message_counters[queue_id] = 0
    
    def close_queue(self, queue_id: str) -> None:
        """关闭队列。
        
        Args:
            queue_id: 队列ID
        """
        if queue_id in self._queues:
            del self._queues[queue_id]
            if queue_id in self._message_counters:
                del self._message_counters[queue_id]
    
    def close_all(self) -> None:
        """关闭所有队列。"""
        for queue_id in list(self._queues.keys()):
            self.close_queue(queue_id)
    
    def get_queue_stats(self, queue_id: str) -> dict:
        """获取队列统计信息。
        
        Args:
            queue_id: 队列ID
            
        Returns:
            统计信息
        """
        return {
            "queue_id": queue_id,
            "exists": queue_id in self._queues,
            "messages_sent": self._message_counters.get(queue_id, 0),
            "namespace": self.namespace
        }
    
    def list_queues(self) -> list[str]:
        """列出所有队列ID。
        
        Returns:
            队列ID列表
        """
        return list(self._queues.keys())


class SharedDataManager:
    """共享数据管理器。"""
    
    def __init__(self):
        self._data = multiprocessing.Manager().dict()
    
    def set(self, key: str, value: Any) -> None:
        """设置共享数据。
        
        Args:
            key: 键
            value: 值
        """
        self._data[key] = value
    
    def get(self, key: str, default: Any = None) -> Any:
        """获取共享数据。
        
        Args:
            key: 键
            default: 默认值
            
        Returns:
            值
        """
        return self._data.get(key, default)
    
    def delete(self, key: str) -> bool:
        """删除共享数据。
        
        Args:
            key: 键
            
        Returns:
            是否成功
        """
        if key in self._data:
            del self._data[key]
            return True
        return False
    
    def keys(self) -> list:
        """获取所有键。
        
        Returns:
            键列表
        """
        return list(self._data.keys())
    
    def clear(self) -> None:
        """清空所有数据。"""
        self._data.clear()
