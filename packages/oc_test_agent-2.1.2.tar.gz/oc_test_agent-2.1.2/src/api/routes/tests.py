"""Test execution and query routes"""

from typing import Optional, List
from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel

from ...db.database import Database, TEST_RESULTS_DB_PATH
from ...core.result_service import ResultService
from ...models.test_result import TestStatus

router = APIRouter()


class TestExecuteRequest(BaseModel):
    project: str
    version: str
    test_type: str = "all"
    agents: Optional[List[str]] = None
    commands: Optional[List[str]] = None
    timeout: int = 3600


class TestExecuteResponse(BaseModel):
    test_id: str
    status: str
    created_at: Optional[str] = None


class TestDetailResponse(BaseModel):
    test_id: str
    project: str
    version: str
    status: str
    passed: int
    failed: int
    errors: int
    total: int
    duration: Optional[float] = None
    created_at: Optional[str] = None


@router.post("/tests/execute", response_model=TestExecuteResponse)
async def execute_test(request: TestExecuteRequest, background_tasks: BackgroundTasks):
    """Execute test"""
    from datetime import datetime
    import uuid
    import asyncio
    from concurrent.futures import ThreadPoolExecutor
    
    test_id = f"test_{uuid.uuid4().hex[:12]}"
    
    db = Database.get_instance(TEST_RESULTS_DB_PATH)
    db.init_schema()
    
    from ...models.test_result import TestResult
    from ...db.repositories.result_repo import ResultRepository
    from ...core.config_service import ConfigService
    
    repo = ResultRepository(db)
    
    result = TestResult(
        id=test_id,
        project=request.project,
        version=request.version,
        status=TestStatus.PENDING,
        test_type=request.test_type,
        created_at=datetime.now()
    )
    repo.insert(result)
    
    def run_test():
        try:
            config_svc = ConfigService()
            project_path = config_svc.get_project_path(request.project)
            
            if not project_path:
                repo.update_status(test_id, TestStatus.ERROR)
                return
            
            from ...core.test_executor import TestExecutor
            executor = TestExecutor(
                project=request.project,
                version=request.version,
                project_path=project_path,
                test_type=request.test_type,
                timeout=request.timeout
            )
            
            test_result = executor.execute()
            
            repo.update_status(
                test_id,
                test_result.status,
                duration=test_result.duration,
                passed=test_result.passed,
                failed=test_result.failed,
                errors=test_result.errors,
                total=test_result.total,
                report_path=test_result.report_path,
                logs_path=test_result.logs_path
            )
        except Exception as e:
            print(f"Background test execution failed: {e}")
            import traceback
            traceback.print_exc()
            repo.update_status(test_id, TestStatus.ERROR)
    
    background_tasks.add_task(run_test)
    
    return TestExecuteResponse(
        test_id=test_id,
        status="pending",
        created_at=result.created_at.isoformat()
    )


@router.get("/tests", response_model=dict)
async def list_tests(
    project: Optional[str] = None,
    version: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 10
):
    """List test results"""
    db = Database.get_instance(TEST_RESULTS_DB_PATH)
    db.init_schema()
    
    status_enum = None
    if status:
        try:
            status_enum = TestStatus(status.lower())
        except ValueError:
            pass
    
    result_svc = ResultService()
    results = result_svc.query(
        project=project,
        version=version,
        status=status_enum,
        limit=limit
    )
    
    tests = []
    for r in results:
        tests.append({
            "test_id": r.id,
            "project": r.project,
            "version": r.version,
            "status": r.status.value,
            "passed": r.passed,
            "failed": r.failed,
            "errors": r.errors,
            "total": r.total,
            "created_at": r.created_at.isoformat() if r.created_at else None
        })
    
    return {
        "tests": tests,
        "total": len(tests)
    }


@router.get("/tests/{test_id}", response_model=TestDetailResponse)
async def get_test(test_id: str):
    """Get test detail"""
    db = Database.get_instance(TEST_RESULTS_DB_PATH)
    db.init_schema()
    
    result_svc = ResultService()
    result = result_svc.get(test_id)
    
    if not result:
        raise HTTPException(status_code=404, detail="Test not found")
    
    return TestDetailResponse(
        test_id=result.id,
        project=result.project,
        version=result.version,
        status=result.status.value,
        passed=result.passed,
        failed=result.failed,
        errors=result.errors,
        total=result.total,
        duration=result.duration,
        created_at=result.created_at.isoformat() if result.created_at else None
    )


@router.delete("/tests/{test_id}")
async def cancel_test(test_id: str):
    """Cancel test"""
    db = Database.get_instance(TEST_RESULTS_DB_PATH)
    db.init_schema()
    
    from ...db.repositories.result_repo import ResultRepository
    from ...core.result_service import ResultService
    result_svc = ResultService()
    result = result_svc.get(test_id)
    
    if not result:
        raise HTTPException(status_code=404, detail="Test not found")
    
    repo = ResultRepository(db)
    repo.update_status(test_id, TestStatus.CANCELLED)
    
    return {"message": "Test cancelled", "test_id": test_id}
