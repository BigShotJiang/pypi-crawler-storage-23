"""
Webhook回调API路由
"""

import uuid
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel
import hmac
import hashlib
import json

from ...core.notification.webhook import get_notification_manager, WebhookConfig

router = APIRouter()


class WebhookSubscribeRequest(BaseModel):
    """Webhook订阅请求"""
    url: str
    events: List[str]
    secret: Optional[str] = None


@router.post("/webhook/subscribe")
async def subscribe_webhook(request: WebhookSubscribeRequest):
    """注册订阅（与conf-man一致）"""
    notification_manager = get_notification_manager()
    
    webhook_config = WebhookConfig(
        id=f"wh_{uuid.uuid4().hex[:12]}",
        url=request.url,
        events=request.events,
        secret=request.secret
    )
    
    notification_manager.add_webhook(webhook_config)
    
    return {
        "subscription_id": webhook_config.id,
        "message": "Subscription registered",
        "url": request.url,
        "events": request.events
    }


@router.post("/webhook/callback")
async def webhook_callback(
    event: dict,
    x_webhook_signature: Optional[str] = Header(None)
):
    """接收回调"""
    event_type = event.get("event", "unknown")
    
    if event_type == "test.trigger":
        pass
    
    return {
        "message": "Callback received",
        "event": event_type
    }


@router.get("/webhook/subscriptions")
async def list_subscriptions():
    """列出订阅"""
    notification_manager = get_notification_manager()
    webhooks = notification_manager.get_webhooks()
    
    subscriptions = [
        {
            "id": wh.id,
            "url": wh.url,
            "events": wh.events
        }
        for wh in webhooks
    ]
    
    return {
        "subscriptions": subscriptions,
        "total": len(subscriptions)
    }


@router.delete("/webhook/subscriptions/{subscription_id}")
async def delete_subscription(subscription_id: str):
    """删除订阅"""
    notification_manager = get_notification_manager()
    success = notification_manager.remove_webhook(subscription_id)
    
    if not success:
        raise HTTPException(status_code=404, detail="Subscription not found")
    
    return {
        "message": "Subscription deleted",
        "id": subscription_id
    }
