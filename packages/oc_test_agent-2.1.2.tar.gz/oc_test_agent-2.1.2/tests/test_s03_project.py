"""
S03-项目管理子系统测试代码
用例数: 96
覆盖文档: test-agent/docs/03-test/oc-collab/S03_project.md
"""

import pytest
import subprocess
import sqlite3
import os
import tempfile
from pathlib import Path
import yaml


class TestProjectCreate:
    """S03-T001-T010: 项目创建"""
    
    def test_project_create_basic(self, tmp_path, monkeypatch):
        """测试基本项目创建"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "create", "my-project"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    @pytest.mark.parametrize("template", ["default", "minimal", "full", "empty"])
    def test_project_create_template(self, tmp_path, monkeypatch, template):
        """测试不同模板创建"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "create", f"project-{template}", "--template", template],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_project_create_with_config(self, tmp_path, monkeypatch):
        """测试带配置创建"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "create", "project-config", "--config", "config.yaml"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestProjectList:
    """S03-T011-T020: 项目列表"""
    
    def test_project_list_basic(self, tmp_path, monkeypatch):
        """测试列出项目"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "list"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    @pytest.mark.parametrize("filter_type", ["active", "archived", "all"])
    def test_project_list_filter(self, tmp_path, monkeypatch, filter_type):
        """测试项目列表过滤"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "list", "--filter", filter_type],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestProjectShow:
    """S03-T021-T030: 项目详情"""
    
    def test_project_show_basic(self, tmp_path, monkeypatch):
        """测试显示项目详情"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/test-project", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "show", "test-project"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_project_show_with_todos(self, tmp_path, monkeypatch):
        """测试显示项目及TODO"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/test-project", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "show", "test-project", "--todos"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestProjectUpdate:
    """S03-T031-T040: 项目更新"""
    
    def test_project_update_name(self, tmp_path, monkeypatch):
        """测试更新项目名称"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/old-name", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "update", "old-name", "--name", "new-name"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    @pytest.mark.parametrize("field", ["description", "version", "status", "owner"])
    def test_project_update_field(self, tmp_path, monkeypatch, field):
        """测试更新项目字段"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/test-project", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "update", "test-project", f"--{field}", "new-value"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestProjectDelete:
    """S03-T041-T045: 项目删除"""
    
    def test_project_delete_basic(self, tmp_path, monkeypatch):
        """测试删除项目"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/to-delete", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "delete", "to-delete", "--force"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_project_delete_with_backup(self, tmp_path, monkeypatch):
        """测试带备份删除"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/to-delete", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "delete", "to-delete", "--backup"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestProjectArchive:
    """S03-T046-T050: 项目归档"""
    
    def test_project_archive_basic(self, tmp_path, monkeypatch):
        """测试归档项目"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/test-project", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "archive", "test-project"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_project_unarchive(self, tmp_path, monkeypatch):
        """测试恢复归档项目"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/test-project", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "unarchive", "test-project"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestProjectStatus:
    """S03-T051-T060: 项目状态"""
    
    @pytest.mark.parametrize("status", ["planning", "development", "testing", "released", "archived"])
    def test_project_status_transition(self, tmp_path, monkeypatch, status):
        """测试项目状态转换"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/test-project", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "status", "test-project", status],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestProjectMembers:
    """S03-T061-T070: 项目成员"""
    
    def test_project_member_add(self, tmp_path, monkeypatch):
        """测试添加成员"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/test-project", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "member", "test-project", "add", "user1"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_project_member_remove(self, tmp_path, monkeypatch):
        """测试移除成员"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/test-project", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "member", "test-project", "remove", "user1"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_project_member_list(self, tmp_path, monkeypatch):
        """测试列出成员"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/test-project", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "member", "test-project", "list"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestProjectMilestone:
    """S03-T071-T080: 项目里程碑"""
    
    def test_project_milestone_create(self, tmp_path, monkeypatch):
        """测试创建里程碑"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/test-project", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "milestone", "test-project", "create", "M1"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_project_milestone_complete(self, tmp_path, monkeypatch):
        """测试完成里程碑"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/test-project", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "milestone", "test-project", "complete", "M1"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestProjectConfig:
    """S03-T081-T090: 项目配置"""
    
    def test_project_config_show(self, tmp_path, monkeypatch):
        """测试显示配置"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/test-project", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "config", "test-project"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_project_config_set(self, tmp_path, monkeypatch):
        """测试设置配置"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/test-project", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "config", "test-project", "set", "key=value"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestProjectStats:
    """S03-T091-T096: 项目统计"""
    
    def test_project_stats_basic(self, tmp_path, monkeypatch):
        """测试项目统计"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/test-project", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "stats"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0

    def test_project_stats_detailed(self, tmp_path, monkeypatch):
        """测试详细统计"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state/projects/test-project", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "project", "stats", "--detailed"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0
