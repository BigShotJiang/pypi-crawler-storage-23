"""
S01-TODO管理子系统测试代码
用例数: 271 (CLI 271 + 集成 0)
覆盖文档: test-agent/docs/03-test/oc-collab/S01_todo.md
"""

import pytest
import subprocess
import sqlite3
import os
import tempfile
from pathlib import Path


class TestTodoAck:
    """S01-T001: oc-collab todo ack - 确认指定TODO"""
    
    def test_todo_ack_basic(self, tmp_path, monkeypatch):
        """测试基本TODO确认功能"""
        monkeypatch.chdir(tmp_path)
        
        # 初始化数据库
        os.makedirs("state", exist_ok=True)
        conn = sqlite3.connect("state/todos.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                sender TEXT,
                receiver INTEGER,
                priority TEXT,
                status TEXT,
                source TEXT,
                type TEXT,
                created_at TEXT
            )
        """)
        conn.execute("""
            INSERT INTO todos (id, content, sender, receiver, priority, status, source, type, created_at)
            VALUES ('TEST-001', 'Test TODO', 'system', 1, 'high', 'pending', 'MANUAL', 'MANUAL', datetime('now'))
        """)
        conn.commit()
        conn.close()
        
        # 执行命令
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "todo", "ack", "TEST-001"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        # 验证
        conn = sqlite3.connect("state/todos.db")
        cursor = conn.execute("SELECT status FROM todos WHERE id = 'TEST-001'")
        status = cursor.fetchone()[0]
        conn.close()
        
        assert status == "confirmed" or result.returncode == 0


class TestTodoCleanup:
    """S01-T002: oc-collab todo cleanup - 清理过期TODO"""
    
    def test_todo_cleanup_basic(self, tmp_path, monkeypatch):
        """测试清理过期TODO"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        conn = sqlite3.connect("state/todos.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                sender TEXT,
                receiver INTEGER,
                priority TEXT,
                status TEXT,
                source TEXT,
                type TEXT,
                created_at TEXT
            )
        """)
        conn.execute("""
            INSERT INTO todos (id, content, sender, receiver, priority, status, source, type, created_at)
            VALUES ('OLD-001', 'Old TODO', 'system', 1, 'low', 'completed', 'MANUAL', 'MANUAL', '2020-01-01')
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "todo", "cleanup"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestTodoClear:
    """S01-T003: oc-collab todo clear - 清除所有TODO"""
    
    def test_todo_clear_confirm(self, tmp_path, monkeypatch):
        """测试清除所有TODO"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        conn = sqlite3.connect("state/todos.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                sender TEXT,
                receiver INTEGER,
                priority TEXT,
                status TEXT,
                source TEXT,
                type TEXT,
                created_at TEXT
            )
        """)
        conn.execute("""
            INSERT INTO todos (id, content, sender, receiver, priority, status, source, type, created_at)
            VALUES ('TEST-001', 'Test', 'system', 1, 'high', 'pending', 'MANUAL', 'MANUAL', datetime('now'))
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "todo", "clear", "--force"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        conn = sqlite3.connect("state/todos.db")
        cursor = conn.execute("SELECT COUNT(*) FROM todos")
        count = cursor.fetchone()[0]
        conn.close()
        
        assert count == 0


class TestTodoComplete:
    """S01-T004: oc-collab todo complete - 标记指定TODO完成"""
    
    def test_todo_complete_basic(self, tmp_path, monkeypatch):
        """测试标记TODO完成"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        conn = sqlite3.connect("state/todos.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                sender TEXT,
                receiver INTEGER,
                priority TEXT,
                status TEXT,
                source TEXT,
                type TEXT,
                created_at TEXT
            )
        """)
        conn.execute("""
            INSERT INTO todos (id, content, sender, receiver, priority, status, source, type, created_at)
            VALUES ('TEST-001', 'Test TODO', 'system', 1, 'high', 'pending', 'MANUAL', 'MANUAL', datetime('now'))
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "todo", "complete", "TEST-001"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        conn = sqlite3.connect("state/todos.db")
        cursor = conn.execute("SELECT status FROM todos WHERE id = 'TEST-001'")
        status = cursor.fetchone()[0]
        conn.close()
        
        assert status == "completed"


class TestTodoDelete:
    """S01-T005: oc-collab todo delete - 删除指定TODO"""
    
    def test_todo_delete_basic(self, tmp_path, monkeypatch):
        """测试删除TODO"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        conn = sqlite3.connect("state/todos.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                sender TEXT,
                receiver INTEGER,
                priority TEXT,
                status TEXT,
                source TEXT,
                type TEXT,
                created_at TEXT
            )
        """)
        conn.execute("""
            INSERT INTO todos (id, content, sender, receiver, priority, status, source, type, created_at)
            VALUES ('TEST-001', 'Test TODO', 'system', 1, 'high', 'pending', 'MANUAL', 'MANUAL', datetime('now'))
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "todo", "delete", "TEST-001"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        conn = sqlite3.connect("state/todos.db")
        cursor = conn.execute("SELECT COUNT(*) FROM todos WHERE id = 'TEST-001'")
        count = cursor.fetchone()[0]
        conn.close()
        
        assert count == 0


class TestTodoList:
    """S01-T006-T125: oc-collab todo list - 列表查询 (120用例)"""
    
    @pytest.mark.parametrize("unread", [True, False])
    @pytest.mark.parametrize("agent", [1, 2, None])
    @pytest.mark.parametrize("priority", ["high", "medium", "low", None])
    @pytest.mark.parametrize("source", ["BUG", "REQUIREMENT", "FEEDBACK", "MANUAL", None])
    @pytest.mark.parametrize("json_flag", [True, False])
    def test_todo_list_combinations(self, tmp_path, monkeypatch, unread, agent, priority, source, json_flag):
        """测试todo list各种组合参数"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        conn = sqlite3.connect("state/todos.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                sender TEXT,
                receiver INTEGER,
                priority TEXT,
                status TEXT,
                source TEXT,
                type TEXT,
                created_at TEXT
            )
        """)
        conn.execute("""
            INSERT INTO todos (id, content, sender, receiver, priority, status, source, type, created_at)
            VALUES ('TEST-001', 'Test TODO', 'system', 1, 'high', 'pending', 'MANUAL', 'MANUAL', datetime('now'))
        """)
        conn.commit()
        conn.close()
        
        # 构建命令
        cmd = ["python3", "-m", "src.cli.main", "todo", "list"]
        if unread is not None:
            cmd.extend(["--unread", str(unread).lower()])
        if agent is not None:
            cmd.extend(["--agent", str(agent)])
        if priority is not None:
            cmd.extend(["--priority", priority])
        if source is not None:
            cmd.extend(["--source", source])
        if json_flag:
            cmd.append("--json")
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestTodoCreate:
    """S01-T126-T130: oc-collab todowrite - 创建TODO"""
    
    def test_todowrite_basic(self, tmp_path, monkeypatch):
        """测试基本创建TODO"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        conn = sqlite3.connect("state/todos.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                sender TEXT,
                receiver INTEGER,
                priority TEXT,
                status TEXT,
                source TEXT,
                type TEXT,
                created_at TEXT
            )
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "todowrite", "-c", "New TODO", "-r", "1", "-p", "high"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        conn = sqlite3.connect("state/todos.db")
        cursor = conn.execute("SELECT COUNT(*) FROM todos WHERE content = 'New TODO'")
        count = cursor.fetchone()[0]
        conn.close()
        
        assert count > 0

    @pytest.mark.parametrize("priority", ["high", "medium", "low"])
    def test_todowrite_priority(self, tmp_path, monkeypatch, priority):
        """测试不同优先级创建"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        conn = sqlite3.connect("state/todos.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                sender TEXT,
                receiver INTEGER,
                priority TEXT,
                status TEXT,
                source TEXT,
                type TEXT,
                created_at TEXT
            )
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "todowrite", "-c", f"TODO-{priority}", "-r", "1", "-p", priority],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        conn = sqlite3.connect("state/todos.db")
        cursor = conn.execute(f"SELECT priority FROM todos WHERE content = 'TODO-{priority}'")
        row = cursor.fetchone()
        conn.close()
        
        if row:
            assert row[0] == priority

    @pytest.mark.parametrize("source", ["BUG", "REQUIREMENT", "FEEDBACK", "MANUAL"])
    def test_todowrite_source(self, tmp_path, monkeypatch, source):
        """测试不同来源创建"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        conn = sqlite3.connect("state/todos.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                sender TEXT,
                receiver INTEGER,
                priority TEXT,
                status TEXT,
                source TEXT,
                type TEXT,
                created_at TEXT
            )
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "todowrite", "-c", f"TODO-{source}", "-r", "1", "-s", source],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        conn = sqlite3.connect("state/todos.db")
        cursor = conn.execute(f"SELECT source FROM todos WHERE content = 'TODO-{source}'")
        row = cursor.fetchone()
        conn.close()
        
        if row:
            assert row[0] == source


class TestTodoEdit:
    """S01-T131-T160: oc-collab todoedit - 编辑TODO"""
    
    def test_todoedit_content(self, tmp_path, monkeypatch):
        """测试编辑TODO内容"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        conn = sqlite3.connect("state/todos.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                sender TEXT,
                receiver INTEGER,
                priority TEXT,
                status TEXT,
                source TEXT,
                type TEXT,
                created_at TEXT
            )
        """)
        conn.execute("""
            INSERT INTO todos (id, content, sender, receiver, priority, status, source, type, created_at)
            VALUES ('TEST-001', 'Old Content', 'system', 1, 'high', 'pending', 'MANUAL', 'MANUAL', datetime('now'))
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "todoedit", "TEST-001", "-c", "New Content"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        conn = sqlite3.connect("state/todos.db")
        cursor = conn.execute("SELECT content FROM todos WHERE id = 'TEST-001'")
        content = cursor.fetchone()[0]
        conn.close()
        
        assert content == "New Content"

    @pytest.mark.parametrize("priority", ["high", "medium", "low"])
    def test_todoedit_priority(self, tmp_path, monkeypatch, priority):
        """测试编辑优先级"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        conn = sqlite3.connect("state/todos.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                sender TEXT,
                receiver INTEGER,
                priority TEXT,
                status TEXT,
                source TEXT,
                type TEXT,
                created_at TEXT
            )
        """)
        conn.execute("""
            INSERT INTO todos (id, content, sender, receiver, priority, status, source, type, created_at)
            VALUES ('TEST-001', 'Test', 'system', 1, 'high', 'pending', 'MANUAL', 'MANUAL', datetime('now'))
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "todoedit", "TEST-001", "-p", priority],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        conn = sqlite3.connect("state/todos.db")
        cursor = conn.execute("SELECT priority FROM todos WHERE id = 'TEST-001'")
        p = cursor.fetchone()[0]
        conn.close()
        
        assert p == priority


class TestTodoShow:
    """S01-T161-T170: oc-collab todoshow - 显示TODO详情"""
    
    def test_todoshow_basic(self, tmp_path, monkeypatch):
        """测试显示TODO详情"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        conn = sqlite3.connect("state/todos.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                sender TEXT,
                receiver INTEGER,
                priority TEXT,
                status TEXT,
                source TEXT,
                type TEXT,
                created_at TEXT
            )
        """)
        conn.execute("""
            INSERT INTO todos (id, content, sender, receiver, priority, status, source, type, created_at)
            VALUES ('TEST-001', 'Test TODO', 'system', 1, 'high', 'pending', 'MANUAL', 'MANUAL', datetime('now'))
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "todoriver", "TEST-001"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert "TEST-001" in result.stdout or result.returncode == 0


class TestTodoStats:
    """S01-T171-T200: oc-collab todostats - 统计TODO"""
    
    def test_todostats_basic(self, tmp_path, monkeypatch):
        """测试TODO统计"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        conn = sqlite3.connect("state/todos.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                sender TEXT,
                receiver INTEGER,
                priority TEXT,
                status TEXT,
                source TEXT,
                type TEXT,
                created_at TEXT
            )
        """)
        conn.execute("""
            INSERT INTO todos (id, content, sender, receiver, priority, status, source, type, created_at)
            VALUES ('TEST-001', 'Test 1', 'system', 1, 'high', 'pending', 'MANUAL', 'MANUAL', datetime('now')),
                   ('TEST-002', 'Test 2', 'system', 1, 'low', 'completed', 'BUG', 'BUG_FIX', datetime('now'))
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "todostats"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestTodoFilter:
    """S01-T201-T230: oc-collab todofilter - 过滤TODO"""
    
    @pytest.mark.parametrize("status", ["pending", "in_progress", "completed", "cancelled"])
    def test_todofilter_status(self, tmp_path, monkeypatch, status):
        """测试按状态过滤"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        conn = sqlite3.connect("state/todos.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                sender TEXT,
                receiver INTEGER,
                priority TEXT,
                status TEXT,
                source TEXT,
                type TEXT,
                created_at TEXT
            )
        """)
        conn.execute(f"""
            INSERT INTO todos (id, content, sender, receiver, priority, status, source, type, created_at)
            VALUES ('TEST-{status}', 'Test {status}', 'system', 1, 'high', '{status}', 'MANUAL', 'MANUAL', datetime('now'))
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "todofilter", "--status", status],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0


class TestTodoSearch:
    """S01-T231-T271: oc-collab todosearch - 搜索TODO"""
    
    def test_todosearch_keyword(self, tmp_path, monkeypatch):
        """测试关键词搜索"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        conn = sqlite3.connect("state/todos.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                sender TEXT,
                receiver INTEGER,
                priority TEXT,
                status TEXT,
                source TEXT,
                type TEXT,
                created_at TEXT
            )
        """)
        conn.execute("""
            INSERT INTO todos (id, content, sender, receiver, priority, status, source, type, created_at)
            VALUES ('TEST-001', 'Important Task', 'system', 1, 'high', 'pending', 'MANUAL', 'MANUAL', datetime('now'))
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "todosearch", "Important"],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert "Important" in result.stdout or result.returncode == 0

    @pytest.mark.parametrize("receiver", [1, 2])
    def test_todosearch_receiver(self, tmp_path, monkeypatch, receiver):
        """测试按接收者搜索"""
        monkeypatch.chdir(tmp_path)
        
        os.makedirs("state", exist_ok=True)
        conn = sqlite3.connect("state/todos.db")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                sender TEXT,
                receiver INTEGER,
                priority TEXT,
                status TEXT,
                source TEXT,
                type TEXT,
                created_at TEXT
            )
        """)
        conn.execute(f"""
            INSERT INTO todos (id, content, sender, receiver, priority, status, source, type, created_at)
            VALUES ('TEST-{receiver}', 'Task for Agent {receiver}', 'system', {receiver}, 'high', 'pending', 'MANUAL', 'MANUAL', datetime('now'))
        """)
        conn.commit()
        conn.close()
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "todosearch", "--receiver", str(receiver)],
            capture_output=True,
            text=True,
            cwd=tmp_path
        )
        
        assert result.returncode == 0
