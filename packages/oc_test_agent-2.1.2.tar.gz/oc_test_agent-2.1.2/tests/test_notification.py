"""
通知模块单元测试
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch
from src.core.notification.webhook import WebhookManager, WebhookConfig, WebhookPayload


class TestWebhookConfig:
    """Webhook配置测试"""
    
    def test_webhook_config_creation(self):
        """测试Webhook配置创建"""
        config = WebhookConfig(
            id="test-1",
            url="http://example.com/webhook",
            events=["test.completed", "test.failed"]
        )
        assert config.id == "test-1"
        assert config.url == "http://example.com/webhook"
        assert len(config.events) == 2
    
    def test_webhook_config_with_secret(self):
        """测试带密钥的Webhook配置"""
        config = WebhookConfig(
            id="test-2",
            url="http://example.com/webhook",
            events=["test.completed"],
            secret="my-secret"
        )
        assert config.secret == "my-secret"


class TestWebhookPayload:
    """Webhook负载测试"""
    
    def test_payload_creation(self):
        """测试负载创建"""
        payload = WebhookPayload(
            event="test.completed",
            test_id="test_123",
            project="pm-agent",
            version="v1.0",
            status="passed",
            passed=10,
            failed=0,
            errors=0,
            duration=5.5
        )
        assert payload.event == "test.completed"
        assert payload.test_id == "test_123"
        assert payload.passed == 10


class TestWebhookManager:
    """Webhook管理器测试"""
    
    def test_add_webhook(self):
        """测试添加Webhook"""
        manager = WebhookManager()
        config = WebhookConfig(
            id="test-1",
            url="http://example.com/webhook",
            events=["test.completed"]
        )
        manager.add_webhook(config)
        assert len(manager.webhooks) == 1
    
    def test_remove_webhook(self):
        """测试移除Webhook"""
        manager = WebhookManager()
        config = WebhookConfig(
            id="test-1",
            url="http://example.com/webhook",
            events=["test.completed"]
        )
        manager.add_webhook(config)
        result = manager.remove_webhook("test-1")
        assert result is True
        assert len(manager.webhooks) == 0
    
    def test_remove_nonexistent_webhook(self):
        """测试移除不存在的Webhook"""
        manager = WebhookManager()
        result = manager.remove_webhook("nonexistent")
        assert result is False
    
    def test_should_send_event_match(self):
        """测试事件匹配"""
        manager = WebhookManager()
        config = WebhookConfig(
            id="test-1",
            url="http://example.com/webhook",
            events=["test.completed"]
        )
        assert manager.should_send(config, "test.completed") is True
    
    def test_should_send_event_wildcard(self):
        """测试通配符事件"""
        manager = WebhookManager()
        config = WebhookConfig(
            id="test-1",
            url="http://example.com/webhook",
            events=["*"]
        )
        assert manager.should_send(config, "any.event") is True
    
    def test_build_payload(self):
        """测试构建负载"""
        manager = WebhookManager()
        
        mock_result = Mock()
        mock_result.id = "test_123"
        mock_result.project = "pm-agent"
        mock_result.version = "v1.0"
        mock_result.status = "passed"
        mock_result.passed = 10
        mock_result.failed = 0
        mock_result.errors = 0
        mock_result.duration = 5.5
        
        payload = manager.build_payload(mock_result)
        
        assert payload.test_id == "test_123"
        assert payload.project == "pm-agent"
        assert payload.status == "passed"


class TestNotificationIntegration:
    """通知集成测试"""
    
    def test_get_notification_manager_singleton(self):
        """测试通知管理器单例"""
        from src.core.notification import get_notification_manager
        manager1 = get_notification_manager()
        manager2 = get_notification_manager()
        assert manager1 is manager2
    
    def test_notification_disabled(self):
        """测试通知禁用"""
        manager = WebhookManager()
        manager._enabled = False
        
        mock_result = Mock()
        mock_result.id = "test_123"
        mock_result.project = "pm-agent"
        mock_result.version = "v1.0"
        mock_result.status = "passed"
        mock_result.passed = 10
        mock_result.failed = 0
        mock_result.errors = 0
        mock_result.duration = 5.5
        
        # 不应该抛出异常
        loop = asyncio.new_event_loop()
        loop.run_until_complete(manager.notify(mock_result))
        loop.close()
