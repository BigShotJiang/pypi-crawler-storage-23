"""Test-Agent 单元测试 - 执行引擎和日志模块。"""

import pytest
import tempfile
import shutil
import json
import time
import subprocess
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.core.execution import ExecutionEngine
from src.core.agent import AgentManager
from src.core.isolation import DatabaseManager
from src.utils.logger import LogManager


class TestExecutionEngine:
    """ExecutionEngine 测试类。"""
    
    @pytest.fixture
    def temp_dir(self):
        """创建临时目录。"""
        temp = tempfile.mkdtemp()
        yield temp
        shutil.rmtree(temp, ignore_errors=True)
    
    @pytest.fixture
    def engine(self, temp_dir):
        """创建ExecutionEngine实例。"""
        return ExecutionEngine("test_project", max_workers=5)
    
    def test_init(self, temp_dir):
        """TC-EE-001: 初始化执行引擎。"""
        engine = ExecutionEngine("test_project", max_workers=3)
        assert engine.project_id == "test_project"
        assert engine.max_workers == 3
    
    def test_run_no_agents(self, engine):
        """TC-EE-002: 无Agent执行。"""
        result = engine.run([], ["echo test"])
        assert result["status"] == "error"
        assert "No agents" in result["error"]
    
    def test_run_no_commands(self, engine):
        """TC-EE-003: 无命令执行。"""
        result = engine.run(["test_agent_001"], [])
        assert result["status"] == "error"
        assert "No commands" in result["error"]
    
    def test_run_unregistered_agent(self, engine):
        """TC-EE-004: Agent未注册。"""
        result = engine.run(["test_nonexistent_agent_xyz"], ["echo test"])
        assert "test_nonexistent_agent_xyz" in result["results"]
        assert result["results"]["test_nonexistent_agent_xyz"]["status"] == "error"
    
    def test_generate_summary_all_passed(self, engine):
        """TC-EE-005: 生成摘要-全部通过。"""
        results = {
            "agent1": {"status": "success"},
            "agent2": {"status": "success"}
        }
        summary = engine._generate_summary(results)
        assert summary["total"] == 2
        assert summary["passed"] == 2
        assert summary["failed"] == 0
    
    def test_generate_summary_with_failures(self, engine):
        """TC-EE-006: 生成摘要-有失败。"""
        results = {
            "agent1": {"status": "success"},
            "agent2": {"status": "failed"},
            "agent3": {"status": "error"}
        }
        summary = engine._generate_summary(results)
        assert summary["total"] == 3
        assert summary["passed"] == 1
        assert summary["failed"] == 1
        assert summary["error"] == 1
    
    def test_run_async_success(self, temp_dir):
        """TC-EE-007: 异步执行成功。"""
        engine = ExecutionEngine("test_project", max_workers=5)
        engine.agent_manager.register("test_async_agent_001", {})
        
        try:
            success, result = engine.run_async("test_async_agent_001", "echo test")
            assert success is True
        finally:
            engine.cleanup()
            engine.agent_manager.unregister("test_async_agent_001")
    
    def test_run_async_unregistered_agent(self, temp_dir):
        """TC-EE-008: 异步执行-未注册Agent。"""
        engine = ExecutionEngine("test_project", max_workers=5)
        
        try:
            success, result = engine.run_async("test_unregistered_xyz", "echo test")
            assert success is False or "error" in result
        finally:
            engine.cleanup()
    
    def test_collect_results(self, engine):
        """TC-EE-009: 收集结果。"""
        engine.results = {"agent1": {"status": "success"}}
        results = engine.collect_results()
        assert results == {"agent1": {"status": "success"}}
    
    def test_cleanup(self, temp_dir):
        """TC-EE-010: 清理资源。"""
        engine = ExecutionEngine("test_project", max_workers=5)
        engine.cleanup()
        assert engine.agent_manager._agent_pool is None


class TestLogManager:
    """LogManager 测试类。"""
    
    @pytest.fixture
    def temp_dir(self):
        """创建临时目录。"""
        temp = tempfile.mkdtemp()
        yield temp
        shutil.rmtree(temp, ignore_errors=True)
    
    @pytest.fixture
    def log_manager(self, temp_dir):
        """创建LogManager实例。"""
        return LogManager(Path(temp_dir))
    
    def test_init(self, temp_dir):
        """TC-LM-001: 初始化日志管理器。"""
        lm = LogManager(Path(temp_dir))
        assert lm.log_dir.exists()
    
    def test_get_logger(self, log_manager):
        """TC-LM-002: 获取Logger实例。"""
        logger = log_manager.get_logger("test_logger", "test.log")
        assert logger is not None
        assert logger.name == "test_logger"
    
    def test_get_logger_cached(self, log_manager):
        """TC-LM-003: Logger缓存。"""
        logger1 = log_manager.get_logger("test_logger")
        logger2 = log_manager.get_logger("test_logger")
        assert logger1 is logger2
    
    def test_log_error(self, log_manager):
        """TC-LM-004: 记录错误日志。"""
        log_manager.log_error(
            "test_project",
            "test_agent",
            "T001",
            "Test error message",
            {"details": "test"}
        )
        
        error_log = log_manager.log_dir / "test_project" / "error.log"
        assert error_log.exists()
        
        with open(error_log, 'r') as f:
            content = f.read()
            assert "T001" in content
            assert "Test error message" in content
    
    def test_log_test_result(self, log_manager):
        """TC-LM-005: 记录测试结果。"""
        result = {
            "status": "success",
            "tests_run": 10,
            "tests_passed": 10
        }
        
        log_manager.log_test_result("test_project", "test_agent", result)
        
        result_file = log_manager.log_dir / "test_project" / "test_agent_result.json"
        assert result_file.exists()
        
        with open(result_file, 'r') as f:
            saved = json.load(f)
            assert saved["status"] == "success"
    
    def test_log_error_creates_directory(self, log_manager):
        """TC-LM-006: 错误日志自动创建目录。"""
        log_manager.log_error("test_project2", "test_agent", "T001", "Error")
        
        assert (log_manager.log_dir / "test_project2").exists()
    
    def test_log_result_creates_directory(self, log_manager):
        """TC-LM-007: 结果日志自动创建目录。"""
        log_manager.log_test_result("test_project3", "test_agent", {"status": "ok"})
        
        assert (log_manager.log_dir / "test_project3").exists()
    
    def test_multiple_loggers(self, log_manager):
        """TC-LM-008: 多个Logger实例。"""
        logger1 = log_manager.get_logger("logger1", "log1.log")
        logger2 = log_manager.get_logger("logger2", "log2.log")
        
        assert logger1 is not logger2
        assert logger1.name == "logger1"
        assert logger2.name == "logger2"


class TestExecutionEngineIntegration:
    """ExecutionEngine 集成测试类。"""
    
    @pytest.fixture
    def temp_dir(self):
        """创建临时目录。"""
        temp = tempfile.mkdtemp()
        yield temp
        shutil.rmtree(temp, ignore_errors=True)
    
    def test_execute_agent_test_success(self, temp_dir):
        """TC-EI-001: Agent测试执行成功。"""
        engine = ExecutionEngine("test_project", max_workers=5)
        
        try:
            result = engine._execute_agent_test(
                "test_agent",
                "echo 'test success'",
                "test_project"
            )
            
            assert result["status"] == "success"
            assert result["command"] == "echo 'test success'"
            assert result["returncode"] == 0
        finally:
            engine.cleanup()
    
    def test_execute_agent_test_failure(self, temp_dir):
        """TC-EI-002: Agent测试执行失败。"""
        engine = ExecutionEngine("test_project", max_workers=5)
        
        try:
            result = engine._execute_agent_test(
                "test_agent",
                "exit 1",
                "test_project"
            )
            
            assert result["status"] == "failed"
            assert result["returncode"] == 1
        finally:
            engine.cleanup()
    
    def test_execute_agent_test_timeout(self, temp_dir):
        """TC-EI-003: Agent测试执行超时。"""
        engine = ExecutionEngine("test_project", max_workers=5)
        
        try:
            with patch('subprocess.run') as mock_run:
                mock_run.side_effect = subprocess.TimeoutExpired("cmd", 300)
                
                result = engine._execute_agent_test(
                    "test_agent",
                    "sleep 1000",
                    "test_project"
                )
                
                assert result["status"] == "error"
                assert "timeout" in result["error"].lower()
        finally:
            engine.cleanup()
    
    def test_execute_agent_test_exception(self, temp_dir):
        """TC-EI-004: Agent测试执行异常。"""
        engine = ExecutionEngine("test_project", max_workers=5)
        
        try:
            with patch('subprocess.run') as mock_run:
                mock_run.side_effect = Exception("Test exception")
                
                result = engine._execute_agent_test(
                    "test_agent",
                    "echo test",
                    "test_project"
                )
                
                assert result["status"] == "error"
                assert "Test exception" in result["error"]
        finally:
            engine.cleanup()


class TestDatabaseManagerExtended:
    """DatabaseManager 扩展测试类 - 共享数据库方案。"""
    
    @pytest.fixture
    def temp_dir(self):
        """创建临时目录。"""
        temp = tempfile.mkdtemp()
        yield temp
        shutil.rmtree(temp, ignore_errors=True)
    
    @pytest.fixture
    def dm(self, temp_dir):
        """创建DatabaseManager实例。"""
        return DatabaseManager(base_path=temp_dir)
    
    def test_get_connection_creates_new(self, dm):
        """TC-DBE-001: 获取新连接。"""
        conn1 = dm.get_connection()
        conn2 = dm.get_connection()
        
        assert conn1 is conn2
    
    def test_record_heartbeat(self, dm):
        """TC-DBE-002: 记录心跳。"""
        dm.record_heartbeat(
            "test_ns",
            "test_agent",
            "test_project",
            "running",
            45.5,
            1024.0
        )
        
        conn = dm.get_connection()
        cursor = conn.execute("SELECT * FROM agent_heartbeats WHERE agent_id = 'test_agent'")
        heartbeat = cursor.fetchone()
        
        assert heartbeat is not None
        assert heartbeat["status"] == "running"
        assert heartbeat["cpu_usage"] == 45.5
    
    def test_record_heartbeat_multiple(self, dm):
        """TC-DBE-003: 多次记录心跳。"""
        for i in range(5):
            dm.record_heartbeat(
                "test_ns",
                f"agent_{i}",
                "test_project",
                "running"
            )
        
        conn = dm.get_connection()
        cursor = conn.execute("SELECT COUNT(*) FROM agent_heartbeats")
        count = cursor.fetchone()[0]
        
        assert count == 5
    
    def test_get_tasks_by_project_empty(self, dm):
        """TC-DBE-004: 获取空项目任务。"""
        tasks = dm.get_tasks_by_project("test_ns", "empty_project")
        assert len(tasks) == 0
    
    def test_cleanup_nonexistent_namespace(self, dm):
        """TC-DBE-005: 清理不存在的命名空间。"""
        success = dm.cleanup_namespace("nonexistent")
        assert success is False
    
    def test_shared_db_concurrent_namespace(self, dm):
        """TC-DBE-006: 共享数据库-多命名空间并发。"""
        dm.create_task("ns1", "t1", "p1", "a1", "c1")
        dm.create_task("ns2", "t2", "p2", "a2", "c2")
        
        ns1_tasks = dm.get_tasks_by_namespace("ns1")
        ns2_tasks = dm.get_tasks_by_namespace("ns2")
        
        assert len(ns1_tasks) == 1
        assert len(ns2_tasks) == 1
        assert ns1_tasks[0]["namespace"] == "ns1"
        assert ns2_tasks[0]["namespace"] == "ns2"


class TestIPCManagerExtended:
    """IPCManager 扩展测试类。"""
    
    def test_send_to_nonexistent_queue(self):
        """TC-IPCE-001: 发送到不存在的队列。"""
        from src.core.ipc import IPCManager
        ipc = IPCManager("test_ns")
        
        result = ipc.send("new_queue", {"data": "test"}, timeout=0.5)
        assert result is True
        
        received = ipc.receive("new_queue", timeout=1)
        assert received is not None
    
    def test_receive_timeout(self):
        """TC-IPCE-002: 接收超时。"""
        from src.core.ipc import IPCManager
        ipc = IPCManager("test_ns")
        ipc.create_queue("empty_queue")
        
        received = ipc.receive("empty_queue", timeout=0.1)
        assert received is None
    
    def test_get_queue_stats(self):
        """TC-IPCE-003: 队列统计。"""
        from src.core.ipc import IPCManager
        ipc = IPCManager("test_ns")
        ipc.create_queue("queue1")
        ipc.send("queue1", {"data": "test"})
        
        stats = ipc.get_queue_stats("queue1")
        
        assert stats["queue_id"] == "queue1"
        assert stats["exists"] is True
        assert stats["messages_sent"] == 1
    
    def test_get_nonexistent_queue_stats(self):
        """TC-IPCE-004: 不存在队列的统计。"""
        from src.core.ipc import IPCManager
        ipc = IPCManager("test_ns")
        
        stats = ipc.get_queue_stats("nonexistent")
        
        assert stats["exists"] is False
        assert stats["messages_sent"] == 0
    
    def test_close_all_queues(self):
        """TC-IPCE-005: 关闭所有队列。"""
        from src.core.ipc import IPCManager
        ipc = IPCManager("test_ns")
        ipc.create_queue("queue1")
        ipc.create_queue("queue2")
        
        ipc.close_all()
        
        assert len(ipc.list_queues()) == 0


class TestSharedDataManager:
    """SharedDataManager 测试类。"""
    
    def test_set_and_get(self):
        """TC-SDM-001: 设置和获取数据。"""
        from src.core.ipc import SharedDataManager
        sdm = SharedDataManager()
        
        sdm.set("key1", "value1")
        assert sdm.get("key1") == "value1"
    
    def test_get_default(self):
        """TC-SDM-002: 获取默认值。"""
        from src.core.ipc import SharedDataManager
        sdm = SharedDataManager()
        
        assert sdm.get("nonexistent", "default") == "default"
    
    def test_delete(self):
        """TC-SDM-003: 删除数据。"""
        from src.core.ipc import SharedDataManager
        sdm = SharedDataManager()
        
        sdm.set("key1", "value1")
        assert sdm.delete("key1") is True
        assert sdm.get("key1") is None
    
    def test_delete_nonexistent(self):
        """TC-SDM-004: 删除不存在的数据。"""
        from src.core.ipc import SharedDataManager
        sdm = SharedDataManager()
        
        assert sdm.delete("nonexistent") is False
    
    def test_keys(self):
        """TC-SDM-005: 获取所有键。"""
        from src.core.ipc import SharedDataManager
        sdm = SharedDataManager()
        
        sdm.set("key1", "value1")
        sdm.set("key2", "value2")
        
        keys = sdm.keys()
        assert "key1" in keys
        assert "key2" in keys
    
    def test_clear(self):
        """TC-SDM-006: 清空所有数据。"""
        from src.core.ipc import SharedDataManager
        sdm = SharedDataManager()
        
        sdm.set("key1", "value1")
        sdm.set("key2", "value2")
        sdm.clear()
        
        assert len(sdm.keys()) == 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
