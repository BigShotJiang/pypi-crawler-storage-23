"""
oc-collab HTTP API测试

测试oc-collab提供的HTTP API服务
"""

import pytest
import os
import sys
import subprocess
import requests
import time
import signal
from pathlib import Path

os.environ["OC_SKIP_SKILL_CHECK"] = "1"

BASE_URL = "http://localhost:8000"
TEST_TODO_ID = "test-todo-001"

OC_COLLAB_PATH = os.environ.get("OC_COLLAB_PATH", "/app")


class TestOcCollabAPI:
    """oc-collab HTTP API测试"""

    @pytest.fixture(scope="class", autouse=True)
    def setup_api_server(self):
        """启动API服务作为前置条件"""
        port = 8000
        
        proc = subprocess.Popen(
            ["python3", "-m", "src.cli.main", "serve", "--port", str(port)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=OC_COLLAB_PATH
        )
        
        time.sleep(3)
        
        yield proc
        
        proc.send_signal(signal.SIGTERM)
        proc.wait(timeout=5)

    def test_api_001_health_check(self):
        """TC-API-001: 健康检查"""
        resp = requests.get(f"{BASE_URL}/health", timeout=5)
        assert resp.status_code == 200
        data = resp.json()
        assert data.get("status") == "ok"

    def test_api_002_list_todos(self):
        """TC-TODO-001: GET /api/todo/list - 获取TODO列表"""
        resp = requests.get(f"{BASE_URL}/api/todo/list", timeout=5)
        assert resp.status_code == 200
        data = resp.json()
        assert data.get("success") == True

    def test_api_003_get_todo_detail(self):
        """TC-TODO-002: GET /api/todo/{todo_id} - 获取TODO详情"""
        resp = requests.get(f"{BASE_URL}/api/todo/{TEST_TODO_ID}", timeout=5)
        assert resp.status_code in [200, 404]

    def test_api_004_create_todo(self):
        """TC-TODO-003: POST /api/todo/create - 创建TODO"""
        resp = requests.post(
            f"{BASE_URL}/api/todo/create",
            json={"content": "Test TODO", "priority": "medium"},
            timeout=5
        )
        assert resp.status_code in [200, 201]

    def test_api_005_update_todo(self):
        """TC-TODO-004: PUT /api/todo/{todo_id} - 更新TODO"""
        resp = requests.put(
            f"{BASE_URL}/api/todo/{TEST_TODO_ID}",
            json={"content": "Updated TODO"},
            timeout=5
        )
        assert resp.status_code in [200, 404]

    def test_api_006_delete_todo(self):
        """TC-TODO-005: DELETE /api/todo/{todo_id} - 删除TODO"""
        resp = requests.delete(f"{BASE_URL}/api/todo/{TEST_TODO_ID}", timeout=5)
        assert resp.status_code in [200, 404]

    def test_api_007_complete_todo(self):
        """TC-TODO-006: POST /api/todo/{todo_id}/complete - 标记完成"""
        resp = requests.post(f"{BASE_URL}/api/todo/{TEST_TODO_ID}/complete", timeout=5)
        assert resp.status_code in [200, 404]

    def test_api_008_ack_todo(self):
        """TC-TODO-007: POST /api/todo/{todo_id}/ack - 确认TODO"""
        resp = requests.post(f"{BASE_URL}/api/todo/{TEST_TODO_ID}/ack", timeout=5)
        assert resp.status_code in [200, 404]

    def test_api_009_export_todos(self):
        """TC-TODO-008: GET /api/todo/export - 导出TODO数据"""
        resp = requests.get(f"{BASE_URL}/api/todo/export", timeout=5)
        assert resp.status_code == 200
        data = resp.json()
        assert data.get("success") == True

    def test_api_010_404_error(self):
        """TC-ERR-001: 不存在的端点返回404"""
        resp = requests.get(f"{BASE_URL}/api/todo/list/notexist", timeout=5)
        assert resp.status_code == 404

    def test_api_011_400_error(self):
        """TC-ERR-002: 无body创建TODO返回400"""
        resp = requests.post(f"{BASE_URL}/api/todo/create", timeout=5)
        assert resp.status_code in [400, 422]


class TestOcCollabCLIServe:
    """CLI serve命令测试"""

    def test_cli_001_serve_help(self):
        """TC-CLI-001: oc-collab serve --help"""
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "serve", "--help"],
            capture_output=True,
            text=True,
            cwd=OC_COLLAB_PATH
        )
        assert result.returncode == 0

    def test_cli_002_serve_port(self):
        """TC-CLI-002: oc-collab serve --port 9000"""
        proc = subprocess.Popen(
            ["python3", "-m", "src.cli.main", "serve", "--port", "9000"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=OC_COLLAB_PATH
        )
        time.sleep(2)
        proc.terminate()
        assert proc.poll() is None or proc.returncode in [0, -15]
