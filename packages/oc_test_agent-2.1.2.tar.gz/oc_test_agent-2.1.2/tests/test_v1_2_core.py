"""Test-Agent v1.2 补充测试 - 核心服务"""

import pytest
import tempfile
import os
from datetime import datetime
from unittest.mock import Mock, patch, MagicMock
import json

os.environ["TEST_ENV"] = "1"

from src.models.test_result import TestResult, TestStatus
from src.db.database import Database
from src.db.repositories.result_repo import ResultRepository


class TestResultService:
    """测试ResultService"""
    
    @pytest.fixture
    def temp_db(self):
        """创建临时数据库"""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        db = Database(db_path)
        db.init_schema()
        
        yield db
        
        db.close()
        os.unlink(db_path)
    
    def test_save(self, temp_db):
        """测试保存结果"""
        from src.core.result_service import ResultService
        
        svc = ResultService.__new__(ResultService)
        svc.db = temp_db
        svc.repo = ResultRepository(temp_db)
        
        result = TestResult(
            id="test_001",
            project="test-project",
            version="v1.0.0",
            status=TestStatus.PASSED,
            created_at=datetime.now()
        )
        
        test_id = svc.save(result)
        
        assert test_id == "test_001"
    
    def test_get(self, temp_db):
        """测试获取结果"""
        from src.core.result_service import ResultService
        
        svc = ResultService.__new__(ResultService)
        svc.db = temp_db
        svc.repo = ResultRepository(temp_db)
        
        result = TestResult(
            id="test_001",
            project="test-project",
            version="v1.0.0",
            status=TestStatus.PASSED,
            created_at=datetime.now()
        )
        svc.repo.insert(result)
        
        found = svc.get("test_001")
        
        assert found is not None
        assert found.id == "test_001"
    
    def test_query(self, temp_db):
        """测试查询"""
        from src.core.result_service import ResultService
        
        svc = ResultService.__new__(ResultService)
        svc.db = temp_db
        svc.repo = ResultRepository(temp_db)
        
        for i in range(3):
            result = TestResult(
                id=f"test_{i:03d}",
                project="test-project",
                version="v1.0.0",
                status=TestStatus.PASSED,
                created_at=datetime.now()
            )
            svc.repo.insert(result)
        
        results = svc.query(project="test-project", limit=10)
        
        assert len(results) == 3
    
    def test_delete(self, temp_db):
        """测试删除"""
        from src.core.result_service import ResultService
        
        svc = ResultService.__new__(ResultService)
        svc.db = temp_db
        svc.repo = ResultRepository(temp_db)
        
        result = TestResult(
            id="test_001",
            project="test-project",
            version="v1.0.0",
            status=TestStatus.PASSED,
            created_at=datetime.now()
        )
        svc.repo.insert(result)
        
        deleted = svc.delete("test_001")
        
        assert deleted is True
    
    def test_cleanup(self, temp_db):
        """测试清理"""
        from src.core.result_service import ResultService
        
        svc = ResultService.__new__(ResultService)
        svc.db = temp_db
        svc.repo = ResultRepository(temp_db)
        
        deleted = svc.cleanup("2020-01-01", "test-project")
        
        assert deleted == 0


class TestDockerService:
    """测试DockerService"""
    
    def test_is_available_mock(self):
        """测试Docker可用性检查（模拟）"""
        with patch('src.core.docker_service.docker.from_env') as mock_docker:
            mock_client = MagicMock()
            mock_client.ping.return_value = True
            mock_docker.return_value = mock_client
            
            from src.core.docker_service import DockerService
            svc = DockerService()
            
            result = svc.is_available()
            
            assert result is True
    
    def test_image_exists_mock(self):
        """测试镜像存在检查（模拟）"""
        with patch('src.core.docker_service.docker.from_env') as mock_docker:
            mock_client = MagicMock()
            mock_client.images.get.return_value = MagicMock()
            mock_docker.return_value = mock_client
            
            from src.core.docker_service import DockerService
            svc = DockerService()
            
            result = svc.image_exists("test:latest")
            
            assert result is True
    
    def test_build_image_mock(self):
        """测试镜像构建（模拟）"""
        with patch('src.core.docker_service.docker.from_env') as mock_docker:
            mock_client = MagicMock()
            mock_image = MagicMock()
            mock_image.short_id = "abc123"
            mock_client.images.build.return_value = (mock_image, [])
            mock_docker.return_value = mock_client
            
            from src.core.docker_service import DockerService
            svc = DockerService()
            
            result = svc.build_image("/tmp", tag="test:latest")
            
            assert result is True
    
    def test_run_container_mock(self):
        """测试容器运行（模拟）"""
        with patch('src.core.docker_service.docker.from_env') as mock_docker:
            mock_client = MagicMock()
            mock_container = MagicMock()
            mock_container.id = "container123"
            mock_container.short_id = "container123"
            mock_client.containers.run.return_value = mock_container
            mock_docker.return_value = mock_client
            
            from src.core.docker_service import DockerService
            svc = DockerService()
            
            result = svc.run_container("test-image", env={"TEST": "value"})
            
            assert result == "container123"
    
    def test_stop_container_mock(self):
        """测试容器停止（模拟）"""
        with patch('src.core.docker_service.docker.from_env') as mock_docker:
            mock_client = MagicMock()
            mock_client.containers.get.return_value = MagicMock()
            mock_docker.return_value = mock_client
            
            from src.core.docker_service import DockerService
            svc = DockerService()
            
            result = svc.stop_container("container123")
            
            assert result is True
    
    def test_remove_container_mock(self):
        """测试容器删除（模拟）"""
        with patch('src.core.docker_service.docker.from_env') as mock_docker:
            mock_client = MagicMock()
            mock_client.containers.get.return_value = MagicMock()
            mock_docker.return_value = mock_client
            
            from src.core.docker_service import DockerService
            svc = DockerService()
            
            result = svc.remove_container("container123")
            
            assert result is True
    
    def test_get_container_logs_mock(self):
        """测试获取容器日志（模拟）"""
        with patch('src.core.docker_service.docker.from_env') as mock_docker:
            mock_client = MagicMock()
            mock_container = MagicMock()
            mock_container.logs.return_value = b"test log output"
            mock_client.containers.get.return_value = mock_container
            mock_docker.return_value = mock_client
            
            from src.core.docker_service import DockerService
            svc = DockerService()
            
            result = svc.get_container_logs("container123")
            
            assert "test log output" in result


class TestTestExecutor:
    """测试TestExecutor"""
    
    @pytest.fixture
    def temp_db(self):
        """创建临时数据库"""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        db = Database(db_path)
        db.init_schema()
        
        yield db
        
        db.close()
        os.unlink(db_path)
    
    @patch('src.core.test_executor.DockerService')
    def test_execute_build_failed(self, mock_docker, temp_db):
        """测试构建失败"""
        mock_ds = MagicMock()
        mock_ds.build_image.return_value = False
        mock_docker.return_value = mock_ds
        
        from src.core.test_executor import TestExecutor
        
        executor = TestExecutor(
            project="test-project",
            version="v1.0.0",
            project_path="/tmp",
            test_type="unit",
            timeout=60,
            tag="latest"
        )
        executor.docker = mock_ds
        
        result = executor.execute()
        
        assert result.status == TestStatus.ERROR
    
    @patch('src.core.test_executor.DockerService')
    def test_execute_container_failed(self, mock_docker, temp_db):
        """测试容器启动失败"""
        mock_ds = MagicMock()
        mock_ds.build_image.return_value = True
        mock_ds.run_container.return_value = None
        mock_docker.return_value = mock_ds
        
        from src.core.test_executor import TestExecutor
        
        executor = TestExecutor(
            project="test-project",
            version="v1.0.0",
            project_path="/tmp",
            test_type="unit",
            timeout=60,
            tag="latest"
        )
        executor.docker = mock_ds
        
        result = executor.execute()
        
        assert result.status == TestStatus.ERROR
    
    def test_parse_pytest_output(self):
        """测试pytest输出解析"""
        from src.core.test_executor import TestExecutor
        
        executor = TestExecutor(
            project="test-project",
            version="v1.0.0",
            project_path="/tmp",
            timeout=60
        )
        
        logs = "5 passed, 2 failed, 1 error in 10.5s"
        passed, failed, errors, total = executor._parse_pytest_output(logs)
        
        assert passed == 5
        assert failed == 2
        assert errors == 1
        assert total == 8
    
    def test_generate_paths(self):
        """测试路径生成"""
        from src.core.test_executor import TestExecutor
        
        executor = TestExecutor(
            project="test-project",
            version="v1.0.0",
            project_path="/tmp",
            timeout=60
        )
        
        report_path = executor._generate_report_path()
        logs_path = executor._generate_logs_path()
        
        assert "test-reports" in report_path
        assert "test-logs" in logs_path
        assert "test-project" in report_path
        assert "test-project" in logs_path


class TestDependencyService:
    """测试DependencyService - 更多场景"""
    
    def test_detect_circular_false(self):
        """测试无循环依赖"""
        from src.core.dependency_service import DependencyService
        
        svc = DependencyService()
        
        deps = [
            {"name": "a", "path": "/a"},
            {"name": "b", "path": "/b"}
        ]
        
        result = svc.detect_circular(deps)
        
        assert result is False
    
    def test_topological_sort(self):
        """测试拓扑排序"""
        from src.core.dependency_service import DependencyService
        
        svc = DependencyService()
        
        deps = [{"name": "a", "path": "/a"}]
        
        result = svc.topological_sort(deps)
        
        assert len(result) == 1


class TestConfigService:
    """测试ConfigService - 更多场景"""
    
    def test_get_project_config(self):
        """测试获取项目配置"""
        from src.core.config_service import ConfigService
        
        svc = ConfigService("/nonexistent")
        
        config = svc.get_project_config("test")
        
        assert config is None
    
    def test_get_project_path_default(self):
        """测试获取项目路径默认"""
        from src.core.config_service import ConfigService
        
        svc = ConfigService("/nonexistent")
        
        path = svc.get_project_path("test-project")
        
        assert path is None


class TestReportService:
    """测试ReportService - 更多场景"""
    
    def test_generate_html(self):
        """测试HTML报告生成"""
        from src.core.report_service import ReportService
        
        svc = ReportService()
        
        result = TestResult(
            id="test_001",
            project="test-project",
            version="v1.0.0",
            status=TestStatus.PASSED,
            created_at=datetime.now()
        )
        
        report = svc.generate(result, "html")
        
        assert "<html>" in report
        assert "test-project" in report
    
    def test_generate_unsupported_format(self):
        """测试不支持的格式"""
        from src.core.report_service import ReportService
        
        svc = ReportService()
        
        result = TestResult(
            id="test_001",
            project="test-project",
            version="v1.0.0",
            status=TestStatus.PASSED,
            created_at=datetime.now()
        )
        
        with pytest.raises(ValueError):
            svc.generate(result, "pdf")
    
    def test_save_report(self):
        """测试保存报告"""
        from src.core.report_service import ReportService
        
        svc = ReportService()
        
        result = TestResult(
            id="test_001",
            project="test-project",
            version="v1.0.0",
            status=TestStatus.PASSED,
            created_at=datetime.now()
        )
        
        with tempfile.NamedTemporaryFile(suffix='.md', delete=False) as f:
            output_path = f.name
        
        try:
            path = svc.save(result, output_path, "markdown")
            
            assert os.path.exists(path)
            
            with open(path) as f:
                content = f.read()
            
            assert "测试报告" in content
        finally:
            os.unlink(output_path)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
