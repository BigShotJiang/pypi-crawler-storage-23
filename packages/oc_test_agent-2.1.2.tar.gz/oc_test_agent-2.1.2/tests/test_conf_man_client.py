"""
F-NF-001: ConfManClient 测试

测试ConfManClient与conf-man子系统的集成
"""

import pytest
import os
import sys
from unittest.mock import Mock, patch, MagicMock

os.environ["OC_SKIP_SKILL_CHECK"] = "1"


class TestConfManClient:
    """ConfManClient测试"""

    def test_import_confman_client(self):
        """TC-F-NF-001-01: 导入ConfManClient类"""
        try:
            from src.core.conf_man_client import ConfManClient
            assert ConfManClient is not None
        except ImportError:
            pytest.skip("ConfManClient not implemented yet")

    def test_get_data_dir(self):
        """TC-F-NF-001-02: 获取data_dir路径"""
        try:
            from src.core.conf_man_client import ConfManClient
            with patch('pathlib.Path.exists', return_value=True):
                with patch('builtins.open', MagicMock()):
                    client = ConfManClient()
                    result = client.get_data_dir()
                    assert result is not None
        except (ImportError, AttributeError):
            pytest.skip("ConfManClient not fully implemented")

    def test_get_todo_db_path(self):
        """TC-F-NF-001-03: 获取todo_db路径"""
        try:
            from src.core.conf_man_client import ConfManClient
            with patch('pathlib.Path.exists', return_value=True):
                with patch('builtins.open', MagicMock()):
                    client = ConfManClient()
                    result = client.get_todo_db_path()
                    assert result is not None
        except (ImportError, AttributeError):
            pytest.skip("ConfManClient not fully implemented")

    def test_get_skill_index_path(self):
        """TC-F-NF-001-04: 获取skill_index路径"""
        try:
            from src.core.conf_man_client import ConfManClient
            with patch('pathlib.Path.exists', return_value=True):
                with patch('builtins.open', MagicMock()):
                    client = ConfManClient()
                    result = client.get_skill_index_path()
                    assert result is not None
        except (ImportError, AttributeError):
            pytest.skip("ConfManClient not fully implemented")

    def test_local_config_compatible(self):
        """TC-F-NF-001-05: 与LocalConfigProvider兼容性"""
        try:
            from src.core.conf_man_client import ConfManClient
            from src.core.config import LocalConfigProvider
            with patch('pathlib.Path.exists', return_value=True):
                with patch('builtins.open', MagicMock()):
                    confman = ConfManClient()
                    local = LocalConfigProvider()
                    assert local.get_data_dir() is not None
        except (ImportError, AttributeError):
            pytest.skip("ConfManClient not fully implemented")


class TestConfManClientErrors:
    """ConfManClient异常处理测试"""

    def test_confman_not_found(self):
        """TC-F-NF-001-06: conf-man不可用时的错误处理"""
        try:
            from src.core.conf_man_client import ConfManClient, ConfManClientError
            with patch('pathlib.Path.exists', return_value=False):
                with pytest.raises(ConfManClientError):
                    client = ConfManClient()
        except (ImportError, AttributeError):
            pytest.skip("ConfManClient not fully implemented")
