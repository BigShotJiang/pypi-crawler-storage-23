"""
测试用例记录功能 - BUG_2026_021_02

验证每个测试用例的详细记录能够正确保存到数据库
"""

import pytest
import tempfile
import os
from datetime import datetime


class TestCaseRecordRepository:
    """测试用例记录仓库测试"""
    
    @pytest.fixture
    def temp_db(self):
        """创建临时数据库"""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        from src.db.database import Database
        db = Database(db_path)
        db.init_schema()
        
        yield db
        
        db.close()
        os.unlink(db_path)
    
    def test_save_test_case_record(self, temp_db):
        """测试保存测试用例记录"""
        from src.db.repositories.result_repo import ResultRepository
        from src.models.test_result import TestResult, TestStatus
        
        repo = ResultRepository(temp_db)
        
        test_case_record = {
            'test_id': 'test_001',
            'test_case_name': 'test_v1_2_unit.py::TestDatabase::test_init_schema',
            'status': 'passed',
            'duration': 0.05,
            'requirement_id': 'REQ_001',
            'agent_id': 'agent6t',
            'created_at': datetime.now().isoformat()
        }
        
        repo.insert_test_case_record(test_case_record)
        
        records = repo.get_test_case_records('test_001')
        
        assert len(records) == 1
        assert records[0]['test_case_name'] == 'test_v1_2_unit.py::TestDatabase::test_init_schema'
        assert records[0]['status'] == 'passed'
    
    def test_query_test_case_records_by_test_id(self, temp_db):
        """测试根据测试ID查询用例记录"""
        from src.db.repositories.result_repo import ResultRepository
        
        repo = ResultRepository(temp_db)
        
        records = [
            {
                'test_id': 'test_001',
                'test_case_name': 'test_v1_2_core.py::TestDockerService::test_is_available_mock',
                'status': 'passed',
                'duration': 0.1,
                'requirement_id': 'REQ_002',
                'agent_id': 'agent7t',
                'created_at': datetime.now().isoformat()
            },
            {
                'test_id': 'test_001',
                'test_case_name': 'test_v1_2_core.py::TestDockerService::test_build_image_mock',
                'status': 'passed',
                'duration': 0.2,
                'requirement_id': 'REQ_002',
                'agent_id': 'agent7t',
                'created_at': datetime.now().isoformat()
            }
        ]
        
        for record in records:
            repo.insert_test_case_record(record)
        
        result = repo.get_test_case_records('test_001')
        
        assert len(result) == 2
    
    def test_count_test_case_runs(self, temp_db):
        """测试统计测试用例执行次数"""
        from src.db.repositories.result_repo import ResultRepository
        
        repo = ResultRepository(temp_db)
        
        records = [
            {
                'test_id': 'test_001',
                'test_case_name': 'test_e2e.py::TestE2EPrinciple::test_tc_principle_01',
                'status': 'passed',
                'duration': 0.5,
                'requirement_id': 'REQ_003',
                'agent_id': 'agent6t',
                'created_at': datetime.now().isoformat()
            },
            {
                'test_id': 'test_002',
                'test_case_name': 'test_e2e.py::TestE2EPrinciple::test_tc_principle_01',
                'status': 'passed',
                'duration': 0.4,
                'requirement_id': 'REQ_003',
                'agent_id': 'agent6t',
                'created_at': datetime.now().isoformat()
            }
        ]
        
        for record in records:
            repo.insert_test_case_record(record)
        
        count = repo.count_test_case_runs('test_e2e.py::TestE2EPrinciple::test_tc_principle_01')
        
        assert count == 2
    
    def test_get_test_case_records_by_requirement(self, temp_db):
        """测试根据需求ID查询用例记录"""
        from src.db.repositories.result_repo import ResultRepository
        
        repo = ResultRepository(temp_db)
        
        records = [
            {
                'test_id': 'test_001',
                'test_case_name': 'test_v1_2_unit.py::TestConfigService::test_get_project_path',
                'status': 'passed',
                'duration': 0.01,
                'requirement_id': 'REQ_TEST_AGENT_V1.2',
                'agent_id': 'agent6t',
                'created_at': datetime.now().isoformat()
            },
            {
                'test_id': 'test_002',
                'test_case_name': 'test_v1_2_core.py::TestConfigService::test_get_project_config',
                'status': 'passed',
                'duration': 0.02,
                'requirement_id': 'REQ_TEST_AGENT_V1.2',
                'agent_id': 'agent6t',
                'created_at': datetime.now().isoformat()
            }
        ]
        
        for record in records:
            repo.insert_test_case_record(record)
        
        result = repo.get_test_case_records_by_requirement('REQ_TEST_AGENT_V1.2')
        
        assert len(result) == 2
    
    def test_get_test_case_records_by_agent(self, temp_db):
        """测试根据Agent ID查询用例记录"""
        from src.db.repositories.result_repo import ResultRepository
        
        repo = ResultRepository(temp_db)
        
        records = [
            {
                'test_id': 'test_001',
                'test_case_name': 'test_v1_2_unit.py::TestDatabase::test_init_schema',
                'status': 'passed',
                'duration': 0.05,
                'requirement_id': 'REQ_001',
                'agent_id': 'agent6t',
                'created_at': datetime.now().isoformat()
            },
            {
                'test_id': 'test_002',
                'test_case_name': 'test_v1_2_core.py::TestDockerService::test_is_available_mock',
                'status': 'passed',
                'duration': 0.1,
                'requirement_id': 'REQ_002',
                'agent_id': 'agent7t',
                'created_at': datetime.now().isoformat()
            }
        ]
        
        for record in records:
            repo.insert_test_case_record(record)
        
        result_agent6 = repo.get_test_case_records_by_agent('agent6t')
        result_agent7 = repo.get_test_case_records_by_agent('agent7t')
        
        assert len(result_agent6) == 1
        assert len(result_agent7) == 1
