"""
F-NF-004: ReliableTodoStorage 可靠存储测试

测试可靠存储层的事务、重试、完整性校验、并发安全
"""

import pytest
import os
import sqlite3
import threading
import time
from pathlib import Path
from unittest.mock import patch, MagicMock

os.environ["OC_SKIP_SKILL_CHECK"] = "1"


class TestReliableTodoStorage:
    """可靠存储测试"""

    @pytest.fixture
    def temp_db(self, tmp_path):
        """创建临时数据库"""
        db_path = tmp_path / "test.db"
        conn = sqlite3.connect(str(db_path))
        conn.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id TEXT PRIMARY KEY,
                content TEXT,
                status TEXT DEFAULT 'pending',
                priority TEXT DEFAULT 'medium',
                sender TEXT,
                receiver TEXT,
                source TEXT,
                created_at TEXT,
                is_read INTEGER DEFAULT 0
            )
        """)
        conn.commit()
        conn.close()
        yield str(db_path)

    def test_import_reliable_storage(self):
        """TC-F-NF-004-00: 导入ReliableTodoStorage"""
        try:
            from src.core.reliable_todo_storage import ReliableTodoStorage
            assert ReliableTodoStorage is not None
        except ImportError:
            pytest.skip("ReliableTodoStorage not implemented yet")

    def test_transaction_atomicity(self, temp_db):
        """TC-F-NF-004-01: 批量保存原子性"""
        try:
            from src.core.reliable_todo_storage import ReliableTodoStorage
            storage = ReliableTodoStorage(temp_db)
            
            todos = [
                {"id": f"test-{i}", "content": f"test-{i}", "status": "pending"}
                for i in range(5)
            ]
            
            for todo in todos:
                storage.save_todo(todo)
            
            conn = sqlite3.connect(temp_db)
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM todos")
            count = cursor.fetchone()[0]
            conn.close()
            
            assert count == 5
        except (ImportError, AttributeError):
            pytest.skip("ReliableTodoStorage not fully implemented")

    def test_retry_mechanism(self, temp_db):
        """TC-F-NF-004-02: 错误重试机制"""
        try:
            from src.core.reliable_todo_storage import ReliableTodoStorage
            storage = ReliableTodoStorage(temp_db)
            
            call_count = 0
            original_add = storage.add
            
            def failing_add(*args, **kwargs):
                nonlocal call_count
                call_count += 1
                if call_count < 3:
                    raise Exception("Temporary failure")
                return original_add(*args, **kwargs)
            
            with patch.object(storage, 'add', failing_add):
                result = storage.retry_save({"id": "test-retry", "content": "test"})
                assert call_count >= 1
        except (ImportError, AttributeError):
            pytest.skip("ReliableTodoStorage not fully implemented")

    def test_checksum_verification(self, temp_db):
        """TC-F-NF-004-03: checksum验证"""
        try:
            from src.core.reliable_todo_storage import ReliableTodoStorage
            storage = ReliableTodoStorage(temp_db)
            
            todo = {"id": "test-checksum", "content": "test content"}
            storage.save_todo(todo)
            
            result = storage.verify_integrity()
            assert result is True or result is not None
        except (ImportError, AttributeError):
            pytest.skip("ReliableTodoStorage not fully implemented")

    def test_concurrent_safety(self, temp_db):
        """TC-F-NF-004-04: 并发安全"""
        try:
            from src.core.reliable_todo_storage import ReliableTodoStorage
            storage = ReliableTodoStorage(temp_db)
            
            errors = []
            
            def write_todo(iteration):
                try:
                    storage.save_todo({
                        "id": f"concurrent-{iteration}",
                        "content": f"test-{iteration}",
                        "status": "pending"
                    })
                except Exception as e:
                    errors.append(e)
            
            threads = []
            for i in range(10):
                t = threading.Thread(target=write_todo, args=(i,))
                threads.append(t)
                t.start()
            
            for t in threads:
                t.join()
            
            assert len(errors) == 0 or all("locked" in str(e).lower() for e in errors)
        except (ImportError, AttributeError):
            pytest.skip("ReliableTodoStorage not fully implemented")


class TestReliableTodoStorageErrors:
    """可靠存储异常处理"""

    def test_error_handling(self, temp_db):
        """TC-F-NF-004-05: 异常详细信息"""
        try:
            from src.core.reliable_todo_storage import ReliableTodoStorage, ReliableTodoStorageError
            storage = ReliableTodoStorage(temp_db)
            
            with pytest.raises(Exception) as exc_info:
                storage.save_todo({"id": None, "content": "test"})
            
            assert str(exc_info.value) is not None
        except (ImportError, AttributeError):
            pytest.skip("ReliableTodoStorage not fully implemented")

    def test_retry_exhausted(self, temp_db):
        """TC-F-NF-004-06: 重试次数耗尽"""
        try:
            from src.core.reliable_todo_storage import ReliableTodoStorage, ReliableTodoStorageError
            storage = ReliableTodoStorage(temp_db)
            
            def always_fail(*args, **kwargs):
                raise Exception("Permanent failure")
            
            with patch.object(storage, 'add', always_fail):
                with pytest.raises((ReliableTodoStorageError, Exception)):
                    storage.retry_save({"id": "test", "content": "test"}, max_retries=3)
        except (ImportError, AttributeError):
            pytest.skip("ReliableTodoStorage not fully implemented")
