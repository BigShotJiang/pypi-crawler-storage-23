"""
通知模块单元测试 - Bug Report和WebSocket
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch
from src.core.notification.bug_report import BugReportGenerator
from src.core.notification.websocket import WebSocketManager


class TestBugReportGenerator:
    """缺陷报告生成器测试"""
    
    def test_bug_report_generator_creation(self):
        """测试BugReportGenerator创建"""
        generator = BugReportGenerator()
        assert generator.pm_agent_url == "http://pm-agent:8003"
    
    def test_bug_report_generator_custom_url(self):
        """测试自定义URL"""
        generator = BugReportGenerator(pm_agent_url="http://custom:9000")
        assert generator.pm_agent_url == "http://custom:9000"
    
    def test_build_report_no_failures(self):
        """测试无失败时不生成报告"""
        generator = BugReportGenerator()
        
        mock_result = Mock()
        mock_result.id = "test_123"
        mock_result.project = "pm-agent"
        mock_result.version = "v1.0"
        mock_result.passed = 10
        mock_result.failed = 0
        mock_result.errors = 0
        mock_result.total = 10
        
        report = generator._build_report(mock_result)
        # 当没有失败时，不应该生成报告（返回None的逻辑在generate_and_send中）
        assert report["severity"] == "medium"
    
    def test_build_report_high_severity(self):
        """测试高严重性"""
        generator = BugReportGenerator()
        
        mock_result = Mock()
        mock_result.id = "test_123"
        mock_result.project = "pm-agent"
        mock_result.version = "v1.0"
        mock_result.passed = 5
        mock_result.failed = 10
        mock_result.errors = 0
        mock_result.total = 15
        
        report = generator._build_report(mock_result)
        assert report["severity"] == "high"
        assert "10个用例失败" in report["title"]
    
    def test_build_report_medium_severity(self):
        """测试中等严重性"""
        generator = BugReportGenerator()
        
        mock_result = Mock()
        mock_result.id = "test_123"
        mock_result.project = "pm-agent"
        mock_result.version = "v1.0"
        mock_result.passed = 8
        mock_result.failed = 2
        mock_result.errors = 0
        mock_result.total = 10
        
        report = generator._build_report(mock_result)
        assert report["severity"] == "medium"
    
    def test_build_description(self):
        """测试描述构建"""
        generator = BugReportGenerator()
        
        mock_result = Mock()
        mock_result.id = "test_123"
        mock_result.project = "pm-agent"
        mock_result.version = "v1.0"
        mock_result.passed = 5
        mock_result.failed = 3
        mock_result.errors = 2
        mock_result.total = 10
        
        desc = generator._build_description(mock_result)
        assert "pm-agent" in desc
        assert "v1.0" in desc
        assert "3" in desc  # failed
        assert "2" in desc  # errors
        assert "5" in desc  # passed
    
    @pytest.mark.asyncio
    async def test_generate_and_send_no_failures(self):
        """测试无失败时不发送报告"""
        generator = BugReportGenerator()
        
        mock_result = Mock()
        mock_result.id = "test_123"
        mock_result.project = "pm-agent"
        mock_result.version = "v1.0"
        mock_result.passed = 10
        mock_result.failed = 0
        mock_result.errors = 0
        mock_result.total = 10
        
        result = await generator.generate_and_send(mock_result)
        assert result is None
    
    def test_get_bug_report_generator_singleton(self):
        """测试单例"""
        from src.core.notification.bug_report import get_bug_report_generator
        gen1 = get_bug_report_generator()
        gen2 = get_bug_report_generator()
        assert gen1 is gen2


class TestWebSocketManager:
    """WebSocket管理器测试"""
    
    def test_websocket_manager_creation(self):
        """测试WebSocketManager创建"""
        manager = WebSocketManager()
        assert manager.active_connections == {}
    
    def test_disconnect_nonexistent(self):
        """测试断开不存在的连接"""
        manager = WebSocketManager()
        mock_ws = Mock()
        manager.disconnect(mock_ws, "tests")
        # 不应该抛出异常
    
    @pytest.mark.asyncio
    async def test_send_message_no_connections(self):
        """测试无连接时发送消息"""
        manager = WebSocketManager()
        # 不应该抛出异常
        await manager.send_message({"test": "data"}, "tests")
    
    @pytest.mark.asyncio
    async def test_broadcast_test_update(self):
        """测试广播测试更新"""
        manager = WebSocketManager()
        # 不应该抛出异常
        await manager.broadcast_test_update({"test_id": "test_123"})


class TestBugReportGeneratorIntegration:
    """缺陷报告集成测试"""
    
    def test_get_bug_report_generator(self):
        """测试获取生成器"""
        from src.core.notification.bug_report import get_bug_report_generator
        generator = get_bug_report_generator()
        assert isinstance(generator, BugReportGenerator)


class TestWebSocketIntegration:
    """WebSocket集成测试"""
    
    def test_get_websocket_manager(self):
        """测试获取WebSocket管理器"""
        from src.core.notification.websocket import get_websocket_manager
        manager = get_websocket_manager()
        assert isinstance(manager, WebSocketManager)
    
    def test_websocket_manager_singleton(self):
        """测试单例"""
        from src.core.notification.websocket import get_websocket_manager
        mgr1 = get_websocket_manager()
        mgr2 = get_websocket_manager()
        assert mgr1 is mgr2
