"""
S04-Agent管理子系统测试代码
用例数: 15
覆盖文档: test-agent/docs/03-test/oc-collab/S04_agent.md
"""

import pytest
import subprocess
import sqlite3
import os


class TestAgentRegister:
    """S04-T001-T005: Agent注册"""
    
    def test_agent_register_basic(self, tmp_path, monkeypatch):
        """测试基本注册"""
        monkeypatch.chdir(tmp_path)
        os.makedirs("state", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "agent", "register", "agent1"],
            capture_output=True, text=True, cwd=tmp_path
        )
        assert result.returncode == 0


class TestAgentList:
    """S04-T006-T010: Agent列表"""
    
    def test_agent_list_basic(self, tmp_path, monkeypatch):
        """测试列出Agent"""
        monkeypatch.chdir(tmp_path)
        os.makedirs("state", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "agent", "list"],
            capture_output=True, text=True, cwd=tmp_path
        )
        assert result.returncode == 0


class TestAgentStatus:
    """S04-T011-T015: Agent状态"""
    
    def test_agent_status_basic(self, tmp_path, monkeypatch):
        """测试Agent状态"""
        monkeypatch.chdir(tmp_path)
        os.makedirs("state", exist_ok=True)
        
        result = subprocess.run(
            ["python3", "-m", "src.cli.main", "agent", "status", "agent1"],
            capture_output=True, text=True, cwd=tmp_path
        )
        assert result.returncode == 0
