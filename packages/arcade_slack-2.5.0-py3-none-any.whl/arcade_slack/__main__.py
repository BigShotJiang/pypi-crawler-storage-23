import argparse
from typing import cast

from arcade_mcp_server import MCPApp
from arcade_mcp_server.mcp_app import TransportType

import arcade_slack

app = MCPApp(
    name="Slack",
    instructions=(
        "Use this server when you need to interact with Slack — sending messages, reading "
        "conversations, managing channels, and looking up users."
    ),
)

app.add_tools_from_module(arcade_slack)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Slack MCP server.")
    parser.add_argument("--host", type=str, default="127.0.0.1", help="Host to bind the server.")
    parser.add_argument("--port", type=int, default=8000, help="Port to bind the server.")
    parser.add_argument(
        "--transport",
        type=str,
        default="stdio",
        choices=["stdio", "http"],
        help="Transport type (stdio or http).",
    )
    args = parser.parse_args()

    app.run(host=args.host, port=args.port, transport=cast(TransportType, args.transport))


if __name__ == "__main__":
    main()
