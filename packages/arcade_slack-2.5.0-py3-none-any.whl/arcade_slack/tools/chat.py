from typing import Annotated, cast

from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_tdk import ToolContext, tool
from arcade_tdk.auth import Slack
from arcade_tdk.errors import ToolExecutionError
from slack_sdk.web.async_client import AsyncWebClient

from arcade_slack.constants import MAX_PAGINATION_SIZE_LIMIT
from arcade_slack.conversation_retrieval import (
    get_channel_by_name,
    get_conversation_by_id,
)
from arcade_slack.message_retrieval import (
    retrieve_messages_in_conversation,
    retrieve_thread_messages,
)
from arcade_slack.models import (
    ConversationType,
)
from arcade_slack.user_retrieval import (
    get_users_by_id,
    get_users_by_id_username_or_email,
)
from arcade_slack.utils import (
    async_paginate,
    extract_conversation_metadata,
    invite_users_to_conversation,
    populate_users_in_messages,
    raise_for_users_not_found,
)


@tool(
    requires_auth=Slack(
        scopes=[
            "channels:read",
            "groups:read",
            "mpim:read",
            "im:read",
            "users:read",
            "users:read.email",
            "chat:write",
            # "mpim:write",
            "im:write",
        ],
    ),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.MESSAGING],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def send_message(
    context: ToolContext,
    message: Annotated[str, "The content of the message to send."],
    channel_name: Annotated[
        str | None,
        "The channel name to send the message to. Prefer providing a conversation_id, "
        "when available, since the performance is better.",
    ] = None,
    conversation_id: Annotated[str | None, "The conversation ID to send the message to."] = None,
    user_ids: Annotated[list[str] | None, "The Slack user IDs of the people to message."] = None,
    emails: Annotated[list[str] | None, "The emails of the people to message."] = None,
    usernames: Annotated[
        list[str] | None,
        "The Slack usernames of the people to message. Prefer providing user_ids and/or emails, "
        "when available, since the performance is better.",
    ] = None,
    thread_ts: Annotated[
        str | None,
        "The timestamp of the parent message to reply to in a thread. Use the 'ts' field "
        "from the parent message (the first message in the thread), not from a reply. "
        "If omitted, the message is sent as a new top-level message. "
        "Get this value from prior get_messages or get_thread_messages results.",
    ] = None,
    reply_broadcast: Annotated[
        bool,
        "When replying to a thread (thread_ts is set), set to true to also post the reply "
        "to the main conversation. Only valid when thread_ts is provided. Defaults to False",
    ] = False,
) -> Annotated[dict, "The response from the Slack API"]:
    """Send a message to a Channel, Direct Message (IM/DM), or Multi-Person (MPIM) conversation.

    Can send top-level messages or reply to an existing thread.

    Provide exactly one of:
    - channel_name; or
    - conversation_id; or
    - any combination of user_ids, usernames, and/or emails.

    In case multiple user_ids, usernames, and/or emails are provided, the tool will open a
    multi-person conversation with the specified people and send the message to it.

    To reply to a thread, also provide thread_ts (the 'ts' field of the parent message).
    Optionally set reply_broadcast to true to also post the reply to the main conversation.
    """
    if conversation_id and any([channel_name, user_ids, usernames, emails]):
        raise ToolExecutionError(
            "Provide exactly one of: channel_name, OR conversation_id, OR any combination of "
            "user_ids, usernames, and/or emails."
        )

    if reply_broadcast and thread_ts is None:
        raise ToolExecutionError(
            "reply_broadcast can only be used when thread_ts is provided "
            "(i.e., when replying to a thread)."
        )

    if not conversation_id:
        conversation = await get_conversation_metadata(
            context=context,
            channel_name=channel_name,
            user_ids=user_ids,
            usernames=usernames,
            emails=emails,
        )
        conversation_id = conversation["id"]

    slack_client = AsyncWebClient(token=context.get_auth_token_or_empty())
    post_kwargs: dict = {"channel": cast(str, conversation_id), "text": message}
    if thread_ts is not None:
        post_kwargs["thread_ts"] = thread_ts
        if reply_broadcast:
            post_kwargs["reply_broadcast"] = reply_broadcast
    response = await slack_client.chat_postMessage(**post_kwargs)
    return {"success": True, "data": response.data}


@tool(
    requires_auth=Slack(
        scopes=[
            "channels:read",
            "groups:read",
            "im:read",
            "mpim:read",
            "users:read",
            "users:read.email",
        ],
    ),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.MESSAGING],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_users_in_conversation(
    context: ToolContext,
    conversation_id: Annotated[str | None, "The ID of the conversation to get users in."] = None,
    channel_name: Annotated[
        str | None,
        "The name of the channel to get users in. Prefer providing a conversation_id, "
        "when available, since the performance is better.",
    ] = None,
    # The user object is relatively small, so we allow a higher limit.
    limit: Annotated[
        int, "The maximum number of users to return. Defaults to 200. Maximum is 500."
    ] = 200,
    next_cursor: Annotated[str | None, "The cursor to use for pagination."] = None,
) -> Annotated[dict, "Information about each user in the conversation"]:
    """Get the users in a Slack conversation (Channel, DM/IM, or MPIM) by its ID or by channel name.

    Provide exactly one of conversation_id or channel_name. Prefer providing a conversation_id,
    when available, since the performance is better.
    """
    limit = max(1, min(limit, 500))

    if sum({bool(conversation_id), bool(channel_name)}) != 1:
        raise ToolExecutionError("Provide exactly one of conversation_id OR channel_name.")

    auth_token = context.get_auth_token_or_empty()

    if not conversation_id:
        channel = await get_channel_by_name(auth_token, cast(str, channel_name))
        conversation_id = channel["id"]

    slack_client = AsyncWebClient(token=auth_token)
    user_ids, next_cursor = await async_paginate(
        func=slack_client.conversations_members,
        response_key="members",
        limit=limit,
        next_cursor=next_cursor,
        channel=conversation_id,
    )

    response = await get_users_by_id(auth_token, user_ids)

    await raise_for_users_not_found(context, [response])

    return {
        "users": [user for user in response["users"] if not user.get("is_bot")],
        "next_cursor": next_cursor,
    }


@tool(
    requires_auth=Slack(
        scopes=[
            "channels:read",
            "groups:read",
            "mpim:read",
            "im:read",
            "users:read",
            "users:read.email",
            "channels:history",
            "groups:history",
            "mpim:history",
            "im:history",
        ]
    ),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.MESSAGING],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_messages(
    context: ToolContext,
    conversation_id: Annotated[
        str | None,
        "The ID of the conversation to get messages from. Provide exactly one of conversation_id "
        "OR any combination of user_ids, usernames, and/or emails.",
    ] = None,
    channel_name: Annotated[
        str | None,
        "The name of the channel to get messages from. Prefer providing a conversation_id, "
        "when available, since the performance is better.",
    ] = None,
    user_ids: Annotated[
        list[str] | None, "The IDs of the users in the conversation to get messages from."
    ] = None,
    usernames: Annotated[
        list[str] | None,
        "The usernames of the users in the conversation to get messages from. Prefer providing"
        "user_ids and/or emails, when available, since the performance is better.",
    ] = None,
    emails: Annotated[
        list[str] | None,
        "The emails of the users in the conversation to get messages from.",
    ] = None,
    oldest_relative: Annotated[
        str | None,
        (
            "The oldest message to include in the results, specified as a time offset from the "
            "current time in the format 'DD:HH:MM'"
        ),
    ] = None,
    latest_relative: Annotated[
        str | None,
        (
            "The latest message to include in the results, specified as a time offset from the "
            "current time in the format 'DD:HH:MM'"
        ),
    ] = None,
    oldest_datetime: Annotated[
        str | None,
        (
            "The oldest message to include in the results, specified as a datetime object in the "
            "format 'YYYY-MM-DD HH:MM:SS'"
        ),
    ] = None,
    latest_datetime: Annotated[
        str | None,
        (
            "The latest message to include in the results, specified as a datetime object in the "
            "format 'YYYY-MM-DD HH:MM:SS'"
        ),
    ] = None,
    limit: Annotated[
        # The message object can be relatively large, so we limit maximum to 100
        # to preserve LLM's context window and reduce the likelihood of hallucinations.
        int, "The maximum number of messages to return. Defaults to 20. Maximum is 100."
    ] = 20,
    next_cursor: Annotated[str | None, "The cursor to use for pagination."] = None,
) -> Annotated[
    dict,
    "The messages in a Slack Channel, DM (direct message) or MPIM (multi-person) conversation.",
]:
    """Get messages in a Slack Channel, DM (direct message) or MPIM (multi-person) conversation.

    Provide exactly one of:
    - conversation_id; or
    - channel_name; or
    - any combination of user_ids, usernames, and/or emails.

    To filter messages by an absolute datetime, use 'oldest_datetime' and/or 'latest_datetime'. If
    only 'oldest_datetime' is provided, it will return messages from the oldest_datetime to the
    current time. If only 'latest_datetime' is provided, it will return messages since the
    beginning of the conversation to the latest_datetime.

    To filter messages by a relative datetime (e.g. 3 days ago, 1 hour ago, etc.), use
    'oldest_relative' and/or 'latest_relative'. If only 'oldest_relative' is provided, it will
    return messages from the oldest_relative to the current time. If only 'latest_relative' is
    provided, it will return messages from the current time to the latest_relative.

    Do not provide both 'oldest_datetime' and 'oldest_relative' or both 'latest_datetime' and
    'latest_relative'.

    Leave all arguments with the default None to get messages without date/time filtering"""
    limit = max(1, min(limit, 100))

    has_conversation_id = bool(conversation_id)
    has_channel_name = bool(channel_name)
    has_user_identity = any([user_ids, usernames, emails])
    selector_count = sum([has_conversation_id, has_channel_name, has_user_identity])

    if selector_count != 1:
        raise ToolExecutionError(
            "Provide exactly one of: conversation_id, OR channel_name, OR any combination of "
            "user_ids, usernames, and/or emails."
        )

    if not conversation_id:
        conversation = await get_conversation_metadata(
            context=context,
            channel_name=channel_name,
            user_ids=user_ids,
            usernames=usernames,
            emails=emails,
        )
        conversation_id = conversation["id"]

    response = await retrieve_messages_in_conversation(
        auth_token=context.get_auth_token_or_empty(),
        conversation_id=cast(str, conversation_id),
        oldest_relative=oldest_relative,
        latest_relative=latest_relative,
        oldest_datetime=oldest_datetime,
        latest_datetime=latest_datetime,
        limit=limit,
        next_cursor=next_cursor,
    )

    response["messages"] = await populate_users_in_messages(
        auth_token=context.get_auth_token_or_empty(),
        messages=response["messages"],
    )

    return cast(dict, response)


@tool(
    requires_auth=Slack(
        scopes=[
            "channels:read",
            "groups:read",
            "mpim:read",
            "im:read",
            "users:read",
            "users:read.email",
            "channels:history",
            "groups:history",
            "mpim:history",
            "im:history",
        ]
    ),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.MESSAGING],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_thread_messages(
    context: ToolContext,
    thread_ts: Annotated[
        str,
        "The timestamp of the parent message that starts the thread. This is the 'ts' field from "
        "the parent message.",
    ],
    conversation_id: Annotated[
        str | None,
        "The ID of the conversation containing the thread. Provide exactly one of conversation_id "
        "OR channel_name OR any combination of user_ids, usernames, and/or emails.",
    ] = None,
    channel_name: Annotated[
        str | None,
        "The name of the channel containing the thread. Prefer providing a conversation_id, "
        "when available, since the performance is better.",
    ] = None,
    user_ids: Annotated[
        list[str] | None,
        "The IDs of the users in the conversation containing the thread.",
    ] = None,
    usernames: Annotated[
        list[str] | None,
        "The usernames of the users in the conversation containing the thread. Prefer providing "
        "user_ids and/or emails, when available, since the performance is better.",
    ] = None,
    emails: Annotated[
        list[str] | None,
        "The emails of the users in the conversation containing the thread.",
    ] = None,
    oldest_relative: Annotated[
        str | None,
        (
            "The oldest message to include in the results, specified as a time offset from the "
            "current time in the format 'DD:HH:MM'"
        ),
    ] = None,
    latest_relative: Annotated[
        str | None,
        (
            "The latest message to include in the results, specified as a time offset from the "
            "current time in the format 'DD:HH:MM'"
        ),
    ] = None,
    oldest_datetime: Annotated[
        str | None,
        (
            "The oldest message to include in the results, specified as a datetime object in the "
            "format 'YYYY-MM-DD HH:MM:SS'"
        ),
    ] = None,
    latest_datetime: Annotated[
        str | None,
        (
            "The latest message to include in the results, specified as a datetime object in the "
            "format 'YYYY-MM-DD HH:MM:SS'"
        ),
    ] = None,
    limit: Annotated[
        # The message object can be relatively large, so we limit maximum to 100
        # to preserve LLM's context window and reduce the likelihood of hallucinations.
        int, "The maximum number of messages to return. Defaults to 20. Maximum is 100."
    ] = 20,
    next_cursor: Annotated[str | None, "The cursor to use for pagination."] = None,
) -> Annotated[
    dict,
    "The messages in a Slack thread within a Channel, DM (direct message) or "
    "MPIM (multi-person) conversation.",
]:
    """Get messages in a Slack thread.

    A thread is a collection of messages grouped together as replies to a parent message.
    This tool retrieves all messages in a specific thread, identified by the parent message's
    timestamp (thread_ts).

    Provide exactly one of:
    - conversation_id; or
    - channel_name; or
    - any combination of user_ids, usernames, and/or emails.

    To filter messages by an absolute datetime, use 'oldest_datetime' and/or 'latest_datetime'. If
    only 'oldest_datetime' is provided, it will return messages from the oldest_datetime to the
    current time. If only 'latest_datetime' is provided, it will return messages since the
    beginning of the thread to the latest_datetime.

    To filter messages by a relative datetime (e.g. 3 days ago, 1 hour ago, etc.), use
    'oldest_relative' and/or 'latest_relative'. If only 'oldest_relative' is provided, it will
    return messages from the oldest_relative to the current time. If only 'latest_relative' is
    provided, it will return messages from the current time to the latest_relative.

    Do not provide both 'oldest_datetime' and 'oldest_relative' or both 'latest_datetime' and
    'latest_relative'.

    Leave all datetime arguments with the default None to get all thread messages without
    date/time filtering.
    """
    limit = max(1, min(limit, 100))

    has_conversation_id = bool(conversation_id)
    has_channel_name = bool(channel_name)
    has_user_identity = any([user_ids, usernames, emails])
    selector_count = sum([has_conversation_id, has_channel_name, has_user_identity])

    if selector_count != 1:
        raise ToolExecutionError(
            "Provide exactly one of: conversation_id, OR channel_name, OR any combination of "
            "user_ids, usernames, and/or emails."
        )

    if not conversation_id:
        conversation = await get_conversation_metadata(
            context=context,
            channel_name=channel_name,
            user_ids=user_ids,
            usernames=usernames,
            emails=emails,
        )
        conversation_id = conversation["id"]

    auth_token = context.get_auth_token_or_empty()

    response = await retrieve_thread_messages(
        auth_token=auth_token,
        conversation_id=cast(str, conversation_id),
        thread_ts=thread_ts,
        oldest_relative=oldest_relative,
        latest_relative=latest_relative,
        oldest_datetime=oldest_datetime,
        latest_datetime=latest_datetime,
        limit=limit,
        next_cursor=next_cursor,
    )

    response["messages"] = await populate_users_in_messages(
        auth_token=auth_token,
        messages=response["messages"],
    )

    return cast(dict, response)


@tool(
    requires_auth=Slack(
        scopes=[
            "channels:read",
            "groups:read",
            "mpim:read",
            "im:read",
            "users:read",
            "users:read.email",
        ],
    ),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.MESSAGING],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_conversation_metadata(
    context: ToolContext,
    conversation_id: Annotated[str | None, "The ID of the conversation to get metadata for"] = None,
    channel_name: Annotated[
        str | None,
        "The name of the channel to get metadata for. Prefer providing a conversation_id, "
        "when available, since the performance is better.",
    ] = None,
    usernames: Annotated[
        list[str] | None,
        "The usernames of the users to get the conversation metadata. "
        "Prefer providing user_ids and/or emails, when available, since the performance is better.",
    ] = None,
    emails: Annotated[
        list[str] | None,
        "The emails of the users to get the conversation metadata.",
    ] = None,
    user_ids: Annotated[
        list[str] | None,
        "The IDs of the users to get the conversation metadata.",
    ] = None,
) -> Annotated[
    dict | None,
    "The conversation metadata.",
]:
    """Get metadata of a Channel, a Direct Message (IM / DM) or a Multi-Person (MPIM) conversation.

    Use this tool to retrieve metadata about a conversation with a conversation_id, a channel name,
    or by the user_id(s), username(s), and/or email(s) of the user(s) in the conversation.

    This tool does not return the messages in a conversation. To get the messages, use the
    'Slack.GetMessages' tool instead.

    Provide exactly one of:
    - conversation_id; or
    - channel_name; or
    - any combination of user_ids, usernames, and/or emails.
    """
    has_conversation_id = bool(conversation_id)
    has_channel_name = bool(channel_name)
    has_user_identity = any([user_ids, usernames, emails])
    selector_count = sum([has_conversation_id, has_channel_name, has_user_identity])

    if selector_count != 1:
        raise ToolExecutionError(
            "Provide exactly one of: conversation_id, OR channel_name, OR any combination of "
            "user_ids, usernames, and/or emails."
        )

    auth_token = context.get_auth_token_or_empty()

    if conversation_id:
        return await get_conversation_by_id(auth_token, conversation_id)

    elif channel_name:
        return await get_channel_by_name(auth_token, channel_name)

    user_ids_list = user_ids if isinstance(user_ids, list) else []

    slack_client = AsyncWebClient(token=auth_token)

    current_user = await slack_client.auth_test()

    if current_user["user_id"] not in user_ids_list:
        user_ids_list.append(current_user["user_id"])

    if usernames or emails:
        other_users = await get_users_by_id_username_or_email(
            context=context,
            usernames=usernames,
            emails=emails,
        )
        user_ids_list.extend([user["id"] for user in other_users])

    response = await slack_client.conversations_open(users=user_ids_list, return_im=True)
    return dict(**extract_conversation_metadata(response["channel"]))


@tool(
    requires_auth=Slack(
        scopes=["channels:read", "groups:read", "im:read", "mpim:read"],
    ),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.MESSAGING],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_conversations(
    context: ToolContext,
    conversation_types: Annotated[
        list[ConversationType] | None,
        "Optionally filter by the type(s) of conversations. Defaults to None (all types).",
    ] = None,
    # The conversation object is relatively small, so we allow a higher limit.
    limit: Annotated[
        int,
        f"The maximum number of conversations to list. Defaults to {MAX_PAGINATION_SIZE_LIMIT}. "
        "Maximum is 500.",
    ] = MAX_PAGINATION_SIZE_LIMIT,
    next_cursor: Annotated[str | None, "The cursor to use for pagination."] = None,
) -> Annotated[dict, "The list of conversations found with metadata"]:
    """List metadata for Slack conversations (channels, DMs, MPIMs) the user is a member of.

    This tool does not return the messages in a conversation. To get the messages, use the
    'Slack.GetMessages' tool instead. Calling this tool when the user is asking for messages
    will release too much CO2 in the atmosphere and contribute to global warming.
    """
    limit = max(1, min(limit, 500))

    if conversation_types:
        conversation_types_filter = ",".join(
            conversation_type.to_slack_name_str() for conversation_type in conversation_types
        )
    else:
        conversation_types_filter = None

    slack_client = AsyncWebClient(token=context.get_auth_token_or_empty())

    results, next_cursor = await async_paginate(
        slack_client.conversations_list,
        "channels",
        limit=limit,
        next_cursor=next_cursor,
        types=conversation_types_filter,
        exclude_archived=True,
    )

    return {
        "conversations": [
            dict(**extract_conversation_metadata(conversation))
            for conversation in results
            if conversation.get("is_im") or conversation.get("is_member")
        ],
        "next_cursor": next_cursor,
    }


@tool(
    requires_auth=Slack(
        scopes=[
            "channels:read",
            "groups:read",
            "channels:write",
            "groups:write",
            "users:read",
            "users:read.email",
        ],
    ),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.MESSAGING],
        ),
        behavior=Behavior(
            operations=[Operation.UPDATE],
            read_only=False,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def invite_users_to_channel(
    context: ToolContext,
    channel_id: Annotated[
        str | None,
        "The ID of the Slack channel or MPIM (multi-person direct message) to invite users to. "
        "Provide exactly one of channel_id OR channel_name.",
    ] = None,
    channel_name: Annotated[
        str | None,
        "The name of the channel to invite users to. Prefer providing a channel_id when "
        "available for better performance. Note: MPIMs don't have names, so use channel_id "
        "for MPIMs.",
    ] = None,
    user_ids: Annotated[
        list[str] | None,
        "The Slack user IDs of the people to invite. Up to 100 users may be listed. "
        "Provide at least one of user_ids, usernames, or emails.",
    ] = None,
    usernames: Annotated[
        list[str] | None,
        "The Slack usernames of the people to invite. Prefer providing user_ids "
        "and/or emails when available for better performance.",
    ] = None,
    emails: Annotated[
        list[str] | None,
        "The email addresses of the people to invite.",
    ] = None,
) -> Annotated[dict, "The response from inviting users to the conversation"]:
    """Invite users to a Slack channel or MPIM (multi-person direct message).

    This tool invites specified users to join a Slack conversation. It works with:
    - Public channels
    - Private channels
    - MPIMs (multi-person direct messages / group DMs)

    You can specify users by their user IDs, usernames, or email addresses.

    Provide exactly one of channel_id or channel_name, and at least one of user_ids, usernames,
    or emails.

    The tool will resolve usernames and emails to user IDs before inviting them.
    Up to 100 users may be invited at once.
    """
    # XOR validation: exactly one of channel_id or channel_name must be provided
    if not ((channel_id is None) ^ (channel_name is None)):
        raise ToolExecutionError("Provide exactly one of channel_id OR channel_name.")

    if not any([user_ids, usernames, emails]):
        raise ToolExecutionError(
            "Provide at least one of user_ids, usernames, or emails to invite."
        )

    auth_token = context.get_auth_token_or_empty()

    # Resolve channel name to ID if needed
    resolved_channel_id = channel_id
    if not resolved_channel_id:
        channel = await get_channel_by_name(auth_token, cast(str, channel_name))
        resolved_channel_id = channel["id"]

    # Use the shared helper to invite users
    invite_result = await invite_users_to_conversation(
        context=context,
        conversation_id=cast(str, resolved_channel_id),
        user_ids=user_ids,
        usernames=usernames,
        emails=emails,
    )

    invited_channel = invite_result.get("channel", {})
    channel_display = invited_channel.get("name", resolved_channel_id)
    message = f"Successfully invited {invite_result['invited_count']} user(s) to {channel_display}"

    return {
        "success": True,
        "channel_id": resolved_channel_id,
        "channel_name": invited_channel.get("name"),
        "invited_user_ids": invite_result["invited_user_ids"],
        "invited_count": invite_result["invited_count"],
        "message": message,
    }
