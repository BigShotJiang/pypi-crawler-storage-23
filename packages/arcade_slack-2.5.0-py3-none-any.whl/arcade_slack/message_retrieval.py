from datetime import datetime, timezone
from typing import Any

from arcade_tdk.errors import FatalToolError
from slack_sdk.web.async_client import AsyncWebClient

from arcade_slack.utils import (
    async_paginate,
    convert_datetime_to_unix_timestamp,
    convert_relative_datetime_to_unix_timestamp,
    enrich_message_datetime,
)


def _prepare_datetime_filters(
    oldest_relative: str | None = None,
    latest_relative: str | None = None,
    oldest_datetime: str | None = None,
    latest_datetime: str | None = None,
) -> dict[str, Any]:
    """Validate and convert datetime parameters to Slack API timestamp arguments.

    Args:
        oldest_relative: Oldest message to include, specified as time offset (DD:HH:MM)
        latest_relative: Latest message to include, specified as time offset (DD:HH:MM)
        oldest_datetime: Oldest message to include, specified as datetime (YYYY-MM-DD HH:MM:SS)
        latest_datetime: Latest message to include, specified as datetime (YYYY-MM-DD HH:MM:SS)

    Returns:
        A dictionary with 'oldest' and/or 'latest' timestamp keys for the Slack API

    Raises:
        FatalToolError: If both relative and absolute datetime parameters are specified
    """
    error_message = None
    if oldest_datetime and oldest_relative:
        error_message = "Cannot specify both 'oldest_datetime' and 'oldest_relative'."

    if latest_datetime and latest_relative:
        error_message = "Cannot specify both 'latest_datetime' and 'latest_relative'."

    if error_message:
        raise FatalToolError(error_message, developer_message=error_message)

    current_unix_timestamp = int(datetime.now(timezone.utc).timestamp())

    if latest_relative:
        latest_timestamp = convert_relative_datetime_to_unix_timestamp(
            latest_relative, current_unix_timestamp
        )
    elif latest_datetime:
        latest_timestamp = convert_datetime_to_unix_timestamp(latest_datetime)
    else:
        latest_timestamp = None

    if oldest_relative:
        oldest_timestamp = convert_relative_datetime_to_unix_timestamp(
            oldest_relative, current_unix_timestamp
        )
    elif oldest_datetime:
        oldest_timestamp = convert_datetime_to_unix_timestamp(oldest_datetime)
    else:
        oldest_timestamp = None

    datetime_args: dict[str, Any] = {}
    if oldest_timestamp:
        datetime_args["oldest"] = oldest_timestamp
    if latest_timestamp:
        datetime_args["latest"] = latest_timestamp

    return datetime_args


async def retrieve_messages_in_conversation(
    conversation_id: str,
    auth_token: str | None = None,
    oldest_relative: str | None = None,
    latest_relative: str | None = None,
    oldest_datetime: str | None = None,
    latest_datetime: str | None = None,
    limit: int | None = None,
    next_cursor: str | None = None,
) -> dict:
    datetime_args = _prepare_datetime_filters(
        oldest_relative=oldest_relative,
        latest_relative=latest_relative,
        oldest_datetime=oldest_datetime,
        latest_datetime=latest_datetime,
    )

    slackClient = AsyncWebClient(token=auth_token)

    response, next_cursor = await async_paginate(
        slackClient.conversations_history,
        "messages",
        limit=limit,
        next_cursor=next_cursor,
        channel=conversation_id,
        include_all_metadata=True,
        inclusive=True,  # Include messages at the start and end of the time range
        **datetime_args,
    )

    messages = [enrich_message_datetime(message) for message in response]

    return {"messages": messages, "next_cursor": next_cursor}


async def retrieve_thread_messages(
    conversation_id: str,
    thread_ts: str,
    auth_token: str | None = None,
    oldest_relative: str | None = None,
    latest_relative: str | None = None,
    oldest_datetime: str | None = None,
    latest_datetime: str | None = None,
    limit: int | None = None,
    next_cursor: str | None = None,
) -> dict:
    """Retrieve messages in a Slack thread.

    Args:
        conversation_id: The ID of the conversation containing the thread
        thread_ts: The timestamp of the parent message that starts the thread
        auth_token: The Slack authentication token
        oldest_relative: Oldest message to include, specified as time offset (DD:HH:MM)
        latest_relative: Latest message to include, specified as time offset (DD:HH:MM)
        oldest_datetime: Oldest message to include, specified as datetime (YYYY-MM-DD HH:MM:SS)
        latest_datetime: Latest message to include, specified as datetime (YYYY-MM-DD HH:MM:SS)
        limit: Maximum number of messages to return
        next_cursor: Cursor for pagination

    Returns:
        A dictionary containing:
        - messages: List of messages in the thread
        - next_cursor: Cursor for the next page (if more results exist)
    """
    datetime_args = _prepare_datetime_filters(
        oldest_relative=oldest_relative,
        latest_relative=latest_relative,
        oldest_datetime=oldest_datetime,
        latest_datetime=latest_datetime,
    )

    slackClient = AsyncWebClient(token=auth_token)

    response, next_cursor = await async_paginate(
        slackClient.conversations_replies,
        "messages",
        limit=limit,
        next_cursor=next_cursor,
        channel=conversation_id,
        ts=thread_ts,
        include_all_metadata=True,
        inclusive=True,  # Include messages at the start and end of the time range
        **datetime_args,
    )

    messages = [enrich_message_datetime(message) for message in response]

    return {"messages": messages, "next_cursor": next_cursor}
