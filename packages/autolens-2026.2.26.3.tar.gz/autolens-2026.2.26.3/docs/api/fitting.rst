=======
Fitting
=======

Fitting
-------

For fitting a model (composed from ``Galaxy`` objects in a ``Tracer``) to a dataset.

.. currentmodule:: autolens

.. autosummary::
   :toctree: _autosummary
   :template: custom-class-template.rst
   :recursive:

   FitImaging
   FitInterferometer