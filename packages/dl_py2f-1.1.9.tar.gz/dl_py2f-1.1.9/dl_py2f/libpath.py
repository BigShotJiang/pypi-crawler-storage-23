import os
libpath = os.path.dirname(os.path.abspath(__file__))
