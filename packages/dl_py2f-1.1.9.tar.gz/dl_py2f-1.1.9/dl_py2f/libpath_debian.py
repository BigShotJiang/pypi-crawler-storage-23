libpath = '/lib/x86_64-linux-gnu'
