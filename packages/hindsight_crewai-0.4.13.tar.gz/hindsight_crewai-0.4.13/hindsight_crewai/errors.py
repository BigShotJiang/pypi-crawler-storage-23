"""Hindsight-CrewAI error types."""


class HindsightError(Exception):
    """Exception raised when a Hindsight memory operation fails."""

    pass
