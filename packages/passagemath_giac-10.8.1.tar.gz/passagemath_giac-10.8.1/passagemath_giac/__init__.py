# sage_setup: distribution = sagemath-giac

from sage.all__sagemath_giac import *
