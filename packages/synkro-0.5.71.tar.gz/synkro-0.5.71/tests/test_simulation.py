"""Tests for agent simulation module."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from synkro.simulation.simulated_user import SimulatedUser
from synkro.simulation.simulator import Simulator
from synkro.simulation.types import SimulationResult, SimulationResults
from synkro.types.logic_map import (
    GoldenScenario,
    LogicMap,
    Rule,
    RuleCategory,
    ScenarioType,
    VerificationResult,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_logic_map() -> LogicMap:
    """Create a minimal logic map for testing."""
    return LogicMap(
        rules=[
            Rule(
                rule_id="R001",
                text="Refunds require a receipt",
                condition="Customer requests a refund",
                action="Require receipt before processing",
                dependencies=[],
                category=RuleCategory.CONSTRAINT,
            ),
            Rule(
                rule_id="R002",
                text="Max refund amount is $500",
                condition="Refund amount exceeds $500",
                action="Deny refund above $500",
                dependencies=["R001"],
                category=RuleCategory.CONSTRAINT,
            ),
        ],
        root_rules=["R001"],
    )


def _make_scenario() -> GoldenScenario:
    """Create a test scenario."""
    return GoldenScenario(
        description="Customer wants a refund for a $50 item with receipt",
        context="The customer purchased a shirt last week and has the receipt.",
        category="simulation",
        scenario_type=ScenarioType.POSITIVE,
        target_rule_ids=["R001"],
        expected_outcome="Agent should process the refund since the customer has a receipt and amount is under $500.",
    )


def _make_verification(passed: bool = True) -> VerificationResult:
    """Create a test verification result."""
    return VerificationResult(
        passed=passed,
        issues=[] if passed else ["Missing receipt verification"],
        skipped_rules=[] if passed else ["R001"],
        hallucinated_rules=[],
        contradictions=[],
        rules_verified=["R001", "R002"] if passed else [],
    )


# ---------------------------------------------------------------------------
# SimulationResult tests
# ---------------------------------------------------------------------------


class TestSimulationResult:
    def test_basic_creation(self):
        result = SimulationResult(
            scenario=_make_scenario(),
            messages=[
                {"role": "user", "content": "I want a refund"},
                {"role": "assistant", "content": "Do you have a receipt?"},
            ],
            passed=True,
            issues=[],
            verification=_make_verification(passed=True),
        )
        assert result.passed is True
        assert len(result.messages) == 2
        assert result.issues == []

    def test_failed_result(self):
        result = SimulationResult(
            scenario=_make_scenario(),
            messages=[
                {"role": "user", "content": "I want a refund"},
                {"role": "assistant", "content": "Sure, here's your refund."},
            ],
            passed=False,
            issues=["Missing receipt verification"],
            verification=_make_verification(passed=False),
        )
        assert result.passed is False
        assert len(result.issues) == 1


# ---------------------------------------------------------------------------
# SimulationResults tests
# ---------------------------------------------------------------------------


class TestSimulationResults:
    def _make_results(self) -> SimulationResults:
        logic_map = _make_logic_map()
        return SimulationResults(
            results=[
                SimulationResult(
                    scenario=_make_scenario(),
                    messages=[{"role": "user", "content": "Q"}],
                    passed=True,
                    issues=[],
                    verification=_make_verification(True),
                ),
                SimulationResult(
                    scenario=_make_scenario(),
                    messages=[{"role": "user", "content": "Q2"}],
                    passed=False,
                    issues=["Issue"],
                    verification=_make_verification(False),
                ),
            ],
            logic_map=logic_map,
        )

    def test_pass_rate(self):
        results = self._make_results()
        assert results.pass_rate == 0.5

    def test_total(self):
        results = self._make_results()
        assert results.total == 2

    def test_passed_failed_counts(self):
        results = self._make_results()
        assert results.passed == 1
        assert results.failed == 1

    def test_iter(self):
        results = self._make_results()
        items = list(results)
        assert len(items) == 2

    def test_len(self):
        results = self._make_results()
        assert len(results) == 2

    def test_str_repr(self):
        results = self._make_results()
        s = str(results)
        assert "total=2" in s
        assert "passed=1" in s

    def test_empty_results(self):
        results = SimulationResults(results=[], logic_map=_make_logic_map())
        assert results.pass_rate == 0.0
        assert results.total == 0

    def test_dataset_property(self):
        results = self._make_results()
        dataset = results.dataset
        assert len(dataset) == 2
        assert dataset.traces[0].grade.passed is True
        assert dataset.traces[1].grade.passed is False

    def test_save(self, tmp_path):
        results = self._make_results()
        path = tmp_path / "sim_results.json"
        results.save(str(path))
        assert path.exists()

        import json

        with open(path) as f:
            data = json.load(f)
        assert data["summary"]["total"] == 2
        assert data["summary"]["passed"] == 1


# ---------------------------------------------------------------------------
# SimulatedUser tests
# ---------------------------------------------------------------------------


class TestSimulatedUser:
    @pytest.mark.asyncio
    async def test_generate_message(self):
        mock_llm = AsyncMock()
        mock_llm.generate = AsyncMock(return_value="Hi, I'd like to return a shirt.")

        user = SimulatedUser(llm=mock_llm)
        msg = await user.generate_message(
            scenario=_make_scenario(),
            logic_map=_make_logic_map(),
            conversation=[],
            turn_number=1,
            max_turns=3,
        )

        assert msg == "Hi, I'd like to return a shirt."
        mock_llm.generate.assert_called_once()

    @pytest.mark.asyncio
    async def test_generate_done_signal(self):
        mock_llm = AsyncMock()
        mock_llm.generate = AsyncMock(return_value="[DONE]")

        user = SimulatedUser(llm=mock_llm)
        msg = await user.generate_message(
            scenario=_make_scenario(),
            logic_map=_make_logic_map(),
            conversation=[
                {"role": "user", "content": "Thanks"},
                {"role": "assistant", "content": "You're welcome!"},
            ],
            turn_number=3,
            max_turns=3,
        )

        assert msg is None


# ---------------------------------------------------------------------------
# Simulator tests (with mocked components)
# ---------------------------------------------------------------------------


class TestSimulator:
    @pytest.mark.asyncio
    async def test_run_async_with_mocks(self):
        """Test full simulation flow with mocked LLM components."""
        logic_map = _make_logic_map()
        scenario = _make_scenario()
        verification = _make_verification(passed=True)

        # Mock agent
        def mock_agent(messages):
            return "Do you have a receipt? I'll process your refund."

        with (
            patch("synkro.simulation.simulator.LogicExtractor") as MockExtractor,
            patch("synkro.simulation.simulator.GoldenScenarioGenerator") as MockScenGen,
            patch("synkro.simulation.simulator.TraceVerifier") as MockVerifier,
            patch("synkro.simulation.simulator.SimulatedUser") as MockSimUser,
            patch("synkro.simulation.simulator.LLM"),
        ):
            # Configure mocks
            MockExtractor.return_value.extract = AsyncMock(return_value=logic_map)
            MockScenGen.return_value.generate = AsyncMock(return_value=[scenario])
            MockVerifier.return_value.verify = AsyncMock(return_value=verification)

            # SimulatedUser: return one message then signal done
            sim_user_instance = MockSimUser.return_value
            sim_user_instance.generate_message = AsyncMock(
                side_effect=["I want to return this shirt.", None]
            )

            sim = Simulator(model="gpt-4o-mini")
            results = await sim.run_async(
                agent=mock_agent,
                policy="Refunds require a receipt. Max refund is $500.",
                scenarios=1,
                turns=3,
            )

        assert results.total == 1
        assert results.passed == 1
        assert results.pass_rate == 1.0

    @pytest.mark.asyncio
    async def test_async_agent_support(self):
        """Test that async agents are properly awaited."""
        logic_map = _make_logic_map()
        scenario = _make_scenario()
        verification = _make_verification(passed=True)

        # Async agent
        async def async_agent(messages):
            return "I can help with that refund."

        with (
            patch("synkro.simulation.simulator.LogicExtractor") as MockExtractor,
            patch("synkro.simulation.simulator.GoldenScenarioGenerator") as MockScenGen,
            patch("synkro.simulation.simulator.TraceVerifier") as MockVerifier,
            patch("synkro.simulation.simulator.SimulatedUser") as MockSimUser,
            patch("synkro.simulation.simulator.LLM"),
        ):
            MockExtractor.return_value.extract = AsyncMock(return_value=logic_map)
            MockScenGen.return_value.generate = AsyncMock(return_value=[scenario])
            MockVerifier.return_value.verify = AsyncMock(return_value=verification)

            sim_user_instance = MockSimUser.return_value
            sim_user_instance.generate_message = AsyncMock(
                side_effect=["Return this please.", None]
            )

            sim = Simulator(model="gpt-4o-mini")
            results = await sim.run_async(
                agent=async_agent,
                policy="Refunds require a receipt.",
                scenarios=1,
                turns=3,
            )

        assert results.total == 1
        assert results.passed == 1

    @pytest.mark.asyncio
    async def test_multi_turn_conversation(self):
        """Test that multi-turn conversations work correctly."""
        logic_map = _make_logic_map()
        scenario = _make_scenario()
        verification = _make_verification(passed=True)

        call_count = 0

        def mock_agent(messages):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return "Do you have a receipt?"
            return "Great, I'll process your $50 refund."

        with (
            patch("synkro.simulation.simulator.LogicExtractor") as MockExtractor,
            patch("synkro.simulation.simulator.GoldenScenarioGenerator") as MockScenGen,
            patch("synkro.simulation.simulator.TraceVerifier") as MockVerifier,
            patch("synkro.simulation.simulator.SimulatedUser") as MockSimUser,
            patch("synkro.simulation.simulator.LLM"),
        ):
            MockExtractor.return_value.extract = AsyncMock(return_value=logic_map)
            MockScenGen.return_value.generate = AsyncMock(return_value=[scenario])
            MockVerifier.return_value.verify = AsyncMock(return_value=verification)

            sim_user_instance = MockSimUser.return_value
            sim_user_instance.generate_message = AsyncMock(
                side_effect=[
                    "I want to return a shirt I bought.",
                    "Yes, here's my receipt.",
                    None,  # Done
                ]
            )

            sim = Simulator(model="gpt-4o-mini")
            results = await sim.run_async(
                agent=mock_agent,
                policy="Refunds require a receipt.",
                scenarios=1,
                turns=5,
            )

        assert results.total == 1
        # Agent was called twice (2 user messages before [DONE])
        assert call_count == 2
        # Messages: user, assistant, user, assistant = 4
        assert len(results.results[0].messages) == 4

    @pytest.mark.asyncio
    async def test_failed_verification(self):
        """Test handling of failed verification."""
        logic_map = _make_logic_map()
        scenario = _make_scenario()
        verification = _make_verification(passed=False)

        def mock_agent(messages):
            return "Sure, here's your refund!"  # Doesn't check receipt

        with (
            patch("synkro.simulation.simulator.LogicExtractor") as MockExtractor,
            patch("synkro.simulation.simulator.GoldenScenarioGenerator") as MockScenGen,
            patch("synkro.simulation.simulator.TraceVerifier") as MockVerifier,
            patch("synkro.simulation.simulator.SimulatedUser") as MockSimUser,
            patch("synkro.simulation.simulator.LLM"),
        ):
            MockExtractor.return_value.extract = AsyncMock(return_value=logic_map)
            MockScenGen.return_value.generate = AsyncMock(return_value=[scenario])
            MockVerifier.return_value.verify = AsyncMock(return_value=verification)

            sim_user_instance = MockSimUser.return_value
            sim_user_instance.generate_message = AsyncMock(side_effect=["I want a refund.", None])

            sim = Simulator(model="gpt-4o-mini")
            results = await sim.run_async(
                agent=mock_agent,
                policy="Refunds require a receipt.",
                scenarios=1,
                turns=3,
            )

        assert results.total == 1
        assert results.failed == 1
        assert results.pass_rate == 0.0
        assert len(results.results[0].issues) > 0


# ---------------------------------------------------------------------------
# Import tests
# ---------------------------------------------------------------------------


class TestImports:
    def test_simulation_imports(self):
        from synkro import SimulationResult, SimulationResults, Simulator, simulate, simulate_async

        assert Simulator is not None
        assert SimulationResult is not None
        assert SimulationResults is not None
        assert simulate is not None
        assert simulate_async is not None

    def test_simulation_submodule_imports(self):
        from synkro.simulation import Simulator
        from synkro.simulation.simulated_user import SimulatedUser
        from synkro.simulation.simulator import Simulator as Sim2

        assert Simulator is Sim2
        assert SimulatedUser is not None
