"""Types for agent simulation results."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Iterator

from pydantic import BaseModel, Field

from synkro.core.dataset import Dataset
from synkro.types.core import GradeResult, Message, Trace
from synkro.types.logic_map import GoldenScenario, LogicMap
from synkro.types.logic_map import VerificationResult as LogicMapVerificationResult


class SimulationResult(BaseModel):
    """Result of simulating a single scenario against an agent."""

    scenario: GoldenScenario = Field(description="The scenario that was simulated")
    messages: list[dict] = Field(
        default_factory=list,
        description="Full conversation transcript (OpenAI-format dicts)",
    )
    passed: bool = Field(description="Whether the agent passed verification")
    issues: list[str] = Field(default_factory=list, description="Issues found during verification")
    verification: LogicMapVerificationResult = Field(
        description="Full verification details from the auditor"
    )

    def model_dump(self, **kwargs) -> dict:
        """Custom serialization."""
        data = super().model_dump(**kwargs)
        return data


class SimulationResults(BaseModel):
    """Aggregated results from running all simulation scenarios."""

    results: list[SimulationResult] = Field(default_factory=list)
    logic_map: LogicMap = Field(description="The logic map extracted from the policy")

    @property
    def pass_rate(self) -> float:
        """Fraction of scenarios that passed (0.0 - 1.0)."""
        if not self.results:
            return 0.0
        return self.passed / self.total

    @property
    def total(self) -> int:
        """Total number of scenarios simulated."""
        return len(self.results)

    @property
    def passed(self) -> int:
        """Number of scenarios that passed."""
        return sum(1 for r in self.results if r.passed)

    @property
    def failed(self) -> int:
        """Number of scenarios that failed."""
        return sum(1 for r in self.results if not r.passed)

    @property
    def dataset(self) -> Dataset:
        """Convert simulation results to a Dataset for export."""
        traces = []
        for result in self.results:
            messages = [
                Message(role=m["role"], content=m.get("content", "")) for m in result.messages
            ]
            scenario = result.scenario.to_base_scenario()
            grade = GradeResult(
                passed=result.passed,
                issues=result.issues,
                feedback="; ".join(result.issues) if result.issues else "Passed",
            )
            traces.append(Trace(messages=messages, scenario=scenario, grade=grade))
        return Dataset(traces=traces)

    def save(self, path: str | Path) -> None:
        """Save simulation results to JSON."""
        path = Path(path)
        data = {
            "summary": {
                "total": self.total,
                "passed": self.passed,
                "failed": self.failed,
                "pass_rate": self.pass_rate,
            },
            "results": [r.model_dump() for r in self.results],
            "logic_map": self.logic_map.model_dump(),
        }
        with open(path, "w") as f:
            json.dump(data, f, indent=2)

    def __iter__(self) -> Iterator[SimulationResult]:
        return iter(self.results)

    def __len__(self) -> int:
        return len(self.results)

    def __str__(self) -> str:
        return (
            f"SimulationResults(total={self.total}, "
            f"passed={self.passed}, failed={self.failed}, "
            f"pass_rate={self.pass_rate:.1%})"
        )

    def __repr__(self) -> str:
        return self.__str__()


__all__ = ["SimulationResult", "SimulationResults"]
