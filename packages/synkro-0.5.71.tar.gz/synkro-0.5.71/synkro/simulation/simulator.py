"""Simulator - Orchestrates agent simulation with auto-generated scenarios.

Runs generated scenarios against a live agent using an LLM-driven simulated
user, then verifies conversations against the extracted policy rules.
"""

from __future__ import annotations

import asyncio
from typing import Awaitable, Callable, Union

from synkro.generation.golden_scenarios import GoldenScenarioGenerator
from synkro.generation.logic_extractor import LogicExtractor
from synkro.llm.client import LLM
from synkro.quality.verifier import TraceVerifier
from synkro.simulation.simulated_user import SimulatedUser
from synkro.simulation.types import SimulationResult, SimulationResults
from synkro.types.core import Category, Message, Trace
from synkro.types.logic_map import GoldenScenario, LogicMap

# Agent callable types
AgentCallable = Union[
    Callable[[list[dict]], str],
    Callable[[list[dict]], Awaitable[str]],
]

# Default concurrency for parallel scenario execution
DEFAULT_CONCURRENCY = 5


class Simulator:
    """Orchestrates agent simulation with policy-grounded verification.

    Reuses Synkro's existing pipeline components:
    - LogicExtractor for rule extraction
    - GoldenScenarioGenerator for scenario generation
    - TraceVerifier for conversation verification

    Example:
        >>> sim = Simulator(model="gpt-4o-mini")
        >>> results = sim.run(agent=my_agent, policy="...", scenarios=10)
        >>> print(results.pass_rate)
    """

    def __init__(
        self,
        model: str | None = None,
        grading_model: str | None = None,
        concurrency: int = DEFAULT_CONCURRENCY,
    ):
        """Initialize the simulator.

        Args:
            model: Model for simulated user and scenario generation.
                Auto-detected if not specified.
            grading_model: Model for verification/grading.
                Defaults to model if not specified.
            concurrency: Max concurrent scenario executions.
        """
        self._model = model
        self._grading_model = grading_model or model
        self._concurrency = concurrency

    def _get_model(self) -> str:
        """Resolve model, auto-detecting if needed."""
        if self._model is not None:
            return self._model
        from synkro.utils.model_detection import get_default_model

        return get_default_model()

    def _get_grading_model(self) -> str:
        """Resolve grading model."""
        if self._grading_model is not None:
            return self._grading_model
        from synkro.utils.model_detection import get_default_grading_model

        return get_default_grading_model()

    def run(
        self,
        agent: AgentCallable,
        policy: str,
        scenarios: int = 10,
        turns: int = 3,
    ) -> SimulationResults:
        """Run simulation synchronously.

        Args:
            agent: Callable that takes OpenAI-format messages and returns a string.
                Can be sync or async.
            policy: Policy document text.
            scenarios: Number of scenarios to auto-generate.
            turns: Max conversation turns per scenario.

        Returns:
            SimulationResults with pass/fail details for each scenario.
        """
        return asyncio.run(
            self.run_async(agent=agent, policy=policy, scenarios=scenarios, turns=turns)
        )

    async def run_async(
        self,
        agent: AgentCallable,
        policy: str,
        scenarios: int = 10,
        turns: int = 3,
    ) -> SimulationResults:
        """Run simulation asynchronously.

        Args:
            agent: Callable that takes OpenAI-format messages and returns a string.
            policy: Policy document text.
            scenarios: Number of scenarios to auto-generate.
            turns: Max conversation turns per scenario.

        Returns:
            SimulationResults with pass/fail details for each scenario.
        """
        model = self._get_model()
        grading_model = self._get_grading_model()

        # Create LLM clients
        gen_llm = LLM(model=model, temperature=0.7)
        grade_llm = LLM(model=grading_model, temperature=0.1)

        # Stage 1: Extract rules
        extractor = LogicExtractor(llm=gen_llm)
        logic_map = await extractor.extract(policy)

        # Stage 2: Generate scenarios
        scenario_gen = GoldenScenarioGenerator(llm=gen_llm)
        category = Category(
            name="simulation",
            description="Auto-generated scenarios for agent simulation",
            count=scenarios,
        )
        golden_scenarios = await scenario_gen.generate(
            policy_text=policy,
            logic_map=logic_map,
            category=category,
            count=scenarios,
        )

        # Stage 3: Run conversations concurrently
        simulated_user = SimulatedUser(llm=gen_llm)
        verifier = TraceVerifier(llm=grade_llm)
        semaphore = asyncio.Semaphore(self._concurrency)

        async def run_one(scenario: GoldenScenario) -> SimulationResult:
            async with semaphore:
                return await self._run_scenario(
                    agent=agent,
                    scenario=scenario,
                    logic_map=logic_map,
                    policy=policy,
                    simulated_user=simulated_user,
                    verifier=verifier,
                    max_turns=turns,
                )

        results = await asyncio.gather(*(run_one(s) for s in golden_scenarios))

        return SimulationResults(
            results=list(results),
            logic_map=logic_map,
        )

    async def _run_scenario(
        self,
        agent: AgentCallable,
        scenario: GoldenScenario,
        logic_map: LogicMap,
        policy: str,
        simulated_user: SimulatedUser,
        verifier: TraceVerifier,
        max_turns: int,
    ) -> SimulationResult:
        """Run a single scenario: conversation loop + verification."""
        messages: list[dict] = []
        is_async_agent = asyncio.iscoroutinefunction(agent)

        for turn in range(1, max_turns + 1):
            # Simulated user generates message
            user_msg = await simulated_user.generate_message(
                scenario=scenario,
                logic_map=logic_map,
                conversation=messages,
                turn_number=turn,
                max_turns=max_turns,
            )
            if user_msg is None:
                break

            messages.append({"role": "user", "content": user_msg})

            # Call the agent
            if is_async_agent:
                agent_response = await agent(messages)
            else:
                agent_response = agent(messages)

            messages.append({"role": "assistant", "content": agent_response})

        # Build Trace for verification
        trace_messages = [Message(role=m["role"], content=m.get("content", "")) for m in messages]
        trace = Trace(
            messages=trace_messages,
            scenario=scenario.to_base_scenario(),
        )

        # Verify conversation against policy rules
        verification = await verifier.verify(
            trace=trace,
            logic_map=logic_map,
            scenario=scenario,
        )

        return SimulationResult(
            scenario=scenario,
            messages=messages,
            passed=verification.passed,
            issues=verification.issues,
            verification=verification,
        )


__all__ = ["Simulator"]
