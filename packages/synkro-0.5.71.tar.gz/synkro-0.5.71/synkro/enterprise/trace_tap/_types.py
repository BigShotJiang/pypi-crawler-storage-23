"""Pydantic models for trace tap events — used for docs and test assertions."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ToolCallPayload(BaseModel):
    """A single tool call extracted from a trace."""

    name: str
    arguments: dict[str, Any] = Field(default_factory=dict)
    response: str | None = None
    status: str = "success"


class TraceMetadata(BaseModel):
    """Metadata attached to every forwarded trace event."""

    run_type: str = "llm"
    name: str = ""
    latency_ms: int | None = None
    status: str = "success"
    tags: list[str] = Field(default_factory=list)
    parent_run_id: str | None = None
    prompt_tokens: int | None = None
    completion_tokens: int | None = None


class TraceEvent(BaseModel):
    """A normalized trace event ready for the Synkro backend."""

    source: str  # "langsmith" | "langfuse"
    project: str
    trace_id: str
    external_id: str = ""
    messages: list[dict[str, Any]] = Field(default_factory=list)
    model: str = ""
    tool_calls: list[ToolCallPayload] = Field(default_factory=list)
    metadata: TraceMetadata = Field(default_factory=TraceMetadata)
