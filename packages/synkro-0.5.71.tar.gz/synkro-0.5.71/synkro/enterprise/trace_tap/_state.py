"""Global singleton state for the trace tap system."""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from synkro.enterprise.trace_tap._langfuse_tap import LangfuseTap
    from synkro.enterprise.trace_tap._langsmith_tap import LangSmithTap
    from synkro.enterprise.trace_tap._worker import TraceWorker


@dataclass
class _TraceTapState:
    initialized: bool = False
    enabled: bool = True
    api_key: str = ""
    project: str = ""
    ingest_url: str = ""
    worker: TraceWorker | None = None
    langsmith_tap: LangSmithTap | None = None
    langfuse_tap: LangfuseTap | None = None
    _lock: threading.Lock = field(default_factory=threading.Lock)


_state = _TraceTapState()
