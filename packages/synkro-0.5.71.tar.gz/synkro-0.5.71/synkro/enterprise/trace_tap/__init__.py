"""Trace Tap — intercept LangSmith/Langfuse traces and forward to Synkro."""

from __future__ import annotations

import atexit
import logging
import os
from contextlib import contextmanager
from typing import Generator

from synkro.enterprise.trace_tap._state import _state

logger = logging.getLogger("synkro.trace_tap")

__all__ = ["init", "disable", "enable"]

_DEFAULT_BASE_URL = "https://api.synkro.sh"


def _resolve_ingest_url(ingest_url: str | None) -> str:
    """Resolve ingest URL from explicit arg, env var, or default."""
    if ingest_url:
        return ingest_url
    base = os.environ.get("SYNKRO_BASE_URL", _DEFAULT_BASE_URL).rstrip("/")
    return f"{base}/api/traces"


def init(
    api_key: str | None = None,
    project: str | None = None,
    *,
    ingest_url: str | None = None,
    batch_size: int = 50,
    flush_interval: float = 5.0,
) -> None:
    """Start the trace tap: patches LangSmith/Langfuse to forward traces to Synkro.

    Args:
        api_key: Synkro API key. Falls back to ``SYNKRO_API_KEY`` env var.
        project: Project slug. Falls back to ``SYNKRO_PROJECT`` env var.
        ingest_url: Override ingest endpoint. Defaults to ``SYNKRO_BASE_URL/api/traces``.
        batch_size: Events per HTTP batch (default 50).
        flush_interval: Max seconds between flushes (default 5.0).

    Idempotent — calling twice logs a warning and returns.
    """
    with _state._lock:
        if _state.initialized:
            logger.warning("synkro.trace_tap: already initialized, ignoring duplicate init()")
            return

        api_key = api_key or os.environ.get("SYNKRO_API_KEY", "")
        project = project or os.environ.get("SYNKRO_PROJECT", "default")
        resolved_url = _resolve_ingest_url(ingest_url)

        from synkro.enterprise.trace_tap._langfuse_tap import LangfuseTap
        from synkro.enterprise.trace_tap._langsmith_tap import LangSmithTap
        from synkro.enterprise.trace_tap._worker import TraceWorker

        _state.api_key = api_key
        _state.project = project
        _state.ingest_url = resolved_url
        _state.enabled = True

        # Start background worker
        _state.worker = TraceWorker(
            ingest_url=resolved_url,
            api_key=api_key,
            batch_size=batch_size,
            flush_interval=flush_interval,
        )

        # Install taps
        _state.langsmith_tap = LangSmithTap(worker=_state.worker, project=project)
        _state.langsmith_tap.install()

        _state.langfuse_tap = LangfuseTap(worker=_state.worker, project=project)
        _state.langfuse_tap.install()

        _state.initialized = True
        atexit.register(_shutdown)
        logger.debug("synkro.trace_tap: initialized for project %r", project)


@contextmanager
def disable() -> Generator[None, None, None]:
    """Context manager to temporarily suppress trace forwarding."""
    prev = _state.enabled
    _state.enabled = False
    try:
        yield
    finally:
        _state.enabled = prev


def enable() -> None:
    """Re-enable trace forwarding after it was disabled."""
    _state.enabled = True


def _shutdown() -> None:
    """Flush the worker on exit."""
    if _state.worker is not None:
        try:
            _state.worker.flush()
        except Exception:
            pass
    if _state.langsmith_tap is not None:
        _state.langsmith_tap.uninstall()
    if _state.langfuse_tap is not None:
        _state.langfuse_tap.uninstall()
    _state.initialized = False
