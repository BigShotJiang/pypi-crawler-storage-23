"""Normalize LangSmith/Langfuse trace data into a common event format."""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("synkro.trace_tap")


def normalize_langsmith_run(run: dict[str, Any], project: str) -> dict[str, Any] | None:
    """Convert a LangSmith run dict into a normalized trace event."""
    run_type = run.get("run_type", "")
    if run_type in {"retriever", "embedding"}:
        return None

    trace_id = str(run.get("trace_id", run.get("id", "")))
    external_id = str(run.get("id", ""))

    messages = _extract_langsmith_messages(run)
    model = _extract_langsmith_model(run)
    tool_calls = _extract_langsmith_tool_calls(run)
    tokens = _extract_langsmith_tokens(run)
    latency = _extract_langsmith_latency(run)

    status = "error" if run.get("error") else "success"
    name = run.get("name", "")
    tags = run.get("tags", []) or []
    parent_run_id = str(run["parent_run_id"]) if run.get("parent_run_id") else None

    return {
        "source": "langsmith",
        "project": project,
        "trace_id": trace_id,
        "external_id": external_id,
        "messages": messages,
        "model": model,
        "tool_calls": tool_calls,
        "metadata": {
            "run_type": run_type or "llm",
            "name": name,
            "latency_ms": latency,
            "status": status,
            "tags": tags,
            "parent_run_id": parent_run_id,
            "prompt_tokens": tokens.get("prompt_tokens"),
            "completion_tokens": tokens.get("completion_tokens"),
        },
    }


def normalize_langfuse_event(
    event_type: str, body: dict[str, Any], project: str
) -> dict[str, Any] | None:
    """Convert a Langfuse event body into a normalized trace event."""
    allowed = {"generation-create", "generation-update", "span-create", "span-update"}
    if event_type not in allowed:
        return None

    trace_id = str(body.get("traceId", body.get("trace_id", "")))
    external_id = str(body.get("id", ""))

    messages = _normalize_messages(body.get("input"))
    model = body.get("model", "") or ""
    tool_calls = _extract_langfuse_tool_calls(body)
    tokens = _extract_langfuse_tokens(body)
    latency = body.get("latencyMs") or body.get("latency_ms")

    run_type = "llm" if "generation" in event_type else "chain"
    status = "error" if body.get("statusMessage") or body.get("level") == "ERROR" else "success"
    name = body.get("name", "") or ""

    return {
        "source": "langfuse",
        "project": project,
        "trace_id": trace_id,
        "external_id": external_id,
        "messages": messages,
        "model": model,
        "tool_calls": tool_calls,
        "metadata": {
            "run_type": run_type,
            "name": name,
            "latency_ms": int(latency) if latency else None,
            "status": status,
            "tags": body.get("tags", []) or [],
            "parent_run_id": str(body["parentObservationId"])
            if body.get("parentObservationId")
            else None,
            "prompt_tokens": tokens.get("prompt_tokens"),
            "completion_tokens": tokens.get("completion_tokens"),
        },
    }


# ── LangSmith helpers ──────────────────────────────────


def _extract_langsmith_messages(run: dict[str, Any]) -> list[dict[str, str]]:
    inputs = run.get("inputs") or {}
    outputs = run.get("outputs") or {}

    raw_messages = inputs.get("messages") or inputs.get("prompts") or inputs.get("input")
    messages = _normalize_messages(raw_messages)

    # Add assistant output
    generations = outputs.get("generations") or outputs.get("output")
    if generations:
        out_msgs = _extract_generation_messages(generations)
        if out_msgs:
            messages.extend(out_msgs)
        elif isinstance(generations, str):
            messages.append({"role": "assistant", "content": generations})

    return messages


def _extract_generation_messages(generations: Any) -> list[dict[str, str]]:
    """Extract assistant messages from LangSmith generations output.

    Handles nested list format: [[{text, message: {lc, kwargs}}, ...], ...]
    """
    messages: list[dict[str, str]] = []
    if not isinstance(generations, list):
        return _normalize_messages(generations)

    for item in generations:
        if isinstance(item, list):
            for gen in item:
                if not isinstance(gen, dict):
                    continue
                # Try message.kwargs.content (LangChain serialized)
                msg = gen.get("message")
                if isinstance(msg, dict):
                    msg_msgs = _normalize_messages(msg)
                    if msg_msgs:
                        messages.extend(msg_msgs)
                        continue
                # Fall back to text field
                text = gen.get("text")
                if text:
                    messages.append({"role": "assistant", "content": str(text)})
        elif isinstance(item, dict):
            msg = item.get("message")
            if isinstance(msg, dict):
                msg_msgs = _normalize_messages(msg)
                if msg_msgs:
                    messages.extend(msg_msgs)
                    continue
            text = item.get("text")
            if text:
                messages.append({"role": "assistant", "content": str(text)})
        elif isinstance(item, str):
            messages.append({"role": "assistant", "content": item})

    return messages


def _extract_langsmith_model(run: dict[str, Any]) -> str:
    extra = run.get("extra") or {}

    # Try invocation_params first
    inv_params = extra.get("invocation_params") or {}
    model = inv_params.get("model") or inv_params.get("model_name") or ""
    if model:
        return model

    # Try serialized.kwargs
    serialized = run.get("serialized") or {}
    kwargs = serialized.get("kwargs") or {}
    model = kwargs.get("model") or kwargs.get("model_name") or ""
    if model:
        return model

    # Try metadata
    metadata = extra.get("metadata") or {}
    return metadata.get("ls_model_name", "")


def _extract_langsmith_tool_calls(run: dict[str, Any]) -> list[dict[str, Any]]:
    tool_calls: list[dict[str, Any]] = []

    outputs = run.get("outputs") or {}
    generations = outputs.get("generations")
    if isinstance(generations, list):
        for gen_list in generations:
            items = gen_list if isinstance(gen_list, list) else [gen_list]
            for gen in items:
                if not isinstance(gen, dict):
                    continue
                msg = gen.get("message") or gen
                calls = msg.get("tool_calls") or msg.get("additional_kwargs", {}).get(
                    "tool_calls", []
                )
                for tc in calls:
                    if isinstance(tc, dict):
                        fn = tc.get("function") or tc
                        tool_calls.append(
                            {
                                "name": fn.get("name", ""),
                                "arguments": fn.get("arguments", {}),
                                "response": None,
                                "status": "success",
                            }
                        )

    # Tool run type → single tool call
    if run.get("run_type") == "tool":
        tool_calls.append(
            {
                "name": run.get("name", ""),
                "arguments": run.get("inputs", {}),
                "response": str(outputs) if outputs else None,
                "status": "error" if run.get("error") else "success",
            }
        )

    return tool_calls


def _extract_langsmith_tokens(run: dict[str, Any]) -> dict[str, int | None]:
    extra = run.get("extra") or {}
    token_usage = extra.get("token_usage") or {}
    if token_usage:
        return {
            "prompt_tokens": token_usage.get("prompt_tokens"),
            "completion_tokens": token_usage.get("completion_tokens"),
        }

    outputs = run.get("outputs") or {}
    llm_output = outputs.get("llm_output") or {}
    token_usage = llm_output.get("token_usage") or {}
    return {
        "prompt_tokens": token_usage.get("prompt_tokens"),
        "completion_tokens": token_usage.get("completion_tokens"),
    }


def _extract_langsmith_latency(run: dict[str, Any]) -> int | None:
    start = run.get("start_time")
    end = run.get("end_time")
    if start and end:
        try:
            from datetime import datetime

            if isinstance(start, str):
                start = datetime.fromisoformat(start.replace("Z", "+00:00"))
            if isinstance(end, str):
                end = datetime.fromisoformat(end.replace("Z", "+00:00"))
            delta = end - start
            return int(delta.total_seconds() * 1000)
        except Exception:
            return None
    return None


# ── Langfuse helpers ──────────────────────────────────


def _extract_langfuse_tool_calls(body: dict[str, Any]) -> list[dict[str, Any]]:
    output = body.get("output")
    if not isinstance(output, dict):
        return []
    calls = output.get("tool_calls", [])
    result = []
    for tc in calls:
        if isinstance(tc, dict):
            fn = tc.get("function") or tc
            result.append(
                {
                    "name": fn.get("name", ""),
                    "arguments": fn.get("arguments", {}),
                    "response": None,
                    "status": "success",
                }
            )
    return result


def _extract_langfuse_tokens(body: dict[str, Any]) -> dict[str, int | None]:
    usage = body.get("usage") or {}
    if usage:
        return {
            "prompt_tokens": usage.get("promptTokens") or usage.get("prompt_tokens"),
            "completion_tokens": usage.get("completionTokens") or usage.get("completion_tokens"),
        }
    return {
        "prompt_tokens": body.get("promptTokens"),
        "completion_tokens": body.get("completionTokens"),
    }


# ── Shared message normalization ──────────────────────


def _normalize_messages(raw: Any) -> list[dict[str, str]]:
    """Normalize various message formats into [{role, content}] dicts."""
    if raw is None:
        return []

    if isinstance(raw, str):
        return [{"role": "user", "content": raw}]

    if isinstance(raw, dict):
        # OpenAI-style dict with role/content
        if "role" in raw and "content" in raw:
            content = raw["content"]
            # Handle vision content parts
            if isinstance(content, list):
                text_parts = []
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        text_parts.append(part.get("text", ""))
                    elif isinstance(part, str):
                        text_parts.append(part)
                content = " ".join(text_parts)
            return [{"role": raw["role"], "content": str(content)}]
        # LangChain serialized message: {lc: 1, type: "constructor", id: [...], kwargs: {content, type}}
        if raw.get("lc") and raw.get("kwargs"):
            kwargs = raw["kwargs"]
            content = kwargs.get("content", "")
            msg_type = kwargs.get("type", "")
            role_map = {"human": "user", "ai": "assistant", "system": "system"}
            role = role_map.get(msg_type, msg_type or "user")
            if content:
                return [{"role": role, "content": str(content)}]
            return []
        return []

    if isinstance(raw, (list, tuple)):
        messages = []
        for item in raw:
            if isinstance(item, dict):
                msgs = _normalize_messages(item)
                messages.extend(msgs)
            elif isinstance(item, (list, tuple)):
                # Nested lists (e.g., LangChain message batches)
                if len(item) == 2 and isinstance(item[0], str) and isinstance(item[1], str):
                    # Tuple of (role, content)
                    messages.append({"role": item[0], "content": item[1]})
                else:
                    messages.extend(_normalize_messages(item))
            elif isinstance(item, str):
                messages.append({"role": "user", "content": item})
            elif hasattr(item, "content") and hasattr(item, "type"):
                # LangChain message objects
                role = getattr(item, "type", "user")
                role_map = {"human": "user", "ai": "assistant", "system": "system"}
                role = role_map.get(role, role)
                content = getattr(item, "content", "")
                messages.append({"role": role, "content": str(content)})
        return messages

    # Last resort: try to get content/type from object
    if hasattr(raw, "content") and hasattr(raw, "type"):
        role = getattr(raw, "type", "user")
        role_map = {"human": "user", "ai": "assistant", "system": "system"}
        role = role_map.get(role, role)
        return [{"role": role, "content": str(getattr(raw, "content", ""))}]

    return []
