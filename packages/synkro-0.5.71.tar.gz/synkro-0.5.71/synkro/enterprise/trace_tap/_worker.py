"""Background thread worker that batches and forwards trace events."""

from __future__ import annotations

import logging
import queue
import threading
import time
from typing import Any

logger = logging.getLogger("synkro.trace_tap")


class TraceWorker:
    """Daemon thread that drains a queue and POSTs batches to the ingest endpoint."""

    def __init__(
        self,
        ingest_url: str,
        api_key: str,
        batch_size: int = 50,
        flush_interval: float = 5.0,
    ) -> None:
        self._ingest_url = ingest_url
        self._api_key = api_key
        self._batch_size = batch_size
        self._flush_interval = flush_interval
        self._queue: queue.Queue[dict[str, Any]] = queue.Queue(maxsize=10_000)
        self._stop = threading.Event()
        self._warned_full = False
        self._warned_send = False
        self._client: Any = None  # lazy httpx.Client
        self._thread = threading.Thread(target=self._run, daemon=True, name="synkro-trace-tap")
        self._thread.start()

    def _get_client(self) -> Any:
        if self._client is None:
            import httpx

            self._client = httpx.Client(timeout=10.0)
        return self._client

    def enqueue(self, event: dict[str, Any]) -> None:
        """Non-blocking enqueue. Drops silently if queue is full."""
        try:
            self._queue.put_nowait(event)
        except queue.Full:
            if not self._warned_full:
                logger.warning("synkro.trace_tap: queue full, dropping events")
                self._warned_full = True

    def _run(self) -> None:
        while not self._stop.is_set():
            batch = self._drain(self._batch_size, self._flush_interval)
            if batch:
                self._send(batch)

    def _drain(self, max_items: int, timeout: float) -> list[dict[str, Any]]:
        batch: list[dict[str, Any]] = []
        deadline = time.monotonic() + timeout
        while len(batch) < max_items:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            try:
                item = self._queue.get(timeout=min(remaining, 0.5))
                batch.append(item)
            except queue.Empty:
                if self._stop.is_set():
                    break
        return batch

    def _send(self, batch: list[dict[str, Any]]) -> None:
        try:
            client = self._get_client()
            resp = client.post(
                self._ingest_url,
                json=batch,
                headers={
                    "x-api-key": self._api_key,
                    "Content-Type": "application/json",
                },
            )
            if resp.status_code >= 400 and not self._warned_send:
                logger.warning(
                    "synkro.trace_tap: ingest returned %s: %s",
                    resp.status_code,
                    resp.text[:200],
                )
                self._warned_send = True
        except Exception:
            if not self._warned_send:
                logger.warning("synkro.trace_tap: failed to send batch to %s", self._ingest_url)
                self._warned_send = True

    def flush(self) -> None:
        """Drain remaining items and shut down."""
        self._stop.set()
        self._thread.join(timeout=5.0)
        # Drain any remaining items
        remaining: list[dict[str, Any]] = []
        while True:
            try:
                remaining.append(self._queue.get_nowait())
            except queue.Empty:
                break
        if remaining:
            self._send(remaining)
        if self._client is not None:
            try:
                self._client.close()
            except Exception:
                pass
