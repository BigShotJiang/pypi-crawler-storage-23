"""Provider resolution — maps model strings to gateway provider names."""

from __future__ import annotations

# Provider names the gateway accepts (from the error message).
# We map our internal names to the gateway's expected names.
_GATEWAY_PROVIDER: dict[str, str] = {
    "openai": "openai",
    "anthropic": "anthropic",
    "google": "google",
    "mistral": "mistral-ai",
    "groq": "groq",
    "xai": "x-ai",
    "together_ai": "together-ai",
    "fireworks_ai": "fireworks-ai",
    "deepseek": "deepseek",
    "cohere": "cohere",
    "perplexity": "perplexity-ai",
    "cerebras": "cerebras",
    "openrouter": "openrouter",
    "bedrock": "bedrock",
    "azure": "azure-openai",
    "huggingface": "huggingface",
    "ollama": "ollama",
    "replicate": "replicate",
}

_PREFIX_MAP: list[tuple[str, str]] = [
    ("gpt-", "openai"),
    ("o1", "openai"),
    ("o3", "openai"),
    ("o4", "openai"),
    ("chatgpt-", "openai"),
    ("claude-", "anthropic"),
    ("gemini", "google"),
    ("mistral", "mistral"),
    ("groq/", "groq"),
    ("xai/", "xai"),
    ("together_ai/", "together_ai"),
    ("fireworks_ai/", "fireworks_ai"),
    ("deepseek", "deepseek"),
    ("command", "cohere"),
    ("sonar", "perplexity"),
    ("cerebras/", "cerebras"),
    ("openrouter/", "openrouter"),
]

_LITELLM_ALIASES: dict[str, str] = {
    "vertex_ai": "google",
    "vertex_ai_beta": "google",
    "gemini": "google",
}


def resolve_upstream(model: str) -> tuple[str, str]:
    """Resolve a model string to ``(gateway_provider, clean_model)``.

    Tries litellm's ``get_llm_provider()`` first, falls back to prefix matching.

    Returns:
        Tuple of (gateway provider name, model name to send to the upstream).

    Raises:
        ValueError: If the provider cannot be determined.
    """
    # Strip provider prefix for litellm-style "provider/model" strings
    clean_model = model
    if "/" in model:
        parts = model.split("/", 1)
        clean_model = parts[1]

    # Try litellm first
    try:
        from litellm import get_llm_provider

        _, provider, _, _ = get_llm_provider(model)
        provider = _LITELLM_ALIASES.get(provider, provider)
        if provider in _GATEWAY_PROVIDER:
            return _GATEWAY_PROVIDER[provider], clean_model
    except Exception:
        pass

    # Fallback: prefix matching
    lower = model.lower()
    for prefix, provider in _PREFIX_MAP:
        if lower.startswith(prefix):
            return _GATEWAY_PROVIDER[provider], clean_model

    raise ValueError(
        f"Cannot determine provider for model {model!r}. "
        "Use a 'provider/model' format (e.g. 'openai/gpt-4o') "
        "or install litellm for automatic detection."
    )
