"""Synkro enterprise client — main entry point."""

from __future__ import annotations

from synkro.enterprise._http import AsyncBaseHTTPClient, BaseHTTPClient
from synkro.enterprise.resources.integrations import AsyncIntegrations, Integrations
from synkro.enterprise.resources.policies import AsyncPolicies, Policies
from synkro.enterprise.resources.projects import AsyncProjects, Projects

DEFAULT_BASE_URL = "https://api.synkro.sh"
SYNKRO_GATEWAY_URL = "https://gateway.synkro.sh"


class Synkro:
    """Synkro enterprise client (synchronous).

    Args:
        api_key: API key (sk-synkro-xxx).
        gateway_url: Gateway URL for LLM proxying (e.g. ``https://gateway.synkro.sh/v1/p/proj_xxx``).
            When provided, enables ``client.chat.completions.create()``.
        base_url: CRUD server URL. Defaults to https://api.synkro.sh.
        timeout: Request timeout in seconds.

    Example::

        client = Synkro(
            api_key="sk-synkro-xxx",
            gateway_url="http://localhost:8787/v1/p/proj_394a54b7b81a2214",
        )
        resp = client.chat.completions.create(
            model="gpt-4o", api_key=OPENAI_KEY, messages=[...],
            user_id="u1", conversation_id="conv-1",
        )
        resp.synkro.blocked  # True/False
    """

    projects: Projects
    policies: Policies
    integrations: Integrations

    def __init__(
        self,
        api_key: str,
        *,
        gateway_url: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ):
        self._api_key = api_key
        self._http = BaseHTTPClient(base_url=base_url, api_key=api_key, timeout=timeout)
        self.projects = Projects(self._http)
        self.policies = Policies(self._http)
        self.integrations = Integrations(self._http)

        # Gateway client (only when gateway_url provided)
        if gateway_url:
            try:
                from openai import OpenAI
            except ImportError:
                raise ImportError(
                    "openai is required for gateway_url support. "
                    "Install it with: pip install openai"
                )

            from synkro.enterprise.openai_wrapper import SynkroClient

            oai_kwargs: dict = {
                "base_url": gateway_url,
                "api_key": "x",
                "default_headers": {"x-synkro-api-key": api_key},
            }
            if timeout != 30.0:
                oai_kwargs["timeout"] = timeout

            self._universal = SynkroClient(OpenAI(**oai_kwargs))
            self.chat = self._universal.chat

    def openai_client(
        self,
        project: str,
        upstream: str,
        api_key: str,
        *,
        timeout: float | None = None,
    ):
        """Create a drop-in OpenAI replacement with ``.synkro`` on responses.

        Works with any OpenAI-compatible endpoint (OpenAI, MindsDB, Ollama, etc.).
        Pass ``user_id`` and ``conversation_id`` per-call on ``.create()``.

        Args:
            project: Project slug.
            upstream: Upstream provider base URL (e.g. "https://api.openai.com/v1").
            api_key: The *provider's* API key.
            timeout: Request timeout in seconds (passed to OpenAI client).

        Returns:
            SynkroOpenAI instance.
        """
        try:
            from openai import OpenAI
        except ImportError:
            raise ImportError(
                "openai is required for synkro.openai_client(). "
                "Install it with: pip install openai"
            )

        from synkro.enterprise.openai_wrapper import SynkroOpenAI

        base_url = SYNKRO_GATEWAY_URL + "/v1/p/" + project
        headers = {
            "x-synkro-api-key": self._api_key,
            "x-synkro-upstream": upstream,
        }

        kwargs: dict = {
            "base_url": base_url,
            "api_key": api_key,
            "default_headers": headers,
        }
        if timeout is not None:
            kwargs["timeout"] = timeout

        return SynkroOpenAI(OpenAI(**kwargs))

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._http.close()

    def __enter__(self) -> Synkro:
        return self

    def __exit__(self, *args) -> None:
        self.close()


class AsyncSynkro:
    """Synkro enterprise client (asynchronous).

    Args:
        api_key: API key (sk-synkro-xxx).
        gateway_url: Gateway URL for LLM proxying.
        base_url: CRUD server URL. Defaults to https://api.synkro.sh.
        timeout: Request timeout in seconds.

    Example::

        client = AsyncSynkro(
            api_key="sk-synkro-xxx",
            gateway_url="http://localhost:8787/v1/p/proj_xxx",
        )
        resp = await client.chat.completions.create(
            model="gpt-4o", api_key=OPENAI_KEY, messages=[...],
            user_id="u1", conversation_id="conv-1",
        )
    """

    projects: AsyncProjects
    policies: AsyncPolicies
    integrations: AsyncIntegrations

    def __init__(
        self,
        api_key: str,
        *,
        gateway_url: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ):
        self._api_key = api_key
        self._http = AsyncBaseHTTPClient(base_url=base_url, api_key=api_key, timeout=timeout)
        self.projects = AsyncProjects(self._http)
        self.policies = AsyncPolicies(self._http)
        self.integrations = AsyncIntegrations(self._http)

        if gateway_url:
            try:
                from openai import AsyncOpenAI
            except ImportError:
                raise ImportError(
                    "openai is required for gateway_url support. "
                    "Install it with: pip install openai"
                )

            from synkro.enterprise.openai_wrapper import AsyncSynkroClient

            oai_kwargs: dict = {
                "base_url": gateway_url,
                "api_key": "x",
                "default_headers": {"x-synkro-api-key": api_key},
            }
            if timeout != 30.0:
                oai_kwargs["timeout"] = timeout

            self._universal = AsyncSynkroClient(AsyncOpenAI(**oai_kwargs))
            self.chat = self._universal.chat

    def openai_client(
        self,
        project: str,
        upstream: str,
        api_key: str,
        *,
        timeout: float | None = None,
    ):
        """Create an async drop-in OpenAI replacement with ``.synkro`` on responses.

        Works with any OpenAI-compatible endpoint (OpenAI, MindsDB, Ollama, etc.).
        Pass ``user_id`` and ``conversation_id`` per-call on ``.create()``.

        Args:
            project: Project slug.
            upstream: Upstream provider base URL (e.g. "https://api.openai.com/v1").
            api_key: The *provider's* API key.
            timeout: Request timeout in seconds (passed to AsyncOpenAI client).

        Returns:
            AsyncSynkroOpenAI instance.
        """
        try:
            from openai import AsyncOpenAI
        except ImportError:
            raise ImportError(
                "openai is required for synkro.openai_client(). "
                "Install it with: pip install openai"
            )

        from synkro.enterprise.openai_wrapper import AsyncSynkroOpenAI

        base_url = SYNKRO_GATEWAY_URL + "/v1/p/" + project
        headers = {
            "x-synkro-api-key": self._api_key,
            "x-synkro-upstream": upstream,
        }

        kwargs: dict = {
            "base_url": base_url,
            "api_key": api_key,
            "default_headers": headers,
        }
        if timeout is not None:
            kwargs["timeout"] = timeout

        return AsyncSynkroOpenAI(AsyncOpenAI(**kwargs))

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.close()

    async def __aenter__(self) -> AsyncSynkro:
        return self

    async def __aexit__(self, *args) -> None:
        await self.close()
