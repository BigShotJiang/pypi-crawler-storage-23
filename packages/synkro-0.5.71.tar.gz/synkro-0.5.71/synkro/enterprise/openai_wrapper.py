"""Drop-in OpenAI wrapper that exposes ``.synkro`` on responses."""

from __future__ import annotations

import json as _json
from dataclasses import dataclass, field


@dataclass
class PolicyIssue:
    """A single policy issue flagged by the gateway."""

    rule_id: str
    message: str
    severity: str = "warning"


@dataclass
class SynkroResult:
    """Policy result attached as ``.synkro`` on wrapped OpenAI responses."""

    blocked: bool = False
    refusal: str | None = None
    issues: list[PolicyIssue] = field(default_factory=list)


class _WrappedChatCompletion:
    """Wraps an OpenAI ``ChatCompletion`` and adds a ``.synkro`` attribute.

    All other attribute access is delegated to the underlying completion.
    """

    def __init__(self, completion, synkro: SynkroResult):
        self._completion = completion
        self.synkro = synkro

    def __getattr__(self, name: str):
        return getattr(self._completion, name)

    def __repr__(self) -> str:
        return f"_WrappedChatCompletion({self._completion!r}, synkro={self.synkro!r})"


def _parse_synkro_result(hook: dict) -> SynkroResult:
    """Parse ``hook_results`` dict into a SynkroResult."""
    issues = [
        PolicyIssue(
            rule_id=i.get("rule_id", ""),
            message=i.get("message", ""),
            severity=i.get("severity", "warning"),
        )
        for i in (hook.get("issues") or [])
    ]
    return SynkroResult(
        blocked=hook.get("blocked", False),
        refusal=hook.get("refusal"),
        issues=issues,
    )


class _WrappedCompletions:
    """Wraps ``client.chat.completions`` to intercept ``create()``."""

    def __init__(self, completions):
        self._completions = completions

    def create(self, *, user_id: str | None = None, conversation_id: str | None = None, **kwargs):
        extra = kwargs.pop("extra_headers", None) or {}
        if user_id:
            extra["x-synkro-user-id"] = user_id
        if conversation_id:
            extra["x-synkro-conversation-id"] = conversation_id
        if extra:
            kwargs["extra_headers"] = extra

        # Streaming: fall through to unwrapped client
        if kwargs.get("stream"):
            return self._completions.create(**kwargs)

        raw_response = self._completions.with_raw_response.create(**kwargs)

        # Extract hook_results from raw JSON before the SDK parses it
        try:
            body = _json.loads(raw_response.text)
            hook = body.get("hook_results") or {}
        except Exception:
            hook = {}

        synkro_result = _parse_synkro_result(hook)
        completion = raw_response.parse()
        return _WrappedChatCompletion(completion, synkro_result)

    def __getattr__(self, name: str):
        return getattr(self._completions, name)


class _AsyncWrappedCompletions:
    """Async version of _WrappedCompletions."""

    def __init__(self, completions):
        self._completions = completions

    async def create(
        self, *, user_id: str | None = None, conversation_id: str | None = None, **kwargs
    ):
        extra = kwargs.pop("extra_headers", None) or {}
        if user_id:
            extra["x-synkro-user-id"] = user_id
        if conversation_id:
            extra["x-synkro-conversation-id"] = conversation_id
        if extra:
            kwargs["extra_headers"] = extra

        if kwargs.get("stream"):
            return await self._completions.create(**kwargs)

        raw_response = await self._completions.with_raw_response.create(**kwargs)

        try:
            body = _json.loads(raw_response.text)
            hook = body.get("hook_results") or {}
        except Exception:
            hook = {}

        synkro_result = _parse_synkro_result(hook)
        completion = raw_response.parse()
        return _WrappedChatCompletion(completion, synkro_result)

    def __getattr__(self, name: str):
        return getattr(self._completions, name)


class _WrappedChat:
    """Wraps ``client.chat`` to expose wrapped completions."""

    def __init__(self, chat):
        self._chat = chat
        self.completions = _WrappedCompletions(chat.completions)

    def __getattr__(self, name: str):
        return getattr(self._chat, name)


class _AsyncWrappedChat:
    """Async version of _WrappedChat."""

    def __init__(self, chat):
        self._chat = chat
        self.completions = _AsyncWrappedCompletions(chat.completions)

    def __getattr__(self, name: str):
        return getattr(self._chat, name)


class SynkroOpenAI:
    """Drop-in replacement for ``openai.OpenAI`` that adds ``.synkro`` to responses.

    Use ``Synkro.openai_client()`` to create an instance — don't construct directly.

    Example::

        client = synkro.openai_client(project="my-proj", upstream="...", api_key=key)
        resp = client.chat.completions.create(model="gpt-4o", messages=[...])
        resp.synkro.blocked  # True/False
    """

    def __init__(self, client):
        self._client = client
        self.chat = _WrappedChat(client.chat)

    def __getattr__(self, name: str):
        return getattr(self._client, name)


class AsyncSynkroOpenAI:
    """Async drop-in replacement for ``openai.AsyncOpenAI``."""

    def __init__(self, client):
        self._client = client
        self.chat = _AsyncWrappedChat(client.chat)

    def __getattr__(self, name: str):
        return getattr(self._client, name)


# ── Universal client (per-call model/provider resolution) ──────────


class _UniversalCompletions:
    """Completions with per-call model resolution and provider API key."""

    def __init__(self, completions):
        self._completions = completions

    def create(
        self,
        *,
        model: str,
        api_key: str,
        user_id: str | None = None,
        conversation_id: str | None = None,
        **kwargs,
    ):
        from synkro.enterprise._provider import resolve_upstream

        provider, clean_model = resolve_upstream(model)
        extra_headers = {
            "x-synkro-config": _json.dumps({"provider": provider}),
            "Authorization": f"Bearer {api_key}",
        }
        if user_id:
            extra_headers["x-synkro-user-id"] = user_id
        if conversation_id:
            extra_headers["x-synkro-conversation-id"] = conversation_id

        if kwargs.get("stream"):
            return self._completions.create(
                model=clean_model,
                extra_headers=extra_headers,
                **kwargs,
            )

        raw_response = self._completions.with_raw_response.create(
            model=clean_model,
            extra_headers=extra_headers,
            **kwargs,
        )

        try:
            body = _json.loads(raw_response.text)
            hook = body.get("hook_results") or {}
        except Exception:
            hook = {}

        synkro_result = _parse_synkro_result(hook)
        completion = raw_response.parse()
        return _WrappedChatCompletion(completion, synkro_result)

    def __getattr__(self, name: str):
        return getattr(self._completions, name)


class _AsyncUniversalCompletions:
    """Async version of _UniversalCompletions."""

    def __init__(self, completions):
        self._completions = completions

    async def create(
        self,
        *,
        model: str,
        api_key: str,
        user_id: str | None = None,
        conversation_id: str | None = None,
        **kwargs,
    ):
        from synkro.enterprise._provider import resolve_upstream

        provider, clean_model = resolve_upstream(model)
        extra_headers = {
            "x-synkro-config": _json.dumps({"provider": provider}),
            "Authorization": f"Bearer {api_key}",
        }
        if user_id:
            extra_headers["x-synkro-user-id"] = user_id
        if conversation_id:
            extra_headers["x-synkro-conversation-id"] = conversation_id

        if kwargs.get("stream"):
            return await self._completions.create(
                model=clean_model,
                extra_headers=extra_headers,
                **kwargs,
            )

        raw_response = await self._completions.with_raw_response.create(
            model=clean_model,
            extra_headers=extra_headers,
            **kwargs,
        )

        try:
            body = _json.loads(raw_response.text)
            hook = body.get("hook_results") or {}
        except Exception:
            hook = {}

        synkro_result = _parse_synkro_result(hook)
        completion = raw_response.parse()
        return _WrappedChatCompletion(completion, synkro_result)

    def __getattr__(self, name: str):
        return getattr(self._completions, name)


class _UniversalChat:
    """Wraps ``client.chat`` with universal completions."""

    def __init__(self, chat):
        self._chat = chat
        self.completions = _UniversalCompletions(chat.completions)

    def __getattr__(self, name: str):
        return getattr(self._chat, name)


class _AsyncUniversalChat:
    """Async version of _UniversalChat."""

    def __init__(self, chat):
        self._chat = chat
        self.completions = _AsyncUniversalCompletions(chat.completions)

    def __getattr__(self, name: str):
        return getattr(self._chat, name)


class SynkroClient:
    """Universal LLM client with per-call model/provider resolution.

    Use via ``Synkro(gateway_url=...).chat`` — don't construct directly.
    """

    def __init__(self, client):
        self._client = client
        self.chat = _UniversalChat(client.chat)

    def __getattr__(self, name: str):
        return getattr(self._client, name)


class AsyncSynkroClient:
    """Async universal LLM client with per-call model/provider resolution."""

    def __init__(self, client):
        self._client = client
        self.chat = _AsyncUniversalChat(client.chat)

    def __getattr__(self, name: str):
        return getattr(self._client, name)
