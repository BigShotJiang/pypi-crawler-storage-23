# General Agent Guides

Condensed, project-agnostic copies of `CLAUDE.md` and `.claude/**`. Use them when
the original notes would leak repo specifics.
