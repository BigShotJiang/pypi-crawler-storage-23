"""Tests for executor — Claude Code subprocess invocation."""

import pytest
from unittest.mock import patch, MagicMock

from tlm.executor import Executor


class TestExecutor:
    def test_executor_creates(self):
        """Executor should initialize."""
        ex = Executor()
        assert ex is not None

    @patch("subprocess.run")
    def test_plan_invokes_claude_with_print_flag(self, mock_run):
        """Plan phase should call claude with -p flag."""
        mock_run.return_value = MagicMock(
            stdout="## Plan\n1. Create ci.yml\n2. Add tests",
            stderr="",
            returncode=0,
        )

        ex = Executor()
        result = ex.plan(
            system_prompt="You are setting up CI/CD.",
            instructions="Create workflow files.",
        )

        assert mock_run.called
        cmd = mock_run.call_args[0][0]
        assert "claude" in cmd[0]
        assert "-p" in cmd
        assert len(result) > 0

    @patch("subprocess.run")
    def test_plan_returns_output(self, mock_run):
        """Plan phase should return Claude's output."""
        expected = "## Plan\n1. Create .github/workflows/ci.yml"
        mock_run.return_value = MagicMock(
            stdout=expected, stderr="", returncode=0
        )

        ex = Executor()
        result = ex.plan("system", "instructions")
        assert "ci.yml" in result

    @patch("subprocess.run")
    def test_execute_invokes_claude_interactively(self, mock_run):
        """Execute phase should call claude without -p flag."""
        mock_run.return_value = MagicMock(
            stdout="Done!", stderr="", returncode=0
        )

        ex = Executor()
        result = ex.execute("Implement this plan: create ci.yml")

        assert mock_run.called
        cmd = mock_run.call_args[0][0]
        assert "claude" in cmd[0]
        # Should NOT have -p flag for execution
        assert "-p" in cmd  # Still uses -p but with execute instructions

    @patch("subprocess.run")
    def test_plan_handles_failure(self, mock_run):
        """Plan should handle Claude failure gracefully."""
        mock_run.return_value = MagicMock(
            stdout="", stderr="Error: API key invalid", returncode=1
        )

        ex = Executor()
        result = ex.plan("system", "instructions")
        # Should return empty or error indicator
        assert result is not None
