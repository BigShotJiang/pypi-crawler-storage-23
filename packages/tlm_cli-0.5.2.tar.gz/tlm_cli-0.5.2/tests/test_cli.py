"""Tests for CLI — auth, install, scan, gaps, fix, status, logout, uninstall, upgrade commands."""

import json
import click
import pytest
from unittest.mock import patch, MagicMock
from click.testing import CliRunner
from pathlib import Path

from tlm.cli import main, _is_firebase_token, _restore_terminal, _validate_install_directory, AUTH_URL
from tlm.client import (
    TLMCreditsError,
    TLMAuthError,
    TLMProjectLimitError,
    TLMServerError,
    TLMConnectionError,
)
from tlm.gaps import GapStatus


class TestIsFirebaseToken:
    def test_detects_firebase_jwt(self):
        """3-part dot-separated token >100 chars should be detected as Firebase."""
        # Realistic Firebase JWT structure (header.payload.signature)
        token = "eyJhbGciOiJSUzI1NiJ9." + "a" * 50 + "." + "b" * 50
        assert _is_firebase_token(token) is True

    def test_rejects_tlm_api_key(self):
        """tlm_sk_ prefixed keys should NOT be detected as Firebase."""
        assert _is_firebase_token("tlm_sk_abc123") is False

    def test_rejects_short_token(self):
        """Short tokens should NOT be detected as Firebase."""
        assert _is_firebase_token("short.but.jwt") is False


class TestAuthCommand:
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_auth_direct_api_key(self, mock_client_cls, mock_save):
        """tlm auth <tlm_sk_...> should verify and save directly."""
        mock_client = MagicMock()
        mock_client.me = MagicMock(return_value={"user_id": 1, "email": "test@x.com"})
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth", "tlm_sk_abc123"])

        assert result.exit_code == 0
        assert "test@x.com" in result.output
        mock_save.assert_called_once()

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_auth_firebase_exchange(self, mock_client_cls, mock_save):
        """tlm auth <firebase_jwt> should exchange for API key and save."""
        firebase_token = "eyJhbGciOiJSUzI1NiJ9." + "a" * 50 + "." + "b" * 50
        mock_client = MagicMock()
        mock_client.exchange_firebase_token = MagicMock(return_value={
            "api_key": "tlm_sk_exchanged",
            "user_id": 1,
            "email": "user@example.com",
        })
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth", firebase_token])

        assert result.exit_code == 0
        assert "user@example.com" in result.output
        mock_client.exchange_firebase_token.assert_called_once_with(firebase_token)
        # Should save the exchanged API key, not the Firebase token
        save_call = mock_save.call_args
        assert save_call[0][1] == "tlm_sk_exchanged"

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.get_api_key", return_value=None)
    def test_auth_interactive_prompt(self, mock_key, mock_client_cls, mock_save):
        """tlm auth (no args) should show URL and prompt for token."""
        mock_client = MagicMock()
        mock_client.me = MagicMock(return_value={"user_id": 1, "email": "test@x.com"})
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth"], input="tlm_sk_from_prompt\n")

        assert result.exit_code == 0
        assert AUTH_URL in result.output
        assert "test@x.com" in result.output
        mock_save.assert_called_once()

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.get_api_key", return_value=None)
    def test_auth_interactive_firebase(self, mock_key, mock_client_cls, mock_save):
        """Interactive mode: pasting a Firebase JWT should exchange it."""
        firebase_token = "eyJhbGciOiJSUzI1NiJ9." + "a" * 50 + "." + "b" * 50
        mock_client = MagicMock()
        mock_client.exchange_firebase_token = MagicMock(return_value={
            "api_key": "tlm_sk_interactive",
            "user_id": 1,
            "email": "firebase@x.com",
        })
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth"], input=firebase_token + "\n")

        assert result.exit_code == 0
        assert "firebase@x.com" in result.output
        save_call = mock_save.call_args
        assert save_call[0][1] == "tlm_sk_interactive"

    def test_auth_invalid_token(self):
        """tlm auth <garbage> should show error."""
        runner = CliRunner()
        result = runner.invoke(main, ["auth", "not-a-valid-token"])

        assert result.exit_code != 0
        assert "invalid" in result.output.lower()

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_auth_custom_server(self, mock_client_cls, mock_save):
        """tlm auth --server should use custom server URL."""
        mock_client = MagicMock()
        mock_client.me = MagicMock(return_value={"user_id": 1})
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth", "tlm_sk_key", "--server", "http://custom:9000"])

        assert result.exit_code == 0
        save_call = mock_save.call_args
        assert save_call[0][0] == "http://custom:9000"

    @patch("tlm.cli.TLMClient")
    def test_auth_exchange_failure(self, mock_client_cls):
        """Firebase exchange failure should show error."""
        firebase_token = "eyJhbGciOiJSUzI1NiJ9." + "a" * 50 + "." + "b" * 50
        mock_client = MagicMock()
        mock_client.exchange_firebase_token = MagicMock(
            side_effect=Exception("Invalid Firebase token")
        )
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth", firebase_token])

        assert result.exit_code != 0
        assert "failed" in result.output.lower()

    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_existing")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    def test_auth_already_logged_in(self, mock_url, mock_key, mock_client_cls):
        """tlm auth (no args) when already logged in should show status and exit."""
        mock_client = MagicMock()
        mock_client.me.return_value = {"email": "existing@x.com", "user_id": 1}
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth"])

        assert result.exit_code == 0
        assert "existing@x.com" in result.output
        assert "logout" in result.output.lower()

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_stale")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    def test_auth_stale_creds_reprompts(self, mock_url, mock_key,
                                        mock_client_cls, mock_save):
        """Stale creds (me() fails) should fall through to interactive prompt."""
        mock_client = MagicMock()
        # First call (pre-check) fails, second call (after new token) succeeds
        mock_client.me.side_effect = [
            Exception("Unauthorized"),
            {"email": "new@x.com", "user_id": 2},
        ]
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth"], input="tlm_sk_fresh\n")

        assert result.exit_code == 0
        assert AUTH_URL in result.output
        assert "new@x.com" in result.output
        mock_save.assert_called_once()

    @patch("tlm.cli.get_api_key", return_value=None)
    def test_auth_shows_url(self, mock_key):
        """Interactive auth should display the AUTH_URL."""
        runner = CliRunner()
        # Give invalid token to trigger URL display then error
        result = runner.invoke(main, ["auth"], input="not-a-valid-token\n")

        assert AUTH_URL in result.output

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_auth_verify_failure_still_saves(self, mock_client_cls, mock_save):
        """me() failure after saving key should warn but still save credentials."""
        mock_client = MagicMock()
        mock_client.me.side_effect = Exception("Server error")
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth", "tlm_sk_abc123"])

        # Should still save even though verification failed — but warn
        # Current behavior: exits with error. MVP warns but saves.
        # After fix: should save and warn.
        mock_save.assert_called_once()
        assert "warning" in result.output.lower() or "saved" in result.output.lower()

    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_auth_connection_error_warns(self, mock_client_cls, mock_save):
        """Connection error during verify should warn but still save."""
        mock_client = MagicMock()
        mock_client.me.side_effect = TLMConnectionError("Connection refused")
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["auth", "tlm_sk_abc123"])

        mock_save.assert_called_once()
        assert result.exit_code == 0
        assert "warning" in result.output.lower() or "saved" in result.output.lower()

    @patch("tlm.cli.get_api_key", return_value=None)
    def test_auth_keyboard_interrupt(self, mock_key):
        """Ctrl+C during token prompt should exit cleanly."""
        runner = CliRunner()
        # Empty input simulates EOF / Ctrl+C for click.prompt
        result = runner.invoke(main, ["auth"], input="")

        # Should not show a traceback
        assert "Traceback" not in result.output


class TestInstallCommand:
    """Tests for the new install flow: auto-auth, config generation, approval, install_full."""

    def _make_mocks(self):
        """Helper: create common mock objects for install tests."""
        mock_installer = MagicMock()
        mock_installer.scan_project.return_value = {"file_tree": "app.py", "samples": "code"}
        mock_installer.ensure_project.return_value = 42
        mock_installer.assess.return_value = {
            "recommendations": [],
            "profile": {"stack": "Python"},
        }

        mock_config_gen = MagicMock()
        mock_config_gen.generate.return_value = {
            "checks": [{"name": "tests", "command": "pytest", "blocker": True}],
            "environments": {"dev": {"deploy_command": "docker-compose up"}},
            "coverage": {"min_line_coverage": 80},
        }
        mock_config_gen.update_config.return_value = {
            "checks": [{"name": "tests-updated", "command": "pytest -v", "blocker": True}],
            "environments": {},
            "coverage": {"min_line_coverage": 90},
        }

        return mock_installer, mock_config_gen

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    def test_install_auto_auth(self, mock_url, mock_key, mock_validate):
        """No API key → should show auto-auth message and exit if still no key."""
        runner = CliRunner()
        result = runner.invoke(main, ["install"])

        assert result.exit_code != 0
        # New flow should attempt auth, not just say "run tlm auth"
        assert "starting auth" in result.output.lower() or "not authenticated" in result.output.lower()

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.ConfigGenerator")
    @patch("tlm.cli.Installer")
    def test_install_generates_config(self, mock_installer_cls, mock_cg_cls,
                                       mock_url, mock_key, mock_validate, tmp_path):
        """Install should call ConfigGenerator.generate()."""
        mock_installer, mock_config_gen = self._make_mocks()
        mock_installer_cls.return_value = mock_installer
        mock_cg_cls.return_value = mock_config_gen

        runner = CliRunner()
        # Input: approve config + quality tier
        result = runner.invoke(main, ["install", "--path", str(tmp_path)], input="a\n\n")

        assert result.exit_code == 0
        mock_config_gen.generate.assert_called_once()

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.ConfigGenerator")
    @patch("tlm.cli.Installer")
    def test_install_approval_saves(self, mock_installer_cls, mock_cg_cls,
                                     mock_url, mock_key, mock_validate, tmp_path):
        """Approving config should call save_approved()."""
        mock_installer, mock_config_gen = self._make_mocks()
        mock_installer_cls.return_value = mock_installer
        mock_cg_cls.return_value = mock_config_gen

        runner = CliRunner()
        result = runner.invoke(main, ["install", "--path", str(tmp_path)], input="a\n\n")

        assert result.exit_code == 0
        mock_config_gen.save_approved.assert_called_once()

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.ConfigGenerator")
    @patch("tlm.cli.Installer")
    def test_install_correct_updates(self, mock_installer_cls, mock_cg_cls,
                                      mock_url, mock_key, mock_validate, tmp_path):
        """Choosing 'correct' should call update_config(), then approve on second pass."""
        mock_installer, mock_config_gen = self._make_mocks()
        mock_installer_cls.return_value = mock_installer
        mock_cg_cls.return_value = mock_config_gen

        runner = CliRunner()
        # correct → feedback → approve → quality tier
        result = runner.invoke(main, ["install", "--path", str(tmp_path)],
                               input="c\nIncrease coverage to 90%\na\n\n")

        assert result.exit_code == 0
        mock_config_gen.update_config.assert_called_once()
        mock_config_gen.save_approved.assert_called_once()

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.ConfigGenerator")
    @patch("tlm.cli.Installer")
    def test_install_reject_exits(self, mock_installer_cls, mock_cg_cls,
                                   mock_url, mock_key, mock_validate, tmp_path):
        """Rejecting config should exit without installing."""
        mock_installer, mock_config_gen = self._make_mocks()
        mock_installer_cls.return_value = mock_installer
        mock_cg_cls.return_value = mock_config_gen

        runner = CliRunner()
        result = runner.invoke(main, ["install", "--path", str(tmp_path)], input="r\n")

        assert result.exit_code == 0
        mock_config_gen.save_approved.assert_not_called()
        mock_installer.install_full.assert_not_called()

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.ConfigGenerator")
    @patch("tlm.cli.Installer")
    def test_install_calls_install_full(self, mock_installer_cls, mock_cg_cls,
                                         mock_url, mock_key, mock_validate, tmp_path):
        """Install should call install_full(), not just install_hooks()."""
        mock_installer, mock_config_gen = self._make_mocks()
        mock_installer_cls.return_value = mock_installer
        mock_cg_cls.return_value = mock_config_gen

        runner = CliRunner()
        result = runner.invoke(main, ["install", "--path", str(tmp_path)], input="a\n\n")

        assert result.exit_code == 0
        mock_installer.install_full.assert_called_once()

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.ConfigGenerator")
    @patch("tlm.cli.Installer")
    def test_install_no_claude_md(self, mock_installer_cls, mock_cg_cls,
                                   mock_url, mock_key, mock_validate, tmp_path):
        """Install should NOT create or modify CLAUDE.md."""
        mock_installer, mock_config_gen = self._make_mocks()
        mock_installer_cls.return_value = mock_installer
        mock_cg_cls.return_value = mock_config_gen

        runner = CliRunner()
        result = runner.invoke(main, ["install", "--path", str(tmp_path)], input="a\n\n")

        assert result.exit_code == 0
        claude_md = tmp_path / "CLAUDE.md"
        assert not claude_md.exists()

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.ConfigGenerator")
    @patch("tlm.cli.Installer")
    def test_install_shows_claude_warning(self, mock_installer_cls, mock_cg_cls,
                                           mock_url, mock_key, tmp_path):
        """No .claude/ → 'claude code not detected' in output."""
        mock_installer, mock_config_gen = self._make_mocks()
        mock_installer_cls.return_value = mock_installer
        mock_cg_cls.return_value = mock_config_gen

        runner = CliRunner()
        # y for confirm + a for approve + enter for quality tier
        result = runner.invoke(main, ["install", "--path", str(tmp_path)],
                               input="y\na\n\n")

        assert result.exit_code == 0
        assert "claude code not detected" in result.output.lower()


class TestValidateInstallDirectory:
    """Tests for _validate_install_directory() pre-install guardrails."""

    def test_warns_if_no_claude_dir(self, tmp_path, capsys):
        """No .claude/ → proceeds with warning (non-blocking), returns path."""
        with patch("tlm.cli.click.confirm", return_value=True):
            result = _validate_install_directory(str(tmp_path))
        assert result == tmp_path.resolve()
        captured = capsys.readouterr().out
        assert "claude code not detected" in captured.lower()

    def test_no_warning_when_claude_exists(self, tmp_path, capsys):
        """.claude exists → proceeds without warning."""
        (tmp_path / ".claude").mkdir()
        with patch("tlm.cli.click.confirm", return_value=True):
            result = _validate_install_directory(str(tmp_path))
        assert result == tmp_path.resolve()
        captured = capsys.readouterr().out
        assert "claude code not detected" not in captured.lower()

    def test_proceeds_on_y_confirmation(self, tmp_path):
        """click.confirm returns True → returns resolved Path."""
        (tmp_path / ".claude").mkdir()
        with patch("tlm.cli.click.confirm", return_value=True):
            result = _validate_install_directory(str(tmp_path))
        assert result == tmp_path.resolve()

    def test_exits_on_decline(self, tmp_path):
        """click.confirm returns False → SystemExit(1)."""
        with patch("tlm.cli.click.confirm", return_value=False):
            with pytest.raises(SystemExit) as exc_info:
                _validate_install_directory(str(tmp_path))
            assert exc_info.value.code == 1

    def test_exits_on_keyboard_interrupt(self, tmp_path):
        """click.confirm raises KeyboardInterrupt → SystemExit(1)."""
        with patch("tlm.cli.click.confirm", side_effect=KeyboardInterrupt()):
            with pytest.raises(SystemExit) as exc_info:
                _validate_install_directory(str(tmp_path))
            assert exc_info.value.code == 1

    def test_exits_on_eof_error(self, tmp_path):
        """click.confirm raises EOFError → SystemExit(1)."""
        with patch("tlm.cli.click.confirm", side_effect=EOFError()):
            with pytest.raises(SystemExit) as exc_info:
                _validate_install_directory(str(tmp_path))
            assert exc_info.value.code == 1

    def test_returns_resolved_absolute_path(self, tmp_path):
        """Return is a resolved, absolute Path object."""
        (tmp_path / ".claude").mkdir()
        with patch("tlm.cli.click.confirm", return_value=True):
            result = _validate_install_directory(str(tmp_path))
        assert isinstance(result, Path)
        assert result.is_absolute()
        assert result == tmp_path.resolve()


class TestScanCommand:
    @patch("tlm.cli.Installer")
    def test_scan_shows_recommendations(self, mock_installer_cls, tmp_path):
        """tlm scan should display recommendations."""
        mock_installer = MagicMock()
        mock_installer.scan_project.return_value = {"file_tree": "app.py", "samples": "code"}
        mock_installer.assess.return_value = {
            "recommendations": [
                {"id": "cicd", "type": "cicd", "category": "CI/CD",
                 "severity": "critical", "description": "No CI/CD pipeline", "fixable": True},
            ],
            "profile": {"stack": "Python"},
        }
        mock_installer_cls.return_value = mock_installer

        runner = CliRunner()
        result = runner.invoke(main, ["scan", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "CI/CD" in result.output or "cicd" in result.output


class TestGapsCommand:
    def test_gaps_shows_active_gaps(self, tmp_path):
        """tlm gaps should show active gaps."""
        from tlm.gaps import add_gap
        from tlm.state import write_state

        (tmp_path / ".tlm").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})
        add_gap(str(tmp_path), {
            "id": "cicd", "type": "cicd", "category": "CI/CD",
            "severity": "critical", "description": "No CI/CD pipeline",
        })

        runner = CliRunner()
        result = runner.invoke(main, ["gaps", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "CI/CD" in result.output or "cicd" in result.output

    def test_gaps_no_gaps(self, tmp_path):
        """tlm gaps should show message when no gaps."""
        (tmp_path / ".tlm").mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["gaps", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "no" in result.output.lower() or "clean" in result.output.lower()


class TestHookCommand:
    def test_hook_session_start(self, tmp_path):
        """_hook session_start should call hook_session_start."""
        from tlm.state import write_state
        (tmp_path / ".tlm").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})

        runner = CliRunner()
        result = runner.invoke(main, ["_hook", "session_start", "--path", str(tmp_path)])
        assert result.exit_code == 0

    def test_hook_prompt_submit(self, tmp_path):
        """_hook prompt_submit should return JSON."""
        from tlm.state import write_state
        (tmp_path / ".tlm").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})

        runner = CliRunner()
        result = runner.invoke(main, ["_hook", "prompt_submit", "--path", str(tmp_path)])
        assert result.exit_code == 0

    def test_hook_guard(self, tmp_path):
        """_hook guard should accept tool input from stdin."""
        from tlm.state import write_state
        (tmp_path / ".tlm").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})

        tool_input = json.dumps({
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/app.py"},
        })

        runner = CliRunner()
        result = runner.invoke(main, ["_hook", "guard", "--path", str(tmp_path)], input=tool_input)
        assert result.exit_code == 0

    def test_hook_compliance(self, tmp_path):
        """_hook compliance should accept tool input from stdin."""
        from tlm.state import write_state
        (tmp_path / ".tlm").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})

        tool_input = json.dumps({"command": "python -m pytest tests/"})

        runner = CliRunner()
        result = runner.invoke(main, ["_hook", "compliance", "--path", str(tmp_path)], input=tool_input)
        assert result.exit_code == 0


class TestFixCommand:
    """Tests for `tlm fix` — gap remediation command."""

    def _setup_gaps(self, tmp_path, gaps=None):
        """Helper: write .tlm/gaps.json and config.json."""
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir(exist_ok=True)

        if gaps is None:
            gaps = [
                {
                    "id": "cicd",
                    "type": "cicd",
                    "category": "CI/CD",
                    "severity": "critical",
                    "description": "No CI/CD pipeline",
                    "status": "detected",
                    "dismiss_reason": None,
                    "detected_at": "2026-02-22",
                    "resolved_at": None,
                },
                {
                    "id": "testing",
                    "type": "testing",
                    "category": "Testing",
                    "severity": "high",
                    "description": "Low test coverage",
                    "status": "detected",
                    "dismiss_reason": None,
                    "detected_at": "2026-02-22",
                    "resolved_at": None,
                },
            ]

        (tlm_dir / "gaps.json").write_text(json.dumps(gaps))
        (tlm_dir / "config.json").write_text(json.dumps({
            "project_id": 42,
            "quality_tier": "high",
        }))
        (tlm_dir / "state.json").write_text(json.dumps({"phase": "idle"}))

    # ── Edge cases ────────────────────────────────────────────

    def test_fix_no_active_gaps(self, tmp_path):
        """tlm fix with no active gaps should show message and exit cleanly."""
        self._setup_gaps(tmp_path, gaps=[])

        runner = CliRunner()
        result = runner.invoke(main, ["fix", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "no" in result.output.lower() and "gap" in result.output.lower()

    @patch("tlm.cli.get_api_key", return_value="")
    def test_fix_not_authenticated(self, mock_key, tmp_path):
        """tlm fix without auth should show error."""
        self._setup_gaps(tmp_path)

        runner = CliRunner()
        result = runner.invoke(main, ["fix", "--path", str(tmp_path)])

        assert result.exit_code != 0
        assert "auth" in result.output.lower()

    # ── Gap selection ─────────────────────────────────────────

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.Interviewer")
    @patch("tlm.cli.Executor")
    def test_fix_shows_gap_selection(
        self, mock_exec_cls, mock_inter_cls, mock_client_cls,
        mock_url, mock_key, tmp_path
    ):
        """tlm fix (no arg) should list active gaps and let user pick."""
        self._setup_gaps(tmp_path)

        mock_client = MagicMock()
        mock_client.get_interview = MagicMock(return_value={
            "intro": "Let's fix CI/CD",
            "questions": [{"id": "q1", "question": "Which CI?", "options": ["GitHub Actions"], "default": "GitHub Actions"}],
        })
        mock_client.build_context = MagicMock(return_value={
            "system_prompt": "You are a CI/CD expert",
            "instructions": "Set up GitHub Actions",
        })
        mock_client.review_plan = MagicMock(return_value={
            "verdict": "pass",
            "feedback": "Looks good",
        })
        mock_client_cls.return_value = mock_client

        mock_interviewer = MagicMock()
        mock_interviewer.run.return_value = {"q1": "GitHub Actions"}
        mock_inter_cls.return_value = mock_interviewer

        mock_executor = MagicMock()
        mock_executor.plan.return_value = "Plan: create .github/workflows/ci.yml"
        mock_executor.execute.return_value = "Done"
        mock_exec_cls.return_value = mock_executor

        runner = CliRunner()
        # User selects gap #1 (cicd), then approves plan
        result = runner.invoke(main, ["fix", "--path", str(tmp_path)], input="1\ny\n")

        assert result.exit_code == 0
        # Should show the gap list
        assert "cicd" in result.output.lower() or "CI/CD" in result.output

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.Interviewer")
    @patch("tlm.cli.Executor")
    def test_fix_with_gap_id(
        self, mock_exec_cls, mock_inter_cls, mock_client_cls,
        mock_url, mock_key, tmp_path
    ):
        """tlm fix cicd should skip selection and go straight to interview."""
        self._setup_gaps(tmp_path)

        mock_client = MagicMock()
        mock_client.get_interview = MagicMock(return_value={
            "intro": "Let's fix CI/CD",
            "questions": [{"id": "q1", "question": "Which CI?", "options": ["GitHub Actions"], "default": "GitHub Actions"}],
        })
        mock_client.build_context = MagicMock(return_value={
            "system_prompt": "You are a CI/CD expert",
            "instructions": "Set up GitHub Actions",
        })
        mock_client.review_plan = MagicMock(return_value={
            "verdict": "pass",
            "feedback": "Looks good",
        })
        mock_client_cls.return_value = mock_client

        mock_interviewer = MagicMock()
        mock_interviewer.run.return_value = {"q1": "GitHub Actions"}
        mock_inter_cls.return_value = mock_interviewer

        mock_executor = MagicMock()
        mock_executor.plan.return_value = "Plan: create CI"
        mock_executor.execute.return_value = "Done"
        mock_exec_cls.return_value = mock_executor

        runner = CliRunner()
        # Approve plan
        result = runner.invoke(main, ["fix", "cicd", "--path", str(tmp_path)], input="y\n")

        assert result.exit_code == 0
        # Should call get_interview with the cicd gap
        mock_client.get_interview.assert_called_once()
        call_args = mock_client.get_interview.call_args
        assert call_args[1].get("rec_id", call_args[0][1] if len(call_args[0]) > 1 else None) == "cicd" or call_args[0][1] == "cicd"

    # ── Full flow ─────────────────────────────────────────────

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.Interviewer")
    @patch("tlm.cli.Executor")
    def test_fix_runs_interview(
        self, mock_exec_cls, mock_inter_cls, mock_client_cls,
        mock_url, mock_key, tmp_path
    ):
        """tlm fix should call get_interview and run Interviewer."""
        self._setup_gaps(tmp_path)

        mock_client = MagicMock()
        mock_client.get_interview = MagicMock(return_value={
            "intro": "Let's fix CI/CD",
            "questions": [
                {"id": "q1", "question": "Which CI?", "options": ["GitHub Actions"], "default": "GitHub Actions"},
                {"id": "q2", "question": "Branch?", "options": ["main"], "default": "main"},
            ],
        })
        mock_client.build_context = MagicMock(return_value={
            "system_prompt": "system",
            "instructions": "instructions",
        })
        mock_client.review_plan = MagicMock(return_value={
            "verdict": "pass",
            "feedback": "OK",
        })
        mock_client_cls.return_value = mock_client

        mock_interviewer = MagicMock()
        mock_interviewer.run.return_value = {"q1": "GitHub Actions", "q2": "main"}
        mock_inter_cls.return_value = mock_interviewer

        mock_executor = MagicMock()
        mock_executor.plan.return_value = "Plan"
        mock_executor.execute.return_value = "Done"
        mock_exec_cls.return_value = mock_executor

        runner = CliRunner()
        result = runner.invoke(main, ["fix", "cicd", "--path", str(tmp_path)], input="y\n")

        assert result.exit_code == 0
        mock_client.get_interview.assert_called_once()
        mock_inter_cls.assert_called_once()
        mock_interviewer.run.assert_called_once()

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.Interviewer")
    @patch("tlm.cli.Executor")
    def test_fix_builds_context(
        self, mock_exec_cls, mock_inter_cls, mock_client_cls,
        mock_url, mock_key, tmp_path
    ):
        """tlm fix should call build_context with interview answers."""
        self._setup_gaps(tmp_path)

        mock_client = MagicMock()
        mock_client.get_interview = MagicMock(return_value={
            "intro": "Intro",
            "questions": [{"id": "q1", "question": "Q?", "options": ["A"], "default": "A"}],
        })
        mock_client.build_context = MagicMock(return_value={
            "system_prompt": "You are expert",
            "instructions": "Do the thing",
        })
        mock_client.review_plan = MagicMock(return_value={
            "verdict": "pass",
            "feedback": "OK",
        })
        mock_client_cls.return_value = mock_client

        mock_interviewer = MagicMock()
        mock_interviewer.run.return_value = {"q1": "A"}
        mock_inter_cls.return_value = mock_interviewer

        mock_executor = MagicMock()
        mock_executor.plan.return_value = "Plan"
        mock_executor.execute.return_value = "Done"
        mock_exec_cls.return_value = mock_executor

        runner = CliRunner()
        result = runner.invoke(main, ["fix", "cicd", "--path", str(tmp_path)], input="y\n")

        assert result.exit_code == 0
        mock_client.build_context.assert_called_once()
        call_args = mock_client.build_context.call_args
        # answers should be passed
        assert call_args[1].get("answers") == {"q1": "A"} or call_args[0][2] == {"q1": "A"}

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.Interviewer")
    @patch("tlm.cli.Executor")
    def test_fix_executes_plan(
        self, mock_exec_cls, mock_inter_cls, mock_client_cls,
        mock_url, mock_key, tmp_path
    ):
        """tlm fix should call executor.plan then executor.execute."""
        self._setup_gaps(tmp_path)

        mock_client = MagicMock()
        mock_client.get_interview = MagicMock(return_value={
            "intro": "Intro",
            "questions": [{"id": "q1", "question": "Q?", "options": ["A"], "default": "A"}],
        })
        mock_client.build_context = MagicMock(return_value={
            "system_prompt": "system",
            "instructions": "instructions",
        })
        mock_client.review_plan = MagicMock(return_value={
            "verdict": "pass",
            "feedback": "OK",
        })
        mock_client_cls.return_value = mock_client

        mock_interviewer = MagicMock()
        mock_interviewer.run.return_value = {"q1": "A"}
        mock_inter_cls.return_value = mock_interviewer

        mock_executor = MagicMock()
        mock_executor.plan.return_value = "The Plan"
        mock_executor.execute.return_value = "Executed"
        mock_exec_cls.return_value = mock_executor

        runner = CliRunner()
        result = runner.invoke(main, ["fix", "cicd", "--path", str(tmp_path)], input="y\n")

        assert result.exit_code == 0
        mock_executor.plan.assert_called_once_with("system", "instructions")
        mock_executor.execute.assert_called_once_with("The Plan")

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.Interviewer")
    @patch("tlm.cli.Executor")
    def test_fix_reviews_plan(
        self, mock_exec_cls, mock_inter_cls, mock_client_cls,
        mock_url, mock_key, tmp_path
    ):
        """tlm fix should call review_plan and show the verdict."""
        self._setup_gaps(tmp_path)

        mock_client = MagicMock()
        mock_client.get_interview = MagicMock(return_value={
            "intro": "Intro",
            "questions": [{"id": "q1", "question": "Q?", "options": ["A"], "default": "A"}],
        })
        mock_client.build_context = MagicMock(return_value={
            "system_prompt": "system",
            "instructions": "instructions",
        })
        mock_client.review_plan = MagicMock(return_value={
            "verdict": "pass",
            "feedback": "Everything looks correct",
        })
        mock_client_cls.return_value = mock_client

        mock_interviewer = MagicMock()
        mock_interviewer.run.return_value = {"q1": "A"}
        mock_inter_cls.return_value = mock_interviewer

        mock_executor = MagicMock()
        mock_executor.plan.return_value = "Plan"
        mock_executor.execute.return_value = "Done"
        mock_exec_cls.return_value = mock_executor

        runner = CliRunner()
        result = runner.invoke(main, ["fix", "cicd", "--path", str(tmp_path)], input="y\n")

        assert result.exit_code == 0
        mock_client.review_plan.assert_called_once()
        assert "pass" in result.output.lower() or "verdict" in result.output.lower()

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.Interviewer")
    @patch("tlm.cli.Executor")
    @patch("tlm.cli.update_gap_status")
    def test_fix_resolves_gap_on_pass(
        self, mock_update, mock_exec_cls, mock_inter_cls, mock_client_cls,
        mock_url, mock_key, tmp_path
    ):
        """tlm fix should mark gap as RESOLVED when review passes."""
        self._setup_gaps(tmp_path)

        mock_client = MagicMock()
        mock_client.get_interview = MagicMock(return_value={
            "intro": "Intro",
            "questions": [{"id": "q1", "question": "Q?", "options": ["A"], "default": "A"}],
        })
        mock_client.build_context = MagicMock(return_value={
            "system_prompt": "system",
            "instructions": "instructions",
        })
        mock_client.review_plan = MagicMock(return_value={
            "verdict": "pass",
            "feedback": "Good",
        })
        mock_client_cls.return_value = mock_client

        mock_interviewer = MagicMock()
        mock_interviewer.run.return_value = {"q1": "A"}
        mock_inter_cls.return_value = mock_interviewer

        mock_executor = MagicMock()
        mock_executor.plan.return_value = "Plan"
        mock_executor.execute.return_value = "Done"
        mock_exec_cls.return_value = mock_executor

        runner = CliRunner()
        result = runner.invoke(main, ["fix", "cicd", "--path", str(tmp_path)], input="y\n")

        assert result.exit_code == 0
        mock_update.assert_called_once_with(str(tmp_path), "cicd", GapStatus.RESOLVED)


class TestUninstallCommand:
    """Tests for `tlm uninstall` — full clean uninstall."""

    def test_uninstall_not_installed(self, tmp_path):
        """No .tlm/ → early exit message, no error."""
        runner = CliRunner()
        result = runner.invoke(main, ["uninstall", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "not installed" in result.output.lower()

    def test_uninstall_requires_confirmation(self, tmp_path):
        """Without --yes, must type UNINSTALL to proceed."""
        (tmp_path / ".tlm").mkdir()

        runner = CliRunner()
        # Type UNINSTALL to confirm
        result = runner.invoke(main, ["uninstall", "--path", str(tmp_path)],
                               input="UNINSTALL\n")

        assert result.exit_code == 0
        assert "WARNING" in result.output or "warning" in result.output.lower()

    def test_uninstall_cancelled_wrong_input(self, tmp_path):
        """Typing anything else cancels."""
        (tmp_path / ".tlm").mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["uninstall", "--path", str(tmp_path)],
                               input="nope\n")

        assert result.exit_code == 0
        assert "cancelled" in result.output.lower()

    def test_uninstall_cancelled_empty(self, tmp_path):
        """Pressing enter (empty input) cancels."""
        (tmp_path / ".tlm").mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["uninstall", "--path", str(tmp_path)],
                               input="\n")

        assert result.exit_code == 0
        assert "cancelled" in result.output.lower()

    @patch("tlm.cli.Installer")
    def test_uninstall_yes_flag_skips_confirm(self, mock_installer_cls, tmp_path):
        """--yes skips the warning and proceeds directly."""
        (tmp_path / ".tlm").mkdir()
        mock_installer = MagicMock()
        mock_installer_cls.return_value = mock_installer

        runner = CliRunner()
        result = runner.invoke(main, ["uninstall", "--path", str(tmp_path), "--yes"])

        assert result.exit_code == 0
        mock_installer.uninstall.assert_called_once()

    @patch("tlm.cli.Installer")
    def test_uninstall_calls_installer(self, mock_installer_cls, tmp_path):
        """Installer.uninstall() should be called after confirmation."""
        (tmp_path / ".tlm").mkdir()
        mock_installer = MagicMock()
        mock_installer_cls.return_value = mock_installer

        runner = CliRunner()
        result = runner.invoke(main, ["uninstall", "--path", str(tmp_path)],
                               input="UNINSTALL\n")

        assert result.exit_code == 0
        mock_installer.uninstall.assert_called_once()

    @patch("tlm.cli.Installer")
    def test_uninstall_shows_summary(self, mock_installer_cls, tmp_path):
        """Output should contain removal confirmation lines."""
        (tmp_path / ".tlm").mkdir()
        mock_installer = MagicMock()
        mock_installer_cls.return_value = mock_installer

        runner = CliRunner()
        result = runner.invoke(main, ["uninstall", "--path", str(tmp_path), "--yes"])

        assert result.exit_code == 0
        assert "settings.json" in result.output
        assert ".tlm/" in result.output or "tlm" in result.output.lower()
        assert "fully removed" in result.output.lower() or "TLM fully removed" in result.output

    def test_uninstall_ctrl_c_cancels(self, tmp_path):
        """Ctrl+C during prompt → cancels gracefully."""
        (tmp_path / ".tlm").mkdir()

        runner = CliRunner()
        # Simulate EOFError (Ctrl+C/Ctrl+D during prompt)
        with patch("tlm.cli.click.prompt", side_effect=click.exceptions.Abort()):
            result = runner.invoke(main, ["uninstall", "--path", str(tmp_path)])

        assert result.exit_code == 0 or "abort" in result.output.lower() or "cancelled" in result.output.lower()

    @patch("tlm.cli.Installer")
    def test_uninstall_mentions_reinstall(self, mock_installer_cls, tmp_path):
        """After uninstall → output mentions 'tlm install'."""
        (tmp_path / ".tlm").mkdir()
        mock_installer = MagicMock()
        mock_installer_cls.return_value = mock_installer

        runner = CliRunner()
        result = runner.invoke(main, ["uninstall", "--path", str(tmp_path), "--yes"])

        assert result.exit_code == 0
        assert "tlm install" in result.output


class TestAPIErrorHandling:
    """API errors → friendly messages, never stacktraces."""

    def _install_mocks(self):
        """Patches for install command up to ensure_project()."""
        return {
            "tlm.cli.get_api_key": "tlm_sk_test",
            "tlm.cli.get_server_url": "http://localhost:8003",
        }

    # ── install ──────────────────────────────────────────────────

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.Installer")
    def test_install_credits_error(self, mock_inst_cls, mock_url, mock_key, mock_validate, tmp_path):
        """TLMCreditsError during install → friendly credits message."""
        mock_inst = MagicMock()
        mock_inst.init_project_dir.return_value = None
        mock_inst.ensure_project.side_effect = TLMCreditsError(
            {"tier": "free", "upgrade_url": "https://tlmforge.dev/#pricing"}
        )
        mock_inst_cls.return_value = mock_inst

        runner = CliRunner()
        result = runner.invoke(main, ["install", "--path", str(tmp_path)])

        assert result.exit_code == 1
        assert "credits" in result.output.lower()
        assert "Traceback" not in result.output

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.Installer")
    def test_install_auth_error(self, mock_inst_cls, mock_url, mock_key, mock_validate, tmp_path):
        """TLMAuthError during install → friendly auth message."""
        mock_inst = MagicMock()
        mock_inst.init_project_dir.return_value = None
        mock_inst.ensure_project.side_effect = TLMAuthError("bad token")
        mock_inst_cls.return_value = mock_inst

        runner = CliRunner()
        result = runner.invoke(main, ["install", "--path", str(tmp_path)])

        assert result.exit_code == 1
        assert "authentication failed" in result.output.lower()
        assert "tlm auth" in result.output.lower()
        assert "Traceback" not in result.output

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.Installer")
    def test_install_connection_error(self, mock_inst_cls, mock_url, mock_key, mock_validate, tmp_path):
        """TLMConnectionError during install → friendly connection message."""
        mock_inst = MagicMock()
        mock_inst.init_project_dir.return_value = None
        mock_inst.ensure_project.side_effect = TLMConnectionError("timeout")
        mock_inst_cls.return_value = mock_inst

        runner = CliRunner()
        result = runner.invoke(main, ["install", "--path", str(tmp_path)])

        assert result.exit_code == 1
        assert "cannot reach" in result.output.lower()
        assert "Traceback" not in result.output

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.Installer")
    def test_install_server_error(self, mock_inst_cls, mock_url, mock_key, mock_validate, tmp_path):
        """TLMServerError during install → friendly server error message."""
        mock_inst = MagicMock()
        mock_inst.init_project_dir.return_value = None
        mock_inst.ensure_project.side_effect = TLMServerError("500 oops")
        mock_inst_cls.return_value = mock_inst

        runner = CliRunner()
        result = runner.invoke(main, ["install", "--path", str(tmp_path)])

        assert result.exit_code == 1
        assert "internal error" in result.output.lower()
        assert "Traceback" not in result.output

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.Installer")
    def test_install_project_limit_error(self, mock_inst_cls, mock_url, mock_key, mock_validate, tmp_path):
        """TLMProjectLimitError during install → friendly limit message."""
        mock_inst = MagicMock()
        mock_inst.init_project_dir.return_value = None
        mock_inst.ensure_project.side_effect = TLMProjectLimitError(
            {"max_allowed": 1, "tier": "free"}
        )
        mock_inst_cls.return_value = mock_inst

        runner = CliRunner()
        result = runner.invoke(main, ["install", "--path", str(tmp_path)])

        assert result.exit_code == 1
        assert "project limit" in result.output.lower()
        assert "Traceback" not in result.output

    # ── scan ─────────────────────────────────────────────────────

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.Installer")
    def test_scan_credits_error(self, mock_inst_cls, mock_url, mock_key, tmp_path):
        """TLMCreditsError during scan → friendly message."""
        mock_inst = MagicMock()
        mock_inst.init_project_dir.return_value = None
        mock_inst.ensure_project.side_effect = TLMCreditsError({"tier": "free"})
        mock_inst_cls.return_value = mock_inst

        runner = CliRunner()
        result = runner.invoke(main, ["scan", "--path", str(tmp_path)])

        assert result.exit_code == 1
        assert "credits" in result.output.lower()
        assert "Traceback" not in result.output

    # ── fix ──────────────────────────────────────────────────────

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.TLMClient")
    def test_fix_credits_error(self, mock_client_cls, mock_url, mock_key, tmp_path):
        """TLMCreditsError during fix → friendly message."""
        # Setup gap file
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        (tlm_dir / "gaps.json").write_text(json.dumps([{
            "id": "cicd", "type": "cicd", "category": "CI/CD",
            "severity": "critical", "description": "No CI/CD",
            "status": "detected", "dismiss_reason": None,
            "detected_at": "2026-02-22", "resolved_at": None,
        }]))
        (tlm_dir / "config.json").write_text(json.dumps({
            "project_id": 42, "quality_tier": "high",
        }))
        (tlm_dir / "state.json").write_text(json.dumps({"phase": "idle"}))

        mock_client = MagicMock()
        mock_client.get_interview.side_effect = TLMCreditsError({"tier": "free"})
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["fix", "cicd", "--path", str(tmp_path)])

        assert result.exit_code == 1
        assert "credits" in result.output.lower()
        assert "Traceback" not in result.output

    # ── generic + keyboard ───────────────────────────────────────

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.Installer")
    def test_generic_exception(self, mock_inst_cls, mock_url, mock_key, mock_validate, tmp_path):
        """Random RuntimeError → 'internal error', no traceback."""
        mock_inst = MagicMock()
        mock_inst.init_project_dir.return_value = None
        mock_inst.ensure_project.side_effect = RuntimeError("something unexpected")
        mock_inst_cls.return_value = mock_inst

        runner = CliRunner()
        result = runner.invoke(main, ["install", "--path", str(tmp_path)])

        assert result.exit_code == 1
        assert "internal error" in result.output.lower()
        assert "Traceback" not in result.output
        assert "something unexpected" not in result.output

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.Installer")
    def test_keyboard_interrupt(self, mock_inst_cls, mock_url, mock_key, mock_validate, tmp_path):
        """KeyboardInterrupt → 'Interrupted', exit 130."""
        mock_inst = MagicMock()
        mock_inst.init_project_dir.return_value = None
        mock_inst.ensure_project.side_effect = KeyboardInterrupt()
        mock_inst_cls.return_value = mock_inst

        runner = CliRunner()
        result = runner.invoke(main, ["install", "--path", str(tmp_path)])

        assert result.exit_code == 130
        assert "interrupted" in result.output.lower()
        assert "Traceback" not in result.output

    # ── no traceback for any error type ──────────────────────────

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.Installer")
    @pytest.mark.parametrize("exc_cls,exc_args", [
        (TLMCreditsError, ({"tier": "free"},)),
        (TLMAuthError, ("bad",)),
        (TLMProjectLimitError, ({"max_allowed": 1, "tier": "free"},)),
        (TLMServerError, ("500",)),
        (TLMConnectionError, ("timeout",)),
        (RuntimeError, ("boom",)),
    ])
    def test_no_traceback_in_output(self, mock_inst_cls, mock_url, mock_key, mock_validate,
                                     exc_cls, exc_args, tmp_path):
        """No error type should ever produce a traceback in terminal output."""
        mock_inst = MagicMock()
        mock_inst.init_project_dir.return_value = None
        mock_inst.ensure_project.side_effect = exc_cls(*exc_args)
        mock_inst_cls.return_value = mock_inst

        runner = CliRunner()
        result = runner.invoke(main, ["install", "--path", str(tmp_path)])

        assert "Traceback" not in result.output


class TestLogoutCommand:
    """Tests for `tlm logout` — remove stored credentials."""

    def test_logout_removes_credentials(self, tmp_path):
        """Creds file exists → deleted, success message."""
        creds_dir = tmp_path / ".tlm"
        creds_dir.mkdir()
        creds_file = creds_dir / "credentials.json"
        creds_file.write_text('{"api_key": "tlm_sk_test"}')

        with patch("tlm.cli.Path.home", return_value=tmp_path):
            runner = CliRunner()
            result = runner.invoke(main, ["logout"])

        assert result.exit_code == 0
        assert "removed" in result.output.lower()
        assert not creds_file.exists()

    def test_logout_when_not_logged_in(self, tmp_path):
        """No creds file → 'No credentials' message."""
        with patch("tlm.cli.Path.home", return_value=tmp_path):
            runner = CliRunner()
            result = runner.invoke(main, ["logout"])

        assert result.exit_code == 0
        assert "no credentials" in result.output.lower()


class TestStatusCommand:
    """Tests for `tlm status` — show TLM project status."""

    def test_status_not_installed(self, tmp_path):
        """No .tlm/ → 'not installed' message."""
        runner = CliRunner()
        result = runner.invoke(main, ["status", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "not installed" in result.output.lower()

    def test_status_shows_project_info(self, tmp_path):
        """Config exists → shows project name, phase, quality tier, project ID."""
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        (tlm_dir / "config.json").write_text(json.dumps({
            "project_name": "myapp",
            "project_id": 42,
            "quality_control": "high",
        }))
        (tlm_dir / "state.json").write_text(json.dumps({"phase": "idle"}))
        (tlm_dir / "gaps.json").write_text("[]")

        runner = CliRunner()
        result = runner.invoke(main, ["status", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "myapp" in result.output
        assert "idle" in result.output
        assert "high" in result.output
        assert "42" in result.output

    def test_status_shows_gaps_count(self, tmp_path):
        """Active gaps → shows count."""
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        (tlm_dir / "config.json").write_text(json.dumps({
            "project_id": 1, "quality_control": "standard",
        }))
        (tlm_dir / "state.json").write_text(json.dumps({"phase": "idle"}))
        (tlm_dir / "gaps.json").write_text(json.dumps([
            {"id": "g1", "type": "testing", "category": "Testing",
             "severity": "high", "description": "No tests",
             "status": "detected", "dismiss_reason": None,
             "detected_at": "2026-01-01", "resolved_at": None},
            {"id": "g2", "type": "cicd", "category": "CI/CD",
             "severity": "medium", "description": "No CI",
             "status": "detected", "dismiss_reason": None,
             "detected_at": "2026-01-01", "resolved_at": None},
        ]))

        runner = CliRunner()
        result = runner.invoke(main, ["status", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "2" in result.output  # 2 active gaps

    def test_status_shows_enforcement(self, tmp_path):
        """Enforcement file → shows 'approved' or 'draft'."""
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        (tlm_dir / "config.json").write_text(json.dumps({
            "project_id": 1, "quality_control": "standard",
        }))
        (tlm_dir / "state.json").write_text(json.dumps({"phase": "idle"}))
        (tlm_dir / "gaps.json").write_text("[]")
        (tlm_dir / "enforcement.json").write_text(json.dumps({"approved": True}))

        runner = CliRunner()
        result = runner.invoke(main, ["status", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "approved" in result.output.lower()


class TestUpgradeCommand:
    """Tests for `tlm upgrade` — upgrade CLI via pipx or pip."""

    @patch("tlm.cli.subprocess.run")
    def test_upgrade_pipx_success(self, mock_run):
        """pipx succeeds → shows success message."""
        mock_run.return_value = MagicMock(
            returncode=0, stdout="tlm-cli 0.5.0", stderr=""
        )

        runner = CliRunner()
        result = runner.invoke(main, ["upgrade"])

        assert result.exit_code == 0
        assert "0.5.0" in result.output or "tlm-cli" in result.output.lower()

    @patch("tlm.cli.subprocess.run")
    def test_upgrade_pip_fallback(self, mock_run):
        """pipx fails → falls back to pip, shows success."""
        mock_run.side_effect = [
            MagicMock(returncode=1, stdout="", stderr="not found"),  # pipx fails
            MagicMock(returncode=0, stdout="Successfully installed", stderr=""),  # pip succeeds
        ]

        runner = CliRunner()
        result = runner.invoke(main, ["upgrade"])

        assert result.exit_code == 0
        assert "success" in result.output.lower() or "upgraded" in result.output.lower()

    @patch("tlm.cli.subprocess.run", side_effect=FileNotFoundError)
    def test_upgrade_not_found(self, mock_run):
        """Neither pipx nor pip → error about missing tools."""
        runner = CliRunner()
        result = runner.invoke(main, ["upgrade"])

        assert result.exit_code == 0  # doesn't crash
        assert "neither" in result.output.lower() or "not found" in result.output.lower()


class TestCtrlCInterrupt:
    """Ctrl+C during various commands → clean exit 130, no traceback, terminal restored."""

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.Installer")
    def test_install_ctrl_c_during_scan(self, mock_inst_cls, mock_url, mock_key, mock_validate, tmp_path):
        """Ctrl+C during project scan → clean exit 130, no traceback."""
        mock_inst = MagicMock()
        mock_inst.init_project_dir.return_value = None
        mock_inst.ensure_project.side_effect = KeyboardInterrupt()
        mock_inst_cls.return_value = mock_inst

        runner = CliRunner()
        result = runner.invoke(main, ["install", "--path", str(tmp_path)])

        assert result.exit_code == 130
        assert "interrupted" in result.output.lower()
        assert "Traceback" not in result.output

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.Installer")
    def test_install_ctrl_c_during_assess(self, mock_inst_cls, mock_url, mock_key, mock_validate, tmp_path):
        """Ctrl+C during assessment → clean exit 130."""
        mock_inst = MagicMock()
        mock_inst.init_project_dir.return_value = None
        mock_inst.ensure_project.return_value = 42
        mock_inst.scan_project.return_value = {"file_tree": "", "samples": ""}
        mock_inst.assess.side_effect = KeyboardInterrupt()
        mock_inst_cls.return_value = mock_inst

        runner = CliRunner()
        result = runner.invoke(main, ["install", "--path", str(tmp_path)])

        assert result.exit_code == 130
        assert "interrupted" in result.output.lower()
        assert "Traceback" not in result.output

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.Installer")
    @patch("tlm.cli.ConfigGenerator")
    def test_install_ctrl_c_during_prompt(
        self, mock_cg_cls, mock_inst_cls, mock_url, mock_key, mock_validate, tmp_path
    ):
        """Ctrl+C during approval prompt → clean exit 130."""
        mock_inst = MagicMock()
        mock_inst.init_project_dir.return_value = None
        mock_inst.ensure_project.return_value = 42
        mock_inst.scan_project.return_value = {"file_tree": "", "samples": ""}
        mock_inst.assess.return_value = {"profile": {"stack": "python"}, "recommendations": []}
        mock_inst_cls.return_value = mock_inst

        mock_cg = MagicMock()
        mock_cg.generate.return_value = {"checks": [], "environments": {}}
        mock_cg_cls.return_value = mock_cg

        runner = CliRunner()
        # click.prompt raises KeyboardInterrupt when Ctrl+C is pressed
        with patch("tlm.cli.click.prompt", side_effect=KeyboardInterrupt()):
            result = runner.invoke(main, ["install", "--path", str(tmp_path)])

        assert result.exit_code == 130
        assert "interrupted" in result.output.lower()
        assert "Traceback" not in result.output

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.TLMClient")
    def test_fix_ctrl_c_during_interview(self, mock_client_cls, mock_url, mock_key, tmp_path):
        """Ctrl+C during interview → clean exit 130."""
        # Setup gap file
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        (tlm_dir / "gaps.json").write_text(json.dumps([{
            "id": "cicd", "type": "cicd", "category": "CI/CD",
            "severity": "critical", "description": "No CI/CD",
            "status": "detected", "dismiss_reason": None,
            "detected_at": "2026-02-22", "resolved_at": None,
        }]))
        (tlm_dir / "config.json").write_text(json.dumps({
            "project_id": 42, "quality_tier": "high",
        }))
        (tlm_dir / "state.json").write_text(json.dumps({"phase": "idle"}))

        mock_client = MagicMock()
        mock_client.get_interview.side_effect = KeyboardInterrupt()
        mock_client_cls.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(main, ["fix", "cicd", "--path", str(tmp_path)])

        assert result.exit_code == 130
        assert "interrupted" in result.output.lower()
        assert "Traceback" not in result.output

    @patch("tlm.cli._validate_install_directory", return_value=Path("/fake"))
    @patch("tlm.cli._restore_terminal")
    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8003")
    @patch("tlm.cli.Installer")
    def test_terminal_restore_called_on_interrupt(
        self, mock_inst_cls, mock_url, mock_key, mock_restore, mock_validate
    ):
        """_restore_terminal is called when KeyboardInterrupt fires."""
        mock_inst = MagicMock()
        mock_inst.init_project_dir.return_value = None
        mock_inst.ensure_project.side_effect = KeyboardInterrupt()
        mock_inst_cls.return_value = mock_inst

        runner = CliRunner()
        runner.invoke(main, ["install"])

        mock_restore.assert_called()
