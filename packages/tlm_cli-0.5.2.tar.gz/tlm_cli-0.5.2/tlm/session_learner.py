"""
TLM Session Learner -- Learns from Claude CLI session transcripts.

Reads session prompts and optional transcript JSONL to build a compact summary.
The summary is sent to the server for pattern detection -- the full transcript
never leaves the machine.
"""

import json
import datetime
from pathlib import Path
from collections import Counter


def build_session_summary(tlm_dir: str, transcript_path: str = "") -> dict | None:
    """Build a compact session summary from captured prompts and optional transcript.

    Returns dict with session summary, or None if no data available.
    """
    tlm = Path(tlm_dir)
    prompts_file = tlm / "session_prompts.jsonl"

    user_prompts = []
    if prompts_file.exists():
        try:
            for line in prompts_file.read_text().strip().split("\n"):
                if not line.strip():
                    continue
                entry = json.loads(line)
                user_prompts.append(entry.get("prompt", ""))
        except (json.JSONDecodeError, OSError):
            pass

    if not user_prompts and not transcript_path:
        return None

    repeated = _find_repeated_instructions(user_prompts)

    files_changed = []
    tools_used = Counter()
    hooks_triggered = Counter()

    if transcript_path:
        transcript_data = _parse_transcript(transcript_path)
        files_changed = transcript_data.get("files_changed", [])
        tools_used = transcript_data.get("tools_used", Counter())
        hooks_triggered = transcript_data.get("hooks_triggered", Counter())

    duration_minutes = 0
    if prompts_file.exists():
        try:
            lines = [l for l in prompts_file.read_text().strip().split("\n") if l.strip()]
            if len(lines) >= 2:
                first = json.loads(lines[0])
                last = json.loads(lines[-1])
                t1 = datetime.datetime.fromisoformat(first["timestamp"])
                t2 = datetime.datetime.fromisoformat(last["timestamp"])
                duration_minutes = int((t2 - t1).total_seconds() / 60)
        except (json.JSONDecodeError, OSError, KeyError, ValueError):
            pass

    phase_flow = ""
    state_file = tlm / "state.json"
    if state_file.exists():
        try:
            state = json.loads(state_file.read_text())
            phase_flow = state.get("phase", "idle")
        except (json.JSONDecodeError, OSError):
            pass

    return {
        "user_prompts": user_prompts[:50],
        "repeated_instructions": repeated,
        "phase_flow": phase_flow,
        "hooks_triggered": dict(hooks_triggered),
        "files_changed": files_changed[:50],
        "tools_used": dict(tools_used),
        "session_duration_minutes": duration_minutes,
    }


def _find_repeated_instructions(prompts: list[str]) -> list[str]:
    """Find instructions that appear multiple times across prompts."""
    normalized = [p.lower().strip() for p in prompts if p.strip()]

    counter = Counter(normalized)
    repeated = []
    for phrase, count in counter.most_common(10):
        if count >= 2 and len(phrase) > 10:
            repeated.append(f"{phrase} ({count}x)")

    instruction_patterns = [
        "always", "never", "make sure", "don't forget", "remember to",
        "use tdd", "test first", "run tests", "deploy to",
    ]
    pattern_counts = Counter()
    for prompt in normalized:
        for pattern in instruction_patterns:
            if pattern in prompt:
                for sentence in prompt.split("."):
                    if pattern in sentence.strip():
                        pattern_counts[sentence.strip()] += 1

    for phrase, count in pattern_counts.most_common(10):
        if count >= 2 and phrase not in [r.rsplit(" (", 1)[0] for r in repeated]:
            repeated.append(f"{phrase} ({count}x)")

    return repeated[:10]


def _parse_transcript(transcript_path: str) -> dict:
    """Parse a Claude session transcript JSONL for metadata."""
    result = {
        "files_changed": [],
        "tools_used": Counter(),
        "hooks_triggered": Counter(),
    }

    try:
        path = Path(transcript_path)
        if not path.exists():
            return result

        files_seen = set()
        for line in path.read_text().strip().split("\n"):
            if not line.strip():
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            tool_name = entry.get("tool_name", "")
            if tool_name:
                result["tools_used"][tool_name] += 1

            if tool_name in ("Write", "Edit"):
                file_path = entry.get("tool_input", {}).get("file_path", "")
                if file_path and file_path not in files_seen:
                    files_seen.add(file_path)
                    result["files_changed"].append(file_path)

            hook_type = entry.get("hook_type", "")
            if hook_type:
                result["hooks_triggered"][hook_type] += 1

    except (OSError, ValueError):
        pass

    return result


def analyze_session(client, summary: dict, project_knowledge: str = "") -> dict:
    """Send session summary to server for pattern analysis."""
    try:
        return client.learn_session(summary, project_knowledge=project_knowledge)
    except Exception:
        return {"inferred_rules": [], "workflow_patterns": []}
