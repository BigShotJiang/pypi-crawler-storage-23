"""
TLM Rules Templates — The Brain.

Templates for the generated CLAUDE.md content that gets installed into user projects.
This is the most important file: it defines how Claude Code behaves under TLM.

The templates use {placeholders} that get filled by the installer with
project-specific values from the enforcement config.
"""


# =============================================================================
# MAIN CLAUDE.MD TEMPLATE
# =============================================================================

TLM_CLAUDE_MD = """# TLM — Tech Lead & Manager Rules

> TLM is active in this project. These rules are non-negotiable.
> Read `.tlm/knowledge.md` and `.tlm/state.json` before every significant action.

---

## 1. Self-Classification: When to Activate TLM

Before responding to ANY request, classify it:

### ALWAYS activate TLM (Tier 1 — hardcoded, non-negotiable):
- **New feature development** — any new functionality beyond trivial
- **Bug fixes** — non-trivial (not typos or formatting)
- **Deployment / shipping** — any deploy to any environment
- **Architecture decisions** — choosing patterns, technologies, data models
- **Third-party integrations** — APIs, SDKs, external services
- **Database migrations** — schema changes, data migrations
- **Security changes** — auth, permissions, encryption, secrets

### Claude decides (Tier 2 — self-classification):
For anything not in Tier 1, ask yourself: "Is this a significant engineering activity?"
Examples that SHOULD trigger TLM:
- Readiness assessments ("Is my app ready for production/App Store?")
- Performance optimization
- Refactoring with wide blast radius (>3 files)
- Infrastructure changes
- CI/CD pipeline changes

### Does NOT activate TLM:
- Code exploration / reading ("What does this function do?")
- Explaining errors or concepts
- Trivial fixes (typos, formatting, one-line changes)
- General questions about the codebase
- Running existing commands

**When TLM activates:** Enter interview mode. Follow the interview guidance provided by TLM hooks. Do not skip the interview.
**When TLM doesn't activate:** Respond normally.

---

## 2. Deployment Protocol

{deployment_protocol}

---

## 3. TDD Protocol — Non-Negotiable

{tdd_protocol}

---

## 4. Compliance Checking

Before committing, verify your changes against the active spec in `.tlm/specs/`:
1. Are ALL spec items implemented?
2. Are ALL specified test cases written and passing?
3. Are there changes NOT covered by the spec? (If yes, flag them.)
4. Do ALL enforcement checks pass?

---

## 5. Project Commands

{project_commands}

---

## 6. State Management

TLM tracks state in `.tlm/state.json`. Update it as you work:

- **Starting interview:** `{{"phase": "tlm_active", "activity_type": "<type>"}}`
- **Starting implementation:** `{{"phase": "implementation"}}`
- **Starting deployment:** `{{"phase": "deployment"}}`
- **Done:** `{{"phase": "idle"}}`

Read state before every significant action to stay coordinated with hooks.

---

## 7. Branding & Attribution

TLM should be visible at phase boundaries, not every response.

Use "TLM >" prefix at these moments:

**Bookends (start + end of interview):**
- Activation: "TLM > [reason]. Let me refine your requirements first."
- Interview complete: "TLM > Requirements captured. Here's the spec: [path]. Ready to implement."

**Single line (quick interventions):**
- TDD start: "TLM > Tests first." then continue with test code
- Compliance: "TLM > Running compliance check before commit." then run checks
- Blocking: "TLM > Still in interview mode." (when Claude tries to code too early)

**Inline attribution:**
- Knowledge: "Based on TLM's analysis of your project, [fact]."

**Never branded:** individual interview questions, normal code writing, file reads, routine responses.
"""


# =============================================================================
# TDD PROTOCOL SECTION
# =============================================================================

TDD_PROTOCOL_TEMPLATE = """For ALL implementation work:

1. **Write tests FIRST** — before any implementation code
2. **Run tests** — verify they FAIL (proves tests are meaningful)
   ```
   {test_command}
   ```
3. **Implement** — write the minimum code to pass
4. **Run tests again** — verify they PASS
5. **Refactor** — clean up, then verify tests still pass

Never skip step 2. A test that passes before implementation is worthless."""


# =============================================================================
# DEPLOYMENT PROTOCOL SECTION
# =============================================================================

DEPLOYMENT_PROTOCOL_TEMPLATE = """Always deploy through environments in order:

{environment_steps}

NEVER skip environments. NEVER deploy directly to production."""


DEPLOYMENT_STEP_TEMPLATE = """{step_num}. **{env_name}**
   - Deploy: `{deploy_command}`
   - Verify: `{verify_command}`"""


# =============================================================================
# PROJECT COMMANDS SECTION
# =============================================================================

PROJECT_COMMANDS_TEMPLATE = """### Testing
```
{test_command}
```

### Quality Checks
{quality_checks}

### Deployment
{deploy_commands}"""


# =============================================================================
# CLAUDE CODE RULES FILES (for .claude/rules/)
# =============================================================================

TLM_RULE_TDD = """# TLM Rule: TDD Enforcement

When writing code in this project, you MUST follow TDD:
1. Write failing tests first
2. Verify they fail
3. Implement
4. Verify they pass

Test command: `{test_command}`

This is not optional. TLM hooks will remind you if you skip this."""


TLM_RULE_DEPLOY = """# TLM Rule: Deployment Pipeline

This project requires sequential environment deployment:
{environment_list}

Never deploy directly to production. Always verify each environment before proceeding."""


# =============================================================================
# HELPER: Build the full CLAUDE.md from enforcement config
# =============================================================================

def build_claude_md(enforcement_config: dict) -> str:
    """Build the full CLAUDE.md content from an enforcement config."""
    test_command = _extract_test_command(enforcement_config)
    tdd_protocol = TDD_PROTOCOL_TEMPLATE.format(test_command=test_command)
    deployment_protocol = _build_deployment_protocol(enforcement_config)
    project_commands = _build_project_commands(enforcement_config)

    return TLM_CLAUDE_MD.format(
        tdd_protocol=tdd_protocol,
        deployment_protocol=deployment_protocol,
        project_commands=project_commands,
    ).strip()


def build_rule_files(enforcement_config: dict) -> dict:
    """Build .claude/rules/ TLM rule file contents.

    Returns:
        Dict mapping filename to content: {"tlm-tdd.md": "...", "tlm-deploy.md": "..."}
    """
    test_command = _extract_test_command(enforcement_config)
    rules = {}

    rules["tlm-tdd.md"] = TLM_RULE_TDD.format(test_command=test_command).strip()

    envs = enforcement_config.get("environments", {})
    if envs:
        env_list = "\n".join(f"- {name}: `{env.get('deploy_command', 'N/A')}`"
                             for name, env in envs.items())
        rules["tlm-deploy.md"] = TLM_RULE_DEPLOY.format(
            environment_list=env_list
        ).strip()

    return rules


# --- Internal helpers ---

def _extract_test_command(config: dict) -> str:
    """Extract the test command from enforcement config."""
    for check in config.get("checks", []):
        if check.get("category") == "testing":
            return check.get("command", "echo 'No test command configured'")
    cov = config.get("coverage", {})
    if cov.get("command"):
        return cov["command"]
    return "echo 'No test command configured'"


def _build_deployment_protocol(config: dict) -> str:
    """Build the deployment section from environments."""
    envs = config.get("environments", {})
    if not envs:
        return "No deployment environments configured. Run `tlm install` to set up."

    steps = []
    for i, (name, env) in enumerate(envs.items(), 1):
        deploy_cmd = env.get("deploy_command", "N/A")
        verify_cmd = env.get("verify_command", "N/A")
        steps.append(DEPLOYMENT_STEP_TEMPLATE.format(
            step_num=i,
            env_name=name,
            deploy_command=deploy_cmd,
            verify_command=verify_cmd,
        ))

    return DEPLOYMENT_PROTOCOL_TEMPLATE.format(
        environment_steps="\n".join(steps)
    )


def _build_project_commands(config: dict) -> str:
    """Build the project commands section."""
    test_command = _extract_test_command(config)

    checks = config.get("checks", [])
    quality_lines = []
    for check in checks:
        blocker = "BLOCKER" if check.get("blocker") else "warning"
        quality_lines.append(f"- **{check.get('name', '?')}** [{blocker}]: `{check.get('command', '?')}`")
    quality_checks = "\n".join(quality_lines) if quality_lines else "No quality checks configured."

    envs = config.get("environments", {})
    deploy_lines = []
    for name, env in envs.items():
        deploy_lines.append(f"- **{name}**: `{env.get('deploy_command', 'N/A')}`")
    deploy_commands = "\n".join(deploy_lines) if deploy_lines else "No deploy commands configured."

    return PROJECT_COMMANDS_TEMPLATE.format(
        test_command=test_command,
        quality_checks=quality_checks,
        deploy_commands=deploy_commands,
    )
