"""Interviewer — presents questions with options, collects answers."""

import sys


def _ensure_terminal_sane():
    """Reset terminal to canonical mode before reading input.

    After ANSI spinner output, readline can leave the terminal in raw mode
    (no echo, no line buffering, no signals). This forces it back to sane state.
    """
    try:
        import termios
        fd = sys.stdin.fileno()
        attrs = termios.tcgetattr(fd)
        attrs[3] |= termios.ICANON | termios.ECHO | termios.ISIG | termios.IEXTEN
        attrs[0] |= termios.ICRNL
        termios.tcsetattr(fd, termios.TCSANOW, attrs)
    except (ImportError, termios.error, OSError):
        pass


def _read_line(prompt="> "):
    """Read a line from stdin, bypassing readline to avoid terminal corruption.

    Uses sys.stdin.readline() instead of input() because readline can leave
    the terminal in raw mode after ANSI spinner output.
    """
    sys.stdout.write(prompt)
    sys.stdout.flush()
    if sys.stdin.isatty():
        _ensure_terminal_sane()
    line = sys.stdin.readline()
    if not line:
        raise EOFError
    return line.strip()


class Interviewer:
    """Terminal Q&A loop for recommendation interviews."""

    def __init__(self, questions: list[dict]):
        self.questions = questions

    def run(self) -> dict[str, str]:
        """Run the interview, return answers dict keyed by question id."""
        answers = {}

        for q in self.questions:
            qid = q["id"]
            question_text = q["question"]
            options = q.get("options", [])
            default = q.get("default", "")
            context = q.get("context", "")

            # Display question
            print(f"\n{question_text}")
            if context:
                print(f"  ({context})")

            # Display options
            for i, opt in enumerate(options, 1):
                marker = " *" if opt == default else ""
                print(f"  {i}. {opt}{marker}")

            if default:
                print(f"  [default: {default}]")

            # Get input — bypass readline to avoid terminal corruption
            raw = _read_line("> ")

            if not raw:
                # Use default
                answers[qid] = default
            elif raw.isdigit():
                idx = int(raw) - 1
                if 0 <= idx < len(options):
                    answers[qid] = options[idx]
                else:
                    answers[qid] = raw
            else:
                answers[qid] = raw

        return answers
