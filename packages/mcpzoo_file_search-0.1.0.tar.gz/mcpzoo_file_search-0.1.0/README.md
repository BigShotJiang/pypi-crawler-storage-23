# mcpzoo-file-search

> 文件搜索 — 在指定目录中搜索匹配模式的文件

## Installation

```bash
uvx mcpzoo-file-search
```

## uvx JSON

```json
{
  "mcpServers": {
    "file-search": {
      "args": ["mcpzoo-file-search"],
      "command": "uvx"
    }
  }
}
```
