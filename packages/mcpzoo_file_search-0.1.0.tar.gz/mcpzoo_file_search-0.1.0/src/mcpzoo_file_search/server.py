import os
import fnmatch
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("file-search")

@mcp.tool()
def search_files(directory: str, pattern: str = "*", recursive: bool = True, max_results: int = 100) -> str:
    """在指定目录中搜索匹配模式（glob）的文件。"""
    if not os.path.isdir(directory):
        return f"目录不存在或不是一个目录: {directory}"
        
    results = []
    try:
        if recursive:
            for root, dirs, files in os.walk(directory):
                for basename in files:
                    if fnmatch.fnmatch(basename, pattern):
                        results.append(os.path.join(root, basename))
                        if len(results) >= max_results:
                            return "\n".join(results) + f"\n... (已截断到前 {max_results} 个结果)"
        else:
            for basename in os.listdir(directory):
                if fnmatch.fnmatch(basename, pattern):
                    results.append(os.path.join(directory, basename))
                    if len(results) >= max_results:
                        return "\n".join(results) + f"\n... (已截断到前 {max_results} 个结果)"
                        
        if not results:
            return "未找到匹配的文件"
        return "\n".join(results)
    except Exception as e:
        return f"搜索失败: {e}"

def main():
    mcp.run()

if __name__ == "__main__":
    main()
