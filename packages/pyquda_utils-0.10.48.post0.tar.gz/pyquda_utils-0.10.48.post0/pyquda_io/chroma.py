from os import path

from .mpi_utils import getSublatticeSize, readMPIFile
from .io_utils import checksumSciDAC, gaugeReunitarize

Nd, Ns, Nc = 4, 4, 3
_precision_map = {"D": 8, "F": 4}


def readQIOGauge(filename: str, checksum: bool = True, reunitarize_sigma: float = 1e-6):
    from .lime import Lime

    filename = path.expanduser(path.expandvars(filename))
    lime = Lime(filename)
    scidac_private_file_xml = lime.loadXML("scidac-private-file-xml")
    scidac_private_record_xml = lime.loadXML("scidac-private-record-xml")
    scidac_checksum_xml = lime.loadXML("scidac-checksum")
    offset = lime.record("ildg-binary-data").offset

    precision = _precision_map[scidac_private_record_xml.find("precision").text]
    assert int(scidac_private_record_xml.find("colors").text) == Nc
    assert int(scidac_private_record_xml.find("typesize").text) == Nc * Nc * 2 * precision
    assert int(scidac_private_record_xml.find("datacount").text) == Nd
    assert int(scidac_private_file_xml.find("spacetime").text) == Nd
    latt_size = [int(L) for L in scidac_private_file_xml.find("dims").text.split()]
    Lx, Ly, Lz, Lt = getSublatticeSize(latt_size)
    dtype = f">c{2 * precision}"

    gauge = readMPIFile(filename, dtype, offset, (Lt, Lz, Ly, Lx, Nd, Nc, Nc), (3, 2, 1, 0))
    if checksum:
        assert (
            int(scidac_checksum_xml.find("suma").text, 16),
            int(scidac_checksum_xml.find("sumb").text, 16),
        ) == checksumSciDAC(latt_size, gauge.reshape(Lt * Lz * Ly * Lx, Nd * Nc * Nc))
    gauge = gauge.transpose(4, 0, 1, 2, 3, 5, 6).astype("<c16")
    if precision == 4:
        gauge = gaugeReunitarize(gauge, reunitarize_sigma)
    return latt_size, gauge


def readQIOPropagator(filename: str, checksum: bool = True):
    from .lime import Lime

    filename = path.expanduser(path.expandvars(filename))
    lime = Lime(filename)
    scidac_private_file_xml = lime.loadXML("scidac-private-file-xml")
    scidac_private_record_xml = lime.loadXML("scidac-private-record-xml")
    scidac_checksum_xml = lime.loadXML("scidac-checksum")
    offset = lime.record("scidac-binary-data").offset

    precision = _precision_map[scidac_private_record_xml.find("precision").text]
    assert int(scidac_private_record_xml.find("colors").text) == Nc
    assert int(scidac_private_record_xml.find("spins").text) == Ns
    assert int(scidac_private_record_xml.find("typesize").text) == Ns * Ns * Nc * Nc * 2 * precision
    assert int(scidac_private_record_xml.find("datacount").text) == 1
    assert int(scidac_private_file_xml.find("spacetime").text) == Nd
    latt_size = [int(L) for L in scidac_private_file_xml.find("dims").text.split()]
    Lx, Ly, Lz, Lt = getSublatticeSize(latt_size)
    dtype = f">c{2 * precision}"

    propagator = readMPIFile(filename, dtype, offset, (Lt, Lz, Ly, Lx, Ns, Ns, Nc, Nc), (3, 2, 1, 0))
    if checksum:
        assert (
            int(scidac_checksum_xml.find("suma").text, 16),
            int(scidac_checksum_xml.find("sumb").text, 16),
        ) == checksumSciDAC(latt_size, propagator.reshape(Lt * Lz * Ly * Lx, Ns * Ns * Nc * Nc))
    propagator = propagator.astype("<c16")
    return latt_size, propagator


def readQIOStaggeredPropagator(filename: str, checksum: bool = True):
    from .lime import Lime

    filename = path.expanduser(path.expandvars(filename))
    lime = Lime(filename)
    scidac_private_file_xml = lime.loadXML("scidac-private-file-xml")
    scidac_private_record_xml = lime.loadXML("scidac-private-record-xml")
    scidac_checksum_xml = lime.loadXML("scidac-checksum")
    offset = lime.record("scidac-binary-data").offset

    precision = _precision_map[scidac_private_record_xml.find("precision").text]
    assert int(scidac_private_record_xml.find("colors").text) == Nc
    assert int(scidac_private_record_xml.find("typesize").text) == Nc * Nc * 2 * precision
    assert int(scidac_private_record_xml.find("datacount").text) == 1
    assert int(scidac_private_file_xml.find("spacetime").text) == Nd
    latt_size = [int(L) for L in scidac_private_file_xml.find("dims").text.split()]
    Lx, Ly, Lz, Lt = getSublatticeSize(latt_size)
    dtype = f">c{2 * precision}"

    propagator = readMPIFile(filename, dtype, offset, (Lt, Lz, Ly, Lx, Nc, Nc), (3, 2, 1, 0))
    if checksum:
        assert (
            int(scidac_checksum_xml.find("suma").text, 16),
            int(scidac_checksum_xml.find("sumb").text, 16),
        ) == checksumSciDAC(latt_size, propagator.reshape(Lt * Lz * Ly * Lx, Nc * Nc))
    propagator = propagator.astype("<c16")
    return latt_size, propagator
