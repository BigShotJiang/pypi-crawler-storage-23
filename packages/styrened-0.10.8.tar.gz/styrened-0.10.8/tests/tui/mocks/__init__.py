"""Mock objects for testing."""

from tests.mocks.rpc_client_mock import MockRPCClient

__all__ = ["MockRPCClient"]
