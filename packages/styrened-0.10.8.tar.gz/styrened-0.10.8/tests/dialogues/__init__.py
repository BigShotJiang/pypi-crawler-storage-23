"""Dialogue testing framework for styrened overnight tests.

Provides models, primitives, and YAML-driven dialogue scripts for
exercising multi-turn conversations between styrened instances.
"""
