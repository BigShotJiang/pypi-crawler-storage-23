# coding=utf-8

"""Runtime 工具转换公共组件。

目标：
- 统一 tool -> OpenAI function tools 的转换逻辑。
- 统一 function.name 的命名：`name_id@belongToProjectId`（来自 tool 对象）。
- 支持 MCP 工具的转换。

注意：
- 不做网络请求；仅做结构转换。
- input schema 优先使用 tool.input_schema；缺失时尝试从 tool.input 推导。
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

from turbo_agent_core.utils.identity import build_tool_call_name
from turbo_agent_core.schema.agents import MCPTool


def convert_tools_to_openai_functions(
    tools: List[Any], 
    *, 
    parameters_to_json_schema: Any = None,
    include_mcp: bool = True,
) -> List[Dict[str, Any]]:
    """将工具列表转换为 OpenAI function 格式。
    
    Args:
        tools: 工具列表，可包含 Tool、MCPTool 等
        parameters_to_json_schema: 参数到 JSON schema 的转换函数
        include_mcp: 是否支持 MCP 工具转换（默认 True）
        
    Returns:
        OpenAI function 格式列表
    """
    converted: List[Dict[str, Any]] = []

    for tool in tools or []:
        # 检查是否为 MCP 工具
        if include_mcp and isinstance(tool, MCPTool):
            converted.append(_convert_mcp_tool_to_openai_function(tool))
        else:
            # 标准工具转换
            schema = getattr(tool, "input_schema", None)
            if (schema is None or schema == {}) and parameters_to_json_schema is not None:
                tool_input = getattr(tool, "input", None)
                if tool_input:
                    schema = parameters_to_json_schema(tool_input)

            converted.append(
                {
                    "type": "function",
                    "function": {
                        "name": build_tool_call_name(tool),
                        "description": getattr(tool, "description", None) or "",
                        "parameters": schema or {},
                    },
                }
            )

    return converted


def _convert_mcp_tool_to_openai_function(mcp_tool: MCPTool) -> Dict[str, Any]:
    """将 MCPTool 转换为 OpenAI function 格式。
    
    Args:
        mcp_tool: MCP 工具
        
    Returns:
        OpenAI function 格式字典
    """
    # 获取输入 schema
    schema = _extract_mcp_input_schema(mcp_tool)
    
    # 构建描述
    description_parts = []
    if mcp_tool.server and mcp_tool.server.name:
        description_parts.append(f"[{mcp_tool.server.name}]")
    if mcp_tool.description:
        description_parts.append(mcp_tool.description)
    elif mcp_tool.resource and mcp_tool.resource.description:
        description_parts.append(mcp_tool.resource.description)
    
    description = " ".join(description_parts) if description_parts else ""
    
    return {
        "type": "function",
        "function": {
            "name": build_tool_call_name(mcp_tool),
            "description": description,
            "parameters": schema or {},
        },
    }


def _extract_mcp_input_schema(mcp_tool: MCPTool) -> Dict[str, Any]:
    """从 MCPTool 提取输入 schema。
    
    Args:
        mcp_tool: MCP 工具
        
    Returns:
        JSON schema dict
    """
    # 优先使用 resource 的 schema
    if mcp_tool.resource and mcp_tool.resource.input_schema:
        return mcp_tool.resource.input_schema
    
    # 从 input 参数推导
    if mcp_tool.input:
        try:
            from turbo_agent_core.utils.param_schema import parameters_to_json_schema
            return parameters_to_json_schema(mcp_tool.input)
        except Exception:
            pass
    
    return {"type": "object", "properties": {}}


def is_mcp_tool(tool: Any) -> bool:
    """检查工具是否为 MCP 工具。
    
    Args:
        tool: 工具对象
        
    Returns:
        是否为 MCP 工具
    """
    return isinstance(tool, MCPTool)


def filter_mcp_tools(tools: List[Any]) -> List[MCPTool]:
    """从工具列表中过滤出 MCP 工具。
    
    Args:
        tools: 工具列表
        
    Returns:
        MCP 工具列表
    """
    return [t for t in tools if isinstance(t, MCPTool)]


def separate_tools_by_type(
    tools: List[Any]
) -> Dict[str, List[Any]]:
    """按类型分离工具列表。
    
    Args:
        tools: 工具列表
        
    Returns:
        按类型分类的工具字典，包含：
        - standard: 标准工具
        - mcp: MCP 工具
        - frontend: 前端工具
        - builtin: 内置工具
    """
    from turbo_agent_core.schema.agents import FrontendTool, BuiltinTool
    
    result = {
        "standard": [],
        "mcp": [],
        "frontend": [],
        "builtin": [],
        "other": [],
    }
    
    for tool in tools or []:
        if isinstance(tool, MCPTool):
            result["mcp"].append(tool)
        elif isinstance(tool, FrontendTool):
            result["frontend"].append(tool)
        elif isinstance(tool, BuiltinTool):
            result["builtin"].append(tool)
        elif isinstance(tool, (type(None),)):
            # 忽略 None
            pass
        else:
            # 其他类型视为标准工具
            result["standard"].append(tool)
    
    return result
