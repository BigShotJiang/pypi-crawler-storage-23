import base64
import copy
import json
import re
import os
import time
from argparse import ArgumentParser

from volcengine.visual.VisualService import VisualService
from pydantic import BaseModel, Field
from enum import Enum
from typing import Dict, List, Optional

class ImagePrompt(BaseModel):
    prompt: str

class GeneratedImages(BaseModel):
    image_urls: List[str]

def image_gen(prompt:ImagePrompt):
    visual_service = VisualService()

    # call below method if you don't set ak and sk in $HOME/.volc/config
    visual_service.set_ak('AKLTZGU1ZGQ5MmVhOWI1NDhhM2ExZjAzZmI5MTZhMmYyNjM')
    visual_service.set_sk('WXpaa1pUbGhOamxpWVdJM05EZGpZMkV5TldFNFptRTBaR1pqTXpBeFpEUQ==')
    
    # 请求Body(查看接口文档请求参数-请求示例，将请求参数内容复制到此)
    form = {
        "req_key": "high_aes_general_v20_L",
        "prompt":prompt.prompt,
        "model_version":"general_v2.0_L",
        "req_schedule_conf":"general_v20_9B_rephraser",
        "return_url":True
    }

    resp = visual_service.cv_process(form)
    return GeneratedImages(image_urls=resp["data"]["image_urls"])