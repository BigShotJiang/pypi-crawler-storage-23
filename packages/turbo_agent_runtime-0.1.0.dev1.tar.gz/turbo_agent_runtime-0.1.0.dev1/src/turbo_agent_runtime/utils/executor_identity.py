# coding=utf-8

"""Runtime 执行者标识工具。

约定：
1) executor_id 统一使用 `executor_type:id` 格式
2) 其中 id = `name_id@belongToProjectId`

说明：
- 该约定用于跨产品线（云/端/worker）统一审计与展示。
- 若缺少必要字段（name_id/belongToProjectId），会回退到 `id` 字段，确保不中断运行。
"""

from __future__ import annotations

from typing import Any

from turbo_agent_core.utils.identity import build_scoped_id as build_entity_id
from turbo_agent_core.utils.identity import build_executor_id
