import json
from turbo_agent.db.client import db
from litellm import acompletion, completion_cost 
from loguru import logger
import asyncio
import litellm
from typing import List, Dict, Any, Optional
from copy import deepcopy
from turbo_agent.config import settings

BasicType = str  # 可以使用 Literal["string", "datetime", "enum", "array", "object"] 替代

def trans_parameter_to_json_schema(name,root_type,parameters: List[Dict[str, Any]]) -> Dict[str, Any]:
    properties = {}
    required = []

    for parameter in parameters:
        p_name = parameter.get("name")
        p_type = parameter.get("type")
        is_required = parameter.get("required", False)
        description = parameter.get("description", "")
        default = parameter.get("default")

        if not name or not p_type:
            continue

        if is_required:
            required.append(p_name)

        prop = {
            "title": p_name,
            "description": description
        }

        if default is not None:
            prop["default"] = default

        if p_type == "datetime":
            prop.update({
                "type": "string",
                "format": "date-time"
            })
        elif p_type == "enum":
            enum_values = parameter.get("enum_values")
            if enum_values:
                prop.update({
                    "type": "string",
                    "enum": enum_values
                })
        elif p_type == "array":
            type_ref = parameter.get("type_ref")
            if type_ref == "object":
                # 使用 json_schema 提供的对象结构
                item_schema = trans_parameter_to_json_schema(name=p_name+"_list_element",root_type=type_ref,parameters=parameter.get("parameters",[]))
                prop.update({
                    "type": "array",
                    "items": deepcopy(item_schema)
                })
            else:
                prop.update({
                    "type": "array",
                    "items": {"type": type_ref} if type_ref else {}
                })
        elif p_type == "object":
            schema = trans_parameter_to_json_schema(name=p_name,root_type="object",parameters=parameter.get("parameters",[]))
            prop.update(deepcopy(schema))
        else:
            prop["type"] = p_type

        properties[p_name] = prop

    if root_type=="object":
        return {
            "title":name,
            "type": "object",
            "required": required,
            "properties": properties,
        }
    elif root_type=="array":
        return {
            "title":name,
            "type": "array",
            "items":{
                "title":name+"_list_element",
                "type":"object",
                "required": required,
                "properties": properties,
            }
        }
    else:
        return {
            "required": required,
            "properties": properties,
        }
def parse_handlebar_result(result: str):
    """
    解析 handlebar 模板结果，自动识别并移除各种代码块标识符
    支持：```handlebars, ```hbs, ```html, ``` 等格式
    """
    if not result:
        return result
    
    result = result.strip()
    
    # 支持的代码块标识符列表
    code_block_identifiers = [
        "```handlebars",
        "```hbs", 
        "```html",
        "```"  # 普通代码块，放在最后作为兜底
    ]
    
    # 尝试找到代码块的开始和结束位置
    begin = -1
    begin_marker = None
    
    for identifier in code_block_identifiers:
        pos = result.find(identifier)
        if pos >= 0:
            begin = pos
            begin_marker = identifier
            break
    
    if begin >= 0:
        # 找到了代码块开始标识符
        end = result.rfind("```")  # 找到最后一个结束标识符
        
        if end > begin:
            # 提取代码块内容
            start_pos = begin + len(begin_marker)
            output_raw = result[start_pos:end].strip()
            
            # 清理多余的引号
            output_raw = output_raw.replace("\" \"", "\"")
            return output_raw
    
    # 如果没有找到代码块标识符，直接返回原内容
    return result

# 从配置加载模型与鉴权信息
template_api_key = settings.TEMPLATE_MODEL_API_KEY
template_api_url = settings.TEMPLATE_MODEL_API_URL
template_request_model_id = settings.TEMPLATE_MODEL

# 兼容现有变量名的别名
api_key = template_api_key
api_url = template_api_url
request_model_id = template_request_model_id

# litellm._turn_on_debug()
async def gen_tool_version_template(tool_output_schema:str):
    messages=[
        {
                "role":"system",
                "content":"你是一个乐于助人的助手，请尽全力帮助用户完成他需要你帮助他完成的功能"
        },
        {
            "role":"user",
            "content":gen_handle_bars_prompt_template+json.dumps(tool_output_schema,ensure_ascii=False,indent=2)+finish_prompt
        }
    ]
    logger.info("messages:"+str(messages))
    response =await acompletion(
            model=f"openai/{request_model_id}",               # add `openai/` prefix to model so litellm knows to route to OpenAI
            api_key=api_key,                  # api key to your openai compatible endpoint
            api_base=api_url,     # set API Base of your Custom OpenAI Endpoint
            messages=messages,
            temperature=0.6,
            stream=True,
            input_cost_per_token=0.005,
            output_cost_per_token=1
        )
    output = ""
    async for chunk in response:
        # print(chunk.choices[0].delta.content or "")
        output+=chunk.choices[0].delta.content or ""
    # logger.info("output:"+str(output))
    # cost = completion_cost(completion_response=response)
    # logger.info("cost:"+str(cost))
    
    return parse_handlebar_result(output)

async def update_tool_version_template(tool_version_id:str,user_id:str):
    if not db.is_connected():
        await db.connect()
    versions = await db.toolversion.find_many(
        where={
            "id":tool_version_id
        }
    )
    for version in versions:
        # if version.output_handlebar_template:
        #     if verbose:
        #         logger.info(f"跳过已存在模板的 toolversion: {version.id} {version.versionOfToolNameId}")
        #     continue
        json_schema_type = version.output_schema.get("type","object")
        final_json_schema = trans_parameter_to_json_schema(name=version.versionOfToolNameId+"_output",root_type=json_schema_type,parameters=version.output)
        
        version.output_schema = json.dumps(final_json_schema,ensure_ascii=False)
        raw_template = await gen_tool_version_template(version.output_schema)
        # 清理模板中的代码块标识符
        version.output_handlebar_template = parse_handlebar_result(raw_template)
        
        # if verbose:
        logger.info("origin output:"+str(version.output))
        logger.info("version.output_schema:"+str(version.output_schema))
        logger.info("raw_template: " + raw_template)
        logger.info("cleaned output_handlebar_template: " + version.output_handlebar_template)
        # if not dry_run:
        result = await db.toolversion.update(
            where={
                "id":version.id
            },
            data={
                "output_schema":version.output_schema,
                "output_handlebar_template":version.output_handlebar_template,
            }
        )
        return result

async def flush_tool_version(dry_run,verbose):
    if not db.is_connected():
        await db.connect()
    versions =await db.toolversion.find_many()
    for version in versions:
        if version.output_handlebar_template:
            if verbose:
                logger.info(f"跳过已存在模板的 toolversion: {version.id} {version.versionOfToolNameId}")
            continue
        json_schema_type = version.output_schema.get("type","object")
        final_json_schema = trans_parameter_to_json_schema(name=version.versionOfToolNameId+"_output",root_type=json_schema_type,parameters=version.output)
        
        version.output_schema = json.dumps(final_json_schema,ensure_ascii=False)
        raw_template = await gen_tool_version_template(version.output_schema)
        # 清理模板中的代码块标识符
        version.output_handlebar_template = parse_handlebar_result(raw_template)
        
        if verbose:
            logger.info("origin output:"+str(version.output))
            logger.info("version.output_schema:"+str(version.output_schema))
            logger.info("raw_template: " + raw_template)
            logger.info("cleaned output_handlebar_template: " + version.output_handlebar_template)
        if not dry_run:
            await db.toolversion.update(
                where={
                    "id":version.id
                },
                data={
                    "output_schema":version.output_schema,
                    "output_handlebar_template":version.output_handlebar_template,
                }
            )

gen_handle_bars_prompt_template="""

当前前端框架为：daisyui+tailwind+reactjs+iconfiy（logo）+react-grid-layout。
现在需要根据输出schema 构造一个结果展示子组件。可接收与输出schema相符的数据并展示出来。
子组件只能以handle bars template的方式从后端传入，再结合要展示的数据在页面中作渲染，没有办法直接作为组件集成到代码中。 输出结果的子组件高度和宽度应均为full。你提供的输出结果子组件将会被嵌套入父组件（card 组件）的card body中，为保证展示效果，不要嵌套太多层card组件(算上父组件不超过2层，且越内层shadow越小或者没有)。
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 参考信息：

1. daisyui 使用方式参考链接：
   [https://daisyui.com/components/](https://daisyui.com/components/)
   Accordion
   Accordion
   Accordion is used for showing and hiding content but only one item can stay open at a time.

Alert
Alert
Alert informs users about important events.

Avatar
Avatar
Avatars are used to show a thumbnail representation of an individual or business in the interface.

Badge
Badge
Badges are used to inform the user of the status of specific data.

Breadcrumbs
Breadcrumbs
Breadcrumbs helps users to navigate through the website.

Button
Button
Buttons allow the user to take actions or make choices.

Calendar
Calendar
Calendar includes styles for different calendar libraries.

Card
Card
Cards are used to group and display content in a way that is easily readable.

Carousel
Carousel
Carousel show images or content in a scrollable area.

Chat bubble
Chat bubble
Chat bubbles are used to show one line of conversation and all its data, including the author image, author name, time, etc.

Checkbox
Checkbox
Checkboxes are used to select or deselect a value.

Collapse
Collapse
Collapse is used for showing and hiding content.

Countdown
Countdown
Countdown gives you a transition effect when you change a number between 0 to 99.

Diff
Diff
Diff component shows a side-by-side comparison of two items.

Divider
Divider
Divider will be used to separate content vertically or horizontally.

Dock
Dock
Dock (also know as Bottom navigation or Bottom bar) is a UI element that provides navigation options to the user. Dock sticks to the bottom of the screen.

Drawer
Drawer
Drawer is a grid layout that can show/hide a sidebar on the left or right side of the page.

Dropdown
Dropdown
Dropdown can open a menu or any other element when the button is clicked.

Fieldset
Fieldset
Fieldset is a container for grouping related form elements. It includes fieldset-legend as a title and label as a description.

File Input
File Input
File Input is a an input field for uploading files.

Filter
Filter
Filter is a group of radio buttons. Choosing one of the options will hide the others and shows a reset button next to the chosen option.

Footer
Footer
Footer can contain logo, copyright notice, and links to other pages.

Hero
Hero
Hero is a component for displaying a large box or image with a title and description.

Indicator
Indicator
Indicators are used to place an element on the corner of another element.

Text Input
Text Input
Text Input is a simple input field.

Join
Join
Join is a container for grouping multiple items, it can be used to group buttons, inputs, etc. Join applies border radius to the first and last item. Join can be used to create a horizontal or vertical list of items.

Kbd
Kbd
Kbd is used to display keyboard shortcuts.

Label
Label
Label is used to provide a name or title for an input field. Label can be placed before or after the field.

Link
Link
Link adds the missing underline style to links.

List
List
List is a vertical layout to display information in rows.

Loading
Loading
Loading shows an animation to indicate that something is loading.

Mask
Mask
Mask crops the content of the element to common shapes.

Menu
Menu
Menu is used to display a list of links vertically or horizontally.

Browser mockup
Browser mockup
Browser mockup shows a box that looks like a browser window.

Code mockup
Code mockup
Code mockup is used to show a block of code in a box that looks like a code editor.

Phone mockup
Phone mockup
Phone mockup shows a mockup of an iPhone.

Window mockup
Window mockup
Window mockup shows a box that looks like an operating system window.

Modal
Modal
Modal is used to show a dialog or a box when you click a button.

Navbar
Navbar
Navbar is used to show a navigation bar on the top of the page.

Pagination
Pagination
Pagination is a group of buttons that allow the user to navigate between a set of related content.

Progress
Progress
Progress bar can be used to show the progress of a task or to show the passing of time.

Radial progress
Radial progress
Radial progress can be used to show the progress of a task or to show the passing of time.

Radio
Radio
Radio buttons allow the user to select one option from a set.

Range slider
Range slider
Range slider is used to select a value by sliding a handle.

Rating
Rating
Rating is a set of radio buttons that allow the user to rate something.

Select
Select
Select is used to pick a value from a list of options.

Skeleton
Skeleton
Skeleton is a component that can be used to show a loading state of a component.

Stack
Stack
Stack visually puts elements on top of each other.

Stat
Stat
Stat is used to show numbers and data in a block.

Status
Status
Status is a really small icon to visually show the current status of an element, like online, offline, error, etc.

Steps
Steps
Steps can be used to show a list of steps in a process.

Swap
Swap
Swap allows you to toggle the visibility of two elements using a checkbox or a class name.

Tabs
Tabs
Tabs can be used to show a list of links in a tabbed format.

Table
Table
Table can be used to show a list of data in a table format.

Textarea
Textarea
Textarea allows users to enter text in multiple lines.

Theme Controller
Theme Controller
If a checked checkbox input or a checked radio input with theme-controller class exists in the page, The page will have the same theme as that input's value.

Timeline
Timeline
Timeline component shows a list of events in chronological order.

Toast
Toast
Toast is a wrapper to stack elements, positioned on the corner of page.

Toggle
Toggle
Toggle is a checkbox that is styled to look like a switch button.

Tooltip
Tooltip
Tooltip can be used to show a message when hovering over an element.

Validator
Validator
Validator class changes the color of form elements to error or success based on input's validation rules.

-----------------

handlebars 模板中不支持直接插入JS代码，否则会导致XSS攻击风险, 仅可使用daisyui的Tabs 进行简单交互 ！！ 
Tabs 参考样例如下：
<div class="tabs tabs-lift">
  <input type="radio" name="my_tabs_3" class="tab" aria-label="Tab 1" />
  <div class="tab-content bg-base-100 border-base-300 p-6">Tab content 1</div>

  <input type="radio" name="my_tabs_3" class="tab" aria-label="Tab 2" checked="checked" />
  <div class="tab-content bg-base-100 border-base-300 p-6">Tab content 2</div>

  <input type="radio" name="my_tabs_3" class="tab" aria-label="Tab 3" />
  <div class="tab-content bg-base-100 border-base-300 p-6">Tab content 3</div>
</div>

界面风格尽可能扁平化，简洁化，避免过多TAB嵌套，所有组件均使用daisyui组件，避免自定义css样式。
所有界面文字均使用中文！！！所有界面文字均使用中文！！！所有界面文字均使用中文！！！
---------------------------------------------------------------------------------------------------------

2. iconify 参考样例如下： 
<span className="iconify carbon--chevron-down size-6"></span> 
<span className="iconify lucide--layout-dashboard size-6"></span> 
<span className="iconify carbon--chat size-6"></span>
...（也可以使用其它 carbon或 lucide 系列的icon）


-----------------------------

3. 如果遇到展示的变量内容为markdown， 务必使用自定义Helper: "Markdown" 并且外围使用 `<div className='prose dark:prose-invert max-w-none'>` 使用参考样例如下 ：
```
    <div className='prose dark:prose-invert max-w-none'>
       {{Markdown the_markdown_variable}}
    </div>
```

----------------------------

现在有一个工具 输出schema是：
""" 
finish_prompt="""
严格按照该schema格式在handlebars template中使用对应的变量名进行展示，不能新增、修改、删除、缩略任何字段。
严格按照该schema格式在handlebars template中使用对应的变量名进行展示，不能新增、修改、删除、缩略任何字段。
严格按照该schema格式在handlebars template中使用对应的变量名进行展示，不能新增、修改、删除、缩略任何字段。

不要插入任何JS代码！！！！ 不能使用任何JS表达式！！！！ 不能包含任何script标签！！！！
--------------
请生成 用于展示输出数据 子组件 的 handelbars template。仅handlebars template即可，你下面输出的内容将直接用于中handelbars compile中，不需要提供任何可能导致代码错误的其它信息，父组件不需要被包含在handle bars template中。
"""

async def main():
    await flush_tool_version(dry_run=False, verbose=True)

if __name__ =="__main__":
    asyncio.run(main())