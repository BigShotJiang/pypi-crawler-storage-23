from __future__ import annotations

import json
import uuid
from typing import List, Union, Dict, Any, Optional
from loguru import logger

from turbo_agent_core.schema.states import Message, Action, ReActRound
from turbo_agent_core.schema.enums import MessageRole, ActionStatus


# Linkage removed


def convert_state_message_to_openai_message(core_message: Message) -> List[Dict[str, Any]]:
    """
    将 Turbo Agent 的 Core Message (原 State Message) 转换为 OpenAI 格式的消息列表。
    """
    if core_message.role == MessageRole.user:
        return [{"role": "user", "content": core_message.content or ""}]
    
    elif core_message.role == MessageRole.system:
        return [{"role": "system", "content": core_message.content or ""}]
    
    elif core_message.role == MessageRole.assistant:
        results = []
        
        # 1. 优先处理 reactRounds (多轮对话历史复原)
        if hasattr(core_message, "reactRounds") and core_message.reactRounds:
            for round_data in core_message.reactRounds:
                
                # 1.1 构造 Assistant 消息 (可能包含 Tool Calls)
                tool_calls = []
                for action in round_data.actions:
                    args = {}
                    if isinstance(action.input, dict):
                        args = action.input
                    elif isinstance(action.input, str):
                        try:
                            args = json.loads(action.input)
                        except json.JSONDecodeError:
                            args = {"__raw__": action.input}
                    
                    tool_calls.append({
                        "id": action.id,
                        "type": "function",
                        "function": {
                            "name": action.name or "unknown_tool",
                            "arguments": json.dumps(args, ensure_ascii=False)
                        }
                    })

                assistant_content = round_data.content
                if isinstance(assistant_content, dict):
                    assistant_content = str(assistant_content)

                msg = {
                    "role": "assistant",
                    "content": assistant_content
                }
                
                if tool_calls:
                    msg["tool_calls"] = tool_calls
                
                if round_data.thought:
                    msg["reasoning_content"] = round_data.thought

                if msg["content"] or tool_calls or msg.get("reasoning_content"):
                    results.append(msg)
                
                # 1.2 构造 Tool 结果消息
                for action in round_data.actions:
                    raw_content = action.observation
                    if raw_content is None:
                        tool_content = "Tool output not available"
                    elif isinstance(raw_content, str):
                        tool_content = raw_content
                    else:
                        try:
                            tool_content = json.dumps(raw_content, ensure_ascii=False)
                        except Exception:
                            tool_content = str(raw_content)

                    results.append({
                        "role": "tool",
                        "tool_call_id": action.id,
                        "content": tool_content
                    })
            
            return results

        # 2. Fallback: 普通 actions 处理 (无 reactRounds)
        if core_message.actions:
            tool_calls = []
            
            # 使用第一个 action 的 intent/summary 作为 assistant content
            first_action = core_message.actions[0]
            ai_content = first_action.intent or first_action.summary or ""
            if core_message.content and not ai_content:
                ai_content = core_message.content

            for action in core_message.actions:
                args = {}
                if isinstance(action.input, dict):
                    args = action.input
                elif isinstance(action.input, str):
                    try:
                        args = json.loads(action.input)
                    except json.JSONDecodeError:
                        args = {"__raw__": action.input}
                
                tool_calls.append({
                    "id": action.id,
                    "type": "function",
                    "function": {
                        "name": action.name or "unknown_tool",
                        "arguments": json.dumps(args, ensure_ascii=False)
                    }
                })
            
            msg = {
                "role": "assistant",
                "content": ai_content,
                "tool_calls": tool_calls
            }
            if core_message.reasoning_content:
                msg["reasoning_content"] = core_message.reasoning_content
            
            results.append(msg)
            
            # 添加 Tool Results
            for action in core_message.actions:
                raw_content = action.observation
                if raw_content is None:
                    tool_content = "Tool output not available"
                elif isinstance(raw_content, str):
                    tool_content = raw_content
                else:
                    try:
                        tool_content = json.dumps(raw_content, ensure_ascii=False)
                    except Exception:
                        tool_content = str(raw_content)

                results.append({
                    "role": "tool",
                    "tool_call_id": action.id,
                    "content": tool_content
                })

            # 如果还有额外的 content 且未被 consummed
            if core_message.content and core_message.content != ai_content:
                 results.append({
                     "role": "assistant",
                     "content": core_message.content
                 })
            
            return results
        
        # 3. 纯文本 Assistant 回复
        msg = {
            "role": "assistant",
            "content": core_message.content or ""
        }
        if core_message.reasoning_content:
            msg["reasoning_content"] = core_message.reasoning_content
        return [msg]
    # Fallback
    return [{"role": core_message.role.value, "content": core_message.content or ""}]

def convert_openai_message_to_state_message(message: Any) -> Optional[Message]:
    """
    将 OpenAI 格式的消息 (dict 或 ChatCompletionMessage 对象) 转换为 Core Message。
    """
    if not message:
        return None
    
    def get_val(obj, key, default=None):
        if isinstance(obj, dict):
            return obj.get(key, default)
        return getattr(obj, key, default)

    role_str = get_val(message, "role")
    content = get_val(message, "content")
    tool_calls = get_val(message, "tool_calls")
    reasoning_content = get_val(message, "reasoning_content")
    
    role = MessageRole.user
    if role_str == "assistant":
        role = MessageRole.assistant
    elif role_str == "system":
        role = MessageRole.system
    elif role_str == "tool":
        # Tool message usually doesn't convert directly to a standalone State Message 
        # But if we must:
        return Message(
            id=str(uuid.uuid4()),
            role=MessageRole.assistant,
            content=str(content or "")
        )

    msg_id = str(uuid.uuid4())
    actions = []

    if tool_calls:
        for tc in tool_calls:
            func = get_val(tc, "function")
            fname = get_val(func, "name")
            fargs = get_val(func, "arguments")
            
            if isinstance(fargs, str):
                try:
                    fargs = json.loads(fargs)
                except:
                    pass
            
            action = Action(
                id=get_val(tc, "id") or str(uuid.uuid4()),
                name=fname,
                input=fargs or {},
                status=ActionStatus.Pending
            )
            actions.append(action)

    # Construct ReActRound to preserve structure
    react_round = ReActRound(
        id=str(uuid.uuid4()),
        thought=reasoning_content,
        content=content if content is not None else None,
        belongToMessageId=msg_id,
        actions=actions
    )

    msg = Message(
        id=msg_id,
        role=role,
        content=str(content) if content is not None else "", # Content can be None
        actions=actions,
        reactRounds=[react_round]
    )
    
    if reasoning_content:
        msg.reasoning_content = reasoning_content
            
    return msg
