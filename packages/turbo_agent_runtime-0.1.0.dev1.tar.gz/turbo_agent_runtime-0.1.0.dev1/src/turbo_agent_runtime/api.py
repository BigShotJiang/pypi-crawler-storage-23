from __future__ import annotations

from typing import AsyncIterator, List, Optional
from loguru import logger

from turbo_agent_core.schema.enums import RunType, JSON
from turbo_agent_core.schema.entity import TurboEntity
from turbo_agent_core.schema.events import (
    BaseEvent,
    RunLifecycleCreatedEvent,
    RunLifecycleCreatedPayload,
    RunLifecycleCompletedEvent,
    RunLifecycleCompletedPayload,
    RunLifecycleFailedEvent,
    RunLifecycleFailedPayload,
    ContentTextDeltaEvent,
    ContentTextDeltaPayload,
    ExecutorMetadata,
    UserInfo,
)
from turbo_agent_core.schema.agents import Tool, APITool, LLMTool, AgentTool
from turbo_agent_core.schema.entity import TurboEntity, LLMModel

from .base import BaseExecutor
from .utils.executor_identity import build_executor_id
# from .context import ExecutionContext

class APIRunExecutor(BaseExecutor):
    run_type = RunType.Tool

    def _resolve_user_metadata(self, **kwargs) -> UserInfo:
        raw = kwargs.get("user_metadata") or kwargs.get("user_info")
        if isinstance(raw, UserInfo):
            return raw
        if isinstance(raw, dict):
            try:
                return UserInfo.model_validate(raw)
            except Exception:
                pass
        user_id = kwargs.get("user_id")
        username = kwargs.get("username")
        return UserInfo(id=str(user_id or "local"), username=str(username or "local"))

    async def run(self, entity: TurboEntity, input: JSON) -> JSON:
        # entity = ctx.entity
        if not isinstance(entity, Tool):
            return {"error": "Entity is not a Tool", "entity_id": entity.id}
        version = self._choose_version(entity)
        if isinstance(version, APITool):
            result = await self._run_api_tool(entity, version, input)
            return {"tool": entity.name, "version": version.id, "result": result}
        if isinstance(version, LLMTool):
            content = await self._run_llm_tool(version, input)
            return {"tool": entity.name, "version": version.id, "llm_output": content}
        if isinstance(version, AgentTool) and version.backendAgent:
            # Delegate to backend agent single-shot (not streaming)
            delegated = await version.backendAgent.run(input)  # patched separately
            return {"tool": entity.name, "version": version.id, "delegated": delegated}
        return {"tool": entity.name, "version": getattr(version, 'id', None), "result": f"stub result for {entity.name}"}

    async def stream(self, entity: TurboEntity, input: JSON, trace_id: Optional[str] = None) -> AsyncIterator[BaseEvent]:
        # entity = ctx.entity
        trace_id = trace_id or getattr(entity, "trace_id", None) or str(__import__("uuid").uuid4())
        run_id = f"run_{entity.id}"
        executor_type = self.run_type
        executor_id = build_executor_id(entity, executor_type)
        executor_path = [executor_id] if executor_id else None

        yield RunLifecycleCreatedEvent(
            trace_id=trace_id,
            trace_path=[],
            run_id=run_id,
            run_path=[run_id],
            executor_id=executor_id,
            executor_type=executor_type,
            executor_path=executor_path,
            executor_metadata=ExecutorMetadata(
                id=getattr(entity, "id", ""),
                name=getattr(entity, "name", None),
                run_type=getattr(entity, "run_type", None),
                version_id=getattr(entity, "version_id", None),
                version=getattr(entity, "version_tag", None),
            ),
            user_metadata=self._resolve_user_metadata(),
            payload=RunLifecycleCreatedPayload(input_data=input),
        )
        try:
            if not isinstance(entity, Tool):
                yield RunLifecycleFailedEvent(
                    trace_id=trace_id,
                    trace_path=[],
                    run_id=run_id,
                    run_path=[run_id],
                    executor_type=executor_type,
                    executor_id=executor_id,
                    executor_path=executor_path,
                    payload=RunLifecycleFailedPayload(
                        error={"code": "TypeError", "message": "Entity is not Tool"}
                    ),
                )
                return
            version = self._choose_version(entity)
            if isinstance(version, APITool):
                result = await self._run_api_tool(entity, version, input)
                yield ContentTextDeltaEvent(
                    trace_id=trace_id,
                    trace_path=[],
                    run_id=run_id,
                    run_path=[run_id],
                    executor_type=executor_type,
                    executor_id=executor_id,
                    executor_path=executor_path,
                    payload=ContentTextDeltaPayload(delta=str(result))
                )
            elif isinstance(version, LLMTool):
                # Stream LLM output tokens
                async for delta in self._stream_llm_tool(
                    version,
                    input,
                    entity,
                    trace_id=trace_id,
                    run_id=run_id,
                    executor_id=executor_id,
                    executor_type=executor_type,
                    executor_path=executor_path,
                ):
                    yield delta
            elif isinstance(version, AgentTool) and version.backendAgent:
                async for evt in version.backendAgent.stream_run(input):
                    yield evt
            else:
                yield ContentTextDeltaEvent(
                    trace_id=trace_id,
                    trace_path=[],
                    run_id=run_id,
                    run_path=[run_id],
                    executor_type=executor_type,
                    executor_id=executor_id,
                    executor_path=executor_path,
                    payload=ContentTextDeltaPayload(delta=f"stub result for {entity.name}")
                )
            yield RunLifecycleCompletedEvent(
                trace_id=trace_id,
                trace_path=[],
                run_id=run_id,
                run_path=[run_id],
                executor_type=executor_type,
                executor_id=executor_id,
                executor_path=executor_path,
                payload=RunLifecycleCompletedPayload(output=None, usage={"total_tokens": 0}),
            )
        except Exception as e:  # pragma: no cover
            logger.exception(e)
            yield RunLifecycleFailedEvent(
                trace_id=trace_id,
                trace_path=[],
                run_id=run_id,
                run_path=[run_id],
                executor_type=executor_type,
                executor_id=executor_id,
                executor_path=executor_path,
                payload=RunLifecycleFailedPayload(error={"code": "RuntimeError", "message": str(e)}),
            )
    # ---------------- internal helpers -----------------
    def _choose_version(self, tool: Tool):
        if not tool.versions:
            return None
        if tool.defaultVersionId:
            for v in tool.versions:
                if getattr(v, "id", None) == tool.defaultVersionId:
                    return v
        return tool.versions[0]

    async def _run_api_tool(self, tool: Tool, version: APITool, input: JSON):
        # Placeholder: integrate real HTTP call based on version fields
        logger.debug(f"_run_api_tool {tool.name} path={version.url_path_template} input={input}")
        return {"echo": input}

    async def _run_llm_tool(self, version: LLMTool, input: JSON):
        model_obj: Optional[LLMModel] = getattr(version, "model", None)
        text = input.get("text") if isinstance(input, dict) else str(input)
        if model_obj and model_obj.instances:
            try:
                from langchain_openai import ChatOpenAI
                instance = model_obj.instances[0]
                endpoint = instance.endpoint
                chat = ChatOpenAI(model=instance.request_model_id or model_obj.id,
                                  base_url=endpoint.url,
                                  api_key=endpoint.accessKeyOrToken,
                                  temperature=0.2)
                resp = await chat.ainvoke([f"你是工具 {version.name}", text])  # type: ignore
                return getattr(resp, "content", None) or str(resp)
            except Exception as e:  # pragma: no cover
                logger.warning(f"LLMTool invocation failed: {e}")
        return f"(stub llm-tool response for {version.name}) 输入: {text}"

    async def _stream_llm_tool(
        self,
        version: LLMTool,
        input: JSON,
        parent: Tool,
        *,
        trace_id: str,
        run_id: str,
        executor_id: str,
        executor_type: RunType,
        executor_path: Optional[List[str]],
    ) -> AsyncIterator[BaseEvent]:
        model_obj: Optional[LLMModel] = getattr(version, "model", None)
        text = input.get("text") if isinstance(input, dict) else str(input)
        # 注意：该函数属于 Parent executor 的事件流产出，应复用调用方的 trace_id/run_id 与执行者上下文。
        
        if model_obj and model_obj.instances:
            try:
                from langchain_openai import ChatOpenAI
                instance = model_obj.instances[0]
                endpoint = instance.endpoint
                chat = ChatOpenAI(model=instance.request_model_id or model_obj.id,
                                  base_url=endpoint.url,
                                  api_key=endpoint.accessKeyOrToken,
                                  temperature=0.2)
                accumulated = ""
                async for chunk in chat.astream([f"你是工具 {version.name}", text]):  # type: ignore
                    part = getattr(chunk, "content", None) or ""
                    if not part:
                        continue
                    accumulated += part
                    yield ContentTextDeltaEvent(
                        trace_id=trace_id,
                        trace_path=[],
                        run_id=run_id,
                        run_path=[run_id],
                        executor_id=executor_id,
                        executor_type=executor_type,
                        executor_path=executor_path,
                        payload=ContentTextDeltaPayload(delta=part)
                    )
                return
            except Exception as e:  # pragma: no cover
                logger.warning(f"LLMTool stream failed: {e}")
        yield ContentTextDeltaEvent(
            trace_id=trace_id,
            trace_path=[],
            run_id=run_id,
            run_path=[run_id],
            executor_id=executor_id,
            executor_type=executor_type,
            executor_path=executor_path,
            payload=ContentTextDeltaPayload(delta=f"(stub llm-tool stream for {version.name}) 输入: {text}")
        )

# Register executor
APIRunExecutor()
