from typing import List, Tuple, Any, Optional
from pydantic import BaseModel, Field
from langchain.tools import StructuredTool

class NamedTool(StructuredTool):
    """A tool that has a name and can be used in a structured way."""
    name_for_human: str = Field(..., description="The name of the tool for humans.")