# -*- coding: utf-8 -*-
import copy
import json
import os
from openai.types.chat.chat_completion_chunk import ChatCompletionChunk,Choice,ChoiceDelta,ChoiceDeltaToolCall,ChoiceDeltaToolCallFunction
from typing import List, Literal, Union,Dict,Iterator,AsyncIterator
from loguru import logger
import uuid
from .schemas import ToolChoiceDelta, ReasoningChoiceDelta


def create_tool_call_chunk(
    ori_chunk: ChatCompletionChunk, 
    type: Literal["Thought", "Action", "Action Input", "Observation", "Answer"],
    tool_call_index: int = -1, 
    tool_call_id: Union[str, None] = None,
    content: Union[str, None] = None, 
) -> ChatCompletionChunk:   
    """创建工具调用chunk"""

    new_chunk = copy.deepcopy(ori_chunk)
    new_chunk.choices[0].delta.content = None
    new_chunk.choices[0].delta.tool_calls = None
    tool_calls = []
    choices = []
    new_id = None
    if type =="Action":
        # Action阶段需要创建一个新的工具调用
        new_id = f"call-{tool_call_index}-{uuid.uuid4()}"
        tool_calls = [ChoiceDeltaToolCall(
            index=tool_call_index,
            id=new_id,
            function=ChoiceDeltaToolCallFunction(
                name=content.strip(),
                arguments=""
            )
        )]
        new_chunk.choices[0].delta.content = None
        new_chunk.choices[0].delta.tool_calls = tool_calls
    elif type == "Action Input":
        # Action Input阶段不需要创建工具调用
        tool_calls = [ChoiceDeltaToolCall(
            index=tool_call_index,
            id= None,
            function=ChoiceDeltaToolCallFunction(
                arguments=content
            )
        )]
        new_chunk.choices[0].delta.content = None
        new_chunk.choices[0].delta.tool_calls = tool_calls
    else:
        # 其他阶段不需要创建工具调用
        tool_calls = None
        
    


    if type in ["Answer"]:
        # 这三个阶段的内容是工具调用的内容
        new_chunk.choices[0].delta.content =content
        new_chunk.choices[0].delta.tool_calls = None
        new_chunk.choices[0].index=0
    elif type == "Thought":
        new_chunk.choices[0].delta.reasoning_content = content
        new_chunk.choices[0].index = 0
    elif type == "Observation":
        new_chunk.choices[0].delta = ToolChoiceDelta(
                tool_call_id=tool_call_id,
                role="tool",
                content=content
            )
        logger.debug(f"创建的工具调用chunk: {type}, choices: {new_chunk}")
    
    # new_chunk["choices"] = [choices[0].model_dump()]
    # logger.debug(f"创建的工具调用chunk: {type}, choices: {new_chunk}")
    if type  == "Action":
        # 如果是Action阶段，设置新的工具调用ID
        return new_chunk,new_id
    else:
        # 其他阶段不需要新的工具调用ID
        return new_chunk

class ReActCommonTemplate:
    def __init__(self,tool_names:List[str]):
        
        self.tool_names = set(tool_names)

    async def hijack_stream(self,chunks:AsyncIterator[ChatCompletionChunk]):
        self.stream_processor = self.process_stream()
        next(self.stream_processor)
        current_stage = None
        tool_call_index = -1
        tool_name = ""
        current_tool_call_id = None
        is_virtual_tool = False
        should_break = False
        async for ori_chunk in chunks:
            if ori_chunk is None:
                break
            if not isinstance(ori_chunk, ChatCompletionChunk):
                logger.warning(f"chunck illegal： {ori_chunk}")
            if not ori_chunk.choices or ori_chunk.choices[0].delta.content is None:
                logger.debug(f"not compatible: {ori_chunk}")
                yield ori_chunk
                continue
            chunk_content = ori_chunk.choices[0].delta.content
            if chunk_content:
                outputs = send_chunk_to_stream(self.stream_processor, chunk_content)
                
                for output in outputs:
                    # logger.debug(f"处理输出.stage: {output['type']}, chunk: {output['chunk']}")
                    if output['type'] != current_stage:
                        if current_stage =="Action":
                            if tool_name in self.tool_names:
                                is_virtual_tool = True
                            
                            tool_call_index += 1
                            # Action 阶段结束时 创建工具调用chunk
                            chunk, current_tool_call_id = create_tool_call_chunk(ori_chunk, current_stage, tool_call_index=tool_call_index, content=tool_name)
                            tool_name = ""
                            yield chunk
                        elif current_stage in ["Thought","Answer"]:
                            current_tool_call_id = None
                            is_virtual_tool = False
                            tool_name = ""

                        current_stage = output['type']
                    
                    if  output['type'] == 'Action':
                        tool_name += output['chunk']
                        # action 阶段仅对tool_name进行累积
                        continue
                    elif current_stage == "Action Input":
                        # Action Input 阶段,持续生成参数
                        yield create_tool_call_chunk(ori_chunk, current_stage, tool_call_index=tool_call_index,  content= output['chunk'])
                    elif current_stage == "Observation":
                        if is_virtual_tool:
                            yield create_tool_call_chunk(ori_chunk, current_stage, tool_call_id=current_tool_call_id, content=output['chunk'])
                        else:
                            should_break = True
                            break
                    elif current_stage == "Thought":
                        # logger.debug(f"处理结果: {current_stage} - {output['chunk']}")
                        yield create_tool_call_chunk(ori_chunk, current_stage, content=output['chunk'])
                    elif current_stage == "Answer":
                        yield create_tool_call_chunk(ori_chunk, current_stage, content = output['chunk'])
            if should_break:
                break
        self.force_end_stream()
    

    def process_stream(self) -> Iterator[Dict[str, str]]:
        """
        流式处理 ReAct 格式的字符串，实时劫持并分阶段输出
        
        使用yield-based generator来接收流式字符串输入，实时解析并输出
        支持跨chunk的关键词识别，确保准确的阶段切换
        
        Returns:
            Generator: 产生 {'type': str, 'chunk': str} 格式的输出
        """
        current_type = 'Answer'  # 默认从Answer阶段开始
        buffer = ''
        
        # 按长度降序排列关键词，避免短关键词(Action:)被长关键词(Action Input:)抢先匹配
        keywords = sorted(['Action Input:', 'Action Iinut:','Observation:', 'Thought:', 'Action:', 'Final Answer:'], key=len, reverse=True)
        keyword_to_type = {
            'Thought:': 'Thought',
            'Action:': 'Action', 
            'Action Input:': 'Action Input',
            'Action Iinut:': 'Action Input',
            'Observation:': 'Observation',
            'Final Answer:': 'Answer'
        }
        
        chunk = yield  # 等待第一个输入chunk
        
        while True:
            # 将新chunk添加到buffer
            if chunk:
                buffer += chunk

            # 持续处理buffer直到无法再处理为止
            while True:
                # 查找buffer中最早出现的关键词
                min_idx = len(buffer)  # 初始化为buffer长度，表示未找到
                found_keyword = None
                
                for keyword in keywords:
                    idx = buffer.find(keyword)
                    if idx != -1 and idx < min_idx:
                        min_idx = idx
                        found_keyword = keyword

                if found_keyword is not None:
                    # 找到了完整的关键词
                    if min_idx > 0:
                        # 输出关键词前的内容
                        yield {'type': current_type, 'chunk': buffer[:min_idx]}
                    
                    # 移除已输出的内容和关键词，切换到新阶段
                    buffer = buffer[min_idx + len(found_keyword):]
                    current_type = keyword_to_type[found_keyword]
                    # 继续处理剩余的buffer内容
                    continue
                
                # 没有找到完整关键词，检查buffer末尾是否可能是关键词的前缀
                is_potential_keyword = False
                
                # 检查buffer是否以任何关键词的前缀结尾
                for keyword in keywords:
                    for prefix_len in range(1, min(len(keyword), len(buffer) + 1)):
                        if buffer.endswith(keyword[:prefix_len]):
                            is_potential_keyword = True
                            break
                    if is_potential_keyword:
                        break
                
                if is_potential_keyword:
                    # buffer末尾可能是跨chunk的关键词前缀，保留等待更多数据
                    break
                elif buffer:
                    # buffer不是关键词前缀，输出所有内容
                    yield {'type': current_type, 'chunk': buffer}
                    buffer = ''
                else:
                    # buffer为空，退出内层循环等待新chunk
                    break

            # 等待下一个chunk
            chunk = yield None

    def force_end_stream(self):
        """
        强制结束流处理，输出剩余的buffer内容
        """
        results = []
        try:
            # 发送一个不可能是关键词前缀的字符来强制输出
            result = self.stream_processor.send('!')  # 感叹号通常不会是关键词前缀
            while result is not None:
                results.append(result)
                result = self.stream_processor.send('')
        except StopIteration:
            pass
        # 过滤掉强制字符
        filtered_results = []
        for result in results:
            if result['chunk'] == '!':
                continue
            # 如果chunk以!结尾，移除!
            chunk = result['chunk']
            if chunk.endswith('!'):
                chunk = chunk[:-1]
            if chunk:  # 只保留非空的chunk
                filtered_results.append({'type': result['type'], 'chunk': chunk})
        return filtered_results

# Test cases
def collect_outputs(stream, text):
    """收集生成器的所有输出，包括通过发送空字符串来强制输出缓冲内容"""
    results = []
    
    # 发送实际文本
    result = stream.send(text)
    while result is not None:
        results.append(result)
        result = stream.send('')  # 发送空字符串继续处理
    
    # 发送一个非前缀字符来强制输出任何剩余的缓冲内容
    result = stream.send(' ')  # 空格通常不会是关键词前缀
    while result is not None:
        results.append(result)
        result = stream.send('')
        
    return results


def send_chunk_to_stream(stream, chunk):
    """
    向流处理器发送数据块并收集所有输出
    """
    results = []
    try:
        result = stream.send(chunk)
        while result is not None:
            results.append(result)
            result = stream.send('')
    except StopIteration:
        pass
    return results