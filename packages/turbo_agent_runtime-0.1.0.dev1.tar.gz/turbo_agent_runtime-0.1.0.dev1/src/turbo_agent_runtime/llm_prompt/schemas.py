
from __future__ import annotations
from openai.types.chat.chat_completion_chunk import ChoiceDelta
class ToolChoiceDelta(ChoiceDelta):
    tool_call_id: str = None

class ReasoningChoiceDelta(ChoiceDelta):
    reasoning_content: str = None



from dataclasses import dataclass, field
from typing import List, Optional, Union, Literal

# Role constants compatible with qwen_agent.llm.schema
SYSTEM: Literal["system"] = "system"
USER: Literal["user"] = "user"
ASSISTANT: Literal["assistant"] = "assistant"
FUNCTION: Literal["function"] = "function"

# A minimal default system message content; adjust if your project has its own
DEFAULT_SYSTEM_MESSAGE: str = "You are a helpful assistant."


@dataclass
class ContentItem:
    """Minimal content item supporting text and image fields.

    Provides a 'type' property to mirror qwen_agent behavior used by callers.
    """

    text: Optional[str] = None
    image: Optional[str] = None

    @property
    def type(self) -> str:
        if self.text is not None:
            return "text"
        if self.image is not None:
            return "image"
        return "unknown"


@dataclass
class FunctionCall:
    name: str
    arguments: str  # JSON string as used by upstream code


@dataclass
class Message:
    role: Literal["system", "user", "assistant", "function"]
    content: Union[str, List[ContentItem]]
    reasoning_content: Optional[str] = None
    function_call: Optional[FunctionCall] = None
