import json
from typing import cast,List,Optional,Callable,Any,Union
from loguru import logger

from .utils import datetimes_to_iso as normalize_datetimes
from langchain.load.dump import dumps as langchain_dumps

from langchain_core.messages import (
    HumanMessage,
    SystemMessage,
    BaseMessage,
    AIMessage,
    ToolMessage
)

from typing import TypedDict
from enum import Enum
from typing_extensions import NotRequired

class MessageRole(Enum):
    """Message role"""
    ASSISTANT = "assistant"
    SYSTEM = "system"
    USER = "user"

class Message(TypedDict):
    """Message"""
    id: str
    createdAt: str

class TextMessage(Message):
    """Text message"""
    parentMessageId: NotRequired[str]
    role: MessageRole
    content: str

class ActionExecutionMessage(Message):
    """Action execution message"""
    parentMessageId: NotRequired[str]
    name: str
    arguments: dict

class ResultMessage(Message):
    """Result message"""
    actionExecutionId: str
    actionName: str
    result: str

class IntermediateStateConfig(TypedDict):
    """Intermediate state config"""
    state_key: str
    tool: str
    tool_argument: NotRequired[str]

class MetaEvent(TypedDict):
    """Type definition for meta events"""
    name: str
    response: NotRequired[str]

def copilotkit_messages_to_langchain(
        use_function_call: bool = False
    ) -> Callable[[List[Message]], List[BaseMessage]]:
    """
    Convert CopilotKit messages to LangChain messages
    """
    def _copilotkit_messages_to_langchain(messages: List[Message]) -> List[BaseMessage]:
        result = []
        processed_action_executions = set()
        for message in cast(Any, messages):
            if message["type"] == "TextMessage":
                if message["role"] == "user":
                    try:
                        logger.debug("Processing user message: %s", message["content"])
                        result.append(HumanMessage(
                            content=json.loads(message["content"]),
                            id=message["id"]
                        ))
                    except json.JSONDecodeError:
                        # Fallback to string content if JSON decoding fails
                        result.append(HumanMessage(
                            content=message["content"],
                            id=message["id"]
                        ))
                elif message["role"] == "system":
                    result.append(SystemMessage(content=message["content"], id=message["id"]))
                elif message["role"] == "assistant":
                    logger.debug(f"Processing assistant message: {message}")
                    result.append(AIMessage(content=message["content"], id=message["id"],additional_kwargs={
                        "reasoning_content": message.get("reasoningContent", "")
                    }))
            elif message["type"] == "ActionExecutionMessage":
                if use_function_call:
                    result.append(AIMessage(
                        id=message["id"],
                        content="",
                        additional_kwargs={
                            'function_call':{
                                'name': message["name"],
                                'arguments': json.dumps(message["arguments"]),
                            }
                        } 
                    ))
                else:
                    # convert multiple tool calls to a single message
                    message_id = message.get("parentMessageId")
                    if message_id is None:
                        message_id = message["id"]
                    if message_id in processed_action_executions:
                        continue
                    processed_action_executions.add(message_id)
                    all_tool_calls = []
                    # Find all tool calls for this message
                    for msg in messages:
                        #此处对源代码进行了修改，仅ActionExecutionMessage可进入 tool——calls
                        if msg.get("type",None) == "ActionExecutionMessage" and ( msg.get("parentMessageId", None) == message_id or msg["id"] == message_id):
                            all_tool_calls.append(msg)
                    tool_calls = [{
                        "name": t["name"],
                        "args": t["arguments"],
                        "id": t["id"],
                    } for t in all_tool_calls]
                    result.append(
                        AIMessage(
                            id=message_id,
                            content="",
                            tool_calls=tool_calls
                        )
                    )
            elif message["type"] == "ResultMessage":
                result.append(ToolMessage(
                    id=message["id"],
                    content=message["result"],
                    name=message["actionName"],
                    tool_call_id=message["actionExecutionId"]
                ))
        return result
    return _copilotkit_messages_to_langchain


def langchain_messages_to_copilotkit(
        messages: List[BaseMessage]
    ) -> List[Message]:
    """
    Convert LangChain messages to CopilotKit messages
    """
    result = []
    tool_call_names = {}

    for message in messages:
        if isinstance(message, AIMessage):
            for tool_call in message.tool_calls or []:
                tool_call_names[tool_call["id"]] = tool_call["name"]

    for message in messages:
        content = None

        if hasattr(message, "content"):
            content = message.content

            # Check if content is a list and use the first element
            if isinstance(content, list):
                content = json.dumps(content,ensure_ascii=False)

            # Anthropic models return a dict with a "text" key
            if isinstance(content, dict):
                content = json.dumps([content],ensure_ascii=False)

        if isinstance(message, HumanMessage):
            result.append({
                "role": "user",
                "content": content,
                "id": message.id,
            })
        elif isinstance(message, SystemMessage):
            result.append({
                "role": "system",
                "content": content,
                "id": message.id,
            })
        elif isinstance(message, AIMessage):
            # logger.debug(f"AIMessage content: {message.model_dump_json()}")
            reasoning_content = message.additional_kwargs.get("reasoning_content", "")
            if reasoning_content is None:
                reasoning_content = ""
            if message.tool_calls:
                if content or reasoning_content:
                    result.append({
                        "role": "assistant",
                        "content": content,
                        "reasoningContent": reasoning_content,
                        "id": message.id,
                        "parentMessageId": message.id,
                    })
                for tool_call in message.tool_calls:
                    result.append({
                        "id": tool_call["id"],
                        "name": tool_call["name"],
                        "arguments": tool_call["args"],
                        "parentMessageId": message.id,
                    })
                
            else:
                result.append({
                    "role": "assistant",
                    "content": content,
                    "reasoningContent": reasoning_content,
                    "id": message.id,
                    "parentMessageId": message.id,
                })
        elif isinstance(message, ToolMessage):
            result.append({
                "actionExecutionId": message.tool_call_id,
                "actionName": tool_call_names.get(message.tool_call_id, message.name or ""),
                "result": content,
                "id": message.id,
            })
    # Create a dictionary to map message ids to their corresponding messages
    results_dict = {msg["actionExecutionId"]: msg for msg in result if "actionExecutionId" in msg}


    # since we are splitting multiple tool calls into multiple messages,
    # we need to reorder the corresponding result messages to be after the tool call
    reordered_result = []

    for msg in result:

        # add all messages that are not tool call results
        if not "actionExecutionId" in msg:
            reordered_result.append(msg)

        # if the message is a tool call, also add the corresponding result message
        # immediately after the tool call
        if "arguments" in msg:
            msg_id = msg["id"]
            if msg_id in results_dict:
                reordered_result.append(results_dict[msg_id])
            else:
                logger.warning("Tool call result message not found for id: %s", msg_id)

    return reordered_result
