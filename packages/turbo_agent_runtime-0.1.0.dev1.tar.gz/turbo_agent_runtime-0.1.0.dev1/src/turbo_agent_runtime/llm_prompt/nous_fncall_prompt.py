import copy
import json
import os
from typing import List, Literal, Union
import json5
from .basic_fncall_prompt import BaseFnCallPrompt
from .schemas import ASSISTANT, FUNCTION, SYSTEM, USER, ContentItem, FunctionCall, Message


class NousFnCallPrompt(BaseFnCallPrompt):

    def preprocess_fncall_messages(self,
                                   messages: List[Message],
                                   functions: List[dict],
                                   lang: Literal['en', 'zh'],
                                   parallel_function_calls: bool = True,
                                   function_choice: Union[Literal['auto'], str] = 'auto',
                                   **kwargs) -> List[Message]:
        del lang  # ignored
        del parallel_function_calls  # ignored
        if function_choice != 'auto':
            raise NotImplementedError

        ori_messages = messages

        # Change function_call responses to plaintext responses:
        messages = []
        for msg in copy.deepcopy(ori_messages):
            role, content, reasoning_content = msg.role, msg.content, msg.reasoning_content
            if role in (SYSTEM, USER):
                messages.append(msg)
            elif role == ASSISTANT:
                content = (content or [])
                fn_call = msg.function_call
                if fn_call:
                    fc = {'name': fn_call.name, 'arguments': json5.loads(fn_call.arguments)}
                    fc = json.dumps(fc, ensure_ascii=False)
                    fc = f'<tool_call>\n{fc}\n</tool_call>'

                    content.append(ContentItem(text=fc))
                if messages and messages[-1].role == ASSISTANT:
                    if messages[-1].content and messages[-1].content[-1].text and (
                            not messages[-1].content[-1].text.endswith('\n')):
                        messages[-1].content.append(ContentItem(text='\n'))
                    messages[-1].content.extend(content)
                else:
                    # TODO: Assuming there will only be one continuous reasoning_content here
                    messages.append(Message(role=role, content=content, reasoning_content=reasoning_content))
            elif role == FUNCTION:
                assert isinstance(content, list)
                assert len(content) == 1
                assert content[0].text
                fc = f'<tool_response>\n{content[0].text}\n</tool_response>'
                content = [ContentItem(text=fc)]
                if messages[-1].role == USER:
                    messages[-1].content.append(ContentItem(text='\n'))
                    messages[-1].content.extend(content)
                else:
                    messages.append(Message(role=USER, content=content))
            else:
                raise TypeError

        tool_descs = [{'type': 'function', 'function': f} for f in functions]
        tool_names = [function.get('name_for_model', function.get('name', '')) for function in functions]
        tool_descs = '\n'.join([json.dumps(f, ensure_ascii=False) for f in tool_descs])
        tool_system = FN_CALL_TEMPLATE.format(tool_descs=tool_descs)

        if messages and messages[0].role == SYSTEM:
            messages[0].content.append(ContentItem(text='\n\n' + tool_system))
        else:
            messages = [Message(role=SYSTEM, content=[ContentItem(text=tool_system)])] + messages
        return messages

FN_CALL_TEMPLATE = """# Tools

You may call one or more functions to assist with the user query.

You are provided with function signatures within <tools></tools> XML tags:
<tools>
{tool_descs}
</tools>

For each function call, return a json object with function name and arguments within <tool_call></tool_call> XML tags.

CRITICAL: You MUST use complete XML tags - both opening <tool_call> and closing </tool_call> tags are REQUIRED!

EXACT format requirement:
<tool_call>
{{"name": "function_name", "arguments": {{"param1": "value1", "param2": "value2"}}}}
</tool_call>

The content between tags MUST be valid JSON with exactly two fields:
1. "name": the function name (string)
2. "arguments": the function arguments (object)

INCORRECT formats to avoid:
- Missing closing tag: <tool_call>{{"name": "func", "arguments": {{}}}}
- Missing opening tag: {{"name": "func", "arguments": {{}}}}</tool_call>
- Extra braces: <tool_call>{{"name": "func", "arguments": {{}}}} }}</tool_call>
- Missing "name" field: <tool_call>function_name {{"param": "value"}}</tool_call>
- Invalid JSON: <tool_call>function_name param=value</tool_call>

you can call multiple functions in a single response if needed. The exact format could be like below:


<tool_call>
{{"name": "function_name1", "arguments": {{"param1-1": "value1-1", "param1-2": "value1-2"}}}}
</tool_call>
<tool_call>
{{"name": "function_name2", "arguments": {{"param2-1": "value2-1", "param2-2": "value2-2", "param2-3": "value2-3"}}}}
</tool_call>
<tool_call>
{{"name": "function_name3", "arguments": {{"param3-1": "value3-1"}}}}
</tool_call>
<tool_call>
{{"name": "function_name1", "arguments": {{"param4-1": "value4-1", "param4-2": "value4-2"}}}}
</tool_call>

Remember: Always start with <tool_call> before the JSON object and close with </tool_call> tag after the JSON object!

"""

SPECIAL_CODE_MODE = os.getenv('SPECIAL_CODE_MODE', 'false').lower() == 'true'
CODE_TOOL_PATTERN = 'code_interpreter'

# Mainly for removing incomplete special tokens when streaming the output
# This assumes that '<tool_call>\n{"name": "' is the special token for the NousFnCallPrompt
def remove_incomplete_special_tokens(text: str) -> str:
    if text in '<tool_call>\n{"name": "':
        text = ''
    return text


def extract_fn(text: str):
    fn_name, fn_args = '', ''
    fn_name_s = '"name": "'
    fn_name_e = '", "'
    fn_args_s = '"arguments": '
    i = text.find(fn_name_s)
    k = text.find(fn_args_s)
    if i > 0:
        _text = text[i + len(fn_name_s):]
        j = _text.find(fn_name_e)
        if j > -1:
            fn_name = _text[:j]
    if k > 0:
        fn_args = text[k + len(fn_args_s):]

    # if len(fn_args) > 5:
    #     fn_args = fn_args[:-5]
    # else:
    #     fn_args = ''
    # fn_args = fn_args.strip()
     
    return fn_name, fn_args
