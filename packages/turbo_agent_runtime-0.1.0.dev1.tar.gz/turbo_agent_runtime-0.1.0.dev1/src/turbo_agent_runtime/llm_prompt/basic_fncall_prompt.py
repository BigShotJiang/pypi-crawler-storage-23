from __future__ import annotations

from typing import List, Literal, Union

from .schemas import Message


class BaseFnCallPrompt:
    """Local minimal replacement for qwen_agent.llm.fncall_prompts.base_fncall_prompt.BaseFnCallPrompt.

    Implementations are expected to provide:
    - preprocess_fncall_messages(...): List[Message]
    - Optionally, postprocess_fncall_messages(...): List[Message] or pass-through
    """

    def preprocess_fncall_messages(
        self,
        messages: List[Message],
        functions: List[dict],
        lang: Literal["en", "zh"],
        parallel_function_calls: bool = True,
        function_choice: Union[Literal["auto"], str] = "auto",
        **kwargs,
    ) -> List[Message]:
        raise NotImplementedError

    # Optional hook; keep signature flexible for compatibility
    def postprocess_fncall_messages(self, *args, **kwargs):  # noqa: ANN001, D401
        """Optional postprocess hook. Default: no-op passthrough."""
        if args:
            return args[0]
        return []
