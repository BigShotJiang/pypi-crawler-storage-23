"""turbo-agent runtime: orchestration and execution utilities.

Importing this package patches `TurboEntity.run` / `TurboEntity.stream_run` to
dispatch to runtime executors based on `run_type`.
"""

from .utils.patch import patch_turbo_entity_methods  # noqa: E402
# from .executor import llm  # noqa: F401  (register LLM executor)
# from .executor import api  # noqa: F401  (register API executor)

patch_turbo_entity_methods()

__all__ = ["__version__", "patch_turbo_entity_methods"]
__version__ = "0.1.0"
