"""TFS Deploy - Terraform + Serverless Devs deployment orchestrator."""

__version__ = "0.1.0"
