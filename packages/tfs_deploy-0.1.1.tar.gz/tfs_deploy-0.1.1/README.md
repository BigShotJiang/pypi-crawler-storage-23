# TFS Deploy

Terraform + Serverless deployment orchestrator for FaaS services.

## Installation

```bash
pip install tfs-deploy
```

## Usage

### Deploy a service

```bash
# Deploy with default settings (dev stage, us-west-1 region)
tfs deploy

# Deploy to specific stage and region
tfs deploy --stage prod --region cn-beijing

# Skip certain steps
tfs deploy --skip-terraform --skip-tests

# Auto-approve Terraform changes
tfs deploy --auto-approve
```

### Destroy infrastructure

```bash
tfs destroy --stage dev
```

### Initialize a new project

```bash
tfs init
```

## Project Structure

TFS Deploy expects the following structure:

```
my-service/
├── main.tf              # Terraform infrastructure
├── s.yaml               # Serverless configuration
├── .env                 # Environment variables
├── scripts/             # Deployment scripts
├── src/                 # Source code
└── tests/
    ├── unit/            # Unit tests
    └── integration/     # Integration tests
```

## Environment Variables

- `STAGE` - Deployment stage (dev, beta, prod)
- `REGION` - Cloud region
- `PROFILE` - Cloud provider CLI profile
- `TF_VAR_*` - Terraform variables

## How It Works

1. **Terraform**: Applies infrastructure changes and exports outputs to `.env.terraform`
2. **s deploy**: Runs `s deploy` for function deployment
3. **Integration Tests**: Runs pytest on the deployed service

## Example s.yaml

```yaml
edition: 3.0.0
name: my-service
access: default

resources:
  my-function:
    component: fc3
    props:
      region: ${vars.region}
      functionName: my-function-${vars.stage}
      # ...
```

## License

MIT
