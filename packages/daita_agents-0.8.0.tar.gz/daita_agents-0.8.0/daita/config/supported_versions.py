"""
Registry of supported daita-agents versions and their executor functions.

This file defines which framework versions are supported for cloud deployment
and maps them to their corresponding Lambda executor functions.
"""

from typing import Dict, Optional
from datetime import datetime


class VersionInfo:
    """Information about a supported framework version."""

    def __init__(
        self,
        version: str,
        executor_function: str,
        container_image: str,
        status: str = "supported",
        deprecation_date: Optional[datetime] = None,
        min_cli_version: Optional[str] = None
    ):
        self.version = version
        self.executor_function = executor_function
        self.container_image = container_image
        self.status = status
        self.deprecation_date = deprecation_date
        self.min_cli_version = min_cli_version

    def is_deprecated(self) -> bool:
        """Check if this version is deprecated."""
        return self.status == "deprecated"

    def is_supported(self) -> bool:
        """Check if this version is actively supported."""
        return self.status in ["supported", "active"]


# Registry of supported versions
SUPPORTED_VERSIONS: Dict[str, VersionInfo] = {
    "0.5.0": VersionInfo(
        version="0.5.0",
        executor_function="daita-executor-v050",
        container_image="746229248679.dkr.ecr.us-east-1.amazonaws.com/daita-executor:0.5.0",
        status="supported"
    ),
    "0.6.0": VersionInfo(
        version="0.6.0",
        executor_function="daita-executor-v060",
        container_image="746229248679.dkr.ecr.us-east-1.amazonaws.com/daita-executor:0.6.0",
        status="supported"
    ),
    "0.6.1": VersionInfo(
        version="0.6.1",
        executor_function="daita-executor-v061",
        container_image="746229248679.dkr.ecr.us-east-1.amazonaws.com/daita-executor:0.6.1",
        status="supported"
    ),
    "0.6.2": VersionInfo(
        version="0.6.2",
        executor_function="daita-executor-v062",
        container_image="746229248679.dkr.ecr.us-east-1.amazonaws.com/daita-executor:0.6.2",
        status="supported"
    ),
    "0.7.0": VersionInfo(
        version="0.7.0",
        executor_function="daita-executor-v070-test",
        container_image="746229248679.dkr.ecr.us-east-1.amazonaws.com/daita-executor:0.7.0-test",
        status="active"
    ),
    "0.7.0-test": VersionInfo(
        version="0.7.0-test",
        executor_function="daita-executor-v070-test",
        container_image="746229248679.dkr.ecr.us-east-1.amazonaws.com/daita-executor:0.7.0-test",
        status="supported"
    ),
    "0.7.1-test": VersionInfo(
        version="0.7.1-test",
        executor_function="daita-executor-v071-test",
        container_image="746229248679.dkr.ecr.us-east-1.amazonaws.com/daita-executor:0.7.1-test",
        status="supported"
    ),
    "0.7.1": VersionInfo(
        version="0.7.1",
        executor_function="daita-executor-v071",
        container_image="746229248679.dkr.ecr.us-east-1.amazonaws.com/daita-executor:0.7.1",
        status="active"
    ),
}

# Default version for deployments without explicit version
DEFAULT_VERSION = "0.7.1"


def get_version_info(version: str) -> Optional[VersionInfo]:
    """Get information about a specific version."""
    return SUPPORTED_VERSIONS.get(version)


def get_executor_function(version: str) -> str:
    """Get the Lambda function name for a version."""
    info = get_version_info(version)
    if info and info.is_supported():
        return info.executor_function
    return SUPPORTED_VERSIONS[DEFAULT_VERSION].executor_function


def list_supported_versions() -> list[str]:
    """List all supported framework versions."""
    return [
        version for version, info in SUPPORTED_VERSIONS.items()
        if info.is_supported()
    ]


def validate_version(version: str) -> tuple[bool, str]:
    """
    Validate if a version is supported.

    Returns:
        (is_valid, message)
    """
    if version not in SUPPORTED_VERSIONS:
        return False, f"Version {version} is not supported. Supported versions: {list_supported_versions()}"

    info = SUPPORTED_VERSIONS[version]

    if info.is_deprecated():
        return False, f"Version {version} is deprecated and no longer supported"

    return True, "Version is supported"
