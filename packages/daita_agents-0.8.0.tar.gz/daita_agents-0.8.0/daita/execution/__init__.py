"""
daita.execution — re-exports from the standalone daita-client package.

Install separately if using outside of daita-agents:
    pip install daita-client
"""

try:
    from daita_client import DaitaClient
    from daita_client import ExecutionResult, ScheduledTask, WebhookTrigger
    from daita_client import (
        ExecutionError,
        AuthenticationError,
        NotFoundError,
        ValidationError,
        RateLimitError,
        ExecutionTimeoutError,
        ServerError,
    )
except ImportError as e:
    raise ImportError(
        "daita-client is required for agent execution. "
        "Install it with: pip install daita-client"
    ) from e

__all__ = [
    "DaitaClient",
    "ExecutionResult",
    "ScheduledTask",
    "WebhookTrigger",
    "ExecutionError",
    "AuthenticationError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    "ExecutionTimeoutError",
    "ServerError",
]
