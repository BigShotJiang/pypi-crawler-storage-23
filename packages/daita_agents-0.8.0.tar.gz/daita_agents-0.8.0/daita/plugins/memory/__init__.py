"""
Memory plugin for DAITA agents.

Provides persistent, semantic memory with automatic local/cloud detection.
"""

from .memory_plugin import MemoryPlugin
from .local_backend import LocalMemoryBackend
from .cloud_curator import CurationResult

__all__ = ['MemoryPlugin', 'LocalMemoryBackend', 'CurationResult']
