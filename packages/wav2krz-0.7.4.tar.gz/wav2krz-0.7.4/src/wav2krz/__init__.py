"""
wav2krz - WAV to Kurzweil .krz file converter

A Python tool to convert WAV files to Kurzweil K2000/K2500/K2600 .krz format.
"""

__version__ = "1.0.0"
