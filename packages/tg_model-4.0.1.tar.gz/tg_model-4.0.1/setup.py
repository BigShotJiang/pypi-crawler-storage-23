# -*- coding: utf-8 -*-
# Copyright (C) 2023-2026 TUD | ZIH
# ralf.klammer@tu-dresden.de

from setuptools import find_packages, setup

with open("README.MD", "r") as fh:
    long_description = fh.read()

setup(
    name="tg_model",
    version="4.0.1",
    description="",
    author="Ralf Klammer",
    author_email="ralf.klammer@tu-dresden.de",
    packages=find_packages(),
    long_description=long_description,
    long_description_content_type="text/markdown",
    install_requires=[
        "click",
        "iso639-lang",
        "jinja2",
        "lxml",
        "requests",
        "pyaml",
        "tgadmin",
    ],
    extras_require={"build": ["build", "twine"]},
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "tg_configs = tgmodel.cli:tg_configs",  # Backwards compatibility
            "tg_model = tgmodel.cli:tg_model",  # Backwards compatibility
            "tgm_cli = tgmodel.cli:tg_model",
        ]
    },
)
