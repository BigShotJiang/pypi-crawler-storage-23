"""Terminal animation helpers for AgentRun."""

from __future__ import annotations

import os
import sys
import time

from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.spinner import Spinner
from rich.text import Text


def animations_enabled() -> bool:
    """Return whether animations should run."""
    env = os.getenv("AGENTRUN_ANIMATIONS", "true").strip().lower()
    if env in {"0", "false", "off", "no"}:
        return False
    return sys.stdout.isatty()


def _speed_factor() -> float:
    raw = os.getenv("AGENTRUN_ANIMATION_SPEED", "1.0").strip()
    try:
        val = float(raw)
    except ValueError:
        return 1.0
    return min(3.0, max(0.2, val))


def _pause(seconds: float):
    if not animations_enabled():
        return
    time.sleep(seconds * _speed_factor())


def _safe_spinner(name: str, text: str, style_name: str) -> Spinner:
    try:
        return Spinner(name, text=Text(text, style=style_name))
    except Exception:
        return Spinner("dots", text=Text(text, style=style_name))


def pulse(
    console: Console,
    text: str,
    style_name: str,
    spinner_name: str = "dots12",
    duration: float = 0.22,
):
    """Show a short transient spinner pulse."""
    if not animations_enabled():
        return
    with Live(
        _safe_spinner(spinner_name, text, style_name),
        console=console,
        refresh_per_second=24,
        transient=True,
    ):
        _pause(duration)


def animate_banner(console: Console, banner: str, style_name: str):
    """Reveal the ASCII banner line-by-line."""
    if not animations_enabled():
        console.print(banner, style=style_name)
        return
    lines = banner.strip("\n").splitlines()
    rendered: list[str] = []
    with Live("", console=console, refresh_per_second=40, transient=False) as live:
        for line in lines:
            rendered.append(f"[{style_name}]{line}[/]")
            live.update("\n".join(rendered))
            _pause(0.045)
    _pause(0.08)


def animate_panel(
    console: Console,
    panel: Panel,
    intro_text: str,
    intro_style: str,
    spinner_name: str = "dots8",
    duration: float = 0.18,
):
    """Pulse briefly, then print the panel."""
    pulse(
        console=console,
        text=intro_text,
        style_name=intro_style,
        spinner_name=spinner_name,
        duration=duration,
    )
    console.print(panel)


def type_line(console: Console, text: str, style_name: str, char_delay: float = 0.004):
    """Type a single line for subtle terminal motion."""
    if not animations_enabled() or len(text) > 180:
        console.print(text, style=style_name)
        return
    rendered = Text("", style=style_name)
    with Live(rendered, console=console, refresh_per_second=80, transient=False) as live:
        for ch in text:
            rendered.append(ch)
            live.update(rendered)
            _pause(char_delay)


def thinking_spinner_name(iteration: int, had_error: bool = False) -> str:
    """Return a richer spinner sequence for thinking phases."""
    if had_error:
        sequence = ("dots8", "line", "dots12", "line2")
    else:
        sequence = ("dots12", "dots8", "line", "dots10", "dots2")
    return sequence[iteration % len(sequence)]

