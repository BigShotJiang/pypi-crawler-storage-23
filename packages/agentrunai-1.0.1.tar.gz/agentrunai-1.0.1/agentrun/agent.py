"""AI Agent that processes user requests using OpenRouter with tool calling."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

from openai import OpenAI
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.spinner import Spinner
from rich.text import Text

from .animations import animate_panel, pulse, thinking_spinner_name, type_line
from .config import MEMORY_FILE, load_config
from .icons import ICONS, TOOL_DISPLAY, TOOL_DISPLAY_ALIASES
from .retrieval import RepoIndex
from .theme import style
from .tools import TOOL_DEFINITIONS, execute_tool

console = Console()

SYSTEM_PROMPT = """You are AgentRun, a powerful AI coding assistant running inside the user's terminal. You have direct access to their filesystem and can execute commands.

## Your Capabilities
- Read, create, edit, and delete files
- Replace specific code blocks in files
- Insert code at specific line numbers
- Run shell commands (build, test, install packages, git, etc.)
- Search across files and list directory structures

## Guidelines
1. Always read files before editing to confirm current state.
2. Prefer smallest diffs: use replace_in_file / insert_at_line / delete_lines before write_file.
3. Use write_file for new files or full rewrites only.
4. Group independent reads/searches/list actions together when possible.
5. Explain your intent briefly before actions and summarize outcome after changes.
6. Avoid destructive commands and risky operations.
7. If a tool fails, diagnose from the error and retry with a narrower fix.
8. When requests are clear, proceed without asking unnecessary permission.

## Current Working Directory
{cwd}

## Operating System
{os_info}

Be concise but thorough. Act like an expert developer pair-programming with the user.
"""


class Agent:
    def __init__(self):
        self.config = load_config()

        # OpenRouter uses the OpenAI SDK — base_url points to OpenRouter.
        self.client = OpenAI(
            api_key=self.config["api_key"],
            base_url=self.config["base_url"],
            default_headers={
                "HTTP-Referer": self.config.get("site_url", "https://github.com/agentrun"),
                "X-Title": self.config.get("site_name", "AgentRun CLI"),
            },
        )

        self.project_root = str(Path(os.getcwd()).resolve())
        self.repo_index = RepoIndex(self.project_root)
        self.conversation_history: list[dict[str, Any]] = []
        self.history_digest = ""
        self.turn_tokens_used = 0
        self._last_tool_error = False
        self._last_tool_names: list[str] = []
        self._file_content_refs: dict[str, str] = {}
        self._project_memory = self._load_project_memory()

        self._init_system_prompt()

    def _init_system_prompt(self):
        """Initialize system prompt with current context."""
        os_info = f"{platform.system()} {platform.release()}"
        system_msg = SYSTEM_PROMPT.format(cwd=os.getcwd(), os_info=os_info)
        self.conversation_history = [{"role": "system", "content": system_msg}]

    def _print_action(
        self,
        action_name: str,
        path: str = "",
        summary: str = "",
        icon_key: str = "action",
    ):
        """Show one action line with a compact icon and label."""
        icon = ICONS.get(icon_key, ICONS["action"])
        if path:
            type_line(
                console,
                f"{icon} {action_name} ({path})",
                style("accent", "cyan"),
                char_delay=0.0018,
            )
        else:
            type_line(
                console,
                f"{icon} {action_name}",
                style("accent", "cyan"),
                char_delay=0.0018,
            )
        if summary:
            type_line(
                console,
                f"  {summary}",
                style("muted", "dim"),
                char_delay=0.0012,
            )

    def _is_transient_api_error(self, error_text: str) -> bool:
        lower = error_text.lower()
        transient_markers = (
            "429",
            "rate limit",
            "timeout",
            "timed out",
            "connection reset",
            "temporarily unavailable",
            "503",
            "502",
            "504",
        )
        return any(marker in lower for marker in transient_markers)

    def _format_api_error(self, error_text: str) -> str:
        lower = error_text.lower()
        if "context length" in lower or "maximum context" in lower:
            return f"CONTEXT_LIMIT::{error_text}"
        if "401" in error_text:
            return (
                "Authentication failed. Your OpenRouter API key is invalid.\n"
                "   Get a valid key at: https://openrouter.ai/keys\n"
                "   Then run: agentrun (it will prompt for a new key)\n"
                "   Or set: export OPENROUTER_API_KEY='sk-or-...'"
            )
        if "402" in error_text:
            return (
                "Insufficient credits on OpenRouter.\n"
                "   Add credits at: https://openrouter.ai/credits"
            )
        if "429" in error_text:
            return "Rate limited by OpenRouter. Wait a moment and try again."
        if "model" in lower and ("not found" in lower or "404" in error_text):
            return (
                f"Model '{self.config['model']}' not found on OpenRouter.\n"
                "   Browse available models: https://openrouter.ai/models\n"
                "   Change model with: /model <model_name>"
            )
        return f"API Error: {error_text}"

    def _make_api_call(self, messages: list[dict[str, Any]], model: str):
        """Make API call with targeted retries on transient failures."""
        attempts = 3
        for attempt in range(attempts):
            try:
                response = self.client.chat.completions.create(
                    model=model,
                    messages=messages,
                    tools=TOOL_DEFINITIONS,
                    tool_choice="auto",
                    parallel_tool_calls=True,
                    max_tokens=self.config["max_tokens"],
                    temperature=self.config["temperature"],
                )
                return response, None
            except Exception as exc:
                error_text = str(exc)
                if self._is_transient_api_error(error_text) and attempt < attempts - 1:
                    wait_s = 1.2 * (2 ** attempt)
                    console.print(
                        f"{ICONS['warning']} Temporary API issue, retrying in {wait_s:.1f}s...",
                        style=style("muted", "dim"),
                    )
                    time.sleep(wait_s)
                    continue
                return None, self._format_api_error(error_text)
        return None, "API Error: retry loop exhausted"

    def _extract_usage_tokens(self, response: Any) -> int:
        usage = getattr(response, "usage", None)
        if usage is None:
            return 0
        total = getattr(usage, "total_tokens", None)
        if isinstance(total, int):
            return total
        return 0

    def _estimate_tokens(self, text: str) -> int:
        # Rough estimate; used for context compaction heuristics.
        return max(1, len(text) // 4)

    def _estimate_messages_tokens(self, messages: list[dict[str, Any]]) -> int:
        total = 0
        for msg in messages:
            total += self._estimate_tokens(msg.get("content", "")) + 6
        return total

    def _truncate_text(self, text: str, max_chars: int, max_lines: int | None = None) -> str:
        lines = text.splitlines()
        if max_lines is not None and len(lines) > max_lines:
            head = lines[: max_lines // 2]
            tail = lines[-max(1, max_lines // 3):]
            text = "\n".join(head + [f"... <TRUNCATED {len(lines) - len(head) - len(tail)} lines> ..."] + tail)
        if len(text) > max_chars:
            head_chars = max_chars // 2
            tail_chars = max_chars // 3
            omitted = len(text) - head_chars - tail_chars
            text = f"{text[:head_chars]}\n... <TRUNCATED {omitted} chars> ...\n{text[-tail_chars:]}"
        return text

    def _summarize_messages(self, messages: list[dict[str, Any]]) -> str:
        lines: list[str] = []
        for msg in messages:
            role = msg.get("role", "")
            content = msg.get("content", "")
            if role == "system" and isinstance(content, str) and content.startswith("Conversation summary"):
                continue
            if role in {"user", "assistant"}:
                snippet = self._truncate_text(str(content).strip().replace("\n", " "), 220)
                if snippet:
                    lines.append(f"{role}: {snippet}")
                continue
            if role == "tool":
                try:
                    data = json.loads(content)
                except Exception:
                    data = {}
                if isinstance(data, dict):
                    if data.get("success") is False:
                        err = str(data.get("error", "tool error"))[:180]
                        lines.append(f"tool error: {err}")
                    else:
                        summary = []
                        if data.get("path"):
                            summary.append(f"path={data['path']}")
                        if data.get("action"):
                            summary.append(f"action={data['action']}")
                        if data.get("replacements") is not None:
                            summary.append(f"replacements={data['replacements']}")
                        if data.get("exit_code") is not None:
                            summary.append(f"exit={data['exit_code']}")
                        if data.get("total") is not None:
                            summary.append(f"total={data['total']}")
                        if summary:
                            lines.append("tool: " + ", ".join(summary))
                continue

        summary = "\n".join(lines)
        return self._truncate_text(summary, 5000, max_lines=40)

    def _compact_history_if_needed(self, force: bool = False):
        """Keep a rolling digest and only retain the active message window."""
        max_history = int(self.config.get("max_history_messages", 18))
        budget = int(self.config.get("context_budget_tokens", 256000))
        estimated = self._estimate_messages_tokens(self.conversation_history)
        if not force and len(self.conversation_history) <= max_history and estimated < int(budget * 0.85):
            return

        if len(self.conversation_history) <= 2:
            return

        keep_tail = min(max(8, max_history - 3), max(1, len(self.conversation_history) - 1))
        head = self.conversation_history[0]
        tail = self.conversation_history[-keep_tail:]
        split_at = len(self.conversation_history) - keep_tail
        older = self.conversation_history[1:split_at]
        digest_piece = self._summarize_messages(older)
        if digest_piece:
            if self.history_digest:
                self.history_digest = f"{self.history_digest}\n{digest_piece}"
            else:
                self.history_digest = digest_piece
            self.history_digest = self._truncate_text(self.history_digest, 7000, max_lines=80)

        compacted = [head]
        if self.history_digest:
            compacted.append({
                "role": "system",
                "content": "Conversation summary (compressed):\n" + self.history_digest,
            })
        compacted.extend(tail)
        self.conversation_history = compacted

    def _shrink_tool_messages(self):
        """Emergency shrinker for context-limit retries."""
        for msg in self.conversation_history:
            if msg.get("role") != "tool":
                continue
            content = msg.get("content", "")
            if not isinstance(content, str):
                continue
            if len(content) > 1800:
                msg["content"] = self._truncate_text(content, 1600, max_lines=40)

    def _compress_tool_result(self, tool_name: str, args: dict[str, Any], result: str) -> str:
        """Reduce large payloads while preserving actionable context."""
        try:
            data = json.loads(result)
        except Exception:
            return self._truncate_text(result, int(self.config.get("tool_output_char_limit", 12000)))

        if not isinstance(data, dict):
            return result

        char_limit = int(self.config.get("tool_output_char_limit", 12000))
        line_limit = int(self.config.get("tool_output_line_limit", 200))
        canonical = TOOL_DISPLAY_ALIASES.get(tool_name, tool_name)

        if canonical == "read_file" and data.get("success"):
            content = data.get("content")
            if isinstance(content, str):
                digest = hashlib.sha1(content.encode("utf-8")).hexdigest()[:10]
                path = data.get("path") or args.get("filepath") or ""
                ref = f"{path}:{digest}"
                if path and self._file_content_refs.get(path) == ref:
                    data["content"] = f"[UNCHANGED_FROM_PREVIOUS_READ:{ref}]"
                    data["content_elided"] = True
                else:
                    if path:
                        self._file_content_refs[path] = ref
                    data["content_hash"] = digest
                    data["content"] = self._truncate_text(content, char_limit, max_lines=line_limit)
                    if len(content) > len(data["content"]):
                        data["content_truncated"] = True

        if canonical == "run_command":
            for field in ("stdout", "stderr"):
                text = data.get(field, "")
                if isinstance(text, str):
                    clipped = self._truncate_text(text, char_limit // 2, max_lines=max(40, line_limit // 2))
                    if clipped != text:
                        data[field] = clipped
                        data[f"{field}_truncated"] = True

        if canonical == "list_files":
            files = data.get("files")
            if isinstance(files, list) and len(files) > 120:
                data["files"] = files[:120]
                data["omitted_files"] = len(files) - 120

        if canonical == "search_in_files":
            results = data.get("results")
            if isinstance(results, list) and len(results) > 40:
                data["results"] = results[:40]
                data["omitted_results"] = len(results) - 40

        for key, value in list(data.items()):
            if isinstance(value, str) and len(value) > char_limit:
                data[key] = self._truncate_text(value, char_limit, max_lines=line_limit)
                data[f"{key}_truncated"] = True

        return json.dumps(data, indent=2)

    def _result_one_line(self, result: str) -> str:
        try:
            data = json.loads(result)
        except Exception:
            line = result.strip().splitlines()[0] if result.strip() else "tool completed"
            return self._truncate_text(line, 140)
        if not isinstance(data, dict):
            return "tool completed"
        if data.get("success") is False:
            return f"Error: {str(data.get('error', 'tool error'))[:120]}"
        if data.get("path") and data.get("action"):
            return f"{data['action']} {data['path']}"
        if data.get("path") and data.get("lines") is not None:
            return f"Read {data['lines']} lines from {data['path']}"
        if data.get("replacements") is not None:
            return f"Replaced {data['replacements']} occurrence(s)"
        if data.get("deleted_lines") is not None:
            return f"Deleted {data['deleted_lines']} line(s)"
        if data.get("line") is not None and data.get("path"):
            return f"Inserted at line {data['line']} in {data['path']}"
        if data.get("exit_code") is not None:
            return f"Exit code {data['exit_code']}"
        if data.get("total") is not None:
            return f"Total matches/files: {data['total']}"
        return "Tool completed"

    def _select_model(self, user_message: str, iteration: int) -> str:
        if not self.config.get("routing_enabled", True):
            return self.config.get("quality_model") or self.config["model"]

        fast_model = self.config.get("fast_model") or self.config["model"]
        quality_model = self.config.get("quality_model") or self.config["model"]
        if fast_model == quality_model:
            return quality_model

        text = user_message.lower()
        complex_markers = (
            "architecture",
            "refactor",
            "optimize",
            "security",
            "migrate",
            "design",
            "complex",
        )
        edit_tools = {"write_file", "replace_in_file", "insert_at_line", "delete_lines"}

        if any(marker in text for marker in complex_markers):
            return quality_model
        if self._last_tool_error:
            return quality_model
        if any(name in edit_tools for name in self._last_tool_names):
            return quality_model
        if iteration == 0:
            return fast_model
        if iteration == 1:
            return fast_model
        return quality_model

    def _load_project_memory(self) -> dict[str, Any]:
        """Load persistent project memory keyed by absolute project root."""
        if not MEMORY_FILE.exists():
            return {"notes": [], "recent_files": [], "successful_commands": []}
        try:
            payload = json.loads(MEMORY_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {"notes": [], "recent_files": [], "successful_commands": []}
        project_data = payload.get(self.project_root, {})
        return {
            "notes": list(project_data.get("notes", []))[:20],
            "recent_files": list(project_data.get("recent_files", []))[:30],
            "successful_commands": list(project_data.get("successful_commands", []))[:20],
        }

    def _save_project_memory(self):
        MEMORY_FILE.parent.mkdir(parents=True, exist_ok=True)
        payload = {}
        if MEMORY_FILE.exists():
            try:
                payload = json.loads(MEMORY_FILE.read_text(encoding="utf-8"))
            except Exception:
                payload = {}
        payload[self.project_root] = self._project_memory
        try:
            MEMORY_FILE.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        except OSError:
            pass

    def _remember_user_message(self, user_message: str):
        text = " ".join(user_message.strip().split())
        if not text:
            return
        lower = text.lower()
        preference_markers = ("prefer ", "always ", "never ", "don't ", "do not ", "use ")
        if any(marker in lower for marker in preference_markers):
            notes = self._project_memory.get("notes", [])
            if text not in notes:
                notes.append(text[:240])
                self._project_memory["notes"] = notes[-20:]
                self._save_project_memory()

    def _remember_tool_result(self, tool_name: str, tool_args: dict[str, Any], result: str):
        try:
            data = json.loads(result)
        except Exception:
            return
        if not isinstance(data, dict):
            return

        path = data.get("path") or tool_args.get("filepath") or tool_args.get("directory")
        if path:
            recent = self._project_memory.get("recent_files", [])
            path = str(path)
            if path in recent:
                recent.remove(path)
            recent.append(path)
            self._project_memory["recent_files"] = recent[-30:]

        canonical = TOOL_DISPLAY_ALIASES.get(tool_name, tool_name)
        if canonical == "run_command" and data.get("success"):
            cmd = tool_args.get("command")
            if isinstance(cmd, str) and cmd.strip():
                cmds = self._project_memory.get("successful_commands", [])
                command = cmd.strip()
                if command in cmds:
                    cmds.remove(command)
                cmds.append(command[:200])
                self._project_memory["successful_commands"] = cmds[-20:]

        self._save_project_memory()

    def _build_memory_context(self) -> str:
        notes = self._project_memory.get("notes", [])[:8]
        files = self._project_memory.get("recent_files", [])[-8:]
        cmds = self._project_memory.get("successful_commands", [])[-6:]

        chunks = []
        if notes:
            chunks.append("Preferences:\n- " + "\n- ".join(notes))
        if files:
            chunks.append("Recent files:\n- " + "\n- ".join(files))
        if cmds:
            chunks.append("Recent successful commands:\n- " + "\n- ".join(cmds))
        if not chunks:
            return ""
        joined = "\n\n".join(chunks)
        return self._truncate_text(joined, 1800, max_lines=36)

    def _build_retrieval_context(self, user_message: str) -> str:
        if not self.config.get("retrieval_enabled", True):
            return ""
        max_files = int(self.config.get("retrieval_max_files", 4))
        results = self.repo_index.query(user_message, max_files=max_files)
        if not results:
            return ""

        lines = ["Potentially relevant repo context (auto-selected):"]
        for item in results:
            matches = ", ".join(item.get("matches", [])[:6]) or "path/symbol match"
            lines.append(f"- {item['path']} [score {item['score']}], matches: {matches}")
            snippet = item.get("snippet", "")
            if snippet:
                lines.append(snippet)
        return self._truncate_text("\n".join(lines), 3000, max_lines=60)

    def _prepare_request_messages(self, user_message: str, iteration: int) -> list[dict[str, Any]]:
        self._compact_history_if_needed()
        messages = list(self.conversation_history)

        memory_context = self._build_memory_context()
        if memory_context:
            messages.append({
                "role": "system",
                "content": f"Project memory (persistent):\n{memory_context}",
            })

        if iteration == 0:
            retrieval_context = self._build_retrieval_context(user_message)
            if retrieval_context:
                messages.append({
                    "role": "system",
                    "content": retrieval_context,
                })

        context_budget = int(self.config.get("context_budget_tokens", 256000))
        estimated = self._estimate_messages_tokens(messages)
        if estimated > context_budget:
            # First drop retrieval by rebuilding without it.
            messages = list(self.conversation_history)
            if memory_context:
                messages.append({
                    "role": "system",
                    "content": f"Project memory (persistent):\n{memory_context}",
                })
            estimated = self._estimate_messages_tokens(messages)
            if estimated > context_budget:
                self._compact_history_if_needed(force=True)
                messages = list(self.conversation_history)
                if memory_context:
                    messages.append({
                        "role": "system",
                        "content": f"Project memory (persistent):\n{memory_context}",
                    })

        return messages

    def _execute_tool_batch(self, calls: list[dict[str, Any]]) -> list[str]:
        """Execute a batch of tool calls, parallelizing safe reads/searches."""
        safe_parallel = {"read_file", "list_files", "search_in_files"}
        canonical = [TOOL_DISPLAY_ALIASES.get(c["func_name"], c["func_name"]) for c in calls]
        can_parallel = len(calls) > 1 and all(name in safe_parallel for name in canonical)

        if not can_parallel:
            results = []
            for call in calls:
                results.append(execute_tool(call["func_name"], call["func_args"], self.config))
            return results

        pulse(
            console,
            text=f"Queueing {len(calls)} parallel reads...",
            style_name=style("muted", "dim"),
            spinner_name="dots8",
            duration=0.1,
        )
        type_line(
            console,
            f"  Batching {len(calls)} read/search actions in parallel",
            style("muted", "dim"),
            char_delay=0.0012,
        )
        results = ["" for _ in calls]
        max_workers = min(4, len(calls))
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            future_map = {
                pool.submit(execute_tool, c["func_name"], c["func_args"], self.config): idx
                for idx, c in enumerate(calls)
            }
            for future, idx in future_map.items():
                results[idx] = future.result()
        return results

    def chat(self, user_message: str) -> str:
        """Process a user message and return the assistant's response."""
        self.conversation_history.append({"role": "user", "content": user_message})
        self._remember_user_message(user_message)
        self.turn_tokens_used = 0
        self._last_tool_error = False
        self._last_tool_names = []

        context_limit_retries = 0
        iteration = 0

        while True:
            model = self._select_model(user_message, iteration)
            request_messages = self._prepare_request_messages(user_message, iteration)
            phase_by_step = ("Thinking", "Planning", "Reasoning", "Applying", "Validating")
            phase = phase_by_step[iteration % len(phase_by_step)]
            if self._last_tool_error:
                phase = "Re-evaluating"
            spinner_name = thinking_spinner_name(iteration, had_error=self._last_tool_error)

            with Live(
                Spinner(spinner_name, text=Text(f"{phase} ({model})...", style=style("accent", "cyan"))),
                console=console,
                refresh_per_second=18,
                transient=True,
            ):
                response, error = self._make_api_call(request_messages, model=model)

            if error:
                if isinstance(error, str) and error.startswith("CONTEXT_LIMIT::") and context_limit_retries < 2:
                    context_limit_retries += 1
                    self._compact_history_if_needed(force=True)
                    self._shrink_tool_messages()
                    iteration += 1
                    continue
                console.print(f"\n{ICONS['error']} {error}", style=style("error", "red"))
                if self.conversation_history and self.conversation_history[-1]["role"] == "user":
                    self.conversation_history.pop()
                return error

            self.turn_tokens_used += self._extract_usage_tokens(response)

            message = response.choices[0].message

            msg_dict: dict[str, Any] = {"role": "assistant", "content": message.content or ""}
            if message.tool_calls:
                msg_dict["tool_calls"] = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.function.name,
                            "arguments": tc.function.arguments,
                        },
                    }
                    for tc in message.tool_calls
                ]
            self.conversation_history.append(msg_dict)

            if not message.tool_calls:
                text = message.content or ""
                if text:
                    console.print()
                    response_panel = Panel(
                        Markdown(text),
                        title=f"{ICONS['brand']} AgentRun",
                        border_style=style("panel", "cyan"),
                        padding=(1, 2),
                    )
                    animate_panel(
                        console,
                        response_panel,
                        intro_text="Finalizing response...",
                        intro_style=style("muted", "dim"),
                        spinner_name="dots10",
                        duration=0.12,
                    )
                self._compact_history_if_needed()
                return text

            console.print()

            parsed_calls: list[dict[str, Any]] = []
            for tc in message.tool_calls:
                func_name = tc.function.name
                try:
                    func_args = json.loads(tc.function.arguments)
                except json.JSONDecodeError:
                    func_args = {}
                canonical = TOOL_DISPLAY_ALIASES.get(func_name, func_name)
                display_name, icon_key = TOOL_DISPLAY.get(
                    canonical,
                    (func_name.replace("_", " ").title(), "action"),
                )
                path = (
                    func_args.get("path")
                    or func_args.get("file_path")
                    or func_args.get("filepath")
                    or func_args.get("directory")
                    or func_args.get("file")
                    or ""
                )
                self._print_action(display_name, path, icon_key=icon_key)
                parsed_calls.append({
                    "tool_call_id": tc.id,
                    "func_name": func_name,
                    "func_args": func_args,
                })

            pulse(
                console,
                text="Executing tool calls...",
                style_name=style("muted", "dim"),
                spinner_name="dots12",
                duration=0.12,
            )
            self._last_tool_names = [c["func_name"] for c in parsed_calls]
            raw_results = self._execute_tool_batch(parsed_calls)

            for call, raw_result in zip(parsed_calls, raw_results):
                compressed = self._compress_tool_result(call["func_name"], call["func_args"], raw_result)
                line = self._result_one_line(compressed)
                console.print(f"  [{style('muted', 'dim')}]{line}[/]")

                try:
                    result_obj = json.loads(compressed)
                    self._last_tool_error = bool(result_obj.get("success") is False) or self._last_tool_error
                except Exception:
                    pass

                self.conversation_history.append({
                    "role": "tool",
                    "tool_call_id": call["tool_call_id"],
                    "content": compressed,
                })
                self._remember_tool_result(call["func_name"], call["func_args"], compressed)

            self._compact_history_if_needed()
            iteration += 1

    def reset(self):
        """Reset conversation history."""
        self.history_digest = ""
        self._init_system_prompt()
        pulse(
            console,
            text="Resetting conversation...",
            style_name=style("muted", "dim"),
            spinner_name="line2",
            duration=0.08,
        )
        console.print(f"{ICONS['reset']} Conversation reset.", style=style("accent", "cyan"))
