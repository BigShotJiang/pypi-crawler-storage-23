"""Theme tokens for CLI styling.

Set `AGENTRUN_THEME` to `minimal` or `vivid`.
"""

from __future__ import annotations

import os

THEMES = {
    "minimal": {
        "banner": "bold cyan",
        "accent": "cyan",
        "panel": "cyan",
        "muted": "dim",
        "success": "green",
        "error": "red",
        "warning": "yellow",
        "prompt": "bold cyan",
        "run": "blue",
        "insert": "magenta",
        "delete": "red",
        "heading_markup": "bold cyan",
        "key_markup": "cyan",
        "prompt_pt": "bold ansicyan",
    },
    "vivid": {
        "banner": "bold bright_cyan",
        "accent": "bold bright_cyan",
        "panel": "bright_cyan",
        "muted": "bright_black",
        "success": "bold bright_green",
        "error": "bold bright_red",
        "warning": "bold bright_yellow",
        "prompt": "bold bright_cyan",
        "run": "bold bright_blue",
        "insert": "bold bright_magenta",
        "delete": "bold bright_red",
        "heading_markup": "bold bright_cyan",
        "key_markup": "bright_cyan",
        "prompt_pt": "bold ansibrightcyan",
    },
}

THEME_NAME = os.getenv("AGENTRUN_THEME", "minimal").strip().lower()
if THEME_NAME not in THEMES:
    THEME_NAME = "minimal"

THEME = THEMES[THEME_NAME]


def style(key: str, default: str = "") -> str:
    """Get a style token for the active theme."""
    return THEME.get(key, default)
