"""File manipulation and command execution tools for AgentRun."""
import os
import subprocess
import shutil
import re
import json
from pathlib import Path
from typing import Optional, Tuple
from rich.console import Console
from rich.syntax import Syntax
from rich.panel import Panel
from rich.prompt import Confirm

from .animations import pulse
from .icons import ICONS
from .theme import style

console = Console()
READ_FILE_CACHE: dict[str, dict] = {}
READ_FILE_CACHE_LIMIT = 200
READ_FILE_CACHE_MAX_BYTES = 1_000_000


def _trim_text_payload(text: str, max_chars: int = 12000, max_lines: int = 300) -> Tuple[str, bool]:
    """Trim command/tool text payloads to avoid huge context bloat."""
    changed = False
    lines = text.splitlines()
    if len(lines) > max_lines:
        head = lines[: max_lines // 2]
        tail = lines[-max(1, max_lines // 3):]
        text = "\n".join(head + [f"... <TRUNCATED {len(lines) - len(head) - len(tail)} lines> ..."] + tail)
        changed = True
    if len(text) > max_chars:
        head_chars = max_chars // 2
        tail_chars = max_chars // 3
        omitted = len(text) - head_chars - tail_chars
        text = f"{text[:head_chars]}\n... <TRUNCATED {omitted} chars> ...\n{text[-tail_chars:]}"
        changed = True
    return text, changed


def read_file(filepath: str) -> dict:
    """Read the contents of a file."""
    try:
        path = Path(filepath).resolve()
        if not path.exists():
            return {"success": False, "error": f"File not found: {filepath}"}
        if not path.is_file():
            return {"success": False, "error": f"Not a file: {filepath}"}
        stat = path.stat()
        cache_key = f"{stat.st_mtime_ns}:{stat.st_size}"
        cache_entry = READ_FILE_CACHE.get(str(path))
        if cache_entry and cache_entry.get("cache_key") == cache_key:
            return {
                "success": True,
                "content": cache_entry["content"],
                "path": str(path),
                "lines": cache_entry["lines"],
                "cache_hit": True,
            }
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
        lines = len(content.splitlines())
        if stat.st_size <= READ_FILE_CACHE_MAX_BYTES:
            if len(READ_FILE_CACHE) >= READ_FILE_CACHE_LIMIT:
                READ_FILE_CACHE.pop(next(iter(READ_FILE_CACHE)))
            READ_FILE_CACHE[str(path)] = {
                "cache_key": cache_key,
                "content": content,
                "lines": lines,
            }
        return {
            "success": True,
            "content": content,
            "path": str(path),
            "lines": lines,
            "cache_hit": False,
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def write_file(filepath: str, content: str, auto_confirm: bool = False) -> dict:
    """Write content to a file (create or overwrite)."""
    try:
        path = Path(filepath).resolve()
        exists = path.exists()
        action = "Overwrite" if exists else "Create"
        console.print(f"\n{ICONS['write']} [{action}] {path}", style=style("accent", "cyan"))
        pulse(
            console,
            text="Preparing write preview...",
            style_name=style("muted", "dim"),
            spinner_name="dots8",
            duration=0.1,
        )
        lang = _detect_language(filepath)
        syntax = Syntax(content, lang, theme="monokai", line_numbers=True)
        console.print(Panel(
            syntax,
            title=f"{ICONS['write']} Write Preview ({path.name})",
            border_style=style("panel", "cyan"),
        ))
        if not auto_confirm:
            if not Confirm.ask(f"  {ICONS['write']} {action} this file?"):
                return {"success": False, "error": "User cancelled the operation"}
        path.parent.mkdir(parents=True, exist_ok=True)
        pulse(
            console,
            text="Writing file...",
            style_name=style("muted", "dim"),
            spinner_name="line",
            duration=0.08,
        )
        if exists:
            backup_path = path.with_suffix(path.suffix + ".bak")
            shutil.copy2(path, backup_path)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        console.print(
            f"  {ICONS['success']} File {'overwritten' if exists else 'created'}: {path}",
            style=style("success", "green"),
        )
        return {"success": True, "path": str(path), "action": action.lower()}
    except Exception as e:
        return {"success": False, "error": str(e)}


def replace_in_file(
    filepath: str,
    old_text: str,
    new_text: str,
    auto_confirm: bool = False,
) -> dict:
    """Replace specific text in a file."""
    try:
        path = Path(filepath).resolve()
        if not path.exists():
            return {"success": False, "error": f"File not found: {filepath}"}
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        if old_text not in content:
            return {
                "success": False,
                "error": f"Text to replace not found in {filepath}. Make sure the old_text matches exactly (including whitespace and indentation).",
            }
        count = content.count(old_text)
        console.print(f"\n{ICONS['replace']} Replace text in: {path}", style=style("accent", "cyan"))
        pulse(
            console,
            text="Preparing replacement diff...",
            style_name=style("muted", "dim"),
            spinner_name="dots10",
            duration=0.1,
        )
        lang = _detect_language(filepath)
        console.print(Panel(
            Syntax(old_text, lang, theme="monokai"),
            title=f"{ICONS['minus']} Current Block",
            border_style=style("delete", "red"),
        ))
        console.print(Panel(
            Syntax(new_text, lang, theme="monokai"),
            title=f"{ICONS['plus']} Replacement Block",
            border_style=style("panel", "cyan"),
        ))
        console.print(f"  Found {count} occurrence(s)", style=style("muted", "dim"))
        if not auto_confirm:
            if not Confirm.ask(f"  {ICONS['replace']} Apply this replacement?"):
                return {"success": False, "error": "User cancelled the operation"}
        backup_path = path.with_suffix(path.suffix + ".bak")
        pulse(
            console,
            text="Applying replacement...",
            style_name=style("muted", "dim"),
            spinner_name="line2",
            duration=0.08,
        )
        shutil.copy2(path, backup_path)
        new_content = content.replace(old_text, new_text)
        with open(path, "w", encoding="utf-8") as f:
            f.write(new_content)
        console.print(
            f"  {ICONS['success']} Replaced {count} occurrence(s) in {path}",
            style=style("success", "green"),
        )
        return {"success": True, "path": str(path), "replacements": count}
    except Exception as e:
        return {"success": False, "error": str(e)}


def insert_at_line(
    filepath: str,
    line_number: int,
    text: str,
    auto_confirm: bool = False,
) -> dict:
    """Insert text at a specific line number."""
    try:
        path = Path(filepath).resolve()
        if not path.exists():
            return {"success": False, "error": f"File not found: {filepath}"}
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        if line_number < 1 or line_number > len(lines) + 1:
            return {
                "success": False,
                "error": f"Line {line_number} out of range (file has {len(lines)} lines)",
            }
        console.print(
            f"\n{ICONS['insert']} Insert at line {line_number} in: {path}",
            style=style("insert", "magenta"),
        )
        pulse(
            console,
            text="Preparing insert preview...",
            style_name=style("muted", "dim"),
            spinner_name="dots8",
            duration=0.1,
        )
        lang = _detect_language(filepath)
        syntax = Syntax(text, lang, theme="monokai")
        console.print(Panel(
            syntax,
            title=f"{ICONS['insert']} Insert Preview (line {line_number})",
            border_style=style("panel", "cyan"),
        ))
        if not auto_confirm:
            if not Confirm.ask(f"  {ICONS['insert']} Insert this text?"):
                return {"success": False, "error": "User cancelled the operation"}
        backup_path = path.with_suffix(path.suffix + ".bak")
        pulse(
            console,
            text="Inserting lines...",
            style_name=style("muted", "dim"),
            spinner_name="line",
            duration=0.08,
        )
        shutil.copy2(path, backup_path)
        insert_lines = text.splitlines(keepends=True)
        if insert_lines and not insert_lines[-1].endswith("\n"):
            insert_lines[-1] += "\n"
        for i, line in enumerate(insert_lines):
            lines.insert(line_number - 1 + i, line)
        with open(path, "w", encoding="utf-8") as f:
            f.writelines(lines)
        console.print(
            f"  {ICONS['success']} Inserted at line {line_number} in {path}",
            style=style("success", "green"),
        )
        return {"success": True, "path": str(path), "line": line_number}
    except Exception as e:
        return {"success": False, "error": str(e)}


def delete_lines(
    filepath: str,
    start_line: int,
    end_line: int,
    auto_confirm: bool = False,
) -> dict:
    """Delete lines from start_line to end_line (inclusive)."""
    try:
        path = Path(filepath).resolve()
        if not path.exists():
            return {"success": False, "error": f"File not found: {filepath}"}
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        if start_line < 1 or end_line > len(lines) or start_line > end_line:
            return {
                "success": False,
                "error": f"Invalid line range {start_line}-{end_line} (file has {len(lines)} lines)",
            }
        deleted = lines[start_line - 1 : end_line]
        deleted_text = "".join(deleted)
        console.print(
            f"\n{ICONS['delete']} Delete lines {start_line}-{end_line} in: {path}",
            style=style("delete", "red"),
        )
        pulse(
            console,
            text="Preparing delete preview...",
            style_name=style("muted", "dim"),
            spinner_name="dots12",
            duration=0.1,
        )
        lang = _detect_language(filepath)
        syntax = Syntax(deleted_text, lang, theme="monokai", line_numbers=True, start_line=start_line)
        console.print(Panel(
            syntax,
            title=f"{ICONS['delete']} Delete Preview",
            border_style=style("delete", "red"),
        ))
        if not auto_confirm:
            if not Confirm.ask(f"  {ICONS['delete']} Delete these lines?"):
                return {"success": False, "error": "User cancelled the operation"}
        backup_path = path.with_suffix(path.suffix + ".bak")
        pulse(
            console,
            text="Deleting lines...",
            style_name=style("muted", "dim"),
            spinner_name="line2",
            duration=0.08,
        )
        shutil.copy2(path, backup_path)
        del lines[start_line - 1 : end_line]
        with open(path, "w", encoding="utf-8") as f:
            f.writelines(lines)
        console.print(
            f"  {ICONS['success']} Deleted lines {start_line}-{end_line} from {path}",
            style=style("success", "green"),
        )
        return {"success": True, "path": str(path), "deleted_lines": end_line - start_line + 1}
    except Exception as e:
        return {"success": False, "error": str(e)}


def run_command(command: str, auto_confirm: bool = False) -> dict:
    """Run a shell command in the current directory."""
    try:
        dangerous_patterns = [
            r"\brm\s+-rf\s+/\b",
            r"\bmkfs\b",
            r"\bdd\s+if=",
            r">\s*/dev/sd",
            r"\bformat\b.*\bc:\b",
            r":(){.*};:",
        ]
        for pattern in dangerous_patterns:
            if re.search(pattern, command, re.IGNORECASE):
                console.print(
                    f"\n{ICONS['warning']} BLOCKED dangerous command: {command}",
                    style=style("warning", "yellow"),
                )
                return {"success": False, "error": "Command blocked for safety reasons"}
        console.print(f"\n{ICONS['run']} Command: {command}", style=style("run", "blue"))
        console.print(f"   {ICONS['folder']} Working dir: {os.getcwd()}", style=style("muted", "dim"))
        pulse(
            console,
            text="Preparing command execution...",
            style_name=style("muted", "dim"),
            spinner_name="dots10",
            duration=0.1,
        )
        if not auto_confirm:
            if not Confirm.ask(f"  {ICONS['run']} Run this command?"):
                return {"success": False, "error": "User cancelled the command"}
        pulse(
            console,
            text="Running command...",
            style_name=style("muted", "dim"),
            spinner_name="line",
            duration=0.1,
        )
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=120,
            cwd=os.getcwd(),
        )
        stdout = result.stdout.strip()
        stderr = result.stderr.strip()
        stdout, stdout_trimmed = _trim_text_payload(stdout)
        stderr, stderr_trimmed = _trim_text_payload(stderr)
        if stdout:
            console.print(Panel(stdout, title=f"{ICONS['run']} stdout", border_style=style("panel", "cyan")))
        if stderr:
            err_border = style("error", "red") if result.returncode != 0 else style("panel", "cyan")
            console.print(Panel(stderr, title=f"{ICONS['run']} stderr", border_style=err_border))
        exit_icon = ICONS["success"] if result.returncode == 0 else ICONS["error"]
        console.print(
            f"  {exit_icon} Exit code: {result.returncode}",
            style=style("success", "green") if result.returncode == 0 else style("error", "red"),
        )
        return {
            "success": result.returncode == 0,
            "stdout": stdout,
            "stderr": stderr,
            "exit_code": result.returncode,
            "stdout_truncated": stdout_trimmed,
            "stderr_truncated": stderr_trimmed,
        }
    except subprocess.TimeoutExpired:
        return {"success": False, "error": "Command timed out after 120 seconds"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def list_files(directory: str = ".", recursive: bool = False, pattern: str = "*") -> dict:
    """List files in a directory."""
    try:
        path = Path(directory).resolve()
        if not path.exists():
            return {"success": False, "error": f"Directory not found: {directory}"}
        if recursive:
            files = sorted([str(p.relative_to(path)) for p in path.rglob(pattern) if p.is_file()])
        else:
            files = sorted([str(p.relative_to(path)) for p in path.glob(pattern) if p.is_file()])
        ignore_dirs = {".git", "__pycache__", "node_modules", ".venv", "venv", ".idea", ".vscode"}
        files = [f for f in files if not any(d in f.split(os.sep) for d in ignore_dirs)]
        return {"success": True, "files": files[:200], "total": len(files), "directory": str(path)}
    except Exception as e:
        return {"success": False, "error": str(e)}


def search_in_files(directory: str, search_text: str, file_pattern: str = "*") -> dict:
    """Search for text across files in a directory."""
    try:
        path = Path(directory).resolve()
        if not path.exists():
            return {"success": False, "error": f"Directory not found: {directory}"}
        results = []
        ignore_dirs = {".git", "__pycache__", "node_modules", ".venv", "venv"}
        for fpath in path.rglob(file_pattern):
            if not fpath.is_file():
                continue
            if any(d in fpath.parts for d in ignore_dirs):
                continue
            try:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                    for i, line in enumerate(f, 1):
                        if search_text in line:
                            results.append({
                                "file": str(fpath.relative_to(path)),
                                "line": i,
                                "content": line.strip()[:200],
                            })
                            if len(results) >= 50:
                                break
            except (IOError, OSError):
                continue
            if len(results) >= 50:
                break
        return {"success": True, "results": results, "total": len(results)}
    except Exception as e:
        return {"success": False, "error": str(e)}


def _detect_language(filepath: str) -> str:
    """Detect programming language from file extension."""
    ext_map = {
        ".py": "python", ".js": "javascript", ".ts": "typescript",
        ".jsx": "jsx", ".tsx": "tsx", ".html": "html", ".css": "css",
        ".json": "json", ".yaml": "yaml", ".yml": "yaml", ".toml": "toml",
        ".md": "markdown", ".sql": "sql", ".sh": "bash", ".bash": "bash",
        ".rs": "rust", ".go": "go", ".java": "java", ".cpp": "cpp",
        ".c": "c", ".h": "c", ".rb": "ruby", ".php": "php",
        ".swift": "swift", ".kt": "kotlin", ".scala": "scala",
        ".r": "r", ".R": "r", ".xml": "xml", ".ini": "ini",
        ".cfg": "ini", ".conf": "ini", ".dockerfile": "dockerfile",
        ".tf": "hcl", ".lua": "lua", ".vim": "vim",
    }
    ext = Path(filepath).suffix.lower()
    name = Path(filepath).name.lower()
    if name == "dockerfile":
        return "dockerfile"
    if name == "makefile":
        return "makefile"
    return ext_map.get(ext, "text")


# Tool definitions for OpenAI-compatible function calling (works with OpenRouter)
TOOL_DEFINITIONS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read the contents of a file at the given path. Use this to understand existing code before making changes.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filepath": {
                        "type": "string",
                        "description": "Path to the file to read (relative or absolute)"
                    }
                },
                "required": ["filepath"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Create a new file or completely overwrite an existing file with the provided content. Use for creating new files or when the entire file needs to be rewritten.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filepath": {
                        "type": "string",
                        "description": "Path to the file to write"
                    },
                    "content": {
                        "type": "string",
                        "description": "The complete content to write to the file"
                    }
                },
                "required": ["filepath", "content"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "replace_in_file",
            "description": "Replace a specific block of text in a file with new text. The old_text must match EXACTLY (including whitespace/indentation). Use for targeted edits within a file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filepath": {
                        "type": "string",
                        "description": "Path to the file"
                    },
                    "old_text": {
                        "type": "string",
                        "description": "The exact text to find and replace (must match exactly including whitespace)"
                    },
                    "new_text": {
                        "type": "string",
                        "description": "The new text to replace it with"
                    }
                },
                "required": ["filepath", "old_text", "new_text"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "insert_at_line",
            "description": "Insert text at a specific line number in a file. Existing content is shifted down.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filepath": {
                        "type": "string",
                        "description": "Path to the file"
                    },
                    "line_number": {
                        "type": "integer",
                        "description": "Line number to insert at (1-based)"
                    },
                    "text": {
                        "type": "string",
                        "description": "Text to insert"
                    }
                },
                "required": ["filepath", "line_number", "text"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "delete_lines",
            "description": "Delete a range of lines from a file (inclusive).",
            "parameters": {
                "type": "object",
                "properties": {
                    "filepath": {
                        "type": "string",
                        "description": "Path to the file"
                    },
                    "start_line": {
                        "type": "integer",
                        "description": "First line to delete (1-based)"
                    },
                    "end_line": {
                        "type": "integer",
                        "description": "Last line to delete (1-based, inclusive)"
                    }
                },
                "required": ["filepath", "start_line", "end_line"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "run_command",
            "description": "Execute a shell command in the current working directory. Use for running scripts, installing packages, building projects, git commands, etc.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "The shell command to execute"
                    }
                },
                "required": ["command"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "list_files",
            "description": "List files in a directory. Use to understand project structure.",
            "parameters": {
                "type": "object",
                "properties": {
                    "directory": {
                        "type": "string",
                        "description": "Directory path (default: current directory)",
                        "default": "."
                    },
                    "recursive": {
                        "type": "boolean",
                        "description": "Whether to list files recursively",
                        "default": False
                    },
                    "pattern": {
                        "type": "string",
                        "description": "Glob pattern to filter files (e.g., '*.py')",
                        "default": "*"
                    }
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "search_in_files",
            "description": "Search for a text string across files in a directory. Use to find where something is defined or used.",
            "parameters": {
                "type": "object",
                "properties": {
                    "directory": {
                        "type": "string",
                        "description": "Directory to search in"
                    },
                    "search_text": {
                        "type": "string",
                        "description": "Text to search for"
                    },
                    "file_pattern": {
                        "type": "string",
                        "description": "Glob pattern to filter files (e.g., '*.py')",
                        "default": "*"
                    }
                },
                "required": ["directory", "search_text"]
            }
        }
    }
]


def execute_tool(tool_name: str, arguments: dict, config: dict) -> str:
    """Execute a tool by name with given arguments and return result as JSON string."""
    auto_confirm_cmds = config.get("auto_confirm_commands", False)
    auto_confirm_edits = config.get("auto_confirm_edits", False)
    if tool_name == "read_file":
        result = read_file(**arguments)
    elif tool_name == "write_file":
        result = write_file(**arguments, auto_confirm=auto_confirm_edits)
    elif tool_name == "replace_in_file":
        result = replace_in_file(**arguments, auto_confirm=auto_confirm_edits)
    elif tool_name == "insert_at_line":
        result = insert_at_line(**arguments, auto_confirm=auto_confirm_edits)
    elif tool_name == "delete_lines":
        result = delete_lines(**arguments, auto_confirm=auto_confirm_edits)
    elif tool_name == "run_command":
        result = run_command(**arguments, auto_confirm=auto_confirm_cmds)
    elif tool_name == "list_files":
        result = list_files(**arguments)
    elif tool_name == "search_in_files":
        result = search_in_files(**arguments)
    else:
        result = {"success": False, "error": f"Unknown tool: {tool_name}"}
    return json.dumps(result, indent=2)
