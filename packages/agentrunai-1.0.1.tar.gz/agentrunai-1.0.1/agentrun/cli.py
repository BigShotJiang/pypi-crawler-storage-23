"""CLI entry point for AgentRun."""

import sys
import os
import json
import argparse
import traceback
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.styles import Style as PtStyle

from .animations import animate_banner, animate_panel, pulse, type_line
from .config import setup_api_key, load_config, save_config, CONFIG_DIR
from .agent import Agent
from .icons import ICONS, ICON_MODE
from .theme import style, THEME_NAME

console = Console()
HEADING = style("heading_markup", "bold cyan")
KEY_STYLE = style("key_markup", "cyan")
MUTED = style("muted", "dim")

BANNER = fr"""
    ___                    __  ____
   /   | ____ ____  ____  / /_/ __ \__  ______
  / /| |/ __ `/ _ \/ __ \/ __/ /_/ / / / / __ \
 / ___ / /_/ /  __/ / / / /_/ _, _/ /_/ / / / /
/_/  |_\__, /\___/_/ /_/\__/_/ |_|\__,_/_/ /_/
      /____/
          {ICONS["provider"]} Powered by OpenRouter
"""

HELP_TEXT = f"""
[{HEADING}]{ICONS["help"]} Commands:[/]
  [{KEY_STYLE}]/help[/]        — Show this help message
  [{KEY_STYLE}]/reset[/]       — Reset conversation history
  [{KEY_STYLE}]/clear[/]       — Clear the screen
  [{KEY_STYLE}]/config[/]      — Show current configuration
  [{KEY_STYLE}]/model NAME[/]  — Change the AI model
  [{KEY_STYLE}]/models[/]      — Show popular available models
  [{KEY_STYLE}]/cd PATH[/]     — Change working directory
  [{KEY_STYLE}]/autoconfirm[/] — Toggle auto-confirm mode on/off
  [{KEY_STYLE}]/exit[/]        — Exit AgentRun (or Ctrl+D / Ctrl+C)

[{HEADING}]{ICONS["edit"]} Tool Actions:[/]
  [{KEY_STYLE}]{ICONS["read"]}[/] Read file contents (`read_file`)
  [{KEY_STYLE}]{ICONS["write"]}[/] Create/overwrite files (`write_file`)
  [{KEY_STYLE}]{ICONS["replace"]}[/] Replace text blocks (`replace_in_file`)
  [{KEY_STYLE}]{ICONS["insert"]}[/] Insert lines (`insert_at_line`)
  [{KEY_STYLE}]{ICONS["delete"]}[/] Delete line ranges (`delete_lines`)
  [{KEY_STYLE}]{ICONS["search"]}[/] Search project files (`search_in_files`)
  [{KEY_STYLE}]{ICONS["list"]}[/] List project files (`list_files`)
  [{KEY_STYLE}]{ICONS["run"]}[/] Run shell commands (`run_command`)

[{HEADING}]{ICONS["prompt"]} Usage:[/]
  Just type what you want to do in natural language!

[{HEADING}]{ICONS["command"]} Examples:[/]
  "Read main.py and add error handling to the parse function"
  "Create a new Python script that downloads images from a URL"
  "Run the tests and fix any failures"
  "Find all TODO comments in the project"
  "Refactor the User class to use dataclasses"
  "Install flask and create a hello world app"
"""

POPULAR_MODELS = f"""
[{HEADING}]Popular OpenRouter Models:[/]

[{HEADING}]StepFun:[/]
  stepfun/step-3.5-flash:free — Default (free)

[{HEADING}]OpenAI:[/]
  openai/gpt-4o              — Best overall
  openai/gpt-4o-mini         — Fast & cheap
  openai/gpt-4-turbo         — Powerful
  openai/o3-mini             — Reasoning model

[{HEADING}]Anthropic:[/]
  anthropic/claude-sonnet-4  — Excellent for coding
  anthropic/claude-3.5-haiku — Fast & cheap

[{HEADING}]Google:[/]
  google/gemini-2.5-pro      — Very capable
  google/gemini-2.0-flash-001 — Fast

[{HEADING}]Meta:[/]
  meta-llama/llama-4-maverick  — Open source
  meta-llama/llama-3.3-70b-instruct — Popular open model

[{HEADING}]DeepSeek:[/]
  deepseek/deepseek-chat-v3-0324  — Strong coder
  deepseek/deepseek-r1             — Reasoning model

[{MUTED}]Browse all: https://openrouter.ai/models[/]
[{MUTED}]Change with: /model <model_name>[/]
"""


def handle_command(cmd: str, agent: Agent) -> bool:
    """
    Handle slash commands.
    Returns True if the REPL should continue, False to exit.
    """
    parts = cmd.strip().split(maxsplit=1)
    command = parts[0].lower()
    args = parts[1] if len(parts) > 1 else ""

    # ── Exit ──────────────────────────────────────────────
    if command in ("/exit", "/quit", "/q"):
        console.print(f"\n{ICONS['goodbye']} Goodbye!", style=style("accent"))
        return False

    # ── Help ──────────────────────────────────────────────
    elif command in ("/help", "/h", "/?"):
        help_panel = Panel(HELP_TEXT, title=f"{ICONS['help']} AgentRun Help", border_style=style("panel"))
        animate_panel(
            console,
            help_panel,
            intro_text="Loading help...",
            intro_style=style("muted"),
            spinner_name="dots8",
            duration=0.14,
        )

    # ── Models list ───────────────────────────────────────
    elif command == "/models":
        models_panel = Panel(POPULAR_MODELS, title=f"{ICONS['model']} Available Models", border_style=style("panel"))
        animate_panel(
            console,
            models_panel,
            intro_text="Fetching model list...",
            intro_style=style("muted"),
            spinner_name="line",
            duration=0.14,
        )

    # ── Reset conversation ────────────────────────────────
    elif command == "/reset":
        agent.reset()

    # ── Clear screen ──────────────────────────────────────
    elif command == "/clear":
        os.system("cls" if os.name == "nt" else "clear")

    # ── Show config ───────────────────────────────────────
    elif command == "/config":
        config = load_config()
        safe_config = config.copy()
        if safe_config.get("api_key"):
            key = safe_config["api_key"]
            safe_config["api_key"] = (
                key[:12] + "..." + key[-4:] if len(key) > 16 else "***"
            )
        config_panel = Panel(
            json.dumps(safe_config, indent=2),
            title=f"{ICONS['config']} Current Configuration",
            border_style=style("panel"),
        )
        animate_panel(
            console,
            config_panel,
            intro_text="Loading config...",
            intro_style=style("muted"),
            spinner_name="dots10",
            duration=0.12,
        )

    # ── Change model ──────────────────────────────────────
    elif command == "/model":
        if args:
            new_model = args.strip()
            config = load_config()
            config["model"] = new_model
            save_config(config)
            agent.config = config
            pulse(
                console,
                text="Switching model...",
                style_name=style("muted"),
                spinner_name="line2",
                duration=0.12,
            )
            console.print(f"{ICONS['success']} Model changed to: [bold]{new_model}[/bold]", style=style("success"))
            console.print("  Conversation has been reset for the new model.", style=style("muted"))
            agent.reset()
        else:
            console.print(f"Current model: [bold]{agent.config['model']}[/bold]", style=style("accent"))
            console.print("Usage: /model <model_name>", style=style("muted"))
            console.print("Type /models to see popular options", style=style("muted"))

    # ── Change directory ──────────────────────────────────
    elif command == "/cd":
        if args:
            try:
                target = Path(args).expanduser().resolve()
                if not target.is_dir():
                    console.print(f"{ICONS['error']} Not a directory: {target}", style=style("error"))
                else:
                    pulse(
                        console,
                        text="Changing workspace...",
                        style_name=style("muted"),
                        spinner_name="dots8",
                        duration=0.1,
                    )
                    os.chdir(target)
                    agent.reset()
                    console.print(f"{ICONS['folder']} Changed to: {target}", style=style("accent"))
            except Exception as e:
                console.print(f"{ICONS['error']} {e}", style=style("error"))
        else:
            console.print(f"{ICONS['folder']} Current directory: {os.getcwd()}", style=style("accent"))

    # ── Toggle auto-confirm ──────────────────────────────
    elif command == "/autoconfirm":
        config = load_config()
        current = config.get("auto_confirm_edits", False)
        new_val = not current
        config["auto_confirm_edits"] = new_val
        config["auto_confirm_commands"] = new_val
        save_config(config)
        agent.config = config
        pulse(
            console,
            text="Updating safety mode...",
            style_name=style("muted"),
            spinner_name="dots",
            duration=0.1,
        )
        if new_val:
            state = f"ON {ICONS['auto']} (all changes auto-approved)"
            console.print(f"Auto-confirm is now: [bold]{state}[/bold]", style=style("warning"))
            console.print(
                f"{ICONS['warning_danger']} Dangerous: commands and edits run without confirmation.",
                style=style("warning"),
            )
        else:
            state = f"OFF {ICONS['warning']} (you approve each change)"
            console.print(f"Auto-confirm is now: [bold]{state}[/bold]", style=style("accent"))

    # ── Unknown command ───────────────────────────────────
    else:
        console.print(
            f"{ICONS['error']} Unknown command: {command}. Type [bold]/help[/bold] for available commands.",
            style=style("error"),
        )

    return True


def run_interactive():
    """Run the interactive REPL loop."""

    # ── API key ───────────────────────────────────────────
    api_key = setup_api_key()
    if not api_key:
        console.print(f"{ICONS['error']} Cannot start without an API key.", style=style("error"))
        console.print("   Get one at: https://openrouter.ai/keys", style=style("muted"))
        sys.exit(1)

    # ── Create agent ──────────────────────────────────────
    try:
        agent = Agent()
    except Exception as e:
        console.print(f"{ICONS['error']} Failed to initialise agent: {e}", style=style("error"))
        sys.exit(1)

    # ── Banner ────────────────────────────────────────────
    animate_banner(console, BANNER, style("banner"))
    auto = agent.config.get("auto_confirm_edits", False)
    status_line = (
        f"{ICONS['folder']} [bold]{os.getcwd()}[/bold]   "
        f"{ICONS['model']} [bold]{agent.config['model']}[/bold]   "
        f"{ICONS['provider']} [bold]OpenRouter[/bold]   "
        f"{ICONS['auto']} [bold]{'ON' if auto else 'OFF'}[/bold]   "
        f"route [bold]{'on' if agent.config.get('routing_enabled', True) else 'off'}[/bold]   "
        f"budget [bold]{agent.config.get('turn_budget_tokens', 256000)}[/bold]   "
        f"theme [bold]{THEME_NAME}[/bold]   "
        f"icons [bold]{ICON_MODE}[/bold]"
    )
    session_panel = Panel(
        status_line,
        title=f"{ICONS['brand']} Session",
        border_style=style("panel"),
        padding=(0, 1),
    )
    animate_panel(
        console,
        session_panel,
        intro_text="Bootstrapping session...",
        intro_style=style("muted"),
        spinner_name="dots12",
        duration=0.15,
    )
    type_line(
        console,
        f"  Type /help for commands or just describe what you need.",
        style("muted"),
        char_delay=0.003,
    )
    console.print()

    # ── Prompt session with persistent history ────────────
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    history_file = CONFIG_DIR / "history.txt"

    pt_style = PtStyle.from_dict({
        "prompt": style("prompt_pt", "bold ansicyan"),
    })

    session = PromptSession(
        history=FileHistory(str(history_file)),
        auto_suggest=AutoSuggestFromHistory(),
        style=pt_style,
        multiline=False,
    )

    # ── Main loop ─────────────────────────────────────────
    while True:
        try:
            user_input = session.prompt(f"\n{ICONS['prompt']} You > ").strip()

            if not user_input:
                continue

            # Slash commands
            if user_input.startswith("/"):
                if not handle_command(user_input, agent):
                    break
                continue

            # Send to AI agent
            agent.chat(user_input)

        except KeyboardInterrupt:
            console.print(f"\n\n{ICONS['goodbye']} Goodbye! (Ctrl+C)", style=style("accent"))
            break
        except EOFError:
            console.print(f"\n\n{ICONS['goodbye']} Goodbye! (Ctrl+D)", style=style("accent"))
            break
        except Exception as e:
            console.print(f"\n{ICONS['error']} Unexpected error: {e}", style=style("error"))
            console.print(traceback.format_exc(), style=style("muted"))
            console.print("Type [bold]/reset[/bold] to clear state, or keep going.\n", style=style("muted"))


def run_single_command(command: str):
    """Run a single natural-language command and exit."""
    api_key = setup_api_key()
    if not api_key:
        console.print(f"{ICONS['error']} Cannot run without an API key.", style=style("error"))
        sys.exit(1)

    agent = Agent()
    summary = (
        f"{ICONS['folder']} [bold]{os.getcwd()}[/bold]   "
        f"{ICONS['model']} [bold]{agent.config['model']}[/bold]"
    )
    single_panel = Panel(
        summary,
        title=f"{ICONS['brand']} Single Command",
        border_style=style("panel"),
        padding=(0, 1),
    )
    animate_panel(
        console,
        single_panel,
        intro_text="Preparing single command...",
        intro_style=style("muted"),
        spinner_name="line",
        duration=0.12,
    )
    type_line(console, f"{ICONS['prompt']} {command}", style("accent"), char_delay=0.0025)
    console.print()
    agent.chat(command)


def main():
    """Main entry point — called by the `agentrun` console script."""

    parser = argparse.ArgumentParser(
        prog="agentrun",
        description="AI-powered CLI tool for code editing and terminal commands. Powered by OpenRouter.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
examples:
  agentrun                                       # interactive mode
  agentrun "fix the bug in app.py line 23"       # single-shot mode
  agentrun -m anthropic/claude-sonnet-4          # use Claude
  agentrun -m google/gemini-2.5-pro              # use Gemini
  agentrun -m deepseek/deepseek-chat-v3-0324     # use DeepSeek
  agentrun -y "add tests for utils.py"           # auto-confirm everything
        """,
    )
    parser.add_argument(
        "command",
        nargs="*",
        help="Natural-language command to run (non-interactive mode)",
    )
    parser.add_argument(
        "--model", "-m",
        type=str,
        default=None,
        help="Override the AI model (e.g. openai/gpt-4o, anthropic/claude-sonnet-4)",
    )
    parser.add_argument(
        "--auto-confirm", "-y",
        action="store_true",
        default=False,
        help="Auto-confirm all file changes and commands (use with caution!)",
    )
    parser.add_argument(
        "--version", "-v",
        action="version",
        version="AgentRun 1.0.1",
    )

    args = parser.parse_args()

    # ── Apply CLI overrides to config ─────────────────────
    if args.model or args.auto_confirm:
        config = load_config()
        if args.model:
            config["model"] = args.model
        if args.auto_confirm:
            config["auto_confirm_commands"] = True
            config["auto_confirm_edits"] = True
        save_config(config)

    # ── Choose run mode ───────────────────────────────────
    if args.command:
        run_single_command(" ".join(args.command))
    else:
        run_interactive()


if __name__ == "__main__":
    main()
