"""Shared icon tokens for terminal output.

Modes:
- `AGENTRUN_ICON_MODE=unicode` (default): broadly compatible symbols.
- `AGENTRUN_ICON_MODE=phosphor`: real Phosphor PUA glyphs (font required).
- `AGENTRUN_ICON_MODE=ascii`: plain text fallbacks.
"""

from __future__ import annotations

import os

# User-selected icon names.
ICON_NAMES = {
    # app shell
    "brand": "openAiLogo",
    "provider": "headCircuit",
    "folder": "folders",
    "model": "openAiLogo",
    "prompt": "pencil",
    "goodbye": "handWaving",
    "help": "info",
    "config": "gear",
    "reset": "clockCounterClockwise",
    "command": "terminalWindow",
    "auto": "lightningA",

    # status
    "success": "checkCircle",
    "error": "imageBroken",
    "warning": "warning",
    "warning_danger": "warningDiamond",
    "key": "key",

    # tooling actions
    "read": "fileMagnifyingGlass",
    "write": "filePlus",
    "edit": "scissors",
    "insert": "fileCode",
    "delete": "trash",
    "search": "magnifyingGlass",
    "list": "keyboard",
    "run": "keyReturn",
    "replace": "fileText",
    "action": "toolbox",
    "plus": "plusSquare",
    "minus": "minusSquare",
}

# Broadly compatible Unicode fallbacks.
UNICODE_BY_NAME = {
    "headCircuit": "◍",
    "folders": "▦",
    "openAiLogo": "◎",
    "pencil": "✎",
    "handWaving": "◌",
    "info": "ℹ",
    "gear": "⚙",
    "clockCounterClockwise": "↺",
    "terminalWindow": "⌨",
    "lightningA": "ϟ",
    "checkCircle": "✓",
    "imageBroken": "✕",
    "warning": "⚠",
    "warningDiamond": "◆",
    "key": "⌁",
    "fileMagnifyingGlass": "⊙",
    "filePlus": "✚",
    "fileText": "≣",
    "fileCode": "⌬",
    "trash": "⊘",
    "magnifyingGlass": "⌕",
    "keyboard": "⌨",
    "keyReturn": "↵",
    "scissors": "✂",
    "toolbox": "☖",
    "plusSquare": "⊞",
    "minusSquare": "⊟",
}

# Real Phosphor glyph codepoints (PUA). Requires terminal font support.
PHOSPHOR_BY_NAME = {
    "headCircuit": "\ue7d4",
    "folders": "\ue260",
    "openAiLogo": "\ue7d2",
    "pencil": "\ue3ae",
    "handWaving": "\ue580",
    "info": "\ue2ce",
    "gear": "\ue270",
    "clockCounterClockwise": "\ue1a0",
    "terminalWindow": "\ueae8",
    "lightningA": "\uea84",
    "checkCircle": "\ue184",
    "imageBroken": "\ue7a8",
    "warning": "\ue4e0",
    "warningDiamond": "\ue7fc",
    "key": "\ue2d6",
    "fileMagnifyingGlass": "\ue238",
    "filePlus": "\ue236",
    "fileText": "\ue23a",
    "fileCode": "\ue914",
    "trash": "\ue4a6",
    "magnifyingGlass": "\ue30c",
    "keyboard": "\ue2d8",
    "keyReturn": "\ue782",
    "scissors": "\ueae0",
    "toolbox": "\ueca0",
    "plusSquare": "\ued4a",
    "minusSquare": "\ued4c",
}

# Readable fallbacks for very limited terminals.
ASCII_BY_NAME = {
    "headCircuit": "P",
    "folders": "#",
    "openAiLogo": "O",
    "pencil": ">",
    "handWaving": ".",
    "info": "i",
    "gear": "c",
    "clockCounterClockwise": "r",
    "terminalWindow": "t",
    "lightningA": "a",
    "checkCircle": "+",
    "imageBroken": "x",
    "warning": "!",
    "warningDiamond": "!",
    "key": "k",
    "fileMagnifyingGlass": "R",
    "filePlus": "W",
    "fileText": "~",
    "fileCode": "+",
    "trash": "-",
    "magnifyingGlass": "S",
    "keyboard": "L",
    "keyReturn": ">",
    "scissors": "E",
    "toolbox": "T",
    "plusSquare": "+",
    "minusSquare": "-",
}


def _resolve_icons(icon_names: dict[str, str], by_name: dict[str, str]) -> dict[str, str]:
    return {key: by_name.get(name, "?") for key, name in icon_names.items()}


ICON_MODE = os.getenv("AGENTRUN_ICON_MODE", "unicode").strip().lower()
if ICON_MODE in {"ascii", "plain", "simple"}:
    ICONS = _resolve_icons(ICON_NAMES, ASCII_BY_NAME)
elif ICON_MODE in {"phosphor", "pua"}:
    ICONS = _resolve_icons(ICON_NAMES, PHOSPHOR_BY_NAME)
else:
    ICONS = _resolve_icons(ICON_NAMES, UNICODE_BY_NAME)

# Canonical tool label/icon mapping so all surfaces stay in sync.
TOOL_DISPLAY = {
    "read_file": ("Read File", "read"),
    "write_file": ("Write File", "write"),
    "replace_in_file": ("Replace Text", "replace"),
    "insert_at_line": ("Insert Lines", "insert"),
    "delete_lines": ("Delete Lines", "delete"),
    "search_in_files": ("Search Files", "search"),
    "list_files": ("List Files", "list"),
    "run_command": ("Run Command", "run"),
}

# Backward-compatible aliases.
TOOL_DISPLAY_ALIASES = {
    "list_dir": "list_files",
    "list_directory": "list_files",
    "search_files": "search_in_files",
    "grep": "search_in_files",
}
