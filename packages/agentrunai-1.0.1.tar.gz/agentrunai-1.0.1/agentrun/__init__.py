"""AgentRun - AI-powered CLI tool for code editing and terminal commands. Powered by OpenRouter."""
__version__ = "1.0.1"
