"""Lightweight repository indexing for token-efficient context retrieval."""

from __future__ import annotations

import re
import time
from dataclasses import dataclass
from pathlib import Path

IGNORE_DIRS = {
    ".git",
    "__pycache__",
    "node_modules",
    ".venv",
    "venv",
    ".idea",
    ".vscode",
    "dist",
    "build",
    ".mypy_cache",
    ".pytest_cache",
}

INDEXABLE_EXTENSIONS = {
    ".py", ".js", ".ts", ".tsx", ".jsx", ".json", ".toml", ".yaml", ".yml",
    ".md", ".txt", ".sh", ".bash", ".zsh", ".go", ".rs", ".java", ".kt",
    ".c", ".h", ".cpp", ".hpp", ".swift", ".php", ".rb", ".sql", ".html", ".css",
}

STOP_WORDS = {
    "the", "and", "for", "that", "this", "with", "from", "into", "line",
    "file", "files", "code", "project", "please", "just", "need", "want",
    "make", "add", "fix", "update", "use", "run",
}

MAX_FILE_BYTES = 300_000
SYMBOL_LIMIT = 80


@dataclass
class IndexedFile:
    rel_path: str
    mtime_ns: int
    size: int
    symbols: set[str]


class RepoIndex:
    """Best-effort lexical index for finding likely relevant files."""

    def __init__(self, root: str):
        self.root = Path(root).resolve()
        self._index: dict[str, IndexedFile] = {}
        self._last_scan_at = 0.0

    def refresh(self, force: bool = False):
        """Refresh metadata/symbol index with a low-frequency guard."""
        now = time.time()
        if not force and (now - self._last_scan_at) < 8:
            return
        self._last_scan_at = now

        if not self.root.exists():
            self._index = {}
            return

        seen: set[str] = set()
        for path in self.root.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(self.root).as_posix()
            if self._is_ignored(rel) or not self._is_indexable(path):
                continue
            seen.add(rel)

            try:
                stat = path.stat()
            except OSError:
                continue

            if stat.st_size > MAX_FILE_BYTES:
                continue

            existing = self._index.get(rel)
            if existing and existing.mtime_ns == stat.st_mtime_ns and existing.size == stat.st_size:
                continue

            text = self._read_text(path)
            if text is None:
                continue

            self._index[rel] = IndexedFile(
                rel_path=rel,
                mtime_ns=stat.st_mtime_ns,
                size=stat.st_size,
                symbols=self._extract_symbols(text),
            )

        for rel in list(self._index):
            if rel not in seen:
                self._index.pop(rel, None)

    def query(self, query_text: str, max_files: int = 4) -> list[dict]:
        """Return top matching files with short snippets."""
        self.refresh()
        keywords = self._keywords(query_text)
        if not keywords:
            return []

        scored: list[tuple[float, IndexedFile, list[str]]] = []
        for item in self._index.values():
            score, matched = self._score(item, keywords)
            if score <= 0:
                continue
            scored.append((score, item, matched))

        scored.sort(key=lambda x: (-x[0], x[1].rel_path))
        selected = scored[: max(1, max_files)]

        results = []
        for score, item, matched in selected:
            snippet = self._snippet(item.rel_path, keywords)
            results.append({
                "path": item.rel_path,
                "score": round(score, 2),
                "matches": matched[:6],
                "snippet": snippet,
            })
        return results

    def _is_indexable(self, path: Path) -> bool:
        name = path.name.lower()
        if name in {"dockerfile", "makefile"}:
            return True
        return path.suffix.lower() in INDEXABLE_EXTENSIONS

    def _is_ignored(self, rel_path: str) -> bool:
        parts = rel_path.split("/")
        return any(part in IGNORE_DIRS for part in parts)

    def _read_text(self, path: Path) -> str | None:
        try:
            return path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            return None

    def _extract_symbols(self, text: str) -> set[str]:
        symbols = set()
        patterns = [
            r"^\s*(?:def|class)\s+([A-Za-z_][A-Za-z0-9_]*)",
            r"^\s*(?:function|interface|type)\s+([A-Za-z_][A-Za-z0-9_]*)",
            r"^\s*(?:const|let|var)\s+([A-Za-z_][A-Za-z0-9_]*)",
        ]
        for pat in patterns:
            for match in re.finditer(pat, text, flags=re.MULTILINE):
                symbols.add(match.group(1).lower())
                if len(symbols) >= SYMBOL_LIMIT:
                    return symbols
        return symbols

    def _keywords(self, text: str) -> list[str]:
        raw = re.findall(r"[a-zA-Z_][a-zA-Z0-9_/-]{1,}", text.lower())
        cleaned = []
        for token in raw:
            token = token.replace("-", "_").replace("/", "_")
            if token in STOP_WORDS or len(token) < 3:
                continue
            cleaned.append(token)
        return list(dict.fromkeys(cleaned))[:24]

    def _score(self, item: IndexedFile, keywords: list[str]) -> tuple[float, list[str]]:
        path_tokens = set(re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*", item.rel_path.lower()))
        symbol_tokens = item.symbols

        matched = []
        score = 0.0
        for kw in keywords:
            kw_parts = kw.split("_")
            for part in kw_parts:
                if not part:
                    continue
                if part in path_tokens:
                    score += 2.0
                    matched.append(part)
                if part in symbol_tokens:
                    score += 3.0
                    matched.append(part)
                if any(part in token for token in path_tokens):
                    score += 0.5
                if any(part in token for token in symbol_tokens):
                    score += 0.75
        # Prefer project-local shorter paths a bit.
        depth_bonus = max(0.0, 1.5 - (item.rel_path.count("/") * 0.15))
        score += depth_bonus
        return score, list(dict.fromkeys(matched))

    def _snippet(self, rel_path: str, keywords: list[str]) -> str:
        path = self.root / rel_path
        text = self._read_text(path)
        if text is None:
            return ""
        lines = text.splitlines()
        if not lines:
            return ""

        kw_set = {k for k in keywords if len(k) >= 3}
        hit_idx = 0
        for idx, line in enumerate(lines):
            lower = line.lower()
            if any(kw in lower for kw in kw_set):
                hit_idx = idx
                break

        start = max(0, hit_idx - 3)
        end = min(len(lines), start + 10)
        snippet = "\n".join(lines[start:end])
        if len(snippet) > 900:
            snippet = snippet[:900] + "\n..."
        return snippet

