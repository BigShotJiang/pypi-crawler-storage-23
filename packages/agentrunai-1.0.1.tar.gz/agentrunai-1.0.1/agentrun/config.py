"""Configuration management for AgentRun."""

import os
import json
from pathlib import Path
from dotenv import load_dotenv

from .icons import ICONS

load_dotenv()

CONFIG_DIR = Path.home() / ".agentrun"
CONFIG_FILE = CONFIG_DIR / "config.json"
MEMORY_FILE = CONFIG_DIR / "memory.json"

DEFAULT_CONFIG = {
    "api_key": "",
    "model": "stepfun/step-3.5-flash:free",
    "base_url": "https://openrouter.ai/api/v1",
    "max_tokens": 4096,
    "temperature": 0.1,
    "auto_confirm_commands": False,
    "auto_confirm_edits": False,
    "site_url": "https://github.com/agentrun",
    "site_name": "AgentRun CLI",
    # Cost/perf controls
    "routing_enabled": True,
    "fast_model": "",
    "quality_model": "",
    # Budget + compaction
    "context_budget_tokens": 256000,
    "turn_budget_tokens": 256000,
    "max_history_messages": 18,
    # Retrieval
    "retrieval_enabled": True,
    "retrieval_max_files": 4,
    # Tool payload controls
    "tool_output_char_limit": 12000,
    "tool_output_line_limit": 200,
}

LEGACY_DEFAULT_CONTEXT_BUDGETS = {20000, 128000}
DEFAULT_CONTEXT_BUDGET = DEFAULT_CONFIG["context_budget_tokens"]
LEGACY_DEFAULT_TURN_BUDGETS = {12000, 128000}
DEFAULT_TURN_BUDGET = DEFAULT_CONFIG["turn_budget_tokens"]


def load_config() -> dict:
    """Load configuration from file and environment variables."""
    config = DEFAULT_CONFIG.copy()
    file_config = {}

    # Load from config file
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r") as f:
                file_config = json.load(f)
                config.update(file_config)
        except (json.JSONDecodeError, IOError):
            pass

    # Upgrade older saved defaults to the new context budget.
    if (
        file_config.get("context_budget_tokens") in LEGACY_DEFAULT_CONTEXT_BUDGETS
        and not os.getenv("AGENTRUN_CONTEXT_BUDGET")
    ):
        config["context_budget_tokens"] = DEFAULT_CONTEXT_BUDGET
    if (
        file_config.get("turn_budget_tokens") in LEGACY_DEFAULT_TURN_BUDGETS
        and not os.getenv("AGENTRUN_TURN_BUDGET")
    ):
        config["turn_budget_tokens"] = DEFAULT_TURN_BUDGET

    # Environment variables override config file
    if os.getenv("OPENROUTER_API_KEY"):
        config["api_key"] = os.getenv("OPENROUTER_API_KEY")
    if os.getenv("AGENTRUN_MODEL"):
        config["model"] = os.getenv("AGENTRUN_MODEL")
    if os.getenv("AGENTRUN_BASE_URL"):
        config["base_url"] = os.getenv("AGENTRUN_BASE_URL")
    if os.getenv("AGENTRUN_FAST_MODEL"):
        config["fast_model"] = os.getenv("AGENTRUN_FAST_MODEL")
    if os.getenv("AGENTRUN_QUALITY_MODEL"):
        config["quality_model"] = os.getenv("AGENTRUN_QUALITY_MODEL")
    if os.getenv("AGENTRUN_ROUTING_ENABLED"):
        config["routing_enabled"] = os.getenv("AGENTRUN_ROUTING_ENABLED").strip().lower() in {"1", "true", "yes", "on"}
    if os.getenv("AGENTRUN_CONTEXT_BUDGET"):
        try:
            config["context_budget_tokens"] = int(os.getenv("AGENTRUN_CONTEXT_BUDGET"))
        except ValueError:
            pass
    if os.getenv("AGENTRUN_TURN_BUDGET"):
        try:
            config["turn_budget_tokens"] = int(os.getenv("AGENTRUN_TURN_BUDGET"))
        except ValueError:
            pass

    # Default quality model to model if unset.
    if not config.get("quality_model"):
        config["quality_model"] = config["model"]
    # Default fast model to quality model if unset.
    if not config.get("fast_model"):
        config["fast_model"] = config["quality_model"]

    return config


def save_config(config: dict):
    """Save configuration to file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)


def setup_api_key():
    """Interactive API key setup."""
    config = load_config()
    if config["api_key"]:
        return config["api_key"]

    print(f"\n{ICONS['key']} No API key found. Let's set one up!")
    print("Get your OpenRouter API key from: https://openrouter.ai/keys\n")
    api_key = input("Enter your OpenRouter API key: ").strip()

    if api_key:
        config["api_key"] = api_key
        save_config(config)
        print(f"{ICONS['success']} API key saved to ~/.agentrun/config.json\n")
        return api_key
    else:
        print(f"{ICONS['error']} No API key provided. Set OPENROUTER_API_KEY environment variable or run setup again.")
        return None
