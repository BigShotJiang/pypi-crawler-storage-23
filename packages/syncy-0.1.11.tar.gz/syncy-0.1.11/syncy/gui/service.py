"""Service layer to run validation without invoking the CLI directly.

This wraps the existing syncy validation pipeline so the GUI can call it
programmatically and render the returned summary.
"""

from __future__ import annotations

from datetime import datetime, timezone, timedelta
from typing import Optional

from .. import __version__
from ..cli import (
    DEFAULT_BEHAVIOUR_LIMIT,
    DEFAULT_BEHAVIOUR_TIMEOUT_S,
    _engine_info,
    _make_output_dir,
)
from ..config.runtime import (
    coerce_bool,
    load_yaml_config,
    normalize_schema_map,
    resolve_connection_urls,
    resolve_rule_pack,
    resolve_validate_objects,
    OBJECT_TYPE_MAP,
    VALIDATE_OBJECTS,
)
from ..core.behaviour import run_behaviour_tests
from ..core.connectors import MSSQLConnector, PostgresConnector
from ..core.diff_engine import compare_catalogs
from ..core.extractor import extract_catalog_mssql, extract_catalog_postgres
from ..core.report import generate_reports
from .state import RunConfig, RunResult


def run_validation(cfg: RunConfig) -> RunResult:
    """Execute a validation run and return a condensed result for the UI."""
    # Resolve connection URLs (same precedence as CLI)
    src_url, tgt_url = resolve_connection_urls(cfg.source_url, cfg.target_url, cfg.config_path)
    validate_list = list(cfg.validate_objects or [])
    if not validate_list:
        validate_list, _unknown, _src = resolve_validate_objects(None, cfg.config_path)
    if not validate_list:
        validate_list = list(VALIDATE_OBJECTS)

    out_path = _make_output_dir(None)

    cfg_yaml = load_yaml_config(cfg.config_path)

    def _resolve_list(raw):
        if isinstance(raw, list):
            return [str(s) for s in raw]
        if isinstance(raw, str):
            return [s.strip() for s in raw.split(",") if s.strip()]
        return None

    global_includes = cfg.include_schemas or None
    if not global_includes:
        global_includes = _resolve_list(cfg_yaml.get("include_schemas"))

    src_section = cfg_yaml.get("source") if isinstance(cfg_yaml.get("source"), dict) else {}
    tgt_section = cfg_yaml.get("target") if isinstance(cfg_yaml.get("target"), dict) else {}

    src_includes = cfg.include_schemas_source or None
    if not src_includes:
        src_includes = _resolve_list(src_section.get("include_schemas"))
    if src_includes is None:
        src_includes = global_includes

    tgt_includes = cfg.include_schemas_target or None
    if not tgt_includes:
        tgt_includes = _resolve_list(tgt_section.get("include_schemas"))
    if tgt_includes is None:
        tgt_includes = global_includes

    cfg_ignore_raw = cfg_yaml.get("ignore_case")
    if cfg_ignore_raw is None:
        cfg_ignore_raw = cfg_yaml.get("case_insensitive")
    cfg_ignore = coerce_bool(cfg_ignore_raw)
    ignore_case = bool(cfg.ignore_case) or bool(cfg_ignore or False)

    cfg_schema_raw = cfg_yaml.get("schema_map")
    if cfg_schema_raw is None:
        cfg_schema_raw = cfg_yaml.get("schema_mapping")
    cfg_schema_map, _cfg_invalid = normalize_schema_map(cfg_schema_raw)
    schema_map = {**cfg_schema_map, **(cfg.schema_map or {})}

    def filter_catalog(catalog: dict) -> dict:
        if not validate_list:
            return {}
        allowed = set()
        for obj in validate_list:
            allowed.update(OBJECT_TYPE_MAP.get(obj, set()))
        return {k: v for k, v in catalog.items() if v.get("type") in allowed}

    # Initialize connectors
    src = MSSQLConnector.from_url(src_url) if src_url.lower().startswith("mssql") else PostgresConnector.from_url(src_url)
    tgt = MSSQLConnector.from_url(tgt_url) if tgt_url.lower().startswith("mssql") else PostgresConnector.from_url(tgt_url)

    # Extract catalogs
    if isinstance(src, MSSQLConnector):
        src_catalog = extract_catalog_mssql(
            src,
            src_includes,
            None,
            schema_map=schema_map,
            ignore_case=ignore_case,
        )
    else:
        src_catalog = extract_catalog_postgres(
            src,
            src_includes,
            None,
            schema_map=schema_map,
            ignore_case=ignore_case,
        )
    if isinstance(tgt, MSSQLConnector):
        tgt_catalog = extract_catalog_mssql(
            tgt,
            tgt_includes,
            None,
            schema_map=schema_map,
            ignore_case=ignore_case,
        )
    else:
        tgt_catalog = extract_catalog_postgres(
            tgt,
            tgt_includes,
            None,
            schema_map=schema_map,
            ignore_case=ignore_case,
        )
    src_catalog = filter_catalog(src_catalog)
    tgt_catalog = filter_catalog(tgt_catalog)

    # Resolve rules
    rules = resolve_rule_pack(cfg.rules_path, cfg_yaml)

    # Compare and run behaviour tests
    comparison = compare_catalogs(src_catalog, tgt_catalog, rules)
    behaviour = {}
    if "views" in validate_list:
        behaviour = run_behaviour_tests(
            src,
            tgt,
            src_catalog,
            tgt_catalog,
            sample_limit=DEFAULT_BEHAVIOUR_LIMIT,
            timeout_s=DEFAULT_BEHAVIOUR_TIMEOUT_S,
        )

    # Summarize and write reports
    results = {
        "version": __version__,
        "runtime_utc": datetime.now(timezone.utc).isoformat(),
        "source_url": src.redacted_url,
        "target_url": tgt.redacted_url,
        "source_info": _engine_info(src),
        "target_info": _engine_info(tgt),
        "coverage": comparison.get("coverage", {}),
        "findings": comparison.get("findings", {}),
        "behaviour": behaviour,
        "finding_counts": comparison.get("finding_counts", {}),
        "status": comparison.get("status", "unknown"),
        "params": {
            "include_schemas": global_includes,
            "include_schemas_source": src_includes,
            "include_schemas_target": tgt_includes,
            "ignore_case": ignore_case,
            "schema_map": schema_map,
            "validate_objects": validate_list,
            "behaviour_limit": DEFAULT_BEHAVIOUR_LIMIT,
            "behaviour_timeout_s": DEFAULT_BEHAVIOUR_TIMEOUT_S,
        },
        "thresholds": {
            "fail_on_findings": False,
            "min_coverage": cfg.min_coverage,
            "fail_reasons": [],
        },
    }

    generate_reports(results, out_path)

    cov = results["coverage"]
    counts = results["finding_counts"]
    reasons = results["thresholds"]["fail_reasons"]
    status = results.get("status", "unknown")

    # Apply threshold logic to capture user intent
    rule_hits = int(counts.get("rule_hits", 0))
    mismatches = int(counts.get("mismatches", 0))
    missing = int(counts.get("missing", 0))
    total_findings = rule_hits + mismatches + missing
    cov_pct = float(cov.get("coverage_pct", 0.0) or 0.0)
    if cfg.min_coverage is not None and cov_pct < float(cfg.min_coverage):
        reasons.append(f"coverage {cov_pct:.2f}% < min {float(cfg.min_coverage):.2f}%")

    display_status = "fail" if reasons else status

    return RunResult(
        status=display_status,
        coverage_pct=cov_pct,
        compared=int(cov.get("compared_objects", 0)),
        total=int(cov.get("total_objects", 0)),
        rule_hits=rule_hits,
        mismatches=mismatches,
        missing=missing,
        fail_reasons=reasons,
        findings=results.get("findings", {}),
        report_dir=str(out_path),
    )
