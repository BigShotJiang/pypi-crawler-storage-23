from __future__ import annotations

import re
from typing import Dict, List, Tuple


Catalog = Dict[str, dict]


def _strip_sql_comments(text: str) -> str:
    if not text:
        return ""
    out: List[str] = []
    i = 0
    n = len(text)
    in_single = False
    in_double = False
    in_line = False
    in_block = False
    dollar_tag: str | None = None

    while i < n:
        ch = text[i]
        nxt = text[i + 1] if i + 1 < n else ""

        if in_line:
            if ch == "\n":
                in_line = False
                out.append(ch)
            i += 1
            continue

        if in_block:
            if ch == "*" and nxt == "/":
                in_block = False
                i += 2
                continue
            i += 1
            continue

        if dollar_tag is not None:
            if text.startswith(dollar_tag, i):
                out.append(dollar_tag)
                i += len(dollar_tag)
                dollar_tag = None
            else:
                out.append(ch)
                i += 1
            continue

        if not in_single and not in_double:
            if ch == "-" and nxt == "-":
                out.append(" ")
                in_line = True
                i += 2
                continue
            if ch == "/" and nxt == "*":
                out.append(" ")
                in_block = True
                i += 2
                continue
            if ch == "$":
                j = i + 1
                while j < n and (text[j].isalnum() or text[j] == "_"):
                    j += 1
                if j < n and text[j] == "$":
                    tag = text[i : j + 1]
                    out.append(tag)
                    i = j + 1
                    dollar_tag = tag
                    continue

        if ch == "'" and not in_double:
            if in_single:
                if nxt == "'":
                    out.append(ch)
                    out.append(nxt)
                    i += 2
                    continue
                in_single = False
                out.append(ch)
                i += 1
                continue
            in_single = True
            out.append(ch)
            i += 1
            continue

        if ch == '"' and not in_single:
            if in_double:
                if nxt == '"':
                    out.append(ch)
                    out.append(nxt)
                    i += 2
                    continue
                in_double = False
                out.append(ch)
                i += 1
                continue
            in_double = True
            out.append(ch)
            i += 1
            continue

        out.append(ch)
        i += 1

    return "".join(out)


def _normalize_sql(text: str) -> str:
    s = _strip_sql_comments(text or "")
    s = s.replace("[", '"').replace("]", '"')
    s = re.sub(r"\s+", " ", s).strip().lower()
    return s


def _normalize_pattern(text: str) -> str:
    s = text or ""
    s = s.replace("[", '"').replace("]", '"')
    s = re.sub(r"\s+", " ", s).lower()
    return s


def _apply_rules(src_sql: str, tgt_sql: str, rules: List[dict]) -> List[dict]:
    findings: List[dict] = []
    s = f" {_normalize_sql(src_sql)} "
    t = f" {_normalize_sql(tgt_sql)} "

    def _listify(value: object) -> List[str]:
        if value is None:
            return []
        if isinstance(value, list):
            items = value
        else:
            items = [value]
        out: List[str] = []
        for item in items:
            if item is None:
                continue
            out.append(_normalize_pattern(str(item)))
        return out

    def _contains_any(hay: str, needles: List[str]) -> bool:
        if not needles:
            return True
        return any(n in hay for n in needles)

    def _contains_none(hay: str, needles: List[str]) -> bool:
        if not needles:
            return True
        return all(n not in hay for n in needles)

    for rule in rules:
        if not isinstance(rule, dict):
            continue
        src_terms = _listify(rule.get("source_contains"))
        tgt_terms = _listify(rule.get("target_contains"))
        src_not_terms = _listify(rule.get("source_not_contains"))
        tgt_not_terms = _listify(rule.get("target_not_contains"))
        if not (src_terms or tgt_terms or src_not_terms or tgt_not_terms):
            continue
        if not _contains_any(s, src_terms):
            continue
        if not _contains_any(t, tgt_terms):
            continue
        if not _contains_none(s, src_not_terms):
            continue
        if not _contains_none(t, tgt_not_terms):
            continue

        row: dict = {}
        rule_id = rule.get("id")
        if rule_id:
            row["id"] = rule_id
        desc = rule.get("desc")
        if desc:
            row["desc"] = desc
        hint = rule.get("hint")
        if hint:
            row["hint"] = hint
        findings.append(row)

    return findings


def compare_catalogs(src: Catalog, tgt: Catalog, rules: List[dict]) -> Dict[str, object]:
    """Compare normalized catalogs and apply rule pack.

    Returns summary with coverage, status, finding counts, and per-object findings.
    """
    all_keys = set(src.keys()) | set(tgt.keys())
    src_tables = {k for k, v in src.items() if v.get("type") == "table"}
    tgt_tables = {k for k, v in tgt.items() if v.get("type") == "table"}
    findings: Dict[str, dict] = {}
    rule_hits_total = 0
    mismatch_count = 0
    missing_count = 0
    matched = 0
    compared = 0

    def _skip_column_due_to_parent(key: str, s_obj: dict | None, t_obj: dict | None) -> bool:
        obj = s_obj or t_obj
        if not obj or obj.get("type") != "column":
            return False
        parent = obj.get("table_key")
        if not parent:
            return False
        return parent not in src_tables or parent not in tgt_tables

    processed_keys: List[str] = []
    for key in sorted(all_keys):
        s_obj = src.get(key)
        t_obj = tgt.get(key)
        if _skip_column_due_to_parent(key, s_obj, t_obj):
            continue
        processed_keys.append(key)
        def _display(obj: dict | None) -> str:
            if not obj:
                return ""
            schema = str(obj.get("schema") or "").strip()
            name = str(obj.get("name") or "").strip()
            if schema and name:
                return f"{schema}.{name}"
            return schema or name

        entry = {
            "status": None,
            "rules": [],
            "source_display": _display(s_obj),
            "target_display": _display(t_obj),
        }  # type: ignore[assignment]

        if s_obj and not t_obj:
            entry["status"] = "missing_in_target"
            missing_count += 1
        elif t_obj and not s_obj:
            entry["status"] = "missing_in_source"
            missing_count += 1
        else:
            compared += 1
            s_def = s_obj.get("definition", "")
            t_def = t_obj.get("definition", "")
            obj_type = s_obj.get("type")
            if obj_type in {"table", "column"}:
                if _normalize_sql(s_def) == _normalize_sql(t_def):
                    entry["status"] = "match"
                    matched += 1
                else:
                    entry["status"] = "mismatch"
                    mismatch_count += 1
            else:
                if _normalize_sql(s_def) == _normalize_sql(t_def):
                    entry["status"] = "match"
                    matched += 1
                else:
                    rule_hits = _apply_rules(s_def, t_def, rules)
                    entry["rules"] = rule_hits
                    entry["status"] = "equivalent_with_rules" if rule_hits else "mismatch"
                    if rule_hits:
                        rule_hits_total += len(rule_hits)
                    else:
                        mismatch_count += 1

        findings[key] = entry

    total_objects = len(processed_keys)
    coverage = {
        "total_objects": total_objects,
        "compared_objects": compared,
        "matched_objects": matched,
        "coverage_pct": (compared / total_objects * 100.0) if total_objects else 0.0,
    }

    has_issues = mismatch_count > 0 or missing_count > 0
    status = "fail" if has_issues else "pass"

    return {
        "coverage": coverage,
        "finding_counts": {
            "rule_hits": rule_hits_total,
            "mismatches": mismatch_count,
            "missing": missing_count,
        },
        "status": status,
        "findings": findings,
    }
