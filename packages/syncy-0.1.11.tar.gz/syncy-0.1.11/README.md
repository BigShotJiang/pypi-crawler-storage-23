# Syncy

**Syncy** is a lightweight database migration validation tool designed to compare logic and schema objects between **SQL Server** and **PostgreSQL**. It focuses on safe, read-only validation and generates comprehensive HTML and JSON reports.

## Features
* **Read-only Connectors:** Support for MSSQL (`pyodbc`) and Postgres (`psycopg2-binary`).
* **Logic Extraction:** Extracts metadata and definitions for views, functions, procedures, and triggers.
* **Rule Pack:** Includes 8 built-in pattern-based cross-engine checks.
* **Behavioral Testing:** Simple shape comparison for views to ensure data consistency.
* **Automated Reporting:** Generates timestamped HTML and JSON reports for every run.

---

## Quick Start (via pip)

1.  **Install (Python 3.10+):**
    ```bash
    pip install syncy
    ```

2.  **Launch GUI (Optional):**
    ```bash
    syncy gui
    ```

3.  **Run Validation:**
    ```bash
    syncy validate \
      --source "<MSSQL Database Connection String>" \
      --target "<Postgres Database Connection String>"
    ```

---

## Quick Start (from Source)

1.  **Create and activate a virtual environment:**
    * **Windows (PowerShell):**
        ```powershell
        python -m venv .venv
        .\.venv\Scripts\Activate.ps1
        ```
    * **macOS/Linux:**
        ```bash
        python3 -m venv .venv
        source .venv/bin/activate
        ```

2.  **Install dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

3.  **Run validation:**
    You can provide connection URLs via CLI flags, a YAML config, or environment variables.
    ```bash
    syncy validate \
      --source "<MSSQL Database Connection String>" \
      --target "<Postgres Database Connection String>" \
      --out ./reports/demo/ \
      --source-schemas dbo \
      --target-schemas vras3_dbo
    ```

### Optional: Seed Sample Schemas
To populate your databases with sample data for testing:
```bash
python demo/load_samples.py \
  --source "<MSSQL Database Connection String>" \
  --target "<Postgres Database Connection String>"
```

## Configuration

### Resolution Order
Syncy resolves configuration in the following priority:
1.  **CLI Flags** (e.g., `--source`)
2.  **`validator.yaml`**
3.  **Environment Variables** (e.g., `SYNCY_SOURCE_URL`)

### Examples
* **validator.yaml:** Refer to `validator.yaml.example`
* **rules.yaml:** Refer to `rules.yaml.example`

---

## Notes
* **Safety First:** All queries run in safe mode. Write operations are strictly blocked.
* **Output:** Reports are saved to a timestamped folder under the directory specified by `--out` (defaults to `./reports/`).

## License
MIT