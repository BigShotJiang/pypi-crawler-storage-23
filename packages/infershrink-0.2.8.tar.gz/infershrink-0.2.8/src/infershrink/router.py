"""Model router — picks the cheapest model that meets the quality floor.

IMPORTANT: Routing only downgrades within the same provider. A user wrapping
an OpenAI client must never receive a model name that OpenAI doesn't recognize.
"""

from __future__ import annotations

from typing import Any, Dict

from .config import COMPLEXITY_TO_TIER
from .types import Complexity, RoutingDecision

# Ordered from cheapest to most expensive
_TIER_ORDER = ["tier1", "tier2", "tier3"]

# Provider detection: model prefix → provider key
_PROVIDER_PREFIXES = {
    "gpt-": "openai",
    "o1": "openai",
    "o3": "openai",
    "o4": "openai",
    "claude-": "anthropic",
    "gemini-": "google",
    "qwen": "local",
    "llama": "local",
    "mistral": "local",
    "phi-": "local",
}


def _detect_provider(model: str) -> str:
    """Detect provider from model name."""
    model_lower = model.lower()
    for prefix, provider in _PROVIDER_PREFIXES.items():
        if model_lower.startswith(prefix):
            return provider
    # If contains a colon, likely local (ollama format: model:tag)
    if ":" in model:
        return "local"
    return "unknown"


def _models_in_tier_for_provider(tier: Dict[str, Any], provider: str) -> list[str]:
    """Return models from a tier that match the given provider."""
    return [m for m in tier.get("models", []) if _detect_provider(m) == provider]


def _tier_index(tier_name: str) -> int:
    try:
        return _TIER_ORDER.index(tier_name)
    except ValueError:
        return len(_TIER_ORDER)


def _find_tier_for_model(model: str, tiers: Dict[str, Any]) -> str | None:
    """Return the tier name that lists *model*, or None."""
    for tier_name, tier_cfg in tiers.items():
        if model in tier_cfg.get("models", []):
            return tier_name
    return None


def route(
    original_model: str,
    complexity: Complexity,
    config: Dict[str, Any],
) -> RoutingDecision:
    """Determine which model to actually use.

    Parameters
    ----------
    original_model:
        The model the caller originally requested.
    complexity:
        Classified complexity of the task.
    config:
        The full InferShrink configuration dict.

    Returns
    -------
    RoutingDecision
    """
    tiers = config.get("tiers", {})

    # Accept string or Complexity enum
    if isinstance(complexity, str):
        complexity = Complexity(complexity)

    # Which tier does this complexity map to?
    target_tier_name = COMPLEXITY_TO_TIER.get(complexity.value, "tier3")
    target_tier = tiers.get(target_tier_name, {})

    # Which tier is the original model in?
    original_tier_name = _find_tier_for_model(original_model, tiers)

    # Detect provider to constrain routing
    provider = _detect_provider(original_model)

    # If the original model isn't in any known tier, keep it for COMPLEX/SECURITY
    if original_tier_name is None:
        if complexity in (Complexity.SECURITY_CRITICAL, Complexity.COMPLEX):
            return RoutingDecision(
                original_model=original_model,
                routed_model=original_model,
                complexity=complexity,
            )
        # For simpler tasks, try to route to a cheaper same-provider model
        same_provider_models = _models_in_tier_for_provider(target_tier, provider)
        routed = same_provider_models[0] if same_provider_models else original_model
        return RoutingDecision(
            original_model=original_model,
            routed_model=routed,
            complexity=complexity,
            was_downgraded=bool(same_provider_models) and same_provider_models[0] != original_model,
        )

    original_tier_idx = _tier_index(original_tier_name)
    target_tier_idx = _tier_index(target_tier_name)

    # Never upgrade beyond what the user asked for
    # (i.e., if they asked for tier1, don't push to tier3)
    # But we CAN downgrade if the task is simpler than the model

    if target_tier_idx < original_tier_idx:
        # Task is simpler than the requested model → downgrade within same provider
        same_provider_models = _models_in_tier_for_provider(target_tier, provider)
        if same_provider_models:
            routed = same_provider_models[0]
            return RoutingDecision(
                original_model=original_model,
                routed_model=routed,
                complexity=complexity,
                was_downgraded=True,
            )
        # No same-provider model in target tier — try intermediate tiers
        for tier_idx in range(target_tier_idx + 1, original_tier_idx):
            intermediate_tier_name = _TIER_ORDER[tier_idx]
            intermediate_tier = tiers.get(intermediate_tier_name, {})
            same_provider = _models_in_tier_for_provider(intermediate_tier, provider)
            if same_provider:
                return RoutingDecision(
                    original_model=original_model,
                    routed_model=same_provider[0],
                    complexity=complexity,
                    was_downgraded=True,
                )
        # No cheaper same-provider model anywhere — keep original
        return RoutingDecision(
            original_model=original_model,
            routed_model=original_model,
            complexity=complexity,
        )

    if target_tier_idx > original_tier_idx:
        # Task is more complex than the requested model → keep original
        # (we don't silently upgrade to avoid cost surprises)
        return RoutingDecision(
            original_model=original_model,
            routed_model=original_model,
            complexity=complexity,
            was_upgraded=False,
        )

    # Same tier — keep the original model
    return RoutingDecision(
        original_model=original_model,
        routed_model=original_model,
        complexity=complexity,
    )
