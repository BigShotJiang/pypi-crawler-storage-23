"""Cost tracking and savings calculator."""

from __future__ import annotations

import json
import logging
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .types import Complexity, RequestRecord, SessionStats

logger = logging.getLogger(__name__)

try:
    from . import __version__ as _sdk_version
except ImportError:
    _sdk_version = "unknown"

# Default cost per 1K tokens (input) by model — rough estimates in USD
_MODEL_COST_INPUT: Dict[str, float] = {
    # tier1 — cheap
    "gpt-4o-mini": 0.00015,
    "gpt-4.1-mini": 0.00015,
    "gpt-4.1-nano": 0.0001,
    "gemini-2.5-flash": 0.0,
    "qwen2.5:32b": 0.0,
    # tier2 — mid
    "gpt-4o": 0.0025,
    "gpt-4.1": 0.002,
    "claude-sonnet-4-20250514": 0.003,
    "claude-3-5-haiku-20241022": 0.001,
    "gemini-2.5-pro": 0.0,
    # tier3 — expensive
    "gpt-4.5-preview": 0.075,
    "o3": 0.01,
    "claude-opus-4-6": 0.015,
    "gemini-3-pro-preview": 0.00125,
}

# Maximum number of request records kept in memory to prevent unbounded growth
_MAX_IN_MEMORY_RECORDS = 10000


def _safe_home_dir() -> Path:
    """Return the user's home directory, falling back to /tmp if unavailable."""
    try:
        return Path.home()
    except (RuntimeError, OSError):
        return Path("/tmp")  # noqa: S108


_DEFAULT_PERSIST_PATH = _safe_home_dir() / ".infershrink" / "stats.jsonl"


class Tracker:
    """Tracks request costs and calculates cumulative savings."""

    def __init__(
        self,
        config: Dict[str, Any] | None = None,
        persist_path: str | None = None,
    ) -> None:
        self._config = config or {}
        self._lock = threading.Lock()
        self._stats = SessionStats()

        # Edge telemetry
        self._edge_sync: Any = None
        self._init_edge_sync()

        # Persistence
        self._persist_path: Optional[Path] = None
        if persist_path is None:
            self._persist_path = _DEFAULT_PERSIST_PATH
        elif persist_path == "":
            # Explicit empty string = disable persistence
            self._persist_path = None
        else:
            self._persist_path = Path(persist_path)

    def _init_edge_sync(self) -> None:
        """Initialize edge telemetry sync if configured."""
        import os

        edge_cfg = self._config.get("telemetry", {}).get("edge", {})

        # Env vars override config
        enabled = os.environ.get("INFERSHRINK_EDGE_ENABLED", "").lower()
        if enabled == "false":
            return
        if enabled != "true" and not edge_cfg.get("enabled", False):
            return

        endpoint = os.environ.get("INFERSHRINK_EDGE_ENDPOINT", "") or edge_cfg.get("endpoint", "")
        token = os.environ.get("INFERSHRINK_EDGE_TOKEN", "")

        if not endpoint:
            return
        if not token:
            logger.warning("Edge telemetry enabled but INFERSHRINK_EDGE_TOKEN not set. Disabling.")
            return

        try:
            from .edge_sync import EdgeSync

            batch_size = int(edge_cfg.get("batch_size", 50))
            if batch_size < 1 or batch_size > 100:
                logger.warning(
                    "Edge telemetry batch_size %d out of range [1,100], clamping.",
                    batch_size,
                )

            self._edge_sync = EdgeSync(
                endpoint=endpoint,
                token=token,
                batch_size=batch_size,
                flush_interval_s=int(edge_cfg.get("flush_interval_s", 300)),
                sdk_version=str(_sdk_version),
            )
        except Exception:
            logger.debug("Failed to initialize edge telemetry sync", exc_info=True)

    @staticmethod
    def _extract_provider(model: str) -> str:
        """Extract provider name from model string."""
        model_lower = model.lower()
        if "gpt" in model_lower or "o3" in model_lower or "o1" in model_lower:
            return "openai"
        if "claude" in model_lower:
            return "anthropic"
        if "gemini" in model_lower:
            return "google"
        if "qwen" in model_lower:
            return "local"
        return "unknown"

    def _get_cost_per_1k(self, model: str) -> float:
        """Look up input cost per 1K tokens for a model."""
        # First check tier config for explicit costs
        tiers = self._config.get("tiers", {})
        for _tier_name, tier_cfg in tiers.items():
            if model in tier_cfg.get("models", []):
                return float(tier_cfg.get("cost_per_1k_input", 0.0))

        # Fall back to built-in table
        return float(_MODEL_COST_INPUT.get(model, 0.005))

    def _persist_record(self, record: RequestRecord) -> None:
        """Append a JSON line to the persist file."""
        if self._persist_path is None:
            return
        try:
            self._persist_path.parent.mkdir(parents=True, exist_ok=True)
            entry = {
                "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                "original_model": record.original_model,
                "routed_model": record.routed_model,
                "original_tokens": record.original_tokens,
                "compressed_tokens": record.compressed_tokens,
                "complexity": record.complexity.value,
                "cost_original": record.estimated_cost_original,
                "cost_routed": record.estimated_cost_routed,
                "savings": record.savings,
            }
            with open(self._persist_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + "\n")
        except OSError:
            logger.debug("Failed to persist record to %s", self._persist_path)

    def record(
        self,
        original_model: str,
        routed_model: str,
        original_tokens: int,
        compressed_tokens: int,
        complexity: Complexity,
    ) -> RequestRecord:
        """Record a single request and calculate savings.

        Returns the RequestRecord with computed costs.
        """
        cost_original = (original_tokens / 1000) * self._get_cost_per_1k(original_model)
        cost_routed = (compressed_tokens / 1000) * self._get_cost_per_1k(routed_model)
        savings = max(0.0, cost_original - cost_routed)

        record = RequestRecord(
            original_model=original_model,
            routed_model=routed_model,
            original_tokens=original_tokens,
            compressed_tokens=compressed_tokens,
            complexity=complexity,
            estimated_cost_original=cost_original,
            estimated_cost_routed=cost_routed,
            savings=savings,
        )

        with self._lock:
            self._stats.total_requests += 1
            self._stats.total_original_tokens += original_tokens
            self._stats.total_compressed_tokens += compressed_tokens
            self._stats.total_tokens_saved += max(0, original_tokens - compressed_tokens)
            self._stats.total_estimated_savings_usd += savings

            if original_model != routed_model:
                self._stats.requests_downgraded += 1
            if compressed_tokens < original_tokens:
                self._stats.requests_compressed += 1

            if self._stats.total_original_tokens > 0:
                self._stats.compression_ratio = (
                    self._stats.total_compressed_tokens / self._stats.total_original_tokens
                )

            # Cap in-memory records to prevent unbounded growth
            if len(self._stats.records) < _MAX_IN_MEMORY_RECORDS:
                self._stats.records.append(record)

        # Persist to disk (outside the lock)
        self._persist_record(record)

        # Edge telemetry (best-effort, never affects core functionality)
        if self._edge_sync is not None:
            try:
                import time as _time

                self._edge_sync.push(
                    {
                        "ts": int(_time.time() * 1000),
                        "complexity": complexity.value.lower(),
                        "original_model": original_model,
                        "routed_model": routed_model,
                        "was_downgraded": original_model != routed_model,
                        "provider": self._extract_provider(original_model),
                        "input_tokens": original_tokens,
                        "output_tokens": compressed_tokens,
                        "original_cost_usd": cost_original,
                        "actual_cost_usd": cost_routed,
                        "savings_usd": savings,
                        "latency_ms": 0,
                    }
                )
            except Exception:
                logger.debug("Edge telemetry push failed", exc_info=True)

        return record

    def stats(self) -> SessionStats:
        """Return current session statistics (snapshot)."""
        with self._lock:
            return SessionStats(
                total_requests=self._stats.total_requests,
                total_original_tokens=self._stats.total_original_tokens,
                total_compressed_tokens=self._stats.total_compressed_tokens,
                total_tokens_saved=self._stats.total_tokens_saved,
                total_estimated_savings_usd=self._stats.total_estimated_savings_usd,
                requests_downgraded=self._stats.requests_downgraded,
                requests_compressed=self._stats.requests_compressed,
                compression_ratio=self._stats.compression_ratio,
                records=list(self._stats.records),
            )

    def reset(self) -> None:
        """Reset all tracked statistics."""
        with self._lock:
            self._stats = SessionStats()

    def summary(self) -> str:
        """Return a human-readable summary of savings."""
        s = self.stats()
        pct_tokens = (1 - s.compression_ratio) * 100 if s.compression_ratio < 1 else 0
        return (
            f"InferShrink Session Stats\n"
            f"{'=' * 40}\n"
            f"Total requests:       {s.total_requests}\n"
            f"Requests downgraded:  {s.requests_downgraded}\n"
            f"Requests compressed:  {s.requests_compressed}\n"
            f"Original tokens:      {s.total_original_tokens:,}\n"
            f"Compressed tokens:    {s.total_compressed_tokens:,}\n"
            f"Tokens saved:         {s.total_tokens_saved:,} ({pct_tokens:.1f}%)\n"
            f"Estimated savings:    ${s.total_estimated_savings_usd:.4f}\n"
            f"{'=' * 40}"
        )

    # ── Persistent history methods ──

    def load_history(self) -> List[Dict[str, Any]]:
        """Read past records from the persist file."""
        if self._persist_path is None or not self._persist_path.exists():
            return []
        records = []
        try:
            with open(self._persist_path, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            records.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue
        except OSError:
            pass
        return records

    def lifetime_stats(self) -> Dict[str, Any]:
        """Aggregate ALL records (disk + current session)."""
        history = self.load_history()
        total_requests = len(history)
        total_original_tokens = 0
        total_compressed_tokens = 0
        total_savings = 0.0
        total_cost_original = 0.0
        total_cost_routed = 0.0

        for rec in history:
            total_original_tokens += rec.get("original_tokens", 0)
            total_compressed_tokens += rec.get("compressed_tokens", 0)
            total_savings += rec.get("savings", 0.0)
            total_cost_original += rec.get("cost_original", 0.0)
            total_cost_routed += rec.get("cost_routed", 0.0)

        compression_ratio = (
            total_compressed_tokens / total_original_tokens if total_original_tokens > 0 else 1.0
        )
        return {
            "total_requests": total_requests,
            "total_original_tokens": total_original_tokens,
            "total_compressed_tokens": total_compressed_tokens,
            "total_tokens_saved": total_original_tokens - total_compressed_tokens,
            "total_savings_usd": total_savings,
            "total_cost_original_usd": total_cost_original,
            "total_cost_routed_usd": total_cost_routed,
            "compression_ratio": compression_ratio,
        }

    def daily_stats(self, date: str) -> Dict[str, Any]:
        """Aggregate records for a specific date (YYYY-MM-DD)."""
        history = self.load_history()
        day_records = [r for r in history if r.get("timestamp", "").startswith(date)]
        return self._aggregate(day_records)

    def weekly_stats(self) -> List[Dict[str, Any]]:
        """Aggregate records per day for the last 7 days."""
        today = datetime.now(timezone.utc).date()
        results = []
        for i in range(7):
            d = today - timedelta(days=i)
            ds = d.isoformat()
            day = self.daily_stats(ds)
            day["date"] = ds
            results.append(day)
        return results

    @staticmethod
    def _aggregate(records: List[Dict[str, Any]]) -> Dict[str, Any]:
        total_requests = len(records)
        total_original = sum(r.get("original_tokens", 0) for r in records)
        total_compressed = sum(r.get("compressed_tokens", 0) for r in records)
        total_savings = sum(r.get("savings", 0.0) for r in records)
        return {
            "total_requests": total_requests,
            "total_original_tokens": total_original,
            "total_compressed_tokens": total_compressed,
            "total_tokens_saved": total_original - total_compressed,
            "total_savings_usd": total_savings,
        }
