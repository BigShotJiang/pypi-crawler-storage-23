"""CRDT sync client for pushing tracker data to Edge CRDT runtime."""

from __future__ import annotations

import atexit
import json
import logging
import threading
import time
import uuid
from queue import Empty, Queue
from typing import Any, Dict, List, Optional

from .types import RequestRecord

logger = logging.getLogger(__name__)

# SDK version - should match pyproject.toml
_SDK_VERSION = "0.2.1"

# Default endpoint
_DEFAULT_ENDPOINT = "https://musashi-runtime.musashi-labs.workers.dev"


class CRDTSync:
    """Sync client that pushes tracker records to Edge CRDT runtime.

    Records are batched and flushed periodically via a background thread.
    Supports retry with exponential backoff on failure.
    """

    def __init__(
        self,
        token: str,
        doc_id: str,
        endpoint: str = _DEFAULT_ENDPOINT,
        batch_size: int = 50,
        flush_interval: float = 60.0,
        enabled: bool = True,
        instance_id: Optional[str] = None,
    ) -> None:
        """Initialize the sync client.

        Args:
            token: Bearer token for authentication
            doc_id: Document ID (customer namespace)
            endpoint: Edge CRDT runtime URL
            batch_size: Max records per batch
            flush_interval: Seconds between flushes
            enabled: Whether sync is active
            instance_id: Unique instance ID (auto-generated if not provided)
        """
        self.endpoint = endpoint.rstrip("/")
        self.token = token
        self.doc_id = doc_id
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        self.enabled = enabled
        self.instance_id = instance_id or str(uuid.uuid4())

        self._queue: Queue[RequestRecord] = Queue()
        self._shutdown = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._pending: List[RequestRecord] = []

        # Stats
        self._total_pushed = 0
        self._total_failed = 0

        if self.enabled:
            self._start_background_thread()
            atexit.register(self.close)

    def _start_background_thread(self) -> None:
        """Start the background flush thread."""
        self._thread = threading.Thread(
            target=self._flush_loop,
            daemon=True,
            name="infershrink-crdt-sync",
        )
        self._thread.start()

    def _flush_loop(self) -> None:
        """Background loop that periodically flushes records."""
        while not self._shutdown.is_set():
            # Wait for flush interval or shutdown
            self._shutdown.wait(timeout=self.flush_interval)

            if self._shutdown.is_set():
                break

            self._do_flush()

        # Final flush on shutdown
        self._do_flush()

    def _do_flush(self) -> None:
        """Flush pending records to the server."""
        # Drain queue into pending list
        while True:
            try:
                record = self._queue.get_nowait()
                with self._lock:
                    self._pending.append(record)
            except Empty:
                break

        with self._lock:
            if not self._pending:
                return

            # Take up to batch_size records
            batch = self._pending[: self.batch_size]
            self._pending = self._pending[self.batch_size :]

        # Convert to events
        events = [self._record_to_event(r) for r in batch]

        # Send with retry
        success = self._send_with_retry(events)

        if success:
            self._total_pushed += len(events)
            logger.debug("Flushed %d events to CRDT", len(events))
        else:
            self._total_failed += len(events)
            logger.warning("Failed to flush %d events after retries", len(events))

    def _record_to_event(self, record: RequestRecord) -> Dict[str, Any]:
        """Convert a RequestRecord to the telemetry event format."""
        # Map complexity - server expects lowercase simple/moderate/complex
        complexity = record.complexity.value.lower()
        if complexity == "security_critical":
            complexity = "complex"

        return {
            "ts": int(time.time() * 1000),
            "complexity": complexity,
            "original_model": record.original_model,
            "routed_model": record.routed_model,
            "was_downgraded": record.routed_model != record.original_model,
            "provider": "infershrink",
            "input_tokens": record.original_tokens,
            "output_tokens": 0,
            "original_cost_usd": record.estimated_cost_original,
            "actual_cost_usd": record.estimated_cost_routed,
            "savings_usd": record.savings,
            "latency_ms": 0,
            "null_recovery": False,
            "error": None,
        }

    def _send_with_retry(self, events: List[Dict[str, Any]], max_retries: int = 3) -> bool:
        """Send events with exponential backoff retry."""
        import urllib.error
        import urllib.request

        url = f"{self.endpoint}/doc/{self.doc_id}/ingest"
        payload = json.dumps(
            {
                "meta": {
                    "instance_id": self.instance_id,
                    "sdk_version": _SDK_VERSION,
                },
                "events": events,
            }
        ).encode("utf-8")

        for attempt in range(max_retries):
            try:
                req = urllib.request.Request(  # noqa: S310
                    url,
                    data=payload,
                    headers={
                        "Authorization": f"Bearer {self.token}",
                        "Content-Type": "application/json",
                    },
                    method="POST",
                )

                with urllib.request.urlopen(req, timeout=30) as resp:  # noqa: S310
                    if resp.status == 200:
                        return True

            except urllib.error.HTTPError as e:
                if e.code == 429:
                    # Rate limited - wait longer
                    time.sleep(2 ** (attempt + 2))
                else:
                    logger.debug("HTTP error %d on attempt %d", e.code, attempt + 1)

            except urllib.error.URLError as e:
                logger.debug("URL error on attempt %d: %s", attempt + 1, e.reason)

            except Exception as e:
                logger.debug("Unexpected error on attempt %d: %s", attempt + 1, e)

            # Exponential backoff: 1s, 2s, 4s
            if attempt < max_retries - 1:
                time.sleep(2**attempt)

        return False

    def push(self, record: RequestRecord) -> None:
        """Queue a record for batch upload.

        Thread-safe. Records are batched and sent periodically.
        """
        if not self.enabled:
            return

        self._queue.put(record)

    def flush(self) -> None:
        """Force an immediate flush of pending records."""
        self._do_flush()

    def close(self) -> None:
        """Gracefully shutdown the sync client."""
        if self._shutdown.is_set():
            return

        self._shutdown.set()

        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=5.0)

        # Unregister atexit handler
        try:
            atexit.unregister(self.close)
        except Exception:  # noqa: S110
            pass

    @property
    def stats(self) -> Dict[str, int]:
        """Return sync statistics."""
        return {
            "total_pushed": self._total_pushed,
            "total_failed": self._total_failed,
            "pending": self._queue.qsize() + len(self._pending),
        }

    def __enter__(self) -> "CRDTSync":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
