"""Auth middleware for InferShrink MCP Server.

Supports:
- Bearer token auth (validates via license.py)
- x402 micropayment verification (USDC on Base via Coinbase facilitator)
- Unauthenticated → HTTP 402 with payment instructions

When running over stdio transport, auth is bypassed (local/trusted).
"""

from __future__ import annotations

import base64
import json
import logging
import os
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class AuthResult:
    """Result of authentication check."""

    authenticated: bool
    tier: str = "free"  # free, pro, team, admin
    client_id: str = ""
    method: str = ""  # "bearer", "x402", "none"
    error: str = ""


# x402 payment configuration
X402_PRICING = {
    "ingest": "0.001000",  # $0.001 per tool call (USDC, 6 decimals)
    "read": "0.000100",  # $0.0001 per read
}

X402_CHAIN_ID = 8453  # Base mainnet


def _get_seller_wallet() -> str:
    """Get the USDC receiving wallet address."""
    return os.environ.get("SELLER_WALLET", "")


def _build_402_payload() -> dict:
    """Build x402 PAYMENT-REQUIRED response payload."""
    wallet = _get_seller_wallet()
    return {
        "x402Version": 1,
        "accepts": [
            {
                "scheme": "exact",
                "network": "base-mainnet",
                "maxAmountRequired": X402_PRICING["ingest"],
                "resource": "infershrink-mcp",
                "description": "InferShrink MCP tool call",
                "mimeType": "application/json",
                "payTo": wallet,
                "extra": {
                    "name": "USDC",
                    "chainId": X402_CHAIN_ID,
                },
            }
        ],
    }


def build_402_header() -> str:
    """Build base64-encoded PAYMENT-REQUIRED header value."""
    payload = _build_402_payload()
    return base64.b64encode(json.dumps(payload).encode()).decode()


def authenticate_bearer(token: str) -> AuthResult:
    """Validate a Bearer token.

    Uses InferShrink's license validation if available,
    otherwise checks against INFERSHRINK_API_KEY env var.
    """
    if not token:
        return AuthResult(authenticated=False, method="bearer", error="Empty token")

    # Simple env-based auth for now
    expected = os.environ.get("INFERSHRINK_API_KEY", "")
    admin_key = os.environ.get("INFERSHRINK_ADMIN_KEY", "")

    import hmac

    if admin_key and hmac.compare_digest(token, admin_key):
        return AuthResult(authenticated=True, tier="admin", client_id="admin", method="bearer")

    if expected and hmac.compare_digest(token, expected):
        return AuthResult(authenticated=True, tier="pro", client_id="api-key", method="bearer")

    # Try license.py validation if available
    try:
        from .license import validate

        result = validate(token)
        if result.valid:
            return AuthResult(
                authenticated=True,
                tier=result.tier or "pro",
                client_id=result.customer_email or "license",
                method="bearer",
            )
    except ImportError:
        pass
    except Exception:
        logger.debug("License validation failed", exc_info=True)

    return AuthResult(
        authenticated=False,
        method="bearer",
        error="Invalid API key. Get one at musashi-labs.lemonsqueezy.com",
    )


def authenticate_x402(payment_proof: str) -> AuthResult:
    """Verify an x402 payment proof.

    In production, this calls the Coinbase x402 facilitator to verify
    the payment was made. For now, accepts any non-empty proof as valid
    (facilitator integration in Task 2 of x402 spec).
    """
    if not payment_proof:
        return AuthResult(authenticated=False, method="x402", error="Empty payment proof")

    wallet = _get_seller_wallet()
    if not wallet:
        return AuthResult(
            authenticated=False,
            method="x402",
            error="x402 payments not configured (no SELLER_WALLET)",
        )

    # TODO: Verify via Coinbase facilitator endpoint
    # For now, accept non-empty proof (matches edge-crdt-runtime behavior)
    return AuthResult(authenticated=True, tier="pro", client_id="x402-payer", method="x402")


def authenticate(
    bearer_token: Optional[str] = None,
    x402_proof: Optional[str] = None,
) -> AuthResult:
    """Authenticate a request using available credentials.

    Priority: Bearer token > x402 payment > unauthenticated (402).
    """
    # Try Bearer first
    if bearer_token:
        result = authenticate_bearer(bearer_token)
        if result.authenticated:
            return result

    # Try x402
    if x402_proof:
        result = authenticate_x402(x402_proof)
        if result.authenticated:
            return result

    # Unauthenticated — still allowed at free tier
    return AuthResult(
        authenticated=True,
        tier="free",
        client_id="anonymous",
        method="none",
    )
