"""InferShrink — Cut LLM costs 80%+ with one package.

Smart retrieval, prompt compression, model routing — one package.

Usage::

    import openai
    from infershrink import optimize

    client = optimize(openai.Client())
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Hello!"}],
    )
    # InferShrink automatically compressed the prompt and routed
    # to the cheapest model that can handle this simple request.

    # Check savings:
    print(client.infershrink_tracker.summary())

Full stack (with retrieval)::

    from infershrink import TokenShrink, optimize

    # Build a retrieval index
    ts = TokenShrink()
    ts.index("./docs")
    result = ts.query("What are the API limits?")
    print(result.context)       # Compressed, relevant context
    print(result.savings)       # "Saved 72% (1200 → 336 tokens)"
"""

from .classifier import classify
from .compressor import compress
from .config import DEFAULT_CONFIG, build_config
from .router import route
from .tracker import Tracker
from .types import (
    ClassificationResult,
    Complexity,
    CompressionResult,
    RequestRecord,
    RoutingDecision,
    SessionStats,
)
from .wrapper import InferShrinkClient, optimize

__version__ = "0.2.8"


# Lazy imports for retrieval module (requires heavy optional deps: faiss, sentence-transformers)
_RETRIEVAL_NAMES = frozenset({"TokenShrink", "ShrinkResult", "ChunkScore"})


def _make_retrieval_stub(class_name: str):
    """Create a placeholder that raises ImportError when instantiated."""

    def _init(self, *args, **kwargs):
        raise ImportError(
            f"'{class_name}' requires retrieval dependencies. "
            "Install with: pip install infershrink[retrieval]"
        )

    return type(class_name, (), {"__init__": _init})


def __getattr__(name):
    if name in _RETRIEVAL_NAMES:
        try:
            from .retrieval import ChunkScore, ShrinkResult, TokenShrink

            globals().update(
                {
                    "TokenShrink": TokenShrink,
                    "ShrinkResult": ShrinkResult,
                    "ChunkScore": ChunkScore,
                }
            )
            return globals()[name]
        except ImportError:
            # Deps not installed — return stubs so hasattr() works
            # but instantiation raises a clear ImportError
            stub = _make_retrieval_stub(name)
            globals()[name] = stub
            return stub
    raise AttributeError(f"module 'infershrink' has no attribute {name!r}")


__all__ = [
    # Core (zero-dep)
    "optimize",
    "InferShrinkClient",
    "classify",
    "compress",
    "route",
    "Tracker",
    "build_config",
    "DEFAULT_CONFIG",
    "Complexity",
    "ClassificationResult",
    "CompressionResult",
    "RoutingDecision",
    "RequestRecord",
    "SessionStats",
    # Retrieval (optional deps: faiss-cpu, sentence-transformers)
    "TokenShrink",
    "ShrinkResult",
    "ChunkScore",
    # Meta
    "__version__",
]
