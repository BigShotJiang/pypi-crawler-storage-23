"""InferShrink Hosted API Client.

Use InferShrink via the hosted API with optional x402 micropayments.
No signup, no API keys — just call the API.

Usage with subscription token (recommended)::

    from infershrink.hosted import InferShrinkClient

    client = InferShrinkClient(token="isub_...")
    result = client.classify("What is 2+2?")
    print(result)  # {'complexity': 'SIMPLE', ...}

Usage with Bearer token (admin/provisioned)::

    client = InferShrinkClient(token="crdt_...")

Usage without auth (returns 402 with payment instructions)::

    client = InferShrinkClient()
    info = client.payment_info()  # Get pricing and payment details
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any, Optional

DEFAULT_BASE_URL = "https://musashi-runtime.musashi-labs.workers.dev"


class InferShrinkClient:
    """HTTP client for the InferShrink hosted API.

    Args:
        token: Bearer token (subscription isub_* or admin token).
        base_url: API base URL. Defaults to the public InferShrink API.
    """

    def __init__(
        self,
        token: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
    ):
        self.base_url = base_url.rstrip("/")
        self.token = token

    def _request(self, method: str, path: str, body: Optional[dict] = None) -> dict[str, Any]:
        """Make an HTTP request to the API."""
        url = f"{self.base_url}{path}"
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"

        data = json.dumps(body).encode() if body else None
        req = urllib.request.Request(url, data=data, headers=headers, method=method)  # noqa: S310

        try:
            with urllib.request.urlopen(req) as resp:  # noqa: S310
                result: dict[str, Any] = json.loads(resp.read().decode())
                return result
        except urllib.error.HTTPError as e:
            body_text = e.read().decode() if e.fp else ""
            try:
                error_data = json.loads(body_text)
            except (json.JSONDecodeError, ValueError):
                error_data = {"error": body_text}

            if e.code == 402:
                # Payment required — include payment info
                payment_header = e.headers.get("PAYMENT-REQUIRED", "")
                if payment_header:
                    try:
                        import base64

                        payment_info = json.loads(base64.b64decode(payment_header))
                        error_data["payment_info"] = payment_info
                    except Exception:  # noqa: S110
                        pass
                raise PaymentRequired(error_data) from e
            raise APIError(e.code, error_data) from e

    def classify(self, prompt: str) -> dict[str, Any]:
        """Classify a prompt's complexity.

        Args:
            prompt: The prompt text to classify.

        Returns:
            dict with complexity, reason, estimated_tokens, signals.

        Raises:
            PaymentRequired: If no token and x402 payment needed.
            APIError: On other HTTP errors.
        """
        return self._request("POST", "/classify", {"prompt": prompt})

    def route(
        self,
        model: str,
        prompt: Optional[str] = None,
        complexity: Optional[str] = None,
    ) -> dict[str, Any]:
        """Route to optimal model based on complexity.

        Args:
            model: Current model name (e.g., 'gpt-4o').
            prompt: Prompt text for auto-classification.
            complexity: Explicit complexity (SIMPLE/MODERATE/COMPLEX/SECURITY_CRITICAL).

        Returns:
            dict with routed_model, original_model, was_downgraded, savings_estimate.
        """
        body: dict[str, Any] = {"model": model}
        if complexity:
            body["complexity"] = complexity
        elif prompt:
            body["prompt"] = prompt
        else:
            raise ValueError("Either prompt or complexity is required")
        return self._request("POST", "/route", body)

    def subscribe(self) -> dict[str, Any]:
        """Subscribe to get 1000 API credits ($1.01 via x402).

        This endpoint requires x402 payment. Use an x402-compatible
        HTTP client or pay manually.

        Returns:
            dict with token, credits, expires_at.
        """
        return self._request("POST", "/subscribe", {})

    def payment_info(self) -> dict[str, Any]:
        """Get payment information for the API.

        Returns pricing, network, and payment instructions.
        """
        try:
            return self._request("POST", "/classify", {"prompt": "test"})
        except PaymentRequired as e:
            return e.details


class PaymentRequired(Exception):
    """Raised when x402 payment is required."""

    def __init__(self, details: dict):
        self.details = details
        price = details.get("price", "unknown")
        super().__init__(
            f"Payment required: {price}. Subscribe at POST /subscribe ($1.01 for 1000 credits)"
        )


class APIError(Exception):
    """Raised on API errors."""

    def __init__(self, status: int, details: dict):
        self.status = status
        self.details = details
        super().__init__(f"API error {status}: {details.get('error', 'Unknown')}")
