# InferShrink — Dockerized Use Case Tests

Each use case runs in Docker to prove InferShrink works in real-world agent scenarios.

## Use Cases

### 1. Research Assistant (RAG)
Agent answers questions from a knowledge base (PDFs, docs).
- InferShrink retrieves relevant chunks, compresses, routes simple Q&A to cheap model
- **Test:** 50 questions against a 100-doc corpus, measure cost vs baseline

### 2. Coding Assistant
Agent generates, reviews, and debugs code.
- Simple completions (docstrings, type hints) → cheap model
- Complex refactors → strong model
- **Test:** 30 coding tasks of varying complexity

### 3. Customer Support Bot
Agent handles support tickets with tool calls (lookup order, check status).
- Simple "what's my order status?" → cheap model
- Complex "I was charged twice and need a refund" → strong model
- **Test:** 40 support scenarios with mock tools

### 4. Data Analysis Pipeline
Agent processes CSV/JSON data, generates summaries and charts.
- Simple transforms → cheap model
- Statistical analysis with interpretation → strong model
- **Test:** 20 data tasks (clean, transform, analyze, summarize)

### 5. Content Generation
Agent writes blog posts, emails, social media content.
- Short social posts → cheap model
- Long-form articles with research → strong model
- **Test:** 25 content generation tasks

### 6. Multi-Agent Workflow
Multiple agents coordinate (planner → researcher → writer → reviewer).
- Each agent's prompts get individually classified and routed
- **Test:** 10 end-to-end multi-agent workflows

## Docker Structure

```
tests/integration/
├── docker-compose.yml          # Runs all scenarios
├── Dockerfile                  # Python 3.12 + infershrink + test deps
├── scenarios/
│   ├── research_assistant/
│   │   ├── corpus/             # Test documents
│   │   ├── questions.json      # Test questions
│   │   └── test_research.py    # Scenario runner
│   ├── coding_assistant/
│   │   ├── tasks.json
│   │   └── test_coding.py
│   ├── customer_support/
│   │   ├── tickets.json
│   │   ├── mock_tools.py
│   │   └── test_support.py
│   ├── data_analysis/
│   │   ├── datasets/
│   │   └── test_analysis.py
│   ├── content_generation/
│   │   ├── prompts.json
│   │   └── test_content.py
│   └── multi_agent/
│       ├── workflows.json
│       └── test_multi_agent.py
├── conftest.py                 # Shared fixtures
├── baseline.py                 # Run without InferShrink (baseline cost)
└── report.py                   # Compare baseline vs InferShrink savings
```

## Metrics Per Scenario

- Total requests
- Requests routed to cheaper model
- Tokens before/after compression
- Estimated cost with InferShrink vs without
- % savings
- Quality score (did the output match expected?)
