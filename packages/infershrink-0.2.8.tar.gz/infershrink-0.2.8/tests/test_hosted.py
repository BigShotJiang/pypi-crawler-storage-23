"""Tests for the hosted API client."""

from __future__ import annotations

import json
import urllib.error
from unittest.mock import MagicMock, patch

import pytest

from infershrink.hosted import APIError, InferShrinkClient, PaymentRequired


class TestInferShrinkClient:
    """Test the hosted API client."""

    def test_init_defaults(self):
        client = InferShrinkClient()
        assert client.base_url == "https://musashi-runtime.musashi-labs.workers.dev"
        assert client.token is None

    def test_init_with_token(self):
        test_token = "isub_test123"  # noqa: S105
        client = InferShrinkClient(token=test_token)
        assert client.token == test_token

    def test_init_custom_url(self):
        client = InferShrinkClient(base_url="http://localhost:8787/")
        assert client.base_url == "http://localhost:8787"  # trailing slash stripped

    @patch("infershrink.hosted.urllib.request.urlopen")
    def test_classify_success(self, mock_urlopen):
        response_data = {
            "complexity": "SIMPLE",
            "reason": "Short prompt",
            "estimated_tokens": 5,
            "signals": {},
        }
        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps(response_data).encode()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        client = InferShrinkClient(token="isub_test")
        result = client.classify("Hello")

        assert result["complexity"] == "SIMPLE"
        assert result["estimated_tokens"] == 5

    @patch("infershrink.hosted.urllib.request.urlopen")
    def test_classify_sends_auth_header(self, mock_urlopen):
        mock_resp = MagicMock()
        mock_resp.read.return_value = b'{"complexity":"SIMPLE"}'
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        client = InferShrinkClient(token="isub_mytoken")
        client.classify("test")

        # Check the Request object passed to urlopen
        call_args = mock_urlopen.call_args
        req = call_args[0][0]
        assert req.get_header("Authorization") == "Bearer isub_mytoken"

    @patch("infershrink.hosted.urllib.request.urlopen")
    def test_classify_payment_required(self, mock_urlopen):
        error_body = json.dumps({"error": "Payment required", "price": "$0.001 USDC"}).encode()
        http_error = urllib.error.HTTPError(
            url="https://example.com/classify",
            code=402,
            msg="Payment Required",
            hdrs=MagicMock(get=lambda k, d=None: None),  # type: ignore
            fp=MagicMock(read=MagicMock(return_value=error_body)),
        )
        mock_urlopen.side_effect = http_error

        client = InferShrinkClient()
        with pytest.raises(PaymentRequired) as exc_info:
            client.classify("test")

        assert "Payment required" in str(exc_info.value)
        assert exc_info.value.details["price"] == "$0.001 USDC"

    @patch("infershrink.hosted.urllib.request.urlopen")
    def test_route_with_prompt(self, mock_urlopen):
        response_data = {
            "original_model": "gpt-4o",
            "routed_model": "gpt-4o-mini",
            "was_downgraded": True,
        }
        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps(response_data).encode()
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        client = InferShrinkClient(token="test")
        result = client.route("gpt-4o", prompt="Hello")

        assert result["routed_model"] == "gpt-4o-mini"
        assert result["was_downgraded"] is True

    def test_route_requires_prompt_or_complexity(self):
        client = InferShrinkClient(token="test")
        with pytest.raises(ValueError, match="Either prompt or complexity"):
            client.route("gpt-4o")

    @patch("infershrink.hosted.urllib.request.urlopen")
    def test_api_error(self, mock_urlopen):
        error_body = json.dumps({"error": "Server error"}).encode()
        http_error = urllib.error.HTTPError(
            url="https://example.com/classify",
            code=500,
            msg="Internal Server Error",
            hdrs=MagicMock(),  # type: ignore
            fp=MagicMock(read=MagicMock(return_value=error_body)),
        )
        mock_urlopen.side_effect = http_error

        client = InferShrinkClient(token="test")
        with pytest.raises(APIError) as exc_info:
            client.classify("test")

        assert exc_info.value.status == 500
