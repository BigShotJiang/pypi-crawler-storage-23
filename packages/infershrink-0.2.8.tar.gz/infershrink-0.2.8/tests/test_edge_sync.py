"""Tests for edge telemetry sync."""
# ruff: noqa: S106

from __future__ import annotations

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any, Dict, List
from unittest.mock import patch

import pytest

from infershrink.edge_sync import EdgeSync, _compute_instance_id, _validate_event

# --- Helpers ---


class MockIngestHandler(BaseHTTPRequestHandler):
    """Mock HTTP handler that records requests."""

    requests: List[Dict[str, Any]] = []
    response_code: int = 200
    response_body: bytes = b'{"ok":true,"eventsIngested":1,"version":1}'

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        MockIngestHandler.requests.append(
            {
                "path": self.path,
                "body": json.loads(body) if body else None,
                "auth": self.headers.get("Authorization"),
            }
        )
        self.send_response(MockIngestHandler.response_code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(MockIngestHandler.response_body)

    def log_message(self, *args: Any) -> None:  # noqa: ANN401
        pass  # Silence logs


@pytest.fixture()
def mock_server():
    """Start a mock HTTP server for testing."""
    MockIngestHandler.requests = []
    MockIngestHandler.response_code = 200
    MockIngestHandler.response_body = b'{"ok":true,"eventsIngested":1,"version":1}'

    server = HTTPServer(("127.0.0.1", 0), MockIngestHandler)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


def make_event(**overrides: Any) -> Dict[str, Any]:
    """Create a valid telemetry event."""
    base = {
        "ts": int(time.time() * 1000),
        "complexity": "simple",
        "original_model": "gpt-4o",
        "routed_model": "gpt-4o-mini",
        "was_downgraded": True,
        "provider": "openai",
        "input_tokens": 1200,
        "output_tokens": 340,
        "original_cost_usd": 0.0035,
        "actual_cost_usd": 0.0002,
        "savings_usd": 0.0033,
        "latency_ms": 820,
    }
    base.update(overrides)
    return base


# --- Unit Tests ---


class TestValidateEvent:
    def test_strips_unknown_fields(self) -> None:
        event = make_event(messages="secret", prompt="also secret", foo="bar")
        cleaned = _validate_event(event)
        assert "messages" not in cleaned
        assert "prompt" not in cleaned
        assert "foo" not in cleaned
        assert cleaned["ts"] == event["ts"]

    def test_keeps_all_allowed_fields(self) -> None:
        event = make_event(null_recovery=True, error="timeout")
        cleaned = _validate_event(event)
        assert cleaned["null_recovery"] is True
        assert cleaned["error"] == "timeout"

    def test_keeps_required_fields(self) -> None:
        event = make_event()
        cleaned = _validate_event(event)
        assert len(cleaned) == 12  # 12 required fields


class TestComputeInstanceId:
    def test_no_key_returns_dev(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            assert _compute_instance_id("") == "dev"
            assert _compute_instance_id(None) == "dev"

    def test_with_key_returns_hash(self) -> None:
        result = _compute_instance_id("test-key-123")
        assert result != "dev"
        assert len(result) == 16

    def test_deterministic(self) -> None:
        a = _compute_instance_id("my-key")
        b = _compute_instance_id("my-key")
        assert a == b


class TestEdgeSyncBatching:
    def test_events_queue_up_to_batch_size(self, mock_server: str) -> None:
        sync = EdgeSync(
            endpoint=mock_server,
            token="test-token",
            batch_size=5,
            flush_interval_s=9999,  # disable timer
        )
        for _ in range(4):
            sync.push(make_event())
        # Should NOT have flushed yet (4 < 5)
        assert len(MockIngestHandler.requests) == 0
        sync.close()

    def test_flush_on_batch_size(self, mock_server: str) -> None:
        sync = EdgeSync(
            endpoint=mock_server,
            token="test-token",
            batch_size=3,
            flush_interval_s=9999,
        )
        for _ in range(3):
            sync.push(make_event())
        time.sleep(0.1)  # Allow flush to complete
        assert len(MockIngestHandler.requests) >= 1
        body = MockIngestHandler.requests[0]["body"]
        assert len(body["events"]) == 3
        sync.close()

    def test_manual_flush(self, mock_server: str) -> None:
        sync = EdgeSync(
            endpoint=mock_server,
            token="test-token",
            batch_size=100,
            flush_interval_s=9999,
        )
        sync.push(make_event())
        assert sync.flush() is True
        assert len(MockIngestHandler.requests) == 1
        sync.close()


class TestEdgeSyncFailure:
    def test_three_failures_disables(self, mock_server: str) -> None:
        MockIngestHandler.response_code = 500
        sync = EdgeSync(
            endpoint=mock_server,
            token="test-token",
            batch_size=1,
            flush_interval_s=9999,
            max_queue=100,
        )
        for _ in range(3):
            sync.push(make_event())
            time.sleep(0.05)

        assert sync._disabled is True
        sync.close()

    def test_429_disables_until_next_day(self, mock_server: str) -> None:
        MockIngestHandler.response_code = 429
        MockIngestHandler.response_body = b'{"error":"rate limited"}'
        sync = EdgeSync(
            endpoint=mock_server,
            token="test-token",
            batch_size=1,
            flush_interval_s=9999,
        )
        sync.push(make_event())
        time.sleep(0.1)
        assert sync._disabled_until is not None
        assert sync._disabled_until > time.time()
        sync.close()


class TestEdgeSyncDisabled:
    def test_disabled_no_network(self) -> None:
        sync = EdgeSync(
            endpoint="http://should-never-connect:9999",
            token="test-token",
            batch_size=50,
            flush_interval_s=9999,
        )
        sync._disabled = True
        sync.push(make_event())
        # Should not raise or make any network call
        assert sync.flush() is False
        sync.close()


class TestEdgeSyncThreadSafety:
    def test_concurrent_push(self, mock_server: str) -> None:
        sync = EdgeSync(
            endpoint=mock_server,
            token="test-token",
            batch_size=1000,  # Don't auto-flush by batch
            flush_interval_s=99999,
        )
        errors: List[Exception] = []

        def push_many() -> None:
            try:
                for _ in range(100):
                    sync.push(make_event())
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=push_many) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0
        # All 500 events should be queued (no auto-flush triggered)
        with sync._lock:
            queue_len = len(sync._queue)
        # May have been flushed by timer — check total (queued + sent)
        total = queue_len + sum(len(r["body"]["events"]) for r in MockIngestHandler.requests)
        assert total == 500
        sync.close()


class TestEdgeSyncQueueOverflow:
    def test_drops_oldest_on_overflow(self, mock_server: str) -> None:
        sync = EdgeSync(
            endpoint=mock_server,
            token="test-token",
            batch_size=1000,
            flush_interval_s=9999,
            max_queue=10,
        )
        for i in range(15):
            sync.push(make_event(ts=i + 1))

        with sync._lock:
            assert len(sync._queue) == 10
            # Oldest should be dropped, newest kept
            assert sync._queue[0]["ts"] == 6
        sync.close()


class TestEdgeSyncAuth:
    def test_sends_bearer_token(self, mock_server: str) -> None:
        sync = EdgeSync(
            endpoint=mock_server,
            token="my-secret-token",
            batch_size=1,
            flush_interval_s=9999,
        )
        sync.push(make_event())
        time.sleep(0.1)
        assert len(MockIngestHandler.requests) >= 1
        assert MockIngestHandler.requests[0]["auth"] == "Bearer my-secret-token"
        sync.close()


class TestEdgeSyncDocId:
    def test_doc_id_format(self, mock_server: str) -> None:
        sync = EdgeSync(
            endpoint=mock_server,
            token="test-token",
            instance_id="test-inst",
            batch_size=100,
            flush_interval_s=9999,
        )
        sync.push(make_event())
        sync.flush()
        assert len(MockIngestHandler.requests) == 1
        path = MockIngestHandler.requests[0]["path"]
        assert path.startswith("/doc/telemetry:test-inst:")
        assert "/ingest" in path
        sync.close()


class TestEdgeSyncConfig:
    def test_env_var_override(self) -> None:
        """Verify _compute_instance_id reads from env."""
        with patch.dict("os.environ", {"INFERSHRINK_LICENSE_KEY": "test-key"}):
            result = _compute_instance_id()
            assert result != "dev"
            assert len(result) == 16

    def test_batch_size_clamped(self, mock_server: str) -> None:
        sync = EdgeSync(
            endpoint=mock_server,
            token="test-token",
            batch_size=200,  # Over max
            flush_interval_s=9999,
        )
        assert sync._batch_size == 100
        sync.close()

        sync2 = EdgeSync(
            endpoint=mock_server,
            token="test-token",
            batch_size=0,  # Under min
            flush_interval_s=9999,
        )
        assert sync2._batch_size == 1
        sync2.close()
