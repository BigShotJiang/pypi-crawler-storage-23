"""Integration tests — full pipeline: classify → compress → route → track."""

from unittest.mock import MagicMock

from infershrink import Tracker, build_config, classify, compress, optimize, route
from infershrink.types import Complexity


class MockCompletions:
    def create(self, **kwargs):
        self._last_kwargs = kwargs
        return MagicMock(
            choices=[MagicMock(message=MagicMock(content="OK", role="assistant"))],
            model=kwargs.get("model"),
        )


class MockChat:
    def __init__(self):
        self.completions = MockCompletions()


class MockOpenAIClient:
    def __init__(self):
        self.chat = MockChat()


class MockAnthropicMessages:
    def create(self, **kwargs):
        self._last_kwargs = kwargs
        return MagicMock(
            content=[MagicMock(text="OK", type="text")],
            model=kwargs.get("model"),
        )


class MockAnthropicClient:
    def __init__(self):
        self.messages = MockAnthropicMessages()

    class __class__:
        __module__ = "anthropic"
        __name__ = "Anthropic"


class TestFullPipelineOpenAI:
    """Test the full pipeline through the OpenAI wrapper."""

    def test_simple_message_routed_and_tracked(self):
        """Simple greeting → classify(SIMPLE) → no compress → route(tier1) → track."""
        mock = MockOpenAIClient()
        client = optimize(mock)

        client.chat.completions.create(
            model="gpt-4o",  # tier2 OpenAI
            messages=[{"role": "user", "content": "Hello!"}],
        )

        # Model was downgraded to tier1 (same provider: gpt-4o-mini)
        assert mock.chat.completions._last_kwargs["model"] == "gpt-4o-mini"

        # Tracker recorded it
        stats = client.infershrink_tracker.stats()
        assert stats.total_requests == 1
        assert stats.requests_downgraded == 1
        assert stats.total_estimated_savings_usd > 0

    def test_complex_message_not_downgraded(self):
        """Complex message → classify(COMPLEX) → route(tier3) → track."""
        mock = MockOpenAIClient()
        client = optimize(mock)

        code = "```python\n" + "x = 1\n" * 100 + "```\n"
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": f"Step by step review:\n{code * 3}"}],
        )

        assert mock.chat.completions._last_kwargs["model"] == "claude-opus-4-6"
        stats = client.infershrink_tracker.stats()
        assert stats.requests_downgraded == 0

    def test_security_message_never_downgraded(self):
        """Security-critical → classify(SECURITY_CRITICAL) → route(keep) → track."""
        mock = MockOpenAIClient()
        client = optimize(mock)

        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "My api_key is sk-secret123, encrypt it."}],
        )

        assert mock.chat.completions._last_kwargs["model"] == "claude-opus-4-6"
        stats = client.infershrink_tracker.stats()
        assert stats.requests_downgraded == 0

    def test_moderate_message_partial_downgrade(self):
        """Moderate complexity from tier3 → downgrade to tier2 (same provider)."""
        mock = MockOpenAIClient()
        client = optimize(mock)

        client.chat.completions.create(
            model="gpt-4.5-preview",  # tier3 OpenAI
            messages=[{"role": "user", "content": "Explain this:\n```python\nprint('hello')\n```"}],
        )

        # tier3 OpenAI + MODERATE → tier2 OpenAI (gpt-4o)
        assert mock.chat.completions._last_kwargs["model"] == "gpt-4o"
        stats = client.infershrink_tracker.stats()
        assert stats.requests_downgraded == 1

    def test_mixed_requests_accumulated(self):
        """Multiple requests of different complexities."""
        mock = MockOpenAIClient()
        client = optimize(mock)

        # Simple
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
        )

        # Complex
        code = "```python\n" + "x = 1\n" * 100 + "```\n"
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": f"Step by step:\n{code * 3}"}],
        )

        # Security
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Store this password: abc123"}],
        )

        stats = client.infershrink_tracker.stats()
        assert stats.total_requests == 3
        assert stats.requests_downgraded == 1  # Only the simple one
        assert stats.total_estimated_savings_usd > 0

    def test_savings_summary_readable(self):
        mock = MockOpenAIClient()
        client = optimize(mock)

        for _ in range(5):
            client.chat.completions.create(
                model="claude-opus-4-6",
                messages=[{"role": "user", "content": "What is 2+2?"}],
            )

        summary = client.infershrink_tracker.summary()
        assert "Total requests:       5" in summary
        assert "Estimated savings:" in summary


class TestFullPipelineAnthropic:
    """Test the full pipeline through the Anthropic wrapper."""

    def test_simple_message_routed(self):
        mock = MockAnthropicClient()
        client = optimize(mock)

        client.messages.create(
            model="claude-opus-4-6",  # tier3 Anthropic
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello!"}],
        )

        # tier3 Anthropic + SIMPLE → tier2 Anthropic (no anthropic in tier1)
        routed = mock.messages._last_kwargs["model"]
        assert routed in ["claude-sonnet-4-20250514", "claude-3-5-haiku-20241022"]
        stats = client.infershrink_tracker.stats()
        assert stats.requests_downgraded == 1

    def test_security_via_system_prompt(self):
        """Security keywords in Anthropic system prompt should prevent downgrade."""
        mock = MockAnthropicClient()
        client = optimize(mock)

        client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1024,
            system="You handle API credentials and tokens securely.",
            messages=[{"role": "user", "content": "Help me set up auth"}],
        )

        assert mock.messages._last_kwargs["model"] == "claude-opus-4-6"


class TestManualPipeline:
    """Test the classify → compress → route → track pipeline manually (no wrapper)."""

    def test_manual_simple_pipeline(self):
        config = build_config()
        messages = [{"role": "user", "content": "What is the capital of France?"}]

        classification = classify(messages)
        assert classification.complexity == Complexity.SIMPLE

        compression = compress(messages, classification.complexity, config)
        assert compression.was_compressed is False

        # gpt-4o (tier2) + SIMPLE → gpt-4o-mini (tier1, same provider)
        routing = route("gpt-4o", classification.complexity, config)
        assert routing.routed_model == "gpt-4o-mini"
        assert routing.was_downgraded is True

        tracker = Tracker(config, persist_path="")
        record = tracker.record(
            original_model="gpt-4o",
            routed_model=routing.routed_model,
            original_tokens=compression.original_tokens,
            compressed_tokens=compression.compressed_tokens,
            complexity=classification.complexity,
        )
        assert record.savings > 0

    def test_manual_complex_pipeline(self):
        config = build_config()
        code = "```python\n" + "x = 1\n" * 100 + "```\n"
        messages = [{"role": "user", "content": f"Debug this step by step:\n{code * 3}"}]

        classification = classify(messages)
        assert classification.complexity == Complexity.COMPLEX

        compress(messages, classification.complexity, config)

        routing = route("claude-opus-4-6", classification.complexity, config)
        assert routing.routed_model == "claude-opus-4-6"
        assert routing.was_downgraded is False

    def test_manual_security_pipeline(self):
        config = build_config()
        messages = [{"role": "user", "content": "Encrypt my password: hunter2"}]

        classification = classify(messages)
        assert classification.complexity == Complexity.SECURITY_CRITICAL

        compression = compress(messages, classification.complexity, config)
        assert compression.was_compressed is False

        routing = route("claude-opus-4-6", classification.complexity, config)
        assert routing.routed_model == "claude-opus-4-6"

    def test_savings_calculation_end_to_end(self):
        """Verify that reported savings match manual calculation."""
        config = build_config()
        tracker = Tracker(config, persist_path="")

        # Simulate 100 simple requests routed from gpt-4o (tier2) to gpt-4o-mini (tier1)
        for _ in range(100):
            tracker.record(
                original_model="gpt-4o",
                routed_model="gpt-4o-mini",
                original_tokens=100,
                compressed_tokens=100,
                complexity=Complexity.SIMPLE,
            )

        stats = tracker.stats()
        # gpt-4o: tier2 cost 0.0025/1k, gpt-4o-mini: tier1 cost 0.00015/1k
        # Original: 100 requests × (100/1000) × 0.0025 = 0.025
        # Routed:   100 requests × (100/1000) × 0.00015 = 0.0015
        # Savings:  0.0235
        assert stats.total_estimated_savings_usd > 0.02


class TestModuleExports:
    """Test that __init__.py exports everything correctly."""

    def test_all_exports_importable(self):
        import infershrink

        assert hasattr(infershrink, "optimize")
        assert hasattr(infershrink, "InferShrinkClient")
        assert hasattr(infershrink, "classify")
        assert hasattr(infershrink, "compress")
        assert hasattr(infershrink, "route")
        assert hasattr(infershrink, "Tracker")
        assert hasattr(infershrink, "build_config")
        assert hasattr(infershrink, "DEFAULT_CONFIG")
        assert hasattr(infershrink, "Complexity")
        assert hasattr(infershrink, "ClassificationResult")
        assert hasattr(infershrink, "CompressionResult")
        assert hasattr(infershrink, "RoutingDecision")
        assert hasattr(infershrink, "RequestRecord")
        assert hasattr(infershrink, "SessionStats")
        assert hasattr(infershrink, "__version__")

    def test_version_is_string(self):
        import infershrink

        assert isinstance(infershrink.__version__, str)
        assert len(infershrink.__version__) > 0

    def test_all_list_matches_exports(self):
        import infershrink

        for name in infershrink.__all__:
            assert hasattr(infershrink, name), f"{name} in __all__ but not importable"
