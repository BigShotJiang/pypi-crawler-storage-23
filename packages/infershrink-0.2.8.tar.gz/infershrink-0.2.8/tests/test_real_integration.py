"""
Real integration tests — actual API calls + classifier accuracy + API ergonomics.
Requires GEMINI_API_KEY for API tests. Run with: pytest tests/test_real_integration.py -v
"""

import os

import pytest

from infershrink import Complexity, build_config, classify, route

GEMINI_KEY = os.environ.get("GEMINI_API_KEY")
GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/openai/"
skip_no_gemini = pytest.mark.skipif(not GEMINI_KEY, reason="GEMINI_API_KEY not set")


# ── Classifier accuracy ──


class TestClassifierAccuracy:
    SIMPLE_PROMPTS = [
        "What is 2+2?",
        "What is the capital of France?",
        "Translate 'hello' to Spanish",
        "Who wrote Romeo and Juliet?",
    ]

    COMPLEX_PROMPTS = [
        "Write a Python function that implements quicksort with type hints",
        "```python\ndef merge_sort(arr):\n```\nComplete this with O(n log n) implementation",
        "Compare REST vs GraphQL vs gRPC with code examples, benchmarks, and tradeoffs",
    ]

    DECEPTIVE_PROMPTS = [
        # Short but needs deep reasoning
        "Prove P != NP",
        # Academic, no code keywords — classifier likely misses this
        "Explain the mathematical foundations of transformer attention including softmax derivation, multi-head scaling, and computational complexity analysis.",
    ]

    def _msgs(self, content):
        return [{"role": "user", "content": content}]

    def test_simple_prompts(self):
        for prompt in self.SIMPLE_PROMPTS:
            r = classify(self._msgs(prompt))
            assert r.complexity == Complexity.SIMPLE, (
                f"Expected SIMPLE: '{prompt[:50]}' → {r.complexity} ({r.reason})"
            )

    def test_complex_prompts(self):
        for prompt in self.COMPLEX_PROMPTS:
            r = classify(self._msgs(prompt))
            assert r.complexity in (Complexity.MODERATE, Complexity.COMPLEX), (
                f"Expected MODERATE/COMPLEX: '{prompt[:50]}' → {r.complexity} ({r.reason})"
            )

    def test_deceptive_prompts(self):
        """Prompts that look simple but need complex reasoning."""
        failures = []
        for prompt in self.DECEPTIVE_PROMPTS:
            r = classify(self._msgs(prompt))
            if r.complexity == Complexity.SIMPLE:
                failures.append(f"  '{prompt[:60]}' → SIMPLE ({r.reason})")
        if failures:
            pytest.xfail(f"Classifier fooled by {len(failures)} prompts:\n" + "\n".join(failures))

    def test_system_prompt_adds_complexity(self):
        """System prompt should increase estimated complexity."""
        msgs_no_sys = [{"role": "user", "content": "Help me"}]
        msgs_sys = [
            {
                "role": "system",
                "content": "You are an expert security researcher. Provide detailed analysis with code examples, CVE references, and mitigation strategies.",
            },
            {"role": "user", "content": "Help me"},
        ]
        r1 = classify(msgs_no_sys)
        r2 = classify(msgs_sys)
        assert r2.estimated_tokens > r1.estimated_tokens

    def test_long_context_is_complex(self):
        """Messages with >500 tokens should not be SIMPLE."""
        long_content = "Analyze: " + "distributed microservice architecture " * 50
        r = classify(self._msgs(long_content))
        assert r.complexity != Complexity.SIMPLE, (
            f"Long prompt ({r.estimated_tokens} tokens) classified as SIMPLE"
        )


# ── Routing integrity ──


class TestRoutingIntegrity:
    @pytest.fixture(autouse=True)
    def _setup(self, tmp_path):
        # Run from tmp_path to avoid picking up local infershrink.toml
        old_cwd = os.getcwd()
        os.chdir(tmp_path)
        self.cfg = build_config()
        yield
        os.chdir(old_cwd)

    def test_same_provider_openai(self):
        r = classify([{"role": "user", "content": "hi"}])
        result = route("gpt-4o", r.complexity, self.cfg)
        assert "gpt" in result.routed_model.lower(), (
            f"Cross-provider! gpt-4o → {result.routed_model}"
        )

    def test_same_provider_anthropic(self):
        r = classify([{"role": "user", "content": "hi"}])
        result = route("claude-sonnet-4-20250514", r.complexity, self.cfg)
        assert "claude" in result.routed_model.lower(), (
            f"Cross-provider! claude → {result.routed_model}"
        )

    def test_same_provider_google(self):
        r = classify([{"role": "user", "content": "hi"}])
        result = route("gemini-2.5-pro", r.complexity, self.cfg)
        assert "gemini" in result.routed_model.lower(), (
            f"Cross-provider! gemini → {result.routed_model}"
        )

    def test_simple_downgrades_openai(self):
        r = classify([{"role": "user", "content": "What is 2+2?"}])
        result = route("gpt-4o", r.complexity, self.cfg)
        assert result.was_downgraded, f"Expected downgrade, got {result.routed_model}"
        assert result.routed_model != "gpt-4o"

    def test_complex_preserves_model(self):
        r = classify(
            [
                {
                    "role": "user",
                    "content": "```python\ndef quicksort(arr):\n```\nImplement with tests",
                }
            ]
        )
        result = route("gpt-4o", r.complexity, self.cfg)
        # Complex should stay at tier2 or higher
        assert result.routed_model in ("gpt-4o", "gpt-4.5-preview", "o3"), (
            f"Complex was downgraded to {result.routed_model}"
        )

    def test_unknown_model_passthrough(self):
        r = classify([{"role": "user", "content": "hi"}])
        result = route("my-custom-model-v1", r.complexity, self.cfg)
        assert result.routed_model == "my-custom-model-v1"


# ── Real API calls ──


@skip_no_gemini
class TestRealAPICalls:
    @pytest.fixture(autouse=True)
    def _setup(self, tmp_path):
        old_cwd = os.getcwd()
        os.chdir(tmp_path)
        yield
        os.chdir(old_cwd)

    def _client(self):
        from openai import OpenAI

        return OpenAI(api_key=GEMINI_KEY, base_url=GEMINI_BASE)

    def test_simple_to_flash(self):
        client = self._client()
        msgs = [{"role": "user", "content": "What is 2+2?"}]
        c = classify(msgs)
        cfg = build_config()
        r = route("gemini-2.5-pro", c.complexity, cfg)
        assert "flash" in r.routed_model.lower()
        resp = client.chat.completions.create(model=r.routed_model, messages=msgs, max_tokens=50)
        assert resp.choices[0].message.content is not None
        assert "4" in resp.choices[0].message.content

    def test_flash_returns_content(self):
        """Flash should return content with sufficient max_tokens."""
        client = self._client()
        for prompt in ["Say hello", "List 3 colors", "What is Python?"]:
            resp = client.chat.completions.create(
                model="gemini-2.5-flash",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=500,  # Thinking models need more headroom
            )
            content = resp.choices[0].message.content
            if content is None and resp.choices[0].finish_reason == "length":
                pytest.xfail(f"Thinking model used all tokens for reasoning on: {prompt}")
            assert content is not None, f"Null content for: {prompt}"

    def test_pro_null_content_known_issue(self):
        """Gemini 2.5 Pro returns null via OpenAI-compat — this MUST be handled."""
        client = self._client()
        resp = client.chat.completions.create(
            model="gemini-2.5-pro",
            messages=[{"role": "user", "content": "Say hello"}],
            max_tokens=50,
        )
        content = resp.choices[0].message.content
        if content is None:
            pytest.xfail("Gemini 2.5 Pro returns None via OpenAI-compat (known upstream issue)")


# ── API ergonomics ──


class TestAPIErgonomics:
    def test_classify_bare_string_works(self):
        """classify('hello') should auto-wrap into messages format."""
        result = classify("What is 2+2?")
        assert result is not None
        assert result.complexity == Complexity.SIMPLE

    def test_classify_string_list_works(self):
        """classify(['hello']) should auto-wrap strings into messages."""
        result = classify(["What is 2+2?"])
        assert result is not None
        assert result.complexity == Complexity.SIMPLE

    def test_classify_empty_messages(self):
        """classify([]) should return a result, not crash."""
        try:
            result = classify([])
            assert result is not None
        except Exception as e:
            pytest.fail(f"classify([]) crashed: {e}")

    def test_classify_none_content(self):
        """Messages with None content should not crash."""
        try:
            result = classify([{"role": "user", "content": None}])
            assert result is not None
        except Exception as e:
            pytest.fail(f"classify(None content) crashed: {e}")

    def test_route_accepts_string_complexity(self):
        """route() should accept 'SIMPLE' string, not just Complexity enum."""
        cfg = build_config()
        try:
            result = route("gpt-4o", "SIMPLE", cfg)
            assert result is not None
        except Exception as e:
            pytest.fail(f"route() rejects string complexity: {e}")
