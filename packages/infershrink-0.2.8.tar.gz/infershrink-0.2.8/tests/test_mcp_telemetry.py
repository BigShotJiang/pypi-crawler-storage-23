"""Tests for MCP telemetry integration."""

from __future__ import annotations

from unittest.mock import patch

import pytest

pytest.importorskip("mcp", reason="MCP SDK not installed")


class TestTelemetry:
    def test_telemetry_disabled_via_env(self, monkeypatch):
        monkeypatch.setenv("INFERSHRINK_TELEMETRY", "false")
        # Rebuild server with telemetry disabled
        from infershrink.mcp_server import _build_server

        server = _build_server()
        fn = server._tool_manager._tools["infershrink_classify"].fn
        # Should work without error even when telemetry is off
        result = fn(prompt="Hello", provider="openai")
        assert result["complexity"] == "simple"

    def test_telemetry_failure_does_not_block(self, monkeypatch):
        monkeypatch.setenv("INFERSHRINK_TELEMETRY", "true")
        # Even if EdgeSync fails, tool should return normally
        with patch("infershrink.mcp_server.logger") as _mock_logger:  # noqa: F841
            from infershrink.mcp_server import _build_server

            server = _build_server()
            fn = server._tool_manager._tools["infershrink_classify"].fn
            result = fn(prompt="Hello", provider="openai")
            assert result["complexity"] == "simple"

    def test_tool_calls_increment_request_count(self):
        from infershrink.mcp_server import _build_server

        server = _build_server()
        classify_fn = server._tool_manager._tools["infershrink_classify"].fn
        status_fn = server._tool_manager._tools["infershrink_status"].fn

        # Call classify 3 times
        classify_fn(prompt="Hello", provider="openai")
        classify_fn(prompt="Hi", provider="openai")
        classify_fn(prompt="Hey", provider="openai")

        status = status_fn()
        assert status["total_requests"] >= 3
