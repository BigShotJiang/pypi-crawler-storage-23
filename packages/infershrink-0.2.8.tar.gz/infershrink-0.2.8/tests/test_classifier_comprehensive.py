"""Comprehensive classifier tests — 50+ diverse real-world prompts, edge cases."""

import pytest

from infershrink.classifier import (
    _SECURITY_KEYWORDS,
    _contains_any,
    _count_code_blocks,
    _count_inline_code,
    _estimate_tokens,
    _flatten_text,
    _has_tool_calls,
    classify,
)
from infershrink.types import Complexity

# ====================================================================
# Edge cases
# ====================================================================


class TestEdgeCases:
    """Boundary conditions and malformed inputs."""

    def test_empty_messages_list(self):
        result = classify([])
        assert result.complexity == Complexity.SIMPLE
        assert result.estimated_tokens >= 0

    def test_message_with_empty_content(self):
        result = classify([{"role": "user", "content": ""}])
        assert result.complexity == Complexity.SIMPLE

    def test_message_with_none_content(self):
        """None content (common in tool_calls messages)."""
        result = classify([{"role": "assistant", "content": None}])
        assert result.complexity == Complexity.SIMPLE

    def test_message_missing_content_key(self):
        """Message dict without 'content' key."""
        result = classify([{"role": "user"}])
        assert result.complexity == Complexity.SIMPLE

    def test_message_missing_role_key(self):
        result = classify([{"content": "Hello"}])
        assert result.complexity == Complexity.SIMPLE

    def test_completely_empty_message_dict(self):
        result = classify([{}])
        assert result.complexity == Complexity.SIMPLE

    def test_single_character_message(self):
        result = classify([{"role": "user", "content": "?"}])
        assert result.complexity == Complexity.SIMPLE

    def test_very_long_single_message(self):
        """10000+ tokens should be COMPLEX."""
        text = "word " * 50000  # ~50000 tokens
        result = classify([{"role": "user", "content": text}])
        assert result.complexity == Complexity.COMPLEX

    def test_unicode_content(self):
        result = classify([{"role": "user", "content": "こんにちは世界 🌍 مرحبا"}])
        assert result.complexity == Complexity.SIMPLE

    def test_only_whitespace_content(self):
        result = classify([{"role": "user", "content": "   \n\t\n  "}])
        assert result.complexity == Complexity.SIMPLE

    def test_multipart_content_with_images(self):
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "What's in this image?"},
                    {"type": "image_url", "image_url": {"url": "data:image/png;base64,abc"}},
                ],
            }
        ]
        result = classify(messages)
        assert result.complexity in (Complexity.SIMPLE, Complexity.MODERATE)

    def test_multipart_content_empty_text_blocks(self):
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": ""},
                    {"type": "text", "text": ""},
                ],
            }
        ]
        result = classify(messages)
        assert result.complexity == Complexity.SIMPLE

    def test_multipart_content_with_strings(self):
        """Content list with plain strings (not dicts)."""
        messages = [
            {
                "role": "user",
                "content": ["Hello", "World"],
            }
        ]
        result = classify(messages)
        assert result.complexity == Complexity.SIMPLE

    def test_content_as_integer(self):
        """Non-string, non-list content should not crash."""
        result = classify([{"role": "user", "content": 12345}])
        # Should handle gracefully
        assert result.complexity == Complexity.SIMPLE

    def test_metadata_as_none(self):
        """metadata key present but None."""
        result = classify([{"role": "user", "content": "Hello", "metadata": None}])
        assert result.complexity == Complexity.SIMPLE

    def test_metadata_not_dict(self):
        """metadata key present but not a dict."""
        result = classify([{"role": "user", "content": "Hello", "metadata": "string"}])
        assert result.complexity == Complexity.SIMPLE

    def test_exactly_500_token_boundary(self):
        """Exactly at the MODERATE boundary (500 tokens = 2000 chars)."""
        text = "a" * 2000  # exactly 500 tokens
        result = classify([{"role": "user", "content": text}])
        # 500 is not > 500, so should be SIMPLE
        assert result.complexity == Complexity.SIMPLE

    def test_501_token_boundary(self):
        """Just above MODERATE boundary."""
        text = "a" * 2004  # 501 tokens
        result = classify([{"role": "user", "content": text}])
        assert result.complexity == Complexity.MODERATE

    def test_exactly_2000_token_boundary(self):
        """At the COMPLEX boundary (2000 tokens = 8000 chars)."""
        text = "a" * 8000  # exactly 2000 tokens
        result = classify([{"role": "user", "content": text}])
        # 2000 is not > 2000, so should be MODERATE
        assert result.complexity == Complexity.MODERATE

    def test_2001_token_boundary(self):
        """Just above COMPLEX boundary."""
        text = "a" * 8004  # 2001 tokens
        result = classify([{"role": "user", "content": text}])
        assert result.complexity == Complexity.COMPLEX

    def test_exactly_5_messages(self):
        """Exactly 5 messages triggers multi-turn MODERATE."""
        messages = [
            {"role": "user", "content": "a"},
            {"role": "assistant", "content": "b"},
            {"role": "user", "content": "c"},
            {"role": "assistant", "content": "d"},
            {"role": "user", "content": "e"},
        ]
        result = classify(messages)
        assert result.complexity == Complexity.MODERATE

    def test_exactly_4_messages_still_simple(self):
        messages = [
            {"role": "user", "content": "a"},
            {"role": "assistant", "content": "b"},
            {"role": "user", "content": "c"},
            {"role": "assistant", "content": "d"},
        ]
        result = classify(messages)
        assert result.complexity == Complexity.SIMPLE


# ====================================================================
# Helper function tests
# ====================================================================


class TestHelperFunctions:
    """Direct tests for internal helpers."""

    def test_estimate_tokens_empty(self):
        assert _estimate_tokens("") == 1  # min 1

    def test_estimate_tokens_short(self):
        assert _estimate_tokens("hello") == 1

    def test_estimate_tokens_long(self):
        # 400 chars / 4 = 100 tokens
        assert _estimate_tokens("a" * 400) == 100

    def test_flatten_text_simple(self):
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "World"},
        ]
        text = _flatten_text(messages)
        assert "Hello" in text
        assert "World" in text

    def test_flatten_text_multipart(self):
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Part 1"},
                    {"type": "text", "text": "Part 2"},
                ],
            }
        ]
        text = _flatten_text(messages)
        assert "Part 1" in text
        assert "Part 2" in text

    def test_flatten_text_none_content(self):
        messages = [{"role": "assistant", "content": None}]
        text = _flatten_text(messages)
        assert text == ""

    def test_has_tool_calls_true(self):
        messages = [
            {"role": "assistant", "content": None, "tool_calls": [{"id": "1"}]},
        ]
        assert _has_tool_calls(messages) is True

    def test_has_tool_calls_function_call(self):
        messages = [
            {"role": "assistant", "content": None, "function_call": {"name": "f"}},
        ]
        assert _has_tool_calls(messages) is True

    def test_has_tool_calls_tool_role(self):
        messages = [
            {"role": "tool", "content": "result", "tool_call_id": "1"},
        ]
        assert _has_tool_calls(messages) is True

    def test_has_tool_calls_function_role(self):
        messages = [
            {"role": "function", "content": "result", "name": "f"},
        ]
        assert _has_tool_calls(messages) is True

    def test_has_tool_calls_false(self):
        messages = [{"role": "user", "content": "Hello"}]
        assert _has_tool_calls(messages) is False

    def test_count_code_blocks(self):
        text = "Here is code:\n```python\nprint('hello')\n```\nAnd more:\n```js\nconsole.log()\n```"
        assert _count_code_blocks(text) == 2

    def test_count_code_blocks_none(self):
        assert _count_code_blocks("no code here") == 0

    def test_count_inline_code(self):
        text = "Use `map()`, `filter()`, and `reduce()`"
        assert _count_inline_code(text) == 3

    def test_contains_any_found(self):
        hits = _contains_any("My password is hunter2", _SECURITY_KEYWORDS)
        assert "password" in hits

    def test_contains_any_case_insensitive(self):
        hits = _contains_any("My PASSWORD is safe", _SECURITY_KEYWORDS)
        assert "password" in hits

    def test_contains_any_empty_text(self):
        hits = _contains_any("", _SECURITY_KEYWORDS)
        assert hits == []


# ====================================================================
# 50+ Diverse Real-World Prompts
# ====================================================================


class TestClassifierAccuracy:
    """Test with diverse real-world prompts across all 4 complexity levels."""

    # --- SIMPLE prompts (should classify as SIMPLE) ---

    @pytest.mark.parametrize(
        "prompt,expected",
        [
            # Greetings
            ("Hello!", Complexity.SIMPLE),
            ("Hi there, how are you?", Complexity.SIMPLE),
            ("Good morning", Complexity.SIMPLE),
            # Simple factual questions
            ("What is the capital of France?", Complexity.SIMPLE),
            ("How many continents are there?", Complexity.SIMPLE),
            ("What color is the sky?", Complexity.SIMPLE),
            ("Who wrote Romeo and Juliet?", Complexity.SIMPLE),
            ("What year did World War II end?", Complexity.SIMPLE),
            # Simple requests
            ("Translate 'hello' to Spanish", Complexity.SIMPLE),
            ("What's 2 + 2?", Complexity.SIMPLE),
            ("Define the word 'ephemeral'", Complexity.SIMPLE),
            ("Is water wet?", Complexity.SIMPLE),
            ("Give me a synonym for 'happy'", Complexity.SIMPLE),
            ("What's the boiling point of water?", Complexity.SIMPLE),
            ("Name three primary colors", Complexity.SIMPLE),
        ],
    )
    def test_simple_prompts(self, prompt, expected):
        result = classify([{"role": "user", "content": prompt}])
        assert result.complexity == expected, (
            f"Expected {expected} for: {prompt!r}, got {result.complexity} — {result.reason}"
        )

    # --- MODERATE prompts (code, medium length, multi-turn) ---

    @pytest.mark.parametrize(
        "prompt,expected_min",
        [
            # Single code block
            (
                "Explain this:\n```python\ndef fibonacci(n):\n    if n <= 1: return n\n    return fibonacci(n-1) + fibonacci(n-2)\n```",
                Complexity.MODERATE,
            ),
            # Multiple inline code references
            (
                "What's the difference between `let`, `const`, and `var` in JavaScript?",
                Complexity.MODERATE,
            ),
            # Medium-length explanation requests (these need enough chars to cross 500 token threshold)
            # These are short, so they'll actually be SIMPLE unless they have code/inline code triggers
        ],
    )
    def test_moderate_prompts(self, prompt, expected_min):
        result = classify([{"role": "user", "content": prompt}])
        complexity_order = [
            Complexity.SIMPLE,
            Complexity.MODERATE,
            Complexity.COMPLEX,
            Complexity.SECURITY_CRITICAL,
        ]
        assert complexity_order.index(result.complexity) >= complexity_order.index(expected_min), (
            f"Expected at least {expected_min} for prompt, got {result.complexity} — {result.reason}"
        )

    # --- COMPLEX prompts ---

    @pytest.mark.parametrize(
        "prompt,expected",
        [
            # Step-by-step keyword
            ("Walk me through step by step how to build a REST API in Python", Complexity.COMPLEX),
            ("Explain chain of thought reasoning in LLMs", Complexity.COMPLEX),
            # Creative writing keywords
            ("Write a story about a samurai who discovers time travel", Complexity.COMPLEX),
            ("Write a poem about the ocean at midnight", Complexity.COMPLEX),
            # Debug/refactor keywords
            ("Debug this code and find the bug", Complexity.COMPLEX),
            ("Refactor this function to be more efficient", Complexity.COMPLEX),
            # Architecture keywords
            ("Design pattern for a microservices architecture", Complexity.COMPLEX),
            # Multi-step keywords
            ("Analyze the pros and cons of using NoSQL vs SQL databases", Complexity.COMPLEX),
            ("Compare and contrast TCP and UDP protocols", Complexity.COMPLEX),
            # Math keywords
            ("Derive the quadratic formula from first principles", Complexity.COMPLEX),
        ],
    )
    def test_complex_prompts(self, prompt, expected):
        result = classify([{"role": "user", "content": prompt}])
        assert result.complexity == expected, (
            f"Expected {expected} for: {prompt!r}, got {result.complexity} — {result.reason}"
        )

    # --- SECURITY_CRITICAL prompts ---

    @pytest.mark.parametrize(
        "prompt,expected",
        [
            # Passwords
            ("My password is hunter2, please remember it", Complexity.SECURITY_CRITICAL),
            ("Reset my passwd to something stronger", Complexity.SECURITY_CRITICAL),
            # API keys
            ("Here's my api_key: sk-proj-abc123", Complexity.SECURITY_CRITICAL),
            ("Store this api-key securely", Complexity.SECURITY_CRITICAL),
            # Tokens
            ("My auth token is eyJhbGciOiJIUzI1NiJ9.abc", Complexity.SECURITY_CRITICAL),
            # Credit cards
            ("My credit card is 4111-1111-1111-1111", Complexity.SECURITY_CRITICAL),
            # SSN
            ("My SSN is 123-45-6789", Complexity.SECURITY_CRITICAL),
            ("My social security number is private", Complexity.SECURITY_CRITICAL),
            # Financial
            ("Analyze my bank account transactions", Complexity.SECURITY_CRITICAL),
            ("Calculate my financial portfolio returns", Complexity.SECURITY_CRITICAL),
            # Security-related
            ("Encrypt this message with AES-256", Complexity.SECURITY_CRITICAL),
            ("Generate an OAuth token for the API", Complexity.SECURITY_CRITICAL),
            ("Decode this JWT and check its claims", Complexity.SECURITY_CRITICAL),
            # HIPAA
            ("This patient data is HIPAA protected", Complexity.SECURITY_CRITICAL),
            # PCI
            ("Ensure PCI compliance for payment processing", Complexity.SECURITY_CRITICAL),
        ],
    )
    def test_security_critical_prompts(self, prompt, expected):
        result = classify([{"role": "user", "content": prompt}])
        assert result.complexity == expected, (
            f"Expected {expected} for: {prompt!r}, got {result.complexity} — {result.reason}"
        )

    # --- Ambiguous / tricky prompts ---

    def test_security_keyword_trumps_simple(self):
        """Even a short message with security keywords is SECURITY_CRITICAL."""
        result = classify([{"role": "user", "content": "auth_token"}])
        assert result.complexity == Complexity.SECURITY_CRITICAL

    def test_security_keyword_trumps_complex(self):
        """Security keywords have highest priority over complexity keywords."""
        result = classify(
            [{"role": "user", "content": "Step by step, encrypt my password with AES"}]
        )
        assert result.complexity == Complexity.SECURITY_CRITICAL

    def test_code_in_security_context(self):
        """Code with security keywords → SECURITY_CRITICAL."""
        messages = [
            {"role": "user", "content": "```python\napi_key = 'sk-abc123'\n```\nIs this safe?"},
        ]
        result = classify(messages)
        assert result.complexity == Complexity.SECURITY_CRITICAL

    def test_long_simple_conversation_stays_below_complex(self):
        """A casual conversation with 5 short messages."""
        messages = [
            {"role": "user", "content": "Hi"},
            {"role": "assistant", "content": "Hello!"},
            {"role": "user", "content": "How are you?"},
            {"role": "assistant", "content": "I'm great!"},
            {"role": "user", "content": "Cool"},
        ]
        result = classify(messages)
        assert result.complexity == Complexity.MODERATE  # 5 messages triggers multi-turn

    def test_tool_response_makes_complex(self):
        """Messages with tool role should be COMPLEX."""
        messages = [
            {"role": "user", "content": "What's the weather?"},
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": "1",
                        "type": "function",
                        "function": {"name": "get_weather", "arguments": "{}"},
                    }
                ],
            },
            {"role": "tool", "content": '{"temp": 72}', "tool_call_id": "1"},
        ]
        result = classify(messages)
        assert result.complexity == Complexity.COMPLEX


class TestClassifierSignals:
    """Verify that signals dict contains accurate information."""

    def test_signals_token_count(self):
        text = "a" * 400  # 100 tokens
        result = classify([{"role": "user", "content": text}])
        assert result.signals["estimated_tokens"] == 100

    def test_signals_code_blocks_count(self):
        text = "```python\nprint(1)\n```\n```js\nconsole.log(1)\n```"
        result = classify([{"role": "user", "content": text}])
        assert result.signals["code_blocks"] == 2

    def test_signals_inline_code_count(self):
        text = "Use `a`, `b`, `c`, `d`"
        result = classify([{"role": "user", "content": text}])
        assert result.signals["inline_code"] == 4

    def test_signals_message_count(self):
        messages = [
            {"role": "user", "content": "a"},
            {"role": "assistant", "content": "b"},
            {"role": "user", "content": "c"},
        ]
        result = classify(messages)
        assert result.signals["message_count"] == 3

    def test_signals_has_tool_calls(self):
        messages = [
            {"role": "user", "content": "test"},
            {"role": "assistant", "content": None, "tool_calls": [{"id": "1"}]},
        ]
        result = classify(messages)
        assert result.signals["has_tool_calls"] is True

    def test_signals_system_prompt_tokens(self):
        system = "You are an expert. " * 50
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": "Hi"},
        ]
        result = classify(messages)
        assert result.signals["system_prompt_tokens"] > 0

    def test_signals_security_keywords_list(self):
        result = classify([{"role": "user", "content": "my password and api_key"}])
        assert "password" in result.signals["security_keywords"]
        assert "api_key" in result.signals["security_keywords"]

    def test_signals_complex_keywords_list(self):
        result = classify([{"role": "user", "content": "step by step analyze this"}])
        kws = result.signals["complex_keywords"]
        assert "step by step" in kws
        assert "analyze" in kws
