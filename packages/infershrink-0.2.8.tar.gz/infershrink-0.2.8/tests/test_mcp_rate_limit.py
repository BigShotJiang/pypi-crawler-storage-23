"""Tests for MCP rate limiter."""

from __future__ import annotations

from infershrink.mcp_rate_limit import RateLimiter


class TestRateLimiter:
    def test_allows_within_limit(self):
        limiter = RateLimiter()
        for _ in range(10):
            result = limiter.check("client-1", "free")
            assert result.allowed is True

    def test_blocks_over_limit(self):
        limiter = RateLimiter()
        # Free tier = 10/min
        for _ in range(10):
            limiter.check("client-1", "free")
        result = limiter.check("client-1", "free")
        assert result.allowed is False
        assert result.remaining == 0
        assert result.retry_after > 0

    def test_error_message_includes_tier(self):
        limiter = RateLimiter()
        for _ in range(10):
            limiter.check("client-1", "free")
        result = limiter.check("client-1", "free")
        assert "free" in result.error
        assert "10/min" in result.error
        assert "Retry after" in result.error

    def test_pro_tier_higher_limit(self):
        limiter = RateLimiter()
        for _ in range(50):
            result = limiter.check("client-pro", "pro")
            assert result.allowed is True
        # Still under pro limit (100)
        result = limiter.check("client-pro", "pro")
        assert result.allowed is True

    def test_different_clients_independent(self):
        limiter = RateLimiter()
        # Exhaust client-1
        for _ in range(10):
            limiter.check("client-1", "free")
        blocked = limiter.check("client-1", "free")
        assert blocked.allowed is False
        # client-2 should still work
        result = limiter.check("client-2", "free")
        assert result.allowed is True

    def test_remaining_count(self):
        limiter = RateLimiter()
        result = limiter.check("client-1", "free")
        assert result.remaining == 9  # 10 - 1
        result = limiter.check("client-1", "free")
        assert result.remaining == 8

    def test_reset_specific_client(self):
        limiter = RateLimiter()
        for _ in range(10):
            limiter.check("client-1", "free")
        assert limiter.check("client-1", "free").allowed is False
        limiter.reset("client-1")
        assert limiter.check("client-1", "free").allowed is True

    def test_reset_all(self):
        limiter = RateLimiter()
        for _ in range(10):
            limiter.check("client-1", "free")
            limiter.check("client-2", "free")
        limiter.reset()
        assert limiter.check("client-1", "free").allowed is True
        assert limiter.check("client-2", "free").allowed is True

    def test_admin_tier_very_high(self):
        limiter = RateLimiter()
        for _ in range(500):
            result = limiter.check("admin", "admin")
            assert result.allowed is True

    def test_unknown_tier_defaults_to_free(self):
        limiter = RateLimiter()
        for _ in range(10):
            limiter.check("client-1", "unknown_tier")
        result = limiter.check("client-1", "unknown_tier")
        assert result.allowed is False
