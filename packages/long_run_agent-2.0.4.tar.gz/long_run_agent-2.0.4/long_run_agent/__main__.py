#!/usr/bin/env python3
"""
LRA 安装后初始化
用户安装后直接运行: python3 -m long_run_agent
"""

from .installer import main

if __name__ == "__main__":
    main()
