- Add minimal deferring time configuration if it ever becomes necessary.
  See <https://github.com/OCA/social/pull/1001#issuecomment-1461581573>
  for the rationale behind current hardcoded value of 30 seconds.
