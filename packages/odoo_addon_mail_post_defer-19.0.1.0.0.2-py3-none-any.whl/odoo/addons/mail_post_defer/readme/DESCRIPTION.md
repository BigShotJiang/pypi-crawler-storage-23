This module enhances mail threads by using the mail queue by default.

Without this module, Odoo attempts to notify recipients of your message
immediately. If your mail server is slow or you have many followers,
this can mean a lot of time. Install this module and make Odoo more
snappy!

All emails will be kept in the outgoing queue by at least 30 seconds,
giving you some time to re-think what you wrote. During that time, you
can still delete the message and start again.
