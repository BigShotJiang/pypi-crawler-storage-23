from . import test_install
from . import test_mail
