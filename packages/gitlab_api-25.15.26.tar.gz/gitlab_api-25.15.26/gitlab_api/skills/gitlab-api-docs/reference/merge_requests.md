[Skip to main content](https://docs.gitlab.com/api/merge_requests/#skipTarget) [Go to GitLab Docs homepage](https://docs.gitlab.com/)
`/`
[What's new?](https://about.gitlab.com/releases/whats-new/)
English
  * Language
  * English
  * 日本語


v18.10
  *     * [18.10 (not yet released)](https://docs.gitlab.com/api/merge_requests/)
  *     * [18.9 (recently released)](https://docs.gitlab.com/18.9/api/merge_requests/)
    * [18.8](https://docs.gitlab.com/18.8/api/merge_requests/)
    * [18.7](https://archives.docs.gitlab.com/18.7/api/merge_requests/)
  *     * [17.11](https://archives.docs.gitlab.com/17.11/api/merge_requests/)
    * [16.11](https://archives.docs.gitlab.com/16.11/ee/api/merge_requests.html)
  *     * [Archives](https://docs.gitlab.com/archives)


Select theme and layout
  * Light mode
  * Dark mode
  * Auto


  * Fixed width
  * Fluid width


[What's new?](https://about.gitlab.com/releases/whats-new/) [Get free trial](https://gitlab.com/-/trial_registrations/new?glm_source=docs.gitlab.com&amp;glm_content=navigation-cta-docs)
Toggle menu
  * [Use GitLab](https://docs.gitlab.com/user/)
  * [GitLab Duo](https://docs.gitlab.com/user/gitlab_duo/)
  * [Extend](https://docs.gitlab.com/api/)
  * [Install](https://docs.gitlab.com/install/)
  * [Administer](https://docs.gitlab.com/administration/)
  * [Subscribe](https://docs.gitlab.com/subscriptions/)
  * [Contribute](https://docs.gitlab.com/development/)
  * [Solutions](https://docs.gitlab.com/solutions/)


Select a topicUse GitLab GitLab Duo Extend Install Administer Subscribe Contribute Solutions
[Getting started](https://docs.gitlab.com/api/get_started/get_started_extending/)
[Tutorials](https://docs.gitlab.com/tutorials/develop/)
[Integrations](https://docs.gitlab.com/integration/)
[Webhooks](https://docs.gitlab.com/user/project/integrations/webhooks/)
[REST API](https://docs.gitlab.com/api/rest/)
[Resources](https://docs.gitlab.com/api/api_resources/)
[.gitignore (templates)](https://docs.gitlab.com/api/templates/gitignores/)
[.gitlab-ci.yml (templates)](https://docs.gitlab.com/api/templates/gitlab_ci_ymls/)
[Access requests](https://docs.gitlab.com/api/access_requests/)
[Agent for Kubernetes](https://docs.gitlab.com/api/cluster_agents/)
[AI Catalog admin](https://docs.gitlab.com/api/admin/ai_catalog/)
[Alert management](https://docs.gitlab.com/api/alert_management_alerts/)
[Application appearance](https://docs.gitlab.com/api/appearance/)
[Application settings](https://docs.gitlab.com/api/settings/)
[Application statistics](https://docs.gitlab.com/api/statistics/)
[Applications](https://docs.gitlab.com/api/applications/)
[Attestations](https://docs.gitlab.com/api/attestations/)
[Audit events](https://docs.gitlab.com/api/audit_events/)
[Avatar](https://docs.gitlab.com/api/avatar/)
[Branches](https://docs.gitlab.com/api/branches/)
[Broadcast messages](https://docs.gitlab.com/api/broadcast_messages/)
[Cluster discovery (certificate-based) (deprecated)](https://docs.gitlab.com/api/cluster_discovery/)
[Code Suggestions](https://docs.gitlab.com/api/code_suggestions/)
[Commits](https://docs.gitlab.com/api/commits/)
[Compliance and policy settings](https://docs.gitlab.com/api/compliance_policy_settings/)
[Composer](https://docs.gitlab.com/api/packages/composer/)
[Conan v1](https://docs.gitlab.com/api/packages/conan_v1/)
[Conan v2](https://docs.gitlab.com/api/packages/conan_v2/)
[Container registry](https://docs.gitlab.com/api/container_registry/)
[Container repository protection rules](https://docs.gitlab.com/api/container_repository_protection_rules/)
[Container registry protection tag rules](https://docs.gitlab.com/api/container_registry_protection_tag_rules/)
[Container virtual registry](https://docs.gitlab.com/api/container_virtual_registries/)
[Custom attributes](https://docs.gitlab.com/api/custom_attributes/)
[Database migrations](https://docs.gitlab.com/api/database_migrations/)
[Data management](https://docs.gitlab.com/api/admin/data_management/)
[Debian](https://docs.gitlab.com/api/packages/debian/)
[Debian group distributions](https://docs.gitlab.com/api/packages/debian_group_distributions/)
[Debian project distributions](https://docs.gitlab.com/api/packages/debian_project_distributions/)
[Dependencies](https://docs.gitlab.com/api/dependencies/)
[Dependency list export](https://docs.gitlab.com/api/dependency_list_export/)
[Dependency Proxy](https://docs.gitlab.com/api/dependency_proxy/)
[Deploy keys](https://docs.gitlab.com/api/deploy_keys/)
[Deploy tokens](https://docs.gitlab.com/api/deploy_tokens/)
[Deployments](https://docs.gitlab.com/api/deployments/)
[Discussions](https://docs.gitlab.com/api/discussions/)
[Dockerfile (templates)](https://docs.gitlab.com/api/templates/dockerfiles/)
[DORA4 metrics](https://docs.gitlab.com/api/dora/metrics/)
[Emoji reactions](https://docs.gitlab.com/api/emoji_reactions/)
[Environments](https://docs.gitlab.com/api/environments/)
[Epics (deprecated)](https://docs.gitlab.com/api/epics/)
[Error tracking](https://docs.gitlab.com/api/error_tracking/)
[Events](https://docs.gitlab.com/api/events/)
[Experiments](https://docs.gitlab.com/api/experiments/)
[External status checks](https://docs.gitlab.com/api/status_checks/)
[Feature flags](https://docs.gitlab.com/api/feature_flags/)
[Feature flag user lists](https://docs.gitlab.com/api/feature_flag_user_lists/)
[Freeze periods](https://docs.gitlab.com/api/freeze_periods/)
[Geo nodes (deprecated)](https://docs.gitlab.com/api/geo_nodes/)
[Geo sites](https://docs.gitlab.com/api/geo_sites/)
[GitLab Duo Chat completions](https://docs.gitlab.com/api/chat/)
[GitLab Pages](https://docs.gitlab.com/api/pages/)
[GLQL](https://docs.gitlab.com/api/glql/)
[Go Proxy](https://docs.gitlab.com/api/packages/go_proxy/)
[Google Cloud integration](https://docs.gitlab.com/api/google_cloud_integration/)
[Groups](https://docs.gitlab.com/api/groups/)
[Helm](https://docs.gitlab.com/api/packages/helm/)
[Import](https://docs.gitlab.com/api/import/)
[Instance CI/CD variables](https://docs.gitlab.com/api/instance_level_ci_variables/)
[Invitations](https://docs.gitlab.com/api/invitations/)
[Issues](https://docs.gitlab.com/api/issues/)
[Issues (epic) (deprecated)](https://docs.gitlab.com/api/epic_issues/)
[Issues statistics](https://docs.gitlab.com/api/issues_statistics/)
[Jobs](https://docs.gitlab.com/api/jobs/)
[Job artifacts](https://docs.gitlab.com/api/job_artifacts/)
[Job token scopes](https://docs.gitlab.com/api/project_job_token_scopes/)
[Keys](https://docs.gitlab.com/api/keys/)
[License](https://docs.gitlab.com/api/license/)
[Licenses (templates)](https://docs.gitlab.com/api/templates/licenses/)
[Linked epics (deprecated)](https://docs.gitlab.com/api/linked_epics/)
[Links (issue)](https://docs.gitlab.com/api/issue_links/)
[Links (epic) (deprecated)](https://docs.gitlab.com/api/epic_links/)
[Lint .gitlab-ci.yml](https://docs.gitlab.com/api/lint/)
[Markdown](https://docs.gitlab.com/api/markdown/)
[Maven](https://docs.gitlab.com/api/packages/maven/)
[Maven virtual registry](https://docs.gitlab.com/api/maven_virtual_registries/)
[Member roles](https://docs.gitlab.com/api/member_roles/)
[Merge request approvals](https://docs.gitlab.com/api/merge_request_approvals/)
[Merge request approval settings](https://docs.gitlab.com/api/merge_request_approval_settings/)
[Merge request context commits](https://docs.gitlab.com/api/merge_request_context_commits/)
[Merge requests](https://docs.gitlab.com/api/merge_requests/)
[Merge trains](https://docs.gitlab.com/api/merge_trains/)
[Metadata](https://docs.gitlab.com/api/metadata/)
[Model registry](https://docs.gitlab.com/api/model_registry/)
[Namespaces](https://docs.gitlab.com/api/namespaces/)
[Notes (comments)](https://docs.gitlab.com/api/notes/)
[Notification settings](https://docs.gitlab.com/api/notification_settings/)
[npm](https://docs.gitlab.com/api/packages/npm/)
[NuGet](https://docs.gitlab.com/api/packages/nuget/)
[Organizations](https://docs.gitlab.com/api/organizations/)
[Packages](https://docs.gitlab.com/api/packages/)
[Pages domains](https://docs.gitlab.com/api/pages_domains/)
[Personal access tokens](https://docs.gitlab.com/api/personal_access_tokens/)
[Pipeline schedules](https://docs.gitlab.com/api/pipeline_schedules/)
[Pipeline trigger tokens](https://docs.gitlab.com/api/pipeline_triggers/)
[Pipelines](https://docs.gitlab.com/api/pipelines/)
[Plan limits](https://docs.gitlab.com/api/plan_limits/)
[Product analytics](https://docs.gitlab.com/api/product_analytics/)
[Projects](https://docs.gitlab.com/api/projects/)
[PyPI](https://docs.gitlab.com/api/packages/pypi/)
[Repositories](https://docs.gitlab.com/api/repositories/)
[Repository files](https://docs.gitlab.com/api/repository_files/)
[Repository submodules](https://docs.gitlab.com/api/repository_submodules/)
[Resource group](https://docs.gitlab.com/api/resource_groups/)
[Resource iteration events](https://docs.gitlab.com/api/resource_iteration_events/)
[Resource label events](https://docs.gitlab.com/api/resource_label_events/)
[Resource milestone events](https://docs.gitlab.com/api/resource_milestone_events/)
[Resource state events](https://docs.gitlab.com/api/resource_state_events/)
[Resource weight events](https://docs.gitlab.com/api/resource_weight_events/)
[Ruby gems](https://docs.gitlab.com/api/packages/rubygems/)
[Runners](https://docs.gitlab.com/api/runners/)
[Runner controllers](https://docs.gitlab.com/api/runner_controllers/)
[Runner controller tokens](https://docs.gitlab.com/api/runner_controller_tokens/)
[Search](https://docs.gitlab.com/api/search/)
[Search migrations](https://docs.gitlab.com/api/search_admin/)
[Secure files](https://docs.gitlab.com/api/secure_files/)
[Service accounts](https://docs.gitlab.com/api/service_accounts/)
[Service Ping](https://docs.gitlab.com/api/usage_data/)
[Sidekiq metrics](https://docs.gitlab.com/api/sidekiq_metrics/)
[Sidekiq queues](https://docs.gitlab.com/api/admin_sidekiq_queues/)
[Snippet repository storage moves](https://docs.gitlab.com/api/snippet_repository_storage_moves/)
[Snippets](https://docs.gitlab.com/api/snippets/)
[Suggestions](https://docs.gitlab.com/api/suggestions/)
[System hooks](https://docs.gitlab.com/api/system_hooks/)
[Tags](https://docs.gitlab.com/api/tags/)
[Terraform registry](https://docs.gitlab.com/api/packages/terraform-modules/)
[To-Do List](https://docs.gitlab.com/api/todos/)
[Token information](https://docs.gitlab.com/api/admin/token/)
[Topics](https://docs.gitlab.com/api/topics/)
[Users](https://docs.gitlab.com/api/users/)
[Version](https://docs.gitlab.com/api/version/)
[Virtual registries cleanup policies](https://docs.gitlab.com/api/virtual_registries_cleanup_policies/)
[Vulnerabilities](https://docs.gitlab.com/api/vulnerabilities/)
[Vulnerability archive export](https://docs.gitlab.com/api/vulnerability_archive_exports/)
[Vulnerability export](https://docs.gitlab.com/api/vulnerability_exports/)
[Vulnerability findings](https://docs.gitlab.com/api/vulnerability_findings/)
[Web commits](https://docs.gitlab.com/api/web_commits/)
[Authentication](https://docs.gitlab.com/api/rest/authentication/)
[Third-party clients](https://docs.gitlab.com/api/rest/third_party_clients/)
[Deprecations and removals](https://docs.gitlab.com/api/rest/deprecations/)
[OpenAPI](https://docs.gitlab.com/api/openapi/openapi_interactive/)
[Automate storage management](https://docs.gitlab.com/user/storage_management_automation/)
[Troubleshooting](https://docs.gitlab.com/api/rest/troubleshooting/)
[GraphQL API](https://docs.gitlab.com/api/graphql/)
[OAuth 2.0 identity provider API](https://docs.gitlab.com/api/oauth2/)
[GitLab Duo CLI (duo)](https://docs.gitlab.com/user/gitlab_duo_cli/)
[GitLab CLI (glab)](https://docs.gitlab.com/cli/)
[Editor and IDE extensions](https://docs.gitlab.com/editor_extensions/)
/
  1. [GitLab Docs](https://docs.gitlab.com/)
  2. [Extend](https://docs.gitlab.com/api/)
  3. [REST API](https://docs.gitlab.com/api/rest/)
  4. [Resources](https://docs.gitlab.com/api/api_resources/)
  5. [Merge requests](https://docs.gitlab.com/api/merge_requests/)


* * *
# Merge requests API
  * Tier: Free, Premium, Ultimate
  * Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated


History
  * `reference` [deprecated](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/20354) in GitLab 12.7.
  * `merged_by` [deprecated](https://gitlab.com/gitlab-org/gitlab/-/issues/350534) in GitLab 14.7.
  * `merge_status` [deprecated](https://gitlab.com/gitlab-org/gitlab/-/issues/3169#note_1162532204) in favor of `detailed_merge_status` in GitLab 15.6.
  * `with_merge_status_recheck` [changed](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/115948) in GitLab 15.11 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `restrict_merge_status_recheck` to be ignored for requests from users with insufficient permissions. Disabled by default.
  * `approvals_before_merge` [deprecated](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/119503) in GitLab 16.0.
  * `prepared_at` [introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/122001) in GitLab 16.1.
  * `merge_after` [introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/165092) in GitLab 17.5.
  * `security_policy_violations` [generally available](https://gitlab.com/gitlab-org/gitlab/-/issues/473704) in GitLab 18.4. Feature flag `policy_mergability_check` removed.


Use this API to manage [merge requests](https://docs.gitlab.com/user/project/merge_requests/). You can:
  * Automate any part of the code review process.
  * Connect code changes to external tools.
  * Send merge request information to non-GitLab systems in your preferred format.
  * Update, approve, merge, or block merge requests based on data from external systems.


All API calls to non-public information require authentication.
## Removals in API v5[](https://docs.gitlab.com/api/merge_requests/#removals-in-api-v5 "Permalink")
The `approvals_before_merge` attribute is deprecated, and [is scheduled for removal](https://docs.gitlab.com/api/rest/deprecations/) in API v5 in favor of the [Merge request approvals API](https://docs.gitlab.com/api/merge_request_approvals/).
## List merge requests[](https://docs.gitlab.com/api/merge_requests/#list-merge-requests "Permalink")
List all merge requests accessible to the authenticated user. By default, returns only merge requests created by the current user. Use `scope=all` to retrieve all merge requests.
Use the `state` parameter to get only merge requests with a given state (`opened`, `closed`, `locked`, or `merged`) or all states (`all`). Searching by `locked` generally returns no results as that state is short-lived and transitional. Use the pagination parameters `page` and `per_page` to restrict the list of merge requests.
```
GET /merge_requests
GET /merge_requests?state=opened
GET /merge_requests?state=all
GET /merge_requests?milestone=release
GET /merge_requests?labels=bug,reproduced
GET /merge_requests?author_id=5
GET /merge_requests?author_username=gitlab-bot
GET /merge_requests?my_reaction_emoji=star
GET /merge_requests?scope=assigned_to_me
GET /merge_requests?scope=reviews_for_me
GET /merge_requests?search=foo&in=title
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`approved_by_ids` | integer array | No | Returns the merge requests approved by all the users with the given `id`, up to 5 users. `None` returns merge requests with no approvals. `Any` returns merge requests with an approval. Premium and Ultimate only.
`approver_ids` | integer array | No | Returns merge requests which have specified all the users with the given `id` as individual approvers. `None` returns merge requests without approvers. `Any` returns merge requests with an approver. Premium and Ultimate only.
`assignee_id` | integer | No | Returns merge requests assigned to the given user `id`. `None` returns unassigned merge requests. `Any` returns merge requests with an assignee.
`author_id` | integer | No | Returns merge requests created by the given user `id`. Mutually exclusive with `author_username`. Combine with `scope=all` or `scope=assigned_to_me`.
`author_username` | string | No | Returns merge requests created by the given `username`. Mutually exclusive with `author_id`.
`created_after` | datetime | No | Returns merge requests created on or after the given time. Expected in ISO 8601 format (`2019-03-15T08:00:00Z`).
`created_before` | datetime | No | Returns merge requests created on or before the given time. Expected in ISO 8601 format (`2019-03-15T08:00:00Z`).
`deployed_after` | datetime | No | Returns merge requests deployed after the given date/time. Expected in ISO 8601 format (`2019-03-15T08:00:00Z`).
`deployed_before` | datetime | No | Returns merge requests deployed before the given date/time. Expected in ISO 8601 format (`2019-03-15T08:00:00Z`).
`environment` | string | No | Returns merge requests deployed to the given environment.
`in` | string | No | Change the scope of the `search` attribute. `title`, `description`, or a string joining them with comma. Default is `title,description`.
`labels` | string | No | Returns merge requests matching a comma-separated list of labels. `None` lists all merge requests with no labels. `Any` lists all merge requests with at least one label. Predefined names are case-insensitive.
`merge_user_id` | integer | No | Returns the merge requests merged by the user with the given user `id`. Mutually exclusive with `merge_user_username`. [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/140002) in GitLab 17.0.
`merge_user_username` | string | No | Returns the merge requests merged by the user with the given `username`. Mutually exclusive with `merge_user_id`. [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/140002) in GitLab 17.0.
`milestone` | string | No | Returns merge requests for a specific milestone. `None` returns merge requests with no milestone. `Any` returns merge requests that have an assigned milestone.
`my_reaction_emoji` | string | No | Returns merge requests reacted by the authenticated user by the given `emoji`. `None` returns issues not given a reaction. `Any` returns issues given at least one reaction.
`not` | Hash | No | Returns merge requests that do not match the parameters supplied. Accepts: `labels`, `milestone`, `author_id`, `author_username`, `assignee_id`, `assignee_username`, `reviewer_id`, `reviewer_username`, `my_reaction_emoji`.
`order_by` | string | No | Returns requests ordered by `created_at`, `title`, `merged_at` ([introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/147052) in GitLab 17.2), or `updated_at` fields. Default is `created_at`.
`render_html` | boolean | No | If `true`, the response includes rendered HTML fields `title_html` and `description_html`.
`reviewer_id` | integer | No | Returns merge requests which have the user as a [reviewer](https://docs.gitlab.com/user/project/merge_requests/reviews/) with the given user `id`. `None` returns merge requests with no reviewers. `Any` returns merge requests with any reviewer. Mutually exclusive with `reviewer_username`.
`reviewer_username` | string | No | Returns merge requests which have the user as a [reviewer](https://docs.gitlab.com/user/project/merge_requests/reviews/) with the given `username`. `None` returns merge requests with no reviewers. `Any` returns merge requests with any reviewer. Mutually exclusive with `reviewer_id`.
`scope` | string | No | Returns merge requests for the given scope: `created_by_me`, `assigned_to_me`, `reviews_for_me`, or `all`. Defaults to `created_by_me`. `reviews_for_me` returns merge requests where the current user is assigned as a reviewer.
`search` | string | No | Search merge requests against their `title` and `description`.
`sort` | string | No | Returns requests sorted in `asc` or `desc` order. Default is `desc`.
`source_branch` | string | No | Returns merge requests with the given source branch.
`state` | string | No | Returns all merge requests or just those that are `opened`, `closed`, `locked`, or `merged`.
`target_branch` | string | No | Returns merge requests with the given target branch.
`updated_after` | datetime | No | Returns merge requests updated on or after the given time. Expected in ISO 8601 format (`2019-03-15T08:00:00Z`).
`updated_before` | datetime | No | Returns merge requests updated on or before the given time. Expected in ISO 8601 format (`2019-03-15T08:00:00Z`).
`view` | string | No | If `simple`, returns the `iid`, URL, title, description, and basic state of merge request.
`with_labels_details` | boolean | No | If `true`, response returns more details for each label in labels field: `:name`, `:color`, `:description`, `:description_html`, `:text_color`. Default is `false`.
`with_merge_status_recheck` | boolean | No | If `true`, this projection requests (but does not guarantee) an asynchronous recalculation of the `merge_status` field. Enable the `restrict_merge_status_recheck` [feature flag](https://docs.gitlab.com/administration/feature_flags/) to ignore this attribute when requested by users without the Developer, Maintainer, or Owner role.
`wip` | string | No | Filter merge requests against their `wip` status. Use `yes` to return only draft merge requests, `no` to return non-draft merge requests.
If successful, returns [`200 OK`](https://docs.gitlab.com/api/rest/troubleshooting/#status-codes). If `view` is set to `simple`, returns a subset of fields. Otherwise, response attributes include:
Attribute | Type | Description
---|---|---
`allow_collaboration` | boolean | If `true`, this fork allows collaboration from members who can merge to the target branch. Used only for merge requests from forks.
`allow_maintainer_to_push` | boolean | Deprecated. Use `allow_collaboration` instead.
`approvals_before_merge` | integer |  [Deprecated](https://gitlab.com/gitlab-org/gitlab/-/issues/353097) in GitLab 16.0. To configure approval rules, see [Merge request approvals API](https://docs.gitlab.com/api/merge_request_approvals/) instead. GitLab Premium and Ultimate only.
`assignee[]` | object | Deprecated. Use `assignees` instead.
`assignees[]` | array | Users assigned to the merge request.
`assignees.avatar_url` | string | Full URL to the assignee’s avatar image.
`assignees.id` | integer | The unique ID of the assignee.
`assignees.locked` | boolean | If `true`, the assignee’s account is locked due to failed authentication attempts, and they cannot sign in until the lock expires or an administrator unlocks the account.
`assignees.name` | string | Display name of the assignee. Might be redacted, based on current user’s permissions.
`assignees.public_email` | string | The public email address of the assignee.
`assignees.state` | string | Current state of the assignee’s user account. Possible values: `active`, `blocked`, or `deactivated`.
`assignees.username` | string | Username of the merge request assignee.
`assignees.web_url` | string | Full URL to the assignee’s profile page.
`author[]` | object | Object with information about the user who created the merge request.
`author.avatar_url` | string | Full URL to the author’s avatar image.
`author.id` | integer | The unique ID of the user who created the merge request.
`author.locked` | boolean | If `true`, the author’s account is locked due to failed authentication attempts, and they cannot sign in until the lock expires or an administrator unlocks the account.
`author.name` | string | Display name of the author. Might be redacted, based on current user’s permissions.
`author.public_email` | string | The public email address of the author.
`author.state` | string | Current state of the user account. Possible values: `active`, `blocked`, or `deactivated`.
`author.username` | string | Username of the merge request author.
`author.web_url` | string | Full URL to the author’s profile page.
`blocking_discussions_resolved` | boolean | If `true`, all discussion threads in the merge request must be resolved before merging.
`closed_at` | dateTime | Timestamp of when the merge request was closed.
`closed_by[]` | object | Object with information about the user who closed the merge request. If `null`, the merge request is open.
`closed_by.avatar_url` | string | Full URL to the closing user’s avatar image.
`closed_by.id` | integer | The unique ID of the user who closed the merge request.
`closed_by.locked` | boolean | If `true`, the closing user’s account is locked due to failed authentication attempts, and they cannot sign in until the lock expires or an administrator unlocks the account.
`closed_by.name` | string | Display name of the closing user. Might be redacted, based on current user’s permissions.
`closed_by.public_email` | string | The public email address of the closing user.
`closed_by.state` | string | Current state of the closing user’s account. Possible values: `active`, `blocked`, or `deactivated`.
`closed_by.username` | string | Username of the user who closed the merge request.
`closed_by.web_url` | string | Full URL to the closing user’s profile page.
`created_at` | dateTime | Timestamp of when the merge request was created.
`description` | string | Description of the merge request. Contains Markdown rendered as HTML for caching.
`description_html` | string | If `render_html` is set, the rendered HTML version of the description.
`detailed_merge_status` | string | Detailed merge status information. See [merge status](https://docs.gitlab.com/api/merge_requests/#merge-status) for a list of potential values.
`discussion_locked` | boolean | If `true`, discussions are locked. Only project members can add, edit or resolve comments in locked discussions.
`downvotes` | integer | Number of downvotes for the merge request.
`draft` | boolean | If `true`, the merge request is marked in a `draft` state.
`force_remove_source_branch` | boolean | If `true`, the project settings force the deletion of the source branch after merge.
`has_conflicts` | boolean | If `true`, the merge request has conflicts and cannot merge. Dependent on the `merge_status` property. Returns `false` unless `merge_status` is `cannot_be_merged`.
`id` | integer | The unique ID of the merge request.
`iid` | integer | The internal ID of the merge request in the project.
`imported` | boolean | If `true`, the merge request was imported.
`imported_from` | string | Source of import, such as `Bitbucket`.
`labels[]` | array | Array of label assigned to the merge request. If `with_labels_details` is `true`, returns an array for each label.
`labels.archived` | boolean | If `with_labels_details` is `true`, the label is archived.
`labels.color` | string | If `with_labels_details` is `true`, the background color of the label.
`labels.description` | string | If `with_labels_details` is `true`, the description text of the label. If `null`, the label has no description.
`labels.description_html`. | string | If `with_labels_details` is `true`, the HTML-rendered description of the label. If `null`, the label has no description.
`labels.id` | integer | If `with_labels_details` is `true`, the unique ID of the label.
`labels.name` | string | If `with_labels_details` is `true`, the name of the label.
`labels.text_color` | string | If `with_labels_details` is `true`, the text color for the label.
`merge_after` | dateTime | If set, timestamp after which the merge request can be merged. [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/510992) in GitLab 17.8.
`merge_commit_sha` | string | If set, the SHA of the merge request commit. Returns `null` until merged.
`merge_status` | string | Status of the merge request. Use `detailed_merge_status` instead, which accounts for all potential statuses. Affects the `has_conflicts` property. For important notes on response data, see [Single merge request response notes](https://docs.gitlab.com/api/merge_requests/#single-merge-request-response-notes). [Deprecated](https://gitlab.com/gitlab-org/gitlab/-/issues/3169#note_1162532204) in GitLab 15.6.
`merge_user` | object | Object with information about the user who merged the merge request, set it to auto-merge, or `null`.
`merge_when_pipeline_succeeds` | boolean | If `true`, the merge request is set to auto-merge.
`merged_at` | dateTime | Timestamp of when the merge request merged.
`merged_by[]` | object | Deprecated. Use `merge_user` instead.
`milestone[]` | object | Object with information about the milestone assigned to the merge request.
`milestone.created_at` | dateTime | Timestamp when the milestone was created.
`milestone.description` | string | Description text of the milestone. If `null`, the milestone has no description.
`milestone.due_date` | date | Due date for the milestone. If `null`, the milestone has no due date.
`milestone.expired` | boolean | If `true`, the milestone has expired.
`milestone.group_id` | integer | ID of the group the milestone belongs to. Included only if the milestone is a group milestone.
`milestone.id` | integer | Unique ID of the milestone.
`milestone.iid` | integer | Internal ID of the milestone in the project or group.
`milestone.project_id` | integer | ID of the project the milestone belongs to. Included only if the milestone is a project milestone.
`milestone.start_date` | date | Start date for the milestone. If `null`, the milestone has no start date
`milestone.state` | string | Current state of the milestone, such as `active` or `closed`.
`milestone.title` | string | Name of the milestone.
`milestone.updated_at` | dateTime | Timestamp when the milestone was last updated.
`milestone.web_url` | string | Full web URL to view the milestone.
`prepared_at` | dateTime | Timestamp of when the merge request was prepared. This field populates one time, only after all the [preparation steps](https://docs.gitlab.com/api/merge_requests/#preparation-steps) complete, and is not updated if more changes are added.
`project_id` | integer | The ID of the project containing the merge request.
`reference` | string | Deprecated. Use `references` instead.
`references[]` | object | Object with all internal references of the merge request.
`references.full` | string | Complete reference to a merge request, including full project path, like `gitlab-org/gitlab!123`. When requested across groups or projects, identical to `references.relative`.
`references.relative` | string | Reference relative to a specific project or group: `!123` for a merge request in the current project, or `other-project!123` for another project in the same group.
`references.short` | string | Shortest possible reference to a merge request, like `!123`. When fetched from the merge request’s project, identical to `references.relative`.
`reviewers[]` | array | Reviewers of the merge request.
`reviewers.avatar_url` | string | Full URL to the reviewer’s avatar image.
`reviewers.id` | integer | The unique ID of the reviewer.
`reviewers.locked` | boolean | If `true`, the reviewer’s account is locked due to failed authentication attempts, and they cannot sign in until the lock expires or an administrator unlocks the account.
`reviewers.name` | string | Display name of the reviewer. Might be redacted, based on current user’s permissions.
`reviewers.public_email` | string | The public email address of the reviewer.
`reviewers.state` | string | Current state of the reviewer’s user account. Possible values: `active`, `blocked`, or `deactivated`.
`reviewers.username` | string | Username of the merge request reviewer.
`reviewers.web_url` | string | Full URL to the reviewer’s profile page.
`sha` | string | SHA of the head commit in the source branch.
`should_remove_source_branch` | boolean | If `true`, the source branch is removed after merge.
`source_branch` | string | Name of the source branch.
`source_project_id` | integer | ID of the source project.
`squash` | boolean | If `true`, squash commits when merging.
`squash_commit_sha` | string | If set, the SHA of the squash commit. Empty until merged.
`squash_on_merge` | boolean | If `true`, commits are squashed on merge.
`state` | string | The current state of the merge request. Possible values: `opened`, `closed`, `merged`, or `locked`.
`target_branch` | string | Name of the target branch.
`target_project_id` | integer | ID of the target project.
`task_completion_status[]` | object | Object with information on the task list completion status.
`task_completion_status.completed_count` | integer | Number of completed task list items in the merge request description. Returns `0` if the merge request has no description or no task list items.
`task_completion_status.count` | integer | Total number of task list items found in the merge request description. Returns `0` if the merge request has no description or no task list items.
`time_stats[]` | object | Object with information on time tracking for this merge request.
`time_stats.human_time_estimate` | string | Human-readable format of `time_stats.time_estimate`, like `3h 30m`.
`time_stats.human_total_time_spent` | string | Human-readable format of `time_stats.total_time_spent`, like `3h 30m`.
`time_stats.time_estimate` | integer | Estimated time to complete the merge request, in seconds.
`time_stats.total_time_spent` | integer | Total time spent working on the merge request, in seconds.
`title` | string | The merge request title.
`title_html` | string | If `render_html` is `true`, the rendered HTML version of the title.
`updated_at` | dateTime | Timestamp of when the merge request was last updated.
`upvotes` | integer | Number of upvotes for the merge request.
`user_notes_count` | integer | Number of user comments.
`web_url` | string | Web URL to view the merge request.
`work_in_progress` | boolean | Deprecated. Use `draft` instead.
Other possible responses:
  * `401 Unauthorized` if the access token is invalid.
  * `408 Request Timeout` if the database query times out.
  * `422 Unprocessable Entity` if validation failed.
  * `429 Too Many Requests` if using the `search` parameter, and the request has been rate-limited.


Example response:
json
```
[
  {
    "id": 1,
    "iid": 1,
    "project_id": 3,
    "title": "test1",
    "description": "fixed login page css paddings",
    "state": "merged",
    "imported": false,
    "imported_from": "none",
    "merged_by": { // Deprecated and will be removed in API v5, use `merge_user` instead
      "id": 87854,
      "name": "Douwe Maan",
      "username": "DouweM",
      "state": "active",
      "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
      "web_url": "https://gitlab.com/DouweM"
    },
    "merge_user": {
      "id": 87854,
      "name": "Douwe Maan",
      "username": "DouweM",
      "state": "active",
      "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
      "web_url": "https://gitlab.com/DouweM"
    },
    "merged_at": "2018-09-07T11:16:17.520Z",
    "merge_after": "2018-09-07T11:16:00.000Z",
    "prepared_at": "2018-09-04T11:16:17.520Z",
    "closed_by": null,
    "closed_at": null,
    "created_at": "2017-04-29T08:46:00Z",
    "updated_at": "2017-04-29T08:46:00Z",
    "target_branch": "main",
    "source_branch": "test1",
    "upvotes": 0,
    "downvotes": 0,
    "author": {
      "id": 1,
      "name": "Administrator",
      "username": "admin",
      "state": "active",
      "avatar_url": null,
      "web_url" : "https://gitlab.example.com/admin"
    },
    "assignee": {
      "id": 1,
      "name": "Administrator",
      "username": "admin",
      "state": "active",
      "avatar_url": null,
      "web_url" : "https://gitlab.example.com/admin"
    },
    "assignees": [{
      "name": "Miss Monserrate Beier",
      "username": "axel.block",
      "id": 12,
      "state": "active",
      "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
      "web_url": "https://gitlab.example.com/axel.block"
    }],
    "reviewers": [{
      "id": 2,
      "name": "Sam Bauch",
      "username": "kenyatta_oconnell",
      "state": "active",
      "avatar_url": "https://www.gravatar.com/avatar/956c92487c6f6f7616b536927e22c9a0?s=80&d=identicon",
      "web_url": "http://gitlab.example.com//kenyatta_oconnell"
    }],
    "source_project_id": 2,
    "target_project_id": 3,
    "labels": [
      "Community contribution",
      "Manage"
    ],
    "draft": false,
    "work_in_progress": false,
    "milestone": {
      "id": 5,
      "iid": 1,
      "project_id": 3,
      "title": "v2.0",
      "description": "Assumenda aut placeat expedita exercitationem labore sunt enim earum.",
      "state": "closed",
      "created_at": "2015-02-02T19:49:26.013Z",
      "updated_at": "2015-02-02T19:49:26.013Z",
      "due_date": "2018-09-22",
      "start_date": "2018-08-08",
      "web_url": "https://gitlab.example.com/my-group/my-project/milestones/1"
    },
    "merge_when_pipeline_succeeds": true,
    "merge_status": "can_be_merged",
    "detailed_merge_status": "not_open",
    "sha": "8888888888888888888888888888888888888888",
    "merge_commit_sha": null,
    "squash_commit_sha": null,
    "user_notes_count": 1,
    "discussion_locked": null,
    "should_remove_source_branch": true,
    "force_remove_source_branch": false,
    "allow_collaboration": false,
    "allow_maintainer_to_push": false,
    "web_url": "http://gitlab.example.com/my-group/my-project/merge_requests/1",
    "references": {
      "short": "!1",
      "relative": "my-group/my-project!1",
      "full": "my-group/my-project!1"
    },
    "time_stats": {
      "time_estimate": 0,
      "total_time_spent": 0,
      "human_time_estimate": null,
      "human_total_time_spent": null
    },
    "squash": false,
    "task_completion_status":{
      "count":0,
      "completed_count":0
    }
  }
]
```

### Merge requests list response notes[](https://docs.gitlab.com/api/merge_requests/#merge-requests-list-response-notes "Permalink")
  * Listing merge requests might not proactively update `merge_status` (which also affects the `has_conflicts`), as this can be an expensive operation. If you need the value of these fields from this endpoint, set the `with_merge_status_recheck` parameter to `true` in the query.
  * For notes on merge request object fields, see [Single merge request response notes](https://docs.gitlab.com/api/merge_requests/#single-merge-request-response-notes).


## List project merge requests[](https://docs.gitlab.com/api/merge_requests/#list-project-merge-requests "Permalink")
List all merge requests for a project.
```
GET /projects/:id/merge_requests
GET /projects/:id/merge_requests?state=opened
GET /projects/:id/merge_requests?state=all
GET /projects/:id/merge_requests?iids[]=42&iids[]=43
GET /projects/:id/merge_requests?milestone=release
GET /projects/:id/merge_requests?labels=bug,reproduced
GET /projects/:id/merge_requests?my_reaction_emoji=star
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`approved_by_ids` | integer array | No | Returns merge requests approved by all the users with the given `id`, up to 5 users. `None` returns merge requests with no approvals. `Any` returns merge requests with an approval. Premium and Ultimate only.
`approver_ids` | integer array | No | Returns merge requests which have specified all the users with the given `id` as individual approvers. `None` returns merge requests without approvers. `Any` returns merge requests with an approver. Premium and Ultimate only.
`assignee_id` | integer | No | Returns merge requests assigned to the given user `id`. `None` returns unassigned merge requests. `Any` returns merge requests with an assignee.
`author_id` | integer | No | Returns merge requests created by the given user `id`. Mutually exclusive with `author_username`.
`author_username` | string | No | Returns merge requests created by the given `username`. Mutually exclusive with `author_id`.
`created_after` | datetime | No | Returns merge requests created on or after the given time. Expected in ISO 8601 format (`2019-03-15T08:00:00Z`).
`created_before` | datetime | No | Returns merge requests created on or before the given time. Expected in ISO 8601 format (`2019-03-15T08:00:00Z`).
`environment` | string | No | Returns merge requests deployed to the given environment.
`iids[]` | integer array | No | Returns the request having the given `iid`.
`labels` | string | No | Returns merge requests matching a comma-separated list of labels. `None` lists all merge requests with no labels. `Any` lists all merge requests with at least one label. Predefined names are case-insensitive.
`merge_user_id` | integer | No | Returns merge requests merged by the user with the given user `id`. Mutually exclusive with `merge_user_username`. [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/140002) in GitLab 17.0.
`merge_user_username` | string | No | Returns merge requests merged by the user with the given `username`. Mutually exclusive with `merge_user_id`. [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/140002) in GitLab 17.0.
`milestone` | string | No | Returns merge requests for a specific milestone. `None` returns merge requests with no milestone. `Any` returns merge requests that have an assigned milestone.
`my_reaction_emoji` | string | No | Returns merge requests reacted by the authenticated user by the given `emoji`. `None` returns issues not given a reaction. `Any` returns issues given at least one reaction.
`not` | Hash | No | Returns merge requests that do not match the parameters supplied. Accepts: `labels`, `milestone`, `author_id`, `author_username`, `assignee_id`, `assignee_username`, `reviewer_id`, `reviewer_username`, `my_reaction_emoji`.
`order_by` | string | No | Returns requests ordered by `created_at`, `title` or `updated_at` fields. Default is `created_at`.
`reviewer_id` | integer | No | Returns merge requests which have the user as a [reviewer](https://docs.gitlab.com/user/project/merge_requests/reviews/) with the given user `id`. `None` returns merge requests with no reviewers. `Any` returns merge requests with any reviewer. Mutually exclusive with `reviewer_username`.
`reviewer_username` | string | No | Returns merge requests which have the user as a [reviewer](https://docs.gitlab.com/user/project/merge_requests/reviews/) with the given `username`. `None` returns merge requests with no reviewers. `Any` returns merge requests with any reviewer. Mutually exclusive with `reviewer_id`.
`scope` | string | No | Returns merge requests for the given scope: `created_by_me`, `assigned_to_me`, `reviews_for_me`, or `all`. `reviews_for_me` returns merge requests where the current user is assigned as a reviewer.
`search` | string | No | Search merge requests against their `title` and `description`.
`sort` | string | No | Returns requests sorted in `asc` or `desc` order. Default is `desc`.
`source_branch` | string | No | Returns merge requests with the given source branch.
`state` | string | No | Returns all merge requests (`all`) or just those that are `opened`, `closed`, `locked`, or `merged`.
`target_branch` | string | No | Returns merge requests with the given target branch.
`updated_after` | datetime | No | Returns merge requests updated on or after the given time. Expected in ISO 8601 format (`2019-03-15T08:00:00Z`).
`updated_before` | datetime | No | Returns merge requests updated on or before the given time. Expected in ISO 8601 format (`2019-03-15T08:00:00Z`).
`view` | string | No | If `simple`, returns the `iid`, URL, title, description, and basic state of merge request.
`wip` | string | No | Filter merge requests against their `wip` status. `yes` to return only draft merge requests, `no` to return non-draft merge requests.
`with_labels_details` | boolean | No | If `true`, response returns more details for each label in labels field: `:name`, `:color`, `:description`, `:description_html`, `:text_color`. Default is `false`.
`with_merge_status_recheck` | boolean | No | If `true`, this projection requests (but does not guarantee) an asynchronous recalculation of the `merge_status` field. Enable the `restrict_merge_status_recheck` [feature flag](https://docs.gitlab.com/administration/feature_flags/) to ignore this attribute when requested by users without the Developer, Maintainer, or Owner role.
If successful, returns [`200 OK`](https://docs.gitlab.com/api/rest/troubleshooting/#status-codes) and the following response attributes:
Attribute | Type | Description
---|---|---
`[].id` | integer | ID of the merge request.
`[].iid` | integer | Internal ID of the merge request.
`[].approvals_before_merge` | integer | Number of approvals required before this merge request can merge. To configure approval rules, see [Merge request approvals API](https://docs.gitlab.com/api/merge_request_approvals/). [Deprecated](https://gitlab.com/gitlab-org/gitlab/-/issues/353097) in GitLab 16.0. Premium and Ultimate only.
`[].assignee` | object | First assignee of the merge request.
`[].assignees` | array | Assignees of the merge request.
`[].author` | object | User who created this merge request.
`[].blocking_discussions_resolved` | boolean | Indicates if all discussions are resolved only if all are required before merge request can be merged.
`[].closed_at` | datetime | Timestamp of when the merge request was closed.
`[].closed_by` | object | User who closed this merge request.
`[].created_at` | datetime | Timestamp of when the merge request was created.
`[].description` | string | Description of the merge request.
`[].detailed_merge_status` | string | Detailed merge status of the merge request. See [merge status](https://docs.gitlab.com/api/merge_requests/#merge-status) for a list of potential values.
`[].discussion_locked` | boolean | Indicates if comments on the merge request are locked to members only.
`[].downvotes` | integer | Number of downvotes for the merge request.
`[].draft` | boolean | Indicates if the merge request is a draft.
`[].force_remove_source_branch` | boolean | Indicates if the project settings lead to source branch deletion after merge.
`[].has_conflicts` | boolean | Indicates if merge request has conflicts and cannot merge. Dependent on the `merge_status` property. Returns `false` unless `merge_status` is `cannot_be_merged`.
`[].labels` | array | Labels of the merge request.
`[].merge_commit_sha` | string | SHA of the merge request commit. Returns `null` until merged.
`[].merge_status` | string | Status of the merge request. Can be `unchecked`, `checking`, `can_be_merged`, `cannot_be_merged`, or `cannot_be_merged_recheck`. Affects the `has_conflicts` property. For important notes on response data, see [Single merge request response notes](https://docs.gitlab.com/api/merge_requests/#single-merge-request-response-notes). [Deprecated](https://gitlab.com/gitlab-org/gitlab/-/issues/3169#note_1162532204) in GitLab 15.6. Use `detailed_merge_status` instead.
`[].merge_user` | object | User who merged this merge request, the user who set it to auto-merge, or `null`.
`[].merge_when_pipeline_succeeds` | boolean | Indicates if the merge request is set to auto-merge.
`[].merged_at` | datetime | Timestamp of when the merge request was merged.
`[].merged_by` | object | User who merged this merge request or set it to auto-merge. [Deprecated](https://gitlab.com/gitlab-org/gitlab/-/issues/350534) in GitLab 14.7, and scheduled for removal in [API version 5](https://gitlab.com/groups/gitlab-org/-/epics/8115). Use `merge_user` instead.
`[].milestone` | object | Milestone of the merge request.
`[].prepared_at` | datetime | Timestamp of when the merge request was prepared. This field is populated one time, only after all the [preparation steps](https://docs.gitlab.com/api/merge_requests/#preparation-steps) are completed, and is not updated if more changes are added.
`[].project_id` | integer | ID of the project where the merge request resides. Always equal to `target_project_id`.
`[].reference` | string | Internal reference of the merge request. Returned in shortened format by default. [Deprecated](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/20354) in GitLab 12.7, and scheduled for removal in [API version 5](https://gitlab.com/groups/gitlab-org/-/epics/8115). Use `references` instead.
`[].references` | object | Internal references of the merge request. Includes `short`, `relative`, and `full` references. `references.relative` is relative to the merge request’s group or project. When fetched from the merge request’s project, `relative` and `short` formats are identical. When requested across groups or projects, `relative` and `full` formats are identical.
`[].reviewers` | array | Reviewers of the merge request.
`[].sha` | string | Diff head SHA of the merge request.
`[].should_remove_source_branch` | boolean | Indicates if the source branch of the merge request should be deleted after merge.
`[].source_branch` | string | Source branch of the merge request.
`[].source_project_id` | integer | ID of the merge request source project. Equal to `target_project_id`, unless the merge request originates from a fork.
`[].squash` | boolean | If `true`, squash all commits into a single commit on merge. [Project settings](https://docs.gitlab.com/user/project/merge_requests/squash_and_merge/#configure-squash-options-for-a-project) might override this value. Use `squash_on_merge` instead to take project squash options into account.
`[].squash_commit_sha` | string | SHA of the squash commit. Empty until merged.
`[].squash_on_merge` | boolean | Indicates whether to squash the merge request when merging.
`[].state` | string | State of the merge request. Can be `opened`, `closed`, `merged`, `locked`.
`[].target_branch` | string | Target branch of the merge request.
`[].target_project_id` | integer | ID of the merge request target project.
`[].task_completion_status` | object | Completion status of tasks. Includes `count` and `completed_count`.
`[].time_stats` | object | Time tracking stats of the merge request. Includes `time_estimate`, `total_time_spent`, `human_time_estimate`, and `human_total_time_spent`.
`[].title` | string | Title of the merge request.
`[].updated_at` | datetime | Timestamp of when the merge request was updated.
`[].upvotes` | integer | Number of upvotes for the merge request.
`[].user_notes_count` | integer | User notes count of the merge request.
`[].web_url` | string | Web URL of the merge request.
`[].work_in_progress` | boolean | Deprecated: Use `draft` instead. Indicates if the merge request is a draft.
Example request:
shell
```
curl --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/1/merge_requests"
```

Example response:
json
```
[
  {
    "id": 1,
    "iid": 1,
    "project_id": 3,
    "title": "test1",
    "description": "fixed login page css paddings",
    "state": "merged",
    "imported": false,
    "imported_from": "none",
    "merged_by": { // Deprecated and will be removed in API v5, use `merge_user` instead
      "id": 87854,
      "name": "Douwe Maan",
      "username": "DouweM",
      "state": "active",
      "locked": false,
      "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
      "web_url": "https://gitlab.com/DouweM"
    },
    "merge_user": {
      "id": 87854,
      "name": "Douwe Maan",
      "username": "DouweM",
      "state": "active",
      "locked": false,
      "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
      "web_url": "https://gitlab.com/DouweM"
    },
    "merged_at": "2018-09-07T11:16:17.520Z",
    "merge_after": "2018-09-07T11:16:00.000Z",
    "prepared_at": "2018-09-04T11:16:17.520Z",
    "closed_by": null,
    "closed_at": null,
    "created_at": "2017-04-29T08:46:00Z",
    "updated_at": "2017-04-29T08:46:00Z",
    "target_branch": "main",
    "source_branch": "test1",
    "upvotes": 0,
    "downvotes": 0,
    "author": {
      "id": 1,
      "name": "Administrator",
      "username": "admin",
      "state": "active",
      "locked": false,
      "avatar_url": null,
      "web_url" : "https://gitlab.example.com/admin"
    },
    "assignee": {
      "id": 1,
      "name": "Administrator",
      "username": "admin",
      "state": "active",
      "locked": false,
      "avatar_url": null,
      "web_url" : "https://gitlab.example.com/admin"
    },
    "assignees": [{
      "name": "Miss Monserrate Beier",
      "username": "axel.block",
      "id": 12,
      "state": "active",
      "locked": false,
      "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
      "web_url": "https://gitlab.example.com/axel.block"
    }],
    "reviewers": [{
      "id": 2,
      "name": "Sam Bauch",
      "username": "kenyatta_oconnell",
      "state": "active",
      "avatar_url": "https://www.gravatar.com/avatar/956c92487c6f6f7616b536927e22c9a0?s=80&d=identicon",
      "web_url": "http://gitlab.example.com//kenyatta_oconnell"
    }],
    "source_project_id": 2,
    "target_project_id": 3,
    "labels": [
      "Community contribution",
      "Manage"
    ],
    "draft": false,
    "work_in_progress": false,
    "milestone": {
      "id": 5,
      "iid": 1,
      "project_id": 3,
      "title": "v2.0",
      "description": "Assumenda aut placeat expedita exercitationem labore sunt enim earum.",
      "state": "closed",
      "created_at": "2015-02-02T19:49:26.013Z",
      "updated_at": "2015-02-02T19:49:26.013Z",
      "due_date": "2018-09-22",
      "start_date": "2018-08-08",
      "web_url": "https://gitlab.example.com/my-group/my-project/milestones/1"
    },
    "merge_when_pipeline_succeeds": true,
    "merge_status": "can_be_merged",
    "detailed_merge_status": "not_open",
    "sha": "8888888888888888888888888888888888888888",
    "merge_commit_sha": null,
    "squash_commit_sha": null,
    "user_notes_count": 1,
    "discussion_locked": null,
    "should_remove_source_branch": true,
    "force_remove_source_branch": false,
    "web_url": "http://gitlab.example.com/my-group/my-project/merge_requests/1",
    "reference": "!1",
    "references": {
      "short": "!1",
      "relative": "!1",
      "full": "my-group/my-project!1"
    },
    "time_stats": {
      "time_estimate": 0,
      "total_time_spent": 0,
      "human_time_estimate": null,
      "human_total_time_spent": null
    },
    "squash": false,
    "squash_on_merge": false,
    "task_completion_status":{
      "count":0,
      "completed_count":0
    },
    "has_conflicts": false,
    "blocking_discussions_resolved": true,
    "approvals_before_merge": 2
  }
]
```

For important notes on response data, see [Merge requests list response notes](https://docs.gitlab.com/api/merge_requests/#merge-requests-list-response-notes).
## List group merge requests[](https://docs.gitlab.com/api/merge_requests/#list-group-merge-requests "Permalink")
List all merge requests for a group and its subgroups.
```
GET /groups/:id/merge_requests
GET /groups/:id/merge_requests?state=opened
GET /groups/:id/merge_requests?state=all
GET /groups/:id/merge_requests?milestone=release
GET /groups/:id/merge_requests?labels=bug,reproduced
GET /groups/:id/merge_requests?my_reaction_emoji=star
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path](https://docs.gitlab.com/api/rest/#namespaced-paths) of the group.
`approved` | string | No | If `yes`, returns only approved merge requests. `no` returns only non-approved merge requests.
`approved_by_ids` | integer array | No | Returns the merge requests approved by all the users with the given `id`, up to 5 users. `None` returns merge requests with no approvals. `Any` returns merge requests with an approval. Premium and Ultimate only.
`approved_by_usernames` | string array | No | Returns the merge requests approved by all the users with the given `username`, up to 5 users. `None` returns merge requests with no approvals. `Any` returns merge requests with an approval. Premium and Ultimate only.
`approver_ids` | integer array | No | Returns merge requests which have specified all the users with the given `id` as individual approvers. `None` returns merge requests without approvers. `Any` returns merge requests with an approver. Premium and Ultimate only.
`assignee_id` | integer or string | No | Returns merge requests assigned to the given user `id`. `None` returns unassigned merge requests. `Any` returns merge requests with an assignee. Mutually exclusive with `assignee_username`.
`assignee_username[]` | array | No | Returns merge requests assigned to the given usernames. Mutually exclusive with `assignee_id`.
`author_id` | integer | No | Returns merge requests created by the given user `id`. Mutually exclusive with `author_username`.
`author_username` | string | No | Returns merge requests created by the given `username`. Mutually exclusive with `author_id`.
`created_after` | datetime | No | Returns merge requests created on or after the given time. Expected in ISO 8601 format (`2019-03-15T08:00:00Z`).
`created_before` | datetime | No | Returns merge requests created on or before the given time. Expected in ISO 8601 format (`2019-03-15T08:00:00Z`).
`deployed_after` | datetime | No | Returns merge requests deployed after the given time. Expected in ISO 8601 format (`2019-03-15T08:00:00Z`).
`deployed_before` | datetime | No | Returns merge requests deployed before the given time. Expected in ISO 8601 format (`2019-03-15T08:00:00Z`).
`environment` | string | No | Returns merge requests deployed to the given environment.
`in` | string | No | If set, modifies the scope of the search attribute. Can be `title`, `description`, or a string joining them with a comma, like `"title,description"`
`labels` | string | No | Returns merge requests matching a comma-separated list of labels. `None` lists all merge requests with no labels. `Any` lists all merge requests with at least one label. Predefined names are case-insensitive.
`merge_user_id` | integer | No | Returns merge requests merged by the user with the given user `id`. Mutually exclusive with `merge_user_username`. [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/140002) in GitLab 17.0.
`merge_user_username` | string | No | Returns merge requests merged by the user with the given `username`. Mutually exclusive with `merge_user_id`. [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/140002) in GitLab 17.0.
`milestone` | string | No | Returns merge requests for a specific milestone. `None` returns merge requests with no milestone. `Any` returns merge requests that have an assigned milestone.
`my_reaction_emoji` | string | No | Returns merge requests reacted by the authenticated user by the given `emoji`. `None` returns issues not given a reaction. `Any` returns issues given at least one reaction.
`non_archived` | boolean | No | When `true`, returns merge requests from non-archived projects only. Default is `true`.
`not` | hash | No | Returns merge requests that do not match the parameters supplied. Can be: `labels`, `milestone`, `author_id`, `author_username`, `assignee_id`, `assignee_username`, `reviewer_id`, `reviewer_username`, `my_reaction_emoji`.
`order_by` | string | No | Returns merge requests ordered by `created_at`, `label_priority`, `merged_at`, `milestone_due`, `popularity`, `priority`, `title`, or `updated_at` fields. Default is `created_at`.
`page` | integer | No | Returns the current page number. Defaults to `1`.
`per_page` | integer | No | Number of items per page to return. Defaults to `20`.
`reviewer_id` | integer or string | No | Returns merge requests which have the user as a [reviewer](https://docs.gitlab.com/user/project/merge_requests/reviews/) with the given user `id`. `None` returns merge requests with no reviewers. `Any` returns merge requests with any reviewer. Mutually exclusive with `reviewer_username`.
`reviewer_username` | string | No | Returns merge requests which have the user as a [reviewer](https://docs.gitlab.com/user/project/merge_requests/reviews/) with the given `username`. `None` returns merge requests with no reviewers. `Any` returns merge requests with any reviewer. Mutually exclusive with `reviewer_id`.
`scope` | string | No | Returns merge requests for the given scope: `created_by_me`, `assigned_to_me`, `reviews_for_me`, or `all`. Defaults to `created_by_me`. `reviews_for_me` returns merge requests where the current user is assigned as a reviewer.
`search` | string | No | Search merge requests against their `title` and `description`.
`source_branch` | string | No | Returns merge requests with the given source branch.
`source_project_id` | integer | No | Returns merge requests with the given source project ID.
`sort` | string | No | Returns merge requests sorted in `asc` or `desc` order. Default is `desc`.
`state` | string | No | Returns all merge requests or just those that are `opened`, `closed`, `locked`, or `merged`. Defaults to `all`.
`target_branch` | string | No | Returns merge requests with the given target branch.
`updated_after` | datetime | No | Returns merge requests updated on or after the given time. Expected in ISO 8601 format (`2019-03-15T08:00:00Z`).
`updated_before` | datetime | No | Returns merge requests updated on or before the given time. Expected in ISO 8601 format (`2019-03-15T08:00:00Z`).
`view` | string | No | If `simple`, returns the `iid`, URL, title, description, and basic state of merge request.
`with_labels_details` | boolean | No | If `true`, response returns more details for each label in labels field: `:name`, `:color`, `:description`, `:description_html`, `:text_color`. Default is `false`.
`with_merge_status_recheck` | boolean | No | If `true`, requests (but does not guarantee) an asynchronous recalculation of the `merge_status` field. Enable the `restrict_merge_status_recheck` [feature flag](https://docs.gitlab.com/administration/feature_flags/) to ignore this attribute when requested by users without the Developer, Maintainer, or Owner role.
`wip` | string | No | Filter merge requests against their `wip` status. Use `yes` to return only draft merge requests, `no` to return non-draft merge requests.
In the response, `group_id` represents the ID of the group containing the project where the merge request resides.
If successful, returns [`200 OK`](https://docs.gitlab.com/api/rest/troubleshooting/#status-codes). If `view` is set to `simple`, returns a subset of fields. Otherwise, response attributes include:
Attribute | Type | Description
---|---|---
`allow_collaboration` | boolean | If `true`, this fork allows collaboration from members who can merge to the target branch. Used only for merge requests from forks.
`allow_maintainer_to_push` | boolean | Deprecated. Use `allow_collaboration` instead.
`approvals_before_merge` | integer |  [Deprecated](https://gitlab.com/gitlab-org/gitlab/-/issues/353097) in GitLab 16.0. To configure approval rules, see [Merge request approvals API](https://docs.gitlab.com/api/merge_request_approvals/) instead. GitLab Premium and Ultimate only.
`assignee[]` | object | Deprecated. Use `assignees` instead.
`assignees[]` | array | Users assigned to the merge request.
`assignees.avatar_url` | string | Full URL to the assignee’s avatar image.
`assignees.id` | integer | The unique ID of the assignee.
`assignees.locked` | boolean | If `true`, the assignee’s account is locked due to failed authentication attempts, and they cannot sign in until the lock expires or an administrator unlocks the account.
`assignees.name` | string | Display name of the assignee. Might be redacted, based on current user’s permissions.
`assignees.public_email` | string | The public email address of the assignee.
`assignees.state` | string | Current state of the assignee’s user account. Possible values: `active`, `blocked`, or `deactivated`.
`assignees.username` | string | Username of the merge request assignee.
`assignees.web_url` | string | Full URL to the assignee’s profile page.
`author[]` | object | Object with information about the user who created the merge request.
`author.avatar_url` | string | Full URL to the author’s avatar image.
`author.id` | integer | The unique ID of the user who created the merge request.
`author.locked` | boolean | If `true`, the author’s account is locked due to failed authentication attempts, and they cannot sign in until the lock expires or an administrator unlocks the account.
`author.name` | string | Display name of the author. Might be redacted, based on current user’s permissions.
`author.public_email` | string | The public email address of the author.
`author.state` | string | Current state of the user account. Possible values: `active`, `blocked`, or `deactivated`.
`author.username` | string | Username of the merge request author.
`author.web_url` | string | Full URL to the author’s profile page.
`blocking_discussions_resolved` | boolean | If `true`, all discussion threads in the merge request must be resolved before merging.
`closed_at` | dateTime | Timestamp of when the merge request was closed.
`closed_by[]` | object | Object with information about the user who closed the merge request. If `null`, the merge request is open.
`closed_by.avatar_url` | string | Full URL to the closing user’s avatar image.
`closed_by.id` | integer | The unique ID of the user who closed the merge request.
`closed_by.locked` | boolean | If `true`, the closing user’s account is locked due to failed authentication attempts, and they cannot sign in until the lock expires or an administrator unlocks the account.
`closed_by.name` | string | Display name of the closing user. Might be redacted, based on current user’s permissions.
`closed_by.public_email` | string | The public email address of the closing user.
`closed_by.state` | string | Current state of the closing user’s account. Possible values: `active`, `blocked`, or `deactivated`.
`closed_by.username` | string | Username of the user who closed the merge request.
`closed_by.web_url` | string | Full URL to the closing user’s profile page.
`created_at` | dateTime | Timestamp of when the merge request was created.
`description` | string | Description of the merge request. Contains Markdown rendered as HTML for caching.
`detailed_merge_status` | string | Detailed merge status information. See [merge status](https://docs.gitlab.com/api/merge_requests/#merge-status) for a list of potential values.
`discussion_locked` | boolean | If `true`, discussions are locked. Only project members can add, edit or resolve comments in locked discussions.
`downvotes` | integer | Number of downvotes for the merge request.
`draft` | boolean | If `true`, the merge request is marked in a `draft` state.
`force_remove_source_branch` | boolean | If `true`, the project settings force the deletion of the source branch after merge.
`has_conflicts` | boolean | If `true`, the merge request has conflicts and cannot merge. Dependent on the `merge_status` property. Returns `false` unless `merge_status` is `cannot_be_merged`.
`id` | integer | The unique ID of the merge request.
`iid` | integer | The internal ID of the merge request in the project.
`imported` | boolean | If `true`, the merge request was imported.
`imported_from` | string | Source of import, such as `Bitbucket`.
`labels[]` | array | Array of label assigned to the merge request. If `with_labels_details` is `true`, returns an array for each label.
`labels.archived` | boolean | If `with_labels_details` is `true`, the label is archived.
`labels.color` | string | If `with_labels_details` is `true`, the background color of the label.
`labels.description` | string | If `with_labels_details` is `true`, the description text of the label. If `null`, the label has no description.
`labels.description_html` | string | If `with_labels_details` is `true`, the HTML-rendered description of the label. If `null`, the label has no description.
`labels.id` | integer | If `with_labels_details` is `true`, the unique ID of the label.
`labels.name` | string | If `with_labels_details` is `true`, the name of the label.
`labels.text_color` | string | If `with_labels_details` is `true`, the text color for the label.
`merge_after` | dateTime | If set, timestamp after which the merge request can be merged. [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/510992) in GitLab 17.8.
`merge_commit_sha` | string | If set, the SHA of the merge request commit. Returns `null` until merged.
`merge_status` | string | Status of the merge request. Use `detailed_merge_status` instead, which accounts for all potential statuses. Affects the `has_conflicts` property. For important notes on response data, see [Single merge request response notes](https://docs.gitlab.com/api/merge_requests/#single-merge-request-response-notes). [Deprecated](https://gitlab.com/gitlab-org/gitlab/-/issues/3169#note_1162532204) in GitLab 15.6.
`merge_user` | object | Object with information about the user who merged the merge request, set it to auto-merge, or `null`.
`merge_when_pipeline_succeeds` | boolean | If `true`, the merge request is set to auto-merge.
`merged_at` | dateTime | Timestamp of when the merge request merged.
`merged_by[]` | object | Deprecated. Use `merge_user` instead.
`milestone[]` | object | Object with information about the milestone assigned to the merge request.
`milestone.created_at` | dateTime | Timestamp when the milestone was created.
`milestone.description` | string | Description text of the milestone. If `null`, the milestone has no description.
`milestone.due_date` | date | Due date for the milestone. If `null`, the milestone has no due date.
`milestone.expired` | boolean | If `true`, the milestone has expired.
`milestone.group_id` | integer | ID of the group the milestone belongs to. Included only if the milestone is a group milestone.
`milestone.id` | integer | Unique ID of the milestone.
`milestone.iid` | integer | Internal ID of the milestone in the project or group.
`milestone.project_id` | integer | ID of the project the milestone belongs to. Included only if the milestone is a project milestone.
`milestone.start_date` | date | Start date for the milestone. If `null`, the milestone has no start date
`milestone.state` | string | Current state of the milestone, such as `active` or `closed`.
`milestone.title` | string | Name of the milestone.
`milestone.updated_at` | dateTime | Timestamp when the milestone was last updated.
`milestone.web_url` | string | Full web URL to view the milestone.
`prepared_at` | dateTime | Timestamp of when the merge request was prepared. This field populates one time, only after all the [preparation steps](https://docs.gitlab.com/api/merge_requests/#preparation-steps) complete, and is not updated if more changes are added.
`project_id` | integer | The ID of the project containing the merge request.
`reference` | string | Deprecated. Use `references` instead.
`references[]` | object | Object with all internal references of the merge request.
`references.full` | string | Complete reference to a merge request, including full project path, like `gitlab-org/gitlab!123`. When requested across groups or projects, identical to `references.relative`.
`references.relative` | string | Reference relative to a specific project or group: `!123` for a merge request in the current project, or `other-project!123` for another project in the same group.
`references.short` | string | Shortest possible reference to a merge request, like `!123`. When fetched from the merge request’s project, identical to `references.relative`.
`reviewers[]` | array | Reviewers of the merge request.
`reviewers.avatar_url` | string | Full URL to the reviewer’s avatar image.
`reviewers.id` | integer | The unique ID of the reviewer.
`reviewers.locked` | boolean | If `true`, the reviewer’s account is locked due to failed authentication attempts, and they cannot sign in until the lock expires or an administrator unlocks the account.
`reviewers.name` | string | Display name of the reviewer. Might be redacted, based on current user’s permissions.
`reviewers.public_email` | string | The public email address of the reviewer.
`reviewers.state` | string | Current state of the reviewer’s user account. Possible values: `active`, `blocked`, or `deactivated`.
`reviewers.username` | string | Username of the merge request reviewer.
`reviewers.web_url` | string | Full URL to the reviewer’s profile page.
`sha` | string | SHA of the head commit in the source branch.
`should_remove_source_branch` | boolean | If `true`, the source branch is removed after merge.
`source_branch` | string | Name of the source branch.
`source_project_id` | integer | ID of the source project.
`squash` | boolean | If `true`, squash commits when merging.
`squash_commit_sha` | string | If set, the SHA of the squash commit. Empty until merged.
`squash_on_merge` | boolean | If `true`, commits are squashed on merge.
`state` | string | The current state of the merge request. Possible values: `opened`, `closed`, `merged`, or `locked`.
`target_branch` | string | Name of the target branch.
`target_project_id` | integer | ID of the target project.
`task_completion_status[]` | object | Object with information on the task list completion status.
`task_completion_status.completed_count` | integer | Number of completed task list items in the merge request description. Returns `0` if the merge request has no description or no task list items.
`task_completion_status.count` | integer | Total number of task list items found in the merge request description. Returns `0` if the merge request has no description or no task list items.
`time_stats[]` | object | Object with information on time tracking for this merge request.
`time_stats.human_time_estimate` | string | Human-readable format of `time_stats.time_estimate`, like `3h 30m`.
`time_stats.human_total_time_spent` | string | Human-readable format of `time_stats.total_time_spent`, like `3h 30m`.
`time_stats.time_estimate` | integer | Estimated time to complete the merge request, in seconds.
`time_stats.total_time_spent` | integer | Total time spent working on the merge request, in seconds.
`title` | string | The merge request title.
`updated_at` | dateTime | Timestamp of when the merge request was last updated.
`upvotes` | integer | Number of upvotes for the merge request.
`user_notes_count` | integer | Number of user comments.
`web_url` | string | Web URL to view the merge request.
`work_in_progress` | boolean | Deprecated. Use `draft` instead.
Other possible responses:
  * `401 Unauthorized` if the access token is invalid.
  * `404 Not Found` if the project or merge request is not found.
  * `422 Unprocessable Entity` if validation failed.
  * `429 Too Many Requests` if using the `search` parameter, and the request has been rate-limited.


Example response:
json
```
[
  {
    "id": 1,
    "iid": 1,
    "project_id": 3,
    "title": "test1",
    "description": "fixed login page css paddings",
    "state": "merged",
    "imported": false,
    "imported_from": "none",
    "merged_by": { // Deprecated and will be removed in API v5, use `merge_user` instead
      "id": 87854,
      "name": "Douwe Maan",
      "username": "DouweM",
      "state": "active",
      "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
      "web_url": "https://gitlab.com/DouweM"
    },
    "merge_user": {
      "id": 87854,
      "name": "Douwe Maan",
      "username": "DouweM",
      "state": "active",
      "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
      "web_url": "https://gitlab.com/DouweM"
    },
    "merged_at": "2018-09-07T11:16:17.520Z",
    "merge_after": "2018-09-07T11:16:00.000Z",
    "prepared_at": "2018-09-04T11:16:17.520Z",
    "closed_by": null,
    "closed_at": null,
    "created_at": "2017-04-29T08:46:00Z",
    "updated_at": "2017-04-29T08:46:00Z",
    "target_branch": "main",
    "source_branch": "test1",
    "upvotes": 0,
    "downvotes": 0,
    "author": {
      "id": 1,
      "name": "Administrator",
      "username": "admin",
      "state": "active",
      "avatar_url": null,
      "web_url" : "https://gitlab.example.com/admin"
    },
    "assignee": {
      "id": 1,
      "name": "Administrator",
      "username": "admin",
      "state": "active",
      "avatar_url": null,
      "web_url" : "https://gitlab.example.com/admin"
    },
    "assignees": [{
      "name": "Miss Monserrate Beier",
      "username": "axel.block",
      "id": 12,
      "state": "active",
      "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
      "web_url": "https://gitlab.example.com/axel.block"
    }],
    "reviewers": [{
      "id": 2,
      "name": "Sam Bauch",
      "username": "kenyatta_oconnell",
      "state": "active",
      "avatar_url": "https://www.gravatar.com/avatar/956c92487c6f6f7616b536927e22c9a0?s=80&d=identicon",
      "web_url": "http://gitlab.example.com//kenyatta_oconnell"
    }],
    "source_project_id": 2,
    "target_project_id": 3,
    "labels": [
      "Community contribution",
      "Manage"
    ],
    "draft": false,
    "work_in_progress": false,
    "milestone": {
      "id": 5,
      "iid": 1,
      "project_id": 3,
      "title": "v2.0",
      "description": "Assumenda aut placeat expedita exercitationem labore sunt enim earum.",
      "state": "closed",
      "created_at": "2015-02-02T19:49:26.013Z",
      "updated_at": "2015-02-02T19:49:26.013Z",
      "due_date": "2018-10-22",
      "start_date": "2018-09-08",
      "web_url": "gitlab.example.com/my-group/my-project/milestones/1"
    },
    "merge_when_pipeline_succeeds": true,
    "merge_status": "can_be_merged",
    "detailed_merge_status": "not_open",
    "sha": "8888888888888888888888888888888888888888",
    "merge_commit_sha": null,
    "squash_commit_sha": null,
    "user_notes_count": 1,
    "discussion_locked": null,
    "should_remove_source_branch": true,
    "force_remove_source_branch": false,
    "web_url": "http://gitlab.example.com/my-group/my-project/merge_requests/1",
    "references": {
      "short": "!1",
      "relative": "my-project!1",
      "full": "my-group/my-project!1"
    },
    "time_stats": {
      "time_estimate": 0,
      "total_time_spent": 0,
      "human_time_estimate": null,
      "human_total_time_spent": null
    },
    "squash": false,
    "task_completion_status":{
      "count":0,
      "completed_count":0
    },
    "has_conflicts": false,
    "blocking_discussions_resolved": true
  }
]
```

For important notes on response data, see [Merge requests list response notes](https://docs.gitlab.com/api/merge_requests/#merge-requests-list-response-notes).
## Retrieve a merge request[](https://docs.gitlab.com/api/merge_requests/#retrieve-a-merge-request "Permalink")
Retrieve information about a merge request.
```
GET /projects/:id/merge_requests/:merge_request_iid
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
`include_diverged_commits_count` | boolean | No | If `true`, response includes the commits behind the target branch.
`include_rebase_in_progress` | boolean | No | If `true`, response includes whether a rebase operation is in progress.
`render_html` | boolean | No | If `true`, response includes rendered HTML for title and description.
If successful, returns [`200 OK`](https://docs.gitlab.com/api/rest/troubleshooting/#status-codes). Other possible responses:
  * `401 Unauthorized` if the access token is invalid.
  * `403 Forbidden` if access is denied.
  * `404 Not Found` if the project or merge request is not found.
  * `408 Request Timeout` if the database query times out.
  * `409 Conflict` if a resource lock conflict exists.
  * `422 Unprocessable Entity` if validation failed.
  * `429 Too Many Requests` if using the `search` parameter, and the request has been rate-limited.


### Response[](https://docs.gitlab.com/api/merge_requests/#response "Permalink")
Attribute | Type | Description
---|---|---
`allow_collaboration` | boolean | If `true`, this fork allows collaboration from members who can merge to the target branch. Used only for merge requests from forks.
`allow_maintainer_to_push` | boolean | Deprecated. Use `allow_collaboration` instead.
`approvals_before_merge` | integer |  [Deprecated](https://gitlab.com/gitlab-org/gitlab/-/issues/353097) in GitLab 16.0. To configure approval rules, see [Merge request approvals API](https://docs.gitlab.com/api/merge_request_approvals/) instead. GitLab Premium and Ultimate only.
`assignee[]` | object | Deprecated. Use `assignees` instead.
`assignees[]` | array | Users assigned to the merge request.
`assignees.avatar_url` | string | Full URL to the assignee’s avatar image.
`assignees.id` | integer | The unique ID of the assignee.
`assignees.locked` | boolean | If `true`, the assignee’s account is locked due to failed authentication attempts, and they cannot sign in until the lock expires or an administrator unlocks the account.
`assignees.name` | string | Display name of the assignee. Might be redacted, based on current user’s permissions.
`assignees.public_email` | string | The public email address of the assignee.
`assignees.state` | string | Current state of the assignee’s user account. Possible values: `active`, `blocked`, or `deactivated`.
`assignees.username` | string | Username of the merge request assignee.
`assignees.web_url` | string | Full URL to the assignee’s profile page.
`author[]` | object | Object with information about the user who created the merge request.
`author.avatar_url` | string | Full URL to the author’s avatar image.
`author.id` | integer | The unique ID of the user who created the merge request.
`author.locked` | boolean | If `true`, the author’s account is locked due to failed authentication attempts, and they cannot sign in until the lock expires or an administrator unlocks the account.
`author.name` | string | Display name of the author. Might be redacted, based on current user’s permissions.
`author.public_email` | string | The public email address of the author.
`author.state` | string | Current state of the user account. Possible values: `active`, `blocked`, or `deactivated`.
`author.username` | string | Username of the merge request author.
`author.web_url` | string | Full URL to the author’s profile page.
`blocking_discussions_resolved` | boolean | If `true`, all discussion threads in the merge request must be resolved before merging.
`changes_count` | string | If set, the number of changes made on the merge request. Empty when the merge request is created. Populates asynchronously. A string, not an integer. When a merge request has too many changes to display and store, the value is capped at 1000 and returns the string `"1000+"`. See [Empty API Fields for new merge requests](https://docs.gitlab.com/api/merge_requests/#empty-api-fields-for-new-merge-requests).
`closed_at` | dateTime | Timestamp of when the merge request was closed.
`closed_by[]` | object | Object with information about the user who closed the merge request. If `null`, the merge request is open.
`closed_by.avatar_url` | string | Full URL to the closing user’s avatar image.
`closed_by.id` | integer | The unique ID of the user who closed the merge request.
`closed_by.locked` | boolean | If `true`, the closing user’s account is locked due to failed authentication attempts, and they cannot sign in until the lock expires or an administrator unlocks the account.
`closed_by.name` | string | Display name of the closing user. Might be redacted, based on current user’s permissions.
`closed_by.public_email` | string | The public email address of the closing user.
`closed_by.state` | string | Current state of the closing user’s account. Possible values: `active`, `blocked`, or `deactivated`.
`closed_by.username` | string | Username of the user who closed the merge request.
`closed_by.web_url` | string | Full URL to the closing user’s profile page.
`created_at` | datetime | Timestamp of when the merge request was created.
`description` | string | Description of the merge request. Contains Markdown rendered as HTML for caching.
`detailed_merge_status` | string | Detailed merge status information. See [merge status](https://docs.gitlab.com/api/merge_requests/#merge-status) for a list of potential values.
`diff_refs[]` | object | Object with references of the base, head, and start SHAs for this merge request. Corresponds to the latest diff version of the merge request. Empty when the merge request is created, and populates asynchronously. See [Empty API fields for new merge requests](https://docs.gitlab.com/api/merge_requests/#empty-api-fields-for-new-merge-requests).
`diff_refs.base_sha` | string | SHA of the merge base commit where the source and target branches diverged.
`diff_refs.start_sha` | string | SHA of the target branch commit. The starting point for the diff. Usually the same as `base_sha`.
`diff_refs.head_sha` | string | SHA of the head commit in the source branch. The latest commit in the merge request.
`discussion_locked` | boolean | If `true`, discussions are locked. Only project members can add, edit or resolve comments in locked discussions.
`diverged_commits_count` | integer | If set, contains the number of commits the source branch is behind the target branch.
`downvotes` | integer | Number of downvotes for the merge request.
`draft` | boolean | If `true`, the merge request is marked in a `draft` state.
`first_contribution` | boolean | If `true`, the author’s first contribution to this project.
`first_deployed_to_production_at` | datetime | Timestamp of when the first deployment finished.
`force_remove_source_branch` | boolean | If `true`, the project settings force the deletion of the source branch after merge.
`has_conflicts` | boolean | If `true`, the merge request has conflicts and cannot merge. Dependent on the `merge_status` property. Returns `false` unless `merge_status` is `cannot_be_merged`.
`head_pipeline[]` | object | Pipeline that runs on the HEAD commit of the merge request’s source branch. Use instead of `pipeline`, because it contains more complete information. Exposed only if the current user can view pipelines for this project.
`head_pipeline.before_sha` | string | SHA of the commit before this pipeline.
`head_pipeline.committed_at` | dateTime | Timestamp of when the commit was made.
`head_pipeline.coverage` | number | Test coverage percentage, like `98.29`.
`head_pipeline.created_at` | dateTime | Timestamp of when the pipeline was created.
`head_pipeline.detailed_status[]` | object | Object containing fields with the detailed status of this pipeline.
`head_pipeline.detailed_status.action[]` | object | If set, object containing available actions for this pipeline.
`head_pipeline.detailed_status.action.button_title` | string | Button title for the action.
`head_pipeline.detailed_status.action.confirmation_message` | string | Confirmation message for the action.
`head_pipeline.detailed_status.action.icon` | string | Icon for the action.
`head_pipeline.detailed_status.action.method` | string | HTTP method for the action, like `POST`.
`head_pipeline.detailed_status.action.path` | string | Path for the action, like `"/namespace1/project1/-/jobs/2/cancel"`.
`head_pipeline.detailed_status.action.title` | string | Title for the action.
`head_pipeline.detailed_status.details_path` | string | Path to detailed view, like `"/test-group/test-project/-/pipelines/287"`.
`head_pipeline.detailed_status.favicon` | string | Path to status favicon.
`head_pipeline.detailed_status.group` | string | Status group, like `success`.
`head_pipeline.detailed_status.has_details` | boolean | If set, a detailed view is available.
`head_pipeline.detailed_status.icon` | string | Status icon name, like `"status_success"`.
`head_pipeline.detailed_status.illustration.content` | string | Content text for the illustration, like `"This job depends on upstream jobs that need to succeed in order for this job to be triggered"`.
`head_pipeline.detailed_status.illustration.image` | string | Path to illustration image.
`head_pipeline.detailed_status.illustration.size` | string | Size of the illustration.
`head_pipeline.detailed_status.illustration.title` | string | Title for the illustration, like `"This job has not been triggered yet"`.
`head_pipeline.detailed_status.label` | string | Status label for the pipeline, like `"passed"`.
`head_pipeline.detailed_status.text` | string | Status text for the pipeline, like `"passed"`.
`head_pipeline.detailed_status.tooltip` | string | Tooltip text for the pipeline, like `"passed"`.
`head_pipeline.duration` | integer | Time spent running the pipeline, in seconds.
`head_pipeline.finished_at` | dateTime | Timestamp of when the pipeline finished.
`head_pipeline.id` | integer | Unique numeric identifier of the pipeline. Foreign key to the `ci_pipelines` table.
`head_pipeline.iid` | integer | Internal numeric ID of the pipeline.
`head_pipeline.project_id` | integer | Numeric ID of the project containing the pipeline.
`head_pipeline.queued_duration` | integer | Time spent enqueued, in seconds.
`head_pipeline.ref` | string | Name of the Git reference (branch or tag) the pipeline runs on.
`head_pipeline.sha` | string | SHA of the commit that triggered the pipeline.
`head_pipeline.source` | string | How the pipeline was triggered. For example `push`, `merge_request_event`, or `api`
`head_pipeline.started_at` | dateTime | Timestamp of when the pipeline started running.
`head_pipeline.status` | string | Current status of the pipeline. Possible values: `success`, `failed`, `running`, `pending`
`head_pipeline.tag` | boolean | If `true`, this pipeline is running on a Git tag.
`head_pipeline.updated_at` | dateTime | Timestamp of when the pipeline was last updated.
`head_pipeline.user[]` | object | Object containing information about the user who triggered the pipeline.
`head_pipeline.user.avatar_url` | string | Full URL to user’s avatar image.
`head_pipeline.user.id` | integer | The unique ID of the user who triggered the pipeline.
`head_pipeline.user.locked` | boolean | If `true`, the user account that triggered the pipeline is locked due to failed authentication attempts, and they cannot sign in until the lock expires or an administrator unlocks the account.
`head_pipeline.user.name` | string | Display name of the user who triggered the pipeline. Might be redacted, based on current user’s permissions.
`head_pipeline.user.public_email` | string | The public email address of the user who triggered the pipeline.
`head_pipeline.user.state` | string | Current state of the account of the user who triggered the pipeline. Possible values: `active`, `blocked`, or `deactivated`.
`head_pipeline.user.username` | string | Username of the user who triggered the pipeline.
`head_pipeline.user.web_url` | string | Full URL to the profile page of the user that triggered the pipeline.
`head_pipeline.web_url` | string | Full URL to the pipeline page.
`head_pipeline.yaml_errors` | string | Any YAML configuration errors. For example, `widgets:build: needs 'widgets:test'`)
`id` | integer | ID of the merge request.
`iid` | integer | Internal ID of the merge request.
`imported` | boolean | If `true`, the merge request was imported.
`imported_from` | string | Source of import, such as `Bitbucket`.
`labels[]` | array | Array of label assigned to the merge request. If `with_labels_details` is `true`, returns an array for each label.
`labels.archived` | boolean | If `with_labels_details` is `true`, the label is archived.
`labels.color` | string | If `with_labels_details` is `true`, the background color of the label.
`labels.description` | string | If `with_labels_details` is `true`, the description text of the label. If `null`, the label has no description.
`labels.description_html` | string | If `with_labels_details` is `true`, the HTML-rendered description of the label. If `null`, the label has no description.
`labels.id` | integer | If `with_labels_details` is `true`, the unique ID of the label.
`labels.name` | string | If `with_labels_details` is `true`, the name of the label.
`labels.text_color` | string | If `with_labels_details` is `true`, the text color for the label.
`latest_build_finished_at` | datetime | Timestamp of when the latest build for the merge request finished.
`latest_build_started_at` | datetime | Timestamp of when the latest build for the merge request started.
`merge_after` | dateTime | If set, timestamp after which the merge request can be merged. [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/510992) in GitLab 17.8.
`merge_commit_sha` | string | If set, the SHA of the merge request commit. Returns `null` until merged.
`merge_error` | string | If set, the error message shown when a merge fails. To check mergeability, use `detailed_merge_status` instead.
`merge_status` | string | Status of the merge request. Use `detailed_merge_status` instead, which accounts for all potential statuses. Affects the `has_conflicts` property. For important notes on response data, see [Single merge request response notes](https://docs.gitlab.com/api/merge_requests/#single-merge-request-response-notes). [Deprecated](https://gitlab.com/gitlab-org/gitlab/-/issues/3169#note_1162532204) in GitLab 15.6.
`merge_user[]` | object | The user who merged this merge request, the user who set it to auto-merge, or `null`.
`merge_when_pipeline_succeeds` | boolean | If `true`, the merge request is set to auto-merge.
`merged_at` | dateTime | Timestamp of when the merge request merged.
`merged_by[]` | object | User who merged this merge request or set it to auto-merge. [Deprecated](https://gitlab.com/gitlab-org/gitlab/-/issues/350534) in GitLab 14.7, and scheduled for removal in [API version 5](https://gitlab.com/groups/gitlab-org/-/epics/8115). Use `merge_user` instead.
`milestone[]` | object | Object with information about the milestone assigned to the merge request.
`milestone.created_at` | dateTime | Timestamp when the milestone was created.
`milestone.description` | string | Description text of the milestone. If `null`, the milestone has no description.
`milestone.due_date` | date | Due date for the milestone. If `null`, the milestone has no due date.
`milestone.expired` | boolean | If `true`, the milestone has expired.
`milestone.group_id` | integer | ID of the group the milestone belongs to. Included only if the milestone is a group milestone.
`milestone.id` | integer | Unique ID of the milestone.
`milestone.iid` | integer | Internal ID of the milestone in the project or group.
`milestone.project_id` | integer | ID of the project the milestone belongs to. Included only if the milestone is a project milestone.
`milestone.start_date` | date | Start date for the milestone. If `null`, the milestone has no start date
`milestone.state` | string | Current state of the milestone, such as `active` or `closed`.
`milestone.title` | string | Name of the milestone.
`milestone.updated_at` | dateTime | Timestamp when the milestone was last updated.
`milestone.web_url` | string | Full web URL to view the milestone.
`pipeline[]` | object | Pipeline running on the branch HEAD of the merge request. Consider using `head_pipeline` instead, as it contains more information.
`prepared_at` | dateTime | Timestamp of when the merge request was prepared. This field populates one time, only after all the [preparation steps](https://docs.gitlab.com/api/merge_requests/#preparation-steps) complete, and is not updated if more changes are added.
`project_id` | integer | The ID of the project containing the merge request.
`rebase_in_progress` | boolean | If `true`, Sidekiq is running a rebase operation on this branch.
`reference` | string | Deprecated. Use `references` instead. [Deprecated](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/20354) in GitLab 12.7, and scheduled for removal in [API version 5](https://gitlab.com/groups/gitlab-org/-/epics/8115). Use `references` instead.
`references[]` | object | Object with all internal references of the merge request.
`references.full` | string | Complete reference to a merge request, including full project path, like `gitlab-org/gitlab!123`. When requested across groups or projects, identical to `references.relative`.
`references.relative` | string | Reference relative to a specific project or group: `!123` for a merge request in the current project, or `other-project!123` for another project in the same group.
`references.short` | string | Shortest possible reference to a merge request, like `!123`. When fetched from the merge request’s project, identical to `references.relative`.
`reviewers[]` | array | Reviewers of the merge request.
`reviewers.avatar_url` | string | Full URL to the reviewer’s avatar image.
`reviewers.id` | integer | The unique ID of the reviewer.
`reviewers.locked` | boolean | If `true`, the reviewer’s account is locked due to failed authentication attempts, and they cannot sign in until the lock expires or an administrator unlocks the account.
`reviewers.name` | string | Display name of the reviewer. Might be redacted, based on current user’s permissions.
`reviewers.public_email` | string | The public email address of the reviewer.
`reviewers.state` | string | Current state of the reviewer’s user account. Possible values: `active`, `blocked`, or `deactivated`.
`reviewers.username` | string | Username of the merge request reviewer.
`reviewers.web_url` | string | Full URL to the reviewer’s profile page.
`sha` | string | SHA of the head commit in the source branch.
`should_remove_source_branch` | boolean | If `true`, the source branch is removed after merge.
`source_branch` | string | Name of the source branch.
`source_project_id` | integer | ID of the source project.
`squash` | boolean | If `true`, squash commits when merging.
`squash_commit_sha` | string | If set, the SHA of the squash commit. Empty until merged.
`squash_on_merge` | boolean | If `true`, commits are squashed on merge.
`state` | string | The current state of the merge request. Possible values: `opened`, `closed`, `merged`, or `locked`.
`subscribed` | boolean | If `true`, the current authenticated user subscribes to this merge request.
`target_branch` | string | Name of the target branch.
`target_project_id` | integer | ID of the target project.
`task_completion_status[]` | object | Object with information on the task list completion status.
`task_completion_status.completed_count` | integer | Number of completed task list items in the merge request description. Returns `0` if the merge request has no description or no task list items.
`task_completion_status.count` | integer | Total number of task list items found in the merge request description. Returns `0` if the merge request has no description or no task list items.
`time_stats[]` | object | Object with information on time tracking for this merge request.
`time_stats.human_time_estimate` | string | Human-readable format of `time_stats.time_estimate`, like `3h 30m`.
`time_stats.human_total_time_spent` | string | Human-readable format of `time_stats.total_time_spent`, like `3h 30m`.
`time_stats.time_estimate` | integer | Estimated time to complete the merge request, in seconds.
`time_stats.total_time_spent` | integer | Total time spent working on the merge request, in seconds.
`title` | string | The merge request title.
`updated_at` | datetime | Timestamp of when the merge request was last updated.
`upvotes` | integer | Number of upvotes for the merge request.
`user[]` | object | Permissions of the user requested for the merge request.
`user.can_merge` | boolean | If `true`, the current authenticated user can merge this merge request.
`user_notes_count` | integer | Number of user comments.
`web_url` | string | Web URL to view the merge request.
`work_in_progress` | boolean | Deprecated. Use `draft` instead.
Example response:
json
```
{
  "id": 155016530,
  "iid": 133,
  "project_id": 15513260,
  "title": "Manual job rules",
  "description": "",
  "state": "opened",
  "imported": false,
  "imported_from": "none",
  "created_at": "2022-05-13T07:26:38.402Z",
  "updated_at": "2022-05-14T03:38:31.354Z",
  "merged_by": null, // Deprecated and will be removed in API v5. Use `merge_user` instead.
  "merge_user": null,
  "merged_at": null,
  "merge_after": "2018-09-07T11:16:00.000Z",
  "prepared_at": "2018-09-04T11:16:17.520Z",
  "closed_by": null,
  "closed_at": null,
  "target_branch": "main",
  "source_branch": "manual-job-rules",
  "user_notes_count": 0,
  "upvotes": 0,
  "downvotes": 0,
  "author": {
    "id": 4155490,
    "username": "marcel.amirault",
    "name": "Marcel Amirault",
    "state": "active",
    "avatar_url": "https://gitlab.com/uploads/-/system/user/avatar/4155490/avatar.png",
    "web_url": "https://gitlab.com/marcel.amirault"
  },
  "assignees": [],
  "assignee": null,
  "reviewers": [],
  "source_project_id": 15513260,
  "target_project_id": 15513260,
  "labels": [],
  "draft": false,
  "work_in_progress": false,
  "milestone": null,
  "merge_when_pipeline_succeeds": false,
  "merge_status": "can_be_merged",
  "detailed_merge_status": "mergeable",
  "sha": "e82eb4a098e32c796079ca3915e07487fc4db24c",
  "merge_commit_sha": null,
  "squash_commit_sha": null,
  "discussion_locked": null,
  "should_remove_source_branch": null,
  "force_remove_source_branch": true,
  "reference": "!133", // Deprecated. Use `references` instead.
  "references": {
    "short": "!133",
    "relative": "!133",
    "full": "marcel.amirault/test-project!133"
  },
  "web_url": "https://gitlab.com/marcel.amirault/test-project/-/merge_requests/133",
  "time_stats": {
    "time_estimate": 0,
    "total_time_spent": 0,
    "human_time_estimate": null,
    "human_total_time_spent": null
  },
  "squash": false,
  "task_completion_status": {
    "count": 0,
    "completed_count": 0
  },
  "has_conflicts": false,
  "blocking_discussions_resolved": true,
  "approvals_before_merge": null, // deprecated, use [Merge request approvals API](merge_request_approvals.md)
  "subscribed": true,
  "changes_count": "1",
  "latest_build_started_at": "2022-05-13T09:46:50.032Z",
  "latest_build_finished_at": null,
  "first_deployed_to_production_at": null,
  "pipeline": { // Use `head_pipeline` instead.
    "id": 538317940,
    "iid": 1877,
    "project_id": 15513260,
    "sha": "1604b0c46c395822e4e9478777f8e54ac99fe5b9",
    "ref": "refs/merge-requests/133/merge",
    "status": "failed",
    "source": "merge_request_event",
    "created_at": "2022-05-13T09:46:39.560Z",
    "updated_at": "2022-05-13T09:47:20.706Z",
    "web_url": "https://gitlab.com/marcel.amirault/test-project/-/pipelines/538317940"
  },
  "head_pipeline": {
    "id": 538317940,
    "iid": 1877,
    "project_id": 15513260,
    "sha": "1604b0c46c395822e4e9478777f8e54ac99fe5b9",
    "ref": "refs/merge-requests/133/merge",
    "status": "failed",
    "source": "merge_request_event",
    "created_at": "2022-05-13T09:46:39.560Z",
    "updated_at": "2022-05-13T09:47:20.706Z",
    "web_url": "https://gitlab.com/marcel.amirault/test-project/-/pipelines/538317940",
    "before_sha": "1604b0c46c395822e4e9478777f8e54ac99fe5b9",
    "tag": false,
    "yaml_errors": null,
    "user": {
      "id": 4155490,
      "username": "marcel.amirault",
      "name": "Marcel Amirault",
      "state": "active",
      "avatar_url": "https://gitlab.com/uploads/-/system/user/avatar/4155490/avatar.png",
      "web_url": "https://gitlab.com/marcel.amirault"
    },
    "started_at": "2022-05-13T09:46:50.032Z",
    "finished_at": "2022-05-13T09:47:20.697Z",
    "committed_at": null,
    "duration": 30,
    "queued_duration": 10,
    "coverage": null,
    "detailed_status": {
      "icon": "status_failed",
      "text": "failed",
      "label": "failed",
      "group": "failed",
      "tooltip": "failed",
      "has_details": true,
      "details_path": "/marcel.amirault/test-project/-/pipelines/538317940",
      "illustration": null,
      "favicon": "/assets/ci_favicons/favicon_status_failed-41304d7f7e3828808b0c26771f0309e55296819a9beea3ea9fbf6689d9857c12.png"
    },
    "archived": false
  },
  "diff_refs": {
    "base_sha": "1162f719d711319a2efb2a35566f3bfdadee8bab",
    "head_sha": "e82eb4a098e32c796079ca3915e07487fc4db24c",
    "start_sha": "1162f719d711319a2efb2a35566f3bfdadee8bab"
  },
  "merge_error": null,
  "first_contribution": false,
  "user": {
    "can_merge": true
  },
  "approvals_before_merge": { // Available for GitLab Premium and Ultimate tiers only
    "id": 1,
    "title": "test1",
    "approvals_before_merge": null
  },
}
```

### Single merge request response notes[](https://docs.gitlab.com/api/merge_requests/#single-merge-request-response-notes "Permalink")
The mergeability (`merge_status`) of each merge request is checked asynchronously when a request is made to this endpoint. Poll this API endpoint to get the updated status. This affects the `has_conflicts` property, as it depends on the `merge_status`. It returns `false` unless `merge_status` is `cannot_be_merged`.
### Merge status[](https://docs.gitlab.com/api/merge_requests/#merge-status "Permalink")
Use `detailed_merge_status` instead of `merge_status` to account for all potential statuses.
  * The `detailed_merge_status` field can contain one of the following values related to the merge request:
    * `approvals_syncing`: The merge request’s approvals are syncing.
    * `checking`: Git is testing if a valid merge is possible.
    * `ci_must_pass`: A CI/CD pipeline must succeed before merge.
    * `ci_still_running`: A CI/CD pipeline is still running.
    * `commits_status`: Source branch should exist, and contain commits.
    * `conflict`: Conflicts exist between the source and target branches.
    * `discussions_not_resolved`: All discussions must be resolved before merge.
    * `draft_status`: Can’t merge because the merge request is a draft.
    * `jira_association_missing`: The title or description must reference a Jira issue. To configure, see [Require associated Jira issue for merge requests to be merged](https://docs.gitlab.com/integration/jira/issues/#require-associated-jira-issue-for-merge-requests-to-be-merged).
    * `mergeable`: The branch can merge cleanly into the target branch.
    * `merge_request_blocked`: Blocked by another merge request.
    * `merge_time`: May not be merged until after the specified time.
    * `need_rebase`: The merge request must be rebased.
    * `not_approved`: Approval is required before merge.
    * `not_open`: The merge request must be open before merge.
    * `preparing`: Merge request diff is being created.
    * `requested_changes`: The merge request has reviewers who have requested changes.
    * `security_policy_violations`: All security policies must be satisfied.
    * `status_checks_must_pass`: All status checks must pass before merge.
    * `unchecked`: Git has not yet tested if a valid merge is possible.
    * `locked_paths`: Paths locked by other users must be unlocked before merging to default branch.
    * `locked_lfs_files`: LFS files locked by other users must be unlocked before merge.
    * `title_regex`: Checks whether the title matches the expected regex, if configured in project settings.


### Preparation steps[](https://docs.gitlab.com/api/merge_requests/#preparation-steps "Permalink")
The `prepared_at` field populates one time, only after these steps complete:
  * Create the diff.
  * Create the pipelines.
  * Check mergeability.
  * Link all Git LFS objects.
  * Send notifications.


The `prepared_at` field does not update if more changes are added to the merge request.
## Retrieve merge request participants[](https://docs.gitlab.com/api/merge_requests/#retrieve-merge-request-participants "Permalink")
Retrieve participants for a merge request.
```
GET /projects/:id/merge_requests/:merge_request_iid/participants
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
Example response:
json
```
[
  {
    "id": 1,
    "name": "John Doe1",
    "username": "user1",
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/c922747a93b40d1ea88262bf1aebee62?s=80&d=identicon",
    "web_url": "http://localhost/user1"
  },
  {
    "id": 2,
    "name": "John Doe2",
    "username": "user2",
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/10fc7f102be8de7657fb4d80898bbfe3?s=80&d=identicon",
    "web_url": "http://localhost/user2"
  }
]
```

## Retrieve merge request reviewers[](https://docs.gitlab.com/api/merge_requests/#retrieve-merge-request-reviewers "Permalink")
Retrieve reviewers for a merge request.
```
GET /projects/:id/merge_requests/:merge_request_iid/reviewers
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
Example response:
json
```
[
  {
    "user": {
      "id": 1,
      "name": "John Doe1",
      "username": "user1",
      "state": "active",
      "avatar_url": "http://www.gravatar.com/avatar/c922747a93b40d1ea88262bf1aebee62?s=80&d=identicon",
      "web_url": "http://localhost/user1"
    },
    "state": "unreviewed",
    "created_at": "2022-07-27T17:03:27.684Z"
  },
  {
    "user": {
      "id": 2,
      "name": "John Doe2",
      "username": "user2",
      "state": "active",
      "avatar_url": "http://www.gravatar.com/avatar/10fc7f102be8de7657fb4d80898bbfe3?s=80&d=identicon",
      "web_url": "http://localhost/user2"
    },
    "state": "reviewed",
    "created_at": "2022-07-27T17:03:27.684Z"
  }
]
```

## Retrieve merge request commits[](https://docs.gitlab.com/api/merge_requests/#retrieve-merge-request-commits "Permalink")
Retrieve commits for a merge request.
```
GET /projects/:id/merge_requests/:merge_request_iid/commits
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | Internal ID of the merge request.
If successful, returns [`200 OK`](https://docs.gitlab.com/api/rest/troubleshooting/#status-codes) and the following response attributes:
Attribute | Type | Description
---|---|---
`commits` | object array | Commits in the merge request.
`commits[].id` | string | ID of the commit.
`commits[].short_id` | string | Short ID of the commit.
`commits[].created_at` | datetime | Identical to the `committed_date` field.
`commits[].parent_ids` | array | IDs of the parent commits.
`commits[].title` | string | Commit title.
`commits[].message` | string | Commit message.
`commits[].author_name` | string | Commit author’s name.
`commits[].author_email` | string | Commit author’s email address.
`commits[].authored_date` | datetime | Commit authored date.
`commits[].committer_name` | string | Name of the committer.
`commits[].committer_email` | string | Email address of the committer.
`commits[].committed_date` | datetime | Commit date.
`commits[].trailers` | object | Git trailers parsed for the commit. Duplicate keys include the last value only.
`commits[].extended_trailers` | object | Git trailers parsed for the commit.
`commits[].web_url` | string | Web URL of the merge request.
Example request:
shell
```
curl --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/1/merge_requests/1/commits"
```

Example response:
json
```
[
  {
    "id": "ed899a2f4b50b4370feeea94676502b42383c746",
    "short_id": "ed899a2f4b5",
    "title": "Replace sanitize with escape once",
    "author_name": "Example User",
    "author_email": "user@example.com",
    "authored_date": "2012-09-20T11:50:22+03:00",
    "committer_name": "Example User",
    "committer_email": "user@example.com",
    "committed_date": "2012-09-20T11:50:22+03:00",
    "created_at": "2012-09-20T11:50:22+03:00",
    "message": "Replace sanitize with escape once",
    "trailers": {},
    "extended_trailers": {},
    "web_url": "https://gitlab.example.com/project/-/commit/ed899a2f4b50b4370feeea94676502b42383c746"
  },
  {
    "id": "6104942438c14ec7bd21c6cd5bd995272b3faff6",
    "short_id": "6104942438c",
    "title": "Sanitize for network graph",
    "author_name": "Example User",
    "author_email": "user@example.com",
    "authored_date": "2012-09-20T09:06:12+03:00",
    "committer_name": "Example User",
    "committer_email": "user@example.com",
    "committed_date": "2012-09-20T09:06:12+03:00",
    "created_at": "2012-09-20T09:06:12+03:00",
    "message": "Sanitize for network graph",
    "trailers": {},
    "extended_trailers": {},
    "web_url": "https://gitlab.example.com/project/-/commit/6104942438c14ec7bd21c6cd5bd995272b3faff6"
  }
]
```

## Retrieve merge request dependencies[](https://docs.gitlab.com/api/merge_requests/#retrieve-merge-request-dependencies "Permalink")
Retrieve dependencies that must be resolved before a merge request can be merged.
If the user does not have access to the blocking merge request, no `blocking_merge_request` attribute is returned.
```
GET /projects/:id/merge_requests/:merge_request_iid/blocks
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
Example request:
shell
```
curl --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/1/merge_requests/1/blocks"
```

Example response:
json
```
[
  {
    "id": 1,
    "blocking_merge_request": {
      "id": 145,
      "iid": 12,
      "project_id": 7,
      "title": "Interesting MR",
      "description": "Does interesting things.",
      "state": "opened",
      "created_at": "2024-07-05T21:29:11.172Z",
      "updated_at": "2024-07-05T21:29:11.172Z",
      "merged_by": null,
      "merge_user": null,
      "merged_at": null,
      "merge_after": "2018-09-07T11:16:00.000Z",
      "closed_by": null,
      "closed_at": null,
      "target_branch": "master",
      "source_branch": "v2.x",
      "user_notes_count": 0,
      "upvotes": 0,
      "downvotes": 0,
      "author": {
        "id": 2,
        "username": "aiguy123",
        "name": "AI GUY",
        "state": "active",
        "locked": false,
        "avatar_url": "https://www.gravatar.com/avatar/0?s=80&d=identicon",
        "web_url": "https://localhost/aiguy123"
      },
      "assignees": [
        {
          "id": 2,
          "username": "aiguy123",
          "name": "AI GUY",
          "state": "active",
          "locked": false,
          "avatar_url": "https://www.gravatar.com/avatar/0?s=80&d=identicon",
          "web_url": "https://localhost/aiguy123"
        }
      ],
      "assignee": {
        "id": 2,
        "username": "aiguy123",
        "name": "AI GUY",
        "state": "active",
        "locked": false,
        "avatar_url": "https://www.gravatar.com/avatar/0?s=80&d=identicon",
        "web_url": "https://localhost/aiguy123"
      },
      "reviewers": [
        {
          "id": 2,
          "username": "aiguy123",
          "name": "AI GUY",
          "state": "active",
          "locked": false,
          "avatar_url": "https://www.gravatar.com/avatar/0?s=80&d=identicon",
          "web_url": "https://localhost/aiguy123"
        },
        {
          "id": 1,
          "username": "root",
          "name": "Administrator",
          "state": "active",
          "locked": false,
          "avatar_url": "https://www.gravatar.com/avatar/0?s=80&d=identicon",
          "web_url": "https://localhost/root"
        }
      ],
      "source_project_id": 7,
      "target_project_id": 7,
      "labels": [],
      "draft": false,
      "imported": false,
      "imported_from": "none",
      "work_in_progress": false,
      "milestone": null,
      "merge_when_pipeline_succeeds": false,
      "merge_status": "unchecked",
      "detailed_merge_status": "unchecked",
      "sha": "ce7e4f2d0ce13cb07479bb39dc10ee3b861c08a6",
      "merge_commit_sha": null,
      "squash_commit_sha": null,
      "discussion_locked": null,
      "should_remove_source_branch": null,
      "force_remove_source_branch": true,
      "prepared_at": null,
      "reference": "!12",
      "references": {
        "short": "!12",
        "relative": "!12",
        "full": "my-group/my-project!12"
      },
      "web_url": "https://localhost/my-group/my-project/-/merge_requests/12",
      "time_stats": {
        "time_estimate": 0,
        "total_time_spent": 0,
        "human_time_estimate": null,
        "human_total_time_spent": null
      },
      "squash": false,
      "squash_on_merge": false,
      "task_completion_status": {
        "count": 0,
        "completed_count": 0
      },
      "has_conflicts": false,
      "blocking_discussions_resolved": true,
      "approvals_before_merge": null
    },
    "blocked_merge_request": {
      "id": 146,
      "iid": 13,
      "project_id": 7,
      "title": "Really cool MR",
      "description": "Adds some stuff",
      "state": "opened",
      "created_at": "2024-07-05T21:31:34.811Z",
      "updated_at": "2024-07-27T02:57:08.054Z",
      "merged_by": null,
      "merge_user": null,
      "merged_at": null,
      "merge_after": "2018-09-07T11:16:00.000Z",
      "closed_by": null,
      "closed_at": null,
      "target_branch": "master",
      "source_branch": "remove-from",
      "user_notes_count": 0,
      "upvotes": 1,
      "downvotes": 0,
      "author": {
        "id": 2,
        "username": "aiguy123",
        "name": "AI GUY",
        "state": "active",
        "locked": false,
        "avatar_url": "https://www.gravatar.com/avatar/0?s=80&d=identicon",
        "web_url": "https://localhost/aiguy123"
      },
      "assignees": [
        {
          "id": 2,
          "username": "aiguy123",
          "name": "AI GUY",
          "state": "active",
          "locked": false,
          "avatar_url": "https://www.gravatar.com/avatar/0?s=80&d=identicon",
          "web_url": "https://localhose/aiguy123"
        }
      ],
      "assignee": {
        "id": 2,
        "username": "aiguy123",
        "name": "AI GUY",
        "state": "active",
        "locked": false,
        "avatar_url": "https://www.gravatar.com/avatar/0?s=80&d=identicon",
        "web_url": "https://localhost/aiguy123"
      },
      "reviewers": [
        {
          "id": 1,
          "username": "root",
          "name": "Administrator",
          "state": "active",
          "locked": false,
          "avatar_url": "https://www.gravatar.com/avatar/0?s=80&d=identicon",
          "web_url": "https://localhost/root"
        }
      ],
      "source_project_id": 7,
      "target_project_id": 7,
      "labels": [],
      "draft": false,
      "imported": false,
      "imported_from": "none",
      "work_in_progress": false,
      "milestone": {
        "id": 59,
        "iid": 6,
        "project_id": 7,
        "title": "Sprint 1718897375",
        "description": "Accusantium omnis iusto a animi.",
        "state": "active",
        "created_at": "2024-06-20T15:29:35.739Z",
        "updated_at": "2024-06-20T15:29:35.739Z",
        "due_date": null,
        "start_date": null,
        "expired": false,
        "web_url": "https://localhost/my-group/my-project/-/milestones/6"
      },
      "merge_when_pipeline_succeeds": false,
      "merge_status": "cannot_be_merged",
      "detailed_merge_status": "not_approved",
      "sha": "daa75b9b17918f51f43866ff533987fda71375ea",
      "merge_commit_sha": null,
      "squash_commit_sha": null,
      "discussion_locked": null,
      "should_remove_source_branch": null,
      "force_remove_source_branch": true,
      "prepared_at": "2024-07-11T18:50:46.215Z",
      "reference": "!13",
      "references": {
        "short": "!13",
        "relative": "!13",
        "full": "my-group/my-project!12"
      },
      "web_url": "https://localhost/my-group/my-project/-/merge_requests/13",
      "time_stats": {
        "time_estimate": 0,
        "total_time_spent": 0,
        "human_time_estimate": null,
        "human_total_time_spent": null
      },
      "squash": false,
      "squash_on_merge": false,
      "task_completion_status": {
        "count": 0,
        "completed_count": 0
      },
      "has_conflicts": true,
      "blocking_discussions_resolved": true,
      "approvals_before_merge": null
    },
    "project_id": 7
  }
]
```

## Delete a merge request dependency[](https://docs.gitlab.com/api/merge_requests/#delete-a-merge-request-dependency "Permalink")
Delete a merge request dependency.
```
DELETE /projects/:id/merge_requests/:merge_request_iid/blocks/:block_id
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths) owned by the authenticated user.
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
`block_id` | integer | Yes | The ID of the block.
Example request:
shell
```
curl --request DELETE --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/1/merge_requests/1/blocks/1"
```

Returns:
  * `204 No Content` if the dependency is successfully deleted.
  * `403 Forbidden` if the user lacks permissions for updating the merge request.
  * `403 Forbidden` if the user lacks permissions for reading the blocking merge request.


## Create a merge request dependency[](https://docs.gitlab.com/api/merge_requests/#create-a-merge-request-dependency "Permalink")
Create a merge request dependency.
```
POST /projects/:id/merge_requests/:merge_request_iid/blocks
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths) owned by the authenticated user.
`merge_request_iid` | integer | Yes | The internal ID of the merge request to be blocked.
`blocking_merge_request_id` | integer | Conditional | The global ID of the blocking merge request. Required if `blocking_merge_request_iid` is not provided.
`blocking_merge_request_iid` | integer | Conditional | The IID of the blocking merge request. Required if `blocking_merge_request_id` is not provided.
`blocking_project_id` | integer or string | No | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths) that contains the blocking merge request. Required when `blocking_merge_request_iid` refers to a merge request in a different project. Defaults to the current project.
Example request using IID (same project):
shell
```
curl --request POST \
  --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/1/merge_requests/1/blocks?blocking_merge_request_iid=2"
```

Example request using IID (cross-project):
shell
```
curl --request POST \
  --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/1/merge_requests/1/blocks?blocking_merge_request_iid=5&blocking_project_id=2"
```

Example request using global ID (legacy method):
shell
```
curl --request POST \
  --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/1/merge_requests/1/blocks?blocking_merge_request_id=12345"
```

Returns:
  * `201 Created` if the dependency is successfully created.
  * `400 Bad request` if the blocking merge request fails to save.
  * `403 Forbidden` if the user lacks permissions for reading the blocking merge request.
  * `404 Not found` if the blocking merge request is not found.
  * `409 Conflict` if the block already exists.


Example response:
json
```
{
  "id": 1,
  "blocking_merge_request": {
    "id": 145,
    "iid": 12,
    "project_id": 7,
    "title": "Interesting MR",
    "description": "Does interesting things.",
    "state": "opened",
    "created_at": "2024-07-05T21:29:11.172Z",
    "updated_at": "2024-07-05T21:29:11.172Z",
    "merged_by": null,
    "merge_user": null,
    "merged_at": null,
    "merge_after": "2018-09-07T11:16:00.000Z",
    "closed_by": null,
    "closed_at": null,
    "target_branch": "master",
    "source_branch": "v2.x",
    "user_notes_count": 0,
    "upvotes": 0,
    "downvotes": 0,
    "author": {
      "id": 2,
      "username": "aiguy123",
      "name": "AI GUY",
      "state": "active",
      "locked": false,
      "avatar_url": "https://www.gravatar.com/avatar/0?s=80&d=identicon",
      "web_url": "https://localhost/aiguy123"
    },
    "assignees": [
      {
        "id": 2,
        "username": "aiguy123",
        "name": "AI GUY",
        "state": "active",
        "locked": false,
        "avatar_url": "https://www.gravatar.com/avatar/0?s=80&d=identicon",
        "web_url": "https://localhost/aiguy123"
      }
    ],
    "assignee": {
      "id": 2,
      "username": "aiguy123",
      "name": "AI GUY",
      "state": "active",
      "locked": false,
      "avatar_url": "https://www.gravatar.com/avatar/0?s=80&d=identicon",
      "web_url": "https://localhost/aiguy123"
    },
    "reviewers": [
      {
        "id": 2,
        "username": "aiguy123",
        "name": "AI GUY",
        "state": "active",
        "locked": false,
        "avatar_url": "https://www.gravatar.com/avatar/0?s=80&d=identicon",
        "web_url": "https://localhost/aiguy123"
      },
      {
        "id": 1,
        "username": "root",
        "name": "Administrator",
        "state": "active",
        "locked": false,
        "avatar_url": "https://www.gravatar.com/avatar/0?s=80&d=identicon",
        "web_url": "https://localhost/root"
      }
    ],
    "source_project_id": 7,
    "target_project_id": 7,
    "labels": [],
    "draft": false,
    "imported": false,
    "imported_from": "none",
    "work_in_progress": false,
    "milestone": null,
    "merge_when_pipeline_succeeds": false,
    "merge_status": "unchecked",
    "detailed_merge_status": "unchecked",
    "sha": "ce7e4f2d0ce13cb07479bb39dc10ee3b861c08a6",
    "merge_commit_sha": null,
    "squash_commit_sha": null,
    "discussion_locked": null,
    "should_remove_source_branch": null,
    "force_remove_source_branch": true,
    "prepared_at": null,
    "reference": "!12",
    "references": {
      "short": "!12",
      "relative": "!12",
      "full": "my-group/my-project!12"
    },
    "web_url": "https://localhost/my-group/my-project/-/merge_requests/12",
    "time_stats": {
      "time_estimate": 0,
      "total_time_spent": 0,
      "human_time_estimate": null,
      "human_total_time_spent": null
    },
    "squash": false,
    "squash_on_merge": false,
    "task_completion_status": {
      "count": 0,
      "completed_count": 0
    },
    "has_conflicts": false,
    "blocking_discussions_resolved": true,
    "approvals_before_merge": null
  },
  "project_id": 7
}
```

## Retrieve blocked merge requests[](https://docs.gitlab.com/api/merge_requests/#retrieve-blocked-merge-requests "Permalink")
Retrieve merge requests blocked by a merge request.
```
GET /projects/:id/merge_requests/:merge_request_iid/blockees
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
Example request:
shell
```
curl --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/1/merge_requests/1/blockees"
```

Example response:
json
```
[
  {
    "id": 18,
    "blocking_merge_request": {
      "id": 71,
      "iid": 10,
      "project_id": 7,
      "title": "At quaerat occaecati voluptate ex explicabo nisi.",
      "description": "Aliquid distinctio officia corrupti ad nemo natus ipsum culpa.",
      "state": "merged",
      "created_at": "2024-07-05T19:44:14.023Z",
      "updated_at": "2024-07-05T19:44:14.023Z",
      "merged_by": {
        "id": 40,
        "username": "i-user-0-1720208283",
        "name": "I User0",
        "state": "active",
        "locked": false,
        "avatar_url": "https://www.gravatar.com/avatar/8325417f0f7919e3724957543b4414fdeca612cade1e4c0be45685fdaa2be0e2?s=80&d=identicon",
        "web_url": "http://127.0.0.1:3000/i-user-0-1720208283"
      },
      "merge_user": {
        "id": 40,
        "username": "i-user-0-1720208283",
        "name": "I User0",
        "state": "active",
        "locked": false,
        "avatar_url": "https://www.gravatar.com/avatar/8325417f0f7919e3724957543b4414fdeca612cade1e4c0be45685fdaa2be0e2?s=80&d=identicon",
        "web_url": "http://127.0.0.1:3000/i-user-0-1720208283"
      },
      "merged_at": "2024-06-26T19:44:14.123Z",
      "closed_by": null,
      "closed_at": null,
      "target_branch": "master",
      "source_branch": "Brickwood-Brunefunc-417",
      "user_notes_count": 0,
      "upvotes": 0,
      "downvotes": 0,
      "author": {
        "id": 40,
        "username": "i-user-0-1720208283",
        "name": "I User0",
        "state": "active",
        "locked": false,
        "avatar_url": "https://www.gravatar.com/avatar/8325417f0f7919e3724957543b4414fdeca612cade1e4c0be45685fdaa2be0e2?s=80&d=identicon",
        "web_url": "http://127.0.0.1:3000/i-user-0-1720208283"
      },
      "assignees": [],
      "assignee": null,
      "reviewers": [],
      "source_project_id": 7,
      "target_project_id": 7,
      "labels": [],
      "draft": false,
      "imported": false,
      "imported_from": "none",
      "work_in_progress": false,
      "milestone": null,
      "merge_when_pipeline_succeeds": false,
      "merge_status": "can_be_merged",
      "detailed_merge_status": "not_open",
      "merge_after": null,
      "sha": null,
      "merge_commit_sha": null,
      "squash_commit_sha": null,
      "discussion_locked": null,
      "should_remove_source_branch": null,
      "force_remove_source_branch": null,
      "prepared_at": null,
      "reference": "!10",
      "references": {
        "short": "!10",
        "relative": "!10",
        "full": "flightjs/Flight!10"
      },
      "web_url": "http://127.0.0.1:3000/flightjs/Flight/-/merge_requests/10",
      "time_stats": {
        "time_estimate": 0,
        "total_time_spent": 0,
        "human_time_estimate": null,
        "human_total_time_spent": null
      },
      "squash": false,
      "squash_on_merge": false,
      "task_completion_status": {
        "count": 0,
        "completed_count": 0
      },
      "has_conflicts": false,
      "blocking_discussions_resolved": true,
      "approvals_before_merge": null
    },
    "blocked_merge_request": {
      "id": 176,
      "iid": 14,
      "project_id": 7,
      "title": "second_mr",
      "description": "Signed-off-by: Lucas Zampieri <lzampier@redhat.com>",
      "state": "opened",
      "created_at": "2024-07-08T19:12:29.089Z",
      "updated_at": "2024-08-27T19:27:17.045Z",
      "merged_by": null,
      "merge_user": null,
      "merged_at": null,
      "closed_by": null,
      "closed_at": null,
      "target_branch": "master",
      "source_branch": "second_mr",
      "user_notes_count": 0,
      "upvotes": 0,
      "downvotes": 0,
      "author": {
        "id": 1,
        "username": "root",
        "name": "Administrator",
        "state": "active",
        "locked": false,
        "avatar_url": "https://www.gravatar.com/avatar/fc3634394c590e212d964e8e0a34c4d9b8c17c992f4d6d145d75f9c21c1c3b6e?s=80&d=identicon",
        "web_url": "http://127.0.0.1:3000/root"
      },
      "assignees": [],
      "assignee": null,
      "reviewers": [],
      "source_project_id": 7,
      "target_project_id": 7,
      "labels": [],
      "draft": false,
      "imported": false,
      "imported_from": "none",
      "work_in_progress": false,
      "milestone": null,
      "merge_when_pipeline_succeeds": false,
      "merge_status": "cannot_be_merged",
      "detailed_merge_status": "commits_status",
      "merge_after": null,
      "sha": "3a576801e528db79a75fbfea463673054ff224fb",
      "merge_commit_sha": null,
      "squash_commit_sha": null,
      "discussion_locked": null,
      "should_remove_source_branch": null,
      "force_remove_source_branch": true,
      "prepared_at": null,
      "reference": "!14",
      "references": {
        "short": "!14",
        "relative": "!14",
        "full": "flightjs/Flight!14"
      },
      "web_url": "http://127.0.0.1:3000/flightjs/Flight/-/merge_requests/14",
      "time_stats": {
        "time_estimate": 0,
        "total_time_spent": 0,
        "human_time_estimate": null,
        "human_total_time_spent": null
      },
      "squash": false,
      "squash_on_merge": false,
      "task_completion_status": {
        "count": 0,
        "completed_count": 0
      },
      "has_conflicts": true,
      "blocking_discussions_resolved": true,
      "approvals_before_merge": null
    },
    "project_id": 7
  }
]
```

## Retrieve merge request changes[](https://docs.gitlab.com/api/merge_requests/#retrieve-merge-request-changes "Permalink")
This endpoint was [deprecated](https://gitlab.com/gitlab-org/gitlab/-/issues/322117) in GitLab 15.7 and [is scheduled for removal](https://docs.gitlab.com/api/rest/deprecations/) in API v5. Use the [List merge request diffs](https://docs.gitlab.com/api/merge_requests/#list-merge-request-diffs) endpoint instead.
Retrieve information about a merge request, including its files and changes.
```
GET /projects/:id/merge_requests/:merge_request_iid/changes
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
`access_raw_diffs` | boolean | No | Retrieve change diffs through Gitaly.
`unidiff` | boolean | No | Present change diffs in the [unified diff](https://www.gnu.org/software/diffutils/manual/html_node/Detailed-Unified.html) format. Default is false. [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/130610) in GitLab 16.5.
Diffs associated with the set of changes have the same size limitations applied as other diffs returned by the API or viewed through the UI. When these limits impact the results, the `overflow` field contains a value of `true`. Retrieve the diff data without these limits by adding the `access_raw_diffs` parameter, which accesses diffs not from the database, but from Gitaly directly. This approach is generally slower and more resource-intensive, but isn’t subject to size limits placed on database-backed diffs. Limits inherent to Gitaly still apply.
Example response:
json
```
{
  "id": 21,
  "iid": 1,
  "project_id": 4,
  "title": "Blanditiis beatae suscipit hic assumenda et molestias nisi asperiores repellat et.",
  "state": "reopened",
  "created_at": "2015-02-02T19:49:39.159Z",
  "updated_at": "2015-02-02T20:08:49.959Z",
  "target_branch": "secret_token",
  "source_branch": "version-1-9",
  "upvotes": 0,
  "downvotes": 0,
  "author": {
    "name": "Chad Hamill",
    "username": "jarrett",
    "id": 5,
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/b95567800f828948baf5f4160ebb2473?s=40&d=identicon",
    "web_url" : "https://gitlab.example.com/jarrett"
  },
  "assignee": {
    "name": "Administrator",
    "username": "root",
    "id": 1,
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/e64c7d89f26bd1972efa854d13d7dd61?s=40&d=identicon",
    "web_url" : "https://gitlab.example.com/root"
  },
  "assignees": [{
    "name": "Miss Monserrate Beier",
    "username": "axel.block",
    "id": 12,
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
    "web_url": "https://gitlab.example.com/axel.block"
  }],
  "reviewers": [{
    "name": "Miss Monserrate Beier",
    "username": "axel.block",
    "id": 12,
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
    "web_url": "https://gitlab.example.com/axel.block"
  }],
  "source_project_id": 4,
  "target_project_id": 4,
  "labels": [ ],
  "description": "Qui voluptatibus placeat ipsa alias quasi. Deleniti rem ut sint. Optio velit qui distinctio.",
  "draft": false,
  "work_in_progress": false,
  "milestone": {
    "id": 5,
    "iid": 1,
    "project_id": 4,
    "title": "v2.0",
    "description": "Assumenda aut placeat expedita exercitationem labore sunt enim earum.",
    "state": "closed",
    "created_at": "2015-02-02T19:49:26.013Z",
    "updated_at": "2015-02-02T19:49:26.013Z",
    "due_date": null
  },
  "merge_when_pipeline_succeeds": true,
  "merge_status": "can_be_merged",
  "detailed_merge_status": "mergeable",
  "subscribed" : true,
  "sha": "8888888888888888888888888888888888888888",
  "merge_commit_sha": null,
  "squash_commit_sha": null,
  "user_notes_count": 1,
  "changes_count": "1",
  "should_remove_source_branch": true,
  "force_remove_source_branch": false,
  "squash": false,
  "web_url": "http://gitlab.example.com/my-group/my-project/merge_requests/1",
  "references": {
    "short": "!1",
    "relative": "!1",
    "full": "my-group/my-project!1"
  },
  "discussion_locked": false,
  "time_stats": {
    "time_estimate": 0,
    "total_time_spent": 0,
    "human_time_estimate": null,
    "human_total_time_spent": null
  },
  "task_completion_status":{
    "count":0,
    "completed_count":0
  },
  "changes": [
    {
    "old_path": "VERSION",
    "new_path": "VERSION",
    "a_mode": "100644",
    "b_mode": "100644",
    "diff": "@@ -1 +1 @@\ -1.9.7\ +1.9.8",
    "new_file": false,
    "renamed_file": false,
    "deleted_file": false
    }
  ],
  "overflow": false
}
```

## List merge request diffs[](https://docs.gitlab.com/api/merge_requests/#list-merge-request-diffs "Permalink")
History
  * `generated_file` [introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/141576) in GitLab 16.9 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `collapse_generated_diff_files`. Disabled by default.
  * [Enabled on GitLab.com and GitLab Self-Managed](https://gitlab.com/gitlab-org/gitlab/-/issues/432670) in GitLab 16.10.
  * `generated_file` [generally available](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/148478) in GitLab 16.11. Feature flag `collapse_generated_diff_files` removed.
  * `collapsed` and `too_large` response attributes [introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/199633) in GitLab 18.4.


List diffs of the files changed in a merge request.
```
GET /projects/:id/merge_requests/:merge_request_iid/diffs
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
`page` | integer | No | The page of results to return. Defaults to 1.
`per_page` | integer | No | The number of results per page. Defaults to 20.
`unidiff` | boolean | No | Present diffs in the [unified diff](https://www.gnu.org/software/diffutils/manual/html_node/Detailed-Unified.html) format. Default is false. [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/130610) in GitLab 16.5.
If successful, returns [`200 OK`](https://docs.gitlab.com/api/rest/troubleshooting/#status-codes) and the following response attributes:
Attribute | Type | Description
---|---|---
`a_mode` | string | Old file mode of the file.
`b_mode` | string | New file mode of the file.
`collapsed` | boolean | File diffs are excluded but can be fetched on request.
`deleted_file` | boolean | File has been removed.
`diff` | string | Diff representation of the changes made to the file.
`generated_file` | boolean | File is [marked as generated](https://docs.gitlab.com/user/project/merge_requests/changes/#collapse-generated-files).
`new_file` | boolean | File has been added.
`new_path` | string | New path of the file.
`old_path` | string | Old path of the file.
`renamed_file` | boolean | File has been renamed.
`too_large` | boolean | File diffs are excluded and cannot be retrieved.
Example request:
shell
```
curl --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/1/merge_requests/1/diffs?page=1&per_page=2"
```

Example response:
json
```
[
  {
    "old_path": "README",
    "new_path": "README",
    "a_mode": "100644",
    "b_mode": "100644",
    "diff": "@@ -1 +1 @@\ -Title\ +README",
    "collapsed": false,
    "too_large": false,
    "new_file": false,
    "renamed_file": false,
    "deleted_file": false,
    "generated_file": false
  },
  {
    "old_path": "VERSION",
    "new_path": "VERSION",
    "a_mode": "100644",
    "b_mode": "100644",
    "diff": "@@\ -1.9.7\ +1.9.8",
    "collapsed": false,
    "too_large": false,
    "new_file": false,
    "renamed_file": false,
    "deleted_file": false,
    "generated_file": false
  }
]
```

This endpoint is subject to [Merge requests diff limits](https://docs.gitlab.com/administration/instance_limits/#diff-limits). Merge requests that exceed the diff limits return limited results.
## Show merge request raw diffs[](https://docs.gitlab.com/api/merge_requests/#show-merge-request-raw-diffs "Permalink")
Show raw diffs of the files changed in a merge request.
```
GET /projects/:id/merge_requests/:merge_request_iid/raw_diffs
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
If successful, returns [`200 OK`](https://docs.gitlab.com/api/rest/troubleshooting/#status-codes) and a raw diff response to use programmatically:
Example request:
shell
```
curl --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/1/merge_requests/1/raw_diffs"
```

Example response:
diff
```
        diff --git a/lib/api/helpers.rb b/lib/api/helpers.rb
index 31525ad523553c8d7eff163db3e539058efd6d3a..f30e36d6fdf4cd4fa25f62e08ecdbf4a7b169681 100644
--- a/lib/api/helpers.rb
+++ b/lib/api/helpers.rb
@@ -944,6 +944,10 @@ def send_git_blob(repository, blob)
       body ''
     end

+    def send_git_diff(repository, diff_refs)
+      header(*Gitlab::Workhorse.send_git_diff(repository, diff_refs))
+    end
+
     def send_git_archive(repository, **kwargs)
       header(*Gitlab::Workhorse.send_git_archive(repository, **kwargs))

diff --git a/lib/api/merge_requests.rb b/lib/api/merge_requests.rb
index e02d9eea1852f19fe5311acda6aa17465eeb422e..f32b38585398a18fea75c11d7b8ebb730eeb3fab 100644
--- a/lib/api/merge_requests.rb
+++ b/lib/api/merge_requests.rb
@@ -6,6 +6,8 @@ class MergeRequests < ::API::Base
     include PaginationParams
     include Helpers::Unidiff

+    helpers ::API::Helpers::HeadersHelpers
+
     CONTEXT_COMMITS_POST_LIMIT = 20

     before { authenticate_non_get! }

```

This endpoint is subject to [Merge requests diff limits](https://docs.gitlab.com/administration/instance_limits/#diff-limits). Merge requests that exceed the diff limits return limited results.
## List merge request pipelines[](https://docs.gitlab.com/api/merge_requests/#list-merge-request-pipelines "Permalink")
List all pipelines for a merge request.
```
GET /projects/:id/merge_requests/:merge_request_iid/pipelines
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
To restrict the list of merge request pipelines, use the pagination parameters `page` and `per_page`.
Example response:
json
```
[
  {
    "id": 77,
    "sha": "959e04d7c7a30600c894bd3c0cd0e1ce7f42c11d",
    "ref": "main",
    "status": "success"
  }
]
```

## Create merge request pipeline[](https://docs.gitlab.com/api/merge_requests/#create-merge-request-pipeline "Permalink")
Create a new [pipeline for a merge request](https://docs.gitlab.com/ci/pipelines/merge_request_pipelines/). A pipeline created from this endpoint doesn’t run a regular branch/tag pipeline. To create jobs, configure `.gitlab-ci.yml` with `only: [merge_requests]`.
The new pipeline can be:
  * A detached merge request pipeline.
  * A [merged results pipeline](https://docs.gitlab.com/ci/pipelines/merged_results_pipelines/) if the [project setting is enabled](https://docs.gitlab.com/ci/pipelines/merged_results_pipelines/#enable-merged-results-pipelines).


```
POST /projects/:id/merge_requests/:merge_request_iid/pipelines
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
Example response:
json
```
{
  "id": 2,
  "sha": "b83d6e391c22777fca1ed3012fce84f633d7fed0",
  "ref": "refs/merge-requests/1/head",
  "status": "pending",
  "web_url": "http://localhost/user1/project1/pipelines/2",
  "before_sha": "0000000000000000000000000000000000000000",
  "tag": false,
  "yaml_errors": null,
  "user": {
    "id": 1,
    "name": "John Doe1",
    "username": "user1",
    "state": "active",
    "avatar_url": "https://www.gravatar.com/avatar/c922747a93b40d1ea88262bf1aebee62?s=80&d=identicon",
    "web_url": "http://example.com"
  },
  "created_at": "2019-09-04T19:20:18.267Z",
  "updated_at": "2019-09-04T19:20:18.459Z",
  "started_at": null,
  "finished_at": null,
  "committed_at": null,
  "duration": null,
  "coverage": null,
  "detailed_status": {
    "icon": "status_pending",
    "text": "pending",
    "label": "pending",
    "group": "pending",
    "tooltip": "pending",
    "has_details": false,
    "details_path": "/user1/project1/pipelines/2",
    "illustration": null,
    "favicon": "/assets/ci_favicons/favicon_status_pending-5bdf338420e5221ca24353b6bff1c9367189588750632e9a871b7af09ff6a2ae.png"
  },
  "archived": false
}
```

## Create a merge request[](https://docs.gitlab.com/api/merge_requests/#create-a-merge-request "Permalink")
Create a new merge request.
```
POST /projects/:id/merge_requests
```

Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths)
`source_branch` | string | Yes | The source branch.
`target_branch` | string | Yes | The target branch.
`title` | string | Yes | Title of MR.
`allow_collaboration` | boolean | No | Allow commits from members who can merge to the target branch.
`approvals_before_merge` | integer | No | Number of approvals required before this merge request can merge (see below). To configure approval rules, see [Merge request approvals API](https://docs.gitlab.com/api/merge_request_approvals/). [Deprecated](https://gitlab.com/gitlab-org/gitlab/-/issues/353097) in GitLab 16.0. Premium and Ultimate only.
`allow_maintainer_to_push` | boolean | No | Alias of `allow_collaboration`.
`assignee_id` | integer | No | Assignee user ID.
`assignee_ids` | integer array | No | The ID of the users to assign the merge request to. Set to `0` or provide an empty value to unassign all assignees.
`description` | string | No | Description of the merge request. Limited to 1,048,576 characters.
`labels` | string | No | Labels for the merge request, as a comma-separated list. If a label does not already exist, this creates a new project label and assigns it to the merge request.
`merge_after` | string | No | Date after which the merge request can be merged. [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/510992) in GitLab 17.8.
`milestone_id` | integer | No | The global ID of a milestone.
`remove_source_branch` | boolean | No | Flag indicating if a merge request should remove the source branch when merging.
`reviewer_ids` | integer array | No | The ID of the users added as a reviewer to the merge request. If set to `0` or left empty, no reviewers are added.
`squash` | boolean | No | If `true`, squash all commits into a single commit on merge. When not provided, defaults to the [project’s squash option setting](https://docs.gitlab.com/user/project/merge_requests/squash_and_merge/#configure-squash-options-for-a-project). Project settings might override this value at merge time.
`target_project_id` | integer | No | Numeric ID of the target project.
Example response:
json
```
{
  "id": 1,
  "iid": 1,
  "project_id": 3,
  "title": "test1",
  "description": "fixed login page css paddings",
  "state": "merged",
  "imported": false,
  "imported_from": "none",
  "created_at": "2017-04-29T08:46:00Z",
  "updated_at": "2017-04-29T08:46:00Z",
  "target_branch": "main",
  "source_branch": "test1",
  "upvotes": 0,
  "downvotes": 0,
  "author": {
    "id": 1,
    "name": "Administrator",
    "username": "admin",
    "state": "active",
    "avatar_url": null,
    "web_url" : "https://gitlab.example.com/admin"
  },
  "assignee": {
    "id": 1,
    "name": "Administrator",
    "username": "admin",
    "state": "active",
    "avatar_url": null,
    "web_url" : "https://gitlab.example.com/admin"
  },
  "source_project_id": 2,
  "target_project_id": 3,
  "labels": [
    "Community contribution",
    "Manage"
  ],
  "draft": false,
  "work_in_progress": false,
  "milestone": {
    "id": 5,
    "iid": 1,
    "project_id": 3,
    "title": "v2.0",
    "description": "Assumenda aut placeat expedita exercitationem labore sunt enim earum.",
    "state": "closed",
    "created_at": "2015-02-02T19:49:26.013Z",
    "updated_at": "2015-02-02T19:49:26.013Z",
    "due_date": "2018-09-22",
    "start_date": "2018-08-08",
    "web_url": "https://gitlab.example.com/my-group/my-project/milestones/1"
  },
  "merge_when_pipeline_succeeds": true,
  "merge_status": "can_be_merged",
  "detailed_merge_status": "not_open",
  "merge_error": null,
  "sha": "8888888888888888888888888888888888888888",
  "merge_commit_sha": null,
  "squash_commit_sha": null,
  "user_notes_count": 1,
  "discussion_locked": null,
  "should_remove_source_branch": true,
  "force_remove_source_branch": false,
  "allow_collaboration": false,
  "allow_maintainer_to_push": false,
  "web_url": "http://gitlab.example.com/my-group/my-project/merge_requests/1",
  "references": {
    "short": "!1",
    "relative": "!1",
    "full": "my-group/my-project!1"
  },
  "time_stats": {
    "time_estimate": 0,
    "total_time_spent": 0,
    "human_time_estimate": null,
    "human_total_time_spent": null
  },
  "squash": false,
  "subscribed": false,
  "changes_count": "1",
  "merged_by": { // Deprecated and will be removed in API v5, use `merge_user` instead
    "id": 87854,
    "name": "Douwe Maan",
    "username": "DouweM",
    "state": "active",
    "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
    "web_url": "https://gitlab.com/DouweM"
  },
  "merge_user": {
    "id": 87854,
    "name": "Douwe Maan",
    "username": "DouweM",
    "state": "active",
    "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
    "web_url": "https://gitlab.com/DouweM"
  },
  "merged_at": "2018-09-07T11:16:17.520Z",
  "merge_after": "2018-09-07T11:16:00.000Z",
  "prepared_at": "2018-09-04T11:16:17.520Z",
  "closed_by": null,
  "closed_at": null,
  "latest_build_started_at": "2018-09-07T07:27:38.472Z",
  "latest_build_finished_at": "2018-09-07T08:07:06.012Z",
  "first_deployed_to_production_at": null,
  "pipeline": {
    "id": 29626725,
    "sha": "2be7ddb704c7b6b83732fdd5b9f09d5a397b5f8f",
    "ref": "patch-28",
    "status": "success",
    "web_url": "https://gitlab.example.com/my-group/my-project/pipelines/29626725"
  },
  "diff_refs": {
    "base_sha": "c380d3acebd181f13629a25d2e2acca46ffe1e00",
    "head_sha": "2be7ddb704c7b6b83732fdd5b9f09d5a397b5f8f",
    "start_sha": "c380d3acebd181f13629a25d2e2acca46ffe1e00"
  },
  "diverged_commits_count": 2,
  "task_completion_status":{
    "count":0,
    "completed_count":0
  }
}
```

For important notes on response data, see [Single merge request response notes](https://docs.gitlab.com/api/merge_requests/#single-merge-request-response-notes).
## Update a merge request[](https://docs.gitlab.com/api/merge_requests/#update-a-merge-request "Permalink")
Update an existing merge request.
```
PUT /projects/:id/merge_requests/:merge_request_iid
```

Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The ID of a merge request.
`add_labels` | string | No | Comma-separated label names to add to a merge request. If a label does not already exist, this creates a new project label and assigns it to the merge request.
`allow_collaboration` | boolean | No | Allow commits from members who can merge to the target branch.
`allow_maintainer_to_push` | boolean | No | Alias of `allow_collaboration`.
`assignee_id` | integer | No | The ID of the user to assign the merge request to. Set to `0` or provide an empty value to unassign all assignees.
`assignee_ids` | integer array | No | The ID of the users to assign the merge request to. Set to `0` or provide an empty value to unassign all assignees.
`description` | string | No | Description of the merge request. Limited to 1,048,576 characters.
`discussion_locked` | boolean | No | Flag indicating if the merge request’s discussion is locked. Only project members can add, edit or resolve comments to locked discussions.
`labels` | string | No | Comma-separated label names for a merge request. Set to an empty string to unassign all labels. If a label does not already exist, this creates a new project label and assigns it to the merge request.
`merge_after` | string | No | Date after which the merge request can be merged. [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/510992) in GitLab 17.8.
`milestone_id` | integer | No | The global ID of a milestone to assign the merge request to. Set to `0` or provide an empty value to unassign a milestone.
`remove_labels` | string | No | Comma-separated label names to remove from a merge request.
`remove_source_branch` | boolean | No | Flag indicating if a merge request should remove the source branch when merging.
`reviewer_ids` | integer array | No | The ID of the users set as a reviewer to the merge request. Set the value to `0` or provide an empty value to unset all reviewers.
`squash` | boolean | No | If `true`, squash all commits into a single commit on merge. When not provided, defaults to the [project’s squash option setting](https://docs.gitlab.com/user/project/merge_requests/squash_and_merge/#configure-squash-options-for-a-project). If the project is configured to **Require** or **Do not allow** squashing, that setting takes precedence at merge time.
`state_event` | string | No | New state (close/reopen).
`target_branch` | string | No | The target branch.
`title` | string | No | Title of MR.
Must include at least one non-required attribute.
Example response:
json
```
{
  "id": 1,
  "iid": 1,
  "project_id": 3,
  "title": "test1",
  "description": "fixed login page css paddings",
  "state": "merged",
  "created_at": "2017-04-29T08:46:00Z",
  "updated_at": "2017-04-29T08:46:00Z",
  "target_branch": "main",
  "source_branch": "test1",
  "upvotes": 0,
  "downvotes": 0,
  "author": {
    "id": 1,
    "name": "Administrator",
    "username": "admin",
    "state": "active",
    "avatar_url": null,
    "web_url" : "https://gitlab.example.com/admin"
  },
  "assignee": {
    "id": 1,
    "name": "Administrator",
    "username": "admin",
    "state": "active",
    "avatar_url": null,
    "web_url" : "https://gitlab.example.com/admin"
  },
  "assignees": [{
    "name": "Miss Monserrate Beier",
    "username": "axel.block",
    "id": 12,
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
    "web_url": "https://gitlab.example.com/axel.block"
  }],
  "reviewers": [{
    "name": "Miss Monserrate Beier",
    "username": "axel.block",
    "id": 12,
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
    "web_url": "https://gitlab.example.com/axel.block"
  }],
  "source_project_id": 2,
  "target_project_id": 3,
  "labels": [
    "Community contribution",
    "Manage"
  ],
  "draft": false,
  "work_in_progress": false,
  "milestone": {
    "id": 5,
    "iid": 1,
    "project_id": 3,
    "title": "v2.0",
    "description": "Assumenda aut placeat expedita exercitationem labore sunt enim earum.",
    "state": "closed",
    "created_at": "2015-02-02T19:49:26.013Z",
    "updated_at": "2015-02-02T19:49:26.013Z",
    "due_date": "2018-09-22",
    "start_date": "2018-08-08",
    "web_url": "https://gitlab.example.com/my-group/my-project/milestones/1"
  },
  "merge_when_pipeline_succeeds": true,
  "merge_status": "can_be_merged",
  "detailed_merge_status": "not_open",
  "merge_error": null,
  "sha": "8888888888888888888888888888888888888888",
  "merge_commit_sha": null,
  "squash_commit_sha": null,
  "user_notes_count": 1,
  "discussion_locked": null,
  "should_remove_source_branch": true,
  "force_remove_source_branch": false,
  "allow_collaboration": false,
  "allow_maintainer_to_push": false,
  "web_url": "http://gitlab.example.com/my-group/my-project/merge_requests/1",
  "references": {
    "short": "!1",
    "relative": "!1",
    "full": "my-group/my-project!1"
  },
  "time_stats": {
    "time_estimate": 0,
    "total_time_spent": 0,
    "human_time_estimate": null,
    "human_total_time_spent": null
  },
  "squash": false,
  "subscribed": false,
  "changes_count": "1",
  "merged_by": { // Deprecated and will be removed in API v5, use `merge_user` instead
    "id": 87854,
    "name": "Douwe Maan",
    "username": "DouweM",
    "state": "active",
    "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
    "web_url": "https://gitlab.com/DouweM"
  },
  "merge_user": {
    "id": 87854,
    "name": "Douwe Maan",
    "username": "DouweM",
    "state": "active",
    "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
    "web_url": "https://gitlab.com/DouweM"
  },
  "merged_at": "2018-09-07T11:16:17.520Z",
  "merge_after": "2018-09-07T11:16:00.000Z",
  "prepared_at": "2018-09-04T11:16:17.520Z",
  "closed_by": null,
  "closed_at": null,
  "latest_build_started_at": "2018-09-07T07:27:38.472Z",
  "latest_build_finished_at": "2018-09-07T08:07:06.012Z",
  "first_deployed_to_production_at": null,
  "pipeline": {
    "id": 29626725,
    "sha": "2be7ddb704c7b6b83732fdd5b9f09d5a397b5f8f",
    "ref": "patch-28",
    "status": "success",
    "web_url": "https://gitlab.example.com/my-group/my-project/pipelines/29626725"
  },
  "diff_refs": {
    "base_sha": "c380d3acebd181f13629a25d2e2acca46ffe1e00",
    "head_sha": "2be7ddb704c7b6b83732fdd5b9f09d5a397b5f8f",
    "start_sha": "c380d3acebd181f13629a25d2e2acca46ffe1e00"
  },
  "diverged_commits_count": 2,
  "task_completion_status":{
    "count":0,
    "completed_count":0
  }
}
```

For important notes on response data, see [Single merge request response notes](https://docs.gitlab.com/api/merge_requests/#single-merge-request-response-notes).
## Delete a merge request[](https://docs.gitlab.com/api/merge_requests/#delete-a-merge-request "Permalink")
Delete a merge request. Only administrators and project owners can delete merge requests.
```
DELETE /projects/:id/merge_requests/:merge_request_iid
```

Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
shell
```
curl --request DELETE \
  --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/4/merge_requests/85"
```

## Merge a merge request[](https://docs.gitlab.com/api/merge_requests/#merge-a-merge-request "Permalink")
Accept and merge changes submitted with merge request using this API.
```
PUT /projects/:id/merge_requests/:merge_request_iid/merge
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
`auto_merge` | boolean | No | If `true`, the merge request merges when the pipeline succeeds.
`merge_commit_message` | string | No | Custom merge commit message.
`merge_when_pipeline_succeeds` | boolean | No |  [Deprecated](https://gitlab.com/gitlab-org/gitlab/-/issues/521291) in GitLab 17.11. Use `auto_merge` instead.
`sha` | string | No | If present, this SHA must match the HEAD of the source branch. Use to ensure that only reviewed commits are merged.
`should_remove_source_branch` | boolean | No | If `true`, removes the source branch.
`squash_commit_message` | string | No | Custom squash commit message.
`squash` | boolean | No | If `true`, squash all commits into a single commit on merge.
This API returns specific HTTP status codes on failure:
HTTP Status | Message | Reason
---|---|---
`401` | `401 Unauthorized` | This user does not have permission to accept this merge request.
`405` | `405 Method Not Allowed` | The merge request cannot merge.
`409` | `SHA does not match HEAD of source branch` | The provided `sha` parameter does not match the HEAD of the source.
`422` | `Branch cannot be merged` | The merge request failed to merge.
For important notes on response data, see [Single merge request response notes](https://docs.gitlab.com/api/merge_requests/#single-merge-request-response-notes).
Example response:
json
```
{
  "id": 1,
  "iid": 1,
  "project_id": 3,
  "title": "test1",
  "description": "fixed login page css paddings",
  "state": "merged",
  "created_at": "2017-04-29T08:46:00Z",
  "updated_at": "2017-04-29T08:46:00Z",
  "target_branch": "main",
  "source_branch": "test1",
  "upvotes": 0,
  "downvotes": 0,
  "author": {
    "id": 1,
    "name": "Administrator",
    "username": "admin",
    "state": "active",
    "avatar_url": null,
    "web_url" : "https://gitlab.example.com/admin"
  },
  "assignee": {
    "id": 1,
    "name": "Administrator",
    "username": "admin",
    "state": "active",
    "avatar_url": null,
    "web_url" : "https://gitlab.example.com/admin"
  },
  "assignees": [{
    "name": "Miss Monserrate Beier",
    "username": "axel.block",
    "id": 12,
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
    "web_url": "https://gitlab.example.com/axel.block"
  }],
  "reviewers": [{
    "name": "Miss Monserrate Beier",
    "username": "axel.block",
    "id": 12,
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
    "web_url": "https://gitlab.example.com/axel.block"
  }],
  "source_project_id": 2,
  "target_project_id": 3,
  "labels": [
    "Community contribution",
    "Manage"
  ],
  "draft": false,
  "work_in_progress": false,
  "milestone": {
    "id": 5,
    "iid": 1,
    "project_id": 3,
    "title": "v2.0",
    "description": "Assumenda aut placeat expedita exercitationem labore sunt enim earum.",
    "state": "closed",
    "created_at": "2015-02-02T19:49:26.013Z",
    "updated_at": "2015-02-02T19:49:26.013Z",
    "due_date": "2018-09-22",
    "start_date": "2018-08-08",
    "web_url": "https://gitlab.example.com/my-group/my-project/milestones/1"
  },
  "merge_when_pipeline_succeeds": true,
  "merge_status": "can_be_merged",
  "detailed_merge_status": "not_open",
  "merge_error": null,
  "sha": "8888888888888888888888888888888888888888",
  "merge_commit_sha": null,
  "squash_commit_sha": null,
  "user_notes_count": 1,
  "discussion_locked": null,
  "should_remove_source_branch": true,
  "force_remove_source_branch": false,
  "allow_collaboration": false,
  "allow_maintainer_to_push": false,
  "web_url": "http://gitlab.example.com/my-group/my-project/merge_requests/1",
  "references": {
    "short": "!1",
    "relative": "!1",
    "full": "my-group/my-project!1"
  },
  "time_stats": {
    "time_estimate": 0,
    "total_time_spent": 0,
    "human_time_estimate": null,
    "human_total_time_spent": null
  },
  "squash": false,
  "subscribed": false,
  "changes_count": "1",
  "merged_by": { // Deprecated and will be removed in API v5, use `merge_user` instead
    "id": 87854,
    "name": "Douwe Maan",
    "username": "DouweM",
    "state": "active",
    "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
    "web_url": "https://gitlab.com/DouweM"
  },
  "merge_user": {
    "id": 87854,
    "name": "Douwe Maan",
    "username": "DouweM",
    "state": "active",
    "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
    "web_url": "https://gitlab.com/DouweM"
  },
  "merged_at": "2018-09-07T11:16:17.520Z",
  "merge_after": "2018-09-07T11:16:00.000Z",
  "prepared_at": "2018-09-04T11:16:17.520Z",
  "closed_by": null,
  "closed_at": null,
  "latest_build_started_at": "2018-09-07T07:27:38.472Z",
  "latest_build_finished_at": "2018-09-07T08:07:06.012Z",
  "first_deployed_to_production_at": null,
  "pipeline": {
    "id": 29626725,
    "sha": "2be7ddb704c7b6b83732fdd5b9f09d5a397b5f8f",
    "ref": "patch-28",
    "status": "success",
    "web_url": "https://gitlab.example.com/my-group/my-project/pipelines/29626725"
  },
  "diff_refs": {
    "base_sha": "c380d3acebd181f13629a25d2e2acca46ffe1e00",
    "head_sha": "2be7ddb704c7b6b83732fdd5b9f09d5a397b5f8f",
    "start_sha": "c380d3acebd181f13629a25d2e2acca46ffe1e00"
  },
  "diverged_commits_count": 2,
  "task_completion_status":{
    "count":0,
    "completed_count":0
  }
}
```

## Merge to default merge ref path[](https://docs.gitlab.com/api/merge_requests/#merge-to-default-merge-ref-path "Permalink")
Merge the changes between the merge request source and target branches into `refs/merge-requests/:iid/merge` ref, of the target project repository, if possible. This ref has the state the target branch would have if a regular merge action was taken.
This action isn’t a regular merge action, because it doesn’t change the merge request target branch state in any manner.
This ref (`refs/merge-requests/:iid/merge`) isn’t necessarily overwritten when submitting requests to this API, though it makes sure the ref has the latest possible state.
```
GET /projects/:id/merge_requests/:merge_request_iid/merge_ref
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
This API returns specific HTTP status codes:
HTTP Status | Message | Reason
---|---|---
`200` | _(none)_ | Success. Returns the HEAD commit of `refs/merge-requests/:iid/merge`.
`400` | `Merge request is not mergeable` | The merge request has conflicts.
`400` | `Merge ref cannot be updated` |
`400` | `Unsupported operation` | The GitLab database is in read-only mode.
Example response:
json
```
{
  "commit_id": "854a3a7a17acbcc0bbbea170986df1eb60435f34"
}
```

## Cancel merge when pipeline succeeds[](https://docs.gitlab.com/api/merge_requests/#cancel-merge-when-pipeline-succeeds "Permalink")
```
POST /projects/:id/merge_requests/:merge_request_iid/cancel_merge_when_pipeline_succeeds
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
This API returns specific HTTP status codes:
HTTP Status | Message | Reason
---|---|---
`201` | _(none)_ | Success, or the merge request has already merged.
`406` | `Can't cancel the automatic merge` | The merge request is closed.
For important notes on response data, see [Single merge request response notes](https://docs.gitlab.com/api/merge_requests/#single-merge-request-response-notes).
Example response:
json
```
{
  "id": 1,
  "iid": 1,
  "project_id": 3,
  "title": "test1",
  "description": "fixed login page css paddings",
  "state": "merged",
  "created_at": "2017-04-29T08:46:00Z",
  "updated_at": "2017-04-29T08:46:00Z",
  "target_branch": "main",
  "source_branch": "test1",
  "upvotes": 0,
  "downvotes": 0,
  "author": {
    "id": 1,
    "name": "Administrator",
    "username": "admin",
    "state": "active",
    "avatar_url": null,
    "web_url" : "https://gitlab.example.com/admin"
  },
  "assignee": {
    "id": 1,
    "name": "Administrator",
    "username": "admin",
    "state": "active",
    "avatar_url": null,
    "web_url" : "https://gitlab.example.com/admin"
  },
  "assignees": [{
    "name": "Miss Monserrate Beier",
    "username": "axel.block",
    "id": 12,
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
    "web_url": "https://gitlab.example.com/axel.block"
  }],
  "reviewers": [{
    "name": "Miss Monserrate Beier",
    "username": "axel.block",
    "id": 12,
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
    "web_url": "https://gitlab.example.com/axel.block"
  }],
  "source_project_id": 2,
  "target_project_id": 3,
  "labels": [
    "Community contribution",
    "Manage"
  ],
  "draft": false,
  "work_in_progress": false,
  "milestone": {
    "id": 5,
    "iid": 1,
    "project_id": 3,
    "title": "v2.0",
    "description": "Assumenda aut placeat expedita exercitationem labore sunt enim earum.",
    "state": "closed",
    "created_at": "2015-02-02T19:49:26.013Z",
    "updated_at": "2015-02-02T19:49:26.013Z",
    "due_date": "2018-09-22",
    "start_date": "2018-08-08",
    "web_url": "https://gitlab.example.com/my-group/my-project/milestones/1"
  },
  "merge_when_pipeline_succeeds": false,
  "merge_status": "can_be_merged",
  "detailed_merge_status": "not_open",
  "merge_error": null,
  "sha": "8888888888888888888888888888888888888888",
  "merge_commit_sha": null,
  "squash_commit_sha": null,
  "user_notes_count": 1,
  "discussion_locked": null,
  "should_remove_source_branch": true,
  "force_remove_source_branch": false,
  "allow_collaboration": false,
  "allow_maintainer_to_push": false,
  "web_url": "http://gitlab.example.com/my-group/my-project/merge_requests/1",
  "references": {
    "short": "!1",
    "relative": "!1",
    "full": "my-group/my-project!1"
  },
  "time_stats": {
    "time_estimate": 0,
    "total_time_spent": 0,
    "human_time_estimate": null,
    "human_total_time_spent": null
  },
  "squash": false,
  "subscribed": false,
  "changes_count": "1",
  "merged_by": { // Deprecated and will be removed in API v5, use `merge_user` instead
    "id": 87854,
    "name": "Douwe Maan",
    "username": "DouweM",
    "state": "active",
    "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
    "web_url": "https://gitlab.com/DouweM"
  },
  "merge_user": {
    "id": 87854,
    "name": "Douwe Maan",
    "username": "DouweM",
    "state": "active",
    "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
    "web_url": "https://gitlab.com/DouweM"
  },
  "merged_at": "2018-09-07T11:16:17.520Z",
  "merge_after": "2018-09-07T11:16:00.000Z",
  "prepared_at": "2018-09-04T11:16:17.520Z",
  "closed_by": null,
  "closed_at": null,
  "latest_build_started_at": "2018-09-07T07:27:38.472Z",
  "latest_build_finished_at": "2018-09-07T08:07:06.012Z",
  "first_deployed_to_production_at": null,
  "pipeline": {
    "id": 29626725,
    "sha": "2be7ddb704c7b6b83732fdd5b9f09d5a397b5f8f",
    "ref": "patch-28",
    "status": "success",
    "web_url": "https://gitlab.example.com/my-group/my-project/pipelines/29626725"
  },
  "diff_refs": {
    "base_sha": "c380d3acebd181f13629a25d2e2acca46ffe1e00",
    "head_sha": "2be7ddb704c7b6b83732fdd5b9f09d5a397b5f8f",
    "start_sha": "c380d3acebd181f13629a25d2e2acca46ffe1e00"
  },
  "diverged_commits_count": 2,
  "task_completion_status":{
    "count":0,
    "completed_count":0
  }
}
```

## Rebase a merge request[](https://docs.gitlab.com/api/merge_requests/#rebase-a-merge-request "Permalink")
Automatically rebase the `source_branch` of the merge request against its `target_branch`.
```
PUT /projects/:id/merge_requests/:merge_request_iid/rebase
```

Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
`skip_ci` | boolean | No | Set to `true` to skip creating a CI pipeline.
shell
```
curl --request PUT \
  --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/76/merge_requests/1/rebase"
```

This API returns specific HTTP status codes:
HTTP Status | Message | Reason
---|---|---
`202` | _(no message)_ | Successfully enqueued.
`403` | `Cannot push to source branch` | You don’t have permission to push to the merge request’s source branch.
`403` | `Source branch does not exist` | You don’t have permission to push to the merge request’s source branch.
`403` | `Source branch is protected from force push` | You don’t have permission to push to the merge request’s source branch.
`409` | `Failed to enqueue the rebase operation` | A long-lived transaction might have blocked your request.
If the request is added to the queue successfully, the response contains:
json
```
{
  "rebase_in_progress": true
}
```

You can poll the [Retrieve a merge request](https://docs.gitlab.com/api/merge_requests/#retrieve-a-merge-request) endpoint with the `include_rebase_in_progress` parameter to check the status of the asynchronous request.
If the rebase operation is ongoing, the response includes the following:
json
```
{
  "rebase_in_progress": true,
  "merge_error": null
}
```

After the rebase operation has completed successfully, the response includes the following:
json
```
{
  "rebase_in_progress": false,
  "merge_error": null
}
```

If the rebase operation fails, the response includes the following:
json
```
{
  "rebase_in_progress": false,
  "merge_error": "Rebase failed. Please rebase locally"
}
```

## Comments on merge requests[](https://docs.gitlab.com/api/merge_requests/#comments-on-merge-requests "Permalink")
The [notes](https://docs.gitlab.com/api/notes/) resource creates comments.
## List issues that close on merge[](https://docs.gitlab.com/api/merge_requests/#list-issues-that-close-on-merge "Permalink")
List issues that would close when a merge request is merged.
```
GET /projects/:id/merge_requests/:merge_request_iid/closes_issues
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | Internal ID of the merge request.
If successful, returns [`200 OK`](https://docs.gitlab.com/api/rest/troubleshooting/#status-codes) and the following response attributes when you use the GitLab issue tracker:
Attribute | Type | Description
---|---|---
`[].assignee` | object | First assignee of the issue.
`[].assignees` | array | Assignees of the issue.
`[].author` | object | User who created this issue.
`[].blocking_issues_count` | integer | Count of issues this issue is blocking.
`[].closed_at` | datetime | Timestamp of when the issue was closed.
`[].closed_by` | object | User who closed this issue.
`[].confidential` | boolean | Indicates if the issue is confidential.
`[].created_at` | datetime | Timestamp of when the issue was created.
`[].description` | string | Description of the issue.
`[].discussion_locked` | boolean | Indicates if comments on the issue are locked to members only.
`[].downvotes` | integer | Number of downvotes the issue has received.
`[].due_date` | datetime | Due date of the issue.
`[].id` | integer | ID of the issue.
`[].iid` | integer | Internal ID of the issue.
`[].issue_type` | string | Type of the issue. Can be `issue`, `incident`, `test_case`, `requirement`, `task`.
`[].labels` | array | Labels of the issue.
`[].merge_requests_count` | integer | Number of merge requests that close the issue on merge.
`[].milestone` | object | Milestone of the issue.
`[].project_id` | integer | ID of the issue project.
`[].state` | string | State of the issue. Can be `opened` or `closed`.
`[].task_completion_status` | object | Includes `count` and `completed_count`.
`[].time_stats` | object | Time statistics for the issue. Includes `time_estimate`, `total_time_spent`, `human_time_estimate`, and `human_total_time_spent`.
`[].title` | string | Title of the issue.
`[].type` | string | Type of the issue. Same as `issue_type`, but uppercase.
`[].updated_at` | datetime | Timestamp of when the issue was updated.
`[].upvotes` | integer | Number of upvotes the issue has received.
`[].user_notes_count` | integer | User notes count of the issue.
`[].web_url` | string | Web URL of the issue.
`[].weight` | integer | Weight of the issue.
If successful, returns [`200 OK`](https://docs.gitlab.com/api/rest/troubleshooting/#status-codes) and the following response attributes when you use an external issue tracker, like Jira:
Attribute | Type | Description
---|---|---
`[].id` | integer | ID of the issue.
`[].title` | string | Title of the issue.
Example request:
shell
```
curl --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/76/merge_requests/1/closes_issues"
```

Example response when you use the GitLab issue tracker:
json
```
[
  {
    "id": 76,
    "iid": 6,
    "project_id": 1,
    "title": "Consequatur vero maxime deserunt laboriosam est voluptas dolorem.",
    "description": "Ratione dolores corrupti mollitia soluta quia.",
    "state": "opened",
    "created_at": "2024-09-06T10:58:49.002Z",
    "updated_at": "2024-09-06T11:01:40.710Z",
    "closed_at": null,
    "closed_by": null,
    "labels": [
      "label"
    ],
    "milestone": {
      "project_id": 1,
      "description": "Ducimus nam enim ex consequatur cumque ratione.",
      "state": "closed",
      "due_date": null,
      "iid": 2,
      "created_at": "2016-01-04T15:31:39.996Z",
      "title": "v4.0",
      "id": 17,
      "updated_at": "2016-01-04T15:31:39.996Z"
    },
    "assignees": [
      {
        "id": 1,
        "username": "root",
        "name": "Administrator",
        "state": "active",
        "locked": false,
        "avatar_url": null,
        "web_url": "https://gitlab.example.com/root"
      }
    ],
    "author": {
      "id": 18,
      "username": "eileen.lowe",
      "name": "Alexandra Bashirian",
      "state": "active",
      "locked": false,
      "avatar_url": null,
      "web_url": "https://gitlab.example.com/eileen.lowe"
    },
    "type": "ISSUE",
    "assignee": {
      "id": 1,
      "username": "root",
      "name": "Administrator",
      "state": "active",
      "locked": false,
      "avatar_url": null,
      "web_url": "https://gitlab.example.com/root"
    },
    "user_notes_count": 1,
    "merge_requests_count": 1,
    "upvotes": 0,
    "downvotes": 0,
    "due_date": null,
    "confidential": false,
    "discussion_locked": null,
    "issue_type": "issue",
    "web_url": "https://gitlab.example.com/my-group/my-project/-/issues/6",
    "time_stats": {
      "time_estimate": 0,
      "total_time_spent": 0,
      "human_time_estimate": null,
      "human_total_time_spent": null
    },
    "task_completion_status": {
      "count": 0,
      "completed_count": 0
    },
    "weight": null,
    "blocking_issues_count": 0
 }
]
```

Example response when you use an external issue tracker, like Jira:
json
```
[
   {
       "id" : "PROJECT-123",
       "title" : "Title of this issue"
   }
]
```

## List issues related to the merge request[](https://docs.gitlab.com/api/merge_requests/#list-issues-related-to-the-merge-request "Permalink")
List issues related to a merge request from its title, description, commit messages, comments, and discussions.
```
GET /projects/:id/merge_requests/:merge_request_iid/related_issues
```

Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
shell
```
curl --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/76/merge_requests/1/related_issues"
```

Example response when you use the GitLab issue tracker:
json
```
[
   {
      "state" : "opened",
      "description" : "Ratione dolores corrupti mollitia soluta quia.",
      "author" : {
         "state" : "active",
         "id" : 18,
         "web_url" : "https://gitlab.example.com/eileen.lowe",
         "name" : "Alexandra Bashirian",
         "avatar_url" : null,
         "username" : "eileen.lowe"
      },
      "milestone" : {
         "project_id" : 1,
         "description" : "Ducimus nam enim ex consequatur cumque ratione.",
         "state" : "closed",
         "due_date" : null,
         "iid" : 2,
         "created_at" : "2016-01-04T15:31:39.996Z",
         "title" : "v4.0",
         "id" : 17,
         "updated_at" : "2016-01-04T15:31:39.996Z"
      },
      "project_id" : 1,
      "assignee" : {
         "state" : "active",
         "id" : 1,
         "name" : "Administrator",
         "web_url" : "https://gitlab.example.com/root",
         "avatar_url" : null,
         "username" : "root"
      },
      "updated_at" : "2016-01-04T15:31:51.081Z",
      "id" : 76,
      "title" : "Consequatur vero maxime deserunt laboriosam est voluptas dolorem.",
      "created_at" : "2016-01-04T15:31:51.081Z",
      "iid" : 6,
      "labels" : [],
      "user_notes_count": 1,
      "changes_count": "1"
   }
]
```

Example response when you use an external issue tracker, like Jira:
json
```
[
   {
       "id" : "PROJECT-123",
       "title" : "Title of this issue"
   }
]
```

## Subscribe to a merge request[](https://docs.gitlab.com/api/merge_requests/#subscribe-to-a-merge-request "Permalink")
Subscribes the authenticated user to a merge request to receive notification.
```
POST /projects/:id/merge_requests/:merge_request_iid/subscribe
```

Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
If the user is already subscribed to the merge request, the endpoint returns the status code `HTTP 304 Not Modified`.
shell
```
curl --request POST \
  --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/5/merge_requests/17/subscribe"
```

Example response:
json
```
{
  "id": 1,
  "iid": 1,
  "project_id": 3,
  "title": "test1",
  "description": "fixed login page css paddings",
  "state": "merged",
  "created_at": "2017-04-29T08:46:00Z",
  "updated_at": "2017-04-29T08:46:00Z",
  "target_branch": "main",
  "source_branch": "test1",
  "upvotes": 0,
  "downvotes": 0,
  "author": {
    "id": 1,
    "name": "Administrator",
    "username": "admin",
    "state": "active",
    "avatar_url": null,
    "web_url" : "https://gitlab.example.com/admin"
  },
  "assignee": {
    "id": 1,
    "name": "Administrator",
    "username": "admin",
    "state": "active",
    "avatar_url": null,
    "web_url" : "https://gitlab.example.com/admin"
  },
  "assignees": [{
    "name": "Miss Monserrate Beier",
    "username": "axel.block",
    "id": 12,
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
    "web_url": "https://gitlab.example.com/axel.block"
  }],
  "reviewers": [{
    "name": "Miss Monserrate Beier",
    "username": "axel.block",
    "id": 12,
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
    "web_url": "https://gitlab.example.com/axel.block"
  }],
  "source_project_id": 2,
  "target_project_id": 3,
  "labels": [
    "Community contribution",
    "Manage"
  ],
  "draft": false,
  "work_in_progress": false,
  "milestone": {
    "id": 5,
    "iid": 1,
    "project_id": 3,
    "title": "v2.0",
    "description": "Assumenda aut placeat expedita exercitationem labore sunt enim earum.",
    "state": "closed",
    "created_at": "2015-02-02T19:49:26.013Z",
    "updated_at": "2015-02-02T19:49:26.013Z",
    "due_date": "2018-09-22",
    "start_date": "2018-08-08",
    "web_url": "https://gitlab.example.com/my-group/my-project/milestones/1"
  },
  "merge_when_pipeline_succeeds": true,
  "merge_status": "can_be_merged",
  "detailed_merge_status": "not_open",
  "sha": "8888888888888888888888888888888888888888",
  "merge_commit_sha": null,
  "squash_commit_sha": null,
  "user_notes_count": 1,
  "discussion_locked": null,
  "should_remove_source_branch": true,
  "force_remove_source_branch": false,
  "allow_collaboration": false,
  "allow_maintainer_to_push": false,
  "web_url": "http://gitlab.example.com/my-group/my-project/merge_requests/1",
  "references": {
    "short": "!1",
    "relative": "!1",
    "full": "my-group/my-project!1"
  },
  "time_stats": {
    "time_estimate": 0,
    "total_time_spent": 0,
    "human_time_estimate": null,
    "human_total_time_spent": null
  },
  "squash": false,
  "subscribed": false,
  "changes_count": "1",
  "merged_by": { // Deprecated and will be removed in API v5, use `merge_user` instead
    "id": 87854,
    "name": "Douwe Maan",
    "username": "DouweM",
    "state": "active",
    "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
    "web_url": "https://gitlab.com/DouweM"
  },
  "merge_user": {
    "id": 87854,
    "name": "Douwe Maan",
    "username": "DouweM",
    "state": "active",
    "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
    "web_url": "https://gitlab.com/DouweM"
  },
  "merged_at": "2018-09-07T11:16:17.520Z",
  "merge_after": "2018-09-07T11:16:00.000Z",
  "prepared_at": "2018-09-04T11:16:17.520Z",
  "closed_by": null,
  "closed_at": null,
  "latest_build_started_at": "2018-09-07T07:27:38.472Z",
  "latest_build_finished_at": "2018-09-07T08:07:06.012Z",
  "first_deployed_to_production_at": null,
  "pipeline": {
    "id": 29626725,
    "sha": "2be7ddb704c7b6b83732fdd5b9f09d5a397b5f8f",
    "ref": "patch-28",
    "status": "success",
    "web_url": "https://gitlab.example.com/my-group/my-project/pipelines/29626725"
  },
  "diff_refs": {
    "base_sha": "c380d3acebd181f13629a25d2e2acca46ffe1e00",
    "head_sha": "2be7ddb704c7b6b83732fdd5b9f09d5a397b5f8f",
    "start_sha": "c380d3acebd181f13629a25d2e2acca46ffe1e00"
  },
  "diverged_commits_count": 2,
  "task_completion_status":{
    "count":0,
    "completed_count":0
  }
}
```

For important notes on response data, see [Single merge request response notes](https://docs.gitlab.com/api/merge_requests/#single-merge-request-response-notes).
## Unsubscribe from a merge request[](https://docs.gitlab.com/api/merge_requests/#unsubscribe-from-a-merge-request "Permalink")
Unsubscribes the authenticated user from a merge request to not receive notifications from that merge request.
```
POST /projects/:id/merge_requests/:merge_request_iid/unsubscribe
```

Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
shell
```
curl --request POST \
  --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/5/merge_requests/17/unsubscribe"
```

If the user is not subscribed to the merge request, the endpoint returns the status code `HTTP 304 Not Modified`.
Example response:
json
```
{
  "id": 1,
  "iid": 1,
  "project_id": 3,
  "title": "test1",
  "description": "fixed login page css paddings",
  "state": "merged",
  "created_at": "2017-04-29T08:46:00Z",
  "updated_at": "2017-04-29T08:46:00Z",
  "target_branch": "main",
  "source_branch": "test1",
  "upvotes": 0,
  "downvotes": 0,
  "author": {
    "id": 1,
    "name": "Administrator",
    "username": "admin",
    "state": "active",
    "avatar_url": null,
    "web_url" : "https://gitlab.example.com/admin"
  },
  "assignee": {
    "id": 1,
    "name": "Administrator",
    "username": "admin",
    "state": "active",
    "avatar_url": null,
    "web_url" : "https://gitlab.example.com/admin"
  },
  "assignees": [{
    "name": "Miss Monserrate Beier",
    "username": "axel.block",
    "id": 12,
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
    "web_url": "https://gitlab.example.com/axel.block"
  }],
  "reviewers": [{
    "name": "Miss Monserrate Beier",
    "username": "axel.block",
    "id": 12,
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
    "web_url": "https://gitlab.example.com/axel.block"
  }],
  "source_project_id": 2,
  "target_project_id": 3,
  "labels": [
    "Community contribution",
    "Manage"
  ],
  "draft": false,
  "work_in_progress": false,
  "milestone": {
    "id": 5,
    "iid": 1,
    "project_id": 3,
    "title": "v2.0",
    "description": "Assumenda aut placeat expedita exercitationem labore sunt enim earum.",
    "state": "closed",
    "created_at": "2015-02-02T19:49:26.013Z",
    "updated_at": "2015-02-02T19:49:26.013Z",
    "due_date": "2018-09-22",
    "start_date": "2018-08-08",
    "web_url": "https://gitlab.example.com/my-group/my-project/milestones/1"
  },
  "merge_when_pipeline_succeeds": true,
  "merge_status": "can_be_merged",
  "detailed_merge_status": "not_open",
  "sha": "8888888888888888888888888888888888888888",
  "merge_commit_sha": null,
  "squash_commit_sha": null,
  "user_notes_count": 1,
  "discussion_locked": null,
  "should_remove_source_branch": true,
  "force_remove_source_branch": false,
  "allow_collaboration": false,
  "allow_maintainer_to_push": false,
  "web_url": "http://gitlab.example.com/my-group/my-project/merge_requests/1",
  "references": {
    "short": "!1",
    "relative": "!1",
    "full": "my-group/my-project!1"
  },
  "time_stats": {
    "time_estimate": 0,
    "total_time_spent": 0,
    "human_time_estimate": null,
    "human_total_time_spent": null
  },
  "squash": false,
  "subscribed": false,
  "changes_count": "1",
  "merged_by": { // Deprecated and will be removed in API v5, use `merge_user` instead
    "id": 87854,
    "name": "Douwe Maan",
    "username": "DouweM",
    "state": "active",
    "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
    "web_url": "https://gitlab.com/DouweM"
  },
  "merge_user": {
    "id": 87854,
    "name": "Douwe Maan",
    "username": "DouweM",
    "state": "active",
    "avatar_url": "https://gitlab.example.com/uploads/-/system/user/avatar/87854/avatar.png",
    "web_url": "https://gitlab.com/DouweM"
  },
  "merged_at": "2018-09-07T11:16:17.520Z",
  "merge_after": "2018-09-07T11:16:00.000Z",
  "prepared_at": "2018-09-04T11:16:17.520Z",
  "closed_by": null,
  "closed_at": null,
  "latest_build_started_at": "2018-09-07T07:27:38.472Z",
  "latest_build_finished_at": "2018-09-07T08:07:06.012Z",
  "first_deployed_to_production_at": null,
  "pipeline": {
    "id": 29626725,
    "sha": "2be7ddb704c7b6b83732fdd5b9f09d5a397b5f8f",
    "ref": "patch-28",
    "status": "success",
    "web_url": "https://gitlab.example.com/my-group/my-project/pipelines/29626725"
  },
  "diff_refs": {
    "base_sha": "c380d3acebd181f13629a25d2e2acca46ffe1e00",
    "head_sha": "2be7ddb704c7b6b83732fdd5b9f09d5a397b5f8f",
    "start_sha": "c380d3acebd181f13629a25d2e2acca46ffe1e00"
  },
  "diverged_commits_count": 2,
  "task_completion_status":{
    "count":0,
    "completed_count":0
  }
}
```

For important notes on response data, see [Single merge request response notes](https://docs.gitlab.com/api/merge_requests/#single-merge-request-response-notes).
## Create a to-do item[](https://docs.gitlab.com/api/merge_requests/#create-a-to-do-item "Permalink")
Manually creates a to-do item for the current user on a merge request. If a to-do item already exists for the user on that merge request, this endpoint returns status code `HTTP 304 Not Modified`.
```
POST /projects/:id/merge_requests/:merge_request_iid/todo
```

Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
shell
```
curl --request POST \
  --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/5/merge_requests/27/todo"
```

Example response:
json
```
{
  "id": 113,
  "project": {
    "id": 3,
    "name": "GitLab CI/CD",
    "name_with_namespace": "GitLab Org / GitLab CI/CD",
    "path": "gitlab-ci",
    "path_with_namespace": "gitlab-org/gitlab-ci"
  },
  "author": {
    "name": "Administrator",
    "username": "root",
    "id": 1,
    "state": "active",
    "avatar_url": "http://www.gravatar.com/avatar/e64c7d89f26bd1972efa854d13d7dd61?s=80&d=identicon",
    "web_url": "https://gitlab.example.com/root"
  },
  "action_name": "marked",
  "target_type": "MergeRequest",
  "target": {
    "id": 27,
    "iid": 7,
    "project_id": 3,
    "title": "Et voluptas laudantium minus nihil recusandae ut accusamus earum aut non.",
    "description": "Veniam sunt nihil modi earum cumque illum delectus. Nihil ad quis distinctio quia. Autem eligendi at quibusdam repellendus.",
    "state": "merged",
    "created_at": "2016-06-17T07:48:04.330Z",
    "updated_at": "2016-07-01T11:14:15.537Z",
    "target_branch": "allow_regex_for_project_skip_ref",
    "source_branch": "backup",
    "upvotes": 0,
    "downvotes": 0,
    "author": {
      "name": "Jarret O'Keefe",
      "username": "francisca",
      "id": 14,
      "state": "active",
      "avatar_url": "http://www.gravatar.com/avatar/a7fa515d53450023c83d62986d0658a8?s=80&d=identicon",
      "web_url": "https://gitlab.example.com/francisca",
      "discussion_locked": false
    },
    "assignee": {
      "name": "Dr. Gabrielle Strosin",
      "username": "barrett.krajcik",
      "id": 4,
      "state": "active",
      "avatar_url": "http://www.gravatar.com/avatar/733005fcd7e6df12d2d8580171ccb966?s=80&d=identicon",
      "web_url": "https://gitlab.example.com/barrett.krajcik"
    },
    "assignees": [{
      "name": "Miss Monserrate Beier",
      "username": "axel.block",
      "id": 12,
      "state": "active",
      "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
      "web_url": "https://gitlab.example.com/axel.block"
    }],
    "reviewers": [{
      "name": "Miss Monserrate Beier",
      "username": "axel.block",
      "id": 12,
      "state": "active",
      "avatar_url": "http://www.gravatar.com/avatar/46f6f7dc858ada7be1853f7fb96e81da?s=80&d=identicon",
      "web_url": "https://gitlab.example.com/axel.block"
    }],
    "source_project_id": 3,
    "target_project_id": 3,
    "labels": [],
    "draft": false,
    "work_in_progress": false,
    "milestone": {
      "id": 27,
      "iid": 2,
      "project_id": 3,
      "title": "v1.0",
      "description": "Quis ea accusantium animi hic fuga assumenda.",
      "state": "active",
      "created_at": "2016-06-17T07:47:33.840Z",
      "updated_at": "2016-06-17T07:47:33.840Z",
      "due_date": null
    },
    "merge_when_pipeline_succeeds": false,
    "merge_status": "unchecked",
    "detailed_merge_status": "not_open",
    "subscribed": true,
    "sha": "8888888888888888888888888888888888888888",
    "merge_commit_sha": null,
    "squash_commit_sha": null,
    "user_notes_count": 7,
    "changes_count": "1",
    "should_remove_source_branch": true,
    "force_remove_source_branch": false,
    "squash": false,
    "web_url": "http://example.com/my-group/my-project/merge_requests/1",
    "references": {
      "short": "!1",
      "relative": "!1",
      "full": "my-group/my-project!1"
    }
  },
  "target_url": "https://gitlab.example.com/gitlab-org/gitlab-ci/merge_requests/7",
  "body": "Et voluptas laudantium minus nihil recusandae ut accusamus earum aut non.",
  "state": "pending",
  "created_at": "2016-07-01T11:14:15.530Z"
}
```

## Retrieve merge request diff versions[](https://docs.gitlab.com/api/merge_requests/#retrieve-merge-request-diff-versions "Permalink")
Retrieve diff versions for a merge request.
```
GET /projects/:id/merge_requests/:merge_request_iid/versions
```

Attribute | Type | Required | Description
---|---|---|---
`id` | String | Yes | The ID of the project.
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
For an explanation of the SHAs in the response, see [SHAs in the API response](https://docs.gitlab.com/api/merge_requests/#shas-in-the-api-response).
shell
```
curl --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/1/merge_requests/1/versions"
```

Example response:
json
```
[{
  "id": 110,
  "head_commit_sha": "33e2ee8579fda5bc36accc9c6fbd0b4fefda9e30",
  "base_commit_sha": "eeb57dffe83deb686a60a71c16c32f71046868fd",
  "start_commit_sha": "eeb57dffe83deb686a60a71c16c32f71046868fd",
  "created_at": "2016-07-26T14:44:48.926Z",
  "merge_request_id": 105,
  "state": "collected",
  "real_size": "1",
  "patch_id_sha": "d504412d5b6e6739647e752aff8e468dde093f2f"
}, {
  "id": 108,
  "head_commit_sha": "3eed087b29835c48015768f839d76e5ea8f07a24",
  "base_commit_sha": "eeb57dffe83deb686a60a71c16c32f71046868fd",
  "start_commit_sha": "eeb57dffe83deb686a60a71c16c32f71046868fd",
  "created_at": "2016-07-25T14:21:33.028Z",
  "merge_request_id": 105,
  "state": "collected",
  "real_size": "1",
  "patch_id_sha": "72c30d1f0115fc1d2bb0b29b24dc2982cbcdfd32"
}]
```

### SHAs in the API response[](https://docs.gitlab.com/api/merge_requests/#shas-in-the-api-response "Permalink")
SHA field | Purpose
---|---
`base_commit_sha` | The merge-base commit SHA between the source branch and the target branches.
`head_commit_sha` | The HEAD commit of the source branch.
`start_commit_sha` | The HEAD commit SHA of the target branch when this version of the diff was created.
## Retrieve a merge request diff version[](https://docs.gitlab.com/api/merge_requests/#retrieve-a-merge-request-diff-version "Permalink")
History
  * `collapsed` and `too_large` response attributes [introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/199633) in GitLab 18.4.


Retrieve a specific diff version for a merge request.
```
GET /projects/:id/merge_requests/:merge_request_iid/versions/:version_id
```

Supported attributes:
Attribute | Type | Required | Description
---|---|---|---
`id` | String | Yes | ID of the project.
`merge_request_iid` | integer | Yes | Internal ID of the merge request.
`version_id` | integer | Yes | ID of the merge request diff version.
`unidiff` | boolean | No | Present diffs in the [unified diff](https://www.gnu.org/software/diffutils/manual/html_node/Detailed-Unified.html) format. Default is false. [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/130610) in GitLab 16.5.
If successful, returns [`200 OK`](https://docs.gitlab.com/api/rest/troubleshooting/#status-codes) and the following response attributes:
Attribute | Type | Description
---|---|---
`id` | integer | ID of the merge request diff version.
`base_commit_sha` | string | Merge-base commit SHA between the source branch and the target branches.
`commits` | object array | Commits in the merge request diff.
`commits[].id` | string | ID of the commit.
`commits[].short_id` | string | Short ID of the commit.
`commits[].created_at` | datetime | Identical to the `committed_date` field.
`commits[].parent_ids` | array | IDs of the parent commits.
`commits[].title` | string | Commit title.
`commits[].message` | string | Commit message.
`commits[].author_name` | string | Commit author’s name.
`commits[].author_email` | string | Commit author’s email address.
`commits[].authored_date` | datetime | Commit authored date.
`commits[].committer_name` | string | Name of the committer.
`commits[].committer_email` | string | Email address of the committer.
`commits[].committed_date` | datetime | Commit date.
`commits[].trailers` | object | Git trailers parsed for the commit. Duplicate keys include the last value only.
`commits[].extended_trailers` | object | Git trailers parsed for the commit.
`commits[].web_url` | string | Web URL of the merge request.
`created_at` | datetime | Creation date and time of the merge request.
`diffs` | object array | Diffs in the merge request diff version.
`diffs[].a_mode` | string | Old file mode of the file.
`diffs[].b_mode` | string | New file mode of the file.
`diffs[].collapsed` | boolean | File diffs are excluded but can be fetched on request.
`diffs[].deleted_file` | boolean | File has been removed.
`diffs[].diff` | string | Content of the diff.
`diffs[].generated_file` | boolean | File is [marked as generated](https://docs.gitlab.com/user/project/merge_requests/changes/#collapse-generated-files).
`diffs[].new_file` | boolean | File has been added.
`diffs[].new_path` | string | New path of the file.
`diffs[].old_path` | string | Old path of the file.
`diffs[].renamed_file` | boolean | File has been renamed.
`diffs[].too_large` | boolean | File diffs are excluded and cannot be retrieved.
`head_commit_sha` | string | HEAD commit of the source branch.
`merge_request_id` | integer | ID of the merge request.
`patch_id_sha` | string |  [Patch ID](https://git-scm.com/docs/git-patch-id) for the merge request diff.
`real_size` | string | Number of changes in the merge request diff.
`start_commit_sha` | string | HEAD commit SHA of the target branch when this version of the diff was created.
`state` | string | State of the merge request diff. Can be `collected`, `overflow`, `without_files`. Deprecated values: `timeout`, `overflow_commits_safe_size`, `overflow_diff_files_limit`, `overflow_diff_lines_limit`.
Example request:
shell
```
curl --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/1/merge_requests/1/versions/1"
```

Example response:
json
```
{
  "id": 110,
  "head_commit_sha": "33e2ee8579fda5bc36accc9c6fbd0b4fefda9e30",
  "base_commit_sha": "eeb57dffe83deb686a60a71c16c32f71046868fd",
  "start_commit_sha": "eeb57dffe83deb686a60a71c16c32f71046868fd",
  "created_at": "2016-07-26T14:44:48.926Z",
  "merge_request_id": 105,
  "state": "collected",
  "real_size": "1",
  "patch_id_sha": "d504412d5b6e6739647e752aff8e468dde093f2f",
  "commits": [{
    "id": "33e2ee8579fda5bc36accc9c6fbd0b4fefda9e30",
    "short_id": "33e2ee85",
    "parent_ids": [],
    "title": "Change year to 2018",
    "author_name": "Administrator",
    "author_email": "admin@example.com",
    "authored_date": "2016-07-26T17:44:29.000+03:00",
    "committer_name": "Administrator",
    "committer_email": "admin@example.com",
    "committed_date": "2016-07-26T17:44:29.000+03:00",
    "created_at": "2016-07-26T17:44:29.000+03:00",
    "message": "Change year to 2018",
    "trailers": {},
    "extended_trailers": {},
    "web_url": "https://gitlab.example.com/project/-/commit/33e2ee8579fda5bc36accc9c6fbd0b4fefda9e30"
  }, {
    "id": "aa24655de48b36335556ac8a3cd8bb521f977cbd",
    "short_id": "aa24655d",
    "parent_ids": [],
    "title": "Update LICENSE",
    "author_name": "Administrator",
    "author_email": "admin@example.com",
    "authored_date": "2016-07-25T17:21:53.000+03:00",
    "committer_name": "Administrator",
    "committer_email": "admin@example.com",
    "committed_date": "2016-07-25T17:21:53.000+03:00",
    "created_at": "2016-07-25T17:21:53.000+03:00",
    "message": "Update LICENSE",
    "trailers": {},
    "extended_trailers": {},
    "web_url": "https://gitlab.example.com/project/-/commit/aa24655de48b36335556ac8a3cd8bb521f977cbd"
  }, {
    "id": "3eed087b29835c48015768f839d76e5ea8f07a24",
    "short_id": "3eed087b",
    "parent_ids": [],
    "title": "Add license",
    "author_name": "Administrator",
    "author_email": "admin@example.com",
    "authored_date": "2016-07-25T17:21:20.000+03:00",
    "committer_name": "Administrator",
    "committer_email": "admin@example.com",
    "committed_date": "2016-07-25T17:21:20.000+03:00",
    "created_at": "2016-07-25T17:21:20.000+03:00",
    "message": "Add license",
    "trailers": {},
    "extended_trailers": {},
    "web_url": "https://gitlab.example.com/project/-/commit/3eed087b29835c48015768f839d76e5ea8f07a24"
  }],
  "diffs": [{
    "old_path": "LICENSE",
    "new_path": "LICENSE",
    "a_mode": "0",
    "b_mode": "100644",
    "diff": "@@ -0,0 +1,21 @@\n+The MIT License (MIT)\n+\n+Copyright (c) 2018 Administrator\n+\n+Permission is hereby granted, free of charge, to any person obtaining a copy\n+of this software and associated documentation files (the \"Software\"), to deal\n+in the Software without restriction, including without limitation the rights\n+to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\n+copies of the Software, and to permit persons to whom the Software is\n+furnished to do so, subject to the following conditions:\n+\n+The above copyright notice and this permission notice shall be included in all\n+copies or substantial portions of the Software.\n+\n+THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\n+IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\n+FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\n+AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\n+LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\n+OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\n+SOFTWARE.\n",
    "collapsed": false,
    "too_large": false,
    "new_file": true,
    "renamed_file": false,
    "deleted_file": false,
    "generated_file": false
  }]
}
```

## Set a time estimate for a merge request[](https://docs.gitlab.com/api/merge_requests/#set-a-time-estimate-for-a-merge-request "Permalink")
Sets an estimated time of work for this merge request.
```
POST /projects/:id/merge_requests/:merge_request_iid/time_estimate
```

Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
`duration` | string | Yes | The duration in human format, such as `3h30m`.
shell
```
curl --request POST \
  --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/5/merge_requests/93/time_estimate?duration=3h30m"
```

Example response:
json
```
{
  "human_time_estimate": "3h 30m",
  "human_total_time_spent": null,
  "time_estimate": 12600,
  "total_time_spent": 0
}
```

## Reset the time estimate for a merge request[](https://docs.gitlab.com/api/merge_requests/#reset-the-time-estimate-for-a-merge-request "Permalink")
Resets the estimated time for this merge request to 0 seconds.
```
POST /projects/:id/merge_requests/:merge_request_iid/reset_time_estimate
```

Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of a project’s merge request.
shell
```
curl --request POST \
  --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/5/merge_requests/93/reset_time_estimate"
```

Example response:
json
```
{
  "human_time_estimate": null,
  "human_total_time_spent": null,
  "time_estimate": 0,
  "total_time_spent": 0
}
```

## Add spent time for a merge request[](https://docs.gitlab.com/api/merge_requests/#add-spent-time-for-a-merge-request "Permalink")
Adds spent time for this merge request.
```
POST /projects/:id/merge_requests/:merge_request_iid/add_spent_time
```

Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
`duration` | string | Yes | The duration in human format, such as `3h30m`
`summary` | string | No | A summary of how the time was spent.
shell
```
curl --request POST \
  --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/5/merge_requests/93/add_spent_time?duration=1h"
```

Example response:
json
```
{
  "human_time_estimate": null,
  "human_total_time_spent": "1h",
  "time_estimate": 0,
  "total_time_spent": 3600
}
```

## Reset spent time for a merge request[](https://docs.gitlab.com/api/merge_requests/#reset-spent-time-for-a-merge-request "Permalink")
Resets the total spent time for this merge request to 0 seconds.
```
POST /projects/:id/merge_requests/:merge_request_iid/reset_spent_time
```

Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of a project’s merge request.
shell
```
curl --request POST \
  --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/5/merge_requests/93/reset_spent_time"
```

Example response:
json
```
{
  "human_time_estimate": null,
  "human_total_time_spent": null,
  "time_estimate": 0,
  "total_time_spent": 0
}
```

## Retrieve time tracking statistics[](https://docs.gitlab.com/api/merge_requests/#retrieve-time-tracking-statistics "Permalink")
Retrieve time tracking statistics for a merge request.
```
GET /projects/:id/merge_requests/:merge_request_iid/time_stats
```

Attribute | Type | Required | Description
---|---|---|---
`id` | integer or string | Yes | The ID or [URL-encoded path of the project](https://docs.gitlab.com/api/rest/#namespaced-paths).
`merge_request_iid` | integer | Yes | The internal ID of the merge request.
shell
```
curl --header "PRIVATE-TOKEN: <your_access_token>" \
  --url "https://gitlab.example.com/api/v4/projects/5/merge_requests/93/time_stats"
```

Example response:
json
```
{
  "human_time_estimate": "2h",
  "human_total_time_spent": "1h",
  "time_estimate": 7200,
  "total_time_spent": 3600
}
```

## Approvals[](https://docs.gitlab.com/api/merge_requests/#approvals "Permalink")
For approvals, see [Merge request approvals](https://docs.gitlab.com/api/merge_request_approvals/).
## List merge request state events[](https://docs.gitlab.com/api/merge_requests/#list-merge-request-state-events "Permalink")
To track which state was set, who did it, and when it happened, check out [Resource state events API](https://docs.gitlab.com/api/resource_state_events/#merge-requests).
## Troubleshooting[](https://docs.gitlab.com/api/merge_requests/#troubleshooting "Permalink")
### Empty API fields for new merge requests[](https://docs.gitlab.com/api/merge_requests/#empty-api-fields-for-new-merge-requests "Permalink")
When you create a merge request, the `diff_refs` and `changes_count` fields are initially empty. These fields populate asynchronously after you create the merge request. For more information, see [issue 386562](https://gitlab.com/gitlab-org/gitlab/-/issues/386562), and the [related discussion](https://forum.gitlab.com/t/diff-refs-empty-after-mr-is-created/78975) in the GitLab forums.
Was this page helpful?YesNo
Edit this page
  *     * [ Open in Web IDE`.`Quickly and easily edit multiple files. ](https://gitlab.com/-/ide/project/gitlab-org/gitlab/edit/master/-/doc/api/merge_requests.md)
    * [ View page sourceEdit this file only. ](https://gitlab.com/gitlab-org/gitlab/-/blob/master/doc/api/merge_requests.md)
    * [ Create an issueSuggest improvements. ](https://gitlab.com/gitlab-org/gitlab/-/issues/new?issuable_template=Documentation)


  * [Removals in API v5](https://docs.gitlab.com/api/merge_requests/#removals-in-api-v5)
  * [List merge requests](https://docs.gitlab.com/api/merge_requests/#list-merge-requests)
  * [Merge requests list response notes](https://docs.gitlab.com/api/merge_requests/#merge-requests-list-response-notes)
  * [List project merge requests](https://docs.gitlab.com/api/merge_requests/#list-project-merge-requests)
  * [List group merge requests](https://docs.gitlab.com/api/merge_requests/#list-group-merge-requests)
  * [Retrieve a merge request](https://docs.gitlab.com/api/merge_requests/#retrieve-a-merge-request)
  * [Response](https://docs.gitlab.com/api/merge_requests/#response)
  * [Single merge request response notes](https://docs.gitlab.com/api/merge_requests/#single-merge-request-response-notes)
  * [Merge status](https://docs.gitlab.com/api/merge_requests/#merge-status)
  * [Preparation steps](https://docs.gitlab.com/api/merge_requests/#preparation-steps)
  * [Retrieve merge request participants](https://docs.gitlab.com/api/merge_requests/#retrieve-merge-request-participants)
  * [Retrieve merge request reviewers](https://docs.gitlab.com/api/merge_requests/#retrieve-merge-request-reviewers)
  * [Retrieve merge request commits](https://docs.gitlab.com/api/merge_requests/#retrieve-merge-request-commits)
  * [Retrieve merge request dependencies](https://docs.gitlab.com/api/merge_requests/#retrieve-merge-request-dependencies)
  * [Delete a merge request dependency](https://docs.gitlab.com/api/merge_requests/#delete-a-merge-request-dependency)
  * [Create a merge request dependency](https://docs.gitlab.com/api/merge_requests/#create-a-merge-request-dependency)
  * [Retrieve blocked merge requests](https://docs.gitlab.com/api/merge_requests/#retrieve-blocked-merge-requests)
  * [Retrieve merge request changes](https://docs.gitlab.com/api/merge_requests/#retrieve-merge-request-changes)
  * [List merge request diffs](https://docs.gitlab.com/api/merge_requests/#list-merge-request-diffs)
  * [Show merge request raw diffs](https://docs.gitlab.com/api/merge_requests/#show-merge-request-raw-diffs)
  * [List merge request pipelines](https://docs.gitlab.com/api/merge_requests/#list-merge-request-pipelines)
  * [Create merge request pipeline](https://docs.gitlab.com/api/merge_requests/#create-merge-request-pipeline)
  * [Create a merge request](https://docs.gitlab.com/api/merge_requests/#create-a-merge-request)
  * [Update a merge request](https://docs.gitlab.com/api/merge_requests/#update-a-merge-request)
  * [Delete a merge request](https://docs.gitlab.com/api/merge_requests/#delete-a-merge-request)
  * [Merge a merge request](https://docs.gitlab.com/api/merge_requests/#merge-a-merge-request)
  * [Merge to default merge ref path](https://docs.gitlab.com/api/merge_requests/#merge-to-default-merge-ref-path)
  * [Cancel merge when pipeline succeeds](https://docs.gitlab.com/api/merge_requests/#cancel-merge-when-pipeline-succeeds)
  * [Rebase a merge request](https://docs.gitlab.com/api/merge_requests/#rebase-a-merge-request)
  * [Comments on merge requests](https://docs.gitlab.com/api/merge_requests/#comments-on-merge-requests)
  * [List issues that close on merge](https://docs.gitlab.com/api/merge_requests/#list-issues-that-close-on-merge)
  * [List issues related to the merge request](https://docs.gitlab.com/api/merge_requests/#list-issues-related-to-the-merge-request)
  * [Subscribe to a merge request](https://docs.gitlab.com/api/merge_requests/#subscribe-to-a-merge-request)
  * [Unsubscribe from a merge request](https://docs.gitlab.com/api/merge_requests/#unsubscribe-from-a-merge-request)
  * [Create a to-do item](https://docs.gitlab.com/api/merge_requests/#create-a-to-do-item)
  * [Retrieve merge request diff versions](https://docs.gitlab.com/api/merge_requests/#retrieve-merge-request-diff-versions)
  * [SHAs in the API response](https://docs.gitlab.com/api/merge_requests/#shas-in-the-api-response)
  * [Retrieve a merge request diff version](https://docs.gitlab.com/api/merge_requests/#retrieve-a-merge-request-diff-version)
  * [Set a time estimate for a merge request](https://docs.gitlab.com/api/merge_requests/#set-a-time-estimate-for-a-merge-request)
  * [Reset the time estimate for a merge request](https://docs.gitlab.com/api/merge_requests/#reset-the-time-estimate-for-a-merge-request)
  * [Add spent time for a merge request](https://docs.gitlab.com/api/merge_requests/#add-spent-time-for-a-merge-request)
  * [Reset spent time for a merge request](https://docs.gitlab.com/api/merge_requests/#reset-spent-time-for-a-merge-request)
  * [Retrieve time tracking statistics](https://docs.gitlab.com/api/merge_requests/#retrieve-time-tracking-statistics)
  * [Approvals](https://docs.gitlab.com/api/merge_requests/#approvals)
  * [List merge request state events](https://docs.gitlab.com/api/merge_requests/#list-merge-request-state-events)
  * [Troubleshooting](https://docs.gitlab.com/api/merge_requests/#troubleshooting)
  * [Empty API fields for new merge requests](https://docs.gitlab.com/api/merge_requests/#empty-api-fields-for-new-merge-requests)


[![GitLab Docs logo](https://docs.gitlab.com/gitlab-logo-footer.svg)](https://docs.gitlab.com/)
  * [Facebook](https://www.facebook.com/gitlab)
  * [LinkedIn](https://www.linkedin.com/company/gitlab-com)
  * [Twitter](https://twitter.com/gitlab)
  * [YouTube](https://www.youtube.com/channel/UCnMGQ8QHMAnVIsI3xJrihhg)

[![Creative Commons License](https://docs.gitlab.com/by-sa.svg)](https://creativecommons.org/licenses/by-sa/4.0/)
Company
  * [About GitLab](https://about.gitlab.com/company/)
  * [View pricing](https://about.gitlab.com/pricing/)
  * [Try GitLab for free](https://about.gitlab.com/free-trial/)


Feedback
  * [View page source](https://gitlab.com/gitlab-org/gitlab/-/blob/master/doc/api/merge_requests.md)
  * [Edit in Web IDE](https://gitlab.com/-/ide/project/gitlab-org/gitlab/edit/master/-/doc/api/merge_requests.md)
  * [Contribute to GitLab](https://about.gitlab.com/community/contribute/)
  * [Suggest updates](https://gitlab.com/gitlab-org/gitlab/-/issues/new?issuable_template=Documentation)


Help & Community
  * [Get certified](https://university.gitlab.com/pages/certifications)
  * [Get support](https://about.gitlab.com/support/)
  * [Post on the GitLab forum](https://forum.gitlab.com/new-topic?title=topic%20title&body=topic%20body&tags=docs-feedback)


Resources
  * [Terms](https://about.gitlab.com/terms/)
  * [Privacy statement](https://about.gitlab.com/privacy/)
  * [Use of generative AI](https://docs.gitlab.com/legal/use_generative_ai/)
  * [Acceptable use of user licenses](https://docs.gitlab.com/legal/licensing_policy/)
  * Cookie Preferences


![](https://cdn.bizible.com/ipv?_biz_r=&_biz_h=800054037&_biz_u=10503924d6784ad3f2d352558587a67a&_biz_l=https%3A%2F%2Fdocs.gitlab.com%2Fapi%2Fmerge_requests%2F&_biz_t=1772174324038&_biz_i=Merge%20requests%20API%20%7C%20GitLab%20Docs&_biz_n=95&rnd=945290&cdn_o=a&_biz_z=1772174324040)
![Company Logo](https://cdn.cookielaw.org/logos/aa14a5c8-79e3-442a-8177-464ad850b19d/e46c1d0d-1f66-481f-bc06-5427671431da/253e6fee-c4c0-4b60-bc35-79cdae5dda32/gitlab-logo-100.png)
## Privacy Preference Center
## Privacy Preference Center
  * ### Your Privacy
  * ### Strictly Necessary Cookies
  * ### Functionality Cookies
  * ### Performance and Analytics Cookies
  * ### Targeting and Advertising Cookies
  * ### Ad User Data
  * ### Ad Personalization


#### Your Privacy
When you visit any website, it may store or retrieve information on your browser, mostly in the form of cookies. This information might be about you, your preferences or your device and is mostly used to make the site work as you expect it to. The information does not usually directly identify you, but it can give you a more personalized web experience. Because we respect your right to privacy, you can choose not to allow some types of cookies. Click on the different category headings to find out more and change our default settings. However, blocking some types of cookies may impact your experience of the site and the services we are able to offer.
[Cookie Policy](https://about.gitlab.com/privacy/cookies/)
**User ID:** 42fad8d5-ed56-4786-8d74-3c72635252d2
_This User ID will be used as a unique identifier while storing and accessing your preferences for future._
**Timestamp:** --
#### Strictly Necessary Cookies
Always Active
These cookies are necessary for the website to function and cannot be switched off in our systems. They are usually only set in response to actions made by you which amount to a request for services, such as setting your privacy preferences, enabling you to securely log into the site, filling in forms, or using the customer checkout. GitLab processes any personal data collected through these cookies on the basis of our legitimate interest.
Cookies Details
#### Functionality Cookies
Functionality Cookies
These cookies enable helpful but non-essential website functions that improve your website experience. By recognizing you when you return to our website, they may, for example, allow us to personalize our content for you or remember your preferences. If you do not allow these cookies then some or all of these services may not function properly. GitLab processes any personal data collected through these cookies on the basis of your consent
Cookies Details
#### Performance and Analytics Cookies
Performance and Analytics Cookies
These cookies allow us and our third-party service providers to recognize and count the number of visitors on our websites and to see how visitors move around our websites when they are using it. This helps us improve our products and ensures that users can easily find what they need on our websites. These cookies usually generate aggregate statistics that are not associated with an individual. To the extent any personal data is collected through these cookies, GitLab processes that data on the basis of your consent.
Cookies Details
#### Targeting and Advertising Cookies
Targeting and Advertising Cookies
These cookies enable different advertising related functions. They may allow us to record information about your visit to our websites, such as pages visited, links followed, and videos viewed so we can make our websites and the advertising displayed on it more relevant to your interests. They may be set through our website by our advertising partners. They may be used by those companies to build a profile of your interests and show you relevant advertisements on other websites. GitLab processes any personal data collected through these cookies on the basis of your consent.
Cookies Details
#### Ad User Data
Ad User Data
Sets consent for sending user data to Google for advertising purposes.
Cookies Details
#### Ad Personalization
Ad Personalization
Sets consent for personalized advertising.
Cookies Details
Back Button
### Cookie List
Filter Button
Consent Leg.Interest
checkbox label label
checkbox label label
checkbox label label
Clear
  * checkbox label label


Apply Cancel
Confirm My Choices
Allow All
[![Powered by Onetrust](https://cdn.cookielaw.org/logos/static/powered_by_logo.svg)](https://www.onetrust.com/products/cookie-consent/)
