## [0.2.0] - 2026-03-06

### 🚀 Features

- *(agent)* Add Ollama runtime health check and configurable host
- *(cli)* Add Ollama runtime check and alert UI

### 🧪 Testing

- *(agent)* Add comprehensive Ollama runtime health check tests
- *(cli)* Add comprehensive Ollama runtime health alert tests

### ⚙️ Miscellaneous Tasks

- Bump version to 0.2.0
