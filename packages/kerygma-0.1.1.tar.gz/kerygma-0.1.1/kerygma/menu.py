import asyncio

from kerygma.telegram_client import conectar
from kerygma.database import (
    adicionar_agendamento,
    listar_pendentes,
    listar_historico,
    excluir_agendamento
)


def capturar_mensagem_multilinha():
    print("\nCole a mensagem abaixo.")
    print("Quando terminar, pressione ENTER duas vezes para finalizar.\n")

    linhas = []
    while True:
        linha = input()
        if linha == "":
            break
        linhas.append(linha)

    return "\n".join(linhas)


async def enviar_mensagem():
    destino = input("Digite o @username ou nome do grupo: ")
    mensagem = capturar_mensagem_multilinha()

    client = await conectar()
    await client.send_message(destino, mensagem)
    await client.disconnect()

    print("\n✅ Mensagem enviada com sucesso!\n")


def iniciar_menu():
    while True:
        print("\n===== Projeto Kerygma - feito por Tiago Rabelo =====")
        print("1 - Enviar mensagem agora")
        print("2 - Agendar mensagem")
        print("3 - Ver pendentes")
        print("4 - Ver histórico")
        print("5 - Excluir agendamento")
        print("0 - Sair")

        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            asyncio.run(enviar_mensagem())

        elif opcao == "2":
            destino = input("Destino: ")
            mensagem = capturar_mensagem_multilinha()
            data = input("Data e hora (YYYY-MM-DD HH:MM): ")

            adicionar_agendamento(destino, mensagem, data)
            print("\n✅ Agendamento salvo com sucesso!\n")

        elif opcao == "3":
            pendentes = listar_pendentes()

            if not pendentes:
                print("Nenhuma mensagem pendente.")
            else:
                print("\n=== PENDENTES ===")
                for ag in pendentes:
                    print(f"""
ID: {ag[0]}
Destino: {ag[1]}
Mensagem:
{ag[2]}
Data/Hora: {ag[3]}
Status: {ag[4]}
------------------------
""")

        elif opcao == "4":
            historico = listar_historico()

            if not historico:
                print("Nenhuma mensagem enviada ainda.")
            else:
                print("\n=== HISTÓRICO (últimas 10) ===")
                for ag in historico:
                    print(f"""
ID: {ag[0]}
Destino: {ag[1]}
Mensagem:
{ag[2]}
Data/Hora: {ag[3]}
Status: {ag[4]}
------------------------
""")

        elif opcao == "5":
            try:
                ag_id = int(input("Digite o ID do agendamento que deseja excluir: "))
                excluir_agendamento(ag_id)
                print("\n✅ Agendamento excluído com sucesso!\n")
            except ValueError:
                print("❌ ID inválido. Digite apenas números.\n")

        elif opcao == "0":
            print("Saindo...")
            break

        else:
            print("Opção inválida!")
