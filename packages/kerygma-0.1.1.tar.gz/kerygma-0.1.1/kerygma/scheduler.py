import asyncio
from datetime import datetime
from kerygma.database import get_connection
from kerygma.telegram_client import conectar


async def verificar_agendamentos():
    while True:
        try:
            conn = get_connection()
            cursor = conn.cursor()

            agora = datetime.now().strftime("%Y-%m-%d %H:%M")

            cursor.execute("""
                SELECT id, destino, mensagem 
                FROM agendamentos 
                WHERE data_hora <= ? AND status = 'pendente'
            """, (agora,))

            agendamentos = cursor.fetchall()

            if agendamentos:
                try:
                    client = await conectar()
                except Exception as e:
                    print("⚠️ Não foi possível conectar ao Telegram.")
                    print("Tentará novamente em 30 segundos...")
                    conn.close()
                    await asyncio.sleep(30)
                    continue

                for ag in agendamentos:
                    ag_id, destino, mensagem = ag

                    try:
                        await client.send_message(destino, mensagem)

                        cursor.execute("""
                            UPDATE agendamentos
                            SET status = 'enviado'
                            WHERE id = ?
                        """, (ag_id,))
                        conn.commit()

                        print(f"✅ Mensagem enviada para {destino}")

                    except Exception as e:
                        print(f"⚠️ Falha ao enviar para {destino}. Permanecerá pendente.")

                await client.disconnect()

            conn.close()

        except Exception as e:
            print("⚠️ Erro inesperado no scheduler. Continuando...")

        await asyncio.sleep(30)
