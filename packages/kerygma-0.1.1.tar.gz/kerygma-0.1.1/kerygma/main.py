from kerygma.scheduler import verificar_agendamentos
import asyncio
from kerygma.database import init_db
from kerygma.menu import iniciar_menu
from kerygma.telegram_client import conectar


async def main_async():
    # Inicializa banco
    init_db()

    # 🔐 Garante login antes de tudo
    print("🔐 Verificando autenticação com o Telegram...")
    try:
        client = await conectar()
        await client.disconnect()
        print("✅ Autenticado com sucesso!\n")
    except Exception:
        print("❌ Erro ao autenticar. Verifique sua conexão.")
        return

    # Inicia scheduler em background
    asyncio.create_task(verificar_agendamentos())

    # Inicia menu (em thread separada)
    await asyncio.to_thread(iniciar_menu)


def run():
    asyncio.run(main_async())
