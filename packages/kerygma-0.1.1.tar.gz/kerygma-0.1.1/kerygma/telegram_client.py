from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError
import os

API_ID = 31781606  # coloque seu api_id aqui
API_HASH = "8c7d6f713ae32d19558381f5b8979e70"

SESSION_NAME = "kerygma_session"


async def conectar():
    client = TelegramClient(SESSION_NAME, API_ID, API_HASH)

    await client.start()

    print("✅ Conectado com sucesso!")
    return client
