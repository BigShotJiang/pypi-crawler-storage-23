import sqlite3
from datetime import datetime
from platformdirs import user_data_dir
import os

APP_NAME = "kerygma"


# =========================
# CONFIGURAÇÃO DO BANCO
# =========================

def get_db_path():
    data_dir = user_data_dir(APP_NAME)
    os.makedirs(data_dir, exist_ok=True)
    return os.path.join(data_dir, "database.db")


def get_connection():
    return sqlite3.connect(get_db_path())


def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    # =========================
    # TABELA CATEGORIAS
    # =========================
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS categorias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT UNIQUE NOT NULL
        )
    """)

    # =========================
    # TABELA MENSAGENS
    # =========================
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS mensagens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            destinatario TEXT NOT NULL,
            mensagem TEXT NOT NULL,
            data_envio TEXT NOT NULL,
            categoria TEXT NOT NULL,
            status TEXT NOT NULL
        )
    """)

    # =========================
    # TABELA AGENDAMENTOS
    # =========================
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS agendamentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            destino TEXT NOT NULL,
            mensagem TEXT NOT NULL,
            data_hora TEXT NOT NULL,
            telegram_msg_id INTEGER,
            status TEXT NOT NULL
        )
    """)

    conn.commit()
    conn.close()


# =========================
# CATEGORIAS
# =========================

def adicionar_categoria(nome):
    conn = get_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("INSERT INTO categorias (nome) VALUES (?)", (nome,))
        conn.commit()
        print("Categoria criada com sucesso.")
    except sqlite3.IntegrityError:
        print("Categoria já existe.")

    conn.close()


def listar_categorias():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT id, nome FROM categorias ORDER BY nome")
    categorias = cursor.fetchall()

    conn.close()
    return categorias


# =========================
# MENSAGENS IMEDIATAS
# =========================

def adicionar_mensagem(destinatario, mensagem, data_envio, categoria):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO mensagens 
        (destinatario, mensagem, data_envio, categoria, status)
        VALUES (?, ?, ?, ?, ?)
    """, (destinatario, mensagem, data_envio, categoria, "pendente"))

    conn.commit()
    conn.close()


def listar_mensagens():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id, destinatario, mensagem, data_envio, categoria, status
        FROM mensagens
        ORDER BY data_envio
    """)

    mensagens = cursor.fetchall()
    conn.close()
    return mensagens


def listar_mensagens_pendentes():
    conn = get_connection()
    cursor = conn.cursor()

    agora = datetime.now().strftime("%Y-%m-%d %H:%M")

    cursor.execute("""
        SELECT id, destinatario, mensagem, data_envio, categoria
        FROM mensagens
        WHERE status = 'pendente'
        AND data_envio <= ?
        ORDER BY data_envio
    """, (agora,))

    mensagens = cursor.fetchall()
    conn.close()
    return mensagens


def marcar_como_enviado(mensagem_id):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        UPDATE mensagens
        SET status = 'enviado'
        WHERE id = ?
    """, (mensagem_id,))

    conn.commit()
    conn.close()


def excluir_mensagem(mensagem_id):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM mensagens WHERE id = ?", (mensagem_id,))
    conn.commit()
    conn.close()


# =========================
# AGENDAMENTOS
# =========================

def adicionar_agendamento(destino, mensagem, data_hora):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO agendamentos (destino, mensagem, data_hora, status)
        VALUES (?, ?, ?, ?)
    """, (destino, mensagem, data_hora, "pendente"))

    conn.commit()
    conn.close()


def listar_agendamentos():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id, destino, mensagem, data_hora, status
        FROM agendamentos
        ORDER BY data_hora
    """)

    resultados = cursor.fetchall()
    conn.close()
    return resultados


def listar_pendentes():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id, destino, mensagem, data_hora, status
        FROM agendamentos
        WHERE status = 'pendente'
        ORDER BY data_hora
    """)

    dados = cursor.fetchall()
    conn.close()
    return dados


def listar_historico(limite=10):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id, destino, mensagem, data_hora, status
        FROM agendamentos
        WHERE status = 'enviado'
        ORDER BY data_hora DESC
        LIMIT ?
    """, (limite,))

    dados = cursor.fetchall()
    conn.close()
    return dados


def excluir_agendamento(agendamento_id):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        "DELETE FROM agendamentos WHERE id = ?",
        (agendamento_id,)
    )

    conn.commit()
    conn.close()
