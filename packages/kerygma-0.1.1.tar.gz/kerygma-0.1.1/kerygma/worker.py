import asyncio
from kerygma.scheduler import verificar_e_enviar

async def main():
    while True:
        await verificar_e_enviar()
        await asyncio.sleep(30)  # verifica a cada 30 segundos

if __name__ == "__main__":
    asyncio.run(main())
