# Kerygma

CLI multiplataforma para envio e agendamento automatizado de mensagens via Telegram.

## Instalação

pip install kerygma

## Uso

kerygma
