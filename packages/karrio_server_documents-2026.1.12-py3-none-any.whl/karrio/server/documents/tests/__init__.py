import logging

logging.disable(logging.CRITICAL)

from karrio.server.documents.tests.test_templates import *
from karrio.server.documents.tests.test_generator import *
