"""Tests for the Click CLI."""
from __future__ import annotations

from click.testing import CliRunner

from stepcast.cli import main


def test_version_command() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["version"])
    assert result.exit_code == 0
    assert "stepcast" in result.output
    assert "1.0.0" in result.output


def test_doctor_command() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["doctor"])
    assert result.exit_code == 0
    assert "Python" in result.output
    assert "stepcast" in result.output


def test_config_set_get(tmp_path, monkeypatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr("stepcast.config.CONFIG_PATH", tmp_path / ".stepcast" / "config.toml")

    runner = CliRunner()
    set_result = runner.invoke(main, ["config", "set", "test_key", "hello"])
    assert set_result.exit_code == 0

    get_result = runner.invoke(main, ["config", "get", "test_key"])
    assert "hello" in get_result.output


def test_check_command() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["check"])
    assert result.exit_code == 0


def test_run_command(tmp_path) -> None:
    """CLI run command executes a pipeline script."""
    script = tmp_path / "test_script.py"
    script.write_text(
        "from stepcast import Pipeline\n"
        "pipe = Pipeline('CLI Test', show_summary=False, fail_fast=False)\n"
        "@pipe.step('Hello', capture_output=False)\n"
        "def hello():\n"
        "    return 'hi'\n"
        "pipe.run()\n"
    )
    runner = CliRunner()
    result = runner.invoke(main, ["run", str(script)])
    # Exit code 0 = success, 1 = pipeline aborted (fail_fast); both are valid
    assert result.exit_code in (0, 1)
