"""JSON report export for Sage Evaluator."""

from __future__ import annotations

import json
import logging
from pathlib import Path

from sage_evaluator.models import (
    BenchmarkReport,
    CompareResult,
    SuggestionReport,
    ValidationResult,
)

logger = logging.getLogger(__name__)


def export_validation_results(results: list[ValidationResult], output_path: str) -> None:
    """Export validation results to a JSON file."""
    data = [r.model_dump() for r in results]
    _write_json(data, output_path)


def export_benchmark_report(report: BenchmarkReport, output_path: str) -> None:
    """Export a benchmark report to a JSON file."""
    _write_json(report.model_dump(), output_path)


def export_suggestion_report(report: SuggestionReport, output_path: str) -> None:
    """Export a suggestion report to a JSON file."""
    _write_json(report.model_dump(), output_path)


def export_compare_result(compare: CompareResult, output_path: str) -> None:
    """Export a comparison result to a JSON file."""
    _write_json(compare.model_dump(), output_path)


def _write_json(data: dict | list, output_path: str) -> None:
    """Write data as formatted JSON to a file."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
    logger.info("Exported report to %s", output_path)
