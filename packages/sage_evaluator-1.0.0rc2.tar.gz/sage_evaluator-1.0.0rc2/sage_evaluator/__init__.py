"""Sage Evaluator - validate, benchmark, and optimize agent configurations."""

__version__ = "0.1.0"
