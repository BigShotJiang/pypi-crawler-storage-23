"""
The compileflags package defines the flags used by the compiler engine.

We centralize the definition of flags to avoid defining flags into each package
and ending up with incompatible compiler engine flags.

**End-user usage**

Set the ``DTMODEL_ENGINE_FLAGS`` environment variable to a comma-separated list
of flag names before starting Python.  For example::

    export DTMODEL_ENGINE_FLAGS=trace

Available flag names: ``trace``, ``dump``, ``break``.
"""

import os
from typing import Callable

TRACE = 1 << 0
"""Indicates that we should trace execution.

Specifically, tracing execution means printing the equivalent backend
code that is being executed in SSA form along with contextual info.

Note that this flag does not mix well with DUMP since both emit
valid Python code using the same names.
"""

BREAK = 1 << 1
"""Indicates that we should break execution after evaluation."""

DUMP = 1 << 2
"""Dump nodes in SSA format ahead of evaluation.

Note that this flag does not mix well with TRACE since both emit
valid Python code using the same names.
"""

_flagnames: dict[str, int] = {
    "break": BREAK,
    "dump": DUMP,
    "trace": TRACE,
}
"""Maps the lowercase name of the flag to its value."""


def from_environ(
    varname: str = "DTMODEL_ENGINE_FLAGS",
    getenv: Callable[[str], str | None] = os.getenv,
) -> int:
    """Read flags from a specific environment variable.

    The format for the flags is the following:

        <key>[,<key>,...]

    where <key> is the case-insensitive name of an existing flag.

    For example:

        export DTMODEL_ENGINE_FLAGS=trace,break

    causes this function to return:

        TRACE|BREAK

    Arguments
    ---------
    varname: the name of the environment variable (default: `DTMODEL_ENGINE_FLAGS`).
    getenv: the function to read the environment variable (default: os.getenv).
    """
    flags: int = 0
    for value in (getenv(varname) or "").split(","):
        flags |= _flagnames.get(value.strip().lower(), 0)
    return flags


defaults = from_environ()
"""Default compile flags initialized from the ``DTMODEL_ENGINE_FLAGS`` environment variable.

Read once at import time — the env var must be set *before* importing any engine
module; changes to the environment after import have no effect on this value.
"""
