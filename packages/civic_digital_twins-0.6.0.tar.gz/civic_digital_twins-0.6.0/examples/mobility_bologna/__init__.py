"""Bologna mobility example."""

# SPDX-License-Identifier: Apache-2.0
