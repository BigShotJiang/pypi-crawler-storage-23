"""Tests for the example models."""
