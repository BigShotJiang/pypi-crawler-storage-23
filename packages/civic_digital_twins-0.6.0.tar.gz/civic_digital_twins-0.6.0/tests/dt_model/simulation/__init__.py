"""Tests for the simulation layer."""
