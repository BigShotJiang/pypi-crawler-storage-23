"""Tests for the civic_digital_twins.dt_model.model package."""

# SPDX-License-Identifier: Apache-2.0
