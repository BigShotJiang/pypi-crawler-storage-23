# Rebasing the Experimental JIT Branch (`issues/54`)

## Context

`issues/54` diverged from `main` before the `feat/engine-cleanup` work and
has not been updated.  It contains the Numba JIT compiler (`jit.py`) built
on top of `forest`/`ir`.  It must be rebased onto the current `main` before
JIT work can continue.

## Known conflicts to resolve during rebase

- **`jit.py` rename → `numpy_ast.py`** — `issues/54` still has `jit.py`; the
  rebase must preserve the Numba-specific additions (`compile_function`,
  `call_function`, `forest_tree_to_ast_function_def`) on top of the renamed
  and updated `numpy_ast.py`.
- **`graph.function` → `graph.function_call`** — `issues/54` uses the old
  alias throughout; update all call sites in `jit.py`, `executor.py`, and
  tests.
- **`executor.py`** — re-add `forest`/`ir` imports and
  `evaluate_dag`/`evaluate_trees`/`evaluate_single_tree` on top of the
  cleaned-up executor; reconcile with timeseries and `negate` additions.
- **`keepdims`** — `issues/54` does not have the `keepdims=True` change;
  update `_reduce_sum`/`_reduce_mean` and remove the `keepdims` parameter
  from node construction.
- **`graph.py`** — apply timeseries (`timeseries_constant`,
  `timeseries_placeholder`), `negate`, and `piecewise` additions; remove
  `reduce_sum`/`reduce_mean`/`function` aliases.
- **Tests** — `test_forest.py` and `test_ir.py` were removed from `main`;
  keep them on `issues/54`.  Update `test_jit.py` → `test_numpy_ast.py` (or
  keep as `test_jit.py` if the file is renamed back; decision TBD).

## Action items

- [ ] Rebase `issues/54` onto `main`; resolve the conflicts listed above.
- [ ] Verify all existing `issues/54` tests pass after rebase.
- [ ] Update `numpy_ast.py` on the rebased branch to re-add `forest`/`ir`
  support (Numba JIT functions) as a separate layer on top of the node-level
  AST generation.
- [ ] Add `examples/jit.py` (present on `issues/54`) to the rebased branch
  after updating its imports.
