"""Tests for the state management module."""

import re
import shutil

import pytest

from gsd_lean.state.planning import (
    CYCLE_ARCHIVE_DIR,
    CYCLE_DIR,
    CYCLE_FILES,
    PLANNING_DIR,
    STATIC_FILES,
    PlanTask,
    _is_v1_layout,
    _reset_state_phase,
    _split_decisions,
    get_in_progress_task,
    get_next_pending_task,
    get_plan_status,
    init_planning,
    migrate_v1_to_v2,
    parse_plan_tasks,
    read_plan,
    read_state,
    reset_cycle,
    update_plan_status,
    update_task_status,
    write_state,
)


class TestInitPlanning:
    """Tests for init_planning function."""

    def test_creates_planning_directory(self, tmp_path):
        """Test that init creates the .planning/ directory."""
        init_planning(tmp_path)
        assert (tmp_path / PLANNING_DIR).is_dir()

    def test_creates_cycle_directory(self, tmp_path):
        """Test that init creates the .planning/cycle/ directory."""
        init_planning(tmp_path)
        assert (tmp_path / PLANNING_DIR / CYCLE_DIR).is_dir()

    def test_creates_all_files(self, tmp_path):
        """Test that init creates all 7 planning files (5 static + 2 cycle)."""
        created = init_planning(tmp_path)
        assert len(created) == 7
        for filename in STATIC_FILES:
            assert (tmp_path / PLANNING_DIR / filename).exists()
        for filename in CYCLE_FILES:
            assert (tmp_path / PLANNING_DIR / CYCLE_DIR / filename).exists()

    def test_static_file_contents_match_templates(self, tmp_path):
        """Test that static files contain the expected template content."""
        init_planning(tmp_path)
        for filename, expected_content in STATIC_FILES.items():
            actual = (tmp_path / PLANNING_DIR / filename).read_text()
            assert actual == expected_content

    def test_cycle_file_contents_match_templates(self, tmp_path):
        """Test that cycle files contain the expected template content."""
        init_planning(tmp_path)
        for filename, expected_content in CYCLE_FILES.items():
            actual = (tmp_path / PLANNING_DIR / CYCLE_DIR / filename).read_text()
            assert actual == expected_content

    def test_returns_created_paths(self, tmp_path):
        """Test that init returns the list of created file paths."""
        created = init_planning(tmp_path)
        filenames = {p.name for p in created}
        expected = set(STATIC_FILES.keys()) | set(CYCLE_FILES.keys())
        assert filenames == expected

    def test_raises_if_all_files_exist(self, tmp_path):
        """Test that init raises FileExistsError when all files already exist."""
        init_planning(tmp_path)
        with pytest.raises(FileExistsError, match='already exists'):
            init_planning(tmp_path)

    def test_skips_existing_creates_missing(self, tmp_path):
        """Test that init only creates missing files, skipping existing ones."""
        init_planning(tmp_path)

        # Remove one file
        (tmp_path / PLANNING_DIR / 'STATE.md').unlink()

        # Re-init without force should create only the missing file
        created = init_planning(tmp_path)
        assert len(created) == 1
        assert created[0].name == 'STATE.md'

    def test_force_overwrites_existing(self, tmp_path):
        """Test that --force overwrites all files."""
        init_planning(tmp_path)

        # Modify a file
        state_file = tmp_path / PLANNING_DIR / 'STATE.md'
        state_file.write_text('modified content')

        # Force re-init should overwrite
        created = init_planning(tmp_path, force=True)
        assert len(created) == 7
        assert state_file.read_text() == STATIC_FILES['STATE.md']

    def test_state_md_has_discuss_phase(self, tmp_path):
        """Test that STATE.md defaults to discuss phase."""
        init_planning(tmp_path)
        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert '`discuss`' in content

    def test_creates_gitignore(self, tmp_path):
        """Test that .planning/.gitignore is created."""
        init_planning(tmp_path)
        assert (tmp_path / PLANNING_DIR / '.gitignore').exists()

    def test_gitignore_ignores_ephemeral(self, tmp_path):
        """Test that .gitignore ignores cycle/, cycle-archive/, and STATE.md."""
        init_planning(tmp_path)
        content = (tmp_path / PLANNING_DIR / '.gitignore').read_text()
        assert 'cycle/' in content
        assert 'cycle-archive/' in content
        assert 'STATE.md' in content
        # Static docs should NOT be ignored
        assert 'PROJECT.md' not in content
        assert 'CONTEXT.md' not in content
        assert 'config.yaml' not in content

    def test_no_roadmap_created(self, tmp_path):
        """Test that ROADMAP.md is not created."""
        init_planning(tmp_path)
        assert not (tmp_path / PLANNING_DIR / 'ROADMAP.md').exists()

    def test_context_md_created(self, tmp_path):
        """Test that CONTEXT.md is created with Architecture/Tooling/Skills sections."""
        init_planning(tmp_path)
        content = (tmp_path / PLANNING_DIR / 'CONTEXT.md').read_text()
        assert '## Architecture' in content
        assert '## Tooling' in content
        assert '## Skills' in content

    def test_decisions_md_in_cycle(self, tmp_path):
        """Test that DECISIONS.md is in cycle/ with reduced scope."""
        init_planning(tmp_path)
        content = (tmp_path / PLANNING_DIR / CYCLE_DIR / 'DECISIONS.md').read_text()
        assert '## Style & Preferences' in content
        assert '## Constraints' in content
        assert '## Dependencies' in content
        # Architecture/Tooling/Skills moved to CONTEXT.md
        assert '## Architecture' not in content
        assert '## Tooling' not in content
        assert '## Skills' not in content


class TestResetCycle:
    """Tests for reset_cycle function."""

    def test_archives_and_scaffolds(self, tmp_path):
        """Test that reset_cycle archives old cycle/ and creates fresh templates."""
        init_planning(tmp_path)
        cycle_dir = tmp_path / PLANNING_DIR / CYCLE_DIR

        # Write some content to cycle files to simulate a completed cycle
        (cycle_dir / 'REQUIREMENTS.md').write_text('# Filled requirements')
        (cycle_dir / 'PLAN.md').write_text('# Filled plan')

        created = reset_cycle(tmp_path)

        # Fresh templates created
        assert len(created) == len(CYCLE_FILES)
        for filename, template in CYCLE_FILES.items():
            assert (cycle_dir / filename).read_text() == template

        # Archive created with old files
        archive_base = tmp_path / PLANNING_DIR / CYCLE_ARCHIVE_DIR
        assert archive_base.exists()
        archive_dirs = list(archive_base.iterdir())
        assert len(archive_dirs) == 1
        archived_files = {f.name for f in archive_dirs[0].iterdir()}
        assert 'REQUIREMENTS.md' in archived_files
        assert 'PLAN.md' in archived_files

    def test_no_archive_flag(self, tmp_path):
        """Test that archive=False deletes cycle files without archiving."""
        init_planning(tmp_path)
        cycle_dir = tmp_path / PLANNING_DIR / CYCLE_DIR
        (cycle_dir / 'PLAN.md').write_text('# Plan content')

        reset_cycle(tmp_path, archive=False)

        # No archive created
        assert not (tmp_path / PLANNING_DIR / CYCLE_ARCHIVE_DIR).exists()
        # Fresh templates still created
        for filename, template in CYCLE_FILES.items():
            assert (cycle_dir / filename).read_text() == template

    def test_empty_cycle_dir(self, tmp_path):
        """Test that reset_cycle handles empty cycle/ without error."""
        init_planning(tmp_path)
        cycle_dir = tmp_path / PLANNING_DIR / CYCLE_DIR

        # Remove all files from cycle/
        for f in cycle_dir.iterdir():
            f.unlink()

        created = reset_cycle(tmp_path)

        # No archive created (nothing to archive)
        assert not (tmp_path / PLANNING_DIR / CYCLE_ARCHIVE_DIR).exists()
        # Templates created
        assert len(created) == len(CYCLE_FILES)

    def test_no_cycle_dir(self, tmp_path):
        """Test that reset_cycle creates cycle/ if it doesn't exist."""
        init_planning(tmp_path)
        shutil.rmtree(tmp_path / PLANNING_DIR / CYCLE_DIR)

        created = reset_cycle(tmp_path)
        assert len(created) == len(CYCLE_FILES)
        assert (tmp_path / PLANNING_DIR / CYCLE_DIR).is_dir()

    def test_raises_if_no_planning_dir(self, tmp_path):
        """Test that reset_cycle raises FileNotFoundError if .planning/ doesn't exist."""
        with pytest.raises(FileNotFoundError, match='not found'):
            reset_cycle(tmp_path)

    def test_preserves_static_files(self, tmp_path):
        """Test that reset_cycle does not touch static files."""
        init_planning(tmp_path)
        project_md = tmp_path / PLANNING_DIR / 'PROJECT.md'
        project_md.write_text('# Custom project info')

        reset_cycle(tmp_path)

        assert project_md.read_text() == '# Custom project info'

    def test_preserves_history(self, tmp_path):
        """Test that reset_cycle preserves STATE.md history rows."""
        init_planning(tmp_path)
        write_state(tmp_path, 'plan', note='Started planning')
        write_state(tmp_path, 'execute', note='Executing')

        reset_cycle(tmp_path)

        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert '`discuss`' in content
        assert 'Started planning' in content
        assert 'Executing' in content

    def test_resets_phase_to_discuss(self, tmp_path):
        """Test that reset_cycle resets STATE.md phase to discuss."""
        init_planning(tmp_path)
        write_state(tmp_path, 'complete', note='Done')

        reset_cycle(tmp_path)

        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert '`discuss`' in content
        assert '`complete`' not in content


class TestResetStatePhase:
    """Tests for _reset_state_phase function."""

    def test_resets_phase_to_discuss(self, tmp_path):
        """Test that _reset_state_phase resets phase to discuss."""
        init_planning(tmp_path)
        write_state(tmp_path, 'execute')

        _reset_state_phase(tmp_path)

        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert '`discuss`' in content
        assert '`execute`' not in content

    def test_resets_active_task(self, tmp_path):
        """Test that _reset_state_phase clears active task to (none)."""
        init_planning(tmp_path)
        state_file = tmp_path / PLANNING_DIR / 'STATE.md'
        content = state_file.read_text()
        content = content.replace('(none)\n\n## Blockers', 'T-003: Build feature\n\n## Blockers')
        state_file.write_text(content)

        _reset_state_phase(tmp_path)

        content = state_file.read_text()
        assert '(none)' in content.split('## Active Task')[1].split('## Blockers')[0]

    def test_preserves_history_rows(self, tmp_path):
        """Test that _reset_state_phase preserves history table rows."""
        init_planning(tmp_path)
        write_state(tmp_path, 'plan', note='Planning phase')
        write_state(tmp_path, 'execute', note='Executing tasks')

        _reset_state_phase(tmp_path)

        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert 'Planning phase' in content
        assert 'Executing tasks' in content

    def test_noop_if_no_state_file(self, tmp_path):
        """Test that _reset_state_phase does nothing if STATE.md doesn't exist."""
        (tmp_path / PLANNING_DIR).mkdir(parents=True)
        # Should not raise
        _reset_state_phase(tmp_path)


class TestReadState:
    """Tests for read_state function."""

    def test_reads_state_content(self, tmp_path):
        """Test that read_state returns STATE.md contents."""
        init_planning(tmp_path)
        content = read_state(tmp_path)
        assert '# Workflow State' in content
        assert '`discuss`' in content

    def test_raises_if_not_initialized(self, tmp_path):
        """Test that read_state raises FileNotFoundError when not initialized."""
        with pytest.raises(FileNotFoundError, match='not found'):
            read_state(tmp_path)


class TestWriteState:
    """Tests for write_state function."""

    def test_updates_phase(self, tmp_path):
        """Test that write_state changes the phase line from discuss to plan."""
        init_planning(tmp_path)
        write_state(tmp_path, 'plan')
        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert '`plan`' in content
        assert '`discuss`' not in content

    def test_appends_history_row(self, tmp_path):
        """Test that write_state appends a new row with ISO timestamp to the history table."""
        init_planning(tmp_path)
        write_state(tmp_path, 'plan', note='Starting planning')
        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert '| plan | Starting planning |' in content
        # Check ISO 8601 timestamp format
        assert re.search(r'\| \d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z \|', content)

    def test_preserves_other_content(self, tmp_path):
        """Test that write_state preserves Active Task, Blockers, and other sections."""
        init_planning(tmp_path)
        write_state(tmp_path, 'plan')
        content = (tmp_path / PLANNING_DIR / 'STATE.md').read_text()
        assert '## Active Task' in content
        assert '## Blockers' in content
        assert '## History' in content
        assert '# Workflow State' in content

    def test_invalid_phase(self, tmp_path):
        """Test that write_state raises ValueError for invalid phase name."""
        init_planning(tmp_path)
        with pytest.raises(ValueError, match='Invalid phase'):
            write_state(tmp_path, 'invalid')

    def test_missing_file(self, tmp_path):
        """Test that write_state raises FileNotFoundError if STATE.md is absent."""
        with pytest.raises(FileNotFoundError, match='not found'):
            write_state(tmp_path, 'plan')

    def test_broken_format(self, tmp_path):
        """Test that write_state raises ValueError if STATE.md has unexpected format."""
        init_planning(tmp_path)
        state_file = tmp_path / PLANNING_DIR / 'STATE.md'
        state_file.write_text('# Completely different content\n')
        with pytest.raises(ValueError, match='unexpected format'):
            write_state(tmp_path, 'plan')


class TestReadPlan:
    """Tests for read_plan function."""

    def test_reads_plan_content(self, tmp_path):
        """Test that read_plan returns PLAN.md contents from cycle/ directory."""
        init_planning(tmp_path)
        plan_file = tmp_path / PLANNING_DIR / CYCLE_DIR / 'PLAN.md'
        plan_file.write_text('# Plan\n\n> **Status:** draft\n')
        content = read_plan(tmp_path)
        assert '# Plan' in content

    def test_raises_if_missing(self, tmp_path):
        """Test that read_plan raises FileNotFoundError when PLAN.md does not exist."""
        init_planning(tmp_path)
        with pytest.raises(FileNotFoundError, match='PLAN.md not found'):
            read_plan(tmp_path)


SAMPLE_PLAN = """\
# Plan

> **Status:** verified
> **Created:** 2026-02-01T14:30:00Z
> **Waves:** 2
> **Source:** REQUIREMENTS.md

## Tasks

| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|
| T-001 | 1 | done | Create workflow module | `src/workflow.py` | unit tests pass |
| T-002 | 1 | in-progress | Add state functions | `src/state.py` | unit tests pass |
| T-003 | 2 | pending | Add CLI commands | `src/cli.py` | CLI tests pass |

## Task Details

### T-001: Create workflow module
...
"""


class TestParsePlanTasks:
    """Tests for parse_plan_tasks function."""

    def test_happy_path(self, tmp_path):
        """Test that parse_plan_tasks parses a valid table into PlanTask list."""
        tasks = parse_plan_tasks(SAMPLE_PLAN)
        assert len(tasks) == 3
        assert tasks[0] == PlanTask(
            id='T-001',
            wave=1,
            status='done',
            title='Create workflow module',
            files='`src/workflow.py`',
            verification='unit tests pass',
        )
        assert tasks[1].status == 'in-progress'
        assert tasks[2].id == 'T-003'
        assert tasks[2].wave == 2

    def test_empty(self):
        """Test that parse_plan_tasks returns empty list when no tasks are found."""
        content = '# Plan\n\n> **Status:** draft\n\n## Tasks\n\n| ID | Wave | ... |\n|----|------|\n'
        tasks = parse_plan_tasks(content)
        assert tasks == []

    def test_malformed_row(self):
        """Test that parse_plan_tasks skips malformed rows and parses valid ones."""
        content = """\
| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|
| T-001 | 1 | done | Good task | `file.py` | tests pass |
| broken row with missing columns |
| T-002 | abc | done | Bad wave | `file.py` | tests pass |
| T-003 | 2 | invalid_status | Bad status | `file.py` | tests pass |
| T-004 | 2 | pending | Also good | `file2.py` | lint pass |
"""
        tasks = parse_plan_tasks(content)
        assert len(tasks) == 2
        assert tasks[0].id == 'T-001'
        assert tasks[1].id == 'T-004'


class TestGetPlanStatus:
    """Tests for get_plan_status function."""

    def test_extracts_verified(self):
        """Test that get_plan_status extracts 'verified' from header."""
        assert get_plan_status(SAMPLE_PLAN) == 'verified'

    def test_extracts_draft(self):
        """Test that get_plan_status extracts 'draft' from header."""
        content = '# Plan\n\n> **Status:** draft\n'
        assert get_plan_status(content) == 'draft'

    def test_missing_header(self):
        """Test that get_plan_status raises ValueError when Status header is missing."""
        with pytest.raises(ValueError, match='missing the Status header'):
            get_plan_status('# Plan\n\nNo status here.\n')

    def test_invalid_status_value(self):
        """Test that get_plan_status raises ValueError for invalid status values."""
        with pytest.raises(ValueError, match='Invalid plan status'):
            get_plan_status('> **Status:** unknown\n')


def _write_plan(tmp_path, content=SAMPLE_PLAN):
    """Helper to write PLAN.md to cycle/ directory for tests."""
    cycle_dir = tmp_path / PLANNING_DIR / CYCLE_DIR
    cycle_dir.mkdir(parents=True, exist_ok=True)
    plan_file = cycle_dir / 'PLAN.md'
    plan_file.write_text(content)
    return plan_file


class TestUpdateTaskStatus:
    """Tests for update_task_status function."""

    def test_happy_path_pending_to_in_progress(self, tmp_path):
        """Test that update_task_status changes pending to in-progress."""
        _write_plan(tmp_path)
        update_task_status(tmp_path, 'T-003', 'in-progress')
        content = (tmp_path / PLANNING_DIR / CYCLE_DIR / 'PLAN.md').read_text()
        tasks = parse_plan_tasks(content)
        t003 = [t for t in tasks if t.id == 'T-003'][0]
        assert t003.status == 'in-progress'

    def test_in_progress_to_done(self, tmp_path):
        """Test that update_task_status changes in-progress to done."""
        _write_plan(tmp_path)
        update_task_status(tmp_path, 'T-002', 'done')
        content = (tmp_path / PLANNING_DIR / CYCLE_DIR / 'PLAN.md').read_text()
        tasks = parse_plan_tasks(content)
        t002 = [t for t in tasks if t.id == 'T-002'][0]
        assert t002.status == 'done'

    def test_invalid_status(self, tmp_path):
        """Test that update_task_status raises ValueError for invalid status."""
        _write_plan(tmp_path)
        with pytest.raises(ValueError, match='Invalid task status'):
            update_task_status(tmp_path, 'T-001', 'invalid')

    def test_task_not_found(self, tmp_path):
        """Test that update_task_status raises ValueError when task ID not found."""
        _write_plan(tmp_path)
        with pytest.raises(ValueError, match='T-999 not found'):
            update_task_status(tmp_path, 'T-999', 'done')

    def test_missing_plan(self, tmp_path):
        """Test that update_task_status raises FileNotFoundError when PLAN.md missing."""
        with pytest.raises(FileNotFoundError, match='PLAN.md not found'):
            update_task_status(tmp_path, 'T-001', 'done')

    def test_preserves_other_tasks(self, tmp_path):
        """Test that update_task_status only modifies the target task row."""
        _write_plan(tmp_path)
        update_task_status(tmp_path, 'T-003', 'in-progress')
        content = (tmp_path / PLANNING_DIR / CYCLE_DIR / 'PLAN.md').read_text()
        tasks = parse_plan_tasks(content)
        assert tasks[0].status == 'done'  # T-001 unchanged
        assert tasks[1].status == 'in-progress'  # T-002 unchanged
        assert tasks[2].status == 'in-progress'  # T-003 changed


class TestGetNextPendingTask:
    """Tests for get_next_pending_task function."""

    def test_happy_path(self, tmp_path):
        """Test that get_next_pending_task returns first pending task by wave order."""
        _write_plan(tmp_path)
        task = get_next_pending_task(tmp_path)
        assert task is not None
        assert task.id == 'T-003'
        assert task.status == 'pending'

    def test_skips_done_and_in_progress(self, tmp_path):
        """Test that get_next_pending_task skips done and in-progress tasks."""
        _write_plan(tmp_path)
        task = get_next_pending_task(tmp_path)
        assert task is not None
        assert task.id == 'T-003'  # Skips T-001 (done) and T-002 (in-progress)

    def test_none_when_all_done(self, tmp_path):
        """Test that get_next_pending_task returns None when no pending tasks."""
        plan = SAMPLE_PLAN.replace('| pending |', '| done |')
        _write_plan(tmp_path, plan)
        task = get_next_pending_task(tmp_path)
        assert task is None

    def test_missing_plan(self, tmp_path):
        """Test that get_next_pending_task raises FileNotFoundError when PLAN.md missing."""
        with pytest.raises(FileNotFoundError, match='PLAN.md not found'):
            get_next_pending_task(tmp_path)


class TestGetInProgressTask:
    """Tests for get_in_progress_task function."""

    def test_found(self, tmp_path):
        """Test that get_in_progress_task returns the in-progress task."""
        _write_plan(tmp_path)
        task = get_in_progress_task(tmp_path)
        assert task is not None
        assert task.id == 'T-002'
        assert task.status == 'in-progress'

    def test_none_when_no_in_progress(self, tmp_path):
        """Test that get_in_progress_task returns None when no task is in-progress."""
        plan = SAMPLE_PLAN.replace('| in-progress |', '| done |')
        _write_plan(tmp_path, plan)
        task = get_in_progress_task(tmp_path)
        assert task is None

    def test_missing_plan(self, tmp_path):
        """Test that get_in_progress_task raises FileNotFoundError when PLAN.md missing."""
        with pytest.raises(FileNotFoundError, match='PLAN.md not found'):
            get_in_progress_task(tmp_path)


class TestUpdatePlanStatus:
    """Tests for update_plan_status function."""

    def test_verified_to_in_progress(self, tmp_path):
        """Test that update_plan_status changes verified to in-progress."""
        _write_plan(tmp_path)
        update_plan_status(tmp_path, 'in-progress')
        content = (tmp_path / PLANNING_DIR / CYCLE_DIR / 'PLAN.md').read_text()
        assert get_plan_status(content) == 'in-progress'

    def test_in_progress_to_complete(self, tmp_path):
        """Test that update_plan_status changes in-progress to complete."""
        plan = SAMPLE_PLAN.replace('**Status:** verified', '**Status:** in-progress')
        _write_plan(tmp_path, plan)
        update_plan_status(tmp_path, 'complete')
        content = (tmp_path / PLANNING_DIR / CYCLE_DIR / 'PLAN.md').read_text()
        assert get_plan_status(content) == 'complete'

    def test_invalid_status(self, tmp_path):
        """Test that update_plan_status raises ValueError for invalid status."""
        _write_plan(tmp_path)
        with pytest.raises(ValueError, match='Invalid plan status'):
            update_plan_status(tmp_path, 'invalid')

    def test_missing_plan(self, tmp_path):
        """Test that update_plan_status raises FileNotFoundError when PLAN.md missing."""
        with pytest.raises(FileNotFoundError, match='PLAN.md not found'):
            update_plan_status(tmp_path, 'in-progress')

    def test_missing_status_header(self, tmp_path):
        """Test that update_plan_status raises ValueError when Status header is missing."""
        _write_plan(tmp_path, '# Plan\n\nNo status header here.\n')
        with pytest.raises(ValueError, match='missing the Status header'):
            update_plan_status(tmp_path, 'in-progress')


# Old v1 DECISIONS.md template (flat layout, pre-refactor)
V1_DECISIONS_MD = """\
# Decisions

> Key decisions, preferences, and constraints captured during discussion.

## Architecture

- Microservices with REST API

## Style & Preferences

- Use single quotes

## Constraints

- Must run on Python 3.12+

## Dependencies

- httpx for HTTP calls

## Tooling

- **MCP servers:** context7

## Skills

- Custom deploy skill
"""

V1_DECISIONS_MD_TEMPLATE = """\
# Decisions

> Key decisions, preferences, and constraints captured during discussion.

## Architecture

- (none yet)

## Style & Preferences

- (none yet)

## Constraints

- (none yet)

## Dependencies

- (none yet)

## Tooling

- (none yet)

## Skills

- (none yet)
"""


def _setup_v1_layout(tmp_path):
    """Create a v1 .planning/ layout for migration tests."""
    planning_dir = tmp_path / PLANNING_DIR
    planning_dir.mkdir(parents=True)
    (planning_dir / 'PROJECT.md').write_text('# Project Overview\n')
    (planning_dir / 'REQUIREMENTS.md').write_text('# Requirements\n\n## User Intent\n\nBuild a widget\n')
    (planning_dir / 'DECISIONS.md').write_text(V1_DECISIONS_MD)
    (planning_dir / 'ROADMAP.md').write_text('# Roadmap\n')
    (planning_dir / 'STATE.md').write_text(STATIC_FILES['STATE.md'])
    (planning_dir / '.gitignore').write_text('*\n')
    (planning_dir / 'config.yaml').write_text('defaults:\n  max_turns: 25\n')
    return planning_dir


class TestIsV1Layout:
    """Tests for _is_v1_layout detection."""

    def test_detects_v1_layout(self, tmp_path):
        """Test that v1 layout is correctly identified."""
        _setup_v1_layout(tmp_path)
        assert _is_v1_layout(tmp_path) is True

    def test_v2_layout_returns_false(self, tmp_path):
        """Test that v2 layout (with cycle/) returns False."""
        init_planning(tmp_path)
        assert _is_v1_layout(tmp_path) is False

    def test_no_planning_dir_returns_false(self, tmp_path):
        """Test that missing .planning/ returns False."""
        assert _is_v1_layout(tmp_path) is False

    def test_empty_planning_dir_returns_false(self, tmp_path):
        """Test that empty .planning/ returns False."""
        (tmp_path / PLANNING_DIR).mkdir()
        assert _is_v1_layout(tmp_path) is False


class TestMigrateV1ToV2:
    """Tests for migrate_v1_to_v2 function."""

    def test_full_migration(self, tmp_path):
        """Test complete migration: moves files, splits DECISIONS, deletes ROADMAP."""
        _setup_v1_layout(tmp_path)
        planning_dir = tmp_path / PLANNING_DIR

        result = migrate_v1_to_v2(tmp_path)

        assert result is True
        cycle_dir = planning_dir / CYCLE_DIR

        # REQUIREMENTS.md moved to cycle/
        assert not (planning_dir / 'REQUIREMENTS.md').exists()
        assert (cycle_dir / 'REQUIREMENTS.md').exists()
        assert 'Build a widget' in (cycle_dir / 'REQUIREMENTS.md').read_text()

        # DECISIONS.md split: old one deleted, CONTEXT.md + cycle/DECISIONS.md created
        assert not (planning_dir / 'DECISIONS.md').exists()
        assert (planning_dir / 'CONTEXT.md').exists()
        assert (cycle_dir / 'DECISIONS.md').exists()

        # CONTEXT.md has static sections
        context_content = (planning_dir / 'CONTEXT.md').read_text()
        assert '## Architecture' in context_content
        assert '## Tooling' in context_content
        assert '## Skills' in context_content
        assert 'Microservices' in context_content

        # cycle/DECISIONS.md has ephemeral sections
        decisions_content = (cycle_dir / 'DECISIONS.md').read_text()
        assert '## Style & Preferences' in decisions_content
        assert '## Constraints' in decisions_content
        assert '## Dependencies' in decisions_content
        assert 'single quotes' in decisions_content
        # Static sections NOT in cycle DECISIONS.md
        assert '## Architecture' not in decisions_content
        assert '## Tooling' not in decisions_content
        assert '## Skills' not in decisions_content

        # ROADMAP.md deleted
        assert not (planning_dir / 'ROADMAP.md').exists()

        # .gitignore updated
        gitignore = (planning_dir / '.gitignore').read_text()
        assert 'cycle/' in gitignore
        assert 'cycle-archive/' in gitignore

        # PROJECT.md preserved (not modified by migration)
        assert (planning_dir / 'PROJECT.md').read_text() == '# Project Overview\n'

    def test_already_v2_returns_false(self, tmp_path):
        """Test that migration returns False if already v2 layout."""
        init_planning(tmp_path)
        assert migrate_v1_to_v2(tmp_path) is False

    def test_no_planning_dir_returns_false(self, tmp_path):
        """Test that migration returns False if no .planning/ exists."""
        assert migrate_v1_to_v2(tmp_path) is False

    def test_migration_without_decisions_md(self, tmp_path):
        """Test migration when DECISIONS.md is missing."""
        _setup_v1_layout(tmp_path)
        planning_dir = tmp_path / PLANNING_DIR
        (planning_dir / 'DECISIONS.md').unlink()

        result = migrate_v1_to_v2(tmp_path)

        assert result is True
        # Fresh templates created
        assert (planning_dir / 'CONTEXT.md').exists()
        assert (planning_dir / CYCLE_DIR / 'DECISIONS.md').exists()

    def test_migration_without_plan_md(self, tmp_path):
        """Test migration when PLAN.md doesn't exist (no /plan run yet)."""
        _setup_v1_layout(tmp_path)
        planning_dir = tmp_path / PLANNING_DIR

        result = migrate_v1_to_v2(tmp_path)

        assert result is True
        # PLAN.md not present in cycle/ either
        assert not (planning_dir / CYCLE_DIR / 'PLAN.md').exists()

    def test_migration_with_plan_md(self, tmp_path):
        """Test migration moves PLAN.md to cycle/."""
        _setup_v1_layout(tmp_path)
        planning_dir = tmp_path / PLANNING_DIR
        (planning_dir / 'PLAN.md').write_text('# Plan\n\n> **Status:** verified\n')

        result = migrate_v1_to_v2(tmp_path)

        assert result is True
        assert not (planning_dir / 'PLAN.md').exists()
        assert (planning_dir / CYCLE_DIR / 'PLAN.md').exists()
        assert 'verified' in (planning_dir / CYCLE_DIR / 'PLAN.md').read_text()

    def test_migration_without_roadmap(self, tmp_path):
        """Test migration when ROADMAP.md is already missing."""
        _setup_v1_layout(tmp_path)
        (tmp_path / PLANNING_DIR / 'ROADMAP.md').unlink()

        result = migrate_v1_to_v2(tmp_path)

        assert result is True  # migration still proceeds


class TestSplitDecisions:
    """Tests for _split_decisions function."""

    def test_splits_populated_decisions(self, tmp_path):
        """Test splitting a fully populated DECISIONS.md."""
        static_dir = tmp_path / 'static'
        cycle_dir = tmp_path / 'cycle'
        static_dir.mkdir()
        cycle_dir.mkdir()

        _split_decisions(V1_DECISIONS_MD, static_dir, cycle_dir)

        # CONTEXT.md created with static sections
        context = (static_dir / 'CONTEXT.md').read_text()
        assert '## Architecture' in context
        assert 'Microservices' in context
        assert '## Tooling' in context
        assert 'context7' in context
        assert '## Skills' in context
        assert 'deploy skill' in context

        # cycle/DECISIONS.md created with ephemeral sections
        decisions = (cycle_dir / 'DECISIONS.md').read_text()
        assert '## Style & Preferences' in decisions
        assert 'single quotes' in decisions
        assert '## Constraints' in decisions
        assert 'Python 3.12' in decisions
        assert '## Dependencies' in decisions
        assert 'httpx' in decisions

    def test_splits_template_decisions(self, tmp_path):
        """Test splitting DECISIONS.md with only placeholder content."""
        static_dir = tmp_path / 'static'
        cycle_dir = tmp_path / 'cycle'
        static_dir.mkdir()
        cycle_dir.mkdir()

        _split_decisions(V1_DECISIONS_MD_TEMPLATE, static_dir, cycle_dir)

        context = (static_dir / 'CONTEXT.md').read_text()
        assert '## Architecture' in context
        assert '(none yet)' in context

        decisions = (cycle_dir / 'DECISIONS.md').read_text()
        assert '## Style & Preferences' in decisions

    def test_does_not_overwrite_existing_context_md(self, tmp_path):
        """Test that _split_decisions does not overwrite existing CONTEXT.md."""
        static_dir = tmp_path / 'static'
        cycle_dir = tmp_path / 'cycle'
        static_dir.mkdir()
        cycle_dir.mkdir()
        (static_dir / 'CONTEXT.md').write_text('# Existing context\n')

        _split_decisions(V1_DECISIONS_MD, static_dir, cycle_dir)

        # CONTEXT.md not overwritten
        assert (static_dir / 'CONTEXT.md').read_text() == '# Existing context\n'
        # cycle/DECISIONS.md still created
        assert (cycle_dir / 'DECISIONS.md').exists()


class TestInitPlanningAutoMigrate:
    """Tests for auto-migration in init_planning."""

    def test_auto_migrates_v1_layout(self, tmp_path):
        """Test that init_planning auto-migrates v1 layout."""
        _setup_v1_layout(tmp_path)
        planning_dir = tmp_path / PLANNING_DIR

        result = init_planning(tmp_path)

        # Signal that migration happened
        assert result == [planning_dir]
        # v2 structure now in place
        assert (planning_dir / CYCLE_DIR).exists()
        assert not (planning_dir / 'REQUIREMENTS.md').exists()
