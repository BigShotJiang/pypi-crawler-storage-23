"""Workflow engine for phase transitions in the GSD-Lean development cycle."""

import re
from collections.abc import Callable, Sequence
from pathlib import Path

from gsd_lean.git import get_current_branch, get_default_branch
from gsd_lean.state.planning import (
    CYCLE_DIR,
    PHASES,
    PLANNING_DIR,
    get_plan_status,
    parse_plan_tasks,
    read_plan,
    read_state,
    reset_cycle,
    write_state,
)

VALID_TRANSITIONS: dict[str, list[str]] = {
    'discuss': ['discuss', 'plan'],
    'plan': ['plan', 'execute', 'discuss'],
    'execute': ['execute', 'verify'],
    'verify': ['verify', 'execute', 'complete'],
    'complete': ['complete', 'discuss'],
}


class PreconditionError(Exception):
    """Raised when a phase transition precondition is not met."""


def _get_current_phase(content: str) -> str:
    """Extract the current phase from STATE.md content.

    Args:
        content: Raw STATE.md file content.

    Returns:
        Current phase name.

    Raises:
        ValueError: If phase line cannot be found.
    """
    match = re.search(r'## Current Phase\s*\n\s*`(\w+)`', content)
    if not match:
        raise ValueError('STATE.md has unexpected format: could not find phase line under ## Current Phase.')
    return match.group(1)


def transition(root: Path, target: str, *, force: bool = False, note: str = '') -> str:
    """Validate and perform a phase transition.

    Args:
        root: Project root containing .planning/.
        target: Target phase name.
        force: If True, bypass precondition checks.
        note: Optional note for the history table row.

    Returns:
        The new phase name.

    Raises:
        ValueError: If target is not a valid phase or transition is not allowed.
        PreconditionError: If precondition for target phase is not met and force is False.
        FileNotFoundError: If .planning/STATE.md does not exist.
    """
    if target not in PHASES:
        raise ValueError(f'Invalid phase: {target!r}. Must be one of {PHASES}.')

    content = read_state(root)
    current = _get_current_phase(content)

    # Self-transition is always a no-op
    if current == target:
        return target

    # Validate transition is allowed
    allowed = VALID_TRANSITIONS.get(current, [])
    if target not in allowed:
        raise ValueError(f'Cannot transition from {current!r} to {target!r}. Allowed targets: {allowed}')

    # Check preconditions (unless --force)
    if not force:
        _check_preconditions(root, target)

    # Perform the transition
    write_state(root, target, note=note)

    # Auto-reset cycle on complete → discuss
    if current == 'complete' and target == 'discuss':
        reset_cycle(root)

    return target


# Type alias for precondition checker functions.
# Each returns None on success or an error message string on failure.
_PreconditionChecker = Callable[[Path], str | None]


def _check_preconditions(root: Path, target: str) -> None:
    """Run precondition checks for the target phase.

    Args:
        root: Project root containing .planning/.
        target: Target phase name.

    Raises:
        PreconditionError: If a precondition is not met.
    """
    checkers: dict[str, Sequence[_PreconditionChecker]] = {
        'plan': [check_requirements_populated],
        'execute': [check_plan_verified, check_not_on_default_branch],
        'complete': [check_all_tasks_done],
    }
    for checker in checkers.get(target, []):
        error = checker(root)
        if error is not None:
            raise PreconditionError(error)


def check_requirements_populated(root: Path) -> str | None:
    """Check that REQUIREMENTS.md has been populated (no template markers).

    Args:
        root: Project root containing .planning/.

    Returns:
        None if populated, error message string if template markers remain.
    """
    req_file = root / PLANNING_DIR / CYCLE_DIR / 'REQUIREMENTS.md'
    if not req_file.exists():
        return 'Cannot transition to plan: REQUIREMENTS.md not found. Run `gsd-lean init` first.'
    content = req_file.read_text()
    if '(not yet defined)' in content or '(none yet)' in content or '| (none yet) | | |' in content:
        return 'Cannot transition to plan: REQUIREMENTS.md still contains template placeholders. Run /discuss first.'
    return None


def check_plan_verified(root: Path) -> str | None:
    """Check that PLAN.md exists and has status 'verified'.

    Args:
        root: Project root containing .planning/.

    Returns:
        None if plan is verified, error message string otherwise.
    """
    try:
        content = read_plan(root)
    except FileNotFoundError:
        return 'Cannot transition to execute: PLAN.md missing or not verified. Run /plan first.'
    try:
        status = get_plan_status(content)
    except ValueError:
        return 'Cannot transition to execute: PLAN.md missing or not verified. Run /plan first.'
    if status != 'verified':
        return 'Cannot transition to execute: PLAN.md missing or not verified. Run /plan first.'
    return None


def check_all_tasks_done(root: Path) -> str | None:
    """Check that all tasks in PLAN.md have status 'done'.

    Args:
        root: Project root containing .planning/.

    Returns:
        None if all tasks are done, error message string with count otherwise.
    """
    try:
        content = read_plan(root)
    except FileNotFoundError:
        return 'Cannot transition to complete: PLAN.md missing. Run /plan first.'
    tasks = parse_plan_tasks(content)
    if not tasks:
        return 'Cannot transition to complete: no tasks found in PLAN.md.'
    not_done = [t for t in tasks if t.status != 'done']
    if not_done:
        return f'Cannot transition to complete: {len(not_done)} task(s) still pending/in-progress/blocked.'
    return None


def check_not_on_default_branch(root: Path) -> str | None:
    """Check that the working directory is not on the repo's default branch.

    Args:
        root: Project root (git working tree).

    Returns:
        None if not on default branch (or not a git repo), error message otherwise.
    """
    branch = get_current_branch(root)
    if branch is None:
        return None
    default = get_default_branch(root)
    if branch == default:
        return f"Cannot transition to execute: currently on default branch '{branch}'. Create a feature branch first."
    return None
