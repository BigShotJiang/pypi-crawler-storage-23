---
description: Generate structured plan from requirements and decisions, then verify it
argument-hint: [additional planning context]
allowed-tools: Read, Write, Edit, Glob, Grep, Bash(uvx gsd-lean:*), Bash(git:*), Task, LSP, EnterPlanMode, ExitPlanMode
---

## Current State

**Phase:** !`uvx gsd-lean status --path . 2>/dev/null | grep -A1 "Current Phase" | tail -1 | tr -d '\140'`

## Instructions

You are running the **plan phase** of GSD-Lite's development workflow. Your goal: decompose requirements into structured tasks, write cycle/PLAN.md, and verify it passes review.

### Step 1: Transition Phase

Run:
```
uvx gsd-lean transition plan --path .
```

If this fails with a precondition error, tell the user to run `/gsd-lean:discuss` first.

### Step 2: Enter Plan Mode

Call `EnterPlanMode`. Task decomposition and design happens in plan mode (read-only). You will exit plan mode before writing PLAN.md.

### Step 3: Read Inputs

Read these files:
- `.planning/cycle/REQUIREMENTS.md` — what to build (User Intent, Motivation, Goals, Non-Goals, Functional Requirements, Affected Files, Key Interfaces, Edge Cases, Testing Strategy, Non-Functional Requirements)
- `.planning/cycle/DECISIONS.md` — how to build it (Style & Preferences, Constraints, Dependencies)
- `.planning/PROJECT.md` — stack, constraints
- `.planning/CONTEXT.md` — static architecture, tooling, skills context

> **Note:** Architecture, Tooling, and Skills context lives in `.planning/CONTEXT.md` (static, persists across cycles). Cycle docs (cycle/REQUIREMENTS.md, cycle/DECISIONS.md) contain per-cycle content only.

### Step 4: Decompose Into Tasks

Break requirements into discrete, committable tasks. For each task:
- **ID:** `T-NNN` format (zero-padded 3 digits, e.g. T-001, T-002)
- **Wave:** integer for execution ordering (wave 1 before wave 2, etc.)
- **Title:** short imperative description
- **Files:** which files are created/modified
- **Verification:** specific, runnable criteria (test commands, lint checks, manual checks)
- **Dependencies:** which other T-NNN tasks must complete first (or "none")

Guidelines:
- Each task touches at most ~5 files (split larger tasks)
- Wave 1 = foundational work (modules, types, core logic)
- Wave 2 = features built on wave 1 (CLI commands, integrations)
- Wave 3 = skills, docs, polish
- **Tracer bullet:** Before full decomposition, identify the thinnest end-to-end slice through all system layers. This is production code (not a prototype) — a minimal but complete path from input to output that validates the architecture. Create 1–3 tasks for this slice, prefix titles with `[tracer]`, assign wave 1, and give them the lowest T-NNN IDs. Remaining tasks expand from this foundation.
  - If the feature is single-layered or too small for a meaningful end-to-end slice, skip the tracer and note why in PLAN.md.
- Every requirement must map to at least one task
- Every decision must be respected in task design
- Every goal in Goals must map to at least one task
- Non-Goals must not appear as tasks
- Affected Files should inform the Files column of each task
- Testing Strategy should inform verification criteria
- Edge Cases should be covered by tasks or verification criteria

### Step 5: Exit Plan Mode

Call `ExitPlanMode` to leave plan mode. The following steps will write PLAN.md and run verification.

### Step 6: Write PLAN.md

Write `.planning/cycle/PLAN.md` using this exact format:

````markdown
# Plan

> **Status:** draft
> **Created:** <ISO 8601 UTC timestamp>
> **Waves:** <total wave count>
> **Source:** cycle/REQUIREMENTS.md

## Tasks

| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|
| T-001 | 1 | pending | [tracer] <minimal end-to-end title> | `<file1>`, `<file2>` | <brief verification> |
| T-002 | 1 | pending | <title> | `<file>` | <brief verification> |
| T-003 | 2 | pending | <title> | `<file>` | <brief verification> |

## Task Details

### T-001: [tracer] <minimal end-to-end title>

**Description:** <1-3 sentences. Must explain which layers this tracer cuts through and why this is the thinnest valid slice.>

**Files:**
- `path/to/file.py` (create | modify)

**Verification:**
- [ ] <specific check, e.g. "unit tests in tests/test_foo.py pass">
- [ ] <specific check, e.g. "mypy src/module/ clean">

**Dependencies:** none

---

### T-002: <title>

**Description:** ...

**Files:**
- `path/to/file.py` (modify)

**Verification:**
- [ ] ...

**Dependencies:** T-001

---
````

Important:
- Status header MUST be `draft` initially
- Every task in the summary table MUST have a corresponding Task Details section
- Task IDs must be sequential and zero-padded to 3 digits
- Status values: `pending`, `in-progress`, `done`, `blocked`
- Files column uses backtick-wrapped paths, comma-separated

### Step 6.5: Read Subagent Config

Read `.planning/config.yaml` if it exists. For each subagent spawned below, resolve `model` and `max_turns`:

| Subagent | Config key |
|----------|------------|
| plan-review | `skills.plan.subagents.plan-review` |

Fallback to `defaults` section, then omit parameters (inherit from session).

### Step 7: Verify Plan

Use the Task tool to spawn a plan-review subagent with `subagent_type=general-purpose`. If config was loaded, also pass `model` and `max_turns` from the resolved config for `skills.plan.subagents.plan-review`. Omit any parameter that is null/unset. Pass this prompt:

---BEGIN SUBAGENT PROMPT---
You are a plan verification subagent for GSD-Lean. Review the plan for completeness and correctness.

Read these files:
- `.planning/cycle/PLAN.md` — the plan to review
- `.planning/cycle/REQUIREMENTS.md` — requirements it must satisfy
- `.planning/cycle/DECISIONS.md` — cycle-specific decisions it must respect
- `.planning/CONTEXT.md` — static architecture, tooling, skills context

**Checklist:**

1. FORMAT
   - [ ] Plan has Status header (must be `draft` or `verified`)
   - [ ] Every task has: ID (T-NNN), wave, status, title, files, verification
   - [ ] Task Details section exists for every task in the summary table
   - [ ] Each task detail has: description, files with actions, verification checklist, dependencies

2. COMPLETENESS
   - [ ] Every functional requirement in cycle/REQUIREMENTS.md maps to at least one task
   - [ ] Every non-functional requirement is addressed (testing, linting, types)
   - [ ] No orphan tasks (tasks that don't trace to any requirement)

3. DECISIONS
   - [ ] Architecture decisions in CONTEXT.md are reflected in task design
   - [ ] Style preferences in cycle/DECISIONS.md are captured in relevant verification criteria
   - [ ] Constraints are respected (no tasks violating stated constraints)

4. ORDERING
   - [ ] Wave 1 tasks have no dependencies on later-wave tasks
   - [ ] No circular dependencies
   - [ ] Wave ordering makes logical sense (foundations before features)

5. TRACER BULLET
   - [ ] At least one task has `[tracer]` in its title (or PLAN.md documents why no tracer is needed)
   - [ ] Tracer task(s) are in wave 1 with the lowest task IDs
   - [ ] Tracer task(s) collectively touch all system layers the feature spans
   - [ ] Tracer task(s) form a working end-to-end path (not just scaffolding or types)

6. ATOMICITY
   - [ ] Each task is a discrete committable unit
   - [ ] No task touches more than ~5 files (flag if larger)
   - [ ] Verification criteria are specific and runnable (not vague like "works correctly")

**Output format:**

## Verdict: PASS | FAIL

## Issues (if FAIL)
1. [CATEGORY] description of issue — suggested fix
2. [CATEGORY] description of issue — suggested fix

## Suggestions (optional, non-blocking)
- suggestion

Be strict on format and completeness. Be lenient on subjective design choices.
---END SUBAGENT PROMPT---

### Step 8: Handle Review Result

**If PASS:**
- Update cycle/PLAN.md Status header from `draft` to `verified`
- Print: "Plan verified. {N} tasks across {W} waves. Run `/gsd-lean:execute` when ready."

**If FAIL:**
- Print the issues found
- Revise cycle/PLAN.md to address each issue
- Re-run the verification subagent (same prompt as Step 7)
- If second review also fails: print issues and ask user to resolve manually
- If second review passes: update Status to `verified`

Maximum 1 revision loop (2 total verification attempts).

### Step 9: Update State

The phase transition in Step 1 already updated STATE.md. No further state updates needed unless you need to note blockers.
