---
description: "Two-phase project initialization — scaffold + LSP check, then detect stack + populate docs"
argument-hint: ["project path, defaults to current directory"]
allowed-tools: Read, Write, Edit, Glob, Grep, Bash(command -v uvx), Bash(uvx gsd-lean:*), Bash(git:*), Task, AskUserQuestion, LSP, EnterPlanMode, ExitPlanMode
---

## Instructions

You are running the **/init skill** for GSD-Lean. Your goal: scaffold the `.planning/` directory, check LSP/statusline setup, auto-detect the project's tech stack, populate `PROJECT.md`, and onboard the user to the 5-phase workflow.

The skill has two phases:
- **Phase A (Scaffold):** Create `.planning/`, check LSP and statusline status. If LSP is not configured, stop here with setup guidance.
- **Phase B (Populate):** Detect the project stack, populate planning docs, and onboard. Runs only when LSP is already enabled or on a second `/init` run.

### Step 0: Prerequisites

Run:
```
command -v uvx
```

**If the command fails (exit code != 0):** Print the following error and **STOP immediately** — do not proceed to any other step:

````markdown
## Error: `uvx` is not installed

GSD-Lean requires [uv](https://github.com/astral-sh/uv) to run. Install it:

```bash
# macOS / Linux
curl -LsSf https://astral.sh/uv/install.sh | sh

# Windows
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

After installing, restart your terminal and run `/gsd-lean:init` again.
````

**If the command succeeds:** Proceed to Step 1.

### Step 1: Initialization Gate

Check whether `.planning/STATE.md` exists and whether LSP is enabled.

**1a. Check `.planning/STATE.md` existence.**

**If STATE.md does NOT exist (first run):**

Run:
```
uvx gsd-lean init --path .
```

Then read `.claude/settings.json` (if it exists) and check whether `env.ENABLE_LSP_TOOL` is set to `"1"`.

- **If LSP is NOT enabled:** Print the Phase A output (see Step 1b below), then **STOP**. Do not proceed to Phase B.
- **If LSP IS enabled:** Check statusline (see Step 1c), then proceed to Step 2 (Phase B).

**If STATE.md DOES exist (subsequent run):**

Print: "Project already initialized. Running in populate mode (non-destructive)."

Read `.claude/settings.json` (if it exists) and check whether `env.ENABLE_LSP_TOOL` is set to `"1"`.

- **If LSP is NOT enabled:** Print warning: "LSP not enabled — detection will rely on Glob/Grep/Read instead of LSP tools."
- Continue to Step 2 (Phase B) regardless.

### Step 1b: Phase A Output (LSP Not Configured)

Print the following setup guidance, then STOP:

````markdown
## Setup Required

GSD-Lean works best with LSP tools enabled. Three steps are needed:

### 1. Install an LSP server

Install the LSP server for your project's language globally:

| Language | Install command |
|----------|----------------|
| TypeScript/JavaScript | `npm i -g typescript-language-server@latest` |
| Python | `pip install pyright` or `npm i -g pyright` |

### 2. Install the Claude Code LSP plugin

Run the `/plugin` command in Claude Code and install the appropriate plugin:

| Language | Plugin name |
|----------|-------------|
| TypeScript/JavaScript | `typescript-lsp@claude-plugins-official` |
| Python | `pyright-lsp@claude-plugins-official` |

### 3. Enable LSP in settings

Add the following to your `.claude/settings.json`:

```json
{
  "enabledPlugins": {
    "<plugin-name>@claude-plugins-official": true
  },
  "env": {
    "ENABLE_LSP_TOOL": "1"
  }
}
```

## What's Next

1. Complete the LSP setup above
2. Optionally edit `.planning/config.yaml` to tune subagent settings (model, max_turns)
3. Run `/gsd-lean:init` again to detect your project stack and populate planning docs
````

Also check statusline (see Step 1c) and append statusline guidance if not configured.

### Step 1c: Statusline Check

Check `.claude/settings.json` for the `statusLine` key.

- If not configured, append:
  > **Recommendation:** Install the GSD-Lean statusline hook for phase/branch visibility. Run: `uvx gsd-lean init --force-statusline`
- If already configured, append:
  > **Note:** Statusline is already configured.

---

## Phase B: Populate

The following steps run only after the initialization gate (Step 1) allows progression.

### Step 2: Enter Plan Mode

Call `EnterPlanMode`. All codebase exploration, stack detection, and user confirmation happens in plan mode (read-only). You will exit plan mode before writing state files.

### Step 3: Read Project Documentation

Read available project documentation to understand existing conventions before detection:

1. **`CLAUDE.md`** at repo root (if exists) — extract:
   - Dev commands (build, test, lint, format, typecheck)
   - Code style conventions
   - Tech stack details
   - CI/CD pipeline info
   - Any existing tooling configuration

   **Conflict check:** Also scan for development workflow instructions (branching strategy, commit conventions, PR workflows, test-before-push rules, feature development flow). If found, print a warning:

   > **Warning:** `CLAUDE.md` contains development workflow instructions that may conflict with GSD-Lean's phased development cycle. Consider removing or commenting out these instructions before proceeding. See the [Caveats section in the README](./README.md#caveats) for details.

   Continue without blocking.

2. **Other documentation** (if exists):
   - `PROJECT_KNOWLEDGE.md`, `CONTRIBUTING.md`, `README.md`, `TROUBLESHOOTING.md`

If `CLAUDE.md` exists, treat it as the canonical source for tooling and conventions. The auto-detection step (Step 4) complements this — it fills gaps, not duplicates.

**Note:** Reference `CLAUDE.md` in the onboarding summary rather than recreating its content in `.planning/` files. `CLAUDE.md` is assumed to be continuously updated and is the living reference.

### Step 3.5: Read Subagent Config

Read `.planning/config.yaml` if it exists. For each subagent spawned below, resolve `model` and `max_turns`:

| Subagent | Config key |
|----------|------------|
| explore | `skills.init.subagents.explore` |

Fallback to `defaults` section, then omit parameters (inherit from session).

### Step 4: Auto-Detect Project Stack

Use the Task tool to spawn an Explore subagent. If config was loaded, also pass `model` and `max_turns` from the resolved config for `skills.init.subagents.explore`. Omit any parameter that is null/unset. Pass this prompt:

---BEGIN SUBAGENT PROMPT---
You are a project detection subagent for GSD-Lean. Analyze this repository to detect its tech stack and conventions.

**Scan for:**

1. **Primary manifest** — look for: pyproject.toml, package.json, tsconfig.json, Cargo.toml, go.mod, Gemfile, pom.xml, build.gradle, mix.exs, pubspec.yaml, composer.json, CMakeLists.txt
2. **Language & version** — extract from manifest (requires-python, engines.node, edition, go directive)
3. **Framework** — check dependencies for known frameworks (Django, Flask, FastAPI, React, Next.js, Vue, Express, Axum, Gin, etc.)
4. **Build tool** — hatch, setuptools, poetry, npm, yarn, pnpm, bun, cargo, go build
5. **Test runner** — pytest, jest, vitest, bun, mocha, cargo test, go test
6. **Linter** — ruff, eslint, biome, clippy, golangci-lint
7. **Formatter** — ruff, prettier, biome, rustfmt, gofmt
8. **Type checker** — mypy, pyright, tsc
9. **CI** — .github/workflows, .gitlab-ci.yml, Jenkinsfile, .circleci
10. **Key dependencies** — top 5-10 most important dependencies from the manifest
11. **Conventions** — check for CLAUDE.md, .editorconfig, .prettierrc, ruff.toml, mypy.ini, pyrightconfig.json, Makefile, .pre-commit-config.yaml
12. **Dev commands** — check Makefile targets, package.json scripts, or CLAUDE.md for build/test/lint commands
13. **Runtime manager** — check for lockfiles: uv.lock (uv), bun.lock/bun.lockb (bun), pnpm-lock.yaml (pnpm), yarn.lock (yarn), package-lock.json (npm), poetry.lock (poetry)
14. **MCP servers** — check .mcp.json for configured MCP server names
15. **Plugins** — check .claude/settings.json for enabledPlugins
16. **CLI tools** — scan CLAUDE.md, README.md, and Makefile for references to CLI tools (gh, jq, docker, etc.) that could be used during development workflows
17. **Custom skills** - scan .claude/skills/ for custom skills. These can include references to developer patterns, CLI tools, MCP servers, etc.

**Tools:** Use LSP tools (documentSymbol, workspaceSymbol) if available for understanding code structure. Fall back to Glob/Grep/Read otherwise.

**Output format:**
```
Language: <language> <version>
Framework: <framework or "none">
Build tool: <tool>
Test runner: <runner>
Linter: <linter>
Formatter: <formatter>
Type checker: <checker or "none">
CI: <platform>
Key dependencies: <comma-separated>
Dev commands: <key commands discovered>
Conventions found: <list of config files>
CLAUDE.md: <exists | not found>
Runtime manager: <manager or "none">
MCP servers: <comma-separated or "none">
Plugins: <comma-separated or "none">
CLI tools found: <comma-separated or "none">
Custom skills: <comma-separated or "none">
```

Be thorough. Read manifest files to extract accurate information — don't guess.
---END SUBAGENT PROMPT---

### Step 5: Present Findings & Confirm

Present the subagent findings to the user:

```
## Detected Project Stack

- **Language:** <language> <version>
- **Framework:** <framework>
- **Build tool:** <tool>
- **Key dependencies:** <deps>
- **Test runner:** <runner>
- **Linter:** <linter>
- **Formatter:** <formatter (if different from linter)>
- **Type checker:** <checker>
- **CI:** <platform>
- **Runtime manager:** <manager>
- **MCP servers:** <servers>
- **Plugins:** <plugins>
- **CLI tools:** <tools discovered from project docs>
- **Custom skills:** <skills discovered>
```

Then use `AskUserQuestion` to ask: "Does this look correct? Should I update PROJECT.md with these details?"

Options:
- "Yes, update PROJECT.md"
- "Edit first — I'll make corrections"
- "Skip — don't update PROJECT.md"

If the user chooses "Edit first", ask specific follow-up questions about what to change.

### Step 6: Exit Plan Mode

Call `ExitPlanMode` to leave plan mode. The following steps write to `.planning/` files.

### Step 7: Write State Files

If the user confirmed:

1. **Update PROJECT.md** — Edit `.planning/PROJECT.md` to fill in the Stack section with confirmed values. Only fill in fields that are still template placeholders (empty `**Language:**`, `**Framework:**`, `**Key dependencies:**`). Do not overwrite user-edited content.

2. **Optionally seed CONTEXT.md ## Architecture** — If conventions were detected (e.g. ruff config, mypy strict mode, Makefile targets), check whether the Architecture section in `.planning/CONTEXT.md` still contains the template placeholder `(none yet)`. If so, add entries like:
   - "Linting via ruff (configured in pyproject.toml)"
   - "Strict type checking via mypy"
   - "CI via GitHub Actions"

   Only add if the section is still a placeholder — never overwrite user content.

3. **Optionally seed CONTEXT.md ## Tooling** — If MCP servers or plugins were detected, check whether the Tooling section in `.planning/CONTEXT.md` still contains the template placeholder `(none yet)`. If so, add entries like:
   - "MCP servers: context7, filesystem"
   - "Plugins: pyright-lsp (type checking)"
   - "CLI tools: gh (GitHub), docker"

   If CLI tools were discovered by the subagent, include them here too. Only add if the section is still a placeholder — never overwrite user content.

4. **Optionally seed CONTEXT.md ## Skills** — If custom skills were detected, check whether the Skills section in `.planning/CONTEXT.md` still contains the template placeholder `(none yet)`. If so, add entries like:
   - "backend-dev-guidelines: Guidelines on hono routing in backend API"
   - "ci-debugger: Custom skill for debugging CI failures. Documents specific failure patterns and how to resolve them"
   - "frontend-design: Custom skill on building production-grade frontend interfaces"

   Only add if the section is still a placeholder — never overwrite user content.

If the user chose "Skip", do not modify any state files.

### Step 8: Onboarding Summary

Print:

```
## GSD-Lean Initialized

Your project is ready for the 5-phase development workflow:

1. `/gsd-lean:discuss` — Research and capture requirements
2. `/gsd-lean:plan` — Decompose into structured tasks
3. `/gsd-lean:execute` — Implement tasks with auto-verification
4. `/gsd-lean:verify` — Run project checks
5. `/gsd-lean:complete` — Summarize and wrap up

**Next step:** Run `/gsd-lean:discuss <feature description>` to start your first workflow.
```
