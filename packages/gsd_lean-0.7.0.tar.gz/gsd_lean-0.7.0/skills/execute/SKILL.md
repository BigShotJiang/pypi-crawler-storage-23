---
description: Execute next task from plan — spawns executor subagent, verifies, auto-debugs, commits
argument-hint: ["task ID(s) to execute, e.g. 'T-003' or 'T-001 T-003'"]
allowed-tools: Read, Write, Edit, Glob, Grep, Bash, Task, LSP
---

## Current State

**Phase:** !`uvx gsd-lean status --path . 2>/dev/null | grep -A1 "Current Phase" | tail -1 | tr -d '\140'`
**Plan:** !`uvx gsd-lean plan-status --path . 2>/dev/null || echo "No plan"`

## Instructions

You are running the **execute phase** of GSD-Lean's development workflow. Your goal: pick the next task from PLAN.md, implement it via a subagent, verify it, auto-debug if needed, and commit.

### Step 1: Ensure Execute Phase

**Branch guard:** Run `git rev-parse --abbrev-ref HEAD`. If the current branch equals the repo's default branch (e.g. `main`), **stop immediately** and tell the user:
> You are on the default branch. Create a feature branch before running /gsd-lean:execute.

Do **not** create the branch yourself — let the user decide the branch name.

Read `.planning/STATE.md`. If not in `execute` phase, run:
```
uvx gsd-lean transition execute --path .
```
If this fails (plan not verified), tell the user to run `/gsd-lean:plan` first.

### Step 2: Identify Target Task

**Build target set from arguments:**
1. Extract all task IDs matching `T-\d{3}` from $ARGUMENTS
2. If IDs found → build **target set**:
   - Read Task Details for each task in target set
   - Check **Dependencies:** field; add any dep task IDs whose status is not `done`
   - Repeat expansion transitively until no new tasks added
   - Print which tasks are in target set (including auto-added deps)
3. If no IDs in $ARGUMENTS → no target set (execute all pending tasks as before)

**Select next task:**
- If target set exists:
  1. Check for `in-progress` task within target set
  2. Else find first `pending` task in target set (wave order, then ID order)
- If no target set:
  1. Check for `in-progress` task in cycle/PLAN.md
  2. Else find first `pending` task in wave order

If no task available:
- Target set → "All specified tasks complete: {IDs}." Stop.
- No target set → "All tasks complete. Run `/gsd-lean:complete`." Stop.

### Step 3: Update Task Status

If the task is `pending`, update its status to `in-progress` in the cycle/PLAN.md summary table.
If this is the first task being executed (plan status is `verified`), update the plan Status header to `in-progress`.

### Step 4: Read Task Details

Read the Task Details section for the target task in `.planning/cycle/PLAN.md`. Extract:
- **Description** — what to implement
- **Files** — files to create/modify (with actions)
- **Verification** — checklist items
- **Dependencies** — prerequisite tasks (should already be `done`)

Also read:
- `CLAUDE.md` — project commands, code style, conventions
- `.planning/PROJECT.md` — stack, constraints
- `.planning/CONTEXT.md` — static architecture, tooling, skills context

### Step 4.5: Read Subagent Config

Read `.planning/config.yaml` if it exists. For each subagent spawned below, resolve `model` and `max_turns`:

| Subagent | Config key |
|----------|------------|
| executor | `skills.execute.subagents.executor` |
| auto-debug | `skills.execute.subagents.auto-debug` |
| verify | `skills.execute.subagents.verify` |

Fallback to `defaults` section, then omit parameters (inherit from session).

### Step 5: Spawn Executor Subagent

Use the Task tool to spawn an executor subagent with `subagent_type=general-purpose`. If config was loaded, also pass `model` and `max_turns` from the resolved config for `skills.execute.subagents.executor`. Omit any parameter that is null/unset. Pass this prompt (fill in placeholders from task details):

---BEGIN EXECUTOR SUBAGENT PROMPT---
You are an executor subagent for GSD-Lean. Implement the following task:

**Task:** {task_id}: {task_title}

**Description:** {task_description}

**Files to create/modify:**
{files_list}

**Verification criteria:**
{verification_checklist}

**Project context:**
- Read `CLAUDE.md` at repo root for commands, code style, and conventions
- Read `.planning/PROJECT.md` for stack and constraints
- Read `.planning/CONTEXT.md` for architecture, tooling, and skills context
- Follow existing code patterns in the codebase
- Use LSP tools for code navigation (definitions, references, implementations) — cheaper than Grep/Glob

**Rules:**
- Do NOT run git commands (the orchestrator handles commits)
- Do NOT modify `.planning/` files (the orchestrator handles status updates)
- Do NOT run verification commands (the orchestrator runs /verify after you finish)
- Focus exclusively on implementing the task described above
- Follow the project's code style (ruff, mypy strict, Google docstrings, single quotes)
- Write tests if the verification criteria mention tests
- Prefer LSP tools (goToDefinition, findReferences, hover, documentSymbol) over Grep/Glob for code navigation — this reduces token usage

**Output:** When done, summarize what you implemented and which files you changed.
---END EXECUTOR SUBAGENT PROMPT---

### Step 5.5: Collect Changed Files

Parse the executor subagent output for the list of files it changed. Store this as `{changed_files}` — it will be passed to the verify subagent so it stages only these files (not unrelated user changes).

### Step 6: Verify

After the executor subagent completes, spawn a **verify subagent** using the Task tool with `subagent_type=general-purpose`. If config was loaded, also pass `model` and `max_turns` from the resolved config for `skills.execute.subagents.verify`. Omit any parameter that is null/unset. Pass this prompt (fill in placeholders from task details):

---BEGIN VERIFY SUBAGENT PROMPT---
You are a verify subagent for GSD-Lean. Verify that a task implementation passes its criteria and project checks. On PASS, update the plan and commit.

**Task:** {task_id}: {task_title}

**Files changed during implementation:**
{changed_files}

**Verification criteria:**
{verification_checklist}

**Step 1: Discover project verification commands**

Read available project configuration to determine what checks to run:

1. **`CLAUDE.md`** at repo root — look for lint, format, typecheck, test commands
2. **Common config files** (check existence, use first match per category):
   - Lint/format: `Makefile` (ruff/lint targets), `package.json` (lint/format scripts), `.pre-commit-config.yaml`
   - Typecheck: `Makefile` (mypy/pyright target), `tsconfig.json`, `pyproject.toml`
   - Tests: `Makefile` (test targets), `package.json` (test script), `pytest.ini`/`pyproject.toml` (pytest config), `Cargo.toml`

If no commands can be discovered, report that and stop.

**Step 2: Run checks**

Run each discovered check sequentially. For each, report PASS or FAIL with error details.

**Step 3: Report results**

Output in this format:
````
## Verification: {task_id} — {task_title}

| Check | Result | Details |
|-------|--------|---------|
| <check 1> | PASS/FAIL | <brief detail> |
| <check 2> | PASS/FAIL | <brief detail> |

**Overall: PASS / FAIL (X/Y checks passed)**
````

If overall is FAIL, stop here. Do NOT proceed to Step 4.

**Step 4: Update plan and commit (PASS only)**

Only execute this step if overall result is **PASS**.

1. **Update task status:** In `.planning/cycle/PLAN.md`, find the summary table row for `{task_id}` and change its status from `in-progress` to `done`.
2. **Tick verification checkboxes:** In the Task Details section for `{task_id}`, change every `- [ ]` under the **Verification:** heading to `- [x]`.
3. **Stage and commit:**
   - Run `git status --porcelain` — if no changes, report "nothing to commit" and skip
   - Stage only the files listed in "Files changed during implementation" above:
     `git add {changed_files}` - `.planning/cycle/PLAN.md` is not tracked by git
   - Do **NOT** use `git add -A` — it may stage unrelated user changes
   - Read `git log --oneline -5` for commit style reference
   - Create commit: `git commit -m "{type}({scope}): {task_title} ({task_id})"` with footer
   - `{type}`: `feat` for new features, `fix` for bug fixes, `refactor` for restructuring, `test` for test-only, `docs` for docs-only
   - `{scope}`: primary module/directory affected
   - Footer:
     ```
     [Generated with Claude Code](https://claude.com/claude-code)

     Co-Authored-By: Claude <model-revision> <noreply@anthropic.com>
     ```
4. **Report:** Include in your output:
````
## Plan Updated
- Task {task_id} status: done
- Verification checkboxes: ticked

## Committed
{commit_hash} {type}({scope}): {task_title} ({task_id})
````
If PLAN.md edit or git commit fails, report the error instead.

**Rules:**
- Only modify `.planning/cycle/PLAN.md` — do not touch other `.planning/` files
- Only run git commands in Step 4 (after PASS)
- Do NOT use `git -C`
- Focus on running checks, reporting results, and — on PASS — updating the plan and committing
---END VERIFY SUBAGENT PROMPT---

Parse the verification result for PASS/FAIL.

### Step 7: Handle Verification Result

**If PASS:**
1. Parse the verify subagent output. Confirm it includes "Plan Updated" and a commit hash (or "nothing to commit").
2. If the subagent failed to update PLAN.md or commit, fall back:
   - Update task status to `done` in `cycle/PLAN.md` summary table
   - Tick all `- [ ]` to `- [x]` in the Task Details section for this task
   - Stage only files changed by executor/auto-debug subagents, then commit with conventional message and footer (do **NOT** use `git add -A`)
3. Go to Step 9

**If FAIL:**
1. Capture the error output from the verify subagent
2. Identify which files were touched by the executor subagent
3. Go to Step 8

### Step 8: Auto-Debug

Spawn an auto-debug subagent with `subagent_type=general-purpose`. If config was loaded, also pass `model` and `max_turns` from the resolved config for `skills.execute.subagents.auto-debug`. Omit any parameter that is null/unset. Pass this prompt:

---BEGIN AUTO-DEBUG SUBAGENT PROMPT---
You are an auto-debug subagent for GSD-Lean. A task implementation failed verification. Fix the issues.

**Task:** {task_id}: {task_title}

**Original task description:** {task_description}

**Verification error output:**
```
{error_output}
```

**Files touched by the implementation:**
{touched_files}

**Rules:**
- Focus ONLY on fixing the specific errors shown above
- Do NOT add unrelated changes or refactoring
- Do NOT run git commands
- Do NOT modify `.planning/` files
- Read the failing files and the error output to identify root cause
- Apply the minimal fix needed
- Prefer LSP tools (goToDefinition, findReferences, hover) over Grep/Glob for code navigation — reduces token usage

**Scope:** Narrow — only analyze and fix the specific verification failure. Do not make broader changes.

**Output:** Summarize: (1) root cause, (2) fix applied, (3) files modified.
---END AUTO-DEBUG SUBAGENT PROMPT---

After the auto-debug subagent completes, merge its modified files into `{changed_files}`, then re-run Step 6 (spawn verify subagent again with the updated file list).

**If PASS:** Go to Step 7 (PASS path).

**If still FAIL:**
1. Report the diagnosis: root cause + what was tried + remaining errors
2. Task stays `in-progress`
3. Ask user: "Auto-debug failed. Would you like to fix manually, skip this task, or retry?"
4. Stop the loop — do not proceed to the next task

### Step 9: Check for More Tasks

**If target set was defined:**
1. Check if any tasks in target set still `pending` or `in-progress`
2. If yes → print "Task {task_id} complete. {remaining} target tasks remaining. Continuing..." → loop to Step 2
3. If no → print "All specified tasks complete: {IDs}." Stop. Do NOT update Status header.

**If no target set:**
1. Check for more `pending` tasks in cycle/PLAN.md
2. If yes → print "Task {task_id} complete. {remaining} tasks remaining. Continuing..." → loop to Step 2
3. If no → update Status header to `complete`. Print "All tasks complete. Run `/gsd-lean:complete` to finish the workflow."
