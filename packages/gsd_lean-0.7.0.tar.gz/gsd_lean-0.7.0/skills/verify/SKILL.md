---
description: Verify current task against its criteria and run project checks
argument-hint: ["task ID, e.g. T-003"]
allowed-tools: Read, Glob, Grep, Bash, Task
---

## Current State

**Phase:** !`uvx gsd-lean status --path . 2>/dev/null | grep -A1 "Current Phase" | tail -1 | tr -d '\140'`
**Plan:** !`uvx gsd-lean plan-status --path . 2>/dev/null || echo "No plan"`

## Instructions

You are running the **verify phase** of GSD-Lite's development workflow. Your goal: verify that the current (or specified) task meets its verification criteria and passes project-level checks.

### Step 1: Identify Target Task

If $ARGUMENTS contains a task ID (e.g. `T-003`), verify that task.
Otherwise, find the task with status `in-progress` in `.planning/cycle/PLAN.md`.
If no task is in-progress, report that and stop.

### Step 2: Read Verification Criteria

Read the Task Details section for the target task in `.planning/cycle/PLAN.md`. Extract its **Verification** checklist items.

### Step 3: Discover Project Verification Commands

Read available project configuration to determine what checks to run:

1. **`CLAUDE.md`** at repo root — look for lint, format, typecheck, test commands
2. **Common config files** (check existence, use first match per category):
   - Lint/format: `Makefile` (ruff/lint targets), `package.json` (lint/format scripts), `.pre-commit-config.yaml`
   - Typecheck: `Makefile` (mypy target), `tsconfig.json`, `pyproject.toml` (mypy config)
   - Tests: `Makefile` (test targets), `package.json` (test script), `pytest.ini`/`pyproject.toml` (pytest config), `Cargo.toml`

If no commands can be discovered, ask the user what verification commands to run.

### Step 4: Run Verification

Run each discovered check sequentially. For each:
- Report: **PASS** or **FAIL** with file paths and error details
- Map results back to the task's verification checklist items where possible

### Step 5: Report Results

Output:

```
## Verification: T-NNN — <title>

| Check | Result | Details |
|-------|--------|---------|
| <check 1> | PASS/FAIL | <brief detail> |
| <check 2> | PASS/FAIL | <brief detail> |

**Overall: PASS / FAIL (X/Y checks passed)**
```

If all pass: suggest "Task T-NNN verified. Update status to `done` in cycle/PLAN.md and run `/gsd-lean:commit`."
If any fail: list specific errors and suggest fixes.
