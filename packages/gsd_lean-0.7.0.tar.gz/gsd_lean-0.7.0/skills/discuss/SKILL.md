---
description: Run enriched discuss phase — research, probe preferences, populate requirements and decisions
argument-hint: <feature or change description>
allowed-tools: Read, Write, Edit, Glob, Grep, Bash(uvx gsd-lean:*), Bash(git:*), Task, WebSearch, WebFetch, LSP, EnterPlanMode, ExitPlanMode, mcp__context7__resolve-library-id, mcp__context7__query-docs
---

## Current State

**Phase:** !`uvx gsd-lean status --path . 2>/dev/null | grep -A1 "Current Phase" | tail -1 | tr -d '\140'`
**Project:** !`head -1 .planning/PROJECT.md 2>/dev/null || echo "Not initialized"`

## Instructions

You are running the **discuss phase** of GSD-Lean's development workflow. Your goal: deeply understand what the user wants to build, explore the codebase, research external resources, probe user preferences, and capture everything in cycle/REQUIREMENTS.md and cycle/DECISIONS.md. These documents must be **entirely self-contained** — a fresh `/plan` session reads only these + PROJECT.md + CONTEXT.md.

### Step 1: Verify Phase

Read `.planning/STATE.md`. If not in `discuss` phase, run:
```
uvx gsd-lean transition discuss --path . --force
```

### Step 2: Enter Plan Mode

Call `EnterPlanMode`. All exploration, research, and user probing happens in plan mode (read-only).

### Step 3: Read Existing State + Project Context

Read these files to understand current context:
- `.planning/PROJECT.md` — static project overview
- `.planning/CONTEXT.md` — static architecture, tooling, skills context
- `.planning/cycle/REQUIREMENTS.md` — cycle-specific requirements template
- `.planning/cycle/DECISIONS.md` — cycle-specific decisions template
- `CLAUDE.md` at repo root — extract dev commands, code style, conventions, tooling
- `PROJECT_KNOWLEDGE.md` if it exists — architecture, data flow, patterns
- `README.md` if it exists — project overview

Static docs (PROJECT.md, CONTEXT.md) persist across cycles — reference rather than duplicate their content. Cycle docs (cycle/REQUIREMENTS.md, cycle/DECISIONS.md) are fresh templates to populate.

### Step 4: Explore Codebase

**You MUST explore code relevant to the feature before writing anything.**

1. Use LSP tools (`documentSymbol`, `workspaceSymbol`, `goToDefinition`, `findReferences`) to understand code relevant to the feature
2. Explore source directories that will be affected
3. Identify existing patterns, utilities, modules to reuse or extend
4. Identify exact files that will need to change (for Affected Files section)
5. Read test files to understand testing patterns and conventions

**Prefer LSP over Grep** for code navigation. Use LSP operations to trace code paths, find symbol usages, and understand interfaces. Fall back to Grep only for text patterns that aren't symbols (e.g. string literals, comments, config keys).

### Step 4.5: Read Subagent Config

Read `.planning/config.yaml` if it exists. For each subagent spawned below, resolve `model` and `max_turns`:

| Subagent | Config key |
|----------|------------|
| explore | `skills.discuss.subagents.explore` |
| verify | `skills.discuss.subagents.verify` |

Fallback to `defaults` section, then omit parameters (inherit from session).

### Step 5: Spawn Research Subagent

Use the Task tool to spawn a research subagent with `subagent_type=Explore`. If config was loaded, also pass `model` and `max_turns` from the resolved config for `skills.discuss.subagents.explore`. Omit any parameter that is null/unset. Pass this prompt (fill in {feature_description} from $ARGUMENTS and {codebase_findings} from Step 4):

---BEGIN SUBAGENT PROMPT---
You are a research subagent for GSD-Lean. Investigate the codebase and external resources for the following feature:

**Feature:** {feature_description}

**Codebase findings so far:** {codebase_findings}

**Research tasks:**

1. **Codebase investigation** (use LSP tools if available, otherwise Glob/Grep/Read):
   - Find existing code patterns relevant to this feature
   - Identify files/modules that will be affected
   - Check for existing utilities, helpers, or patterns to reuse
   - Note architectural constraints or conventions

2. **External research** (use WebSearch):
   - Best practices for this type of feature
   - Common pitfalls and edge cases
   - Relevant library documentation if new deps needed

3. **Library documentation** (if the feature involves libraries/frameworks):
   - Use `mcp__context7__resolve-library-id` to resolve library IDs
   - Use `mcp__context7__query-docs` to fetch up-to-date documentation
   - If context7 is not available, fall back to WebSearch

**Output format:**

## Codebase Findings
- [finding]: description + file paths

## External Research
- [finding]: description + source

## Suggested Requirements
- [req]

## Suggested Decisions
- [decision]: rationale

## Suggested Edge Cases
- [edge case]: how to handle

## Suggested Testing Strategy
- [test]: what to verify

## Risks & Considerations
- [risk]

Be thorough but concise. Cite file paths and URLs.
---END SUBAGENT PROMPT---

### Step 6: Probe User Preferences

While research runs (or after), actively ask the user about:
- **Architecture:** preferred patterns, module structure, dependency approach
- **Error handling:** style (exceptions vs result types), granularity, user-facing messages
- **Testing:** coverage expectations, test patterns, integration test needs
- **Naming:** conventions for functions, files, classes
- **Constraints:** performance, backwards compatibility, API surface
- **Scope:** what's explicitly in/out

Use `AskUserQuestion` with specific options, not open-ended questions. Ask 2-4 questions max per round.

### Step 7: Exit Plan Mode

Call `ExitPlanMode` to leave plan mode. The following steps will write to `.planning/` files.

### Step 8: Update State Files

Merge research findings + user answers into the following sections. Replace template placeholders with real content. If a section cannot be fully populated during discuss, use `(to be determined during /plan)` as acceptable placeholder for Affected Files — but all other sections must have substantive content.

**`.planning/cycle/REQUIREMENTS.md`** — update these 10 sections:

1. **User Intent** — 1-2 paragraph summary of what + why
2. **Motivation** — why this change is needed, link to issues/PRDs if relevant
3. **Goals** — bulleted list of what this aims to achieve
4. **Non-Goals** — explicit out-of-scope items (prevents scope creep in /plan)
5. **Functional Requirements** — detailed feature requirements
6. **Affected Files** — table of files to create/modify with descriptions
7. **Key Interfaces** — proposed function signatures, class definitions, API contracts
8. **Edge Cases & Error Handling** — numbered list of edge cases + handling
9. **Testing Strategy** — test files, test cases, coverage notes
10. **Non-Functional Requirements** — performance, security, backwards compatibility

**`.planning/cycle/DECISIONS.md`** — update these 3 sections:

1. **Style & Preferences** — code style, naming, pattern preferences
2. **Constraints** — limits, backwards compatibility, API surface
3. **Dependencies** — new packages/tools needed; if none, state "None"

Each decision should have a one-line rationale.

> **Note:** Architecture, Tooling, and Skills context lives in `.planning/CONTEXT.md` (static, persists across cycles). Do NOT duplicate that content in cycle/DECISIONS.md.

### Step 9: Verify Documents

Use the Task tool to spawn a verification subagent with `subagent_type=general-purpose`. If config was loaded, also pass `model` and `max_turns` from the resolved config for `skills.discuss.subagents.verify`. Omit any parameter that is null/unset. Pass this prompt:

---BEGIN SUBAGENT PROMPT---
You are a verification subagent for GSD-Lean. Validate that the discuss phase output is complete and ready for `/plan`.

Read these files:
- `.planning/cycle/REQUIREMENTS.md`
- `.planning/cycle/DECISIONS.md`

**Checklist:**

1. **COMPLETENESS** — no `(not yet defined)`, `(none yet)`, or `| (none yet) | | |` markers remain in cycle/REQUIREMENTS.md or cycle/DECISIONS.md. The only acceptable placeholder is `(to be determined during /plan)` in the Affected Files table.
2. **QUALITY** — each section has substantive content (not just a single word or trivially short)
3. **UNAMBIGUITY** — requirements are specific enough for `/plan` to decompose into tasks without making design decisions
4. **FILE REFERENCES** — Affected Files table contains real file paths (or explicit TBD entries)
5. **CONSISTENCY** — decisions in cycle/DECISIONS.md align with requirements in cycle/REQUIREMENTS.md

**Output format:**

## Verdict: PASS | FAIL

## Issues (if FAIL)
1. [CATEGORY] description of issue — suggested fix
2. [CATEGORY] description of issue — suggested fix

Be strict on completeness. Be lenient on subjective content quality.
---END SUBAGENT PROMPT---

**If PASS:** proceed to Step 10.

**If FAIL:** fix the issues and re-verify (max 1 retry). If second attempt also fails, print the issues and ask the user to resolve manually.

### Step 10: Summary

Print a summary of what was captured:
- Key requirements (bulleted)
- Key decisions (bulleted)
- Any gaps or open questions

Then suggest: "Requirements and decisions captured. Run `/gsd-lean:plan` when ready to generate a plan."
