# Ralph Sandbox Setup

## Setup Sandbox

Build sandbox template:
```bash
# Navigate to ralph/
cd ralph/

# Build template with uv and uvx
docker build -t docker-sandbox-uv-template:v1 .
```

Create from local image:
```bash
# Navigate to repo root
cd ~/project

# Build sandbox with custom template
docker sandbox create --template docker-sandbox-uv-template:v1 \
    --load-local-template \
    claude .
```

## Key Constraint

The Docker sandbox runs **Ubuntu aarch64 Linux**. The host is **macOS**. The `.venv` is shared via workspace mount — binaries from one OS segfault on the other. Scripts handles this automatically by nuking `.venv` and re-bootstrapping inside the sandbox before each run.

uv's standalone Python 3.14 bundles its own OpenSSL/cert store which doesn't include Docker Desktop Sandbox's proxy CA — causing pip inside pre-commit's isolated venvs to timeout on pypi.org. Switching to `repo:local` + `language:system` with uv run entries avoids pip entirely.

## Manual Debugging

From inside the sandbox (`docker sandbox exec -it claude-gsd-lean bash`):

```bash
cd /home/agent/workspace
rm -rf .venv
make sync-venv
make pre-commit-install
```

## Known Issues

- **Never use `pip`** — PEP 668 on Ubuntu 25.10 blocks it. Use `uv` for everything.
- **After ralph script runs**, the host `.venv` contains Linux binaries. Run `make sync-venv` on the host to restore macOS-compatible venv.
- **Network**: proxy is allow-all by default. Config at `~/.docker/sandboxes/vm/claude-gsd-lean/proxy-config.json`.
