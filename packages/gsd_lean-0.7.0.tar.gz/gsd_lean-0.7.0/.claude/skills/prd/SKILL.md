---
description: Generate a comprehensive PRD from user context and codebase exploration
argument-hint: <feature or change description>
disable-model-invocation: true
allowed-tools: Read, Glob, Grep, Write, WebSearch, WebFetch, EnterPlanMode, AskUserQuestion, Bash(git log:*), Bash(git diff:*), Bash(git branch:*), Bash(gh:*), Bash(ls:*), Bash(tree:*), Bash(find:*), LSP
---

## Current Context

**Project:** !`head -1 README.md 2>/dev/null || echo "No README"`

**Branch:** !`git branch --show-current`

**Git SHA:** !`git rev-parse --short HEAD`

**Project structure:**
```
!`tree -L 3 --gitignore -I __pycache__ 2>/dev/null || find . -maxdepth 3 -not -path '*/.git/*' -not -path '*/__pycache__/*' | sort`
```

**Recent commits (last 15):**
```
!`git log --oneline -15`
```

**Existing PRDs:**
```
!`ls docs/prds/ 2>/dev/null || echo "No PRDs yet"`
```

## User Request

$ARGUMENTS

## Instructions

You are creating a PRD that will be handed to a fresh Claude Code session with zero prior context. That session will read only the PRD and `CLAUDE.md` to implement the feature. The PRD must be entirely self-contained.

Follow these steps in exact order. Do NOT skip or combine steps.

---

### Step 1: Enter Plan Mode

Call `EnterPlanMode` immediately. All exploration and research happens in plan mode.

---

### Step 2: Explore Codebase

**You MUST do all of the following before writing anything:**

1. Read `CLAUDE.md` and any project knowledge docs for conventions
2. Read the project's manifest/config files for dependencies, entry points, tooling
3. Explore source directories — read every file relevant to the user's request
4. Explore test directories — understand testing patterns and conventions
5. Find related existing code, modules, or patterns the feature will touch or extend
6. Identify the exact files, classes, and functions that will need to change or be created

**Prefer LSP over Grep for code navigation.** Use LSP operations (`goToDefinition`, `findReferences`, `hover`, `documentSymbol`, `workspaceSymbol`) to trace code paths, find symbol usages, and understand interfaces. Fall back to Grep only for text patterns that aren't symbols (e.g. string literals, comments, config keys).

Do not cut corners here. The PRD quality is directly proportional to how well you understand the codebase.

---

### Step 3: Research External Resources

**You MUST do all of the following:**

1. Use `WebSearch` to find best practices, prior art, and relevant design patterns for the feature being specified
2. If the feature involves any libraries or frameworks, use context7 MCP tools (`mcp__context7__resolve-library-id` then `mcp__context7__query-docs`) to fetch up-to-date documentation
3. Incorporate relevant findings into your design — cite sources where applicable

---

### Step 4: Clarify with User

Use `AskUserQuestion` to ask about any of the following that are unclear:

- **Scope**: What is explicitly in/out of scope?
- **Behavior**: Ambiguous behaviors or edge cases found during exploration
- **Constraints**: Performance, backwards compatibility, API surface
- **Dependencies**: New deps needed? Any to avoid?
- **Testing**: Specific test scenarios the user cares about?

Wait for answers before proceeding.

You may skip this step ONLY if the request is truly unambiguous — but you must explicitly state why no clarification is needed. This should be rare.

---

### Step 5: Write the PRD

Exit plan mode, then write the PRD.

**Determine output mode** from `$ARGUMENTS`:
- If the user mentions posting as a GitHub issue (e.g. "gh issue", "github issue", "post as issue", "create issue"), use **issue mode**
- Otherwise use **file mode** (default)

#### File mode (default)

**File path:** `docs/prds/<NNN>-<slug>.md`
- `<NNN>` = zero-padded 3-digit number, auto-incremented from existing PRDs in `docs/prds/`
- `<slug>` = kebab-case name derived from the feature
- Create `docs/prds/` directory if it does not exist

Write the PRD to the file path above.

#### Issue mode

Do NOT create a file. Instead:
1. Compose the PRD content using the same template below
2. Create the issue: `gh issue create --title "PRD: <Title>" --label prd --body "<PRD content>"`
   - If the `prd` label does not exist yet, create it first: `gh label create prd --description "Product Requirement Document" --color 0E8A16`
3. Capture and save the returned issue URL for Step 6

Use this exact template (both modes):

```markdown
# PRD: <Title>

> **Status:** Draft
> **Author:** <user> + Claude
> **Date:** <YYYY-MM-DD>
> **Branch:** `<current branch>`
> **Base SHA:** `<short git SHA>`

---

## 1. Summary

One paragraph. What is being built, why, and what problem it solves.

## 2. Motivation

Why this change is needed. Link to issues/discussions if relevant.

## 3. Goals

Bulleted list of what this PRD aims to achieve.

## 4. Non-Goals

Explicit list of what is OUT of scope. This section prevents scope creep during implementation — be thorough.

## 5. Architecture & Design

### 5.1 Overview

High-level description of the approach. Include a diagram (ASCII or mermaid) if helpful.

**Tracer bullet:** Identify the thinnest possible end-to-end slice through all system layers that validates the architecture. This is production code (not a prototype) — a minimal but complete path from input to output. See [The Pragmatic Programmer — Tracer Bullets](https://www.barbarianmeetscoding.com/notes/books/pragmatic-programmer/tracer-bullets/).

### 5.2 Affected Files

Table of files that will be created or modified:

| File | Action | Description |
|------|--------|-------------|
| `path/to/file` | Create/Modify | ... |

### 5.3 Key Interfaces

Code blocks showing proposed function signatures, class definitions, or API contracts. Use the project's language and type system.

### 5.4 Data Flow

How data moves through the system for this feature.

## 6. Detailed Design

Break down into sub-sections per component. Each section must cover:
- What the component does
- Input/output contract
- Error handling behavior
- Exact file path where the code lives

Be specific enough that an implementer doesn't need to make design decisions.

## 7. Edge Cases & Error Handling

Numbered list of edge cases and how each should be handled.

## 8. Testing Strategy

### 8.1 Unit Tests

| Test file | Test case | What it verifies |
|-----------|-----------|-----------------|
| `tests/...` | `test_...` | ... |

### 8.2 Integration Tests

If applicable. Otherwise state "N/A".

### 8.3 Coverage Notes

Areas that are hard to test and why.

## 9. Dependencies

New packages, tools, or services required. If none, say "None."

## 10. Migration & Rollout

Migration steps, feature flags, backwards compatibility concerns. If none, say "N/A — no migration needed."

## 11. Open Questions

Remaining decisions to be made. If none, say "None — all questions resolved."

## 12. Implementation Checklist

Ordered list of implementation steps. Each step should be a discrete, committable unit of work.

**Start with a tracer bullet** — the first step(s) should build the minimal end-to-end slice identified in §5.1. Tag with `[tracer]`. This validates the architecture before investing in full implementation. Remaining steps expand from this foundation.

- [ ] `[tracer]` Step 1: ...
- [ ] Step 2: ...
- [ ] ...

## 13. Project Context for Implementer

> This section gives a fresh Claude Code session everything it needs to start implementing.

- **Start here:** Read `CLAUDE.md` at repo root
- **Package layout:** <describe the project's directory structure and entry points>
- **Tooling:** <list the project's build tools, linters, formatters, test runners>
- **Commands:** <list the key commands for building, testing, linting — reference CLAUDE.md>
- **Code style:** <summarize the project's style conventions>
- **CI:** <describe CI pipeline and requirements>
- **Key files to read first:**
  1. <most relevant file>
  2. <second most relevant file>
  3. <third most relevant file>
```

---

### Step 6: Confirm

After writing:

**File mode:**
1. Print the full file path of the saved PRD
2. Give a 2–3 sentence summary of what the PRD covers
3. Ask: "Want me to revise anything before handing this off to an implementation session?"

**Issue mode:**
1. Print the GitHub issue URL
2. Give a 2–3 sentence summary of what the PRD covers
3. Ask: "Want me to revise anything on the issue?"
