---
description: Create a release by tagging main
argument-hint: ["version, e.g. v0.1.0"]
disable-model-invocation: true
allowed-tools: Bash(git:*), Bash(gh:*), Bash(git-cliff:*), Bash(make:*), Bash(xargs:*), Bash(jq:*), Bash(mv:*)
---

## Current Context

**Branch:** !`git branch --show-current`

**Latest tags:**
```
!`git tag --sort=-v:refname | head -5`
```

**Last release tag:**
```
!`git tag --sort=-v:refname --list 'v*' | head -1`
```

**Commits since last tag (or all if no tag):**
```
!`git tag --sort=-v:refname --list 'v*' | head -1 | xargs -I{} git log {}..HEAD --oneline 2>/dev/null || git log --oneline`
```

**Tag exists for requested version?**
```
!`git tag -l "$1" 2>/dev/null || echo "no argument provided"`
```

## Instructions

### If version argument provided (`$ARGUMENTS` is non-empty):

1. Validate format matches `v*.*.*`. If invalid, stop.
2. If tag already exists, stop.
3. Skip to **Create Release** below.

### If no version argument:

Determine the next version by analyzing commits since the last release tag.

1. **Find base version**: Parse the latest `v*.*.*` tag. If none exists, use `v0.0.0`.
2. **Scan commits** (shown in context above). Apply highest bump found:
   - `BREAKING CHANGE` in body/footer OR `!:` in subject → **major** bump
   - `feat:` or `feat(…):` prefix → **minor** bump
   - Anything else (`fix:`, `chore:`, `docs:`, etc.) → **patch** bump
3. **Compute next version**: Apply bump to base (e.g. `v0.1.2` + minor = `v0.2.0`).
4. **Present to user**: Show suggested version and the commits that informed it. Ask for confirmation. User may override.

### Create Release

1. If not on `main`, switch: `git switch main`
2. Pull latest: `git pull origin main`
3. Create release branch: `git switch -c release/<version>`
4. Generate changelog: `git-cliff -o CHANGELOG.md`
5. Sync plugin version: `jq --arg v "<version-without-v>" '.version = $v' .claude-plugin/plugin.json > tmp.json && mv tmp.json .claude-plugin/plugin.json`
6. Commit: `git add CHANGELOG.md .claude-plugin/plugin.json && git commit -m "chore: update changelog for <version>"`
7. Push branch: `git push -u origin release/<version>`
8. Create PR: `gh pr create --title "chore: release <version>" --body "Update CHANGELOG.md for <version>"`
9. Report: PR created. Instruct user to merge PR, then switch to main, tag, and push.
