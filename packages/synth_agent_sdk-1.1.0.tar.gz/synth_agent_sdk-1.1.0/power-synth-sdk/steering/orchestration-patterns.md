# Orchestration Patterns

## Pipeline

Sequential agent chaining where each agent's output becomes the next agent's input.

### Basic Pipeline

```python
from synth import Agent, Pipeline

summarizer = Agent(model="gpt-4o", instructions="Summarize the input concisely.")
translator = Agent(model="claude-sonnet-4-5", instructions="Translate to French.")
formatter = Agent(model="gpt-4o", instructions="Format as a professional email.")

pipeline = Pipeline([summarizer, translator, formatter])
result = pipeline.run("Long article text here...")
print(result.text)  # French-formatted email summary
```

### Parallel Groups

Run a subset of agents concurrently within a pipeline:

```python
from synth import Pipeline, ParallelGroup

# These two run concurrently, then their merged output goes to the editor
researchers = ParallelGroup([
    Agent(model="gpt-4o", instructions="Research technical aspects."),
    Agent(model="gpt-4o", instructions="Research business aspects."),
])
editor = Agent(model="claude-sonnet-4-5", instructions="Combine into a report.")

pipeline = Pipeline([researchers, editor])
result = pipeline.run("AI in healthcare")
```

ParallelGroup runs agents via `asyncio.gather()` and merges outputs (concatenation by default, configurable via a merge function).

### Pipeline Streaming

Events are wrapped in `StageEvent` so you know which stage produced each event:

```python
for event in pipeline.stream("Input text"):
    match event:
        case StageEvent(stage_name=name, event=TokenEvent(text=t)):
            print(f"[{name}] {t}", end="")
```

### Pipeline with Structured Output

Only the final stage's output is validated against the schema:

```python
result = pipeline.run("Input", output_schema=MyModel)
print(result.output)  # Parsed Pydantic model from last stage
```

### Error Handling

If step k fails, the pipeline halts and raises `PipelineError`:

```python
try:
    result = pipeline.run("Input")
except PipelineError as e:
    print(f"Failed at step {e.failed_step}: {e.agent_name}")
    for partial in e.partial_results:
        print(f"  Completed: {partial.text[:50]}...")
```

## Graph

Directed graph execution with conditional edges, loops, concurrent nodes, and checkpointing.

### Basic Graph

```python
from synth import Graph, node
from pydantic import BaseModel

class ReviewState(BaseModel):
    text: str
    quality_score: float = 0.0
    approved: bool = False

graph = Graph(state_schema=ReviewState)

@node(graph)
def analyze(state: ReviewState) -> ReviewState:
    # Score the text quality
    state.quality_score = score_text(state.text)
    return state

@node(graph)
def improve(state: ReviewState) -> ReviewState:
    # Rewrite for better quality
    state.text = rewrite(state.text)
    return state

@node(graph)
def approve(state: ReviewState) -> ReviewState:
    state.approved = True
    return state

graph.set_entry("analyze")
graph.add_edge("analyze", "improve", when=lambda s: s.quality_score < 0.8)
graph.add_edge("analyze", "approve", when=lambda s: s.quality_score >= 0.8)
graph.add_edge("improve", "analyze")  # Loop back for re-analysis
graph.add_edge("approve", Graph.END)

result = graph.run(
    ReviewState(text="Draft article..."),
    max_iterations=100,  # Prevent infinite loops
)
```

### Conditional Edges

Edges can have `when` conditions. If no condition matches, `GraphRoutingError` is raised:

```python
graph.add_edge("router", "handler_a", when=lambda s: s.category == "A")
graph.add_edge("router", "handler_b", when=lambda s: s.category == "B")
# If category is "C", GraphRoutingError is raised
```

Unconditional edges (no `when`) always match:

```python
graph.add_edge("process", Graph.END)  # Always goes to END
```

### Concurrent Nodes

Nodes with no dependency on each other execute concurrently via `asyncio.gather()`. Each concurrent node receives an isolated state copy (deep-copied) to prevent shared mutable state.

### Loop Detection

If execution exceeds `max_iterations` (default 100), `GraphLoopError` is raised with the full `node_history`:

```python
try:
    result = graph.run(state, max_iterations=50)
except GraphLoopError as e:
    print(f"Loop detected after {e.max_iterations} iterations")
    print(f"Node history: {e.node_history}")
```

### Checkpointing

Enable state persistence after each node for resumable runs:

```python
# Local disk (default)
graph.with_checkpointing()

# Redis for distributed environments
from synth.checkpointing import RedisCheckpointStore
graph.with_checkpointing(store=RedisCheckpointStore("redis://localhost:6379"))

# Run with a specific run_id
result = graph.run(state, run_id="my-run-123")

# Resume after interruption
result = graph.resume("my-run-123")
```

Checkpoints are JSON-serialized (never pickle). Local store uses atomic write-to-temp-then-rename. Redis store uses transactions.

### Human-in-the-Loop

Pause execution for human approval:

```python
graph.with_human_in_the_loop(
    pause_at=["review_node"],
    timeout=3600,           # 1 hour timeout
    fallback="auto_approve" # Route here if timeout expires
)

result = graph.arun(state)
if isinstance(result, PausedRun):
    print(f"Paused at: {result.paused_at_node}")
    print(f"Current state: {result.state}")

    # Human reviews and resumes
    final = result.resume(human_input={"approved": True})
```

The checkpoint is persisted so `resume()` can be called from a different process or server.

### Visualization

Generate a Mermaid diagram of the graph:

```python
mermaid_str = graph.visualise()
print(mermaid_str)
# graph TD
#   analyze --> |quality < 0.8| improve
#   analyze --> |quality >= 0.8| approve
#   improve --> analyze
#   approve --> END
```

## AgentTeam

Multi-agent coordination with an orchestrator model.

### Auto Strategy

The orchestrator dynamically decides which agent handles each step:

```python
from synth import Agent, AgentTeam

researcher = Agent(
    model="gpt-4o",
    instructions="You research topics thoroughly.",
    tools=[search_web, search_papers],
)
coder = Agent(
    model="claude-sonnet-4-5",
    instructions="You write clean Python code.",
    tools=[run_code, write_file],
)
reviewer = Agent(
    model="claude-sonnet-4-5",
    instructions="You review code for bugs and style.",
)

team = AgentTeam(
    orchestrator="claude-sonnet-4-5",
    agents=[researcher, coder, reviewer],
    strategy="auto",
)

result = team.run("Build a CLI tool that converts CSV to JSON")
print(result.answer)              # Final synthesized answer
print(result.total_cost)          # Combined cost
print(result.total_latency_ms)    # Total time
for c in result.contributions:
    print(f"  {c.agent_name}: {c.result.text[:80]}...")
```

### Parallel Strategy

All agents receive the task concurrently:

```python
team = AgentTeam(
    orchestrator="claude-sonnet-4-5",
    agents=[analyst_a, analyst_b, analyst_c],
    strategy="parallel",
)
result = team.run("Analyze Q4 earnings report")
# All three analysts run concurrently, results aggregated
```

### Agent Handoff

A special `handoff(target_agent, context)` tool is automatically injected into each team agent. When called, it transfers control to the named agent:

```python
# The orchestrator or any agent can call:
# handoff(target_agent="coder", context="Please implement the search function")
```

### TeamResult

```python
result = team.run("Task description")
result.answer           # str: Final synthesized answer
result.contributions    # list[AgentContribution]: Each agent's RunResult
result.message_trace    # list[Message]: Full conversation history
result.total_cost       # float: Combined cost in USD
result.total_latency_ms # float: Total wall-clock time
```

### Testing Multi-Agent Projects in the UI

The browser testing dashboard (`synth create ui` or `synth ui main.py`) auto-detects `AgentTeam`, `Pipeline`, and `Graph` orchestration. When you send a prompt:

- Real-time delegation cards show which agent is running, with a running/done status badge
- Each agent's tool calls and output preview appear inline as they complete
- The final response includes a swimlane panel showing all agent contributions with tokens, cost, and latency per agent
- The sidebar shows the orchestration mode (team/pipeline/graph) and agent count

Point the UI at your `main.py` (which exports `team`, `pipeline`, or `graph`) rather than an individual agent file.

## Evaluation

Test agent quality with structured evaluations:

```python
from synth import Eval

eval_suite = Eval(agent=my_agent)

# Add test cases
eval_suite.add_case(
    input="What is 2+2?",
    expected="4",
)
eval_suite.add_case(
    input="Capital of France?",
    expected="Paris",
)

# Custom checker for fuzzy matching
eval_suite.add_case(
    input="Summarize this article...",
    expected="Key points about AI",
    checker=lambda output, expected: semantic_similarity(output, expected),
)

# Run evaluation
report = eval_suite.run()
print(f"Score: {report.overall_score:.1%}")
print(f"Cost: ${report.total_cost:.4f}")

# Compare against a baseline
comparison = report.compare(baseline_report)
print(f"Regressions: {len(comparison.regressions)}")
print(f"Improvements: {len(comparison.improvements)}")
```

### CLI Evaluation

```bash
synth eval my_agent.py --dataset cases.json
# Exits non-zero if pass rate below threshold
```
