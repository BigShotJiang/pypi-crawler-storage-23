"""Base provider ABC and provider-layer types.

Defines the abstract interface that all LLM provider adapters must implement,
along with the ``ProviderResponse`` and ``ProviderEvent`` types used to
communicate results back to the Agent layer.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator
from dataclasses import dataclass, field
from typing import Any, Literal, Union

from synth.types import Message, TokenUsage


# ---------------------------------------------------------------------------
# Provider response types
# ---------------------------------------------------------------------------


@dataclass
class ToolCallInfo:
    """A single tool-call request returned by the model."""

    id: str
    name: str
    args: dict[str, Any]


@dataclass
class ProviderResponse:
    """Structured response from a provider ``complete()`` call.

    Attributes
    ----------
    text:
        The model's text reply (may be empty if only tool calls were made).
    usage:
        Token counts for the request.
    tool_calls:
        Tool invocations requested by the model, if any.
    raw:
        The unmodified response object from the underlying SDK, useful for
        debugging or accessing provider-specific fields.
    """

    text: str
    usage: TokenUsage
    tool_calls: list[ToolCallInfo] = field(default_factory=list)
    raw: Any = None


# ---------------------------------------------------------------------------
# Provider streaming event types
# ---------------------------------------------------------------------------


@dataclass
class TextChunkEvent:
    """A chunk of text emitted during streaming."""

    text: str


@dataclass
class ThinkingChunkEvent:
    """A chunk of reasoning/thinking text emitted during streaming."""

    text: str


@dataclass
class ToolCallChunkEvent:
    """A tool-call request emitted during streaming."""

    id: str
    name: str
    args: dict[str, Any]


@dataclass
class ProviderDoneEvent:
    """Signals that the provider stream has completed."""

    usage: TokenUsage


@dataclass
class ProviderErrorEvent:
    """Signals that the provider stream encountered an error."""

    error: Exception


ProviderEvent = Union[
    TextChunkEvent,
    ThinkingChunkEvent,
    ToolCallChunkEvent,
    ProviderDoneEvent,
    ProviderErrorEvent,
]


# ---------------------------------------------------------------------------
# BaseProvider ABC
# ---------------------------------------------------------------------------


class BaseProvider(ABC):
    """Abstract base class for all LLM provider adapters.

    Every provider (Anthropic, OpenAI, Google, Ollama, Bedrock, custom) must
    subclass ``BaseProvider`` and implement :meth:`complete` and :meth:`stream`.
    """

    @abstractmethod
    async def complete(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> ProviderResponse:
        """Send a completion request and return the full response.

        Parameters
        ----------
        messages:
            Conversation history as a list of ``Message`` dicts.
        tools:
            Optional JSON-schema tool definitions the model may invoke.
        **kwargs:
            Provider-specific options (temperature, max_tokens, etc.).
        """
        ...

    @abstractmethod
    async def stream(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ProviderEvent, None]:
        """Send a streaming completion request.

        Yields ``ProviderEvent`` objects as the model generates output.

        Parameters
        ----------
        messages:
            Conversation history as a list of ``Message`` dicts.
        tools:
            Optional JSON-schema tool definitions the model may invoke.
        **kwargs:
            Provider-specific options (temperature, max_tokens, etc.).
        """
        ...  # pragma: no cover – abstract
