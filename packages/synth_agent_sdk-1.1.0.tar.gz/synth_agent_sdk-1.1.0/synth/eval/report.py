"""EvalReport and comparison logic for the Synth SDK.

Provides ``EvalReport`` with per-case results, overall score, cost, and
latency, plus ``compare()`` for identifying regressions and improvements.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# EvalCaseResult
# ---------------------------------------------------------------------------


@dataclass
class EvalCaseResult:
    """Result of a single evaluation case."""

    input: str
    expected: Any
    actual: str
    score: float
    passed: bool
    latency_ms: float
    cost: float


# ---------------------------------------------------------------------------
# EvalComparison
# ---------------------------------------------------------------------------


@dataclass
class EvalComparison:
    """Comparison between two EvalReports."""

    regressions: list[EvalCaseResult] = field(default_factory=list)
    improvements: list[EvalCaseResult] = field(default_factory=list)
    unchanged: list[EvalCaseResult] = field(default_factory=list)
    baseline_score: float = 0.0
    current_score: float = 0.0


# ---------------------------------------------------------------------------
# EvalReport
# ---------------------------------------------------------------------------


@dataclass
class EvalReport:
    """Report from an evaluation run.

    Attributes
    ----------
    cases:
        Per-case results.
    overall_score:
        Mean score across all cases.
    total_cost:
        Sum of cost across all cases.
    total_latency_ms:
        Sum of latency across all cases.
    """

    cases: list[EvalCaseResult] = field(default_factory=list)
    overall_score: float = 0.0
    total_cost: float = 0.0
    total_latency_ms: float = 0.0

    def compare(self, baseline: EvalReport) -> EvalComparison:
        """Compare this report against a baseline.

        Classifies each case as a regression (score decreased),
        improvement (score increased), or unchanged.

        Parameters
        ----------
        baseline:
            The baseline report to compare against.

        Returns
        -------
        EvalComparison
            Classification of each case.
        """
        regressions: list[EvalCaseResult] = []
        improvements: list[EvalCaseResult] = []
        unchanged: list[EvalCaseResult] = []

        baseline_map = {c.input: c for c in baseline.cases}

        for case in self.cases:
            base_case = baseline_map.get(case.input)
            if base_case is None:
                improvements.append(case)
                continue

            if case.score < base_case.score:
                regressions.append(case)
            elif case.score > base_case.score:
                improvements.append(case)
            else:
                unchanged.append(case)

        return EvalComparison(
            regressions=regressions,
            improvements=improvements,
            unchanged=unchanged,
            baseline_score=baseline.overall_score,
            current_score=self.overall_score,
        )
