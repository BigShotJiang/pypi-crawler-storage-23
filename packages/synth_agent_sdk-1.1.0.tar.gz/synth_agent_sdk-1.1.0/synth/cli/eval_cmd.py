"""``synth eval`` command — run evaluation suite against an agent."""

from __future__ import annotations

import json
import sys

import click

from synth.errors import SynthError


def run_eval(file: str, dataset: str, threshold: float) -> None:
    """Load agent, run eval cases from *dataset*, print report."""
    from synth.cli.run_cmd import _load_agent
    from synth.eval.eval import Eval

    try:
        agent = _load_agent(file)
        cases = _load_dataset(dataset)

        evaluator = Eval(agent=agent, pass_threshold=threshold)
        for case in cases:
            evaluator.add_case(
                input=case["input"],
                expected=case["expected"],
            )

        report = evaluator.run()

        # Print per-case results
        for case_result in report.cases:
            status = click.style("PASS", fg="green") if case_result.passed else click.style("FAIL", fg="red")
            click.echo(f"  [{status}] {case_result.input[:40]} -> score: {case_result.score:.2f}")

        # Print summary
        click.echo(f"\nOverall score: {report.overall_score:.2f}")
        click.echo(f"Pass rate: {sum(1 for c in report.cases if c.passed)}/{len(report.cases)}")

        # Exit code based on threshold
        pass_rate = sum(1 for c in report.cases if c.passed) / len(report.cases) if report.cases else 0.0
        if pass_rate < threshold:
            sys.exit(1)

    except SynthError as exc:
        click.echo(click.style(f"Error: {exc}", fg="red"), err=True)
        sys.exit(1)


def _load_dataset(path: str) -> list[dict]:
    """Load eval cases from a JSON file."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        click.echo(click.style("Dataset must be a JSON array.", fg="red"), err=True)
        sys.exit(1)
    return data
