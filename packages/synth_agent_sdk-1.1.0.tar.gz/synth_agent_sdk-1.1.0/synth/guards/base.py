"""Base guard abstraction and factory for the Synth SDK.

Defines ``BaseGuard``, the abstract base class that all guards must subclass,
and ``Guard``, a factory class with static methods that return concrete guard
instances.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Callable

from synth.types import GuardContext, GuardResult

if TYPE_CHECKING:
    from synth.guards.cost import CostGuard
    from synth.guards.custom import CustomGuard
    from synth.guards.pii import PIIGuard
    from synth.guards.tool_filter import ToolFilterGuard


class BaseGuard(ABC):
    """Abstract base class for all Synth guards.

    Guards are declarative constraints applied to an Agent's input or output.
    They enforce safety, cost, or policy rules and are evaluated in declaration
    order during a run.

    Subclasses must implement the async ``check()`` method.  Guard checks must
    be side-effect-free — they inspect content but do not modify it.

    Parameters
    ----------
    name:
        Human-readable name for this guard instance, used in error messages.
    """

    def __init__(self, name: str) -> None:
        self.name = name

    @abstractmethod
    async def check(self, content: str, context: GuardContext) -> GuardResult:
        """Evaluate the guard against the given content.

        Parameters
        ----------
        content:
            The text to inspect (agent input or output).
        context:
            Contextual information about the current run (cumulative cost,
            tool calls made so far, run ID).

        Returns
        -------
        GuardResult
            A result indicating whether the check passed and, if not, a
            violation message.
        """
        ...


class Guard:
    """Factory class for creating built-in guard instances.

    Usage::

        agent = Agent(
            model="claude-sonnet-4-5",
            guards=[
                Guard.no_pii_output(),
                Guard.max_cost(dollars=0.10),
                Guard.no_tool_calls(["delete_*"]),
                Guard.custom(my_check_fn),
            ],
        )
    """

    @staticmethod
    def no_pii_output() -> PIIGuard:
        """Create a guard that scans output for PII patterns.

        Returns
        -------
        PIIGuard
            A guard that raises ``GuardViolationError`` when PII (emails,
            phone numbers, SSNs, etc.) is detected in the response.
        """
        from synth.guards.pii import PIIGuard

        return PIIGuard()

    @staticmethod
    def max_cost(dollars: float) -> CostGuard:
        """Create a guard that enforces a cumulative cost limit.

        Parameters
        ----------
        dollars:
            Maximum allowed cost in USD for the run.

        Returns
        -------
        CostGuard
            A guard that raises ``CostLimitError`` when the cumulative cost
            exceeds the specified limit.
        """
        from synth.guards.cost import CostGuard

        return CostGuard(limit=dollars)

    @staticmethod
    def no_tool_calls(patterns: list[str]) -> ToolFilterGuard:
        """Create a guard that blocks tool calls matching glob patterns.

        Parameters
        ----------
        patterns:
            List of glob patterns (e.g. ``["delete_*"]``).  Any tool call
            whose name matches at least one pattern will be blocked.

        Returns
        -------
        ToolFilterGuard
            A guard that raises ``GuardViolationError`` when a blocked tool
            call is detected.
        """
        from synth.guards.tool_filter import ToolFilterGuard

        return ToolFilterGuard(patterns=patterns)

    @staticmethod
    def custom(fn: Callable[..., bool]) -> CustomGuard:
        """Create a guard from a user-supplied check function.

        Parameters
        ----------
        fn:
            A callable that receives the content string and returns ``True``
            if the check passes or ``False`` / raises an exception if it
            fails.

        Returns
        -------
        CustomGuard
            A guard that raises ``GuardViolationError`` when the function
            returns ``False`` or raises an exception.
        """
        from synth.guards.custom import CustomGuard

        return CustomGuard(fn=fn)
