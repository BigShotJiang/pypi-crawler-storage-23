"""AgentCore memory integration.

Routes memory operations to AgentCore's managed memory service when
available, falling back to the Synth-native Memory backend otherwise.
Uses the ``bedrock_agentcore.memory.MemoryClient`` for short-term
conversation storage via the events API.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from synth.errors import SynthConfigError
from synth.memory.base import BaseMemory
from synth.types import Message

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Role mapping between Synth and AgentCore
# ---------------------------------------------------------------------------

_SYNTH_ROLE_TO_AGENTCORE: dict[str, str] = {
    "user": "USER",
    "assistant": "ASSISTANT",
    "system": "SYSTEM",
    "tool": "TOOL",
}

_AGENTCORE_ROLE_TO_SYNTH: dict[str, str] = {
    v: k for k, v in _SYNTH_ROLE_TO_AGENTCORE.items()
}


# ---------------------------------------------------------------------------
# AgentCoreMemory
# ---------------------------------------------------------------------------


class AgentCoreMemory(BaseMemory):
    """Memory backend that delegates to AgentCore's managed memory.

    Uses the AgentCore events API for short-term conversation history.
    Each ``thread_id`` maps to an AgentCore ``session_id``, and messages
    are stored/retrieved as events.

    Falls back to a Synth-native backend if AgentCore memory is
    unavailable.  In production, refuses to fall back to unauthenticated
    local storage per security policy.

    Parameters
    ----------
    fallback:
        Optional Synth-native memory backend for fallback.
    memory_id:
        The AgentCore memory resource ID.  If omitted, read from
        ``AGENTCORE_MEMORY_ID`` environment variable.
    actor_id:
        Default actor identifier for events.  If omitted, read from
        ``AGENTCORE_ACTOR_ID`` or defaults to ``"synth-agent"``.
    region_name:
        AWS region for the AgentCore client.  If omitted, uses the
        SDK default resolution (env vars / instance metadata).
    max_turns:
        Maximum number of conversation turns to retrieve.  Defaults
        to ``50``.

    Raises
    ------
    SynthConfigError
        If AgentCore is unavailable and no fallback is configured.

    Examples
    --------
    ::

        from synth.deploy.agentcore.memory import AgentCoreMemory

        mem = AgentCoreMemory(memory_id="mem-abc123")
        msgs = await mem.get_messages("session-xyz")
    """

    def __init__(
        self,
        fallback: BaseMemory | None = None,
        memory_id: str | None = None,
        actor_id: str | None = None,
        region_name: str | None = None,
        max_turns: int = 50,
    ) -> None:
        self._fallback = fallback
        self._max_turns = max_turns
        self._memory_id = (
            memory_id or os.environ.get("AGENTCORE_MEMORY_ID")
        )
        self._actor_id = (
            actor_id
            or os.environ.get("AGENTCORE_ACTOR_ID", "synth-agent")
        )
        self._region_name = region_name
        self._client: Any | None = None
        self._agentcore_available = self._check_agentcore()

    # ------------------------------------------------------------------
    # Initialisation helpers
    # ------------------------------------------------------------------

    def _check_agentcore(self) -> bool:
        """Check if AgentCore memory service is available."""
        endpoint = os.environ.get("AGENTCORE_MEMORY_ENDPOINT")
        return endpoint is not None and self._memory_id is not None

    def _get_client(self) -> Any:
        """Lazily initialise and return the AgentCore MemoryClient.

        Raises
        ------
        SynthConfigError
            If the ``bedrock-agentcore`` package is not installed.
        """
        if self._client is not None:
            return self._client

        try:
            from bedrock_agentcore.memory import MemoryClient
        except ImportError:
            raise SynthConfigError(
                message=(
                    "Package 'bedrock-agentcore' is not installed. "
                    "Run: pip install synth-agent-sdk[agentcore]"
                ),
                component="AgentCoreMemory",
                suggestion="pip install synth-agent-sdk[agentcore]",
            )

        self._client = MemoryClient(region_name=self._region_name)
        return self._client

    # ------------------------------------------------------------------
    # BaseMemory interface
    # ------------------------------------------------------------------

    async def get_messages(self, thread_id: str) -> list[Message]:
        """Retrieve conversation history from AgentCore or fallback.

        Fetches the last ``max_turns`` turns from the AgentCore events
        API and converts them into Synth ``Message`` dicts.

        Parameters
        ----------
        thread_id:
            Unique identifier for the conversation thread.  Maps to
            the AgentCore ``session_id``.

        Returns
        -------
        list[Message]
            Ordered list of messages in the thread.
        """
        if self._agentcore_available:
            return await self._get_agentcore_messages(thread_id)

        if self._fallback is not None:
            return await self._fallback.get_messages(thread_id)

        raise SynthConfigError(
            message="No memory backend available in AgentCore deployment.",
            component="AgentCoreMemory",
            suggestion=(
                "Configure AGENTCORE_MEMORY_ENDPOINT and "
                "AGENTCORE_MEMORY_ID, or provide a fallback memory "
                "backend."
            ),
        )

    async def add_messages(
        self, thread_id: str, messages: list[Message],
    ) -> None:
        """Store messages in AgentCore or fallback.

        Creates an event in AgentCore containing the supplied messages.

        Parameters
        ----------
        thread_id:
            Unique identifier for the conversation thread.  Maps to
            the AgentCore ``session_id``.
        messages:
            Messages to append.
        """
        if self._agentcore_available:
            await self._add_agentcore_messages(thread_id, messages)
            return

        if self._fallback is not None:
            await self._fallback.add_messages(thread_id, messages)
            return

        raise SynthConfigError(
            message="No memory backend available in AgentCore deployment.",
            component="AgentCoreMemory",
            suggestion=(
                "Configure AGENTCORE_MEMORY_ENDPOINT and "
                "AGENTCORE_MEMORY_ID, or provide a fallback memory "
                "backend."
            ),
        )

    # ------------------------------------------------------------------
    # AgentCore API helpers
    # ------------------------------------------------------------------

    async def _get_agentcore_messages(
        self, thread_id: str,
    ) -> list[Message]:
        """Fetch conversation turns from AgentCore and convert to Messages."""
        import asyncio

        client = self._get_client()

        try:
            turns = await asyncio.to_thread(
                client.get_last_k_turns,
                memory_id=self._memory_id,
                actor_id=self._actor_id,
                session_id=thread_id,
                k=self._max_turns,
            )
        except Exception as exc:
            logger.warning(
                "AgentCore memory retrieval failed for session '%s': %s. "
                "Falling back to empty history.",
                thread_id,
                exc,
            )
            if self._fallback is not None:
                return await self._fallback.get_messages(thread_id)
            return []

        messages: list[Message] = []
        for turn in turns:
            for entry in turn:
                role_raw = entry.get("role", "USER")
                content = entry.get("content", {}).get("text", "")
                synth_role = _AGENTCORE_ROLE_TO_SYNTH.get(
                    role_raw, "user",
                )
                messages.append(
                    {"role": synth_role, "content": content},
                )

        return messages

    async def _add_agentcore_messages(
        self, thread_id: str, messages: list[Message],
    ) -> None:
        """Store messages as an AgentCore event."""
        import asyncio

        if not messages:
            return

        client = self._get_client()

        ac_messages: list[tuple[str, str]] = []
        for msg in messages:
            role = _SYNTH_ROLE_TO_AGENTCORE.get(
                msg["role"], "USER",
            )
            ac_messages.append((msg["content"], role))

        try:
            await asyncio.to_thread(
                client.create_event,
                memory_id=self._memory_id,
                actor_id=self._actor_id,
                session_id=thread_id,
                messages=ac_messages,
            )
        except Exception as exc:
            logger.warning(
                "AgentCore memory storage failed for session '%s': %s. "
                "Attempting fallback.",
                thread_id,
                exc,
            )
            if self._fallback is not None:
                await self._fallback.add_messages(thread_id, messages)
                return
            raise SynthConfigError(
                message=(
                    f"Failed to store messages in AgentCore memory: "
                    f"{exc}"
                ),
                component="AgentCoreMemory",
                suggestion=(
                    "Check AGENTCORE_MEMORY_ENDPOINT, "
                    "AGENTCORE_MEMORY_ID, and IAM permissions."
                ),
            ) from exc
