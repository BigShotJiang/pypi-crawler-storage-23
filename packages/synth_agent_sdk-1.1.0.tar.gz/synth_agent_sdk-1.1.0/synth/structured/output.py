"""Pydantic schema enforcement and retry parsing for structured output.

The ``StructuredOutputHandler`` instructs the model to produce JSON conforming
to a Pydantic schema, parses the response, and retries with corrective prompts
on failure.
"""

from __future__ import annotations

import json
from typing import Any

from pydantic import BaseModel, ValidationError

from synth.errors import SynthParseError
from synth.providers.base import BaseProvider
from synth.types import Message


class StructuredOutputHandler:
    """Enforce structured output from an LLM via a Pydantic schema.

    Parameters
    ----------
    schema:
        The Pydantic model class that the model output must conform to.
    max_retries:
        Maximum number of retry attempts when parsing fails.  The handler
        makes up to ``max_retries`` additional provider calls with corrective
        prompts before raising ``SynthParseError``.
    """

    def __init__(self, schema: type[BaseModel], max_retries: int = 3) -> None:
        self._schema = schema
        self._max_retries = max_retries

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    def get_system_message(self) -> str:
        """Return a system message instructing the model to output JSON.

        The message includes the full JSON Schema derived from the Pydantic
        model via ``model_json_schema()``.
        """
        json_schema = self._schema.model_json_schema()
        return (
            "You must respond with valid JSON that conforms to this schema:\n"
            f"{json.dumps(json_schema, indent=2)}\n"
            "Output ONLY the JSON, no other text."
        )

    def parse(self, raw_output: str) -> BaseModel:
        """Parse *raw_output* into a validated Pydantic model instance.

        Parameters
        ----------
        raw_output:
            The raw string returned by the model.

        Returns
        -------
        BaseModel
            An instance of the configured schema.

        Raises
        ------
        json.JSONDecodeError
            If *raw_output* is not valid JSON.
        ValidationError
            If the JSON does not conform to the schema.
        """
        data = json.loads(raw_output)
        return self._schema.model_validate(data)

    async def parse_and_validate(
        self,
        raw_output: str,
        provider: BaseProvider,
        messages: list[Message],
    ) -> BaseModel:
        """Parse output, retrying with corrective prompts on failure.

        On each failed parse attempt the handler appends the invalid output
        and a corrective user message to *messages*, then calls the provider
        again.  After ``max_retries`` failed attempts a ``SynthParseError``
        is raised.

        Parameters
        ----------
        raw_output:
            The initial raw string returned by the model.
        provider:
            The LLM provider to call for retries.
        messages:
            The conversation history (mutated in-place on retries).

        Returns
        -------
        BaseModel
            A validated instance of the configured schema.

        Raises
        ------
        SynthParseError
            If parsing fails after all retry attempts are exhausted.
        """
        for attempt in range(self._max_retries + 1):
            try:
                return self.parse(raw_output)
            except (json.JSONDecodeError, ValidationError) as exc:
                if attempt >= self._max_retries:
                    raise SynthParseError(
                        message=(
                            f"Failed to parse output as {self._schema.__name__} "
                            f"after {self._max_retries} retries: {exc}"
                        ),
                        component="StructuredOutputHandler",
                        suggestion=(
                            f"Check that the model can produce valid "
                            f"{self._schema.__name__} JSON."
                        ),
                    ) from exc

                # Append corrective messages and retry via the provider.
                messages.append({"role": "assistant", "content": raw_output})
                messages.append(
                    {
                        "role": "user",
                        "content": (
                            "Your output was not valid JSON conforming to the "
                            f"schema. Error: {exc}. Please try again."
                        ),
                    }
                )
                response = await provider.complete(messages)
                raw_output = response.text

        # Unreachable — the loop always returns or raises — but satisfies
        # type checkers and defensive coding.
        raise SynthParseError(
            message=f"Failed to parse output as {self._schema.__name__}",
            component="StructuredOutputHandler",
            suggestion=f"Check that the model can produce valid {self._schema.__name__} JSON.",
        )
