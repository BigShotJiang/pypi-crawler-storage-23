---
inclusion: fileMatch
fileMatchPattern: "synth/deploy/*"
---

# AgentCore Deployment Guide

Rules for implementing and modifying the AWS AgentCore deployment layer in `synth/deploy/`.

## Module Responsibilities

- `agentcore/adapter.py` — `AgentCoreAdapter` class that translates between AgentCore
  invocation payloads and Synth's `run()` input/output format. This is the core bridge.
- `agentcore/handler.py` — `@agentcore_handler` decorator that wraps an `Agent` or `Graph`
  into an AgentCore-compatible request handler conforming to the runtime invocation contract.
- `agentcore/manifest.py` — generates or updates the AgentCore agent descriptor (manifest)
  declaring the agent's name, description, supported actions, and required IAM permissions.
- `agentcore/memory.py` — integrates with AgentCore's managed memory service for session
  and long-term memory, falling back to Synth-native Memory if AgentCore memory is
  unavailable.
- `packager.py` — packages agent code, dependencies, and configuration into a deployment
  artifact suitable for AgentCore.

## Payload Translation

- `AgentCoreAdapter.handle_invocation(payload: dict) -> dict` MUST:
  1. Validate the incoming payload against an expected schema. Reject malformed payloads
     with a clear error, not an unhandled exception.
  2. Extract the prompt/input from the AgentCore payload format.
  3. Call `agent.arun()` or `graph.arun()` with the translated input.
  4. Translate the `RunResult` back into AgentCore's response format.
  5. Include trace metadata in the response for AgentCore's observability infrastructure.

## Credential Handling

- When running inside AgentCore, ALWAYS use the runtime-provided IAM credentials.
  Never accept or bundle static AWS credentials in the deployment artifact.
- The adapter MUST integrate with AgentCore's identity and authorization model so that
  tools requiring AWS service access use runtime credentials automatically.
- The `BedrockProvider` is the natural choice for agents deployed to AgentCore since it
  uses IAM credentials from the environment.

## Memory Integration

- When AgentCore's managed memory service is available, route all memory operations
  through it instead of Synth-native backends.
- If AgentCore memory is unavailable, fall back to the Synth-native Memory backend
  configured on the agent.
- In production deployments, MUST NOT silently fall back to unauthenticated local storage.
  If no memory backend is available, fail explicitly with a `SynthConfigError`.

## Manifest Generation

- `generate_manifest()` MUST produce a valid AgentCore agent descriptor with:
  - Agent name and description (derived from the Agent's `instructions` or explicit config)
  - Supported actions
  - Required IAM permissions — follow least-privilege. Only request permissions that the
    agent's tools actually require.
- The manifest MUST be deterministic — same agent config produces the same manifest.

## Checkpointing in AgentCore

- When a Graph-based agent is deployed to AgentCore with checkpointing enabled, use
  AgentCore's managed state persistence instead of local disk or self-managed Redis.
- The `BaseCheckpointStore` interface is the abstraction point — implement an
  `AgentCoreCheckpointStore` that delegates to the managed service.

## Packaging Rules

- `synth deploy --target agentcore` packages code + dependencies into a deployment artifact.
- The packager MUST NOT bundle `.env` files, credential files, `.synth/checkpoints/`,
  or `.hypothesis/` directories.
- `synth deploy --target agentcore --dry-run` validates configuration and IAM permissions
  without actually deploying.
- If `synth[agentcore]` extra is not installed, raise `SynthConfigError` with the exact
  `pip install synth-agent-sdk[agentcore]` command.

## Trace Forwarding

- When running in AgentCore, forward trace data to AgentCore's built-in observability
  infrastructure in addition to any Synth-configured trace endpoints
  (`SYNTH_TRACE_ENDPOINT`).
- Use the standard `Trace` and `TraceSpan` types — don't create AgentCore-specific
  trace types.

## Error Handling

- All errors in the deploy layer MUST be `SynthError` subclasses.
- `SynthConfigError` for missing `synth[agentcore]` extra, invalid manifest config,
  or IAM permission issues.
- Payload validation errors MUST return structured error responses, not raw exceptions.
