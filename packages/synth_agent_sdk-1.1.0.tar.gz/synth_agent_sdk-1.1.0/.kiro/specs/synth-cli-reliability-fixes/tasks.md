# Implementation Plan: Synth CLI Reliability Fixes

## Overview

Incremental fixes across agent loading, CLI commands, UI server, Bedrock provider, and deployment pipeline. Each task builds on the previous and ends with wiring into the existing codebase. Tests are co-located with their implementation tasks.

## Tasks

- [x] 1. Centralize sys.path injection in Agent Loader
  - [x] 1.1 Update `_load_agent` in `synth/cli/run_cmd.py` to prepend the agent file's parent directory to `sys.path` before `spec.loader.exec_module(module)`, guarded by `if agent_dir not in sys.path`
    - _Requirements: 1.1, 1.2, 1.4_
  - [x] 1.2 Update `_load_agent_module` in `synth/cli/_tui.py` with the same sys.path injection logic
    - _Requirements: 1.1, 1.3_
  - [x] 1.3 Write property tests for sys.path injection (Properties 1 and 2)
    - **Property 1: sys.path injection ensures parent directory is present**
    - **Property 2: sys.path injection is idempotent**
    - **Validates: Requirements 1.1, 1.2, 1.3**
  - [x] 1.4 Write unit tests for agent loading edge cases
    - Test non-existent file path raises clear error
    - Test duplicate sys.path prevention
    - _Requirements: 1.5_

- [x] 2. Add `synth ui` CLI command
  - [x] 2.1 Update `AGENT_FILE` in `synth/cli/_ui_assets/server.py` to read from `os.environ.get("SYNTH_AGENT_FILE", "../agent.py")`
    - _Requirements: 2.2_
  - [x] 2.2 Add `ui_cmd` to `synth/cli/main.py` that launches the UI server subprocess using `sys.executable`, passing `SYNTH_AGENT_FILE` env var, with agent discovery fallback when file is omitted
    - _Requirements: 2.1, 2.2, 2.4, 2.5_
  - [x] 2.3 Write unit tests for `synth ui` command
    - Test subprocess uses `sys.executable`
    - Test `SYNTH_AGENT_FILE` env var is set
    - Test missing dependency error message
    - _Requirements: 2.1, 2.2, 2.3_

- [x] 3. Venv-aware UI launch in init flow
  - [x] 3.1 Add `_is_in_venv()` helper to `synth/cli/init_cmd.py` and update `_prompt_testing_mode` to pass `SYNTH_AGENT_FILE` in the subprocess environment when launching the UI server
    - _Requirements: 3.1, 3.2, 3.3, 3.4_
  - [x] 3.2 Write property test for venv detection (Property 3)
    - **Property 3: Venv detection correctness**
    - **Validates: Requirements 3.1**
  - [x] 3.3 Write unit tests for init flow UI launch
    - Test `SYNTH_AGENT_FILE` is passed in subprocess env
    - Test both single-agent and multi-agent flows use same logic
    - _Requirements: 3.2, 3.3, 3.4_

- [x] 4. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.
  

- [x] 5. UI server feature parity fixes
  - [x] 5.1 Update `/api/chat/stream` and `/api/chat` endpoints in `synth/cli/_ui_assets/server.py` to pass `thread_id=conv_id` to `_agent.run()` and `_agent.stream()`
    - _Requirements: 4.1, 4.2_
  - [x] 5.2 Replace the buffered `list(_agent.stream(prompt))` pattern in the streaming endpoint with a queue-based approach that yields events as they arrive from a background thread
    - _Requirements: 4.3_
  - [x] 5.3 Replace string-based `type(event).__name__` checks with `isinstance()` checks using imported event types from `synth.types`
    - _Requirements: 4.5_
  - [x] 5.4 Surface tool initialization errors in `_load_agent()` by catching exceptions during tool registration and storing them in `_agent_status["tool_errors"]`, exposed via `/api/info`
    - _Requirements: 4.4_
  - [x] 5.5 Write property tests for thread_id consistency and tool result serialization (Properties 4 and 5)
    - **Property 4: Thread ID consistency across conversation turns**
    - **Property 5: Tool result serialization completeness**
    - **Validates: Requirements 4.1, 4.2, 4.6**
  - [x] 5.6 Write unit tests for UI server fixes
    - Test isinstance-based event detection with actual event instances
    - Test tool error surfacing in /api/info
    - Test streaming yields events incrementally
    - _Requirements: 4.3, 4.4, 4.5_

- [x] 6. Bedrock content block sanitization
  - [x] 6.1 Add `_sanitize_content(text: str) -> str` helper to `synth/agent.py` and apply it to tool result content in both `arun` and `astream` message appends
    - _Requirements: 5.4, 5.5_
  - [x] 6.2 Write property test for content sanitization (Property 6)
    - **Property 6: Content block sanitization**
    - **Validates: Requirements 5.1, 5.2, 5.3**
  - [x] 6.3 Write unit tests for content sanitization
    - Test empty string, None, whitespace-only, and normal string inputs
    - Test that arun and astream apply sanitization to tool results
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

- [x] 7. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 8. AgentCore deployment name validation
  - [x] 8.1 Add `_stage_dockerfile_validation(agent_name: str, file: str) -> StageResult` to `synth/cli/deploy_cmd.py` that checks `.bedrock_agentcore/` for a matching folder, returning failure with available folder names when no match is found, and skipping when the directory does not exist
    - _Requirements: 6.2, 6.3, 6.5_
  - [x] 8.2 Wire `_stage_dockerfile_validation` into `run_deploy` between Stage 4 (manifest) and Stage 5 (packaging), printing the result with `_print_stage_result`
    - _Requirements: 6.1, 6.2_
  - [x] 8.3 Write property tests for name validation and sanitization (Properties 7, 8, and 9)
    - **Property 7: Agent name validation accepts only valid names**
    - **Property 8: Dockerfile folder mismatch error includes all available folders**
    - **Property 9: Agent name sanitization produces valid names**
    - **Validates: Requirements 6.1, 6.3, 6.4**
  - [x] 8.4 Write unit tests for Dockerfile folder validation
    - Test matching folder returns success
    - Test non-matching folder returns failure with suggestions
    - Test missing .bedrock_agentcore/ directory skips validation
    - _Requirements: 6.2, 6.3, 6.5_

- [x] 9. Final checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties using Hypothesis
- Unit tests validate specific examples and edge cases
- All property tests go in `tests/property/test_cli_reliability_props.py`
- All unit tests go in existing test files or `tests/unit/test_cli_reliability.py`
