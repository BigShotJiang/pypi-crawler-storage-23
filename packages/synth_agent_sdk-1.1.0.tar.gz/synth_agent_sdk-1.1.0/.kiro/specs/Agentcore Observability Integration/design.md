# Design Document: AgentCore Evaluations Integration

## Overview

This design covers two new capabilities added to the Synth SDK's AgentCore observability feature:

1. **Init Flow Evaluations Wiring (Requirement 13)**: When a developer runs `synth init` with the AgentCore provider and selects the "eval" feature, the init wizard generates AgentCore Evaluations configuration files (`eval_config.json`, updated `agentcore.yaml`) alongside the existing local `eval_dataset.json`. This gives developers a ready-to-use online evaluation setup from project creation.

2. **Dashboard Evaluations Integration (Requirement 14)**: The observability tab in the Dashboard gains an "Evaluations" sub-section that displays evaluation scores from AgentCore's Evaluations API, shows online evaluation configuration status, and allows triggering on-demand evaluations.

Both capabilities build on the existing `_build_agentcore_yaml` function in `init_cmd.py`, the `_parse_agentcore_yaml` function in `server.py`, and the `AgentCore_Client` service defined in Requirements 1–12.

## Architecture

```mermaid
graph TD
    subgraph "synth init"
        A[run_init / run_multi_init] --> B{provider == agentcore<br/>AND eval in features?}
        B -->|Yes| C[_build_eval_config]
        B -->|Yes| D[_build_agentcore_yaml<br/>+ evaluations section]
        B -->|Yes| E[Write eval_dataset.json]
        B -->|No agentcore| E
        C --> F[Write eval_config.json]
    end

    subgraph "Dashboard Server"
        G[GET /api/agentcore/evaluations] --> H[AgentCore_Client]
        I[POST /api/agentcore/evaluations/run] --> H
        J[GET /api/agentcore/evaluations/config] --> H
        H --> K[boto3 bedrock-agentcore API]
    end

    subgraph "Dashboard UI"
        L[Evaluations Sub-section] --> G
        L --> I
        L --> J
    end
```

The init flow changes are purely additive — they extend `_generate_project` and `_generate_multi_agent_project` with conditional evaluation config generation. The dashboard changes add three new API endpoints and a new UI sub-section within the existing "AgentCore" tab.

## Components and Interfaces

### 1. Init Flow: `_build_eval_config()`

New function in `synth/cli/init_cmd.py` that generates the `eval_config.json` content.

```python
def _build_eval_config(
    agent_name: str,
    sampling_rate: float = 1.0,
) -> str:
    """Build eval_config.json with default AgentCore Evaluations settings.

    Parameters
    ----------
    agent_name:
        The project/agent name for the config name field.
    sampling_rate:
        Sampling rate for online evaluation (0.01 to 1.0).

    Returns
    -------
    str
        JSON string for eval_config.json.
    """
```

### 2. Init Flow: `_build_agentcore_yaml()` Extension

The existing `_build_agentcore_yaml` function gains an optional `features` parameter. When `"eval"` is in the features list, it appends an `evaluations` section and additional IAM permissions.

```python
def _build_agentcore_yaml(
    name: str,
    setup: dict[str, Any],
    features: list[str] | None = None,
) -> str:
```

### 3. Init Flow: `_validate_evaluator_arns()`

New helper that validates evaluator ARN patterns and emits warnings via `click.echo`.

```python
def _validate_evaluator_arns(arns: list[str]) -> list[str]:
    """Validate evaluator ARNs match the expected Builtin pattern.

    Parameters
    ----------
    arns:
        List of evaluator ARN strings.

    Returns
    -------
    list[str]
        List of warning messages for invalid ARNs (empty if all valid).
    """
```

### 4. Dashboard Server: Evaluation Endpoints

Three new FastAPI endpoints in `synth/cli/_ui_assets/server.py`:

```python
@app.get("/api/agentcore/evaluations")
async def get_evaluations() -> JSONResponse:
    """Return evaluation scores from AgentCore Evaluations API."""

@app.post("/api/agentcore/evaluations/run")
async def run_on_demand_evaluation(request: Request) -> JSONResponse:
    """Trigger an on-demand evaluation against the most recent session."""

@app.get("/api/agentcore/evaluations/config")
async def get_evaluation_config() -> JSONResponse:
    """Return the current online evaluation configuration status."""
```

### 5. Dashboard Server: `_parse_eval_config()`

New helper in `server.py` that reads `eval_config.json` from the agent directory.

```python
def _parse_eval_config() -> dict[str, Any] | None:
    """Parse eval_config.json from the agent file directory, if present."""
```

### 6. Dashboard UI: Evaluations Sub-section

New HTML/JS section within the AgentCore tab in `synth/cli/_ui_assets/static/`. Renders:
- Summary table of most recent evaluator scores
- Online evaluation config status (active/disabled, sampling rate, evaluator list)
- "Run Evaluation" button for on-demand evaluation

## Data Models

### EvalConfig (eval_config.json)

```json
{
  "config_name": "my-agent-online-eval",
  "sampling_rate": 1.0,
  "evaluators": [
    {
      "id": "Builtin.Helpfulness",
      "arn": "arn:aws:bedrock-agentcore:::evaluator/Builtin.Helpfulness",
      "level": "TRACE"
    },
    {
      "id": "Builtin.Correctness",
      "arn": "arn:aws:bedrock-agentcore:::evaluator/Builtin.Correctness",
      "level": "TRACE"
    },
    {
      "id": "Builtin.GoalSuccessRate",
      "arn": "arn:aws:bedrock-agentcore:::evaluator/Builtin.GoalSuccessRate",
      "level": "SESSION"
    }
  ]
}
```

### agentcore.yaml Evaluations Section

```yaml
# Evaluations Configuration
evaluations:
  config_name: my-agent-online-eval
  sampling_rate: 1.0
  evaluators:
    - "Builtin.Helpfulness"
    - "Builtin.Correctness"
    - "Builtin.GoalSuccessRate"
```

### EvaluationResult (API response dataclass)

```python
@dataclass
class EvaluationResult:
    """A single evaluation score from AgentCore Evaluations."""
    evaluator_name: str
    score: float
    level: str  # "SESSION", "TRACE", or "TOOL_CALL"
    timestamp: str  # ISO 8601
```

### EvaluationConfigStatus (API response dataclass)

```python
@dataclass
class EvaluationConfigStatus:
    """Online evaluation configuration status."""
    config_name: str
    active: bool
    sampling_rate: float
    evaluators: list[str]
```

### IAM Permissions for Evaluations

Added to the `permissions` list in `agentcore.yaml` when eval is enabled:

```yaml
permissions:
  # ... existing permissions ...
  - "bedrock-agentcore:CreateEvaluationConfig"
  - "bedrock-agentcore:RunEvaluation"
  - "bedrock-agentcore:GetEvaluationResults"
  - "logs:CreateLogGroup"
  - "logs:PutLogEvents"
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: eval_config.json contains required default evaluators

*For any* valid agent name, calling `_build_eval_config(agent_name)` SHALL produce valid JSON containing a `sampling_rate` of 1.0 and exactly three evaluator entries with IDs `Builtin.Helpfulness`, `Builtin.Correctness`, and `Builtin.GoalSuccessRate`, each with a valid ARN matching `arn:aws:bedrock-agentcore:::evaluator/Builtin.*`.

**Validates: Requirements 13.1**

### Property 2: agentcore.yaml includes evaluations section and IAM permissions when eval enabled

*For any* valid agent name and setup dict, calling `_build_agentcore_yaml(name, setup, features=["eval"])` SHALL produce output containing an `evaluations:` section with `config_name`, `sampling_rate`, and `evaluators` fields, AND the permissions list SHALL include `bedrock-agentcore:CreateEvaluationConfig`, `bedrock-agentcore:RunEvaluation`, `bedrock-agentcore:GetEvaluationResults`, `logs:CreateLogGroup`, and `logs:PutLogEvents`.

**Validates: Requirements 13.2, 13.3**

### Property 3: Agent code references eval_config.json when agentcore + eval enabled

*For any* valid agent configuration with provider "agentcore" and "eval" in features, the generated agent code SHALL contain a comment referencing `eval_config.json`.

**Validates: Requirements 13.4**

### Property 4: Non-agentcore providers produce no AgentCore evaluation config

*For any* provider that is not "agentcore", calling `_build_agentcore_yaml` is not invoked, and `_build_eval_config` is not called. The only eval artifact generated SHALL be `eval_dataset.json`. No `eval_config.json` content is produced.

**Validates: Requirements 13.6**

### Property 5: Evaluator ARN validation detects invalid patterns

*For any* string that does not match the pattern `arn:aws:bedrock-agentcore:::evaluator/Builtin.*`, `_validate_evaluator_arns` SHALL return a non-empty list of warnings. *For any* string that matches the pattern, `_validate_evaluator_arns` SHALL return an empty list.

**Validates: Requirements 13.7**

### Property 6: Evaluation results response contains all required fields

*For any* set of evaluation data returned by the AgentCore Evaluations API, the `/api/agentcore/evaluations` endpoint response SHALL contain objects where each object includes `evaluator_name` (non-empty string), `score` (float), `level` (one of "SESSION", "TRACE", "TOOL_CALL"), and `timestamp` (ISO 8601 string).

**Validates: Requirements 14.2**

### Property 7: Evaluation config status contains all required fields

*For any* valid eval_config.json, the `/api/agentcore/evaluations/config` endpoint response SHALL contain `config_name` (non-empty string), `active` (boolean), `sampling_rate` (float between 0.0 and 1.0), and `evaluators` (non-empty list of strings).

**Validates: Requirements 14.5**

### Property 8: Credential scrubbing removes all credential patterns from evaluation data

*For any* evaluation response string containing AWS access key patterns (AKIA/ASIA + 16 alphanumeric chars) or secret key patterns (40-char base64-like strings), applying `CredentialResolver.redact_credentials()` SHALL produce output containing zero matches for those patterns.

**Validates: Requirements 14.7**

## Error Handling

### Init Flow Errors

| Condition | Error Type | Component | Behavior |
|---|---|---|---|
| `json.dumps` fails on eval config | `SynthConfigError` | `InitWizard` | Abort project generation with actionable message |
| Invalid evaluator ARN pattern | Warning via `click.echo` | `InitWizard` | Emit warning, continue generation (non-fatal) |

### Dashboard Server Errors

| Condition | Error Type | Behavior |
|---|---|---|
| `eval_config.json` missing or unparseable | Return `None` from `_parse_eval_config()` | Dashboard hides Evaluations sub-section silently (Req 14.6) |
| AgentCore Evaluations API unreachable | Return structured error JSON with `"error"` key | Dashboard shows retry option (follows Req 10.3 pattern) |
| AgentCore Evaluations API returns error | Return structured error JSON with `"error"` key | Dashboard displays error message without credential details |
| `synth[agentcore]` not installed | Endpoint not registered | Dashboard hides AgentCore tab entirely (follows Req 10.1 pattern) |
| Credential patterns in evaluation response | Scrubbed by `CredentialResolver.redact_credentials()` | No credential data reaches the Dashboard (Req 14.7) |

All errors follow the existing SDK pattern: `SynthError` subclasses with `component` and `suggestion` kwargs. Dashboard API errors return `JSONResponse` with status codes and structured error bodies, never raw tracebacks.

## Testing Strategy

### Property-Based Testing

Use `hypothesis` (already a dev dependency) for property-based tests. Each property test runs a minimum of 100 iterations.

| Property | Test File | Strategy |
|---|---|---|
| Property 1: eval_config.json defaults | `tests/property/test_prop_eval_config.py` | Generate random agent names via `st.text(min_size=1, max_size=50)`, verify JSON structure |
| Property 2: agentcore.yaml eval section | `tests/property/test_prop_eval_config.py` | Generate random names + setup dicts, verify yaml output contains evaluations section and permissions |
| Property 3: Agent code eval comment | `tests/property/test_prop_eval_config.py` | Generate random agent configs with agentcore provider, verify comment presence |
| Property 4: Non-agentcore no eval config | `tests/property/test_prop_eval_config.py` | Generate random non-agentcore providers, verify no eval_config content |
| Property 5: ARN validation | `tests/property/test_prop_eval_config.py` | Generate random strings, partition into valid/invalid ARNs, verify warning behavior |
| Property 6: Evaluation results shape | `tests/property/test_prop_eval_config.py` | Generate random evaluation data dicts, verify response shape through endpoint |
| Property 7: Config status shape | `tests/property/test_prop_eval_config.py` | Generate random eval configs, verify response shape |
| Property 8: Credential scrubbing | `tests/property/test_prop_eval_config.py` | Generate strings with embedded credential patterns, verify scrubbing removes all |

Tag format: `# Feature: agentcore-live-observability, Property N: <title>`

### Unit Testing

Unit tests in `tests/unit/test_eval_config.py`:

- `TestBuildEvalConfig`: Verify default JSON structure, sampling rate, evaluator count
- `TestBuildAgentcoreYamlWithEval`: Verify evaluations section added when eval in features, omitted when not
- `TestValidateEvaluatorArns`: Verify valid ARNs pass, invalid ARNs produce warnings
- `TestParseEvalConfig`: Verify parsing of valid/invalid/missing eval_config.json
- `TestGenerateProjectEvalFiles`: Verify correct files created for agentcore+eval vs non-agentcore+eval
- `TestEvaluationEndpoints`: Verify API response shapes, error handling, credential scrubbing

Edge cases to cover:
- Empty agent name
- eval_config.json with malformed JSON
- agentcore.yaml with evaluations section but missing fields
- Evaluation API returning empty results
- Evaluation API returning results with credential patterns embedded
