"""Unit tests for synth.deploy.agentcore.handler.

Covers ``agentcore_handler`` — BedrockAgentCoreApp creation, entrypoint
registration, adapter integration, and error paths.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from synth.errors import SynthConfigError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_mock_agent() -> AsyncMock:
    """Return a mock agent with an ``arun`` async method."""
    agent = AsyncMock()
    agent.arun.return_value = MagicMock(
        text="response",
        tokens=MagicMock(input_tokens=10, output_tokens=20, total_tokens=30),
        cost=0.005,
        latency_ms=100.0,
    )
    return agent


def _make_mock_bedrock_app() -> MagicMock:
    """Return a mock BedrockAgentCoreApp instance."""
    app = MagicMock()
    # Mock the entrypoint decorator to capture the handler function
    def entrypoint_decorator(func):
        app._registered_handler = func
        return func
    app.entrypoint = entrypoint_decorator
    return app


# ---------------------------------------------------------------------------
# Import Error Handling
# ---------------------------------------------------------------------------


class TestAgentCoreHandlerImportError:
    """Tests for missing bedrock-agentcore package."""

    def test_raises_synth_config_error_when_package_missing(self):
        """Missing bedrock-agentcore raises SynthConfigError with install command."""
        from synth.deploy.agentcore.handler import agentcore_handler

        agent = _make_mock_agent()

        with patch.dict("sys.modules", {"bedrock_agentcore": None}):
            with patch("builtins.__import__", side_effect=ImportError):
                with pytest.raises(SynthConfigError) as exc_info:
                    agentcore_handler(agent)

        assert "bedrock-agentcore" in str(exc_info.value)
        assert "pip install synth-agent-sdk[agentcore]" in str(exc_info.value)

    def test_error_component_is_agentcore_handler(self):
        """Error component should be 'agentcore_handler'."""
        from synth.deploy.agentcore.handler import agentcore_handler

        agent = _make_mock_agent()

        with patch.dict("sys.modules", {"bedrock_agentcore": None}):
            with patch("builtins.__import__", side_effect=ImportError):
                with pytest.raises(SynthConfigError) as exc_info:
                    agentcore_handler(agent)

        assert exc_info.value.component == "agentcore_handler"

    def test_error_suggestion_contains_install_command(self):
        """Error suggestion should contain the pip install command."""
        from synth.deploy.agentcore.handler import agentcore_handler

        agent = _make_mock_agent()

        with patch.dict("sys.modules", {"bedrock_agentcore": None}):
            with patch("builtins.__import__", side_effect=ImportError):
                with pytest.raises(SynthConfigError) as exc_info:
                    agentcore_handler(agent)

        assert exc_info.value.suggestion == "pip install synth-agent-sdk[agentcore]"


# ---------------------------------------------------------------------------
# BedrockAgentCoreApp Creation
# ---------------------------------------------------------------------------


class TestAgentCoreHandlerAppCreation:
    """Tests for BedrockAgentCoreApp instance creation."""

    def _patch_bedrock(self, mock_app: MagicMock):
        """Return a context manager that patches the lazy BedrockAgentCoreApp import."""
        mock_module = MagicMock()
        mock_module.BedrockAgentCoreApp = MagicMock(return_value=mock_app)
        return patch.dict("sys.modules", {"bedrock_agentcore": mock_module})

    def test_creates_bedrock_agentcore_app_instance(self):
        """Should create a BedrockAgentCoreApp instance."""
        from synth.deploy.agentcore.handler import agentcore_handler

        agent = _make_mock_agent()
        mock_app = _make_mock_bedrock_app()

        with self._patch_bedrock(mock_app):
            result = agentcore_handler(agent)

        assert result is mock_app

    def test_registers_entrypoint_with_decorator(self):
        """Should register handler using @app.entrypoint decorator."""
        from synth.deploy.agentcore.handler import agentcore_handler

        agent = _make_mock_agent()
        mock_app = _make_mock_bedrock_app()

        with self._patch_bedrock(mock_app):
            agentcore_handler(agent)

        assert hasattr(mock_app, "_registered_handler")
        assert callable(mock_app._registered_handler)

    def test_stores_adapter_reference_on_app(self):
        """Should store AgentCoreAdapter reference on app._synth_adapter."""
        from synth.deploy.agentcore.handler import agentcore_handler

        agent = _make_mock_agent()
        mock_app = _make_mock_bedrock_app()

        with self._patch_bedrock(mock_app):
            result = agentcore_handler(agent)

        assert hasattr(result, "_synth_adapter")
        from synth.deploy.agentcore.adapter import AgentCoreAdapter
        assert isinstance(result._synth_adapter, AgentCoreAdapter)

    def test_stores_handler_reference_on_app(self):
        """Should store handler function reference on app._synth_handler."""
        from synth.deploy.agentcore.handler import agentcore_handler

        agent = _make_mock_agent()
        mock_app = _make_mock_bedrock_app()

        with self._patch_bedrock(mock_app):
            result = agentcore_handler(agent)

        assert hasattr(result, "_synth_handler")
        assert callable(result._synth_handler)

    def test_adapter_wraps_provided_agent(self):
        """AgentCoreAdapter should wrap the provided agent."""
        from synth.deploy.agentcore.handler import agentcore_handler

        agent = _make_mock_agent()
        mock_app = _make_mock_bedrock_app()

        with self._patch_bedrock(mock_app):
            result = agentcore_handler(agent)

        assert result._synth_adapter._target is agent


# ---------------------------------------------------------------------------
# Handler Function Behavior
# ---------------------------------------------------------------------------


class TestAgentCoreHandlerFunction:
    """Tests for the registered handler function behavior."""

    def _patch_bedrock(self, mock_app: MagicMock):
        mock_module = MagicMock()
        mock_module.BedrockAgentCoreApp = MagicMock(return_value=mock_app)
        return patch.dict("sys.modules", {"bedrock_agentcore": mock_module})

    def test_handler_calls_adapter_handle_invocation(self):
        """Handler should delegate to adapter.handle_invocation."""
        from synth.deploy.agentcore.handler import agentcore_handler

        agent = _make_mock_agent()
        mock_app = _make_mock_bedrock_app()

        with self._patch_bedrock(mock_app):
            result = agentcore_handler(agent)

        handler = result._synth_handler

        with patch.object(result._synth_adapter, "handle_invocation", return_value={"output": {"text": "test"}}) as mock_handle:
            payload = {"input": "test prompt"}
            response = handler(payload)

        mock_handle.assert_called_once_with(payload, None)
        assert response == {"output": {"text": "test"}}

    def test_handler_returns_dict(self):
        """Handler should return a dict response."""
        from synth.deploy.agentcore.handler import agentcore_handler

        agent = _make_mock_agent()
        mock_app = _make_mock_bedrock_app()

        with self._patch_bedrock(mock_app):
            result = agentcore_handler(agent)

        handler = result._synth_handler

        with patch.object(result._synth_adapter, "handle_invocation", return_value={"output": {"text": "response"}}):
            response = handler({"input": "test"})

        assert isinstance(response, dict)

    def test_handler_propagates_adapter_exceptions(self):
        """Handler should propagate exceptions from adapter."""
        from synth.deploy.agentcore.handler import agentcore_handler

        agent = _make_mock_agent()
        mock_app = _make_mock_bedrock_app()

        with self._patch_bedrock(mock_app):
            result = agentcore_handler(agent)

        handler = result._synth_handler

        with patch.object(result._synth_adapter, "handle_invocation", side_effect=SynthConfigError("test error", component="test", suggestion="test")):
            with pytest.raises(SynthConfigError, match="test error"):
                handler({"input": "test"})


# ---------------------------------------------------------------------------
# Integration with Different Target Types
# ---------------------------------------------------------------------------


class TestAgentCoreHandlerTargetTypes:
    """Tests for wrapping different target types (Agent, Graph)."""

    def _patch_bedrock(self, mock_app: MagicMock):
        mock_module = MagicMock()
        mock_module.BedrockAgentCoreApp = MagicMock(return_value=mock_app)
        return patch.dict("sys.modules", {"bedrock_agentcore": mock_module})

    def test_accepts_agent_instance(self):
        """Should accept an Agent instance."""
        from synth.deploy.agentcore.handler import agentcore_handler

        agent = _make_mock_agent()
        mock_app = _make_mock_bedrock_app()

        with self._patch_bedrock(mock_app):
            result = agentcore_handler(agent)

        assert result._synth_adapter._target is agent

    def test_accepts_graph_instance(self):
        """Should accept a Graph instance."""
        from synth.deploy.agentcore.handler import agentcore_handler

        graph = _make_mock_agent()
        mock_app = _make_mock_bedrock_app()

        with self._patch_bedrock(mock_app):
            result = agentcore_handler(graph)

        assert result._synth_adapter._target is graph

    def test_accepts_any_object_with_arun(self):
        """Should accept any object (adapter doesn't validate type)."""
        from synth.deploy.agentcore.handler import agentcore_handler

        custom_target = MagicMock()
        mock_app = _make_mock_bedrock_app()

        with self._patch_bedrock(mock_app):
            result = agentcore_handler(custom_target)

        assert result._synth_adapter._target is custom_target
