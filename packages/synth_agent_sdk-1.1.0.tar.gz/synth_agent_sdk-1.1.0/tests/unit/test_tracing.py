"""Unit tests for the tracing system.

Covers TraceSpan, Trace, TraceCollector, and the OTEL exporter.
"""

from __future__ import annotations

import asyncio
import json
import warnings
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

import pytest

from synth.tracing.trace import Trace, TraceCollector, TraceSpan


# ---------------------------------------------------------------------------
# TraceSpan
# ---------------------------------------------------------------------------


class TestTraceSpan:
    """Tests for TraceSpan dataclass."""

    def test_span_creation(self):
        """TraceSpan stores all fields correctly."""
        start = datetime(2025, 1, 1, tzinfo=timezone.utc)
        end = datetime(2025, 1, 1, 0, 0, 1, tzinfo=timezone.utc)
        span = TraceSpan(
            name="test-span",
            type="llm_call",
            start_time=start,
            end_time=end,
            metadata={"total_tokens": 42},
        )
        assert span.name == "test-span"
        assert span.type == "llm_call"
        assert span.start_time == start
        assert span.end_time == end
        assert span.metadata["total_tokens"] == 42

    def test_span_default_metadata(self):
        """TraceSpan defaults metadata to empty dict."""
        now = datetime.now(timezone.utc)
        span = TraceSpan(name="s", type="tool_call", start_time=now, end_time=now)
        assert span.metadata == {}

    def test_span_metadata_isolation(self):
        """Each TraceSpan gets its own metadata dict instance."""
        now = datetime.now(timezone.utc)
        span_a = TraceSpan(name="a", type="tool_call", start_time=now, end_time=now)
        span_b = TraceSpan(name="b", type="tool_call", start_time=now, end_time=now)
        span_a.metadata["key"] = "value"
        assert "key" not in span_b.metadata

    @pytest.mark.parametrize(
        "span_type",
        ["llm_call", "tool_call", "guard_check", "node_execution"],
    )
    def test_span_accepts_all_valid_types(self, span_type):
        """TraceSpan accepts every valid span type literal."""
        now = datetime.now(timezone.utc)
        span = TraceSpan(name="x", type=span_type, start_time=now, end_time=now)
        assert span.type == span_type


# ---------------------------------------------------------------------------
# Trace
# ---------------------------------------------------------------------------


class TestTrace:
    """Tests for Trace dataclass."""

    def test_empty_trace(self):
        """Empty Trace has zero totals."""
        trace = Trace()
        assert trace.spans == []
        assert trace.total_tokens == 0
        assert trace.total_cost == 0.0
        assert trace.total_latency_ms == 0.0

    def test_trace_with_spans(self):
        """Trace stores provided spans and totals."""
        now = datetime.now(timezone.utc)
        spans = [
            TraceSpan(name="a", type="llm_call", start_time=now, end_time=now),
            TraceSpan(name="b", type="tool_call", start_time=now, end_time=now),
        ]
        trace = Trace(
            spans=spans,
            total_tokens=200,
            total_cost=0.05,
            total_latency_ms=123.4,
        )
        assert len(trace.spans) == 2
        assert trace.total_tokens == 200
        assert trace.total_cost == pytest.approx(0.05)
        assert trace.total_latency_ms == pytest.approx(123.4)

    def test_trace_show_delegates_to_exporter(self):
        """Trace.show() calls the exporter's show_trace function."""
        trace = Trace()
        with patch("synth.tracing.exporter.show_trace") as mock_show:
            trace.show()
            mock_show.assert_called_once_with(trace)

    def test_trace_export_delegates_to_exporter(self, tmp_path: Path):
        """Trace.export() calls the exporter's export_trace function."""
        trace = Trace()
        dest = str(tmp_path / "out.json")
        with patch(
            "synth.tracing.exporter.export_trace", return_value=dest
        ) as mock_export:
            result = trace.export(path=dest)
            mock_export.assert_called_once_with(trace, path=dest)
            assert result == dest

    def test_trace_export_none_path(self):
        """Trace.export() passes None when no path given."""
        trace = Trace()
        with patch(
            "synth.tracing.exporter.export_trace", return_value="/fake/path.json"
        ) as mock_export:
            trace.export()
            mock_export.assert_called_once_with(trace, path=None)


# ---------------------------------------------------------------------------
# TraceCollector
# ---------------------------------------------------------------------------


class TestTraceCollector:
    """Tests for TraceCollector lifecycle and span recording."""

    def test_finalise_returns_trace(self):
        """Collector.finalise() returns a Trace with recorded spans."""
        collector = TraceCollector()
        collector.start()

        now = datetime.now(timezone.utc)
        collector.record_span(TraceSpan(
            name="llm", type="llm_call",
            start_time=now, end_time=now,
            metadata={"total_tokens": 100, "cost": 0.01},
        ))

        trace = collector.finalise()
        assert len(trace.spans) == 1
        assert trace.total_tokens == 100
        assert trace.total_cost == pytest.approx(0.01)
        assert trace.total_latency_ms > 0.0

    def test_finalise_sums_multiple_llm_spans(self):
        """Collector sums tokens and cost across multiple llm_call spans."""
        collector = TraceCollector()
        collector.start()

        now = datetime.now(timezone.utc)
        for i in range(3):
            collector.record_span(TraceSpan(
                name=f"llm-{i}", type="llm_call",
                start_time=now, end_time=now,
                metadata={"total_tokens": 50, "cost": 0.005},
            ))

        trace = collector.finalise()
        assert trace.total_tokens == 150
        assert trace.total_cost == pytest.approx(0.015)

    def test_tool_call_spans_not_counted_in_tokens(self):
        """Only llm_call spans contribute to total_tokens and total_cost."""
        collector = TraceCollector()
        collector.start()

        now = datetime.now(timezone.utc)
        collector.record_span(TraceSpan(
            name="tool", type="tool_call",
            start_time=now, end_time=now,
            metadata={"latency_ms": 5.0},
        ))

        trace = collector.finalise()
        assert trace.total_tokens == 0
        assert trace.total_cost == 0.0

    def test_guard_and_node_spans_not_counted_in_tokens(self):
        """guard_check and node_execution spans do not affect token/cost totals."""
        collector = TraceCollector()
        collector.start()

        now = datetime.now(timezone.utc)
        collector.record_span(TraceSpan(
            name="guard", type="guard_check",
            start_time=now, end_time=now,
            metadata={"total_tokens": 999, "cost": 999.0},
        ))
        collector.record_span(TraceSpan(
            name="node", type="node_execution",
            start_time=now, end_time=now,
            metadata={"total_tokens": 888, "cost": 888.0},
        ))

        trace = collector.finalise()
        assert trace.total_tokens == 0
        assert trace.total_cost == 0.0

    def test_llm_span_missing_metadata_keys_defaults_to_zero(self):
        """llm_call spans without total_tokens or cost metadata default to 0."""
        collector = TraceCollector()
        collector.start()

        now = datetime.now(timezone.utc)
        collector.record_span(TraceSpan(
            name="llm", type="llm_call",
            start_time=now, end_time=now,
            metadata={},
        ))

        trace = collector.finalise()
        assert trace.total_tokens == 0
        assert trace.total_cost == 0.0

    def test_finalise_empty_collector(self):
        """Finalising with no recorded spans returns an empty Trace."""
        collector = TraceCollector()
        collector.start()

        trace = collector.finalise()
        assert trace.spans == []
        assert trace.total_tokens == 0
        assert trace.total_cost == 0.0
        assert trace.total_latency_ms >= 0.0

    def test_finalise_copies_spans_list(self):
        """Finalised Trace gets a copy of the spans, not a reference."""
        collector = TraceCollector()
        collector.start()

        now = datetime.now(timezone.utc)
        collector.record_span(TraceSpan(
            name="s", type="tool_call", start_time=now, end_time=now,
        ))

        trace = collector.finalise()
        assert len(trace.spans) == 1

        # Adding more spans to the collector should not affect the trace
        collector.record_span(TraceSpan(
            name="s2", type="tool_call", start_time=now, end_time=now,
        ))
        assert len(trace.spans) == 1

    def test_mixed_span_types_only_llm_counted(self):
        """Only llm_call spans contribute to totals in a mixed collection."""
        collector = TraceCollector()
        collector.start()

        now = datetime.now(timezone.utc)
        collector.record_span(TraceSpan(
            name="llm", type="llm_call",
            start_time=now, end_time=now,
            metadata={"total_tokens": 100, "cost": 0.01},
        ))
        collector.record_span(TraceSpan(
            name="tool", type="tool_call",
            start_time=now, end_time=now,
            metadata={"total_tokens": 50, "cost": 0.005},
        ))
        collector.record_span(TraceSpan(
            name="guard", type="guard_check",
            start_time=now, end_time=now,
        ))
        collector.record_span(TraceSpan(
            name="llm2", type="llm_call",
            start_time=now, end_time=now,
            metadata={"total_tokens": 200, "cost": 0.02},
        ))

        trace = collector.finalise()
        assert len(trace.spans) == 4
        assert trace.total_tokens == 300
        assert trace.total_cost == pytest.approx(0.03)

    def test_async_span_context_manager(self):
        """The async span() context manager records a span with metadata."""

        async def _run():
            collector = TraceCollector()
            collector.start()

            async with collector.span("my-tool", "tool_call") as meta:
                meta["result"] = "ok"

            trace = collector.finalise()
            assert len(trace.spans) == 1
            assert trace.spans[0].name == "my-tool"
            assert trace.spans[0].type == "tool_call"
            assert trace.spans[0].metadata["result"] == "ok"
            assert trace.spans[0].start_time <= trace.spans[0].end_time

        asyncio.run(_run())

    def test_async_span_records_on_exception(self):
        """The async span() context manager records the span even on error."""

        async def _run():
            collector = TraceCollector()
            collector.start()

            with pytest.raises(ValueError, match="boom"):
                async with collector.span("bad", "tool_call"):
                    raise ValueError("boom")

            trace = collector.finalise()
            assert len(trace.spans) == 1
            assert trace.spans[0].name == "bad"

        asyncio.run(_run())

    def test_async_span_with_extra_metadata(self):
        """Extra keyword args to span() appear in the yielded metadata dict."""

        async def _run():
            collector = TraceCollector()
            collector.start()

            async with collector.span(
                "llm", "llm_call", model="gpt-4o", attempt=1
            ) as meta:
                meta["total_tokens"] = 50

            trace = collector.finalise()
            span = trace.spans[0]
            assert span.metadata["model"] == "gpt-4o"
            assert span.metadata["attempt"] == 1
            assert span.metadata["total_tokens"] == 50

        asyncio.run(_run())

    def test_multiple_async_spans_in_sequence(self):
        """Multiple span() calls accumulate spans in order."""

        async def _run():
            collector = TraceCollector()
            collector.start()

            async with collector.span("first", "llm_call") as meta:
                meta["total_tokens"] = 10

            async with collector.span("second", "tool_call"):
                pass

            async with collector.span("third", "guard_check"):
                pass

            trace = collector.finalise()
            assert len(trace.spans) == 3
            assert [s.name for s in trace.spans] == ["first", "second", "third"]

        asyncio.run(_run())

    def test_record_span_and_async_span_interleaved(self):
        """record_span() and span() context manager can be mixed."""

        async def _run():
            collector = TraceCollector()
            collector.start()

            now = datetime.now(timezone.utc)
            collector.record_span(TraceSpan(
                name="pre", type="tool_call", start_time=now, end_time=now,
            ))

            async with collector.span("mid", "llm_call") as meta:
                meta["total_tokens"] = 25

            collector.record_span(TraceSpan(
                name="post", type="guard_check", start_time=now, end_time=now,
            ))

            trace = collector.finalise()
            assert len(trace.spans) == 3
            assert [s.name for s in trace.spans] == ["pre", "mid", "post"]
            assert trace.total_tokens == 25

        asyncio.run(_run())


# ---------------------------------------------------------------------------
# OTEL export
# ---------------------------------------------------------------------------


class TestOtelExport:
    """Tests for trace.export() producing valid OTEL JSON."""

    def test_export_creates_file(self, tmp_path: Path):
        """export() writes a JSON file to the specified path."""
        now = datetime.now(timezone.utc)
        trace = Trace(
            spans=[
                TraceSpan(
                    name="llm", type="llm_call",
                    start_time=now, end_time=now,
                    metadata={"total_tokens": 10},
                ),
            ],
            total_tokens=10,
            total_cost=0.001,
            total_latency_ms=50.0,
        )

        dest = tmp_path / "trace.json"
        result_path = trace.export(path=str(dest))

        assert Path(result_path).exists()
        data = json.loads(dest.read_text(encoding="utf-8"))
        assert "resourceSpans" in data
        spans = data["resourceSpans"][0]["scopeSpans"][0]["spans"]
        assert len(spans) == 1
        assert spans[0]["name"] == "llm"

    def test_export_auto_generates_path(self, tmp_path: Path, monkeypatch):
        """export() generates a timestamped filename when path is None."""
        monkeypatch.chdir(tmp_path)
        trace = Trace(total_latency_ms=1.0)
        result_path = trace.export()
        assert Path(result_path).exists()
        assert result_path.endswith(".json")

    def test_export_otel_structure_has_service_name(self, tmp_path: Path):
        """Exported OTEL JSON includes synth-sdk service name."""
        trace = Trace(total_latency_ms=1.0)
        dest = tmp_path / "trace.json"
        trace.export(path=str(dest))

        data = json.loads(dest.read_text(encoding="utf-8"))
        resource_attrs = data["resourceSpans"][0]["resource"]["attributes"]
        service_attr = next(a for a in resource_attrs if a["key"] == "service.name")
        assert service_attr["value"]["stringValue"] == "synth-sdk"

    def test_export_otel_span_attributes(self, tmp_path: Path):
        """Exported spans include span.type and metadata as OTEL attributes."""
        now = datetime.now(timezone.utc)
        trace = Trace(
            spans=[
                TraceSpan(
                    name="my-tool", type="tool_call",
                    start_time=now, end_time=now,
                    metadata={"latency_ms": 5.0, "success": True},
                ),
            ],
            total_latency_ms=10.0,
        )

        dest = tmp_path / "trace.json"
        trace.export(path=str(dest))

        data = json.loads(dest.read_text(encoding="utf-8"))
        span = data["resourceSpans"][0]["scopeSpans"][0]["spans"][0]
        attr_keys = [a["key"] for a in span["attributes"]]
        assert "span.type" in attr_keys
        assert "latency_ms" in attr_keys
        assert "success" in attr_keys

    def test_export_multiple_spans(self, tmp_path: Path):
        """Exported OTEL JSON contains all spans from the trace."""
        now = datetime.now(timezone.utc)
        trace = Trace(
            spans=[
                TraceSpan(name="a", type="llm_call", start_time=now, end_time=now),
                TraceSpan(name="b", type="tool_call", start_time=now, end_time=now),
                TraceSpan(name="c", type="guard_check", start_time=now, end_time=now),
            ],
            total_latency_ms=1.0,
        )

        dest = tmp_path / "trace.json"
        trace.export(path=str(dest))

        data = json.loads(dest.read_text(encoding="utf-8"))
        spans = data["resourceSpans"][0]["scopeSpans"][0]["spans"]
        assert len(spans) == 3
        assert [s["name"] for s in spans] == ["a", "b", "c"]


# ---------------------------------------------------------------------------
# OTEL attribute value conversion
# ---------------------------------------------------------------------------


class TestOtelAttrValue:
    """Tests for _otel_attr_value helper in the exporter."""

    def test_bool_value(self):
        from synth.tracing.exporter import _otel_attr_value

        assert _otel_attr_value(True) == {"boolValue": True}
        assert _otel_attr_value(False) == {"boolValue": False}

    def test_int_value(self):
        from synth.tracing.exporter import _otel_attr_value

        assert _otel_attr_value(42) == {"intValue": 42}

    def test_float_value(self):
        from synth.tracing.exporter import _otel_attr_value

        assert _otel_attr_value(3.14) == {"doubleValue": 3.14}

    def test_string_value(self):
        from synth.tracing.exporter import _otel_attr_value

        assert _otel_attr_value("hello") == {"stringValue": "hello"}

    def test_other_types_converted_to_string(self):
        from synth.tracing.exporter import _otel_attr_value

        result = _otel_attr_value([1, 2, 3])
        assert result == {"stringValue": "[1, 2, 3]"}

    def test_bool_before_int(self):
        """bool is checked before int since bool is a subclass of int."""
        from synth.tracing.exporter import _otel_attr_value

        # True is also int(1), but should be boolValue not intValue
        assert _otel_attr_value(True) == {"boolValue": True}


# ---------------------------------------------------------------------------
# Trace forwarding
# ---------------------------------------------------------------------------


class TestTraceForwarding:
    """Tests for _maybe_forward and SYNTH_TRACE_ENDPOINT handling."""

    def test_no_forwarding_when_env_not_set(self, monkeypatch):
        """No forwarding attempt when SYNTH_TRACE_ENDPOINT is not set."""
        monkeypatch.delenv("SYNTH_TRACE_ENDPOINT", raising=False)
        from synth.tracing.exporter import _maybe_forward

        # Should not raise or attempt any HTTP call
        _maybe_forward({"resourceSpans": []})

    def test_warns_on_non_https_endpoint(self, monkeypatch):
        """Non-HTTPS endpoint triggers a warning and skips forwarding."""
        monkeypatch.setenv("SYNTH_TRACE_ENDPOINT", "http://insecure.example.com")
        from synth.tracing.exporter import _maybe_forward

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            _maybe_forward({"resourceSpans": []})
            assert len(w) == 1
            assert "HTTPS" in str(w[0].message)

    def test_warns_on_oversized_payload(self, monkeypatch):
        """Payload exceeding 1 MB triggers a warning and skips forwarding."""
        monkeypatch.setenv("SYNTH_TRACE_ENDPOINT", "https://collector.example.com")
        from synth.tracing.exporter import _maybe_forward

        # Create a payload larger than 1 MB
        huge_data = {"data": "x" * (1_048_577)}

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            with patch("httpx.post") as mock_post:
                _maybe_forward(huge_data)
                mock_post.assert_not_called()
            assert any("1 MB" in str(warning.message) for warning in w)

    def test_forwarding_with_valid_https_endpoint(self, monkeypatch):
        """Valid HTTPS endpoint triggers an httpx.post call."""
        monkeypatch.setenv(
            "SYNTH_TRACE_ENDPOINT", "https://collector.example.com/v1/traces"
        )
        from synth.tracing.exporter import _maybe_forward

        with patch("httpx.post") as mock_post:
            _maybe_forward({"resourceSpans": []})
            mock_post.assert_called_once()
            call_kwargs = mock_post.call_args
            assert "https://collector.example.com/v1/traces" in call_kwargs.args

    def test_forwarding_swallows_exceptions(self, monkeypatch):
        """Forwarding errors are silently swallowed (best-effort)."""
        monkeypatch.setenv(
            "SYNTH_TRACE_ENDPOINT", "https://collector.example.com/v1/traces"
        )
        from synth.tracing.exporter import _maybe_forward

        with patch("httpx.post", side_effect=ConnectionError("network down")):
            # Should not raise
            _maybe_forward({"resourceSpans": []})
