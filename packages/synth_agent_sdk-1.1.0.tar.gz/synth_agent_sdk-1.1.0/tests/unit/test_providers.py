"""Unit tests for BaseProvider ABC and provider-layer types."""

from __future__ import annotations

from collections.abc import AsyncGenerator
from typing import Any

import pytest

from synth.providers.base import (
    BaseProvider,
    ProviderDoneEvent,
    ProviderErrorEvent,
    ProviderEvent,
    ProviderResponse,
    TextChunkEvent,
    ThinkingChunkEvent,
    ToolCallChunkEvent,
    ToolCallInfo,
)
from synth.types import Message, TokenUsage


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class ConcreteProvider(BaseProvider):
    """Minimal concrete subclass that implements both abstract methods."""

    async def complete(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> ProviderResponse:
        return ProviderResponse(
            text="hello",
            usage=TokenUsage(input_tokens=1, output_tokens=1, total_tokens=2),
        )

    async def stream(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ProviderEvent, None]:
        yield TextChunkEvent(text="hello")
        yield ProviderDoneEvent(usage=TokenUsage(input_tokens=1, output_tokens=1, total_tokens=2))


class IncompleteProvider(BaseProvider):
    """Subclass that only implements complete(), missing stream()."""

    async def complete(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> ProviderResponse:
        return ProviderResponse(
            text="ok",
            usage=TokenUsage(input_tokens=0, output_tokens=0, total_tokens=0),
        )


# ---------------------------------------------------------------------------
# Tests: BaseProvider is abstract
# ---------------------------------------------------------------------------


class TestBaseProviderAbstract:
    def test_cannot_instantiate_directly(self) -> None:
        """BaseProvider cannot be instantiated because it has abstract methods."""
        with pytest.raises(TypeError, match="abstract method"):
            BaseProvider()  # type: ignore[abstract]

    def test_incomplete_subclass_cannot_instantiate(self) -> None:
        """A subclass that doesn't implement all abstract methods can't be instantiated."""
        with pytest.raises(TypeError, match="abstract method"):
            IncompleteProvider()  # type: ignore[abstract]

    def test_concrete_subclass_can_instantiate(self) -> None:
        """A subclass implementing both complete() and stream() can be instantiated."""
        provider = ConcreteProvider()
        assert isinstance(provider, BaseProvider)


# ---------------------------------------------------------------------------
# Tests: ConcreteProvider works
# ---------------------------------------------------------------------------


class TestConcreteProvider:
    @pytest.mark.asyncio
    async def test_complete_returns_provider_response(self) -> None:
        provider = ConcreteProvider()
        messages: list[Message] = [{"role": "user", "content": "hi"}]
        response = await provider.complete(messages)

        assert isinstance(response, ProviderResponse)
        assert response.text == "hello"
        assert response.usage.total_tokens == 2
        assert response.tool_calls == []

    @pytest.mark.asyncio
    async def test_stream_yields_provider_events(self) -> None:
        provider = ConcreteProvider()
        messages: list[Message] = [{"role": "user", "content": "hi"}]
        events: list[ProviderEvent] = []

        async for event in provider.stream(messages):
            events.append(event)

        assert len(events) == 2
        assert isinstance(events[0], TextChunkEvent)
        assert events[0].text == "hello"
        assert isinstance(events[1], ProviderDoneEvent)


# ---------------------------------------------------------------------------
# Tests: Provider-layer types
# ---------------------------------------------------------------------------


class TestProviderTypes:
    def test_provider_response_defaults(self) -> None:
        resp = ProviderResponse(
            text="test",
            usage=TokenUsage(input_tokens=5, output_tokens=10, total_tokens=15),
        )
        assert resp.tool_calls == []
        assert resp.raw is None

    def test_provider_response_with_tool_calls(self) -> None:
        tc = ToolCallInfo(id="tc_1", name="search", args={"q": "hello"})
        resp = ProviderResponse(
            text="",
            usage=TokenUsage(input_tokens=5, output_tokens=10, total_tokens=15),
            tool_calls=[tc],
        )
        assert len(resp.tool_calls) == 1
        assert resp.tool_calls[0].name == "search"

    def test_text_chunk_event(self) -> None:
        e = TextChunkEvent(text="chunk")
        assert e.text == "chunk"

    def test_thinking_chunk_event(self) -> None:
        e = ThinkingChunkEvent(text="reasoning")
        assert e.text == "reasoning"

    def test_tool_call_chunk_event(self) -> None:
        e = ToolCallChunkEvent(id="tc_1", name="calc", args={"x": 1})
        assert e.name == "calc"
        assert e.args == {"x": 1}

    def test_provider_done_event(self) -> None:
        e = ProviderDoneEvent(usage=TokenUsage(input_tokens=1, output_tokens=2, total_tokens=3))
        assert e.usage.total_tokens == 3

    def test_provider_error_event(self) -> None:
        err = RuntimeError("boom")
        e = ProviderErrorEvent(error=err)
        assert e.error is err


# ---------------------------------------------------------------------------
# Tests: ProviderRouter
# ---------------------------------------------------------------------------

from unittest.mock import MagicMock, patch

from synth.errors import SynthConfigError
from synth.providers.router import KNOWN_PREFIXES, ProviderRouter, _PROVIDER_SPECS


class TestProviderRouterKnownPrefixes:
    """Known model prefixes route to the correct provider class."""

    @pytest.mark.parametrize(
        "model,prefix",
        [
            ("claude-sonnet-4-5", "claude-"),
            ("gpt-4o", "gpt-"),
            ("gemini-2.0-flash", "gemini-"),
            ("ollama/llama3", "ollama/"),
            ("bedrock/claude-sonnet-4-5", "bedrock/"),
            ("bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0", "bedrock/"),
        ],
    )
    def test_known_prefix_routes_to_correct_provider(self, model: str, prefix: str) -> None:
        """Each known prefix should trigger a lazy import of the matching provider."""
        spec = _PROVIDER_SPECS[prefix]
        module_path, class_name, _pkg, _extra = spec

        mock_cls = MagicMock()
        mock_instance = MagicMock(spec=BaseProvider)
        mock_cls.return_value = mock_instance

        mock_module = MagicMock()
        setattr(mock_module, class_name, mock_cls)

        router = ProviderRouter()
        with patch("importlib.import_module", return_value=mock_module) as mock_import:
            result = router.resolve(model)

        mock_import.assert_called_once_with(module_path)
        mock_cls.assert_called_once_with(model=model, base_url=None)
        assert result is mock_instance

    @pytest.mark.parametrize(
        "model,prefix",
        [
            ("claude-sonnet-4-5", "claude-"),
            ("gpt-4o", "gpt-"),
        ],
    )
    def test_known_prefix_with_base_url_forwards_it(self, model: str, prefix: str) -> None:
        """base_url should be forwarded to the provider constructor."""
        spec = _PROVIDER_SPECS[prefix]
        module_path, class_name, _pkg, _extra = spec

        mock_cls = MagicMock()
        mock_module = MagicMock()
        setattr(mock_module, class_name, mock_cls)

        router = ProviderRouter()
        with patch("importlib.import_module", return_value=mock_module):
            router.resolve(model, base_url="https://custom.example.com")

        mock_cls.assert_called_once_with(
            model=model, base_url="https://custom.example.com"
        )


class TestProviderRouterUnknownModel:
    """Unknown model strings raise SynthConfigError."""

    def test_unknown_model_raises_config_error(self) -> None:
        router = ProviderRouter()
        with pytest.raises(SynthConfigError, match="does not match any known provider") as exc_info:
            router.resolve("unknown-model-xyz")

        err = exc_info.value
        assert err.component == "ProviderRouter"
        assert "unknown-model-xyz" in str(err)
        # All known prefixes should be listed
        for prefix in KNOWN_PREFIXES:
            assert prefix in str(err)
        assert "base_url" in str(err)

    def test_unknown_model_error_lists_available_prefixes(self) -> None:
        router = ProviderRouter()
        with pytest.raises(SynthConfigError) as exc_info:
            router.resolve("llama-70b")

        msg = str(exc_info.value)
        assert "claude-" in msg
        assert "gpt-" in msg
        assert "gemini-" in msg
        assert "ollama/" in msg
        assert "bedrock/" in msg


class TestProviderRouterMissingPackage:
    """Missing provider packages raise SynthConfigError with pip install command."""

    @pytest.mark.parametrize(
        "model,prefix",
        [
            ("claude-sonnet-4-5", "claude-"),
            ("gpt-4o", "gpt-"),
            ("gemini-2.0-flash", "gemini-"),
            ("ollama/llama3", "ollama/"),
            ("bedrock/claude-sonnet-4-5", "bedrock/"),
        ],
    )
    def test_missing_package_raises_config_error_with_pip_command(
        self, model: str, prefix: str
    ) -> None:
        spec = _PROVIDER_SPECS[prefix]
        _module_path, _class_name, package, extra = spec

        router = ProviderRouter()
        with patch("importlib.import_module", side_effect=ImportError("no module")):
            with pytest.raises(SynthConfigError, match="pip install") as exc_info:
                router.resolve(model)

        err = exc_info.value
        assert err.component == "ProviderRouter"
        assert package in str(err)
        assert f"synth-agent-sdk[{extra}]" in str(err)

    def test_missing_package_error_message_format(self) -> None:
        router = ProviderRouter()
        with patch("importlib.import_module", side_effect=ImportError("no module")):
            with pytest.raises(SynthConfigError) as exc_info:
                router.resolve("claude-sonnet-4-5")

        msg = str(exc_info.value)
        assert "Provider package 'anthropic' is not installed" in msg
        assert "Run: pip install synth-agent-sdk[anthropic]" in msg


class TestProviderRouterBaseUrl:
    """base_url override creates a provider for custom endpoints."""

    def test_base_url_with_unknown_model_uses_openai_compatible(self) -> None:
        """When base_url is provided and no prefix matches, use OpenAI-compatible provider."""
        openai_spec = _PROVIDER_SPECS["gpt-"]
        _module_path, class_name, _pkg, _extra = openai_spec

        mock_cls = MagicMock()
        mock_instance = MagicMock(spec=BaseProvider)
        mock_cls.return_value = mock_instance

        mock_module = MagicMock()
        setattr(mock_module, class_name, mock_cls)

        router = ProviderRouter()
        with patch("importlib.import_module", return_value=mock_module):
            result = router.resolve(
                "my-custom-model", base_url="http://localhost:8080/v1"
            )

        mock_cls.assert_called_once_with(
            model="my-custom-model", base_url="http://localhost:8080/v1"
        )
        assert result is mock_instance

    def test_base_url_missing_openai_package_raises_config_error(self) -> None:
        """If OpenAI package is missing for base_url fallback, raise SynthConfigError."""
        router = ProviderRouter()
        with patch("importlib.import_module", side_effect=ImportError("no module")):
            with pytest.raises(SynthConfigError, match="pip install"):
                router.resolve(
                    "my-custom-model", base_url="http://localhost:8080/v1"
                )


# ---------------------------------------------------------------------------
# Tests: RetryHandler
# ---------------------------------------------------------------------------

import asyncio

import httpx

from synth.providers.retry import RetryHandler


def _make_http_status_error(status_code: int) -> httpx.HTTPStatusError:
    """Create an ``httpx.HTTPStatusError`` with the given status code."""
    response = httpx.Response(status_code=status_code, request=httpx.Request("POST", "https://api.example.com"))
    return httpx.HTTPStatusError(
        message=f"HTTP {status_code}",
        request=response.request,
        response=response,
    )


class TestRetryHandlerSuccess:
    """Successful calls return immediately without retries."""

    @pytest.mark.asyncio
    async def test_successful_call_returns_result(self) -> None:
        handler = RetryHandler(max_retries=3)

        async def ok() -> str:
            return "hello"

        result = await handler.execute(ok)
        assert result == "hello"

    @pytest.mark.asyncio
    async def test_successful_call_invoked_once(self) -> None:
        call_count = 0
        handler = RetryHandler(max_retries=3)

        async def ok() -> str:
            nonlocal call_count
            call_count += 1
            return "done"

        await handler.execute(ok)
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_passes_args_and_kwargs(self) -> None:
        handler = RetryHandler()

        async def add(a: int, b: int, extra: int = 0) -> int:
            return a + b + extra

        result = await handler.execute(add, 2, 3, extra=10)
        assert result == 15


class TestRetryHandlerRetries429:
    """HTTP 429 triggers retries."""

    @pytest.mark.asyncio
    async def test_retries_on_429_then_succeeds(self) -> None:
        call_count = 0
        handler = RetryHandler(max_retries=3, retry_backoff=0.0)

        async def flaky() -> str:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise _make_http_status_error(429)
            return "ok"

        result = await handler.execute(flaky)
        assert result == "ok"
        assert call_count == 3


class TestRetryHandlerRetries5xx:
    """HTTP 5xx triggers retries."""

    @pytest.mark.asyncio
    async def test_retries_on_500(self) -> None:
        call_count = 0
        handler = RetryHandler(max_retries=3, retry_backoff=0.0)

        async def flaky() -> str:
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise _make_http_status_error(500)
            return "recovered"

        result = await handler.execute(flaky)
        assert result == "recovered"
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_retries_on_502(self) -> None:
        call_count = 0
        handler = RetryHandler(max_retries=3, retry_backoff=0.0)

        async def flaky() -> str:
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise _make_http_status_error(502)
            return "ok"

        result = await handler.execute(flaky)
        assert result == "ok"

    @pytest.mark.asyncio
    async def test_retries_on_503(self) -> None:
        call_count = 0
        handler = RetryHandler(max_retries=3, retry_backoff=0.0)

        async def flaky() -> str:
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise _make_http_status_error(503)
            return "ok"

        result = await handler.execute(flaky)
        assert result == "ok"


class TestRetryHandlerExhaustsRetries:
    """After max_retries, the last exception is re-raised."""

    @pytest.mark.asyncio
    async def test_gives_up_after_max_retries(self) -> None:
        call_count = 0
        handler = RetryHandler(max_retries=2, retry_backoff=0.0)

        async def always_fail() -> str:
            nonlocal call_count
            call_count += 1
            raise _make_http_status_error(429)

        with pytest.raises(httpx.HTTPStatusError, match="429"):
            await handler.execute(always_fail)

        # 1 initial + 2 retries = 3 total calls
        assert call_count == 3

    @pytest.mark.asyncio
    async def test_gives_up_after_max_retries_5xx(self) -> None:
        call_count = 0
        handler = RetryHandler(max_retries=1, retry_backoff=0.0)

        async def always_fail() -> str:
            nonlocal call_count
            call_count += 1
            raise _make_http_status_error(500)

        with pytest.raises(httpx.HTTPStatusError, match="500"):
            await handler.execute(always_fail)

        assert call_count == 2


class TestRetryHandlerExponentialBackoff:
    """Delay increases with each attempt (exponential backoff)."""

    @pytest.mark.asyncio
    async def test_delay_increases_with_each_attempt(self) -> None:
        recorded_delays: list[float] = []
        handler = RetryHandler(max_retries=3, retry_backoff=1.0)

        original_sleep = asyncio.sleep

        async def mock_sleep(delay: float) -> None:
            recorded_delays.append(delay)
            # Don't actually sleep

        call_count = 0

        async def always_fail() -> str:
            nonlocal call_count
            call_count += 1
            raise _make_http_status_error(500)

        with patch("synth.providers.retry.asyncio.sleep", side_effect=mock_sleep):
            with pytest.raises(httpx.HTTPStatusError):
                await handler.execute(always_fail)

        # 3 retries → 3 sleep calls (no sleep after the final attempt)
        assert len(recorded_delays) == 3

        # Each delay should be greater than or equal to the base (without jitter)
        # base delays: 1*2^0=1, 1*2^1=2, 1*2^2=4
        assert recorded_delays[0] >= 1.0
        assert recorded_delays[1] >= 2.0
        assert recorded_delays[2] >= 4.0

        # Each delay should be strictly increasing
        assert recorded_delays[0] < recorded_delays[1] < recorded_delays[2]


class TestRetryHandlerNonRetryable:
    """Non-retryable errors are raised immediately without retries."""

    @pytest.mark.asyncio
    async def test_400_raises_immediately(self) -> None:
        call_count = 0
        handler = RetryHandler(max_retries=3, retry_backoff=0.0)

        async def bad_request() -> str:
            nonlocal call_count
            call_count += 1
            raise _make_http_status_error(400)

        with pytest.raises(httpx.HTTPStatusError, match="400"):
            await handler.execute(bad_request)

        assert call_count == 1

    @pytest.mark.asyncio
    async def test_401_raises_immediately(self) -> None:
        call_count = 0
        handler = RetryHandler(max_retries=3, retry_backoff=0.0)

        async def unauthorized() -> str:
            nonlocal call_count
            call_count += 1
            raise _make_http_status_error(401)

        with pytest.raises(httpx.HTTPStatusError, match="401"):
            await handler.execute(unauthorized)

        assert call_count == 1

    @pytest.mark.asyncio
    async def test_403_raises_immediately(self) -> None:
        call_count = 0
        handler = RetryHandler(max_retries=3, retry_backoff=0.0)

        async def forbidden() -> str:
            nonlocal call_count
            call_count += 1
            raise _make_http_status_error(403)

        with pytest.raises(httpx.HTTPStatusError, match="403"):
            await handler.execute(forbidden)

        assert call_count == 1

    @pytest.mark.asyncio
    async def test_404_raises_immediately(self) -> None:
        call_count = 0
        handler = RetryHandler(max_retries=3, retry_backoff=0.0)

        async def not_found() -> str:
            nonlocal call_count
            call_count += 1
            raise _make_http_status_error(404)

        with pytest.raises(httpx.HTTPStatusError, match="404"):
            await handler.execute(not_found)

        assert call_count == 1

    @pytest.mark.asyncio
    async def test_value_error_raises_immediately(self) -> None:
        call_count = 0
        handler = RetryHandler(max_retries=3, retry_backoff=0.0)

        async def bad() -> str:
            nonlocal call_count
            call_count += 1
            raise ValueError("bad input")

        with pytest.raises(ValueError, match="bad input"):
            await handler.execute(bad)

        assert call_count == 1


class TestRetryHandlerConnectionAndTimeout:
    """ConnectionError and TimeoutError are retryable."""

    @pytest.mark.asyncio
    async def test_retries_on_connection_error(self) -> None:
        call_count = 0
        handler = RetryHandler(max_retries=3, retry_backoff=0.0)

        async def flaky() -> str:
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise ConnectionError("connection reset")
            return "ok"

        result = await handler.execute(flaky)
        assert result == "ok"
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_retries_on_timeout_error(self) -> None:
        call_count = 0
        handler = RetryHandler(max_retries=3, retry_backoff=0.0)

        async def flaky() -> str:
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise TimeoutError("timed out")
            return "ok"

        result = await handler.execute(flaky)
        assert result == "ok"
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_connection_error_exhausts_retries(self) -> None:
        handler = RetryHandler(max_retries=1, retry_backoff=0.0)

        async def always_fail() -> str:
            raise ConnectionError("down")

        with pytest.raises(ConnectionError, match="down"):
            await handler.execute(always_fail)


class TestRetryHandlerConfiguration:
    """RetryHandler respects configuration parameters."""

    @pytest.mark.asyncio
    async def test_zero_retries_fails_immediately(self) -> None:
        call_count = 0
        handler = RetryHandler(max_retries=0, retry_backoff=0.0)

        async def fail() -> str:
            nonlocal call_count
            call_count += 1
            raise _make_http_status_error(500)

        with pytest.raises(httpx.HTTPStatusError):
            await handler.execute(fail)

        assert call_count == 1

    def test_default_configuration(self) -> None:
        handler = RetryHandler()
        assert handler.max_retries == 3
        assert handler.retry_backoff == 1.0
