"""Property-based tests for eval config generation and evaluator ARN validation.

**Property 1: eval_config.json contains required default evaluators**
**Validates: Requirements 13.1**

**Property 2: agentcore.yaml includes evaluations section and IAM permissions when eval enabled**
**Validates: Requirements 13.2, 13.3**

**Property 3: Agent code references eval_config.json when agentcore + eval enabled**
**Validates: Requirements 13.4**

**Property 4: Non-agentcore providers produce no AgentCore evaluation config**
**Validates: Requirements 13.6**

**Property 5: Evaluator ARN validation detects invalid patterns**
**Validates: Requirements 13.7**

**Property 6: Evaluation results response contains all required fields**
**Validates: Requirements 14.2**

**Property 7: Evaluation config status contains all required fields**
**Validates: Requirements 14.5**

**Property 8: Credential scrubbing removes all credential patterns from evaluation data**
**Validates: Requirements 14.7**

# Feature: agentcore-live-observability, Property 1: eval_config.json contains required default evaluators
# Feature: agentcore-live-observability, Property 2: agentcore.yaml includes evaluations section and IAM permissions when eval enabled
# Feature: agentcore-live-observability, Property 3: Agent code references eval_config.json when agentcore + eval enabled
# Feature: agentcore-live-observability, Property 4: Non-agentcore providers produce no AgentCore evaluation config
# Feature: agentcore-live-observability, Property 5: Evaluator ARN validation detects invalid patterns
# Feature: agentcore-live-observability, Property 6: Evaluation results response contains all required fields
# Feature: agentcore-live-observability, Property 7: Evaluation config status contains all required fields
# Feature: agentcore-live-observability, Property 8: Credential scrubbing removes all credential patterns from evaluation data
"""

from __future__ import annotations

import json

from hypothesis import given, settings
from hypothesis import strategies as st

from synth.cli.init_cmd import (
    _build_agent_code,
    _build_agentcore_yaml,
    _build_eval_config,
    _validate_evaluator_arns,
)


# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

# Agent names: printable non-whitespace characters, 1–50 chars
_AGENT_NAME_STRATEGY = st.text(
    min_size=1,
    max_size=50,
    alphabet=st.characters(
        whitelist_categories=("L", "N", "P", "S"),
        blacklist_characters="\t\n\r\x0b\x0c ",
    ),
)

_VALID_BUILTIN_NAMES = [
    "Builtin.Helpfulness",
    "Builtin.Correctness",
    "Builtin.GoalSuccessRate",
    "Builtin.Safety",
    "Builtin.Relevance",
]

_VALID_ARN_STRATEGY = st.sampled_from(
    [f"arn:aws:bedrock-agentcore:::evaluator/{name}" for name in _VALID_BUILTIN_NAMES]
)

# Invalid ARNs: random text that won't accidentally match the pattern
_INVALID_ARN_STRATEGY = st.text(min_size=0, max_size=100).filter(
    lambda s: not s.startswith("arn:aws:bedrock-agentcore:::evaluator/Builtin.")
    or len(s) <= len("arn:aws:bedrock-agentcore:::evaluator/Builtin.")
)

_EXPECTED_EVALUATOR_IDS = {
    "Builtin.Helpfulness",
    "Builtin.Correctness",
    "Builtin.GoalSuccessRate",
}

_ARN_PREFIX = "arn:aws:bedrock-agentcore:::evaluator/"


# ---------------------------------------------------------------------------
# Property 1: eval_config.json contains required default evaluators
# ---------------------------------------------------------------------------

class TestEvalConfigGeneration:
    """Property tests for _build_eval_config().

    # Feature: agentcore-live-observability, Property 1: eval_config.json contains required default evaluators
    """

    @given(agent_name=_AGENT_NAME_STRATEGY)
    @settings(max_examples=100)
    def test_prop1_eval_config_contains_required_defaults(
        self, agent_name: str
    ) -> None:
        """Property 1: eval_config.json contains required default evaluators.

        For any valid agent name, _build_eval_config produces valid JSON with
        sampling_rate 1.0 and exactly three evaluators with correct IDs and
        valid ARNs.

        **Validates: Requirements 13.1**
        """
        raw = _build_eval_config(agent_name)
        config = json.loads(raw)

        # config_name is present and derived from agent_name
        assert "config_name" in config
        assert isinstance(config["config_name"], str)
        assert len(config["config_name"]) > 0

        # sampling_rate is exactly 1.0
        assert config["sampling_rate"] == 1.0

        # Exactly 3 evaluators
        evaluators = config["evaluators"]
        assert len(evaluators) == 3

        # Each evaluator has required fields with correct values
        ids_found = set()
        for ev in evaluators:
            assert "id" in ev
            assert "arn" in ev
            assert "level" in ev

            ids_found.add(ev["id"])

            # ARN matches the expected Builtin pattern
            assert ev["arn"].startswith(_ARN_PREFIX), (
                f"ARN {ev['arn']!r} does not start with {_ARN_PREFIX!r}"
            )
            assert ev["arn"] == f"{_ARN_PREFIX}{ev['id']}"

        assert ids_found == _EXPECTED_EVALUATOR_IDS


# ---------------------------------------------------------------------------
# Property 5: Evaluator ARN validation detects invalid patterns
# ---------------------------------------------------------------------------

class TestEvaluatorArnValidation:
    """Property tests for _validate_evaluator_arns().

    # Feature: agentcore-live-observability, Property 5: Evaluator ARN validation detects invalid patterns
    """

    @given(arn=_VALID_ARN_STRATEGY)
    @settings(max_examples=100)
    def test_prop5_valid_arns_produce_no_warnings(self, arn: str) -> None:
        """Valid ARNs produce an empty warning list.

        **Validates: Requirements 13.7**
        """
        warnings = _validate_evaluator_arns([arn])
        assert warnings == [], (
            f"Expected no warnings for valid ARN {arn!r}, got {warnings}"
        )

    @given(arn=_INVALID_ARN_STRATEGY)
    @settings(max_examples=100)
    def test_prop5_invalid_arns_produce_warnings(self, arn: str) -> None:
        """Invalid ARNs produce a non-empty warning list.

        **Validates: Requirements 13.7**
        """
        warnings = _validate_evaluator_arns([arn])
        assert len(warnings) > 0, (
            f"Expected warnings for invalid ARN {arn!r}, got empty list"
        )


# ---------------------------------------------------------------------------
# Strategies for Property 2
# ---------------------------------------------------------------------------

_AWS_REGION_STRATEGY = st.sampled_from([
    "us-east-1", "us-west-2", "eu-west-1", "ap-southeast-1",
    "eu-central-1", "ap-northeast-1",
])

_MODEL_ID_STRATEGY = st.sampled_from([
    "us.anthropic.claude-sonnet-4-5-20250929-v1:0",
    "us.anthropic.claude-3-haiku-20240307-v1:0",
    "amazon.titan-text-express-v1",
])

_SETUP_DICT_STRATEGY = st.fixed_dictionaries({
    "aws_region": _AWS_REGION_STRATEGY,
    "model_id": _MODEL_ID_STRATEGY,
    "cris_enabled": st.booleans(),
    "aws_profile": st.one_of(st.none(), st.text(min_size=1, max_size=30, alphabet="abcdefghijklmnopqrstuvwxyz-_")),
})

_EVAL_IAM_PERMISSIONS = {
    "bedrock-agentcore:CreateEvaluationConfig",
    "bedrock-agentcore:RunEvaluation",
    "bedrock-agentcore:GetEvaluationResults",
    "logs:CreateLogGroup",
    "logs:PutLogEvents",
}

_EXPECTED_EVALUATOR_NAMES = [
    "Builtin.Helpfulness",
    "Builtin.Correctness",
    "Builtin.GoalSuccessRate",
]


# ---------------------------------------------------------------------------
# Property 2: agentcore.yaml includes evaluations section and IAM
#              permissions when eval enabled
# ---------------------------------------------------------------------------

class TestAgentcoreYamlEvalSection:
    """Property tests for _build_agentcore_yaml() with eval feature.

    # Feature: agentcore-live-observability, Property 2: agentcore.yaml includes evaluations section and IAM permissions when eval enabled
    """

    @given(name=_AGENT_NAME_STRATEGY, setup=_SETUP_DICT_STRATEGY)
    @settings(max_examples=100)
    def test_prop2_eval_feature_adds_evaluations_section(
        self, name: str, setup: dict[str, str]
    ) -> None:
        """Property 2: agentcore.yaml includes evaluations section when eval enabled.

        For any valid agent name and setup dict, calling
        _build_agentcore_yaml(name, setup, features=["eval"]) produces output
        containing an evaluations section with config_name, sampling_rate,
        and evaluators fields.

        **Validates: Requirements 13.2, 13.3**
        """
        output = _build_agentcore_yaml(name, setup, features=["eval"])

        # Evaluations section is present
        assert "evaluations:" in output, (
            "Output must contain 'evaluations:' section when eval feature is enabled"
        )

        # Required fields within evaluations section
        assert "config_name:" in output, (
            "Evaluations section must contain 'config_name:'"
        )
        assert "sampling_rate:" in output, (
            "Evaluations section must contain 'sampling_rate:'"
        )
        assert "evaluators:" in output, (
            "Evaluations section must contain 'evaluators:'"
        )

        # All three built-in evaluators are listed
        for evaluator_name in _EXPECTED_EVALUATOR_NAMES:
            assert evaluator_name in output, (
                f"Evaluations section must include evaluator {evaluator_name!r}"
            )

    @given(name=_AGENT_NAME_STRATEGY, setup=_SETUP_DICT_STRATEGY)
    @settings(max_examples=100)
    def test_prop2_eval_feature_adds_iam_permissions(
        self, name: str, setup: dict[str, str]
    ) -> None:
        """Property 2: agentcore.yaml includes evaluation IAM permissions when eval enabled.

        For any valid agent name and setup dict, calling
        _build_agentcore_yaml(name, setup, features=["eval"]) produces output
        containing all 5 evaluation IAM permissions.

        **Validates: Requirements 13.2, 13.3**
        """
        output = _build_agentcore_yaml(name, setup, features=["eval"])

        for permission in _EVAL_IAM_PERMISSIONS:
            assert permission in output, (
                f"Output must contain IAM permission {permission!r}"
            )

    @given(name=_AGENT_NAME_STRATEGY, setup=_SETUP_DICT_STRATEGY)
    @settings(max_examples=100)
    def test_prop2_no_features_omits_evaluations_section(
        self, name: str, setup: dict[str, str]
    ) -> None:
        """Backward compatibility: calling without features produces no evaluations section.

        **Validates: Requirements 13.2, 13.3**
        """
        output = _build_agentcore_yaml(name, setup)

        assert "evaluations:" not in output, (
            "Output must NOT contain 'evaluations:' when features is not provided"
        )

        # Eval-specific IAM permissions should also be absent
        for permission in _EVAL_IAM_PERMISSIONS:
            assert permission not in output, (
                f"Output must NOT contain eval IAM permission {permission!r} "
                "when features is not provided"
            )


# ---------------------------------------------------------------------------
# Strategies for Properties 3 and 4
# ---------------------------------------------------------------------------

_PROVIDER_CFG_STRATEGY = st.fixed_dictionaries({
    "display": st.sampled_from([
        "AWS AgentCore", "Anthropic (Claude)", "OpenAI (GPT)", "Ollama",
    ]),
    "model": st.sampled_from([
        "us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        "claude-sonnet-4-5",
        "gpt-4o",
        "llama3",
    ]),
})

_INSTRUCTIONS_STRATEGY = st.text(
    min_size=1,
    max_size=100,
    alphabet=st.characters(whitelist_categories=("L", "N", "P", "Z")),
)

_NON_AGENTCORE_PROVIDER_STRATEGY = st.sampled_from([
    "anthropic", "openai", "ollama",
])


# ---------------------------------------------------------------------------
# Property 3: Agent code references eval_config.json when agentcore + eval
#              enabled
# ---------------------------------------------------------------------------

class TestAgentCodeEvalComment:
    """Property tests for _build_agent_code() eval comment behavior.

    # Feature: agentcore-live-observability, Property 3: Agent code references eval_config.json when agentcore + eval enabled
    """

    @given(
        agent_name=_AGENT_NAME_STRATEGY,
        cfg=_PROVIDER_CFG_STRATEGY,
        instructions=_INSTRUCTIONS_STRATEGY,
    )
    @settings(max_examples=100)
    def test_prop3_agentcore_with_eval_contains_eval_config_reference(
        self, agent_name: str, cfg: dict[str, str], instructions: str,
    ) -> None:
        """Property 3: Agent code references eval_config.json when agentcore + eval enabled.

        For any valid agent configuration with provider "agentcore" and "eval"
        in features, the generated agent code contains a comment referencing
        eval_config.json.

        **Validates: Requirements 13.4**
        """
        code = _build_agent_code(
            provider="agentcore",
            cfg=cfg,
            features=["eval"],
            instructions=instructions,
        )
        assert "eval_config.json" in code, (
            "Agent code must reference eval_config.json when provider is "
            "'agentcore' and 'eval' is in features"
        )

    @given(
        agent_name=_AGENT_NAME_STRATEGY,
        cfg=_PROVIDER_CFG_STRATEGY,
        instructions=_INSTRUCTIONS_STRATEGY,
    )
    @settings(max_examples=100)
    def test_prop3_agentcore_without_eval_omits_eval_config_reference(
        self, agent_name: str, cfg: dict[str, str], instructions: str,
    ) -> None:
        """Negative case: agentcore without eval feature omits eval_config.json reference.

        **Validates: Requirements 13.4**
        """
        code = _build_agent_code(
            provider="agentcore",
            cfg=cfg,
            features=[],
            instructions=instructions,
        )
        assert "eval_config.json" not in code, (
            "Agent code must NOT reference eval_config.json when 'eval' is "
            "not in features"
        )


# ---------------------------------------------------------------------------
# Property 4: Non-agentcore providers produce no AgentCore evaluation config
# ---------------------------------------------------------------------------

class TestNonAgentcoreEvalBehavior:
    """Property tests for _build_agent_code() with non-agentcore providers.

    # Feature: agentcore-live-observability, Property 4: Non-agentcore providers produce no AgentCore evaluation config
    """

    @given(
        provider=_NON_AGENTCORE_PROVIDER_STRATEGY,
        cfg=_PROVIDER_CFG_STRATEGY,
        instructions=_INSTRUCTIONS_STRATEGY,
    )
    @settings(max_examples=100)
    def test_prop4_non_agentcore_with_eval_omits_eval_config_reference(
        self, provider: str, cfg: dict[str, str], instructions: str,
    ) -> None:
        """Property 4: Non-agentcore providers produce no AgentCore evaluation config.

        For any provider that is not "agentcore", calling _build_agent_code
        with "eval" in features does NOT produce a reference to
        eval_config.json.

        **Validates: Requirements 13.6**
        """
        code = _build_agent_code(
            provider=provider,
            cfg=cfg,
            features=["eval"],
            instructions=instructions,
        )
        assert "eval_config.json" not in code, (
            f"Agent code for provider {provider!r} must NOT reference "
            "eval_config.json — only agentcore provider should"
        )


# ---------------------------------------------------------------------------
# Imports for Properties 6, 7, 8
# ---------------------------------------------------------------------------

import re
import sys
from dataclasses import asdict
from datetime import datetime, timezone
from unittest.mock import patch

# Mock StaticFiles before importing server module, following the pattern
# from test_ui_evaluations.py.
with patch("starlette.staticfiles.StaticFiles.__init__", return_value=None):
    _srv_mod = "synth.cli._ui_assets.server"
    if _srv_mod in sys.modules:
        del sys.modules[_srv_mod]
    from synth.cli._ui_assets.server import (
        EvaluationConfigStatus,
        EvaluationResult,
        _scrub_credentials,
        _scrub_dict,
    )


# ---------------------------------------------------------------------------
# Strategies for Properties 6, 7, 8
# ---------------------------------------------------------------------------

_EVALUATOR_NAME_STRATEGY = st.text(
    min_size=1,
    max_size=60,
    alphabet=st.characters(whitelist_categories=("L", "N", "P")),
)

_SCORE_STRATEGY = st.floats(min_value=0.0, max_value=1.0, allow_nan=False)

_LEVEL_STRATEGY = st.sampled_from(["SESSION", "TRACE", "TOOL_CALL"])

_ISO_TIMESTAMP_STRATEGY = st.datetimes(
    min_value=datetime(2020, 1, 1),
    max_value=datetime(2030, 12, 31),
    timezones=st.just(timezone.utc),
).map(lambda dt: dt.isoformat())

_CONFIG_NAME_STRATEGY = st.text(
    min_size=1,
    max_size=60,
    alphabet=st.characters(whitelist_categories=("L", "N", "P")),
)

_SAMPLING_RATE_STRATEGY = st.floats(
    min_value=0.0, max_value=1.0, allow_nan=False,
)

_EVALUATOR_LIST_STRATEGY = st.lists(
    _EVALUATOR_NAME_STRATEGY, min_size=1, max_size=10,
)

# AWS access key pattern: AKIA or ASIA followed by 16 uppercase alphanumeric
_ACCESS_KEY_RE = re.compile(r"(AKIA|ASIA)[A-Z0-9]{16}")

_ALPHANUMERIC_UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

_ACCESS_KEY_STRATEGY = st.tuples(
    st.sampled_from(["AKIA", "ASIA"]),
    st.text(
        min_size=16, max_size=16, alphabet=_ALPHANUMERIC_UPPER,
    ),
).map(lambda t: t[0] + t[1])

# Surrounding text that won't accidentally form a credential pattern
_SAFE_TEXT_STRATEGY = st.text(
    min_size=0,
    max_size=40,
    alphabet=st.characters(
        whitelist_categories=("Ll",),  # lowercase only — no AKIA/ASIA risk
    ),
)


# ---------------------------------------------------------------------------
# Property 6: Evaluation results response contains all required fields
# ---------------------------------------------------------------------------

class TestEvaluationResultShape:
    """Property tests for EvaluationResult dataclass serialization.

    # Feature: agentcore-live-observability, Property 6: Evaluation results response contains all required fields
    """

    @given(
        evaluator_name=_EVALUATOR_NAME_STRATEGY,
        score=_SCORE_STRATEGY,
        level=_LEVEL_STRATEGY,
        timestamp=_ISO_TIMESTAMP_STRATEGY,
    )
    @settings(max_examples=100)
    def test_prop6_evaluation_result_contains_all_required_fields(
        self,
        evaluator_name: str,
        score: float,
        level: str,
        timestamp: str,
    ) -> None:
        """Property 6: Evaluation results response contains all required fields.

        For any valid evaluation data, an EvaluationResult instance
        serializes to a dict containing evaluator_name (non-empty string),
        score (float), level (one of SESSION/TRACE/TOOL_CALL), and
        timestamp (ISO 8601 string).

        **Validates: Requirements 14.2**
        """
        result = EvaluationResult(
            evaluator_name=evaluator_name,
            score=score,
            level=level,
            timestamp=timestamp,
        )
        d = asdict(result)

        # All required keys present
        assert "evaluator_name" in d
        assert "score" in d
        assert "level" in d
        assert "timestamp" in d

        # Type and value constraints
        assert isinstance(d["evaluator_name"], str)
        assert len(d["evaluator_name"]) > 0
        assert isinstance(d["score"], float)
        assert 0.0 <= d["score"] <= 1.0
        assert d["level"] in {"SESSION", "TRACE", "TOOL_CALL"}
        assert isinstance(d["timestamp"], str)
        assert len(d["timestamp"]) > 0

        # Round-trip: values match what was passed in
        assert d["evaluator_name"] == evaluator_name
        assert d["score"] == score
        assert d["level"] == level
        assert d["timestamp"] == timestamp


# ---------------------------------------------------------------------------
# Property 7: Evaluation config status contains all required fields
# ---------------------------------------------------------------------------

class TestEvaluationConfigStatusShape:
    """Property tests for EvaluationConfigStatus dataclass serialization.

    # Feature: agentcore-live-observability, Property 7: Evaluation config status contains all required fields
    """

    @given(
        config_name=_CONFIG_NAME_STRATEGY,
        active=st.booleans(),
        sampling_rate=_SAMPLING_RATE_STRATEGY,
        evaluators=_EVALUATOR_LIST_STRATEGY,
    )
    @settings(max_examples=100)
    def test_prop7_evaluation_config_status_contains_all_required_fields(
        self,
        config_name: str,
        active: bool,
        sampling_rate: float,
        evaluators: list[str],
    ) -> None:
        """Property 7: Evaluation config status contains all required fields.

        For any valid eval config, an EvaluationConfigStatus instance
        serializes to a dict containing config_name (non-empty string),
        active (bool), sampling_rate (float 0.0–1.0), and evaluators
        (non-empty list of strings).

        **Validates: Requirements 14.5**
        """
        status = EvaluationConfigStatus(
            config_name=config_name,
            active=active,
            sampling_rate=sampling_rate,
            evaluators=evaluators,
        )
        d = asdict(status)

        # All required keys present
        assert "config_name" in d
        assert "active" in d
        assert "sampling_rate" in d
        assert "evaluators" in d

        # Type and value constraints
        assert isinstance(d["config_name"], str)
        assert len(d["config_name"]) > 0
        assert isinstance(d["active"], bool)
        assert isinstance(d["sampling_rate"], float)
        assert 0.0 <= d["sampling_rate"] <= 1.0
        assert isinstance(d["evaluators"], list)
        assert len(d["evaluators"]) > 0
        assert all(isinstance(e, str) for e in d["evaluators"])

        # Round-trip: values match what was passed in
        assert d["config_name"] == config_name
        assert d["active"] == active
        assert d["sampling_rate"] == sampling_rate
        assert d["evaluators"] == evaluators


# ---------------------------------------------------------------------------
# Property 8: Credential scrubbing removes all credential patterns from
#              evaluation data
# ---------------------------------------------------------------------------

class TestCredentialScrubbingEvaluationData:
    """Property tests for credential scrubbing on evaluation data.

    # Feature: agentcore-live-observability, Property 8: Credential scrubbing removes all credential patterns from evaluation data
    """

    @given(
        prefix=_SAFE_TEXT_STRATEGY,
        access_key=_ACCESS_KEY_STRATEGY,
        suffix=_SAFE_TEXT_STRATEGY,
    )
    @settings(max_examples=100)
    def test_prop8_scrub_credentials_removes_access_key_patterns(
        self,
        prefix: str,
        access_key: str,
        suffix: str,
    ) -> None:
        """Property 8: Credential scrubbing removes all credential patterns.

        For any string containing an AWS access key pattern
        (AKIA/ASIA + 16 alphanumeric chars), applying _scrub_credentials
        produces output containing zero matches for those patterns.

        **Validates: Requirements 14.7**
        """
        text = f"{prefix}{access_key}{suffix}"
        # Confirm the key is present before scrubbing
        assert _ACCESS_KEY_RE.search(text) is not None

        scrubbed = _scrub_credentials(text)
        assert _ACCESS_KEY_RE.search(scrubbed) is None, (
            f"Scrubbed text still contains access key pattern: {scrubbed!r}"
        )

    @given(
        access_key=_ACCESS_KEY_STRATEGY,
        evaluator_name=_EVALUATOR_NAME_STRATEGY,
        score=_SCORE_STRATEGY,
    )
    @settings(max_examples=100)
    def test_prop8_scrub_dict_removes_credentials_from_eval_data(
        self,
        access_key: str,
        evaluator_name: str,
        score: float,
    ) -> None:
        """Property 8: _scrub_dict removes credential patterns from nested dicts.

        For any dict containing AWS access key patterns in string values,
        applying _scrub_dict produces output with zero credential matches.

        **Validates: Requirements 14.7**
        """
        data = {
            "evaluator_name": f"{evaluator_name}-{access_key}",
            "score": score,
            "nested": {
                "key_id": access_key,
                "items": [access_key, "clean-value"],
            },
        }
        scrubbed = _scrub_dict(data)
        serialized = json.dumps(scrubbed)
        assert _ACCESS_KEY_RE.search(serialized) is None, (
            f"Scrubbed dict still contains access key pattern: {serialized!r}"
        )
        # Non-credential values are preserved
        assert scrubbed["score"] == score
        assert scrubbed["nested"]["items"][1] == "clean-value"
