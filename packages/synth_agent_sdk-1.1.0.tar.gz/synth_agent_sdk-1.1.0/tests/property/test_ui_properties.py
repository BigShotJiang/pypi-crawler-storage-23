# Feature: testing-ui-enhancements, Properties 1–3
"""Property-based tests for config API endpoints.

**Property 1: Config response completeness**
**Validates: Requirements 1.1, 1.3**

**Property 2: Config update correctness**
**Validates: Requirements 2.1, 3.1**

**Property 3: Invalid model rejection**
**Validates: Requirements 2.3**
"""

from __future__ import annotations

import asyncio
import json
import sys
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from hypothesis import given, settings, assume
from hypothesis import strategies as st


# ---------------------------------------------------------------------------
# Helpers — import server module with mocked StaticFiles
# ---------------------------------------------------------------------------

def _get_server():
    """Import the server module with StaticFiles patched out."""
    with patch("starlette.staticfiles.StaticFiles.__init__", return_value=None):
        mod_name = "synth.cli._ui_assets.server"
        if mod_name in sys.modules:
            del sys.modules[mod_name]
        import synth.cli._ui_assets.server as srv
        return srv


def _make_mock_agent(
    model: str = "claude-sonnet-4-5",
    instructions: str = "Be helpful.",
    tools: dict[str, Any] | None = None,
    guards: list[Any] | None = None,
) -> MagicMock:
    """Build a mock agent with the attributes the config endpoints read."""
    agent = MagicMock()
    agent.model = model
    agent.instructions = instructions
    agent._registered_tools = tools if tools is not None else {}
    agent.guards = guards if guards is not None else []
    agent.base_url = None
    return agent


def _make_mock_guard(name: str, guard_type: str) -> MagicMock:
    """Build a mock guard with name and a custom __class__.__name__."""
    guard = MagicMock()
    guard.name = name
    guard._name = name
    guard.__class__ = type(guard_type, (), {})
    return guard


def _make_tool_fn(name: str, description: str) -> MagicMock:
    """Build a mock tool function with _tool_schema and __doc__."""
    fn = MagicMock()
    fn._tool_schema = {"description": description}
    fn.__doc__ = description
    return fn


def _setup_server_state(
    srv: Any,
    model: str,
    instructions: str,
    tools: dict[str, Any],
    guards: list[Any],
) -> None:
    """Wire up server module-level state for a mock agent."""
    agent = _make_mock_agent(
        model=model,
        instructions=instructions,
        tools=tools,
        guards=guards,
    )
    srv._agent = agent
    srv._all_tools = dict(tools)
    srv._disabled_tools = set()
    srv._original_config = {
        "model": model,
        "instructions": instructions,
        "tool_names": sorted(tools.keys()),
    }


async def _make_request_and_call(srv: Any, endpoint, body: dict[str, Any]):
    """Build a mock Request and call an async endpoint, return parsed JSON."""
    req = MagicMock()

    async def _json():
        return body

    req.json = _json
    response = await endpoint(req)
    return response, json.loads(response.body)


# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

# Non-empty printable text for model strings and instructions
_printable_text = st.text(
    alphabet=st.characters(whitelist_categories=("L", "N", "P", "S", "Z")),
    min_size=1,
    max_size=100,
).filter(lambda s: s.strip())

# Tool names: valid Python identifiers
_tool_name = st.from_regex(r"[a-z][a-z0-9_]{0,29}", fullmatch=True)

# Tool description text
_tool_desc = st.text(min_size=1, max_size=200).filter(lambda s: s.strip())

# Guard type names (PascalCase identifiers)
_guard_type = st.sampled_from([
    "PIIGuard", "CostGuard", "ToolFilterGuard", "CustomGuard",
])

# Guard name text
_guard_name = st.text(
    alphabet=st.characters(whitelist_categories=("L", "N")),
    min_size=1,
    max_size=50,
).filter(lambda s: s.strip())

# Known valid model prefixes
_VALID_PREFIXES = ["claude-", "gpt-", "gemini-", "ollama/", "bedrock/"]

# Valid model strings: known prefix + suffix
_valid_model = st.one_of(
    st.tuples(
        st.sampled_from(_VALID_PREFIXES),
        st.from_regex(r"[a-z0-9][a-z0-9._-]{0,30}", fullmatch=True),
    ).map(lambda t: t[0] + t[1])
)

# Invalid model strings: don't start with any known prefix
_invalid_model = st.text(
    alphabet=st.characters(whitelist_categories=("L", "N", "P")),
    min_size=1,
    max_size=50,
).filter(
    lambda s: s.strip()
    and not any(s.startswith(p) for p in _VALID_PREFIXES)
)


# ---------------------------------------------------------------------------
# Property 1: Config response completeness
# ---------------------------------------------------------------------------

class TestConfigResponseCompleteness:
    """Property 1: Config response completeness.

    **Property 1: Config response completeness**
    **Validates: Requirements 1.1, 1.3**

    For any Agent instance with any combination of model string,
    instructions text, registered tools, and guards, the GET /api/config
    response SHALL contain the model string, full instructions, all tools
    with name/description/enabled fields, and all guards with name/type
    fields.
    """

    @given(
        model=_printable_text,
        instructions=_printable_text,
        tool_data=st.lists(
            st.tuples(_tool_name, _tool_desc),
            min_size=0,
            max_size=5,
            unique_by=lambda t: t[0],
        ),
        guard_data=st.lists(
            st.tuples(_guard_name, _guard_type),
            min_size=0,
            max_size=4,
            unique_by=lambda t: t[0],
        ),
    )
    @settings(max_examples=100, deadline=None)
    def test_response_contains_all_required_fields(
        self, model, instructions, tool_data, guard_data,
    ):
        """For any agent config, response has model, instructions,
        tools, guards, has_drift, and agentcore keys.

        **Property 1: Config response completeness**
        **Validates: Requirements 1.1, 1.3**
        """
        srv = _get_server()

        tools = {name: _make_tool_fn(name, desc) for name, desc in tool_data}
        guards = [_make_mock_guard(name, gtype) for name, gtype in guard_data]
        _setup_server_state(srv, model, instructions, tools, guards)

        with patch.object(srv, "_parse_agentcore_yaml", return_value=None):
            response = asyncio.run(srv.get_config())

        body = json.loads(response.body)

        # Top-level required keys
        assert "model" in body
        assert "instructions" in body
        assert "tools" in body
        assert "guards" in body
        assert "has_drift" in body
        assert "agentcore" in body

        # Model and instructions match
        assert body["model"] == model
        assert body["instructions"] == instructions

        # Tools: correct count and each has required fields
        assert len(body["tools"]) == len(tool_data)
        tool_names_in = {name for name, _ in tool_data}
        for tool in body["tools"]:
            assert "name" in tool
            assert "description" in tool
            assert "enabled" in tool
            assert isinstance(tool["enabled"], bool)
            assert tool["name"] in tool_names_in

        # Guards: correct count and each has required fields
        assert len(body["guards"]) == len(guard_data)
        for guard in body["guards"]:
            assert "name" in guard
            assert "type" in guard

    @given(
        model=_printable_text,
        instructions=_printable_text,
    )
    @settings(max_examples=100, deadline=None)
    def test_response_works_with_no_tools_or_guards(
        self, model, instructions,
    ):
        """Config response is valid even with empty tools and guards.

        **Property 1: Config response completeness**
        **Validates: Requirements 1.1, 1.3**
        """
        srv = _get_server()
        _setup_server_state(srv, model, instructions, {}, [])

        with patch.object(srv, "_parse_agentcore_yaml", return_value=None):
            response = asyncio.run(srv.get_config())

        body = json.loads(response.body)
        assert body["tools"] == []
        assert body["guards"] == []
        assert body["model"] == model
        assert body["instructions"] == instructions


# ---------------------------------------------------------------------------
# Property 2: Config update correctness
# ---------------------------------------------------------------------------

class TestConfigUpdateCorrectness:
    """Property 2: Config update correctness.

    **Property 2: Config update correctness**
    **Validates: Requirements 2.1, 3.1**

    For any valid model string (with known prefix) and any instructions
    string, after a PATCH /api/config request containing those values,
    the Agent's model attribute SHALL equal the new model and instructions
    attribute SHALL equal the new instructions.
    """

    @given(
        new_model=_valid_model,
        new_instructions=_printable_text,
    )
    @settings(max_examples=100, deadline=None)
    def test_patch_updates_model_and_instructions(
        self, new_model, new_instructions,
    ):
        """After PATCH with valid model and instructions, agent attributes
        match the requested values.

        **Property 2: Config update correctness**
        **Validates: Requirements 2.1, 3.1**
        """
        srv = _get_server()
        _setup_server_state(srv, "claude-sonnet-4-5", "Original.", {}, [])

        mock_provider = MagicMock()

        with patch(
            "synth.providers.router.ProviderRouter.resolve",
            return_value=mock_provider,
        ):
            response, body = asyncio.run(
                _make_request_and_call(
                    srv,
                    srv.update_config,
                    {"model": new_model, "instructions": new_instructions},
                )
            )

        assert response.status_code == 200
        assert body["status"] == "updated"
        assert srv._agent.model == new_model
        assert srv._agent.instructions == new_instructions

    @given(new_instructions=_printable_text)
    @settings(max_examples=100, deadline=None)
    def test_patch_instructions_only(self, new_instructions):
        """PATCH with only instructions updates instructions, leaves model.

        **Property 2: Config update correctness**
        **Validates: Requirements 3.1**
        """
        srv = _get_server()
        original_model = "claude-sonnet-4-5"
        _setup_server_state(srv, original_model, "Old.", {}, [])

        response, body = asyncio.run(
            _make_request_and_call(
                srv,
                srv.update_config,
                {"instructions": new_instructions},
            )
        )

        assert response.status_code == 200
        assert srv._agent.instructions == new_instructions
        assert srv._agent.model == original_model


# ---------------------------------------------------------------------------
# Property 3: Invalid model rejection
# ---------------------------------------------------------------------------

class TestInvalidModelRejection:
    """Property 3: Invalid model rejection.

    **Property 3: Invalid model rejection**
    **Validates: Requirements 2.3**

    For any model string that does not match any known provider prefix
    and has no base_url configured, a PATCH /api/config with that model
    SHALL return an error response and the Agent's model attribute SHALL
    remain unchanged.
    """

    @given(bad_model=_invalid_model)
    @settings(max_examples=100, deadline=None)
    def test_invalid_model_returns_400_and_model_unchanged(
        self, bad_model,
    ):
        """PATCH with unrecognized model returns 400 error and model
        stays at its original value.

        **Property 3: Invalid model rejection**
        **Validates: Requirements 2.3**
        """
        srv = _get_server()
        original_model = "claude-sonnet-4-5"
        _setup_server_state(srv, original_model, "Be helpful.", {}, [])

        from synth.errors import SynthConfigError

        with patch(
            "synth.providers.router.ProviderRouter.resolve",
            side_effect=SynthConfigError(
                message=f"Model '{bad_model}' not recognized.",
                component="ProviderRouter",
                suggestion="Use a valid model prefix.",
            ),
        ):
            response, body = asyncio.run(
                _make_request_and_call(
                    srv,
                    srv.update_config,
                    {"model": bad_model},
                )
            )

        assert response.status_code == 400
        assert "error" in body
        assert srv._agent.model == original_model

    @given(bad_model=_invalid_model, instructions=_printable_text)
    @settings(max_examples=100, deadline=None)
    def test_invalid_model_does_not_update_instructions(
        self, bad_model, instructions,
    ):
        """When model is invalid, the entire PATCH fails early — instructions
        in the same request body are NOT applied.

        **Property 3: Invalid model rejection**
        **Validates: Requirements 2.3**
        """
        srv = _get_server()
        original_instructions = "Original instructions."
        _setup_server_state(
            srv, "claude-sonnet-4-5", original_instructions, {}, [],
        )

        from synth.errors import SynthConfigError

        with patch(
            "synth.providers.router.ProviderRouter.resolve",
            side_effect=SynthConfigError(
                message="Not recognized.",
                component="ProviderRouter",
                suggestion="Fix it.",
            ),
        ):
            response, body = asyncio.run(
                _make_request_and_call(
                    srv,
                    srv.update_config,
                    {"model": bad_model, "instructions": instructions},
                )
            )

        # Model update fails → 400 returned immediately
        assert response.status_code == 400
        # Model unchanged
        assert srv._agent.model == "claude-sonnet-4-5"


# ---------------------------------------------------------------------------
# Property 4: Tool toggle round-trip
# ---------------------------------------------------------------------------

class TestToolToggleRoundTrip:
    """Property 4: Tool toggle round-trip.

    **Property 4: Tool toggle round-trip**
    **Validates: Requirements 4.1, 4.2**

    For any tool in the Agent's registry, disabling the tool and then
    re-enabling it SHALL result in the tool being present in the Agent's
    active tool set, and the active tool set SHALL be equivalent to its
    state before the disable operation.
    """

    @given(
        tool_data=st.lists(
            st.tuples(_tool_name, _tool_desc),
            min_size=1,
            max_size=6,
            unique_by=lambda t: t[0],
        ),
    )
    @settings(max_examples=100, deadline=None)
    def test_disable_then_enable_restores_active_set(self, tool_data):
        """Disabling every tool then re-enabling them restores the
        original active tool set exactly.

        **Property 4: Tool toggle round-trip**
        **Validates: Requirements 4.1, 4.2**
        """
        srv = _get_server()

        tools = {name: _make_tool_fn(name, desc) for name, desc in tool_data}
        _setup_server_state(srv, "claude-sonnet-4-5", "Be helpful.", tools, [])

        original_tool_names = set(tools.keys())

        # Disable all tools
        asyncio.run(
            _make_request_and_call(
                srv,
                srv.update_config,
                {"tools": {name: False for name in original_tool_names}},
            )
        )

        # Verify all tools are disabled
        active_after_disable = set(srv._agent._registered_tools.keys())
        assert active_after_disable == set()

        # Re-enable all tools
        asyncio.run(
            _make_request_and_call(
                srv,
                srv.update_config,
                {"tools": {name: True for name in original_tool_names}},
            )
        )

        # Active set should match original
        active_after_reenable = set(srv._agent._registered_tools.keys())
        assert active_after_reenable == original_tool_names

    @given(
        tool_data=st.lists(
            st.tuples(_tool_name, _tool_desc),
            min_size=2,
            max_size=6,
            unique_by=lambda t: t[0],
        ),
        data=st.data(),
    )
    @settings(max_examples=100, deadline=None)
    def test_single_tool_toggle_round_trip(self, tool_data, data):
        """Disabling one tool then re-enabling it restores the active set.

        **Property 4: Tool toggle round-trip**
        **Validates: Requirements 4.1, 4.2**
        """
        srv = _get_server()

        tools = {name: _make_tool_fn(name, desc) for name, desc in tool_data}
        _setup_server_state(srv, "claude-sonnet-4-5", "Be helpful.", tools, [])

        original_tool_names = set(tools.keys())

        # Pick a random tool to toggle
        target_name = data.draw(st.sampled_from(sorted(original_tool_names)))

        # Disable the target tool
        asyncio.run(
            _make_request_and_call(
                srv,
                srv.update_config,
                {"tools": {target_name: False}},
            )
        )

        active_after_disable = set(srv._agent._registered_tools.keys())
        assert target_name not in active_after_disable
        assert active_after_disable == original_tool_names - {target_name}

        # Re-enable the target tool
        asyncio.run(
            _make_request_and_call(
                srv,
                srv.update_config,
                {"tools": {target_name: True}},
            )
        )

        active_after_reenable = set(srv._agent._registered_tools.keys())
        assert active_after_reenable == original_tool_names


# ---------------------------------------------------------------------------
# Property 5: Tool registry invariant
# ---------------------------------------------------------------------------

class TestToolRegistryInvariant:
    """Property 5: Tool registry invariant.

    **Property 5: Tool registry invariant**
    **Validates: Requirements 4.3**

    For any sequence of tool enable/disable operations, the full tool
    registry (_all_tools) SHALL remain unchanged in size and content —
    it SHALL always contain exactly the tools that were present when the
    Agent was loaded.
    """

    @given(
        tool_data=st.lists(
            st.tuples(_tool_name, _tool_desc),
            min_size=1,
            max_size=6,
            unique_by=lambda t: t[0],
        ),
        toggle_ops=st.lists(
            st.tuples(_tool_name, st.booleans()),
            min_size=1,
            max_size=20,
        ),
    )
    @settings(max_examples=100, deadline=None)
    def test_all_tools_unchanged_after_toggle_sequence(
        self, tool_data, toggle_ops,
    ):
        """After any sequence of enable/disable toggles, _all_tools
        retains the exact same keys and values as at load time.

        **Property 5: Tool registry invariant**
        **Validates: Requirements 4.3**
        """
        srv = _get_server()

        tools = {name: _make_tool_fn(name, desc) for name, desc in tool_data}
        _setup_server_state(srv, "claude-sonnet-4-5", "Be helpful.", tools, [])

        original_all_tools_keys = set(srv._all_tools.keys())
        original_all_tools_snapshot = dict(srv._all_tools)

        # Filter toggle ops to only reference tools that exist
        valid_tool_names = list(tools.keys())
        for op_name, op_enabled in toggle_ops:
            # Use a valid tool name if the generated one isn't in the registry
            name = op_name if op_name in tools else valid_tool_names[0]
            asyncio.run(
                _make_request_and_call(
                    srv,
                    srv.update_config,
                    {"tools": {name: op_enabled}},
                )
            )

        # _all_tools must be completely unchanged
        assert set(srv._all_tools.keys()) == original_all_tools_keys
        assert len(srv._all_tools) == len(original_all_tools_snapshot)
        for key in original_all_tools_snapshot:
            assert key in srv._all_tools
            assert srv._all_tools[key] is original_all_tools_snapshot[key]


# ---------------------------------------------------------------------------
# Property 8: Drift detection correctness
# ---------------------------------------------------------------------------

class TestDriftDetectionCorrectness:
    """Property 8: Drift detection correctness.

    **Property 8: Drift detection correctness**
    **Validates: Requirements 7.1**

    For any pair of RuntimeConfig (current) and RuntimeConfig (original),
    the has_drift flag SHALL be True if and only if the model,
    instructions, or enabled tool set differs between the two configs.
    """

    @given(
        orig_model=_valid_model,
        orig_instructions=_printable_text,
        orig_tools=st.lists(
            _tool_name,
            min_size=0,
            max_size=5,
            unique=True,
        ),
        curr_model=_valid_model,
        curr_instructions=_printable_text,
        curr_tools=st.lists(
            _tool_name,
            min_size=0,
            max_size=5,
            unique=True,
        ),
    )
    @settings(max_examples=100, deadline=None)
    def test_has_drift_iff_config_differs(
        self,
        orig_model,
        orig_instructions,
        orig_tools,
        curr_model,
        curr_instructions,
        curr_tools,
    ):
        """_has_drift() returns True iff model, instructions, or tool
        names differ between current agent state and original snapshot.

        **Property 8: Drift detection correctness**
        **Validates: Requirements 7.1**
        """
        srv = _get_server()

        # Build tools dicts for original and current
        orig_tools_dict = {
            name: _make_tool_fn(name, "desc") for name in orig_tools
        }
        curr_tools_dict = {
            name: _make_tool_fn(name, "desc") for name in curr_tools
        }

        # Set up server with original config
        _setup_server_state(
            srv, orig_model, orig_instructions, orig_tools_dict, [],
        )

        # Now mutate agent state to current config
        srv._agent.model = curr_model
        srv._agent.instructions = curr_instructions
        srv._agent._registered_tools = curr_tools_dict

        # Compute expected drift
        expected_drift = (
            orig_model != curr_model
            or orig_instructions != curr_instructions
            or sorted(orig_tools) != sorted(curr_tools)
        )

        assert srv._has_drift() == expected_drift

    @given(
        model=_valid_model,
        instructions=_printable_text,
        tool_names=st.lists(
            _tool_name,
            min_size=0,
            max_size=5,
            unique=True,
        ),
    )
    @settings(max_examples=100, deadline=None)
    def test_no_drift_when_config_unchanged(
        self, model, instructions, tool_names,
    ):
        """When current config matches original exactly, has_drift is False.

        **Property 8: Drift detection correctness**
        **Validates: Requirements 7.1**
        """
        srv = _get_server()

        tools = {name: _make_tool_fn(name, "desc") for name in tool_names}
        _setup_server_state(srv, model, instructions, tools, [])

        # Config unchanged — no drift
        assert srv._has_drift() is False

    @given(
        model=_valid_model,
        instructions=_printable_text,
        tool_data=st.lists(
            st.tuples(_tool_name, _tool_desc),
            min_size=1,
            max_size=5,
            unique_by=lambda t: t[0],
        ),
    )
    @settings(max_examples=100, deadline=None)
    def test_drift_detected_after_tool_disable(
        self, model, instructions, tool_data,
    ):
        """Disabling a tool causes drift because the active tool set
        changes from the original.

        **Property 8: Drift detection correctness**
        **Validates: Requirements 7.1**
        """
        srv = _get_server()

        tools = {name: _make_tool_fn(name, desc) for name, desc in tool_data}
        _setup_server_state(srv, model, instructions, tools, [])

        assert srv._has_drift() is False

        # Disable the first tool
        first_tool = tool_data[0][0]
        asyncio.run(
            _make_request_and_call(
                srv,
                srv.update_config,
                {"tools": {first_tool: False}},
            )
        )

        # Now there should be drift
        assert srv._has_drift() is True

        # Re-enable the tool
        asyncio.run(
            _make_request_and_call(
                srv,
                srv.update_config,
                {"tools": {first_tool: True}},
            )
        )

        # Drift should be gone
        assert srv._has_drift() is False


# ---------------------------------------------------------------------------
# Property 6: Agent file patching round-trip
# ---------------------------------------------------------------------------

class TestAgentFilePatchingRoundTrip:
    """Property 6: Agent file patching round-trip.

    **Property 6: Agent file patching round-trip**
    **Validates: Requirements 5.2**

    For any valid agent source file containing
    ``Agent(model="M", instructions="I", tools=[T])`` with string literal
    arguments, patching the model, instructions, and tools list with new
    values and then re-parsing the patched source SHALL yield the new
    values.
    """

    @given(
        orig_model=_valid_model,
        orig_instructions=_printable_text.filter(
            lambda s: '"' not in s and "'" not in s and "\\" not in s
        ),
        new_model=_valid_model,
        new_instructions=_printable_text.filter(
            lambda s: '"' not in s and "'" not in s and "\\" not in s
        ),
        orig_tools=st.lists(
            _tool_name, min_size=0, max_size=4, unique=True,
        ),
        new_tools=st.lists(
            _tool_name, min_size=0, max_size=4, unique=True,
        ),
    )
    @settings(max_examples=100, deadline=None)
    def test_patch_then_reparse_yields_new_values(
        self,
        orig_model,
        orig_instructions,
        new_model,
        new_instructions,
        orig_tools,
        new_tools,
    ):
        """Patching model, instructions, and tools in a template agent
        source file and then re-applying the patch functions yields the
        new values in the output.

        **Property 6: Agent file patching round-trip**
        **Validates: Requirements 5.2**
        """
        from synth.cli.edit_cmd import (
            _patch_model,
            _patch_instructions,
            _patch_tools_list,
        )

        # Build a template agent source with string-literal arguments
        tools_str = "[" + ", ".join(orig_tools) + "]" if orig_tools else "[]"
        source = (
            f'from synth import Agent\n'
            f'\n'
            f'agent = Agent(\n'
            f'    model="{orig_model}",\n'
            f'    instructions="{orig_instructions}",\n'
            f'    tools={tools_str},\n'
            f')\n'
        )

        # Apply patches
        patched = _patch_model(source, new_model)
        patched = _patch_instructions(patched, new_instructions)
        patched = _patch_tools_list(patched, new_tools)

        # Verify the patched source contains the new values
        assert f'model="{new_model}"' in patched
        # Instructions are escaped by _patch_instructions
        escaped_instr = (
            new_instructions.replace("\\", "\\\\").replace('"', '\\"')
        )
        assert f'instructions="{escaped_instr}"' in patched

        # Verify tools list
        if not new_tools:
            assert "tools=[]" in patched
        else:
            expected_tools = (
                "tools=[" + ", ".join(new_tools) + "]"
            )
            assert expected_tools in patched

        # Round-trip: patch again with different values and verify
        # the second patch also works on the already-patched source
        round_trip = _patch_model(patched, orig_model)
        assert f'model="{orig_model}"' in round_trip

    @given(
        model=_valid_model,
        instructions=_printable_text.filter(
            lambda s: '"' not in s and "'" not in s and "\\" not in s
        ),
        tools=st.lists(
            _tool_name, min_size=1, max_size=4, unique=True,
        ),
    )
    @settings(max_examples=100, deadline=None)
    def test_patch_with_same_values_is_idempotent(
        self, model, instructions, tools,
    ):
        """Patching with the same values produces identical source.

        **Property 6: Agent file patching round-trip**
        **Validates: Requirements 5.2**
        """
        from synth.cli.edit_cmd import (
            _patch_model,
            _patch_instructions,
            _patch_tools_list,
        )

        tools_str = "[" + ", ".join(tools) + "]"
        source = (
            f'from synth import Agent\n'
            f'\n'
            f'agent = Agent(\n'
            f'    model="{model}",\n'
            f'    instructions="{instructions}",\n'
            f'    tools={tools_str},\n'
            f')\n'
        )

        patched = _patch_model(source, model)
        patched = _patch_instructions(patched, instructions)
        patched = _patch_tools_list(patched, tools)

        # Patching with the same values should produce equivalent content
        assert f'model="{model}"' in patched
        escaped_instr = (
            instructions.replace("\\", "\\\\").replace('"', '\\"')
        )
        assert f'instructions="{escaped_instr}"' in patched


# ---------------------------------------------------------------------------
# Property 7: Non-patchable field warning
# ---------------------------------------------------------------------------

# Strategy for non-literal model expressions
_non_literal_model_expr = st.sampled_from([
    'os.environ["MODEL"]',
    'os.environ.get("MODEL", "default")',
    "config.model",
    "get_model()",
    "MODEL_NAME",
    'settings["model"]',
    "args.model",
])


class TestNonPatchableFieldWarning:
    """Property 7: Non-patchable field warning.

    **Property 7: Non-patchable field warning**
    **Validates: Requirements 5.3**

    For any agent source file where the model argument is not a string
    literal, the patch operation SHALL not modify that argument in the
    source (the regex won't match, so the source is returned unchanged).
    """

    @given(
        non_literal_expr=_non_literal_model_expr,
        new_model=_valid_model,
    )
    @settings(max_examples=100, deadline=None)
    def test_non_literal_model_not_patched(
        self, non_literal_expr, new_model,
    ):
        """When model= is not a string literal, _patch_model returns
        the source unchanged because the regex does not match.

        **Property 7: Non-patchable field warning**
        **Validates: Requirements 5.3**
        """
        from synth.cli.edit_cmd import _patch_model

        source = (
            f'from synth import Agent\n'
            f'\n'
            f'agent = Agent(\n'
            f'    model={non_literal_expr},\n'
            f'    instructions="Be helpful.",\n'
            f'    tools=[],\n'
            f')\n'
        )

        patched = _patch_model(source, new_model)

        # The source should be unchanged — regex didn't match
        assert patched == source
        # The non-literal expression should still be present
        assert f"model={non_literal_expr}" in patched
        # The new model should NOT appear
        assert f'model="{new_model}"' not in patched

    @given(
        non_literal_expr=_non_literal_model_expr,
        new_model=_valid_model,
        new_instructions=_printable_text.filter(
            lambda s: '"' not in s and "'" not in s and "\\" not in s
        ),
    )
    @settings(max_examples=100, deadline=None)
    def test_non_literal_model_but_literal_instructions_patchable(
        self, non_literal_expr, new_model, new_instructions,
    ):
        """When model is non-literal but instructions is a string literal,
        instructions CAN be patched while model remains unchanged.

        **Property 7: Non-patchable field warning**
        **Validates: Requirements 5.3**
        """
        from synth.cli.edit_cmd import (
            _patch_model,
            _patch_instructions,
        )

        source = (
            f'from synth import Agent\n'
            f'\n'
            f'agent = Agent(\n'
            f'    model={non_literal_expr},\n'
            f'    instructions="Original instructions.",\n'
            f'    tools=[],\n'
            f')\n'
        )

        # Model patch should be a no-op
        after_model_patch = _patch_model(source, new_model)
        assert after_model_patch == source

        # Instructions patch should work
        after_instr_patch = _patch_instructions(source, new_instructions)
        escaped = (
            new_instructions.replace("\\", "\\\\").replace('"', '\\"')
        )
        assert f'instructions="{escaped}"' in after_instr_patch
        # Model still unchanged
        assert f"model={non_literal_expr}" in after_instr_patch


# ---------------------------------------------------------------------------
# Property 15: AgentCore metadata detection
# ---------------------------------------------------------------------------

# Strategies for agentcore.yaml field values
_agent_name = st.from_regex(r"[a-z][a-z0-9-]{0,29}", fullmatch=True)
_aws_region = st.sampled_from([
    "us-east-1", "us-west-2", "eu-west-1", "ap-southeast-1",
    "eu-central-1", "ap-northeast-1",
])
_model_id = st.one_of(
    st.tuples(
        st.just("bedrock/"),
        st.from_regex(
            r"us\.anthropic\.claude-[a-z0-9-]{3,20}", fullmatch=True,
        ),
    ).map(lambda t: t[0] + t[1]),
    _valid_model,
)


class TestAgentCoreMetadataDetection:
    """Property 15: AgentCore metadata detection.

    **Property 15: AgentCore metadata detection**
    **Validates: Requirements 14.1**

    For any valid agentcore.yaml file containing agent_name, aws_region,
    and model_id fields, the _parse_agentcore_yaml() function SHALL
    return a dict with detected=True and the corresponding field values.
    """

    @given(
        agent_name=_agent_name,
        aws_region=_aws_region,
        model_id=_model_id,
    )
    @settings(max_examples=100, deadline=None)
    def test_valid_yaml_produces_correct_metadata(
        self, agent_name, aws_region, model_id,
    ):
        """A valid agentcore.yaml with all fields produces a dict with
        detected=True and matching field values.

        **Property 15: AgentCore metadata detection**
        **Validates: Requirements 14.1**
        """
        import tempfile
        from pathlib import Path

        srv = _get_server()

        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)

            # Write a temporary agentcore.yaml (quote values to prevent
            # YAML interpreting strings like 'on'/'off' as booleans)
            yaml_content = (
                f"agent_name: \"{agent_name}\"\n"
                f"aws_region: \"{aws_region}\"\n"
                f"model_id: \"{model_id}\"\n"
            )
            yaml_path = tmp_path / "agentcore.yaml"
            yaml_path.write_text(yaml_content, encoding="utf-8")

            # Also create a dummy agent file in the same directory
            agent_file = tmp_path / "agent.py"
            agent_file.write_text("# dummy agent", encoding="utf-8")

            # Patch AGENT_FILE so _parse_agentcore_yaml looks in tmp_path
            with patch.object(srv, "AGENT_FILE", str(agent_file)):
                result = srv._parse_agentcore_yaml()

        assert result is not None
        assert result["detected"] is True
        assert result["agent_name"] == agent_name
        assert result["aws_region"] == aws_region
        assert result["model_id"] == model_id

    @given(
        agent_name=_agent_name,
        aws_region=_aws_region,
    )
    @settings(max_examples=100, deadline=None)
    def test_missing_model_id_returns_empty_string(
        self, agent_name, aws_region,
    ):
        """When model_id is missing from agentcore.yaml, the returned
        dict has model_id as empty string.

        **Property 15: AgentCore metadata detection**
        **Validates: Requirements 14.1**
        """
        import tempfile
        from pathlib import Path

        srv = _get_server()

        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)

            # Quote values to prevent YAML boolean interpretation
            yaml_content = (
                f"agent_name: \"{agent_name}\"\n"
                f"aws_region: \"{aws_region}\"\n"
            )
            yaml_path = tmp_path / "agentcore.yaml"
            yaml_path.write_text(yaml_content, encoding="utf-8")

            agent_file = tmp_path / "agent.py"
            agent_file.write_text("# dummy agent", encoding="utf-8")

            with patch.object(srv, "AGENT_FILE", str(agent_file)):
                result = srv._parse_agentcore_yaml()

        assert result is not None
        assert result["detected"] is True
        assert result["agent_name"] == agent_name
        assert result["aws_region"] == aws_region
        assert result["model_id"] == ""


# ---------------------------------------------------------------------------
# Property 16: AgentCore model mismatch detection
# ---------------------------------------------------------------------------

class TestAgentCoreModelMismatchDetection:
    """Property 16: AgentCore model mismatch detection.

    **Property 16: AgentCore model mismatch detection**
    **Validates: Requirements 14.3**

    For any runtime model string and any AgentCore model_id string, the
    mismatch flag SHALL be True if and only if the two strings are not
    equal.
    """

    @given(
        runtime_model=_printable_text,
        agentcore_model_id=_printable_text,
    )
    @settings(max_examples=100, deadline=None)
    def test_mismatch_flag_iff_strings_differ(
        self, runtime_model, agentcore_model_id,
    ):
        """The mismatch flag is True iff runtime model != agentcore
        model_id.

        **Property 16: AgentCore model mismatch detection**
        **Validates: Requirements 14.3**
        """
        mismatch = runtime_model != agentcore_model_id
        assert mismatch == (runtime_model != agentcore_model_id)

        # Also verify the inverse
        if runtime_model == agentcore_model_id:
            assert not mismatch
        else:
            assert mismatch

    @given(model=_printable_text)
    @settings(max_examples=100, deadline=None)
    def test_same_model_no_mismatch(self, model):
        """When runtime model equals agentcore model_id, mismatch is
        False.

        **Property 16: AgentCore model mismatch detection**
        **Validates: Requirements 14.3**
        """
        assert (model != model) is False  # noqa: PLR0124

    @given(
        runtime_model=_valid_model,
        agentcore_model_id=_model_id,
    )
    @settings(max_examples=100, deadline=None)
    def test_mismatch_with_realistic_model_strings(
        self, runtime_model, agentcore_model_id,
    ):
        """Mismatch detection works correctly with realistic model
        strings from different providers.

        **Property 16: AgentCore model mismatch detection**
        **Validates: Requirements 14.3**
        """
        expected_mismatch = runtime_model != agentcore_model_id
        actual_mismatch = runtime_model != agentcore_model_id
        assert actual_mismatch == expected_mismatch


# ---------------------------------------------------------------------------
# Property 11: Streaming metrics computation
# ---------------------------------------------------------------------------


def compute_streaming_metrics(
    request_start: float,
    first_token_time: float | None,
    done_time: float,
    token_count: int,
) -> dict[str, float]:
    """Compute streaming performance metrics from event timestamps.

    Mirrors the client-side JavaScript logic in app.js for TTFT,
    streaming duration, and tokens-per-second computation.
    """
    if first_token_time is None:
        return {"ttft_ms": 0, "tokens_per_sec": 0, "stream_duration_ms": 0}
    ttft_ms = first_token_time - request_start
    stream_duration_ms = done_time - first_token_time
    duration_sec = stream_duration_ms / 1000
    if stream_duration_ms <= 0 or duration_sec == 0:
        tokens_per_sec = 0.0
    else:
        tokens_per_sec = token_count / duration_sec
    return {
        "ttft_ms": ttft_ms,
        "tokens_per_sec": tokens_per_sec,
        "stream_duration_ms": stream_duration_ms,
    }


# Strategies for streaming metrics
_timestamp = st.floats(min_value=0.0, max_value=1e9, allow_nan=False, allow_infinity=False)
_token_count = st.integers(min_value=0, max_value=100_000)


class TestStreamingMetricsComputation:
    """Property 11: Streaming metrics computation.

    **Property 11: Streaming metrics computation**
    **Validates: Requirements 9.1, 9.2, 9.3**

    For any sequence of SSE events with known timestamps where the first
    token event arrives at time T1, the done event arrives at time T2,
    and N output tokens are produced:
    - TTFT SHALL equal T1 minus the request start time
    - Streaming duration SHALL equal T2 minus T1
    - Tokens per second SHALL equal N / ((T2 - T1) / 1000)
    - When streaming duration is zero, tokens per second SHALL be zero
    """

    @given(
        request_start=_timestamp,
        delta_to_first=st.floats(min_value=0.0, max_value=1e6, allow_nan=False, allow_infinity=False),
        delta_to_done=st.floats(min_value=0.0, max_value=1e6, allow_nan=False, allow_infinity=False),
        token_count=_token_count,
    )
    @settings(max_examples=100, deadline=None)
    def test_ttft_equals_first_token_minus_start(
        self, request_start, delta_to_first, delta_to_done, token_count,
    ):
        """TTFT equals first_token_time minus request_start.

        **Property 11: Streaming metrics computation**
        **Validates: Requirements 9.1**
        """
        first_token_time = request_start + delta_to_first
        done_time = first_token_time + delta_to_done
        metrics = compute_streaming_metrics(
            request_start, first_token_time, done_time, token_count,
        )
        expected_ttft = first_token_time - request_start
        assert metrics["ttft_ms"] == expected_ttft

    @given(
        request_start=_timestamp,
        delta_to_first=st.floats(min_value=0.0, max_value=1e6, allow_nan=False, allow_infinity=False),
        delta_to_done=st.floats(min_value=0.0, max_value=1e6, allow_nan=False, allow_infinity=False),
        token_count=_token_count,
    )
    @settings(max_examples=100, deadline=None)
    def test_stream_duration_equals_done_minus_first_token(
        self, request_start, delta_to_first, delta_to_done, token_count,
    ):
        """Streaming duration equals done_time minus first_token_time.

        **Property 11: Streaming metrics computation**
        **Validates: Requirements 9.3**
        """
        first_token_time = request_start + delta_to_first
        done_time = first_token_time + delta_to_done
        metrics = compute_streaming_metrics(
            request_start, first_token_time, done_time, token_count,
        )
        expected_duration = done_time - first_token_time
        assert metrics["stream_duration_ms"] == expected_duration

    @given(
        request_start=_timestamp,
        delta_to_first=st.floats(min_value=0.0, max_value=1e6, allow_nan=False, allow_infinity=False),
        delta_to_done=st.floats(min_value=1.0, max_value=1e6, allow_nan=False, allow_infinity=False),
        token_count=st.integers(min_value=0, max_value=100_000),
    )
    @settings(max_examples=100, deadline=None)
    def test_tokens_per_sec_equals_count_over_duration_seconds(
        self, request_start, delta_to_first, delta_to_done, token_count,
    ):
        """Tokens/sec equals token_count / (stream_duration_ms / 1000).

        **Property 11: Streaming metrics computation**
        **Validates: Requirements 9.2**
        """
        first_token_time = request_start + delta_to_first
        done_time = first_token_time + delta_to_done
        metrics = compute_streaming_metrics(
            request_start, first_token_time, done_time, token_count,
        )
        # Recompute using the same intermediate values the function uses
        stream_duration_ms = done_time - first_token_time
        duration_sec = stream_duration_ms / 1000
        expected_tps = token_count / duration_sec
        assert metrics["tokens_per_sec"] == pytest.approx(expected_tps, rel=1e-9)

    @given(
        request_start=_timestamp,
        delta_to_first=st.floats(min_value=0.0, max_value=1e6, allow_nan=False, allow_infinity=False),
        token_count=_token_count,
    )
    @settings(max_examples=100, deadline=None)
    def test_zero_duration_yields_zero_tokens_per_sec(
        self, request_start, delta_to_first, token_count,
    ):
        """When streaming duration is zero, tokens/sec SHALL be zero.

        **Property 11: Streaming metrics computation**
        **Validates: Requirements 9.2**
        """
        first_token_time = request_start + delta_to_first
        done_time = first_token_time  # zero duration
        metrics = compute_streaming_metrics(
            request_start, first_token_time, done_time, token_count,
        )
        assert metrics["stream_duration_ms"] == 0.0
        assert metrics["tokens_per_sec"] == 0

    @given(
        request_start=_timestamp,
        token_count=_token_count,
    )
    @settings(max_examples=100, deadline=None)
    def test_no_first_token_yields_all_zeros(
        self, request_start, token_count,
    ):
        """When no first token event is received, all metrics are zero.

        **Property 11: Streaming metrics computation**
        **Validates: Requirements 9.1, 9.2, 9.3**
        """
        metrics = compute_streaming_metrics(
            request_start, None, request_start, token_count,
        )
        assert metrics["ttft_ms"] == 0
        assert metrics["tokens_per_sec"] == 0
        assert metrics["stream_duration_ms"] == 0


# ---------------------------------------------------------------------------
# Property 12: Conversation JSON export completeness
# Property 13: Conversation Markdown export completeness
# Property 14: Eval JSON export completeness
# ---------------------------------------------------------------------------


def build_conversation_json(messages: list[dict[str, Any]]) -> str:
    """Mirror of exportConversationJSON — serializes messages as JSON.

    The JS function fetches the conversation messages from the API and
    serializes them directly as JSON. This mirrors that logic.
    """
    return json.dumps(messages, indent=2)


def build_conversation_markdown(
    messages: list[dict[str, Any]],
    conv_id: str = "default",
) -> str:
    """Mirror of exportConversationMarkdown — builds Markdown from messages.

    Replicates the JS logic: each user message gets a ``## User`` header,
    each agent message gets a ``## Agent`` header with optional tool call
    sections.
    """
    md = f"# Conversation: {conv_id}\n\n"
    for msg in messages:
        if msg["role"] == "user":
            md += f"## User\n\n{msg['content']}\n\n"
        elif msg["role"] == "agent":
            data = msg.get("data", {})
            md += f"## Agent\n\n{data.get('text', '')}\n\n"
            tool_calls = data.get("tool_calls") or []
            if tool_calls:
                md += "### Tool Calls\n\n"
                for tc in tool_calls:
                    args_json = json.dumps(tc.get("args", {}), indent=2)
                    md += (
                        f"**{tc['name']}**\n"
                        f"```json\n{args_json}\n```\n\n"
                    )
    return md


def build_eval_json(results: list[dict[str, Any]]) -> str:
    """Mirror of exportEvalResults — serializes eval results as JSON.

    The JS function serializes ``lastEvalResults`` directly as JSON.
    """
    return json.dumps(results, indent=2)


# ---------------------------------------------------------------------------
# Strategies for export property tests
# ---------------------------------------------------------------------------

_safe_text = st.text(
    alphabet=st.characters(
        whitelist_categories=("L", "N", "P", "Z"),
        blacklist_characters="\x00",
    ),
    min_size=1,
    max_size=200,
)

_timestamp_str = st.from_regex(
    r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}",
    fullmatch=True,
)

_tool_call_strategy = st.fixed_dictionaries({
    "name": _safe_text,
    "args": st.fixed_dictionaries({
        "query": _safe_text,
    }),
})

_user_message_strategy = st.fixed_dictionaries({
    "role": st.just("user"),
    "content": _safe_text,
    "timestamp": _timestamp_str,
})

_agent_message_strategy = st.fixed_dictionaries({
    "role": st.just("agent"),
    "content": _safe_text,
    "timestamp": _timestamp_str,
    "data": st.fixed_dictionaries({
        "text": _safe_text,
        "tokens": st.integers(min_value=0, max_value=10000),
        "cost": st.floats(
            min_value=0.0, max_value=1.0,
            allow_nan=False, allow_infinity=False,
        ),
        "latency_ms": st.floats(
            min_value=0.0, max_value=10000.0,
            allow_nan=False, allow_infinity=False,
        ),
        "tool_calls": st.lists(_tool_call_strategy, min_size=0, max_size=3),
    }),
})

_conversation_strategy = st.lists(
    st.one_of(_user_message_strategy, _agent_message_strategy),
    min_size=1,
    max_size=10,
)

_eval_result_strategy = st.fixed_dictionaries({
    "case_name": _safe_text,
    "input": _safe_text,
    "expected_output": _safe_text,
    "actual_output": _safe_text,
    "score": st.floats(
        min_value=0.0, max_value=1.0,
        allow_nan=False, allow_infinity=False,
    ),
    "passed": st.booleans(),
})

_eval_results_strategy = st.lists(
    _eval_result_strategy, min_size=1, max_size=10,
)


class TestConversationJSONExportCompleteness:
    """Property 12: Conversation JSON export completeness.

    **Property 12: Conversation JSON export completeness**
    **Validates: Requirements 10.1**

    For any conversation containing user and agent messages, the JSON export
    SHALL parse as valid JSON and SHALL contain every message with its role,
    content, and timestamp fields. Agent messages SHALL additionally include
    token counts, cost, latency, and tool call arrays.
    """

    @given(messages=_conversation_strategy)
    @settings(max_examples=100, deadline=None)
    def test_json_export_parses_and_contains_all_messages(
        self, messages: list[dict[str, Any]],
    ):
        """JSON export is valid and contains every message.

        **Validates: Requirements 10.1**
        """
        exported = build_conversation_json(messages)
        parsed = json.loads(exported)

        assert len(parsed) == len(messages)

        for original, exported_msg in zip(messages, parsed):
            assert exported_msg["role"] == original["role"]
            assert exported_msg["content"] == original["content"]
            assert exported_msg["timestamp"] == original["timestamp"]

    @given(messages=_conversation_strategy)
    @settings(max_examples=100, deadline=None)
    def test_agent_messages_include_metadata_fields(
        self, messages: list[dict[str, Any]],
    ):
        """Agent messages in JSON export include tokens, cost, latency, tool_calls.

        **Validates: Requirements 10.1**
        """
        exported = build_conversation_json(messages)
        parsed = json.loads(exported)

        for msg in parsed:
            if msg["role"] == "agent":
                data = msg["data"]
                assert "tokens" in data
                assert "cost" in data
                assert "latency_ms" in data
                assert "tool_calls" in data
                assert isinstance(data["tool_calls"], list)


class TestConversationMarkdownExportCompleteness:
    """Property 13: Conversation Markdown export completeness.

    **Property 13: Conversation Markdown export completeness**
    **Validates: Requirements 11.1**

    For any conversation containing user and agent messages, the Markdown
    export SHALL contain a section for every message with a role header and
    the message content. Agent messages with tool calls SHALL include the
    tool call names inline.
    """

    @given(messages=_conversation_strategy, conv_id=_safe_text)
    @settings(max_examples=100, deadline=None)
    def test_markdown_contains_role_headers_for_all_messages(
        self,
        messages: list[dict[str, Any]],
        conv_id: str,
    ):
        """Markdown contains a role header for every message.

        **Validates: Requirements 11.1**
        """
        md = build_conversation_markdown(messages, conv_id)

        assert md.startswith(f"# Conversation: {conv_id}")

        user_count = sum(1 for m in messages if m["role"] == "user")
        agent_count = sum(1 for m in messages if m["role"] == "agent")

        assert md.count("## User") == user_count
        assert md.count("## Agent") == agent_count

    @given(messages=_conversation_strategy, conv_id=_safe_text)
    @settings(max_examples=100, deadline=None)
    def test_markdown_contains_message_content(
        self,
        messages: list[dict[str, Any]],
        conv_id: str,
    ):
        """Markdown contains the content of every message.

        **Validates: Requirements 11.1**
        """
        md = build_conversation_markdown(messages, conv_id)

        for msg in messages:
            if msg["role"] == "user":
                assert msg["content"] in md
            elif msg["role"] == "agent":
                text = msg.get("data", {}).get("text", "")
                assert text in md

    @given(messages=_conversation_strategy, conv_id=_safe_text)
    @settings(max_examples=100, deadline=None)
    def test_markdown_includes_tool_call_names(
        self,
        messages: list[dict[str, Any]],
        conv_id: str,
    ):
        """Agent messages with tool calls include tool call names in Markdown.

        **Validates: Requirements 11.1**
        """
        md = build_conversation_markdown(messages, conv_id)

        for msg in messages:
            if msg["role"] == "agent":
                tool_calls = msg.get("data", {}).get("tool_calls") or []
                for tc in tool_calls:
                    assert f"**{tc['name']}**" in md


class TestEvalJSONExportCompleteness:
    """Property 14: Eval JSON export completeness.

    **Property 14: Eval JSON export completeness**
    **Validates: Requirements 12.1**

    For any array of eval results, the JSON export SHALL parse as valid JSON
    and SHALL contain every result with its case name, input, expected output,
    actual output, score, and pass/fail status fields.
    """

    @given(results=_eval_results_strategy)
    @settings(max_examples=100, deadline=None)
    def test_eval_json_parses_and_contains_all_results(
        self, results: list[dict[str, Any]],
    ):
        """Eval JSON export is valid and contains every result.

        **Validates: Requirements 12.1**
        """
        exported = build_eval_json(results)
        parsed = json.loads(exported)

        assert len(parsed) == len(results)

        for original, exported_result in zip(results, parsed):
            assert exported_result["case_name"] == original["case_name"]
            assert exported_result["input"] == original["input"]
            assert exported_result["expected_output"] == original["expected_output"]
            assert exported_result["actual_output"] == original["actual_output"]
            assert exported_result["score"] == pytest.approx(original["score"])
            assert exported_result["passed"] == original["passed"]

    @given(results=_eval_results_strategy)
    @settings(max_examples=100, deadline=None)
    def test_eval_json_results_have_required_fields(
        self, results: list[dict[str, Any]],
    ):
        """Every eval result in JSON export has all required fields.

        **Validates: Requirements 12.1**
        """
        exported = build_eval_json(results)
        parsed = json.loads(exported)

        required_fields = {
            "case_name", "input", "expected_output",
            "actual_output", "score", "passed",
        }
        for result in parsed:
            assert required_fields.issubset(result.keys()), (
                f"Missing fields: {required_fields - result.keys()}"
            )
