from . import bython

if __name__ == "__main__":
    bython.main()