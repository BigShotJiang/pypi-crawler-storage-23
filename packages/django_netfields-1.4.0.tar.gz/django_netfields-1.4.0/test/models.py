from django import VERSION
from django.contrib.postgres.fields import ArrayField
from django.db.models import CASCADE, ForeignKey, Model

from netfields import (
    CidrAddressField,
    InetAddressField,
    MACAddress8Field,
    MACAddressField,
    NetManager,
)


class InetTestModel(Model):
    field = InetAddressField()
    objects = NetManager()

    class Meta:
        db_table = "inet"


class NullInetTestModel(Model):
    field = InetAddressField(null=True)
    objects = NetManager()

    class Meta:
        db_table = "nullinet"


class UniqueInetTestModel(Model):
    field = InetAddressField(unique=True)
    objects = NetManager()

    class Meta:
        db_table = "uniqueinet"


class NoPrefixInetTestModel(Model):
    field = InetAddressField(store_prefix_length=False)
    objects = NetManager()

    class Meta:
        db_table = "noprefixinet"


class CidrTestModel(Model):
    field = CidrAddressField()
    objects = NetManager()

    class Meta:
        db_table = "cidr"


class NullCidrTestModel(Model):
    field = CidrAddressField(null=True)
    objects = NetManager()

    class Meta:
        db_table = "nullcidr"


class UniqueCidrTestModel(Model):
    field = CidrAddressField(unique=True)
    objects = NetManager()

    class Meta:
        db_table = "uniquecidr"


class MACTestModel(Model):
    field = MACAddressField(null=True)
    objects = NetManager()

    class Meta:
        db_table = "mac"


class MAC8TestModel(Model):
    field = MACAddress8Field(null=True)
    objects = NetManager()

    class Meta:
        db_table = "mac8"


class InetArrayTestModel(Model):
    field = ArrayField(InetAddressField(), blank=True, null=True)

    class Meta:
        db_table = "inetarray"


class CidrArrayTestModel(Model):
    field = ArrayField(CidrAddressField(), blank=True, null=True)

    class Meta:
        db_table = "cidrarray"


class MACArrayTestModel(Model):
    field = ArrayField(MACAddressField(), blank=True, null=True)

    class Meta:
        db_table = "macarray"


class MAC8ArrayTestModel(Model):
    field = ArrayField(MACAddress8Field(), blank=True, null=True)

    class Meta:
        db_table = "mac8array"


class AggregateTestModel(Model):
    network = CidrAddressField(blank=True, null=True, default=None)
    inet = InetAddressField(blank=True, null=True, default=None)


class AggregateTestChildModel(Model):
    parent = ForeignKey(
        "AggregateTestModel",
        related_name="children",
        on_delete=CASCADE,
    )
    network = CidrAddressField()
    inet = InetAddressField()


if VERSION >= (5, 1):
    from django.db.models import F, Q, CheckConstraint

    class ConstraintModel(Model):
        network = CidrAddressField()
        inet = InetAddressField()

        class Meta:
            constraints = (
                CheckConstraint(
                    condition=Q(network__net_contains=F("inet")),
                    name="inet_contained",
                ),
            )

elif VERSION >= (4, 1):
    from django.db.models import F, Q, CheckConstraint

    class ConstraintModel(Model):
        network = CidrAddressField()
        inet = InetAddressField()

        class Meta:
            constraints = (
                CheckConstraint(
                    check=Q(network__net_contains=F("inet")),
                    name="inet_contained",
                ),
            )
