"""antaris CLI entry point."""
import sys


def main():
    print("antaris-suite v3.9.0")
    print("Components: memory | guard | context | router | pipeline | contracts")
    print("Run 'python -m antaris_memory.mcp_server' for MCP server")
    print("Docs: https://docs.antarisanalytics.ai")


if __name__ == "__main__":
    main()
