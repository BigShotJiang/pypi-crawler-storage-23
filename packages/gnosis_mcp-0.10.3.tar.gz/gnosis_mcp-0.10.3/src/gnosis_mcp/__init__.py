"""Gnosis MCP -- Zero-config MCP server for searchable documentation."""

__version__ = "0.10.3"

__all__ = ["__version__"]
