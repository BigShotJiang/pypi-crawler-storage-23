"""Parsers that convert non-file sources into markdown for the ingest pipeline."""
