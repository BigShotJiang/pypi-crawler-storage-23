"""JWT user provider for FastAPI."""

from casbin_fastapi_decorator_jwt._provider import JWTUserProvider

__all__ = ["JWTUserProvider"]
