# Multiline title

You can create a multiline title by using the newline character (“\n”) within the title text:

```bash
1. chart1 = legort.Chart(
2.     span=plot_span,
3.     figure_title="Real Inflow of \n Remittances (100× log)",
4.     show_legend=True,
5.     show_grid=True) 
```

This will display the title across two lines.

**Note:** Using more than one \n in a title is not recommended, as it may cause layout issues.

