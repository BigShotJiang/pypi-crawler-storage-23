# Appendix B – Helpful Information and Tips

How to use hints

When using the reporting package, you can hover over the object you are instantiating to view all possible parameters you can configure.

For example, hovering over a report object will display not only the report's parameters and keyword arguments (kwargs) but also the style keys for all associated objects.

Keyword arguments (kwargs) are set in the same way as regular arguments, so you can treat them as such.

**Important:** In some IDEs, this feature might not be available. However, you can view the documentation by using Ctrl + Click on the specific object. (Currently, PyCharm offers the best support for this feature.)
![marketplace](assets/pycharm1.png)

Regular objects will include hints as well, but they will not have style-specific hints.
![marketplace](assets/pycharm2.png)


