**IMPORTANT:** rephorm pdf documentation is outdated. Please refer to the python docs (https://kb.ogresearch.com/python/#reporting)

Contents:

basic_report.py – Getting Started
A simple introductory report demonstrating:
- Text element
- Table element
- Basic charts (line, bar, and contribution bars)
- Grid layout

📌 Start here to understand how Rephorm works.

📄 advanced_report.py – Deep Dive into Rephorm
A more in-depth report, covering:
- Advanced styling (colors, highlighting, formatting)
- Complex charts
- Comparison series in tables
- Legend positioning & orientation in charts

📌 Only proceed to this after mastering basic_report.py.