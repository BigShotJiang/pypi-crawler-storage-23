Rephorm is a Python package for generating PDF reports through code. It builds on the capabilities of fpdf2 for PDF 
rendering and IRISPIE for seamless integration of economic models and data.

Rephorm provides a modular framework of configurable objects that can be instantiated, customized, and composed to 
create structured PDF reports.
