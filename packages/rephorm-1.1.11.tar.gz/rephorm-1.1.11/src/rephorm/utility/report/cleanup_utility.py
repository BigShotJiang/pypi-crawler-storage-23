# make util funct cleanup later on, so less code regarding cleanup stuff. but call it here.
import os
import shutil

from rephorm.object_mappers._globals import reset_figure_map
from rephorm.utility.report.background_process_manager import manager


def perform_cleanup(cleanup: bool = False, directory_path: str = None, base_file_path: str = None):

    reset_figure_map()
    # Reset background manager state between runs
    try:
        manager.reset()
    except Exception:
        pass

    try:
        # Remove tmp dir where pdf figures are stored
        if cleanup and directory_path:
            shutil.rmtree(directory_path)
        # Remove base (initial) pdf
        if base_file_path and os.path.exists(base_file_path):
            os.remove(base_file_path)

    except Exception as e:
        print(f"Cleanup utility - error occurred: {e}")