from .interface import WebInterface

__all__ = [
    "WebInterface",
]
