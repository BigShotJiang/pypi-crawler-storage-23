pub use interned_store::InternedStore;

pub mod interned_store;

#[cfg(test)]
mod __tests__;
