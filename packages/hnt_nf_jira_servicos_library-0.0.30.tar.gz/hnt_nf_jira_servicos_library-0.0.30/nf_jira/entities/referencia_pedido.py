from pydantic import BaseModel

class ReferenciaPedido(BaseModel):
    numero_pedido: str