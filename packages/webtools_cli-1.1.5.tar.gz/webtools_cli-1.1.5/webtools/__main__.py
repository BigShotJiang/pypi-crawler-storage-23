"""Allow running as python -m webtools_cli"""
import sys
sys.dont_write_bytecode = True
from webtools.cli import main
main()
