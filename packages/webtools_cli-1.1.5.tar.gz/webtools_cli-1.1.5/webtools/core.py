import sys,os,re,requests,random,subprocess,time,socket,shutil,json,zipfile,atexit,concurrent.futures,threading,qrcode,logging,queue,urllib3,base64,traceback,csv,io,mtranslate,hashlib
sys.dont_write_bytecode = True

# --- PACKAGE PATHS ---
PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(os.path.expanduser('~'), '.webtools')
# Scraped results are stored in a local 'webfiles' folder for better visibility
SCRAPED_DIR = os.path.join(os.getcwd(), 'webfiles', 'scraped')
os.makedirs(SCRAPED_DIR, exist_ok=True)
try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    COLOR_SUPPORT = True
except ImportError:
    COLOR_SUPPORT = False
import numpy as np
from bs4 import BeautifulSoup
from collections import Counter
from flask import Flask, render_template_string, send_from_directory, request, jsonify, send_file
from PIL import Image,ExifTags,ImageChops,ImageEnhance
from io import BytesIO

try:
    from playwright.sync_api import sync_playwright
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False

def check_playwright_browsers():
    """Check if Playwright browsers are installed"""
    try:
        import subprocess
        result = subprocess.run(
            ["playwright", "install", "--dry-run", "chromium"],
            capture_output=True,
            text=True,
            timeout=5
        )
        # If dry-run succeeds and doesn't show download messages, browsers exist
        return "chromium" in result.stdout.lower() or result.returncode == 0
    except:
        return False

def install_playwright_browsers():
    """Install Playwright browsers if not already installed"""
    if not PLAYWRIGHT_AVAILABLE:
        return False
    
    if check_playwright_browsers():
        return True
    
    print("\n📦 Playwright browsers not found. Installing...")
    try:
        import subprocess
        subprocess.run(["playwright", "install", "chromium"], check=True)
        print("✓ Playwright Chromium installed successfully\n")
        return True
    except Exception as e:
        print(f"⚠️ Failed to install Playwright browsers: {e}\n")
        return False

# --- CLI AUTOCOMPLETE SETUP ---
try:
    if os.name == 'nt':
        try:
            from pyreadline3 import Readline
            readline = Readline()
        except (ImportError, AttributeError):
            import pyreadline3 as readline
    else:
        import readline
    
    HISTORY_FILE = os.path.join(DATA_DIR, 'history')
    
    def setup_autocomplete(commands):
        def completer(text, state):
            options = [i for i in commands if i.startswith(text)]
            if state < len(options):
                return options[state]
            else:
                return None
        
        # Ensure the object has the required methods
        if hasattr(readline, 'set_completer'):
            readline.set_completer(completer)
            if 'libedit' in (getattr(readline, '__doc__', '') or ''):
                readline.parse_and_bind("bind ^I rl_complete")
            else:
                readline.parse_and_bind("tab: complete")
                if os.name != 'nt' and hasattr(readline, 'parse_and_bind'):
                    readline.parse_and_bind("set show-all-if-ambiguous on")
            
            if hasattr(readline, 'set_completer_delims'):
                readline.set_completer_delims(' ')
            
            # Load History
            if os.path.exists(HISTORY_FILE):
                try:
                    readline.read_history_file(HISTORY_FILE)
                except: pass
            
            # Save on exit
            def save_history():
                try:
                    os.makedirs(os.path.dirname(HISTORY_FILE), exist_ok=True)
                    readline.write_history_file(HISTORY_FILE)
                except: pass
            
            atexit.register(save_history)

    AUTOCOMPLETE_AVAILABLE = True
except Exception:
    def setup_autocomplete(commands): pass
    AUTOCOMPLETE_AVAILABLE = False

def print_gradient_text(text, start_rgb, end_rgb):
    """Prints text with a vertical/horizontal color gradient using 24-bit ANSI"""
    lines = text.splitlines()
    if not lines: return
    
    for i, line in enumerate(lines):
        # Calculate ratio for this line
        ratio = i / max(1, len(lines) - 1)
        
        # Interpolate RGB
        r = int(start_rgb[0] + (end_rgb[0] - start_rgb[0]) * ratio)
        g = int(start_rgb[1] + (end_rgb[1] - start_rgb[1]) * ratio)
        b = int(start_rgb[2] + (end_rgb[2] - start_rgb[2]) * ratio)
        
        # Apply 24-bit color ANSI
        print(f"\033[38;2;{r};{g};{b}m{line}\033[0m")

# Flask logs ko suppress karo
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

# SSL warnings ko globally band karo
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Directories setup kar rahe hain
os.makedirs(os.path.join(SCRAPED_DIR, 'images'), exist_ok=True)
os.makedirs(os.path.join(SCRAPED_DIR, 'videos'), exist_ok=True)

# --- PERFORMANCE AUDITOR ---
class PerformanceTracker:
    def __init__(self):
        self.stats_file = os.path.join(DATA_DIR, 'performance_stats.json')
        self.data = self.load_data()
        self.current_report = {}
        self.last_mark = 0
        self.session_url = ""

    def load_data(self):
        if os.path.exists(self.stats_file):
            try:
                with open(self.stats_file, 'r') as f:
                    return json.load(f)
            except: pass
        return {'best': float('inf'), 'worst': 0, 'total_time': 0, 'count': 0}

    def save_data(self):
        try:
            with open(self.stats_file, 'w') as f:
                json.dump(self.data, f)
        except: pass

    def start_session(self, url):
        self.current_report = {}
        self.last_mark = time.perf_counter()
        self.session_url = url

    def record_phase(self, name):
        now = time.perf_counter()
        duration = now - self.last_mark
        self.current_report[name] = self.current_report.get(name, 0) + duration
        self.last_mark = now

    def finish_and_print(self):
        total = sum(self.current_report.values())
        if total <= 0: return {}

        self.data['count'] += 1
        self.data['total_time'] += total
        if total < self.data['best']: self.data['best'] = total
        if total > self.data['worst']: self.data['worst'] = total
        self.save_data()

        avg = self.data['total_time'] / self.data['count']
        
        return {
            'total': total,
            'phases': dict(self.current_report),
            'avg': avg,
            'best': self.data['best'],
            'worst': self.data['worst']
        }

perf_tracker = PerformanceTracker()

class MoonSpinner:
    """Threaded moon-phase loading animation"""
    def __init__(self, message="Processing"):
        self.message = message
        self.frames = ['🌑', '🌒', '🌓', '🌔', '🌕', '🌖', '🌗', '🌘']
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._animate, daemon=True)

    def _animate(self):
        while not self.stop_event.is_set():
            for f in self.frames:
                if self.stop_event.is_set(): break
                sys.stdout.write(f'\r{self.message} {f}   ')
                sys.stdout.flush()
                time.sleep(0.2)

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop_event.set()
        self.thread.join(timeout=1.0)
        sys.stdout.write(f'\r{self.message} 🌕 Done!     \n')
        sys.stdout.flush()

# --- PROXY aur UA MANAGER ---
class ProxyManager:
    def __init__(self):
        self.proxies = []
        self.last_fetch = 0
        self.fetch_interval = 300  # Har 5 minute mein refresh hoga
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Mobile/15E148 Safari/604.1'
        ]
        
        # Background mein validation logic
        self.valid_proxies = queue.Queue()
        self.lock = threading.Lock()
        self.running = True

        # Smart Learner (Scores setup)
        self.scores_file = os.path.join(DATA_DIR, 'scores.json')
        self.scores = self.load_scores()
        
        # Background thread chalao
        threading.Thread(target=self._background_validator, daemon=True).start()

    def load_scores(self):
        if os.path.exists(self.scores_file):
            try:
                with open(self.scores_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        return {}

    def save_scores(self):
        try:
            with open(self.scores_file, 'w') as f:
                json.dump(self.scores, f, indent=2)
        except Exception as e:
            print(f"Failed to save scores: {e}")

    def report_success(self, proxy, domain, task_type, success):
        with self.lock:
            # Score ke liye composite key (jaise "youtube.com::video")
            score_key = f"{domain}::{task_type}"
            
            if score_key not in self.scores:
                self.scores[score_key] = {}
            
            if proxy not in self.scores[score_key]:
                self.scores[score_key][proxy] = {'success': 0, 'fail': 0, 'score': 0.5}
            
            stats = self.scores[score_key][proxy]
            if success:
                stats['success'] += 1
                # Score badhao (Stickiness factor)
                stats['score'] = min(1.0, stats['score'] + 0.25)
            else:
                stats['fail'] += 1
                # Penalty laga rahe hain
                stats['score'] = max(0.0, stats['score'] - 0.2)
            
            self.save_scores()

    def get_smart_proxy(self, domain, task_type='general'):
        # Epsilon-Greedy Strategy with Stickiness
        
        score_key = f"{domain}::{task_type}"
        
        if score_key in self.scores:
            domain_scores = self.scores[score_key]
            # Find best proxy
            if domain_scores:
                best_proxy = max(domain_scores, key=lambda p: domain_scores[p]['score'])
                best_score = domain_scores[best_proxy]['score']
                
                # STICKY LOGIC:
                # If Score > 0.8 (Very Trusted): 95% Exploitation
                # If Score > 0.5 (Trusted): 80% Exploitation
                # Else: 50% Exploitation
                
                exploitation_rate = 0.5
                if best_score > 0.8: exploitation_rate = 0.95
                elif best_score > 0.5: exploitation_rate = 0.80
                
                if random.random() < exploitation_rate and best_score > 0.4:
                    print(f"🧠 Smart Learner: Sticky reuse of {best_proxy} for {score_key} (Score: {best_score:.2f})")
                    return best_proxy
        
        # Fallback to general domain score if task-specific score missing
        if task_type != 'general':
             return self.get_smart_proxy(domain, 'general')

        # Exploration fallback
        return self.get_valid_proxy()

    def fetch_proxies(self):
        # Sirf tab fetch karo jab list empty ya purani ho
        with self.lock:
             if self.proxies and (time.time() - self.last_fetch < self.fetch_interval):
                return
        
        # Quiet mode if background
        # print("Fetching new proxies...")
        try:
            # Optimized timing: timeout=3000 (3s)
            url = "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=3000&country=all&ssl=all&anonymity=elite,anonymous"
            resp = requests.get(url, timeout=5)
            if resp.status_code == 200:
                proxy_list = resp.text.strip().split('\r\n')
                with self.lock:
                    self.proxies = [p for p in proxy_list if p]
                    self.last_fetch = time.time()
                # print(f"Fetched {len(self.proxies)} high-quality proxies.")
        except Exception as e:
            print(f"Failed to fetch proxies: {e}")

    def _background_validator(self):
        while self.running:
            # Queue bhar ke rakho (target: 20 valid proxies)
            if self.valid_proxies.qsize() < 20:
                self.fetch_proxies()
                
                with self.lock:
                    if not self.proxies:
                        time.sleep(5)
                        continue
                    candidates = list(self.proxies)

                # Random proxy select karo
                proxy = random.choice(candidates)
                
                if self._check_proxy(proxy):
                    self.valid_proxies.put(proxy)
                    # print(f"P: {proxy} ({self.valid_proxies.qsize()})")
                else:
                    pass
            else:
                time.sleep(1) # Queue full

    def _check_proxy(self, proxy):
         try:
            proxies = {'http': proxy, 'https': proxy}
            # Jaldi wala check
            resp = requests.get("http://httpbin.org/ip", proxies=proxies, timeout=3, verify=False)
            return resp.status_code == 200
         except:
             return False

    def get_valid_proxy(self):
        # Agar available ho toh turant result do
        try:
            return self.valid_proxies.get_nowait()
        except:
             # Agar queue empty ho toh random unvalidated proxy use karo
             return self.get_random_proxy()

    def get_random_proxy(self):
        self.fetch_proxies()
        if not self.proxies:
            return None
        return random.choice(self.proxies)

    def get_random_ua(self):
        return random.choice(self.user_agents)

proxy_manager = ProxyManager()
# ---------------------

def get_free_port():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('', 0))
    port = sock.getsockname()[1]
    sock.close()
    return port

PORT = get_free_port()
WEB_DIR = os.path.join(PACKAGE_DIR, 'web')
app = Flask(__name__)

# Video Extraction wala updated HTML UI
@app.route('/')
def index():
    return send_from_directory(WEB_DIR, 'index.html')

@app.route('/style.css')
def serve_css():
    return send_from_directory(WEB_DIR, 'style.css')

@app.route('/script.js')
def serve_js():
    return send_from_directory(WEB_DIR, 'script.js')

@app.route('/favicon.png')
def serve_favicon():
    return send_from_directory(WEB_DIR, 'Web_Tools.png')

@app.route('/download/<path:filename>')

@app.route('/download/<path:filename>')
def serve_scraped_file(filename):
    return send_from_directory(SCRAPED_DIR, filename)

def scrape_with_playwright(url, proxy=None):
    if not PLAYWRIGHT_AVAILABLE:
        return None
    
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            
            # Stealth settings ke sath context
            context = browser.new_context(
                viewport={'width': 1920, 'height': 1080},
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            )
            
            page = context.new_page()
            
                # Heavy sites ke liye 30s ka timeout
            try:
                page.goto(url, timeout=30000, wait_until='domcontentloaded')
                
                # Dynamic content ke liye thoda wait karo
                time.sleep(5) 
                
                # Lazy loads trigger karne ke liye niche scroll karo
                page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                time.sleep(2)
                
                content = page.content()
                return content
            except Exception as e:
                print(f"❌ Playwright navigation failed: {e}")
                return None
            finally:
                browser.close()
    except Exception as e:
        print(f"❌ Playwright error: {e}")
        return None


# --- OSINT HELPERS ---
def extract_emails(text):
    """Regex se emails nikalo"""
    # Sahi wala regex:
    # 1. Start with alnum/dots/dashes
    # 2. @ symbol
    # 3. Domain name (alnum/dashes)
    # 4. TLD (2+ chars)
    # Filter: length < 50, accidental image matches remove karo
    raw = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', text)
    valid = []
    for email in set(raw):
        if len(email) > 50: continue
        if email.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg')): continue
        valid.append(email)
    return valid

def extract_phones(text):
    """Phone numbers nikalo (+91 aur intl formats par focus)"""
    phones = set()
    
    # 1. Strict Indian Mobile Numbers: +91 9876543210 / 9876543210 / 09876543210
    # Matches: +91-9876543210, +91 98765 43210, 9876543210
    # Indian mobiles ke liye [6-9] starting digit search karo
    indian_regex = r'(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?([6-9]\d{3}[\s\-]?\d{6})'
    for match in re.findall(indian_regex, text):
        # match[1] number wala part hai
        full_num = match[1].replace(' ', '').replace('-', '')
        if len(full_num) == 10:
             phones.add("+91 " + full_num)

    # 2. General International (Fallback) jaise +1 etc.
    # Explicit plus sign aur digits search karo
    intl_regex = r'\+(?:9[976]\d|8[987530]\d|6[987]\d|5[90]\d|42\d|3[875]\d|2[98654321]\d|9[8543210]|8[6421]|6[6543210]|5[87654321]|4[987654310]|3[9643210]|2[70]|7|1)\W*\d\W*\d\W*\d\W*\d\W*\d\W*\d\W*\d\W*\d\W*(\d{1,2})?'
    for p in re.findall(intl_regex, text):
         # Yeh thoda complex match hai, noise avoid karne ke liye simple rakhte hain
         pass 

    # 3. "Tel:" links ke liye simple grab
    # (Regex ne handle kar liya hoga par safe rehne ke liye)
    
    return list(phones)

def extract_locations(soup):
    """Physical addresses nikalo"""
    locations = set()
    
    # 1. Schema.org Parsing
    for item in soup.find_all(attrs={"itemtype": re.compile(r"schema.org/PostalAddress", re.I)}):
        text = item.get_text(separator=', ').strip()
        if len(text) > 10: locations.add(text)
        
    # 2. Google Maps Embeds
    for iframe in soup.find_all('iframe', src=True):
        if 'maps.google' in iframe['src']:
            # Query nikalne ki koshish karo
            match = re.search(r'q=([^&]+)', iframe['src'])
            if match:
                import urllib.parse
                addr = urllib.parse.unquote(match.group(1).replace('+', ' '))
                locations.add(addr)
    
    # 3. Heuristic Keywords (Footer/Contact)
    # Search ko footer ya contact sections tak limit rakho
    search_area = soup.find('footer') or soup.find(id='contact') or soup.body
    if search_area:
        text = search_area.get_text(separator=' ')
        # "Address: ..." ke liye rough regex
        matches = re.findall(r'(?:Address|Location|Office):\s*([a-zA-Z0-9,\.\-\s]{10,100})', text, re.I)
        for m in matches:
            locations.add(m.strip())

    return list(locations)


def extract_social_media(soup):
    """Social media profile links nikalo"""
    social_domains = {
        'facebook.com': 'Facebook',
        'twitter.com': 'Twitter',
        'x.com': 'X (Twitter)',
        'instagram.com': 'Instagram',
        'linkedin.com': 'LinkedIn',
        'youtube.com': 'YouTube',
        'tiktok.com': 'TikTok',
        'pinterest.com': 'Pinterest',
        'github.com': 'GitHub',
        'gitlab.com': 'GitLab',
        'discord.gg': 'Discord',
        't.me': 'Telegram'
    }
    found = {}
    for a in soup.find_all('a', href=True):
        href = a['href'].lower()
        for domain, name in social_domains.items():
            if domain in href and name not in found:
                # Share links avoid karne ke liye basic check
                if 'share' not in href and 'intent' not in href:
                    found[name] = a['href']
    
    return [{'platform': k, 'url': v} for k, v in found.items()]

def detect_tech_stack(soup, response):
    """Site par kaunsi technologies used hain woh check karo"""
    stack = set()
    
    # 1. Headers
    if 'Server' in response.headers:
        stack.add(f"Server: {response.headers['Server']}")
    if 'X-Powered-By' in response.headers:
        stack.add(f"Powered By: {response.headers['X-Powered-By']}")
    if 'Via' in response.headers:
        stack.add(f"Via: {response.headers['Via']}")
        
    # 2. Meta Tags
    generator = soup.find('meta', attrs={'name': 'generator'})
    if generator and generator.get('content'):
        stack.add(generator['content'])
        
    # 3. Scripts / HTML Patterns
    html_str = str(soup).lower()
    if 'wp-content' in html_str: stack.add('WordPress')
    if 'shopify' in html_str: stack.add('Shopify')
    if 'wix.com' in html_str: stack.add('Wix')
    if 'squarespace' in html_str: stack.add('Squarespace')
    if 'react' in html_str or '_next' in html_str: stack.add('React/Next.js')
    if 'vue' in html_str or 'nuxt' in html_str: stack.add('Vue.js')
    if 'bootstrap' in html_str: stack.add('Bootstrap')
    if 'tailwind' in html_str: stack.add('Tailwind CSS')
    if 'jquery' in html_str: stack.add('jQuery')
    if 'cloudflare' in html_str: stack.add('Cloudflare')
    if 'google-analytics' in html_str: stack.add('Google Analytics')
    
    return list(stack)

def ensure_textblob_corpora(download=False):
    """Ensure necessary NLTK corpora for TextBlob are downloaded"""
    try:
        import nltk
        needed = ['punkt', 'brown', 'averaged_perceptron_tagger']
        all_present = True
        for corpus in needed:
            try:
                nltk.data.find(f'tokenizers/{corpus}' if corpus == 'punkt' else f'corpora/{corpus}')
            except (LookupError, AttributeError):
                if download:
                    print(f"Downloading required AI data: {corpus}...")
                    nltk.download(corpus, quiet=True)
                else:
                    all_present = False
        return all_present
    except:
        return False

def analyze_ai_content(text):
    """Text analyze karo (sentiment, summary, readability, aur keywords)"""
    try:
        if not ensure_textblob_corpora(download=False):
            return {
                'skipped': True,
                'message': 'AI analysis skipped (Missing AI data). Use /setup-ai to download.'
            }
            
        from textblob import TextBlob
        import re
        
        # Text clean karo
        clean_text = re.sub(r'\s+', ' ', text).strip()
        if not clean_text: return None
        
        blob = TextBlob(clean_text)
        sentiment = blob.sentiment
        
        # 1. Summarization (Simple Frequency-based)
        sentences = blob.sentences
        if len(sentences) > 0:
            # Simple summary: pehla sentence + 2 interesting sentences
            # NLTK/Spacy jaisi heavy libraries avoid karne ka tareeka
            summary_sentences = [sentences[0].string]
            
            # Baaki ke diverse sentences search karo
            remaining = sentences[1:]
            remaining.sort(key=lambda s: len(s.noun_phrases), reverse=True)
            for s in remaining[:2]:
                summary_sentences.append(s.string)
                
            summary = ' '.join(summary_sentences)
        else:
            summary = clean_text[:200] + "..."

        # 2. Readability (Flesch Reading Ease)
        # Formula: 206.835 - 1.015 (total words / total sentences) - 84.6 (total syllables / total words)
        words = blob.words
        num_sentences = len(sentences) or 1
        num_words = len(words) or 1
        
        # Syllable approximation (vowel groups)
        def count_syllables(word):
            word = word.lower()
            count = len(re.findall(r'[aeiouy]+', word))
            if word.endswith('e'): count -= 1
            return max(1, count)
            
        num_syllables = sum(count_syllables(w) for w in words)
        
        flesch_score = 206.835 - 1.015 * (num_words / num_sentences) - 84.6 * (num_syllables / num_words)
        
        readability_level = "Standard"
        if flesch_score > 80: readability_level = "Very Easy (Kids)"
        elif flesch_score > 60: readability_level = "Plain English"
        elif flesch_score > 40: readability_level = "Difficult (College)"
        else: readability_level = "Very Difficult (Academic)"

        # 3. Enhanced Keywords
        keywords = []
        seen = set()
        for phrase in blob.noun_phrases:
            p = phrase.lower().strip()
            # Junk aur chhote words filter karo
            if len(p) > 4 and p not in seen and not re.match(r'^\d+$', p) and len(keywords) < 12:
                keywords.append(phrase.title())
                seen.add(p)
                
        return {
            'sentiment': {
                'polarity': round(sentiment.polarity, 2),
                'subjectivity': round(sentiment.subjectivity, 2),
                'label': 'Positive' if sentiment.polarity > 0.1 else 'Negative' if sentiment.polarity < -0.1 else 'Neutral',
                'subjectivity_label': 'Opinionated' if sentiment.subjectivity > 0.5 else 'Objective'
            },
            'summary': summary,
            'readability': {
                'score': round(flesch_score, 1),
                'level': readability_level
            },
            'keywords': keywords
        }
    except Exception as e:
        print(f"AI Analysis failed: {e}")
        return None

def check_broken_links(url, soup, headers):
    """Broken links (404s) check karo (parallel mein)."""
    broken_links = []
    links_to_check = []
    
    from urllib.parse import urlparse, urljoin
    base_domain = urlparse(url).netloc

    # Links deduplicate karo
    seen_links = set()
    
    for a in soup.find_all('a', href=True):
        href = a['href']
        full_url = urljoin(url, href)
        
        # Faltu ya non-http links skip karo
        if not full_url.startswith('http') or full_url in seen_links:
            continue
            
        seen_links.add(full_url)
        
        is_internal = base_domain in full_url
        link_text = a.get_text().strip()[:50] # Text truncate karo
        
        links_to_check.append({
            'url': full_url,
            'text': link_text or "No Text",
            'is_internal': is_internal
        })

    # Iss demo ke performance ke liye 50 links tak limit rakho
    links_to_check = links_to_check[:50]

    def check_status(link_info):
        try:
            # Speed ke liye Head request use karo
            r = requests.head(link_info['url'], headers=headers, timeout=5, allow_redirects=True, verify=False)
            if r.status_code >= 400:
                return {
                    'url': link_info['url'],
                    'text': link_info['text'],
                    'status': r.status_code,
                    'is_internal': link_info['is_internal']
                }
        except Exception:
            # Agar head fail ho jaye toh get try karo (kuch servers HEAD block karte hain)
            try:
                r = requests.get(link_info['url'], headers=headers, stream=True, timeout=5, verify=False)
                if r.status_code >= 400:
                    return {
                        'url': link_info['url'],
                        'text': link_info['text'],
                        'status': r.status_code,
                        'is_internal': link_info['is_internal']
                    }
            except Exception:
                 return {
                    'url': link_info['url'],
                    'text': link_info['text'],
                    'status': 0, # Connection Error
                    'is_internal': link_info['is_internal']
                }
        return None

    # Parallel Execution
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        results = list(executor.map(check_status, links_to_check))
    
    # Filter Nones
    broken_links = [r for r in results if r]
    
    return broken_links

def execute_scrape_logic(url, fetch_images=False, fetch_videos=False, crawl_depth=1, use_proxy=False, device='desktop'):
    try:
        if not url.startswith('http'):
            url = 'https://' + url
           
        # Start performance session
        perf_tracker.start_session(url)

        # UA rotate karo
        ua = proxy_manager.get_random_ua()
        headers = {'User-Agent': ua}
        print(f"Using UA: {ua}")
        
        # SSL warnings band karo
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        perf_tracker.record_phase("Setup & Proxy")
        
        try:
            response = None
            if use_proxy:
                # Smart Learning ke liye Domain nikalo
                from urllib.parse import urlparse
                domain = urlparse(url).netloc
                
                # Task Type decide karo
                task_type = 'general'
                if fetch_videos: task_type = 'video'
                elif fetch_images: task_type = 'image'

                # Smart Loop: Pehle Exploitation fir Exploration
                print(f"Selecting best proxy for {domain} (Task: {task_type})...")
                
                for attempt in range(3):
                    # Attempt 0: Smart Choice (Is domain aur task ke liye best)
                    # Attempt 1+: Fallback (Random valid proxy)
                    if attempt == 0:
                        proxy = proxy_manager.get_smart_proxy(domain, task_type)
                    else:
                        proxy = proxy_manager.get_valid_proxy()
                        
                    if not proxy: 
                        break 

                    print(f"Using proxy: {proxy} (Attempt {attempt+1})")
                    proxies = {'http': proxy, 'https': proxy}
                    try:
                        # SSL errors bypass karne ke liye verify=False
                        response = requests.get(url, headers=headers, proxies=proxies, timeout=30, verify=False)
                        if response.status_code == 200:
                            # SUCCESS: Model train karo
                            print(f"✅ Proxy {proxy} worked for {domain} ({task_type}). Boosting score!")
                            proxy_manager.report_success(proxy, domain, task_type, True)
                            break
                        else:
                            # FAIL (Non-200): Model train karo
                            print(f"❌ Proxy {proxy} failed for {domain} ({task_type}) (Status {response.status_code}). Penalizing.")
                            proxy_manager.report_success(proxy, domain, task_type, False)
                    except Exception as e:
                        # FAIL (Exception): Model train karo
                        print(f"❌ Proxy {proxy} error for {domain} ({task_type}): {e}. Penalizing.")
                        proxy_manager.report_success(proxy, domain, task_type, False)
                        continue
                            
                if response is None or response.status_code != 200:
                     print("All proxies failed. Falling back to direct connection.")
                     response = requests.get(url, headers=headers, timeout=30)
            else:
                # Direct Request (SPA Check ke sath)
                block_domains = ['linkedin.com', 'instagram.com', 'facebook.com', 'twitter.com', 'x.com', 'xhamster', 'pornhub', 'xnxx']
                if any(domain in url.lower() for domain in block_domains):
                    print(f"High-Security Domain detected. Skipping direct requests...")
                    response = None # Playwright force karo
                else:
                    response = requests.get(url, headers=headers, timeout=30)
            
            # Block ya failure check karo
            if response and response.status_code in [403, 401, 406, 429]:
                 print(f"⚠️ Access Denied ({response.status_code}). Triggering Headless Browser...")
                 response = None # Force Playwright

            if response is None:
                raise Exception("SPA/Auth Wall ke liye Playwright force karo")

            response.raise_for_status()
            perf_tracker.record_phase("Fetch Content")

        except Exception as e:
            # Agar requests fail hon toh Playwright use karo
            print(f"Requests failed ({e}). Attempting Playwright Fallback...")
            if PLAYWRIGHT_AVAILABLE:
                pw_html = scrape_with_playwright(url)
                if pw_html:
                    # Compatibility ke liye mock response object
                    class MockResponse:
                        def __init__(self, text):
                            self.text = text
                            self.content = text.encode('utf-8')
                            self.status_code = 200
                            self.headers = {}
                    response = MockResponse(pw_html)
                else:
                    return {'success': False, 'error': f'Request failed and Playwright fallback failed: {str(e)}'}
            else:
                error_msg = f"Request failed: {str(e)}"
                if response and response.status_code == 404:
                    error_msg += "\n💡 Tip: URL might be expired or the site is blocking direct requests. Install Playwright for better results: pip install webtools-cli[playwright]"
                else:
                    error_msg += "\n💡 Tip: Try installing Playwright for better bypassing: pip install webtools-cli[playwright]"
                return {'success': False, 'error': error_msg}
        
        soup = BeautifulSoup(response.text, 'html.parser')
        perf_tracker.record_phase("HTML Parsing")

        # --- HONEYPOT DETECTOR (Security Scout) ---
        security_report = {'level': 'LOW', 'threats': [], 'honeypots': 0}
        
        # 1. Status Code Check
        if response.status_code in [403, 406, 429, 503]:
            security_report['threats'].append(f"Suspicious Status Code: {response.status_code}")
            security_report['level'] = 'HIGH'

        # 2. Keyword Analysis (Anti-Bot)
        page_text_lower = response.text.lower()
        threat_keywords = ['cloudflare', 'managed challenge', 'captcha', 'security check', 'access denied', 'waf']
        found_threats = [kw for kw in threat_keywords if kw in page_text_lower]
        if found_threats:
            security_report['threats'].append(f"Anti-Bot Detected: {', '.join(found_threats)}")
            if 'captcha' in found_threats or 'challenge' in found_threats:
                 security_report['level'] = 'HIGH'
            elif security_report['level'] == 'LOW':
                 security_report['level'] = 'MEDIUM'

        # 3. Honeypot Link Detection (CSS Traps)
        # Aise links nikalo jo bots ko dikhte hain par humans ko nahi
        honeypot_links = 0
        for a in soup.find_all('a', style=True):
            style = a['style'].lower().replace(' ', '')
            if 'display:none' in style or 'visibility:hidden' in style or 'opacity:0' in style:
                honeypot_links += 1
        
        if honeypot_links > 0:
            security_report['honeypots'] = honeypot_links
            security_report['threats'].append(f"Honeypot Traps: {honeypot_links} hidden links found")
            if security_report['level'] == 'LOW': security_report['level'] = 'MEDIUM'
        # ------------------------------------------
        
        # Containers initialize karo
        videos = []
        video_count = 0
        images = []
        image_count = 0
        seen_images = set()

        # Helper validation
        def cleaner_url_validator(url):
            try:
                # Http se start hona chahiye, dot hona chahiye, spaces nahi
                if not url.startswith('http'): return False
                if ' ' in url: return False
                if '.' not in url.split('://')[1]: return False
                return True
            except:
                return False

        # Turbo-Fetch (Parallel Chunk Download) ke liye helper
        def download_file_turbo(url, filepath):
            try:
                # 1. Size nikalo
                head = requests.head(url, headers=headers, timeout=5, verify=False)
                size = int(head.headers.get('content-length', 0))
                
                # 2MB se bade files ke liye Turbo use karo
                if size < 2 * 1024 * 1024:
                    return False 

                print(f"Turbo-Fetch active: {os.path.basename(filepath)} ({size/1024/1024:.1f} MB)")
                
                # 2. Chunks calculate karo (8 parts)
                num_chunks = 8
                chunk_size = size // num_chunks
                chunks = []
                for i in range(num_chunks):
                    start = i * chunk_size
                    end = start + chunk_size - 1 if i < num_chunks - 1 else size - 1
                    chunks.append((start, end, i))
                
                # 3. Parallel Download
                file_data = bytearray(size)
                
                def download_chunk(c):
                    start, end, idx = c
                    h = headers.copy()
                    h['Range'] = f'bytes={start}-{end}'
                    r = requests.get(url, headers=h, timeout=20, verify=False)
                    if r.status_code in [200, 206]:
                        # Seedha buffer mein likho
                        file_data[start:end+1] = r.content
                        return True
                    return False

                with concurrent.futures.ThreadPoolExecutor(max_workers=8) as exc:
                    futures = [exc.submit(download_chunk, c) for c in chunks]
                    concurrent.futures.wait(futures)
                    
                # 4. Disk par save karo
                with open(filepath, 'wb') as f:
                    f.write(file_data)
                    
                return True
                
            except Exception as e:
                print(f"Turbo failed: {e}")
                return False

        def process_video_download_task(task_item):
            v_url, quality, title_hint = task_item
            
            # Sabse pehle m3u8 (HLS) check karo
            if v_url.split('?')[0].lower().endswith('.m3u8'):
                 return {
                    'url': v_url,
                    'original_url': v_url,
                    'filename': 'Stream.m3u8',
                    'external': True,
                    'is_m3u8': True,
                    'quality': quality or 'auto'
                }

            # RETRY LOOP (Max 3 attempts)
            for attempt in range(3):
                try:
                    # verify=False use karo
                    # Stability ke liye 15s timeout, stream=True
                    vid_data = requests.get(v_url, headers=headers, timeout=15, stream=True, verify=False)
                    
                    if vid_data.status_code == 200:
                        content_type = vid_data.headers.get('content-type', '').lower()
                        
                        # Minimum size filter: 2MB se chhoti videos skip karo
                        content_length = vid_data.headers.get('content-length')
                        if content_length:
                            size_mb = int(content_length) / (1024 * 1024)
                            if size_mb < 2:
                                return None
                        
                        if 'video' in content_type or 'octet-stream' in content_type or v_url.endswith(('.mp4', '.webm', '.mov')) or 'mpegurl' in content_type:
                            if 'mpegurl' in content_type or v_url.split('?')[0].lower().endswith('.m3u8'):
                                 return {
                                    'url': v_url,
                                    'original_url': v_url,
                                    'filename': 'Stream.m3u8',
                                    'external': True,
                                    'is_m3u8': True
                                }
                            filename = os.path.basename(v_url.split('?')[0]) or 'video.mp4'
                            if not filename.endswith(('.mp4', '.webm', '.ogg', '.mov', '.avi', '.mkv')):
                                filename += '.mp4'
                            
                            # Title sanitize karo aur filename generate karo
                            import uuid
                            import re
                            
                            if title_hint:
                                safe_title = re.sub(r'[^a-zA-Z0-9_\-\. ]', '', title_hint).strip().replace(' ', '_')[:50]
                                if safe_title:
                                    base, ext = os.path.splitext(filename)
                                    filename = f"{safe_title}_{uuid.uuid4().hex[:8]}{ext}"
                                else:
                                    base, ext = os.path.splitext(filename)
                                    if quality and quality != 'unknown':
                                         filename = f"{base}_{quality}_{uuid.uuid4().hex[:8]}{ext}"
                                    else:
                                         filename = f"{base}_{uuid.uuid4().hex[:8]}{ext}"
                            else:
                                base, ext = os.path.splitext(filename)
                                if quality and quality != 'unknown':
                                     filename = f"{base}_{quality}_{uuid.uuid4().hex[:8]}{ext}"
                                else:
                                     filename = f"{base}_{uuid.uuid4().hex[:8]}{ext}"

                            filepath = os.path.join(SCRAPED_DIR, 'videos', filename)
                            
                            # Pehle TURBO FETCH try karo
                            if not download_file_turbo(v_url, filepath):
                                # Standard stream par wapas jao (fallback)
                                with open(filepath, 'wb') as f:
                                    for chunk in vid_data.iter_content(chunk_size=8192):
                                        f.write(chunk)
                            return {
                            'url': f'/download/videos/{filename}',
                            'original_url': v_url,
                            'filename': filename,
                            'external': False,
                            'quality': quality
                            }
                    elif vid_data.status_code in [403, 404, 401]:
                        # In errors par retry mat karo
                        return None
                        
                except Exception as ex:
                    # Sirf aakhri attempt par poora error print karo
                    if attempt == 2:
                        err_str = str(ex)
                        if 'NameResolutionError' in err_str:
                             print(f"⚠️ DNS Error (Ad/Tracker ho sakta hai)")
                        elif 'RemoteDisconnected' in err_str:
                             print(f"⚠️ Connection Dropped: {v_url}")
                        else:
                             print(f"❌ Failed {v_url}: {ex}")
                    else:
                        time.sleep(1) # Retry se pehle thoda wait karo
                        continue
            return None

# Extract CSS
        css_content = []
        for style in soup.find_all('style'):
            css_content.append(style.string or '')
            style.extract()

        # OpenCV Image Validation
        def validate_image_quality(image_bytes):
            try:
                import cv2
                import numpy as np
                
                # Image decode karo
                nparr = np.frombuffer(image_bytes, np.uint8)
                img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                
                if img is None: return False
                
                # Check 1: Resolution (Chhote icons/thumbnails skip karo)
                h, w, _ = img.shape
                # Increased strictness from 50 to 150
                if w < 150 or h < 150: 
                    return False
                
                # Check 2: Variance (Solid colors ya flat images)
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                variance = cv2.Laplacian(gray, cv2.CV_64F).var()
                # Increased strictness from 50 to 100
                if variance < 100: 
                    return False # Zyada blurry ya flat hai
                
                # Check 3: Entropy (Information density)
                hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
                hist_norm = hist.ravel() / hist.sum()
                logs = np.log2(hist_norm + 0.0001)
                entropy = -np.sum(hist_norm * logs)
                
                # Increased strictness from 3.5 to 5.0
                if entropy < 5.0: 
                    return False # Information kam hai
                
                return True
            except Exception as e:
                return True # Safe rehne ke liye fail open karo

        def is_valuable_media(url_path, element, media_type='image'):
            """Ads aur logos ke liye filtering logic."""
            try:
                # 1. URL Path Keywords
                lower_url = url_path.lower()
                ad_keywords = [
                    'ad', 'advert', 'banner', 'doubleclick', 'googleads', 
                    'syndication', 'amazon-adsystem', 'wp-content/ads/', 
                    'promoted', 'sponsored', 'pixel', 'tracking', 'taboola', 'outbrain'
                ]
                # Logos
                logo_keywords = ['logo', 'brand-logo', 'header-logo', 'footer-logo', 'favicon']
                
                # Ads check karo
                if any(k in lower_url for k in ad_keywords):
                    return False
                
                # Logos check karo
                if any(k in lower_url for k in logo_keywords):
                    return False
                
                # 2. Metadata (Alt/Title)
                alt = element.get('alt', '').lower() if element.get('alt') else ""
                title = element.get('title', '').lower() if element.get('title') else ""
                metadata_text = f"{alt} {title}"
                
                if any(k in metadata_text for k in ['ad ', 'ads ', 'advertisement', 'sponsored', 'logo', 'branding']):
                    return False
                
                # 3. CSS Metadata (Class/ID)
                classes = " ".join(element.get('class', [])) if isinstance(element.get('class'), list) else str(element.get('class', ''))
                id_val = str(element.get('id', ''))
                
                # Parents check karo (simple BS4 method)
                parent_context = ""
                parent = element.parent
                levels = 0
                while parent and levels < 3:
                    p_classes = " ".join(parent.get('class', [])) if isinstance(parent.get('class'), list) else str(parent.get('class', ''))
                    parent_context += p_classes + " " + str(parent.get('id', '')) + " "
                    parent = parent.parent
                    levels += 1
                
                context_text = (classes + " " + id_val + " " + parent_context).lower()
                bad_contexts = [' ad ', ' ads ', 'banner', 'logo', 'brand', 'sponsored', 'advert', 'widget-area']
                if any(k in context_text for k in bad_contexts):
                    # Header ya sidebar check karo (risk areas hain)
                    if any(x in context_text for x in ['header', 'sidebar', 'footer', 'nav']):
                        return False

                # 4. Dimensions (sirf image ke liye)
                width = element.get('width')
                height = element.get('height')
                if width and height:
                    try:
                        w = int(width)
                        h = int(height)
                        if h > 0:
                            ratio = w / h
                            # Banners aksar bahut wide ya tall hote hain
                            if (ratio > 4 or ratio < 0.25) and (w < 900 and h < 900):
                                return False
                    except:
                        pass

                return True
            except:
                return True # Fail open

        # Images download karne ke liye helper
        def process_image_download_task(img_src):
            try:
                img_url = requests.compat.urljoin(url, img_src)
                img_data = requests.get(img_url, headers=headers, timeout=3, verify=False)
                if img_data.status_code == 200:
                    content = img_data.content
                    
                    # QUALITY CHECK KARO
                    if not validate_image_quality(content):
                        return None
                    
                    filename = os.path.basename(img_url.split('?')[0]) or 'image.jpg'
                    if not filename.endswith(('.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg')):
                        filename += '.jpg'
                    
                    import uuid
                    import hashlib
                    
                    image_hash = hashlib.md5(content).hexdigest()
                    
                    filename = f"{uuid.uuid4().hex[:8]}_{filename}"

                    filepath = os.path.join(SCRAPED_DIR, 'images', filename)
                    with open(filepath, 'wb') as f:
                        f.write(content)
                    return (img_src, f'images/{filename}', f'/download/images/{filename}', image_hash, filepath)
            except:
                pass
            return None

        # CSS nikalo
        css_content = []
        for style in soup.find_all('style'):
            css_content.append(style.string or '')
            style.extract()
            
        for link in soup.find_all('link', rel='stylesheet'):
            href = link.get('href')
            if href:
                try:
                    css_url = requests.compat.urljoin(url, href)
                    css_resp = requests.get(css_url, headers=headers, timeout=5)
                    css_content.append(f'/* From {href} */\n' + css_resp.text)
                except:
                    pass
            link.extract()
        
        # JS nikalo
        js_content = []
        # Find all scripts (head and body)
        for script in soup.find_all('script'):
            # Non-executable scripts (JSON-LD, etc) filter karo
            script_type = script.get('type', '').lower()
            if script_type and script_type not in ['text/javascript', 'application/javascript', 'module']:
                script.extract()
                continue
                
            if script.string and not script.get('src'):
                js_content.append(script.string)
            elif script.get('src'):
                src = script.get('src')
                try:
                    js_url = requests.compat.urljoin(url, src)
                    js_resp = requests.get(js_url, headers=headers, timeout=5)
                    js_content.append(f'// From {src}\n' + js_resp.text)
                except:
                    pass
            # Original script tags hatao taaki execution errors/404s na aayein
            script.extract()
        
        # Image Tasks collect karo
        image_tasks = []
        if fetch_images:
            os.makedirs(os.path.join(SCRAPED_DIR, 'images'), exist_ok=True)
            
            # Exclude karne ke liye Video Posters ID karo
            poster_blacklist = set()
            for video in soup.find_all('video'):
                poster = video.get('poster')
                if poster: poster_blacklist.add(poster)
            
            for img in soup.find_all('img'):
                if len(image_tasks) >= 50: break # Limit to 50 images to prevent timeout
                src = img.get('src')
                if src and not src.startswith('data:') and not src.lower().endswith('.svg'):
                     # Exclude video posters
                     if src in poster_blacklist:
                         continue
                         
                     # VALUABLE MEDIA FILTER (Ads/Logos)
                     if not is_valuable_media(src, img):
                         continue
                         
                     # Extension check taaki iframes/HTML avoid ho sakein
                     if any(src.lower().endswith(ext) for ext in ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.tiff']):
                        image_tasks.append(src)

        # =========================================================
        # PERFORMANCE OPTIMIZATION: Images PEHLE process honge
        # Images download faster than videos, so they're prioritized
        # to improve perceived performance and provide quicker feedback.
        # =========================================================
        
        # Image Downloads execute karo
        if fetch_images and image_tasks:
            seen_hashes = set()
            total_images = len(image_tasks)
            completed_images = 0
            with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
                future_to_img = {executor.submit(process_image_download_task, src): src for src in image_tasks}
                for future in concurrent.futures.as_completed(future_to_img):
                    completed_images += 1
                    progress = int((completed_images / total_images) * 100)
                    frames = ['🌑','🌒','🌓','🌔','🌕','🌖','🌗','🌘']
                    spinner = frames[completed_images % len(frames)]
                    sys.stdout.write(f'\r{spinner} Images: {completed_images}/{total_images} ({progress}%)   ')
                    sys.stdout.flush()
                    result = future.result()
                    if result:
                        orig_src, relative_path, download_path, img_hash, filepath = result
                        if img_hash in seen_hashes:
                            # Duplicate content, delete file
                            try:
                                os.remove(filepath)
                            except:
                                pass
                            continue
                        seen_hashes.add(img_hash)
                        # Update soup
                        for img in soup.find_all('img', src=orig_src):
                            img['src'] = relative_path
                        images.append(download_path)
                        image_count += 1
            sys.stdout.write(f'\r🌕 Images Done! ✅ {image_count} accepted     \n')
            sys.stdout.flush()
        # Video Tasks collect karo
        video_tasks = []
        if fetch_videos:
            os.makedirs(os.path.join(SCRAPED_DIR, 'videos'), exist_ok=True)
            # -------------------------------------------------------------------------
            # RESOURCE SNIFFER (Deep Scan)
            # Scans raw HTML/JS for hidden video links (mp4, m3u8, etc)
            # -------------------------------------------------------------------------
            # Video extensions wale links dhundhne ka pattern
            # Handles escaped slashes (common in JSON)
            # Captures: "https://example.com/video.mp4"
            sniffer_regex = r'(https?:\\?\/\\?\/[^"\'\s<>]+?\.(?:mp4|m3u8|webm|mov|mkv|ts|flv|wmv|3gp|f4v|mpg|mpeg|avi|m4v|ogg)(?:[^"\'\s<>]*)?)'
            matches = re.findall(sniffer_regex, response.text)
            sniffed_count = 0
            for match in matches:
                # Fix escaped slashes (e.g. from JSON: https:\/\/example.com)
                clean_url = match.replace('\\/', '/')
                # Basic validation
                if len(clean_url) > 200: continue # Likely garbage
                if not cleaner_url_validator(clean_url): continue

                # Sniffed links ke liye AD FILTER
                ad_domains = ['doubleclick', 'adnxs', 'amazon-adsystem', 'googlesyndication', 'taboola', 'outbrain', 'ads-twitter', 'fb-ads']
                if any(ad in clean_url.lower() for ad in ad_domains):
                    continue
                # URL mein quality clues check karo
                quality = 'unknown'
                lower_url = clean_url.lower()
                if '1080' in lower_url: quality = '1080p'
                elif '720' in lower_url: quality = '720p'
                elif '480' in lower_url: quality = '480p'
                # Avoid duplicates
                is_duplicate = False
                # Avoid duplicates
                is_duplicate = False
                for existing_url, _, _ in video_tasks:
                     if existing_url == clean_url: is_duplicate = True; break
                for existing_vid in videos:
                     if existing_vid['original_url'] == clean_url: is_duplicate = True; break
                if not is_duplicate:
                    if any(x in clean_url for x in ['youtube', 'youtu.be', 'vimeo', 'dailymotion']):
                         pass # Skip external for simple sniffer, usually handled by iframes
                    else:
                        video_tasks.append((clean_url, quality, f"sniffed_video_{sniffed_count}"))
                        sniffed_count += 1
            # Video tags dhundho (sources aur qualities scan karo)
            for video in soup.find_all('video'):
                # VALUABLE MEDIA FILTER
                if not is_valuable_media(video.get('src', ''), video, 'video'):
                    continue
                
                # Check for source tags
                sources = video.find_all('source')
                found_src = False
                
                if sources:
                    for source in sources:
                        src = source.get('src')
                        if src:
                            # Detect quality from attributes or text
                            quality = 'unknown'
                            s_text = (str(source) + src).lower()
                            if '1080' in s_text: quality = '1080p'
                            elif '720' in s_text: quality = '720p'
                            elif '480' in s_text: quality = '480p'
                            if src.startswith('http'):
                                video_url = src
                            else:
                                video_url = requests.compat.urljoin(url, src)
                            # Check external
                            if any(x in video_url for x in ['youtube', 'youtu.be', 'vimeo', 'dailymotion']):
                                videos.append({'url': video_url,'original_url': video_url,'filename': 'External Video','external': True})
                                video_count += 1
                            else:
                                # Extract Title from Video Tag or Context
                                video_title = video.get('title') or video.get('aria-label')
                                if not video_title:
                                    # Try previous sibling header
                                    prev = video.find_previous(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
                                    if prev: video_title = prev.get_text().strip()
                                
                                video_tasks.append((video_url, quality, video_title))
                    found_src = True

                # Fallback to direct src on video tag
                if not found_src:
                    src = video.get('src')
                    if src:
                        if src.startswith('http'):
                            video_url = src
                        else:
                            video_url = requests.compat.urljoin(url, src)
                        
                        if any(x in video_url for x in ['youtube', 'youtu.be', 'vimeo', 'dailymotion']):
                             videos.append({'url': video_url,'original_url': video_url,'filename': 'External Video','external': True})
                             video_count += 1
                        else:
                            # Extract Title
                            video_title = video.get('title') or video.get('aria-label')
                            if not video_title:
                                prev = video.find_previous(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
                                if prev: video_title = prev.get_text().strip()
                            video_tasks.append((video_url, 'unknown', video_title))
            # Video files ke links (a tags) dhundho
            for a in soup.find_all('a'):
                href = a.get('href')
                if href:
                    # VALUABLE MEDIA FILTER
                    if not is_valuable_media(href, a, 'video'):
                        continue
                    lower_href = href.lower()
                    if lower_href.endswith(('.mp4', '.webm', '.ogg', '.mov', '.avi', '.mkv', '.m4v', '.m3u8', '.flv', '.wmv', '.3gp', '.f4v', '.mpg', '.mpeg', '.ts')) or \
                       (('/video/' in lower_href or '/videos/' in lower_href) and '.' in list(filter(None, lower_href.split('/')))[-1]):
                        # Detect quality from link text
                        quality = 'unknown'
                        a_text = a.get_text().lower()
                        if '1080' in a_text: quality = '1080p'
                        elif '720' in a_text: quality = '720p'
                        elif '480' in a_text: quality = '480p'
                        if href.startswith('http'):
                            video_url = href
                        else:
                            video_url = requests.compat.urljoin(url, href)
                        if any(x in video_url for x in ['youtube', 'youtu.be', 'vimeo', 'dailymotion']):
                            videos.append({'url': video_url,'original_url': video_url,'filename': 'External Video','external': True})
                            video_count += 1
                        else:
                            # Extract Title from Link Text or Attributes
                            video_title = a.get('title') or a.get('aria-label') or a.get_text().strip()
                            if not video_title:
                                prev = a.find_previous(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
                                if prev: video_title = prev.get_text().strip()
                            
                            # Fallback to Page Title if single video or very few
                            if not video_title:
                                page_title = soup.title.string if soup.title else ""
                                if page_title:
                                     # Clean up page title (remove site name usually at end)
                                    video_title = page_title.split('|')[0].split('-')[0].strip()


                            video_tasks.append((video_url, quality, video_title))

            # Find iframes with video embeds
            for iframe in soup.find_all('iframe'):
                src = iframe.get('src', '')
                # VALUABLE MEDIA FILTER
                if not is_valuable_media(src, iframe, 'video'):
                    continue
                if any(x in src for x in ['youtube', 'youtu.be', 'vimeo', 'dailymotion']):
                     if not any(v['original_url'] == src for v in videos):
                        videos.append({'url': src,'original_url': src,'filename': f'Embed: {src.split("/")[2]}','external': True,'quality': 'unknown'})
                        video_count += 1
        # Video Downloads execute karo
        if fetch_videos and video_tasks:
            total_videos = len(video_tasks)
            completed_videos = 0
            with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
                future_to_vid = {executor.submit(process_video_download_task, item): item for item in video_tasks}
                for future in concurrent.futures.as_completed(future_to_vid):
                    completed_videos += 1
                    progress = int((completed_videos / total_videos) * 100)
                    frames = ['🌑','🌒','🌓','🌔','🌕','🌖','🌗','🌘']
                    spinner = frames[completed_videos % len(frames)]
                    sys.stdout.write(f'\r{spinner} Videos: {completed_videos}/{total_videos} ({progress}%)   ')
                    sys.stdout.flush()
                    result = future.result()
                    if result:
                        # Avoid duplicates in final list
                        if not any(v['original_url'] == result['original_url'] for v in videos):
                             videos.append(result)
                             video_count += 1
            sys.stdout.write(f'\r🌕 Videos Done! ✅ {video_count} found     \n')
            sys.stdout.flush()
        # HTML update karo
        head = soup.find('head')
        if head:
            for link in head.find_all('link', rel='stylesheet'):
                link.extract()
            css_link = soup.new_tag('link', rel='stylesheet', href='style.css')
            head.insert(0, css_link)
        body = soup.find('body')
        if body:
            js_script = soup.new_tag('script', src='script.js')
            body.append(js_script)
        # Files save karo
        html_content = str(soup)
        with open(os.path.join(SCRAPED_DIR, 'index.html'), 'w', encoding='utf-8') as f:
            f.write(html_content)
        with open(os.path.join(SCRAPED_DIR, 'style.css'), 'w', encoding='utf-8') as f:
            f.write('\n\n'.join(css_content) or '/* No CSS found */')
        with open(os.path.join(SCRAPED_DIR, 'script.js'), 'w', encoding='utf-8') as f:
            f.write('\n\n'.join(js_content) or '// No JS found */')
        # Stats calculate karo
        def get_size(content):
            size = len(content.encode('utf-8'))
            if size < 1024:
                return f'{size} B'
            elif size < 1024*1024:
                return f'{size/1024:.1f} KB'
            else:
                return f'{size/(1024*1024):.1f} MB'
        # --- DESIGN INSPECTOR ---
        design_data = {'colors': [], 'fonts': []}
        full_css = '\n'.join(css_content) + '\n' + html_content
        # Colors (Hex) nikalo
        hex_colors = re.findall(r'#(?:[0-9a-fA-F]{3}){1,2}\b', full_css)
        # Filter for unique and sort by frequency
        unique_colors = Counter(hex_colors).most_common(20) # Top 20
        design_data['colors'] = [c[0] for c in unique_colors]

        # Fonts nikalo
        fonts = re.findall(r'font-family:\s*([^;]+)', full_css, re.IGNORECASE)
        unique_fonts = Counter([f.strip().strip("'").strip('"') for f in fonts]).most_common(10)
        design_data['fonts'] = [f[0] for f in unique_fonts]

        # --- SEO ANALYSIS ---
        seo_data = {
            'title': soup.title.string if soup.title else None,
            'description': None,'keywords': None,
            'headings': {'h1': 0, 'h2': 0, 'h3': 0},
            'images_analysis': {'total': 0, 'missing_alt': 0},
            'links_internal': 0,'links_external': 0,'score': 0
        }

        # Meta tags check karo
        msg_desc = soup.find('meta', attrs={'name': 'description'}) or soup.find('meta', attrs={'property': 'og:description'})
        if msg_desc: seo_data['description'] = msg_desc.get('content')
        msg_keys = soup.find('meta', attrs={'name': 'keywords'})
        if msg_keys: seo_data['keywords'] = msg_keys.get('content')
        # Headings check karo
        seo_data['headings'] = {
            'h1': len(soup.find_all('h1')),'h2': len(soup.find_all('h2')),'h3': len(soup.find_all('h3')),
        }

        # Images
        imgs = soup.find_all('img')
        seo_data['images_analysis']['total'] = len(imgs)
        seo_data['images_analysis']['missing_alt'] = len([img for img in imgs if not img.get('alt')])
        # Links aur Auditor logic
        all_links = soup.find_all('a')
        domain = requests.compat.urlparse(url).netloc
        check_urls = set()
        for link in all_links:
            href = link.get('href', '')
            if not href or href.startswith('#') or href.startswith('javascript'): continue
            if domain in href or href.startswith('/'):
                seo_data['links_internal'] += 1
            else:
                seo_data['links_external'] += 1        
            # Collect for auditing (limit to 50 to avoid timeout)
            if href.startswith('http'):
                check_urls.add(href)
            elif href.startswith('/'):
                check_urls.add(requests.compat.urljoin(url, href))
        
        # Link Auditor (Threaded logic)
        broken_links = []
        def check_link(l_url):
            try:
                r = requests.head(l_url, headers=headers, timeout=3)
                if r.status_code >= 400:
                    return {'url': l_url, 'status': r.status_code}
            except:
                return {'url': l_url, 'status': 'Failed'}
            return None

        # Verify up to 30 unique links
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(check_link, u) for u in list(check_urls)[:30]]
            for f in concurrent.futures.as_completed(futures):
                res = f.result()
                if res: broken_links.append(res)
        seo_data['broken_links'] = broken_links
        # --- DEEP CRAWL LOGIC ---
        site_structure = {'url': url, 'title': seo_data['title'], 'children': []}
        perf_tracker.record_phase("SEO & Parsing")
        
        if crawl_depth > 1:
            # Simple recursive scraper logic
            def scrape_node(node_url, current_level):
                # Max depth par ruk jao
                if current_level > crawl_depth: return None
                try:
                    # Reuse headers/verify settings
                    nr = requests.get(node_url, headers=headers, timeout=3, verify=False)
                    if nr.status_code == 200:
                        ns = BeautifulSoup(nr.text, 'html.parser')
                        node_title = (ns.title.string or node_url).strip()[:50] # Limit title length
                        
                        child_nodes = []
                        # Agar max depth nahi pahoochi, toh children dhundho
                        if current_level < crawl_depth:
                            n_links = []
                            for na in ns.find_all('a', href=True):
                                nh = na['href']
                                if not nh or nh.startswith('#') or nh.startswith('javascript'): continue
                                n_full = requests.compat.urljoin(node_url, nh)
                                # Strict Internal Domain Check
                                if domain in n_full:
                                    if n_full not in n_links and n_full != node_url:
                                        n_links.append(n_full)
                            
                            # Recurse for top 3 links to keep it fast
                            # We don't parallelize here to avoid spawning too many threads recursively
                            for nl in list(set(n_links))[:3]:
                                child = scrape_node(nl, current_level + 1)
                                if child: child_nodes.append(child)
                        
                        return {'url': node_url, 'title': node_title, 'children': child_nodes}
                except: 
                    pass
                return {'url': node_url, 'title': 'Unreachable', 'children': []}

            # Filter start links (Limit 5)
            start_links = list(set([u for u in check_urls if domain in u]))[:5]

            # First level ko parallelize karo
            with concurrent.futures.ThreadPoolExecutor(max_workers=3) as crawler:
                 futures = {crawler.submit(scrape_node, u, 2): u for u in start_links}
                 for f in concurrent.futures.as_completed(futures):
                     res = f.result()
                     if res: site_structure['children'].append(res)
            perf_tracker.record_phase("Deep Crawl")
        score = 0
        if seo_data['title']: score += 20
        if seo_data['description']: score += 20
        if seo_data['headings']['h1'] > 0: score += 20
        if url.startswith('https'): score += 10
        
        if seo_data['images_analysis']['total'] > 0:
            ratio = 1 - (seo_data['images_analysis']['missing_alt'] / seo_data['images_analysis']['total'])
            score += int(30 * ratio)
        else:
            score += 30

        seo_data['score'] = min(100, score)
        
        result = {
            'success': True,
            'security': security_report,
            'site_structure': site_structure,
            'seo': seo_data,
            'design': design_data,
            'stats': {
                'html': get_size(html_content),
                'css': get_size('\n\n'.join(css_content)),
                'js': get_size('\n\n'.join(js_content)),
                'image_count': image_count,
                'video_count': video_count
            },
            'images': images,
            'videos': videos,
            'broken_links': check_broken_links(url, soup, headers),
            'intel': {
                'emails': extract_emails(response.text),
                'phones': extract_phones(response.text),
                'locations': extract_locations(soup),
                'socials': extract_social_media(soup),
                'tech_stack': detect_tech_stack(soup, response),
                'ai_analysis': analyze_ai_content(soup.get_text(separator=' ', strip=True)[:50000]) # Limit to 50k chars for perf
            }
        }
        
        perf_tracker.record_phase("AI & Intel")
        perf_data = perf_tracker.finish_and_print()
        result['performance'] = perf_data
        
        return result
        
    except Exception as e:
        print(f"Error in execute_scrape_logic: {e}")
        traceback.print_exc()
        return {'success': False, 'error': str(e)}

@app.route('/api/scrape', methods=['POST'])
def api_scrape():
    data = request.get_json()
    url = data.get('url', '')
    fetch_images = data.get('fetch_images', False)
    fetch_videos = data.get('fetch_videos', False)
    crawl_depth = int(data.get('crawl_depth', 2))
    use_proxy = data.get('use_proxy', False)
    device = data.get('device', 'desktop')
    
    result = execute_scrape_logic(url, fetch_images, fetch_videos, crawl_depth, use_proxy, device)
    if result.get('success'):
        return jsonify(result)
    else:
        return jsonify(result), 500

@app.route('/api/bulk', methods=['POST'])
def api_bulk():
    try:
        data = request.get_json()
        urls = data.get('urls', [])
        fetch_images = data.get('fetch_images', False)
        
        if not urls:
            return jsonify({'success': False, 'error': 'No URLs provided'})

        timestamp = int(time.time())
        base_folder = f'webfiles/bulk/batch_{timestamp}'
        os.makedirs(base_folder, exist_ok=True)
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        processed = 0
        for i, url in enumerate(urls):
            if not url.strip(): continue
            try:
                if not url.startswith('http'): url = 'https://' + url
                
                # Subfolder banao
                domain = requests.compat.urlparse(url).netloc.replace(':', '_')
                site_folder = f'{base_folder}/{i+1}_{domain}'
                os.makedirs(site_folder, exist_ok=True)
                os.makedirs(f'{site_folder}/images', exist_ok=True)
                
                # Fetch karo
                response = requests.get(url, headers=headers, timeout=10)
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # HTML save karo
                with open(f'{site_folder}/index.html', 'w', encoding='utf-8') as f:
                    f.write(str(soup))
                
                # CSS logic
                css_content = []
                for link in soup.find_all('link', rel='stylesheet'):
                    href = link.get('href')
                    if href:
                        try:
                            css_url = requests.compat.urljoin(url, href)
                            css_content.append(requests.get(css_url, headers=headers, timeout=5).text)
                        except: pass
                with open(f'{site_folder}/style.css', 'w', encoding='utf-8') as f:
                    f.write('\n'.join(css_content))

                # Images check karo
                if fetch_images:
                    for img in soup.find_all('img'):
                        src = img.get('src')
                        if src and not src.startswith('data:') and not src.lower().endswith('.svg'):
                            try:
                                img_url = requests.compat.urljoin(url, src)
                                fname = os.path.basename(img_url.split('?')[0]) or 'image.jpg'
                                if not fname.endswith(('.jpg','.png','.jpeg','.webp')): fname += '.jpg'
                                
                                r = requests.get(img_url, headers=headers, timeout=5)
                                if r.status_code == 200:
                                    with open(f'{site_folder}/images/{fname}', 'wb') as f:
                                        f.write(r.content)
                            except: pass
                
                processed += 1
            except Exception as e:
                print(f"Failed to scrape {url}: {e}")

        # ZIP banao
        shutil.make_archive(base_folder, 'zip', base_folder)
        shutil.rmtree(base_folder) # Folder saaf karo, sirf ZIP rakho
        
        return jsonify({
            'success': True,
            'message': f'Successfully scraped {processed} sites.',
            'download_url': f'/download/bulk/batch_{timestamp}.zip'
        })

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/download/bulk/<path:filename>')
def serve_bulk_file(filename):
    return send_from_directory('webfiles/bulk', filename)

@app.route('/api/save', methods=['POST'])
def api_save():
    try:
        data = request.get_json()
        filename = data.get('filename')
        content = data.get('content')
        
        if filename in ['index.html', 'style.css', 'script.js']:
            with open(f'webfiles/scraped/{filename}', 'w', encoding='utf-8') as f:
                f.write(content)
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'error': 'Invalid filename'}), 400
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/download-zip')
def download_zip():
    try:
        zip_path = os.path.join(DATA_DIR, 'scraped_files.zip')
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(SCRAPED_DIR):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, SCRAPED_DIR)
                    zipf.write(file_path, arcname)
        
        return send_file(zip_path, as_attachment=True, download_name='scraped_files.zip')
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def clear_scraped_data():
    try:
        if os.path.exists(SCRAPED_DIR):
            shutil.rmtree(SCRAPED_DIR)
        os.makedirs(os.path.join(SCRAPED_DIR, 'images'), exist_ok=True)
        os.makedirs(os.path.join(SCRAPED_DIR, 'videos'), exist_ok=True)
        return True
    except Exception as e:
        print(f"Cleanup Error: {e}")
        return False

@app.route('/api/clear', methods=['POST'])
def api_clear():
    if clear_scraped_data():
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'error': 'Cleanup failed'}), 500

@app.route('/api/export', methods=['POST'])
def api_export():
    try:
        req_data = request.get_json()
        data = req_data.get('data')
        export_format = req_data.get('format', 'csv').lower()
        filename = req_data.get('filename', 'export')
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400

        # Buffer create karo
        if export_format == 'csv':
            si = io.StringIO()
            # Check karo data simple list hai ya list of dicts
            if isinstance(data, list) and len(data) > 0:
                if isinstance(data[0], dict):
                    # List of Dicts (e.g. Socials)
                    keys = data[0].keys()
                    writer = csv.DictWriter(si, fieldnames=keys)
                    writer.writeheader()
                    writer.writerows(data)
                else:
                    # Simple List (e.g. Emails)
                    writer = csv.writer(si)
                    writer.writerow(['Value']) # Generic header
                    for item in data:
                        writer.writerow([item])
            
            output = si.getvalue()
            mem = io.BytesIO()
            mem.write(output.encode('utf-8'))
            mem.seek(0)
            
            return send_file(
                mem,
                mimetype='text/csv',
                as_attachment=True,
                download_name=f'{filename}.csv'
            )
            
        elif export_format == 'json':
            mem = io.BytesIO()
            mem.write(json.dumps(data, indent=2).encode('utf-8'))
            mem.seek(0)
            
            return send_file(
                mem,
                mimetype='application/json',
                as_attachment=True,
                download_name=f'{filename}.json'
            )
            
        else:
            return jsonify({'error': 'Unsupported format'}), 400

    except Exception as e:
        print(f"Export Error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/translate', methods=['POST'])
def api_translate():
    try:
        data = request.get_json()
        text = data.get('text')
        target_lang = data.get('target', 'hi') # Default to Hindi
        
        if not text:
            return jsonify({'error': 'No text provided'}), 400
            
        translated = mtranslate.translate(text, target_lang)
        return jsonify({
            'success': True,
            'translated': translated
        })
    except Exception as e:
        print(f"Translation Error: {e}")
        return jsonify({'error': str(e)}), 500

def wait_for_server(port, timeout=10):
    start = time.time()
    while time.time() - start < timeout:
        try:
            import urllib.request
            urllib.request.urlopen(f'http://127.0.0.1:{port}/', timeout=1)
            return True
        except:
            time.sleep(0.5)
    return False


# --- IMAGE ANALYSIS FEATURE ---

def get_decimal_from_dms(dms, ref):
    degrees = dms[0]
    minutes = dms[1]
    seconds = dms[2]
    
    decimal = degrees + (minutes / 60.0) + (seconds / 3600.0)
    if ref in ['S', 'W']:
        decimal = -decimal
    return decimal

def get_image_metadata(image):
    info = {
        "Format": image.format,
        "Mode": image.mode,
        "Size": f"{image.width} x {image.height}",
        "Width": image.width,
        "Height": image.height,
        "Info": image.info.get('comment', '')
    }
    
    # EXIF data
    exif_data = {}
    gps_data = {}
    
    try:
        exif = image._getexif()
        if exif:
            for tag, value in exif.items():
                decoded = ExifTags.TAGS.get(tag, tag)
                if decoded == "GPSInfo":
                    gps_data = {}
                    for t in value:
                        sub_decoded = ExifTags.GPSTAGS.get(t, t)
                        gps_data[sub_decoded] = value[t]
                else:
                    # Binary data filter karo
                    if isinstance(value, bytes):
                        try:
                            value = value.decode()
                        except:
                            value = "<binary data>"
                    exif_data[decoded] = str(value)
    except Exception as e:
        print(f"EXIF Error: {e}")

    # GPS data process karo
    location = None
    if gps_data:
        try:
            lat = get_decimal_from_dms(gps_data.get('GPSLatitude'), gps_data.get('GPSLatitudeRef'))
            lon = get_decimal_from_dms(gps_data.get('GPSLongitude'), gps_data.get('GPSLongitudeRef'))
            location = {'lat': lat, 'lon': lon, 'map_url': f"https://www.google.com/maps?q={lat},{lon}"}
        except Exception as e:
            print(f"GPS Parse Error: {e}")

    return {
        "basic": info,
        "exif": exif_data,
        "gps": str(gps_data),
        "location": location
    }

def generate_ela(image, quality=90, scale=10):
    """
    ELA (Error Level Analysis) image generate karta hai.
    1. Original image ko specific quality (compression) pe save karta hai.
    2. Original aur compressed ke beech ka difference nikalta hai.
    3. Visualisation ke liye difference ko enhance karta hai.
    """
    try:
        # Agar RGB nahi hai (jaise RGBA, P) toh convert karo
        if image.mode != 'RGB':
            image = image.convert('RGB')

        # Compressed version memory mein save karo
        buffer = BytesIO()
        image.save(buffer, 'JPEG', quality=quality)
        buffer.seek(0)
        compressed_image = Image.open(buffer)

        # Difference calculate karo
        ela_image = ImageChops.difference(image, compressed_image)

        # Differences dikhne ke liye brightness badhao
        ela_image = ImageEnhance.Brightness(ela_image).enhance(scale)

        return ela_image
    except Exception as e:
        print(f"ELA Error: {e}")
        return None

@app.route('/api/analyze/ela', methods=['POST'])
def analyze_ela():
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image file provided'}), 400
            
        file = request.files['image']
        image = Image.open(file.stream)
        
        ela_image = generate_ela(image)
        
        if ela_image:
            # ELA result ko base64 mein convert karo
            buffered = BytesIO()
            ela_image.save(buffered, format="PNG") # ELA details ke liye PNG format
            img_str = base64.b64encode(buffered.getvalue()).decode()
            return jsonify({'success': True, 'ela_image': f"data:image/png;base64,{img_str}"})
        else:
            return jsonify({'error': 'Failed to generate ELA'}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def compute_ai_likelihood(image):
    """
    Image mein AI generation artifacts check karta hai (FFT use karke).
    Likelihood score (0-100) aur label return karta hai.
    """
    try:
        # Greyscale aur resize (consistent analysis ke liye)
        img_gray = image.convert('L').resize((512, 512))
        img_array = np.array(img_gray)

        # FFT logic
        f = np.fft.fft2(img_array)
        fshift = np.fft.fftshift(f)
        magnitude_spectrum = 20 * np.log(np.abs(fshift) + 1e-10) # Log scale

        # Heuristic: AI images mein aksar high-frequency energy ya grid artifacts hote hain.
        # High-frequency components ka variance calculate karenge.
        
        # High-pass mask banao
        rows, cols = img_array.shape
        crow, ccol = rows//2, cols//2
        mask_radius = 50
        
        # Low frequencies (center) mask karo
        magnetude_high_freq = magnitude_spectrum.copy()
        magnetude_high_freq[crow-mask_radius:crow+mask_radius, ccol-mask_radius:ccol+mask_radius] = 0
        
        # High frequencies par stats calculate karo
        hf_mean = np.mean(magnetude_high_freq)
        hf_std = np.std(magnetude_high_freq)
        
        # Simple heuristic mapping (demo ke liye tuned)
        # Real images mein HF variance kam hoti hai jab tak textured na ho.
        # GANs aksar high-energy artifacts chhod dete hain.
        
        # Score normalize karo (estimation hai)
        # Maan ke chalte hain natural image std 30-50 hai, AI zyada ho sakta hai.
        # Natural variations ke liye sigmoid-like mapping use karenge.
        
        score = min(100, max(0, (hf_std - 40) * 2 + 50)) 
        
        # Refinement: "checkerboard" artifacts check karo jo strong indicators hote hain
        # Peak detection chahiye par variance bhi achha proxy hai.
        
        label = "Likely Real"
        if score > 60:
            label = "Possible AI / Edited"
        if score > 80:
            label = "Likely AI Generated"
            
        return {
            "score": round(score, 1),
            "label": label,
            "details": f"HF Variance: {round(hf_std, 2)}"
        }
    except Exception as e:
        print(f"AI Detection Error: {e}")
        return {"score": 0, "label": "Error", "details": str(e)}

@app.route('/api/analyze/ai', methods=['POST'])
def analyze_ai():
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image file provided'}), 400
            
        file = request.files['image']
        image = Image.open(file.stream)
        
        result = compute_ai_likelihood(image)
        
        return jsonify({'success': True, 'data': result})
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/analyze-image', methods=['POST'])
def analyze_image():
    try:
        image = None
        source_type = "upload"
        
        # 1. File upload check karo
        if 'file' in request.files:
            file = request.files['file']
            if file.filename == '':
                return jsonify({'error': 'No selected file'}), 400
            try:
                image = Image.open(file.stream)
            except Exception as e:
                 return jsonify({'error': f'Invalid image file: {e}'}), 400
                 
        # 2. URL check karo
        elif 'url' in request.form or (request.is_json and 'url' in request.get_json()):
            data = request.get_json() if request.is_json else request.form
            url = data.get('url')
            if not url:
                 return jsonify({'error': 'No URL provided'}), 400
            
            source_type = "url"
            try:
                headers = {'User-Agent': 'Mozilla/5.0'}
                resp = requests.get(url, headers=headers, stream=True, timeout=15, verify=False)
                resp.raise_for_status()
                image = Image.open(BytesIO(resp.content))
            except Exception as e:
                return jsonify({'error': f'Failed to fetch image from URL: {e}'}), 400
        
        else:
            return jsonify({'error': 'No image provided (file or url)'}), 400

        # Image process karo
        metadata = get_image_metadata(image)
        ai_detection = compute_ai_likelihood(image)
        
        return jsonify({
            'success': True,
            'source': source_type,
            'data': metadata,
            'ai_detection': ai_detection
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

def display_qr_image(url):
    """QR code generate aur ASCII format mein terminal pe dikhao"""
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(url)
    qr.make(fit=True)
    
    # ASCII QR code print karo (invert=True better options hai)
    qr.print_ascii(invert=True)
    print(f"\n🔗 {url}")

def start_cloudflare_tunnel(port):
    try:
        if os.name == 'nt':
            os.system("taskkill /F /IM cloudflared.exe >NUL 2>&1")
        else:
            os.system("pkill -f cloudflared 2>/dev/null")
        time.sleep(1)
        
        # OS ke hisaab se executable choose karo
        cf_executable = os.path.join(DATA_DIR, 'cloudflared.exe') if os.name == 'nt' else os.path.join(DATA_DIR, 'cloudflared')
        
        # Agar missing ho toh download karo
        if not os.path.exists(cf_executable):
            print(f"Downloading cloudflared for {os.name}...")
            if os.name == 'nt':
                # Windows binary download URL
                win_url = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
                resp = requests.get(win_url, stream=True)
                with open(cf_executable, 'wb') as f:
                    for chunk in resp.iter_content(chunk_size=8192):
                        f.write(chunk)
            else:
                # Linux binary download URL
                subprocess.run(['wget', '-q', '-O', cf_executable, 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64'])
                subprocess.run(['chmod', '+x', cf_executable])
        
        process = subprocess.Popen(
            [cf_executable, 'tunnel', '--protocol', 'http2', '--url', f'http://127.0.0.1:{port}'],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )
        
        url_pattern = r'https://[a-z0-9-]+\.trycloudflare\.com'
        start_time = time.time()
        
        while time.time() - start_time < 30:
            line = process.stdout.readline()
            if line:
                match = re.search(url_pattern, line)
                if match:
                    url = match.group(0)
                    time.sleep(2)
                    return url, process
        return None, None
    except:
        return None, None

def print_cli_report(data):
    """Beautiful Colorized two-column report for CLI mode"""
    if not data.get('success'):
        print(f"\n{Fore.RED if COLOR_SUPPORT else ''}❌ Scrape Failed: {data.get('error')}")
        return

    c_b = Fore.CYAN if COLOR_SUPPORT else ""
    c_g = Fore.GREEN if COLOR_SUPPORT else ""
    c_y = Fore.YELLOW if COLOR_SUPPORT else ""
    c_r = Fore.RED if COLOR_SUPPORT else ""
    c_m = Fore.MAGENTA if COLOR_SUPPORT else ""
    c_w = Fore.WHITE if COLOR_SUPPORT else ""
    R = Style.RESET_ALL if COLOR_SUPPORT else ""

    W = 37  # Inner width per column
    SEP = "─"

    def vlen(s):
        return len(re.sub(r'\033\[[0-9;]*m', '', s))

    def pad(s, w):
        return s + ' ' * max(0, w - vlen(s))

    # --- Build LEFT column: Security + SEO + Intel ---
    left = []
    sec = data['security']
    sec_icon = "🟢" if sec['level'] == 'LOW' else "🟡" if sec['level'] == 'MEDIUM' else "🔴"
    sec_c = c_g if sec['level'] == 'LOW' else c_y if sec['level'] == 'MEDIUM' else c_r
    left.append(f"SECURITY: {sec_icon} {sec_c}{sec['level']}{R}")
    for t in sec['threats'][:3]:
        left.append(f" - {t[:W-3]}")
    left.append(SEP)

    seo = data['seo']
    bar = '█' * int(seo['score']/5)
    left.append(f"SEO: {c_g}{seo['score']}{R}/100 {bar}")
    left.append(f"H1:{seo['headings']['h1']} H2:{seo['headings']['h2']} H3:{seo['headings']['h3']}")
    left.append(f"Imgs: {seo['images_analysis']['total']} total, {seo['images_analysis']['missing_alt']} no-alt")
    left.append(SEP)

    intel = data['intel']
    left.append(f"INTEL (OSINT):")
    left.append(f" 📧 Emails: {len(intel['emails'])}")
    for e in intel['emails'][:2]:
        left.append(f"    {e[:W-4]}")
    left.append(f" 📱 Phones: {len(intel['phones'])}")
    for p in intel['phones'][:2]:
        left.append(f"    {p[:W-4]}")
    left.append(f" 📍 Locations: {len(intel['locations'])}")
    left.append(f" 🛠️ {c_m}{', '.join(intel['tech_stack'][:3])[:W-4]}{R}")

    # --- Build RIGHT column: AI + Performance ---
    right = []
    if intel.get('ai_analysis'):
        ai = intel['ai_analysis']
        right.append(f"AI ANALYSIS:")
        right.append(f" Sentiment: {c_m}{ai['sentiment']['label']}{R} ({ai['sentiment']['polarity']})")
        right.append(f" Readability: {ai['readability']['level']} ({ai['readability']['score']})")
        right.append(f" Keywords:")
        kw = ', '.join(ai['keywords'][:5])
        right.append(f"  {kw[:W-2]}")
    right.append(SEP)

    perf = data.get('performance', {})
    if perf and perf.get('total'):
        right.append(f"PERFORMANCE: {c_y}{perf['total']:.2f}s{R}")
        for phase, dur in perf['phases'].items():
            perc = (dur / perf['total']) * 100
            bl = int(perc / 5)
            b = "█" * bl
            right.append(f" {phase[:12]:<12} {c_g}{b:<10}{R} {perc:>3.0f}%")
        right.append(f" Avg:{perf['avg']:.1f}s Best:{perf['best']:.1f}s")

    # Equalize rows
    mx = max(len(left), len(right))
    while len(left) < mx: left.append("")
    while len(right) < mx: right.append("")

    # --- Render ---
    url_display = data['site_structure']['url'][:W*2]
    total_w = W * 2 + 5  # inner total

    print(f"\n{c_b}╔{'═'*total_w}╗{R}")
    print(f"{c_b}║ {R}{pad('intelligence report: ' + url_display, total_w - 1)}{c_b}║{R}")
    print(f"{c_b}╠{'═'*W}═╦═{'═'*W}══╣{R}")

    for i in range(mx):
        l, r = left[i], right[i]
        l_sep = (l == SEP)
        r_sep = (r == SEP)

        if l_sep and r_sep:
            print(f"{c_b}╟{'─'*W}─╫─{'─'*W}──╢{R}")
        elif l_sep:
            print(f"{c_b}╟{'─'*W}─╫ {R}{pad(r, W+1)}{c_b}║{R}")
        elif r_sep:
            print(f"{c_b}║ {R}{pad(l, W)}{c_b}╟ {R}{' '*W} {c_b}║{R}")
        else:
            print(f"{c_b}║ {R}{pad(l, W)}{c_b}║ {R}{pad(r, W+1)}{c_b}║{R}")

    print(f"{c_b}╚{'═'*W}═╩═{'═'*W}══╝{R}\n")

def is_valid_url(text):
    """Smart detection for URLs/Domains - Ultra Strict"""
    text = text.lower().strip()
    if not text or ' ' in text or len(text) < 4: return False
    if text.startswith('http'): return True
    if text.startswith(('/', '.', '@')): return False
    
    # Must have a legitimate domain-like structure
    parts = text.split('.')
    if len(parts) >= 2:
        # Check TLD (2-12 chars, letters only)
        tld = parts[-1].split('/')[0]
        if tld.isalpha() and 2 <= len(tld) <= 12:
            # Common file types to exclude
            if tld in ['py', 'json', 'txt', 'md', 'exe', 'log', 'bat', 'sh', 'zip', 'rar']:
                return False
            # Ensure the domain part isn't empty or invalid
            domain_part = parts[-2]
            if domain_part and any(c.isalnum() for c in domain_part):
                return True
    return False

def run_cli_mode(initial_url=None):
    """Interactive CLI prompting flow"""
    if initial_url and not is_valid_url(initial_url):
        print(f"\n{Fore.RED}⚠️ Invalid Link: {Fore.WHITE}{initial_url}")
        time.sleep(1.5)
        return

    os.system('cls' if os.name == 'nt' else 'clear')
    banner = r"""██╗    ██╗███████╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
██║    ██║██╔════╝██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
██║ █╗ ██║█████╗  ██████╔╝       ██║   ██║   ██║██║   ██║██║     ███████╗
██║███╗██║██╔══╝  ██╔══██╗       ██║   ██║   ██║██║   ██║██║     ╚════██║
╚███╔███╔╝███████╗██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
 ╚══╝╚══╝ ╚══════╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝"""
    print_gradient_text(banner, (0, 255, 255), (255, 0, 255))
    print(f"{' ' * 45}{Fore.WHITE}{Style.DIM}Dev: Abhinav Adarsh{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{Style.BRIGHT}           ADVANCED CLI INTELLIGENCE MODE{Style.RESET_ALL}")
    
    try:
        url = initial_url if initial_url else input(f"{Fore.LIGHTGREEN_EX if COLOR_SUPPORT else ''}link > {Style.RESET_ALL}").strip()
        if not url: return
        
        # Double check validity if manual input
        if not initial_url and not is_valid_url(url):
            print(f"\n{Fore.RED}⚠️ Invalid Link: {Fore.WHITE}{url}")
            time.sleep(1.5)
            return
        
        if AUTOCOMPLETE_AVAILABLE:
            if not url.startswith('/'):
                try: readline.write_history_file(HISTORY_FILE)
                except: pass
            else:
                try: readline.remove_history_item(readline.get_current_history_length() - 1)
                except: pass

        print("\n⚙️  Scrape Options:")
        fetch_img = input("   - Fetch & Analyze Images? (y/N) > ").lower() == 'y'
        if AUTOCOMPLETE_AVAILABLE:
            try: readline.remove_history_item(readline.get_current_history_length() - 1)
            except: pass
        fetch_vid = input("   - Fetch & Deep-Scan Videos? (y/N) > ").lower() == 'y'
        if AUTOCOMPLETE_AVAILABLE:
            try: readline.remove_history_item(readline.get_current_history_length() - 1)
            except: pass
        depth = input("   - Crawl Depth (1-3) [Default 2] > ").strip()
        depth = int(depth) if depth.isdigit() else 2
        if AUTOCOMPLETE_AVAILABLE:
            try: readline.remove_history_item(readline.get_current_history_length() - 1)
            except: pass
        use_proxy = input("   - Use Intelligent Proxies? (y/N) > ").lower() == 'y'
        if AUTOCOMPLETE_AVAILABLE:
            try: readline.remove_history_item(readline.get_current_history_length() - 1)
            except: pass

        with MoonSpinner("Scanning"):
            result = execute_scrape_logic(url, fetch_img, fetch_vid, depth, use_proxy)
        print_cli_report(result)
        
        input("Press Enter to return to main menu and CLEAR session data...")
        clear_scraped_data()
        print("🧹 Session data cleared.")
        time.sleep(1)
    except KeyboardInterrupt:
        print("\n\n⚠️ Input interrupted. Returning to menu...")
        time.sleep(1)

def run_image_forensics_mode(initial_image=None):
    """CLI flow for image analysis"""
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        banner = r"""██╗███╗   ███╗ █████╗  ██████╗ ███████╗    ███████╗ ██████╗ ██████╗ ███████╗███╗   ██╗███████╗██╗ ██████╗███████╗
██║████╗ ████║██╔══██╗██╔════╝ ██╔════╝    ██╔════╝██╔═══██╗██╔══██╗██╔════╝████╗  ██║██╔════╝██║██╔════╝██╔════╝
██║██╔████╔██║███████║██║  ███╗█████╗      █████╗  ██║   ██║██████╔╝█████╗  ██╔██╗ ██║███████╗██║██║     ███████╗
██║██║╚██╔╝██║██╔══██║██║   ██║██╔══╝      ██╔══╝  ██║   ██║██╔══██╗██╔══╝  ██║╚██╗██║╚════██║██║██║     ╚════██║
██║██║ ╚═╝ ██║██║  ██║╚██████╔╝███████╗    ██║     ╚██████╔╝██║  ██║███████╗██║ ╚████║███████║██║╚██████╗███████║
╚═╝╚═╝     ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝    ╚═╝      ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═══╝╚══════╝╚═╝ ╚═════╝╚══════╝"""
        print_gradient_text(banner, (255, 100, 100), (100, 100, 255))
        print(f"{' ' * 45}{Fore.WHITE}{Style.DIM}Dev : Abhinav Adarsh{Style.RESET_ALL}\n")

        try:
            user_input = initial_image if initial_image else input(f"{Fore.LIGHTGREEN_EX if COLOR_SUPPORT else ''}image link or local path (or {Fore.RED}/q{Fore.LIGHTGREEN_EX if COLOR_SUPPORT else ''} to quit) > {Style.RESET_ALL}").strip()
            
            if user_input in ['/q', '/quit']:
                print("\n Returning to main menu...")
                time.sleep(1)
                return
            
            if not user_input:
                if initial_image:
                    return
                continue

            # Handle quotes (e.g. from copy-pasting path)
            user_input = user_input.strip('"\'')

            image = None
            source_type = "local"

            with MoonSpinner("Analyzing Image"):
                try:
                    # Is it a URL?
                    if user_input.startswith(('http://', 'https://')):
                        source_type = "url"
                        headers = {'User-Agent': proxy_manager.get_random_ua()}
                        resp = requests.get(user_input, headers=headers, stream=True, timeout=15, verify=False)
                        resp.raise_for_status()
                        image = Image.open(BytesIO(resp.content))
                    else:
                        # Assume it's a local path
                        if os.path.exists(user_input):
                            image = Image.open(user_input)
                        else:
                            print(f"\n{Fore.RED}Error: File or URL not found: {Fore.WHITE}{user_input}")
                            time.sleep(2)
                            if initial_image:
                                return
                            continue

                    if not image:
                        raise Exception("Failed to load image")

                    # Process
                    metadata = get_image_metadata(image)
                    ai_detection = compute_ai_likelihood(image)
                    
                    print_image_forensics_report({
                        'source': source_type,
                        'path': user_input,
                        'metadata': metadata,
                        'ai': ai_detection
                    })

                except Exception as e:
                    print(f"\n{Fore.RED}Analysis Failed: {Fore.WHITE}{e}")
                    time.sleep(2)
                    if initial_image:
                        return
                    continue

            if initial_image:
                input("\nPress Enter to return to main menu...")
                return
            
            response = input(f"\nAnalyze another image? (y/n or {Fore.RED}/q{Style.RESET_ALL} to quit): ").strip().lower()
            if response in ['/q', '/quit', 'n', 'no']:
                print("\n Returning to main menu...")
                time.sleep(1)
                return
                
        except KeyboardInterrupt:
            print("\n Returning to main menu...")
            time.sleep(1)
            return

def print_image_forensics_report(data):
    """Beautiful terminal table for image analysis results"""
    c_b = Fore.CYAN if COLOR_SUPPORT else ""
    c_g = Fore.GREEN if COLOR_SUPPORT else ""
    c_y = Fore.YELLOW if COLOR_SUPPORT else ""
    c_r = Fore.RED if COLOR_SUPPORT else ""
    c_w = Fore.WHITE if COLOR_SUPPORT else ""
    R = Style.RESET_ALL if COLOR_SUPPORT else ""

    meta = data['metadata']
    basic = meta['basic']
    ai = data['ai']
    
    total_w = 80
    def vlen(s): return len(re.sub(r'\033\[[0-9;]*m', '', s))
    def pad(s, w): return s + ' ' * (w - vlen(s))

    print(f"\n{c_b}╔{'═'*(total_w-2)}╗{R}")
    title = f" forensic report: {os.path.basename(data['path'])[:40]} "
    print(f"{c_b}║{R}{c_w}{Style.BRIGHT}{title.center(total_w-2)}{R}{c_b}║{R}")
    print(f"{c_b}╠{'═'*(total_w-2)}╣{R}")

    # Row helper
    def print_row(key, val, color=c_w):
        k = f" {key}:"
        line = f"{c_y}{pad(k, 20)}{R} {color}{val}{R}"
        print(f"{c_b}║{R} {pad(line, total_w-4)} {c_b}║{R}")

    # Basic Info
    print_row("Source Type", data['source'].upper(), c_g)
    print_row("Format", basic['Format'])
    print_row("Resolution", basic['Size'])
    print_row("Color Mode", basic['Mode'])
    
    # AI Detection
    ai_score = ai['score']
    ai_color = c_r if ai_score > 70 else (c_y if ai_score > 40 else c_g)
    print_row("AI Likelihood", f"{ai_score}% ({ai['label']})", ai_color)

    # GPS / Location
    if meta.get('location'):
        print_row("GPS Coordinates", f"{meta['location']['lat']}, {meta['location']['lon']}", c_m := (Fore.MAGENTA if COLOR_SUPPORT else ""))
        print_row("Map Link", meta['location']['map_url'], c_b)

    # Crucial EXIF
    exif = meta['exif']
    important_tags = ['Make', 'Model', 'Software', 'DateTime', 'LensModel', 'ExposureTime', 'ISOSpeedRatings']
    found_exif = False
    for tag in important_tags:
        if tag in exif:
            if not found_exif:
                print(f"{c_b}╟{'─'*(total_w-2)}╢{R}")
                found_exif = True
            print_row(tag, exif[tag])

    print(f"{c_b}╚{'═'*(total_w-2)}╝{R}\n")

def main_launcher():
    """Mode selection menu on startup"""
    menu_commands = ['/web', '/cli', '/image', '/help', '/clear', '/quit', '/history', '/setup-ai', '/w', '/c', '/i', '/h', '/q', '/hi', '--help']
    setup_autocomplete(menu_commands)
    
    while True:
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            banner = r"""██╗    ██╗███████╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
██║    ██║██╔════╝██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
██║ █╗ ██║█████╗  ██████╔╝       ██║   ██║   ██║██║   ██║██║     ███████╗
██║███╗██║██╔══╝  ██╔══██╗       ██║   ██║   ██║██║   ██║██║     ╚════██║
╚███╔███╔╝███████╗██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
 ╚══╝╚══╝ ╚══════╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝"""
            print_gradient_text(banner, (0, 255, 255), (255, 0, 255))
            print(f"{' ' * 45}{Fore.WHITE}{Style.DIM}Dev: Abhinav Adarsh{Style.RESET_ALL}")
            print(f"{Fore.WHITE}Type {Fore.CYAN}/help{Fore.WHITE} or {Fore.CYAN}/h{Fore.WHITE} to see all commands.")
            
            choice = input(f"{Fore.LIGHTGREEN_EX if COLOR_SUPPORT else ''}> {Style.RESET_ALL}").strip().lower()
            if AUTOCOMPLETE_AVAILABLE:
                try: readline.remove_history_item(readline.get_current_history_length() - 1)
                except: pass
            
            if choice in ['/web', '/w']:
                # Check and install Playwright browsers if needed
                if PLAYWRIGHT_AVAILABLE:
                    install_playwright_browsers()
                start_web_server()
            elif choice in ['/cli', '/c']:
                # Check and install Playwright browsers if needed
                if PLAYWRIGHT_AVAILABLE:
                    install_playwright_browsers()
                run_cli_mode()
            elif choice in ['/image', '/i']:
                run_image_forensics_mode()
            elif choice in ['/help', '/h', '--help']:
                print(f"\n{Fore.CYAN if COLOR_SUPPORT else ''}Available Commands:")
                print(f"  {Fore.CYAN}/web{Style.RESET_ALL}     - Launches the web engine for browser-based auditing. (Alias: /w)")
                print(f"  {Fore.CYAN}/cli{Style.RESET_ALL}     - Runs a deep-scan intelligence report in the terminal. (Alias: /c)")
                print(f"  {Fore.CYAN}/image{Style.RESET_ALL}   - Local/Remote Image Forensics & AI detection. (Alias: /i)")
                print(f"  {Fore.CYAN}/setup-ai{Style.RESET_ALL}- Downloads required NLTK data for AI sentiment analysis.")
                print(f"  {Fore.CYAN}/clear{Style.RESET_ALL}   - Purges the 'webfiles/scraped' directory and clears screen.")
                print(f"  {Fore.CYAN}/history{Style.RESET_ALL} - Shows command history. (Alias: /hi)")
                print(f"  {Fore.CYAN}/help{Style.RESET_ALL}    - Displays this help message. (Alias: /h, --help)")
                print(f"  {Fore.RED}/quit{Style.RESET_ALL}    - Shuts down the application safely. (Alias: /q)")
                print(f"\n{Fore.YELLOW}Tip:{Style.RESET_ALL} While in /web mode, type {Fore.RED}/q{Style.RESET_ALL} to return to main menu.")
                input("\nPress Enter to continue...")
            elif choice == '/setup-ai':
                print(f"\n{Fore.CYAN}Initializing AI Data Setup...{Style.RESET_ALL}")
                if ensure_textblob_corpora(download=True):
                    print(f"{Fore.GREEN}✅ AI Data successfully installed!")
                else:
                    print(f"{Fore.RED}❌ AI Data installation failed. Check internet connection.")
                input("\nPress Enter to continue...")
            elif choice in ['/history', '/hi']:
                if AUTOCOMPLETE_AVAILABLE and os.path.exists(HISTORY_FILE):
                    print(f"\n{Fore.CYAN}--- Command History ---{Style.RESET_ALL}")
                    with open(HISTORY_FILE, 'r') as f:
                        lines = f.readlines()
                        for i, line in enumerate(lines[-20:]): # Show last 20
                            print(f"{Fore.WHITE}{i+1}. {line.strip()}")
                else:
                    print(f"\n{Fore.YELLOW}No history found.")
                input("\nPress Enter to continue...")
            elif choice in ['/clear', '/c']:
                clear_scraped_data()
                os.system('cls' if os.name == 'nt' else 'clear')
                print("Cache purged and screen cleared.")
                time.sleep(1)
            elif choice in ['/quit', '/q']:
                print(f"\n{Fore.YELLOW if COLOR_SUPPORT else ''}Goodbye!")
                sys.exit()
            elif is_valid_url(choice):
                run_cli_mode(choice)
        except KeyboardInterrupt:
            print("\n\nGoodbye!")
            sys.exit()

def start_web_server():
    """Original server startup logic"""
    public_url, tunnel_proc = None, None
    with MoonSpinner("Initializing Web Engine"):
        threading.Thread(target=lambda: app.run(host='0.0.0.0', port=PORT, debug=False, use_reloader=False, threaded=True), daemon=True).start()
        
        if wait_for_server(PORT, timeout=10):
            public_url, tunnel_proc = start_cloudflare_tunnel(PORT)
        else:
            print("❌ Server failed to start")
            return

    if public_url:
        os.system('cls' if os.name == 'nt' else 'clear')
        print(f"Scan this QR code :\n")
        display_qr_image(public_url)
        print(f"\nType {Fore.RED}/q{Style.RESET_ALL} or press Ctrl+C to return to main menu.")
        
        try:
            if 'google.colab' in sys.modules:
                print("\n Running in Background. Type /q to stop.")
                while True:
                    user_input = input().strip()
                    if user_input in ['/q', '/quit']:
                        print("\n Returning to main menu...")
                        break
                    time.sleep(0.1)
            else:
                while True:
                    try:
                        user_input = input().strip()
                        if user_input in ['/q', '/quit']:
                            print("\n Returning to main menu...")
                            break
                    except EOFError:
                        time.sleep(1)
        except KeyboardInterrupt:
            print("\n Returning to main menu...")
        finally:
            if tunnel_proc:
                try: tunnel_proc.terminate()
                except: pass
    else:
        print("❌ Failed to create tunnel")

# Sab start karo
if __name__ == '__main__':
    main_launcher()