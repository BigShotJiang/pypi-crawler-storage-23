r'''
# @jjrawlins/cdk-deploy-pr-github-action

A [projen](https://projen.io/) construct that generates GitHub Actions workflows for AWS CDK deployments.

## Features

* **Automated deploy pipeline** (`deploy.yml`) — synth, publish assets, and deploy on push to main
* **Manual dispatch workflow** (`deploy-dispatch.yml`) — deploy any previously published version to any environment
* **Versioned cloud assemblies** — publishes `cdk.out` to GitHub Packages with auto-incrementing versions
* **GitHub Releases** — each deploy creates a git tag and GitHub Release tied to the assembly version
* **Multi-stage deployments** — parallel or sequential stages with `dependsOn` ordering
* **GitHub Environments** — per-stage environment protection rules, secrets scoping, and deployment approvals
* **Manual approval stages** — exclude stages from auto-deploy, only deployable via dispatch
* **Per-stage IAM role overrides** — cross-account deployments with per-stage OIDC roles
* **Concurrency groups** — prevents concurrent deployments to the same stage
* **Rollback support** — redeploy any previous assembly version via the dispatch workflow

## Installation

```bash
npm install @jjrawlins/cdk-deploy-pr-github-action
```

Also available on [PyPI](https://pypi.org/project/jjrawlins-cdk-deploy-pr-github-action/), [NuGet](https://www.nuget.org/packages/JJRawlins.CdkDeployPrGithubAction), and [Go](https://pkg.go.dev/github.com/JaysonRawlins/cdk-deploy-pr-github-action).

## Usage

In your `.projenrc.ts`:

```python
import { CdkDeployPipeline } from '@jjrawlins/cdk-deploy-pr-github-action';

new CdkDeployPipeline(project, {
  stackPrefix: 'MyApp',
  pkgNamespace: '@my-org',
  iamRoleArn: 'arn:aws:iam::111111111111:role/GitHubActionsOidcRole',
  iamRoleRegion: 'us-east-1',
  stages: [
    {
      name: 'dev',
      env: { account: '222222222222', region: 'us-east-1' },
      environment: 'development',
    },
    {
      name: 'staging',
      env: { account: '333333333333', region: 'us-east-1' },
      environment: 'staging',
      dependsOn: ['dev'],
    },
    {
      name: 'prod',
      env: { account: '444444444444', region: 'us-east-1' },
      environment: 'production',
      dependsOn: ['staging'],
      manualApproval: true, // Only deployable via dispatch
    },
  ],
});
```

Run `npx projen` to generate the workflow files.

## Generated Workflows

### `deploy.yml`

Triggered on push to main. Jobs:

1. **synth** — checks out code, installs dependencies, runs `cdk synth`, uploads cloud assembly artifact
2. **publish-assets** — publishes Lambda/container assets to AWS, versions and publishes the cloud assembly to GitHub Packages, creates a git tag and GitHub Release
3. **deploy-{stage}** — one job per non-manual stage, deploys stacks using the cloud assembly artifact

### `deploy-dispatch.yml`

Triggered manually via `workflow_dispatch`. Inputs:

* **environment** — target environment (dropdown of configured stages)
* **version** — assembly version to deploy (e.g., `0.0.4`)

Downloads the specified assembly version from GitHub Packages and deploys it. This enables:

* Deploying to `manualApproval` stages (e.g., production)
* Rolling back to any previous version
* Ad-hoc deployments outside the normal CI/CD flow

## Options

### `CdkDeployPipelineOptions`

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `pkgNamespace` | `string` | *required* | npm scope for assembly packages (e.g., `@my-org`) |
| `stackPrefix` | `string` | *required* | Stack name prefix (e.g., `MyApp` -> `MyApp-dev`) |
| `iamRoleArn` | `string` | *required* | Default OIDC role ARN for AWS credential assumption |
| `stages` | `DeployStageOptions[]` | *required* | Deployment stages |
| `iamRoleRegion` | `string` | `us-east-1` | Default AWS region for OIDC credential assumption |
| `nodeVersion` | `string` | `24.x` | Node.js version for workflow runners |
| `cdkCommand` | `string` | `npx cdk` | CDK CLI command prefix |
| `installCommand` | `string` | `yarn install --check-files --frozen-lockfile` | Package install command |
| `manualDeployment` | `boolean` | `true` | Generate the dispatch workflow |
| `useGithubPackagesForAssembly` | `boolean` | `true` | Publish cloud assembly to GitHub Packages |
| `branchName` | `string` | `main` | Branch that triggers deployments |

### `DeployStageOptions`

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `name` | `string` | *required* | Stage name (used in job IDs and stack names) |
| `env` | `{ account, region }` | *required* | AWS target environment |
| `environment` | `string` | stage name | GitHub Environment name |
| `iamRoleArn` | `string` | pipeline default | Override OIDC role for this stage |
| `iamRoleRegion` | `string` | pipeline default | Override AWS region for this stage |
| `dependsOn` | `string[]` | `[]` | Stages that must complete first |
| `stacks` | `string[]` | `['{stackPrefix}-{name}']` | CDK stack names to deploy |
| `manualApproval` | `boolean` | `false` | Exclude from auto-deploy, dispatch only |

## Examples

### Parallel stages

Stages without `dependsOn` run in parallel after asset publishing:

```python
stages: [
  { name: 'us-east-1', env: usEast1Env },
  { name: 'eu-west-1', env: euWest1Env },
]
```

### Cross-account with per-stage roles

```python
stages: [
  {
    name: 'dev',
    env: { account: '222222222222', region: 'us-east-1' },
    iamRoleArn: 'arn:aws:iam::222222222222:role/DevDeployRole',
  },
  {
    name: 'prod',
    env: { account: '333333333333', region: 'us-east-1' },
    iamRoleArn: 'arn:aws:iam::333333333333:role/ProdDeployRole',
    manualApproval: true,
  },
]
```

### Rolling back

Each deploy creates a GitHub Release with the assembly version. To roll back:

```bash
gh workflow run deploy-dispatch.yml -f environment=production -f version=0.0.3
```

## Prerequisites

* AWS OIDC identity provider configured for GitHub Actions
* IAM role with trust policy for GitHub Actions OIDC
* GitHub Environments configured for deployment protection rules (optional)

## License

Apache-2.0
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ._jsii import *


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-deploy-pr-github-action.AwsEnvironment",
    jsii_struct_bases=[],
    name_mapping={"account": "account", "region": "region"},
)
class AwsEnvironment:
    def __init__(self, *, account: builtins.str, region: builtins.str) -> None:
        '''AWS environment target for a deployment stage.

        :param account: AWS account ID.
        :param region: AWS region.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__55b37d39845ad5a35e8c503333edb493bc147e36a4431940770a9215267c4186)
            check_type(argname="argument account", value=account, expected_type=type_hints["account"])
            check_type(argname="argument region", value=region, expected_type=type_hints["region"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "account": account,
            "region": region,
        }

    @builtins.property
    def account(self) -> builtins.str:
        '''AWS account ID.'''
        result = self._values.get("account")
        assert result is not None, "Required property 'account' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def region(self) -> builtins.str:
        '''AWS region.'''
        result = self._values.get("region")
        assert result is not None, "Required property 'region' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "AwsEnvironment(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CdkDeployDispatchWorkflow(
    metaclass=jsii.JSIIMeta,
    jsii_type="@jjrawlins/cdk-deploy-pr-github-action.CdkDeployDispatchWorkflow",
):
    '''Generates a workflow_dispatch workflow for manual CDK deployments and rollbacks.

    Allows deploying any previously published version of the cloud assembly
    to any configured environment. This enables:

    - Manual promotion between environments
    - Rollback to any previous version
    - Ad-hoc deployments outside the normal CI/CD flow
    '''

    def __init__(
        self,
        project: typing.Any,
        *,
        app_name: builtins.str,
        cdk_command: builtins.str,
        iam_role_arn: builtins.str,
        iam_role_region: builtins.str,
        install_command: builtins.str,
        node_version: builtins.str,
        pkg_namespace: builtins.str,
        stack_prefix: builtins.str,
        stages: typing.Sequence[typing.Union["DeployStageOptions", typing.Dict[builtins.str, typing.Any]]],
    ) -> None:
        '''
        :param project: -
        :param app_name: 
        :param cdk_command: 
        :param iam_role_arn: 
        :param iam_role_region: 
        :param install_command: 
        :param node_version: 
        :param pkg_namespace: 
        :param stack_prefix: 
        :param stages: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__95e1d806c4c893dadb14d2ffca8dcd1081a6e13665ce071117e4a01c5b32ba72)
            check_type(argname="argument project", value=project, expected_type=type_hints["project"])
        options = DeployDispatchInternalOptions(
            app_name=app_name,
            cdk_command=cdk_command,
            iam_role_arn=iam_role_arn,
            iam_role_region=iam_role_region,
            install_command=install_command,
            node_version=node_version,
            pkg_namespace=pkg_namespace,
            stack_prefix=stack_prefix,
            stages=stages,
        )

        jsii.create(self.__class__, self, [project, options])


class CdkDeployPipeline(
    metaclass=jsii.JSIIMeta,
    jsii_type="@jjrawlins/cdk-deploy-pr-github-action.CdkDeployPipeline",
):
    '''Generates GitHub Actions workflows for CDK deployments.

    Creates a ``deploy.yml`` workflow with:

    - Synth job to compile and synthesize the CDK app
    - Asset publish job to upload Lambda/container assets to AWS
    - Per-stage deploy jobs with GitHub Environments, parallel execution, and concurrency groups

    Optionally creates a ``deploy-dispatch.yml`` workflow for manual deployments and rollbacks.
    '''

    def __init__(
        self,
        project: typing.Any,
        *,
        iam_role_arn: builtins.str,
        pkg_namespace: builtins.str,
        stack_prefix: builtins.str,
        stages: typing.Sequence[typing.Union["DeployStageOptions", typing.Dict[builtins.str, typing.Any]]],
        branch_name: typing.Optional[builtins.str] = None,
        cdk_command: typing.Optional[builtins.str] = None,
        iam_role_region: typing.Optional[builtins.str] = None,
        install_command: typing.Optional[builtins.str] = None,
        manual_deployment: typing.Optional[builtins.bool] = None,
        node_version: typing.Optional[builtins.str] = None,
        use_github_packages_for_assembly: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''
        :param project: -
        :param iam_role_arn: Default OIDC role ARN for AWS credential assumption.
        :param pkg_namespace: npm scope for versioned cloud assembly packages (e.g., '@defiance-digital').
        :param stack_prefix: Stack name prefix. Stage names are appended with a dash (e.g., 'MyApp' -> 'MyApp-Production')
        :param stages: Deployment stages in declaration order.
        :param branch_name: Branch that triggers deployments on push. Default: 'main'
        :param cdk_command: CDK CLI command prefix. Default: 'npx cdk'
        :param iam_role_region: Default AWS region for OIDC credential assumption. Default: 'us-east-1'
        :param install_command: Package install command. Default: 'yarn install --check-files --frozen-lockfile'
        :param manual_deployment: Generate a workflow_dispatch workflow for manual deployments and rollbacks. Default: true
        :param node_version: Node.js version for workflow runners. Default: '24.x'
        :param use_github_packages_for_assembly: Version and publish cloud assembly to GitHub Packages for rollback support. Default: true
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fd5610c02687537e020f1eb5581bb5592e9f94564325ecf494074c110c0f6c7f)
            check_type(argname="argument project", value=project, expected_type=type_hints["project"])
        options = CdkDeployPipelineOptions(
            iam_role_arn=iam_role_arn,
            pkg_namespace=pkg_namespace,
            stack_prefix=stack_prefix,
            stages=stages,
            branch_name=branch_name,
            cdk_command=cdk_command,
            iam_role_region=iam_role_region,
            install_command=install_command,
            manual_deployment=manual_deployment,
            node_version=node_version,
            use_github_packages_for_assembly=use_github_packages_for_assembly,
        )

        jsii.create(self.__class__, self, [project, options])


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-deploy-pr-github-action.CdkDeployPipelineOptions",
    jsii_struct_bases=[],
    name_mapping={
        "iam_role_arn": "iamRoleArn",
        "pkg_namespace": "pkgNamespace",
        "stack_prefix": "stackPrefix",
        "stages": "stages",
        "branch_name": "branchName",
        "cdk_command": "cdkCommand",
        "iam_role_region": "iamRoleRegion",
        "install_command": "installCommand",
        "manual_deployment": "manualDeployment",
        "node_version": "nodeVersion",
        "use_github_packages_for_assembly": "useGithubPackagesForAssembly",
    },
)
class CdkDeployPipelineOptions:
    def __init__(
        self,
        *,
        iam_role_arn: builtins.str,
        pkg_namespace: builtins.str,
        stack_prefix: builtins.str,
        stages: typing.Sequence[typing.Union["DeployStageOptions", typing.Dict[builtins.str, typing.Any]]],
        branch_name: typing.Optional[builtins.str] = None,
        cdk_command: typing.Optional[builtins.str] = None,
        iam_role_region: typing.Optional[builtins.str] = None,
        install_command: typing.Optional[builtins.str] = None,
        manual_deployment: typing.Optional[builtins.bool] = None,
        node_version: typing.Optional[builtins.str] = None,
        use_github_packages_for_assembly: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''Configuration for the CDK deploy pipeline.

        :param iam_role_arn: Default OIDC role ARN for AWS credential assumption.
        :param pkg_namespace: npm scope for versioned cloud assembly packages (e.g., '@defiance-digital').
        :param stack_prefix: Stack name prefix. Stage names are appended with a dash (e.g., 'MyApp' -> 'MyApp-Production')
        :param stages: Deployment stages in declaration order.
        :param branch_name: Branch that triggers deployments on push. Default: 'main'
        :param cdk_command: CDK CLI command prefix. Default: 'npx cdk'
        :param iam_role_region: Default AWS region for OIDC credential assumption. Default: 'us-east-1'
        :param install_command: Package install command. Default: 'yarn install --check-files --frozen-lockfile'
        :param manual_deployment: Generate a workflow_dispatch workflow for manual deployments and rollbacks. Default: true
        :param node_version: Node.js version for workflow runners. Default: '24.x'
        :param use_github_packages_for_assembly: Version and publish cloud assembly to GitHub Packages for rollback support. Default: true
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__61a7fa163838ee4fd916db4be0d084f5f1f643299d15b44adbb9e992f796e1b2)
            check_type(argname="argument iam_role_arn", value=iam_role_arn, expected_type=type_hints["iam_role_arn"])
            check_type(argname="argument pkg_namespace", value=pkg_namespace, expected_type=type_hints["pkg_namespace"])
            check_type(argname="argument stack_prefix", value=stack_prefix, expected_type=type_hints["stack_prefix"])
            check_type(argname="argument stages", value=stages, expected_type=type_hints["stages"])
            check_type(argname="argument branch_name", value=branch_name, expected_type=type_hints["branch_name"])
            check_type(argname="argument cdk_command", value=cdk_command, expected_type=type_hints["cdk_command"])
            check_type(argname="argument iam_role_region", value=iam_role_region, expected_type=type_hints["iam_role_region"])
            check_type(argname="argument install_command", value=install_command, expected_type=type_hints["install_command"])
            check_type(argname="argument manual_deployment", value=manual_deployment, expected_type=type_hints["manual_deployment"])
            check_type(argname="argument node_version", value=node_version, expected_type=type_hints["node_version"])
            check_type(argname="argument use_github_packages_for_assembly", value=use_github_packages_for_assembly, expected_type=type_hints["use_github_packages_for_assembly"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "iam_role_arn": iam_role_arn,
            "pkg_namespace": pkg_namespace,
            "stack_prefix": stack_prefix,
            "stages": stages,
        }
        if branch_name is not None:
            self._values["branch_name"] = branch_name
        if cdk_command is not None:
            self._values["cdk_command"] = cdk_command
        if iam_role_region is not None:
            self._values["iam_role_region"] = iam_role_region
        if install_command is not None:
            self._values["install_command"] = install_command
        if manual_deployment is not None:
            self._values["manual_deployment"] = manual_deployment
        if node_version is not None:
            self._values["node_version"] = node_version
        if use_github_packages_for_assembly is not None:
            self._values["use_github_packages_for_assembly"] = use_github_packages_for_assembly

    @builtins.property
    def iam_role_arn(self) -> builtins.str:
        '''Default OIDC role ARN for AWS credential assumption.'''
        result = self._values.get("iam_role_arn")
        assert result is not None, "Required property 'iam_role_arn' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def pkg_namespace(self) -> builtins.str:
        '''npm scope for versioned cloud assembly packages (e.g., '@defiance-digital').'''
        result = self._values.get("pkg_namespace")
        assert result is not None, "Required property 'pkg_namespace' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def stack_prefix(self) -> builtins.str:
        '''Stack name prefix.

        Stage names are appended with a dash (e.g., 'MyApp' -> 'MyApp-Production')
        '''
        result = self._values.get("stack_prefix")
        assert result is not None, "Required property 'stack_prefix' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def stages(self) -> typing.List["DeployStageOptions"]:
        '''Deployment stages in declaration order.'''
        result = self._values.get("stages")
        assert result is not None, "Required property 'stages' is missing"
        return typing.cast(typing.List["DeployStageOptions"], result)

    @builtins.property
    def branch_name(self) -> typing.Optional[builtins.str]:
        '''Branch that triggers deployments on push.

        :default: 'main'
        '''
        result = self._values.get("branch_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def cdk_command(self) -> typing.Optional[builtins.str]:
        '''CDK CLI command prefix.

        :default: 'npx cdk'
        '''
        result = self._values.get("cdk_command")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def iam_role_region(self) -> typing.Optional[builtins.str]:
        '''Default AWS region for OIDC credential assumption.

        :default: 'us-east-1'
        '''
        result = self._values.get("iam_role_region")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def install_command(self) -> typing.Optional[builtins.str]:
        '''Package install command.

        :default: 'yarn install --check-files --frozen-lockfile'
        '''
        result = self._values.get("install_command")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def manual_deployment(self) -> typing.Optional[builtins.bool]:
        '''Generate a workflow_dispatch workflow for manual deployments and rollbacks.

        :default: true
        '''
        result = self._values.get("manual_deployment")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def node_version(self) -> typing.Optional[builtins.str]:
        '''Node.js version for workflow runners.

        :default: '24.x'
        '''
        result = self._values.get("node_version")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def use_github_packages_for_assembly(self) -> typing.Optional[builtins.bool]:
        '''Version and publish cloud assembly to GitHub Packages for rollback support.

        :default: true
        '''
        result = self._values.get("use_github_packages_for_assembly")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CdkDeployPipelineOptions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-deploy-pr-github-action.DeployDispatchInternalOptions",
    jsii_struct_bases=[],
    name_mapping={
        "app_name": "appName",
        "cdk_command": "cdkCommand",
        "iam_role_arn": "iamRoleArn",
        "iam_role_region": "iamRoleRegion",
        "install_command": "installCommand",
        "node_version": "nodeVersion",
        "pkg_namespace": "pkgNamespace",
        "stack_prefix": "stackPrefix",
        "stages": "stages",
    },
)
class DeployDispatchInternalOptions:
    def __init__(
        self,
        *,
        app_name: builtins.str,
        cdk_command: builtins.str,
        iam_role_arn: builtins.str,
        iam_role_region: builtins.str,
        install_command: builtins.str,
        node_version: builtins.str,
        pkg_namespace: builtins.str,
        stack_prefix: builtins.str,
        stages: typing.Sequence[typing.Union["DeployStageOptions", typing.Dict[builtins.str, typing.Any]]],
    ) -> None:
        '''Internal helper to build deploy dispatch workflow options from pipeline options.

        Exported for use by CdkDeployDispatchWorkflow.

        :param app_name: 
        :param cdk_command: 
        :param iam_role_arn: 
        :param iam_role_region: 
        :param install_command: 
        :param node_version: 
        :param pkg_namespace: 
        :param stack_prefix: 
        :param stages: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bb0cc8f66445ad544cfb6237542cb40e029f4d28a5debf1f25e3e1ef67c17c33)
            check_type(argname="argument app_name", value=app_name, expected_type=type_hints["app_name"])
            check_type(argname="argument cdk_command", value=cdk_command, expected_type=type_hints["cdk_command"])
            check_type(argname="argument iam_role_arn", value=iam_role_arn, expected_type=type_hints["iam_role_arn"])
            check_type(argname="argument iam_role_region", value=iam_role_region, expected_type=type_hints["iam_role_region"])
            check_type(argname="argument install_command", value=install_command, expected_type=type_hints["install_command"])
            check_type(argname="argument node_version", value=node_version, expected_type=type_hints["node_version"])
            check_type(argname="argument pkg_namespace", value=pkg_namespace, expected_type=type_hints["pkg_namespace"])
            check_type(argname="argument stack_prefix", value=stack_prefix, expected_type=type_hints["stack_prefix"])
            check_type(argname="argument stages", value=stages, expected_type=type_hints["stages"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "app_name": app_name,
            "cdk_command": cdk_command,
            "iam_role_arn": iam_role_arn,
            "iam_role_region": iam_role_region,
            "install_command": install_command,
            "node_version": node_version,
            "pkg_namespace": pkg_namespace,
            "stack_prefix": stack_prefix,
            "stages": stages,
        }

    @builtins.property
    def app_name(self) -> builtins.str:
        result = self._values.get("app_name")
        assert result is not None, "Required property 'app_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def cdk_command(self) -> builtins.str:
        result = self._values.get("cdk_command")
        assert result is not None, "Required property 'cdk_command' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def iam_role_arn(self) -> builtins.str:
        result = self._values.get("iam_role_arn")
        assert result is not None, "Required property 'iam_role_arn' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def iam_role_region(self) -> builtins.str:
        result = self._values.get("iam_role_region")
        assert result is not None, "Required property 'iam_role_region' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def install_command(self) -> builtins.str:
        result = self._values.get("install_command")
        assert result is not None, "Required property 'install_command' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def node_version(self) -> builtins.str:
        result = self._values.get("node_version")
        assert result is not None, "Required property 'node_version' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def pkg_namespace(self) -> builtins.str:
        result = self._values.get("pkg_namespace")
        assert result is not None, "Required property 'pkg_namespace' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def stack_prefix(self) -> builtins.str:
        result = self._values.get("stack_prefix")
        assert result is not None, "Required property 'stack_prefix' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def stages(self) -> typing.List["DeployStageOptions"]:
        result = self._values.get("stages")
        assert result is not None, "Required property 'stages' is missing"
        return typing.cast(typing.List["DeployStageOptions"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DeployDispatchInternalOptions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@jjrawlins/cdk-deploy-pr-github-action.DeployStageOptions",
    jsii_struct_bases=[],
    name_mapping={
        "env": "env",
        "name": "name",
        "depends_on": "dependsOn",
        "environment": "environment",
        "iam_role_arn": "iamRoleArn",
        "iam_role_region": "iamRoleRegion",
        "manual_approval": "manualApproval",
        "stacks": "stacks",
    },
)
class DeployStageOptions:
    def __init__(
        self,
        *,
        env: typing.Union["AwsEnvironment", typing.Dict[builtins.str, typing.Any]],
        name: builtins.str,
        depends_on: typing.Optional[typing.Sequence[builtins.str]] = None,
        environment: typing.Optional[builtins.str] = None,
        iam_role_arn: typing.Optional[builtins.str] = None,
        iam_role_region: typing.Optional[builtins.str] = None,
        manual_approval: typing.Optional[builtins.bool] = None,
        stacks: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''Configuration for a single deployment stage.

        :param env: AWS target environment (account + region).
        :param name: Stage name (used as suffix in job IDs and stack names, e.g., 'Sandbox', 'Production').
        :param depends_on: Stage names that must complete successfully before this stage runs. Stages with no dependsOn run in parallel after the publish-assets job. Default: - depends only on publish-assets (runs as soon as assets are ready)
        :param environment: GitHub Environment name for protection rules, secrets scoping, and deployment approvals. Default: - uses the stage name
        :param iam_role_arn: Override the default OIDC role ARN for this stage. Useful for cross-account deployments where each account has its own role.
        :param iam_role_region: Override the default AWS region for OIDC credential assumption. Default: - uses the pipeline-level iamRoleRegion or the stage env.region
        :param manual_approval: When true, this stage is excluded from the automatic deploy.yml pipeline and can only be deployed via the deploy-dispatch.yml workflow. Auto-deploy stages cannot depend on manual-approval stages. Default: false
        :param stacks: Specific CDK stack names to deploy in this stage. Default: - ['{stackPrefix}-{stageName}']
        '''
        if isinstance(env, dict):
            env = AwsEnvironment(**env)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cc4cfebd6c045db80dc09f05cdcf2a5ca9add5751cf21fb421c4c2181d3d8f5e)
            check_type(argname="argument env", value=env, expected_type=type_hints["env"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument environment", value=environment, expected_type=type_hints["environment"])
            check_type(argname="argument iam_role_arn", value=iam_role_arn, expected_type=type_hints["iam_role_arn"])
            check_type(argname="argument iam_role_region", value=iam_role_region, expected_type=type_hints["iam_role_region"])
            check_type(argname="argument manual_approval", value=manual_approval, expected_type=type_hints["manual_approval"])
            check_type(argname="argument stacks", value=stacks, expected_type=type_hints["stacks"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "env": env,
            "name": name,
        }
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if environment is not None:
            self._values["environment"] = environment
        if iam_role_arn is not None:
            self._values["iam_role_arn"] = iam_role_arn
        if iam_role_region is not None:
            self._values["iam_role_region"] = iam_role_region
        if manual_approval is not None:
            self._values["manual_approval"] = manual_approval
        if stacks is not None:
            self._values["stacks"] = stacks

    @builtins.property
    def env(self) -> "AwsEnvironment":
        '''AWS target environment (account + region).'''
        result = self._values.get("env")
        assert result is not None, "Required property 'env' is missing"
        return typing.cast("AwsEnvironment", result)

    @builtins.property
    def name(self) -> builtins.str:
        '''Stage name (used as suffix in job IDs and stack names, e.g., 'Sandbox', 'Production').'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def depends_on(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Stage names that must complete successfully before this stage runs.

        Stages with no dependsOn run in parallel after the publish-assets job.

        :default: - depends only on publish-assets (runs as soon as assets are ready)

        Example::

            ['Sandbox', 'Dev'] // waits for both before deploying
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def environment(self) -> typing.Optional[builtins.str]:
        '''GitHub Environment name for protection rules, secrets scoping, and deployment approvals.

        :default: - uses the stage name
        '''
        result = self._values.get("environment")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def iam_role_arn(self) -> typing.Optional[builtins.str]:
        '''Override the default OIDC role ARN for this stage.

        Useful for cross-account deployments where each account has its own role.
        '''
        result = self._values.get("iam_role_arn")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def iam_role_region(self) -> typing.Optional[builtins.str]:
        '''Override the default AWS region for OIDC credential assumption.

        :default: - uses the pipeline-level iamRoleRegion or the stage env.region
        '''
        result = self._values.get("iam_role_region")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def manual_approval(self) -> typing.Optional[builtins.bool]:
        '''When true, this stage is excluded from the automatic deploy.yml pipeline and can only be deployed via the deploy-dispatch.yml workflow.

        Auto-deploy stages cannot depend on manual-approval stages.

        :default: false
        '''
        result = self._values.get("manual_approval")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def stacks(self) -> typing.Optional[typing.List[builtins.str]]:
        '''Specific CDK stack names to deploy in this stage.

        :default: - ['{stackPrefix}-{stageName}']
        '''
        result = self._values.get("stacks")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DeployStageOptions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "AwsEnvironment",
    "CdkDeployDispatchWorkflow",
    "CdkDeployPipeline",
    "CdkDeployPipelineOptions",
    "DeployDispatchInternalOptions",
    "DeployStageOptions",
]

publication.publish()

def _typecheckingstub__55b37d39845ad5a35e8c503333edb493bc147e36a4431940770a9215267c4186(
    *,
    account: builtins.str,
    region: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__95e1d806c4c893dadb14d2ffca8dcd1081a6e13665ce071117e4a01c5b32ba72(
    project: typing.Any,
    *,
    app_name: builtins.str,
    cdk_command: builtins.str,
    iam_role_arn: builtins.str,
    iam_role_region: builtins.str,
    install_command: builtins.str,
    node_version: builtins.str,
    pkg_namespace: builtins.str,
    stack_prefix: builtins.str,
    stages: typing.Sequence[typing.Union[DeployStageOptions, typing.Dict[builtins.str, typing.Any]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fd5610c02687537e020f1eb5581bb5592e9f94564325ecf494074c110c0f6c7f(
    project: typing.Any,
    *,
    iam_role_arn: builtins.str,
    pkg_namespace: builtins.str,
    stack_prefix: builtins.str,
    stages: typing.Sequence[typing.Union[DeployStageOptions, typing.Dict[builtins.str, typing.Any]]],
    branch_name: typing.Optional[builtins.str] = None,
    cdk_command: typing.Optional[builtins.str] = None,
    iam_role_region: typing.Optional[builtins.str] = None,
    install_command: typing.Optional[builtins.str] = None,
    manual_deployment: typing.Optional[builtins.bool] = None,
    node_version: typing.Optional[builtins.str] = None,
    use_github_packages_for_assembly: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__61a7fa163838ee4fd916db4be0d084f5f1f643299d15b44adbb9e992f796e1b2(
    *,
    iam_role_arn: builtins.str,
    pkg_namespace: builtins.str,
    stack_prefix: builtins.str,
    stages: typing.Sequence[typing.Union[DeployStageOptions, typing.Dict[builtins.str, typing.Any]]],
    branch_name: typing.Optional[builtins.str] = None,
    cdk_command: typing.Optional[builtins.str] = None,
    iam_role_region: typing.Optional[builtins.str] = None,
    install_command: typing.Optional[builtins.str] = None,
    manual_deployment: typing.Optional[builtins.bool] = None,
    node_version: typing.Optional[builtins.str] = None,
    use_github_packages_for_assembly: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bb0cc8f66445ad544cfb6237542cb40e029f4d28a5debf1f25e3e1ef67c17c33(
    *,
    app_name: builtins.str,
    cdk_command: builtins.str,
    iam_role_arn: builtins.str,
    iam_role_region: builtins.str,
    install_command: builtins.str,
    node_version: builtins.str,
    pkg_namespace: builtins.str,
    stack_prefix: builtins.str,
    stages: typing.Sequence[typing.Union[DeployStageOptions, typing.Dict[builtins.str, typing.Any]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cc4cfebd6c045db80dc09f05cdcf2a5ca9add5751cf21fb421c4c2181d3d8f5e(
    *,
    env: typing.Union[AwsEnvironment, typing.Dict[builtins.str, typing.Any]],
    name: builtins.str,
    depends_on: typing.Optional[typing.Sequence[builtins.str]] = None,
    environment: typing.Optional[builtins.str] = None,
    iam_role_arn: typing.Optional[builtins.str] = None,
    iam_role_region: typing.Optional[builtins.str] = None,
    manual_approval: typing.Optional[builtins.bool] = None,
    stacks: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
