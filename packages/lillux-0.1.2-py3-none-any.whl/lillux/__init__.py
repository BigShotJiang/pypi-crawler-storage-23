"""Lillux: Dumb Execution Microkernel.

A stateless, async-first execution engine with clear separation between
execution (Lillux) and orchestration (intelligence).
"""

__version__ = "0.1.0"
