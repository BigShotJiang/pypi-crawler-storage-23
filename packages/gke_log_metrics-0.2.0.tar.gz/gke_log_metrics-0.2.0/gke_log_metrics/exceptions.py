class ValidationError(Exception):
    """Raised when configuration validation fails."""
    pass
