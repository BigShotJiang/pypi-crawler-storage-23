"""
This is Reinforcement Learning for Graph Theory (RLGT), a reinforcement learning framework that
aims to facilitate future research in extremal graph theory.
"""
