# 🔥 0. First Classification Pass (5-Second Scan)

Before thinking about code, classify the problem along 4 axes:

1. **Equality or Inequality?**

   * `= k`
   * `≤ k` / `≥ k`
2. **Negatives allowed?**
3. **Longest / Shortest / Count / Existence?**
4. **Sorted or Unsorted?**

Those four answers narrow it to 1–2 strategies immediately.

---

# 🧠 1. Sliding Window (True Window)

## Trigger Keywords

* “Longest subarray…”
* “At most k…”
* “No more than k distinct…”
* “Replace at most k…”
* “Sum ≤ k” **(only if non-negative numbers)**

## Required Property

The constraint must be **monotonic**:

* Expanding right can only worsen constraint
* Shrinking left improves it

## Pattern

```
expand right
while invalid:
    shrink left
update answer
```

## Red Flag

If numbers can be negative and constraint is sum-based →
**STOP. Not sliding window.**

---

# 🧮 2. Prefix Sum + Hash Map (Equality Class)

## Trigger Keywords

* “Subarray sum equals k”
* “Longest subarray with sum k”
* “Count subarrays with sum k”
* Negatives allowed
* Exact equality

## Recognition Formula

```
prefix[j] - prefix[i] = k
```

## Strategy

Store prefix sums in a map.

| Goal     | What to store    |
| -------- | ---------------- |
| Longest  | First occurrence |
| Count    | Frequency        |
| Shortest | Sometimes latest |

## Mental Shortcut

If you see:

* equality
* unsorted
* negatives allowed

→ Prefix + hashmap.

---

# 📉 3. Prefix Sum + Monotonic Deque (Inequality + Negatives)

## Trigger Keywords

* “Shortest subarray with sum ≥ k”
* “Longest subarray with sum ≤ k”
* Negatives allowed
* Inequality
* Need optimal length

## Recognition Formula

```
prefix[j] - prefix[i] ≤ k
```

Becomes:

```
prefix[i] ≥ prefix[j] - k
```

## Core Insight

You need:

* Earliest valid i
* Efficient pruning of dominated candidates

→ Maintain **monotonic deque of prefix indices**

## Dominance Rule

If:

```
prefix[a] >= prefix[b] and a < b
```

Then `a` is useless.

This same dominance logic appears in:

* Sliding window minimum
* Histogram
* Next smaller/greater
* Convex hull trick (higher tier)

---

# 📦 4. Frequency Window (Generalized Sliding)

## Trigger Keywords

* “At most k times”
* “At most k distinct”
* “At most k replacements”
* “Longest substring with…”

## Invariant

Only the newly added element can violate constraint.

If you ever scan entire dict to check validity → wrong approach.

---

# ↔️ 5. Two Pointers From Ends

## Trigger Keywords

* Sorted array
* Pair sum
* 3Sum
* Remove duplicates
* Container with most water

## Required Property

Monotonic decision based on sorted order.

If array not sorted → usually sort first.

---

# 🔍 6. Binary Search on Answer

## Trigger Keywords

* “Minimize the maximum…”
* “Maximize the minimum…”
* Feels greedy but unclear
* Can check feasibility in O(n)

## Strategy

Binary search on answer.
Feasibility check often uses:

* Prefix sums
* Greedy accumulation
* Sliding window

---

# 📚 7. Monotonic Stack (Next Greater / Smaller)

## Trigger Keywords

* “Next greater”
* “Next smaller”
* “Nearest”
* “First element to left/right”
* Histogram
* “For each element, find …”

## Core Rule

Maintain stack monotonic in value.
Pop while invariant broken.

Same elimination logic as deque, just different direction.

---

# 🔁 8. Kadane / Max Subarray Variant

## Trigger Keywords

* “Maximum subarray”
* “Contiguous”
* “Maximum sum”

If no constraints → Kadane.
If constraints → usually prefix transform first.

---

# 🎯 9. Transform Before Solving

Advanced move.

Many problems are disguised forms of:

* Prefix difference
* Replace value with +1/-1
* Convert condition to sum
* Reduce to known pattern

Example:
“Longest equal 0 and 1”
→ Convert 0 → -1
→ Now “longest subarray with sum 0”
→ Prefix + hashmap.

This transformation skill is what separates strong candidates.

---

# 🧩 The 8-Core Pattern Compression

Honestly, 80% of array interview problems fall into:

1. Sliding window (monotonic constraint)
2. Prefix + hashmap (equality)
3. Prefix + deque (inequality + negatives)
4. Monotonic stack
5. Two pointers (sorted)
6. Binary search on answer
7. Kadane
8. Greedy interval merge

That’s it.

Everything else is flavoring.

---

# ⚡ HRT Calibration Layer

At HRT-level SWE, they probe:

* Can you justify dominance elimination?
* Can you explain why pointer movement is monotonic?
* Can you prove amortized O(n)?
* Do you recognize when sliding window fails?

They don’t care if you memorized LeetCode.
They care if you understand **why** the structure works.

---

# 🚇 Tube Mental Drill

When reading any problem tomorrow, ask instantly:

1. Equality or inequality?
2. Negatives allowed?
3. Longest, shortest, count?
4. Sorted?
5. Can constraint be monotonic?

If you can classify in 5 seconds, you’re operating at senior pattern-recognition speed.

---

If you want, next session we can:

* Build a **one-page printable cheat sheet**
* Or simulate 3 rapid-fire classifications without coding
* Or go deep on dominance proofs (monotonic stack/deque theory)

This is the right direction.
Now you’re thinking like an interviewer, not just a solver.
