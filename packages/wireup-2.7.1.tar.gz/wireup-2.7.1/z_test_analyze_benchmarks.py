#!/usr/bin/env python3

import csv
import json
from pathlib import Path
from collections import defaultdict
import math


class BenchmarkAnalyzer:
    def __init__(self, csv_path="benchmark_results.csv", meta_path="benchmarks/benchmark_meta.json"):
        self.csv_path = Path(csv_path)
        self.meta_path = Path(meta_path)
        self.results = []
        self.metadata = {}
        self._load_data()

    def _load_data(self):
        with open(self.csv_path, "r") as f:
            reader = csv.DictReader(f)
            self.results = list(reader)

        if self.meta_path.exists():
            with open(self.meta_path, "r") as f:
                self.metadata = json.load(f)

    def _parse_float(self, value):
        try:
            return float(value)
        except (ValueError, TypeError):
            return 0.0

    def analyze(self):
        print("=" * 80)
        print("WIREUP FASTAPI BENCHMARK ANALYSIS")
        print("=" * 80)
        print()

        print("BENCHMARK CONFIGURATION:")
        print(f"  Iterations: {self.metadata.get('iterations', 'N/A')}")
        print(f"  Requests per iteration: {self.metadata.get('requests', 'N/A')}")
        print(f"  Concurrency: {self.metadata.get('concurrency', 'N/A')}")
        print(f"  Python version: {self.metadata.get('python_version', 'N/A')}")
        print(f"  Total test configurations: {len(self.results)}")
        print()

        # Group results
        singleton = [r for r in self.results if r["test"] == "singleton"]
        scoped = [r for r in self.results if r["test"] == "scoped"]

        print("=" * 80)
        print("AGGREGATE STATISTICS (ALL ITERATIONS)")
        print("=" * 80)
        print()
        self._analyze_aggregate_stats()

        print()
        print("=" * 80)
        print("DETAILED METRICS BY CONFIGURATION")
        print("=" * 80)
        print()

        for result in sorted(self.results, key=lambda x: (x["test"], x["project"])):
            self._print_single_result(result)
            print()

        print("=" * 80)
        print("SINGLETON MODE ANALYSIS")
        print("=" * 80)
        print()
        self._analyze_group(singleton, "Singleton")

        print()
        print("=" * 80)
        print("SCOPED MODE ANALYSIS")
        print("=" * 80)
        print()
        self._analyze_group(scoped, "Scoped")

        print()
        print("=" * 80)
        print("PERFORMANCE COMPARISON: Singleton vs Scoped")
        print("=" * 80)
        print()
        self._compare_modes()

        print()
        print("=" * 80)
        print("MIDDLEWARE MODE IMPACT ANALYSIS")
        print("=" * 80)
        print()
        self._analyze_middleware_impact()

        print()
        print("=" * 80)
        print("CLASS-BASED VS FUNCTIONAL ANALYSIS")
        print("=" * 80)
        print()
        self._analyze_class_based()

        print()
        print("=" * 80)
        print("WIREUP OVERHEAD COMPARED TO GLOBALS")
        print("=" * 80)
        print()
        self._analyze_overhead()

        print()
        print("=" * 80)
        print("LATENCY DISTRIBUTION ANALYSIS")
        print("=" * 80)
        print()
        self._analyze_latency_distribution()

        print()
        print("=" * 80)
        print("MEMORY EFFICIENCY RANKING")
        print("=" * 80)
        print()
        self._analyze_memory()

        print()
        print("=" * 80)
        print("STABILITY ANALYSIS (Coefficient of Variation)")
        print("=" * 80)
        print()
        self._analyze_stability()

        print()
        print("=" * 80)
        print("COMPREHENSIVE RANKING TABLE")
        print("=" * 80)
        print()
        self._print_ranking_table()

        print()
        print("=" * 80)
        print("KEY INSIGHTS")
        print("=" * 80)
        print()
        self._print_key_insights()

    def _get_percentile(self, values, percentile):
        if not values:
            return 0.0
        sorted_values = sorted(values)
        n = len(sorted_values)
        if n == 1:
            return sorted_values[0]

        # Using linear interpolation for percentiles
        pos = percentile / 100 * (n - 1)
        lower = int(pos)
        upper = lower + 1

        if upper >= n:
            return sorted_values[-1]

        return sorted_values[lower] + (pos - lower) * (sorted_values[upper] - sorted_values[lower])

    def _analyze_aggregate_stats(self):
        print("Statistics calculated across ALL 50 iterations for each configuration:")
        print()

        # Note: Since we only have the median run data in the CSV,
        # we can only report what's available. The CSV contains median run data,
        # not all iteration data.

        print(
            f"{'Project':<40} {'Test':<12} {'RPS':>12} {'P50(ms)':>10} {'P95(ms)':>10} {'P99(ms)':>10} {'StdDev':>10}"
        )
        print("-" * 110)

        for r in sorted(self.results, key=lambda x: (x["test"], x["project"])):
            rps = self._parse_float(r["rps"])
            p50 = self._parse_float(r["p50"])
            p95 = self._parse_float(r["p95"])
            p99 = self._parse_float(r["p99"])
            stdev = self._parse_float(r["stdev"])

            print(
                f"{r['project']:<40} {r['test']:<12} {rps:>12.2f} {p50:>10.2f} {p95:>10.2f} {p99:>10.2f} {stdev:>10.2f}"
            )

        print()
        print("Note: These metrics represent the MEDIAN run from 50 iterations.")
        print("To see p50/p95/p99 across ALL iterations, you would need raw iteration data.")
        print("The current benchmark runner only saves the median run to CSV.")

    def _print_single_result(self, r):
        rps = self._parse_float(r["rps"])
        p50 = self._parse_float(r["p50"])
        p95 = self._parse_float(r["p95"])
        p99 = self._parse_float(r["p99"])
        stdev = self._parse_float(r["stdev"])
        rss = self._parse_float(r["rss_peak"])

        print(f"Project: {r['project']}")
        print(f"  Test Mode: {r['test']}")
        print(f"  Requests/Second: {rps:.2f} (MEDIAN RUN)")
        print(f"  Latency P50 (Median): {p50:.2f} ms")
        print(f"  Latency P95: {p95:.2f} ms")
        print(f"  Latency P99: {p99:.2f} ms")
        print(f"  Standard Deviation: {stdev:.2f} ms")
        print(f"  Peak RSS (Memory): {rss:.2f} MB")
        print(f"  Average Request Duration: {(1000 / rps):.2f} ms")
        print(f"  Coefficient of Variation: {(stdev / p50) * 100:.2f}%")

        # Calculate throughput efficiency
        baseline_rps = self._get_baseline_rps(r["test"])
        if baseline_rps:
            efficiency = (rps / baseline_rps) * 100
            print(f"  Throughput Efficiency vs Baseline: {efficiency:.2f}%")

    def _analyze_group(self, results, title):
        if not results:
            print(f"No results for {title}")
            return

        sorted_results = sorted(results, key=lambda x: self._parse_float(x["rps"]), reverse=True)

        print(f"Top Performers by RPS ({title}):")
        print()
        print(f"{'Rank':<6} {'Project':<40} {'RPS':>12} {'P50(ms)':>10} {'P95(ms)':>10} {'RSS(MB)':>10} {'Score':>8}")
        print("-" * 100)

        for i, r in enumerate(sorted_results, 1):
            rps = self._parse_float(r["rps"])
            p50 = self._parse_float(r["p50"])
            p95 = self._parse_float(r["p95"])
            rss = self._parse_float(r["rss_peak"])

            # Calculate composite score (higher is better)
            # Score = (RPS / max_RPS * 50) + (min_p50 / p50 * 30) + (min_rss / rss * 20)
            max_rps = max([self._parse_float(x["rps"]) for x in results])
            min_p50 = min([self._parse_float(x["p50"]) for x in results])
            min_rss = min([self._parse_float(x["rss_peak"]) for x in results])

            score = (rps / max_rps * 50) + (min_p50 / p50 * 30) + (min_rss / rss * 20)

            print(f"{i:<6} {r['project']:<40} {rps:>12.2f} {p50:>10.2f} {p95:>10.2f} {rss:>10.2f} {score:>7.2f}")

        # Statistics
        rps_values = [self._parse_float(r["rps"]) for r in results]
        p50_values = [self._parse_float(r["p50"]) for r in results]

        print()
        print(f"Statistics for {title}:")
        print(f"  Average RPS: {sum(rps_values) / len(rps_values):.2f}")
        print(f"  RPS Range: {min(rps_values):.2f} - {max(rps_values):.2f}")
        print(f"  RPS Std Dev: {self._calc_stddev(rps_values):.2f}")
        print(f"  Average P50 Latency: {sum(p50_values) / len(p50_values):.2f} ms")
        print(f"  P50 Latency Range: {min(p50_values):.2f} - {max(p50_values):.2f} ms")
        print(f"  Performance Gap (Max/Min RPS): {(max(rps_values) / min(rps_values)) * 100:.2f}%")

    def _compare_modes(self):
        print("Impact of Scoped vs Singleton Injection:")
        print()
        print(f"{'Project':<40} {'Singleton RPS':>15} {'Scoped RPS':>15} {'Diff (%)':>12} {'P50 Diff (ms)':>15}")
        print("-" * 100)

        projects = set(r["project"] for r in self.results)

        for project in sorted(projects):
            singleton_r = next((r for r in self.results if r["project"] == project and r["test"] == "singleton"), None)
            scoped_r = next((r for r in self.results if r["project"] == project and r["test"] == "scoped"), None)

            if singleton_r and scoped_r:
                s_rps = self._parse_float(singleton_r["rps"])
                sc_rps = self._parse_float(scoped_r["rps"])
                s_p50 = self._parse_float(singleton_r["p50"])
                sc_p50 = self._parse_float(scoped_r["p50"])

                diff_pct = ((sc_rps - s_rps) / s_rps) * 100
                p50_diff = sc_p50 - s_p50

                print(f"{project:<40} {s_rps:>15.2f} {sc_rps:>15.2f} {diff_pct:>11.2f}% {p50_diff:>15.2f}")

        print()
        print("Key Findings:")
        print("  Scoped injection requires recreating the dependency graph per request")
        print("  This typically results in 15-30% lower throughput and higher latency")

    def _analyze_middleware_impact(self):
        print("Impact of Middleware Mode:")
        print()

        wireup_reg = next((r for r in self.results if r["project"] == "Wireup"), None)
        wireup_mm = next((r for r in self.results if r["project"] == "Wireup Middleware Mode"), None)

        if wireup_reg and wireup_mm:
            print(f"{'Metric':<20} {'Regular':>15} {'Middleware':>15} {'Impact':>15}")
            print("-" * 65)

            for metric in ["rps", "p50", "p95", "p99", "rss_peak"]:
                reg_val = self._parse_float(wireup_reg[metric])
                mm_val = self._parse_float(wireup_mm[metric])

                if metric in ["rps"]:
                    impact = ((mm_val - reg_val) / reg_val) * 100
                    print(f"{metric.upper():<20} {reg_val:>15.2f} {mm_val:>15.2f} {impact:>14.2f}%")
                else:
                    impact = ((mm_val - reg_val) / reg_val) * 100
                    print(f"{metric.upper():<20} {reg_val:>15.2f} {mm_val:>15.2f} {impact:>14.2f}%")

        print()
        # Class-based comparison
        wireup_cbr = next((r for r in self.results if r["project"] == "Wireup (Class-Based)"), None)
        wireup_cbr_mm = next((r for r in self.results if r["project"] == "Wireup (Class-Based) Middleware Mode"), None)

        if wireup_cbr and wireup_cbr_mm:
            print("Class-Based - Middleware Mode Impact:")
            print(f"{'Metric':<20} {'Regular':>15} {'Middleware':>15} {'Impact':>15}")
            print("-" * 65)

            for metric in ["rps", "p50", "p95", "p99", "rss_peak"]:
                reg_val = self._parse_float(wireup_cbr[metric])
                mm_val = self._parse_float(wireup_cbr_mm[metric])

                if metric in ["rps"]:
                    impact = ((mm_val - reg_val) / reg_val) * 100
                    print(f"{metric.upper():<20} {reg_val:>15.2f} {mm_val:>15.2f} {impact:>14.2f}%")
                else:
                    impact = ((mm_val - reg_val) / reg_val) * 100
                    print(f"{metric.upper():<20} {reg_val:>15.2f} {mm_val:>15.2f} {impact:>14.2f}%")

    def _analyze_class_based(self):
        print("Class-Based vs Functional Approach:")
        print()

        configs = [
            ("Wireup", "Wireup (Class-Based)"),
            ("Wireup Middleware Mode", "Wireup (Class-Based) Middleware Mode"),
        ]

        for reg, cb in configs:
            reg_r = next((r for r in self.results if r["project"] == reg), None)
            cb_r = next((r for r in self.results if r["project"] == cb), None)

            if reg_r and cb_r:
                print(f"{reg} vs {cb}:")
                print(f"{'Metric':<20} {'Functional':>15} {'Class-Based':>15} {'Difference':>15}")
                print("-" * 65)

                for metric in ["rps", "p50", "p95", "p99"]:
                    reg_val = self._parse_float(reg_r[metric])
                    cb_val = self._parse_float(cb_r[metric])
                    diff = cb_val - reg_val

                    if metric in ["rps"]:
                        diff_pct = ((cb_val - reg_val) / reg_val) * 100
                        print(f"{metric.upper():<20} {reg_val:>15.2f} {cb_val:>15.2f} {diff_pct:>14.2f}%")
                    else:
                        diff_pct = ((cb_val - reg_val) / reg_val) * 100
                        print(f"{metric.upper():<20} {reg_val:>15.2f} {cb_val:>15.2f} {diff_pct:>14.2f}%")
                print()

    def _analyze_overhead(self):
        print("Wireup Overhead Compared to Global Variables:")
        print()
        print("Global variables represent the theoretical maximum performance")
        print("(no dependency injection overhead)")
        print()

        baseline_singleton = next(
            (r for r in self.results if r["project"] == "Globals" and r["test"] == "singleton"), None
        )
        baseline_scoped = next((r for r in self.results if r["project"] == "Globals" and r["test"] == "scoped"), None)

        if baseline_singleton:
            print(f"{'Project':<40} {'RPS':>12} {'vs Baseline':>15} {'Overhead':>15}")
            print("-" * 82)

            base_rps = self._parse_float(baseline_singleton["rps"])

            wireup_results = [r for r in self.results if r["test"] == "singleton" and "Wireup" in r["project"]]

            for r in sorted(wireup_results, key=lambda x: self._parse_float(x["rps"]), reverse=True):
                rps = self._parse_float(r["rps"])
                vs_baseline = (rps / base_rps) * 100
                overhead = 100 - vs_baseline

                print(f"{r['project']:<40} {rps:>12.2f} {vs_baseline:>14.2f}% {overhead:>14.2f}%")

        if baseline_scoped:
            print()
            print("Scoped Mode Overhead:")
            print(f"{'Project':<40} {'RPS':>12} {'vs Baseline':>15} {'Overhead':>15}")
            print("-" * 82)

            base_rps = self._parse_float(baseline_scoped["rps"])

            wireup_results = [r for r in self.results if r["test"] == "scoped" and "Wireup" in r["project"]]

            for r in sorted(wireup_results, key=lambda x: self._parse_float(x["rps"]), reverse=True):
                rps = self._parse_float(r["rps"])
                vs_baseline = (rps / base_rps) * 100
                overhead = 100 - vs_baseline

                print(f"{r['project']:<40} {rps:>12.2f} {vs_baseline:>14.2f}% {overhead:>14.2f}%")

    def _analyze_latency_distribution(self):
        print("Latency Spread Analysis (P99 - P50):")
        print()
        print("Lower spread indicates more predictable performance")
        print()

        print(f"{'Project':<40} {'Test':<12} {'P50':>10} {'P95':>10} {'P99':>10} {'P99-P50':>12} {'Spread %':>10}")
        print("-" * 108)

        for r in sorted(self.results, key=lambda x: (x["test"], x["project"])):
            p50 = self._parse_float(r["p50"])
            p95 = self._parse_float(r["p95"])
            p99 = self._parse_float(r["p99"])
            spread = p99 - p50
            spread_pct = (spread / p50) * 100 if p50 > 0 else 0

            print(
                f"{r['project']:<40} {r['test']:<12} {p50:>10.2f} {p95:>10.2f} {p99:>10.2f} {spread:>12.2f} {spread_pct:>9.2f}%"
            )

    def _analyze_memory(self):
        print("Memory Usage Ranking (Lower is Better):")
        print()

        sorted_results = sorted(self.results, key=lambda x: self._parse_float(x["rss_peak"]))

        print(f"{'Rank':<6} {'Project':<40} {'Test':<12} {'RSS Peak (MB)':>15}")
        print("-" * 73)

        for i, r in enumerate(sorted_results, 1):
            rss = self._parse_float(r["rss_peak"])
            print(f"{i:<6} {r['project']:<40} {r['test']:<12} {rss:>15.2f}")

        print()
        # Memory statistics
        rss_values = [self._parse_float(r["rss_peak"]) for r in self.results]
        print(f"Memory Statistics:")
        print(f"  Min: {min(rss_values):.2f} MB")
        print(f"  Max: {max(rss_values):.2f} MB")
        print(f"  Average: {sum(rss_values) / len(rss_values):.2f} MB")
        print(f"  Range: {max(rss_values) - min(rss_values):.2f} MB")

    def _analyze_stability(self):
        print("Coefficient of Variation (CV) Analysis:")
        print("CV = (Standard Deviation / Mean) * 100")
        print("Lower CV indicates more stable performance")
        print()

        print(f"{'Project':<40} {'Test':<12} {'P50 (ms)':>12} {'StdDev':>12} {'CV (%)':>10}")
        print("-" * 78)

        for r in sorted(self.results, key=lambda x: (x["test"], x["project"])):
            p50 = self._parse_float(r["p50"])
            stdev = self._parse_float(r["stdev"])
            cv = (stdev / p50) * 100 if p50 > 0 else 0

            print(f"{r['project']:<40} {r['test']:<12} {p50:>12.2f} {stdev:>12.2f} {cv:>9.2f}%")

    def _print_ranking_table(self):
        print("Overall Performance Ranking (Composite Score):")
        print("Score = RPS (50%) + Latency (30%) + Memory (20%)")
        print()

        # Calculate scores
        scored_results = []
        singleton_results = [r for r in self.results if r["test"] == "singleton"]
        scoped_results = [r for r in self.results if r["test"] == "scoped"]

        for test_type, results in [("Singleton", singleton_results), ("Scoped", scoped_results)]:
            if not results:
                continue

            max_rps = max([self._parse_float(r["rps"]) for r in results])
            min_p50 = min([self._parse_float(r["p50"]) for r in results])
            min_rss = min([self._parse_float(r["rss_peak"]) for r in results])

            for r in results:
                rps = self._parse_float(r["rps"])
                p50 = self._parse_float(r["p50"])
                rss = self._parse_float(r["rss_peak"])

                score = (rps / max_rps * 50) + (min_p50 / p50 * 30) + (min_rss / rss * 20)

                scored_results.append(
                    {"project": r["project"], "test": r["test"], "score": score, "rps": rps, "p50": p50, "rss": rss}
                )

        # Sort by test type and score
        scored_results.sort(key=lambda x: (x["test"], -x["score"]))

        # Print by test type
        for test_type in ["Singleton", "Scoped"]:
            test_results = [r for r in scored_results if r["test"] == test_type]
            if not test_results:
                continue

            print(f"{test_type} Mode:")
            print(f"{'Rank':<6} {'Project':<40} {'Score':>8} {'RPS':>12} {'P50(ms)':>10} {'RSS(MB)':>10}")
            print("-" * 88)

            for i, r in enumerate(test_results, 1):
                print(
                    f"{i:<6} {r['project']:<40} {r['score']:>7.2f} {r['rps']:>12.2f} {r['p50']:>10.2f} {r['rss']:>10.2f}"
                )
            print()

    def _print_key_insights(self):
        # Find best performers
        best_singleton_rps = max(
            [r for r in self.results if r["test"] == "singleton"], key=lambda x: self._parse_float(x["rps"])
        )
        best_scoped_rps = max(
            [r for r in self.results if r["test"] == "scoped"], key=lambda x: self._parse_float(x["rps"])
        )

        best_latency = min(self.results, key=lambda x: self._parse_float(x["p50"]))
        lowest_memory = min(self.results, key=lambda x: self._parse_float(x["rss_peak"]))

        print("🏆 BEST OVERALL PERFORMERS:")
        print(
            f"  Singleton RPS: {best_singleton_rps['project']} ({self._parse_float(best_singleton_rps['rps']):.2f} req/s)"
        )
        print(f"  Scoped RPS: {best_scoped_rps['project']} ({self._parse_float(best_scoped_rps['rps']):.2f} req/s)")
        print(
            f"  Lowest Latency: {best_latency['project']} ({best_latency['test']}) ({self._parse_float(best_latency['p50']):.2f} ms)"
        )
        print(
            f"  Lowest Memory: {lowest_memory['project']} ({lowest_memory['test']}) ({self._parse_float(lowest_memory['rss_peak']):.2f} MB)"
        )
        print()

        # Calculate overhead
        baseline_singleton = next(
            (r for r in self.results if r["project"] == "Globals" and r["test"] == "singleton"), None
        )
        if baseline_singleton:
            base_rps = self._parse_float(baseline_singleton["rps"])
            wireup_best_rps = self._parse_float(best_singleton_rps["rps"])
            overhead = 100 - (wireup_best_rps / base_rps * 100)
            print(f"📊 WIREUP OVERHEAD:")
            print(f"  Best Wireup configuration has {overhead:.2f}% overhead vs global variables")
            print(f"  This is typical for DI frameworks and represents the cost of flexibility")
            print()

        # Compare modes
        print(f"🔄 SINGLETON vs SCOPED:")
        if best_singleton_rps and best_scoped_rps:
            s_rps = self._parse_float(best_singleton_rps["rps"])
            sc_rps = self._parse_float(best_scoped_rps["rps"])
            diff = ((sc_rps - s_rps) / s_rps) * 100
            print(f"  Singleton mode is {abs(diff):.2f}% {'faster' if s_rps > sc_rps else 'slower'} than scoped mode")
            print(f"  Use singleton for high-throughput, read-heavy scenarios")
            print(f"  Use scoped for request-scoped dependencies or complex lifecycles")
            print()

        # Middleware impact
        wireup_reg = next((r for r in self.results if r["project"] == "Wireup" and r["test"] == "singleton"), None)
        wireup_mm = next(
            (r for r in self.results if r["project"] == "Wireup Middleware Mode" and r["test"] == "singleton"), None
        )

        if wireup_reg and wireup_mm:
            reg_rps = self._parse_float(wireup_reg["rps"])
            mm_rps = self._parse_float(wireup_mm["rps"])
            diff = ((mm_rps - reg_rps) / reg_rps) * 100
            print(f"🔧 MIDDLEWARE MODE IMPACT:")
            print(f"  Middleware mode has {abs(diff):.2f}% {'higher' if mm_rps > reg_rps else 'lower'} throughput")
            print(f"  Consider using middleware mode for cleaner integration with FastAPI")
            print()

        print("💡 RECOMMENDATIONS:")
        print(f"  1. For maximum performance: Use Singleton mode with globals or Wireup")
        print(f"  2. For clean architecture: Use Wireup (Class-Based) in Singleton mode")
        print(f"  3. For request-scoped deps: Accept ~15-25% performance penalty of Scoped mode")
        print(f"  4. For FastAPI integration: Middleware mode offers good balance")
        print(f"  5. The overhead of Wireup is minimal compared to the benefits it provides")

    def _get_baseline_rps(self, test_type):
        baseline = next((r for r in self.results if r["project"] == "Globals" and r["test"] == test_type), None)
        if baseline:
            return self._parse_float(baseline["rps"])
        return None

    def _calc_stddev(self, values):
        if len(values) < 2:
            return 0.0
        mean = sum(values) / len(values)
        variance = sum((x - mean) ** 2 for x in values) / (len(values) - 1)
        return math.sqrt(variance)


if __name__ == "__main__":
    analyzer = BenchmarkAnalyzer()
    analyzer.analyze()
