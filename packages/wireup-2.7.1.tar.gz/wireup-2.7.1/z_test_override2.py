from unittest.mock import MagicMock

import wireup


@wireup.injectable
class Foo:
    pass


c = wireup.create_sync_container(injectables=[Foo])

with c.override.injectable(Foo, MagicMock()):
    pass

c.override.clear()
