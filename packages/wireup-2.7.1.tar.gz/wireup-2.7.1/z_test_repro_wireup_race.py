import asyncio
import uuid
import uvicorn
from fastapi import FastAPI, Request
from httpx import AsyncClient
import wireup
from wireup import injectable, Injected, Inject, AsyncContainer
import wireup.integration.fastapi
from wireup.integration.fastapi import get_request_container
from typing import Annotated

app = FastAPI()

# --- Counters ---
singleton_init_calls = 0
scoped_init_calls = 0

class SingletonInstance:
    def __init__(self):
        self.id = uuid.uuid4()

class ScopedInstance:
    def __init__(self):
        self.id = uuid.uuid4()

@injectable(lifetime="singleton")
async def singleton_factory() -> SingletonInstance:
    global singleton_init_calls
    singleton_init_calls += 1
    await asyncio.sleep(0.1)
    return SingletonInstance()

@injectable(lifetime="scoped")
async def scoped_factory() -> ScopedInstance:
    global scoped_init_calls
    scoped_init_calls += 1
    await asyncio.sleep(0.1)
    return ScopedInstance()

@injectable(lifetime="scoped")
class ScopedConsumer:
    def __init__(
        self, 
        s1: Injected[ScopedInstance],
        s2: Injected[ScopedInstance]
    ):
        self.s1 = s1
        self.s2 = s2

@app.get("/singleton")
async def singleton_endpoint(service: Injected[SingletonInstance]):
    return {"id": str(service.id)}

@app.get("/scoped_standard")
async def scoped_standard_endpoint(consumer: Injected[ScopedConsumer]):
    """Standard injection: Sequential resolution, no race."""
    return {
        "id1": str(consumer.s1.id), 
        "id2": str(consumer.s2.id), 
        "match": consumer.s1.id == consumer.s2.id
    }

@app.get("/scoped_race")
async def scoped_manual_race_endpoint(request: Request, _: Injected[SingletonInstance]):
    """Manual Concurrent Access: Should RACE now that locks are removed."""
    container = get_request_container()
    # Concurrent resolution in the SAME scope
    res = await asyncio.gather(container.get(ScopedInstance), container.get(ScopedInstance))
    s1, s2 = res
    return {
        "id1": str(s1.id), 
        "id2": str(s2.id), 
        "match": s1.id == s2.id
    }

@app.get("/counters")
async def get_counters():
    return {"singleton_calls": singleton_init_calls, "scoped_calls": scoped_init_calls}

# Initialize Wireup
container = wireup.create_async_container(
    injectables=[singleton_factory, scoped_factory, ScopedConsumer]
)
wireup.integration.fastapi.setup(container, app)

def get_free_port():
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]

async def run_repro():
    port = get_free_port()
    config = uvicorn.Config(app, port=port, log_level="error")
    server = uvicorn.Server(config)
    loop = asyncio.get_event_loop()
    server_task = loop.create_task(server.serve())
    
    await asyncio.sleep(1)
    
    async with AsyncClient(base_url=f"http://127.0.0.1:{port}") as client:
        print("\n--- Testing Wireup Scoped STANDARD (Sequential) ---")
        resp = await client.get("/scoped_standard")
        print(f"Match: {resp.json()['match']}")

        print("\n--- Testing Wireup Scoped MANUAL RACE (Concurrent) ---")
        resp = await client.get("/scoped_race")
        data = resp.json()
        print(f"Match: {data['match']} (id1: {data['id1'][:8]}, id2: {data['id2'][:8]})")

        if not data['match']:
            print("\nRESULT: Scoped Dependency RACED in a FastAPI context! (Manual concurrent access)")
        else:
            print("\nRESULT: Scoped Dependency still matched (maybe race was too tight or sleep too short)")

    server.should_exit = True
    await server_task

if __name__ == "__main__":
    asyncio.run(run_repro())
