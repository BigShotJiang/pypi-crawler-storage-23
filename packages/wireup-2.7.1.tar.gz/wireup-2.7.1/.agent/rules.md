# Agent Rules

1. **Stdout/Stderr Redirection**: The `run_command` tool has a bug where it cannot reliably capture stdout/stderr directly. YOU MUST ALWAYS redirect output to a file (e.g., `cmd > output.txt 2>&1`) and then read that file using `view_file` or `read_resource` to inspect the output. Never rely on the `output` field of `run_command` or `command_status`.
