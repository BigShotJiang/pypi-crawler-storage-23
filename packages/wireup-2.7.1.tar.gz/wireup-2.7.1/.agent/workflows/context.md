# Wireup - Dependency Injection Framework for Python

Wireup is a type-safe dependency injection framework for Python 3.8+ with async support and framework integrations.

## Core Architecture

Wireup follows a container-based DI pattern with three main components:

- **Container**: Central registry that resolves dependencies (`create_sync_container`/`create_async_container`)
- **Injectables**: Classes/functions marked with `@injectable` decorator 
- **Configuration**: Configuration values injected via `config`

Key modules:
- `wireup/ioc/` - Core container and service registry implementation
- `wireup/integration/` - Framework integrations (FastAPI, Django, Flask, etc.)
- `wireup/_annotations.py` - Core decorators (`@injectable`, `@abstract`, `Inject`, `Injected`)

## Development Workflows

### Testing
- Use `make test` for unit tests (runs `pytest test/unit`)
- Tests use parameterized containers (both sync/async) via `conftest.py`
- Test services are in `test/unit/services/` with clear module structure
- Override services in tests using `container.override.service(target=Original, new=mock)`
- Integration tests are in `test/integration/` for framework-specific testing

### Linting & Type Checking
- `make lint` - Runs formatting, ruff, and mypy checks
- `make format` - Auto-format code with ruff
- Strict mypy compliance required (`mypy wireup --strict`)
- Ruff configured for Python 3.8+ with comprehensive rule set
- Note: `tool.mypy` excludes `wireup.integration` directory

### Building & Documentation
- Poetry-based project (`poetry install`, `poetry build`)
- Documentation via MkDocs Material (`make docs-deploy version=X.Y.Z`)
- Use `z_test_*.py` files for experimentation and examples
- Profile performance with `make profile ./profile_tests <num_runs>`

## Key Patterns

### Injectable Registration
```python
@injectable  # Singleton by default
class Database: ...

@injectable(lifetime="scoped")  # Per-request/scope
class RequestContext: ...

@injectable(lifetime="transient")  # Always new instance
class OrderProcessor: ...
```

### Interface-Implementation Binding
```python
@abstract
class Cache: ...

@injectable(qualifier="redis")
class RedisCache(Cache): ...

# Inject specific implementation
def handler(cache: Annotated[Cache, Inject(qualifier="redis")]): ...
```

### Factory Functions with Cleanup
```python
@injectable
def database_factory() -> Iterator[Database]:
    db = Database()
    try:
        yield db
    finally:
        db.close()
```

### Function Injection
```python
@inject_from_container(container)
def process_data(service: Injected[UserService]):
    # UserService automatically injected
    pass
```

### Configuration Injection
```python
@injectable
class Database:
    def __init__(self, db_url: Annotated[str, Inject(config="db_url")]) -> None:
        self.db_url = db_url

# Templated string configuration
@injectable  
class Logger:
    def __init__(self, prefix: Annotated[str, Inject(expr="app-${env_name}")]) -> None:
        self.prefix = prefix
```

## Framework Integration Notes

- Integrations are in `wireup/integration/` with separate files per framework
- Setup pattern: `wireup.integration.{framework}.setup(container, app)`
- FastAPI integration auto-wraps `Inject()` with `Depends()` for compatibility
- All integrations validate dependencies at startup, not runtime

## Error Handling & Validation

Wireup validates dependencies early to catch configuration errors:

```python
# Container creation fails with clear error messages
@injectable
class Foo:
    def __init__(self, unknown: NotManagedByWireup) -> None:
        pass

container = wireup.create_sync_container(service_modules=[Foo])
# ❌ Parameter 'unknown' of 'Foo' depends on an unknown injectable 'NotManagedByWireup'
```

Common error types:
- `UnknownServiceRequestedError` - Missing injectable registration
- `DuplicateServiceRegistrationError` - Same injectable registered twice
- `DuplicateQualifierForInterfaceError` - Qualifier conflicts

## Testing Conventions

- Use `Container = Union[SyncContainer, AsyncContainer]` type hint for parameterized tests
- Service modules for tests use clear hierarchical imports
- Test both sync and async containers with same test logic via fixtures
- Mock external dependencies using container overrides, not monkey patching

## Container Usage Patterns

### Service Discovery
```python
# Auto-discover injectables from modules
container = wireup.create_sync_container(service_modules=[services])

# Explicit injectable registration
container = wireup.create_sync_container(service_modules=[Database, UserService])
```

### Scoped Containers
Use scoped containers for request-scoped injectables:
```python
with container.request_scope() as scoped:
    # All scoped services share same instance within this block
    service = scoped.get(RequestScopedService)
```

## File Organization

- `z_test_*.py` - Experimental/example files (not actual tests)
- `test/unit/` - Unit tests with services in subfolders
- `test/integration/` - Integration tests
- `wireup/ioc/` - Core DI implementation
- `docs/pages/` - MkDocs documentation source
