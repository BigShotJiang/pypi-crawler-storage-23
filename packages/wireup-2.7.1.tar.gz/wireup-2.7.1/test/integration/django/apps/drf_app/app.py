from django.apps import AppConfig


class DrfApp(AppConfig):
    name = "drf_app"
