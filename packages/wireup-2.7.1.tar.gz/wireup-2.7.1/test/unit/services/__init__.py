from test.unit.services.abstract_multiple_bases import FooBase, FooBaseAnother

__all__ = ["FooBase", "FooBaseAnother"]
