import asyncio
import time
from typing import AsyncIterator, Iterator, Literal

from wireup import Injected, create_async_container, injectable
from wireup._decorators import inject_from_container


class H: ...


async def make_h() -> AsyncIterator[H]:
    yield H()


class G:
    def __init__(self, h: H) -> None:
        self.h = h


class F:
    def __init__(self, g: G):
        self.g = g


class E:
    def __init__(self, f: F):
        self.f = f


class D:
    def __init__(self, e: E, g: G):
        self.e = e


class C:
    def __init__(self, d: D, g: G):
        self.d = d


class B:
    def __init__(self, c: C):
        self.c = c


class A:
    def __init__(self, b: B):
        self.b = b


def empty_middleware(
    scoped_container,  # noqa: ARG001
    *args,  # noqa: ARG001
    **kwargs,  # noqa: ARG001
) -> Iterator[None]:
    yield


async def run_bench():
    classes = [make_h, G, F, E, D, C, B, A]
    iterations = 20_000
    lifetimes: list[Literal["singleton", "scoped"]] = ["singleton", "scoped"]
    middleware_options = [None, empty_middleware]

    results = {}

    for lifetime in lifetimes:
        for middleware in middleware_options:
            middleware_name = "middleware" if middleware else "no_middleware"
            print(f"\n{'=' * 50}")
            print(f"LIFETIME: {lifetime.upper()} | {middleware_name.upper().replace('_', ' ')}")
            print("=" * 50)

            # Test 1: Raw await container.get
            print("=== Test 1: Raw await container.get ===")
            container = create_async_container(injectables=[injectable(c, lifetime=lifetime) for c in classes])

            if lifetime == "scoped":
                start = time.time()
                async with container.enter_scope() as scope:
                    for _ in range(iterations):
                        await scope.get(A)
                end = time.time()
            else:
                await container.get(A)
                start = time.time()
                for _ in range(iterations):
                    await container.get(A)
                end = time.time()

            raw_ops = iterations / (end - start)
            print(f"Ops/sec: {raw_ops:.2f}")

            # Test 2: inject_from_container decorator
            print("\n=== Test 2: @inject_from_container ===")
            container2 = create_async_container(injectables=[injectable(c, lifetime=lifetime) for c in classes])

            @inject_from_container(container=container2, _middleware=middleware)
            async def target(a: Injected[A]) -> A:
                return a

            start = time.time()
            for _ in range(iterations):
                await target()
            end = time.time()
            decorator_ops = iterations / (end - start)
            print(f"Ops/sec: {decorator_ops:.2f}")

            results[(lifetime, middleware_name)] = {"raw_ops": raw_ops, "decorator_ops": decorator_ops}

    # Summary
    print("\n" + "=" * 50)
    print("SUMMARY")
    print("=" * 50)
    for (lifetime, middleware_name), data in results.items():
        print(f"\n{lifetime.upper()} | {middleware_name.upper().replace('_', ' ')}:")
        print(f"  Raw await container.get: {data['raw_ops']:.2f} ops/sec")
        print(f"  @inject_from_container: {data['decorator_ops']:.2f} ops/sec")
        print(f"  Decorator overhead: {(data['raw_ops'] / data['decorator_ops'] - 1) * 100:.1f}%")


if __name__ == "__main__":
    asyncio.run(run_bench())
