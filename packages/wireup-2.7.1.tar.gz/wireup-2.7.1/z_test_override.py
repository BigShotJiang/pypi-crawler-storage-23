from unittest.mock import MagicMock

import wireup


class Foo:
    pass


@wireup.injectable
async def async_foo_factory() -> Foo:
    return Foo()


container = wireup.create_sync_container(injectables=[async_foo_factory])

outer = MagicMock(spec=Foo)
inner = MagicMock(spec=Foo)

with container.override.injectable(Foo, new=outer):
    assert container.get(Foo) is outer

    with container.override.injectable(Foo, new=inner):
        assert container.get(Foo) is inner

    # BUG (current reverted state):
    # expected outer, actual WireupError
    assert container.get(Foo) is outer
