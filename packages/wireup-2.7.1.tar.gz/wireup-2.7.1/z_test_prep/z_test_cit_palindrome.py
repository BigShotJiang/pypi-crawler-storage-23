"""
You are given a string s. Your task is to find all palindromic substrings in it.
If there are multiple palindromic substrings of the same length, sort them according to:

    Length in descending order;
    If equal length, lexicographical order.

"""

from __future__ import annotations


def all_palindromes(s: str) -> list[str]:
    res: list[str] = []

    for i in range(len(s)):
        pass

    return sorted(res, key=lambda item: (len(item), item))


print(all_palindromes("abbaacca"))
