# Given an array of integers, return the length of the longest subarray where each value appears at most twice.

# Example:
from __future__ import annotations

from collections import defaultdict

nums = [1, 2, 1, 1, 2, 3, 3, 3]
# longest valid subarray is [1, 2, 1, 2, 3, 3]
# answer = 6


def longest_distinct_subarray(nums: list[int]) -> int:
    counts: dict[int, int] = defaultdict(int)
    left = 0
    best = 0

    for right, val in enumerate(nums):
        counts[val] += 1

        while counts[val] > 2:
            counts[nums[left]] -= 1
            left += 1

        best = max(best, right - left + 1)

    return best


print(longest_distinct_subarray(nums))
