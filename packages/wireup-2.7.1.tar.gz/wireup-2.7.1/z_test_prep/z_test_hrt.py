# Given an array of integers, return the length of the longest subarray with all distinct values.
# [1, 2, 3, 3, 4, 5, 1, 6, 4, 3, 2]
from __future__ import annotations


def longest_distinct_subarray(nums: list[int]) -> int:
    best = 0
    left = 0
    current_nums: dict[int, int] = {}

    for right, val in enumerate(nums):
        if val in current_nums:
            start_j = left
            left = current_nums[val] + 1

            for j in range(start_j, current_nums[val] + 1):
                del current_nums[nums[j]]

        current_nums[val] = right
        best = max(best, len(current_nums))

    return best


print(longest_distinct_subarray([1, 2, 3, 3, 3, 4, 5, 1, 6, 4, 3, 2]))
print(longest_distinct_subarray([1, 2, 3, 1, 4]))
