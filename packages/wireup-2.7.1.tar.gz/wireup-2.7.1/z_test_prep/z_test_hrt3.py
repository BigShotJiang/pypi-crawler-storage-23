# Given an array of integers (can include negatives) and an integer k, return the length of the longest subarray whose sum is exactly k.

# Example:


nums = [-3, 1, -1, 6, 5, -6, -2, 3, 5, 15]
k = 3
# Longest is [1, -1, 5, -2] -> sum = 3
# answer = 4


def longest_subarray_sum_exact(nums: list[int], target_sum: int) -> int:
    acc = 0
    first_seen_at = {0: -1}
    best = 0

    for index, num in enumerate(nums):
        acc += num
        if acc not in first_seen_at:
            first_seen_at[acc] = index

        delta = acc - target_sum

        if delta in first_seen_at:
            best = max(best, index - first_seen_at[delta])

    return best


print(longest_subarray_sum_exact(nums, target_sum=3))
print(longest_subarray_sum_exact([1, -1, 5, -2, 3], target_sum=3))
