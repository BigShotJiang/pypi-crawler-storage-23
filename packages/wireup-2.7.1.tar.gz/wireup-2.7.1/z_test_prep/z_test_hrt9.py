# nums = [100, 4, 200, 1, 3, 2]
# longest consecutive sequence is [1,2,3,4]
# answer = 4


from collections import defaultdict


class UnionFind:
    def __init__(self) -> None:
        self.parent: dict[int, int] = {}

    def union(self, x: int, y: int) -> None:
        self.parent[self.find(x)] = self.find(y)

    def find(self, x: int) -> int:
        while x in self.parent:
            x = self.parent[x]

        return x


def longest_consecutive_uf(nums: list[int]) -> int:
    uf = UnionFind()
    seen: set[int] = set()

    for num in nums:
        if num - 1 in seen:
            uf.union(num, num - 1)
        if num + 1 in seen:
            uf.union(num, num + 1)

        seen.add(num)

    freq: dict[int, int] = defaultdict(int)

    for num in nums:
        freq[uf.find(num)] += 1

    print(uf.parent)

    return max(freq.values())


def longest_consecutive2(nums: list[int]) -> int:
    num_depth = defaultdict(int)

    for num in set(nums):
        num_depth[num] = num_depth[num - 1] + 1 + num_depth[num + 1]

    return max(num_depth.values())


def longest_consecutive(nums: list[int]) -> int:
    best = float("-inf")
    nums = set(nums)

    for num in nums:
        if num - 1 not in nums:
            current = 1
            x = num
            while x + 1 in nums:
                current += 1
                x = x + 1

            best = max(best, current)

    return best


print(longest_consecutive([100, 4, 200, 1, 3, 2]))
