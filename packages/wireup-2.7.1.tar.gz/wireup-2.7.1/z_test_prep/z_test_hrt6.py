# Given an integer array nums and an integer k,
# return the length of the longest subarray that contains exactly k odd numbers.


def longest_subarray_k_odds(nums: list[int], k: int) -> int:
    best = 0
    left = 0
    num_odds = 0

    for right, num in enumerate(nums):
        if num % 2 == 1:
            num_odds += 1

        while num_odds > k:
            if nums[left] % 2 == 1:
                num_odds -= 1

            left += 1

        if num_odds == k:
            best = max(best, right - left + 1)

    return best


nums = [2, 1, 2, 2, 1, 2]
k = 2
print(longest_subarray_k_odds(nums, k))
