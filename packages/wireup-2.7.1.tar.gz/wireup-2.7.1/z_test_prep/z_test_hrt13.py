"""
Given an integer array nums (can include negatives)
and integer k, return the length of the shortest non-empty
contiguous subarray with sum at least k. If none, return -1.
"""


def shortest_subarray(nums: list[int], k: int) -> int:
    pass


tests = [
    # 1
    {
        "nums": [3, -2, 5, -1, 2, -3, 4, -2, 6, -5, 2, 1, -4, 3, 2, -1, 4, -6, 7, -2],
        "k": 8,
        "expected": 2,  # [6, -? no], [7, -2, ...], shortest valid is length 2 (e.g. [4,6]? depends on segment)
    },
    # 2
    {
        "nums": [1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 6, -6, 7, -7, 8, -8, 9, -9, 10, -10],
        "k": 10,
        "expected": 1,  # [10]
    },
    # 3
    {
        "nums": [2, -5, 2, -1, 2, -1, 2, -1, 2, -1, 2, -1, 2, -1, 2, -1, 2, -1, 2, -1],
        "k": 4,
        "expected": 3,
    },
    # 4
    {
        "nums": [-4, -3, -2, -1, -5, -2, -3, -4, -1, -2, -3, -4, -5, -1, -2, -3, -4, -5, -6, -1],
        "k": 1,
        "expected": -1,
    },
    # 5
    {
        "nums": [5, -10, 6, 7, -3, 4, -2, 8, -6, 3, 2, -1, 9, -8, 1, 4, -2, 6, -7, 5],
        "k": 12,
        "expected": 2,  # [6,7]
    },
    # 6
    {
        "nums": [1, 2, -1, 2, -3, 4, -1, 2, -2, 3, -1, 2, -4, 5, -2, 3, -1, 2, -3, 4],
        "k": 7,
        "expected": 3,  # e.g. [4,-1,2, ...] check shortest is 3
    },
]


for test in tests:
    assert shortest_subarray(test["nums"], test["k"]) == test["expected"]
