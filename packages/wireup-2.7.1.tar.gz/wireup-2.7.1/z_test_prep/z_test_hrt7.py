# nums = [2, 1, 3, 2]

# Output:
# [3, 3, -1, -1]


def next_largest(nums: list[int]) -> list[int]:
    stack = []
    res = [-1] * len(nums)

    for index, num in enumerate(nums):
        while stack and num > nums[stack[-1]]:
            res[stack.pop()] = num

        stack.append(index)

    return res


print(next_largest([2, 1, 3, 2]))
