def max_sum_subarray_size_k(nums: list[int], k: int) -> int:
    best = float("-inf")
    current = 0
    left = 0

    for right, num in enumerate(nums):
        current += num

        if right >= k:
            current -= nums[left]
            left += 1

            best = max(best, current)

    return best


print(max_sum_subarray_size_k(nums=[2, 1, 5, 1, 3, 2], k=3))
