def min_subarray_len(target: int, nums: list[int]) -> int:
    best = float("inf")
    left = 0
    current = 0

    for right, num in enumerate(nums):
        current += num

        while current >= target:
            best = min(best, right - left + 1)
            current -= nums[left]
            left += 1

    return 0 if best == float("inf") else best


print(min_subarray_len(target=7, nums=[2, 3, 1, 2, 4, 3]))
