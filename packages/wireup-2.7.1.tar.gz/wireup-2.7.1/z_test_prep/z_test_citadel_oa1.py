"""
Given an array of length (10^5), we had to find the number of subarrays that satisfied the condition:
arr[i] == arr[j] == sum(arr[i+1 : j-1])
where (i) and (j) are indices of the array.
"""

from __future__ import annotations

import itertools
from collections import defaultdict


def count_sub_array_sum(numbers: list[int]) -> int:
    running_sum = list(itertools.accumulate(numbers))
    number_to_index: dict[int, int] = {}
    res = 0

    def sum_between(start: int, end: int) -> int | None:
        return running_sum[end - 1] - running_sum[start] if 0 <= start <= end - 1 < len(numbers) else None

    for idx, num in enumerate(numbers):
        if num in number_to_index:
            other_index = number_to_index[num]

            if sum_between(start=other_index, end=idx) == num:
                res += 1

        number_to_index[num] = idx

    return res


def count_sub_array_sum_repeated(numbers: list[int]) -> int:
    state_to_freq: dict[tuple[int, int], int] = defaultdict(int)
    res = 0
    running_sum = 0

    for num in numbers:
        running_sum += num
        target_running_sum = running_sum - (2 * num)

        if freq := state_to_freq.get((num, target_running_sum)):
            res += freq

        state_to_freq[(num, running_sum)] += 1

    return res


print(count_sub_array_sum([15, 5, 1, 4, 5, 15]))
print(count_sub_array_sum_repeated([15, 5, 0, 5, 5, 15]))
