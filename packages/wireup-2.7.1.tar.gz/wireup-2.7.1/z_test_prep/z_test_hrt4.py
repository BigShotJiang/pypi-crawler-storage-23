# Given an array of integers and an integer k, return the length of the longest subarray with sum ≤ k.

nums = [2, -1, 2, 1, -3, 4]
# acc = [2,  1, 3, 4,  1, 5]
k = 3


def longest_subarray_less_than_equal(nums: list[int], target_sum: int) -> int:
    best = 0
    acc = 0
    running_sum = []

    for index, num in enumerate(nums):
        acc += num
        running_sum.append(acc)

        target = acc - target_sum

        for j in range(index):
            if running_sum[j] <= target:
                best = max(best, index - j)
                print(index, j)

    return best


print(longest_subarray_less_than_equal(nums, target_sum=k))
