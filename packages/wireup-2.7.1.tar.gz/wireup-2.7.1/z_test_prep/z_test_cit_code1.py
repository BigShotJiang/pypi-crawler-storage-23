"""
Given two lists that have been concatenated the wrong way round B+A instead of A+B, and their lengths,
correct the result in constant memory and O(n) time.
"""

from typing import Any


def reverse_sub_list(items: list[Any], start: int, length: int) -> None:
    end = start + length

    for i in range((end - start) // 2):
        items[start + i], items[end - i - 1] = items[end - i - 1], items[start + i]


def fix_concatenation(items: list[Any], a_len: int, b_len: int) -> None:
    assert len(items) == a_len + b_len

    if not (a_len and b_len):
        return

    reverse_sub_list(items, start=0, length=len(items))
    reverse_sub_list(items, start=0, length=a_len)
    reverse_sub_list(items, start=a_len, length=b_len)


# 1 2 3 4 5
# [5 4] [3 2 1]
# [4 5] [1 2 3]

a = [1, 2, 3]
b = [4, 5]
c = [*b, *a]

fix_concatenation(c, len(a), len(b))
print(c)


a = [1, 2, 3, 4, 5, 6]
b = [9]
c = [*b, *a]

fix_concatenation(c, len(a), len(b))
print(c)
