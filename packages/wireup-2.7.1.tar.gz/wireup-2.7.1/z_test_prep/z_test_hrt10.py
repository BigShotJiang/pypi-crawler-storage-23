from collections import defaultdict
from typing import Hashable, Iterable


def longest_subarray_at_most_k_distinct(nums: list[int], k: int) -> int:
    best = 0
    left = 0
    curr = defaultdict(int)

    for right, num in enumerate(nums):
        curr[num] += 1

        while len(curr) > k:
            curr[nums[left]] -= 1

            if curr[nums[left]] == 0:
                del curr[nums[left]]

            left += 1

        best = max(best, right - left + 1)

    return best


def longest_subarray_exactly_k_distinct(sequence: Iterable[Hashable], k: int) -> int:
    best = 0
    left = 0
    curr = defaultdict(int)

    for right, elm in enumerate(sequence):
        curr[elm] += 1

        while len(curr) > k:
            curr[sequence[left]] -= 1

            if curr[sequence[left]] == 0:
                del curr[sequence[left]]

            left += 1

        if len(curr) == k:
            best = max(best, right - left + 1)

    return best


print(longest_subarray_at_most_k_distinct(nums=[1, 2, 1, 2, 3], k=2))
