# Monotonic Deque: Sliding Window Maximum


# Given an integer array nums and an integer k, return an array out where:

# out[i] is the maximum of nums[i : i+k]

# Example
from __future__ import annotations

from collections import deque

# [1, 3, 2, 5, 8, 7]

# dq [5]


# stack/queue/deque??? [5]


def sliding_window_max(nums: list[int], k: int) -> list[int]:
    res: list[int] = []
    q: deque[int] = deque([])

    for index, num in enumerate(nums):
        while q and num > q[0]:
            q.pop()

        q.append(num)

        if index >= k - 1:
            res.append(q[0])

    return res


print(sliding_window_max([1, 3, -1, -3, 5, 3, 6, 7], k=3))
print(sliding_window_max([1, 3, 2, 5, 8, 7], k=3))
# out = [3,3,5,5,6,7]


# q   = [7]
# res = [3, 3, 5, 5, 6, 7]
