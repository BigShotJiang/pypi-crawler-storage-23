# Given an integer array nums and an integer k, return the length of the longest subarray that contains exactly k distinct elements.


from collections import defaultdict

nums = [1, 2, 1, 2, 2, 1, 3]
k = 2
# Answer: 4
# [1,2,1,2]


def longest_subarray_k_distinct(nums: list[int], num_distinct: int) -> int:
    freqs = defaultdict(int)
    left = 0
    best = 0

    for right, num in enumerate(nums):
        freqs[num] += 1

        while len(freqs) > num_distinct:
            j = nums[left]
            freqs[j] -= 1

            if freqs[j] == 0:
                del freqs[j]

            left += 1

        if len(freqs) == num_distinct:
            best = max(best, right - left + 1)

    return best


print(longest_subarray_k_distinct(nums, num_distinct=2))
