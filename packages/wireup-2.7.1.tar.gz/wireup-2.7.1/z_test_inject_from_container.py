import wireup

container = wireup.create_async_container()


@wireup.inject_from_container(container)
async def main():
    pass


print(main.__wireup_generated_code__)
