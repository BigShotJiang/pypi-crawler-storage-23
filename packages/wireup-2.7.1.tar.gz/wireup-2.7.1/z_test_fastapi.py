import contextlib
from collections.abc import AsyncIterator

import wireup
import wireup.integration.fastapi
from fastapi import FastAPI, HTTPException, Request
from wireup import Injected, injectable
from wireup.integration.starlette import inject


@contextlib.asynccontextmanager
@inject
async def require_not_bob(request: Injected[Request]) -> AsyncIterator[None]:
    if request.query_params.get("name") == "Bob":
        raise HTTPException(status_code=401, detail="Bob is not allowed")
    yield


# 1. Define a service (add @injectable)
@injectable
class GreeterService:
    def greet(self, name: str) -> str:
        return f"Hello, {name}!"


# 2. Create the container
container = wireup.create_async_container(injectables=[GreeterService, wireup.integration.fastapi])

# 3. Create the FastAPI app and define your routes
app = FastAPI()


@app.get("/")
@require_not_bob()
async def greet(greeter: Injected[GreeterService]):
    return {"message": greeter.greet("World")}


# 4. Initialize Wireup (after all routes are added)
wireup.integration.fastapi.setup(container, app)
