from unittest.mock import MagicMock

m = MagicMock(foo=1)
print(m.foo)
