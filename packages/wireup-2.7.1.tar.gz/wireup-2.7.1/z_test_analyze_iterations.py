#!/usr/bin/env python3

import re
import json
from pathlib import Path
from collections import defaultdict
import math


class LogAnalyzer:
    def __init__(self, log_path="cmd.log", max_iterations=None):
        self.log_path = Path(log_path)
        self.max_iterations = max_iterations
        self.iterations = defaultdict(list)
        self._parse_log()

    def _parse_log(self):
        """Parse cmd.log to extract all iteration data"""
        current_project = None
        current_test = None
        iteration_count = 0

        iteration_pattern = re.compile(
            r"Iteration\s+(\d+)/(\d+):\s+([\d.]+)\s+rps,\s+p50:\s+([\d.]+)\s+ms,\s+p95:\s+([\d.]+)\s+ms,\s+p99:\s+([\d.]+)\s+ms,\s+stdev:\s+([\d.]+)\s+ms"
        )

        benchmark_pattern = re.compile(r"-?\s*Benchmarking\s+(.+?)\s+-\s+(singleton|scoped)")

        with open(self.log_path, "r") as f:
            for line in f:
                # Check for new benchmark
                benchmark_match = benchmark_pattern.search(line)
                if benchmark_match:
                    current_project = benchmark_match.group(1)
                    current_test = benchmark_match.group(2)
                    # Map to project names
                    project_map = {
                        "globals": "Globals",
                        "wireup": "Wireup",
                        "wireup_mm": "Wireup Middleware Mode",
                        "wireup_cbr": "Wireup (Class-Based)",
                        "wireup_cbr_mm": "Wireup (Class-Based) Middleware Mode",
                    }
                    current_project = project_map.get(current_project, current_project)
                    iteration_count = 0  # Reset counter for new benchmark
                    continue

                # Check for iteration data
                iteration_match = iteration_pattern.search(line)
                if iteration_match and current_project and current_test:
                    iter_num = int(iteration_match.group(1))
                    total_iters = int(iteration_match.group(2))
                    rps = float(iteration_match.group(3))
                    p50 = float(iteration_match.group(4))
                    p95 = float(iteration_match.group(5))
                    p99 = float(iteration_match.group(6))
                    stdev = float(iteration_match.group(7))

                    # Limit to max_iterations if specified (to handle duplicate runs)
                    if self.max_iterations and iteration_count >= self.max_iterations:
                        continue

                    key = f"{current_project} - {current_test}"
                    self.iterations[key].append(
                        {
                            "project": current_project,
                            "test": current_test,
                            "iteration": iter_num,
                            "rps": rps,
                            "p50": p50,
                            "p95": p95,
                            "p99": p99,
                            "stdev": stdev,
                        }
                    )

                    iteration_count += 1

    def _get_percentile(self, values, percentile):
        if not values:
            return 0.0
        sorted_values = sorted(values)
        n = len(sorted_values)
        if n == 1:
            return sorted_values[0]

        pos = percentile / 100 * (n - 1)
        lower = int(pos)
        upper = lower + 1

        if upper >= n:
            return sorted_values[-1]

        return sorted_values[lower] + (pos - lower) * (sorted_values[upper] - sorted_values[lower])

    def _calc_mean(self, values):
        return sum(values) / len(values) if values else 0.0

    def _calc_stddev(self, values):
        if len(values) < 2:
            return 0.0
        mean = sum(values) / len(values)
        variance = sum((x - mean) ** 2 for x in values) / (len(values) - 1)
        return math.sqrt(variance)

    def analyze(self):
        print("=" * 100)
        print("WIREUP BENCHMARK ANALYSIS - ALL 50 ITERATIONS")
        print("=" * 100)
        print()
        print(f"Total configurations analyzed: {len(self.iterations)}")
        if self.max_iterations:
            print(f"Limited to {self.max_iterations} iterations per configuration")
        print()

        # Aggregate statistics table
        print("=" * 100)
        print("AGGREGATE STATISTICS ACROSS ALL ITERATIONS")
        print("=" * 100)
        print()

        print(
            f"{'Configuration':<45} {'RPS P50':>10} {'RPS P95':>10} {'RPS P99':>10} {'P50(ms)':>10} {'P95(ms)':>10} {'P99(ms)':>10} {'StdDev':>10}"
        )
        print("-" * 115)

        results = []
        for key in sorted(self.iterations.keys()):
            iters = self.iterations[key]
            project = iters[0]["project"]
            test = iters[0]["test"]

            # Extract metrics across all iterations
            rps_values = [i["rps"] for i in iters]
            p50_values = [i["p50"] for i in iters]
            p95_values = [i["p95"] for i in iters]
            p99_values = [i["p99"] for i in iters]
            stdev_values = [i["stdev"] for i in iters]

            # Calculate percentiles across all iterations
            rps_p50 = self._get_percentile(rps_values, 50)
            rps_p95 = self._get_percentile(rps_values, 95)
            rps_p99 = self._get_percentile(rps_values, 99)

            p50_p50 = self._get_percentile(p50_values, 50)
            p95_p50 = self._get_percentile(p95_values, 50)
            p99_p50 = self._get_percentile(p99_values, 50)

            stdev_mean = self._calc_mean(stdev_values)

            config_name = f"{project} - {test}"
            print(
                f"{config_name:<45} {rps_p50:>10.2f} {rps_p95:>10.2f} {rps_p99:>10.2f} {p50_p50:>10.2f} {p95_p50:>10.2f} {p99_p50:>10.2f} {stdev_mean:>10.3f}"
            )

            results.append(
                {
                    "key": key,
                    "project": project,
                    "test": test,
                    "rps_p50": rps_p50,
                    "rps_p95": rps_p95,
                    "rps_p99": rps_p99,
                    "p50_p50": p50_p50,
                    "p95_p50": p95_p50,
                    "p99_p50": p99_p50,
                    "stdev_mean": stdev_mean,
                    "rps_mean": self._calc_mean(rps_values),
                    "rps_min": min(rps_values),
                    "rps_max": max(rps_values),
                    "rps_stddev": self._calc_stddev(rps_values),
                    "count": len(iters),
                }
            )

        print()
        print("Note: RPS P50/P95/P99 represent the distribution of RPS values across all iterations")
        print("      P50/P95/P99 represent the median of latency values across all iterations")
        print()

        # Detailed breakdown by configuration
        print("=" * 100)
        print("DETAILED STATISTICS PER CONFIGURATION")
        print("=" * 100)
        print()

        for result in sorted(results, key=lambda x: (x["test"], x["project"])):
            print(f"Configuration: {result['project']} - {result['test']}")
            print(f"  Total Iterations: {result['count']}")
            print()
            print(f"  RPS Statistics:")
            print(f"    Median (P50): {result['rps_p50']:.2f} req/s")
            print(f"    P95: {result['rps_p95']:.2f} req/s")
            print(f"    P99: {result['rps_p99']:.2f} req/s")
            print(f"    Mean: {result['rps_mean']:.2f} req/s")
            print(f"    Std Dev: {result['rps_stddev']:.2f} req/s")
            print(f"    Range: {result['rps_min']:.2f} - {result['rps_max']:.2f} req/s")
            print(f"    Coefficient of Variation: {(result['rps_stddev'] / result['rps_mean'] * 100):.2f}%")
            print()
            print(f"  Latency Statistics (Median across iterations):")
            print(f"    P50: {result['p50_p50']:.2f} ms")
            print(f"    P95: {result['p95_p50']:.2f} ms")
            print(f"    P99: {result['p99_p50']:.2f} ms")
            print(f"    StdDev: {result['stdev_mean']:.3f} ms")
            print()

        # Performance comparison
        print()
        print("=" * 100)
        print("PERFORMANCE COMPARISON")
        print("=" * 100)
        print()

        # Singleton vs Scoped comparison
        print("Singleton vs Scoped Mode (RPS P50):")
        print()
        print(f"{'Project':<40} {'Singleton':>15} {'Scoped':>15} {'Difference':>15}")
        print("-" * 85)

        projects = set(r["project"] for r in results)
        for project in sorted(projects):
            singleton = next((r for r in results if r["project"] == project and r["test"] == "singleton"), None)
            scoped = next((r for r in results if r["project"] == project and r["test"] == "scoped"), None)

            if singleton and scoped:
                diff = ((scoped["rps_p50"] - singleton["rps_p50"]) / singleton["rps_p50"]) * 100
                print(f"{project:<40} {singleton['rps_p50']:>15.2f} {scoped['rps_p50']:>15.2f} {diff:>14.2f}%")

        print()

        # Middleware impact
        print("Middleware Mode Impact:")
        print()

        wireup_reg = next((r for r in results if r["project"] == "Wireup"), None)
        wireup_mm = next((r for r in results if r["project"] == "Wireup Middleware Mode"), None)

        if wireup_reg and wireup_mm:
            for test in ["singleton", "scoped"]:
                reg_result = next((r for r in results if r["project"] == "Wireup" and r["test"] == test), None)
                mm_result = next(
                    (r for r in results if r["project"] == "Wireup Middleware Mode" and r["test"] == test), None
                )

                if reg_result and mm_result:
                    diff = ((mm_result["rps_p50"] - reg_result["rps_p50"]) / reg_result["rps_p50"]) * 100
                    print(f"{test.capitalize()} mode:")
                    print(f"  Wireup: {reg_result['rps_p50']:.2f} req/s")
                    print(f"  Wireup Middleware Mode: {mm_result['rps_p50']:.2f} req/s")
                    print(f"  Impact: {diff:.2f}%")
                    print()

        # Class-based comparison
        wireup_cbr = next((r for r in results if r["project"] == "Wireup (Class-Based)"), None)
        wireup_cbr_mm = next((r for r in results if r["project"] == "Wireup (Class-Based) Middleware Mode"), None)

        if wireup_cbr and wireup_cbr_mm:
            for test in ["singleton", "scoped"]:
                cbr_result = next(
                    (r for r in results if r["project"] == "Wireup (Class-Based)" and r["test"] == test), None
                )
                cbr_mm_result = next(
                    (
                        r
                        for r in results
                        if r["project"] == "Wireup (Class-Based) Middleware Mode" and r["test"] == test
                    ),
                    None,
                )

                if cbr_result and cbr_mm_result:
                    diff = ((cbr_mm_result["rps_p50"] - cbr_result["rps_p50"]) / cbr_result["rps_p50"]) * 100
                    print(f"Class-Based {test.capitalize()} mode:")
                    print(f"  Wireup (Class-Based): {cbr_result['rps_p50']:.2f} req/s")
                    print(f"  Wireup (Class-Based) Middleware Mode: {cbr_mm_result['rps_p50']:.2f} req/s")
                    print(f"  Impact: {diff:.2f}%")
                    print()

        # Stability analysis
        print()
        print("=" * 100)
        print("STABILITY ANALYSIS (Lower CV = More Stable)")
        print("=" * 100)
        print()

        print(f"{'Configuration':<45} {'CV (%)':>10} {'RPS Range':>15}")
        print("-" * 70)

        for result in sorted(results, key=lambda x: x["rps_stddev"] / x["rps_mean"]):
            cv = (result["rps_stddev"] / result["rps_mean"]) * 100
            rps_range = result["rps_max"] - result["rps_min"]
            config = f"{result['project']} - {result['test']}"
            print(f"{config:<45} {cv:>9.2f}% {rps_range:>15.2f}")

        print()

        # Best performers
        print("=" * 100)
        print("BEST PERFORMERS")
        print("=" * 100)
        print()

        best_singleton = max([r for r in results if r["test"] == "singleton"], key=lambda x: x["rps_p50"])
        best_scoped = max([r for r in results if r["test"] == "scoped"], key=lambda x: x["rps_p50"])
        best_latency = min(results, key=lambda x: x["p50_p50"])
        most_stable = min(results, key=lambda x: x["rps_stddev"] / x["rps_mean"])

        print(f"Best Singleton RPS (P50): {best_singleton['project']} - {best_singleton['test']}")
        print(
            f"  {best_singleton['rps_p50']:.2f} req/s (P95: {best_singleton['rps_p95']:.2f}, P99: {best_singleton['rps_p99']:.2f})"
        )
        print()

        print(f"Best Scoped RPS (P50): {best_scoped['project']} - {best_scoped['test']}")
        print(
            f"  {best_scoped['rps_p50']:.2f} req/s (P95: {best_scoped['rps_p95']:.2f}, P99: {best_scoped['rps_p99']:.2f})"
        )
        print()

        print(f"Lowest Latency (P50): {best_latency['project']} - {best_latency['test']}")
        print(
            f"  {best_latency['p50_p50']:.2f} ms (P95: {best_latency['p95_p50']:.2f}, P99: {best_latency['p99_p50']:.2f})"
        )
        print()

        cv = (most_stable["rps_stddev"] / most_stable["rps_mean"]) * 100
        print(f"Most Stable Performance: {most_stable['project']} - {most_stable['test']}")
        print(f"  CV: {cv:.2f}%, RPS Range: {most_stable['rps_max'] - most_stable['rps_min']:.2f} req/s")
        print()


if __name__ == "__main__":
    # Limit to 50 iterations to handle the duplicate run issue
    analyzer = LogAnalyzer(max_iterations=50)
    analyzer.analyze()
