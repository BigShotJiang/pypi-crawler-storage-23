==================================================
SUMMARY 2.7.0
==================================================

SINGLETON | NO MIDDLEWARE:
  Raw await container.get: 5233720.99 ops/sec
  @inject_from_container: 3118209.80 ops/sec
  Decorator overhead: 67.8%

SINGLETON | MIDDLEWARE:
  Raw await container.get: 5236988.39 ops/sec
  @inject_from_container: 857529.21 ops/sec
  Decorator overhead: 510.7%

SCOPED | NO MIDDLEWARE:
  Raw await container.get: 5107530.44 ops/sec
  @inject_from_container: 226834.39 ops/sec
  Decorator overhead: 2151.7%

SCOPED | MIDDLEWARE:
  Raw await container.get: 5135672.83 ops/sec
  @inject_from_container: 212247.31 ops/sec
  Decorator overhead: 2319.7%


==================================================
SUMMARY 2.6.0
==================================================

SINGLETON | NO MIDDLEWARE:
  Raw await container.get: 5208051.16 ops/sec
  @inject_from_container: 391648.79 ops/sec
  Decorator overhead: 1229.8%

SINGLETON | MIDDLEWARE:
  Raw await container.get: 5195471.32 ops/sec
  @inject_from_container: 295305.93 ops/sec
  Decorator overhead: 1659.4%

SCOPED | NO MIDDLEWARE:
  Raw await container.get: 5126257.64 ops/sec
  @inject_from_container: 92492.51 ops/sec
  Decorator overhead: 5442.3%

SCOPED | MIDDLEWARE:
  Raw await container.get: 5182631.90 ops/sec
  @inject_from_container: 84467.64 ops/sec
  Decorator overhead: 6035.6%
