# SEO Optimization Plan for benchmarks.md

## Context
- Goal: Make benchmarks.md discoverable when people search for Python DI libraries
- Framework: mkdocs-material
- Current issue: Page has no H1 title, missing metadata, generic headings

## MkDocs-Material SEO Capabilities Available

### Current Setup
- ✅ **Search plugin** enabled (line 15 in mkdocs.yml)
- ❌ **Meta plugin** NOT enabled

### What MkDocs-Material Offers
1. **Meta Plugin** - Adds metadata via `.meta.yml` files for SEO (description, tags, authors)
2. **Search Plugin** - Has `search.boost` front matter to rank specific pages higher
3. **Native Markdown** - H1 titles, proper headings, image alt text all work for SEO

---

## Proposed SEO Plan for benchmarks.md

### Change 1: Add Meta Plugin to mkdocs.yml

**Add to `plugins:` section:**
```yaml
plugins:
  - search
  - meta  # Add this line
```

**Why:** Enables metadata support for all pages including SEO descriptions, tags, etc.

---

### Change 2: Create `.meta.yml` for benchmarks metadata

**Create file:** `docs/pages/.meta.yml`

**Content:**
```yaml
---
description: >
  Python dependency injection benchmark 2026 comparing Wireup vs Dependency Injector,
  FastAPI Depends, Aioinject, Dishka, Svcs, That Depends, Injector, and Lagom.
  Real-world FastAPI + Uvicorn tests showing requests per second, latency (p50/p95/p99),
  memory usage.

tags:
  - python di
  - dependency injection
  - python benchmark
  - wireup vs dependency injector
  - wireup vs fastapi depends
  - di library comparison
  - python performance
  - fastapi dependency injection
  - aioinject
  - dishka
  - that depends
  - lagom
  - injector
  - svcs
```

**Why:** Provides search engines with rich metadata for better indexing and click-through rates.

---

### Change 3: Add H1 Title to benchmarks.md

**Current:** Starts with abstract note, no H1

**Proposed:** Add at line 1 (after frontmatter):
```markdown
# Wireup Benchmark: Python DI Performance Comparison
```

**Why:** H1 is critical for SEO. Search engines use H1 text heavily for understanding page topic. Current title is only visible in navigation.

---

### Change 4: Enhance Section Headings with Keywords

**Current:**
```markdown
## Scoped Performance
## Singleton Performance
```

**Proposed:**
```markdown
## Python DI Performance: Scoped Dependencies

### Wireup vs Dependency Injector vs FastAPI Depends
Each request creates new instances for scoped services while reusing singletons.
```

**Alternative (more explicit):**
```markdown
## Python DI Library Performance: Scoped Dependencies
## Python DI Library Performance: Singleton Dependencies
```

**Why:** High-intent search phrases ("python di performance", "wireup vs dependency injector") will be in page headings.

---

### Change 5: Improve Image Alt Text for SEO

**Current:**
```markdown
![Scoped Performance](img/benchmarks_scoped_light.svg#only-light)
```

**Proposed:**
```markdown
![Python DI library performance comparison: Scoped dependencies - Wireup vs Dependency Injector vs FastAPI Depends vs Aioinject vs Dishka vs Lagom](img/benchmarks_scoped_light.svg#only-light)
```

**Why:** Alt text is important for image search and accessibility. Include all library names for discoverability.

---

### Change 6: Add Search Boost to benchmarks.md

**Add to frontmatter:**
```markdown
---
search:
  boost: 2  # Moderate boost, won't overwhelm other pages
---
```

**Why:** Makes benchmarks page rank higher in site search results when people search for "di", "benchmark", "performance".

---

## What NOT To Change (Per User Request)

1. **No conclusion section** - Let numbers speak for themselves
2. **No separate comparison section** - Avoid "which library should you use" summary
3. **Keep it factual** - Benchmark data speaks for itself

---

## Implementation Order

| Priority | File                     | Changes                         | Impact                                 |
| -------- | ------------------------ | ------------------------------- | -------------------------------------- |
| 1        | mkdocs.yml               | Add `meta` plugin               | High (enables metadata support)        |
| 2        | docs/pages/.meta.yml     | Create with description/tags    | High (SEO metadata for search engines) |
| 3        | docs/pages/benchmarks.md | Add H1 title                    | High (primary SEO signal)              |
| 4        | docs/pages/benchmarks.md | Add search.boost to frontmatter | Medium (search ranking)                |
| 5        | docs/pages/benchmarks.md | Enhance section headings        | Medium (keyword targeting)             |
| 6        | docs/pages/benchmarks.md | Update image alt text           | Low/Medium (image search)              |

---

## Additional SEO Tips for Content

Within benchmarks.md content (beyond structure changes):

1. **Natural keyword integration** - Use phrases like:
   - "Python DI library"
   - "Dependency Injection for Python"
   - "FastAPI Depends alternative"
   - "Wireup vs Dependency Injector"

2. **Add internal links** - Link to library names in tables when mentioning them in text
3. **Add backlinks** - Link to relevant docs pages (integration guides, migration docs)

---

## Search Boost Value Question

- What level makes sense? 1-3 range?
  - Level 1 = Low priority
  - Level 2 = Medium priority (recommended starting point)
  - Level 3 = High priority (might overshadow other pages)

**Recommendation:** Start with level 2 (moderate) for benchmarks page specifically, as it's a key differentiator.

---

## Questions to Address Before Implementation

1. **H1 title** - Confirmed: "Wireup Benchmark: Python DI Performance Comparison"?

2. **Tags selection** - Are these the right tags?
   - Core: python di, dependency injection, python benchmark
   - Library-specific: wireup, dependency-injector, fastapi-depends, aioinject, dishka, svcs, injector, lagom

3. **Section headings style** - Do you prefer "Python DI Performance: Scoped" or "Wireup vs FastAPI Depends: Scoped"?

4. **Alt text detail** - Should we list all libraries in alt text or focus on top performers?
   - Option A: "Wireup vs Dependency Injector vs FastAPI Depends" (concise)
   - Option B: "Wireup vs Dependency Injector vs FastAPI Depends vs Aioinject vs Dishka vs Svcs vs That Depends vs Injector vs Lagom" (comprehensive)

5. **Description length** - Is the description too long or just right for search snippets?

---

## Next Steps

1. Review this plan
2. Make decisions on questions above
3. Approve implementation
4. Execute changes in order (1-6)
5. Test locally with `mkdocs serve`
6. Deploy and verify search results
