from __future__ import annotations

import wireup


@wireup.service
class Bar: ...
