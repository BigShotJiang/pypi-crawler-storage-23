import wireup
from typing_extensions import Annotated
from wireup._decorators import inject_from_container_unchecked


def target(conf: Annotated[str, wireup.Inject(config="foo")]) -> None:
    pass


container = wireup.create_sync_container(config={"foo": "bar"})
wrapped = inject_from_container_unchecked(lambda: container.enter_scope())(target)
wrapped()
