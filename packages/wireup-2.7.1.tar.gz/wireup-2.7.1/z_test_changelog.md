# Changelog (since v2.6.0)

## Added

- Opt-in scoped locking for scopes accessed concurrently via `concurrent_scoped_access` on `create_sync_container` /
    `create_async_container`.
- Compiler snapshot tests to validate generated injection wrapper code (`test/unit/test_compiler_code_generation.py`).
- `make docs-serve` target for local MkDocs development.

## Changed

- Function injection (`inject_from_container` and framework integrations) now generates specialized wrappers at
    decoration time, reducing per-call runtime overhead and skipping container lookups when possible.
- Factory compilation generates more specialized factories by inlining config lookups and dependency resolution.
- Exit stack cleanup avoids runtime `inspect.isasyncgen()` checks by tracking generator type on push.

## Fixed

- Fixed a bug where an async container injecting into a `def` function would not inject async dependencies already
    cached in the container.
- Added support for injecting into generator / async-generator functions (and ensured middleware cleanup works correctly
    in generated wrappers).
- Improved FastAPI integration middleware wrapper generation.
- Qualifiers with falsy values (e.g. `0`, `""`, `False`) are now handled correctly during injection.
- Wireup raises a clearer error when encountering positional-only parameters in injectables or injected callables.