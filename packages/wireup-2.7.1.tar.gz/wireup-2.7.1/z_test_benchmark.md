# Benchmark validation report

Date: 2026-02-11
Scope: `benchmarks/wireup_benchmarks`

## Executive summary
Three benchmark setups do not currently match the intended lifetimes in the benchmark spec:
- Dependency Injector: H/I resources are not per-request, and context managers are never entered/exited.
- fastapi-injector: context manager/async lifetime is not exercised; cleanup not enabled.
- that-depends: `default_scope` makes `Singleton` providers request-scoped, so A/B/Settings are rebuilt per request.

All other libraries appear aligned with the spec, given their documented capabilities and limitations.

## Findings by library

### Dependency Injector
File: `benchmarks/wireup_benchmarks/dependency_injector_setup.py`

Issue:
- `providers.Resource` for H/I is application-scoped unless explicitly initialized and shut down per request. The current setup never enters these resources per request, so H/I are effectively singletons and their context managers never run.

Impact:
- The benchmark does not reflect request-scoped resource setup/teardown overhead for H/I.

Suggested fix:
- Add per-request resource enter/exit (e.g., middleware that calls `container.init_resources()` and `container.shutdown_resources()` per request), or switch H/I to request-scoped providers that model context managers correctly (if supported by the library).

### fastapi-injector
File: `benchmarks/wireup_benchmarks/injector_setup.py`

Issue:
- H and I are provided as plain dataclasses, not context-managed resources. Also, `RequestScopeOptions(enable_cleanup=True)` is not set when attaching the injector middleware, so request-scope cleanup hooks are not run.

Impact:
- The benchmark does not exercise context manager/async lifetime for H/I, undercounting per-request setup/teardown work compared to the benchmark spec.

Suggested fix:
- Provide H/I using context managers (sync for H, async for I) and enable request scope cleanup when attaching the injector middleware.

### that-depends
File: `benchmarks/wireup_benchmarks/that_depends_setup.py`

Issue:
- `default_scope = ContextScopes.REQUEST` makes even `providers.Singleton` request-scoped. Settings/A/B should be app-wide singletons per the benchmark spec, but are reconstructed per request.

Impact:
- The benchmark for singletons is not comparable to other libraries.

Suggested fix:
- Change `default_scope` to `ContextScopes.APP` (or explicitly scope Settings/A/B to app scope).

## No issues found (matches spec or documented limitations)

- Wireup: `benchmarks/wireup_benchmarks/wireup_setup.py`, `benchmarks/wireup_benchmarks/wireup_cbr_setup.py`
- FastAPI built-in: `benchmarks/wireup_benchmarks/fastapi_setup.py` (matches documented pattern with per-request caching)
- Aioinject: `benchmarks/wireup_benchmarks/aioinject_setup.py`
- Dishka: `benchmarks/wireup_benchmarks/dishka_setup.py`
- Svcs: `benchmarks/wireup_benchmarks/svcs_setup.py`
- Lagom: `benchmarks/wireup_benchmarks/lagom_setup.py` (known limitation: async context manager not supported; I is sync)

## Notes
- The benchmark spec states H is a context manager and I is an async context manager. Any library setup that does not enter/exit these contexts per request deviates from the spec and should be marked accordingly in `docs/pages/benchmarks.md`.
