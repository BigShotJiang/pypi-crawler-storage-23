Use this prompt next time:

```text
Implement a performance optimization in `wireup/ioc/factory_compiler.py` only (do not modify `wireup/ioc/override_manager.py`).

Goal:
- Reduce generated-factory dependency resolution overhead by binding dependency factories to direct names in the generated namespace, instead of doing `factories[dep_hash].factory(container)` on every call.

Constraints:
1. Do not change files outside `wireup/ioc/factory_compiler.py`.
2. Keep override behavior fully correct even though `OverrideManager` may replace entries in `compiler.factories`.
3. Generated code can use a fast/slow path:
   - Fast path (no active overrides): use direct bound names for dependency compiled factories.
   - Slow path (overrides active): fall back to lookup via `container._factories[...]` (or equivalent dynamic lookup) so overrides are respected.
4. Preserve existing behavior for:
   - async dependencies
   - generator/async-generator factories
   - singleton/scoped/transient lifetimes
   - interface aliasing and cache semantics
   - scope mismatch errors
5. Keep code style consistent and avoid unnecessary refactors.

Validation:
- Run `uv run pytest -q test/unit/test_compiler_code_generation.py test/unit/test_concurrency.py test/unit/test_container_core.py`
- Run `uv run python z_test_bench.py` before and after, and report before/after ops/sec with percentage deltas.

Deliverables:
- Patch in `factory_compiler.py`
- Short summary of implementation details and risk/tradeoffs
- Benchmark and test results
```