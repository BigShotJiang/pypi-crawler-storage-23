from django_spire.core.redirect.safe_redirect import safe_redirect_url


__all__ = [
    'safe_redirect_url'
]
