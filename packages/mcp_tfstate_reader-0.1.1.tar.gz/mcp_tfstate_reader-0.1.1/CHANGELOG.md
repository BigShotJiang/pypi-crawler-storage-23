# Changelog

## [0.1.1](https://github.com/berkayyildirim/mcp-tfstate-reader/compare/v0.1.0...v0.1.1) (2026-03-01)


### Features

* initial release of MCP Terraform state reader with security auditing ([6a22a6b](https://github.com/berkayyildirim/mcp-tfstate-reader/commit/6a22a6b1c80207fdea31a2fc3d8a94857ad126c8))
