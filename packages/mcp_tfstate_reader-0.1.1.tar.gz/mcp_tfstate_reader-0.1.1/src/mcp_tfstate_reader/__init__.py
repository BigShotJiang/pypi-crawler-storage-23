"""MCP server for auditing Terraform state files for security misconfigurations."""

__version__ = "0.1.1"
