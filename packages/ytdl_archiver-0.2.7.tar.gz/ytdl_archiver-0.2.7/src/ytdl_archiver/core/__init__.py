"""Core functionality for ytdl-archiver."""
