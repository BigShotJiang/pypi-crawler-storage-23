"""CLI module - Command line interface for Lantern."""

from lantern_cli.cli.main import app

__all__ = ["app"]
