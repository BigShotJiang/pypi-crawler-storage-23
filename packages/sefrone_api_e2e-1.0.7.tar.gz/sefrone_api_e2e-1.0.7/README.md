This is not a usable Python package, but the name is reserved by SARL Sefrone.

You can find other packages published by Sefrone at pypi.org/user/gnasreddine