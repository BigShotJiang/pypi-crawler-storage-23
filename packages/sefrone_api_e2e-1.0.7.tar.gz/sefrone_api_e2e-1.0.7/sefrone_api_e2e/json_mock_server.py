import threading
import json
import re
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import List, Dict, Any, Optional, Callable
from datetime import datetime
from urllib.parse import urlparse, parse_qs


class JsonMockServer:
    """
    Simple mock JSON/REST API server that can mock endpoints and record requests.
    
    Features:
    - Configure mock endpoints with expected responses
    - Record all incoming requests for verification
    - Query recorded requests
    - Support for dynamic response functions
    - Pattern matching for URLs
    """
    
    def __init__(self, host: str = "localhost", port: int = 8080):
        self.host = host
        self.port = port
        self.mocks: List[Dict[str, Any]] = []
        self.requests: List[Dict[str, Any]] = []
        self._server: Optional[HTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self._running = False
        
    def start(self):
        """Start the mock JSON server in a background thread."""
        if self._running:
            print(f"[JsonMockServer] Already running on {self.host}:{self.port}")
            return
            
        handler = self._create_handler()
        self._server = HTTPServer((self.host, self.port), handler)
        self._running = True
        
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()
        print(f"[JsonMockServer] Started on http://{self.host}:{self.port}")
        
    def stop(self):
        """Stop the mock JSON server."""
        if not self._running:
            return
            
        self._running = False
        if self._server:
            self._server.shutdown()
            self._server.server_close()
        if self._thread:
            self._thread.join(timeout=2)
        print(f"[JsonMockServer] Stopped")
        
    def clear_mocks(self):
        """Clear all configured mocks."""
        self.mocks.clear()
        print(f"[JsonMockServer] Cleared all mocks")
        
    def clear_requests(self):
        """Clear all recorded requests."""
        self.requests.clear()
        print(f"[JsonMockServer] Cleared all recorded requests")
        
    def clear_all(self):
        """Clear both mocks and recorded requests."""
        self.clear_mocks()
        self.clear_requests()
        
    def add_mock(
        self,
        method: str,
        path: str,
        response_body: Any = None,
        status_code: int = 200,
        response_headers: Optional[Dict[str, str]] = None,
        response_fn: Optional[Callable] = None,
        is_regex: bool = False
    ):
        """
        Add a mock endpoint.
        
        Args:
            method: HTTP method (GET, POST, PUT, DELETE, etc.)
            path: URL path or regex pattern
            response_body: Response body to return (dict or any JSON-serializable)
            status_code: HTTP status code to return
            response_headers: Additional response headers
            response_fn: Optional function(request_data) -> response_body for dynamic responses
            is_regex: Whether path is a regex pattern
            
        Example:
            server.add_mock("GET", "/api/users", {"users": []})
            server.add_mock("POST", "/api/users", {"id": 1}, status_code=201)
            server.add_mock("GET", r"/api/users/\d+", response_fn=lambda req: {"id": req["path_params"][0]}, is_regex=True)
        """
        mock = {
            "method": method.upper(),
            "path": path,
            "response_body": response_body,
            "status_code": status_code,
            "response_headers": response_headers or {},
            "response_fn": response_fn,
            "is_regex": is_regex,
            "hit_count": 0
        }
        self.mocks.append(mock)
        print(f"[JsonMockServer] Added mock: {method.upper()} {path} -> {status_code}")
        
    def get_requests(self) -> List[Dict[str, Any]]:
        """Get all recorded requests."""
        return self.requests.copy()
        
    def get_request(self, index: int) -> Optional[Dict[str, Any]]:
        """Get a specific request by index."""
        if 0 <= index < len(self.requests):
            return self.requests[index]
        return None
        
    def count_requests(self, method: Optional[str] = None, path: Optional[str] = None) -> int:
        """
        Count recorded requests, optionally filtered by method and/or path.
        
        Example:
            count_requests()  # all requests
            count_requests(method="POST")
            count_requests(path="/api/users")
            count_requests(method="POST", path="/api/users")
        """
        filtered = self.requests
        if method:
            filtered = [r for r in filtered if r["method"] == method.upper()]
        if path:
            filtered = [r for r in filtered if r["path"] == path]
        return len(filtered)
        
    def find_requests(self, **filters) -> List[Dict[str, Any]]:
        """
        Find requests matching the given filters.
        
        Example:
            find_requests(method="POST", path="/api/users")
        """
        results = []
        for request in self.requests:
            match = True
            for key, value in filters.items():
                if key not in request or request[key] != value:
                    match = False
                    break
            if match:
                results.append(request)
        return results
        
    def _find_mock(self, method: str, path: str) -> Optional[Dict[str, Any]]:
        """Find a matching mock for the given method and path."""
        for mock in self.mocks:
            if mock["method"] != method:
                continue
                
            if mock["is_regex"]:
                if re.match(mock["path"], path):
                    return mock
            else:
                if mock["path"] == path:
                    return mock
        return None
        
    def _create_handler(self):
        """Create the HTTP request handler with access to this server instance."""
        server_instance = self
        
        class JsonMockHandler(BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                """Suppress default logging."""
                pass
                
            def _send_json_response(self, status: int, data: Any, headers: Optional[Dict[str, str]] = None):
                """Send a JSON response."""
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                if headers:
                    for key, value in headers.items():
                        self.send_header(key, value)
                self.end_headers()
                self.wfile.write(json.dumps(data).encode())
                
            def do_OPTIONS(self):
                """Handle CORS preflight requests."""
                self.send_response(200)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH, OPTIONS")
                self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
                self.end_headers()
                
            def _handle_request(self, method: str):
                """Common request handling logic."""
                parsed_url = urlparse(self.path)
                path = parsed_url.path
                query_params = parse_qs(parsed_url.query)
                
                # Read request body if present
                body = None
                content_length = int(self.headers.get("Content-Length", 0))
                if content_length > 0:
                    body_bytes = self.rfile.read(content_length)
                    try:
                        body = json.loads(body_bytes.decode("utf-8"))
                    except json.JSONDecodeError:
                        body = body_bytes.decode("utf-8")
                
                # Record the request
                request_data = {
                    "index": len(server_instance.requests),
                    "method": method,
                    "path": path,
                    "query_params": query_params,
                    "headers": dict(self.headers),
                    "body": body,
                    "received_at": datetime.utcnow().isoformat()
                }
                server_instance.requests.append(request_data)
                
                print(f"[JsonMockServer] Recorded request #{request_data['index']}: {method} {path}")
                
                # Special endpoint to query recorded requests
                if path == "/_mock/requests":
                    self._send_json_response(200, {
                        "count": len(server_instance.requests),
                        "requests": server_instance.requests
                    })
                    return
                elif path.startswith("/_mock/requests/"):
                    try:
                        index = int(path.split("/")[-1])
                        request = server_instance.get_request(index)
                        if request:
                            self._send_json_response(200, request)
                        else:
                            self._send_json_response(404, {
                                "status": "error",
                                "message": f"Request at index {index} not found"
                            })
                        return
                    except ValueError:
                        self._send_json_response(400, {
                            "status": "error",
                            "message": "Invalid index"
                        })
                        return
                elif path == "/_mock/health":
                    self._send_json_response(200, {
                        "status": "healthy",
                        "mocks_count": len(server_instance.mocks),
                        "requests_count": len(server_instance.requests)
                    })
                    return
                
                # Find matching mock
                mock = server_instance._find_mock(method, path)
                if mock:
                    mock["hit_count"] += 1
                    
                    # Generate response
                    if mock["response_fn"]:
                        try:
                            response_body = mock["response_fn"](request_data)
                        except Exception as e:
                            self._send_json_response(500, {
                                "status": "error",
                                "message": f"Mock response function error: {str(e)}"
                            })
                            return
                    else:
                        response_body = mock["response_body"]
                    
                    print(f"[JsonMockServer] Matched mock: {method} {path} -> {mock['status_code']}")
                    self._send_json_response(
                        mock["status_code"],
                        response_body,
                        mock["response_headers"]
                    )
                else:
                    print(f"[JsonMockServer] No mock found for: {method} {path}")
                    self._send_json_response(404, {
                        "status": "error",
                        "message": f"No mock configured for {method} {path}"
                    })
                    
            def do_GET(self):
                self._handle_request("GET")
                
            def do_POST(self):
                self._handle_request("POST")
                
            def do_PUT(self):
                self._handle_request("PUT")
                
            def do_DELETE(self):
                self._handle_request("DELETE")
                
            def do_PATCH(self):
                self._handle_request("PATCH")
        
        return JsonMockHandler
