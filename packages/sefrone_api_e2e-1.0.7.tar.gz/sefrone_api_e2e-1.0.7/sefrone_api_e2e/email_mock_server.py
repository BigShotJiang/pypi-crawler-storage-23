import threading
import json
import socket
import email
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import List, Dict, Any, Optional
from datetime import datetime


class EmailMockServer:
    """
    Comprehensive mock email server that supports SMTP, IMAP, and HTTP protocols.
    
    Features:
    - SMTP server for receiving emails (standard protocol)
    - IMAP server for checking emails (standard protocol)
    - HTTP API for test automation and verification
    - Query captured emails via GET /emails
    - Clear emails via DELETE /emails
    """
    
    def __init__(self, host: str = "localhost", http_port: int = 8025, smtp_port: int = 1025, imap_port: int = 1143):
        self.host = host
        self.http_port = http_port
        self.smtp_port = smtp_port
        self.imap_port = imap_port
        self.emails: List[Dict[str, Any]] = []
        self._http_server: Optional[HTTPServer] = None
        self._smtp_thread: Optional[threading.Thread] = None
        self._imap_thread: Optional[threading.Thread] = None
        self._http_thread: Optional[threading.Thread] = None
        self._running = False
        self._smtp_socket: Optional[socket.socket] = None
        self._imap_socket: Optional[socket.socket] = None
        self._next_uid = 1
        
    def start(self):
        """Start all email server protocols in background threads."""
        if self._running:
            print(f"[EmailMockServer] Already running")
            return
            
        self._running = True
        
        # Start HTTP server
        handler = self._create_http_handler()
        self._http_server = HTTPServer((self.host, self.http_port), handler)
        self._http_thread = threading.Thread(target=self._http_server.serve_forever, daemon=True)
        self._http_thread.start()
        print(f"[EmailMockServer] HTTP API started on http://{self.host}:{self.http_port}")
        
        # Start SMTP server
        self._smtp_thread = threading.Thread(target=self._run_smtp_server, daemon=True)
        self._smtp_thread.start()
        print(f"[EmailMockServer] SMTP server started on {self.host}:{self.smtp_port}")
        
        # Start IMAP server
        self._imap_thread = threading.Thread(target=self._run_imap_server, daemon=True)
        self._imap_thread.start()
        print(f"[EmailMockServer] IMAP server started on {self.host}:{self.imap_port}")
        
    def stop(self):
        """Stop all email server protocols."""
        if not self._running:
            return
            
        self._running = False
        
        # Stop HTTP server
        if self._http_server:
            self._http_server.shutdown()
            self._http_server.server_close()
        if self._http_thread:
            self._http_thread.join(timeout=2)
            
        # Stop SMTP server
        if self._smtp_socket:
            try:
                self._smtp_socket.close()
            except:
                pass
        if self._smtp_thread:
            self._smtp_thread.join(timeout=2)
            
        # Stop IMAP server
        if self._imap_socket:
            try:
                self._imap_socket.close()
            except:
                pass
        if self._imap_thread:
            self._imap_thread.join(timeout=2)
            
        print(f"[EmailMockServer] Stopped all protocols")
        
    def clear(self):
        """Clear all captured emails."""
        self.emails.clear()
        print(f"[EmailMockServer] Cleared all emails")
        
    def get_emails(self) -> List[Dict[str, Any]]:
        """Get all captured emails."""
        return self.emails.copy()
        
    def get_email(self, index: int) -> Optional[Dict[str, Any]]:
        """Get a specific email by index."""
        if 0 <= index < len(self.emails):
            return self.emails[index]
        return None
        
    def count_emails(self) -> int:
        """Get the count of captured emails."""
        return len(self.emails)
        
    def find_emails(self, **filters) -> List[Dict[str, Any]]:
        """
        Find emails matching the given filters.
        
        Example:
            find_emails(to="user@example.com", subject="Welcome")
        """
        results = []
        for email_data in self.emails:
            match = True
            for key, value in filters.items():
                if key not in email_data or email_data[key] != value:
                    match = False
                    break
            if match:
                results.append(email_data)
        return results
    
    def _run_smtp_server(self):
        """Run a simple SMTP server to receive emails."""
        self._smtp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._smtp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._smtp_socket.bind((self.host, self.smtp_port))
        self._smtp_socket.listen(5)
        self._smtp_socket.settimeout(1.0)
        
        while self._running:
            try:
                client_socket, addr = self._smtp_socket.accept()
                threading.Thread(target=self._handle_smtp_client, args=(client_socket,), daemon=True).start()
            except socket.timeout:
                continue
            except Exception as e:
                if self._running:
                    print(f"[EmailMockServer] SMTP error: {e}")
                break
    
    def _handle_smtp_client(self, client_socket: socket.socket):
        """Handle SMTP client connection."""
        try:
            client_socket.sendall(b"220 Mock SMTP Server Ready\r\n")
            
            mail_from = None
            rcpt_to = []
            data_mode = False
            email_data = []
            
            while True:
                data = client_socket.recv(4096).decode('utf-8', errors='ignore')
                if not data:
                    break
                
                lines = data.strip().split('\r\n')
                for line in lines:
                    if not line:
                        continue
                    
                    if data_mode:
                        if line == '.':
                            # End of email data
                            data_mode = False
                            email_content = '\r\n'.join(email_data)
                            self._store_smtp_email(mail_from, rcpt_to, email_content)
                            client_socket.sendall(b"250 OK: Message accepted\r\n")
                            email_data = []
                            mail_from = None
                            rcpt_to = []
                        else:
                            email_data.append(line)
                    elif line.upper().startswith('EHLO') or line.upper().startswith('HELO'):
                        client_socket.sendall(b"250 Hello\r\n")
                    elif line.upper().startswith('MAIL FROM:'):
                        mail_from = line[10:].strip().strip('<>')
                        client_socket.sendall(b"250 OK\r\n")
                    elif line.upper().startswith('RCPT TO:'):
                        rcpt_to.append(line[8:].strip().strip('<>'))
                        client_socket.sendall(b"250 OK\r\n")
                    elif line.upper() == 'DATA':
                        data_mode = True
                        client_socket.sendall(b"354 Start mail input; end with <CRLF>.<CRLF>\r\n")
                    elif line.upper() == 'QUIT':
                        client_socket.sendall(b"221 Bye\r\n")
                        return
                    else:
                        client_socket.sendall(b"250 OK\r\n")
        except Exception as e:
            print(f"[EmailMockServer] SMTP client error: {e}")
        finally:
            client_socket.close()
    
    def _store_smtp_email(self, mail_from: str, rcpt_to: List[str], raw_content: str):
        """Parse and store an SMTP email."""
        try:
            msg = email.message_from_string(raw_content)
            
            # Extract email details
            subject = msg.get('Subject', '')
            to = msg.get('To', ', '.join(rcpt_to) if rcpt_to else '')
            from_addr = msg.get('From', mail_from or '')
            
            # Get body
            body = ""
            if msg.is_multipart():
                for part in msg.walk():
                    if part.get_content_type() == "text/plain":
                        body = part.get_payload(decode=True).decode('utf-8', errors='ignore')
                        break
            else:
                body = msg.get_payload(decode=True)
                if body:
                    body = body.decode('utf-8', errors='ignore')
                else:
                    body = msg.get_payload()
            
            email_data = {
                "index": len(self.emails),
                "uid": self._next_uid,
                "to": to,
                "from": from_addr,
                "subject": subject,
                "body": body,
                "raw": raw_content,
                "received_at": datetime.utcnow().isoformat(),
                "flags": []
            }
            
            self._next_uid += 1
            self.emails.append(email_data)
            
            print(f"[EmailMockServer] SMTP captured email #{email_data['index']}: "
                  f"from={from_addr}, to={to}, subject={subject}")
        except Exception as e:
            print(f"[EmailMockServer] Error parsing SMTP email: {e}")
    
    def _run_imap_server(self):
        """Run a simple IMAP server to allow checking emails."""
        self._imap_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._imap_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._imap_socket.bind((self.host, self.imap_port))
        self._imap_socket.listen(5)
        self._imap_socket.settimeout(1.0)
        
        while self._running:
            try:
                client_socket, addr = self._imap_socket.accept()
                threading.Thread(target=self._handle_imap_client, args=(client_socket,), daemon=True).start()
            except socket.timeout:
                continue
            except Exception as e:
                if self._running:
                    print(f"[EmailMockServer] IMAP error: {e}")
                break
    
    def _handle_imap_client(self, client_socket: socket.socket):
        """Handle IMAP client connection."""
        try:
            client_socket.sendall(b"* OK Mock IMAP Server Ready\r\n")
            
            authenticated = False
            selected_mailbox = None
            
            while True:
                data = client_socket.recv(4096).decode('utf-8', errors='ignore')
                if not data:
                    break
                
                lines = data.strip().split('\r\n')
                for line in lines:
                    if not line:
                        continue
                    
                    parts = line.split(' ', 2)
                    if len(parts) < 2:
                        continue
                    
                    tag = parts[0]
                    command = parts[1].upper()
                    args = parts[2] if len(parts) > 2 else ""
                    
                    if command == 'CAPABILITY':
                        client_socket.sendall(b"* CAPABILITY IMAP4rev1\r\n")
                        client_socket.sendall(f"{tag} OK CAPABILITY completed\r\n".encode())
                    
                    elif command == 'LOGIN':
                        authenticated = True
                        client_socket.sendall(f"{tag} OK LOGIN completed\r\n".encode())
                    
                    elif command == 'SELECT' or command == 'EXAMINE':
                        if not authenticated:
                            client_socket.sendall(f"{tag} NO Not authenticated\r\n".encode())
                            continue
                        
                        selected_mailbox = "INBOX"
                        count = len(self.emails)
                        client_socket.sendall(f"* {count} EXISTS\r\n".encode())
                        client_socket.sendall(b"* 0 RECENT\r\n")
                        client_socket.sendall(b"* FLAGS (\\Seen \\Answered \\Flagged \\Deleted \\Draft)\r\n")
                        client_socket.sendall(f"{tag} OK [{command}] completed\r\n".encode())
                    
                    elif command == 'FETCH':
                        if not authenticated or not selected_mailbox:
                            client_socket.sendall(f"{tag} NO Not authenticated or no mailbox selected\r\n".encode())
                            continue
                        
                        # Parse FETCH command: e.g., "1:* (FLAGS BODY[])"
                        fetch_parts = args.split(' ', 1)
                        sequence = fetch_parts[0]
                        items = fetch_parts[1] if len(fetch_parts) > 1 else "(FLAGS)"
                        
                        # Simple implementation: fetch all emails
                        for i, email_data in enumerate(self.emails, 1):
                            response_items = []
                            
                            if 'FLAGS' in items:
                                flags = ' '.join(email_data.get('flags', []))
                                response_items.append(f"FLAGS ({flags})")
                            
                            if 'BODY[]' in items or 'RFC822' in items:
                                raw = email_data.get('raw', '')
                                if not raw:
                                    # Construct simple email if raw not available
                                    raw = f"From: {email_data.get('from', '')}\r\n"
                                    raw += f"To: {email_data.get('to', '')}\r\n"
                                    raw += f"Subject: {email_data.get('subject', '')}\r\n"
                                    raw += f"\r\n{email_data.get('body', '')}"
                                
                                response_items.append(f"BODY[] {{{len(raw.encode())}}}\r\n{raw}")
                            
                            if 'BODY[HEADER.FIELDS (SUBJECT)]' in items or 'ENVELOPE' in items:
                                subject = email_data.get('subject', '')
                                response_items.append(f"BODY[HEADER.FIELDS (SUBJECT)] {{Subject: {subject}}}")
                            
                            response = f"* {i} FETCH ({' '.join(response_items)})\r\n"
                            client_socket.sendall(response.encode())
                        
                        client_socket.sendall(f"{tag} OK FETCH completed\r\n".encode())
                    
                    elif command == 'SEARCH':
                        if not authenticated or not selected_mailbox:
                            client_socket.sendall(f"{tag} NO Not authenticated or no mailbox selected\r\n".encode())
                            continue
                        
                        # Simple SEARCH implementation - return all emails
                        matches = ' '.join(str(i) for i in range(1, len(self.emails) + 1))
                        client_socket.sendall(f"* SEARCH {matches}\r\n".encode())
                        client_socket.sendall(f"{tag} OK SEARCH completed\r\n".encode())
                    
                    elif command == 'LOGOUT':
                        client_socket.sendall(b"* BYE Logging out\r\n")
                        client_socket.sendall(f"{tag} OK LOGOUT completed\r\n".encode())
                        return
                    
                    else:
                        client_socket.sendall(f"{tag} BAD Command not recognized\r\n".encode())
        
        except Exception as e:
            print(f"[EmailMockServer] IMAP client error: {e}")
        finally:
            client_socket.close()
        
    def _create_http_handler(self):
        """Create the HTTP request handler with access to this server instance."""
        server_instance = self
        
        class EmailMockHandler(BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                """Suppress default logging."""
                pass
                
            def _send_json_response(self, status: int, data: Any):
                """Send a JSON response."""
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(json.dumps(data).encode())
                
            def do_OPTIONS(self):
                """Handle CORS preflight requests."""
                self.send_response(200)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
                self.send_header("Access-Control-Allow-Headers", "Content-Type")
                self.end_headers()
                
            def do_POST(self):
                """Handle POST requests to capture emails."""
                if self.path == "/send":
                    content_length = int(self.headers.get("Content-Length", 0))
                    body = self.rfile.read(content_length).decode("utf-8")
                    
                    try:
                        email_data = json.loads(body)
                        email_data["received_at"] = datetime.utcnow().isoformat()
                        email_data["index"] = len(server_instance.emails)
                        server_instance.emails.append(email_data)
                        
                        print(f"[EmailMockServer] Captured email #{email_data['index']}: "
                              f"to={email_data.get('to', 'N/A')}, "
                              f"subject={email_data.get('subject', 'N/A')}")
                        
                        self._send_json_response(200, {
                            "status": "success",
                            "message": "Email captured",
                            "index": email_data["index"]
                        })
                    except json.JSONDecodeError:
                        self._send_json_response(400, {
                            "status": "error",
                            "message": "Invalid JSON"
                        })
                else:
                    self._send_json_response(404, {
                        "status": "error",
                        "message": "Not found"
                    })
                    
            def do_GET(self):
                """Handle GET requests to query emails."""
                if self.path == "/emails":
                    self._send_json_response(200, {
                        "count": len(server_instance.emails),
                        "emails": server_instance.emails
                    })
                elif self.path.startswith("/emails/"):
                    try:
                        index = int(self.path.split("/")[-1])
                        email = server_instance.get_email(index)
                        if email:
                            self._send_json_response(200, email)
                        else:
                            self._send_json_response(404, {
                                "status": "error",
                                "message": f"Email at index {index} not found"
                            })
                    except ValueError:
                        self._send_json_response(400, {
                            "status": "error",
                            "message": "Invalid index"
                        })
                elif self.path == "/health":
                    self._send_json_response(200, {
                        "status": "healthy",
                        "emails_count": len(server_instance.emails)
                    })
                else:
                    self._send_json_response(404, {
                        "status": "error",
                        "message": "Not found"
                    })
                    
            def do_DELETE(self):
                """Handle DELETE requests to clear emails."""
                if self.path == "/emails":
                    server_instance.clear()
                    self._send_json_response(200, {
                        "status": "success",
                        "message": "All emails cleared"
                    })
                else:
                    self._send_json_response(404, {
                        "status": "error",
                        "message": "Not found"
                    })
        
        return EmailMockHandler
