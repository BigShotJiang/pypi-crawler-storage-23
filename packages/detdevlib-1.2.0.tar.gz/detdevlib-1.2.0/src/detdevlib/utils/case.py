"""A simple utility for converting strings between different naming conventions."""

import re
from collections import defaultdict, deque
from enum import Enum, auto
from typing import Callable


class Case(Enum):
    """Enum of all supported casing styles."""

    SNAKE = auto()
    SCREAMING_SNAKE = auto()
    PASCAL = auto()
    CAMEL = auto()
    KEBAB = auto()


ConversionFunc = Callable[[str], str]


class ConversionManager:
    """Manages string case conversions using a graph-based approach.

    This manager allows registering specific conversion functions between cases
    and automatically finds the shortest path for multistep conversions.
    """

    def __init__(self):
        """Initialize an empty ConversionManager."""
        self._conversions: dict[tuple[Case, Case], ConversionFunc] = {}
        self._adj = defaultdict(list)

    def add_conversion(self, from_case: Case, to_case: Case):
        """Decorator to register case conversion functions and update graph."""

        def decorator(func: ConversionFunc) -> ConversionFunc:
            self._conversions[(from_case, to_case)] = func
            self._adj[from_case].append(to_case)
            return func

        return decorator

    def get_conversion(self, from_case: Case, to_case: Case) -> ConversionFunc:
        """Finds the shortest path and returns a composite conversion function."""
        # BFS to find the shortest path
        queue: deque[tuple[Case, list[Case]]] = deque()
        queue.append((from_case, [from_case]))
        visited: set[Case] = {from_case}
        path: list[Case] | None = None

        while queue:
            current_case, current_path = queue.popleft()

            if current_case == to_case:
                path = current_path
                break

            for neighbour_case in self._adj[current_case]:
                if neighbour_case not in visited:
                    visited.add(neighbour_case)
                    queue.append((neighbour_case, current_path + [neighbour_case]))

        if path is None:
            raise ValueError(f"No conversion path found from {from_case} to {to_case}")
        path: list[Case]

        # Construct the composite function
        steps = [
            self._conversions[(path[i], path[i + 1])] for i in range(len(path) - 1)
        ]

        def composite_conversion(text: str) -> str:
            for step in steps:
                text = step(text)
            return text

        return composite_conversion


_CONVERSIONS: dict[tuple[Case, Case], ConversionFunc] = {}
converter = ConversionManager()


@converter.add_conversion(Case.SNAKE, Case.KEBAB)
def _snake_to_kebab(text: str) -> str:
    return text.replace("_", "-")


@converter.add_conversion(Case.KEBAB, Case.SNAKE)
def _kebab_to_snake(text: str) -> str:
    return text.replace("-", "_")


@converter.add_conversion(Case.SNAKE, Case.SCREAMING_SNAKE)
def _snake_to_screaming_snake(text: str) -> str:
    return text.upper()


@converter.add_conversion(Case.SCREAMING_SNAKE, Case.SNAKE)
def _screaming_snake_to_snake(text: str) -> str:
    return text.lower()


@converter.add_conversion(Case.SNAKE, Case.PASCAL)
def _snake_to_pascal(text: str) -> str:
    return "".join(word.capitalize() for word in text.split("_"))


@converter.add_conversion(Case.PASCAL, Case.SNAKE)
def _pascal_to_snake(text: str) -> str:
    return "_".join(word.lower() for word in re.findall(r"[A-Z][a-z0-9]*", text))


@converter.add_conversion(Case.PASCAL, Case.CAMEL)
def _pascal_to_camel(text: str) -> str:
    if text == "":
        return ""
    return text[0].lower() + text[1:]


@converter.add_conversion(Case.CAMEL, Case.PASCAL)
def _camel_to_pascal(text: str) -> str:
    if text == "":
        return ""
    return text[0].upper() + text[1:]
