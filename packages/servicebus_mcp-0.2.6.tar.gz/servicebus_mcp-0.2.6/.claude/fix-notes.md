# Bug Fix Needed

## The Problem

`src/servicebus_mcp/tools/send_message.py` line 35 calls `client.get_queue_or_topic_sender(queue)` but that method does not exist on `ServiceBusClient` in azure-servicebus 7.12+. The available methods are `get_queue_sender` and `get_topic_sender`.

Fix line 35:

```python
# Before
with client.get_queue_or_topic_sender(queue) as sender:

# After
with client.get_queue_sender(queue) as sender:
```

Check if the same pattern appears in any other tool files (peek, purge, requeue, etc.) and fix those too.

When you think you've fixed it, call the code directly and try to send the message described at the bottom of this file to verify the fix works end-to-end.

## After Fixing

Bump the version in `pyproject.toml` and publish to PyPI.

Then update the MCP server config to pick up the new version:

```bash
claude mcp remove azure-service-bus -s user
claude mcp add --scope user azure-service-bus -- uvx servicebus-mcp
```

## Test Message to Send

Once fixed, send this message to verify the assetcfg-worker fleet adapter onboarding path works end-to-end:

- **Namespace**: `shdapps-dev1-eus2-sbn`
- **Queue**: `onboard-vehicles`
- **Body**: contents of `/Users/mzxt2g/Documents/Development/assetcfg-worker/.claude/onboard-vehicles-test-message.json`

Expected result: the service logs a WARN-level "Would have initiated batch boarding" message with the two vehicle entries. No CosmosDB writes, no queue sends — both paths are stubbed.
