# GEMINI.md - cz-fogoprobr

## Project Overview
`cz-fogoprobr` is a custom **Commitizen adapter** (plugin) that implements a specific set of rules for Git commit messages. It follows a variation of the Conventional Commits specification, allowing for optional scopes and breaking change indicators (`!`) in the header.

### Core Technologies
- **Python 3.9+**: Primary programming language.
- **Commitizen**: The framework this plugin extends.
- **Hatchling**: Build backend and project manager.
- **Pytest**: For unit testing.
- **Ruff**: For linting and code formatting.

### Architecture
- `src/cz_fogoprobr/`: Main package directory.
  - `cz_fogoprobr.py`: Contains the `CzFogoprobr` class inheriting from `BaseCommitizen`.
  - `spec.py`: Defines the commit types, regex patterns (`SCHEMA_PATTERN`, `BUMP_PATTERN`), and bump mapping.
- `tests/`: Contains `pytest` suites to verify regex matching and plugin behavior.

## Building and Running

### Development Setup
To set up the development environment, install the project with development dependencies:
```bash
pip install -e ".[dev]"
```

### Key Commands
- **Linting**: `ruff check .`
- **Testing**: `pytest`
- **Build**: `python -m build`
- **Plugin Info**: `cz --name cz_fogoprobr info`
- **Interactive Commit**: `cz --name cz_fogoprobr commit`
- **Version Bump**: `cz --name cz_fogoprobr bump`

## Development Conventions

### Commit Message Format
The project enforces the following header format:
`<type>(<scope>)!: <subject>`

An optional long description (**body**) can be provided:
```
<type>(<scope>)!: <subject>

<body>
```

- **Types**: `feat`, `fix`, `docs`, `refactor`, `perf`, `test`, `chore`.
- **Scope**: Optional, enclosed in parentheses.
- **Breaking Change**: Indicated by an optional `!` before the colon or `BREAKING CHANGE` in the body/footer.
- **Subject**: Imperative mood, between 5 and 72 characters.
- **Body**: Optional, separated from the subject by a blank line. Supports multi-line text (use `\n` in prompt).

### Coding Style
- Follows standard Python typing practices (uses `from __future__ import annotations`).
- Uses `ruff` for linting with a line length of 100.
- Logic should be separated: data and patterns in `spec.py`, logic in `cz_fogoprobr.py`.

### Testing Guidelines
- All new features or changes to the `SCHEMA_PATTERN` must be accompanied by tests in `tests/test_cz_fogoprobr.py`.
- Ensure regex groups (`type`, `scope`, `breaking`, `subject`) are correctly captured.
