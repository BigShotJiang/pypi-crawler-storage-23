# pylint: disable-all
from __future__ import annotations

from cleo.commands.command import Command as BaseCommand


class Command(BaseCommand):

    def handle(self):
        pass
