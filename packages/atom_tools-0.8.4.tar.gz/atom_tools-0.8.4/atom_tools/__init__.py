"""
A cli, classes and functions for converting an atom slice to a different format
"""
__version__ = '0.8.4'
