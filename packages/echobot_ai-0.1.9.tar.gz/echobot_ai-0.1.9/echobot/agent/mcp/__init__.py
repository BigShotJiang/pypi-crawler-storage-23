# 中文注释：
# 文件：echobot/agent/mcp/__init__.py
# 说明：MCP 客户端模块

"""MCP client module for connecting to MCP servers."""

from echobot.agent.mcp.client import MCPClient

__all__ = ["MCPClient"]
