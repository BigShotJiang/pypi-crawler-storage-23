# 中文注释：
# 文件：echobot/__init__.py
# 说明：项目核心源码。

"""
echobot - 轻量级 AI 助手框架
=================================================

echobot 是一个轻量级的 AI 助手框架，支持：
- 多种 LLM 提供商（OpenRouter、Anthropic、OpenAI、Claude 等）
- 多平台集成（Telegram）
- 工具调用（文件操作、Shell 命令、Web 搜索等）
- 任务调度（定时任务）
- 持久化会话管理

主要组件：
- Agent Loop: 核心处理引擎，负责消息处理和工具调用
- Channels: 聊天平台集成（Telegram）
- Providers: LLM 接口抽象层
- Tools: Agent 可用的工具集
- Bus: 消息总线，解耦各组件

使用方式：
    python -m echobot agent -m "Hello!"
    python -m echobot gateway  # 启动服务

版本: 0.1.0
"""

__version__ = "0.1.0"
__logo__ = "🐈"
