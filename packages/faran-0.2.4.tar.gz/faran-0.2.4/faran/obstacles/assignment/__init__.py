from .basic import (
    NumPyHungarianObstacleIdAssignment as NumPyHungarianObstacleIdAssignment,
)
from .accelerated import (
    JaxHungarianObstacleIdAssignment as JaxHungarianObstacleIdAssignment,
)
