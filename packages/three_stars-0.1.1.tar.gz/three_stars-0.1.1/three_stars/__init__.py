"""three-stars: Deploy AI-powered web applications to AWS with a single command."""

__version__ = "0.1.0"
