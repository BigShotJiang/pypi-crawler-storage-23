from enum import Enum


class Project(Enum):
    SCHOOL_DISTRICT = "School District"
    MEDICARE = "Medicare"
    SECURE_BANK = "SecureBank-Support"
    TIME_OFF = "Time-Off"
