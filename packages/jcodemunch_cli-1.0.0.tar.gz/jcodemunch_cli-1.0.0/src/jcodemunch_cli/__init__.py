"""jCodeMunch CLI - Token-efficient code exploration via MCP."""

__version__ = "1.0.0"
