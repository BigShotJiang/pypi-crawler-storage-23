#!/usr/bin/env python3
"""
jCodeMunch CLI - Thin wrapper for jcodemunch-mcp
Uses uvx to always stay up to date with the latest jcodemunch-mcp.
"""

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path

# Add common paths
os.environ["PATH"] = "/home/linuxbrew/.linuxbrew/bin:/usr/local/bin:" + os.environ.get("PATH", "")

try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
except ImportError:
    print("Error: mcp package required. Install with: pip install mcp", file=sys.stderr)
    sys.exit(1)


# Configuration - can be overridden via environment
DEFAULT_ENV_VARS = {
    "GITHUB_TOKEN": os.environ.get("GITHUB_TOKEN", ""),
    "OPENAI_API_KEY": os.environ.get("OPENAI_API_KEY", ""),
    "OPENAI_API_BASE": os.environ.get("OPENAI_API_BASE", "https://api.minimax.chat/v1"),
    "ANTHROPIC_API_KEY": os.environ.get("ANTHROPIC_API_KEY", ""),
    "GOOGLE_API_KEY": os.environ.get("GOOGLE_API_KEY", ""),
}


def get_env():
    """Get environment variables for MCP, filtering empty values."""
    return {k: v for k, v in DEFAULT_ENV_VARS.items() if v}


@asynccontextmanager
async def get_session():
    """Create and manage MCP session."""
    env = {**os.environ, **get_env()}
    
    server_params = StdioServerParameters(
        command="uvx",
        args=["jcodemunch-mcp"],
        env=env,
    )
    
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            yield session


async def cmd_list_tools() -> dict:
    """List available MCP tools."""
    async with get_session() as session:
        tools = await session.list_tools()
        return {"tools": [{"name": t.name, "description": t.description} for t in tools.tools]}


async def cmd_index_folder(path: str) -> dict:
    """Index a local folder."""
    async with get_session() as session:
        result = await session.call_tool("index_folder", {"path": path})
        return {"result": str(result)}


async def cmd_index_repo(url: str) -> dict:
    """Index a GitHub repository."""
    async with get_session() as session:
        result = await session.call_tool("index_repo", {"url": url})
        return {"result": str(result)}


async def cmd_search_symbols(repo: str, query: str) -> dict:
    """Search for symbols in a repository."""
    async with get_session() as session:
        result = await session.call_tool("search_symbols", {"repo": repo, "query": query})
        return {"result": str(result)}


async def cmd_get_symbol(repo: str, symbol_id: str) -> dict:
    """Get a specific symbol's code."""
    async with get_session() as session:
        result = await session.call_tool("get_symbol", {"repo": repo, "symbol_id": symbol_id})
        return {"result": str(result)}


async def cmd_get_file_outline(repo: str, file_path: str) -> dict:
    """Get all symbols in a file."""
    async with get_session() as session:
        result = await session.call_tool("get_file_outline", {"repo": repo, "file_path": file_path})
        return {"result": str(result)}


async def cmd_get_repo_outline(repo: str) -> dict:
    """Get high-level repository overview."""
    async with get_session() as session:
        result = await session.call_tool("get_repo_outline", {"repo": repo})
        return {"result": str(result)}


async def cmd_search_text(repo: str, query: str) -> dict:
    """Full-text search in repository."""
    async with get_session() as session:
        result = await session.call_tool("search_text", {"repo": repo, "query": query})
        return {"result": str(result)}


async def cmd_list_repos() -> dict:
    """List indexed repositories."""
    async with get_session() as session:
        result = await session.call_tool("list_repos", {})
        return {"result": str(result)}


def main():
    parser = argparse.ArgumentParser(
        description="jCodeMunch CLI - Token-efficient code exploration",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Environment Variables:
  GITHUB_TOKEN       GitHub token for private repos (optional)
  OPENAI_API_KEY     API key for AI summaries (optional)
  OPENAI_API_BASE    API base URL (default: https://api.minimax.chat/v1)
  ANTHROPIC_API_KEY  Anthropic key for Claude summaries (optional)
  GOOGLE_API_KEY     Google key for Gemini summaries (optional)

Examples:
  jcodemunch index-repo owner/repo
  jcodemunch search-symbols --repo owner/repo login
  jcodemunch get-symbol --repo owner/repo "src/main.py::User#class"
  jcodemunch file-outline --repo owner/repo src/main.py
        """
    )
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # list-tools
    subparsers.add_parser("list-tools", help="List available MCP tools")
    
    # index-folder
    p_index_folder = subparsers.add_parser("index-folder", help="Index a local folder")
    p_index_folder.add_argument("path", help="Path to folder")
    
    # index-repo
    p_index_repo = subparsers.add_parser("index-repo", help="Index a GitHub repository")
    p_index_repo.add_argument("url", help="Repository URL (owner/repo)")
    
    # search-symbols
    p_search = subparsers.add_parser("search-symbols", help="Search symbols")
    p_search.add_argument("--repo", required=True, help="Repository (owner/repo)")
    p_search.add_argument("query", help="Search query")
    
    # get-symbol
    p_get = subparsers.add_parser("get-symbol", help="Get symbol code")
    p_get.add_argument("--repo", required=True, help="Repository (owner/repo)")
    p_get.add_argument("symbol_id", help="Symbol ID (path::name#kind)")
    
    # file-outline
    p_outline = subparsers.add_parser("file-outline", help="Get file outline")
    p_outline.add_argument("--repo", required=True, help="Repository (owner/repo)")
    p_outline.add_argument("file_path", help="File path")
    
    # repo-outline
    p_repo_outline = subparsers.add_parser("repo-outline", help="Get repo overview")
    p_repo_outline.add_argument("repo", help="Repository (owner/repo)")
    
    # search-text
    p_text = subparsers.add_parser("search-text", help="Full-text search")
    p_text.add_argument("--repo", required=True, help="Repository (owner/repo)")
    p_text.add_argument("query", help="Search query")
    
    # list-repos
    subparsers.add_parser("list-repos", help="List indexed repositories")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    try:
        if args.command == "list-tools":
            result = asyncio.run(cmd_list_tools())
        elif args.command == "index-folder":
            result = asyncio.run(cmd_index_folder(args.path))
        elif args.command == "index-repo":
            result = asyncio.run(cmd_index_repo(args.url))
        elif args.command == "search-symbols":
            result = asyncio.run(cmd_search_symbols(args.repo, args.query))
        elif args.command == "get-symbol":
            result = asyncio.run(cmd_get_symbol(args.repo, args.symbol_id))
        elif args.command == "file-outline":
            result = asyncio.run(cmd_get_file_outline(args.repo, args.file_path))
        elif args.command == "repo-outline":
            result = asyncio.run(cmd_get_repo_outline(args.repo))
        elif args.command == "search-text":
            result = asyncio.run(cmd_search_text(args.repo, args.query))
        elif args.command == "list-repos":
            result = asyncio.run(cmd_list_repos())
        
        print(json.dumps(result, indent=2))
        
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
