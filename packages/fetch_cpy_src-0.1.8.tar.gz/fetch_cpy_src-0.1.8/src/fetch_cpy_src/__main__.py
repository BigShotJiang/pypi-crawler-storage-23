""" expose module entry as cli """
from fetch_cpy_src.cli import cli_app

if __name__ == '__main__':
    cli_app()
