"""
scrapy-common-downloadhandler

A composite Scrapy download handler that integrates cloudscraper,
curl_cffi (via scrapy-impersonate), and Twisted HTTP/1.1 into one handler
with per-request routing via request.meta.
"""

from .handler import CommonDownloadHandler

__version__ = "0.1.0"
__all__ = ["CommonDownloadHandler"]
