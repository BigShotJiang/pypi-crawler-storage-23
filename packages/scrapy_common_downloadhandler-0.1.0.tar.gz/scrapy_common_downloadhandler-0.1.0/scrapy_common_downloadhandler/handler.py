import logging
import time

import cloudscraper
from scrapy.http.headers import Headers
from scrapy.http.request import Request
from scrapy.http.response import Response
from scrapy.responsetypes import responsetypes
from scrapy.spiders import Spider
from scrapy_impersonate import ImpersonateDownloadHandler
from twisted.internet import threads
from twisted.internet.defer import Deferred

logger = logging.getLogger(__name__)


class CommonDownloadHandler(ImpersonateDownloadHandler):
    """Composite download handler with per-request routing via request.meta:

    - meta["use_cloudscraper"] = True  -> cloudscraper (sync, via deferToThread)
    - meta["impersonate"] = "chrome"   -> curl_cffi (ImpersonateDownloadHandler)
    - neither                          -> Twisted HTTP/1.1 (HTTP11DownloadHandler)

    Parameter passthrough:
        meta["cloudscraper_args"] dict is passed to cloudscraper.create_scraper(**args)
    """

    def __init__(self, crawler) -> None:
        super().__init__(crawler)

    def download_request(self, request: Request, spider: Spider) -> Deferred:
        if request.meta.get("use_cloudscraper"):
            return self._cloudscraper_download(request, spider)
        return super().download_request(request, spider)

    def _cloudscraper_download(self, request: Request, spider: Spider) -> Deferred:
        return threads.deferToThread(self._sync_download, request)

    def _sync_download(self, request: Request) -> Response:
        scraper_args = request.meta.get("cloudscraper_args", {})
        scraper = cloudscraper.create_scraper(**scraper_args)

        proxy = request.meta.get("proxy")
        proxies = {"http": proxy, "https": proxy} if proxy else None
        req_headers = {k.decode(): v[0].decode() for k, v in request.headers.items()}
        body = request.body if request.body != b"" else None

        start_time = time.time()
        resp = scraper.request(
            method=request.method, url=request.url,
            headers=req_headers, data=body,
            proxies=proxies, allow_redirects=False,
        )
        download_latency = time.time() - start_time

        headers = Headers(dict(resp.headers))
        headers.pop("Content-Encoding", None)

        respcls = responsetypes.from_args(headers=headers, url=resp.url, body=resp.content)
        response = respcls(
            url=resp.url, status=resp.status_code,
            headers=headers, body=resp.content,
            flags=["cloudscraper"], request=request,
        )
        response.meta["download_latency"] = download_latency

        logger.debug("cloudscraper download done %s status:%s latency:%.2fs",
                      request.url, resp.status_code, download_latency)
        return response
