# scrapy-common-downloadhandler

组合下载处理器，将 **cloudscraper**、**curl_cffi**（通过 [scrapy-impersonate](https://github.com/jxlil/scrapy-impersonate)）和 **Twisted HTTP/1.1** 三种下载能力集成到一个 Scrapy Download Handler 中，通过 `request.meta` 按请求级别自动分流。

## 继承链

```
HTTP11DownloadHandler             <- Twisted HTTP/1.1（兜底）
  └── ImpersonateDownloadHandler  <- curl_cffi（meta["impersonate"] 存在时）
        └── CommonDownloadHandler <- cloudscraper（meta["use_cloudscraper"] 为 True 时）
```

## 安装

```bash
pip install scrapy-common-downloadhandler
```

## 快速开始

### 1. 配置下载处理器

在项目 `settings.py` 或 Spider 的 `custom_settings` 中配置：

```python
DOWNLOAD_HANDLERS = {
    "http": "scrapy_common_downloadhandler.CommonDownloadHandler",
    "https": "scrapy_common_downloadhandler.CommonDownloadHandler",
}
USER_AGENT = ""
```

`USER_AGENT` 必须设为空字符串。Scrapy 的 `UserAgentMiddleware` 默认会往请求注入 `User-Agent: Scrapy/x.x.x`，而 curl_cffi 在模拟浏览器时会自动携带对应浏览器的真实 User-Agent。如果不置空，Scrapy 注入的 User-Agent 会与 curl_cffi 的 TLS 指纹不匹配，导致被反爬系统识别。

不需要任何其他额外开关，配置后三种下载能力自动可用。

### 2. 在 Spider 中使用

```python
import scrapy

class MySpider(scrapy.Spider):
    name = "example"

    def start_requests(self):
        # cloudscraper
        yield scrapy.Request(url, meta={"use_cloudscraper": True}, callback=self.parse)

        # curl_cffi impersonate
        yield scrapy.Request(url, meta={"impersonate": "chrome"}, callback=self.parse)

        # 默认 Twisted HTTP/1.1
        yield scrapy.Request(url, callback=self.parse)
```

## 使用方式

### cloudscraper 请求

```python
# 基础用法
yield scrapy.Request(url, meta={"use_cloudscraper": True}, callback=self.parse)

# 透传 create_scraper() 参数
yield scrapy.Request(url, meta={
    "use_cloudscraper": True,
    "cloudscraper_args": {
        "browser": {"browser": "chrome", "mobile": False, "platform": "windows"},
        "delay": 10,
        "interpreter": "nodejs",
    },
}, callback=self.parse)
```

`cloudscraper_args` 字典中的所有键值会透传给 `cloudscraper.create_scraper(**args)`，支持 cloudscraper 的全部初始化参数。

### curl_cffi impersonate 请求

```python
# 基础用法
yield scrapy.Request(url, meta={"impersonate": "chrome"}, callback=self.parse)

# 透传额外参数
yield scrapy.Request(url, meta={
    "impersonate": "chrome",
    "impersonate_args": {"timeout": 30},
}, callback=self.parse)
```

`impersonate_args` 字典中的参数会透传给 curl_cffi 的请求方法，详见 [scrapy-impersonate](https://github.com/jxlil/scrapy-impersonate) 文档。

### 默认 Twisted HTTP/1.1 请求

```python
# 不设任何特殊 meta，走 Scrapy 默认下载器
yield scrapy.Request(url, callback=self.parse)
```

## 参数透传对照

| 下载方式 | meta 标记 | 透传参数 | 透传目标 |
|---|---|---|---|
| cloudscraper | `use_cloudscraper: True` | `cloudscraper_args: {}` | `cloudscraper.create_scraper(**args)` |
| curl_cffi | `impersonate: "chrome"` | `impersonate_args: {}` | `curl_cffi` 请求方法参数 |
| Twisted | 不设 | 无 | 使用 Scrapy 默认配置 |

## 代理兼容

代理中间件往 `request.meta["proxy"]` 写入代理地址后，三种模式都能正常使用：

- **cloudscraper**：转换为 `proxies={"http": proxy, "https": proxy}` 传入
- **curl_cffi**：由 `ImpersonateDownloadHandler` 的 `RequestParser` 自动读取
- **Twisted**：由 Scrapy 内置的 `HttpProxyMiddleware` 自动处理

## scrapy-redis 兼容性

完全兼容。scrapy-redis 只负责调度（Scheduler）和去重（DupeFilter），不涉及下载层。

## 响应标识

可通过 `response.flags` 区分下载方式：

- `"cloudscraper"` in `response.flags` — 通过 cloudscraper 下载
- `"impersonate"` in `response.flags` — 通过 curl_cffi 下载
- 都不在 — 通过 Twisted HTTP/1.1 下载

## 注意事项

1. **必须设置 `USER_AGENT = ""`**。否则 Scrapy 的 `UserAgentMiddleware` 会在请求到达下载处理器之前注入默认 User-Agent，覆盖 curl_cffi 模拟浏览器时自动携带的真实 User-Agent，导致 TLS 指纹与 User-Agent 不匹配
2. cloudscraper 是同步库（基于 requests），Handler 内部通过 `deferToThread` 将同步调用放入线程池执行，不会阻塞 Twisted reactor
3. cloudscraper 内部重定向已禁用（`allow_redirects=False`），重定向由 Scrapy 的 `RedirectMiddleware` 统一处理
4. 响应的 `Content-Encoding` 头会被移除，解压由 Scrapy 的 `HttpCompressionMiddleware` 处理
5. Scrapy 默认 reactor 已是 `AsyncioSelectorReactor`，无需额外配置 `TWISTED_REACTOR`

## 许可证

MIT
