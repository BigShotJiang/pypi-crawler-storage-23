# Changelog

## 0.1.0 (2026-02-27)

- Initial release
- `CommonDownloadHandler`: composite download handler inheriting from `ImpersonateDownloadHandler`
- Three download modes via `request.meta`:
  - `use_cloudscraper: True` — cloudscraper (synchronous, runs in thread pool)
  - `impersonate: "chrome"` — curl_cffi via scrapy-impersonate
  - Default — Twisted HTTP/1.1
- `cloudscraper_args` parameter passthrough to `cloudscraper.create_scraper()`
- Proxy support via `request.meta["proxy"]`
- Full compatibility with scrapy-redis
