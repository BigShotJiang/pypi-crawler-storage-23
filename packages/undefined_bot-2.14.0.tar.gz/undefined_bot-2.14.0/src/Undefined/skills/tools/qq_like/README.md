# qq_like 工具

用于给指定 QQ 资料卡点赞。

常用参数：
- `target_user_id`：目标 QQ 号
- `times`：点赞次数（默认 10）

目录结构：
- `config.json`：工具定义
- `handler.py`：执行逻辑
