"""Backward-compatible shim for MCP registry imports."""

from Undefined.mcp import MCPToolRegistry, MCPToolSetRegistry

__all__ = ["MCPToolRegistry", "MCPToolSetRegistry"]
