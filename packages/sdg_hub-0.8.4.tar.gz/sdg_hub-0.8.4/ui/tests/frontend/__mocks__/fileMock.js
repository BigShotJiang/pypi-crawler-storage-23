// SPDX-License-Identifier: Apache-2.0
/**
 * Mock for file imports in Jest tests.
 */

module.exports = 'test-file-stub';

