from enum import Enum


class UITypes(Enum):
    cli = "cli"
    gui = "gui"
