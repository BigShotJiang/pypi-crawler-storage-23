Scenarios
*********

Scenarios describe **what you need**. They define the tests and the necessary devices for them. Here you can find all
scenarios that are implemented in this BalderHub package.


.. autoclass:: balderhub.waveformmonitor.scenarios.ScenarioPlayAndRecord
    :members:
