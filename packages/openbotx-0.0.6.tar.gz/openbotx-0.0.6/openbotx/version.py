__version__ = "0.0.6"
__version_info__ = tuple(int(x) for x in __version__.split("-")[0].split("."))
