from openbotx.cli.commands import cli

cli()
