"""Vector-based diverse test case selection for Robot Framework."""

__version__ = "0.1.0"
