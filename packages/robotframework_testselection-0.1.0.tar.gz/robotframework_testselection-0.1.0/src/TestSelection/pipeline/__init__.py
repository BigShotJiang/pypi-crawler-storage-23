"""Pipeline bounded context: stage orchestration, caching, and artifact management."""
