"""Shared kernel: value objects, types, and configuration."""
