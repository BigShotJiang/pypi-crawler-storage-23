"""
Side-by-side comparison: calling OpenAI directly vs. through Pikarc.
"""

from __future__ import annotations

from pikarc import AsyncPikarc, PikarcBlockedError
from openai import AsyncOpenAI

openai = AsyncOpenAI()  # uses OPENAI_API_KEY env var


# ---------------------------------------------------------------------------
# A) Direct OpenAI call — no guardrails
# ---------------------------------------------------------------------------
async def direct_openai(user_message: str) -> str:
    """Call OpenAI directly. No budget limits, no kill switch, no audit trail."""
    response = await openai.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": user_message}],
    )
    return response.choices[0].message.content or ""


# ---------------------------------------------------------------------------
# B) OpenAI call through Pikarc — budget, kill switch, audit trail
# ---------------------------------------------------------------------------
async def guarded_openai(user_id: str, user_message: str) -> str:
    """
    Same OpenAI call, but wrapped with Pikarc.

    Before the model executes, Pikarc checks:
      - Is the kill switch active?
      - Has this user exceeded their budget?
      - Are there too many concurrent runs?

    After the model responds, Pikarc records:
      - Token usage (prompt + completion)
      - Latency
      - Step outcome (COMPLETED / FAILED)
    """
    guard = AsyncPikarc(api_key="lg_...", base_url="http://localhost:8000")

    try:
        messages = [{"role": "user", "content": user_message}]

        async with guard.run(user_id=user_id, metadata={"agent": "support-bot"}) as run:
            response = await run.model_call(
                fn=lambda: openai.chat.completions.create(
                    model="gpt-4o",
                    messages=messages,
                ),
                model="gpt-4o",
                input_data={"messages": messages},
                token_extractor=lambda r: (
                    r.usage.prompt_tokens,
                    r.usage.completion_tokens,
                ),
            )

            return response.choices[0].message.content or ""

    except PikarcBlockedError as e:
        # The request was denied — budget exceeded, kill switch on, etc.
        return f"Blocked: {e.reason} ({e.deny_reason})"

    finally:
        await guard.close()

