from __future__ import annotations


class PikarcBlockedError(Exception):
    """Raised when a decision is DENY."""

    def __init__(self, reason: str, deny_reason: str) -> None:
        self.reason = reason
        self.deny_reason = deny_reason
        super().__init__(reason)
