"""Core domain logic for 3D fish pose estimation."""

__all__: list[str] = []
