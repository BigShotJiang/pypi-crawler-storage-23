"""Multi-view fish segmentation pipeline."""

__all__: list[str] = []
