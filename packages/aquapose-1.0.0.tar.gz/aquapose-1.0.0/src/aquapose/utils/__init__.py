"""General-purpose helpers and utilities."""

__all__: list[str] = []
