"""Parametric fish mesh model and differentiable rendering."""

__all__: list[str] = []
