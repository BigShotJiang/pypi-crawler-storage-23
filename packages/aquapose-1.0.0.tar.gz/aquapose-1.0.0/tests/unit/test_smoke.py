"""Smoke tests for package import."""

import aquapose


def test_version():
    assert aquapose.__version__
