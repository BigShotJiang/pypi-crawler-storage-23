"""End-to-end pipeline tests."""
