"""Cross-module integration tests."""
