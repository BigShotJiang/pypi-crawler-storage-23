Segmentation
============

.. automodule:: aquapose.segmentation
   :members:
   :undoc-members:
   :show-inheritance:
