Optimization
============

.. automodule:: aquapose.optimization
   :members:
   :undoc-members:
   :show-inheritance:
