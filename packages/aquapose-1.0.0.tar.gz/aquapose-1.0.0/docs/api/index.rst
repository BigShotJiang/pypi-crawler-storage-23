API Reference
=============

.. toctree::
   :maxdepth: 2

   calibration
   core
   io
   mesh
   optimization
   segmentation
   utils
