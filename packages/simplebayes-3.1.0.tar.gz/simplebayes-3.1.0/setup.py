from setuptools import setup


# Keep setup.py as a compatibility shim.
# Project metadata is defined in pyproject.toml.
setup()
