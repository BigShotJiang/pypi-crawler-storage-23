"""Pytest-discovered wrapper for legacy classifier unit tests."""

from tests import SimpleBayesTests  # noqa: F401  pylint: disable=unused-import
