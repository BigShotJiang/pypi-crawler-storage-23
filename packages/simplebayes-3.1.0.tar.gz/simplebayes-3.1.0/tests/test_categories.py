"""Pytest-discovered wrapper for legacy categories tests."""

from tests.categories import BayesCategoriesTests  # noqa: F401  pylint: disable=unused-import
