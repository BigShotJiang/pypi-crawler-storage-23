"""Pytest-discovered wrapper for legacy category tests."""

from tests.category import BayesCategoryTests  # noqa: F401  pylint: disable=unused-import
