import re

CATEGORY_PATTERN = re.compile(r"^[-_A-Za-z0-9]{1,64}$")
