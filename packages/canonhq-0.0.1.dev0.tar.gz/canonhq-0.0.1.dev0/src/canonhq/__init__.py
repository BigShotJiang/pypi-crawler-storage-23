"""Canon — spec-driven development platform."""
__version__ = "0.0.1.dev0"
