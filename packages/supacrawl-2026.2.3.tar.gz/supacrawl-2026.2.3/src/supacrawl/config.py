"""Configuration helpers for supacrawl."""


# This module previously contained default_sites_dir and default_corpora_dir
# which have been removed as part of CLI simplification.
# The module is retained for future configuration needs.
