#!/usr/bin/env python3
"""
Setup script for long-run-agent
Legacy setup.py for backwards compatibility
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
