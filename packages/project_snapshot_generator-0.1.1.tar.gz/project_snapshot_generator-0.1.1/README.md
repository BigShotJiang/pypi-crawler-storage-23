# project-snapshot-generator

Generates a complete textual snapshot of a project's source code and directory structure for LLM consumption.

![logo](https://raw.githubusercontent.com/trucomanx/ProjectSnapshotGenerator/main/screenshot.png)

## 1. Installing

To install the package from [PyPI](https://pypi.org/project/project_snapshot_generator/), follow the instructions below:


```bash
pip install --upgrade project_snapshot_generator
```

Execute `which project-snapshot-generator` to see where it was installed, probably in `/home/USERNAME/.local/bin/project-snapshot-generator`.

### Using

To start, use the command below:

```bash
project-snapshot-generator
```
## 2. More information

If you want more information go to [doc](https://github.com/trucomanx/ProjectSnapshotGenerator/blob/main/doc) directory.

## 3. Buy me a coffee

If you find this tool useful and would like to support its development, you can buy me a coffee!  
Your donations help keep the project running and improve future updates.  

[☕ Buy me a coffee](https://ko-fi.com/trucomanx) 

## 4. License

This project is licensed under the GPL license. See the `LICENSE` file for more details.
