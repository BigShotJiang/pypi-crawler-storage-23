# about.py

__version__ = "0.1.1"
__package__ = "project_snapshot_generator"
__program_project_name__ = "project-snapshot-generator"
__program_file_name__ = "file-snapshot-generator"
__author__ = "Fernando Pujaico Rivera"
__email__  = "fernando.pujaico.rivera@gmail.com"
__description__ = "Generates a complete textual snapshot of a project's source code and directory structure for LLM consumption."
__url_source__  = "https://github.com/trucomanx/ProjectSnapshotGenerator"
__url_doc__  = "https://github.com/trucomanx/ProjectSnapshotGenerator/tree/main/doc"
__url_funding__ = "https://trucomanx.github.io/en/funding.html"
__url_bugs__    = "https://github.com/trucomanx/ProjectSnapshotGenerator/issues"
