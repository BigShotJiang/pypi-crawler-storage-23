"""
AI Agent Payment Network Python SDK

A Python client library for interacting with the AI Agent Payment Network.

Example:
    from ai_agent_payments import AgentPaymentClient
    
    client = AgentPaymentClient(api_key="your_jwt_token")
    
    # Make a payment
    payment = client.create_payment(
        to_address="0xRecipient...",
        amount=0.01,
        memo="Payment for service"
    )
    
    # Register webhook
    webhook = client.register_webhook(
        url="https://myagent.com/webhook",
        events=["payment.confirmed"]
    )
"""

__version__ = "0.1.0"

from .client import AgentPaymentClient
from .models import Payment, Agent, Webhook, WebhookDelivery
from .exceptions import APIError, AuthenticationError, NotFoundError, ValidationError
from .webhooks import WebhookVerifier, create_webhook_receiver

__all__ = [
    'AgentPaymentClient',
    'Payment',
    'Agent',
    'Webhook',
    'WebhookDelivery',
    'APIError',
    'AuthenticationError',
    'NotFoundError',
    'ValidationError',
    'WebhookVerifier',
    'create_webhook_receiver',
]
