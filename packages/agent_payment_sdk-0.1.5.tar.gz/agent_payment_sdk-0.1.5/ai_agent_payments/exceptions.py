from typing import Optional

class APIError(Exception):
    """Base exception for API errors"""
    def __init__(self, message: str, status_code: Optional[int] = None):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)

class AuthenticationError(APIError):
    """Authentication failed"""
    pass

class NotFoundError(APIError):
    """Resource not found"""
    pass

class ValidationError(APIError):
    """Invalid request data"""
    pass
