import requests
from typing import Optional, Dict, Any, List
from .models import Payment, Agent, Webhook, WebhookDelivery
from .exceptions import APIError, AuthenticationError, NotFoundError

class AgentPaymentClient:
    """
    AI Agent Payment Network Python SDK
    
    Usage:
        client = AgentPaymentClient(api_key="your_jwt_token")
        payment = client.create_payment(to_address="0x...", amount=0.01)
    """
    
    def __init__(
        self,
        api_key: str,
        base_url: str = "http://localhost:8000",
        timeout: int = 30
    ):
        """
        Initialize the client
        
        Args:
            api_key: JWT token or API key for authentication
            base_url: Base URL of the payment network API
            timeout: Request timeout in seconds
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        })
    
    def _request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict] = None,
        params: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Make HTTP request to API"""
        url = f"{self.base_url}{endpoint}"
        
        try:
            response = self.session.request(
                method=method,
                url=url,
                json=data,
                params=params,
                timeout=self.timeout
            )
            
            # Handle errors
            if response.status_code == 401:
                raise AuthenticationError("Invalid authentication credentials")
            elif response.status_code == 404:
                raise NotFoundError("Resource not found")
            elif response.status_code >= 400:
                error_msg = response.json().get('detail', 'Unknown error')
                raise APIError(f"API Error: {error_msg}", status_code=response.status_code)
            
            return response.json() if response.text else {}
            
        except requests.exceptions.RequestException as e:
            raise APIError(f"Request failed: {str(e)}")
    
    # ===== Payment Methods =====
    
    def create_payment(
        self,
        to_address: str,
        amount: float,
        memo: Optional[str] = None,
        metadata: Optional[Dict] = None
    ) -> Payment:
        """
        Create a payment
        
        Args:
            to_address: Recipient's agent address (public key)
            amount: Amount in USD
            memo: Optional payment memo
            metadata: Optional additional data
        
        Returns:
            Payment object
        """
        # Get own agent info first
        agent = self.get_agent_info()
        
        data = {
            'from_agent_id': agent.agent_id,
            'to_agent_id': to_address,  # Note: API might expect agent_id, adjust if needed
            'amount_usd': amount,
            'metadata': metadata or {}
        }
        
        if memo:
            data['metadata']['memo'] = memo
        
        result = self._request('POST', '/api/v1/payments', data=data)
        return Payment.from_dict(result)
    
    def get_balance(self) -> Dict[str, float]:
        """
        Get current balance
        
        Returns:
            Dict with balance_usd and available_usd
        """
        return self._request('GET', '/api/v1/agents/me/balance')
    
    def get_transactions(
        self,
        limit: int = 50,
        offset: int = 0
    ) -> List[Dict]:
        """
        Get transaction history
        
        Args:
            limit: Number of transactions to return
            offset: Pagination offset
        
        Returns:
            List of transactions
        """
        params = {'limit': limit, 'offset': offset}
        result = self._request('GET', '/api/v1/transactions/me', params=params)
        return result.get('transactions', [])
    
    # ===== Agent Methods =====
    
    def get_agent_info(self) -> Agent:
        """
        Get current agent information
        
        Returns:
            Agent object
        """
        balance_info = self.get_balance()
        return Agent(
            agent_id=balance_info.get('agent_id'),
            balance_usd=balance_info.get('balance_usd'),
            available_usd=balance_info.get('available_usd')
        )
    
    def deposit(self, amount: float) -> Dict:
        """
        Deposit funds to channel
        
        Args:
            amount: Amount to deposit in USD
        
        Returns:
            Updated balance info
        """
        return self._request('POST', '/api/v1/channels/me/deposit', params={'amount': amount})
    
    # ===== Webhook Methods =====
    
    def register_webhook(
        self,
        url: str,
        events: List[str],
        metadata: Optional[Dict] = None
    ) -> Webhook:
        """
        Register a webhook endpoint
        
        Args:
            url: Your webhook URL (must be publicly accessible)
            events: List of events to subscribe to
                   (e.g., ['payment.initiated', 'payment.confirmed'])
            metadata: Optional additional data
        
        Returns:
            Webhook object with secret_key for signature verification
        """
        data = {
            'url': url,
            'events': events,
            'metadata': metadata or {}
        }
        
        result = self._request('POST', '/api/v1/webhooks/endpoints', data=data)
        return Webhook.from_dict(result)
    
    def list_webhooks(self) -> List[Webhook]:
        """
        List all registered webhooks
        
        Returns:
            List of Webhook objects
        """
        result = self._request('GET', '/api/v1/webhooks/endpoints')
        return [Webhook.from_dict(w) for w in result]
    
    def delete_webhook(self, webhook_id: int) -> None:
        """
        Delete a webhook endpoint
        
        Args:
            webhook_id: ID of webhook to delete
        """
        self._request('DELETE', f'/api/v1/webhooks/endpoints/{webhook_id}')
    
    def test_webhook(self, webhook_id: int) -> Dict:
        """
        Send a test webhook
        
        Args:
            webhook_id: ID of webhook to test
        
        Returns:
            Test result with delivery status
        """
        return self._request('POST', f'/api/v1/webhooks/endpoints/{webhook_id}/test')
    
    # ===== Blockchain Methods =====
    
    def get_blockchain_balance(self) -> Dict:
        """Get blockchain balance"""
        return self._request('GET', '/api/v1/blockchain/balance')
    
    def blockchain_deposit(self, amount: float) -> Dict:
        """Deposit from blockchain to payment channel"""
        data = {'amount_eth': amount}
        return self._request('POST', '/api/v1/blockchain/deposit', data=data)
    
    def blockchain_pay(
        self,
        to_address: str,
        amount: float,
        memo: Optional[str] = None
    ) -> Dict:
        """Make a blockchain payment"""
        data = {
            'to_address': to_address,
            'amount_eth': amount,
            'memo': memo
        }
        return self._request('POST', '/api/v1/blockchain/pay', data=data)

    # ===== Sandbox Methods =====
    
    def create_sandbox_agent(
        self,
        name: str = "Test Agent",
        initial_balance: float = 100.0
    ) -> Dict:
        """
        Create a pre-funded sandbox test agent
        
        Args:
            name: Agent display name
            initial_balance: Starting balance in USD
            
        Returns:
            Agent details with API key
        """
        data = {
            "name": name,
            "initial_balance": initial_balance
        }
        return self._request('POST', '/api/v1/sandbox/agents', data=data)
    
    def sandbox_payment(
        self,
        from_agent: str,
        to_agent: str,
        amount: float,
        memo: Optional[str] = None,
        trigger_webhook: bool = True
    ) -> Dict:
        """
        Create instant sandbox payment (no gas, instant confirmation)
        
        Args:
            from_agent: Sender public key
            to_agent: Recipient public key
            amount: Amount in USD
            memo: Optional payment memo
            trigger_webhook: Whether to trigger webhooks
            
        Returns:
            Payment details with mock tx hash
        """
        data = {
            "from_agent": from_agent,
            "to_agent": to_agent,
            "amount": amount,
            "memo": memo,
            "trigger_webhook": trigger_webhook
        }
        return self._request('POST', '/api/v1/sandbox/payments', data=data)
    
    def get_sandbox_stats(self) -> Dict:
        """Get sandbox environment statistics"""
        return self._request('GET', '/api/v1/sandbox/stats')
    
    def reset_sandbox(self) -> Dict:
        """Reset sandbox environment to initial state"""
        return self._request('POST', '/api/v1/sandbox/reset', params={'confirm': True})
    
    def get_sandbox_balance(self, public_key: str) -> Dict:
        """Get sandbox agent balance"""
        return self._request('GET', f'/api/v1/sandbox/agents/{public_key}/balance')
    
    def list_sandbox_transactions(
        self,
        limit: int = 50,
        offset: int = 0
    ) -> Dict:
        """List sandbox transactions"""
        params = {'limit': limit, 'offset': offset}
        return self._request('GET', '/api/v1/sandbox/transactions', params=params)
