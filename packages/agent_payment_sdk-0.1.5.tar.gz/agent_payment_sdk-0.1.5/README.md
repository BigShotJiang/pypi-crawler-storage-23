# Agent Payment Network SDK

Python SDK for integrating with the AI Agent Payment Network - enabling hybrid crypto + fiat payments for AI agents.

## Installation
```bash
pip install agent-payment-sdk
```

Or install from source:
```bash
git clone https://github.com/SuryaRaut/agent-payment-network
cd agent-payment-network/sdk/python
pip install -e .
```

## Quick Start
```python
from agent_payment_sdk import AgentPaymentClient

# Initialize client
client = AgentPaymentClient(
    api_key="your_api_key_here",  # Optional for testing
    base_url="http://localhost:8000"
)

# Create a payment
payment = client.create_payment(
    to_agent_id="agent_456",
    amount=50.00,
    currency="USD",
    payment_method="stripe_card",  # or "crypto" or "auto"
    memo="Payment for API usage"
)

print(f"Payment ID: {payment['payment_id']}")
print(f"Status: {payment['status']}")
print(f"Client Secret: {payment['client_secret']}")

# Check payment status
status = client.get_payment(payment['payment_id'])
print(f"Current status: {status['status']}")
```

## Payment Methods

### Crypto Payments (ETH on Base)
```python
# Add crypto wallet
method = client.add_payment_method(
    agent_id="agent_123",
    method_type="crypto_wallet",
    wallet_address="0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb",
    is_default=True
)

# Make crypto payment
payment = client.create_payment(
    to_agent_id="agent_456",
    amount=0.01,
    currency="ETH",
    payment_method="crypto"
)
```

### Stripe Payments (Credit/Debit Cards)
```python
# Add Stripe card (payment_method_id from Stripe.js frontend)
method = client.add_payment_method(
    agent_id="agent_123",
    method_type="stripe_card",
    stripe_payment_method_id="pm_1234567890",
    is_default=True
)

# Make card payment
payment = client.create_payment(
    to_agent_id="agent_456",
    amount=100.00,
    currency="USD",
    payment_method="stripe_card"
)
```

## API Reference

### AgentPaymentClient

#### `__init__(api_key, base_url, timeout)`
Initialize the client.

#### `create_payment(to_agent_id, amount, currency, payment_method, memo)`
Create a new payment.

#### `get_payment(payment_id)`
Get payment status.

#### `health_check()`
Check API health.

#### `add_payment_method(agent_id, method_type, ...)`
Add payment method.

#### `list_payment_methods(agent_id)`
List all payment methods.

#### `delete_payment_method(method_id)`
Remove payment method.

## Error Handling
```python
from agent_payment_sdk import PaymentError, NetworkError

try:
    payment = client.create_payment(
        to_agent_id="agent_456",
        amount=50.00
    )
except PaymentError as e:
    print(f"Payment failed: {e}")
except NetworkError as e:
    print(f"Network error: {e}")
```

## Features

- ✅ Hybrid crypto + fiat payments
- ✅ Automatic payment method selection
- ✅ Payment method management
- ✅ Type hints for better IDE support
- ✅ Comprehensive error handling
- ✅ Simple, intuitive API

## Support

- Documentation: https://docs.agentpayment.network
- Issues: https://github.com/SuryaRaut/agent-payment-network/issues
- Email: itssuryaraut@gmail.com

## License

MIT License - see LICENSE file for details
