# DART-MCP: 재무 분석을 위한 Claude 확장 프로그램

DART API를 활용한 재무 분석 MCP(Model-assisted Capability Package)입니다. Claude를 이용하여 상장 기업의 재무 데이터를 쉽게 분석하고 시각화할 수 있습니다.

상단에 더 상세하고 쉬운 가이드는 [https://dart-mcp.vercel.app/](https://dart-mcp.vercel.app/) 에서 보는 걸 추가드립니다.

<a href="https://glama.ai/mcp/servers/@2geonhyup/dart-mcp">
  <img width="380" height="200" src="https://glama.ai/mcp/servers/@2geonhyup/dart-mcp/badge" alt="dart-mcp MCP server" />
</a>

## 가능한 것 / 불가능한 것

### 가능한 것 (O)
- 주요 재무 분석
- 상세 재무 분석
- 기업의 사업부별 매출
- 클로드를 이용한 시각화
- 재무지표를 활용한 벨류에이션 (DCF 등)

### 불가능한 것 (X)
- 주가 및 시가총액 제공
- 해외기업 분석
- 클로드 무료 사용량 이상의 사용
- 한 채팅창에서 다량 사용 (잘 안되면 채팅창 새로 만들어서 쓰기)
- 100% 정확한 정보

**제공하는 투자 정보는 실제와 다를 수 있고 투자 책임은 투자한 본인에게 있습니다.**

## 사용 예시

### 재무 데이터 분석 및 시각화
```
파마리서치의 2023, 2024년 매출액, 영업이익 추이 분기별로 그래프로 보여줘. 그리고 매출비중이 어떻게 되는지 알려줘. 영업이익이나 매출액 변동 이유도 분석해줘.
```

### 기업 비교 분석
```
카카오와 네이버 2024년 수익성지표를 비교해서 분기별로 보여주고, 각 기업들은 어떤 사업부가 성장을 이끌지 알려줘.
```

### 재무 위험 평가
```
한국전력의 최근 부채상황을 조사하고, 상세하게 어떤 부분이 문제인지 분석해줘.
```

## 사전 준비

### DART API 키 발급
1. [DART 오픈API](https://opendart.fss.or.kr) 웹사이트에 접속
2. 회원가입 및 로그인
3. [인증키 신청/관리] - [오픈API 이용 신청] 메뉴 클릭
4. 이용정보 입력 후 신청
5. [인증키 신청/관리] - [오픈API 이용현황] 메뉴에서 발급된 인증키 확인

### Claude 데스크톱 앱 설치
1. [Claude 데스크톱 앱](https://claude.ai/desktop) 다운로드 
2. 계정 가입 및 로그인

## 설치 방법

### 1. GitHub에서 프로젝트 다운로드
GitHub 페이지에서 zip 파일을 다운로드합니다.
https://github.com/2geonhyup/dart-mcp

### 2. ZIP 파일 압축 해제 및 폴더 위치 확인
1) 다운로드한 ZIP 파일의 압축을 해제합니다.
2) 압축 해제 폴더가 **Downloads**에 있는지 확인합니다. **다른 위치에 있다면 Downloads 위치로 옮겨주세요.**

### 3. 폴더 이름 변경
압축 해제한 폴더 dart-mcp-main 이름을 **dart-mcp로 반드시 바꿔주세요.** (처음부터 dart-mcp라면 바꾸지 마세요)

### 4. Claude 앱 접속 및 설정 접근
1) 설치한 Claude 데스크톱 앱을 실행합니다.
2) 맥 사용자: **Claude > 설정 > 개발자 > 설정 편집** 클릭
   윈도우 사용자: **설정 > 개발자 > 설정 편집** 클릭

### 5. 설정 파일 열기
**상단 claude_desktop_config 파일**을 텍스트 편집기로 엽니다.

### 6. 설정 코드 입력
1. 먼저 알맞은 키와 이름을 입력하세요
   - DART API 키: 발급받은 API 키 입력
   - 컴퓨터 이름: 컴퓨터 계정 이름 입력 (Mac에서는 Finder 홈 폴더, Windows에서는 C:\사용자 폴더명)

2. 다음 코드를 이용하여 설정 파일에 입력
```json
{
  "mcpServers": {
    "dart-mcp": {
      "command": "uv",
      "args": ["--directory", "/Users/{컴퓨터이름}/Downloads/dart-mcp", "run", "dart.py"],
      "env": {
        "DART_API_KEY": "{DART_API_KEY}"
      }
    }
  }
}
```

### 7. Claude 재시작 및 사용 시작
**설정 파일을 저장하고 Claude 앱을 닫은 후 다시 시작**합니다.
이제 Claude에게 질문하면 DART API를 호출하여 답변을 제공합니다.

## 사용시 주의사항
- 기업명은 공식적으로 상장된 이름으로 제공해야 합니다.
- 코스피, 코스닥 종목만 조사 가능합니다.
- 주가나 시가총액과 같은 실시간 정보들은 앞으로 연동할 계획입니다.