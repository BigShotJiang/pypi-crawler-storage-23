"""Gemini Live API voice provider.

Implements the VoiceProvider protocol using Google's Gemini Live WebSocket API
(BidiGenerateContent). Auth is via API key in the URL query string.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
from typing import Any, AsyncIterator

import websockets

from voice_vibecoder.voice_providers import (
    AudioDelta,
    FunctionCall,
    GeminiVADSettings,
    ResponseCreated,
    ResponseDone,
    SpeechStarted,
    TranscriptDelta,
    TranscriptDone,
    UserTranscript,
    VADSettings,
    VoiceError,
    VoiceEvent,
)

logger = logging.getLogger(__name__)


def _convert_tools_for_gemini(openai_tools: list[dict]) -> list[dict]:
    """Convert OpenAI tool format to Gemini functionDeclarations format.

    OpenAI: [{"type": "function", "name": "...", "description": "...", "parameters": {...}}, ...]
    Gemini: [{"name": "...", "description": "...", "parameters": {...}}, ...]
    """
    declarations = []
    for tool in openai_tools:
        decl: dict[str, Any] = {}
        decl["name"] = tool.get("name", "")
        if "description" in tool:
            decl["description"] = tool["description"]
        if "parameters" in tool:
            decl["parameters"] = tool["parameters"]
        declarations.append(decl)
    return declarations


class GeminiLiveVoiceProvider:
    """VoiceProvider implementation for the Gemini Live API."""

    def __init__(self, ws_url: str, model: str) -> None:
        self._ws_url = ws_url
        self._model = model
        self._ws: Any = None
        # Track pending tool calls: call_id → function_name (Gemini needs both for responses)
        self._pending_tool_calls: dict[str, str] = {}
        # Track whether we're in a model turn (for ResponseCreated)
        self._in_model_turn = False
        # PTT mode uses manual activityStart/activityEnd signals
        self._ptt_mode = False
        self._activity_started = False

    async def connect(self) -> None:
        self._ws = await websockets.connect(self._ws_url)

    async def disconnect(self) -> None:
        if self._ws:
            try:
                await self._ws.close()
            except Exception:
                pass
            self._ws = None

    async def configure(
        self,
        instructions: str,
        voice: str,
        tools: list[dict],
        vad: VADSettings | GeminiVADSettings | None,
    ) -> None:
        if not self._ws:
            return

        from voice_vibecoder.config import GEMINI_VOICES

        # Voice fallback — if voice isn't valid for Gemini, use Puck
        if voice not in GEMINI_VOICES:
            voice = "Puck"

        setup_msg: dict[str, Any] = {
            "setup": {
                "model": self._model,
                "generationConfig": {
                    "responseModalities": ["AUDIO"],
                    "speechConfig": {
                        "voiceConfig": {
                            "prebuiltVoiceConfig": {
                                "voiceName": voice,
                            }
                        }
                    },
                },
                "systemInstruction": {
                    "parts": [{"text": instructions}],
                },
            }
        }

        # Tools
        declarations = _convert_tools_for_gemini(tools)
        if declarations:
            setup_msg["setup"]["tools"] = [
                {"functionDeclarations": declarations}
            ]

        # VAD configuration
        if vad is None:
            # PTT mode — disable automatic activity detection, use manual signals
            self._ptt_mode = True
            setup_msg["setup"]["realtimeInputConfig"] = {
                "automaticActivityDetection": {"disabled": True}
            }
        else:
            self._ptt_mode = False
            start_sens = "START_SENSITIVITY_HIGH"
            end_sens = "END_SENSITIVITY_LOW"
            silence_ms = 700
            prefix_ms = 100
            if isinstance(vad, GeminiVADSettings):
                start_sens = f"START_SENSITIVITY_{vad.start_sensitivity}"
                end_sens = f"END_SENSITIVITY_{vad.end_sensitivity}"
                silence_ms = vad.silence_duration_ms
                prefix_ms = vad.prefix_padding_ms
            setup_msg["setup"]["realtimeInputConfig"] = {
                "automaticActivityDetection": {
                    "disabled": False,
                    "startOfSpeechSensitivity": start_sens,
                    "endOfSpeechSensitivity": end_sens,
                    "silenceDurationMs": silence_ms,
                    "prefixPaddingMs": prefix_ms,
                }
            }

        await self._ws.send(json.dumps(setup_msg))

        # Wait for setupComplete
        deadline = asyncio.get_event_loop().time() + 10
        while asyncio.get_event_loop().time() < deadline:
            raw = await asyncio.wait_for(self._ws.recv(), timeout=10)
            msg = json.loads(raw)
            if "setupComplete" in msg:
                logger.info("Gemini setup complete")
                return
        raise RuntimeError("Gemini setup did not complete within timeout")

    async def send_audio(self, base64_chunk: str) -> None:
        if not self._ws:
            return
        try:
            import numpy as np

            # In PTT mode, send activityStart before first audio chunk
            if self._ptt_mode and not self._activity_started:
                await self._ws.send(json.dumps({
                    "realtimeInput": {"activityStart": {}}
                }))
                self._activity_started = True

            # Downsample 24kHz → 16kHz (Gemini expects 16kHz input)
            raw = base64.b64decode(base64_chunk)
            samples = np.frombuffer(raw, dtype=np.int16)
            n_out = int(len(samples) * 2 / 3)
            indices = np.linspace(0, len(samples) - 1, n_out)
            resampled = np.interp(indices, np.arange(len(samples)), samples.astype(np.float64))
            b64 = base64.b64encode(resampled.astype(np.int16).tobytes()).decode("ascii")

            await self._ws.send(json.dumps({
                "realtimeInput": {
                    "audio": {
                        "mimeType": "audio/pcm;rate=16000",
                        "data": b64,
                    }
                }
            }))
        except Exception:
            pass

    async def commit_audio(self) -> None:
        if not self._ws:
            return
        try:
            if self._ptt_mode and self._activity_started:
                # PTT mode: signal end of user speech
                await self._ws.send(json.dumps({
                    "realtimeInput": {"activityEnd": {}}
                }))
                self._activity_started = False
            # VAD mode: no-op — Gemini's server-side VAD handles end-of-speech
        except Exception:
            pass

    async def cancel_response(self) -> None:
        # No-op — Gemini handles interruption via VAD automatically
        pass

    async def request_response(self) -> None:
        # No-op — Gemini auto-responds after turn complete
        pass

    async def inject_message(self, text: str) -> None:
        if not self._ws:
            return
        await self._ws.send(json.dumps({
            "clientContent": {
                "turns": [{
                    "role": "user",
                    "parts": [{"text": text}],
                }],
                "turnComplete": True,
            }
        }))

    async def send_tool_result(self, call_id: str, output: str) -> None:
        if not self._ws:
            return
        name = self._pending_tool_calls.pop(call_id, call_id)
        await self._ws.send(json.dumps({
            "toolResponse": {
                "functionResponses": [{
                    "id": call_id,
                    "name": name,
                    "response": {"result": output},
                }]
            }
        }))

    async def update_session(self, instructions: str) -> None:
        # No-op — Gemini doesn't support mid-session config changes
        logger.debug("update_session is a no-op for Gemini")

    async def listen(self) -> AsyncIterator[VoiceEvent]:
        if not self._ws:
            return
        async for raw in self._ws:
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue
            for event in self._map_events(msg):
                yield event

    async def test_connection(self) -> bytes:
        return await self.test_voice("Puck")

    async def test_voice(self, voice: str) -> bytes:
        ws = await websockets.connect(self._ws_url)
        try:
            from voice_vibecoder.config import GEMINI_VOICES

            if voice not in GEMINI_VOICES:
                voice = "Puck"

            # Send setup
            setup_msg = {
                "setup": {
                    "model": self._model,
                    "generationConfig": {
                        "responseModalities": ["AUDIO"],
                        "speechConfig": {
                            "voiceConfig": {
                                "prebuiltVoiceConfig": {
                                    "voiceName": voice,
                                }
                            }
                        },
                    },
                    "systemInstruction": {
                        "parts": [{"text": "Always speak English. Say a short greeting in 5 words or less."}],
                    },
                }
            }
            await ws.send(json.dumps(setup_msg))

            # Wait for setupComplete
            raw = await asyncio.wait_for(ws.recv(), timeout=10)
            msg = json.loads(raw)
            if "setupComplete" not in msg:
                raise RuntimeError(f"Expected setupComplete, got: {list(msg.keys())}")

            # Inject a text message
            await ws.send(json.dumps({
                "clientContent": {
                    "turns": [{
                        "role": "user",
                        "parts": [{"text": "Say hello!"}],
                    }],
                    "turnComplete": True,
                }
            }))

            # Collect audio until turnComplete
            audio_chunks: list[bytes] = []
            deadline = asyncio.get_event_loop().time() + 15
            while asyncio.get_event_loop().time() < deadline:
                raw = await asyncio.wait_for(ws.recv(), timeout=15)
                msg = json.loads(raw)

                server_content = msg.get("serverContent")
                if server_content:
                    model_turn = server_content.get("modelTurn")
                    if model_turn:
                        for part in model_turn.get("parts", []):
                            inline = part.get("inlineData")
                            if inline and inline.get("data"):
                                audio_chunks.append(base64.b64decode(inline["data"]))
                    if server_content.get("turnComplete"):
                        break

            if not audio_chunks:
                raise RuntimeError("No audio received from Gemini")

            return b"".join(audio_chunks)
        finally:
            await ws.close()

    def _map_events(self, msg: dict) -> list[VoiceEvent]:
        """Map a single Gemini server message to zero or more VoiceEvents."""
        events: list[VoiceEvent] = []

        # Tool calls
        tool_call = msg.get("toolCall")
        if tool_call:
            for fc in tool_call.get("functionCalls", []):
                call_id = fc.get("id", "")
                name = fc.get("name", "")
                args = fc.get("args", {})
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        args = {}
                self._pending_tool_calls[call_id] = name
                events.append(FunctionCall(call_id=call_id, name=name, arguments=args))
            return events

        # Input transcription
        input_transcription = msg.get("inputTranscription")
        if input_transcription:
            text = input_transcription.get("text", "").strip()
            if text:
                events.append(UserTranscript(transcript=text))
            return events

        # Output transcription
        output_transcription = msg.get("outputTranscription")
        if output_transcription:
            text = output_transcription.get("text", "")
            if text:
                events.append(TranscriptDone(transcript=text))
            return events

        # Server content (audio, text, turnComplete, interrupted)
        server_content = msg.get("serverContent")
        if server_content:
            # Interrupted — user started speaking
            if server_content.get("interrupted"):
                self._in_model_turn = False
                events.append(SpeechStarted())
                return events

            model_turn = server_content.get("modelTurn")
            if model_turn:
                # Emit ResponseCreated on first model turn of a response
                if not self._in_model_turn:
                    self._in_model_turn = True
                    events.append(ResponseCreated())

                for part in model_turn.get("parts", []):
                    inline = part.get("inlineData")
                    if inline and inline.get("data"):
                        events.append(AudioDelta(delta=inline["data"]))
                    text = part.get("text")
                    if text:
                        events.append(TranscriptDelta(delta=text))

            if server_content.get("turnComplete"):
                self._in_model_turn = False
                events.append(ResponseDone())

        return events
