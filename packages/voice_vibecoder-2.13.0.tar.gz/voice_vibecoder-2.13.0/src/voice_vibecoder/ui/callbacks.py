"""CallbackMixin — event and callback handlers for VoiceCodingScreen.

Handles audio, transcripts, agent output routing, instance status
changes, UI commands, and tool call logging.
"""

import asyncio

from textual.widgets import RichLog

from voice_vibecoder.instances import InstanceStatus
from voice_vibecoder.ui.styles import _CATEGORY_STYLES, _format_output_line


class CallbackMixin:
    """Mixin providing callback methods for VoiceCodingScreen."""

    def _send_audio_chunk(self, base64_data: str) -> None:
        if self._loop and self._session and self._session.connected:
            asyncio.run_coroutine_threadsafe(
                self._session.send_audio(base64_data), self._loop
            )

    def _on_audio(self, base64_pcm: str) -> None:
        if self._audio:
            self._audio.play_audio(base64_pcm)

    def _on_transcript(self, role: str, text: str) -> None:
        if role == "user":
            self.app.call_from_thread(
                self._log, f"[bold blue]You:[/bold blue] {text}"
            )
        else:
            self.app.call_from_thread(
                self._log, f"[bold green]ChatGPT:[/bold green] {text}"
            )

    def _on_interrupt(self) -> None:
        if self._audio:
            self._audio.clear_playback()

    _prev_category: dict[str, str | None] = {}

    def _on_agent_output(self, instance_id: str, line: str) -> None:
        """Route all agent output to the instance's grid panel."""
        if not self._session:
            return

        inst = self._session.registry.get_by_id(instance_id)
        if not inst:
            return

        category = None
        display_line = line
        if ":" in line:
            prefix, rest = line.split(":", 1)
            if prefix in _CATEGORY_STYLES:
                category = prefix
                display_line = rest

        # Collapse embedded newlines — RichLog.write() renders \n with extra
        # vertical spacing which makes Cursor output look double-spaced.
        display_line = display_line.replace("\n", " ").strip()
        if not display_line:
            return

        prev = self._prev_category.get(instance_id)
        show_badge = category == "text" and prev != "text"
        self._prev_category[instance_id] = category

        styled = _format_output_line(category, display_line, inst.agent_type, show_badge=show_badge)

        self._state.add_instance_line(inst.display_key, styled)
        self.app.call_from_thread(self._ensure_output, instance_id, inst, styled)
        self._write_log_file(f"[{inst.display_key}] {display_line}")

    def _ensure_output(self, instance_id: str, inst, styled: str) -> None:
        """Write output to panel, recovering the widget reference if needed."""
        recovered = False
        if not inst.output_widget:
            # Widget reference lost (e.g. after restore) — recover from DOM
            try:
                inst.output_widget = self.query_one(f"#output-{instance_id}", RichLog)
                recovered = True
            except Exception:
                # Panel doesn't exist yet — create it
                self._create_instance_panel(instance_id, inst.display_key)
                recovered = True
            if not inst.output_widget:
                return
        if recovered:
            self._write_to_output(inst.output_widget, "[dim]─── session resumed ───[/dim]")
        self._write_to_output(inst.output_widget, styled)

    def _write_to_output(self, widget: RichLog, text: str) -> None:
        try:
            widget.write(text)
        except Exception:
            pass

    def _on_instance_status(self, instance_id: str, status: InstanceStatus) -> None:
        """Update panel header when instance status changes."""
        self.app.call_from_thread(self._handle_instance_status, instance_id, status)

    def _handle_instance_status(self, instance_id: str, status: InstanceStatus) -> None:
        if not self._session:
            return

        try:
            self.query_one(f"#panel-{instance_id}")
        except Exception:
            inst = self._session.registry.get_by_id(instance_id)
            if inst:
                self._create_instance_panel(instance_id, inst.display_key)

        self._update_instance_header(instance_id, status)
        self._update_status_bar("ready")

    def _on_ui_command(self, instance_id: str, action: str, data: dict) -> None:
        """Handle UI commands from tool handlers (called from thread pool)."""
        self.app.call_from_thread(self._handle_ui_command, instance_id, action, data)

    def _handle_ui_command(self, instance_id: str, action: str, data: dict) -> None:
        if action == "show_diff":
            self._show_diff_view(instance_id, data)
        elif action == "show_output":
            self._hide_diff_view(instance_id)
        elif action == "fullscreen":
            self._toggle_fullscreen(instance_id)
        elif action == "remove":
            self._remove_instance_panel(instance_id)
        elif action == "file_tree":
            self._update_file_tree(instance_id, data)

    def _on_status(self, status: str) -> None:
        self.app.call_from_thread(self._update_status_bar, status)

    def _on_tool_call(self, name: str, arguments: dict) -> None:
        if name == "send_to_agent":
            msg = arguments.get("message", "")
            branch = arguments.get("branch", "")
            agent = arguments.get("agent", "")
            preview = msg[:100] + "..." if len(msg) > 100 else msg
            branch_label = f" [{branch}]" if branch else ""
            agent_label = f" ({agent})" if agent else ""
            self.app.call_from_thread(
                self._log,
                f"\n[bold yellow]>>> Sending to agent{agent_label}{branch_label}:[/bold yellow] {preview}",
            )
        elif name == "create_branch_instance":
            branch = arguments.get("branch", "")
            self.app.call_from_thread(
                self._log,
                f"[yellow]Creating instance for branch '{branch}'...[/yellow]",
            )
        elif name == "get_agent_status":
            self.app.call_from_thread(
                self._log, "[dim]Checking agent status...[/dim]"
            )
        elif name == "cancel_agent":
            self.app.call_from_thread(
                self._log, "[yellow]Cancelling agent task...[/yellow]"
            )
        elif name == "reset_agent":
            self.app.call_from_thread(
                self._log, "[yellow]Resetting agent session...[/yellow]"
            )
        elif name == "list_branches":
            self.app.call_from_thread(
                self._log, "[dim]Listing branches...[/dim]"
            )
        elif name == "show_diff":
            branch = arguments.get("branch", "")
            label = f" [{branch}]" if branch else ""
            self.app.call_from_thread(
                self._log, f"[dim]Showing diff{label}...[/dim]"
            )
        elif name == "send_to_session":
            msg = arguments.get("message", "")
            session = arguments.get("session_name", "")
            agent = arguments.get("agent", "")
            preview = msg[:100] + "..." if len(msg) > 100 else msg
            session_label = f" [{session}]" if session else ""
            agent_label = f" ({agent})" if agent else ""
            self.app.call_from_thread(
                self._log,
                f"\n[bold yellow]>>> Sending to session{agent_label}{session_label}:[/bold yellow] {preview}",
            )
        elif name == "remove_branch_instance":
            branch = arguments.get("branch", "")
            self.app.call_from_thread(
                self._log, f"[yellow]Removing '{branch}'...[/yellow]"
            )
        elif name == "remove_session":
            session = arguments.get("session_name", "")
            self.app.call_from_thread(
                self._log, f"[yellow]Removing session '{session}'...[/yellow]"
            )
