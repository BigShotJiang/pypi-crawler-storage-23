"""Setup screen for configuring the Realtime API provider, credentials, and session options."""

from textual.binding import Binding
from textual.containers import Vertical, Center, Horizontal
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, Input, RadioSet, RadioButton, Select, Switch

from voice_vibecoder.code_providers.registry import get_choices as get_agent_choices
from voice_vibecoder.config import (
    RealtimeSettings,
    OpenAIConfig,
    AzureConfig,
    GeminiConfig,
    VOICES,
    GEMINI_VOICES,
    LANGUAGES,
    PERMISSION_MODES,
    INPUT_MODES,
    OPENAI_DEFAULT_MODEL,
    AZURE_DEFAULT_ENDPOINT,
    AZURE_DEFAULT_DEPLOYMENT,
    GEMINI_DEFAULT_MODEL,
)


SETUP_CSS = """
VoiceCodingSetupScreen {
    background: $surface;
}

#setup-scroll {
    align: center middle;
    width: 100%;
    height: 100%;
}

#setup-container {
    width: 72;
    height: auto;
    max-height: 90%;
    padding: 1 2;
    border: solid $accent;
    background: $surface;
    overflow-y: auto;
}

#setup-title {
    text-align: center;
    padding: 1 0;
}

.setup-section {
    padding: 1 0 0 0;
    text-style: bold;
    color: $accent;
}

.setup-label {
    padding: 1 0 0 0;
}

.setup-row {
    height: auto;
    width: 100%;
}

.setup-field {
    margin: 0 1 0 0;
    width: 1fr;
}

#api-key-input {
    margin: 0 0 1 0;
}

.provider-fields {
    height: auto;
}

#openai-fields {
    height: auto;
}

#azure-fields {
    height: auto;
}

#gemini-fields {
    height: auto;
}

#openai-vad-fields {
    height: auto;
}

#gemini-vad-fields {
    height: auto;
}

.hidden {
    display: none;
}

#setup-hint {
    text-align: center;
    padding: 1 0;
}

.setup-agent-row {
    height: auto;
    padding: 0 0 0 1;
}

.setup-agent-row Static {
    width: 1fr;
    padding: 0 1 0 0;
}

.setup-agent-row Switch {
    width: auto;
}
"""


class VoiceCodingSetupScreen(Screen):
    """Screen for configuring all voice coding settings."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", priority=True),
    ]

    CSS = SETUP_CSS

    def __init__(self, existing: RealtimeSettings | None = None) -> None:
        super().__init__()
        self._existing = existing or RealtimeSettings()

    def compose(self):
        yield Header(show_clock=True)
        with Center(id="setup-scroll"):
            with Vertical(id="setup-container"):
                yield Static(
                    "[bold cyan]Olaf The Vibecoder[/bold cyan] [dim]Settings[/dim]",
                    id="setup-title",
                )

                # -- Agents --
                yield Static("Coding Agents", classes="setup-section")
                for label, agent_id in get_agent_choices():
                    with Horizontal(classes="setup-agent-row"):
                        yield Switch(
                            value=agent_id in self._existing.enabled_agents,
                            id=f"setup-agent-{agent_id}",
                        )
                        yield Static(label)

                # -- Connection --
                yield Static("Connection", classes="setup-section")

                yield Static("Provider", classes="setup-label")
                with RadioSet(id="provider-radio"):
                    yield RadioButton(
                        "OpenAI",
                        value=self._existing.provider == "openai",
                    )
                    yield RadioButton(
                        "Azure OpenAI",
                        value=self._existing.provider == "azure",
                    )
                    yield RadioButton(
                        "Gemini",
                        value=self._existing.provider == "gemini",
                    )

                yield Static("API Key", classes="setup-label")
                yield Input(
                    value=self._existing.api_key,
                    placeholder="sk-... or Azure API key",
                    password=True,
                    id="api-key-input",
                )

                # OpenAI-specific
                with Vertical(
                    id="openai-fields",
                    classes="" if self._existing.provider == "openai" else "hidden",
                ):
                    yield Static("Model", classes="setup-label")
                    yield Input(
                        value=self._existing.openai.model,
                        placeholder=OPENAI_DEFAULT_MODEL,
                        id="openai-model-input",
                    )
                    yield Static("Voice", classes="setup-label")
                    _ov = self._existing.openai.voice
                    _ov = _ov if _ov in VOICES else VOICES[0]
                    yield Select(
                        [(v, v) for v in VOICES],
                        value=_ov,
                        id="openai-voice-select",
                    )

                # Azure-specific
                with Vertical(
                    id="azure-fields",
                    classes="" if self._existing.provider == "azure" else "hidden",
                ):
                    yield Static("Azure Endpoint (host only)", classes="setup-label")
                    yield Input(
                        value=self._existing.azure.endpoint,
                        placeholder="your-resource.openai.azure.com",
                        id="azure-endpoint-input",
                    )
                    yield Static("Deployment Name", classes="setup-label")
                    yield Input(
                        value=self._existing.azure.deployment,
                        placeholder="gpt-4o-realtime",
                        id="azure-deployment-input",
                    )
                    yield Static("Voice", classes="setup-label")
                    _av = self._existing.azure.voice
                    _av = _av if _av in VOICES else VOICES[0]
                    yield Select(
                        [(v, v) for v in VOICES],
                        value=_av,
                        id="azure-voice-select",
                    )

                # Gemini-specific
                with Vertical(
                    id="gemini-fields",
                    classes="" if self._existing.provider == "gemini" else "hidden",
                ):
                    yield Static("Model", classes="setup-label")
                    yield Input(
                        value=self._existing.gemini.model,
                        placeholder=GEMINI_DEFAULT_MODEL,
                        id="gemini-model-input",
                    )
                    yield Static("Voice", classes="setup-label")
                    _gv = self._existing.gemini.voice
                    _gv = _gv if _gv in GEMINI_VOICES else GEMINI_VOICES[0]
                    yield Select(
                        [(v, v) for v in GEMINI_VOICES],
                        value=_gv,
                        id="gemini-voice-select",
                    )

                # -- Language --
                yield Static("Language", classes="setup-label")
                yield Select(
                    LANGUAGES,
                    value=self._existing.language,
                    id="language-select",
                )

                # -- Input Mode --
                yield Static("Input Mode", classes="setup-label")
                yield Select(
                    INPUT_MODES,
                    value=self._existing.input_mode,
                    id="input-mode-select",
                )

                # -- VAD (provider-specific) --
                yield Static("Voice Activity Detection", classes="setup-section")

                # OpenAI/Azure VAD fields
                with Vertical(
                    id="openai-vad-fields",
                    classes="" if self._existing.provider != "gemini" else "hidden",
                ):
                    with Horizontal(classes="setup-row"):
                        with Vertical(classes="setup-field"):
                            yield Static("Threshold (0.0–1.0)", classes="setup-label")
                            _vad_cfg = self._existing.openai if self._existing.provider == "openai" else self._existing.azure
                            yield Input(
                                value=str(_vad_cfg.vad_threshold),
                                placeholder="0.8",
                                id="vad-threshold-input",
                            )
                        with Vertical(classes="setup-field"):
                            yield Static("Silence (ms)", classes="setup-label")
                            yield Input(
                                value=str(_vad_cfg.silence_duration_ms),
                                placeholder="700",
                                id="silence-duration-input",
                            )
                        with Vertical(classes="setup-field"):
                            yield Static("Prefix Padding (ms)", classes="setup-label")
                            yield Input(
                                value=str(_vad_cfg.prefix_padding_ms),
                                placeholder="300",
                                id="prefix-padding-input",
                            )

                # Gemini VAD fields
                with Vertical(
                    id="gemini-vad-fields",
                    classes="" if self._existing.provider == "gemini" else "hidden",
                ):
                    with Horizontal(classes="setup-row"):
                        with Vertical(classes="setup-field"):
                            yield Static("Start Sensitivity", classes="setup-label")
                            yield Select(
                                [("High", "HIGH"), ("Low", "LOW")],
                                value=self._existing.gemini.start_sensitivity,
                                id="gemini-start-sensitivity",
                            )
                        with Vertical(classes="setup-field"):
                            yield Static("End Sensitivity", classes="setup-label")
                            yield Select(
                                [("High", "HIGH"), ("Low", "LOW")],
                                value=self._existing.gemini.end_sensitivity,
                                id="gemini-end-sensitivity",
                            )
                    with Horizontal(classes="setup-row"):
                        with Vertical(classes="setup-field"):
                            yield Static("Silence (ms)", classes="setup-label")
                            yield Input(
                                value=str(self._existing.gemini.silence_duration_ms),
                                placeholder="700",
                                id="gemini-silence-duration-input",
                            )
                        with Vertical(classes="setup-field"):
                            yield Static("Prefix Padding (ms)", classes="setup-label")
                            yield Input(
                                value=str(self._existing.gemini.prefix_padding_ms),
                                placeholder="100",
                                id="gemini-prefix-padding-input",
                            )

                # -- Agent --
                yield Static("Agent", classes="setup-section")

                yield Static("Permission Mode", classes="setup-label")
                yield Select(
                    PERMISSION_MODES,
                    value=self._existing.permission_mode,
                    id="permission-mode-select",
                )

                yield Static("Timeout (seconds)", classes="setup-label")
                yield Input(
                    value=str(self._existing.agent_timeout),
                    placeholder="300",
                    id="agent-timeout-input",
                )

                yield Static(
                    "[dim]Enter on any field: Save  |  Escape: Cancel[/dim]",
                    id="setup-hint",
                )
        yield Footer()

    def on_mount(self) -> None:
        self.query_one("#api-key-input", Input).focus()
        self._ready = True

    def on_radio_set_changed(self, event: RadioSet.Changed) -> None:
        if event.radio_set.id != "provider-radio":
            return
        # Skip during initial mount — compose already set correct visibility and options
        if not getattr(self, "_ready", False):
            return

        # index 0=OpenAI, 1=Azure, 2=Gemini
        openai_fields = self.query_one("#openai-fields")
        azure_fields = self.query_one("#azure-fields")
        gemini_fields = self.query_one("#gemini-fields")
        openai_vad = self.query_one("#openai-vad-fields")
        gemini_vad = self.query_one("#gemini-vad-fields")

        openai_fields.add_class("hidden")
        azure_fields.add_class("hidden")
        gemini_fields.add_class("hidden")

        if event.index == 0:
            openai_fields.remove_class("hidden")
            openai_vad.remove_class("hidden")
            gemini_vad.add_class("hidden")
        elif event.index == 1:
            azure_fields.remove_class("hidden")
            openai_vad.remove_class("hidden")
            gemini_vad.add_class("hidden")
        elif event.index == 2:
            gemini_fields.remove_class("hidden")
            openai_vad.add_class("hidden")
            gemini_vad.remove_class("hidden")

    def on_input_submitted(self, event: Input.Submitted) -> None:
        self._save_and_dismiss()

    def _save_and_dismiss(self) -> None:
        radio = self.query_one("#provider-radio", RadioSet)
        api_key = self.query_one("#api-key-input", Input).value.strip()

        if not api_key:
            self.notify("API key is required", severity="warning")
            return

        providers = ["openai", "azure", "gemini"]
        provider = providers[radio.pressed_index] if radio.pressed_index < len(providers) else "openai"

        # Per-provider voice selects
        openai_voice_sel = self.query_one("#openai-voice-select", Select)
        openai_voice = openai_voice_sel.value if openai_voice_sel.value != Select.BLANK else "ash"
        azure_voice_sel = self.query_one("#azure-voice-select", Select)
        azure_voice = azure_voice_sel.value if azure_voice_sel.value != Select.BLANK else "ash"
        gemini_voice_sel = self.query_one("#gemini-voice-select", Select)
        gemini_voice = gemini_voice_sel.value if gemini_voice_sel.value != Select.BLANK else "Puck"

        language_select = self.query_one("#language-select", Select)
        language = language_select.value if language_select.value != Select.BLANK else "en"

        input_mode_select = self.query_one("#input-mode-select", Select)
        input_mode = input_mode_select.value if input_mode_select.value != Select.BLANK else "vad"

        permission_select = self.query_one("#permission-mode-select", Select)
        permission_mode = permission_select.value if permission_select.value != Select.BLANK else "bypass"

        # OpenAI/Azure VAD
        vad_threshold = self._parse_float("vad-threshold-input", 0.8, 0.0, 1.0)
        silence_duration = self._parse_int("silence-duration-input", 700, 100, 5000)
        prefix_padding = self._parse_int("prefix-padding-input", 300, 0, 2000)
        agent_timeout = self._parse_int("agent-timeout-input", 300, 30, 3600)

        # Gemini VAD
        start_sens_sel = self.query_one("#gemini-start-sensitivity", Select)
        start_sensitivity = start_sens_sel.value if start_sens_sel.value != Select.BLANK else "HIGH"
        end_sens_sel = self.query_one("#gemini-end-sensitivity", Select)
        end_sensitivity = end_sens_sel.value if end_sens_sel.value != Select.BLANK else "LOW"
        gemini_silence = self._parse_int("gemini-silence-duration-input", 700, 100, 5000)
        gemini_prefix = self._parse_int("gemini-prefix-padding-input", 100, 0, 2000)

        enabled_agents = []
        for _label, agent_id in get_agent_choices():
            switch = self.query_one(f"#setup-agent-{agent_id}", Switch)
            if switch.value:
                enabled_agents.append(agent_id)
        if not enabled_agents:
            self.notify("Select at least one coding agent", severity="warning")
            return

        openai_model = self.query_one("#openai-model-input", Input).value.strip() or OPENAI_DEFAULT_MODEL
        azure_endpoint = self.query_one("#azure-endpoint-input", Input).value.strip() or AZURE_DEFAULT_ENDPOINT
        azure_deployment = self.query_one("#azure-deployment-input", Input).value.strip() or AZURE_DEFAULT_DEPLOYMENT
        gemini_model = self.query_one("#gemini-model-input", Input).value.strip() or GEMINI_DEFAULT_MODEL

        settings = RealtimeSettings(
            provider=provider,
            api_key=api_key,
            openai=OpenAIConfig(
                model=openai_model,
                voice=openai_voice,
                vad_threshold=vad_threshold,
                silence_duration_ms=silence_duration,
                prefix_padding_ms=prefix_padding,
            ),
            azure=AzureConfig(
                endpoint=azure_endpoint,
                deployment=azure_deployment,
                voice=azure_voice,
                vad_threshold=vad_threshold,
                silence_duration_ms=silence_duration,
                prefix_padding_ms=prefix_padding,
            ),
            gemini=GeminiConfig(
                model=gemini_model,
                voice=gemini_voice,
                start_sensitivity=start_sensitivity,
                end_sensitivity=end_sensitivity,
                silence_duration_ms=gemini_silence,
                prefix_padding_ms=gemini_prefix,
            ),
            agent_timeout=agent_timeout,
            language=language,
            permission_mode=permission_mode,
            input_mode=input_mode,
            enabled_agents=enabled_agents,
        )
        settings.save()
        self.dismiss(settings)

    def _parse_float(self, input_id: str, default: float, lo: float, hi: float) -> float:
        raw = self.query_one(f"#{input_id}", Input).value.strip()
        try:
            val = float(raw)
            return max(lo, min(hi, val))
        except ValueError:
            return default

    def _parse_int(self, input_id: str, default: int, lo: int, hi: int) -> int:
        raw = self.query_one(f"#{input_id}", Input).value.strip()
        try:
            val = int(raw)
            return max(lo, min(hi, val))
        except ValueError:
            return default

    def action_cancel(self) -> None:
        self.dismiss(None)
