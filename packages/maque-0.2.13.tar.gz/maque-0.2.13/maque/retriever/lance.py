#! /usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LanceDB 检索器实现

嵌入式向量数据库，适合百万~千万级数据，填补 ChromaDB（轻量）和 Milvus（分布式）之间的空白。
"""

import json
from typing import List, Optional, Union, Literal

from loguru import logger

from ..embedding.base import BaseEmbedding
from .document import Document, SearchResult, Modality, _content_hash


DistanceMetric = Literal["cosine", "l2"]


class LanceRetriever:
    """
    基于 LanceDB 的检索器
    支持文本和图片的向量检索，嵌入式高性能向量数据库
    """

    def __init__(
        self,
        embedding: BaseEmbedding,
        persist_dir: str,
        table_name: str = "default",
        distance_metric: DistanceMetric = "cosine",
    ):
        """
        初始化检索器

        Args:
            embedding: Embedding 实例（TextEmbedding 或 MultiModalEmbedding）
            persist_dir: 持久化目录（必填，LanceDB 基于文件系统）
            table_name: 表名称（对应 collection_name）
            distance_metric: 距离度量方式 (cosine/l2)
        """
        import lancedb

        self.embedding = embedding
        self.persist_dir = persist_dir
        self.table_name = table_name
        self.distance_metric = distance_metric

        self.db = lancedb.connect(persist_dir)
        self._table = None
        self._dim = None

        # 尝试打开已有表
        if table_name in self.db.list_tables():
            self._table = self.db.open_table(table_name)
            logger.info(f"Table '{table_name}' opened, {self.count()} documents")
        else:
            logger.info(f"Table '{table_name}' will be created on first insert")

    def _get_or_create_table(self, dim: int):
        """获取或创建表"""
        import pyarrow as pa
        import lancedb

        if self._table is not None:
            return self._table

        self._dim = dim
        schema = pa.schema([
            pa.field("id", pa.string()),
            pa.field("content", pa.string()),
            pa.field("modality", pa.string()),
            pa.field("metadata", pa.string()),
            pa.field("vector", pa.list_(pa.float32(), dim)),
        ])
        self._table = self.db.create_table(self.table_name, schema=schema)
        logger.info(f"Table '{self.table_name}' created with dim={dim}")
        return self._table

    def _embed_documents(self, documents: List[Document]) -> List[List[float]]:
        """对文档进行向量化"""
        if not documents:
            return []

        has_image = any(doc.is_image for doc in documents)
        if has_image and not self.embedding.supports_image:
            raise ValueError("Embedding 不支持图片，但文档中包含图片。请使用 MultiModalEmbedding。")

        if has_image:
            embeddings = []
            for doc in documents:
                input_type = "image" if doc.modality == "image" else "text"
                vec = self.embedding.embed([doc.content], input_type=input_type)[0]
                embeddings.append(vec)
            return embeddings
        else:
            contents = [doc.content for doc in documents]
            return self.embedding.embed(contents)

    def _embed_query(self, query: str, query_type: Modality = "text") -> List[float]:
        """对查询进行向量化"""
        if query_type == "image" and not self.embedding.supports_image:
            raise ValueError("Embedding 不支持图片查询")

        if self.embedding.supports_image:
            input_type = "image" if query_type == "image" else "text"
            return self.embedding.embed([query], input_type=input_type)[0]
        else:
            return self.embedding.embed([query])[0]

    def _embed_queries(self, queries: List[str], query_type: Modality = "text") -> List[List[float]]:
        """对多个查询进行批量向量化"""
        if not queries:
            return []

        if query_type == "image" and not self.embedding.supports_image:
            raise ValueError("Embedding 不支持图片查询")

        if self.embedding.supports_image:
            input_type = "image" if query_type == "image" else "text"
            return self.embedding.embed(queries, input_type=input_type)
        else:
            return self.embedding.embed(queries)

    def _docs_to_records(self, documents: List[Document], embeddings: List[List[float]]) -> List[dict]:
        """将文档和向量转为 LanceDB 记录"""
        records = []
        for doc, vec in zip(documents, embeddings):
            records.append({
                "id": doc.id,
                "content": doc.content,
                "modality": doc.modality,
                "metadata": json.dumps(doc.metadata, ensure_ascii=False),
                "vector": vec,
            })
        return records

    def _distance_to_score(self, distance: float) -> float:
        """距离转相似度"""
        if self.distance_metric == "cosine":
            return 1 - distance
        else:
            return -distance

    # ========== 索引操作 ==========

    def add(
        self,
        documents: Union[Document, List[Document]],
        skip_existing: bool = False,
    ) -> List[str]:
        """
        添加文档

        Args:
            documents: 单个文档或文档列表
            skip_existing: 是否跳过已存在的文档

        Returns:
            添加的文档 ID 列表
        """
        if isinstance(documents, Document):
            documents = [documents]
        if not documents:
            return []

        if skip_existing:
            existing_ids = self._get_existing_ids([doc.id for doc in documents])
            documents = [doc for doc in documents if doc.id not in existing_ids]
            if not documents:
                return []

        embeddings = self._embed_documents(documents)
        records = self._docs_to_records(documents, embeddings)
        table = self._get_or_create_table(len(embeddings[0]))
        table.add(records)

        ids = [doc.id for doc in documents]
        logger.debug(f"Added {len(documents)} documents")
        return ids

    def upsert(
        self,
        documents: Union[Document, List[Document]],
        skip_existing: bool = False,
    ) -> List[str]:
        """
        添加或更新文档

        Args:
            documents: 单个文档或文档列表
            skip_existing: 是否跳过已存在的文档

        Returns:
            upsert 的文档 ID 列表
        """
        if isinstance(documents, Document):
            documents = [documents]
        if not documents:
            return []

        if skip_existing:
            existing_ids = self._get_existing_ids([doc.id for doc in documents])
            documents = [doc for doc in documents if doc.id not in existing_ids]
            if not documents:
                return []

        embeddings = self._embed_documents(documents)
        records = self._docs_to_records(documents, embeddings)
        table = self._get_or_create_table(len(embeddings[0]))

        table.merge_insert("id").when_matched_update_all().when_not_matched_insert_all().execute(records)

        ids = [doc.id for doc in documents]
        logger.debug(f"Upserted {len(documents)} documents")
        return ids

    def delete(self, ids: Union[str, List[str]]) -> None:
        """
        删除文档

        Args:
            ids: 单个 ID 或 ID 列表
        """
        if self._table is None:
            return

        if isinstance(ids, str):
            ids = [ids]

        # LanceDB 使用 SQL 风格的 where 过滤
        id_list = ", ".join(f"'{id_}'" for id_ in ids)
        self._table.delete(f"id IN ({id_list})")
        logger.debug(f"Deleted {len(ids)} documents")

    def delete_by_content(self, contents: Union[str, List[str]]) -> None:
        """
        根据内容删除文档

        Args:
            contents: 单个内容或内容列表
        """
        if isinstance(contents, str):
            contents = [contents]

        ids = [_content_hash(content) for content in contents]
        self.delete(ids)

    # ========== 检索操作 ==========

    def search(
        self,
        query: str,
        top_k: int = 5,
        query_type: Modality = "text",
        where: Optional[str] = None,
    ) -> List[SearchResult]:
        """
        检索相似文档

        Args:
            query: 查询内容（文本或图片路径/URL）
            top_k: 返回数量
            query_type: 查询类型 "text" / "image"
            where: SQL 风格过滤条件，如 "category = 'tech'"

        Returns:
            SearchResult 列表
        """
        query_embedding = self._embed_query(query, query_type)
        return self.search_by_vector(query_embedding, top_k=top_k, where=where)

    def search_batch(
        self,
        queries: List[str],
        top_k: int = 5,
        query_type: Modality = "text",
        where: Optional[str] = None,
    ) -> List[List[SearchResult]]:
        """
        批量检索相似文档

        Args:
            queries: 查询内容列表
            top_k: 每个查询返回的数量
            query_type: 查询类型
            where: SQL 风格过滤条件

        Returns:
            SearchResult 列表的列表
        """
        if not queries:
            return []

        query_embeddings = self._embed_queries(queries, query_type)
        return self.search_by_vectors(query_embeddings, top_k=top_k, where=where)

    def search_by_vector(
        self,
        vector: List[float],
        top_k: int = 5,
        where: Optional[str] = None,
    ) -> List[SearchResult]:
        """
        直接使用向量检索

        Args:
            vector: 查询向量
            top_k: 返回数量
            where: SQL 风格过滤条件

        Returns:
            SearchResult 列表
        """
        if self._table is None:
            return []

        q = self._table.search(vector, vector_column_name="vector").metric(self.distance_metric).limit(top_k)
        if where:
            q = q.where(where)

        results = q.to_list()
        return self._parse_results(results)

    def search_by_vectors(
        self,
        vectors: List[List[float]],
        top_k: int = 5,
        where: Optional[str] = None,
    ) -> List[List[SearchResult]]:
        """
        批量使用向量检索

        Args:
            vectors: 查询向量列表
            top_k: 每个查询返回的数量
            where: SQL 风格过滤条件

        Returns:
            SearchResult 列表的列表
        """
        if not vectors:
            return []

        return [self.search_by_vector(vec, top_k=top_k, where=where) for vec in vectors]

    def _parse_results(self, results: list) -> List[SearchResult]:
        """解析 LanceDB 查询结果"""
        search_results = []
        for row in results:
            metadata = json.loads(row["metadata"]) if row.get("metadata") else {}
            distance = row.get("_distance", 0)
            score = self._distance_to_score(distance)

            search_results.append(SearchResult(
                id=row["id"],
                content=row["content"],
                score=score,
                modality=row.get("modality", "text"),
                metadata=metadata,
            ))
        return search_results

    # ========== 管理操作 ==========

    def get(
        self,
        ids: Optional[Union[str, List[str]]] = None,
        where: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[Document]:
        """
        获取文档

        Args:
            ids: 文档 ID 或 ID 列表
            where: SQL 风格过滤条件
            limit: 返回数量限制

        Returns:
            Document 列表
        """
        if self._table is None:
            return []

        table = self._table

        # 构建过滤条件
        conditions = []
        if ids is not None:
            if isinstance(ids, str):
                ids = [ids]
            id_list = ", ".join(f"'{id_}'" for id_ in ids)
            conditions.append(f"id IN ({id_list})")
        if where:
            conditions.append(where)

        if conditions:
            combined = " AND ".join(conditions)
            results = table.search().where(combined, prefilter=True).limit(limit or 1000000).to_list()
        else:
            results = table.search().limit(limit or 1000000).to_list()

        documents = []
        for row in results:
            metadata = json.loads(row["metadata"]) if row.get("metadata") else {}
            documents.append(Document(
                id=row["id"],
                content=row["content"],
                modality=row.get("modality", "text"),
                metadata=metadata,
            ))
        return documents

    def count(self) -> int:
        """返回文档数量"""
        if self._table is None:
            return 0
        return self._table.count_rows()

    def clear(self) -> None:
        """清空表"""
        logger.info(f"Clearing table: {self.table_name}")
        if self.table_name in self.db.list_tables():
            self.db.drop_table(self.table_name)
        self._table = None
        logger.info(f"Table '{self.table_name}' cleared")

    def get_all_ids(self) -> List[str]:
        """获取所有文档 ID"""
        if self._table is None:
            return []
        results = self._table.to_pandas()["id"].tolist()
        return results

    # ========== 便利方法 ==========

    def upsert_batch(
        self,
        documents: List[Document],
        batch_size: int = 32,
        skip_existing: bool = False,
        show_progress: bool = True,
    ) -> int:
        """
        批量插入文档（带进度条和增量更新支持）

        Args:
            documents: 文档列表
            batch_size: 批处理大小
            skip_existing: 是否跳过已存在的文档
            show_progress: 是否显示进度条

        Returns:
            实际插入的文档数量
        """
        if not documents:
            return 0

        total_docs = len(documents)
        logger.info(f"Starting batch upsert: {total_docs} documents, batch_size={batch_size}")

        skipped = 0
        if skip_existing:
            existing_ids = self._get_existing_ids([doc.id for doc in documents])
            skipped = len([doc for doc in documents if doc.id in existing_ids])
            documents = [doc for doc in documents if doc.id not in existing_ids]
            if skipped > 0:
                logger.info(f"Skipped {skipped} existing documents")
            if not documents:
                return 0

        inserted = 0
        total_batches = (len(documents) + batch_size - 1) // batch_size
        iterator = range(0, len(documents), batch_size)

        if show_progress:
            try:
                from tqdm import tqdm
                iterator = tqdm(iterator, desc="Upserting", total=total_batches, unit="batch")
            except ImportError:
                logger.debug("tqdm not installed, progress bar disabled")

        for i in iterator:
            batch = documents[i:i + batch_size]
            self.upsert(batch)
            inserted += len(batch)

        logger.info(f"Batch upsert completed: {inserted} inserted, {skipped} skipped")
        return inserted

    def _get_existing_ids(self, candidate_ids: List[str]) -> set:
        """获取已存在的文档 ID 集合"""
        if self._table is None:
            return set()

        all_ids = set(self.get_all_ids())
        return all_ids.intersection(candidate_ids)

    def migrate_to(
        self,
        target,
        batch_size: int = 100,
        skip_existing: bool = True,
        show_progress: bool = True,
    ) -> int:
        """
        将当前表的所有数据迁移到目标 retriever

        Args:
            target: 目标 retriever
            batch_size: 批处理大小
            skip_existing: 是否跳过已存在的文档
            show_progress: 是否显示进度条

        Returns:
            迁移的文档数量
        """
        all_ids = self.get_all_ids()
        if not all_ids:
            logger.info("No documents to migrate")
            return 0

        total = len(all_ids)
        logger.info(f"Starting migration: {total} documents")

        migrated = 0
        iterator = range(0, total, batch_size)

        if show_progress:
            try:
                from tqdm import tqdm
                iterator = tqdm(
                    iterator,
                    desc="Migrating",
                    total=(total + batch_size - 1) // batch_size,
                    unit="batch",
                )
            except ImportError:
                pass

        for i in iterator:
            batch_ids = all_ids[i:i + batch_size]
            documents = self.get(ids=batch_ids)
            if documents:
                migrated += target.upsert_batch(
                    documents,
                    batch_size=batch_size,
                    skip_existing=skip_existing,
                    show_progress=False,
                )

        logger.info(f"Migration completed: {migrated} documents migrated")
        return migrated

    def __repr__(self) -> str:
        return (
            f"LanceRetriever("
            f"table={self.table_name!r}, "
            f"count={self.count()}, "
            f"embedding={self.embedding.__class__.__name__})"
        )
