"""Explicator adapters — CLI, MCP server, and data implementations."""
