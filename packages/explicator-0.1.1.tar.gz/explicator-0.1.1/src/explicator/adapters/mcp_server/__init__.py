"""MCP server adapter for Explicator."""
