"""CLI adapter for Explicator."""
