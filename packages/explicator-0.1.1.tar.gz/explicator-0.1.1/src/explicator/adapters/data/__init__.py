"""In-memory data adapters for Explicator."""
