"""Core domain models and port interfaces for Explicator."""
