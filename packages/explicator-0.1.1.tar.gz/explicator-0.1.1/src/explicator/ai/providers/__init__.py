"""Concrete AI provider adapters (Claude, Azure OpenAI)."""
