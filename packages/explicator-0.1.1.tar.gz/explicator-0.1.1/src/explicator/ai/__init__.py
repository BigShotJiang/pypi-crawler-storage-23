"""AI provider abstractions and tool dispatch for Explicator."""
