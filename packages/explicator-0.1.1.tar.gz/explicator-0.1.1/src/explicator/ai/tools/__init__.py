"""Tool definitions in OpenAI function-calling JSON schema format."""
