"""ERDDAP MCP Server — Universal ERDDAP Data Access for AI Assistants."""
