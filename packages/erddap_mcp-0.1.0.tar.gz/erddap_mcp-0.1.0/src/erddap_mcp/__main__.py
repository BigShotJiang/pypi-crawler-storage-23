"""Allow running the package with python -m erddap_mcp."""

from .server import main

main()
