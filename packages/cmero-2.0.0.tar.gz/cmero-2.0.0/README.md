<p align="center">
  <img src="https://img.shields.io/badge/CMeRo-v2.0.0-blue?style=flat-square&logo=python" alt="CMeRo Version">
  <img src="https://img.shields.io/badge/Python-3.8%2B-green?style=flat-square&logo=python" alt="Python Support">
  <img src="https://img.shields.io/badge/Platform-Windows%20%7C%20Linux%20%7C%20macOS-lightgrey?style=flat-square" alt="Platforms">
  <img src="https://img.shields.io/badge/Developer-MERO:TG@QP4RM-red?style=flat-square" alt="Developer MERO">
</p>

# CMeRo

CMeRo is a Python-to-C/C++ compiler based on Cython. It is designed to compile standard Python (`.py`) and Cython (`.pyx`) files into standalone C/C++ code. It also provides tools to build executable binaries (EXE) and shared libraries (DLL, SO, PYD), alongside a built-in code obfuscation feature.

---

## Features

- **Standard Python Compilation:** Compiles regular `.py` scripts and `.pyx` files directly to C or C++ extensions.
- **Code Obfuscation (`--obf`):** Built-in obfuscation pipeline that includes:
  - String literal encoding (replaces strings with byte arrays evaluated at runtime).
  - Local variable renaming.
  - Opaque predicate injection (dead code blocks).
- **Binary Generation:** Direct build targets for standalone executables (`--target exe`), dynamic link libraries (`--target dll`), and shared objects (`--target so`).
- **External Dependencies:** Supports compiling projects that utilize external Python libraries (e.g., `requests`, `openai`).

---

## Installation

You can install CMeRo directly via pip:

```bash
pip install CMeRo
```

Or install from the source repository:

```bash
git clone https://github.com/6x-u/CMeRo
cd CMeRo
pip install .
```

---

## Command Line Usage

CMeRo operates primarily as a command-line tool. Below are the common use cases.

### Standard Compilation to C
Compiles a Python file to C source code (`script.c`):
```bash
CMeRo script.py
```

### Compilation with Obfuscation
Compiles the file while applying the obfuscation pipeline:
```bash
CMeRo --obf script.py
```

### Building a Dynamic/Standalone Binary (DLL/SO/ELF)
Compiles a Python script to C++ and builds a shared library or standalone binary:
```bash
CMeRo --obf --cplus --target dll script.py
```
*Note: Use `--target so` for Linux shared objects, or `--target elf` for Linux/Android executable binaries.*

### Building a Standalone Executable (EXE / ELF)
Compiles a Python script into a standalone executable (Windows `exe` or Android/Linux `elf`):
```bash
# For Windows (EXE)
CMeRo --obf --target exe script.py

# For Linux / Android (ELF)
CMeRo --obf --embed --target elf script.py
```

---

## Integration with `setup.py`

CMeRo can be integrated into standard Python build processes using `setuptools`.

**Example `setup.py`:**

```python
from setuptools import setup
from CMeRo.Build import CMeRoize

setup(
    name="MyApplication",
    version="1.0.0",
    ext_modules=CMeRoize(
        ["my_app/*.py"],
        compiler_directives={'language_level': "3"}
    ),
)
```

**Build command:**
```bash
python setup.py build_ext --inplace
```

---

## Advanced CLI Options

| Option | Description |
|--------|-------------|
| `-V` or `--version` | Print the current CMeRo version and developer credits. |
| `-o FILE` | Specify the output C/C++ file name. |
| `-3` | Force compilation using Python 3 language semantics (default). |
| `--cplus` | Output C++ code instead of C. |
| `--arch x64\|x86` | Specify the target build architecture. |
| `--icon FILE` | Embed an `.ico` icon file into the generated EXE (Windows only). |
| `-D` or `--no-docstrings` | Strip all docstrings from the compiled output. |

---

## License & Credits

Developed by **MERO:TG@QP4RM**.

Released under the **Apache License 2.0**.
