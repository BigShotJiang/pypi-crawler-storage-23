#!/usr/bin/env python3

#
#   CMeRo -- enhanced main program
#

if __name__ == '__main__':
    from CMeRo.Build.CMeRoize import main
    main()
