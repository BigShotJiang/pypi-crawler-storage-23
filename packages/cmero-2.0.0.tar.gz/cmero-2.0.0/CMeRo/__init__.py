__version__ = "2.0.0"

# Void CMeRo.* directives (for case insensitive operating systems).
from .Shadow import *


def load_ipython_extension(ip):
    """Load the extension in IPython."""
    from .Build.IpythonMagic import CMeRoMagics  # pylint: disable=cyclic-import
    ip.register_magics(CMeRoMagics)
