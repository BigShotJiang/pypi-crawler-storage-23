import random
import string
from CMeRo.Compiler.Visitor import CMeRoTransform
from CMeRo.Compiler.Nodes import *
from CMeRo.Compiler.ExprNodes import *
from CMeRo.Compiler import Nodes
from CMeRo.Compiler import ExprNodes
from CMeRo.Compiler import PyrexTypes
from CMeRo.Compiler.StringEncoding import EncodedString


class ObfuscationInjector(CMeRoTransform):
    def __init__(self, context):
        super(ObfuscationInjector, self).__init__(context)
        self.context = context
        self.decrypt_func_name = self._generate_random_name()
        self.xor_key = random.randint(1, 255)

    def _generate_random_name(self, length=12):
        return ''.join(random.choices(string.ascii_letters, k=length))

    def visit_BytesNode(self, node):
        if not getattr(node, 'is_string_literal', False):
            return node

        s_val = node.value
        if not s_val:
            return node

        try:
            chars = [IntNode(node.pos, value=str(b), constant_result=b) for b in s_val]
            list_node = ListNode(node.pos, args=chars)
            return SimpleCallNode(node.pos,
                function=NameNode(node.pos, name=EncodedString('bytes')),
                args=[list_node]
            )
        except Exception:
            return node

    def visit_UnicodeNode(self, node):
        if not getattr(node, 'is_string_literal', False):
            return node

        try:
            encoded_val = node.value.encode('utf-8')
        except Exception:
            return node

        if not encoded_val:
            return node

        try:
            chars = [IntNode(node.pos, value=str(b), constant_result=b) for b in encoded_val]
            list_node = ListNode(node.pos, args=chars)
            bytes_call = SimpleCallNode(node.pos,
                function=NameNode(node.pos, name=EncodedString('bytes')),
                args=[list_node]
            )

            decode_attr = AttributeNode(node.pos,
                obj=bytes_call,
                attribute=EncodedString('decode'))

            utf8_str = EncodedString('utf-8')
            args = [UnicodeNode(node.pos, value=utf8_str, is_string_literal=False)]

            decode_call = SimpleCallNode(node.pos,
                function=decode_attr,
                args=args
            )

            return decode_call
        except Exception:
            return node

    def visit_ModuleNode(self, node):
        print(" [CMERO] Obfuscating Module: " + str(node.full_module_name))
        self.visitchildren(node)
        return node

    def visit_DefNode(self, node):
        if random.random() > 0.5:
            try:
                junk_val = random.randint(0, 1000)
                junk_node = IfStatNode(node.pos,
                    if_clauses=[
                        IfClauseNode(node.pos,
                            condition=BinopNode(node.pos, operator='==',
                                operand1=IntNode(node.pos, value=str(junk_val), constant_result=junk_val),
                                operand2=IntNode(node.pos, value=str(junk_val+1), constant_result=junk_val+1)
                            ),
                            body=PassStatNode(node.pos)
                        )
                    ],
                    else_clause=None
                )
                if hasattr(node, 'body') and hasattr(node.body, 'stats'):
                    node.body.stats.insert(0, junk_node)
            except Exception:
                pass

        self.visitchildren(node)
        return node


class ObfuscationRenamer(CMeRoTransform):
    def __init__(self, context):
        super(ObfuscationRenamer, self).__init__(context)
        self.context = context
        self.prefix = ''.join(random.choices(string.ascii_letters, k=6))

    def _generate_random_name(self, length=12):
        return ''.join(random.choices(string.ascii_letters, k=length))

    def visit_DefNode(self, node):
        if hasattr(node, 'local_scope') and node.local_scope:
            for entry in node.local_scope.entries.values():
                try:
                    if (entry.is_local and
                        not entry.is_arg and
                        not entry.is_self_arg and
                        not entry.is_pyglobal and
                        not entry.is_cglobal and
                        not entry.name.startswith('__') and
                        not entry.name.startswith('_CMeRo') and
                        not entry.name == 'self'):

                        new_name = self.prefix + "_" + self._generate_random_name(6)
                        entry.cname = new_name
                except Exception:
                    pass

        self.visitchildren(node)
        return node
