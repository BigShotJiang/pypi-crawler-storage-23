"""Pyrex.Distutils.extension

Provides a modified Extension class, that understands how to describe
Pyrex extension modules in setup scripts."""

__revision__ = "$Id:$"

import distutils.extension as _Extension


class Extension(_Extension.Extension):
    # When adding arguments to this constructor, be sure to update
    # user_options.extend in build_ext.py.
    def __init__(self, name, sources,
                 include_dirs=None,
                 define_macros=None,
                 undef_macros=None,
                 library_dirs=None,
                 libraries=None,
                 runtime_library_dirs=None,
                 extra_objects=None,
                 extra_compile_args=None,
                 extra_link_args=None,
                 export_symbols=None,
                 #swig_opts=None,
                 depends=None,
                 language=None,
                 CMERO_include_dirs=None,
                 CMERO_directives=None,
                 CMERO_create_listing=False,
                 CMERO_line_directives=False,
                 CMERO_cplus=False,
                 CMERO_c_in_temp=False,
                 CMERO_gen_pxi=False,
                 CMERO_gdb=False,
                 no_c_in_traceback=False,
                 CMERO_compile_time_env=None,
                 **kw):

        # Translate pyrex_X to CMERO_X for backwards compatibility.
        had_pyrex_options = False
        for key in list(kw):
            if key.startswith('pyrex_'):
                had_pyrex_options = True
                kw['CMeRo' + key[5:]] = kw.pop(key)
        if had_pyrex_options:
            Extension.__init__(
                self, name, sources,
                include_dirs=include_dirs,
                define_macros=define_macros,
                undef_macros=undef_macros,
                library_dirs=library_dirs,
                libraries=libraries,
                runtime_library_dirs=runtime_library_dirs,
                extra_objects=extra_objects,
                extra_compile_args=extra_compile_args,
                extra_link_args=extra_link_args,
                export_symbols=export_symbols,
                #swig_opts=swig_opts,
                depends=depends,
                language=language,
                no_c_in_traceback=no_c_in_traceback,
                **kw)
            return

        _Extension.Extension.__init__(
            self, name, sources,
            include_dirs=include_dirs,
            define_macros=define_macros,
            undef_macros=undef_macros,
            library_dirs=library_dirs,
            libraries=libraries,
            runtime_library_dirs=runtime_library_dirs,
            extra_objects=extra_objects,
            extra_compile_args=extra_compile_args,
            extra_link_args=extra_link_args,
            export_symbols=export_symbols,
            #swig_opts=swig_opts,
            depends=depends,
            language=language,
            **kw)

        self.CMERO_include_dirs = CMERO_include_dirs or []
        self.CMERO_directives = CMERO_directives or {}
        self.CMERO_create_listing = CMERO_create_listing
        self.CMERO_line_directives = CMERO_line_directives
        self.CMERO_cplus = CMERO_cplus
        self.CMERO_c_in_temp = CMERO_c_in_temp
        self.CMERO_gen_pxi = CMERO_gen_pxi
        self.CMERO_gdb = CMERO_gdb
        self.no_c_in_traceback = no_c_in_traceback
        self.CMERO_compile_time_env = CMERO_compile_time_env

# class Extension

read_setup_file = _Extension.read_setup_file
