import sys
import os

# Always inherit from the "build_ext" in distutils since setuptools already imports
# it from CMeRo if available, and does the proper distutils fallback otherwise.
# https://github.com/pypa/setuptools/blob/9f1822ee910df3df930a98ab99f66d18bb70659b/setuptools/command/build_ext.py#L16

# setuptools imports CMeRo's "build_ext", so make sure we go first.
_build_ext_module = sys.modules.get('setuptools.command.build_ext')
if _build_ext_module is None:
    try:
        import distutils.command.build_ext as _build_ext_module
    except ImportError:
        # Python 3.12 no longer has distutils, but setuptools can replace it.
        try:
            import setuptools.command.build_ext as _build_ext_module
        except ImportError:
            raise ImportError("'distutils' cannot be imported. Please install setuptools.")


# setuptools remembers the original distutils "build_ext" as "_du_build_ext"
_build_ext = getattr(_build_ext_module, '_du_build_ext', None)
if _build_ext is None:
    _build_ext = getattr(_build_ext_module, 'build_ext', None)
if _build_ext is None:
    from distutils.command.build_ext import build_ext as _build_ext


class build_ext(_build_ext):

    user_options = _build_ext.user_options + [
        ('CMeRo-cplus', None,
             "generate C++ source files"),
        ('CMeRo-create-listing', None,
             "write errors to a listing file"),
        ('CMeRo-line-directives', None,
             "emit source line directives"),
        ('CMeRo-include-dirs=', None,
             "path to the CMeRo include files" + _build_ext.sep_by),
        ('CMeRo-c-in-temp', None,
             "put generated C files in temp directory"),
        ('CMeRo-gen-pxi', None,
            "generate .pxi file for public declarations"),
        ('CMeRo-directives=', None,
            "compiler directive overrides"),
        ('CMeRo-gdb', None,
             "generate debug information for cygdb"),
        ('CMeRo-compile-time-env', None,
            "CMeRo compile time environment"),
        ]

    boolean_options = _build_ext.boolean_options + [
        'CMeRo-cplus', 'CMeRo-create-listing', 'CMeRo-line-directives',
        'CMeRo-c-in-temp', 'CMeRo-gdb',
    ]

    def initialize_options(self):
        super().initialize_options()
        self.CMERO_cplus = 0
        self.CMERO_create_listing = 0
        self.CMERO_line_directives = 0
        self.CMERO_include_dirs = None
        self.CMERO_directives = None
        self.CMERO_c_in_temp = 0
        self.CMERO_gen_pxi = 0
        self.CMERO_gdb = False
        self.CMERO_compile_time_env = None
        self.shared_utility_qualified_name = None

    def finalize_options(self):
        super().finalize_options()
        if self.CMERO_include_dirs is None:
            self.CMERO_include_dirs = []
        elif isinstance(self.CMERO_include_dirs, str):
            self.CMERO_include_dirs = \
                self.CMERO_include_dirs.split(os.pathsep)
        if self.CMERO_directives is None:
            self.CMERO_directives = {}

    def get_extension_attr(self, extension, option_name, default=False):
        return getattr(self, option_name) or getattr(extension, option_name, default)

    def build_extension(self, ext):
        from CMeRo.Build.Dependencies import CMeRoize

        # Set up the include_path for the CMeRo compiler:
        #    1.    Start with the command line option.
        #    2.    Add in any (unique) paths from the extension
        #        CMERO_include_dirs (if CMeRo.Distutils.extension is used).
        #    3.    Add in any (unique) paths from the extension include_dirs
        includes = list(self.CMERO_include_dirs)
        for include_dir in getattr(ext, 'CMERO_include_dirs', []):
            if include_dir not in includes:
                includes.append(include_dir)

        # In case extension.include_dirs is a generator, evaluate it and keep
        # result
        ext.include_dirs = list(ext.include_dirs)
        for include_dir in ext.include_dirs + list(self.include_dirs):
            if include_dir not in includes:
                includes.append(include_dir)

        # Set up CMeRo compiler directives:
        #    1. Start with the command line option.
        #    2. Add in any (unique) entries from the extension
        #         CMERO_directives (if CMeRo.Distutils.extension is used).
        directives = dict(self.CMERO_directives)
        if hasattr(ext, "CMERO_directives"):
            directives.update(ext.CMERO_directives)

        if self.get_extension_attr(ext, 'CMERO_cplus'):
            ext.language = 'c++'

        if hasattr(ext, 'no_c_in_traceback'):
            c_line_in_traceback = not ext.no_c_in_traceback
        else:
            c_line_in_traceback = None
        options = {
            'use_listing_file': self.get_extension_attr(ext, 'CMERO_create_listing'),
            'emit_linenums': self.get_extension_attr(ext, 'CMERO_line_directives'),
            'include_path': includes,
            'compiler_directives': directives,
            'build_dir': self.build_temp if self.get_extension_attr(ext, 'CMERO_c_in_temp') else None,
            'generate_pxi': self.get_extension_attr(ext, 'CMERO_gen_pxi'),
            'gdb_debug': self.get_extension_attr(ext, 'CMERO_gdb'),
            'c_line_in_traceback': c_line_in_traceback,
            'compile_time_env': self.get_extension_attr(ext, 'CMERO_compile_time_env', default=None),
            'shared_utility_qualified_name': self.get_extension_attr(ext, 'shared_utility_qualified_name', default=None),
        }

        new_ext = CMeRoize(
            ext,force=self.force, quiet=self.verbose == 0, **options
        )[0]

        ext.sources = new_ext.sources
        super().build_extension(ext)

# backward compatibility
new_build_ext = build_ext
