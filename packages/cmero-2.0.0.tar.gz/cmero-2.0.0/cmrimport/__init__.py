from .cmrimport import *

# replicate docstring
from .cmrimport import __doc__
