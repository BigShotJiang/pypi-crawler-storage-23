"""Typed output models for agent kernel function tools."""

from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field
from rettxmutation.models.gene_models import GeneMutation


class BaseToolOutput(BaseModel):
    """Base class for all tool outputs. Tools never raise — they return this."""
    success: bool = Field(True, description="Whether the tool executed successfully")
    error: Optional[str] = Field(None, description="Error message if success=False")


class RegexCandidate(BaseModel):
    """A single regex-detected candidate."""
    value: str
    type: str  # "Variant", "gene_name", "reference_sequence"
    count: int = 1


class RegexToolOutput(BaseToolOutput):
    """Output from regex_extract tool."""
    candidates: List[RegexCandidate] = Field(default_factory=list)


class TextAnalyticsEntity(BaseModel):
    """A single entity from Text Analytics."""
    text: str
    category: str
    confidence_score: Optional[float] = None


class TextAnalyticsToolOutput(BaseToolOutput):
    """Output from text_analytics_extract tool."""
    entities: List[TextAnalyticsEntity] = Field(default_factory=list)


class SearchResult(BaseModel):
    """A single AI Search result."""
    score: Optional[float] = None
    data: Dict[str, Any] = Field(default_factory=dict)


class SearchToolOutput(BaseToolOutput):
    """Output from ai_search_enrich tool."""
    results: List[SearchResult] = Field(default_factory=list)


class ValidatorToolOutput(BaseToolOutput):
    """Output from validate_variant tool."""
    mutation: Optional[GeneMutation] = None


class ComplexValidatorToolOutput(BaseToolOutput):
    """Output from validate_complex tool."""
    mutation: Optional[GeneMutation] = None


class GeneInfo(BaseModel):
    """Gene information from registry lookup."""
    symbol: str
    name: str
    chromosome: str
    refseq_grch37: Optional[str] = Field(None, description="RefSeq accession for GRCh37, e.g. NC_000023.10")
    refseq_grch38: Optional[str] = Field(None, description="RefSeq accession for GRCh38, e.g. NC_000023.11")
    primary_transcript_mrna: str
    primary_transcript_protein: str
    secondary_transcript_mrna: Optional[str] = None
    secondary_transcript_protein: Optional[str] = None


class GeneRegistryToolOutput(BaseToolOutput):
    """Output from lookup_gene_registry tool."""
    gene: Optional[GeneInfo] = None
    all_known_genes: Optional[List[str]] = Field(
        None, description="All gene symbols in registry (returned when gene not found)"
    )


class HgvsParseResult(BaseModel):
    """Parsed HGVS components."""
    transcript: Optional[str] = None
    variant_type: str = "unknown"
    start: int = 0
    end: int = 0
    size: int = 0


class HgvsParserToolOutput(BaseToolOutput):
    """Output from parse_hgvs tool."""
    parsed: Optional[HgvsParseResult] = None
