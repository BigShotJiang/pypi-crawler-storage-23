"""Extraction result models for the agentic mutation extraction pipeline."""

from datetime import datetime
from typing import Dict, List, Optional
from pydantic import BaseModel, Field
from rettxmutation.models.gene_models import GeneMutation


class ExtractionLogEntry(BaseModel):
    """Single entry in the extraction log, capturing one agent action."""
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    action: str = Field(..., description="Action type: tool_call, tool_result, reasoning, validation_skip")
    tool: Optional[str] = Field(None, description="Kernel function name, if applicable")
    input_summary: str = Field("", description="Truncated input description (no PHI)")
    output_summary: str = Field("", description="Truncated output description")
    success: bool = Field(True, description="Whether the action succeeded")
    duration_ms: Optional[int] = Field(None, description="Execution time in milliseconds")


class ExtractionResult(BaseModel):
    """Result of agentic mutation extraction."""
    mutations: Dict[str, GeneMutation] = Field(
        default_factory=dict,
        description="Validated mutations keyed by GRCh38 genomic coordinate HGVS"
    )
    extraction_log: List[str] = Field(
        default_factory=list,
        description="Human-readable agent reasoning trace"
    )
    genes_detected: List[str] = Field(
        default_factory=list,
        description="Gene symbols detected in the input text"
    )
    tool_calls_count: int = Field(0, description="Total number of tool invocations")


class ExtractionError(Exception):
    """Raised when mutation extraction fails (LLM unavailable, timeout, etc.)."""
    def __init__(self, message: str, extraction_log: Optional[List[str]] = None):
        super().__init__(message)
        self.extraction_log = extraction_log or []
