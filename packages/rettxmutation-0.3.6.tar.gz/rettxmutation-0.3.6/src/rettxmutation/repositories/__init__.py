"""Repository layer for external service clients."""

# Repository Interfaces
from .interfaces import (
    AISearchRepositoryInterface,
    TextAnalyticsRepositoryInterface,
    VariantValidatorRepositoryInterface,
)

# Repository Implementations
from .text_analytics_repository import TextAnalyticsRepository
from .ai_search_repository import AISearchRepository
from .variant_validator_repository import (
    VariantValidatorRepository,
    VariantValidatorError,
    VariantValidatorNormalizationError,
)

__all__ = [
    # Interfaces
    "AISearchRepositoryInterface",
    "TextAnalyticsRepositoryInterface", 
    "VariantValidatorRepositoryInterface",
    # Implementations
    "TextAnalyticsRepository",
    "AISearchRepository",
    "VariantValidatorRepository",
    "VariantValidatorError",
    "VariantValidatorNormalizationError",
]
