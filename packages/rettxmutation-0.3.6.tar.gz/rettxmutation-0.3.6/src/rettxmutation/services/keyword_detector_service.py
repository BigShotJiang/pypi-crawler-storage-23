"""
Unified Keyword Detector Service

Service responsible for detecting gene-related keywords and variant patterns
using multiple methods: regex, text analytics, and AI search enrichment.
Follows the 3-layer architecture with automatic deduplication.
"""

import re
import logging
from typing import List, Optional
from collections import Counter

from rettxmutation.models.keyword_collection import Keyword, EnrichedKeyword, KeywordCollection
from rettxmutation.repositories.interfaces import TextAnalyticsRepositoryInterface
from rettxmutation.services.ai_search import AISearchService

logger = logging.getLogger(__name__)


class KeywordDetectorService:
    """
    Unified service for detecting keywords from multiple sources with automatic deduplication.
    
    This service orchestrates keyword detection through:
    1. Regex-based pattern matching
    2. Text analytics via repository
    3. AI search enrichment via service
    
    All results are unified in a KeywordCollection with surface-level deduplication.
    """

    def __init__(self, 
                 text_analytics_repository: Optional[TextAnalyticsRepositoryInterface] = None,
                 ai_search_service: Optional[AISearchService] = None):
        """Initialize the unified keyword detector service."""
        self._text_analytics_repository = text_analytics_repository
        self._ai_search_service = ai_search_service
        logger.debug("KeywordDetectorService initialized with unified detection capabilities")

    def detect_keywords(self, text: str) -> KeywordCollection:
        """
        Detect keywords from all sources and return a unified collection.
        
        Args:
            text: Plain text to analyze for keywords
            
        Returns:
            KeywordCollection: Unified collection with automatic deduplication
        """
        try:
            logger.debug("Starting unified keyword detection")
            collection = KeywordCollection()

            # 1. Regex-based detection
            regex_keywords = self._detect_regex_keywords(text)
            for keyword in regex_keywords:
                collection.add(keyword)
            logger.debug(f"Added {len(regex_keywords)} regex keywords to collection")

            # 2. Text analytics detection (via repository)
            if self._text_analytics_repository:
                analytics_keywords = self._detect_text_analytics_keywords(text)
                for keyword in analytics_keywords:
                    collection.add(keyword)
                logger.debug(f"Added text analytics keywords to collection")

            # 3. AI search enrichment (via service)
            if self._ai_search_service and len(collection) > 0:
                enriched_keywords = self._enrich_with_ai_search(collection)
                for enriched_keyword in enriched_keywords:
                    collection.add_enriched(enriched_keyword)
                logger.debug(f"Added AI search enriched keywords to collection")

            logger.debug(f"Keyword detection completed. Total unique keywords: {len(collection)}")
            return collection

        except Exception as e:
            logger.error(f"Unified keyword detection failed: {e}")
            return KeywordCollection()  # Return empty collection on error

    def _detect_regex_keywords(self, text: str) -> List[Keyword]:
        """
        Detect gene-related keywords and variant patterns using regex.
        
        Args:
            text: Cleaned text to analyze for keywords
            
        Returns:
            List[Keyword]: List of detected keywords with their types and counts
        """
        try:
            detected_keywords = []

            # Detect various types of keywords using existing patterns
            detected_keywords.extend(self._detect_gene_names(text))
            detected_keywords.extend(self._detect_c_variants(text))
            detected_keywords.extend(self._detect_p_variants(text))
            detected_keywords.extend(self._detect_genomic_coordinates(text))
            detected_keywords.extend(self._detect_reference_sequences(text))

            logger.debug(f"Regex detection found {len(detected_keywords)} keywords")
            return detected_keywords

        except Exception as e:
            logger.warning(f"Regex keyword detection failed: {e}")
            return []

    def _detect_text_analytics_keywords(self, text: str) -> List[Keyword]:
        """
        Detect keywords using Azure Text Analytics for Health.
        
        Args:
            text: Text to analyze
            
        Returns:
            List[Keyword]: Keywords detected by text analytics
        """
        try:
            if not self._text_analytics_repository:
                logger.debug("Text analytics repository not available, skipping")
                return []

            # Call repository to analyze healthcare entities
            analytics_result = self._text_analytics_repository.analyze_healthcare_entities(text)
            
            # Convert analytics results to Keywords
            keywords = self._convert_analytics_to_keywords(analytics_result)
            
            logger.debug(f"Text analytics detection found {len(keywords)} keywords")
            return keywords

        except Exception as e:
            logger.warning(f"Text analytics keyword detection failed: {e}")
            return []

    def _enrich_with_ai_search(self, collection: KeywordCollection) -> List[EnrichedKeyword]:
        """
        Enrich variant keywords with AI keyword search results.
        
        Args:
            collection: Current keyword collection
            
        Returns:
            List[EnrichedKeyword]: Variant keywords enriched with keyword search context
        """
        try:
            if not self._ai_search_service:
                logger.debug("AI search service not available, skipping enrichment")
                return []

            enriched_keywords = []
            
            # Get only "Variant" keywords for AI search enrichment
            variant_keywords = [kw for kw in collection.keywords_index.values() if kw.type == "Variant"]
            
            for keyword in variant_keywords:
                # Perform keyword search for each variant
                search_results = self._ai_search_service.keyword_search(keyword.value)
                
                if search_results:
                    # Take the first/best result
                    best_result = search_results[0] if search_results else None
                    enriched = EnrichedKeyword(
                        value=keyword.value,
                        type=keyword.type,
                        source="ai_search",
                        count=keyword.count,
                        confidence=keyword.confidence,
                        search_result=best_result
                    )
                    enriched_keywords.append(enriched)
            
            logger.debug(f"AI search enrichment processed {len(variant_keywords)} variants, found {len(enriched_keywords)} enriched keywords")
            return enriched_keywords

        except Exception as e:
            logger.warning(f"AI search enrichment failed: {e}")
            return []

    def _convert_analytics_to_keywords(self, analytics_result) -> List[Keyword]:
        """
        Convert Azure Text Analytics results to Keyword objects.
        
        Args:
            analytics_result: Results from text analytics
            
        Returns:
            List[Keyword]: Converted keywords
        """
        keywords = []
        
        try:            # Process the analytics results
            # Note: This is a simplified conversion - adjust based on actual analytics result structure
            for doc_result in analytics_result:
                if hasattr(doc_result, 'entities'):
                    for entity in doc_result.entities:
                        # Map categories to our keyword types
                        keyword_type = None
                        if entity.category == "Gene":
                            keyword_type = "gene_name"
                        elif entity.category == "Variant":
                            keyword_type = "Variant"
                        elif entity.category in ["Medication", "Drug", "Treatment"]:
                            keyword_type = "treatment"
                        
                        # Only store relevant keywords 
                        if keyword_type:
                            keyword = Keyword(
                                value=entity.text,
                                type=keyword_type,
                                source="text_analytics",
                                count=1,  # Analytics doesn't provide count
                                confidence=entity.confidence_score if hasattr(entity, 'confidence_score') else None
                            )
                            keywords.append(keyword)
            
        except Exception as e:
            logger.warning(f"Failed to convert analytics results to keywords: {e}")
        
        return keywords

    # All supported gene symbols — dynamically pulled from the registry at
    # import time so new genes added to the registry are detected automatically.
    _GENE_SYMBOLS: List[str] = []

    @classmethod
    def _get_gene_symbols(cls) -> List[str]:
        """Return the list of supported gene symbols (cached)."""
        if not cls._GENE_SYMBOLS:
            try:
                from rettxmutation.models.gene_registry import GENES
                cls._GENE_SYMBOLS = [g.symbol for g in GENES]
            except ImportError:
                cls._GENE_SYMBOLS = [
                    "MECP2", "FOXG1", "SLC6A1", "CDKL5", "EIF2B2", "MEF2C",
                ]
        return cls._GENE_SYMBOLS

    def _detect_gene_names(self, text: str) -> List[Keyword]:
        """
        Detect gene name mentions for all supported genes in the registry.
        
        Args:
            text: Text to analyze
            
        Returns:
            List[Keyword]: List of gene name keywords
        """
        keywords = []
        for symbol in self._get_gene_symbols():
            mentions = re.findall(rf"\b{re.escape(symbol)}\b", text, flags=re.IGNORECASE)
            if mentions:
                keywords.append(
                    Keyword(value=symbol, type="gene_name", source="regex", count=len(mentions))
                )
        return keywords

    def _detect_c_variants(self, text: str) -> List[Keyword]:
        """
        Detect c. variant notations including:
          - Substitutions:  c.916C>T, c.[473C>T]
          - Splice-site:    c.378-2A>G, c.27+1G>T
          - Range del/dup:  c.1040_1047del, c.763_1286del
          - Single-base del: c.484del, c.484delA
          - Duplications:   c.100dup, c.100_200dup
          - Insertions:     c.100_101insACG
          - Indels:         c.100_101delinsACG
          - Old arrow notation: c.502C->T (normalised to c.502C>T)
        
        Args:
            text: Text to analyze
            
        Returns:
            List[Keyword]: List of c. variant keywords
        """
        keywords = []

        # Comprehensive c. variant pattern:
        #   c. [optional bracket] [optional +/- intronic] position
        #       [optional _range] [change: substitution | del | dup | ins | delins]
        c_pattern = re.compile(
            r"(c\.\[?"
            r"[-+*]?\d+(?:[-+]\d+)?"
            r"(?:_[-+*]?\d+(?:[-+]\d+)?)?"
            r"(?:"
            r"  [ACGTacgt]+>[ACGTacgt]+"    # substitution (A>G)
            r"| [ACGTacgt]+->[ACGTacgt]+"   # old arrow notation (C->T)
            r"| delins[ACGTacgt]+"           # indel (delinsACG)
            r"| del[ACGTacgt]?"             # deletion (del, delA)
            r"| dup[ACGTacgt]?"             # duplication (dup, dupA)
            r"| ins[ACGTacgt]+"             # insertion (insACG)
            r")"
            r"\]?)",
            re.VERBOSE,
        )

        raw_matches = c_pattern.findall(text)

        # Normalise old arrow notation: c.502C->T → c.502C>T
        normalised = [m.replace("->", ">") for m in raw_matches]

        counter = Counter(normalised)
        keywords.extend(
            Keyword(value=variant, type="Variant", source="regex", count=count)
            for variant, count in counter.items()
        )

        return keywords

    def _detect_p_variants(self, text: str) -> List[Keyword]:
        """
        Detect p. variant notations including:
          - Missense:    p.Arg306Cys, p.(Thr158Met), p.[Thr158Met]
          - Nonsense:    p.Arg168Ter, p.(Arg168*), p.R168X (old single-letter)
          - Frameshift:  p.(Pro427Argfs*46), p.Arg162GlufsTer48, p.(Arg162Glufs*48)
          - Synonymous:  p.(Lys345=), p.Ser332=
          - Single-letter codes: p.(L136F), p.R306C
        
        Args:
            text: Text to analyze
            
        Returns:
            List[Keyword]: List of p. variant keywords
        """
        keywords = []

        # Comprehensive p. variant pattern — handles missense, nonsense,
        # frameshift (with fs*N or fsTerN), synonymous (=), and stop (*)
        # Uses three alternatives to ensure balanced brackets: (…), […], or bare
        _CORE = (
            r"[A-Za-z]{1,4}"               # reference amino acid (Arg / R / Ter)
            r"\d+"                          # position
            r"(?:"
            r"  [A-Za-z]{1,4}"             # changed amino acid (Cys / C)
            r"  (?:fs\*?\d*|fsTer\d*)?"    # optional frameshift suffix
            r"| ="                          # synonymous (silent)
            r"| \*"                         # stop-gain
            r"| X"                          # old-notation stop (R168X)
            r"| Ter"                        # stop as Ter
            r")"
        )
        p_pattern = re.compile(
            rf"(p\.(?:\({_CORE}\)|\[{_CORE}\]|{_CORE}))",
            re.VERBOSE,
        )

        raw_matches = p_pattern.findall(text)
        counter = Counter(raw_matches)
        keywords.extend(
            Keyword(value=variant, type="Variant", source="regex", count=count)
            for variant, count in counter.items()
        )

        return keywords

    def _detect_genomic_coordinates(self, text: str) -> List[Keyword]:
        """
        Detect genomic coordinate strings such as:
          - chrX:153296399, chr3:11058811
          - X:153,296,399  (with thousand separators)
          - chrX:153296399-153296399  (ranges)
        
        Args:
            text: Text to analyze
            
        Returns:
            List[Keyword]: List of genomic coordinate keywords
        """
        keywords = []

        coord_pattern = re.compile(
            r"((?:chr)?[0-9XY]{1,2}"         # chromosome (chr3, X, chrX, 14)
            r":\s?"                           # colon separator
            r"[\d,]+"                         # start position (may have commas)
            r"(?:\s?[-–]\s?[\d,]+)?)",        # optional end position for ranges
            re.IGNORECASE,
        )

        raw_matches = coord_pattern.findall(text)
        # Normalise: strip commas and spaces
        normalised = [re.sub(r"[,\s]", "", m) for m in raw_matches]
        counter = Counter(normalised)
        keywords.extend(
            Keyword(value=coord, type="genomic_coordinate", source="regex", count=count)
            for coord, count in counter.items()
        )

        return keywords

    def _detect_reference_sequences(self, text: str) -> List[Keyword]:
        """
        Detect reference sequence identifiers (e.g., "NM_004992.4", "NP_004983.1",
        "NC_000023.11", "ENST00000453960.2", "ENSP00000395535.2").
        
        Args:
            text: Text to analyze
            
        Returns:
            List[Keyword]: List of reference sequence keywords
        """
        keywords = []

        # RefSeq accessions with version: NM_, NP_, NC_, NG_, NR_, NW_
        refs = re.findall(r"(N[CMGPRW]_\d+\.\d+)", text)
        refs_counter = Counter(refs)
        keywords.extend(
            Keyword(value=ref, type="reference_sequence", source="regex", count=count)
            for ref, count in refs_counter.items()
        )

        # RefSeq accessions without version
        refs_no_version = re.findall(r"(N[CMGPRW]_\d+)(?!\.\d)", text)
        refs_no_version_counter = Counter(refs_no_version)
        keywords.extend(
            Keyword(value=ref, type="reference_sequence", source="regex", count=count)
            for ref, count in refs_no_version_counter.items()
        )

        # Ensembl transcripts / proteins: ENST, ENSP
        ensembl = re.findall(r"(ENS[TP]\d+(?:\.\d+)?)", text)
        ensembl_counter = Counter(ensembl)
        keywords.extend(
            Keyword(value=ref, type="reference_sequence", source="regex", count=count)
            for ref, count in ensembl_counter.items()
        )

        return keywords


