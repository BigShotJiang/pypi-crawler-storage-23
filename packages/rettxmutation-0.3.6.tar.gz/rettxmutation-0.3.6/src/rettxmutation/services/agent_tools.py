"""
Agent tool wrappers for the agentic mutation extraction service.

Each tool wraps an existing service, accepts primitive arguments (str, list),
returns a typed *ToolOutput, and never raises exceptions. Sync service calls
are bridged to async via asyncio.to_thread().
"""

import asyncio
import logging
from typing import TYPE_CHECKING

from rettxmutation.models.tool_outputs import (
    BaseToolOutput,
    RegexCandidate,
    RegexToolOutput,
    TextAnalyticsEntity,
    TextAnalyticsToolOutput,
    SearchResult,
    SearchToolOutput,
    ValidatorToolOutput,
    ComplexValidatorToolOutput,
    GeneInfo,
    GeneRegistryToolOutput,
    HgvsParseResult,
    HgvsParserToolOutput,
)

if TYPE_CHECKING:
    from rettxmutation.services.services_factory import RettxServices

logger = logging.getLogger(__name__)


class AgentTools:
    """
    Collection of kernel-function tool wrappers for the extraction agent.

    Each method maps 1-to-1 with a tool the LLM can call. They all follow the
    contract: accept primitives → call service → return *ToolOutput (never raise).
    """

    def __init__(self, services: "RettxServices"):
        self._services = services

    # ── regex_extract ──────────────────────────────────────────────

    async def regex_extract(self, text: str) -> RegexToolOutput:
        """Pattern-match HGVS strings from text using regex."""
        try:
            from rettxmutation.services.keyword_detector_service import KeywordDetectorService

            # Standalone detector — regex only, no external deps
            detector = KeywordDetectorService()
            keywords = await asyncio.to_thread(detector._detect_regex_keywords, text)
            candidates = [
                RegexCandidate(value=kw.value, type=kw.type, count=kw.count)
                for kw in keywords
            ]
            return RegexToolOutput(success=True, candidates=candidates)
        except Exception as e:
            logger.warning("regex_extract tool failed: %s", e)
            return RegexToolOutput(success=False, error=str(e))

    # ── text_analytics_extract ─────────────────────────────────────

    async def text_analytics_extract(self, text: str) -> TextAnalyticsToolOutput:
        """Extract medical/genetic entities via Azure Health NLP."""
        try:
            repo = self._services.text_analytics_repository
            raw_result = await asyncio.to_thread(repo.analyze_healthcare_entities, text)

            entities = []
            for doc in raw_result:
                if hasattr(doc, "entities"):
                    for ent in doc.entities:
                        entities.append(
                            TextAnalyticsEntity(
                                text=ent.text,
                                category=ent.category,
                                confidence_score=getattr(ent, "confidence_score", None),
                            )
                        )
            return TextAnalyticsToolOutput(success=True, entities=entities)
        except Exception as e:
            logger.warning("text_analytics_extract tool failed: %s", e)
            return TextAnalyticsToolOutput(success=False, error=str(e))

    # ── ai_search_enrich ───────────────────────────────────────────

    async def ai_search_enrich(self, query: str) -> SearchToolOutput:
        """Search known variants in the AI Search index."""
        try:
            svc = self._services.ai_search_service
            raw_results = await asyncio.to_thread(svc.keyword_search, query)
            results = []
            for r in raw_results:
                score = r.get("@search.score") if isinstance(r, dict) else getattr(r, "score", None)
                data = dict(r) if isinstance(r, dict) else {"value": str(r)}
                results.append(SearchResult(score=score, data=data))
            return SearchToolOutput(success=True, results=results)
        except Exception as e:
            logger.warning("ai_search_enrich tool failed: %s", e)
            return SearchToolOutput(success=False, error=str(e))

    # ── validate_variant ───────────────────────────────────────────

    async def validate_variant(self, hgvs_string: str, gene_symbol: str) -> ValidatorToolOutput:
        """Validate a transcript-level HGVS variant via VariantValidator API."""
        try:
            # Reject Ensembl transcripts — c. positions differ from RefSeq
            transcript_prefix = hgvs_string.split(":")[0] if ":" in hgvs_string else ""
            if transcript_prefix.startswith(("ENST", "ENSP")):
                return ValidatorToolOutput(
                    success=False,
                    error=(
                        f"Ensembl transcript '{transcript_prefix}' cannot be used with validate_variant. "
                        "Ensembl and RefSeq transcripts have different numbering — the c. position "
                        "on an Ensembl transcript does NOT correspond to the same c. position on a "
                        "RefSeq transcript. Instead, use the genomic coordinate from the report "
                        "(e.g., X:153,296,399) and call validate_complex with the appropriate "
                        "assembly_build, assembly_refseq, and genomic-level variant description "
                        "(e.g., NC_000023.10:g.153296399G>A)."
                    ),
                )

            svc = self._services.variant_validator_service
            mutation = await asyncio.to_thread(
                svc.create_gene_mutation_from_transcript_variant,
                hgvs_string,
                gene_symbol,
            )
            return ValidatorToolOutput(success=True, mutation=mutation)
        except Exception as e:
            logger.warning("validate_variant tool failed: %s", e)
            return ValidatorToolOutput(success=False, error=str(e))

    # ── validate_complex ───────────────────────────────────────────

    async def validate_complex(
        self,
        assembly_build: str,
        assembly_refseq: str,
        variant_description: str,
        gene_symbol: str = "",
    ) -> ComplexValidatorToolOutput:
        """Validate a complex variant (large del/dup/ins, or genomic-level SNV) via VariantValidator API.

        When *gene_symbol* is provided the service will also resolve
        transcript-level annotations on the RefSeq primary (and secondary)
        transcripts registered for that gene.
        """
        try:
            from rettxmutation.models.gene_assembly import GenomeAssembly

            assembly = GenomeAssembly(
                build=assembly_build,
                chromosome=self._chromosome_from_refseq(assembly_refseq),
            )
            svc = self._services.variant_validator_service
            mutation = await asyncio.to_thread(
                svc.create_gene_mutation_from_complex_variant,
                assembly,
                variant_description,
                gene_symbol=gene_symbol,
            )
            return ComplexValidatorToolOutput(success=True, mutation=mutation)
        except Exception as e:
            logger.warning("validate_complex tool failed: %s", e)
            return ComplexValidatorToolOutput(success=False, error=str(e))

    # ── lookup_gene_registry ───────────────────────────────────────

    async def lookup_gene_registry(self, gene_symbol: str) -> GeneRegistryToolOutput:
        """Look up a gene symbol in the registry."""
        try:
            from rettxmutation.models.gene_registry import registry
            from rettxmutation.models.gene_assembly import REFSEQ_MAP

            gene = registry.get_gene(gene_symbol)
            if gene is None:
                return GeneRegistryToolOutput(
                    success=True,
                    gene=None,
                    all_known_genes=[g.symbol for g in registry.genes],
                )

            # Look up RefSeq accessions for this gene's chromosome
            chrom = gene.chromosome.upper().removeprefix("CHR")
            refseq_grch37 = REFSEQ_MAP.get(("GRCh37", chrom))
            refseq_grch38 = REFSEQ_MAP.get(("GRCh38", chrom))

            info = GeneInfo(
                symbol=gene.symbol,
                name=gene.name,
                chromosome=gene.chromosome,
                refseq_grch37=refseq_grch37,
                refseq_grch38=refseq_grch38,
                primary_transcript_mrna=gene.primary_transcript.mrna,
                primary_transcript_protein=gene.primary_transcript.protein,
                secondary_transcript_mrna=(
                    gene.secondary_transcript.mrna if gene.secondary_transcript else None
                ),
                secondary_transcript_protein=(
                    gene.secondary_transcript.protein if gene.secondary_transcript else None
                ),
            )
            return GeneRegistryToolOutput(success=True, gene=info)
        except Exception as e:
            logger.warning("lookup_gene_registry tool failed: %s", e)
            return GeneRegistryToolOutput(success=False, error=str(e))

    # ── parse_hgvs ─────────────────────────────────────────────────

    async def parse_hgvs(self, hgvs_string: str) -> HgvsParserToolOutput:
        """Parse and validate an HGVS notation string."""
        try:
            from rettxmutation.utils.hgvs_descriptor import HgvsDescriptor

            desc = await asyncio.to_thread(HgvsDescriptor, hgvs_string)
            parsed = HgvsParseResult(
                transcript=hgvs_string.split(":")[0] if ":" in hgvs_string else None,
                variant_type=desc.variant_type,
                start=desc.start,
                end=desc.end,
                size=desc.size,
            )
            return HgvsParserToolOutput(success=True, parsed=parsed)
        except Exception as e:
            logger.warning("parse_hgvs tool failed: %s", e)
            return HgvsParserToolOutput(success=False, error=str(e))

    # ── helpers ─────────────────────────────────────────────────────

    @staticmethod
    def _chromosome_from_refseq(refseq: str) -> str:
        """
        Derive chromosome from a RefSeq accession.

        Maps NC_000023 → X, NC_000001 → 1, etc.
        """
        from rettxmutation.models.gene_assembly import REFSEQ_MAP

        for (_, chrom), rs in REFSEQ_MAP.items():
            if rs == refseq:
                return chrom
        # Fallback: parse from the numeric part
        # NC_000023.xx → chr 23 → X
        try:
            num = int(refseq.split("_")[1].split(".")[0])
            if num == 23:
                return "X"
            if num == 24:
                return "Y"
            return str(num)
        except (IndexError, ValueError):
            raise ValueError(f"Cannot determine chromosome from refseq: {refseq}")
