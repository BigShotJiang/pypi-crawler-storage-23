"""PHI (Protected Health Information) redactor for genetic report text."""

import re
import logging
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class RedactedTextPair(BaseModel):
    """Container for original and redacted text pair."""
    original: str = Field(..., description="Original text (for local tools)")
    redacted: str = Field(..., description="Redacted text (for LLM)")


class PhiRedactor:
    """
    Best-effort regex-based PHI redaction.

    Strips identifiable patient information before sending text to the LLM.
    Original text is preserved for local tools (regex, text analytics) that
    run in-process without PHI risk.

    This is NOT a certified de-identification tool. It provides defense-in-depth
    for a system where Azure OpenAI has a data processing agreement.
    """

    # Pattern to identify and protect HGVS / RefSeq notation before redaction.
    # Matches: NC_000023.11, NM_004992.4, NP_004983.1, g.154030912G>A, etc.
    _HGVS_PROTECT_PATTERN = re.compile(
        r'(?:N[CMGPRW]_\d+\.\d+)'           # RefSeq accessions (NC_, NM_, NP_, NG_, NR_, NW_)
        r'|(?:[cgpnmro]\.\d[\d_*+\-?>A-Za-z]*)'  # HGVS variant notation (c., g., p., etc.)
    )

    # Placeholder char that won't appear in real text
    _PROTECT_PREFIX = "\x00HGVS"

    # Date patterns: DD/MM/YYYY, MM/DD/YYYY, DD-MM-YYYY, YYYY-MM-DD
    # Only match with / - . separators and plausible day(1-31)/month(1-12)/year ranges
    DATE_PATTERN = re.compile(
        r'(?<![A-Za-z_\d])'  # not preceded by letter, underscore, or digit
        r'(?:'
        r'\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4}'  # DD/MM/YYYY or MM/DD/YYYY
        r'|\d{4}[/\-\.]\d{1,2}[/\-\.]\d{1,2}'   # YYYY-MM-DD
        r')'
        r'(?![A-Za-z_\d])'  # not followed by letter, underscore, or digit
    )

    # Email pattern
    EMAIL_PATTERN = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b')

    # Phone pattern — require + prefix or parenthesized area code for specificity
    PHONE_PATTERN = re.compile(
        r'\+\d{1,4}[\s\-\.]?\(?\d{1,4}\)?[\s\-\.]?\d{2,4}[\s\-\.]?\d{2,4}'
        r'|\(\d{2,4}\)\s?\d{3,4}[\s\-\.]?\d{3,4}'
    )

    # Patient ID patterns: MRN, ID numbers (sequences of digits possibly with prefix)
    ID_PATTERN = re.compile(
        r'\b(?:MRN|Patient\s*(?:ID|No|Number)|Record\s*(?:No|Number))\s*[:#]?\s*\w+\b',
        re.IGNORECASE
    )

    # Address-like patterns (street numbers followed by words)
    ADDRESS_PATTERN = re.compile(
        r'\b\d{1,5}\s+(?:[A-Za-zÀ-ž]+\s*){1,3}'
        r'(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Drive|Dr|Lane|Ln|Way|Place|Pl'
        r'|Rua|Avenida|Strasse|Straße)\b',
        re.IGNORECASE
    )

    # Name-before-label pattern: "Name: Some Name" or "Patient: Some Name"
    # Unicode-aware to match accented characters (João, María, etc.)
    # Supports EN: Patient Name, Name, Patient
    # Supports ES: Nombre, Apellidos, Paciente
    # Supports PT: Nome, Paciente
    # Uses a negative lookahead to avoid consuming subsequent label keywords as name words.
    _NAME_LABELS = (
        r'Patient\s*Name|Patient|Name|Paciente|Nome|Nombre|Apellidos'
    )
    _NAME_WORD = (
        r'[A-ZÀ-Ž][a-zà-ž]+'
    )
    NAME_LABEL_PATTERN = re.compile(
        rf'(?:{_NAME_LABELS})\s*[:\-]\s*'
        rf'{_NAME_WORD}'
        rf'(?:\s+(?!(?:{_NAME_LABELS})\s*[:\-]){_NAME_WORD}){{0,3}}',
        re.IGNORECASE
    )

    # Spanish-specific: "Apellidos\nVALUE" or "Nombre\nVALUE" without colon
    # Handles reports where label and value are on separate lines or separated by spaces
    _ES_NAME_LABELS_NO_COLON = r'Apellidos|Nombre'
    NAME_LABEL_NO_COLON_PATTERN = re.compile(
        rf'(?:{_ES_NAME_LABELS_NO_COLON})\s+'
        rf'{_NAME_WORD}'
        rf'(?:\s+(?!(?:{_NAME_LABELS})\s*[:\-]?|Fecha\b){_NAME_WORD}){{0,5}}',
        re.IGNORECASE
    )

    # Social security / national ID numbers — require dash or space separators
    SSN_PATTERN = re.compile(r'\b\d{3}[\-\s]\d{2}[\-\s]\d{4}\b')

    REDACTED = "[REDACTED]"

    @classmethod
    def redact(cls, text: str) -> RedactedTextPair:
        """
        Redact PHI from text, returning both original and redacted versions.

        Uses a protect-then-redact strategy: HGVS/RefSeq patterns are temporarily
        replaced with placeholders, PHI patterns are applied, then HGVS patterns
        are restored.

        Args:
            text: Raw input text from genetic report

        Returns:
            RedactedTextPair with original and redacted text
        """
        # Step 1: Protect HGVS/genetic notation by replacing with placeholders
        protected_segments: list[str] = []

        def _protect(match: re.Match) -> str:
            idx = len(protected_segments)
            protected_segments.append(match.group(0))
            return f"{cls._PROTECT_PREFIX}{idx}\x00"

        redacted = cls._HGVS_PROTECT_PATTERN.sub(_protect, text)

        # Step 2: Apply PHI redaction patterns
        patterns = [
            cls.NAME_LABEL_NO_COLON_PATTERN,
            cls.NAME_LABEL_PATTERN,
            cls.ID_PATTERN,
            cls.EMAIL_PATTERN,
            cls.ADDRESS_PATTERN,
            cls.SSN_PATTERN,
            cls.PHONE_PATTERN,
            cls.DATE_PATTERN,
        ]

        for pattern in patterns:
            redacted = pattern.sub(cls.REDACTED, redacted)

        # Step 3: Restore protected HGVS segments
        for idx, segment in enumerate(protected_segments):
            redacted = redacted.replace(f"{cls._PROTECT_PREFIX}{idx}\x00", segment)

        if redacted != text:
            logger.debug("PHI redaction applied to input text")

        return RedactedTextPair(original=text, redacted=redacted)
