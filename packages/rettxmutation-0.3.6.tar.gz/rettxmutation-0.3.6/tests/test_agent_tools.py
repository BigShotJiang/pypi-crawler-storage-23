"""
Tests for AgentTools — the kernel-function tool wrappers.

Every tool is tested for:
  - happy-path returning a typed *ToolOutput with success=True
  - error-path returning success=False, error=<message> (never raises)
"""

import asyncio
import pytest
from unittest.mock import MagicMock, patch, AsyncMock

from rettxmutation.services.agent_tools import AgentTools
from rettxmutation.models.tool_outputs import (
    RegexToolOutput,
    TextAnalyticsToolOutput,
    SearchToolOutput,
    ValidatorToolOutput,
    ComplexValidatorToolOutput,
    GeneRegistryToolOutput,
    HgvsParserToolOutput,
)


@pytest.fixture
def tools(mock_services):
    return AgentTools(mock_services)


# ── regex_extract ─────────────────────────────────────────────


class TestRegexExtract:
    @pytest.mark.asyncio
    async def test_success_returns_candidates(self, tools):
        result = await tools.regex_extract(
            "Patient has NM_004992.4:c.916C>T and p.Arg306Cys"
        )
        assert isinstance(result, RegexToolOutput)
        assert result.success is True
        assert len(result.candidates) > 0
        # c.916C>T should be found
        values = [c.value for c in result.candidates]
        assert any("916C>T" in v for v in values)

    @pytest.mark.asyncio
    async def test_empty_text_returns_empty_list(self, tools):
        result = await tools.regex_extract("")
        assert result.success is True
        assert len(result.candidates) == 0

    @pytest.mark.asyncio
    async def test_error_returns_failure(self, tools):
        with patch(
            "rettxmutation.services.keyword_detector_service.KeywordDetectorService._detect_regex_keywords",
            side_effect=RuntimeError("boom"),
        ):
            result = await tools.regex_extract("anything")
        assert result.success is False
        assert "boom" in result.error


# ── text_analytics_extract ────────────────────────────────────


class TestTextAnalyticsExtract:
    @pytest.mark.asyncio
    async def test_success_returns_entities(self, tools, mock_services):
        entity = MagicMock()
        entity.text = "MECP2"
        entity.category = "GeneOrProtein"
        entity.confidence_score = 0.95

        doc = MagicMock()
        doc.entities = [entity]

        mock_services.text_analytics_repository.analyze_healthcare_entities.return_value = [doc]

        result = await tools.text_analytics_extract("Patient has MECP2 mutation")
        assert isinstance(result, TextAnalyticsToolOutput)
        assert result.success is True
        assert len(result.entities) == 1
        assert result.entities[0].text == "MECP2"

    @pytest.mark.asyncio
    async def test_error_returns_failure(self, tools, mock_services):
        mock_services.text_analytics_repository.analyze_healthcare_entities.side_effect = (
            RuntimeError("API down")
        )
        result = await tools.text_analytics_extract("text")
        assert result.success is False
        assert "API down" in result.error


# ── ai_search_enrich ──────────────────────────────────────────


class TestAISearchEnrich:
    @pytest.mark.asyncio
    async def test_success_returns_results(self, tools, mock_services):
        raw = [{"@search.score": 1.5, "mutation": "c.916C>T"}]
        mock_services.ai_search_service.keyword_search.return_value = raw

        result = await tools.ai_search_enrich("c.916C>T")
        assert isinstance(result, SearchToolOutput)
        assert result.success is True
        assert len(result.results) == 1
        assert result.results[0].score == 1.5

    @pytest.mark.asyncio
    async def test_error_returns_failure(self, tools, mock_services):
        mock_services.ai_search_service.keyword_search.side_effect = (
            RuntimeError("Search unavailable")
        )
        result = await tools.ai_search_enrich("query")
        assert result.success is False
        assert "Search unavailable" in result.error


# ── validate_variant ──────────────────────────────────────────


class TestValidateVariant:
    @pytest.mark.asyncio
    async def test_success_returns_mutation(self, tools, mock_services):
        from rettxmutation.models.gene_models import GeneMutation

        fake_mutation = GeneMutation(
            genome_assembly="GRCh38",
            genomic_coordinate="NC_000023.11:g.154031326G>A",
        )
        mock_services.variant_validator_service.create_gene_mutation_from_transcript_variant.return_value = (
            fake_mutation
        )

        result = await tools.validate_variant("NM_004992.4:c.916C>T", "MECP2")
        assert isinstance(result, ValidatorToolOutput)
        assert result.success is True
        assert result.mutation == fake_mutation

    @pytest.mark.asyncio
    async def test_error_returns_failure(self, tools, mock_services):
        mock_services.variant_validator_service.create_gene_mutation_from_transcript_variant.side_effect = (
            ValueError("Invalid HGVS")
        )
        result = await tools.validate_variant("bad:variant", "MECP2")
        assert result.success is False
        assert "Invalid HGVS" in result.error


# ── validate_complex ──────────────────────────────────────────


class TestValidateComplex:
    @pytest.mark.asyncio
    async def test_success_returns_mutation(self, tools, mock_services):
        from rettxmutation.models.gene_models import GeneMutation

        fake_mutation = GeneMutation(
            genome_assembly="GRCh38",
            genomic_coordinate="NC_000023.11:g.154031000_154031500del",
        )
        mock_services.variant_validator_service.create_gene_mutation_from_complex_variant.return_value = (
            fake_mutation
        )

        result = await tools.validate_complex(
            assembly_build="GRCh38",
            assembly_refseq="NC_000023.11",
            variant_description="g.154031000_154031500del",
        )
        assert isinstance(result, ComplexValidatorToolOutput)
        assert result.success is True
        assert result.mutation == fake_mutation

    @pytest.mark.asyncio
    async def test_error_returns_failure(self, tools, mock_services):
        mock_services.variant_validator_service.create_gene_mutation_from_complex_variant.side_effect = (
            RuntimeError("API error")
        )
        result = await tools.validate_complex(
            assembly_build="GRCh38",
            assembly_refseq="NC_000023.11",
            variant_description="g.bad_variant",
        )
        assert result.success is False
        assert "API error" in result.error


# ── lookup_gene_registry ──────────────────────────────────────


class TestLookupGeneRegistry:
    @pytest.mark.asyncio
    async def test_known_gene_returns_info(self, tools):
        result = await tools.lookup_gene_registry("MECP2")
        assert isinstance(result, GeneRegistryToolOutput)
        assert result.success is True
        assert result.gene is not None
        assert result.gene.symbol == "MECP2"
        assert result.gene.chromosome == "X"
        assert result.gene.primary_transcript_mrna == "NM_004992.4"

    @pytest.mark.asyncio
    async def test_unknown_gene_returns_known_list(self, tools):
        result = await tools.lookup_gene_registry("BRCA1")
        assert result.success is True
        assert result.gene is None
        assert "MECP2" in result.all_known_genes
        assert "FOXG1" in result.all_known_genes

    @pytest.mark.asyncio
    async def test_secondary_transcript_present(self, tools):
        result = await tools.lookup_gene_registry("MECP2")
        assert result.gene.secondary_transcript_mrna == "NM_001110792.2"

    @pytest.mark.asyncio
    async def test_no_secondary_transcript(self, tools):
        result = await tools.lookup_gene_registry("FOXG1")
        assert result.gene.secondary_transcript_mrna is None


# ── parse_hgvs ────────────────────────────────────────────────


class TestParseHgvs:
    @pytest.mark.asyncio
    async def test_valid_cdna_variant(self, tools):
        result = await tools.parse_hgvs("NM_004992.4:c.916C>T")
        assert isinstance(result, HgvsParserToolOutput)
        assert result.success is True
        assert result.parsed is not None
        assert result.parsed.transcript == "NM_004992.4"

    @pytest.mark.asyncio
    async def test_invalid_hgvs_returns_failure(self, tools):
        result = await tools.parse_hgvs("not_a_valid_hgvs")
        assert result.success is False
        assert result.error is not None


# ── _chromosome_from_refseq ──────────────────────────────────


class TestChromosomeFromRefseq:
    def test_x_chromosome(self):
        result = AgentTools._chromosome_from_refseq("NC_000023.11")
        assert result == "X"

    def test_numeric_chromosome(self):
        result = AgentTools._chromosome_from_refseq("NC_000014.9")
        assert result == "14"

    def test_chromosome_1(self):
        result = AgentTools._chromosome_from_refseq("NC_000001.11")
        assert result == "1"

    def test_unknown_raises(self):
        with pytest.raises(ValueError, match="Cannot determine chromosome"):
            AgentTools._chromosome_from_refseq("invalid")
