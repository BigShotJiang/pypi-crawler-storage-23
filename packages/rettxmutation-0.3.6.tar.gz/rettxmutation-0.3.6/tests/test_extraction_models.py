"""Tests for extraction models and tool output models."""

import pytest
from datetime import datetime
from pydantic import ValidationError

from rettxmutation.models.extraction_models import (
    ExtractionLogEntry,
    ExtractionResult,
    ExtractionError,
)
from rettxmutation.models.tool_outputs import (
    BaseToolOutput,
    RegexCandidate,
    RegexToolOutput,
    TextAnalyticsEntity,
    TextAnalyticsToolOutput,
    SearchResult,
    SearchToolOutput,
    ValidatorToolOutput,
    ComplexValidatorToolOutput,
    GeneInfo,
    GeneRegistryToolOutput,
    HgvsParseResult,
    HgvsParserToolOutput,
)
from rettxmutation.models.gene_models import (
    GeneMutation,
    GenomicCoordinate,
    TranscriptMutation,
)


# ──────────────────────────────────────────────
# ExtractionLogEntry
# ──────────────────────────────────────────────


class TestExtractionLogEntry:
    def test_defaults(self):
        entry = ExtractionLogEntry(action="tool_call")
        assert entry.action == "tool_call"
        assert isinstance(entry.timestamp, datetime)
        assert entry.tool is None
        assert entry.input_summary == ""
        assert entry.output_summary == ""
        assert entry.success is True
        assert entry.duration_ms is None

    def test_full_fields(self):
        entry = ExtractionLogEntry(
            action="tool_result",
            tool="regex_extract",
            input_summary="text with c.916C>T",
            output_summary="1 candidate",
            success=True,
            duration_ms=42,
        )
        assert entry.tool == "regex_extract"
        assert entry.duration_ms == 42

    def test_serialization_roundtrip(self):
        entry = ExtractionLogEntry(action="reasoning", success=False)
        data = entry.model_dump()
        restored = ExtractionLogEntry(**data)
        assert restored.action == "reasoning"
        assert restored.success is False


# ──────────────────────────────────────────────
# ExtractionResult
# ──────────────────────────────────────────────


class TestExtractionResult:
    def test_empty_result_is_valid(self):
        """AC1: Empty mutations is valid, not an error."""
        result = ExtractionResult()
        assert result.mutations == {}
        assert result.extraction_log == []
        assert result.genes_detected == []
        assert result.tool_calls_count == 0

    def test_with_mutations(self):
        mutation = GeneMutation(
            variant_type="SNV",
            genomic_coordinates={
                "GRCh38": GenomicCoordinate(
                    assembly="GRCh38",
                    hgvs="NC_000023.11:g.154030912G>A",
                    start=154030912,
                    end=154030912,
                )
            },
            primary_transcript=TranscriptMutation(
                hgvs_transcript_variant="NM_004992.4:c.916C>T"
            ),
        )
        result = ExtractionResult(
            mutations={"NC_000023.11:g.154030912G>A": mutation},
            genes_detected=["MECP2"],
            tool_calls_count=3,
        )
        assert len(result.mutations) == 1
        assert "NC_000023.11:g.154030912G>A" in result.mutations
        assert result.genes_detected == ["MECP2"]
        assert result.tool_calls_count == 3

    def test_serialization(self):
        result = ExtractionResult(
            extraction_log=["step 1", "step 2"],
            genes_detected=["MECP2", "FOXG1"],
            tool_calls_count=5,
        )
        data = result.model_dump()
        assert data["mutations"] == {}
        assert data["extraction_log"] == ["step 1", "step 2"]
        assert data["tool_calls_count"] == 5


# ──────────────────────────────────────────────
# ExtractionError
# ──────────────────────────────────────────────


class TestExtractionError:
    def test_basic(self):
        err = ExtractionError("LLM unavailable")
        assert str(err) == "LLM unavailable"
        assert err.extraction_log == []

    def test_with_log(self):
        log = ["PHI redaction applied", "Agent init failed"]
        err = ExtractionError("timeout", extraction_log=log)
        assert err.extraction_log == log
        assert len(err.extraction_log) == 2

    def test_is_exception(self):
        err = ExtractionError("fail")
        assert isinstance(err, Exception)
        with pytest.raises(ExtractionError):
            raise err


# ──────────────────────────────────────────────
# BaseToolOutput
# ──────────────────────────────────────────────


class TestBaseToolOutput:
    def test_success_default(self):
        out = BaseToolOutput()
        assert out.success is True
        assert out.error is None

    def test_failure(self):
        out = BaseToolOutput(success=False, error="service unavailable")
        assert out.success is False
        assert out.error == "service unavailable"

    def test_serialization(self):
        out = BaseToolOutput(success=False, error="timeout")
        data = out.model_dump()
        assert data == {"success": False, "error": "timeout"}


# ──────────────────────────────────────────────
# RegexToolOutput
# ──────────────────────────────────────────────


class TestRegexToolOutput:
    def test_empty(self):
        out = RegexToolOutput()
        assert out.success is True
        assert out.candidates == []

    def test_with_candidates(self):
        out = RegexToolOutput(
            candidates=[
                RegexCandidate(value="c.916C>T", type="Variant", count=1),
                RegexCandidate(value="MECP2", type="gene_name", count=2),
            ]
        )
        assert len(out.candidates) == 2
        assert out.candidates[0].value == "c.916C>T"
        assert out.candidates[1].count == 2

    def test_inherits_base(self):
        out = RegexToolOutput(success=False, error="regex fail")
        assert isinstance(out, BaseToolOutput)
        assert out.success is False


# ──────────────────────────────────────────────
# TextAnalyticsToolOutput
# ──────────────────────────────────────────────


class TestTextAnalyticsToolOutput:
    def test_with_entities(self):
        out = TextAnalyticsToolOutput(
            entities=[
                TextAnalyticsEntity(text="MECP2", category="GeneOrProtein", confidence_score=0.95),
            ]
        )
        assert len(out.entities) == 1
        assert out.entities[0].confidence_score == 0.95

    def test_inherits_base(self):
        out = TextAnalyticsToolOutput(success=False, error="API error")
        assert isinstance(out, BaseToolOutput)


# ──────────────────────────────────────────────
# SearchToolOutput
# ──────────────────────────────────────────────


class TestSearchToolOutput:
    def test_with_results(self):
        out = SearchToolOutput(
            results=[SearchResult(score=0.88, data={"id": "1", "variant": "c.916C>T"})]
        )
        assert len(out.results) == 1
        assert out.results[0].score == 0.88


# ──────────────────────────────────────────────
# ValidatorToolOutput
# ──────────────────────────────────────────────


class TestValidatorToolOutput:
    def test_success_with_mutation(self):
        mutation = GeneMutation(
            variant_type="SNV",
            genomic_coordinates={
                "GRCh38": GenomicCoordinate(
                    assembly="GRCh38",
                    hgvs="NC_000023.11:g.154030912G>A",
                    start=154030912,
                    end=154030912,
                )
            },
            primary_transcript=TranscriptMutation(
                hgvs_transcript_variant="NM_004992.4:c.916C>T"
            ),
        )
        out = ValidatorToolOutput(success=True, mutation=mutation)
        assert out.mutation is not None
        assert out.mutation.variant_type == "SNV"

    def test_failure_no_mutation(self):
        out = ValidatorToolOutput(success=False, error="validation failed")
        assert out.mutation is None

    def test_serialization(self):
        out = ValidatorToolOutput(success=True, mutation=None)
        data = out.model_dump()
        assert data["success"] is True
        assert data["mutation"] is None


# ──────────────────────────────────────────────
# ComplexValidatorToolOutput
# ──────────────────────────────────────────────


class TestComplexValidatorToolOutput:
    def test_inherits_base(self):
        out = ComplexValidatorToolOutput(success=False, error="complex fail")
        assert isinstance(out, BaseToolOutput)
        assert out.mutation is None


# ──────────────────────────────────────────────
# GeneRegistryToolOutput
# ──────────────────────────────────────────────


class TestGeneRegistryToolOutput:
    def test_found_gene(self):
        gene = GeneInfo(
            symbol="MECP2",
            name="methyl-CpG binding protein 2",
            chromosome="X",
            primary_transcript_mrna="NM_004992.4",
            primary_transcript_protein="NP_004983.1",
            secondary_transcript_mrna="NM_001110792.2",
            secondary_transcript_protein="NP_001104262.1",
        )
        out = GeneRegistryToolOutput(gene=gene)
        assert out.success is True
        assert out.gene.symbol == "MECP2"
        assert out.all_known_genes is None

    def test_gene_not_found(self):
        out = GeneRegistryToolOutput(
            success=True,
            gene=None,
            all_known_genes=["MECP2", "FOXG1", "CDKL5"],
        )
        assert out.gene is None
        assert len(out.all_known_genes) == 3


# ──────────────────────────────────────────────
# HgvsParserToolOutput
# ──────────────────────────────────────────────


class TestHgvsParserToolOutput:
    def test_with_parsed(self):
        parsed = HgvsParseResult(
            transcript="NC_000023.11",
            variant_type="substitution",
            start=154030912,
            end=154030912,
            size=1,
        )
        out = HgvsParserToolOutput(parsed=parsed)
        assert out.success is True
        assert out.parsed.variant_type == "substitution"

    def test_failure(self):
        out = HgvsParserToolOutput(success=False, error="invalid HGVS")
        assert out.parsed is None
