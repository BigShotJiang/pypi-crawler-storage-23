"""Tests for PHI redactor utility."""

import pytest
from rettxmutation.utils.phi_redactor import PhiRedactor, RedactedTextPair


class TestRedactedTextPair:
    def test_preserves_original(self):
        pair = RedactedTextPair(original="hello world", redacted="hello world")
        assert pair.original == "hello world"
        assert pair.redacted == "hello world"


class TestPhiRedactorDates:
    def test_dd_mm_yyyy(self):
        result = PhiRedactor.redact("Born on 15/03/1990 in Lisbon")
        assert "15/03/1990" not in result.redacted
        assert "[REDACTED]" in result.redacted

    def test_yyyy_mm_dd(self):
        result = PhiRedactor.redact("Date: 2020-01-15")
        assert "2020-01-15" not in result.redacted

    def test_dd_dot_mm_dot_yyyy(self):
        result = PhiRedactor.redact("Geburtsdatum: 03.11.1985")
        assert "03.11.1985" not in result.redacted


class TestPhiRedactorEmails:
    def test_email_redacted(self):
        result = PhiRedactor.redact("Contact: joao.silva@hospital.pt for results")
        assert "joao.silva@hospital.pt" not in result.redacted
        assert "[REDACTED]" in result.redacted


class TestPhiRedactorPatientNames:
    def test_english_name_label(self):
        result = PhiRedactor.redact("Patient Name: John Smith was diagnosed")
        assert "John Smith" not in result.redacted
        assert "[REDACTED]" in result.redacted

    def test_portuguese_name_label(self):
        result = PhiRedactor.redact("Paciente: Maria Santos apresentou")
        assert "Maria Santos" not in result.redacted
        assert "[REDACTED]" in result.redacted

    def test_nome_label(self):
        result = PhiRedactor.redact("Nome: João Silva")
        assert "João Silva" not in result.redacted


class TestPhiRedactorIds:
    def test_mrn(self):
        result = PhiRedactor.redact("MRN: 123456 was admitted")
        assert "MRN: 123456" not in result.redacted
        assert "[REDACTED]" in result.redacted

    def test_patient_id(self):
        result = PhiRedactor.redact("Patient ID: ABC789")
        assert "ABC789" not in result.redacted


class TestPhiRedactorAddresses:
    def test_street_address(self):
        result = PhiRedactor.redact("Lives at 123 Main Street")
        assert "123 Main Street" not in result.redacted

    def test_portuguese_address(self):
        result = PhiRedactor.redact("Morada: 45 Lisboa Avenida")
        assert "45 Lisboa Avenida" not in result.redacted


class TestPhiRedactorSsn:
    def test_ssn_with_dashes(self):
        result = PhiRedactor.redact("SSN: 123-45-6789")
        assert "123-45-6789" not in result.redacted


class TestPhiRedactorHgvsPreservation:
    """HGVS genetic notation must NOT be redacted."""

    def test_cdna_variant_preserved(self):
        text = "The variant c.916C>T was found in MECP2"
        result = PhiRedactor.redact(text)
        assert "c.916C>T" in result.redacted
        assert "MECP2" in result.redacted

    def test_transcript_variant_preserved(self):
        text = "NM_004992.4:c.916C>T detected"
        result = PhiRedactor.redact(text)
        assert "NM_004992.4:c.916C>T" in result.redacted

    def test_genomic_coordinate_preserved(self):
        text = "NC_000023.11:g.154030912G>A was validated"
        result = PhiRedactor.redact(text)
        assert "NC_000023.11:g.154030912G>A" in result.redacted

    def test_protein_consequence_preserved(self):
        text = "p.Arg306Cys consequence detected"
        result = PhiRedactor.redact(text)
        assert "p.Arg306Cys" in result.redacted

    def test_deletion_notation_preserved(self):
        text = "NC_000023.11:g.154010939_154058566del"
        result = PhiRedactor.redact(text)
        assert "g.154010939_154058566del" in result.redacted


class TestPhiRedactorNoPhiPassthrough:
    def test_no_phi_unchanged(self):
        text = "O exame genético molecular do gene MECP2 revelou a variante c.916C>T (p.Arg306Cys)"
        result = PhiRedactor.redact(text)
        assert result.original == text
        assert result.redacted == text

    def test_original_always_preserved(self):
        text = "Patient Name: João Silva had variant c.916C>T"
        result = PhiRedactor.redact(text)
        assert result.original == text
        assert result.original != result.redacted


class TestPhiRedactorMixedContent:
    def test_phi_and_genetics_mixed(self):
        text = (
            "Patient Name: Maria Santos\n"
            "MRN: 12345\n"
            "O exame revelou a variante NM_004992.4:c.916C>T (p.Arg306Cys) no gene MECP2."
        )
        result = PhiRedactor.redact(text)
        # PHI should be gone
        assert "Maria Santos" not in result.redacted
        assert "MRN: 12345" not in result.redacted
        # Genetic data should be preserved
        assert "NM_004992.4:c.916C>T" in result.redacted
        assert "MECP2" in result.redacted
        assert "p.Arg306Cys" in result.redacted
