"""
Tests for AgentExtractionService.

Covers:
  - Initialisation and config validation
  - Prompt loading and rendering
  - Agent loop with mocked LLM (tool_calls → stop flow)
  - PHI redaction integration
  - ExtractionResult structure
"""

import asyncio
import json
import pytest
from unittest.mock import MagicMock, AsyncMock, patch, PropertyMock

from rettxmutation.services.agent_service import AgentExtractionService
from rettxmutation.models.extraction_models import ExtractionResult, ExtractionError

# ── init / config validation ──────────────────────────────────


class TestAgentServiceInit:
    def test_valid_config_creates_service(self, mock_config, mock_services):
        svc = AgentExtractionService(mock_config, mock_services)
        assert svc._llm_client is None  # Lazy init
        assert svc._system_prompt is None

    def test_missing_key_raises(self, mock_config, mock_services):
        mock_config.RETTX_OPENAI_KEY = None
        with pytest.raises(ValueError, match="AgentExtractionService"):
            AgentExtractionService(mock_config, mock_services)

    def test_missing_endpoint_raises(self, mock_config, mock_services):
        mock_config.RETTX_OPENAI_ENDPOINT = None
        with pytest.raises(ValueError, match="AgentExtractionService"):
            AgentExtractionService(mock_config, mock_services)

    def test_missing_deployment_raises(self, mock_config, mock_services):
        mock_config.RETTX_OPENAI_AGENT_DEPLOYMENT = None
        with pytest.raises(ValueError, match="AgentExtractionService"):
            AgentExtractionService(mock_config, mock_services)


# ── prompt loading ────────────────────────────────────────────


class TestPromptLoading:
    def test_prompt_loads_and_renders(self, mock_config, mock_services):
        svc = AgentExtractionService(mock_config, mock_services)
        prompt = svc._load_and_render_prompt()
        assert isinstance(prompt, str)
        assert len(prompt) > 100
        # Gene registry should be rendered
        assert "MECP2" in prompt
        assert "FOXG1" in prompt
        # Tool descriptions should be rendered
        assert "regex_extract" in prompt
        assert "validate_variant" in prompt
        # Template placeholders should be replaced
        assert "{gene_registry}" not in prompt
        assert "{tool_descriptions}" not in prompt

    def test_prompt_is_cached(self, mock_config, mock_services):
        svc = AgentExtractionService(mock_config, mock_services)
        p1 = svc._load_and_render_prompt()
        p2 = svc._load_and_render_prompt()
        assert p1 is p2


# ── tool definitions ──────────────────────────────────────────


class TestToolDefinitions:
    def test_all_tools_defined(self):
        defs = AgentExtractionService._build_tool_definitions()
        names = [d["function"]["name"] for d in defs]
        assert "regex_extract" in names
        assert "text_analytics_extract" in names
        assert "ai_search_enrich" in names
        assert "validate_variant" in names
        assert "validate_complex" in names
        assert "lookup_gene_registry" in names
        assert "parse_hgvs" in names
        assert "discard_mutation" in names
        assert len(names) == 8

    def test_definitions_have_required_fields(self):
        defs = AgentExtractionService._build_tool_definitions()
        for d in defs:
            assert d["type"] == "function"
            func = d["function"]
            assert "name" in func
            assert "description" in func
            assert "parameters" in func
            params = func["parameters"]
            assert params["type"] == "object"
            assert "properties" in params
            assert "required" in params


# ── mutation key ──────────────────────────────────────────────


class TestMutationKey:
    def test_grch38_coordinate(self):
        mutation = MagicMock()
        mutation.genomic_coordinates = {
            "grch38": MagicMock(hgvs="NC_000023.11:g.154031326G>A")
        }
        mutation.genomic_coordinate = None
        key = AgentExtractionService._mutation_key(mutation)
        assert key == "NC_000023.11:g.154031326G>A"

    def test_fallback_genomic_coordinate(self):
        mutation = MagicMock()
        mutation.genomic_coordinates = {}
        mutation.genomic_coordinate = "NC_000023.11:g.154031326G>A"
        key = AgentExtractionService._mutation_key(mutation)
        assert key == "NC_000023.11:g.154031326G>A"

    def test_no_coordinates_returns_none(self):
        mutation = MagicMock()
        mutation.genomic_coordinates = {}
        mutation.genomic_coordinate = None
        key = AgentExtractionService._mutation_key(mutation)
        assert key is None


# ── collect_mutations ─────────────────────────────────────────


class TestCollectMutations:
    def test_validate_variant_collects_mutation(self):
        mutation = MagicMock()
        mutation.genomic_coordinates = {
            "grch38": MagicMock(hgvs="NC_000023.11:g.154031326G>A")
        }
        mutation.genomic_coordinate = None

        result = MagicMock()
        result.success = True
        result.mutation = mutation

        mutations = {}
        genes = []
        AgentExtractionService._collect_mutations(
            "validate_variant", result, mutations, genes
        )
        assert len(mutations) == 1
        assert "NC_000023.11:g.154031326G>A" in mutations

    def test_lookup_gene_registry_collects_gene(self):
        result = MagicMock()
        result.success = True
        result.gene = MagicMock(symbol="MECP2")

        mutations = {}
        genes = []
        AgentExtractionService._collect_mutations(
            "lookup_gene_registry", result, mutations, genes
        )
        assert genes == ["MECP2"]

    def test_duplicate_gene_not_added(self):
        result = MagicMock()
        result.success = True
        result.gene = MagicMock(symbol="MECP2")

        mutations = {}
        genes = ["MECP2"]
        AgentExtractionService._collect_mutations(
            "lookup_gene_registry", result, mutations, genes
        )
        assert genes == ["MECP2"]

    def test_failed_validation_ignores(self):
        result = MagicMock()
        result.success = False
        result.mutation = None

        mutations = {}
        genes = []
        AgentExtractionService._collect_mutations(
            "validate_variant", result, mutations, genes
        )
        assert len(mutations) == 0


# ── extract_mutations (full loop with mocked LLM) ──────────


class TestExtractMutations:
    @pytest.mark.asyncio
    async def test_happy_path_with_mocked_llm(self, mock_config, mock_services):
        svc = AgentExtractionService(mock_config, mock_services)

        # Build a mock LLM response that calls lookup_gene_registry then stops
        tool_call = MagicMock()
        tool_call.id = "call_1"
        tool_call.function.name = "lookup_gene_registry"
        tool_call.function.arguments = json.dumps({"gene_symbol": "MECP2"})

        msg_with_tools = MagicMock()
        msg_with_tools.tool_calls = [tool_call]

        choice_tool = MagicMock()
        choice_tool.finish_reason = "tool_calls"
        choice_tool.message = msg_with_tools

        response_tool = MagicMock()
        response_tool.choices = [choice_tool]

        # Second response: stop
        msg_stop = MagicMock()
        msg_stop.content = "Found MECP2 gene"
        msg_stop.tool_calls = None

        choice_stop = MagicMock()
        choice_stop.finish_reason = "stop"
        choice_stop.message = msg_stop

        response_stop = MagicMock()
        response_stop.choices = [choice_stop]

        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(
            side_effect=[response_tool, response_stop]
        )

        with patch(
            "openai.AsyncAzureOpenAI",
            return_value=mock_client,
        ):
            result = await svc.extract_mutations(
                "Patient has a MECP2 mutation c.916C>T"
            )

        assert isinstance(result, ExtractionResult)
        assert result.tool_calls_count >= 1
        assert "MECP2" in result.genes_detected
        assert len(result.extraction_log) > 0
        assert any("PHI redaction" in log for log in result.extraction_log)

    @pytest.mark.asyncio
    async def test_llm_timeout_raises_extraction_error(
        self, mock_config, mock_services
    ):
        svc = AgentExtractionService(mock_config, mock_services)

        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(
            side_effect=asyncio.TimeoutError()
        )

        with patch(
            "openai.AsyncAzureOpenAI",
            return_value=mock_client,
        ):
            with pytest.raises(ExtractionError, match="timed out"):
                await svc.extract_mutations("some text")

    @pytest.mark.asyncio
    async def test_extraction_error_contains_log(self, mock_config, mock_services):
        svc = AgentExtractionService(mock_config, mock_services)

        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(
            side_effect=RuntimeError("API down")
        )

        with patch(
            "openai.AsyncAzureOpenAI",
            return_value=mock_client,
        ):
            with pytest.raises(ExtractionError) as exc_info:
                await svc.extract_mutations("some text")
            assert len(exc_info.value.extraction_log) > 0


# ── dispatch_tool ─────────────────────────────────────────────


class TestDispatchTool:
    @pytest.mark.asyncio
    async def test_unknown_tool_returns_failure(self, mock_config, mock_services):
        svc = AgentExtractionService(mock_config, mock_services)

        # Bypass lazy init by setting tool functions directly
        svc._tool_functions = {}
        svc._llm_client = MagicMock()

        from rettxmutation.models.tool_outputs import BaseToolOutput

        result = await svc._dispatch_tool("nonexistent_tool", {}, "original text")
        assert isinstance(result, BaseToolOutput)
        assert result.success is False
        assert "Unknown tool" in result.error

    @pytest.mark.asyncio
    async def test_regex_extract_injects_original_text(
        self, mock_config, mock_services
    ):
        svc = AgentExtractionService(mock_config, mock_services)

        captured_kwargs = {}

        async def capture_regex(**kwargs):
            captured_kwargs.update(kwargs)
            from rettxmutation.models.tool_outputs import RegexToolOutput

            return RegexToolOutput(success=True)

        svc._tool_functions = {"regex_extract": capture_regex}
        svc._llm_client = MagicMock()

        await svc._dispatch_tool(
            "regex_extract", {"text": "redacted"}, "original text with PHI"
        )
        assert captured_kwargs["text"] == "original text with PHI"
