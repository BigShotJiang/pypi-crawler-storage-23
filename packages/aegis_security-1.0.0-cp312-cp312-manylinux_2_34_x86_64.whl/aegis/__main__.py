"""Entry point for `python -m aegis`."""

from aegis.cli import main

main()
