"""AEGIS Browser — Native messaging bridge for browser extension."""
