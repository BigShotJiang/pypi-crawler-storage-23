"""AEGIS hooks — integration with AI coding agents."""
