"""AEGIS — AI Environment Guardian & Integrity Shield.

v1.0: Kernel-level enforcement with eBPF LSM.
"""

__version__ = "1.0.0"
