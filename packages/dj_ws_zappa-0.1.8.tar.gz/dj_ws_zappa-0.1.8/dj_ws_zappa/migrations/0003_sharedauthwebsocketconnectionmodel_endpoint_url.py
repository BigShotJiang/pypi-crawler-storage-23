# Generated manually on 2026-03-04

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('dj_ws_zappa', '0002_websocketconnectionmodel_endpoint_url'),
    ]

    operations = [
        migrations.AddField(
            model_name='sharedauthwebsocketconnectionmodel',
            name='endpoint_url',
            field=models.CharField(blank=True, max_length=255, null=True),
        ),
    ]
