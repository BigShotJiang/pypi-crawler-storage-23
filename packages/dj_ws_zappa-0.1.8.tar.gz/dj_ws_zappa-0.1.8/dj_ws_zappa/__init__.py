try:
    from . import handlers
except ImportError:
    pass
    
default_app_config = "dj_ws_zappa.app.DjWsZappaConfig"
