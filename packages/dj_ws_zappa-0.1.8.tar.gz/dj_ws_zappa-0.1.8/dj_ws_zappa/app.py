from django.apps import AppConfig

class DjWsZappaConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = 'dj_ws_zappa'
    verbose_name = 'Zappa WebSockets'

    def ready(self):
        from . import handlers