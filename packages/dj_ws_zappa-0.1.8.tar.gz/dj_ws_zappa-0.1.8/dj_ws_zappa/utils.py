import json
import logging
from typing import Dict, Any

from boto3 import client as boto3_client

def broadcast_to_connections(user_ids: list, payload: Dict[str, Any]):
    """
    Lista as conexões ativas para os IDs de usuário fornecidos
    e envia o payload instanciando o Zappa via boto3 pra os endpoints reais salvos na tabela.
    """
    if not user_ids:
        return

    # Buscar apenas conexões cadastradas para estes usuários
    try:
        from shared_auth.models import User
        from .models import SharedAuthWebSocketConnectionModel as ModelClass
    except ImportError:
        from .models import WebSocketConnectionModel as ModelClass
        
    apigw_clients = {}
    
    # Recupera o id do websocket e o host da amazon dele (cada um pode ter um fallback)
    connections_data = list(ModelClass.objects.filter(user_id__in=user_ids).values('connection_id', 'endpoint_url'))
    
    if not connections_data:
        return
        
    logger.info(f"Broadcasting websocket to {len(connections_data)} connections...")
    
    # ----------------------------------------------------
    # Código adaptado do zappa.websocket.send_message
    # ----------------------------------------------------
    if isinstance(payload, bytes):
        raw_data = payload
    elif isinstance(payload, str):
        raw_data = payload.encode("utf-8")
    else:
        raw_data = json.dumps(payload).encode("utf-8")
    
    failed_connections = []
    
    for conn in connections_data:
        conn_id = conn['connection_id']
        endpoint_url = conn.get('endpoint_url')
        
        if not endpoint_url:
            continue
            
        if endpoint_url not in apigw_clients:
            apigw_clients[endpoint_url] = boto3_client("apigatewaymanagementapi", endpoint_url=endpoint_url)
            
        client = apigw_clients[endpoint_url]
        
        try:
            client.post_to_connection(
                ConnectionId=conn_id,
                Data=raw_data
            )
        except client.exceptions.GoneException:
            failed_connections.append(conn_id)
        except Exception as e:
            logger.error(f"Falha ao enviar evento para conn_id {conn_id}: {e}")
            
    if failed_connections:
        ModelClass.objects.filter(connection_id__in=failed_connections).delete()
        
    return failed_connections
