from setuptools import setup, find_packages

setup(
    name="dj-ws-zappa",
    version="0.1.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "django>=4",
        "zappa>=0.59",
        "boto3>=1.28.0",
        "PyJWT>=2.8.0",
        "maquinaweb-shared-auth>=0.2.81",
    ],
)
