"""Interfaces: CLI and HTTP API entrypoints."""
