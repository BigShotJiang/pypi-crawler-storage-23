# toml-fmt-common

Contains Rust code common to all formatters under the `toml-fmt` umbrella.

[![Test common](https://github.com/tox-dev/toml-fmt/actions/workflows/common.yaml/badge.svg)](https://github.com/tox-dev/toml-fmt/actions/workflows/common.yaml)
