"""Communication diagnostics and debugging tools.

Implements issue #37: [Tools] 通信诊断和调试工具

Provides:
- CommTracer: Records all communication operations with timestamps
- CommProfiler: Performance analysis – identifies slow ops / bottlenecks
- CommDiagnostics: High-level facade combining trace + profile + topology info
"""

from __future__ import annotations

from sagellm_comm.diagnostics.profiler import CommProfiler, ProfileReport
from sagellm_comm.diagnostics.tracer import CommOperation, CommTracer, TraceRecord

__all__ = [
    "CommTracer",
    "TraceRecord",
    "CommOperation",
    "CommProfiler",
    "ProfileReport",
]
