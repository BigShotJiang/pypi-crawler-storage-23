"""Communication algorithms package for sagellm-comm.

Provides collective algorithm implementations (Ring / Tree / Hybrid All-Reduce)
that run as pure-Python simulations and interface with the CommBackend.
"""

from __future__ import annotations

from sagellm_comm.algorithms.allreduce import (
    AllReduceAlgorithm,
    HybridAllReduce,
    RingAllReduce,
    TreeAllReduce,
)
from sagellm_comm.algorithms.base import CommAlgorithm
from sagellm_comm.algorithms.registry import CommAlgorithmRegistry
from sagellm_comm.algorithms.ring import RingCommAlgorithm
from sagellm_comm.algorithms.selector import AlgorithmSelector, SelectorConfig
from sagellm_comm.algorithms.tree import TreeCommAlgorithm

__all__ = [
    "AllReduceAlgorithm",
    "CommAlgorithm",
    "CommAlgorithmRegistry",
    "RingAllReduce",
    "TreeAllReduce",
    "HybridAllReduce",
    "RingCommAlgorithm",
    "TreeCommAlgorithm",
    "AlgorithmSelector",
    "SelectorConfig",
]
