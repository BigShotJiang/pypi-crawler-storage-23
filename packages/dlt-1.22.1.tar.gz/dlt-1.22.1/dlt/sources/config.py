from dlt.common.configuration.specs import configspec
from dlt.common.configuration.inject import with_config
