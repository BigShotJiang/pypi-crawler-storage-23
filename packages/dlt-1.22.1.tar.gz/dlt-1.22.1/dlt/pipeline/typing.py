from typing import Literal

TPipelineStep = Literal["run", "sync", "extract", "normalize", "load"]
