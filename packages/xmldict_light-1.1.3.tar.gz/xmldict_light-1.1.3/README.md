# XmlDict
This is a lightweight implementation to transform JSON to XML and vice versa.
Uses only python core functions, so no external requirements.