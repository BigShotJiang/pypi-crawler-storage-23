from ._cmd_helper import main

if __name__ == "__main__":
    main()
