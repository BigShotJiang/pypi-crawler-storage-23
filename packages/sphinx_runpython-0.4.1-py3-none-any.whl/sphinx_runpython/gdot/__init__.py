from .sphinx_gdot_extension import setup

__all__ = ["setup"]
