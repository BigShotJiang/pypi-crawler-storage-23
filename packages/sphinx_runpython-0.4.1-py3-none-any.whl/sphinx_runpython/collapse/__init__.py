from .sphinx_collapse_extension import setup

__all__ = ["setup"]
