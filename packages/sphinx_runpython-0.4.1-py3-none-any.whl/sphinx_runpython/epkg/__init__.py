from .sphinx_epkg_extension import setup

__all__ = ["setup"]
