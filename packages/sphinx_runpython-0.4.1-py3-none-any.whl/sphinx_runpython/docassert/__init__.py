from .sphinx_docassert_extension import setup

__all__ = ["setup"]
