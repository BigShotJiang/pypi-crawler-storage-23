from .sphinx_quote_extension import setup

__all__ = ["setup"]
