"""Tests for Personaut server module."""
