"""LLM configuration for LLM-based judges."""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any

@dataclass
class LLMConfig:
    """
    Configuration for LLM API calls.

    Examples:
        >>> # OpenAI
        >>> config = LLMConfig(model="gpt-4o")
        
        >>> # Anthropic with custom settings
        >>> config = LLMConfig(
        ...     model="claude-3-5-sonnet-20241022",
        ...     temperature=0.5,
        ...     max_tokens=3000
        ... )
        
        >>> # Local Ollama
        >>> config = LLMConfig(
        ...     model="ollama/llama3",
        ...     api_base="http://localhost:11434"
        ... )
    """

    model: str
    api_key: Optional[str] = None
    api_base: Optional[str] = None
    temperature: float = 0.0
    max_tokens: int = 2000
    num_retries: int = 3 
    retry_after: Optional[float] = None
    extra_kwargs: Dict[str, Any] = field(default_factory=dict)  # For litellm_kwargs


# src/openevalkit/judges/llm_config.py

"""Configuration for LLM-based judges."""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any


@dataclass
class LLMConfig:
    """
    Configuration for LLM API calls.
    
    Examples:
        >>> # OpenAI with retries
        >>> config = LLMConfig(
        ...     model="gpt-4o",
        ...     num_retries=3,
        ...     retry_after=2.0
        ... )
        
        >>> # Anthropic with custom settings
        >>> config = LLMConfig(
        ...     model="claude-3-5-sonnet-20241022",
        ...     temperature=0.5,
        ...     max_tokens=3000,
        ...     num_retries=5
        ... )
        
        >>> # Local Ollama (no retries needed)
        >>> config = LLMConfig(
        ...     model="ollama/llama3",
        ...     api_base="http://localhost:11434",
        ...     num_retries=0
        ... )
    """
    model: str
    api_key: Optional[str] = None
    api_base: Optional[str] = None
    temperature: float = 0.0
    max_tokens: int = 2000
    
    # Retry configuration (handled by LiteLLM)
    num_retries: int = 3  # Number of retry attempts
    retry_after: Optional[float] = None  # Minimum wait time before retry (seconds)
    
    extra_kwargs: Dict[str, Any] = field(default_factory=dict)