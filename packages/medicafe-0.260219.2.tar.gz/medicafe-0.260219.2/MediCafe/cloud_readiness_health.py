#!/usr/bin/env python
"""
Cloud readiness health snapshot helpers for launcher menus.

Keeps health interpretation and ASCII rendering out of launcher.py so the
menu code can stay focused on routing actions.
"""
from __future__ import print_function

import json
import os


_STATUS_MARK = {
    "ok": "+",
    "warn": "!",
    "fail": "x",
    "unknown": "?",
    "running": "~",
}

_STATUS_LABEL = {
    "ok": "OK",
    "warn": "WARN",
    "fail": "FAIL",
    "unknown": "UNKNOWN",
    "running": "RUNNING",
}

_PHASE_ORDER = {
    "A": 1,
    "B": 2,
    "C": 3,
    "D": 4,
    "E": 5,
    "F": 6,
}


def _safe_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _safe_load_json(path):
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except (IOError, OSError, ValueError):
        pass
    return {}


def _pid_running(pid):
    try:
        pid_int = int(pid)
    except (ValueError, TypeError):
        return False
    if pid_int <= 0:
        return False

    if os.name == "nt":
        try:
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            PROCESS_QUERY_INFORMATION = 0x0400
            STILL_ACTIVE = 259

            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid_int)
            if not handle:
                handle = kernel32.OpenProcess(PROCESS_QUERY_INFORMATION, 0, pid_int)
            if not handle:
                try:
                    last_error = kernel32.GetLastError()
                    if int(last_error) == 5:
                        return True
                except Exception:
                    pass
                return False
            try:
                exit_code = ctypes.c_ulong(0)
                if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return True
                return int(exit_code.value) == STILL_ACTIVE
            finally:
                kernel32.CloseHandle(handle)
        except Exception:
            return True

    try:
        os.kill(pid_int, 0)
        return True
    except OSError:
        return False


def is_pipeline_running(lab_root):
    """Check if shadow pipeline is running via lock file. Returns bool."""
    if not lab_root:
        return False
    lock_path = os.path.join(lab_root, 'shadow_pipeline.lock')
    return _pipeline_running(lock_path)


def _pipeline_running(lock_path):
    if not lock_path or not os.path.exists(lock_path):
        return False
    pid = None
    try:
        with open(lock_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line.startswith("pid="):
                    pid = line[4:].strip()
                    break
    except (IOError, OSError):
        return True
    if pid is None or not str(pid).strip():
        return True
    return _pid_running(pid)


def _phase_status_from_bool(ok_value):
    if ok_value is True:
        return "ok"
    if ok_value is False:
        return "fail"
    return "unknown"


def _phase_run_id(state, phase_code):
    """Resolve phase run_id from v2 map first, then legacy keys."""
    phase_map = state.get("last_shadow_pipeline_phase_run_ids", {})
    if isinstance(phase_map, dict):
        rid = phase_map.get(phase_code, "")
        if rid and str(rid).strip():
            return str(rid).strip()
    legacy_keys = {
        "B": "last_phase_b_run_id",
        "C": "last_phase_c_run_id",
        "D": "last_phase_d_run_id",
        "E": "last_phase_e_run_id",
    }
    key = legacy_keys.get(phase_code, "")
    rid = state.get(key, "") if key else ""
    return str(rid).strip() if rid else ""


def _phase_pending(state, phase_code, run_id, status, err):
    lifecycle_state = str(state.get("pipeline_state", "") or "").strip().lower()
    if lifecycle_state not in ("bootstrapping", "running"):
        return False
    if run_id or status != "unknown" or err:
        return False
    active_phase = str(state.get("active_phase", "") or "").strip().upper()
    if not active_phase:
        return False
    return _PHASE_ORDER.get(phase_code, 99) >= _PHASE_ORDER.get(active_phase, 0)


def _build_phase_b(state):
    run_id = _phase_run_id(state, "B")
    err = state.get("last_discovery_error_code")
    status = _phase_status_from_bool(state.get("last_discovery_ok"))
    counts = state.get("last_discovery_counts_by_class", {})
    if not isinstance(counts, dict):
        counts = {}
    total = 0
    class_bits = []
    for key in sorted(counts.keys()):
        val = _safe_int(counts.get(key), 0)
        total += val
        class_bits.append("{0}:{1}".format(key, val))
    if status == "ok" and total <= 0:
        status = "warn"
    detail_parts = [
        "run_id={0}".format(run_id or "-"),
        "total={0}".format(total),
    ]
    if class_bits:
        detail_parts.append("classes={0}".format(",".join(class_bits)))
    if err:
        detail_parts.append("err={0}".format(err))
    elif status == "unknown" and not run_id:
        if _phase_pending(state, "B", run_id, status, err):
            status = "running"
            detail_parts.append("state=awaiting_phase_write")
        else:
            status = "warn"
            detail_parts.append("state=not_run")
    return {
        "code": "B",
        "name": "Discovery",
        "status": status,
        "detail": ", ".join(detail_parts),
    }


def _build_phase_c(state):
    run_id = _phase_run_id(state, "C")
    err = state.get("last_phase_c_error_code")
    status = _phase_status_from_bool(state.get("last_phase_c_ok"))
    anomalies = _safe_int(state.get("last_phase_c_anomaly_count"), 0)
    if status == "ok" and anomalies > 0:
        status = "warn"
    detail_parts = [
        "run_id={0}".format(run_id or "-"),
        "inserted={0}".format(_safe_int(state.get("last_ingest_rows_inserted"), 0)),
        "failed={0}".format(_safe_int(state.get("last_ingest_rows_failed"), 0)),
        "anomalies={0}".format(anomalies),
    ]
    if err:
        detail_parts.append("err={0}".format(err))
    elif status == "unknown" and not run_id:
        if _phase_pending(state, "C", run_id, status, err):
            status = "running"
            detail_parts.append("state=awaiting_phase_write")
        else:
            status = "warn"
            detail_parts.append("state=not_run")
    return {
        "code": "C",
        "name": "Ingest",
        "status": status,
        "detail": ", ".join(detail_parts),
    }


def _build_phase_d(state):
    run_id = _phase_run_id(state, "D")
    err = state.get("last_phase_d_error_code")
    status = _phase_status_from_bool(state.get("last_phase_d_ok"))
    rejects = _safe_int(state.get("last_phase_d_reject_count"), 0)
    if status == "ok" and rejects > 0:
        status = "warn"
    detail_parts = [
        "run_id={0}".format(run_id or "-"),
        "pass={0}".format(_safe_int(state.get("last_phase_d_pass_count"), 0)),
        "reject={0}".format(rejects),
    ]
    if err:
        detail_parts.append("err={0}".format(err))
    elif status == "unknown" and not run_id:
        if _phase_pending(state, "D", run_id, status, err):
            status = "running"
            detail_parts.append("state=awaiting_phase_write")
        else:
            status = "warn"
            detail_parts.append("state=not_run")
    return {
        "code": "D",
        "name": "QA",
        "status": status,
        "detail": ", ".join(detail_parts),
    }


def _build_phase_e(state):
    run_id = _phase_run_id(state, "E")
    err = state.get("last_phase_e_error_code")
    status = _phase_status_from_bool(state.get("last_phase_e_ok"))
    contract_parity = (state.get("last_contract_parity_status") or "").strip().lower()
    baseline_parity = (state.get("last_baseline_parity_status") or "").strip().lower()
    if contract_parity == "fail":
        status = "fail"
    elif status == "ok" and contract_parity != "pass":
        status = "warn"
    detail_parts = [
        "run_id={0}".format(run_id or "-"),
        "projected={0}".format(_safe_int(state.get("last_phase_e_projected_count"), 0)),
        "parity={0}".format(contract_parity or "-"),
        "baseline={0}".format(baseline_parity or "-"),
    ]
    if err:
        detail_parts.append("err={0}".format(err))
    elif status == "unknown" and not run_id:
        if _phase_pending(state, "E", run_id, status, err):
            status = "running"
            detail_parts.append("state=awaiting_phase_write")
        else:
            status = "warn"
            detail_parts.append("state=not_run")
    return {
        "code": "E",
        "name": "Projection",
        "status": status,
        "detail": ", ".join(detail_parts),
    }


def _build_phase_f(state, pipeline_running):
    lifecycle_state = (state.get("pipeline_state") or "").strip().lower()
    if lifecycle_state in ("bootstrapping", "running"):
        status = "running"
    elif lifecycle_state == "failed":
        status = "fail"
    elif lifecycle_state == "completed":
        status = "ok"
    elif pipeline_running:
        status = "running"
    else:
        status = _phase_status_from_bool(state.get("last_shadow_pipeline_ok"))
    run_id = state.get("active_run_id", "") or state.get("last_shadow_pipeline_run_id", "") or ""
    detail_parts = [
        "run_id={0}".format(run_id or "-"),
        "active_phase={0}".format(state.get("active_phase", "") or "-"),
        "failed_phase={0}".format(state.get("last_shadow_pipeline_failed_phase", "") or "-"),
    ]
    error_code = state.get("last_error_code", "") or state.get("last_shadow_pipeline_error_code", "")
    if error_code and status != "running":
        detail_parts.append("err={0}".format(error_code))
    lock_diag = state.get("last_phase_f_lock_diag_path", "") or ""
    if lock_diag:
        detail_parts.append("lock_diag={0}".format(os.path.basename(lock_diag)))
    elif status == "unknown" and not run_id:
        status = "warn"
        detail_parts.append("state=not_run")
    return {
        "code": "F",
        "name": "Shadow Health",
        "status": status,
        "detail": ", ".join(detail_parts),
    }


def build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True):
    """
    Build an interpreted, ASCII-only health snapshot for phases B..F.
    Returns a list of printable lines.
    """
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    lock_path = os.path.join(lab_root, "shadow_pipeline.lock")
    state = _safe_load_json(state_path)
    pipeline_running = _pipeline_running(lock_path)

    phase_rows = [
        _build_phase_b(state),
        _build_phase_c(state),
        _build_phase_d(state),
        _build_phase_e(state),
        _build_phase_f(state, pipeline_running),
    ]

    path_bits = []
    count_ok = 0
    count_warn = 0
    count_fail = 0
    count_unknown = 0
    count_running = 0
    for row in phase_rows:
        st = row.get("status", "unknown")
        mark = _STATUS_MARK.get(st, "?")
        path_bits.append("[{0}:{1}]".format(row.get("code", "?"), mark))
        if st == "ok":
            count_ok += 1
        elif st == "warn":
            count_warn += 1
        elif st == "fail":
            count_fail += 1
        elif st == "running":
            count_running += 1
        else:
            count_unknown += 1

    if count_fail > 0:
        overall = "FAIL"
    elif count_warn > 0:
        overall = "WARN"
    elif count_running > 0:
        overall = "RUNNING"
    elif count_unknown > 0:
        overall = "UNKNOWN"
    else:
        overall = "OK"
    total_phases = len(phase_rows)
    flow_visual = " -> ".join(path_bits)
    headline = "Pipeline Health: {0} ({1}/{2} phases healthy)".format(
        overall, count_ok, total_phases
    )
    counts_line = "Counts: OK {0} | WARN {1} | FAIL {2} | UNKNOWN {3} | RUNNING {4}".format(
        count_ok, count_warn, count_fail, count_unknown, count_running
    )
    dash_width = 80
    inner_width = dash_width - 4

    def _dash_row(text):
        clean = str(text or "")
        if len(clean) > inner_width:
            clean = clean[:inner_width]
        return "| {0:<{1}} |".format(clean, inner_width)

    lines = []
    lines.append("Pipeline Health Snapshot")
    lines.append("+" + ("=" * (dash_width - 2)) + "+")
    lines.append(_dash_row(headline))
    lines.append(_dash_row("Flow: {0}".format(flow_visual)))
    lines.append(_dash_row(counts_line))
    lines.append("+" + ("-" * (dash_width - 2)) + "+")
    lines.append("{0:<5} {1:<16} {2:<10} {3}".format("Phase", "Name", "Status", "Details"))
    lines.append("-" * 80)
    for row in phase_rows:
        status = row.get("status", "unknown")
        mark = _STATUS_MARK.get(status, "?")
        label = _STATUS_LABEL.get(status, "UNKNOWN")
        lines.append(
            "{0:<5} {1:<16} {2:<10} {3}".format(
                "{0}:{1}".format(row.get("code", "?"), mark),
                row.get("name", "Phase"),
                label,
                row.get("detail", ""),
            )
        )

    if pipeline_running:
        lines.append("-" * 80)
        lines.append("Note: shadow_pipeline.lock is present; pipeline activity may still be in progress.")

    lines.append("-" * 80)
    lines.append(
        "Automation: pipeline_auto={0}, health_telemetry_auto={1}".format(
            bool(auto_pipeline), bool(auto_health)
        )
    )
    return lines
