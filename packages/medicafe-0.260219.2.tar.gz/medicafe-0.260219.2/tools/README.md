# MediLink Pipeline Tools

This folder now contains only focused helper scripts that support the validator-first workflow.

## Canonical Path

Use the validator workflow as the primary operator path:

```powershell
py -3.11 cloud/orchestrator/validate_and_complete_setup.py
py -3.11 cloud/orchestrator/validate_and_complete_setup.py --validate-only
py -3.11 cloud/orchestrator/validate_and_complete_setup.py --verify-runtime
```

Use alert drift checks via:

```powershell
py -3.11 cloud/orchestrator/setup_alerting.py --project-id <PROJECT_ID> --check-drift
```

## Active Scripts In `tools/`

- `get_gmail_oauth_token.ps1`: obtain/refresh user OAuth token for break-glass setup fallback.
- `verify_keyless_dwd.ps1`: guided keyless DWD verification helper.

## Cleanup Notes

Legacy one-off pipeline/subscription/watch scripts were removed to prevent drift from current production strategy.
