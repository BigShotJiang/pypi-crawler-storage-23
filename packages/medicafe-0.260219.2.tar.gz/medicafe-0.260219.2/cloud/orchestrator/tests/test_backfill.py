"""Unit tests for processor has_backlog and run_backfill."""

from __future__ import annotations

import sys
import os
import unittest
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from processor import has_backlog, run_backfill


def _mock_config():
    cfg = MagicMock()
    cfg.gmail_label_ids = []
    return cfg


class TestHasBacklog(unittest.TestCase):
    """Test has_backlog helper."""

    @patch("processor.services.gmail_client")
    def test_has_backlog_true_when_messages_exist(self, mock_gmail):
        """has_backlog returns True when messages.list returns at least one message."""
        mock_client = MagicMock()
        mock_client.users.return_value.messages.return_value.list.return_value.execute.return_value = {
            "messages": [{"id": "msg1"}],
        }
        mock_gmail.return_value = mock_client
        config = _mock_config()
        self.assertTrue(has_backlog(config))

    @patch("processor.services.gmail_client")
    def test_has_backlog_false_when_empty(self, mock_gmail):
        """has_backlog returns False when messages.list returns empty."""
        mock_client = MagicMock()
        mock_client.users.return_value.messages.return_value.list.return_value.execute.return_value = {
            "messages": [],
        }
        mock_gmail.return_value = mock_client
        config = _mock_config()
        self.assertFalse(has_backlog(config))


class TestRunBackfillBatchLimit(unittest.TestCase):
    """Test run_backfill batch size limit."""

    @patch("processor._handle_message")
    @patch("processor._fetch_message")
    @patch("processor._find_existing_queue_doc")
    @patch("processor._bootstrap_messages")
    @patch("processor.services.storage_client")
    @patch("processor.services.firestore_client")
    @patch("processor.services.gmail_client")
    def test_batch_size_limits_processed_count(
        self,
        mock_gmail,
        mock_fs,
        mock_storage,
        mock_bootstrap,
        mock_find,
        mock_fetch,
        mock_handle,
    ):
        """run_backfill with batch_size=5 processes at most 5 messages when 10 exist."""
        mock_bootstrap.return_value = ["id{}".format(i) for i in range(10)]
        mock_find.return_value = None
        mock_fetch.return_value = {"id": "x", "payload": {"headers": []}}

        config = _mock_config()
        result = run_backfill(config, batch_size=5)

        self.assertEqual(result["scanned_count"], 5)
        self.assertEqual(mock_fetch.call_count, 5)
        self.assertEqual(mock_handle.call_count, 5)
        self.assertLessEqual(
            result["processed_count"] + result["skipped_count"] + result["failed_count"],
            5,
        )


class TestRunBackfillExistingDocSkip(unittest.TestCase):
    """Test run_backfill skips already-queued messages without fetch."""

    @patch("processor._handle_message")
    @patch("processor._fetch_message")
    @patch("processor._find_existing_queue_doc")
    @patch("processor._bootstrap_messages")
    @patch("processor.services.storage_client")
    @patch("processor.services.firestore_client")
    @patch("processor.services.gmail_client")
    def test_existing_doc_skipped_without_fetch(
        self,
        mock_gmail,
        mock_fs,
        mock_storage,
        mock_bootstrap,
        mock_find,
        mock_fetch,
        mock_handle,
    ):
        """Existing queue doc is skipped without calling _fetch_message/_handle_message."""
        mock_bootstrap.return_value = ["existing_msg", "new_msg"]
        existing_doc = MagicMock()
        existing_doc.to_dict.return_value = {"acked": False}

        def find_side_effect(fs, cfg, msg_id):
            if msg_id == "existing_msg":
                return existing_doc
            return None

        mock_find.side_effect = find_side_effect
        mock_fetch.return_value = {"id": "new_msg", "payload": {"headers": []}}

        config = _mock_config()
        result = run_backfill(config, batch_size=5)

        self.assertEqual(result["scanned_count"], 2)
        self.assertEqual(result["skipped_count"], 1)
        mock_fetch.assert_called_once()
        mock_handle.assert_called_once()
        self.assertEqual(mock_fetch.call_args[0][1], "new_msg")


class TestRunBackfillIdempotency(unittest.TestCase):
    """Test run_backfill is idempotent by message_id (re-run behavior)."""

    @patch("processor._handle_message")
    @patch("processor._fetch_message")
    @patch("processor._find_existing_queue_doc")
    @patch("processor._bootstrap_messages")
    @patch("processor.services.storage_client")
    @patch("processor.services.firestore_client")
    @patch("processor.services.gmail_client")
    def test_re_run_skips_already_queued_on_second_run(
        self,
        mock_gmail,
        mock_fs,
        mock_storage,
        mock_bootstrap,
        mock_find,
        mock_fetch,
        mock_handle,
    ):
        """Second run skips already-queued docs without fetch/handle; skipped_count reflects it.

        First run: both id1 and id2 processed. Second run: both ids already exist in
        queue (acked or unacked), so both are skipped before fetch/handle.
        """
        mock_bootstrap.return_value = ["id1", "id2"]
        acked_doc = MagicMock()
        acked_doc.to_dict.return_value = {"acked": True}
        unacked_doc = MagicMock()
        unacked_doc.to_dict.return_value = {"acked": False}
        # Run 1: id1->None, id2->None. Run 2: id1->acked, id2->unacked.
        mock_find.side_effect = [None, None, acked_doc, unacked_doc]
        mock_fetch.return_value = {"id": "x", "payload": {"headers": []}}

        config = _mock_config()
        result1 = run_backfill(config, batch_size=10)
        result2 = run_backfill(config, batch_size=10)

        self.assertEqual(result1["scanned_count"], 2)
        self.assertEqual(result1["processed_count"], 2)
        self.assertEqual(result1["skipped_count"], 0)
        self.assertEqual(result2["scanned_count"], 2)
        self.assertEqual(result2["processed_count"], 0)
        self.assertEqual(result2["skipped_count"], 2)
        self.assertEqual(mock_fetch.call_count, 2)
        self.assertEqual(mock_handle.call_count, 2)


if __name__ == "__main__":
    unittest.main()
