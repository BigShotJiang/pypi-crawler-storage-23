"""Unit tests for preprocessor accept/reject cases."""

import unittest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from unittest.mock import Mock
from preprocessor import (
    preprocess_queue_candidate,
    PreprocessResult,
    is_known_reject_code,
    REJECT_CODE_REGISTRY,
    SCHEMA_VERSION,
    PREPROCESSOR_VERSION,
)


def _mock_config():
    return Mock()


class TestPreprocessorAccept(unittest.TestCase):
    """Test preprocessor accept paths."""

    def test_valid_attachment_record(self):
        """Valid attachment record with all required fields is accepted."""
        raw = {
            "machine_id": "clinic-001",
            "message_id": "msg-123",
            "thread_id": "thread-456",
            "historyId": "789",
            "received_at": "1698879600000",
            "subject": "Test",
            "otp_required": False,
            "otp_token": None,
            "files": [
                {"filename": "doc.csv", "gcs_path": "clinic-001/abc/doc.csv", "mime_type": "text/csv", "size": 100},
            ],
        }
        result = preprocess_queue_candidate(raw, _mock_config(), "attempt-xyz")
        self.assertTrue(result.ok)
        self.assertIsNotNone(result.payload)
        self.assertEqual(result.payload["machine_id"], "clinic-001")
        self.assertEqual(result.payload["message_id"], "msg-123")
        self.assertEqual(result.payload["schema_version"], SCHEMA_VERSION)
        self.assertEqual(result.payload["preprocessor_version"], PREPROCESSOR_VERSION)
        self.assertEqual(result.payload["attempt_id"], "attempt-xyz")
        self.assertEqual(len(result.payload["files"]), 1)

    def test_valid_otp_record(self):
        """Valid OTP record (no files, otp_required=True) is accepted."""
        raw = {
            "machine_id": "clinic-001",
            "message_id": "msg-otp",
            "received_at": "1698879600000",
            "otp_required": True,
            "otp_token": "token-abc",
            "files": [],
        }
        result = preprocess_queue_candidate(raw, _mock_config(), "attempt-otp")
        self.assertTrue(result.ok)
        self.assertIsNotNone(result.payload)
        self.assertEqual(result.payload["otp_required"], True)
        self.assertEqual(result.payload["files"], [])


class TestPreprocessorReject(unittest.TestCase):
    """Test preprocessor reject paths."""

    def test_missing_machine_id(self):
        """Missing machine_id is rejected."""
        raw = {"message_id": "msg-1", "received_at": "1698879600000", "otp_required": True, "files": []}
        result = preprocess_queue_candidate(raw, _mock_config(), "attempt-1")
        self.assertFalse(result.ok)
        self.assertEqual(result.code, "missing_machine_id")
        self.assertIsNone(result.payload)

    def test_empty_machine_id(self):
        """Empty machine_id is rejected."""
        raw = {"machine_id": "  ", "message_id": "msg-1", "received_at": "1698879600000", "otp_required": True, "files": []}
        result = preprocess_queue_candidate(raw, _mock_config(), "attempt-1")
        self.assertFalse(result.ok)
        self.assertEqual(result.code, "missing_machine_id")

    def test_missing_message_id(self):
        """Missing message_id is rejected."""
        raw = {"machine_id": "clinic-001", "received_at": "1698879600000", "otp_required": True, "files": []}
        result = preprocess_queue_candidate(raw, _mock_config(), "attempt-1")
        self.assertFalse(result.ok)
        self.assertEqual(result.code, "missing_message_id")

    def test_missing_received_at(self):
        """Missing received_at is rejected."""
        raw = {"machine_id": "clinic-001", "message_id": "msg-1", "otp_required": True, "files": []}
        result = preprocess_queue_candidate(raw, _mock_config(), "attempt-1")
        self.assertFalse(result.ok)
        self.assertEqual(result.code, "missing_received_at")

    def test_empty_files_not_otp(self):
        """Empty files when otp_required=False is rejected."""
        raw = {
            "machine_id": "clinic-001",
            "message_id": "msg-1",
            "received_at": "1698879600000",
            "otp_required": False,
            "files": [],
        }
        result = preprocess_queue_candidate(raw, _mock_config(), "attempt-1")
        self.assertFalse(result.ok)
        self.assertEqual(result.code, "empty_files_not_otp")

    def test_invalid_files_item_missing_filename(self):
        """File item missing filename is rejected."""
        raw = {
            "machine_id": "clinic-001",
            "message_id": "msg-1",
            "received_at": "1698879600000",
            "otp_required": False,
            "files": [{"gcs_path": "path/to/file", "mime_type": "text/csv"}],
        }
        result = preprocess_queue_candidate(raw, _mock_config(), "attempt-1")
        self.assertFalse(result.ok)
        self.assertEqual(result.code, "invalid_files_item")

    def test_invalid_files_item_missing_gcs_path(self):
        """File item missing gcs_path is rejected."""
        raw = {
            "machine_id": "clinic-001",
            "message_id": "msg-1",
            "received_at": "1698879600000",
            "otp_required": False,
            "files": [{"filename": "doc.csv", "mime_type": "text/csv"}],
        }
        result = preprocess_queue_candidate(raw, _mock_config(), "attempt-1")
        self.assertFalse(result.ok)
        self.assertEqual(result.code, "invalid_files_item")


class TestRejectCodeRegistry(unittest.TestCase):
    """Test reject code registry."""

    def test_known_codes_in_registry(self):
        """All expected reject codes are in registry."""
        for code in ["missing_machine_id", "missing_message_id", "empty_files_not_otp", "invalid_files_item", "unhandled_exception"]:
            self.assertTrue(is_known_reject_code(code), "{} should be in registry".format(code))

    def test_unknown_code_not_in_registry(self):
        """Random string is not in registry."""
        self.assertFalse(is_known_reject_code("unknown_code_xyz"))


if __name__ == "__main__":
    unittest.main()
