"""Unit tests for DWD error-message branching under AUTH_MODE=dwd_required.

When keyless DWD fails: error must contain keyless-specific text (IAM Credentials,
Token Creator, DWD allowlist) and must NOT mention SERVICE_ACCOUNT_JSON.
"""

import unittest
from unittest.mock import Mock, patch
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from config import Config
    from services import _get_credentials
    SERVICES_AVAILABLE = True
except ImportError:
    SERVICES_AVAILABLE = False


@unittest.skipUnless(SERVICES_AVAILABLE, "services dependencies not available")
class TestDwdErrorMessages(unittest.TestCase):
    """Test error message branching for dwd_required when keyless fails."""

    def _make_config(self, auth_mode="dwd_required", service_account_info=None):
        """Build minimal Config for testing."""
        return Config(
            project_id="test-project",
            mailbox_user="test@example.com",
            gcs_bucket="test-bucket",
            firestore_queue_collection="queues",
            firestore_state_collection="sync_state",
            signed_url_ttl_seconds=3600,
            jwt_issuer="test",
            jwt_audience="test",
            client_machine_claim="machine_id",
            jwks_url=None,
            xp_public_key_pem=None,
            xp_jwt_algorithm="RS256",
            service_account_info=service_account_info,
            gmail_auth_method="service_account",
            auth_mode=auth_mode,
            gmail_oauth_client_id=None,
            gmail_oauth_client_secret=None,
            gmail_oauth_refresh_token=None,
            gmail_oauth_client_id_secret="gmail_oauth_client_id",
            gmail_oauth_client_secret_secret="gmail_oauth_client_secret",
            gmail_oauth_refresh_token_secret="gmail_oauth_refresh_token",
            enable_cleanup_on_ack=True,
            default_machine_id="clinic-001",
            gmail_processed_label=None,
            gmail_remove_labels=[],
            cleanup_gcs_files=True,
            ready_batch_size=10,
            admin_shared_secret=None,
            gmail_label_ids=[],
            gmail_pubsub_topic="gmail-new-emails",
            allowed_attachment_extensions=["docx", "csv"],
            allowed_sender_domains=None,
            preprocessor_mode="shadow",
            firestore_ingest_errors_collection="ingest_errors",
        )

    @patch("services._get_dwd_credentials_keyless")
    @patch("services._has_key_based_dwd_config")
    def test_keyless_dwd_failure_has_keyless_specific_text(self, mock_has_key, mock_keyless):
        """When keyless DWD fails, RuntimeError contains keyless-specific guidance (no SA key mention)."""
        mock_has_key.return_value = False  # No SA key -> keyless path
        mock_keyless.side_effect = RuntimeError("signJwt PERMISSION_DENIED")

        config = self._make_config(auth_mode="dwd_required", service_account_info=None)
        with self.assertRaises(RuntimeError) as ctx:
            _get_credentials(config)
        msg = str(ctx.exception)
        self.assertIn("Keyless DWD failed", msg)
        self.assertIn("IAM Credentials", msg)
        self.assertIn("TokenCreator", msg)
        self.assertIn("Workspace Admin", msg)
        self.assertNotIn("SERVICE_ACCOUNT_JSON", msg)

    @patch("services._get_base_service_account_credentials")
    @patch("services._has_key_based_dwd_config")
    def test_key_based_dwd_failure_mentions_sa_key(self, mock_has_key, mock_base):
        """When key-based DWD fails, message mentions SA key."""
        mock_has_key.return_value = True  # SA key configured -> key-based path
        mock_base.side_effect = RuntimeError("Invalid key file")

        config = self._make_config(
            auth_mode="dwd_required",
            service_account_info={"type": "service_account"},
        )
        with self.assertRaises(RuntimeError) as ctx:
            _get_credentials(config)
        msg = str(ctx.exception)
        self.assertIn("SERVICE_ACCOUNT_JSON", msg)
        self.assertIn("GOOGLE_APPLICATION_CREDENTIALS", msg)


if __name__ == "__main__":
    unittest.main()
