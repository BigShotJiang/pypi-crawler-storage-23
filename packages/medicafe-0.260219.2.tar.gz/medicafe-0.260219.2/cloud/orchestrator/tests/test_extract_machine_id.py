"""Regression tests for _extract_machine_id precedence.

Owner decision: when DEFAULT_MACHINE_ID is set, it is authoritative; header ignored.
When empty: header wins, then Firestore routing.
"""

import unittest
from unittest.mock import Mock
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from processor import _extract_machine_id
    PROCESSOR_AVAILABLE = True
except ImportError:
    PROCESSOR_AVAILABLE = False


def _make_message(headers=None, **kwargs):
    """Build minimal message dict for testing."""
    msg = {"id": "test-123", "payload": {"headers": []}, **kwargs}
    if headers:
        for name, value in headers.items():
            msg["payload"]["headers"].append({"name": name, "value": value})
    return msg


@unittest.skipUnless(PROCESSOR_AVAILABLE, "processor dependencies not available")
class TestExtractMachineIdPrecedence(unittest.TestCase):
    """Test routing precedence: default wins when set; header wins when default empty."""

    def test_default_wins_when_set_even_with_header(self):
        """When DEFAULT_MACHINE_ID is set, it wins; X-MediLink-Clinic is ignored."""
        config = Mock()
        config.default_machine_id = "clinic-default"
        config.state_collection_path = "sync_state"
        fs_client = Mock()
        fs_client.collection.return_value.document.return_value.get.return_value.exists = False

        message = _make_message(headers={"X-MediLink-Clinic": "clinic-from-header"})
        result = _extract_machine_id(message, config, fs_client)
        self.assertEqual(result, "clinic-default")

    def test_default_wins_when_set_no_header(self):
        """When DEFAULT_MACHINE_ID is set and no header, use default."""
        config = Mock()
        config.default_machine_id = "clinic-001"
        config.state_collection_path = "sync_state"
        fs_client = Mock()
        fs_client.collection.return_value.document.return_value.get.return_value.exists = False

        message = _make_message()
        result = _extract_machine_id(message, config, fs_client)
        self.assertEqual(result, "clinic-001")

    def test_header_wins_when_default_empty(self):
        """When DEFAULT_MACHINE_ID is empty, X-MediLink-Clinic wins."""
        config = Mock()
        config.default_machine_id = None
        config.state_collection_path = "sync_state"
        fs_client = Mock()
        fs_client.collection.return_value.document.return_value.get.return_value.exists = False

        message = _make_message(headers={"X-MediLink-Clinic": "clinic-from-header"})
        result = _extract_machine_id(message, config, fs_client)
        self.assertEqual(result, "clinic-from-header")

    def test_header_wins_when_default_empty_string(self):
        """When DEFAULT_MACHINE_ID is empty string, header wins."""
        config = Mock()
        config.default_machine_id = ""
        config.state_collection_path = "sync_state"
        fs_client = Mock()
        fs_client.collection.return_value.document.return_value.get.return_value.exists = False

        message = _make_message(headers={"X-MediLink-Clinic": "clinic-header"})
        result = _extract_machine_id(message, config, fs_client)
        self.assertEqual(result, "clinic-header")

    def test_firestore_routing_when_no_default_no_header(self):
        """When no default and no header, use Firestore routing."""
        config = Mock()
        config.default_machine_id = None
        config.state_collection_path = "sync_state"
        fs_client = Mock()
        routing_doc = Mock()
        routing_doc.exists = True
        routing_doc.to_dict.return_value = {
            "email_to_machine": {"clinic@example.com": "clinic-001"}
        }
        fs_client.collection.return_value.document.return_value.get.return_value = routing_doc

        message = _make_message(headers={"Delivered-To": "clinic@example.com"})
        result = _extract_machine_id(message, config, fs_client)
        self.assertEqual(result, "clinic-001")

    def test_default_stripped_whitespace(self):
        """DEFAULT_MACHINE_ID with leading/trailing whitespace is stripped."""
        config = Mock()
        config.default_machine_id = "  clinic-002  "
        config.state_collection_path = "sync_state"
        fs_client = Mock()
        fs_client.collection.return_value.document.return_value.get.return_value.exists = False

        message = _make_message(headers={"X-MediLink-Clinic": "other"})
        result = _extract_machine_id(message, config, fs_client)
        self.assertEqual(result, "clinic-002")


if __name__ == "__main__":
    unittest.main()
