"""Tests for /setup-gmail-watch endpoint.

Covers auth rejection (403), admin secret not configured (500), and allowed path
when secret is correct. IAM invoker is enforced by Cloud Run when deployed
(--no-allow-unauthenticated); tests verify shared-secret guard.
"""

import unittest
from unittest.mock import Mock, patch
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from fastapi.testclient import TestClient
    from api import APP
    TESTCLIENT_AVAILABLE = True
except ImportError:
    TESTCLIENT_AVAILABLE = False
    TestClient = None


if not TESTCLIENT_AVAILABLE:
    class TestSetupGmailWatchDeps(unittest.TestCase):
        def test_missing_test_deps(self):
            self.skipTest(
                "FastAPI TestClient is not available. Install: py -3.11 -m pip install httpx"
            )
else:
    class TestSetupGmailWatch(unittest.TestCase):
        """Test /setup-gmail-watch endpoint."""

        @patch('api.register_gmail_watch')
        @patch('api.get_config')
        def test_valid_request_with_secret_succeeds(self, mock_config, mock_register):
            """Test valid request with correct secret returns 200 and watch details."""
            config = Mock()
            config.admin_shared_secret = "test_secret_456"
            mock_config.return_value = config
            mock_register.return_value = (
                "watch registered (historyId=123, expiration=456)",
                "123",
                {"historyId": "123", "expiration": "456"},
            )

            client = TestClient(APP)
            response = client.post(
                "/setup-gmail-watch",
                json={"secret": "test_secret_456"},
            )

            self.assertEqual(response.status_code, 200)
            data = response.json()
            self.assertEqual(data["status"], "success")
            self.assertIn("watch_details", data)
            mock_register.assert_called_once()

        @patch('api.get_config')
        def test_missing_secret_returns_403(self, mock_config):
            """Test missing secret returns 403 Forbidden."""
            config = Mock()
            config.admin_shared_secret = "test_secret_456"
            mock_config.return_value = config

            client = TestClient(APP)
            response = client.post(
                "/setup-gmail-watch",
                json={},
            )

            self.assertEqual(response.status_code, 403)

        @patch('api.get_config')
        def test_wrong_secret_returns_403(self, mock_config):
            """Test wrong secret returns 403 Forbidden."""
            config = Mock()
            config.admin_shared_secret = "test_secret_456"
            mock_config.return_value = config

            client = TestClient(APP)
            response = client.post(
                "/setup-gmail-watch",
                json={"secret": "wrong_secret"},
            )

            self.assertEqual(response.status_code, 403)

        @patch('api.get_config')
        def test_secret_not_configured_returns_500(self, mock_config):
            """Test ADMIN_SHARED_SECRET not set returns 500."""
            config = Mock()
            config.admin_shared_secret = None
            mock_config.return_value = config

            client = TestClient(APP)
            response = client.post(
                "/setup-gmail-watch",
                json={"secret": "any_secret"},
            )

            self.assertEqual(response.status_code, 500)

        @patch('api.register_gmail_watch')
        @patch('api.get_config')
        def test_register_gmail_watch_exception_returns_500(self, mock_config, mock_register):
            """Test exception in register_gmail_watch returns 500 with generic body (no internals leaked)."""
            config = Mock()
            config.admin_shared_secret = "test_secret_456"
            mock_config.return_value = config
            mock_register.side_effect = RuntimeError("Gmail API failed")

            client = TestClient(APP)
            response = client.post(
                "/setup-gmail-watch",
                json={"secret": "test_secret_456"},
            )

            self.assertEqual(response.status_code, 500)
            data = response.json()
            self.assertEqual(data["detail"], "Internal Server Error")


if __name__ == '__main__':
    unittest.main()
