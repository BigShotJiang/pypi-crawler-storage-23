#!/usr/bin/env python
"""
Prototype ingest for unified model. XP-compatible: Python 3.4.4, no pathlib, no f-strings.
"""
from __future__ import print_function

import argparse
import hashlib
import json
import os
import re
import sqlite3
from datetime import datetime

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
SQL_PATH = os.path.join(ROOT, "sql", "unified_relational_model_v1.sql")

QA_VERSION = "v1"
EXTRACTOR_VERSION = "v1"
PROJECTION_VERSION = "v1"


def compute_ingest_key(rec):
    raw = "|".join([
        rec.get("source_system", ""),
        rec.get("source_type", ""),
        rec.get("source_ref", ""),
        rec.get("message_id", ""),
        rec.get("attachment_sha256", ""),
    ])
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def exec_sql(conn, path):
    with open(path, "r", encoding="utf-8") as f:
        conn.executescript(f.read())


def upsert_ref(conn, table, key_col, key_val, payload_cols):
    """Upsert using INSERT-then-UPDATE for SQLite < 3.24 (XP bundle)."""
    items = list(payload_cols.items())
    cols = [key_col] + [c for c, _ in items]
    vals = [key_val] + [v for _, v in items]
    placeholders = ",".join(["?"] * len(cols))
    try:
        conn.execute(
            "INSERT INTO {0} ({1}) VALUES ({2})".format(table, ",".join(cols), placeholders),
            vals,
        )
    except sqlite3.IntegrityError:
        set_parts = []
        update_vals = []
        for c, v in items:
            set_parts.append("{0}=?".format(c))
            update_vals.append(v)
        update_vals.append(key_val)
        conn.execute(
            "UPDATE {0} SET {1} WHERE {2}=?".format(table, ", ".join(set_parts), key_col),
            update_vals,
        )
    return conn.execute(
        "SELECT rowid FROM {0} WHERE {1}=?".format(table, key_col),
        (key_val,),
    ).fetchone()[0]


def qa_check(rec):
    patient_external_id = str(rec.get("patient_external_id", "")).strip()
    if not patient_external_id:
        return False, "missing_patient_external_id", "patient_external_id is required"
    if not re.match(r"^[0-9]{5}$", patient_external_id):
        return False, "invalid_patient_external_id_format", "patient_external_id must match ^[0-9]{5}$"
    if not str(rec.get("date_of_service", "")).strip():
        return False, "missing_date_of_service", "date_of_service is required"
    if rec.get("source_type") == "csv_row" and not str(rec.get("payer_id", "")).strip():
        return False, "missing_payer_id", "payer_id is required for csv_row"
    return True, None, None


CLAIM_BEARING_SOURCE_TYPES = ("csv_row", "jsonl_record")


def canonicalize_and_project(conn, artifact_id, rec):
    pkey = "medisoft:{0}".format(rec.get("patient_external_id", ""))
    payer_key = "payer:{0}".format(rec.get("payer_id") or rec.get("payer_name") or "unknown")
    plan_key = "plan:{0}".format(payer_key)
    cov_key = "coverage:{0}:{1}".format(pkey, plan_key)
    encounter_key = "encounter:{0}:{1}".format(pkey, rec.get("date_of_service", ""))
    claim_key = rec.get("claim_number") or "claim:{0}:{1}".format(encounter_key, payer_key)

    patient_id = upsert_ref(conn, "patient", "patient_key", pkey, {
        "external_patient_id": rec.get("patient_external_id"),
        "full_name": rec.get("patient_name"),
        "source_system": rec.get("source_system", "legacy"),
    })

    payer_id = upsert_ref(conn, "payer", "payer_key", payer_key, {
        "payer_external_id": rec.get("payer_id"),
        "payer_name": rec.get("payer_name"),
        "endpoint_name": rec.get("endpoint"),
    })

    plan_id = upsert_ref(conn, "insurance_plan", "plan_key", plan_key, {
        "payer_id": payer_id,
        "medisoft_insurance_ids_json": json.dumps([rec.get("payer_id")] if rec.get("payer_id") else []),
    })

    upsert_ref(conn, "coverage", "coverage_key", cov_key, {
        "patient_id": patient_id,
        "plan_id": plan_id,
    })

    encounter_id = upsert_ref(conn, "encounter", "encounter_key", encounter_key, {
        "patient_id": patient_id,
        "date_of_service": rec.get("date_of_service"),
        "source_artifact_id": artifact_id,
        "diagnosis_code": rec.get("diagnosis"),
        "eye_side": rec.get("eye"),
    })

    if rec.get("source_type") in CLAIM_BEARING_SOURCE_TYPES:
        claim_id = upsert_ref(conn, "claim", "claim_key", claim_key, {
            "encounter_id": encounter_id,
            "payer_id": payer_id,
            "claim_number": rec.get("claim_number"),
            "status": rec.get("status"),
            "charged_amount": rec.get("charged"),
            "allowed_amount": rec.get("allowed"),
            "paid_amount": rec.get("paid"),
            "patient_resp_amount": rec.get("patient_resp"),
            "source_artifact_id": artifact_id,
        })

        for line in rec.get("claim_lines", []):
            lkey = "{0}:line:{1}".format(claim_key, line.get("line_number", 1))
            upsert_ref(conn, "claim_line", "claim_line_key", lkey, {
                "claim_id": claim_id,
                "line_number": int(line.get("line_number", 1)),
                "cpt_code": line.get("cpt"),
                "diagnosis_pointer": line.get("diagnosis_pointer"),
                "charged_amount": line.get("charged"),
                "paid_amount": line.get("paid"),
            })

        canonical = {
            "patient_key": pkey,
            "encounter_key": encounter_key,
            "claim_key": claim_key,
            "source_type": rec.get("source_type"),
        }
        conn.execute(
            "INSERT OR IGNORE INTO extracted_canonical_record (artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) VALUES (?,?,?,?,?,?)",
            (artifact_id, "claim_fact", claim_key, EXTRACTOR_VERSION, json.dumps(canonical), json.dumps({"source_ref": rec.get("source_ref")})),
        )
        cr = conn.execute(
            "SELECT canonical_record_id FROM extracted_canonical_record WHERE artifact_id=? AND canonical_key=? AND extractor_version=?",
            (artifact_id, claim_key, EXTRACTOR_VERSION),
        ).fetchone()[0]

        projection_payload = {
            "posting_queue_projection": {
                "claim_number": rec.get("claim_number"),
                "patient_external_id": rec.get("patient_external_id"),
                "status": rec.get("status"),
                "paid": rec.get("paid"),
            }
        }
        proj_json = json.dumps(projection_payload)
        try:
            conn.execute(
                "INSERT INTO projection_result (canonical_record_id, projection_type, projection_version, projection_status, projected_json) VALUES (?,?,?,?,?)",
                (cr, "posting_queue", PROJECTION_VERSION, "success", proj_json),
            )
        except sqlite3.IntegrityError:
            conn.execute(
                "UPDATE projection_result SET projection_status=?, projected_json=? WHERE canonical_record_id=? AND projection_type=? AND projection_version=?",
                ("success", proj_json, cr, "posting_queue", PROJECTION_VERSION),
            )
        return True
    return False


def process_file(conn, fixture_path, corrections=None):
    stats = {"ingested": 0, "qa_pass": 0, "qa_reject": 0, "canonicalized": 0}
    with open(fixture_path, "r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            rec = json.loads(line)
            if corrections and rec.get("source_ref") in corrections:
                rec.update(corrections[rec["source_ref"]])
            ingest_key = compute_ingest_key(rec)
            conn.execute(
                "INSERT OR IGNORE INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, attachment_name, attachment_sha256, payload_json, ingest_status) VALUES (?,?,?,?,?,?,?,?,?)",
                (ingest_key, rec.get("source_system"), rec.get("source_type"), rec.get("source_ref"), rec.get("message_id"), rec.get("attachment_name"), rec.get("attachment_sha256"), json.dumps(rec), "ingested"),
            )
            art = conn.execute("SELECT artifact_id FROM ingest_artifact WHERE ingest_key=?", (ingest_key,)).fetchone()[0]
            stats["ingested"] += 1

            ok, code, reason = qa_check(rec)
            deterministic_key = hashlib.sha256("{0}|{1}|{2}".format(art, code or "pass", QA_VERSION).encode("utf-8")).hexdigest()
            conn.execute(
                "INSERT OR REPLACE INTO qa_result (qa_result_id, artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, deterministic_key, created_at) VALUES ((SELECT qa_result_id FROM qa_result WHERE artifact_id=? AND qa_stage='ingest_contract' AND qa_version=?),?,?,?,?,?,?,?,?)",
                (art, QA_VERSION, art, "ingest_contract", QA_VERSION, "pass" if ok else "reject", code, reason, deterministic_key, datetime.utcnow().isoformat()),
            )

            if not ok:
                conn.execute("UPDATE ingest_artifact SET ingest_status='qa_failed', updated_at=datetime('now') WHERE artifact_id=?", (art,))
                conn.execute(
                    "INSERT OR IGNORE INTO replay_queue (artifact_id, reason_code, status) VALUES (?,?, 'pending')",
                    (art, code),
                )
                stats["qa_reject"] += 1
                continue

            conn.execute("UPDATE ingest_artifact SET ingest_status='qa_passed', updated_at=datetime('now') WHERE artifact_id=?", (art,))
            stats["qa_pass"] += 1
            did_claim_canonicalize = canonicalize_and_project(conn, art, rec)
            ingest_status = "projected" if did_claim_canonicalize else "canonicalized"
            conn.execute("UPDATE ingest_artifact SET ingest_status=?, updated_at=datetime('now') WHERE artifact_id=?", (ingest_status, art))
            conn.execute("UPDATE replay_queue SET status='replayed', attempt_count=attempt_count+1, last_attempt_at=datetime('now') WHERE artifact_id=?", (art,))
            if did_claim_canonicalize:
                stats["canonicalized"] += 1
    return stats


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--db", required=True)
    p.add_argument("--fixture", required=True)
    p.add_argument("--replay-corrections")
    args = p.parse_args()

    db_path = os.path.abspath(args.db)
    db_dir = os.path.dirname(db_path)
    if db_dir and not os.path.exists(db_dir):
        os.makedirs(db_dir, exist_ok=True)

    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON")
    exec_sql(conn, SQL_PATH)

    corrections = None
    if args.replay_corrections:
        with open(args.replay_corrections, "r", encoding="utf-8") as f:
            corrections = json.load(f)

    stats = process_file(conn, args.fixture, corrections)
    conn.commit()
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
