#!/usr/bin/env python
"""
Phase F reporting and operational packaging: constants, helpers, report/index builders.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import json
import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)
try:
    from phase_a_common import iso_utc_now
except ImportError:
    import time
    def iso_utc_now():
        return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

PHASE_F_LOCK_FAIL = "PHASE_F_LOCK_FAIL"
PHASE_F_RUN_ID_MISMATCH = "PHASE_F_RUN_ID_MISMATCH"
PHASE_F_SCRIPT_MISSING = "PHASE_F_SCRIPT_MISSING"
PHASE_F_ENTRYPOINT_MISSING = "PHASE_F_ENTRYPOINT_MISSING"
MISSING_MARKER = "__MISSING__"

PHASES = ("B", "C", "D", "E")
PHASE_SUMMARY_PATTERNS = {
    "B": ("artifact_discovery_summary_{0}.json", "manifest_sha256", "config_hash", "crosswalk_hash"),
    "C": ("ingest_write_summary_{0}.json", "rows_inserted", "rows_skipped_duplicate"),
    "D": ("qa_canonical_summary_{0}.json", "qa_pass_count", "qa_reject_count"),
    "E": ("projection_parity_summary_{0}.json", "eligible_count", "projected_success_this_run",
          "projected_reject_this_run", "contract_parity_status", "baseline_parity_status"),
}


def resolve_source_paths(lab_root, phase_run_ids):
    """
    Resolve source summary paths from phase_run_ids.
    phase_run_ids: dict {B: rid_b, C: rid_c, ...} from diagnostics_state.last_shadow_pipeline_phase_run_ids
    Returns dict phase -> path (or MISSING_MARKER).
    """
    reports_dir = os.path.join(lab_root, "reports")
    result = {}
    for phase in PHASES:
        rid = phase_run_ids.get(phase) if phase_run_ids else None
        if not rid or not str(rid).strip():
            result[phase] = MISSING_MARKER
            continue
        pattern = PHASE_SUMMARY_PATTERNS.get(phase)
        if not pattern:
            result[phase] = MISSING_MARKER
            continue
        fname = pattern[0].format(rid)
        path = os.path.join(reports_dir, fname)
        result[phase] = path if os.path.exists(path) else MISSING_MARKER
    return result


def resolve_source_paths_fallback(lab_root, cursor):
    """
    Backward compatibility: when last_shadow_pipeline_phase_run_ids is missing,
    use cursor last_phase_X_run_id for each phase.
    """
    phase_run_ids = {}
    cursor_keys = {"B": "last_phase_b_run_id", "C": "last_phase_c_run_id",
                  "D": "last_phase_d_run_id", "E": "last_phase_e_run_id"}
    for phase in PHASES:
        rid = cursor.get(cursor_keys.get(phase, ""), "") if cursor else ""
        if rid and str(rid).strip():
            phase_run_ids[phase] = rid
    return resolve_source_paths(lab_root, phase_run_ids)


def load_phase_summary(path):
    """Load phase summary JSON. Returns dict or None."""
    if not path or path == MISSING_MARKER or not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def build_report_payload(lab_root, run_id, run_id_source, pipeline_ok, failed_phase, error_code, source_paths, source_data):
    """
    Build shadow_run_report payload per contract.
    source_data: dict phase -> loaded summary dict (or None)
    """
    def _get(phase, *keys):
        data = source_data.get(phase) if source_data else None
        if not data:
            return None
        for k in keys:
            if k in data:
                return data[k]
        return None

    def _int(v):
        if v is None:
            return 0
        try:
            return int(v)
        except (TypeError, ValueError):
            return 0

    def _str(v):
        if v is None:
            return ""
        s = str(v)
        return s if s.strip() else ""

    source_summary_paths = []
    for phase in PHASES:
        p = source_paths.get(phase)
        source_summary_paths.append(p if p and p != MISSING_MARKER else MISSING_MARKER)

    payload = {
        "run_id": run_id or "",
        "run_id_source": run_id_source or "state",
        "generated_at_utc": iso_utc_now(),
        "pipeline_ok": bool(pipeline_ok),
        "failed_phase": _str(failed_phase),
        "error_code": _str(error_code),
        "phase_b_manifest_sha256": _str(_get("B", "manifest_sha256")),
        "phase_b_config_hash": _str(_get("B", "config_hash")),
        "phase_b_crosswalk_hash": _str(_get("B", "crosswalk_hash")),
        "phase_c_inserted_count": _int(_get("C", "rows_inserted")),
        "phase_c_skipped_count": _int(_get("C", "rows_skipped_duplicate")),
        "phase_d_pass_count": _int(_get("D", "qa_pass_count")),
        "phase_d_reject_count": _int(_get("D", "qa_reject_count")),
        "phase_e_eligible_count": _int(_get("E", "eligible_count")),
        "phase_e_projected_success_this_run": _int(_get("E", "projected_success_this_run")),
        "phase_e_projected_reject_this_run": _int(_get("E", "projected_reject_this_run")),
        "phase_e_contract_parity_status": _str(_get("E", "contract_parity_status")),
        "phase_e_baseline_parity_status": _str(_get("E", "baseline_parity_status")),
        "source_summary_paths": source_summary_paths,
    }
    return payload


def build_evidence_index(lab_root, run_id, run_id_source, artifact_files, state_snapshot, dedup_context):
    """Build shadow_evidence_index payload per contract."""
    return {
        "run_id": run_id or "",
        "run_id_source": run_id_source or "state",
        "created_at_utc": iso_utc_now(),
        "artifact_files": artifact_files,
        "state_snapshot": state_snapshot or {},
        "report_dedup_context": dedup_context or {},
    }


def serialize_report_json(obj):
    """Deterministic JSON serialization per plan contract."""
    return json.dumps(obj, separators=(",", ":"), ensure_ascii=True, sort_keys=True)


def atomic_write_json(path, obj):
    """Write JSON via temp file + atomic rename. Deterministic: sort_keys, ensure_ascii."""
    tmp_path = path + ".tmp"
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(obj, f, separators=(",", ":"), ensure_ascii=True, sort_keys=True)
    try:
        if os.path.exists(path):
            os.remove(path)
        os.rename(tmp_path, path)
    except Exception:
        try:
            os.remove(tmp_path)
        except Exception:
            pass
        raise


def atomic_write_text(path, content):
    """Write text via temp file + atomic rename."""
    tmp_path = path + ".tmp"
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(tmp_path, "w", encoding="utf-8") as f:
        f.write(content)
    try:
        if os.path.exists(path):
            os.remove(path)
        os.rename(tmp_path, path)
    except Exception:
        try:
            os.remove(tmp_path)
        except Exception:
            pass
        raise
