#!/usr/bin/env python
from __future__ import print_function

import json
import os
import sys
import tempfile
import time
import unittest

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if THIS_DIR not in sys.path:
    sys.path.insert(0, THIS_DIR)

import audit_migration_health as amh


class TestAuditMigrationHealth(unittest.TestCase):
    def _write_json(self, path, data):
        parent = os.path.dirname(path)
        if not os.path.isdir(parent):
            os.makedirs(parent)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f)

    def test_latest_report_tie_breaker_deterministic(self):
        with tempfile.TemporaryDirectory() as td:
            reports = os.path.join(td, "reports")
            os.makedirs(reports)
            a = os.path.join(reports, "qa_canonical_summary_run-a.json")
            b = os.path.join(reports, "qa_canonical_summary_run-b.json")
            self._write_json(a, {"ok": True})
            self._write_json(b, {"ok": True})
            now = time.time()
            os.utime(a, (now, now))
            os.utime(b, (now, now))
            path, rid = amh.latest_report(reports, "qa_canonical_summary_", (".json",))
            self.assertTrue(path.endswith("run-b.json"))
            self.assertEqual(rid, "run-b")

    def test_collect_xp_pass_basics(self):
        with tempfile.TemporaryDirectory() as td:
            lab = td
            reports = os.path.join(lab, "reports")
            os.makedirs(reports)
            self._write_json(os.path.join(lab, "diagnostics_state.json"), {
                "last_shadow_pipeline_ok": True,
                "last_contract_parity_status": "pass",
                "last_shadow_pipeline_finished_at_utc": "2026-02-18T00:00:00Z",
                "last_shadow_pipeline_phase_run_ids": {"B": "r1", "C": "r1", "D": "r1", "E": "r1"}
            })
            self._write_json(os.path.join(lab, "run_cursor.json"), {
                "last_phase_b_run_id": "r1", "last_phase_c_run_id": "r1", "last_phase_d_run_id": "r1", "last_phase_e_run_id": "r1"
            })
            self._write_json(os.path.join(reports, "qa_canonical_summary_r1.json"), {
                "rows_selected": 100, "qa_reject_count": 1
            })
            self._write_json(os.path.join(reports, "ingest_write_summary_r1.json"), {
                "manifest_rows_read": 100, "anomaly_count": 0
            })
            self._write_json(os.path.join(reports, "projection_parity_summary_r1.json"), {
                "eligible_count": 100, "projected_success_this_run": 100, "projected_reject_this_run": 0
            })
            self._write_json(os.path.join(reports, "shadow_evidence_index_r1.json"), {"artifact_files": []})
            self._write_json(os.path.join(reports, "shadow_run_report_r1.json"), {"pipeline_ok": True})

            xp = amh.collect_xp(lab, amh.THRESHOLD_PROFILES["default"])
            self.assertEqual(xp["status"], amh.PASS)
            self.assertGreaterEqual(xp["score"], 90)

    def test_main_cloud_required_unavailable_exit3(self):
        parser = amh.build_parser()
        args = parser.parse_args(["--scope", "cloud", "--cloud-required", "--no-text", "--no-json"])
        # force missing project id
        old = os.environ.get("GOOGLE_CLOUD_PROJECT")
        if "GOOGLE_CLOUD_PROJECT" in os.environ:
            del os.environ["GOOGLE_CLOUD_PROJECT"]
        try:
            code = amh.run(args)
            self.assertEqual(code, 3)
        finally:
            if old is not None:
                os.environ["GOOGLE_CLOUD_PROJECT"] = old

    def test_parse_ts_utc_not_local_shift(self):
        ts = '2026-02-18T00:00:00Z'
        got = amh.parse_ts(ts)
        import calendar, time
        exp = int(calendar.timegm(time.strptime(ts, '%Y-%m-%dT%H:%M:%SZ')))
        self.assertEqual(got, exp)

    def test_threshold_override_changes_outcome(self):
        parser = amh.build_parser()
        args = parser.parse_args([
            '--scope', 'xp',
            '--no-text', '--no-json',
            '--threshold-override', 'xp.phase_d_reject_ratio.pass_max=0.01',
            '--threshold-override', 'xp.phase_d_reject_ratio.warn_max=0.02',
        ])
        with tempfile.TemporaryDirectory() as td:
            lab = td
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._write_json(os.path.join(lab, 'diagnostics_state.json'), {
                'last_shadow_pipeline_ok': True,
                'last_contract_parity_status': 'pass',
                'last_shadow_pipeline_finished_at_utc': '2026-02-18T00:00:00Z',
                'last_shadow_pipeline_phase_run_ids': {'B': 'r1', 'C': 'r1', 'D': 'r1', 'E': 'r1'}
            })
            self._write_json(os.path.join(lab, 'run_cursor.json'), {
                'last_phase_b_run_id': 'r1', 'last_phase_c_run_id': 'r1', 'last_phase_d_run_id': 'r1', 'last_phase_e_run_id': 'r1'
            })
            self._write_json(os.path.join(reports, 'qa_canonical_summary_r1.json'), {
                'rows_selected': 100, 'qa_reject_count': 3
            })
            self._write_json(os.path.join(reports, 'ingest_write_summary_r1.json'), {
                'manifest_rows_read': 100, 'anomaly_count': 0
            })
            self._write_json(os.path.join(reports, 'projection_parity_summary_r1.json'), {
                'eligible_count': 100, 'projected_success_this_run': 100, 'projected_reject_this_run': 0
            })
            self._write_json(os.path.join(reports, 'shadow_evidence_index_r1.json'), {'artifact_files': []})
            self._write_json(os.path.join(reports, 'shadow_run_report_r1.json'), {'pipeline_ok': True})

            old = os.getcwd()
            os.chdir('/workspace/MediCafe')
            try:
                args.lab_dir = lab
                code = amh.run(args)
            finally:
                os.chdir(old)
            self.assertEqual(code, 1)

    def test_unknown_reject_codes_counted_with_fallback(self):
        known, source = amh._known_reject_codes_and_source()
        self.assertTrue(isinstance(known, set))
        self.assertTrue(len(known) >= 1)
        self.assertIn(source, ('authoritative', 'fallback'))


if __name__ == "__main__":
    unittest.main()
