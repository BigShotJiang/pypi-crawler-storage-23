#!/usr/bin/env python
"""
Phase C ingest: unit tests.
Tests ingest key, artifact class mapping, manifest parsing, idempotency, lock fail.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import json
import os
import sqlite3
import sys
import tempfile
import unittest

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_c_common import (
    PHASE_C_LOCK_FAIL,
    PHASE_C_STATE_WRITE_ERROR,
    PHASE_C_UNKNOWN_ARTIFACT_CLASS,
    artifact_class_to_source_type,
    compute_ingest_key_v1,
)

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock

SQL_PATH = os.path.join(_ROOT, "sql", "unified_relational_model_v1.sql")


def _make_lab_with_db():
    """Create temp lab dir with unified_model_xp.db and schema."""
    lab_root = tempfile.mkdtemp()
    db_path = os.path.join(lab_root, "unified_model_xp.db")
    reports_dir = os.path.join(lab_root, "reports")
    os.makedirs(reports_dir, exist_ok=True)
    if os.path.exists(SQL_PATH):
        with open(SQL_PATH, "r", encoding="utf-8") as f:
            conn = sqlite3.connect(db_path)
            conn.executescript(f.read())
            conn.close()
    return lab_root, db_path, reports_dir


class TestComputeIngestKeyV1(unittest.TestCase):
    """Determinism and field validation for compute_ingest_key_v1."""

    def test_determinism_same_row_same_key(self):
        row = {
            "source_id": "csv_target",
            "artifact_class": "csv",
            "normalized_path": "a/b.csv",
            "mtime_epoch": 1234567890,
            "size_bytes": 100,
            "sha256": "abc123",
            "hash_mode": "full",
        }
        k1 = compute_ingest_key_v1(row)
        k2 = compute_ingest_key_v1(row)
        self.assertEqual(k1, k2)
        self.assertEqual(len(k1), 64)

    def test_missing_required_raises(self):
        row = {"source_id": "x", "artifact_class": "csv"}
        with self.assertRaises(ValueError) as ctx:
            compute_ingest_key_v1(row)
        self.assertIn("Missing required", str(ctx.exception))

    def test_sha256_empty_with_full_raises(self):
        row = {
            "source_id": "x",
            "artifact_class": "csv",
            "normalized_path": "a.csv",
            "mtime_epoch": 0,
            "size_bytes": 0,
            "sha256": "",
            "hash_mode": "full",
        }
        with self.assertRaises(ValueError) as ctx:
            compute_ingest_key_v1(row)
        self.assertIn("sha256", str(ctx.exception))

    def test_sha256_empty_with_skipped_large_ok(self):
        row = {
            "source_id": "x",
            "artifact_class": "csv",
            "normalized_path": "a.csv",
            "mtime_epoch": 0,
            "size_bytes": 0,
            "sha256": "",
            "hash_mode": "skipped_large",
        }
        k = compute_ingest_key_v1(row)
        self.assertEqual(len(k), 64)


class TestArtifactClassMapping(unittest.TestCase):
    """artifact_class_to_source_type map and unknown-class."""

    def test_known_classes_map(self):
        self.assertEqual(artifact_class_to_source_type("csv"), "file_csv")
        self.assertEqual(artifact_class_to_source_type("docx"), "file_docx")
        self.assertEqual(artifact_class_to_source_type("dat"), "file_dat")
        self.assertEqual(artifact_class_to_source_type("jsonl"), "file_jsonl")
        self.assertEqual(artifact_class_to_source_type("837"), "file_837")
        self.assertEqual(artifact_class_to_source_type("receipt"), "file_receipt")
        self.assertEqual(artifact_class_to_source_type("xml"), "file_xml")

    def test_unknown_returns_none(self):
        self.assertIsNone(artifact_class_to_source_type("unknown"))
        self.assertIsNone(artifact_class_to_source_type(""))


class TestManifestRowToIngestRow(unittest.TestCase):
    """manifest_row_to_ingest_row correctness."""

    def test_valid_row_produces_ingest_row(self):
        from ingest_from_manifest import manifest_row_to_ingest_row

        row = {
            "source_id": "csv_target",
            "artifact_class": "csv",
            "normalized_path": "a/b.csv",
            "mtime_epoch": 1234567890,
            "size_bytes": 100,
            "sha256": "abc123",
            "hash_mode": "full",
            "scope": "operational",
        }
        lineage = {"manifest_run_id": "run1", "manifest_sha256": "h1", "config_hash": "", "crosswalk_hash": ""}
        out = manifest_row_to_ingest_row(row, lineage)
        self.assertIsNotNone(out)
        self.assertEqual(out["source_system"], "xp_local")
        self.assertEqual(out["source_type"], "file_csv")
        self.assertIn("csv_target", out["source_ref"])
        self.assertIn("a/b.csv", out["source_ref"])
        self.assertEqual(out["attachment_name"], "b.csv")
        self.assertEqual(out["ingest_status"], "ingested")

    def test_unknown_class_returns_none(self):
        from ingest_from_manifest import manifest_row_to_ingest_row

        row = {
            "source_id": "x",
            "artifact_class": "unknown",
            "normalized_path": "a.csv",
            "mtime_epoch": 0,
            "size_bytes": 0,
            "sha256": "",
            "hash_mode": "skipped_large",
            "scope": "operational",
        }
        lineage = {}
        self.assertIsNone(manifest_row_to_ingest_row(row, lineage))


class TestManifestParsing(unittest.TestCase):
    """Malformed JSON and missing fields yield anomalies, continue."""

    def test_malformed_line_yields_anomaly(self):
        from ingest_from_manifest import read_manifest_rows, validate_manifest_row

        lab_root = tempfile.mkdtemp()
        manifest = os.path.join(lab_root, "manifest.jsonl")
        try:
            with open(manifest, "w", encoding="utf-8") as f:
                f.write('{"valid": true}\n')
                f.write('{invalid json\n')
                f.write('{"artifact_class":"csv"}\n')
            rows = list(read_manifest_rows(manifest))
            self.assertEqual(len(rows), 3)
            self.assertIsNotNone(rows[0][0])
            self.assertIsNone(rows[1][0])
            valid, anomaly = validate_manifest_row(rows[0][0], 1)
            self.assertFalse(valid)
            self.assertIsNotNone(anomaly)
        finally:
            try:
                os.remove(manifest)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestIdempotentDbBehavior(unittest.TestCase):
    """Insert same rows twice; second run yields rows_skipped_duplicate."""

    def test_idempotent_insert(self):
        from ingest_from_manifest import manifest_row_to_ingest_row, write_ingest_rows

        lab_root, db_path, _ = _make_lab_with_db()
        try:
            row = {
                "source_id": "csv_target",
                "artifact_class": "csv",
                "normalized_path": "idem.csv",
                "mtime_epoch": 1234567890,
                "size_bytes": 100,
                "sha256": "abc123",
                "hash_mode": "full",
                "scope": "operational",
            }
            lineage = {}
            ingest_row = manifest_row_to_ingest_row(row, lineage)
            self.assertIsNotNone(ingest_row)
            conn = sqlite3.connect(db_path)
            try:
                ins1, skip1, fail1 = write_ingest_rows(conn, [ingest_row])
                conn.commit()
                self.assertEqual(ins1, 1)
                self.assertEqual(skip1, 0)
                ins2, skip2, fail2 = write_ingest_rows(conn, [ingest_row])
                conn.commit()
                self.assertEqual(ins2, 0)
                self.assertEqual(skip2, 1)
            finally:
                conn.close()
        finally:
            try:
                for f in os.listdir(lab_root):
                    p = os.path.join(lab_root, f)
                    if os.path.isfile(p):
                        os.remove(p)
                    else:
                        for sf in os.listdir(p):
                            os.remove(os.path.join(p, sf))
                        os.rmdir(p)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestLockFail(unittest.TestCase):
    """acquire_lock raises SystemExit => PHASE_C_LOCK_FAIL, exit 1."""

    def test_lock_fail_returns_error_code(self):
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(reports_dir, "artifact_manifest_test.jsonl")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write('{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv","mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n')
        try:
            with patch("ingest_from_manifest.acquire_lock", side_effect=SystemExit(1)):
                ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_LOCK_FAIL)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestStatePersistence(unittest.TestCase):
    """Successful run => run_cursor and diagnostics_state contain Phase C keys."""

    def test_state_persisted(self):
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(reports_dir, "artifact_manifest_test.jsonl")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write('{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv","mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n')
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    ok, rid, summary, _ = run_ingest(lab_root, manifest)
            self.assertTrue(ok)
            self.assertTrue(os.path.exists(cursor_path))
            self.assertTrue(os.path.exists(state_path))
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
            self.assertIn("last_phase_c_run_id", cursor)
            self.assertIn("last_phase_c_ok", cursor)
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
            self.assertIn("last_phase_c_run_id", state)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                os.remove(db_path)
                if os.path.exists(cursor_path):
                    os.remove(cursor_path)
                if os.path.exists(state_path):
                    os.remove(state_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestStateWriteErrorPropagation(unittest.TestCase):
    """persist_phase_c_state failure => PHASE_C_STATE_WRITE_ERROR returned, summary/report consistent."""

    def test_state_write_fail_manifest_missing_returns_state_error(self):
        """When manifest missing and persist fails, return PHASE_C_STATE_WRITE_ERROR."""
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(lab_root, "nonexistent_manifest.jsonl")
        self.assertFalse(os.path.exists(manifest))
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest.persist_phase_c_state", side_effect=IOError("state write failed")):
                        with patch("phase_c_auto_report.submit_phase_c_failure_report", return_value=False):
                            ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_STATE_WRITE_ERROR)
            self.assertIsNotNone(summary)
            self.assertEqual(summary.get("error_code"), PHASE_C_STATE_WRITE_ERROR)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_state_write_fail_db_missing_returns_state_error(self):
        """When db missing and persist fails, return PHASE_C_STATE_WRITE_ERROR."""
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        os.remove(db_path)
        manifest = os.path.join(reports_dir, "artifact_manifest_test.jsonl")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write('{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv","mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n')
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest.persist_phase_c_state", side_effect=IOError("state write failed")):
                        with patch("phase_c_auto_report.submit_phase_c_failure_report", return_value=False):
                            ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_STATE_WRITE_ERROR)
            self.assertIsNotNone(summary)
            self.assertEqual(summary.get("error_code"), PHASE_C_STATE_WRITE_ERROR)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_state_write_fail_success_path_returns_state_error(self):
        """When DB write succeeds but persist fails, return PHASE_C_STATE_WRITE_ERROR, report deferred."""
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(reports_dir, "artifact_manifest_test.jsonl")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write('{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv","mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n')
        report_calls = []
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest.persist_phase_c_state", side_effect=IOError("state write failed")):
                        with patch("phase_c_auto_report.submit_phase_c_failure_report") as mock_report:
                            def capture(lab_root, ctx):
                                report_calls.append(ctx)
                            mock_report.side_effect = capture
                            ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_STATE_WRITE_ERROR)
            self.assertIsNotNone(summary)
            self.assertEqual(summary.get("error_code"), PHASE_C_STATE_WRITE_ERROR)
            self.assertEqual(len(report_calls), 1)
            self.assertEqual(report_calls[0].get("error_code"), PHASE_C_STATE_WRITE_ERROR)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestMissingPhaseBSummary(unittest.TestCase):
    """Missing summary file => warning logged, lineage empty, ingest proceeds."""

    def test_missing_summary_continues(self):
        from ingest_from_manifest import load_phase_b_summary_lineage

        lab_root = tempfile.mkdtemp()
        try:
            lineage = load_phase_b_summary_lineage(lab_root, "nonexistent_run_id")
            self.assertEqual(lineage.get("manifest_sha256"), "")
            self.assertEqual(lineage.get("config_hash"), "")
            self.assertEqual(lineage.get("counts_by_class"), {})
        finally:
            try:
                os.rmdir(lab_root)
            except Exception:
                pass


if __name__ == "__main__":
    unittest.main()
