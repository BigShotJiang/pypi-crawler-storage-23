#!/usr/bin/env python
"""
Phase B artifact discovery engine. Consumes adapter via iter_candidates; no os.walk in core.
Manifest staged outside lock; lock only for finalize + summary + state.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import argparse
import hashlib
import json
import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_b_common import (
    DISCOVERER_VERSION,
    PHASE_B_LOCK_FAIL,
    PHASE_B_MANIFEST_ROW_CAP_EXCEEDED,
    PHASE_B_MANIFEST_WRITE_FAIL,
    PHASE_B_ROOT_RESOLUTION_FAIL,
    iso_utc_now,
    run_id,
)
from phase_b_root_adapter import iter_candidates, resolve_roots
from lab_lock import acquire_lock, release_lock, replace_safe_write
from lab_path_utils import resolve_lab_root

# Canonical fields for manifest_sha256. Excludes run_id, locator, warnings, scope
# so unchanged filesystems produce identical manifest checksums.
CANONICAL_HASH_FIELDS = (
    "artifact_class",
    "normalized_path",
    "size_bytes",
    "mtime_epoch",
    "sha256",
    "hash_mode",
    "source_id",
    "discoverer_version",
)

ROW_CAP = int(os.environ.get("MEDICAFE_PHASE_B_ROW_CAP", "100000"))


def _workspace_root():
    """Workspace root from script location."""
    return os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))


def _resolve_lab_root(args):
    """Lab root: --lab-dir > MEDICAFE_LAB_DIR > workspace/lab."""
    return resolve_lab_root(args.lab_dir, _workspace_root())


def _candidate_to_row(candidate):
    """Build manifest row dict from CandidateArtifact."""
    return {
        "artifact_class": candidate.artifact_class,
        "normalized_path": candidate.normalized_path,
        "size_bytes": candidate.size_bytes,
        "mtime_epoch": candidate.mtime_epoch,
        "mtime_utc": _epoch_to_utc(candidate.mtime_epoch),
        "sha256": candidate.sha256,
        "hash_mode": candidate.hash_mode,
        "source_id": candidate.source_id,
        "scope": candidate.scope,
        "discoverer_version": DISCOVERER_VERSION,
        "warnings": getattr(candidate, "warnings", []) or [],
        "locator": candidate.locator or "",
    }


def _epoch_to_utc(epoch):
    """Format epoch as ISO 8601 UTC."""
    import time
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(epoch))


def _collect_rows(lab_root):
    """
    Layer A: consume adapter, dedupe on canonical_key, emit rows.
    Returns (rows, roots_scanned, errors, config_hash, crosswalk_hash).
    """
    result = resolve_roots(lab_root)
    config_hash = ""
    crosswalk_hash = ""
    if isinstance(result, tuple):
        roots = result[0] if len(result) > 0 else []
        config_hash = result[1] if len(result) > 1 else ""
        crosswalk_hash = result[2] if len(result) > 2 else ""
    else:
        roots = result
    if roots is None:
        roots = []
    if not roots:
        return [], [], [{"code": PHASE_B_ROOT_RESOLUTION_FAIL, "message": "No roots resolvable"}], config_hash, crosswalk_hash
    seen = set()
    rows = []
    roots_scanned = []
    errors = []
    for root_spec in roots:
        exists = os.path.isdir(root_spec.root_path)
        roots_scanned.append({
            "source_id": root_spec.source_id,
            "root_path": root_spec.root_path,
            "exists": exists,
        })
        if not exists:
            continue
        for candidate in iter_candidates(root_spec):
            if candidate.canonical_key in seen:
                continue
            seen.add(candidate.canonical_key)
            row = _candidate_to_row(candidate)
            rows.append(row)
    existing_count = sum(1 for r in roots_scanned if r.get("exists"))
    if existing_count == 0:
        return [], roots_scanned, [{"code": PHASE_B_ROOT_RESOLUTION_FAIL, "message": "No roots resolvable"}], config_hash, crosswalk_hash
    return rows, roots_scanned, errors, config_hash, crosswalk_hash


def _row_sort_key(row):
    """Sort key for manifest rows."""
    return (row.get("artifact_class", ""), row.get("normalized_path", ""))


def _update_hash_from_row(h, row):
    """Update hash with canonical fields of row."""
    canon = {k: row.get(k) for k in CANONICAL_HASH_FIELDS if k in row}
    canon_str = json.dumps(canon, sort_keys=True, separators=(",", ":"))
    h.update(canon_str.encode("utf-8"))


def _write_manifest_and_hash(rows, manifest_tmp_path):
    """Sort rows in memory, write JSONL to temp, return manifest_sha256."""
    sorted_rows = sorted(rows, key=_row_sort_key)
    dir_path = os.path.dirname(manifest_tmp_path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    h = hashlib.sha256()
    with open(manifest_tmp_path, "w", encoding="utf-8") as f:
        for row in sorted_rows:
            line = json.dumps(row, ensure_ascii=False) + "\n"
            f.write(line)
            _update_hash_from_row(h, row)
    return h.hexdigest()


def _write_summary_json(summary, path):
    """Write summary JSON."""
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)


def _write_summary_txt(summary, path):
    """Write human-readable summary."""
    lines = [
        "Phase B Artifact Discovery Summary",
        "run_id: {0}".format(summary.get("run_id", "")),
        "generated_at_utc: {0}".format(summary.get("generated_at_utc", "")),
        "ok: {0}".format(summary.get("ok", False)),
        "total_rows: {0}".format(summary.get("total_rows", 0)),
        "manifest_sha256: {0}".format(summary.get("manifest_sha256", "")),
        "config_hash: {0}".format(summary.get("config_hash", "")),
        "crosswalk_hash: {0}".format(summary.get("crosswalk_hash", "")),
        "",
        "Roots scanned:",
    ]
    for r in summary.get("roots_scanned", []):
        lines.append("  - {0}: {1} (exists={2})".format(
            r.get("source_id", ""), r.get("root_path", ""), r.get("exists", False)
        ))
    lines.append("")
    lines.append("Counts by class:")
    for k, v in sorted(summary.get("counts_by_class", {}).items()):
        lines.append("  {0}: {1}".format(k, v))
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def _persist_phase_b_state(lab_root, rid, ok, error_code, manifest_path, manifest_sha256,
                           counts_by_class):
    """Update run_cursor.json and diagnostics_state.json with Phase B outcome."""
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    now = iso_utc_now()
    cursor = {}
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
        except Exception:
            pass
    cursor["last_phase_b_run_id"] = rid
    cursor["last_manifest_path"] = manifest_path
    cursor["last_manifest_sha256"] = manifest_sha256
    cursor["last_discovery_ok"] = ok
    cursor["last_discovery_counts_by_class"] = counts_by_class or {}
    cursor["last_discovery_error_code"] = error_code
    cursor["last_discovery_at_utc"] = now
    replace_safe_write(cursor_path, cursor)
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["last_phase_b_run_id"] = rid
    state["last_manifest_path"] = manifest_path
    state["last_manifest_sha256"] = manifest_sha256
    state["last_discovery_ok"] = ok
    state["last_discovery_error_code"] = error_code
    state["last_discovery_counts_by_class"] = counts_by_class or {}
    state["last_discovery_at_utc"] = now
    replace_safe_write(state_path, state)


def run_discovery(lab_root):
    """
    Main discovery flow. Returns (ok, run_id, manifest_path, summary, error_code).
    """
    rid = run_id()
    reports_dir = os.path.join(lab_root, "reports")
    manifest_tmp = os.path.join(reports_dir, "artifact_manifest_{0}.jsonl.tmp".format(rid))
    manifest_final = os.path.join(reports_dir, "artifact_manifest_{0}.jsonl".format(rid))
    summary_json = os.path.join(reports_dir, "artifact_discovery_summary_{0}.json".format(rid))
    summary_txt = os.path.join(reports_dir, "artifact_discovery_summary_{0}.txt".format(rid))

    rows, roots_scanned, errors, config_hash, crosswalk_hash = _collect_rows(lab_root)
    if errors and any(e.get("code") == PHASE_B_ROOT_RESOLUTION_FAIL for e in errors):
        summary_fail = {
            "run_id": rid,
            "generated_at_utc": iso_utc_now(),
            "ok": False,
            "total_rows": 0,
            "manifest_sha256": None,
            "roots_scanned": roots_scanned,
            "counts_by_class": {},
            "errors": errors,
            "config_hash": config_hash,
            "crosswalk_hash": crosswalk_hash,
        }
        try:
            acquire_lock(lab_root)
            try:
                summary_json_path = os.path.join(
                    lab_root, "reports",
                    "artifact_discovery_summary_{0}.json".format(rid),
                )
                summary_txt_path = os.path.join(
                    lab_root, "reports",
                    "artifact_discovery_summary_{0}.txt".format(rid),
                )
                reports_dir = os.path.dirname(summary_json_path)
                if reports_dir and not os.path.exists(reports_dir):
                    os.makedirs(reports_dir, exist_ok=True)
                _write_summary_json(summary_fail, summary_json_path)
                _write_summary_txt(summary_fail, summary_txt_path)
                _persist_phase_b_state(
                    lab_root, rid, False, PHASE_B_ROOT_RESOLUTION_FAIL,
                    None, None, {},
                )
            finally:
                release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_b_auto_report import submit_phase_b_failure_report
                submit_phase_b_failure_report(lab_root, {
                    "error_code": PHASE_B_ROOT_RESOLUTION_FAIL,
                    "run_id": rid,
                    "first_failed": "no_roots",
                    "lab_root": lab_root,
                    "report_json_path": summary_json_path,
                    "report_txt_path": summary_txt_path,
                    "summary": summary_fail,
                })
            except Exception:
                pass
        except SystemExit:
            pass
        return False, rid, None, summary_fail, PHASE_B_ROOT_RESOLUTION_FAIL

    counts_by_class = {}
    for r in rows:
        c = r.get("artifact_class", "unknown")
        counts_by_class[c] = counts_by_class.get(c, 0) + 1

    if len(rows) > ROW_CAP:
        msg = "Row count {0} exceeds cap {1}".format(len(rows), ROW_CAP)
        summary_fail = {
            "run_id": rid,
            "generated_at_utc": iso_utc_now(),
            "ok": False,
            "total_rows": len(rows),
            "manifest_sha256": None,
            "roots_scanned": roots_scanned,
            "counts_by_class": counts_by_class,
            "errors": [{"code": PHASE_B_MANIFEST_ROW_CAP_EXCEEDED, "message": msg}],
            "config_hash": config_hash,
            "crosswalk_hash": crosswalk_hash,
        }
        try:
            acquire_lock(lab_root)
            try:
                reports_dir = os.path.join(lab_root, "reports")
                if reports_dir and not os.path.exists(reports_dir):
                    os.makedirs(reports_dir, exist_ok=True)
                _write_summary_json(summary_fail, summary_json)
                _write_summary_txt(summary_fail, summary_txt)
                _persist_phase_b_state(
                    lab_root, rid, False, PHASE_B_MANIFEST_ROW_CAP_EXCEEDED,
                    None, None, counts_by_class,
                )
            finally:
                release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_b_auto_report import submit_phase_b_failure_report
                submit_phase_b_failure_report(lab_root, {
                    "error_code": PHASE_B_MANIFEST_ROW_CAP_EXCEEDED,
                    "run_id": rid,
                    "first_failed": "row_cap",
                    "lab_root": lab_root,
                    "report_json_path": summary_json,
                    "report_txt_path": summary_txt,
                    "summary": summary_fail,
                })
            except Exception:
                pass
        except SystemExit:
            pass
        return False, rid, None, summary_fail, PHASE_B_MANIFEST_ROW_CAP_EXCEEDED

    try:
        manifest_sha256 = _write_manifest_and_hash(rows, manifest_tmp)
    except (IOError, OSError) as e:
        summary_fail = {
            "run_id": rid,
            "generated_at_utc": iso_utc_now(),
            "ok": False,
            "total_rows": len(rows),
            "manifest_sha256": None,
            "roots_scanned": roots_scanned,
            "counts_by_class": counts_by_class,
            "errors": [{"code": PHASE_B_MANIFEST_WRITE_FAIL, "message": str(e)}],
            "config_hash": config_hash,
            "crosswalk_hash": crosswalk_hash,
        }
        try:
            acquire_lock(lab_root)
            try:
                reports_dir = os.path.join(lab_root, "reports")
                if not os.path.exists(reports_dir):
                    os.makedirs(reports_dir, exist_ok=True)
                _write_summary_json(summary_fail, summary_json)
                _write_summary_txt(summary_fail, summary_txt)
                _persist_phase_b_state(
                    lab_root, rid, False, PHASE_B_MANIFEST_WRITE_FAIL,
                    None, None, counts_by_class,
                )
            finally:
                release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_b_auto_report import submit_phase_b_failure_report
                submit_phase_b_failure_report(lab_root, {
                    "error_code": PHASE_B_MANIFEST_WRITE_FAIL,
                    "run_id": rid,
                    "first_failed": "manifest_write",
                    "lab_root": lab_root,
                    "report_json_path": summary_json,
                    "report_txt_path": summary_txt,
                    "summary": summary_fail,
                })
            except Exception:
                pass
        except SystemExit:
            pass
        return False, rid, None, summary_fail, PHASE_B_MANIFEST_WRITE_FAIL
    summary = {
        "run_id": rid,
        "generated_at_utc": iso_utc_now(),
        "ok": True,
        "total_rows": len(rows),
        "manifest_sha256": manifest_sha256,
        "roots_scanned": roots_scanned,
        "counts_by_class": counts_by_class,
        "errors": errors,
        "config_hash": config_hash,
        "crosswalk_hash": crosswalk_hash,
    }

    try:
        acquire_lock(lab_root)
    except SystemExit:
        return False, rid, None, summary, PHASE_B_LOCK_FAIL

    try:
        if os.path.exists(manifest_tmp):
            if os.path.exists(manifest_final):
                try:
                    os.remove(manifest_final)
                except Exception:
                    pass
            os.rename(manifest_tmp, manifest_final)
        _write_summary_json(summary, summary_json)
        _write_summary_txt(summary, summary_txt)
        _persist_phase_b_state(
            lab_root, rid, True, None,
            manifest_final, manifest_sha256, counts_by_class,
        )
        return True, rid, manifest_final, summary, None
    finally:
        release_lock(lab_root, owner_pid=os.getpid())


def main():
    parser = argparse.ArgumentParser(description="Phase B artifact discovery")
    parser.add_argument("--lab-dir", help="Override lab root (default: MEDICAFE_LAB_DIR or workspace/lab)")
    args = parser.parse_args()
    lab_root = _resolve_lab_root(args)
    if not os.path.exists(lab_root):
        os.makedirs(lab_root, exist_ok=True)
    ok, rid, manifest_path, summary, error_code = run_discovery(lab_root)
    if not ok:
        print("Phase B discovery failed: {0}".format(error_code), file=sys.stderr)
        sys.exit(1)
    print("Phase B discovery ok: {0} rows, manifest={1}".format(
        summary.get("total_rows", 0), manifest_path or ""))


if __name__ == "__main__":
    main()
