#!/usr/bin/env python
"""
Phase B artifact discovery: constants, error codes, schema, and data types.
Single source of truth for discover_artifacts.py. XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import collections
import os
import sys

# DRY: Import from phase_a_common
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)
try:
    from phase_a_common import iso_utc_now as _iso_utc_now, run_id as _run_id
    iso_utc_now = _iso_utc_now
    run_id = _run_id
except ImportError:
    import time
    import hashlib
    import uuid
    def iso_utc_now():
        return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    def run_id():
        ts = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
        try:
            hex_part = uuid.uuid4().hex[:8]
        except Exception:
            hex_part = hashlib.sha256(str(time.time()).encode()).hexdigest()[:8]
        return "{0}-{1}".format(ts, hex_part)

DISCOVERER_VERSION = "phase_b_v1"

# Subset of bootstrap_lab ARTIFACT_CLASSES; optional xml via MEDICAFE_PHASE_B_INCLUDE_XML
ARTIFACT_CLASSES = ["csv", "docx", "dat", "jsonl", "837", "receipt", "xml"]

# Error codes for Phase B failure reporting
PHASE_B_ROOT_RESOLUTION_FAIL = "PHASE_B_ROOT_RESOLUTION_FAIL"
PHASE_B_DISCOVERY_IO_ERROR = "PHASE_B_DISCOVERY_IO_ERROR"
PHASE_B_MANIFEST_WRITE_FAIL = "PHASE_B_MANIFEST_WRITE_FAIL"
PHASE_B_MANIFEST_ROW_CAP_EXCEEDED = "PHASE_B_MANIFEST_ROW_CAP_EXCEEDED"
PHASE_B_HASH_POLICY_ERROR = "PHASE_B_HASH_POLICY_ERROR"
PHASE_B_LOCK_FAIL = "PHASE_B_LOCK_FAIL"
PHASE_B_PARTIAL_CLASS_FAILURE = "PHASE_B_PARTIAL_CLASS_FAILURE"

# Manifest row field names (tuple for validation)
MANIFEST_ROW_FIELDS = (
    "artifact_class",
    "normalized_path",
    "size_bytes",
    "mtime_epoch",
    "mtime_utc",
    "sha256",
    "hash_mode",
    "source_id",
    "scope",
    "discoverer_version",
    "warnings",
    "locator",
)

# Hash mode constants
HASH_MODE_FULL = "full"
HASH_MODE_SAMPLED = "sampled"
HASH_MODE_SKIPPED_LARGE = "skipped_large"
HASH_MODE_ERROR = "error"

# ResolvedRootSpec: source_id, root_path, artifact_classes, scope
ResolvedRootSpec = collections.namedtuple(
    "ResolvedRootSpec",
    ["source_id", "root_path", "artifact_classes", "scope"],
)

# CandidateArtifact: adapter-provided; Layer A consumes only
# source_id, canonical_key, normalized_path, size_bytes, mtime_epoch, sha256, hash_mode,
# artifact_class, scope, warnings, locator
CandidateArtifact = collections.namedtuple(
    "CandidateArtifact",
    [
        "source_id",
        "canonical_key",
        "normalized_path",
        "size_bytes",
        "mtime_epoch",
        "sha256",
        "hash_mode",
        "artifact_class",
        "scope",
        "warnings",
        "locator",
    ],
)
