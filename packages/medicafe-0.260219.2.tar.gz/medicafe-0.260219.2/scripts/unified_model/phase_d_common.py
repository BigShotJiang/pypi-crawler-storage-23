#!/usr/bin/env python
"""
Phase D QA and canonicalization: policy versions, error codes, reason registry,
canonical key strategy. XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import hashlib
import json
import os
import sys

# DRY: Import from phase_a_common
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)
try:
    from phase_a_common import iso_utc_now as _iso_utc_now, run_id as _run_id
    iso_utc_now = _iso_utc_now
    run_id = _run_id
except ImportError:
    import time
    import hashlib
    import uuid
    def iso_utc_now():
        return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    def run_id():
        ts = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
        try:
            hex_part = uuid.uuid4().hex[:8]
        except Exception:
            hex_part = hashlib.sha256(str(time.time()).encode()).hexdigest()[:8]
        return "{0}-{1}".format(ts, hex_part)

# Policy versions (frozen)
QA_POLICY_VERSION = "qa_v1"
CANONICALIZATION_VERSION = "canon_v1"

# Phase D run-level error codes
PHASE_D_QA_POLICY_MISSING = "PHASE_D_QA_POLICY_MISSING"
PHASE_D_REPLAY_QUEUE_ERROR = "PHASE_D_REPLAY_QUEUE_ERROR"
PHASE_D_DB_WRITE_ERROR = "PHASE_D_DB_WRITE_ERROR"
PHASE_D_STATE_WRITE_ERROR = "PHASE_D_STATE_WRITE_ERROR"
PHASE_D_LOCK_FAIL = "PHASE_D_LOCK_FAIL"

# Row-level reject reason codes (QA)
QA_IDENTITY_INCOMPLETE = "QA_IDENTITY_INCOMPLETE"
QA_REQUIRED_DATE_INVALID = "QA_REQUIRED_DATE_INVALID"
QA_ARTIFACT_CLASS_REQUIRED_FIELDS = "QA_ARTIFACT_CLASS_REQUIRED_FIELDS"
QA_CANONICALIZATION_PRECONDITION = "QA_CANONICALIZATION_PRECONDITION"
QA_FILE_READ_ERROR = "QA_FILE_READ_ERROR"
QA_PARSE_ERROR = "QA_PARSE_ERROR"
QA_PARSE_IMPORT_ERROR = "QA_PARSE_IMPORT_ERROR"
QA_PARSE_RUNTIME_ERROR = "QA_PARSE_RUNTIME_ERROR"
QA_UNKNOWN_ARTIFACT_CLASS = "QA_UNKNOWN_ARTIFACT_CLASS"

# Sentinel values for null/empty in canonical key serialization
SENTINEL_NULL = "__null__"
SENTINEL_EMPTY = "__empty__"

# QA stage for Phase D
QA_STAGE_PHASE_D = "phase_d"


def _canonicalize_value(v):
    """Convert value for canonical key: None -> SENTINEL_NULL, '' -> SENTINEL_EMPTY."""
    if v is None:
        return SENTINEL_NULL
    if isinstance(v, str) and not v.strip():
        return SENTINEL_EMPTY
    return v


def compute_canonical_key(list_values):
    """
    Compute deterministic canonical key from list of values.
    Rule: canonical_key_material = json.dumps(list_values, separators=(",", ":"), ensure_ascii=True)
    Null/empty encoded with fixed sentinels. Hash input is that serialized string only.
    """
    canonicalized = [_canonicalize_value(v) for v in list_values]
    material = json.dumps(canonicalized, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def compute_patient_key(source_system, external_patient_id, birth_date):
    """Deterministic patient canonical key."""
    return compute_canonical_key([
        source_system or "",
        external_patient_id or "",
        birth_date or "",
    ])


def compute_payer_key(payer_external_id, endpoint_name):
    """Deterministic payer canonical key."""
    return compute_canonical_key([
        payer_external_id or "",
        endpoint_name or "",
    ])


def compute_insurance_plan_key(payer_key, medisoft_insurance_ids_json):
    """Deterministic insurance_plan canonical key."""
    return compute_canonical_key([
        payer_key or "",
        str(medisoft_insurance_ids_json) if medisoft_insurance_ids_json is not None else "",
    ])


def compute_coverage_key(patient_key, plan_key, effective_start):
    """Deterministic coverage canonical key."""
    return compute_canonical_key([
        patient_key or "",
        plan_key or "",
        effective_start or "",
    ])


def compute_encounter_key(patient_key, date_of_service, source_artifact_id):
    """Deterministic encounter canonical key."""
    return compute_canonical_key([
        patient_key or "",
        date_of_service or "",
        str(source_artifact_id) if source_artifact_id is not None else "",
    ])


def compute_claim_key(encounter_key, payer_key, claim_number):
    """Deterministic claim canonical key."""
    return compute_canonical_key([
        encounter_key or "",
        payer_key or "",
        claim_number or "",
    ])


def compute_claim_line_key(claim_key, line_number):
    """Deterministic claim_line canonical key."""
    return compute_canonical_key([
        claim_key or "",
        str(line_number) if line_number is not None else "",
    ])


def compute_qa_deterministic_key(artifact_id, qa_stage, qa_version, status, reject_code=None):
    """Deterministic key for qa_result row (for idempotency)."""
    return compute_canonical_key([
        str(artifact_id),
        qa_stage or "",
        qa_version or "",
        status or "",
        reject_code or "",
    ])
