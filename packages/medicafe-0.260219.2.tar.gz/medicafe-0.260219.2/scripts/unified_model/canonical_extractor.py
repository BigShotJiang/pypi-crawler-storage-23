#!/usr/bin/env python
"""
Phase D canonical extraction: build extracted_canonical_record and domain upsert payloads
from QA-pass rows. Deterministic keys. XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import json
import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_d_common import (
    CANONICALIZATION_VERSION,
    compute_canonical_key,
    compute_patient_key,
)


def _provenance_base(artifact_id, artifact_class, source_system, source_ref):
    """Build base provenance dict."""
    return {
        "artifact_id": artifact_id,
        "artifact_class": artifact_class,
        "source_system": source_system or "",
        "source_ref": source_ref or "",
        "extractor_version": CANONICALIZATION_VERSION,
    }


def extract_canonical_records(artifact_id, artifact_class, envelope, source_system, source_ref):
    """
    Extract canonical records from QA-pass envelope.
    Returns list of dicts: {canonical_type, canonical_key, canonical_json, provenance_json}.
    """
    records = []
    prov_base = _provenance_base(artifact_id, artifact_class, source_system, source_ref)

    if artifact_class == "csv" and envelope:
        rows = envelope.get("rows") or []
        for i, row in enumerate(rows):
            if not isinstance(row, dict):
                continue
            patient_id = row.get("Patient ID") or row.get("patient_id") or ""
            birth_date = row.get("Birth Date") or row.get("birth_date") or row.get("DOB") or ""
            patient_key = compute_patient_key(source_system or "xp_local", patient_id, birth_date)
            canonical_json = json.dumps(row, separators=(",", ":"), ensure_ascii=True)
            prov = dict(prov_base, row_index=i)
            records.append({
                "canonical_type": "patient_csv_row",
                "canonical_key": patient_key,
                "canonical_json": canonical_json,
                "provenance_json": json.dumps(prov, separators=(",", ":"), ensure_ascii=True),
            })

    elif artifact_class == "jsonl" and envelope:
        rows = envelope.get("rows") or []
        for i, row in enumerate(rows):
            if not isinstance(row, dict):
                continue
            claim_num = row.get("claim_number") or row.get("Claim #") or ""
            payer_id = row.get("payer_id") or row.get("Payer ID") or ""
            claim_key = compute_canonical_key([claim_num, payer_id, str(i)])
            canonical_json = json.dumps(row, separators=(",", ":"), ensure_ascii=True)
            prov = dict(prov_base, row_index=i)
            records.append({
                "canonical_type": "remittance_row",
                "canonical_key": claim_key,
                "canonical_json": canonical_json,
                "provenance_json": json.dumps(prov, separators=(",", ":"), ensure_ascii=True),
            })

    elif artifact_class == "837" and envelope:
        member_id = envelope.get("member_id") or ""
        member_dob = envelope.get("member_dob") or ""
        payer_id = envelope.get("payer_id") or ""
        patient_key = compute_patient_key(source_system or "xp_local", member_id, member_dob)
        canonical_json = json.dumps(envelope, separators=(",", ":"), ensure_ascii=True)
        records.append({
            "canonical_type": "x12_member",
            "canonical_key": patient_key,
            "canonical_json": canonical_json,
            "provenance_json": json.dumps(prov_base, separators=(",", ":"), ensure_ascii=True),
        })

    elif artifact_class == "dat" and envelope:
        recs = envelope.get("records") or []
        for i, rec in enumerate(recs):
            if not isinstance(rec, dict):
                continue
            pat_id = rec.get("PATID") or rec.get("patient_id") or ""
            patient_key = compute_patient_key(source_system or "xp_local", pat_id, "")
            canonical_json = json.dumps(rec, separators=(",", ":"), ensure_ascii=True)
            prov = dict(prov_base, record_index=i)
            records.append({
                "canonical_type": "dat_record",
                "canonical_key": patient_key,
                "canonical_json": canonical_json,
                "provenance_json": json.dumps(prov, separators=(",", ":"), ensure_ascii=True),
            })

    elif artifact_class == "docx" and envelope:
        schedules = envelope.get("schedules") or {}
        patient_data = envelope.get("patient_data") or {}
        if schedules:
            for date_str, patients_dict in schedules.items():
                if not isinstance(patients_dict, dict):
                    continue
                for patient_id, details in patients_dict.items():
                    canonical_json = json.dumps(
                        details if isinstance(details, dict) else {"data": details},
                        separators=(",", ":"), ensure_ascii=True
                    )
                    patient_key = compute_patient_key(source_system or "xp_local", str(patient_id), "")
                    prov = dict(prov_base, schedule_key=date_str, patient_id=str(patient_id))
                    records.append({
                        "canonical_type": "docx_schedule",
                        "canonical_key": compute_canonical_key([patient_key, date_str or ""]),
                        "canonical_json": canonical_json,
                        "provenance_json": json.dumps(prov, separators=(",", ":"), ensure_ascii=True),
                    })
        elif patient_data:
            for patient_id, dates_dict in patient_data.items():
                if not isinstance(dates_dict, dict):
                    continue
                for date_str, details in dates_dict.items():
                    canonical_json = json.dumps(
                        details if isinstance(details, dict) else {"data": details},
                        separators=(",", ":"), ensure_ascii=True
                    )
                    patient_key = compute_patient_key(source_system or "xp_local", str(patient_id), "")
                    prov = dict(prov_base, schedule_key=date_str, patient_id=str(patient_id))
                    records.append({
                        "canonical_type": "docx_schedule",
                        "canonical_key": compute_canonical_key([patient_key, date_str or ""]),
                        "canonical_json": canonical_json,
                        "provenance_json": json.dumps(prov, separators=(",", ":"), ensure_ascii=True),
                    })

    if not records:
        prov_base["note"] = "minimal_artifact_summary"
        records.append({
            "canonical_type": "artifact_summary",
            "canonical_key": compute_patient_key(source_system or "xp_local", str(artifact_id), ""),
            "canonical_json": json.dumps({"artifact_class": artifact_class}, separators=(",", ":"), ensure_ascii=True),
            "provenance_json": json.dumps(prov_base, separators=(",", ":"), ensure_ascii=True),
        })

    return records


def build_domain_upserts(canonical_records, artifact_id, source_system):
    """
    Build domain upsert payloads from canonical records.
    Returns dict: {patient: [...], payer: [...], ...}.
    Minimal v1: extract patient/payer where possible from canonical_json.
    """
    upserts = {
        "patient": [],
        "payer": [],
        "insurance_plan": [],
        "coverage": [],
        "encounter": [],
        "claim": [],
        "claim_line": [],
    }
    seen_patients = set()
    for rec in canonical_records or []:
        ctype = rec.get("canonical_type") or ""
        cjson = rec.get("canonical_json") or "{}"
        try:
            data = json.loads(cjson)
        except (ValueError, TypeError):
            continue
        if ctype == "patient_csv_row" and isinstance(data, dict):
            patient_id = data.get("Patient ID") or data.get("patient_id") or ""
            birth_date = data.get("Birth Date") or data.get("birth_date") or ""
            full_name = data.get("Patient Name") or data.get("patient_name") or ""
            pk = compute_patient_key(source_system or "xp_local", patient_id, birth_date)
            if pk and pk not in seen_patients:
                seen_patients.add(pk)
                upserts["patient"].append({
                    "patient_key": pk,
                    "external_patient_id": patient_id,
                    "full_name": full_name,
                    "birth_date": birth_date,
                    "source_system": source_system or "xp_local",
                })
        elif ctype == "x12_member" and isinstance(data, dict):
            member_id = data.get("member_id") or ""
            dob = data.get("member_dob") or ""
            first_name = data.get("member_first_name") or ""
            last_name = data.get("member_last_name") or ""
            full_name = (first_name + " " + last_name).strip() or None
            pk = compute_patient_key(source_system or "xp_local", member_id, dob)
            if pk and pk not in seen_patients:
                seen_patients.add(pk)
                upserts["patient"].append({
                    "patient_key": pk,
                    "external_patient_id": member_id,
                    "full_name": full_name,
                    "birth_date": dob,
                    "source_system": source_system or "xp_local",
                })
    return upserts
