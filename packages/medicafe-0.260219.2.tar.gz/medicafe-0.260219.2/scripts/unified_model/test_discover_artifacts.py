#!/usr/bin/env python
"""
Phase B discovery repairs: unit tests.
Tests dedupe, no-existing-root failure, hash warning propagation, row-cap guard.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import os
import shutil
import sys
import tempfile
import unittest

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_b_common import (
    CandidateArtifact,
    PHASE_B_MANIFEST_ROW_CAP_EXCEEDED,
    PHASE_B_ROOT_RESOLUTION_FAIL,
    ResolvedRootSpec,
)

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock


class TestDedupeCollisions(unittest.TestCase):
    """Two roots pointing at same directory; assert each file appears once."""

    def test_dedupe_same_file_from_two_roots(self):
        from discover_artifacts import _collect_rows

        lab_root = tempfile.mkdtemp()
        try:
            # Same physical path, two roots (e.g. docx and jsonl both pointing at same dir)
            same_path = os.path.normcase(os.path.abspath(os.path.join(lab_root, "file.csv")))
            roots = [
                ResolvedRootSpec("csv_target", lab_root, ["csv"], "operational"),
                ResolvedRootSpec("jsonl", lab_root, ["csv"], "operational"),
            ]
            candidate = CandidateArtifact(
                source_id="csv_target",
                canonical_key=same_path,
                normalized_path="file.csv",
                size_bytes=0,
                mtime_epoch=0,
                sha256="",
                hash_mode="full",
                artifact_class="csv",
                scope="operational",
                warnings=[],
                locator=same_path,
            )

            def fake_resolve_roots(lr):
                return roots, "config_hash", "crosswalk_hash"

            def fake_iter_candidates(root_spec):
                # Both roots yield the same file (same canonical_key)
                yield candidate

            with patch("discover_artifacts.resolve_roots", side_effect=fake_resolve_roots):
                with patch("discover_artifacts.iter_candidates", side_effect=fake_iter_candidates):
                    rows, roots_scanned, errors, config_hash, crosswalk_hash = _collect_rows(lab_root)

            # Same file from two roots should dedupe to one row
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["normalized_path"], "file.csv")
        finally:
            try:
                os.rmdir(lab_root)
            except Exception:
                pass


class TestNoExistingRootFailure(unittest.TestCase):
    """No-existing-root failure: all roots have exists=false; assert PHASE_B_ROOT_RESOLUTION_FAIL."""

    def test_no_existing_root_returns_fail(self):
        from discover_artifacts import _collect_rows

        lab_root = tempfile.mkdtemp()
        try:
            # Roots with non-existent paths
            roots = [
                ResolvedRootSpec("/nonexistent/a", "/nonexistent/a", ["csv"], "operational"),
                ResolvedRootSpec("/nonexistent/b", "/nonexistent/b", ["docx"], "operational"),
            ]

            def fake_resolve_roots(lr):
                return roots, "ch1", "cw1"

            with patch("discover_artifacts.resolve_roots", side_effect=fake_resolve_roots):
                rows, roots_scanned, errors, config_hash, crosswalk_hash = _collect_rows(lab_root)

            self.assertEqual(len(rows), 0)
            self.assertTrue(
                any(e.get("code") == PHASE_B_ROOT_RESOLUTION_FAIL for e in errors),
                "Expected PHASE_B_ROOT_RESOLUTION_FAIL in errors: {0}".format(errors),
            )
            self.assertEqual(len(roots_scanned), 2)
            self.assertFalse(roots_scanned[0].get("exists"))
            self.assertFalse(roots_scanned[1].get("exists"))
        finally:
            try:
                os.rmdir(lab_root)
            except Exception:
                pass


class TestHashWarningPropagation(unittest.TestCase):
    """Hash warning propagation: candidate with warnings yields row with warnings populated."""

    def test_warnings_in_row(self):
        from discover_artifacts import _candidate_to_row

        candidate = CandidateArtifact(
            source_id="csv_target",
            canonical_key="/path/file.csv",
            normalized_path="file.csv",
            size_bytes=0,
            mtime_epoch=0,
            sha256="",
            hash_mode="error",
            artifact_class="csv",
            scope="operational",
            warnings=["read failed"],
            locator="/path/file.csv",
        )
        row = _candidate_to_row(candidate)
        self.assertEqual(row.get("warnings"), ["read failed"])
        self.assertEqual(row.get("hash_mode"), "error")


class TestRowCapGuard(unittest.TestCase):
    """Row-cap guard: when len(rows) > ROW_CAP, assert PHASE_B_MANIFEST_ROW_CAP_EXCEEDED."""

    def test_row_cap_exceeded_returns_fail(self):
        from discover_artifacts import run_discovery

        lab_root = tempfile.mkdtemp()
        reports_dir = os.path.join(lab_root, "reports")
        os.makedirs(reports_dir, exist_ok=True)
        try:
            roots = [ResolvedRootSpec("csv", lab_root, ["csv"], "operational")]

            def fake_resolve_roots(lr):
                return roots, "ch", "cw"

            def fake_iter_candidates(root_spec):
                # Yield 10 rows; ROW_CAP patched to 5
                for i in range(10):
                    yield CandidateArtifact(
                        source_id="csv",
                        canonical_key=os.path.normcase(os.path.abspath(os.path.join(lab_root, "f{0}.csv".format(i)))),
                        normalized_path="f{0}.csv".format(i),
                        size_bytes=0,
                        mtime_epoch=0,
                        sha256="",
                        hash_mode="full",
                        artifact_class="csv",
                        scope="operational",
                        warnings=[],
                        locator="",
                    )

            with patch("discover_artifacts.resolve_roots", side_effect=fake_resolve_roots):
                with patch("discover_artifacts.iter_candidates", side_effect=fake_iter_candidates):
                    with patch("discover_artifacts.ROW_CAP", 5):
                        with patch("discover_artifacts.acquire_lock"):
                            with patch("discover_artifacts.release_lock"):
                                with patch(
                                    "phase_b_auto_report.submit_phase_b_failure_report",
                                    MagicMock(),
                                ):
                                    ok, rid, manifest_path, summary, error_code = run_discovery(lab_root)

            self.assertFalse(ok, "Discovery should fail when row cap exceeded")
            self.assertEqual(error_code, PHASE_B_MANIFEST_ROW_CAP_EXCEEDED)
            self.assertEqual(summary.get("total_rows"), 10)
            self.assertTrue(
                any(e.get("code") == PHASE_B_MANIFEST_ROW_CAP_EXCEEDED for e in summary.get("errors", [])),
            )
        finally:
            try:
                for f in os.listdir(reports_dir):
                    try:
                        os.remove(os.path.join(reports_dir, f))
                    except Exception:
                        pass
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestAdapterTypeFiltering(unittest.TestCase):
    """Adapter should exclude out-of-scope files (e.g., .log) from discovery."""

    def test_log_file_not_discovered_as_837_or_receipt(self):
        from phase_b_root_adapter import iter_candidates

        root_dir = tempfile.mkdtemp()
        try:
            log_path = os.path.join(root_dir, "Log_02142026.log")
            x12_path = os.path.join(root_dir, "claim_837_batch.txt")
            receipt_path = os.path.join(root_dir, "submission_index_20260214.jsonl")
            with open(log_path, "w", encoding="utf-8") as f:
                f.write("legacy app log\n")
            with open(x12_path, "w", encoding="utf-8") as f:
                f.write("ISA*00*...*837*...\n")
            with open(receipt_path, "w", encoding="utf-8") as f:
                f.write("{\"receipt\":true}\n")

            spec = ResolvedRootSpec("837_0", root_dir, ["837", "receipt"], "operational")
            rows = list(iter_candidates(spec))
            discovered = set(r.normalized_path for r in rows)
            classes = set(r.artifact_class for r in rows)

            self.assertIn("claim_837_batch.txt", discovered)
            self.assertIn("submission_index_20260214.jsonl", discovered)
            self.assertNotIn("Log_02142026.log", discovered)
            self.assertIn("837", classes)
            self.assertIn("receipt", classes)
        finally:
            shutil.rmtree(root_dir, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
