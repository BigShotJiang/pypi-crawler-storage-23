#!/usr/bin/env python
"""Shared lab-root path normalization for XP-friendly unified_model scripts."""
from __future__ import print_function

import os
import re


def _tail_parts_cross_platform(path_value):
    """Return (tail, parent_tail) while treating '\\' and '/' as separators."""
    normalized = str(path_value or '').replace('\\', '/')
    parts = [p for p in normalized.split('/') if p]
    tail = parts[-1].lower() if parts else ''
    parent_tail = parts[-2].lower() if len(parts) >= 2 else ''
    return tail, parent_tail


def normalize_medicafe_lab_dir(raw_value):
    """Normalize MEDICAFE_LAB_DIR-like value with legacy drift auto-heals."""
    env_lab = str(raw_value or '').strip()
    if not env_lab:
        return ''

    if len(env_lab) >= 2 and env_lab[0] == env_lab[-1] and env_lab[0] in ('"', "'"):
        env_lab = env_lab[1:-1]
    env_lab = os.path.expandvars(os.path.expanduser(env_lab))

    malformed_prefix = re.match(r'^([A-Za-z]:)\s+([A-Za-z]:[\\/].+)$', env_lab)
    if malformed_prefix:
        env_lab = malformed_prefix.group(2)

    env_lab_norm = os.path.normpath(env_lab)
    env_lab_tail, env_lab_parent_tail = _tail_parts_cross_platform(env_lab_norm)
    if env_lab_tail in ('site-packages', 'medicafe') and (
            env_lab_tail == 'site-packages' or env_lab_parent_tail == 'site-packages'):
        env_lab_norm = os.path.join(env_lab_norm, 'lab')

    return env_lab_norm


def resolve_lab_root(args_lab_dir, workspace_root):
    """Lab root precedence: --lab-dir > MEDICAFE_LAB_DIR > workspace_root/lab."""
    if args_lab_dir:
        return os.path.abspath(args_lab_dir)
    env_lab = normalize_medicafe_lab_dir(os.environ.get('MEDICAFE_LAB_DIR', ''))
    if env_lab:
        if re.match(r'^[A-Za-z]:[\\/]', env_lab):
            return os.path.normpath(env_lab)
        return os.path.abspath(env_lab)
    return os.path.join(workspace_root, 'lab')
