#!/usr/bin/env python
"""
Phase F: Package shadow pipeline run outputs into operational reports and evidence index.
Reads A-E artifacts; writes shadow_run_report_*.json/.txt and shadow_evidence_index_*.json.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import argparse
import json
import os
import sys
import time

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, _WORKSPACE_ROOT)
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_a_common import iso_utc_now
from lab_path_utils import resolve_lab_root
from failure_contract import build_failure_context
from phase_f_common import (
    MISSING_MARKER,
    PHASE_F_LOCK_FAIL,
    PHASE_F_RUN_ID_MISMATCH,
    atomic_write_json,
    atomic_write_text,
    build_evidence_index,
    build_report_payload,
    load_phase_summary,
    resolve_source_paths,
    resolve_source_paths_fallback,
    serialize_report_json,
)

_TRUE_ENV_VALUES = ("1", "true", "yes", "on", "y")
DIAGNOSTICS_STATE_MISSING = "DIAGNOSTICS_STATE_MISSING"


def _env_flag(name, default=False):
    raw = os.environ.get(name)
    if raw is None:
        return default
    return str(raw).strip().lower() in _TRUE_ENV_VALUES


def _report_txt_lines(payload):
    """Human-readable report lines."""
    return [
        "Shadow Run Report (Phase F)",
        "run_id: {0}".format(payload.get("run_id", "")),
        "run_id_source: {0}".format(payload.get("run_id_source", "")),
        "generated_at_utc: {0}".format(payload.get("generated_at_utc", "")),
        "pipeline_ok: {0}".format(payload.get("pipeline_ok", False)),
        "failed_phase: {0}".format(payload.get("failed_phase", "")),
        "error_code: {0}".format(payload.get("error_code", "")),
        "phase_b_manifest_sha256: {0}".format(payload.get("phase_b_manifest_sha256", "")),
        "phase_c_inserted_count: {0}".format(payload.get("phase_c_inserted_count", 0)),
        "phase_c_skipped_count: {0}".format(payload.get("phase_c_skipped_count", 0)),
        "phase_d_pass_count: {0}".format(payload.get("phase_d_pass_count", 0)),
        "phase_d_reject_count: {0}".format(payload.get("phase_d_reject_count", 0)),
        "phase_e_eligible_count: {0}".format(payload.get("phase_e_eligible_count", 0)),
        "phase_e_projected_success_this_run: {0}".format(payload.get("phase_e_projected_success_this_run", 0)),
        "phase_e_projected_reject_this_run: {0}".format(payload.get("phase_e_projected_reject_this_run", 0)),
        "phase_e_contract_parity_status: {0}".format(payload.get("phase_e_contract_parity_status", "")),
        "phase_e_baseline_parity_status: {0}".format(payload.get("phase_e_baseline_parity_status", "")),
    ]


def _resolve_lab_root(args):
    return resolve_lab_root(args.lab_dir, _WORKSPACE_ROOT)


def _load_state(lab_root):
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    if not os.path.exists(state_path):
        return {}, False
    try:
        with open(state_path, "r", encoding="utf-8") as f:
            return json.load(f), True
    except Exception:
        return {}, True


def _load_cursor(lab_root):
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    if not os.path.exists(cursor_path):
        return {}
    try:
        with open(cursor_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _lock_snapshot(lab_root):
    """Best-effort lock context snapshot for diagnostics artifacts."""
    lock_path = os.path.join(lab_root, "shadow.lock")
    snap = {
        "lock_path": lock_path,
        "lock_exists": os.path.exists(lock_path),
        "lock_pid": "",
        "lock_heartbeat_at_utc": "",
        "lock_owner_running": False,
        "lock_heartbeat_stale": True,
    }
    if not snap["lock_exists"]:
        return snap
    try:
        with open(lock_path, "r", encoding="utf-8") as f:
            for raw in f:
                line = raw.strip()
                if line.startswith("pid="):
                    snap["lock_pid"] = line[4:].strip()
                elif line.startswith("heartbeat_at_utc="):
                    snap["lock_heartbeat_at_utc"] = line[17:].strip()
    except Exception:
        return snap
    try:
        import lab_lock
        if snap["lock_pid"]:
            snap["lock_owner_running"] = bool(lab_lock._pid_running(snap["lock_pid"]))
        snap["lock_heartbeat_stale"] = bool(lab_lock._heartbeat_stale(snap["lock_heartbeat_at_utc"]))
    except Exception:
        pass
    return snap


def _write_phase_f_lock_diag(lab_root, run_id, reason, exception_text=""):
    """Write deterministic lock-failure artifact for PHASE_F_LOCK_FAIL triage."""
    reports_dir = os.path.join(lab_root, "reports")
    if reports_dir and not os.path.exists(reports_dir):
        os.makedirs(reports_dir, exist_ok=True)
    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    rid = (run_id or "unknown").strip() or "unknown"
    path = os.path.join(reports_dir, "phase_f_lock_diag_{0}_{1}.json".format(rid, stamp))
    payload = {
        "phase": "F",
        "reason": reason,
        "run_id": rid,
        "generated_at_utc": iso_utc_now(),
        "exception": exception_text or "",
    }
    payload.update(_lock_snapshot(lab_root))
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True)
    return path


def _lock_fail_detail(lab_root, diag_path, reason):
    """Standard detail payload for PHASE_F_LOCK_FAIL classification upstream."""
    snap = _lock_snapshot(lab_root)
    failure = build_failure_context(
        "F", PHASE_F_LOCK_FAIL, "Phase F lock acquisition failed ({0})".format(reason), "SystemExit"
    )
    return {
        "lock_diag_path": diag_path,
        "reason": reason,
        "lock_outcome": "hard_lock_fail",
        "lock_owner_running": bool(snap.get("lock_owner_running")),
        "lock_heartbeat_stale": bool(snap.get("lock_heartbeat_stale", True)),
        "lock_pid": snap.get("lock_pid", "") or "",
        "error_detail": failure.get("error_detail", ""),
        "recoverability": failure.get("recoverability", ""),
        "source_exception_class": failure.get("source_exception_class", ""),
    }


def run_phase_f_report_send(lab_root, report_json_path, report_txt_path, index_path, meta):
    """
    Submit Phase F report and update state if sent.
    meta: run_id, pipeline_ok, failed_phase, error_code, contract_parity_status
    Returns True if report sent, False otherwise.
    """
    try:
        from lab_lock import acquire_lock, release_lock, replace_safe_write
    except ImportError:
        return False
    try:
        from phase_e_auto_report import submit_phase_f_report
    except ImportError:
        return False
    try:
        sent = submit_phase_f_report(lab_root, report_json_path, report_txt_path, index_path, meta)
        if sent:
            try:
                acquire_lock(lab_root)
                try:
                    state2, _ = _load_state(lab_root)
                    state2["phase_f_report_sent"] = True
                    state2["phase_f_report_sent_for_run_id"] = meta.get("run_id", "")
                    replace_safe_write(os.path.join(lab_root, "diagnostics_state.json"), state2)
                finally:
                    release_lock(lab_root, owner_pid=os.getpid())
            except SystemExit:
                pass
        return sent
    except Exception:
        return False


def run_package(lab_root, pipeline_run_id=None, run_id_source="state", auto_report=False):
    """
    Package shadow run report and evidence index.
    pipeline_run_id: from --pipeline-run-id (cli) or state (manual)
    auto_report: if True, may trigger report send on failure
    Returns (ok, report_json_path, report_txt_path, index_path, error_code, policy_trigger, detail_payload).
    """
    state, state_exists = _load_state(lab_root)
    cursor = _load_cursor(lab_root)

    if not state_exists:
        return False, None, None, None, DIAGNOSTICS_STATE_MISSING, False, {}

    run_id = pipeline_run_id or state.get("last_shadow_pipeline_run_id", "")
    if not run_id or not str(run_id).strip():
        return False, None, None, None, "PHASE_F_NO_RUN_ID", False, {}

    if run_id_source == "cli" and state.get("last_shadow_pipeline_run_id") != run_id:
        reports_dir = os.path.join(lab_root, "reports")
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir, exist_ok=True)
        artifact_path = os.path.join(reports_dir, "phase_f_mismatch_{0}.txt".format(run_id))
        try:
            with open(artifact_path, "w", encoding="utf-8") as f:
                f.write("PHASE_F_RUN_ID_MISMATCH: State does not match requested run_id; cannot package.\n")
                f.write("requested_run_id: {0}\n".format(run_id))
                f.write("state_last_run_id: {0}\n".format(state.get("last_shadow_pipeline_run_id", "")))
        except Exception:
            pass
        return False, None, None, None, PHASE_F_RUN_ID_MISMATCH, False, {"mismatch_artifact": artifact_path}

    phase_run_ids = state.get("last_shadow_pipeline_phase_run_ids")
    if not phase_run_ids:
        source_paths = resolve_source_paths_fallback(lab_root, cursor)
    else:
        source_paths = resolve_source_paths(lab_root, phase_run_ids)

    source_data = {}
    for phase, path in source_paths.items():
        if path and path != MISSING_MARKER:
            source_data[phase] = load_phase_summary(path)

    pipeline_ok = state.get("last_shadow_pipeline_ok")
    failed_phase = state.get("last_shadow_pipeline_failed_phase", "")
    error_code = state.get("last_shadow_pipeline_error_code", "")
    contract_parity = ""
    if source_data.get("E"):
        contract_parity = source_data["E"].get("contract_parity_status", "") or ""

    payload = build_report_payload(
        lab_root, run_id, run_id_source, pipeline_ok is True, failed_phase, error_code,
        source_paths, source_data
    )

    artifact_files = []
    for phase in ("B", "C", "D", "E"):
        p = source_paths.get(phase)
        role = "phase_{0}_summary".format(phase.lower())
        if p and p != MISSING_MARKER:
            artifact_files.append({"path": p, "role": role, "exists": os.path.exists(p)})
        else:
            artifact_files.append({"path": p or MISSING_MARKER, "role": role, "exists": False})

    state_snapshot = {
        "last_shadow_pipeline_run_id": state.get("last_shadow_pipeline_run_id", ""),
        "last_shadow_pipeline_ok": state.get("last_shadow_pipeline_ok"),
        "last_shadow_pipeline_failed_phase": state.get("last_shadow_pipeline_failed_phase", ""),
        "last_contract_parity_status": state.get("last_contract_parity_status", ""),
    }
    dedup_context = {}
    if state.get("last_report_dedup_key"):
        dedup_context["last_report_dedup_key"] = state["last_report_dedup_key"]
    if state.get("last_report_sent_at_utc"):
        dedup_context["last_report_sent_at_utc"] = state["last_report_sent_at_utc"]

    index_payload = build_evidence_index(
        lab_root, run_id, run_id_source, artifact_files, state_snapshot, dedup_context
    )

    reports_dir = os.path.join(lab_root, "reports")
    report_json_path = os.path.join(reports_dir, "shadow_run_report_{0}.json".format(run_id))
    report_txt_path = os.path.join(reports_dir, "shadow_run_report_{0}.txt".format(run_id))
    index_path = os.path.join(reports_dir, "shadow_evidence_index_{0}.json".format(run_id))

    try:
        from lab_lock import acquire_lock, release_lock, replace_safe_write
    except ImportError:
        print("lab_lock required.", file=sys.stderr)
        diag_path = _write_phase_f_lock_diag(lab_root, run_id, "import_error", "lab_lock import failed")
        return False, None, None, None, PHASE_F_LOCK_FAIL, False, _lock_fail_detail(lab_root, diag_path, "import_error")

    try:
        acquire_lock(lab_root)
    except SystemExit:
        diag_path = _write_phase_f_lock_diag(lab_root, run_id, "acquire_system_exit", "acquire_lock raised SystemExit")
        return False, None, None, None, PHASE_F_LOCK_FAIL, False, _lock_fail_detail(lab_root, diag_path, "acquire_system_exit")
    except Exception as e:
        diag_path = _write_phase_f_lock_diag(lab_root, run_id, "acquire_exception", str(e))
        detail = _lock_fail_detail(lab_root, diag_path, "acquire_exception")
        detail["source_exception_class"] = e.__class__.__name__
        detail["error_detail"] = str(e)
        return False, None, None, None, PHASE_F_LOCK_FAIL, False, detail

    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir, exist_ok=True)

        report_json_obj = json.loads(serialize_report_json(payload))
        atomic_write_json(report_json_path, report_json_obj)
        atomic_write_text(report_txt_path, "\n".join(_report_txt_lines(payload)) + "\n")
        atomic_write_json(index_path, index_payload)

        state["last_phase_f_run_id"] = run_id
        state["last_phase_f_at_utc"] = iso_utc_now()
        state["last_phase_f_lock_diag_path"] = ""
        replace_safe_write(os.path.join(lab_root, "diagnostics_state.json"), state)
    finally:
        release_lock(lab_root, owner_pid=os.getpid())

    # Default behavior: send health telemetry for unattended runs, not just failures.
    send_health = _env_flag("MEDICAFE_SHADOW_SEND_HEALTH", True)
    policy_trigger = (
        (state.get("last_shadow_pipeline_ok") is False)
        or (contract_parity == "fail")
        or send_health
    )
    if auto_report and policy_trigger:
        run_phase_f_report_send(lab_root, report_json_path, report_txt_path, index_path, {
            "run_id": run_id,
            "pipeline_ok": pipeline_ok,
            "failed_phase": failed_phase,
            "error_code": error_code,
            "contract_parity_status": contract_parity,
        })

    return True, report_json_path, report_txt_path, index_path, None, policy_trigger, {}


def main():
    parser = argparse.ArgumentParser(description="Phase F: Package shadow run report and evidence index")
    parser.add_argument("--lab-dir", help="Override lab root")
    parser.add_argument("--pipeline-run-id", help="Pipeline run id to package (authoritative when provided)")
    parser.add_argument("--auto-report", choices=("0", "1"), default="0",
                        help="1=allow auto-report on failure, 0=never (default for manual)")
    args = parser.parse_args()
    lab_root = _resolve_lab_root(args)
    if not os.path.exists(lab_root):
        os.makedirs(lab_root, exist_ok=True)

    run_id_source = "cli" if args.pipeline_run_id else "state"
    auto_report = args.auto_report == "1"
    ok, report_json, report_txt, index_path, err, _, detail = run_package(
        lab_root, pipeline_run_id=args.pipeline_run_id, run_id_source=run_id_source,
        auto_report=auto_report
    )
    if not ok:
        if detail and detail.get("lock_diag_path"):
            print("Phase F lock diagnostics: {0}".format(detail.get("lock_diag_path")), file=sys.stderr)
        print("Phase F failed: {0}".format(err or "unknown"), file=sys.stderr)
        sys.exit(1)
    print("Phase F ok: {0} -> {1}".format(
        os.path.basename(report_json) if report_json else "report",
        report_json or ""
    ))


if __name__ == "__main__":
    main()
