Baseline GCP Integration
========================

Overview
--------
- Purpose: restore the legacy MediLink dual-flow (OTP + non-OTP) between the Apps Script web app (`webapp.html` + `main.js`) and the Windows XP local helper (`MediLink_Gmail.py`).
- Priority: keep this scope isolated from ongoing redesign work; all artifacts for the baseline rebuild live in this folder.

Dual Flow Summary
-----------------
- OTP/manual flow: `initializeEmailListFlow()` pulls subjects via GAS and lets the user open the Office 365 protected message manually.
- Non-OTP/headless flow: `initializeDocxEmailListFlow()` pushes the local skip list, asks GAS to process DOCX/CSV attachments, and hands the download links back to the local HTTPS server for automated downloads + cleanup.
- Both flows depend on the same OAuth client and consent screen; scopes include Drive, Apps Script, Gmail read/write, and now `gmail.send`.

Root Cause Recap
----------------
- Adding `https://www.googleapis.com/auth/gmail.send` promotes the project into the restricted-scope tier.
- The legacy Apps Script default Cloud project cannot serve restricted scopes; the GAS deployment and the local desktop OAuth client drifted onto different Cloud projects.
- Result: 401/403 responses from Execution API and web-app POSTs, even though gas-side code still works.

Plan of Record
--------------
1. Stand up a dedicated Google Cloud project for the baseline integration using `setup_gcp.sh`.
2. Link the Apps Script deployment to that project and re-deploy it with the new OAuth consent screen.
3. Generate a desktop OAuth client on the same Cloud project and replace the local `json/credentials.json` used by `MediLink_Gmail.py`.
4. Re-run OAuth consent to cache new tokens, then validate both flows (Execution API + manual OTP) end-to-end.

Artifacts
---------
- `setup_gcp.sh`: end-to-end bootstrapper that authenticates gcloud, enables APIs, creates the OAuth brand (if missing), and provisions both desktop and web OAuth clients. It writes the desktop credentials to `MediLink/json/credentials.json` and stores the web client secret in this folder.
- `post_setup_checklist.md`: manual follow-up items (OAuth consent configuration, Apps Script linkage, regression checks).
- `apps_script_link_and_redeploy.md`: step-by-step guide for linking the GAS project to GCP and redeploying the web app / Execution API.
- `local_token_refresh.md`: instructions for refreshing the XP desktop token and validating both flows locally.

Usage
-----
1. Read `post_setup_checklist.md` to understand prerequisites and manual review gates.
2. Export the required environment variables and run `setup_gcp.sh`:
   - `PROJECT_ID` (e.g., `email-de-carol-421600`)
   - `BILLING_ACCOUNT_ID` (the billing account already attached to the project)
   - `SUPPORT_EMAIL` (must be on the verified domain for the OAuth brand)
   - `SCRIPT_ID` (Apps Script project id from Project Settings -> Script ID)
   - Optional: `PROJECT_NAME`, `GCLOUD_CONFIG`, `OAUTH_APP_NAME`
3. Execute `./setup_gcp.sh` from this directory. The script will open a browser for `gcloud auth login`, enable all required services, create the OAuth brand (if needed), generate both OAuth clients, copy the desktop credentials to `MediLink/json/credentials.json`, and leave the web client secret at `MediLink/gcp_baseline/web_client_secret.json`.
4. Follow `apps_script_link_and_redeploy.md` and `local_token_refresh.md`, then complete the checklist before testing both flows.

Notes
-----
- Keep any additional helper scripts for this baseline effort inside this folder.
- The redesign tasks should stay separate to avoid mixing credential or deployment changes.
