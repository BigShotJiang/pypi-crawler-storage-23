# MediLink_Up.py
"""
Notes:
- Duplicate detection relies on a JSONL index under MediLink_Config['receiptsRoot'].
  If 'receiptsRoot' is missing, duplicate checks are skipped with no errors.
- The claim_key used for deconfliction is practical rather than cryptographic:
  it combines (patient_id if available, else ''), (payer_id or primary_insurance), DOS, and a simple service/procedure indicator.
  Pre-submit duplicate guard and post-submission index write use the same key shape: extract_member_data_from_x12_file
  when available (member_id, payer_id, service_start_date), with parse_837p_file fallback for insurance_name and DOS.
  Upstream detection now also flags duplicates per patient record using procedure code when available.
- We do NOT write to the index until a successful submission occurs.
- All I/O uses ASCII-safe defaults.
"""
from datetime import datetime
import os, re, traceback, time
try:
    from tqdm import tqdm
except ImportError:
    # Fallback for when tqdm is not available
    def tqdm(iterable, **kwargs):
        return iterable
import MediLink_837p_encoder
from MediLink_DataMgmt import operate_winscp

# Use core utilities for standardized imports
from MediCafe.core_utils import get_shared_config_loader, get_api_client
MediLink_ConfigLoader = get_shared_config_loader()
log = MediLink_ConfigLoader.log
load_configuration = MediLink_ConfigLoader.load_configuration

# Import api_core for claim submission
try:
    from MediCafe import api_core
except ImportError:
    api_core = None

# Import submission index helpers (XP-safe JSONL)
try:
    from MediCafe.submission_index import (
        compute_claim_key,
        find_by_claim_key,
        find_by_dos_and_basename,
        append_submission_record
    )
except Exception:
    compute_claim_key = None
    find_by_claim_key = None
    find_by_dos_and_basename = None
    append_submission_record = None

# Import IP validation utilities for OPTUMEDI endpoint checking
try:
    from MediLink_IP_utils import (
        get_private_ip_addresses,
        get_public_ip_address,
        validate_ip_against_allowed
    )
except ImportError:
    # Fallback if IP utils not available
    get_private_ip_addresses = None
    get_public_ip_address = None
    validate_ip_against_allowed = None

# Pre-compile regex patterns for better performance
GS_PATTERN = re.compile(r'GS\*HC\*[^*]*\*[^*]*\*([0-9]{8})\*([0-9]{4})')
SE_PATTERN = re.compile(r'SE\*\d+\*\d{4}~')
NM1_IL_PATTERN = re.compile(r'NM1\*IL\*1\*([^*]+)\*([^*]+)\*([^*]*)')
DTP_472_PATTERN = re.compile(r'DTP\*472\D*8\*([0-9]{8})')
CLM_PATTERN = re.compile(r'CLM\*[^\*]*\*([0-9]+\.?[0-9]*)')
NM1_PR_PATTERN = re.compile(r'NM1\*PR\*2\*([^*]+)\*')

# Internet Connectivity Check
# Use the central function from core_utils for consistency across all modules
def check_internet_connection(max_retries=3, initial_delay=1):
    """
    Checks if there is an active internet connection with automatic retry logic.
    This function delegates to the central implementation in MediCafe.core_utils
    to ensure consistent behavior across all MediBot and MediLink modules.
    
    Args:
        max_retries: Maximum number of retry attempts (default: 3)
        initial_delay: Initial delay in seconds before first retry (default: 1)
    
    Returns: Boolean indicating internet connectivity status.
    
    Raises:
        ImportError: If MediCafe.core_utils cannot be imported (indicates configuration issue)
    """
    try:
        from MediCafe.core_utils import check_internet_connection as central_check
        return central_check(max_retries=max_retries, initial_delay=initial_delay)
    except ImportError as e:
        error_msg = (
            "CRITICAL: Cannot import check_internet_connection from MediCafe.core_utils. "
            "This indicates a configuration or installation issue. "
            "Please ensure MediCafe package is properly installed and core_utils.py is accessible. "
            "Original error: {}".format(e)
        )
        print(error_msg)
        raise ImportError(error_msg) from e

# Fallback allowed IPs for OPTUMEDI if config entry is missing
FALLBACK_OPTUMEDI_IPS = ["99.20.30.89", "99.20.30.90", "99.20.30.91"]

def validate_ip_for_endpoint(endpoint, config):
    """
    Validate that the current machine's IP address matches one of the allowed static IPs
    for OPTUMEDI endpoints. Checks both private and public IP addresses.
    
    Args:
        endpoint: Endpoint name (string)
        config: Configuration dictionary
    
    Returns:
        tuple: (is_valid, current_ips_dict, error_message)
            - is_valid: Boolean indicating if validation passed
            - current_ips_dict: Dictionary with 'private' (list) and 'public' (str or None) keys
            - error_message: Formatted error message if validation failed, None if passed
    
    COMPATIBILITY: Python 3.4.4 and Windows XP compatible
    """
    # Check if this is an OPTUMEDI endpoint (case-insensitive)
    if not endpoint or 'optumedi' not in endpoint.lower():
        # Not an OPTUMEDI endpoint, skip validation
        return (True, None, None)
    
    # Check if IP utilities are available
    if not all([get_private_ip_addresses, get_public_ip_address, validate_ip_against_allowed]):
        log("IP validation utilities not available - skipping IP check for endpoint {}".format(endpoint), level="WARNING")
        return (True, None, None)  # Fail open if utilities unavailable
    
    # Normalize configuration for safe access
    if not isinstance(config, dict):
        try:
            config, _ = load_configuration()
        except Exception:
            config = {}
    
    if isinstance(config, dict):
        cfg_candidate = config.get('MediLink_Config')
        if isinstance(cfg_candidate, dict):
            cfg = cfg_candidate
        else:
            cfg = config
    else:
        cfg = {}
    
    # Extract allowed IPs from config
    allowed_ips = None
    try:
        allowed_static_ips = cfg.get('allowed_static_ips', {})
        if isinstance(allowed_static_ips, dict):
            allowed_ips = allowed_static_ips.get('OPTUMEDI')
            if not isinstance(allowed_ips, list):
                allowed_ips = None
    except Exception:
        allowed_ips = None
    
    # Use fallback if config entry not found
    if not allowed_ips:
        log("WARNING: allowed_static_ips not found in MediLink_Config, using fallback IPs for OPTUMEDI validation", level="WARNING")
        allowed_ips = FALLBACK_OPTUMEDI_IPS
    
    # Get current IP addresses
    current_ips = {
        'private': [],
        'public': None
    }
    
    try:
        # Get private IP addresses
        private_ips = get_private_ip_addresses()
        if private_ips:
            current_ips['private'] = private_ips
    except Exception as e:
        log("Error detecting private IP addresses: {}".format(e), level="WARNING")
    
    try:
        # Get public IP address (may fail if offline or service unavailable)
        public_ip = get_public_ip_address(timeout=5)
        if public_ip:
            current_ips['public'] = public_ip
    except Exception as e:
        log("Error detecting public IP address: {}".format(e), level="DEBUG")
    
    # Validate IPs against allowed list
    matched_ip = None
    
    # Check private IPs first
    for private_ip in current_ips['private']:
        if validate_ip_against_allowed(private_ip, allowed_ips):
            matched_ip = private_ip
            break
    
    # Check public IP if no private match found
    if not matched_ip and current_ips['public']:
        if validate_ip_against_allowed(current_ips['public'], allowed_ips):
            matched_ip = current_ips['public']
    
    # If we matched an IP, validation passed
    if matched_ip:
        log("IP validation passed for endpoint {}: matched IP {}".format(endpoint, matched_ip), level="INFO")
        return (True, current_ips, None)
    
    # Validation failed - construct error message
    private_ips_str = ", ".join(current_ips['private']) if current_ips['private'] else "None detected"
    public_ip_str = current_ips['public'] if current_ips['public'] else "Not detected"
    allowed_ips_str = ", ".join(allowed_ips)
    
    error_message = (
        "Current IP addresses do not match any allowed static IP.\n\n"
        "Current IP addresses:\n"
        "  - Private IP(s): {}\n"
        "  - Public IP: {}\n\n"
        "Allowed static IPs for OPTUMEDI:\n"
        "  - {}\n\n"
        "Please verify that this machine is using one of the allowed static IP addresses."
    ).format(private_ips_str, public_ip_str, allowed_ips_str)
    
    log("IP validation failed for endpoint {}: Current IPs do not match allowed list".format(endpoint), level="ERROR")
    
    return (False, current_ips, error_message)

def submit_claims(detailed_patient_data_grouped_by_endpoint, config, crosswalk):
    """
    Submits claims for each endpoint, either via WinSCP or API, based on configuration settings.

    Deconfliction (XP-safe):
    - If JSONL index helpers are available and receiptsRoot is configured, compute a claim_key per 837p file
      and skip submit if index already contains that key (duplicate protection).
    - After a successful submission, append an index record.
    """
    # Normalize configuration for safe nested access
    if not isinstance(config, dict):
        try:
            config, _ = load_configuration()
        except Exception:
            config = {}
    if isinstance(config, dict):
        cfg_candidate = config.get('MediLink_Config')
        if isinstance(cfg_candidate, dict):
            cfg = cfg_candidate
        else:
            cfg = config
    else:
        cfg = {}

    # Resolve receipts folder for index (use same path as receipts)
    receipts_root = cfg.get('local_claims_path', None)

    # Optional submission attempts ledger (custody-aware retries)
    try:
        from MediCafe import submission_attempts as _submission_attempts
    except Exception:
        _submission_attempts = None
    run_id = datetime.now().strftime("%Y%m%d%H%M%S")

    def _derive_claim_key(patient_data):
        try:
            key = patient_data.get('claim_key', '')
            if key:
                return key
            if compute_claim_key:
                return compute_claim_key(
                    patient_data.get('patient_id', ''),
                    '',  # payer_id not reliably known here
                    patient_data.get('primary_insurance', ''),
                    patient_data.get('surgery_date_iso', patient_data.get('surgery_date', '')),
                    patient_data.get('primary_procedure_code', '')
                )
        except Exception:
            pass
        return ''

    def _append_attempt_record(patient_data, endpoint, status, file_path, method, submission_type, transaction_id=''):
        if not _submission_attempts:
            return
        try:
            claim_key = _derive_claim_key(patient_data)
            record = _submission_attempts.build_attempt_record(
                claim_key=claim_key,
                endpoint=endpoint,
                status=status,
                file_path=file_path,
                submission_method=method,
                submission_type=submission_type,
                run_id=run_id,
                transaction_id=transaction_id
            )
            _submission_attempts.append_attempt(config, record)
        except Exception:
            pass

    def _extract_chart_suffix(file_path):
        try:
            base = os.path.splitext(os.path.basename(file_path))[0]
            parts = base.split('_')
            return parts[-1] if parts else ''
        except Exception:
            return ''

    def _map_patients_to_files(patients, converted_files, submission_type):
        file_map = {}
        if not converted_files:
            return file_map
        if submission_type != 'single' or len(converted_files) == 1:
            file_map[converted_files[0]] = list(patients)
            return file_map
        # Single submissions: try to map by chart suffix
        remaining = list(patients)
        used_idx = set()
        for fp in converted_files:
            chart_suffix = _extract_chart_suffix(fp)
            if not chart_suffix:
                continue
            for i, p in enumerate(remaining):
                if i in used_idx:
                    continue
                chart = str(p.get('CHART') or p.get('patient_id') or '').strip()
                if chart and chart == chart_suffix:
                    file_map.setdefault(fp, []).append(p)
                    used_idx.add(i)
                    break
        # Fallback by order for unmatched
        unmatched_patients = [p for i, p in enumerate(remaining) if i not in used_idx]
        unmatched_files = [fp for fp in converted_files if fp not in file_map]
        for fp, p in zip(unmatched_files, unmatched_patients):
            file_map.setdefault(fp, []).append(p)
        # If more patients than files, zip leaves some patients unassigned; attach to first file
        if len(unmatched_patients) > len(unmatched_files):
            file_map.setdefault(converted_files[0], []).extend(unmatched_patients[len(unmatched_files):])
        return file_map

    # Accumulate submission results
    submission_results = {}
    
    if not detailed_patient_data_grouped_by_endpoint:
        print("No new files detected for submission.")
        return

    # Iterate through each endpoint and submit claims
    for endpoint, patients_data in tqdm(detailed_patient_data_grouped_by_endpoint.items(), desc="Progress", unit="endpoint"):
        # Debug context to trace NoneType.get issues early
        try:
            log("[submit_claims] Starting endpoint: {}".format(endpoint), level="INFO")
            if patients_data is None:
                log("[submit_claims] Warning: patients_data is None for endpoint {}".format(endpoint), level="WARNING")
            else:
                try:
                    log("[submit_claims] patients_data count: {}".format(len(patients_data)), level="DEBUG")
                except Exception:
                    log("[submit_claims] patients_data length unavailable (type: {})".format(type(patients_data)), level="DEBUG")
        except Exception:
            pass

        if not patients_data:
            continue

        # Determine the submission method (e.g., "winscp" or "api")
        try:
            endpoint_cfg = cfg.get('endpoints', {}).get(endpoint, {})
            method = endpoint_cfg.get('submission_method', 'winscp')
        except Exception as e:
            log("[submit_claims] Error deriving submission method for endpoint {}: {}".format(endpoint, e), level="ERROR")
            method = 'winscp'
            endpoint_cfg = {}

        try:
            submission_type = endpoint_cfg.get('submission_type', 'batch')
        except Exception:
            submission_type = 'batch'

        if True: #confirm_transmission({endpoint: patients_data}): # Confirm transmission to each endpoint with detailed overview
            try:
                online = check_internet_connection()
            except ImportError:
                log("CRITICAL: Cannot check internet connectivity - configuration issue. Claims submission aborted.", level="ERROR")
                print("CRITICAL: Cannot check internet connectivity - configuration issue. Please check MediCafe installation.")
                return
            if online:
                client = get_api_client()
                if client is None:
                    print("Warning: API client not available via factory")
                    # Fallback to factory-backed shared client
                    try:
                        from MediCafe.api_factory import APIClient
                        client = APIClient()
                    except ImportError:
                        # Final fallback to direct instantiation if factory unavailable
                        try:
                            from MediCafe import api_core
                            client = api_core.APIClient()
                        except ImportError:
                            print("Error: Unable to create API client")
                            continue
                # Process files per endpoint
                try:
                    # Sanitize patient data structure before conversion
                    safe_patients = []
                    if isinstance(patients_data, list):
                        safe_patients = [item for item in patients_data if isinstance(item, dict)]
                    elif isinstance(patients_data, dict):
                        safe_patients = [patients_data]
                    else:
                        log("[submit_claims] Unexpected patients_data type for {}: {}".format(endpoint, type(patients_data)), level="ERROR")
                        safe_patients = []

                    # CRITICAL: Validate configuration before submission
                    try:
                        # Import the validation function from the encoder library
                        import MediLink_837p_encoder_library
                        config_issues = MediLink_837p_encoder_library.validate_config_sender_codes(config, endpoint)
                        if config_issues:
                            log("[CRITICAL] Configuration validation failed for endpoint {}: {}".format(endpoint, config_issues), level="ERROR")
                            print("\n" + "="*80)
                            print("CRITICAL: Configuration issues detected for endpoint '{}'".format(endpoint))
                            print("="*80)
                            for i, issue in enumerate(config_issues, 1):
                                print("   {}. {}".format(i, issue))
                            print("\nWARNING: These issues may cause claim rejections at the clearinghouse!")
                            print("   - Claims may be rejected due to missing sender identification")
                            print("   - Processing may fail due to invalid configuration values")
                            print("="*80)
                            
                            should_continue = False
                            while True:
                                user_choice = input("\nContinue with potentially invalid claims anyway? (y/N): ").strip().lower()
                                if user_choice in ['y', 'yes']:
                                    print("WARNING: Proceeding with submission despite configuration issues...")
                                    log("[WARNING] User chose to continue submission despite config issues for endpoint {}".format(endpoint), level="WARNING")
                                    should_continue = True
                                    break
                                elif user_choice in ['n', 'no', '']:
                                    print("SUCCESS: Submission aborted for endpoint '{}' due to configuration issues.".format(endpoint))
                                    log("[INFO] Submission aborted by user for endpoint {} due to config issues".format(endpoint), level="INFO")
                                    should_continue = False
                                    break
                                else:
                                    print("Please enter 'y' for yes or 'n' for no.")
                            
                            # Skip this endpoint if user chose not to continue
                            if not should_continue:
                                continue
                    except Exception as validation_error:
                        # Don't let validation errors block submission entirely
                        log("[ERROR] Configuration validation check failed: {}".format(validation_error), level="ERROR")
                        print("WARNING: Unable to validate configuration - proceeding with submission")

                    converted_files = MediLink_837p_encoder.convert_files_for_submission(safe_patients, config, crosswalk, client)
                except Exception as e:
                    tb = traceback.format_exc()
                    # Log via logger (may fail if logger expects config); also print to stderr to guarantee visibility
                    try:
                        log("[submit_claims] convert_files_for_submission failed for endpoint {}: {}\nTraceback: {}".format(endpoint, e, tb), level="ERROR")
                    except Exception:
                        pass
                    try:
                        import sys as _sys
                        _sys.stderr.write("[submit_claims] convert_files_for_submission failed for endpoint {}: {}\n".format(endpoint, e))
                        _sys.stderr.write(tb + "\n")
                    except Exception:
                        pass
                    # Record the failure in submission_results so error reporting can detect it
                    # This ensures error reports are sent even when conversion fails
                    if endpoint not in submission_results:
                        submission_results[endpoint] = {}
                    # Create a synthetic failure entry for error reporting
                    # Use a placeholder path since no file was actually converted
                    error_msg = str(e)
                    submission_results[endpoint]['[CONVERSION_FAILED]'] = (False, error_msg)
                    # Record in-custody conversion failure attempts (per patient)
                    try:
                        for p in safe_patients:
                            _append_attempt_record(
                                p,
                                endpoint,
                                "conversion_failed",
                                "",
                                method,
                                submission_type,
                                transaction_id=""
                            )
                    except Exception:
                        pass
                    # Continue to next endpoint instead of raising to allow error reporting to run
                    continue
                if converted_files:
                    # Deconfliction pre-check per file if helpers available.
                    # Key must match post-submission index write: use extract_member_data_from_x12_file
                    # when available so member_id/payer_id/service_start_date align; otherwise fall back
                    # to parse_837p_file for insurance_name and service_date.
                    filtered_files = []
                    for file_path in converted_files:
                        if compute_claim_key and find_by_claim_key and receipts_root:
                            try:
                                service_hash = os.path.basename(file_path)
                                patients, _ = parse_837p_file(file_path)
                                if not patients:
                                    filtered_files.append(file_path)
                                    continue
                                p = patients[0]
                                insurance_name_val = p.get('insurance_name', '')
                                dos_val = p.get('service_date', '')
                                patient_id_val = ''
                                payer_id_val = ''
                                try:
                                    from MediCafe.x12_utils import extract_member_data_from_x12_file
                                    x12_member = extract_member_data_from_x12_file(file_path) or {}
                                    patient_id_val = x12_member.get('member_id') or ''
                                    payer_id_val = x12_member.get('payer_id') or ''
                                    dos_val = x12_member.get('service_start_date') or dos_val
                                except Exception:
                                    pass
                                claim_key = compute_claim_key(
                                    patient_id_val,
                                    payer_id_val,
                                    insurance_name_val,
                                    dos_val,
                                    service_hash
                                )
                                existing = find_by_claim_key(receipts_root, claim_key)
                                if not existing and find_by_dos_and_basename and (not patient_id_val or not payer_id_val):
                                    existing = find_by_dos_and_basename(receipts_root, dos_val, service_hash)
                                if existing:
                                    print("Duplicate detected; skipping file: {}".format(file_path))
                                    continue
                            except Exception:
                                # Fail open (do not block submission)
                                pass
                        filtered_files.append(file_path)

                    if not filtered_files:
                        print("All files skipped as duplicates for endpoint {}.".format(endpoint))
                        submission_results[endpoint] = {}
                    elif method == 'winscp':
                        patient_file_map = _map_patients_to_files(safe_patients, filtered_files, submission_type)
                        # Validate IP address for OPTUMEDI endpoints before transmission
                        is_valid, current_ips, error_msg = validate_ip_for_endpoint(endpoint, config)
                        if not is_valid:
                            # Block submission - IP validation failed
                            error_details = (
                                "\n" + "="*80 + "\n"
                                "ERROR: IP Address Validation Failed for endpoint '{}'\n"
                                "="*80 + "\n"
                                "{}\n"
                                "\nSubmission blocked. Please verify network configuration.\n"
                                "="*80 + "\n"
                            ).format(endpoint, error_msg)
                            print(error_details)
                            log("IP validation failed for endpoint {}: {}".format(endpoint, error_msg), level="ERROR")
                            submission_results[endpoint] = {
                                fp: (False, "IP validation failed: Current IP not in allowed list")
                                for fp in filtered_files
                            }
                            # Record in-custody upload failures
                            try:
                                for fp, patients in patient_file_map.items():
                                    for p in patients:
                                        _append_attempt_record(
                                            p,
                                            endpoint,
                                            "upload_failed",
                                            fp,
                                            method,
                                            submission_type,
                                            transaction_id=""
                                        )
                            except Exception:
                                pass
                            continue  # Skip to next endpoint
                        
                        # Transmit files via WinSCP
                        try:
                            operation_type = "upload"
                            endpoint_cfg = cfg.get('endpoints', {}).get(endpoint, {})
                            local_claims_path = cfg.get('local_claims_path', '.')
                            transmission_result = operate_winscp(operation_type, filtered_files, endpoint_cfg, local_claims_path, config)
                            success_dict = handle_transmission_result(transmission_result, config, operation_type, method)
                            # If we attempted uploads but could not derive any status, emit explicit failures per file
                            if (not success_dict) and filtered_files:
                                success_dict = {fp: (False, "No transfer status found in WinSCP log") for fp in filtered_files}
                            submission_results[endpoint] = success_dict
                            # Record attempts per file
                            try:
                                for fp, result in success_dict.items():
                                    if fp.startswith('_'):
                                        continue
                                    status = "submitted" if result and result[0] else "upload_failed"
                                    for p in patient_file_map.get(fp, []):
                                        _append_attempt_record(
                                            p,
                                            endpoint,
                                            status,
                                            fp,
                                            method,
                                            submission_type,
                                            transaction_id=""
                                        )
                            except Exception:
                                pass
                        except FileNotFoundError as e:
                            msg = "Log file not found - {}".format(str(e))
                            print("Failed to transmit files to {}. Error: {}".format(endpoint, msg))
                            submission_results[endpoint] = {fp: (False, msg) for fp in (filtered_files or [])}
                            try:
                                for fp, patients in patient_file_map.items():
                                    for p in patients:
                                        _append_attempt_record(
                                            p,
                                            endpoint,
                                            "upload_failed",
                                            fp,
                                            method,
                                            submission_type,
                                            transaction_id=""
                                        )
                            except Exception:
                                pass
                        except IOError as e:
                            msg = "Input/output error - {}".format(str(e))
                            print("Failed to transmit files to {}. Error: {}".format(endpoint, msg))
                            submission_results[endpoint] = {fp: (False, msg) for fp in (filtered_files or [])}
                            try:
                                for fp, patients in patient_file_map.items():
                                    for p in patients:
                                        _append_attempt_record(
                                            p,
                                            endpoint,
                                            "upload_failed",
                                            fp,
                                            method,
                                            submission_type,
                                            transaction_id=""
                                        )
                            except Exception:
                                pass
                        except Exception as e:
                            msg = str(e)
                            print("Failed to transmit files to {}. Error: {}".format(endpoint, msg))
                            submission_results[endpoint] = {fp: (False, msg) for fp in (filtered_files or [])}
                            try:
                                for fp, patients in patient_file_map.items():
                                    for p in patients:
                                        _append_attempt_record(
                                            p,
                                            endpoint,
                                            "upload_failed",
                                            fp,
                                            method,
                                            submission_type,
                                            transaction_id=""
                                        )
                            except Exception:
                                pass
                    elif method == 'api':
                        patient_file_map = _map_patients_to_files(safe_patients, filtered_files, submission_type)
                        # Transmit files via API
                        try:
                            api_responses = []
                            # Track transactionIds for submission index
                            transaction_id_map = {}
                            
                            for file_path in filtered_files:
                                with open(file_path, 'r', encoding='utf-8') as file:
                                    # Optimize string operations by doing replacements in one pass
                                    x12_request_data = file.read().replace('\n', '').replace('\r', '').strip()
                                    try:
                                        from MediCafe import api_core
                                        response = api_core.submit_uhc_claim(client, x12_request_data)
                                    except ImportError:
                                        print("Error: Unable to import api_core for claim submission")
                                        response = {"error": "API module not available"}
                                    api_responses.append((file_path, response))
                                    
                                    # Extract transactionId from response if available
                                    if isinstance(response, dict):
                                        transaction_id = response.get('transactionId')
                                        if transaction_id:
                                            transaction_id_map[file_path] = transaction_id
                            
                            # Store transaction_id_map for later use in submission index
                            if transaction_id_map:
                                if endpoint not in submission_results:
                                    submission_results[endpoint] = {}
                                submission_results[endpoint]['_transaction_ids'] = transaction_id_map
                            
                            success_dict = handle_transmission_result(api_responses, config, "api", method)
                            # If API call path yielded no status, emit explicit failures per file attempted
                            if (not success_dict) and filtered_files:
                                success_dict = {fp: (False, "No API response parsed") for fp in filtered_files}
                            submission_results[endpoint] = success_dict
                            
                            # Restore transaction_id_map after success_dict assignment
                            if transaction_id_map:
                                submission_results[endpoint]['_transaction_ids'] = transaction_id_map
                            # Record attempts per file
                            try:
                                for fp, result in success_dict.items():
                                    if fp.startswith('_'):
                                        continue
                                    tx_id = transaction_id_map.get(fp) or transaction_id_map.get(os.path.basename(fp), '')
                                    if result and result[0]:
                                        status = "submitted"
                                    else:
                                        status = "submitted" if tx_id else "api_error"
                                    for p in patient_file_map.get(fp, []):
                                        _append_attempt_record(
                                            p,
                                            endpoint,
                                            status,
                                            fp,
                                            method,
                                            submission_type,
                                            transaction_id=tx_id
                                        )
                            except Exception:
                                pass
                        except Exception as e:
                            msg = str(e)
                            print("Failed to transmit files via API to {}. Error: {}".format(endpoint, msg))
                            submission_results[endpoint] = {fp: (False, msg) for fp in (filtered_files or [])}
                            try:
                                for fp, patients in patient_file_map.items():
                                    for p in patients:
                                        _append_attempt_record(
                                            p,
                                            endpoint,
                                            "api_error",
                                            fp,
                                            method,
                                            submission_type,
                                            transaction_id=""
                                        )
                            except Exception:
                                pass
                else:
                    print("No files were converted for transmission to {}.".format(endpoint))
                    try:
                        for p in safe_patients:
                            _append_attempt_record(
                                p,
                                endpoint,
                                "conversion_failed",
                                "",
                                method,
                                submission_type,
                                transaction_id=""
                            )
                    except Exception:
                        pass
            else:
                print("Error: No internet connection detected.")
                log("Error: No internet connection detected.", level="ERROR")
                try_again = input("Do you want to try again? (Y/N): ").strip().lower()
                if try_again != 'y':
                    print("Exiting transmission process. Please try again later.")
                    return  # Exiting the function if the user decides not to retry
        else:
            # This else statement is inaccessible because it is preceded by an if True condition, 
            # which is always true and effectively makes the else clause unreachable.
            # To handle this, we need to decide under what conditions the submission should be canceled. 
            # One option is to replace the if True with a condition that checks for some pre-submission criteria. 
            # For instance, if there is a confirmation step or additional checks that need to be performed before 
            # proceeding with the submission, these could be included here.
            print("Transmission canceled for endpoint {}.".format(endpoint)) 
        
        # Continue to next endpoint regardless of the previous outcomes

    # Build and display receipt
    build_and_display_receipt(submission_results, config)

    # Check for claim submission failures and automatically submit error report if any detected (non-blocking)
    # FIX: Move error reporting to background thread to avoid blocking receipt display
    try:
        failure_summary = _detect_claim_submission_failures(submission_results)
        if failure_summary:
            log("Claim submission failures detected. Generating automatic error report in background...", level="INFO")
            
            def _submit_error_report_async():
                """Background function to submit error report without blocking receipt display."""
                try:
                    from MediCafe.error_reporter import collect_support_bundle, submit_support_bundle_email
                    zip_path = collect_support_bundle(include_traceback=True, claim_failure_summary=failure_summary)
                    if zip_path:
                        online = False
                        check_failed_reason = None
                        # DIAGNOSTIC: Log context before internet check to help diagnose consistent failures
                        log("Starting internet connectivity check for error report submission (bundle: {})...".format(zip_path), level="DEBUG")
                        try:
                            online = check_internet_connection()
                            if not online:
                                # FIX: Log when check returns False (not just exceptions) to diagnose consistent failures
                                check_failed_reason = "Internet connectivity check returned False (offline or connection failed)"
                                log("Internet connectivity check indicates offline. Error bundle will be queued for retry when online. "
                                    "Check DEBUG logs for detailed connectivity check diagnostics.", level="INFO")
                        except ImportError:
                            # If we can't check connectivity during error reporting, assume offline
                            # to preserve the error bundle for later
                            online = False
                            check_failed_reason = "ImportError: Cannot import check_internet_connection from MediCafe.core_utils"
                            log("Warning: Could not check internet connectivity - preserving error bundle. Reason: {}".format(check_failed_reason), level="WARNING")
                        except Exception as conn_e:
                            # Log connection check failures for debugging
                            check_failed_reason = "Exception during connectivity check: {}".format(conn_e)
                            log("Internet connectivity check failed: {}. Preserving error bundle.".format(conn_e), level="WARNING")
                            online = False
                        
                        if online:
                            success = submit_support_bundle_email(zip_path)
                            if success:
                                # On success, remove the bundle
                                try:
                                    os.remove(zip_path)
                                    log("Error report for claim submission failures submitted successfully.", level="INFO")
                                except Exception:
                                    pass
                            else:
                                # Preserve bundle for manual retry
                                log("Error report send failed - bundle preserved at {} for retry.".format(zip_path), level="WARNING")
                        else:
                            log("Offline - error bundle queued at {} for retry when online.".format(zip_path), level="INFO")
                    else:
                        log("Failed to create error report bundle for claim submission failures.", level="ERROR")
                except ImportError:
                    log("Error reporting not available - check MediCafe installation.", level="WARNING")
                except Exception as report_e:
                    log("Error report collection failed: {}".format(report_e), level="ERROR")
            
            # Submit error report in background thread (non-blocking)
            import threading
            error_report_thread = threading.Thread(target=_submit_error_report_async, daemon=True)
            error_report_thread.start()
    except Exception as e:
        # Don't let error reporting failures break the submission process
        log("Unexpected error during automatic error report generation: {}".format(e), level="ERROR")

    # Append index records for successes
    try:
        if append_submission_record and isinstance(submission_results, dict):
            # Resolve receipts root
            if isinstance(config, dict):
                _cfg2 = config.get('MediLink_Config')
                cfg2 = _cfg2 if isinstance(_cfg2, dict) else config
            else:
                cfg2 = {}
            receipts_root2 = cfg2.get('local_claims_path', None)
            if receipts_root2:
                for endpoint, files in submission_results.items():
                    # Extract transaction ID map if available
                    transaction_id_map = {}
                    if isinstance(files, dict):
                        transaction_id_map = files.get('_transaction_ids', {})
                    
                    for file_path, result in files.items():
                        # Skip metadata entries
                        if file_path.startswith('_'):
                            continue
                        
                        try:
                            status, message = result
                            if status:
                                patients, submitted_at = parse_837p_file(file_path)
                                # Take first patient for keying; improve later for per-service handling
                                p = patients[0] if patients else {}

                                # Best-effort extraction of member/search identity from the actual X12 payload.
                                # This improves post-submission status lookups and avoids "Unknown" rows when
                                # the lightweight parse_837p_file output lacks member identifiers.
                                x12_member = {}
                                try:
                                    from MediCafe.x12_utils import extract_member_data_from_x12_file
                                    x12_member = extract_member_data_from_x12_file(file_path) or {}
                                except Exception:
                                    x12_member = {}

                                payer_id_val = x12_member.get('payer_id') or ''
                                patient_id_val = x12_member.get('member_id') or ''
                                dos_val = x12_member.get('service_start_date') or p.get('service_date', '')
                                insurance_name_val = p.get('insurance_name', '')

                                claim_key = compute_claim_key(
                                    patient_id_val,
                                    payer_id_val,
                                    insurance_name_val,
                                    dos_val,
                                    os.path.basename(file_path)
                                )
                                record = {
                                    'claim_key': claim_key,
                                    'patient_id': patient_id_val,
                                    'payer_id': payer_id_val,
                                    'primary_insurance': insurance_name_val,
                                    'dos': dos_val,
                                    'endpoint': endpoint,
                                    'submitted_at': submitted_at or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                    'receipt_file': os.path.basename(file_path),
                                    'status': 'success',
                                    'member_id': patient_id_val,
                                    'member_first_name': x12_member.get('member_first_name', ''),
                                    'member_last_name': x12_member.get('member_last_name', ''),
                                    'member_dob': x12_member.get('member_dob', ''),
                                    'service_start_date': x12_member.get('service_start_date', ''),
                                    'service_end_date': x12_member.get('service_end_date', ''),
                                }

                                # Add transactionId if available
                                # Try both full path and basename as keys
                                transaction_id = transaction_id_map.get(file_path)
                                if not transaction_id:
                                    transaction_id = transaction_id_map.get(os.path.basename(file_path))
                                if transaction_id:
                                    record['transactionId'] = transaction_id
                                
                                try:
                                    if isinstance(message, str) and " [via UHCAPI fallback]" in message:
                                        record['submission_note'] = "UHCAPI fallback after OPTUMAI failure"
                                except Exception:
                                    pass
                                append_submission_record(receipts_root2, record)
                        except Exception:
                            continue
    except Exception:
        pass
    
    print("Claim submission process completed.\n")

def handle_transmission_result(transmission_result, config, operation_type, method):
    """
    Analyze the outcomes of file transmissions based on WinSCP log entries or API responses.

    Parameters:
    - transmission_result: List of paths for files that were attempted to be transmitted or API response details.
    - config: Configuration dictionary containing paths and settings.
    - operation_type: The type of operation being performed (e.g., "upload").
    - method: The transmission method used ("winscp" or "api").

    Returns:
    - Dictionary mapping each file path or API response to a tuple indicating successful transmission and any relevant messages.
    """
    success_dict = {}

    if method == "winscp":
        # Define the log filename based on the operation type
        log_filename = "winscp_{}.log".format(operation_type)
        # XP/WinSCP NOTE:
        # - Historically this used 'local_claims_path' which is typically the UPLOAD staging directory.
        # - On some XP setups, WinSCP writes logs to a different directory than where files are uploaded or downloaded.
        # - To avoid brittle assumptions, allow an explicit 'winscp_log_dir' override while preserving legacy default.
        # - Fallback remains 'local_claims_path' to preserve current behavior.
        # Ensure cfg is a dict for safe access
        if isinstance(config, dict):
            _cfg_candidate = config.get('MediLink_Config')
            if isinstance(_cfg_candidate, dict):
                cfg = _cfg_candidate
            else:
                cfg = config
        else:
            cfg = {}
        winscp_log_dir = (
            cfg.get('winscp_log_dir')
            or cfg.get('local_claims_path')
            or '.'
        )
        # If you observe missing logs, verify WinSCP's real log location in the ini or via command-line switches.
        # Consider adding a scheduled cleanup (daily) to prevent unbounded log growth on XP machines.
        log_path = os.path.join(winscp_log_dir, log_filename)
        
        try:
            # Read the contents of the WinSCP log file
            with open(log_path, 'r', encoding='utf-8') as log_file:
                log_contents = log_file.readlines()

            if not log_contents:
                # Handle the case where the log file is empty
                log("Log file '{}' is empty.".format(log_path))
                success_dict = {file_path: (False, "Log file empty") for file_path in transmission_result}
            else:
                # Process the last few lines of the log file for transfer status
                last_lines = log_contents[-35:]
                for file_path in transmission_result:
                    # Pre-format success messages to avoid repeated string formatting
                    success_message = "Transfer done: '{}'".format(file_path)
                    additional_success_message = "Upload of file '{}' was successful, but error occurred while setting the permissions and/or timestamp.".format(file_path)
                    # Use any() with generator expression for better performance
                    success = any(success_message in line or additional_success_message in line for line in last_lines)
                    message = "Success" if success else "Transfer incomplete or error occurred"
                    success_dict[file_path] = (success, message)

        except FileNotFoundError:
            # Log file not found, handle the error
            log("Log file '{}' not found.".format(log_path))
            success_dict = {file_path: (False, "Log file not found") for file_path in transmission_result}
        except IOError as e:
            # Handle IO errors, such as issues reading the log file
            log("IO error when handling the log file '{}': {}".format(log_path, e))
            success_dict = {file_path: (False, "IO error: {}".format(e)) for file_path in transmission_result}
        except Exception as e:
            # Catch all other exceptions and log them
            log("Error processing the transmission log: {}".format(e))
            success_dict = {file_path: (False, "Error: {}".format(e)) for file_path in transmission_result}

    elif method == "api":
        # Process each API response to determine the success status
        for file_path, response in transmission_result:
            try:
                # Handle responses that may be None or non-dict safely
                if isinstance(response, dict):
                    message = response.get('message', 'No message provided')
                    fallback_tag = " [via UHCAPI fallback]"
                    message_base = message.split(fallback_tag, 1)[0] if isinstance(message, str) else message
                    statuscode = str(response.get('statuscode', '') or response.get('statusCode', ''))
                    has_transaction_id = bool(response.get('transactionId'))
                    has_x12_response = bool(response.get('x12ResponseData') or response.get('x12Response277CA'))
                    response_type = response.get('responseType') or response.get('response_type')
                    response_type_str = str(response_type).upper() if response_type else ''
                    has_error_response_type = response_type_str.startswith('ERR')
                    response_metadata = response.get('_metadata') if isinstance(response.get('_metadata'), dict) else {}
                    
                    
                    # Success criteria: Check multiple indicators for robustness
                    # UHCAPI legacy messages
                    legacy_success_messages = [
                        "Claim validated and sent for further processing",
                        "Acknowledgement pending"
                    ]
                    # OPTUMAI success messages (from Claim_Actions.json and Claims_Inquiry.json)
                    optumai_success_messages = [
                        "Claim submitted successfully. Refer 277CA for validation outcomes.",
                        "Transaction processed successfully"
                    ]
                    # Success status codes: "000" (OPTUMAI claim submission), "200" (OPTUMAI 277CA search)
                    success_status_codes = ["000", "200"]
                    
                    # Check if message matches known success messages
                    message_success = message_base in legacy_success_messages or message_base in optumai_success_messages
                    # Check if status code indicates success
                    statuscode_success = statuscode in success_status_codes
                    # Check if we have a transaction ID (indicates successful submission)
                    transaction_id_success = has_transaction_id
                    # Check if we have X12 response data (indicates acknowledgment received)
                    x12_response_success = has_x12_response
                    
                    # Detect partial success: transactionId present but 277CA validation failed
                    # This occurs when claim submission succeeds but 277CA search fails with validation error
                    has_277ca_validation_failure = (
                        statuscode in ['400', '422'] and
                        ('Invalid transactionId' in str(message) or 
                         'VALIDATION_FAILED' in str(message) or
                         'validation failed' in str(message).lower())
                    )
                    
                    has_submission_success = response_metadata.get('claim_submission_success')
                    had_277ca_fetch = response_metadata.get('277ca_fetch_attempted')
                    has_277ca_fetch_success = response_metadata.get('277ca_fetch_success')
                    eligible_for_partial = (
                        has_transaction_id and
                        has_277ca_validation_failure and
                        (has_submission_success is True) and
                        (had_277ca_fetch is True) and
                        (has_277ca_fetch_success is False) and
                        (not has_error_response_type)
                    )
                    
                    if eligible_for_partial:
                        # Partial success: claim submitted successfully but 277CA validation failed.
                        # Keep actual API message primary; append partial-success note as secondary.
                        message = "{} (Partial success: claim submitted but 277CA validation failed)".format(message)
                        success = True  # Mark as success for receipt purposes (claim was submitted)
                    else:
                        if has_error_response_type:
                            message = "Submission failed with responseType {}: {}".format(
                                response_type_str or 'UNKNOWN', message
                            )
                            success = False
                        else:
                            # Standard success/failure logic
                            # Success if: (message matches OR statuscode is success) AND (transactionId present OR x12Response present)
                            # This handles both UHCAPI and OPTUMAI responses
                            success = (message_success or statuscode_success) and (transaction_id_success or x12_response_success)
                    
                else:
                    message = str(response) if response is not None else 'No response received'
                    success = False
                success_dict[file_path] = (success, message)
            except Exception as e:
                # Handle API exception
                log("Error processing API response: {}".format(e))
                success_dict[file_path] = (False, str(e))

    return success_dict


def _is_submission_file_key(key):
    """Return True only when the key should be treated as a file entry (not metadata like _transaction_ids)."""
    return not (isinstance(key, str) and key.startswith('_'))


def _parse_submission_file_result(result):
    """Normalize submission result to (status, message). On unpack failure return (False, stringified or 'Unknown result')."""
    try:
        status, message = result
        return (status, message)
    except Exception:
        try:
            return (False, str(result))
        except Exception:
            return (False, "Unknown result")


def _iter_submission_file_entries(submission_results):
    """Yield (endpoint, file_path, file_result) only for file entries (skip metadata keys like _transaction_ids)."""
    if not isinstance(submission_results, dict):
        return
    for endpoint, files in submission_results.items():
        if not isinstance(files, dict):
            continue
        for file_path, file_result in files.items():
            if not _is_submission_file_key(file_path):
                continue
            yield (endpoint, file_path, file_result)


def _detect_claim_submission_failures(submission_results):
    """
    Detect and summarize claim submission failures from submission_results.
    
    Returns a dictionary with failure summary (endpoint names, error types/counts, statistics)
    or None if no failures detected. Summary contains NO PHI (no patient names, dates, amounts, etc.).
    
    Parameters:
    - submission_results: Dictionary containing submission results grouped by endpoint.
        Expected structure: {endpoint_name: {file_path: (status_bool, message_str)}}
    
    Returns:
    - dict or None: Failure summary with endpoint names, error message types/counts, and statistics.
    """
    # DIAGNOSTIC: Log function entry for debugging
    log("_detect_claim_submission_failures: Starting failure detection analysis.", level="DEBUG")
    
    if not isinstance(submission_results, dict):
        log("_detect_claim_submission_failures: submission_results is not a dict (type: {}). Returning None.".format(
            type(submission_results).__name__), level="DEBUG")
        return None
    
    # DIAGNOSTIC: Log structure information
    endpoint_count = len(submission_results)
    log("_detect_claim_submission_failures: Analyzing {} endpoint(s).".format(endpoint_count), level="DEBUG")
    
    # Import _safe_ascii from error_reporter to avoid duplication
    try:
        from MediCafe.error_reporter import _safe_ascii
    except ImportError:
        # Fallback implementation if import fails (shouldn't happen in normal operation)
        def _safe_ascii(text):
            try:
                if text is None:
                    return ''
                if isinstance(text, bytes):
                    try:
                        text = text.decode('ascii', 'ignore')
                    except Exception:
                        text = text.decode('utf-8', 'ignore')
                else:
                    text = str(text)
                return text.encode('ascii', 'ignore').decode('ascii', 'ignore')
            except Exception:
                return ''
    
    failures_by_endpoint = {}
    error_message_counts = {}
    total_successes = 0
    total_failures = 0
    
    # Iterate through submission results to identify failures
    for endpoint, files in submission_results.items():
        if not isinstance(files, dict):
            log("_detect_claim_submission_failures: Endpoint '{}' files is not a dict (type: {}). Skipping.".format(
                endpoint, type(files).__name__), level="DEBUG")
            continue
        
        file_count = len(files)
        log("_detect_claim_submission_failures: Processing endpoint '{}' with {} file(s).".format(
            endpoint, file_count), level="DEBUG")
        
        endpoint_failures = []
        endpoint_successes = 0
        
        for file_path, result in files.items():
            if not _is_submission_file_key(file_path):
                continue
            status, message = _parse_submission_file_result(result)
            result_shape_ok = isinstance(result, (tuple, list)) and len(result) == 2
            if not result_shape_ok:
                try:
                    err_detail = "len={}".format(len(result)) if isinstance(result, (tuple, list)) else "not a tuple/list"
                except Exception:
                    err_detail = "no len"
                log("_detect_claim_submission_failures: File '{}' result is not a 2-tuple (type: {}, {}). Treating as failure.".format(
                    os.path.basename(file_path), type(result).__name__, err_detail), level="WARNING")
            log("_detect_claim_submission_failures: File '{}' result - status: {}, message type: {}".format(
                os.path.basename(file_path), status, type(message).__name__), level="DEBUG")
            
            if status:
                endpoint_successes += 1
                total_successes += 1
            else:
                endpoint_failures.append(message)
                total_failures += 1
                # Sanitize and count error message occurrences
                # Use full message for counting to avoid grouping different errors
                error_key = _safe_ascii(str(message))
                error_message_counts[error_key] = error_message_counts.get(error_key, 0) + 1
                log("_detect_claim_submission_failures: Failure detected for file '{}' at endpoint '{}'. Message: {}".format(
                    os.path.basename(file_path), endpoint, message[:100] + ('...' if len(message) > 100 else '')), level="DEBUG")
        
        if endpoint_failures:
            failures_by_endpoint[endpoint] = {
                'failure_count': len(endpoint_failures),
                'success_count': endpoint_successes,
                'error_messages': list(set(endpoint_failures))  # Unique error messages
            }
            log("_detect_claim_submission_failures: Endpoint '{}' summary - failures: {}, successes: {}.".format(
                endpoint, len(endpoint_failures), endpoint_successes), level="DEBUG")
    
    # If no failures detected, return None
    if not failures_by_endpoint:
        log("_detect_claim_submission_failures: No failures detected (total successes: {}, total failures: {}). Returning None.".format(
            total_successes, total_failures), level="DEBUG")
        return None
    
    # DIAGNOSTIC: Log final summary
    log("_detect_claim_submission_failures: Failures detected - total: {}, endpoints affected: {}. Building summary.".format(
        total_failures, len(failures_by_endpoint)), level="DEBUG")
    
    # Build summary (HIPAA-safe: no PHI)
    # Truncate long error messages in summary for readability (but keep full messages in counts)
    summary = {
        'total_failures': total_failures,
        'total_successes': total_successes,
        'endpoints_with_failures': list(failures_by_endpoint.keys()),
        'failures_by_endpoint': {
            endpoint: {
                'failure_count': data['failure_count'],
                'success_count': data['success_count'],
                'unique_error_count': len(data['error_messages'])
            }
            for endpoint, data in failures_by_endpoint.items()
        },
        'error_message_summary': [
            '{}: {} occurrence(s)'.format(
                (msg[:150] + '...' if len(msg) > 150 else msg),  # Truncate for display only
                count
            )
            for msg, count in sorted(error_message_counts.items(), key=lambda x: x[1], reverse=True)
        ]
    }
    
    return summary

def build_and_display_receipt(submission_results, config):
    """
    Builds and displays a receipt for submitted claims, including both successful and failed submissions.
    A receipt of submitted claims is typically attached to each printed facesheet for recordkeeping confirming submission.
    
    Parameters:
    - submission_results: Dictionary containing submission results with detailed information for each endpoint.
    - config: Configuration settings loaded from a JSON file.

    Returns:
    - None
    """
    # Prepare data for receipt
    receipt_data = prepare_receipt_data(submission_results)

    # Build the receipt
    receipt_content = build_receipt_content(receipt_data)

    # Print the receipt to the screen
    log("Printing receipt...")
    print(receipt_content)

    # Save the receipt to a text file
    save_receipt_to_file(receipt_content, config)

    log("Receipt has been generated and saved.")

def prepare_receipt_data(submission_results):
    """
    Prepare submission results for a receipt, including data from both successful and failed submissions.

    This function extracts patient names, dates of service, amounts billed, and insurance names from an 837p file.
    It also includes the date and time of batch claim submission, and the receiver name from the 1000B segment.
    Data is organized by receiver name and includes both successful and failed submissions.

    Parameters:
    - submission_results (dict): Contains submission results grouped by endpoint, with detailed status information.

    Returns:
    - dict: Organized data for receipt preparation, including both successful and failed submission details.
    """
    receipt_data = {}
    for endpoint, file_path, file_result in _iter_submission_file_entries(submission_results):
        if endpoint not in receipt_data:
            log("Processing endpoint: {}".format(endpoint), level="INFO")
            receipt_data[endpoint] = {
                "patients": [],
                "date_of_submission": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
        log("File path: {}".format(file_path), level="DEBUG")
        log("File result: {}".format(file_result), level="DEBUG")

        status, message = _parse_submission_file_result(file_result)
        log("Status: {}, Message: {}".format(status, message), level="DEBUG")

        try:
            patient_data, _ = parse_837p_file(file_path)
        except Exception as e:
            log("Could not parse 837p for receipt (file: {}): {}. Adding placeholder row.".format(
                os.path.basename(file_path) if file_path else file_path, str(e)), level="WARNING")
            patient_data = [{
                'name': os.path.basename(file_path) if file_path else 'Unknown',
                'service_date': '',
                'amount_billed': '',
                'insurance_name': '',
                'status': status,
                'message': message
            }]
        for patient in patient_data:
            patient['status'] = status
            patient['message'] = message

        receipt_data[endpoint]["patients"].extend(patient_data)
    
    validate_data(receipt_data)
    log("Receipt data: {}".format(receipt_data), level="DEBUG")
    
    return receipt_data

def validate_data(receipt_data):
    # Simple validation to check if data fields are correctly populated
    for endpoint, data in receipt_data.items():
        patients = data.get("patients", [])
        for index, patient in enumerate(patients, start=1):
            missing_fields = [field for field in ('name', 'service_date', 'amount_billed', 'insurance_name', 'status') if patient.get(field) in (None, '')]
            
            if missing_fields:
                # Log the missing fields without revealing PHI
                log("Receipt Data validation error for endpoint '{}', patient {}: Missing information in fields: {}".format(endpoint, index, ", ".join(missing_fields)))
    return True

def parse_837p_file(file_path):
    """
    Parse an 837p file to extract patient details and date of submission.

    This function reads the specified 837p file, extracts patient details such as name, service date, and amount billed,
    and retrieves the date of submission from the GS segment. It then organizes this information into a list of dictionaries
    containing patient data. If the GS segment is not found, it falls back to using the current date and time.

    Parameters:
    - file_path (str): The path to the 837p file to parse.

    Returns:
    - tuple: A tuple containing two elements:
        - A list of dictionaries, where each dictionary represents patient details including name, service date, and amount billed.
        - A string representing the date and time of submission in the format 'YYYY-MM-DD HH:MM:SS'.
    """
    patient_details = []
    date_of_submission = None
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
            log("Parsing submitted 837p...")

            # Extract the submission date from the GS segment
            gs_match = GS_PATTERN.search(content)
            if gs_match:
                date = gs_match.group(1)
                time = gs_match.group(2)
                date_of_submission = datetime.strptime("{}{}".format(date, time), "%Y%m%d%H%M").strftime("%Y-%m-%d %H:%M:%S")
            else:
                # Fallback to the current date and time if GS segment is not found
                date_of_submission = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            # Split content using 'SE*{count}*{control_number}~' as delimiter
            patient_records = SE_PATTERN.split(content)
            
            # Remove any empty strings from list that may have been added from split
            patient_records = [record for record in patient_records if record.strip()]
            
            for record in patient_records:
                # Extract patient name
                name_match = NM1_IL_PATTERN.search(record)
                # Extract service date
                service_date_match = DTP_472_PATTERN.search(record)
                # Extract claim amount
                amount_match = CLM_PATTERN.search(record)
                # Extract insurance name (payer_name)
                insurance_name_match = NM1_PR_PATTERN.search(record)
                
                if name_match and service_date_match and amount_match:
                    # Handle optional middle name
                    middle_name = name_match.group(3).strip() if name_match.group(3) else ""
                    patient_name = "{} {} {}".format(name_match.group(2), middle_name, name_match.group(1)).strip()
                    
                    # Optimize date formatting
                    service_date_raw = service_date_match.group(1)
                    service_date = "{}-{}-{}".format(service_date_raw[:4], service_date_raw[4:6], service_date_raw[6:])
                    
                    amount_billed = float(amount_match.group(1))
                    insurance_name = insurance_name_match.group(1) if insurance_name_match else ""
                    
                    patient_details.append({
                        "name": patient_name,
                        "service_date": service_date,
                        "amount_billed": amount_billed,
                        "insurance_name": insurance_name
                    })
    except Exception as e:
        print("Error reading or parsing the 837p file: {0}".format(str(e)))
    
    return patient_details, date_of_submission

def build_receipt_content(receipt_data):
    """
    Build the receipt content in a human-readable ASCII format with a tabular data presentation for patient information.

    Args:
        receipt_data (dict): Dictionary containing receipt data with patient details.

    Returns:
        str: Formatted receipt content as a string.
    """
    # Build the receipt content in a human-readable ASCII format
    receipt_lines = ["Submission Receipt", "=" * 60, ""]  # Header
    if not receipt_data:
        receipt_lines.append("No submission results to display.")
        return "\n".join(receipt_lines)

    for endpoint, data in receipt_data.items():
        header = "Endpoint: {0} (Submitted: {1})".format(endpoint, data['date_of_submission'])
        receipt_lines.extend([header, "-" * len(header)])
        
        # Table headers (Status column widened so actual API messages are visible)
        table_header = "{:<20} | {:<15} | {:<15} | {:<20} | {:<50}".format("Patient", "Service Date", "Amount Billed", "Insurance", "Status")
        receipt_lines.append(table_header)
        receipt_lines.append("-" * len(table_header))
        
        # Pre-format the status display: prefer actual API message over hardcoded labels
        for patient in data["patients"]:
            message = patient.get('message', '') or ''
            if isinstance(message, str):
                message = message.strip()
            if patient.get('status'):
                # When we have an actual message (including partial-success or fallback), show it
                status_display = message if message else "SUCCESS"
            else:
                status_display = message if message else "Failed"
            # Truncate very long status so user sees ellipsis instead of silent cut-off
            if len(status_display) > 50:
                status_display = status_display[:47] + "..."
            # Use .get for defensive display; column widths preserve alignment
            patient_info = " | ".join([
                "{:<20}".format(patient.get('name') or ''),
                "{:<15}".format(patient.get('service_date') or ''),
                "${:<14}".format(patient.get('amount_billed') or ''),
                "{:<20}".format(patient.get('insurance_name') or ''),
                "{:<50}".format(status_display)
            ])
            receipt_lines.append(patient_info)
        
        receipt_lines.append("")  # Blank line for separation
    
    receipt_content = "\n".join(receipt_lines)
    return receipt_content

def save_receipt_to_file(receipt_content, config):
    """
    Saves the receipt content to a text file and opens it for the user.

    Parameters:
    - receipt_content (str): The formatted content of the receipt.
    - config: Configuration settings loaded from a JSON file.

    Returns:
    - None
    """
    try:
        file_name = "Receipt_{0}.txt".format(datetime.now().strftime('%Y%m%d_%H%M%S'))
        # Ensure cfg is a dict for safe path resolution
        if isinstance(config, dict):
            cfg_candidate = config.get('MediLink_Config')
            if isinstance(cfg_candidate, dict):
                cfg = cfg_candidate
            else:
                cfg = config
        else:
            cfg = {}
        file_path = os.path.join(cfg.get('local_claims_path', '.'), file_name)
        
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(receipt_content)
        
        log("Receipt saved to:", file_path)
        # Open the file automatically for the user (Windows-specific)
        if os.name == 'nt':
            os.startfile(file_path)
    except Exception as e:
        print("Failed to save or open receipt file:", e)

# Secure File Transmission
def confirm_transmission(detailed_patient_data_grouped_by_endpoint):
    """
    Displays detailed patient data ready for transmission and their endpoints, 
    asking for user confirmation before proceeding.

    :param detailed_patient_data_grouped_by_endpoint: Dictionary with endpoints as keys and 
            lists of detailed patient data as values.
    :param config: Configuration settings loaded from a JSON file.
    """ 
    # Clear terminal for clarity
    os.system('cls')
    
    print("\nReview of patient data ready for transmission:")
    for endpoint, patient_data_list in detailed_patient_data_grouped_by_endpoint.items():
        print("\nEndpoint: {0}".format(endpoint))
        for patient_data in patient_data_list:
            patient_info = "({1}) {0}".format(patient_data['patient_name'], patient_data['patient_id'])
            print("- {:<33} | {:<5}, ${:<6}, {}".format(
                patient_info, patient_data['surgery_date'][:5], patient_data['amount'], patient_data['primary_insurance']))
    
    while True:
        confirmation = input("\nProceed with transmission to all endpoints? (Y/N): ").strip().lower()
        if confirmation in ['y', 'n']:
            return confirmation == 'y'
        else:
            print("Invalid input. Please enter 'Y' for yes or 'N' for no.")

# Entry point if this script is run directly. Probably needs to be handled better.
if __name__ == "__main__":
    print("Please run MediLink directly.")
