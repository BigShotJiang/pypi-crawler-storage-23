#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Update endpoint configuration to match swagger specification
"""

import os
import json
import sys

def update_endpoint_configuration():
    """Update endpoint configuration to match swagger specification"""
    
    # Path to configuration file
    config_path = os.path.join(os.path.dirname(__file__), 'json', 'config.json')
    
    if not os.path.exists(config_path):
        print("Configuration file not found: {}".format(config_path))
        return False
    
    try:
        # Load current configuration
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        # Check if MediLink_Config section exists
        if 'MediLink_Config' not in config:
            print("MediLink_Config section not found in configuration")
            return False
        
        # Check if endpoints section exists
        if 'endpoints' not in config['MediLink_Config']:
            print("endpoints section not found in MediLink_Config")
            return False
        
        # Check if UHCAPI section exists
        if 'UHCAPI' not in config['MediLink_Config']['endpoints']:
            print("UHCAPI section not found in endpoints")
            return False
        
        # Check if additional_endpoints section exists
        if 'additional_endpoints' not in config['MediLink_Config']['endpoints']['UHCAPI']:
            print("additional_endpoints section not found in UHCAPI")
            return False
        
        # Update the claim_summary_by_provider endpoint
        current_endpoint = config['MediLink_Config']['endpoints']['UHCAPI']['additional_endpoints'].get('claim_summary_by_provider')
        
        if current_endpoint == '/Claims/api/claim/summary/byprovider/v2.0':
            # Update to match swagger specification
            config['MediLink_Config']['endpoints']['UHCAPI']['additional_endpoints']['claim_summary_by_provider'] = '/api/claim/summary/byprovider/v2.0'
            print("Updated claim_summary_by_provider endpoint from {} to {}".format(
                current_endpoint, 
                config['MediLink_Config']['endpoints']['UHCAPI']['additional_endpoints']['claim_summary_by_provider']
            ))
        else:
            print("Current endpoint: {}".format(current_endpoint))
            print("Expected endpoint: /api/claim/summary/byprovider/v2.0")
            print("No update needed or endpoint already correct")
        
        # Save updated configuration
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
        
        print("Configuration updated successfully")
        return True
        
    except Exception as e:
        print("Error updating configuration: {}".format(e))
        return False

def main():
    """Main function"""
    print("Updating endpoint configuration to match swagger specification...")
    
    success = update_endpoint_configuration()
    
    if success:
        print("Configuration update completed successfully")
        print("The claim_summary_by_provider endpoint has been updated to match the swagger specification")
    else:
        print("Configuration update failed")
        sys.exit(1)

if __name__ == "__main__":
    main() 