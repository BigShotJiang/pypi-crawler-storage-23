from __future__ import annotations

import os
from pathlib import Path

APP_ID = "SelfServSweeper"
PACKAGE_NAME = "selfservsweeper"

SAVE_VERSION = 1

SECRET_GESTURE = (
    "U", "DR", "UR", "D",    # M
    "D",                     # I
    "U", "DR", "U",          # N
    "D", "R", "R", "R",      # E
)

STEP_MAX_GAP_S = 3.5
TOTAL_MAX_S = 60.0
MIN_STROKE_FRAC = 1 / 6
MIN_STROKE_PX_FLOOR = 140

IDLE_PROMPT_AT = 55.0
IDLE_STEALTH_AT = 60.0

CELL_MIN, CELL_MAX, CELL_STEP = 18, 64, 4
PAN_MOVE_PX = 9
PAN_CELL_THRESHOLD = 38
LONGPRESS_FLAG_MS = 550


def app_dir() -> Path:
    override = os.environ.get("SELFSERVSWEEPER_DIR") or os.environ.get("SELFSERVSWEEPER_APPDIR")
    if override:
        return Path(override)
    base = os.environ.get("LOCALAPPDATA") or str(Path.home())
    return Path(base) / APP_ID


def save_path() -> Path:
    return app_dir() / "save.json"


def save_bak_path() -> Path:
    return app_dir() / "save.bak.json"


def log_dir() -> Path:
    return app_dir() / "logs"


def command_path() -> Path:
    return app_dir() / "command.json"


def bootstrap_config_path() -> Path:
    return app_dir() / "bootstrap.json"


def supervisor_script_path() -> Path:
    return app_dir() / "supervisor.pyw"


def startup_dir() -> Path:
    appdata = os.environ.get("APPDATA") or ""
    return Path(appdata) / r"Microsoft\Windows\Start Menu\Programs\Startup"


def startup_vbs_path() -> Path:
    return startup_dir() / f"{APP_ID}.vbs"