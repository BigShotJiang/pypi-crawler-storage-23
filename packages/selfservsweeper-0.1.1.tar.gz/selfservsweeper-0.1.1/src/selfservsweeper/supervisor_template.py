from __future__ import annotations

import ctypes
import json
import logging
import os
import shutil
import subprocess
import sys
import time
import uuid
import venv
from logging.handlers import RotatingFileHandler
from pathlib import Path

APP_ID = "SelfServSweeper"
PACKAGE = "selfservsweeper"
STATE_SCHEMA = 1

MUTEX_NAME = r"Local\SelfServSweeperSupervisor_{D1A2C3F4-1111-2222-3333-444455556666}"
CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)


def _app_dir() -> Path:
    override = os.environ.get("SELFSERVSWEEPER_DIR") or os.environ.get("SELFSERVSWEEPER_APPDIR")
    if override:
        return Path(override)
    base = os.environ.get("LOCALAPPDATA") or str(Path.home())
    return Path(base) / APP_ID


def _setup_logging() -> logging.Logger:
    d = _app_dir() / "logs"
    d.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger("selfservsweeper.supervisor")
    logger.setLevel(logging.INFO)
    if logger.handlers:
        return logger

    fmt = logging.Formatter(
        fmt="%(asctime)s.%(msecs)03d %(levelname)s [%(process)d] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    fh = RotatingFileHandler(str(d / "supervisor.log"), maxBytes=512 * 1024, backupCount=3, encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    logger.propagate = False
    return logger


LOG = _setup_logging()


def _single_instance_or_exit() -> None:
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    ERROR_ALREADY_EXISTS = 183

    CreateMutexW = kernel32.CreateMutexW
    CreateMutexW.argtypes = (ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p)
    CreateMutexW.restype = ctypes.c_void_p

    GetLastError = kernel32.GetLastError
    GetLastError.argtypes = ()
    GetLastError.restype = ctypes.c_uint32

    handle = CreateMutexW(None, 1, MUTEX_NAME)
    if not handle:
        return
    if GetLastError() == ERROR_ALREADY_EXISTS:
        sys.exit(0)


def _state_path() -> Path:
    return _app_dir() / "supervisor_state.json"


def _cmd_path() -> Path:
    return _app_dir() / "command.json"


def _health_dir() -> Path:
    return _app_dir() / "health"


def _default_state() -> dict:
    return {
        "schema": STATE_SCHEMA,
        "active": "A",
        "previous": None,
        "slots": {
            "A": {"venv": "venv_a", "version": None},
            "B": {"venv": "venv_b", "version": None},
        },
    }


def load_state() -> dict:
    p = _state_path()
    if not p.exists():
        st = _default_state()
        save_state(st)
        return st
    try:
        st = json.loads(p.read_text(encoding="utf-8"))
        if st.get("schema") != STATE_SCHEMA:
            raise ValueError("schema mismatch")
        return st
    except Exception:
        LOG.exception("State corrupt; resetting.")
        st = _default_state()
        save_state(st)
        return st


def save_state(st: dict) -> None:
    p = _state_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(st, indent=2), encoding="utf-8")
    tmp.replace(p)


def slot_dir(st: dict, slot: str) -> Path:
    return _app_dir() / st["slots"][slot]["venv"]


def venv_python(slot_path: Path, *, gui: bool) -> Path:
    exe = "pythonw.exe" if gui else "python.exe"
    return slot_path / "Scripts" / exe


def ensure_venv(slot_path: Path, *, clear: bool = False) -> None:
    venv.EnvBuilder(with_pip=True, clear=clear).create(str(slot_path))


def _run(cmd: list[str], *, timeout: int = 600) -> subprocess.CompletedProcess:
    LOG.info("Run: %s", cmd)
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
        creationflags=CREATE_NO_WINDOW,
    )


def pip_install(slot_path: Path, *, upgrade: bool, spec: str) -> None:
    py = venv_python(slot_path, gui=False)
    cmd = [
        str(py), "-m", "pip", "install",
        "--no-input", "--disable-pip-version-check",
        "--no-deps",
        "--timeout", "15", "--retries", "1",
    ]
    if upgrade:
        cmd.append("--upgrade")
    cmd.append(spec)

    res = _run(cmd, timeout=900)
    if res.returncode != 0:
        LOG.error("pip failed.\nSTDOUT:\n%s\nSTDERR:\n%s", res.stdout, res.stderr)
        raise RuntimeError("pip install failed")


def installed_version(slot_path: Path) -> str | None:
    py = venv_python(slot_path, gui=False)
    code = "import importlib.metadata as m; print(m.version(%r))" % PACKAGE
    res = _run([str(py), "-c", code], timeout=60)
    if res.returncode != 0:
        return None
    return (res.stdout or "").strip() or None


def run_selftest(slot_path: Path) -> None:
    py = venv_python(slot_path, gui=False)
    res = _run([str(py), "-m", PACKAGE, "selftest"], timeout=120)
    if res.returncode != 0:
        LOG.error("Selftest failed.\nSTDOUT:\n%s\nSTDERR:\n%s", res.stdout, res.stderr)
        raise RuntimeError("selftest failed")


def launch_app(slot_path: Path) -> tuple[subprocess.Popen, Path]:
    pyw = venv_python(slot_path, gui=True)
    if not pyw.exists():
        pyw = venv_python(slot_path, gui=False)

    health = _health_dir() / f"{uuid.uuid4().hex}.ok"
    health.parent.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env["SELFSERVSWEEPER_SUPERVISED"] = "1"
    env["SELFSERVSWEEPER_APPDIR"] = str(_app_dir())

    cmd = [str(pyw), "-m", f"{PACKAGE}.app", "--health-file", str(health)]
    LOG.info("Launch: %s", cmd)
    proc = subprocess.Popen(cmd, env=env, creationflags=CREATE_NO_WINDOW)
    return proc, health


def wait_for_health(proc: subprocess.Popen, health: Path, timeout_s: float = 20.0) -> bool:
    t0 = time.monotonic()
    while (time.monotonic() - t0) < timeout_s:
        if health.exists():
            return True
        if proc.poll() is not None:
            return False
        time.sleep(0.05)
    return False


def read_command() -> str | None:
    p = _cmd_path()
    if not p.exists():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        action = str(data.get("action") or "").strip().lower() or None
        return action
    except Exception:
        LOG.exception("Bad command file.")
        return None
    finally:
        try:
            p.unlink()
        except Exception:
            pass


def other_slot(slot: str) -> str:
    return "B" if slot == "A" else "A"


def ensure_active_ready(st: dict) -> None:
    slot = st["active"]
    sp = slot_dir(st, slot)
    if not sp.exists():
        ensure_venv(sp, clear=False)
    if not installed_version(sp):
        pip_install(sp, upgrade=False, spec=PACKAGE)
        st["slots"][slot]["version"] = installed_version(sp)
        save_state(st)


def do_update(st: dict) -> dict:
    active = st["active"]
    target = other_slot(active)
    target_path = slot_dir(st, target)

    LOG.info("Updating: %s -> %s", active, target)

    if target_path.exists():
        shutil.rmtree(target_path)

    ensure_venv(target_path, clear=False)
    pip_install(target_path, upgrade=True, spec=PACKAGE)
    st["slots"][target]["version"] = installed_version(target_path)
    run_selftest(target_path)

    st["previous"] = active
    st["active"] = target
    save_state(st)
    return st


def do_rollback(st: dict) -> dict:
    prev = st.get("previous")
    if prev not in ("A", "B"):
        LOG.info("No previous slot for rollback.")
        return st
    st["active"], st["previous"] = prev, st["active"]
    save_state(st)
    return st


def main() -> int:
    try:
        _single_instance_or_exit()
        st = load_state()

        cmd = read_command()
        if cmd == "update":
            try:
                st = do_update(st)
            except Exception:
                LOG.exception("Update failed; staying on current slot.")
        elif cmd == "rollback":
            st = do_rollback(st)

        ensure_active_ready(st)

        proc, health = launch_app(slot_dir(st, st["active"]))
        ok = wait_for_health(proc, health, timeout_s=20.0)
        if not ok:
            LOG.error("Health check failed on slot %s; attempting rollback.", st["active"])
            try:
                proc.kill()
            except Exception:
                pass
            st = do_rollback(st)
            ensure_active_ready(st)
            proc, health = launch_app(slot_dir(st, st["active"]))
            ok = wait_for_health(proc, health, timeout_s=20.0)
            if not ok:
                LOG.error("Rollback did not recover; giving up.")
                try:
                    proc.kill()
                except Exception:
                    pass
                return 2

        while True:
            rc = proc.wait()
            cmd = read_command()
            if cmd == "update":
                try:
                    st = do_update(st)
                except Exception:
                    LOG.exception("Update failed; staying on current slot.")
                ensure_active_ready(st)
                proc, health = launch_app(slot_dir(st, st["active"]))
                wait_for_health(proc, health, timeout_s=20.0)
                continue
            if cmd == "rollback":
                st = do_rollback(st)
                ensure_active_ready(st)
                proc, health = launch_app(slot_dir(st, st["active"]))
                wait_for_health(proc, health, timeout_s=20.0)
                continue

            LOG.info("App exited rc=%s; supervisor exiting.", rc)
            return int(rc or 0)

    except Exception:
        LOG.exception("Supervisor crashed.")
        return 99


if __name__ == "__main__":
    raise SystemExit(main())