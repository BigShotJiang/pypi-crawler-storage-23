from __future__ import annotations

import json
import shutil
import subprocess
import sys
import venv
from importlib import metadata
from pathlib import Path

from .config import PACKAGE_NAME, app_dir, bootstrap_config_path, supervisor_script_path
from .logging_setup import setup_logging
from . import startup as startup_mod

_LOG = setup_logging("selfservsweeper.installer", filename="installer.log")
CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)


def _pythonw_from(python_exe: str) -> str:
    p = Path(python_exe)
    if p.name.lower() == "pythonw.exe":
        return str(p)
    if p.name.lower() == "python.exe":
        candidate = p.with_name("pythonw.exe")
        if candidate.exists():
            return str(candidate)
    return python_exe


def _run(cmd: list[str], *, timeout: int = 180) -> subprocess.CompletedProcess:
    _LOG.info("Running: %s", cmd)
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, creationflags=CREATE_NO_WINDOW)


def _copy_supervisor_template() -> None:
    src = Path(__file__).with_name("supervisor_template.py")
    dst = supervisor_script_path()
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)


def write_bootstrap_config(base_python: str | None = None) -> dict:
    base_python = base_python or sys.executable
    cfg = {
        "schema": 1,
        "base_python": base_python,
        "base_pythonw": _pythonw_from(base_python),
        "package": PACKAGE_NAME,
    }
    p = bootstrap_config_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    return cfg


def ensure_venv(slot_dir: Path, *, clear: bool = False) -> Path:
    builder = venv.EnvBuilder(with_pip=True, clear=clear)
    builder.create(str(slot_dir))
    py = slot_dir / "Scripts" / "python.exe"
    if not py.exists():
        raise FileNotFoundError(f"Venv python not found: {py}")
    return py


def pip_install(python_exe: Path, spec: str) -> None:
    cmd = [
        str(python_exe), "-m", "pip", "install",
        "--no-input", "--disable-pip-version-check",
        "--no-deps",
        "--timeout", "15", "--retries", "1",
        spec,
    ]
    res = _run(cmd, timeout=900)
    if res.returncode != 0:
        _LOG.error("pip failed:\nSTDOUT:\n%s\nSTDERR:\n%s", res.stdout, res.stderr)
        raise RuntimeError("pip install failed")


def install(*, enable_startup: bool = False, clear_existing_venv: bool = False) -> None:
    ad = app_dir()
    ad.mkdir(parents=True, exist_ok=True)

    _copy_supervisor_template()
    cfg = write_bootstrap_config()

    venv_a = ad / "venv_a"
    py_a = ensure_venv(venv_a, clear=clear_existing_venv)

    current_version = metadata.version(PACKAGE_NAME)
    pip_install(py_a, f"{PACKAGE_NAME}=={current_version}")

    if enable_startup:
        startup_mod.enable(cfg["base_pythonw"], supervisor_script_path())

    _LOG.info("Install complete. App dir: %s", ad)