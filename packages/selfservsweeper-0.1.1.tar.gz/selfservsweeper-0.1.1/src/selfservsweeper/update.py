from __future__ import annotations

import json
import subprocess
import sys
from importlib import metadata
from typing import Optional

from .config import PACKAGE_NAME

CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)


def current_version() -> str:
    try:
        return metadata.version(PACKAGE_NAME)
    except metadata.PackageNotFoundError:
        return "0.0.0"


def pip_latest_version(python_exe: str | None = None, *, timeout: int = 25) -> tuple[str, Optional[str], Optional[str]]:
    python_exe = python_exe or sys.executable
    installed = current_version()

    cmd = [python_exe, "-m", "pip", "list", "--outdated", "--format=json", "--disable-pip-version-check"]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, creationflags=CREATE_NO_WINDOW)
    except Exception as e:
        return installed, None, str(e)

    if res.returncode != 0:
        err = (res.stderr or res.stdout or "").strip()
        return installed, None, (err or f"pip exited {res.returncode}")

    try:
        data = json.loads(res.stdout or "[]")
    except Exception as e:
        return installed, None, f"Could not parse pip output: {e}"

    for item in data:
        if str(item.get("name", "")).lower() == PACKAGE_NAME.lower():
            latest = str(item.get("latest_version") or "").strip() or None
            return installed, latest, None

    return installed, None, None