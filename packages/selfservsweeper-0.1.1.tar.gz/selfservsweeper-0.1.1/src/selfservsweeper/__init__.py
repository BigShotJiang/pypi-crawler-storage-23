from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

from .config import PACKAGE_NAME

try:
    __version__ = version(PACKAGE_NAME)
except PackageNotFoundError:
    __version__ = "0.0.0"