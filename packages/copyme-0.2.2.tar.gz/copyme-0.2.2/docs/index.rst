.. rename title [CHANGE THIS]:

.. _home:

Copyme
############################################

.. adapt this welcoming message [CHANGE THIS]:

Welcome to ``copyme`` documentation! A simple template for python development.

Contents
********************************************

.. list all pages it must contain in the home page [CHANGE THIS]:

.. toctree::
   :maxdepth: 1

   Home <self>
   about
   usage
   api
   development
   dummy
