"""Translation API communication layer."""
