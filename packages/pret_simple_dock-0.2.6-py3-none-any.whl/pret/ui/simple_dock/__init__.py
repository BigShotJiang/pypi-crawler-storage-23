"""
Backward compatibility shim for the previous `pret.ui.simple_dock` import path.
"""
from pret_simple_dock import *  # noqa: F401,F403
