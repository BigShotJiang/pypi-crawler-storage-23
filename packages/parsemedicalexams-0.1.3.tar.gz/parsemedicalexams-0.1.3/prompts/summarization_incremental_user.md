Update the following clinical summary by incorporating additional exam transcriptions.
The existing summary covers exams already processed. Integrate the new exam data below, preserving ALL clinically relevant details from both the existing summary and the new transcriptions.

EXISTING SUMMARY:
{existing_summary}

NEW EXAMS ({new_exam_count} additional):
{new_exam_list}

NEW TRANSCRIPTIONS:
{new_transcriptions}

UPDATED CLINICAL SUMMARY (comprehensive, in English, preserving all clinical details from both existing summary and new exams):
