Classify these exam names:

{exam_names}

Return a JSON object mapping each raw name to its classification.
