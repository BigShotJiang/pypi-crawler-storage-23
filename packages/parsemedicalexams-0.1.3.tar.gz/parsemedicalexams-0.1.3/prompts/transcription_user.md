Transcribe ALL text from this page EXACTLY as it appears.

CRITICAL:
- Transcribe ONLY what is visible - NEVER guess or invent text
- Preserve original layout (line breaks, spacing, indentation)
- Do NOT translate, correct, or improve the text
- Mark unclear text as [illegible]

Output the complete verbatim transcription of this page.
