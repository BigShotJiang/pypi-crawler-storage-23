Create a comprehensive clinical summary from the following medical exam transcriptions.

This summary will be part of a patient's permanent medical health record. Preserve ALL clinically relevant details - nothing should be lost.

DOCUMENT CONTAINS {exam_count} EXAM(S):
{exam_list}

TRANSCRIPTIONS:
{transcriptions}

CLINICAL SUMMARY (comprehensive, in English, preserving all clinical details):
