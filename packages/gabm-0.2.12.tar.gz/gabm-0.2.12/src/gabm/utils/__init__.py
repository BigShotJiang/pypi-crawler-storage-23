"""GABM: Generative Agent-Based Model framework utils
 package."""
__version__ = "1.0.0"