# -*- coding: utf-8 -*-
"""
@Author    : limo
@Date      : 2026/1/27 13:55
@FileName  : ijb_util.py
@Software  : PyCharm
@Describe  : 
"""
from kyutil.rpms import get_nvr


def process_upgrade_item(item):
    """
    处理升级项
    """
    iso_nvr = str(item.get('iso_nvr', ''))
    ijo_nvf = str(item.get('ijo_nvf', ''))
    reason = "邮件入库" if 'kernel' in iso_nvr else ""
    return f"{ijo_nvf}->{iso_nvr} {reason}"


def process_downgrade_item(item):
    """
    处理降级项
    """
    iso_nvr = str(item.get('iso_nvr', ''))
    ijo_nvf = str(item.get('ijo_nvf', ''))
    return f"{ijo_nvf}->{iso_nvr}"


def process_delete_item(item, black_list_more, ks_less):
    """
    处理删除项
    """
    ijo_nvf = str(item.get('ijo_nvf', ''))
    reason = ""
    pkg_name = get_nvr(ijo_nvf)[0]
    try:
        if pkg_name in black_list_more:
            reason = " 加入黑名单"

        if not reason and ks_less and pkg_name in ks_less:
            reason = "KS删除"
    except Exception:
        # 忽略解析错误
        pass
    return ijo_nvf + reason


def process_add_item(item, black_list_less, ks_more):
    """
    处理新增项
    """
    iso_nvr = str(item.get('iso_nvr', ''))
    reason = ""
    pkg_name = get_nvr(iso_nvr)[0]
    try:
        if pkg_name in black_list_less:
            reason = " 从黑名单去除"
        if not reason and ks_more and pkg_name in ks_more:
            reason = "KS新增"
    except Exception:
        # 忽略解析错误
        pass
    return iso_nvr + reason


def merge_multi_line(_data_list_sub: list):  # 传入参数为二维
    """
    将多行数据合并成一行，重复的去除掉
    Args:
        _data_list_sub: [
                            ["a", "b", "c"],
                            ["a", "o", "c"],
                            ["g", "0", "b"]
                        ]
    Returns:
        ['g\na', '0\no\nb', 'c\nb']
    """
    if not _data_list_sub:
        return []

    _data_list_merge = []
    for j in range(len(_data_list_sub[0])):
        data_set = set()
        for _data_line in _data_list_sub:
            if _data_line[j]:
                data_set.add(str(_data_line[j]).strip() if _data_line[j] else '')
        _data_list_merge.append("\n".join(data_set))
    return _data_list_merge  # 一维


def get_ks_list_changes(iso, base_iso):
    """
    获取2个ISO的KS的差异
    Args:
        iso:
        base_iso:

    Returns:
        ks_more, ks_less
    """
    more, less = list(set(iso.ks_packages) - set(base_iso.ks_packages)), list(set(base_iso.ks_packages) - set(iso.ks_packages))
    # 去掉架构
    more = [i.split(".")[0] for i in less]
    less = [i.split(".")[0] for i in less]
    return more, less
