# -*- coding:utf-8 -*-
"""client iso integration build module"""

from .isobuild_7 import ReleaseOSEl7


class ReleaseOSNS6(ReleaseOSEl7):
    """7系集成构建类"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # 父类初始化
        self.init_run_env_base()
        # 7系构建过程目录
        self.output_inmock = f"{self.build_inmock}/{self.params.get('release')}/{self.params.get('target_arch')}/os"
        self.isos_inmock = f"{self.build_inmock}/{self.params.get('release')}/{self.params.get('target_arch')}/iso"
        # 7系通用构建参数
        _debug = '--nodebuginfo'
        _source = '--nosource' if self.params.get('debugsource') != 'True' else ''
        self.pungi_str = f"pungi --force {_debug} {_source} "
        self.pungi_args = self.params.get('pungi_cmd') if self.params.get('pungi_cmd') else \
            f"{self.pungi_str} -c /root/{self.ks_file} --name \'{self.params.get('product_name')}\' " \
            f"--ver \'{self.params.get('release')}\' --release \'{self.params.get('build')}\' " \
            f"--bugurl \'{self.params.get('bugzilla_url')}\' " \
            f"--destdir={self.build_inmock} "
        self.iso_name = self.params.get('iso_name') if self.params.get('iso_name') else \
            f"{self.params.get('release')}-{self.params.get('target_arch')}" \
            f"-{self.params.get('build')}-{self.cur_day}.iso"
        self._init_run_env_7()
        self._update_celery(f"{self.series}构建环境init初始化完成", self.process, None)
