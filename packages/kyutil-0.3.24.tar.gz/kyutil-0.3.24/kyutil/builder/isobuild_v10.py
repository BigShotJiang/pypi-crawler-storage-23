# -*- coding:utf-8 -*-
"""client iso integration build module"""
import subprocess

from .build_ns8 import ReleaseOSEl8
from kyutil.config import LINE_QEMU_NET, PYTHON_MINOR_CMD, SOURCE_PATH
from kyutil.download import wget_remote_dirs
from kyutil.file import copy_dirs, delete_dirs, file_str_switch
from kyutil.mock import into_chroot_env, exit_chroot_env
from kyutil.release_bugfix import ReleaseBugfix
from kyutil.shell import run_command


class ReleaseOSV10SP1(ReleaseOSEl8, ReleaseBugfix):
    """V10SP1构建类，独立于8系的特殊构建方法"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.series = "V10-SP1"

    def modify_dracut_args(self, new_str):
        into_chroot_env(self.build_mockroot)
        process = subprocess.Popen(PYTHON_MINOR_CMD, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd='/usr/bin/')
        out = process.stdout.readline()
        minor = out.decode(encoding='utf-8', errors='ignore') if isinstance(out, bytes) else str(out)
        if not minor:
            raise RuntimeError("无法获取mock内 python版本")
        file_str_switch(f"/usr/lib/python3.{minor.strip()}/site-packages/pylorax/__init__.py", LINE_QEMU_NET, new_str, \
                        _logger=self.build_logger, reason='dracut 参数特殊配置')
        exit_chroot_env()

    def mock_pungi_lorax(self):
        """
        重写父类的lorax构建方法
        Returns:

        """
        self.build_logger.info(f"【Step-05/11】: {self.series} Mock内执行lorax-创建启动文件")
        self._update_status(f"{self.series} Mock内执行lorax-创建启动文件", 60, None)

        new_str = ""
        # 0711 iso dracut 参数特殊配置
        if self.params.get('tag').startswith("v10-sp1") or self.params.get('tag').startswith("v10-sp3"):
            new_str = '        anaconda_args = dracut_args + ["--add", "anaconda pollcdrom qemu qemu-net prefixdevname-tools"]'
        # 敏感词修复时/激活等，解决SP1 SP2 无 prefixdevname-tools 的问题。
        if self.params.get('tag').startswith("v10-sp1.1-") or self.params.get('tag').startswith("v10-sp2-"):
            new_str = '        anaconda_args = dracut_args + ["--add-drivers", "ngbe", "--add-drivers", "txgbe", "--add", "anaconda pollcdrom qemu qemu-net prefixdevname-tools"]'
        if new_str:
            into_chroot_env(self.build_mockroot)
            self.modify_dracut_args(new_str)
            exit_chroot_env()

        # 预定义lorax结果
        if self.params.get('boot_dir') and len(self.params.get('boot_dir')) > 0:
            self._update_status(
                f"从{self.params.get('boot_dir')}复制boot启动文件", self.process, None)
            wget_remote_dirs(self.build_logger, self.params.get('boot_dir'), self.boot_file)
            copy_dirs(self.boot_file, f"{self.build_mockroot}{self.build_inmock}/lorax/outfiles/", self.build_logger)
        else:
            into_chroot_env(self.build_mockroot)
            ok = run_command(self.get_lorax_cmd(), self.build_logger, f"{self.series} lorax执行失败")
            self.command_logger.info(f'【CMD】执行lorax制作镜像内images\t命令:{self.get_lorax_cmd()}\t状态:{ok}')
            if ok:
                raise RuntimeError(f"{self.series} lorax执行失败")
            exit_chroot_env()

    def fix_process_file(self):
        super().fix_process_file()
        # #6 sp3不支持capser兼容操作，kernel版本>=4.19.90-40.0.v2207
        if self.params.get('tag').startswith('v10-sp1') or self.params.get('tag').startswith('v10-sp2'):
            self.import_capser_sp()
        else:
            delete_dirs(f"{self.build_mockroot}{self.build_inmock}/capser", self.build_logger)
            self.command_logger.info(f'【DELETE】将"{self.build_mockroot}{self.build_inmock}/capser" 删除')
            delete_dirs(f"{self.build_mockroot}{self.build_inmock}/repo_bak.sh", self.build_logger)
            self.command_logger.info(f'【DELETE】将"f"{self.build_mockroot}{self.build_inmock}/repo_bak.sh" 删除')


class ReleaseOSV10SP2(ReleaseOSV10SP1):
    """V10SP2独立于8系的特殊构建方法"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.series = "V10-SP2"


class ReleaseOSV10SP3(ReleaseOSV10SP1):
    """V10SP3独立于8系的特殊构建方法"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.series = "V10-SP3"


class ReleaseOSMips(ReleaseOSV10SP1, ReleaseBugfix):
    """Mips构建类"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.series = "V10-MIPS"

    def mock_pungi_lorax(self):
        """mips架构lorax构建方法"""
        self._update_status("Mips-mock内lorax生成启动文件SP", 60, None)
        log_name_standard = f"lorax-{self.task_id[0:4]}.log"
        # 复制boot启动文件而非自动生成
        if self.params.get('boot_dir') is not None and len(self.params.get('boot_dir')) > 0:
            self._update_status(f"从{self.params.get('boot_dir')}复制boot启动文件", self.process, None)
            wget_remote_dirs(self.build_logger, self.params.get('boot_dir'), self.boot_file)
            copy_dirs(self.boot_file, f"{self.build_mockroot}{self.build_inmock}/lorax/outfiles/", self.build_logger)
        else:
            if self.params.get('lorax_cmd'):
                lorax_cmd = f"cd {self.build_inmock}/lorax; {self.params.get('lorax_cmd')}"
            else:
                # 当8系主机切换为sp1的时候，需要添加参数--old-chroot,并切换为主机mock执行
                lorax_cmd = "cd %s/lorax; lorax --noupgrade -p \'%s\' -v \'%s\' -r \'%s\' \
                    --isfinal --noverifyssl --nomacboot --volid=\'%s\' \'%s\' --force %s/lorax/outfiles " % (
                    self.build_inmock, self.params.get("product_name"), self.params.get("version"),
                    self.params.get("release"), self.params.get("volid"), self.gen_lorax_source_cmd(), self.build_inmock)
            into_chroot_env(self.build_mockroot)
            run_command(lorax_cmd, error_message="mips lorax执行失败")
            exit_chroot_env()
            copy_dirs(f"{self.build_mockroot}{self.build_inmock}/lorax/lorax.log",
                      f"{self.build_log}/{log_name_standard}", self.build_logger)

    def fix_process_file(self):
        super().fix_process_file()
        self.cut_initrd(config_fp=f"{SOURCE_PATH}/src/build/mips/mips_initrd.yaml")


class ReleaseOSLoong(ReleaseOSV10SP1):
    """
    Loong构建类，注意：不签名，mash源有误
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.series = "V10-LOONGARCH64"

    def mock_pungi_lorax(self):
        """loong架构lorax构建方法"""
        self._update_status("Loong-mock内lorax生成启动文件SP", 60, None)
        log_name_standard = "lorax-%s.log" % self.task_id[0:4]
        if self.params.get('boot_dir') is not None and len(self.params.get('boot_dir')) > 0:
            self._update_status("远程复制boot启动文件", self.process, None)
            wget_remote_dirs(self.build_logger, self.params.get('boot_dir'), self.boot_file)
            copy_dirs(self.boot_file, f"{self.build_mockroot}{self.build_inmock}/lorax/outfiles/", self.build_logger)
        else:
            if self.params.get('lorax_cmd'):
                lorax_cmd = f"cd {self.build_inmock}/lorax; {self.params.get('lorax_cmd')}"
            else:
                lorax_cmd = "cd %s/lorax; lorax -p \'%s\' -v \'%s\' -r \'%s\' \
                    --force --rootfs-size=5 --noverifyssl --isfinal --nomacboot --volid=\'%s\' %s  %s/lorax/outfiles " % (
                    self.build_inmock, self.params.get("product_name"), self.params.get("version"),
                    self.params.get("release"), self.params.get("volid"), self.gen_lorax_source_cmd(), self.build_inmock)
            if self.lorax_templates_url.find("oemaker") >= 0:
                lorax_cmd = lorax_cmd + " --sharedir /opt/oemaker/80-kylin"
            into_chroot_env(self.build_mockroot)
            run_command(lorax_cmd, error_message="loong lorax执行失败")
            exit_chroot_env()
            copy_dirs(f"{self.build_mockroot}{self.build_inmock}/lorax/lorax.log",
                      f"{self.build_log}/{log_name_standard}", self.build_logger)
