# -*- coding:utf-8 -*-
"""client iso integration build module"""
import os
import subprocess

from kyutil.build_base import ReleaseOSBase
from kyutil.config import PYTHON2_MINOR_CMD
from kyutil.download import wget_remote_dirs
from kyutil.file import copy_dirs, delete_dirs, file_str_switch, ensure_dir, get_xml_file
from kyutil.mock import into_chroot_env, exit_chroot_env
from kyutil.rpms import common_split_filename
from kyutil.shell import run_command, run_command_with_return


class ReleaseOSEl7(ReleaseOSBase):
    """7系集成构建类"""
    # pungi通用命令示例
    _str = 'pungi --force --nosource --nodebuginfo --isfinal --nohash --nogreedy --full-archlist'

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.series = "NS7"
        # 父类初始化
        self.init_run_env_base()
        # 7系构建过程目录
        self.output_inmock = f"{self.build_inmock}/{self.params.get('release')}/{self.params.get('target_arch')}/os"
        self.isos_inmock = f"{self.build_inmock}/{self.params.get('release')}/{self.params.get('target_arch')}/iso"
        # 7系通用构建参数
        _debug = '--nodebuginfo'
        _source = '--nosource' if self.params.get('debugsource') != 'True' else ''
        self.pungi_str = f"pungi --force {_debug} {_source} --isfinal --nohash --nogreedy --full-archlist"
        self.pungi_args = self.params.get('pungi_cmd') or \
                          f"{self.pungi_str} -c /root/{self.ks_file} --name \'{self.params.get('product_name')}\' " \
                          f"--ver \'{self.params.get('release')}\' --release \'{self.params.get('build')}\' " \
                          f"--volid \'{self.params.get('volid')}\' --bugurl \'{self.params.get('bugzilla_url')}\' " \
                          f"--destdir={self.build_inmock} "
        self.iso_name = self.params.get('iso_name') or \
                        f"{self.params.get('release')}-{self.params.get('target_arch')}" \
                        f"-{self.params.get('build')}-{self.cur_day}.iso"
        self._init_run_env_7()
        self._update_status(f"{self.series}构建环境init初始化完成", self.process, None)

    def _init_run_env_7(self):
        """获取7系配置参数，初始化目录"""
        self.process = 10
        self._update_status(f"{self.series}构建参数获取完成", self.process, None)

    def mock_pungi_gather(self):
        """7系-pungi -G收集包"""
        self.process = 40
        self.build_logger.info(f"【Step-02.5/11】: {self.series} 修改pungi-gather源码,支持SSL")
        new_str = '    sslverify = BoolOption(False)\n'
        into_chroot_env(self.build_mockroot)
        process = subprocess.Popen(PYTHON2_MINOR_CMD, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd='/usr/bin/')
        out = process.stdout.readline()
        minor = out.decode(encoding='utf-8', errors='ignore') if isinstance(out, bytes) else str(out)
        if not minor:
            raise RuntimeError("无法获取mock内 python版本")
        file_str_switch(f"/usr/lib/python2.{minor.strip()}/site-packages/yum/config.py",
                        "    sslverify = BoolOption(True)", new_str, reason="修改pungi-gather源码,支持SSL")
        exit_chroot_env()

        self._update_status(f"{self.series} mock内执行pungi-G-收集包", self.process, None)
        self._update_status(f"{self.ks_file}中修改repo地址", self.process, None)
        for i, repo in enumerate(self.mash_httpd_path.split("\n")):
            file_str_switch(f"{self.build_cfg_dir}/{self.ks_file}", "%packages",
                            f"repo --name={self.params.get('tag')}-{i} --baseurl={repo}\n%packages\n", _logger=self.build_logger)
        ks_source = os.path.join(self.build_cfg_dir, self.ks_file)
        if os.path.isfile(ks_source):
            copy_dirs(ks_source, os.path.join(self.build_mockroot, 'root', self.ks_file), self.build_logger)
            cmd1 = f'/usr/bin/mock -r {self.build_mocktag} --chroot "{self.pungi_args} -G" --enable-network '
            _cmd1 = f"su - {self.user} <<EOF\n {cmd1} \nEOF"
            run_command(_cmd1, self.build_logger, "pungi -G收集包失败")
            # self.check_rpm(f"{self.build_mockroot}{self.output_inmock}/Packages")
            into_chroot_env(self.build_mockroot)
            run_command("mount -t proc proc /proc", error_message=f"{self.series} pungi -G收集包失败")
            exit_chroot_env()

    def download_not_boot_file(self):
        """
        Step-5.5 7系copy_dirs失败问题
        Returns:

        """
        self.build_logger.info("开始下载 非启动文件")
        for u in self.params.get('not_boot_dir').split("\n"):
            if u and u.strip():
                wget_remote_dirs(self.build_logger, u, self.not_boot_file)
                self.download_post_action(u)
        ensure_dir(f"{self.build_mockroot}{self.os_patch_inmock}")
        cmd = f'cp -avr {self.not_boot_file}/* "{self.build_mockroot}{self.os_patch_inmock}"'
        rc = run_command_with_return(cmd, self.build_logger, "非启动文件复制失败")
        if not rc[0]:
            raise RuntimeError(f"非启动文件复制失败: {rc}")
        for p in ["/.kyinfo", "/.post/"]:
            cmd = f'cp -avr {self.not_boot_file}{p} "{self.build_mockroot}{self.os_patch_inmock}"'
            run_command_with_return(cmd, self.build_logger, "非启动文件[.kyinfo]复制失败")
        self.check_addon_dep()

    def mock_create_repo(self):
        """7系pungi-C创建本地源"""
        self.process = 50
        self._update_status(f"{self.series} mock内执行pungi -C 创建源", self.process, None)
        if self.params.get('before_repo_package'):
            wget_remote_dirs(self.build_logger, self.params.get('before_repo_package'), self.before_repo_package)
            copy_dirs(self.before_repo_package, f"{self.build_mockroot}{self.output_inmock}/Packages", self.build_logger)
        if self.params.get('replace_comps') == 'True':
            # pungi -G 之后会在 /root/buildiso/work/ARCH/目录下生成带空格的comps文件。
            comps_path = get_xml_file(f"{self.build_mockroot}{self.build_inmock}/work/{self.params.get('target_arch')}/")
            if comps_path:
                # 替换原有comps
                self.build_logger.info(f"{self.series} 替换comps文件")
                copy_dirs(os.path.join(self.build_cfg_dir, self.comps_file), comps_path, self.build_logger)
                # move_dirs(comps_path, comps_path.replace(" ", "-"))
            else:
                # 没有comps创建comps
                self.build_logger.info(f"{self.series} 创建comps文件")
                copy_dirs(os.path.join(self.build_cfg_dir, self.comps_file),
                          f"{self.build_mockroot}{self.build_inmock}/work/{self.params.get('target_arch')}/"
                          f"{self.params.get('product_name').replace(' ', '-')}-{self.params.get('release').replace(' ', '-')}-comps.xml", self.build_logger)
        else:
            if not os.path.isfile(f"{self.build_mockroot}/root/{self.comps_file}"):
                copy_dirs(os.path.join(self.build_cfg_dir, self.comps_file), f"{self.build_mockroot}/root/{self.comps_file}", self.build_logger)
                self.build_logger.info(f"{self.series} comps文件从mnt目录移动到了mock环境里:{self.build_mockroot}/root/{self.comps_file}")
        cmd = f'/usr/bin/mock -r {self.build_mocktag} --chroot "{self.pungi_args} -C"'
        _cmd = f"su - {self.user} <<EOF\n {cmd} \nEOF"
        run_command(_cmd, self.build_logger, "pungi -C 创建源失败")
        if self.params.get('after_repo_package'):
            # 复制after_repo_package目录
            wget_remote_dirs(self.build_logger, self.params.get('after_repo_package'), self.after_repo_package)
            copy_dirs(self.after_repo_package, f"{self.build_mockroot}{self.output_inmock}/Packages", self.build_logger)

    def mock_pungi_lorax(self):
        """#5 7系-pungi-B创建启动文件"""
        self.process = 60
        self.build_logger.info(f"【Step-03.5/11】: {self.series} pungi -B 创建启动文件/修改 pungi-gather 源码")

        # 修复无法 umount的错误，直接返回
        new_str = '    return 1\n'
        into_chroot_env(self.build_mockroot)
        process = subprocess.Popen(PYTHON2_MINOR_CMD, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd='/usr/bin/')
        out = process.stdout.readline()
        minor = out.decode(encoding='utf-8', errors='ignore') if isinstance(out, bytes) else str(out)
        if not minor:
            raise RuntimeError("无法获取mock内 python版本")
        file_str_switch(f"/usr/lib/python2.{minor.strip()}/site-packages/pylorax/imgkyutil.py",
                        "    umount = [\"umount\"]", new_str, reason="修复卸载失败的问题")
        exit_chroot_env()

        self._update_status(f"{self.series} mock内执行pungi-B-创建启动文件", self.process, None)
        if self.params.get('boot_dir') and len(self.params.get('boot_dir')) > 0:
            self._update_status(
                f"从{self.params.get('boot_dir')}复制boot启动文件用于构建", self.process, None)
            wget_remote_dirs(self.build_logger, self.params.get('boot_dir'), self.boot_file)
            copy_dirs(self.boot_file, f"{self.build_mockroot}{self.output_inmock}", self.build_logger)
        else:
            # 执行pungi -B ??--old-chroot
            cmd = f'/usr/bin/mock -r {self.build_mocktag} --chroot "{self.pungi_args} -B " --enable-network'
            _cmd = f"su - {self.user} <<EOF\n {cmd} \nEOF"
            into_chroot_env(self.build_mockroot)
            rc = run_command(f"{self.pungi_args} -B", self.build_logger,
                             f"{self.series} lorax 执行失败")
            run_command("umount /proc", error_message="mount proc失败")
            if rc:
                raise RuntimeError(f"{self.series} lorax 执行失败 : {rc}")
            exit_chroot_env()
            copy_dirs(f"{self.build_mockroot}{self.build_inmock}/logs", self.build_log, self.build_logger)

    def fix_process_file(self):
        """7系定制修改lorax启动文件"""
        # self.insert_grub_ks_cmd(self.build_mockroot + self.output_inmock)
        delete_dirs(f"{self.build_mockroot}{self.output_inmock}/.olddata", self.build_logger)
        delete_dirs(f"{self.build_mockroot}{self.output_inmock}/repoview", self.build_logger)

    def write_productinfo(self):
        """7系生成.productinfo文件
        Kylin Linux Advanced Server
        release V10 (SP2)/(Sword)-x86_64-Build09/20210524
        """
        self.product_file = f"{self.build_mockroot}{self.output_inmock}/.productinfo"
        self.write_productinfo2file(self.product_file)

    def create_package_files(self):
        self._update_status("生成packages列表以及sha256sum列表", self.process, None)
        package_dir = self.output_inmock
        pkg_list = f"{self.isos_inmock}/%s" % '-'.join([self.iso_name.strip('.iso'), f'{self.target_arch}-packages.txt'])
        pkg_sum = f"{self.isos_inmock}/%s" % '-'.join([self.iso_name.strip('.iso'), 'packages.sha256sum'])
        self.create_package_list(package_dir, pkg_list)
        self.create_package_sum(package_dir, pkg_sum)
        self.create_env_package_list()

    def mkisofs_iso_file(self):
        """7系pungi-I集成iso文件"""
        self.iso_file_check()
        self.process = 80
        cmd = f'/usr/bin/mock -r {self.build_mocktag} --chroot "{self.pungi_args} -I"'
        _cmd = f"su - {self.user} <<EOF\n {cmd} \nEOF"
        rc = run_command(_cmd, self.build_logger, "pungi -I 集成ISO失败")
        if rc:
            raise RuntimeError("pungi -I 集成ISO失败")

    # 备份及检查工作
    def copy_iso(self):
        """7系拷贝iso文件步骤"""
        self.process = 90
        self._update_status("拷贝ISO文件至本地构建目录", self.process, None)
        isos_dir = f"{self.build_mockroot}{self.isos_inmock}"
        self.copy_iso_to_dir(isos_dir)
        for f in os.listdir(self.build_isos):
            # 删除netinst.iso文件
            if "md5" in f or "CHECKSUM" in f:
                os.remove(os.path.join(self.build_isos, f))
            # iso文件更名
            elif f.endswith('.iso') and f.find('netinst') == -1:
                os.rename(os.path.join(self.build_isos, f), os.path.join(self.build_isos, self.iso_name))
            # netinst iso文件更名
            elif f.endswith('.iso') and "netinst" in f:
                os.rename(os.path.join(self.build_isos, f),
                          f"{self.build_isos}/{self.iso_name.strip('.iso')}-netinst.iso")
        self.create_manifest()

    def copy_lorax_log(self):
        lorax_path = f"{self.build_mockroot}/root/buildiso/logs"
        self.build_logger.info(f"{self.series} 收集lorax日志,源目录 {lorax_path}存在：{os.path.isdir(lorax_path)}")
        if not os.path.isdir(self.build_log + os.sep + "lorax"):
            os.makedirs(self.build_log + os.sep + "lorax")
        self.build_logger.info(
            f"{self.series} 收集lorax日志,目的目录 {self.build_log + os.sep}lorax 存在："
            f"{os.path.isdir(self.build_log + os.sep + 'lorax')}")
        copy_dirs(f"{lorax_path}", self.build_log + os.sep + 'lorax', self.build_logger)

    def check_ks_and_package(self):
        """检查ks文件和packages列表是否一致 """
        if all([os.path.isfile(self.ks_file_path),
                os.path.isfile(self.build_isos + os.sep + os.path.basename(self.pkg_list))]):
            file_ = open(self.ks_file_path, "r", encoding="utf-8")
            ks_list = file_.read().split("\n")[2:]
            ks_list = list(filter(lambda x: len(x), ks_list))[:-1]
            ks_list = set(ks_list)
            file_.close()

            file_ = open(self.build_isos + os.sep + os.path.basename(self.pkg_list), "r")
            pkgs_list = file_.read().split("\n")
            pkgs_list = [len(x) for x in pkgs_list]
            pkgs_list = [(parts := common_split_filename(x))[0] + "." + parts[4] for x in pkgs_list]
            pkgs_list = set(pkgs_list)
            file_.close()
            if ks_list != pkgs_list:
                self.build_logger.error("Ks文件和软件包列表校验【不】通过。")
                open(self.build_warn_file, "a", encoding="utf-8").write(f"KS文件多了：{ks_list - pkgs_list}\n")
                open(self.build_warn_file, "a", encoding="utf-8").write(f"KS文件少了：{pkgs_list - ks_list}\n")
            else:
                self.build_logger.info("ks文件和软件包列表校验通过")
        else:
            self.build_logger.warning(
                f"ks:{self.ks_file_path}。pkg:{os.path.isfile(self.build_isos + os.sep + os.path.basename(self.pkg_list))}")
            self.build_logger.warning("ks文件或者软件包列表文件不存在，无法对包列表是否一致进行检测。")

    def get_nkvers_info(self):
        """
        7系获取系统的nkvers信息
        Returns:
        """
        try:
            self.build_logger.info(f"{self.series} Mock内执行命令：nkvers")
            into_chroot_env(self.build_mockroot)
            run = run_command_with_return("nkvers", self.build_logger, "获取nkvers失败")
            if run[0]:
                self.nkvers = run[1].decode("utf-8")
                self.build_logger.info(f"nkvers信息是：\n{self.nkvers}")
            exit_chroot_env()
        except Exception as e1:
            self.build_logger.error(f"获取系统nkvers信息失败, {e1}")


class ReleaseOSMipsV7(ReleaseOSEl7):
    """Mips构建类"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
