# -*- coding:utf-8 -*-
"""client iso integration build module"""
from .isobuild_v10 import ReleaseOSV10SP3


class ReleaseOSV11(ReleaseOSV10SP3):
    """V10SP3独立于8系的特殊构建方法"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.series = "HPC"

    def get_lorax_cmd(self):
        return super().get_lorax_cmd() + "--sharedir /opt/oemaker/80-kylin"

    def mock_pungi_lorax(self):
        """v11系-pungi-lorax构建方法"""
        self.mount_proc_system()
        try:
            super().mock_pungi_lorax()
        except Exception as e:
            self.build_logger.error(f"lorax生成失败！ 具体原因是{e}")
            raise RuntimeError(f"lorax生成失败！ 具体原因是{e}")
        finally:
            self.umount_proc_system()
