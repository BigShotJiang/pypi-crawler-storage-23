"""Workspace abstractions for sharing files between world and agent VMs."""

from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from plato.v2.async_.environment import Environment

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Subprocess helpers
# ---------------------------------------------------------------------------


async def _run_local(command: str, timeout: int = 60) -> tuple[int, str, str]:
    """Run a command locally as a subprocess."""
    proc = await asyncio.create_subprocess_exec(
        "bash",
        "-c",
        command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        raise RuntimeError(f"Command timed out after {timeout}s: {command[:100]}")
    return proc.returncode or 0, stdout.decode(), stderr.decode()


async def _run_ssh(
    ssh_key_path: Path,
    hostname: str,
    command: str,
    timeout: int = 60,
) -> tuple[int, str, str]:
    """Run a command on a remote VM via SSH."""
    ssh_cmd = [
        "ssh",
        "-i",
        str(ssh_key_path),
        "-o",
        "StrictHostKeyChecking=no",
        "-o",
        "UserKnownHostsFile=/dev/null",
        "-o",
        "LogLevel=ERROR",
        f"root@{hostname}",
        command,
    ]
    proc = await asyncio.create_subprocess_exec(
        *ssh_cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        raise RuntimeError(f"SSH command timed out after {timeout}s: {command[:100]}")
    return proc.returncode or 0, stdout.decode(), stderr.decode()


# ---------------------------------------------------------------------------
# Rsync helpers (used by RsyncWorkspace and PlatoVMRuntime for code sync)
# ---------------------------------------------------------------------------


async def rsync_to(
    ssh_key_path: Path,
    local_path: Path,
    remote_path: str,
    hostname: str,
    chown: str | None = None,
    max_retries: int = 3,
    retry_delay: float = 5.0,
) -> None:
    """Rsync a directory to a remote VM."""
    ssh_cmd = f"ssh -i {ssh_key_path} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR"

    cmd = [
        "rsync",
        "-az",
        "--delete",
        "--rsync-path",
        f"mkdir -p {remote_path} && rsync",
        "-e",
        ssh_cmd,
    ]
    if chown:
        cmd.extend(["--chown", chown])
    cmd.extend([f"{local_path}/", f"root@{hostname}:{remote_path}/"])

    last_error = ""
    for attempt in range(1, max_retries + 1):
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        if proc.returncode == 0:
            return

        last_error = stderr.decode()
        if attempt < max_retries:
            logger.warning(
                f"rsync to VM failed (attempt {attempt}/{max_retries}), "
                f"retrying in {retry_delay}s: {last_error.strip()}"
            )
            await asyncio.sleep(retry_delay)

    raise RuntimeError(f"rsync to VM failed after {max_retries} attempts: {last_error}")


async def rsync_from(
    ssh_key_path: Path,
    remote_path: str,
    local_path: Path,
    hostname: str,
    max_retries: int = 3,
    retry_delay: float = 5.0,
) -> None:
    """Rsync a directory from a remote VM back to local."""
    ssh_cmd = f"ssh -i {ssh_key_path} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR"

    local_path.mkdir(parents=True, exist_ok=True)

    cmd = [
        "rsync",
        "-az",
        "-e",
        ssh_cmd,
        f"root@{hostname}:{remote_path}/",
        f"{local_path}/",
    ]

    last_error = ""
    for attempt in range(1, max_retries + 1):
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        if proc.returncode == 0:
            return

        last_error = stderr.decode()
        if attempt < max_retries:
            logger.warning(
                f"rsync from VM failed (attempt {attempt}/{max_retries}), "
                f"retrying in {retry_delay}s: {last_error.strip()}"
            )
            await asyncio.sleep(retry_delay)

    raise RuntimeError(f"rsync from VM failed after {max_retries} attempts: {last_error}")


# ---------------------------------------------------------------------------
# Workspace ABC and implementations
# ---------------------------------------------------------------------------


class Workspace(ABC):
    """Abstract workspace shared between world VM and agent VMs."""

    path: str

    @abstractmethod
    async def initialize(self) -> None:
        """One-time setup on the world VM (e.g., start NFS server)."""

    @abstractmethod
    async def setup_agent(self, agent_env: Environment, hostname: str) -> None:
        """Make workspace available on an agent VM."""

    @abstractmethod
    async def sync_back(self, agent_env: Environment, hostname: str) -> None:
        """Sync changes back from agent VM to world VM."""

    @abstractmethod
    def with_path(self, path: str) -> Workspace:
        """Return a copy of this workspace with a different path."""


class RsyncWorkspace(Workspace):
    """Workspace shared via rsync over SSH."""

    def __init__(self, path: str, ssh_key_path: Path) -> None:
        self.path = path
        self.ssh_key_path = ssh_key_path

    async def initialize(self) -> None:
        pass

    async def setup_agent(self, agent_env: Environment, hostname: str) -> None:
        workspace_path = Path(self.path)
        if not workspace_path.exists():
            logger.debug(f"Workspace path {self.path} does not exist, skipping rsync")
            return
        logger.debug(f"Syncing workspace: {self.path} -> /workspace")
        await rsync_to(
            self.ssh_key_path,
            workspace_path,
            "/workspace",
            hostname,
            chown="superman:superman",
        )

    async def sync_back(self, agent_env: Environment, hostname: str) -> None:
        workspace_path = Path(self.path)
        logger.debug(f"Syncing workspace back: /workspace -> {self.path}")
        await rsync_from(
            self.ssh_key_path,
            "/workspace",
            workspace_path,
            hostname,
        )

    def with_path(self, path: str) -> RsyncWorkspace:
        return RsyncWorkspace(path, self.ssh_key_path)


# ---------------------------------------------------------------------------
# NFS Workspace
# ---------------------------------------------------------------------------

NFS_ROOT = "/srv/nfs"


class NFSWorkspace(Workspace):
    """Workspace shared via NFSv4 mount from world VM.

    All workspace data lives on a tmpfs mounted at /srv/nfs (the NFSv4
    pseudo-root). The world VM's workspace path (e.g. /workspace) is
    symlinked to /srv/nfs/workspace so both world code and NFS clients
    see the same data. This avoids overlayfs export limitations.
    """

    def __init__(self, path: str, world_vm_ip: str, ssh_key_path: Path) -> None:
        self.path = path
        self.world_vm_ip = world_vm_ip
        self.ssh_key_path = ssh_key_path

    async def initialize(self) -> None:
        """Set up NFS server with tmpfs-backed workspace on the world VM."""
        # Install NFS server if not present (pre-installed in plato-world-base >= 1.1.0)
        await _run_local(
            "which exportfs > /dev/null 2>&1 || (apt-get update -qq && apt-get install -y -qq nfs-kernel-server)",
            timeout=120,
        )

        # Create tmpfs at NFS_ROOT — all workspace data lives here
        exit_code, _, stderr = await _run_local(
            f"mkdir -p {NFS_ROOT} && mountpoint -q {NFS_ROOT} || mount -t tmpfs tmpfs {NFS_ROOT}",
            timeout=10,
        )
        if exit_code != 0:
            raise RuntimeError(f"Failed to create tmpfs at {NFS_ROOT}: {stderr}")

        # Create workspace dir on tmpfs and symlink the world path to it
        await self._setup_workspace_path(self.path)

        # Export the entire tmpfs as NFSv4 pseudo-root
        exit_code, _, stderr = await _run_local(
            f"printf '%s\\n' '{NFS_ROOT} *(rw,sync,fsid=0,no_subtree_check,no_root_squash)' > /etc/exports",
            timeout=10,
        )
        if exit_code != 0:
            raise RuntimeError(f"Failed to configure NFS exports: {stderr}")

        # Mount nfsd filesystem if needed
        exit_code, _, stderr = await _run_local(
            "modprobe nfsd 2>/dev/null; "
            "mkdir -p /proc/fs/nfsd && "
            "mountpoint -q /proc/fs/nfsd || mount -t nfsd nfsd /proc/fs/nfsd",
            timeout=10,
        )
        if exit_code != 0:
            raise RuntimeError(f"Failed to mount nfsd filesystem: {stderr}")

        # Start NFS services
        exit_code, _, stderr = await _run_local(
            "systemctl start rpcbind && "
            "systemctl reset-failed proc-fs-nfsd.mount 2>/dev/null; "
            "exportfs -ra && "
            "systemctl start nfs-kernel-server",
            timeout=30,
        )
        if exit_code != 0:
            raise RuntimeError(f"Failed to start NFS server: {stderr}")

        # Verify
        exit_code, exports, _ = await _run_local("exportfs -s", timeout=5)
        logger.info(f"NFS server running. Exports:\n{exports.strip()}")

    async def _setup_workspace_path(self, path: str) -> None:
        """Create workspace dir on tmpfs and symlink the world path to it."""
        nfs_path = f"{NFS_ROOT}{path}"
        exit_code, _, stderr = await _run_local(
            f"mkdir -p {nfs_path} && rm -rf {path} && ln -sf {nfs_path} {path}",
            timeout=10,
        )
        if exit_code != 0:
            raise RuntimeError(f"Failed to setup workspace path {path}: {stderr}")
        logger.info(f"Workspace {path} -> {nfs_path} (on tmpfs)")

    async def setup_agent(self, agent_env: Environment, hostname: str) -> None:
        """Mount the world VM's NFS export on an agent VM via SSH."""
        # Just ensure the NFS directory exists — don't re-symlink (the parent
        # workspace already set up the symlink chain during initialize())
        nfs_path = f"{NFS_ROOT}{self.path}"
        await _run_local(f"mkdir -p {nfs_path}", timeout=10)

        # Install NFS client if not present (pre-installed in plato-agent-base >= 1.2.0)
        await _run_ssh(
            self.ssh_key_path,
            hostname,
            "which mount.nfs > /dev/null 2>&1 || (apt-get update -qq && apt-get install -y -qq nfs-common)",
            timeout=60,
        )

        # Mount NFSv4 (path is relative to pseudo-root)
        mount_cmd = f"mkdir -p /workspace && mount -t nfs4 -o soft,timeo=30 {self.world_vm_ip}:{self.path} /workspace"
        exit_code, _, stderr = await _run_ssh(
            self.ssh_key_path,
            hostname,
            mount_cmd,
            timeout=30,
        )
        if exit_code != 0:
            raise RuntimeError(f"Failed to mount NFS on agent VM: {stderr}")

        # Ensure the agent user can write to the workspace
        await _run_ssh(
            self.ssh_key_path,
            hostname,
            "chown -R superman:superman /workspace",
            timeout=15,
        )
        logger.debug(f"NFS mounted on agent VM ({hostname})")

    async def sync_back(self, agent_env: Environment, hostname: str) -> None:
        """NFS writes are immediate — nothing to do."""
        pass

    def with_path(self, path: str) -> NFSWorkspace:
        return NFSWorkspace(path, self.world_vm_ip, self.ssh_key_path)
