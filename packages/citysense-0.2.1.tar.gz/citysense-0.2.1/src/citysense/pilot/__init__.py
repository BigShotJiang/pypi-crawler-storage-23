"""Pilot country configurations."""

from citysense.pilot.base import PilotConfig

__all__ = ["PilotConfig"]
