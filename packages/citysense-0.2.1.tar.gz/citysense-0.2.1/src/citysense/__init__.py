"""CitySense: Geospatial RAG and MCP server for urban AI development.

WUF13 aligned. SDG 11 indicator coverage.
"""

__version__ = "0.2.1"
