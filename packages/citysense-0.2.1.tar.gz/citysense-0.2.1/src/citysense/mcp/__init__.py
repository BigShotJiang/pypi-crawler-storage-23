"""MCP server and tools for urban geospatial intelligence."""
