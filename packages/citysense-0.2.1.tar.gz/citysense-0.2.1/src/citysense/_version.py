"""Version placeholder for setuptools-scm."""

__version__ = "0.2.1"
