from simple_error_log import Errors
from usdm4_fhir.factory.base_factory import BaseFactory
from fhir.resources.bundle import BundleEntry


class BundleEntryFactory(BaseFactory):
    MODULE = "usdm4_fhir.factory.bundle_entry_factory.BundleEntryFactory"

    def __init__(self, errors: Errors, **kwargs):
        try:
            super().__init__(errors, **kwargs)
            self.item = BundleEntry(**kwargs)
        except Exception as e:
            self.handle_exception(self.MODULE, "__init__", e)
