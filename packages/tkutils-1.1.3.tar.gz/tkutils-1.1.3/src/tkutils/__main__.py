

def main():
    """ Debugging/poetry script entry point """



if __name__=='__main__':
    main()
