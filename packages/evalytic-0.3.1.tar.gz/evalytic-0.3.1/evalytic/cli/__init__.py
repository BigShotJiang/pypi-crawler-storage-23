"""Evalytic CLI -- command-line tools for visual AI evaluation."""
