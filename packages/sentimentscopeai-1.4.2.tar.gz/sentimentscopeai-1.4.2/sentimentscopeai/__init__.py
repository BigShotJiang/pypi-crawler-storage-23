from .core import SentimentScopeAI
__all__ = ["SentimentScopeAI"]