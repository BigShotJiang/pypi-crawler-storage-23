# Contributing to Xerxo CLI

Thank you for your interest in contributing to Xerxo CLI! This document provides guidelines and instructions for contributing.

## Code of Conduct

Please be respectful and constructive in all interactions. We welcome contributors of all experience levels.

## Getting Started

### 1. Fork and Clone

```bash
git clone https://github.com/YOUR_USERNAME/xerxo-cli
cd xerxo-cli
```

### 2. Set Up Development Environment

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # or `venv\Scripts\activate` on Windows

# Install with dev dependencies
pip install -e ".[dev]"

# Install pre-commit hooks
pre-commit install
```

### 3. Run Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=xerxo --cov-report=html

# Run specific test file
pytest tests/test_config.py

# Run specific test
pytest tests/test_config.py::TestXerxoConfig::test_default_config
```

## Development Workflow

### Branch Naming

- `feature/` - New features
- `fix/` - Bug fixes
- `docs/` - Documentation
- `refactor/` - Code refactoring

Example: `feature/add-slack-channel`

### Commit Messages

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```
type(scope): description

[optional body]

[optional footer]
```

Types:
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Code style (formatting)
- `refactor`: Code refactoring
- `test`: Adding tests
- `chore`: Maintenance

Examples:
```
feat(agent): add streaming response support
fix(auth): handle expired tokens gracefully
docs(readme): update installation instructions
```

### Code Style

We use:
- **Black** for code formatting
- **Ruff** for linting
- **MyPy** for type checking (optional)

```bash
# Format code
black xerxo/

# Run linter
ruff check xerxo/

# Fix auto-fixable issues
ruff check xerxo/ --fix
```

## Project Structure

```
xerxo-cli/
├── xerxo/
│   ├── __init__.py      # Package init
│   ├── cli.py           # Main CLI entry point
│   ├── config.py        # Configuration management
│   ├── client/          # API client
│   ├── commands/        # CLI commands
│   ├── tui/             # Terminal UI
│   ├── gateway/         # Self-hosted gateway
│   ├── sandbox/         # Code execution sandbox
│   ├── browser/         # Browser automation
│   └── skills/          # Local skill execution
├── tests/               # Test files
├── docs/                # Documentation
├── pyproject.toml       # Project config
└── README.md
```

## Adding a New Command

### 1. Create Command Module

```python
# xerxo/commands/mycommand.py
import click
from rich.console import Console

console = Console()

@click.group()
def mycommand():
    """My new command group"""
    pass

@mycommand.command()
@click.option("--option", "-o", help="An option")
@click.pass_context
def subcommand(ctx, option):
    """Subcommand description"""
    config = ctx.obj.get("config")
    console.print(f"Running with {option}")
```

### 2. Register in CLI

```python
# xerxo/cli.py
from xerxo.commands import mycommand

cli.add_command(mycommand.mycommand)
```

### 3. Add to __init__.py

```python
# xerxo/commands/__init__.py
from xerxo.commands import mycommand
```

### 4. Add Tests

```python
# tests/test_commands.py
class TestMyCommand:
    def test_help(self, cli_runner):
        result = cli_runner.invoke(cli, ["mycommand", "--help"])
        assert result.exit_code == 0
```

## Testing Guidelines

### Test Structure

```python
class TestFeature:
    """Tests for a specific feature"""
    
    def test_basic_functionality(self):
        """Test description"""
        # Arrange
        input_data = ...
        
        # Act
        result = function(input_data)
        
        # Assert
        assert result == expected
    
    def test_edge_case(self):
        """Test edge case"""
        ...
```

### Async Tests

```python
import pytest

@pytest.mark.asyncio
async def test_async_function():
    result = await async_function()
    assert result.success
```

### Mocking

```python
from unittest.mock import patch, AsyncMock

@patch("xerxo.client.XerxoClient")
def test_with_mock(mock_client):
    mock_client.return_value.__aenter__ = AsyncMock(...)
```

## Documentation

### Docstrings

Use Google-style docstrings:

```python
def function(arg1: str, arg2: int = 10) -> dict:
    """Short description.
    
    Longer description if needed.
    
    Args:
        arg1: Description of arg1
        arg2: Description of arg2 (default: 10)
    
    Returns:
        Description of return value
    
    Raises:
        ValueError: When something is wrong
    
    Example:
        >>> result = function("test")
        >>> print(result)
    """
```

### Updating Documentation

- Update `docs/README.md` for user-facing docs
- Update `README.md` for overview changes
- Add docstrings to all public functions

## Pull Request Process

1. **Create PR** from your branch to `main`
2. **Fill out PR template** with description and changes
3. **Ensure CI passes** (tests, linting)
4. **Request review** from maintainers
5. **Address feedback** if any
6. **Merge** once approved

### PR Checklist

- [ ] Tests added/updated
- [ ] Documentation updated
- [ ] Code formatted with Black
- [ ] Linting passes (Ruff)
- [ ] Commit messages follow convention
- [ ] PR description is clear

## Release Process

Releases are handled by maintainers:

1. Update version in `pyproject.toml` and `xerxo/__init__.py`
2. Update CHANGELOG.md
3. Create release tag
4. CI publishes to PyPI

## Questions?

- Open a GitHub issue
- Join our Discord
- Email: dev@xerxo.ai

Thank you for contributing! 🎉
