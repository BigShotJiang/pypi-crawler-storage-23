# Changelog

All notable changes to Xerxo CLI will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-03-01

### Added

#### Core Features
- **Agent Commands**: Interactive chat, one-shot questions, agent management
  - `xerxo agent chat` - Start interactive chat session
  - `xerxo agent ask` - Ask single question
  - `xerxo agent list` - List available agents
  - `xerxo agent tools` - Show available tools
  - `xerxo agent config` - View agent configuration
  - `xerxo agent runs` - Show execution history

- **Workflow Commands**: Workflow management and execution
  - `xerxo workflow list` - List workflows
  - `xerxo workflow run` - Execute workflow
  - `xerxo workflow status` - Check run status
  - `xerxo workflow logs` - View execution logs
  - `xerxo workflow analytics` - View analytics

- **Skill Commands**: Skills and marketplace
  - `xerxo skill list` - List installed skills
  - `xerxo skill run` - Execute skill
  - `xerxo skill marketplace browse` - Browse marketplace
  - `xerxo skill marketplace install` - Install from marketplace
  - `xerxo skill publish` - Publish to marketplace

- **Task Commands**: Task management
  - `xerxo task list` - List tasks
  - `xerxo task add` - Create task
  - `xerxo task complete` - Mark complete
  - `xerxo task delete` - Delete task

- **Channel Commands**: Channel management
  - `xerxo channel list` - List channels
  - `xerxo channel status` - Health status
  - `xerxo channel connect` - Connect channel
  - `xerxo channel login` - WhatsApp QR login

#### Terminal UI (TUI)
- Full-screen terminal interface with Textual framework
- Chat panel with streaming responses
- Tools panel showing real-time executions
- Session sidebar for chat management
- Vim-style keyboard navigation
- Rich formatting with Markdown support

#### Self-Hosted Gateway
- Local gateway server (FastAPI)
- WebSocket support for real-time updates
- Message routing to Xerxo API
- Session management
- Channel handler framework

#### Browser Automation
- Playwright-based browser control
- Navigation, clicking, typing commands
- Screenshot capture
- Text extraction
- AI-powered browser control

#### Sandbox Execution
- SubprocessSandbox for lightweight execution
- DockerSandbox for secure isolated execution
- Support for Python, Node.js, Bash
- Timeout and resource limits

#### Configuration
- YAML-based configuration
- Environment variable overrides
- Interactive setup wizard
- Config management commands

#### Utilities
- `xerxo doctor` - System health check
- `xerxo status` - Current status overview
- `xerxo setup` - Interactive setup wizard

### Technical Details
- Python 3.10+ support
- Async HTTP client (httpx)
- Rich terminal output
- Click CLI framework
- Pydantic data models
- MIT License (Open Source)

---

## [Unreleased]

### Planned
- Streaming agent responses in chat
- More channel handlers (Telegram, Discord)
- Plugin system for custom commands
- Shell completions (bash, zsh, fish)
- Windows installer
- Homebrew formula
