# Xerxo CLI

> **Your AI-powered business operations assistant. Any OS. Any Platform. The Xerxo way.**

[![PyPI version](https://badge.fury.io/py/xerxo.svg)](https://badge.fury.io/py/xerxo)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## What is Xerxo?

Xerxo is an **open-source CLI** for AI-powered business operations. It connects to the Xerxo platform or runs as a self-hosted gateway, giving you:

- 🤖 **AI Agents** - Chat with intelligent agents that can use tools
- 🔄 **Workflows** - Automate multi-step business processes
- ⚡ **Skills** - Pre-built automations from the marketplace
- 📱 **Channels** - WhatsApp, Telegram, Discord, Slack, Email
- 🖥️ **Terminal UI** - Beautiful full-screen interface
- 🌐 **Browser Automation** - Control browsers with AI
- 🔒 **Self-Hosted** - Run your own gateway, own your data

## Quick Start

```bash
# Install
pip install xerxo

# Setup (interactive wizard)
xerxo setup

# Start chatting
xerxo agent chat

# Or launch the full Terminal UI
xerxo tui
```

## Installation

### Option 1: pip (Recommended)

```bash
# macOS / Linux
pip3 install xerxo

# Windows
pip install xerxo
# or
py -m pip install xerxo
```

### Option 2: Homebrew (macOS/Linux)

```bash
brew tap xerxo/tap
brew install xerxo
```

### Option 3: One-Line Installer

```bash
curl -fsSL https://xerxo.ai/install.sh | bash
```

### Option 4: From Source

```bash
git clone https://github.com/xerxo/xerxo-cli
cd xerxo-cli
pip install -e .
```

### Troubleshooting pip

**"pip: command not found"**

```bash
# macOS - Use pip3 or install via Homebrew
pip3 install xerxo
# or
brew install python && pip3 install xerxo

# Linux (Ubuntu/Debian)
sudo apt install python3-pip
pip3 install xerxo

# Linux (Fedora)
sudo dnf install python3-pip
pip3 install xerxo
```

### Optional Features

```bash
# Browser automation (Playwright)
pip install xerxo[browser]
playwright install chromium

# Docker sandbox
pip install xerxo[docker]

# All optional features
pip install xerxo[all]
```

## Commands

```
xerxo                          # Show help
├── setup                      # Interactive setup wizard
├── auth                       # Authentication
│   ├── login                  # Login with credentials or API key
│   ├── logout                 # Clear credentials
│   └── status                 # Show auth status
│
├── agent                      # Agent interactions
│   ├── chat                   # Interactive chat session
│   ├── ask "<question>"       # One-shot question
│   ├── list                   # List agents
│   ├── tools                  # Show available tools
│   └── config                 # View/edit agent config
│
├── workflow                   # Workflow management
│   ├── list                   # List workflows
│   ├── run <id>               # Execute workflow
│   ├── status <run_id>        # Check run status
│   └── logs <run_id>          # View logs
│
├── skill                      # Skills management
│   ├── list                   # List installed skills
│   ├── run <id>               # Execute skill
│   ├── marketplace            # Browse marketplace
│   │   ├── browse             # List skills
│   │   ├── install <id>       # Install skill
│   │   └── search <query>     # Search skills
│   └── publish <id>           # Publish to marketplace
│
├── task                       # Task management
│   ├── list                   # List tasks
│   ├── add "<title>"          # Create task
│   ├── complete <id>          # Complete task
│   └── delete <id>            # Delete task
│
├── channel                    # Channel management
│   ├── list                   # List channels
│   ├── status                 # Health status
│   ├── connect <type>         # Connect channel
│   └── login                  # WhatsApp QR login
│
├── browser                    # Browser automation
│   ├── start                  # Start browser
│   ├── navigate <url>         # Navigate to URL
│   ├── screenshot             # Take screenshot
│   ├── click <selector>       # Click element
│   └── type <text>            # Type text
│
├── gateway                    # Self-hosted gateway
│   ├── start                  # Start gateway server
│   ├── stop                   # Stop gateway
│   ├── status                 # Gateway status
│   └── logs                   # View logs
│
├── tui                        # Full terminal UI
├── config                     # CLI configuration
│   ├── set <key> <value>      # Set config
│   ├── get <key>              # Get config
│   └── list                   # Show all config
│
└── version                    # Show version
```

## Terminal UI

Launch the full-screen terminal interface:

```bash
xerxo tui
```

Features:
- 💬 Chat panel with streaming responses
- 🔧 Tool execution visibility
- 📋 Session sidebar
- ⌨️ Vim-style keyboard navigation
- 🎨 Beautiful Rich formatting

## Self-Hosted Gateway

Run your own gateway server:

```bash
# Start gateway
xerxo gateway start --port 8080

# Connect WhatsApp
xerxo channel login --channel whatsapp

# Check status
xerxo gateway status
```

## Configuration

Config is stored at `~/.xerxo/config.yaml`:

```yaml
api_url: https://api.xerxo.ai     # Or your self-hosted URL
api_key: xrx_...                   # API key
default_agent: main                # Default agent
output_format: rich                # rich | json | plain
gateway:
  port: 8080
  bind: localhost
```

## Environment Variables

```bash
XERXO_API_URL=https://api.xerxo.ai
XERXO_API_KEY=xrx_...
XERXO_CONFIG_DIR=~/.xerxo
```

## What's Open Source vs Proprietary?

**Open Source (This Repo - MIT License):**
- CLI client and all commands
- Terminal UI (TUI)
- Local gateway server
- Sandbox execution
- Browser automation
- Tool handlers

**Proprietary (Xerxo Cloud):**
- Hosted platform (web UI)
- Enterprise features (teams, RBAC, audit)
- Premium skills & workflows
- Support & SLAs

## Contributing

We welcome contributions! See [CONTRIBUTING.md](CONTRIBUTING.md).

```bash
# Clone
git clone https://github.com/xerxo/xerxo-cli
cd xerxo-cli

# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Format code
black xerxo/
ruff check xerxo/
```

## License

MIT License - see [LICENSE](LICENSE) for details.

## Links

- 📖 [Documentation](https://docs.xerxo.ai/cli)
- 💬 [Discord Community](https://discord.gg/xerxo)
- 🐛 [Report Issues](https://github.com/xerxo/xerxo-cli/issues)
- 🌐 [Xerxo Platform](https://xerxo.ai)
