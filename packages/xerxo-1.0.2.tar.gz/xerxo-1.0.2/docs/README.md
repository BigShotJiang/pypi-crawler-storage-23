# Xerxo CLI Documentation

Welcome to the Xerxo CLI documentation. This guide covers installation, configuration, and usage of the Xerxo command-line interface.

## Table of Contents

1. [Installation](#installation)
2. [Quick Start](#quick-start)
3. [Configuration](#configuration)
4. [Commands Reference](#commands-reference)
5. [Terminal UI (TUI)](#terminal-ui)
6. [Self-Hosted Gateway](#self-hosted-gateway)
7. [Browser Automation](#browser-automation)
8. [Sandbox Execution](#sandbox-execution)
9. [API Reference](#api-reference)
10. [Troubleshooting](#troubleshooting)

---

## Installation

### From PyPI (Recommended)

```bash
pip install xerxo
```

### From Source

```bash
git clone https://github.com/xerxo/xerxo-cli
cd xerxo-cli
pip install -e .
```

### System Requirements

- Python 3.10 or higher
- pip package manager

### Optional Dependencies

```bash
# For Docker sandbox
pip install docker

# For browser automation
pip install playwright
playwright install chromium

# For all optional features
pip install xerxo[all]
```

---

## Quick Start

### 1. Run Setup Wizard

```bash
xerxo setup
```

This interactive wizard will:
- Configure your API URL
- Set up authentication
- Configure preferences

### 2. Start Chatting

```bash
# Interactive chat
xerxo agent chat

# One-shot question
xerxo agent ask "What tasks do I have today?"
```

### 3. Launch TUI (Terminal UI)

```bash
xerxo tui
```

---

## Configuration

### Config File Location

The configuration file is stored at:
- Linux/Mac: `~/.xerxo/config.yaml`
- Windows: `%USERPROFILE%\.xerxo\config.yaml`

### Configuration Options

```yaml
# API Configuration
api_url: https://api.xerxo.ai
api_key: your_api_key_here

# Agent Settings
default_agent: main

# Output Settings
output_format: rich  # rich, json, plain
theme: dark          # dark, light

# Gateway Settings
gateway:
  port: 8080
  bind: localhost
  auto_start: false

# Agent Settings
agent:
  default_model: gpt-4o
  default_provider: openai
  max_steps: 10
  temperature: 0.7
  timeout: 120
```

### Environment Variables

| Variable | Description |
|----------|-------------|
| `XERXO_API_URL` | API server URL |
| `XERXO_API_KEY` | API key for authentication |
| `XERXO_CONFIG_DIR` | Custom config directory |
| `XERXO_DATA_DIR` | Custom data directory |
| `XERXO_OUTPUT_FORMAT` | Output format (rich/json/plain) |

### Managing Config via CLI

```bash
# Set a value
xerxo config set api_url https://custom.api.com

# Get a value
xerxo config get api_url

# List all config
xerxo config list

# Reset to defaults
xerxo config reset

# Edit config file
xerxo config edit
```

---

## Commands Reference

### Authentication

```bash
# Login with credentials
xerxo auth login

# Login with API key
xerxo auth login --api-key YOUR_KEY

# Check auth status
xerxo auth status

# Show current user
xerxo auth whoami

# Logout
xerxo auth logout
```

### Agent Commands

```bash
# Interactive chat
xerxo agent chat
xerxo agent chat --agent-id custom_agent
xerxo agent chat --session existing_session_id

# One-shot question
xerxo agent ask "Your question here"
xerxo agent ask "Question" --json  # JSON output

# List agents
xerxo agent list

# Show available tools
xerxo agent tools

# View agent config
xerxo agent config

# Show recent runs
xerxo agent runs --limit 20
```

### Workflow Commands

```bash
# List workflows
xerxo workflow list

# Run a workflow
xerxo workflow run wf_123
xerxo workflow run wf_123 --params '{"key": "value"}'

# Check run status
xerxo workflow status run_abc

# View run logs
xerxo workflow logs run_abc

# View analytics
xerxo workflow analytics
```

### Skill Commands

```bash
# List installed skills
xerxo skill list

# Run a skill
xerxo skill run skill_123

# Browse marketplace
xerxo skill marketplace browse
xerxo skill marketplace browse --category productivity
xerxo skill marketplace search "automation"

# Install from marketplace
xerxo skill marketplace install mkt_123

# Publish skill
xerxo skill publish skill_123 --category automation --tags tag1 --tags tag2
```

### Task Commands

```bash
# List tasks
xerxo task list
xerxo task list --status pending

# Add task
xerxo task add "Task title"
xerxo task add "Task" --priority high --due 2024-12-31

# Complete task
xerxo task complete task_123

# Delete task
xerxo task delete task_123
```

### Channel Commands

```bash
# List channels
xerxo channel list

# Check health
xerxo channel status

# Connect channel
xerxo channel connect whatsapp
xerxo channel connect telegram

# WhatsApp QR login
xerxo channel login
```

### Gateway Commands

```bash
# Start gateway
xerxo gateway start
xerxo gateway start --port 9000 --host 0.0.0.0
xerxo gateway start --detach  # Run in background

# Stop gateway
xerxo gateway stop

# Check status
xerxo gateway status

# View logs
xerxo gateway logs
xerxo gateway logs --follow

# Restart
xerxo gateway restart
```

### Browser Commands

```bash
# Start browser
xerxo browser start
xerxo browser start --no-headless  # Show browser window

# Navigate
xerxo browser navigate https://example.com

# Take screenshot
xerxo browser screenshot --output page.png

# Click element
xerxo browser click "#button-id"

# Type text
xerxo browser type "Hello" --selector "#input-field"

# Extract text
xerxo browser extract ".content"

# AI-controlled browser
xerxo browser ai "Click the login button and fill in credentials"

# Stop browser
xerxo browser stop
```

### Utility Commands

```bash
# System health check
xerxo doctor

# Show status
xerxo status

# Version
xerxo --version
```

---

## Terminal UI

The TUI provides a full-screen terminal interface:

```bash
xerxo tui
```

### Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Ctrl+N` | New chat |
| `Ctrl+T` | Toggle tools panel |
| `Ctrl+S` | Toggle sidebar |
| `Ctrl+Q` | Quit |
| `Escape` | Focus input |
| `Enter` | Send message |

### Features

- **Chat Panel**: Real-time conversation with streaming responses
- **Tools Panel**: See tool executions as they happen
- **Session Sidebar**: Switch between chat sessions
- **Rich Formatting**: Markdown rendering, syntax highlighting

---

## Self-Hosted Gateway

Run your own gateway server for full control:

### Starting the Gateway

```bash
# Foreground (development)
xerxo gateway start

# Background (production)
xerxo gateway start --detach
```

### Gateway API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Gateway info |
| `/health` | GET | Health check |
| `/api/message` | POST | Process message |
| `/api/channels` | GET | List channels |
| `/api/sessions` | GET | List sessions |
| `/ws` | WebSocket | Real-time updates |

### WebSocket Events

```javascript
// Connect to gateway
const ws = new WebSocket('ws://localhost:8080/ws');

// Send message
ws.send(JSON.stringify({
  type: 'message',
  message: 'Hello!'
}));

// Receive response
ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log(data.type, data.data);
};
```

---

## Browser Automation

Control browsers with Playwright:

### Prerequisites

```bash
pip install playwright
playwright install chromium
```

### Basic Usage

```bash
# Start browser
xerxo browser start

# Navigate and interact
xerxo browser navigate https://example.com
xerxo browser click "button.submit"
xerxo browser type "search query" --selector "input[name='q']"
xerxo browser screenshot --output result.png

# Cleanup
xerxo browser stop
```

### AI-Powered Browser Control

```bash
xerxo browser ai "Go to Google and search for 'Xerxo AI'"
xerxo browser ai "Fill out the contact form with test data"
```

---

## Sandbox Execution

Execute code in isolated environments:

### Subprocess Sandbox (Default)

Lightweight, uses subprocess isolation:

```python
from xerxo.sandbox import SubprocessSandbox

async def run():
    sandbox = SubprocessSandbox()
    result = await sandbox.execute(
        code='print("Hello!")',
        language='python',
        timeout=30
    )
    print(result.stdout)
```

### Docker Sandbox (Secure)

Full isolation with Docker:

```python
from xerxo.sandbox import DockerSandbox

async def run():
    sandbox = DockerSandbox(
        image="python:3.11-slim",
        memory_limit="256m",
        network_disabled=True
    )
    result = await sandbox.execute(
        code='print("Isolated!")',
        language='python'
    )
```

---

## API Reference

### XerxoClient

```python
from xerxo.client import XerxoClient

async with XerxoClient(api_url, api_key) as client:
    # Agent
    response = await client.agent_run("Hello")
    agents = await client.agent_list()
    
    # Workflows
    workflows = await client.workflow_list()
    result = await client.workflow_run(workflow_id)
    
    # Skills
    skills = await client.skill_list()
    marketplace = await client.marketplace_browse()
    
    # Tasks
    tasks = await client.task_list()
    await client.task_create("New task")
```

### Configuration

```python
from xerxo.config import get_config, save_config, set_value

# Get config
config = get_config()

# Modify
config.api_url = "https://custom.api.com"
save_config(config)

# Or use set_value
set_value("gateway.port", 9000)
```

---

## Troubleshooting

### Common Issues

**"Not authenticated"**
```bash
xerxo auth login
```

**"Connection refused"**
- Check API URL: `xerxo config get api_url`
- Verify network connectivity
- Check if gateway is running: `xerxo gateway status`

**"Docker not available"**
```bash
# Install Docker SDK
pip install docker

# Verify Docker is running
docker info
```

**"Playwright not installed"**
```bash
pip install playwright
playwright install chromium
```

### Debug Mode

```bash
# Enable verbose output
XERXO_DEBUG=1 xerxo agent chat

# Check system health
xerxo doctor
```

### Getting Help

- GitHub Issues: https://github.com/xerxo/xerxo-cli/issues
- Documentation: https://docs.xerxo.ai/cli
- Discord: https://discord.gg/xerxo
