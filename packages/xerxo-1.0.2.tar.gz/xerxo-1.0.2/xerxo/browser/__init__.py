"""
Browser module - Browser automation utilities
"""

# Browser automation module
