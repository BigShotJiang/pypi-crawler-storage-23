"""
Xerxo CLI - Your AI-powered business operations assistant
"""

__version__ = "1.0.1"
__author__ = "Xerxo Team"

from xerxo.cli import main

__all__ = ["main", "__version__"]
