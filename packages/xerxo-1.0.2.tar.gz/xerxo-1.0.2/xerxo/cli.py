"""
Xerxo CLI - Main entry point
"""

import click
from rich.console import Console

from xerxo import __version__
from xerxo.commands import agent, auth, browser, channel, config_cmd, gateway, skill, task, workflow
from xerxo.config import get_config

console = Console()


class XerxoGroup(click.Group):
    """Custom group with better help formatting"""
    
    def format_help(self, ctx, formatter):
        console.print("""
[bold cyan]╭─────────────────────────────────────────────────────────────╮[/]
[bold cyan]│[/]  [bold white]Xerxo CLI[/] [dim]v{version}[/]                                        [bold cyan]│[/]
[bold cyan]│[/]  [dim]Your AI-powered business operations assistant[/]            [bold cyan]│[/]
[bold cyan]╰─────────────────────────────────────────────────────────────╯[/]
""".format(version=__version__))
        super().format_help(ctx, formatter)


@click.group(cls=XerxoGroup)
@click.option("--config", "-c", type=click.Path(), help="Config file path")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
@click.option("--no-color", is_flag=True, help="Disable colors")
@click.version_option(__version__, "-v", "--version")
@click.pass_context
def cli(ctx, config, output_json, no_color):
    """Xerxo CLI - AI-powered business operations"""
    ctx.ensure_object(dict)
    ctx.obj["config_path"] = config
    ctx.obj["output_json"] = output_json
    ctx.obj["no_color"] = no_color
    ctx.obj["config"] = get_config(config)


# Register command groups
cli.add_command(auth.auth)
cli.add_command(agent.agent)
cli.add_command(workflow.workflow)
cli.add_command(skill.skill)
cli.add_command(task.task)
cli.add_command(channel.channel)
cli.add_command(browser.browser)
cli.add_command(gateway.gateway)
cli.add_command(config_cmd.config)


@cli.command()
@click.pass_context
def setup(ctx):
    """Interactive setup wizard"""
    from xerxo.commands.setup import run_setup_wizard
    run_setup_wizard(ctx.obj.get("config"))


@cli.command()
@click.option("--url", help="Gateway URL")
@click.option("--token", help="Auth token")
@click.option("--session", help="Session ID")
@click.pass_context
def tui(ctx, url, token, session):
    """Launch the full terminal UI"""
    from xerxo.tui.app import XerxoTUI
    from xerxo.config import XerxoConfig
    
    config = ctx.obj.get("config") or XerxoConfig()
    app = XerxoTUI(
        api_url=url or config.api_url,
        api_key=token or config.api_key,
        session_id=session
    )
    app.run()


@cli.command()
def doctor():
    """Check system health and configuration"""
    from xerxo.commands.doctor import run_doctor
    run_doctor()


@cli.command()
def status():
    """Show current status (auth, gateway, channels)"""
    from xerxo.commands.status import show_status
    show_status()


def main():
    """Main entry point"""
    cli(obj={})


if __name__ == "__main__":
    main()
