"""
Workflow commands
"""

import asyncio
import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from xerxo.client import XerxoClient

console = Console()


@click.group()
def workflow():
    """Workflow management"""
    pass


@workflow.command()
@click.option("--workspace", "-w", default="default", help="Workspace ID")
@click.pass_context
def list(ctx, workspace):
    """List all workflows"""
    config = ctx.obj.get("config")
    
    async def get_workflows():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.workflow_list(workspace)
    
    with console.status("[bold blue]Fetching workflows...[/]"):
        workflows = asyncio.run(get_workflows())
    
    if not workflows:
        console.print("[yellow]No workflows found[/]")
        return
    
    table = Table(title="Workflows")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="bold")
    table.add_column("Steps")
    table.add_column("Status")
    table.add_column("Last Run")
    
    for wf in workflows:
        status = "🟢 Active" if wf.get("enabled", True) else "⚪ Disabled"
        steps = len(wf.get("steps", []))
        last_run = wf.get("last_run", "Never")
        if last_run and last_run != "Never":
            last_run = last_run[:19]
        
        table.add_row(
            wf.get("id", "?"),
            wf.get("name", "Unnamed"),
            str(steps),
            status,
            last_run
        )
    
    console.print(table)


@workflow.command()
@click.argument("workflow_id")
@click.option("--params", "-p", help="JSON parameters")
@click.option("--workspace", "-w", default="default", help="Workspace ID")
@click.pass_context
def run(ctx, workflow_id, params, workspace):
    """Execute a workflow"""
    import json
    
    config = ctx.obj.get("config")
    run_params = json.loads(params) if params else {}
    
    async def run_workflow():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.workflow_run(workflow_id, run_params, workspace)
    
    with console.status(f"[bold blue]Running workflow {workflow_id}...[/]"):
        result = asyncio.run(run_workflow())
    
    if result.get("success"):
        console.print(Panel(
            f"[green]✓[/] Workflow executed successfully\n"
            f"[bold]Run ID:[/] {result.get('run_id', 'N/A')}\n"
            f"[bold]Steps Succeeded:[/] {result.get('steps_succeeded', 0)}\n"
            f"[bold]Steps Failed:[/] {result.get('steps_failed', 0)}",
            title="Workflow Complete",
            border_style="green"
        ))
    else:
        console.print(f"[red]✗[/] Workflow failed: {result.get('error', 'Unknown error')}")


@workflow.command()
@click.argument("run_id")
@click.pass_context
def status(ctx, run_id):
    """Check workflow run status"""
    config = ctx.obj.get("config")
    
    async def get_status():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.workflow_status(run_id)
    
    with console.status("[bold blue]Fetching status...[/]"):
        result = asyncio.run(get_status())
    
    status_color = {
        "completed": "green",
        "running": "blue",
        "failed": "red",
        "pending": "yellow"
    }
    
    state = result.get("state", "unknown")
    color = status_color.get(state, "white")
    
    console.print(Panel(
        f"[bold]Run ID:[/] {result.get('id', run_id)}\n"
        f"[bold]Status:[/] [{color}]{state.upper()}[/]\n"
        f"[bold]Current Step:[/] {result.get('current_step', 0)}\n"
        f"[bold]Total Steps:[/] {result.get('total_steps', 0)}\n"
        f"[bold]Started:[/] {result.get('started_at', 'N/A')}\n"
        f"[bold]Completed:[/] {result.get('completed_at', 'N/A')}",
        title="Workflow Run Status",
        border_style=color
    ))


@workflow.command()
@click.argument("run_id")
@click.pass_context
def logs(ctx, run_id):
    """View workflow execution logs"""
    config = ctx.obj.get("config")
    
    async def get_logs():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.workflow_status(run_id)
    
    with console.status("[bold blue]Fetching logs...[/]"):
        result = asyncio.run(get_logs())
    
    steps = result.get("step_results", [])
    
    if not steps:
        console.print("[yellow]No step logs available[/]")
        return
    
    console.print(f"[bold]Workflow Run: {run_id}[/]\n")
    
    for i, step in enumerate(steps, 1):
        status_icon = "✓" if step.get("status") == "completed" else "✗"
        status_color = "green" if step.get("status") == "completed" else "red"
        
        console.print(f"[{status_color}]{status_icon}[/] Step {i}: [bold]{step.get('type', 'unknown')}[/]")
        
        if step.get("result"):
            console.print(f"   [dim]Result: {str(step.get('result'))[:100]}...[/]")
        if step.get("error"):
            console.print(f"   [red]Error: {step.get('error')}[/]")
        
        console.print()


@workflow.command()
@click.option("--workspace", "-w", default="default", help="Workspace ID")
@click.pass_context
def analytics(ctx, workspace):
    """Show workflow analytics"""
    config = ctx.obj.get("config")
    
    async def get_analytics():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.workflow_analytics(workspace)
    
    with console.status("[bold blue]Fetching analytics...[/]"):
        result = asyncio.run(get_analytics())
    
    console.print(Panel(
        f"[bold]Total Workflows:[/] {result.get('total_workflows', 0)}\n"
        f"[bold]Total Runs:[/] {result.get('total_runs', 0)}\n"
        f"[bold]Success Rate:[/] {result.get('success_rate', 0):.1f}%\n"
        f"[bold]Average Duration:[/] {result.get('avg_duration', 0):.1f}s\n"
        f"[bold]Runs Today:[/] {result.get('runs_today', 0)}",
        title="Workflow Analytics",
        border_style="cyan"
    ))
