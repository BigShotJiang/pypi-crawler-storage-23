"""
Authentication commands
"""

import click
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

from xerxo.config import get_config, save_config, get_credentials_path, ensure_config_dir
import yaml

console = Console()


@click.group()
def auth():
    """Authentication management"""
    pass


@auth.command()
@click.option("--username", "-u", help="Username")
@click.option("--password", "-p", help="Password", hide_input=True)
@click.option("--api-key", "-k", help="API key (alternative to username/password)")
@click.pass_context
def login(ctx, username, password, api_key):
    """Login to Xerxo"""
    config = ctx.obj.get("config")
    
    if api_key:
        # Direct API key login
        config.api_key = api_key
        save_config(config)
        console.print("[green]✓[/] API key saved successfully")
        return
    
    # Interactive login
    if not username:
        username = Prompt.ask("[bold]Username[/]")
    if not password:
        password = Prompt.ask("[bold]Password[/]", password=True)
    
    # Attempt login
    import asyncio
    from xerxo.client import XerxoClient
    
    async def do_login():
        async with XerxoClient(config.api_url) as client:
            return await client.login(username, password)
    
    try:
        with console.status("[bold blue]Logging in...[/]"):
            result = asyncio.run(do_login())
        
        # Save token
        token = result.get("access_token")
        if token:
            config.api_key = token
            save_config(config)
            
            console.print(Panel(
                f"[green]✓[/] Logged in as [bold]{username}[/]\n"
                f"[dim]Token saved to config[/]",
                title="Login Successful",
                border_style="green"
            ))
        else:
            console.print("[red]✗[/] Login failed: No token received")
            
    except Exception as e:
        console.print(f"[red]✗[/] Login failed: {e}")


@auth.command()
@click.pass_context
def logout(ctx):
    """Logout and clear credentials"""
    config = ctx.obj.get("config")
    config.api_key = None
    save_config(config)
    
    # Also clear credentials file
    creds_path = get_credentials_path()
    if creds_path.exists():
        creds_path.unlink()
    
    console.print("[green]✓[/] Logged out successfully")


@auth.command()
@click.pass_context
def status(ctx):
    """Show authentication status"""
    config = ctx.obj.get("config")
    
    if config.api_key:
        # Verify token
        import asyncio
        from xerxo.client import XerxoClient
        
        async def check_auth():
            try:
                async with XerxoClient(config.api_url, config.api_key) as client:
                    return await client.whoami()
            except Exception:
                return None
        
        with console.status("[bold blue]Checking auth...[/]"):
            user = asyncio.run(check_auth())
        
        if user:
            console.print(Panel(
                f"[green]●[/] Authenticated\n"
                f"[bold]User:[/] {user.get('username', 'Unknown')}\n"
                f"[bold]API URL:[/] {config.api_url}",
                title="Auth Status",
                border_style="green"
            ))
        else:
            console.print(Panel(
                f"[yellow]●[/] Token present but may be invalid\n"
                f"[bold]API URL:[/] {config.api_url}\n"
                f"[dim]Try 'xerxo auth login' to re-authenticate[/]",
                title="Auth Status",
                border_style="yellow"
            ))
    else:
        console.print(Panel(
            f"[red]●[/] Not authenticated\n"
            f"[bold]API URL:[/] {config.api_url}\n"
            f"[dim]Run 'xerxo auth login' to authenticate[/]",
            title="Auth Status",
            border_style="red"
        ))


@auth.command()
@click.pass_context
def whoami(ctx):
    """Show current user info"""
    config = ctx.obj.get("config")
    
    if not config.api_key:
        console.print("[red]✗[/] Not authenticated. Run 'xerxo auth login' first.")
        return
    
    import asyncio
    from xerxo.client import XerxoClient
    
    async def get_user():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.whoami()
    
    try:
        with console.status("[bold blue]Fetching user info...[/]"):
            user = asyncio.run(get_user())
        
        console.print(Panel(
            f"[bold]Username:[/] {user.get('username', 'Unknown')}\n"
            f"[bold]Roles:[/] {', '.join(user.get('roles', ['user']))}\n"
            f"[bold]Workspace:[/] {user.get('workspace_type', 'personal')}",
            title="Current User",
            border_style="cyan"
        ))
    except Exception as e:
        console.print(f"[red]✗[/] Failed to get user info: {e}")
