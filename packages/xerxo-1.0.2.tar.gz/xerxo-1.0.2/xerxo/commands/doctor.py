"""
Doctor command - System health checks
"""

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
import sys
import shutil

console = Console()


def run_doctor():
    """Run system health checks"""
    
    console.print(Panel(
        "[bold]Xerxo Doctor[/]\n"
        "Checking system health...",
        border_style="cyan"
    ))
    
    checks = []
    
    # Python version
    py_version = sys.version_info
    py_ok = py_version >= (3, 10)
    checks.append((
        "Python Version",
        f"{py_version.major}.{py_version.minor}.{py_version.micro}",
        py_ok,
        "Python 3.10+ required"
    ))
    
    # Required packages
    packages = [
        ("click", "CLI framework"),
        ("rich", "Terminal formatting"),
        ("textual", "TUI framework"),
        ("httpx", "HTTP client"),
        ("pydantic", "Data validation"),
    ]
    
    for package, desc in packages:
        try:
            __import__(package)
            checks.append((f"Package: {package}", "Installed", True, desc))
        except ImportError:
            checks.append((f"Package: {package}", "Missing", False, f"pip install {package}"))
    
    # Optional packages
    optional = [
        ("docker", "Docker sandbox"),
        ("playwright", "Browser automation"),
        ("websockets", "WebSocket support"),
    ]
    
    for package, desc in optional:
        try:
            __import__(package)
            checks.append((f"Optional: {package}", "Installed", True, desc))
        except ImportError:
            checks.append((f"Optional: {package}", "Not installed", None, f"pip install {package}"))
    
    # Docker
    docker_available = shutil.which("docker") is not None
    checks.append((
        "Docker",
        "Available" if docker_available else "Not found",
        docker_available if docker_available else None,
        "Required for Docker sandbox"
    ))
    
    # Configuration
    from xerxo.config import get_config, get_config_path
    
    config_path = get_config_path()
    config_exists = config_path.exists()
    checks.append((
        "Config File",
        str(config_path) if config_exists else "Not created",
        config_exists if config_exists else None,
        "Run 'xerxo setup' to create"
    ))
    
    if config_exists:
        config = get_config()
        checks.append((
            "API URL",
            config.api_url,
            True,
            ""
        ))
        checks.append((
            "API Key",
            "Configured" if config.api_key else "Not set",
            config.api_key is not None,
            "Run 'xerxo auth login'"
        ))
    
    # Display results
    table = Table(title="Health Check Results")
    table.add_column("Check", style="bold")
    table.add_column("Status")
    table.add_column("Result")
    table.add_column("Notes", style="dim")
    
    for check, status, ok, note in checks:
        if ok is True:
            result = "[green]✓ Pass[/]"
        elif ok is False:
            result = "[red]✗ Fail[/]"
        else:
            result = "[yellow]○ Optional[/]"
        
        table.add_row(check, status, result, note)
    
    console.print(table)
    
    # Summary
    failed = sum(1 for _, _, ok, _ in checks if ok is False)
    if failed == 0:
        console.print("\n[green]✓ All checks passed![/]")
    else:
        console.print(f"\n[yellow]⚠ {failed} check(s) need attention[/]")
