"""
Gateway commands - Self-hosted gateway server
"""

import asyncio
import click
import os
import signal
import sys
from pathlib import Path
from rich.console import Console
from rich.panel import Panel

from xerxo.config import get_config, get_data_dir

console = Console()

# PID file for gateway process
PID_FILE = get_data_dir() / "gateway.pid"


@click.group()
def gateway():
    """Self-hosted gateway server"""
    pass


@gateway.command()
@click.option("--port", "-p", default=8080, help="Port to run on")
@click.option("--host", "-h", default="localhost", help="Host to bind to")
@click.option("--detach", "-d", is_flag=True, help="Run in background")
@click.pass_context
def start(ctx, port, host, detach):
    """Start the gateway server"""
    config = ctx.obj.get("config")
    
    if is_gateway_running():
        console.print("[yellow]Gateway is already running[/]")
        console.print(f"[dim]Stop it with: xerxo gateway stop[/]")
        return
    
    console.print(Panel(
        f"[bold]Starting Xerxo Gateway[/]\n\n"
        f"Host: {host}\n"
        f"Port: {port}\n"
        f"Mode: {'Background' if detach else 'Foreground'}",
        title="Gateway",
        border_style="cyan"
    ))
    
    if detach:
        # Fork process
        pid = os.fork()
        if pid > 0:
            # Parent process
            save_pid(pid)
            console.print(f"[green]✓[/] Gateway started in background (PID: {pid})")
            console.print(f"[dim]View logs: xerxo gateway logs[/]")
            return
        
        # Child process
        os.setsid()
        sys.stdin.close()
    
    # Run gateway
    run_gateway_server(host, port, config)


def run_gateway_server(host: str, port: int, config):
    """Run the gateway server"""
    import uvicorn
    from xerxo.gateway.server import create_app
    
    app = create_app(config)
    
    console.print(f"[green]●[/] Gateway running at http://{host}:{port}")
    console.print("[dim]Press Ctrl+C to stop[/]")
    
    try:
        uvicorn.run(app, host=host, port=port, log_level="info")
    except KeyboardInterrupt:
        console.print("\n[yellow]Gateway stopped[/]")


@gateway.command()
@click.pass_context
def stop(ctx):
    """Stop the gateway server"""
    if not is_gateway_running():
        console.print("[yellow]Gateway is not running[/]")
        return
    
    pid = get_pid()
    if pid:
        try:
            os.kill(pid, signal.SIGTERM)
            PID_FILE.unlink(missing_ok=True)
            console.print(f"[green]✓[/] Gateway stopped (PID: {pid})")
        except ProcessLookupError:
            PID_FILE.unlink(missing_ok=True)
            console.print("[yellow]Gateway process not found, cleaned up PID file[/]")
        except Exception as e:
            console.print(f"[red]✗[/] Failed to stop gateway: {e}")
    else:
        console.print("[yellow]No PID file found[/]")


@gateway.command()
@click.pass_context
def status(ctx):
    """Check gateway status"""
    config = ctx.obj.get("config")
    
    if is_gateway_running():
        pid = get_pid()
        console.print(Panel(
            f"[green]●[/] Gateway is running\n"
            f"[bold]PID:[/] {pid}\n"
            f"[bold]URL:[/] http://localhost:{config.gateway.port}",
            title="Gateway Status",
            border_style="green"
        ))
        
        # Try to ping
        import httpx
        try:
            resp = httpx.get(f"http://localhost:{config.gateway.port}/health", timeout=2)
            if resp.status_code == 200:
                console.print("[green]✓[/] Health check passed")
        except Exception:
            console.print("[yellow]⚠[/] Health check failed")
    else:
        console.print(Panel(
            f"[red]●[/] Gateway is not running\n"
            f"[dim]Start with: xerxo gateway start[/]",
            title="Gateway Status",
            border_style="red"
        ))


@gateway.command()
@click.option("--lines", "-n", default=50, help="Number of lines to show")
@click.option("--follow", "-f", is_flag=True, help="Follow log output")
@click.pass_context
def logs(ctx, lines, follow):
    """View gateway logs"""
    log_file = get_data_dir() / "gateway.log"
    
    if not log_file.exists():
        console.print("[yellow]No log file found[/]")
        return
    
    if follow:
        console.print(f"[dim]Following {log_file}... (Ctrl+C to stop)[/]")
        import subprocess
        try:
            subprocess.run(["tail", "-f", str(log_file)])
        except KeyboardInterrupt:
            pass
    else:
        with open(log_file) as f:
            log_lines = f.readlines()
            for line in log_lines[-lines:]:
                console.print(line.rstrip())


@gateway.command()
@click.pass_context
def restart(ctx):
    """Restart the gateway server"""
    config = ctx.obj.get("config")
    
    if is_gateway_running():
        ctx.invoke(stop)
        import time
        time.sleep(1)
    
    ctx.invoke(start, port=config.gateway.port, host=config.gateway.bind, detach=True)


def is_gateway_running() -> bool:
    """Check if gateway is running"""
    pid = get_pid()
    if not pid:
        return False
    
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        PID_FILE.unlink(missing_ok=True)
        return False


def get_pid() -> int | None:
    """Get gateway PID from file"""
    try:
        if PID_FILE.exists():
            return int(PID_FILE.read_text().strip())
    except Exception:
        pass
    return None


def save_pid(pid: int):
    """Save PID to file"""
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(pid))
