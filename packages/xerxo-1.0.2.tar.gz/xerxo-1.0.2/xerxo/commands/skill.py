"""
Skill commands
"""

import asyncio
import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from xerxo.client import XerxoClient

console = Console()


@click.group()
def skill():
    """Skills management"""
    pass


@skill.command()
@click.pass_context
def list(ctx):
    """List installed skills"""
    config = ctx.obj.get("config")
    
    async def get_skills():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.skill_list()
    
    with console.status("[bold blue]Fetching skills...[/]"):
        skills = asyncio.run(get_skills())
    
    if not skills:
        console.print("[yellow]No skills installed[/]")
        console.print("[dim]Browse marketplace: xerxo skill marketplace browse[/]")
        return
    
    table = Table(title="Installed Skills")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="bold")
    table.add_column("Trigger")
    table.add_column("Status")
    table.add_column("Runs")
    
    for sk in skills:
        status = "🟢 Enabled" if sk.get("enabled", True) else "⚪ Disabled"
        trigger = sk.get("trigger", "manual")
        runs = sk.get("run_count", 0)
        
        table.add_row(
            sk.get("id", "?")[:12],
            sk.get("name", "Unnamed"),
            trigger,
            status,
            str(runs)
        )
    
    console.print(table)


@skill.command()
@click.argument("skill_id")
@click.pass_context
def run(ctx, skill_id):
    """Execute a skill manually"""
    config = ctx.obj.get("config")
    
    async def run_skill():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.skill_run(skill_id)
    
    with console.status(f"[bold blue]Running skill {skill_id}...[/]"):
        result = asyncio.run(run_skill())
    
    if result.get("success"):
        console.print(Panel(
            f"[green]✓[/] Skill executed successfully\n"
            f"[bold]Actions Run:[/] {result.get('actions_executed', 0)}",
            title="Skill Complete",
            border_style="green"
        ))
    else:
        console.print(f"[red]✗[/] Skill failed: {result.get('error', 'Unknown error')}")


@skill.group()
def marketplace():
    """Skill marketplace"""
    pass


@marketplace.command()
@click.option("--category", "-c", help="Filter by category")
@click.option("--search", "-s", help="Search query")
@click.option("--limit", "-l", default=20, help="Number of results")
@click.pass_context
def browse(ctx, category, search, limit):
    """Browse skill marketplace"""
    config = ctx.obj.get("config")
    
    async def get_marketplace():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.marketplace_browse(category, search, limit)
    
    with console.status("[bold blue]Browsing marketplace...[/]"):
        result = asyncio.run(get_marketplace())
    
    skills = result.get("skills", [])
    
    if not skills:
        console.print("[yellow]No skills found in marketplace[/]")
        return
    
    table = Table(title="Skill Marketplace")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="bold")
    table.add_column("Category", style="dim")
    table.add_column("Installs", justify="right")
    table.add_column("Rating")
    
    for sk in skills:
        rating = sk.get("rating", 0)
        stars = "⭐" * int(rating) + f" {rating:.1f}" if rating else "-"
        
        table.add_row(
            sk.get("id", "?")[:12],
            sk.get("name", "Unnamed"),
            sk.get("category", "general"),
            str(sk.get("installs", 0)),
            stars
        )
    
    console.print(table)
    console.print(f"\n[dim]Install with: xerxo skill marketplace install <ID>[/]")


@marketplace.command()
@click.argument("marketplace_id")
@click.pass_context
def install(ctx, marketplace_id):
    """Install a skill from marketplace"""
    config = ctx.obj.get("config")
    
    async def do_install():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.marketplace_install(marketplace_id)
    
    with console.status(f"[bold blue]Installing {marketplace_id}...[/]"):
        result = asyncio.run(do_install())
    
    if result.get("success"):
        skill_name = result.get("skill", {}).get("name", marketplace_id)
        console.print(Panel(
            f"[green]✓[/] Installed [bold]{skill_name}[/]\n"
            f"[dim]Run with: xerxo skill run {result.get('skill', {}).get('id', marketplace_id)[:12]}[/]",
            title="Skill Installed",
            border_style="green"
        ))
    else:
        console.print(f"[red]✗[/] Installation failed: {result.get('error', 'Unknown error')}")


@marketplace.command()
@click.argument("query")
@click.pass_context
def search(ctx, query):
    """Search marketplace"""
    ctx.invoke(browse, search=query)


@skill.command()
@click.argument("skill_id")
@click.option("--category", "-c", default="general", help="Category")
@click.option("--tags", "-t", multiple=True, help="Tags (can specify multiple)")
@click.pass_context
def publish(ctx, skill_id, category, tags):
    """Publish a skill to the marketplace"""
    config = ctx.obj.get("config")
    
    async def do_publish():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.skill_publish(skill_id, category, list(tags))
    
    with console.status(f"[bold blue]Publishing {skill_id}...[/]"):
        result = asyncio.run(do_publish())
    
    if result.get("success"):
        console.print(Panel(
            f"[green]✓[/] Skill published to marketplace\n"
            f"[bold]Marketplace ID:[/] {result.get('marketplace_skill', {}).get('id', 'N/A')}",
            title="Published",
            border_style="green"
        ))
    else:
        console.print(f"[red]✗[/] Publishing failed: {result.get('error', result.get('detail', 'Unknown error'))}")
