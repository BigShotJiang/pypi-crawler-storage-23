"""
Status command - Show current status
"""

import asyncio
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from xerxo.config import get_config
from xerxo.client import XerxoClient

console = Console()


def show_status():
    """Show current status of auth, gateway, and channels"""
    
    config = get_config()
    
    # Auth status
    console.print("[bold]Authentication[/]")
    if config.api_key:
        console.print(f"  [green]●[/] Authenticated to {config.api_url}")
    else:
        console.print(f"  [red]●[/] Not authenticated")
        console.print(f"  [dim]Run: xerxo auth login[/]")
    
    console.print()
    
    # Gateway status
    console.print("[bold]Gateway[/]")
    from xerxo.commands.gateway import is_gateway_running, get_pid
    
    if is_gateway_running():
        pid = get_pid()
        console.print(f"  [green]●[/] Running (PID: {pid})")
        console.print(f"  [dim]URL: http://{config.gateway.bind}:{config.gateway.port}[/]")
    else:
        console.print(f"  [red]●[/] Not running")
        console.print(f"  [dim]Start: xerxo gateway start[/]")
    
    console.print()
    
    # API health
    if config.api_key:
        console.print("[bold]API Status[/]")
        
        async def check_api():
            try:
                async with XerxoClient(config.api_url, config.api_key) as client:
                    health = await client.gateway_health()
                    return health
            except Exception as e:
                return {"error": str(e)}
        
        with console.status("[bold blue]Checking API...[/]"):
            result = asyncio.run(check_api())
        
        if "error" in result:
            console.print(f"  [red]●[/] API Error: {result['error']}")
        else:
            console.print(f"  [green]●[/] API Healthy")
    
    console.print()
    
    # Channels
    if config.api_key:
        console.print("[bold]Channels[/]")
        
        async def get_channels():
            try:
                async with XerxoClient(config.api_url, config.api_key) as client:
                    return await client.channel_list()
            except Exception:
                return []
        
        with console.status("[bold blue]Fetching channels...[/]"):
            channels = asyncio.run(get_channels())
        
        if channels:
            for ch in channels:
                status_icon = "●" if ch.get("status") == "connected" else "○"
                status_color = "green" if ch.get("status") == "connected" else "red"
                console.print(f"  [{status_color}]{status_icon}[/] {ch.get('type', 'unknown')}: {ch.get('name', '-')}")
        else:
            console.print("  [dim]No channels connected[/]")
