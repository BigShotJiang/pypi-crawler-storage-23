"""
Channel commands
"""

import asyncio
import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from xerxo.client import XerxoClient

console = Console()


@click.group()
def channel():
    """Channel management"""
    pass


@channel.command()
@click.pass_context
def list(ctx):
    """List connected channels"""
    config = ctx.obj.get("config")
    
    async def get_channels():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.channel_list()
    
    with console.status("[bold blue]Fetching channels...[/]"):
        channels = asyncio.run(get_channels())
    
    if not channels:
        console.print("[yellow]No channels connected[/]")
        console.print("[dim]Connect a channel: xerxo channel connect <type>[/]")
        return
    
    table = Table(title="Connected Channels")
    table.add_column("ID", style="cyan")
    table.add_column("Type", style="bold")
    table.add_column("Name")
    table.add_column("Status")
    
    for ch in channels:
        status_map = {
            "connected": "🟢 Connected",
            "disconnected": "🔴 Disconnected",
            "pending": "🟡 Pending"
        }
        status = status_map.get(ch.get("status"), ch.get("status"))
        
        table.add_row(
            ch.get("id", "?")[:12],
            ch.get("type", "unknown"),
            ch.get("name", ch.get("phone_number", "-")),
            status
        )
    
    console.print(table)


@channel.command()
@click.pass_context
def status(ctx):
    """Show channel health status"""
    config = ctx.obj.get("config")
    
    async def get_health():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.channel_health()
    
    with console.status("[bold blue]Checking channel health...[/]"):
        result = asyncio.run(get_health())
    
    connections = result.get("connections", [])
    
    if not connections:
        console.print("[yellow]No channel connections found[/]")
        return
    
    for conn in connections:
        status = conn.get("status", "unknown")
        color = "green" if status == "connected" else "red"
        
        console.print(Panel(
            f"[bold]Type:[/] {conn.get('type', 'unknown')}\n"
            f"[bold]Status:[/] [{color}]{status.upper()}[/]\n"
            f"[bold]Phone:[/] {conn.get('phone_number', '-')}\n"
            f"[bold]Last Ping:[/] {conn.get('last_ping', 'Never')}",
            title=f"Channel: {conn.get('id', 'Unknown')[:12]}",
            border_style=color
        ))


@channel.command()
@click.argument("channel_type", type=click.Choice(["whatsapp", "telegram", "slack", "discord", "email"]))
@click.pass_context
def connect(ctx, channel_type):
    """Connect a new channel"""
    from rich.prompt import Prompt
    
    config = ctx.obj.get("config")
    channel_config = {}
    
    if channel_type == "whatsapp":
        console.print("[bold]WhatsApp Connection[/]")
        method = Prompt.ask("Connection method", choices=["qr", "api"], default="qr")
        
        if method == "api":
            channel_config["phone_number_id"] = Prompt.ask("Phone Number ID")
            channel_config["access_token"] = Prompt.ask("Access Token", password=True)
        else:
            console.print("[dim]QR code will be displayed when gateway starts[/]")
            channel_config["method"] = "qr"
    
    elif channel_type == "telegram":
        channel_config["bot_token"] = Prompt.ask("Bot Token", password=True)
    
    elif channel_type == "slack":
        channel_config["bot_token"] = Prompt.ask("Bot Token", password=True)
        channel_config["app_token"] = Prompt.ask("App Token", password=True)
    
    elif channel_type == "discord":
        channel_config["bot_token"] = Prompt.ask("Bot Token", password=True)
    
    elif channel_type == "email":
        channel_config["smtp_host"] = Prompt.ask("SMTP Host")
        channel_config["smtp_port"] = Prompt.ask("SMTP Port", default="587")
        channel_config["username"] = Prompt.ask("Username")
        channel_config["password"] = Prompt.ask("Password", password=True)
    
    async def do_connect():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.channel_connect(channel_type, channel_config)
    
    with console.status(f"[bold blue]Connecting {channel_type}...[/]"):
        result = asyncio.run(do_connect())
    
    if result.get("success"):
        console.print(f"[green]✓[/] Channel connected successfully")
        if result.get("qr_code"):
            console.print("[bold]Scan this QR code with WhatsApp:[/]")
            console.print(result.get("qr_code"))
    else:
        console.print(f"[red]✗[/] Connection failed: {result.get('error', 'Unknown error')}")


@channel.command()
@click.option("--channel", "-c", default="whatsapp", type=click.Choice(["whatsapp"]))
@click.pass_context
def login(ctx, channel):
    """Login to a channel (WhatsApp QR)"""
    console.print("[bold]WhatsApp QR Login[/]")
    console.print("[dim]This will generate a QR code for WhatsApp Web login[/]")
    console.print()
    console.print("To login via QR:")
    console.print("1. Start the gateway: [bold]xerxo gateway start[/]")
    console.print("2. Open WhatsApp on your phone")
    console.print("3. Go to Settings > Linked Devices > Link a Device")
    console.print("4. Scan the QR code displayed in the gateway")


@channel.command()
@click.argument("channel_id")
@click.confirmation_option(prompt="Are you sure you want to disconnect this channel?")
@click.pass_context
def disconnect(ctx, channel_id):
    """Disconnect a channel"""
    config = ctx.obj.get("config")
    
    console.print(f"[yellow]Disconnecting channel {channel_id}...[/]")
    console.print("[dim]Channel disconnection not implemented yet[/]")
