"""
Browser automation commands
"""

import asyncio
import click
from rich.console import Console
from rich.panel import Panel

console = Console()

# Global browser instance
_browser = None
_page = None


@click.group()
def browser():
    """Browser automation (Playwright)"""
    pass


@browser.command()
@click.option("--headless/--no-headless", default=True, help="Run headless")
@click.pass_context
def start(ctx, headless):
    """Start a browser instance"""
    global _browser, _page
    
    async def do_start():
        global _browser, _page
        from playwright.async_api import async_playwright
        
        pw = await async_playwright().start()
        _browser = await pw.chromium.launch(headless=headless)
        _page = await _browser.new_page()
        return True
    
    with console.status("[bold blue]Starting browser...[/]"):
        asyncio.run(do_start())
    
    console.print("[green]✓[/] Browser started")
    console.print("[dim]Use 'xerxo browser navigate <url>' to go to a page[/]")


@browser.command()
@click.argument("url")
@click.pass_context
def navigate(ctx, url):
    """Navigate to a URL"""
    global _page
    
    if not _page:
        console.print("[red]✗[/] Browser not started. Run 'xerxo browser start' first.")
        return
    
    async def do_navigate():
        await _page.goto(url)
        return await _page.title()
    
    with console.status(f"[bold blue]Navigating to {url}...[/]"):
        title = asyncio.run(do_navigate())
    
    console.print(f"[green]✓[/] Loaded: [bold]{title}[/]")


@browser.command()
@click.option("--output", "-o", default="screenshot.png", help="Output file")
@click.option("--full-page", is_flag=True, help="Capture full page")
@click.pass_context
def screenshot(ctx, output, full_page):
    """Take a screenshot"""
    global _page
    
    if not _page:
        console.print("[red]✗[/] Browser not started. Run 'xerxo browser start' first.")
        return
    
    async def do_screenshot():
        await _page.screenshot(path=output, full_page=full_page)
    
    with console.status("[bold blue]Taking screenshot...[/]"):
        asyncio.run(do_screenshot())
    
    console.print(f"[green]✓[/] Screenshot saved to [bold]{output}[/]")


@browser.command("click")
@click.argument("selector")
@click.pass_context
def click_element(ctx, selector):
    """Click an element"""
    global _page
    
    if not _page:
        console.print("[red]✗[/] Browser not started. Run 'xerxo browser start' first.")
        return
    
    async def do_click():
        await _page.click(selector)
    
    with console.status(f"[bold blue]Clicking {selector}...[/]"):
        asyncio.run(do_click())
    
    console.print(f"[green]✓[/] Clicked: {selector}")


@browser.command()
@click.argument("text")
@click.option("--selector", "-s", help="Element selector to type into")
@click.pass_context
def type(ctx, text, selector):
    """Type text into an element"""
    global _page
    
    if not _page:
        console.print("[red]✗[/] Browser not started. Run 'xerxo browser start' first.")
        return
    
    async def do_type():
        if selector:
            await _page.fill(selector, text)
        else:
            await _page.keyboard.type(text)
    
    with console.status("[bold blue]Typing...[/]"):
        asyncio.run(do_type())
    
    console.print(f"[green]✓[/] Typed: {text[:30]}...")


@browser.command()
@click.argument("selector")
@click.pass_context
def extract(ctx, selector):
    """Extract text from an element"""
    global _page
    
    if not _page:
        console.print("[red]✗[/] Browser not started. Run 'xerxo browser start' first.")
        return
    
    async def do_extract():
        element = await _page.query_selector(selector)
        if element:
            return await element.text_content()
        return None
    
    with console.status(f"[bold blue]Extracting from {selector}...[/]"):
        text = asyncio.run(do_extract())
    
    if text:
        console.print(Panel(text, title="Extracted Text", border_style="cyan"))
    else:
        console.print(f"[yellow]No element found: {selector}[/]")


@browser.command()
@click.pass_context
def stop(ctx):
    """Stop the browser"""
    global _browser, _page
    
    if not _browser:
        console.print("[yellow]Browser not running[/]")
        return
    
    async def do_stop():
        global _browser, _page
        await _browser.close()
        _browser = None
        _page = None
    
    asyncio.run(do_stop())
    console.print("[green]✓[/] Browser stopped")


@browser.command()
@click.argument("script")
@click.pass_context
def run(ctx, script):
    """Run a JavaScript script in the browser"""
    global _page
    
    if not _page:
        console.print("[red]✗[/] Browser not started. Run 'xerxo browser start' first.")
        return
    
    async def do_run():
        return await _page.evaluate(script)
    
    with console.status("[bold blue]Running script...[/]"):
        result = asyncio.run(do_run())
    
    console.print(f"[green]✓[/] Result: {result}")


@browser.command()
@click.argument("instruction")
@click.pass_context
def ai(ctx, instruction):
    """Control browser with AI instructions"""
    global _page
    config = ctx.obj.get("config")
    
    if not _page:
        console.print("[red]✗[/] Browser not started. Run 'xerxo browser start' first.")
        return
    
    # Use agent to interpret instruction and generate Playwright commands
    from xerxo.client import XerxoClient
    
    prompt = f"""You are a browser automation assistant. The user wants to: {instruction}

Generate the exact Playwright Python commands to accomplish this. 
Current page URL: [will be filled]
Available actions: click(selector), fill(selector, text), goto(url), screenshot(path)

Respond with only the Python code, no explanations."""
    
    async def do_ai():
        async with XerxoClient(config.api_url, config.api_key) as client:
            # Get current URL
            url = _page.url
            enhanced_prompt = prompt.replace("[will be filled]", url)
            
            response = await client.agent_run(
                message=enhanced_prompt,
                channel="browser"
            )
            return response.response
    
    with console.status("[bold blue]AI thinking...[/]"):
        code = asyncio.run(do_ai())
    
    console.print(Panel(code, title="Generated Code", border_style="cyan"))
    
    if click.confirm("Execute this code?"):
        console.print("[dim]Code execution not implemented - copy and run manually[/]")
