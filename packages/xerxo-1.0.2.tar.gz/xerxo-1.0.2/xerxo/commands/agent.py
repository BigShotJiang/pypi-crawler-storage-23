"""
Agent commands - Chat with AI agents
"""

import asyncio
import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.live import Live
from rich.markdown import Markdown

from xerxo.client import XerxoClient

console = Console()


@click.group()
def agent():
    """Agent interactions"""
    pass


@agent.command()
@click.option("--agent-id", "-a", help="Specific agent to chat with")
@click.option("--session", "-s", help="Session ID to continue")
@click.pass_context
def chat(ctx, agent_id, session):
    """Interactive chat session with an agent"""
    config = ctx.obj.get("config")
    
    console.print(Panel(
        "[bold cyan]Xerxo Agent Chat[/]\n"
        "[dim]Type 'exit' or 'quit' to end. '/help' for commands.[/]",
        border_style="cyan"
    ))
    
    session_id = session
    
    async def run_chat():
        nonlocal session_id
        
        async with XerxoClient(config.api_url, config.api_key) as client:
            while True:
                try:
                    user_input = console.input("\n[bold green]You:[/] ")
                except (KeyboardInterrupt, EOFError):
                    break
                
                if user_input.lower() in ("exit", "quit", "/exit", "/quit"):
                    break
                
                if user_input.startswith("/"):
                    handle_slash_command(user_input)
                    continue
                
                if not user_input.strip():
                    continue
                
                # Send to agent
                with console.status("[bold blue]Thinking...[/]") as status:
                    try:
                        response = await client.agent_run(
                            message=user_input,
                            session_id=session_id,
                            agent_id=agent_id,
                            channel="cli"
                        )
                        
                        if response.session_id:
                            session_id = response.session_id
                        
                        # Show tool calls if any
                        if response.tool_calls:
                            console.print("\n[dim]Tools used:[/]")
                            for tc in response.tool_calls:
                                status_icon = "✓" if tc.get("status") == "completed" else "✗"
                                console.print(f"  [{status_icon}] {tc.get('tool_name')}")
                        
                        # Show response
                        console.print(f"\n[bold cyan]Agent:[/]")
                        if response.response:
                            console.print(Markdown(response.response))
                        else:
                            console.print("[dim]No response[/]")
                        
                    except Exception as e:
                        console.print(f"\n[red]Error:[/] {e}")
    
    asyncio.run(run_chat())
    console.print("\n[dim]Chat ended. Goodbye![/]")


def handle_slash_command(cmd: str):
    """Handle slash commands in chat"""
    cmd = cmd.lower().strip()
    
    if cmd in ("/help", "/h", "/?"):
        console.print(Panel(
            "[bold]Available Commands:[/]\n"
            "  /help     - Show this help\n"
            "  /clear    - Clear screen\n"
            "  /tools    - Show available tools\n"
            "  /status   - Show session status\n"
            "  /exit     - End chat session",
            title="Help",
            border_style="blue"
        ))
    elif cmd == "/clear":
        console.clear()
    elif cmd == "/tools":
        console.print("[dim]Use 'xerxo agent tools' to see available tools[/]")
    elif cmd == "/status":
        console.print("[dim]Session status not implemented yet[/]")
    else:
        console.print(f"[yellow]Unknown command: {cmd}[/]")


@agent.command()
@click.argument("question")
@click.option("--agent-id", "-a", help="Specific agent")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
@click.pass_context
def ask(ctx, question, agent_id, output_json):
    """One-shot question to agent"""
    config = ctx.obj.get("config")
    
    async def run_ask():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.agent_run(
                message=question,
                agent_id=agent_id,
                channel="cli"
            )
    
    with console.status("[bold blue]Thinking...[/]"):
        response = asyncio.run(run_ask())
    
    if output_json:
        import json
        console.print_json(json.dumps(response.model_dump()))
    else:
        # Show tool calls
        if response.tool_calls:
            console.print("[dim]Tools used:[/]")
            for tc in response.tool_calls:
                status_icon = "✓" if tc.get("status") == "completed" else "✗"
                console.print(f"  [{status_icon}] {tc.get('tool_name')}")
            console.print()
        
        # Show response
        if response.response:
            console.print(Markdown(response.response))
        else:
            console.print("[yellow]No response from agent[/]")


@agent.command()
@click.pass_context
def list(ctx):
    """List available agents"""
    config = ctx.obj.get("config")
    
    async def get_agents():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.agent_list()
    
    with console.status("[bold blue]Fetching agents...[/]"):
        agents = asyncio.run(get_agents())
    
    if not agents:
        console.print("[yellow]No agents found[/]")
        return
    
    table = Table(title="Agents")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="bold")
    table.add_column("Model", style="green")
    table.add_column("Status")
    
    for agent in agents:
        status = "🟢 Active" if agent.get("status") == "active" else "⚪ Inactive"
        table.add_row(
            agent.get("id", "?"),
            agent.get("name", "Unnamed"),
            agent.get("model", "default"),
            status
        )
    
    console.print(table)


@agent.command()
@click.option("--agent-id", "-a", help="Specific agent")
@click.pass_context
def tools(ctx, agent_id):
    """Show available tools for agents"""
    config = ctx.obj.get("config")
    
    async def get_tools():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.agent_tools(agent_id)
    
    with console.status("[bold blue]Fetching tools...[/]"):
        tools_list = asyncio.run(get_tools())
    
    if not tools_list:
        console.print("[yellow]No tools available[/]")
        return
    
    table = Table(title="Agent Tools")
    table.add_column("Name", style="cyan")
    table.add_column("Description")
    table.add_column("Risk", style="dim")
    table.add_column("Approval")
    
    for tool in tools_list:
        approval = "⚠️ Required" if tool.get("requires_approval") else "Auto"
        table.add_row(
            tool.get("name", "?"),
            tool.get("description", "")[:50] + "...",
            tool.get("risk_level", "low"),
            approval
        )
    
    console.print(table)


@agent.command()
@click.option("--agent-id", "-a", help="Specific agent")
@click.pass_context
def config(ctx, agent_id):
    """View agent configuration"""
    config = ctx.obj.get("config")
    
    async def get_agent_config():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.agent_config(agent_id)
    
    with console.status("[bold blue]Fetching config...[/]"):
        agent_cfg = asyncio.run(get_agent_config())
    
    console.print(Panel(
        f"[bold]Agent ID:[/] {agent_cfg.get('id', 'main')}\n"
        f"[bold]Name:[/] {agent_cfg.get('name', 'Xerxo Agent')}\n"
        f"[bold]Model:[/] {agent_cfg.get('model', 'gpt-4o')}\n"
        f"[bold]Provider:[/] {agent_cfg.get('provider', 'openai')}\n"
        f"[bold]Max Steps:[/] {agent_cfg.get('max_steps', 10)}\n"
        f"[bold]Temperature:[/] {agent_cfg.get('temperature', 0.7)}",
        title="Agent Configuration",
        border_style="cyan"
    ))


@agent.command()
@click.option("--limit", "-l", default=10, help="Number of runs to show")
@click.pass_context
def runs(ctx, limit):
    """Show recent agent execution runs"""
    config = ctx.obj.get("config")
    
    async def get_runs():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.agent_runs(limit=limit)
    
    with console.status("[bold blue]Fetching runs...[/]"):
        runs_list = asyncio.run(get_runs())
    
    if not runs_list:
        console.print("[yellow]No recent runs found[/]")
        return
    
    table = Table(title=f"Recent Agent Runs (Last {limit})")
    table.add_column("Run ID", style="cyan")
    table.add_column("Agent", style="bold")
    table.add_column("Status")
    table.add_column("Steps")
    table.add_column("Tools")
    table.add_column("Started")
    
    for run in runs_list:
        status_map = {
            "completed": "✓ Complete",
            "failed": "✗ Failed",
            "running": "⏳ Running"
        }
        table.add_row(
            run.get("id", "?")[:12],
            run.get("agent_id", "main"),
            status_map.get(run.get("state"), run.get("state")),
            str(run.get("current_step", 0)),
            str(len(run.get("tool_calls_made", []))),
            run.get("started_at", "")[:19]
        )
    
    console.print(table)
