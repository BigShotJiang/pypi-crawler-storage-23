"""
Setup wizard for first-time configuration
"""

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt, Confirm

from xerxo.config import XerxoConfig, save_config, ensure_config_dir

console = Console()


def run_setup_wizard(existing_config: XerxoConfig = None):
    """Run the interactive setup wizard"""
    
    console.print(Panel(
        "[bold cyan]Welcome to Xerxo![/]\n\n"
        "Let's set up your CLI. This will only take a minute.",
        title="Setup Wizard",
        border_style="cyan"
    ))
    
    config = existing_config or XerxoConfig()
    
    # API URL
    console.print("\n[bold]1. API Configuration[/]")
    use_cloud = Confirm.ask(
        "Use Xerxo Cloud (api.xerxo.ai)?",
        default=True
    )
    
    if use_cloud:
        config.api_url = "https://api.xerxo.ai"
    else:
        config.api_url = Prompt.ask(
            "Enter your Xerxo API URL",
            default=config.api_url
        )
    
    # Authentication
    console.print("\n[bold]2. Authentication[/]")
    auth_method = Prompt.ask(
        "How do you want to authenticate?",
        choices=["login", "api_key", "skip"],
        default="login"
    )
    
    if auth_method == "login":
        username = Prompt.ask("Username")
        password = Prompt.ask("Password", password=True)
        
        # Attempt login
        import asyncio
        from xerxo.client import XerxoClient
        
        async def do_login():
            async with XerxoClient(config.api_url) as client:
                return await client.login(username, password)
        
        try:
            with console.status("[bold blue]Logging in...[/]"):
                result = asyncio.run(do_login())
            
            token = result.get("access_token")
            if token:
                config.api_key = token
                console.print("[green]✓[/] Login successful!")
            else:
                console.print("[yellow]⚠[/] Login returned no token. You can set it later.")
        except Exception as e:
            console.print(f"[yellow]⚠[/] Login failed: {e}")
            console.print("[dim]You can set the API key later with: xerxo config set api_key <key>[/]")
    
    elif auth_method == "api_key":
        config.api_key = Prompt.ask("API Key", password=True)
    
    # Output format
    console.print("\n[bold]3. Preferences[/]")
    config.output_format = Prompt.ask(
        "Output format",
        choices=["rich", "json", "plain"],
        default="rich"
    )
    
    config.theme = Prompt.ask(
        "Theme",
        choices=["dark", "light"],
        default="dark"
    )
    
    # Gateway settings
    if Confirm.ask("\nConfigure local gateway?", default=False):
        config.gateway.port = int(Prompt.ask(
            "Gateway port",
            default=str(config.gateway.port)
        ))
        config.gateway.bind = Prompt.ask(
            "Gateway host",
            default=config.gateway.bind
        )
    
    # Save configuration
    console.print("\n[bold]Saving configuration...[/]")
    ensure_config_dir()
    save_config(config)
    
    console.print(Panel(
        "[green]✓[/] Setup complete!\n\n"
        "[bold]Quick start:[/]\n"
        "  • Chat with agent: [cyan]xerxo agent chat[/]\n"
        "  • One-shot question: [cyan]xerxo agent ask \"..\"[/]\n"
        "  • Launch TUI: [cyan]xerxo tui[/]\n"
        "  • View help: [cyan]xerxo --help[/]",
        title="Setup Complete",
        border_style="green"
    ))
