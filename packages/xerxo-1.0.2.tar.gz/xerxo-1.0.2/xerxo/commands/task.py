"""
Task commands
"""

import asyncio
import click
from rich.console import Console
from rich.table import Table

from xerxo.client import XerxoClient

console = Console()


@click.group()
def task():
    """Task management"""
    pass


@task.command()
@click.option("--status", "-s", type=click.Choice(["all", "pending", "completed"]), default="all")
@click.option("--limit", "-l", default=20, help="Number of tasks")
@click.pass_context
def list(ctx, status, limit):
    """List tasks"""
    config = ctx.obj.get("config")
    status_filter = status if status != "all" else None
    
    async def get_tasks():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.task_list(status=status_filter, limit=limit)
    
    with console.status("[bold blue]Fetching tasks...[/]"):
        tasks = asyncio.run(get_tasks())
    
    if not tasks:
        console.print("[yellow]No tasks found[/]")
        return
    
    table = Table(title="Tasks")
    table.add_column("ID", style="cyan")
    table.add_column("Title", style="bold")
    table.add_column("Priority")
    table.add_column("Status")
    table.add_column("Due")
    
    priority_colors = {"high": "red", "medium": "yellow", "low": "green"}
    
    for t in tasks:
        priority = t.get("priority", "medium")
        status = "✓" if t.get("status") == "completed" else "○"
        due = t.get("due_date", "-")[:10] if t.get("due_date") else "-"
        
        table.add_row(
            t.get("id", "?")[:12],
            t.get("title", "Untitled")[:40],
            f"[{priority_colors.get(priority, 'white')}]{priority}[/]",
            status,
            due
        )
    
    console.print(table)


@task.command()
@click.argument("title")
@click.option("--description", "-d", default="", help="Task description")
@click.option("--priority", "-p", type=click.Choice(["low", "medium", "high"]), default="medium")
@click.option("--due", help="Due date (YYYY-MM-DD)")
@click.pass_context
def add(ctx, title, description, priority, due):
    """Create a new task"""
    config = ctx.obj.get("config")
    
    async def create_task():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.task_create(title, description, priority, due)
    
    with console.status("[bold blue]Creating task...[/]"):
        result = asyncio.run(create_task())
    
    if result.get("success"):
        task_data = result.get("task", {})
        console.print(f"[green]✓[/] Task created: [bold]{task_data.get('title', title)}[/]")
        console.print(f"[dim]ID: {task_data.get('id', 'N/A')}[/]")
    else:
        console.print(f"[red]✗[/] Failed to create task")


@task.command()
@click.argument("task_id")
@click.pass_context
def complete(ctx, task_id):
    """Mark a task as complete"""
    config = ctx.obj.get("config")
    
    async def do_complete():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.task_complete(task_id)
    
    with console.status("[bold blue]Completing task...[/]"):
        result = asyncio.run(do_complete())
    
    if result.get("success"):
        console.print(f"[green]✓[/] Task marked as complete")
    else:
        console.print(f"[red]✗[/] Failed to complete task")


@task.command()
@click.argument("task_id")
@click.confirmation_option(prompt="Are you sure you want to delete this task?")
@click.pass_context
def delete(ctx, task_id):
    """Delete a task"""
    config = ctx.obj.get("config")
    
    async def do_delete():
        async with XerxoClient(config.api_url, config.api_key) as client:
            return await client.task_delete(task_id)
    
    with console.status("[bold blue]Deleting task...[/]"):
        result = asyncio.run(do_delete())
    
    if result.get("success"):
        console.print(f"[green]✓[/] Task deleted")
    else:
        console.print(f"[red]✗[/] Failed to delete task")
