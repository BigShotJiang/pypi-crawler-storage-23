"""
Configuration commands
"""

import click
from rich.console import Console
from rich.table import Table

from xerxo.config import get_config, save_config, get_value, set_value

console = Console()


@click.group()
def config():
    """CLI configuration"""
    pass


@config.command()
@click.argument("key")
@click.argument("value")
@click.pass_context
def set(ctx, key, value):
    """Set a configuration value"""
    try:
        # Handle boolean values
        if value.lower() in ("true", "yes", "1"):
            value = True
        elif value.lower() in ("false", "no", "0"):
            value = False
        # Handle numeric values
        elif value.isdigit():
            value = int(value)
        elif value.replace(".", "", 1).isdigit():
            value = float(value)
        
        set_value(key, value)
        console.print(f"[green]✓[/] Set [bold]{key}[/] = {value}")
    except Exception as e:
        console.print(f"[red]✗[/] Failed to set config: {e}")


@config.command()
@click.argument("key")
@click.pass_context
def get(ctx, key):
    """Get a configuration value"""
    value = get_value(key)
    
    if value is not None:
        console.print(f"[bold]{key}[/] = {value}")
    else:
        console.print(f"[yellow]Key not found: {key}[/]")


@config.command()
@click.pass_context
def list(ctx):
    """Show all configuration"""
    cfg = ctx.obj.get("config")
    
    table = Table(title="Configuration")
    table.add_column("Key", style="cyan")
    table.add_column("Value")
    
    def add_items(prefix: str, data: dict):
        for key, value in data.items():
            full_key = f"{prefix}.{key}" if prefix else key
            if isinstance(value, dict):
                add_items(full_key, value)
            else:
                display_value = str(value)
                if key in ("api_key", "token", "password") and value:
                    display_value = value[:8] + "..." if len(str(value)) > 8 else "***"
                table.add_row(full_key, display_value)
    
    add_items("", cfg.model_dump())
    console.print(table)


@config.command()
@click.confirmation_option(prompt="Reset all configuration to defaults?")
@click.pass_context
def reset(ctx):
    """Reset configuration to defaults"""
    from xerxo.config import XerxoConfig, get_config_path
    
    default_config = XerxoConfig()
    save_config(default_config)
    
    console.print("[green]✓[/] Configuration reset to defaults")


@config.command()
@click.pass_context
def path(ctx):
    """Show configuration file path"""
    from xerxo.config import get_config_path, get_data_dir
    
    console.print(f"[bold]Config file:[/] {get_config_path()}")
    console.print(f"[bold]Data dir:[/] {get_data_dir()}")


@config.command()
@click.pass_context
def edit(ctx):
    """Open configuration in editor"""
    import subprocess
    from xerxo.config import get_config_path, ensure_config_dir
    
    ensure_config_dir()
    config_path = get_config_path()
    
    # Create default config if doesn't exist
    if not config_path.exists():
        cfg = ctx.obj.get("config")
        save_config(cfg)
    
    editor = click.get_text_stream('EDITOR', 'vi')
    
    try:
        subprocess.run([editor, str(config_path)])
        console.print("[green]✓[/] Configuration saved")
    except Exception as e:
        console.print(f"[red]✗[/] Failed to open editor: {e}")
