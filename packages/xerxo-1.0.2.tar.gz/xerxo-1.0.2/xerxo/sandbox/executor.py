"""
Sandbox Executor - Isolated code execution

Provides two execution modes:
1. Docker-based sandbox (secure, isolated)
2. Subprocess sandbox (lightweight, less isolated)
"""

import asyncio
import logging
import os
import tempfile
import subprocess
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Optional, List
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class ExecutionResult:
    """Result of sandbox execution"""
    success: bool
    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0
    duration_ms: int = 0
    error: Optional[str] = None


class SandboxExecutor(ABC):
    """Abstract base class for sandbox executors"""
    
    @abstractmethod
    async def execute(
        self,
        code: str,
        language: str = "python",
        timeout: int = 30,
        env: Dict[str, str] = None
    ) -> ExecutionResult:
        """Execute code in sandbox"""
        pass
    
    @abstractmethod
    async def cleanup(self):
        """Cleanup sandbox resources"""
        pass


class SubprocessSandbox(SandboxExecutor):
    """
    Subprocess-based sandbox for lightweight execution.
    
    Less secure than Docker but faster to start.
    Uses subprocess with limited permissions.
    """
    
    def __init__(self, work_dir: str = None):
        self.work_dir = Path(work_dir or tempfile.mkdtemp(prefix="xerxo_sandbox_"))
        self.work_dir.mkdir(parents=True, exist_ok=True)
    
    async def execute(
        self,
        code: str,
        language: str = "python",
        timeout: int = 30,
        env: Dict[str, str] = None
    ) -> ExecutionResult:
        """Execute code in subprocess sandbox"""
        import time
        start_time = time.time()
        
        # Determine executable
        executables = {
            "python": ["python3", "-c"],
            "node": ["node", "-e"],
            "bash": ["bash", "-c"],
            "sh": ["sh", "-c"],
        }
        
        if language not in executables:
            return ExecutionResult(
                success=False,
                error=f"Unsupported language: {language}"
            )
        
        cmd = executables[language]
        
        # Build environment
        exec_env = os.environ.copy()
        if env:
            exec_env.update(env)
        
        # Remove sensitive variables
        for key in ["API_KEY", "SECRET", "PASSWORD", "TOKEN"]:
            exec_env.pop(key, None)
        
        try:
            process = await asyncio.create_subprocess_exec(
                *cmd, code,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(self.work_dir),
                env=exec_env
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=timeout
                )
            except asyncio.TimeoutError:
                process.kill()
                return ExecutionResult(
                    success=False,
                    error=f"Execution timed out after {timeout}s",
                    exit_code=-1,
                    duration_ms=timeout * 1000
                )
            
            duration = int((time.time() - start_time) * 1000)
            
            return ExecutionResult(
                success=process.returncode == 0,
                stdout=stdout.decode() if stdout else "",
                stderr=stderr.decode() if stderr else "",
                exit_code=process.returncode,
                duration_ms=duration
            )
            
        except Exception as e:
            logger.error(f"Subprocess execution error: {e}")
            return ExecutionResult(
                success=False,
                error=str(e)
            )
    
    async def cleanup(self):
        """Cleanup temporary files"""
        import shutil
        try:
            shutil.rmtree(self.work_dir, ignore_errors=True)
        except Exception as e:
            logger.warning(f"Failed to cleanup sandbox: {e}")


class DockerSandbox(SandboxExecutor):
    """
    Docker-based sandbox for secure isolated execution.
    
    Provides full isolation with:
    - Network isolation
    - Resource limits
    - Read-only filesystem
    """
    
    def __init__(
        self,
        image: str = "python:3.11-slim",
        memory_limit: str = "256m",
        cpu_limit: float = 1.0,
        network_disabled: bool = True
    ):
        self.image = image
        self.memory_limit = memory_limit
        self.cpu_limit = cpu_limit
        self.network_disabled = network_disabled
        self._container = None
    
    async def execute(
        self,
        code: str,
        language: str = "python",
        timeout: int = 30,
        env: Dict[str, str] = None
    ) -> ExecutionResult:
        """Execute code in Docker container"""
        import time
        start_time = time.time()
        
        try:
            import docker
            client = docker.from_env()
        except ImportError:
            return ExecutionResult(
                success=False,
                error="Docker SDK not installed. Install with: pip install docker"
            )
        except Exception as e:
            return ExecutionResult(
                success=False,
                error=f"Docker not available: {e}"
            )
        
        # Select image based on language
        images = {
            "python": "python:3.11-slim",
            "node": "node:20-slim",
            "bash": "alpine:latest",
        }
        
        image = images.get(language, self.image)
        
        # Build command
        commands = {
            "python": ["python3", "-c", code],
            "node": ["node", "-e", code],
            "bash": ["sh", "-c", code],
        }
        
        if language not in commands:
            return ExecutionResult(
                success=False,
                error=f"Unsupported language: {language}"
            )
        
        cmd = commands[language]
        
        try:
            # Create and run container
            container = client.containers.run(
                image,
                cmd,
                detach=True,
                mem_limit=self.memory_limit,
                cpu_period=100000,
                cpu_quota=int(self.cpu_limit * 100000),
                network_disabled=self.network_disabled,
                read_only=True,
                environment=env or {},
                remove=False  # We'll remove manually after getting logs
            )
            
            self._container = container
            
            # Wait for completion with timeout
            try:
                result = container.wait(timeout=timeout)
                exit_code = result.get("StatusCode", -1)
            except Exception:
                container.kill()
                return ExecutionResult(
                    success=False,
                    error=f"Execution timed out after {timeout}s",
                    exit_code=-1,
                    duration_ms=timeout * 1000
                )
            
            # Get output
            stdout = container.logs(stdout=True, stderr=False).decode()
            stderr = container.logs(stdout=False, stderr=True).decode()
            
            duration = int((time.time() - start_time) * 1000)
            
            return ExecutionResult(
                success=exit_code == 0,
                stdout=stdout,
                stderr=stderr,
                exit_code=exit_code,
                duration_ms=duration
            )
            
        except docker.errors.ImageNotFound:
            return ExecutionResult(
                success=False,
                error=f"Docker image not found: {image}. Pull it with: docker pull {image}"
            )
        except Exception as e:
            logger.error(f"Docker execution error: {e}")
            return ExecutionResult(
                success=False,
                error=str(e)
            )
        finally:
            # Cleanup container
            if self._container:
                try:
                    self._container.remove(force=True)
                except Exception:
                    pass
                self._container = None
    
    async def cleanup(self):
        """Cleanup Docker resources"""
        if self._container:
            try:
                self._container.remove(force=True)
            except Exception:
                pass
            self._container = None


async def create_sandbox(
    mode: str = "subprocess",
    **kwargs
) -> SandboxExecutor:
    """
    Factory function to create appropriate sandbox.
    
    Args:
        mode: "subprocess" or "docker"
        **kwargs: Additional arguments for the sandbox
    
    Returns:
        SandboxExecutor instance
    """
    if mode == "docker":
        return DockerSandbox(**kwargs)
    else:
        return SubprocessSandbox(**kwargs)
