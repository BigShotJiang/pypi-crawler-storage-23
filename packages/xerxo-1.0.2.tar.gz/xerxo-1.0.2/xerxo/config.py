"""
Configuration management for Xerxo CLI
"""

import os
from pathlib import Path
from typing import Any, Optional

import yaml
from platformdirs import user_config_dir, user_data_dir
from pydantic import BaseModel, Field


class GatewayConfig(BaseModel):
    """Gateway configuration"""
    port: int = 8080
    bind: str = "localhost"
    token: Optional[str] = None
    auto_start: bool = False


class AgentConfig(BaseModel):
    """Agent configuration"""
    default_model: str = "gpt-4o"
    default_provider: str = "openai"
    max_steps: int = 10
    temperature: float = 0.7
    timeout: int = 120


class XerxoConfig(BaseModel):
    """Main configuration"""
    api_url: str = "https://api.xerxo.ai"
    api_key: Optional[str] = None
    default_agent: str = "main"
    output_format: str = "rich"  # rich, json, plain
    theme: str = "dark"
    gateway: GatewayConfig = Field(default_factory=GatewayConfig)
    agent: AgentConfig = Field(default_factory=AgentConfig)
    workspace: Optional[str] = None


def get_config_dir() -> Path:
    """Get the config directory path"""
    env_dir = os.environ.get("XERXO_CONFIG_DIR")
    if env_dir:
        return Path(env_dir)
    return Path(user_config_dir("xerxo", "xerxo"))


def get_data_dir() -> Path:
    """Get the data directory path"""
    env_dir = os.environ.get("XERXO_DATA_DIR")
    if env_dir:
        return Path(env_dir)
    return Path(user_data_dir("xerxo", "xerxo"))


def get_config_path() -> Path:
    """Get the config file path"""
    return get_config_dir() / "config.yaml"


def get_credentials_path() -> Path:
    """Get the credentials file path"""
    return get_config_dir() / "credentials.yaml"


def ensure_config_dir():
    """Ensure config directory exists"""
    config_dir = get_config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir


def get_config(config_path: Optional[str] = None) -> XerxoConfig:
    """Load configuration from file and environment"""
    path = Path(config_path) if config_path else get_config_path()
    
    config_dict = {}
    
    # Load from file if exists
    if path.exists():
        with open(path) as f:
            config_dict = yaml.safe_load(f) or {}
    
    # Override with environment variables
    env_overrides = {
        "api_url": os.environ.get("XERXO_API_URL"),
        "api_key": os.environ.get("XERXO_API_KEY"),
        "default_agent": os.environ.get("XERXO_DEFAULT_AGENT"),
        "output_format": os.environ.get("XERXO_OUTPUT_FORMAT"),
    }
    
    for key, value in env_overrides.items():
        if value is not None:
            config_dict[key] = value
    
    return XerxoConfig(**config_dict)


def save_config(config: XerxoConfig, config_path: Optional[str] = None):
    """Save configuration to file"""
    ensure_config_dir()
    path = Path(config_path) if config_path else get_config_path()
    
    with open(path, "w") as f:
        yaml.dump(config.model_dump(exclude_none=True), f, default_flow_style=False)


def get_value(key: str, config: Optional[XerxoConfig] = None) -> Any:
    """Get a configuration value by dot-notation key"""
    if config is None:
        config = get_config()
    
    parts = key.split(".")
    value = config.model_dump()
    
    for part in parts:
        if isinstance(value, dict) and part in value:
            value = value[part]
        else:
            return None
    
    return value


def set_value(key: str, value: Any, config_path: Optional[str] = None):
    """Set a configuration value by dot-notation key"""
    config = get_config(config_path)
    config_dict = config.model_dump()
    
    parts = key.split(".")
    target = config_dict
    
    for part in parts[:-1]:
        if part not in target:
            target[part] = {}
        target = target[part]
    
    target[parts[-1]] = value
    
    new_config = XerxoConfig(**config_dict)
    save_config(new_config, config_path)
    
    return new_config
