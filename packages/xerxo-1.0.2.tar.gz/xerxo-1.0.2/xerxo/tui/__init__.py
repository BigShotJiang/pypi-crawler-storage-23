"""
TUI - Terminal UI module
"""

from xerxo.tui.app import XerxoTUI

__all__ = ["XerxoTUI"]
