"""
Xerxo TUI - Full Terminal User Interface

A full-screen terminal interface for Xerxo with:
- Chat panel with streaming responses
- Session sidebar
- Tool execution visibility
- Vim-style keyboard navigation
"""

from textual.app import App, ComposeResult
from textual.containers import Container, Horizontal, Vertical, ScrollableContainer
from textual.widgets import Header, Footer, Static, Input, Button, ListView, ListItem, Label, ProgressBar
from textual.binding import Binding
from textual.message import Message
from textual import events
from textual.reactive import reactive

import asyncio
from datetime import datetime
from typing import Optional, List, Dict

from xerxo.client import XerxoClient


class ChatMessage(Static):
    """A single chat message widget with copy support"""
    
    # Allow selection in the terminal
    can_focus = True
    
    def __init__(self, role: str, content: str, tool_calls: List[Dict] = None):
        self.role = role
        self.message_content = content
        self.tool_calls = tool_calls or []
        super().__init__()
    
    def compose(self) -> ComposeResult:
        role_style = "bold cyan" if self.role == "assistant" else "bold green"
        role_label = "Agent" if self.role == "assistant" else "You"
        
        yield Static(f"[{role_style}]{role_label}[/]", classes="message-role")
        # Use markup=False to preserve raw content for selection
        yield Static(self.message_content, classes="message-content", markup=True)
        
        if self.tool_calls:
            yield Static("[dim]Tools:[/dim]", classes="tool-header")
            for tc in self.tool_calls:
                status = "✓" if tc.get("status") == "completed" else "○"
                yield Static(f"  {status} {tc.get('tool_name')}", classes="tool-item")
    
    def get_content_plain_text(self) -> str:
        """Get the plain text content for copying"""
        return self.message_content


class SessionItem(ListItem):
    """A session in the sidebar"""
    
    def __init__(self, session_id: str, preview: str = ""):
        self.session_id = session_id
        self.preview = preview[:30] + "..." if len(preview) > 30 else preview
        super().__init__()
    
    def compose(self) -> ComposeResult:
        yield Label(f"[bold]{self.session_id[:12]}[/]")
        yield Label(f"[dim]{self.preview}[/]")


class Sidebar(Container):
    """Session sidebar"""
    
    sessions: reactive[List[Dict]] = reactive([])
    
    def compose(self) -> ComposeResult:
        yield Static("[bold]Sessions[/]", id="sidebar-title")
        yield ListView(id="session-list")
        yield Button("+ New Chat", id="new-chat-btn", variant="primary")
    
    def update_sessions(self, sessions: List[Dict]):
        """Update the session list"""
        list_view = self.query_one("#session-list", ListView)
        list_view.clear()
        for session in sessions:
            list_view.append(SessionItem(
                session.get("id", "unknown"),
                session.get("preview", "")
            ))


class ChatPanel(Container):
    """Main chat panel"""
    
    messages: reactive[List[Dict]] = reactive([])
    is_loading: reactive[bool] = reactive(False)
    
    def compose(self) -> ComposeResult:
        yield ScrollableContainer(id="messages-container")
        with Horizontal(id="input-row"):
            yield Input(placeholder="Type your message...", id="chat-input")
            yield Button("Send", id="send-btn", variant="success")
    
    def add_message(self, role: str, content: str, tool_calls: List[Dict] = None):
        """Add a message to the chat"""
        container = self.query_one("#messages-container", ScrollableContainer)
        container.mount(ChatMessage(role, content, tool_calls))
        container.scroll_end()
    
    def set_loading(self, loading: bool):
        """Set loading state"""
        self.is_loading = loading
        send_btn = self.query_one("#send-btn", Button)
        send_btn.disabled = loading
        send_btn.label = "..." if loading else "Send"


class ToolsPanel(Container):
    """Panel showing current tool executions"""
    
    def compose(self) -> ComposeResult:
        yield Static("[bold]Tools[/]", id="tools-title")
        yield ScrollableContainer(id="tools-container")
    
    def add_tool_execution(self, tool_name: str, status: str, result: str = None):
        """Show a tool execution"""
        container = self.query_one("#tools-container", ScrollableContainer)
        status_icon = {"pending": "○", "executing": "◐", "completed": "✓", "failed": "✗"}.get(status, "?")
        
        content = f"{status_icon} [bold]{tool_name}[/]"
        if result:
            content += f"\n   [dim]{str(result)[:50]}[/]"
        
        container.mount(Static(content, classes="tool-execution"))
        container.scroll_end()
    
    def clear(self):
        """Clear tool executions"""
        container = self.query_one("#tools-container", ScrollableContainer)
        container.remove_children()


class XerxoTUI(App):
    """
    Xerxo Terminal User Interface
    
    A full-screen interface for interacting with Xerxo agents.
    """
    
    CSS = """
    Screen {
        layout: horizontal;
    }
    
    Sidebar {
        width: 25;
        background: $surface;
        border-right: solid $primary;
        padding: 1;
    }
    
    #sidebar-title {
        text-align: center;
        padding: 1;
        background: $primary;
        color: $text;
    }
    
    #session-list {
        height: auto;
        max-height: 20;
    }
    
    #new-chat-btn {
        margin-top: 1;
        width: 100%;
    }
    
    ChatPanel {
        width: 1fr;
        padding: 1;
    }
    
    #messages-container {
        height: 1fr;
        border: solid $primary-lighten-2;
        padding: 1;
    }
    
    #input-row {
        height: 3;
        margin-top: 1;
    }
    
    #chat-input {
        width: 1fr;
    }
    
    #send-btn {
        width: 10;
        margin-left: 1;
    }
    
    ChatMessage {
        margin-bottom: 1;
        padding: 1;
        background: $surface-lighten-1;
    }
    
    .message-role {
        margin-bottom: 0;
    }
    
    .message-content {
        padding-left: 2;
    }
    
    .tool-header {
        margin-top: 1;
    }
    
    .tool-item {
        color: $text-muted;
    }
    
    ToolsPanel {
        width: 30;
        background: $surface;
        border-left: solid $primary;
        padding: 1;
        display: none;
    }
    
    ToolsPanel.-visible {
        display: block;
    }
    
    #tools-title {
        text-align: center;
        padding: 1;
        background: $warning;
        color: $text;
    }
    
    #tools-container {
        height: 1fr;
    }
    
    .tool-execution {
        padding: 1;
        border-bottom: solid $primary-lighten-3;
    }
    """
    
    BINDINGS = [
        Binding("ctrl+n", "new_chat", "New Chat"),
        Binding("ctrl+t", "toggle_tools", "Toggle Tools"),
        Binding("ctrl+s", "toggle_sidebar", "Toggle Sidebar"),
        Binding("ctrl+c", "copy_last", "Copy Last"),
        Binding("ctrl+q", "quit", "Quit"),
        Binding("escape", "focus_input", "Focus Input"),
        Binding("up", "scroll_up", "Scroll Up", show=False),
        Binding("down", "scroll_down", "Scroll Down", show=False),
    ]
    
    def __init__(
        self,
        api_url: str = None,
        api_key: str = None,
        session_id: str = None
    ):
        super().__init__()
        self.api_url = api_url or "https://api.xerxo.ai"
        self.api_key = api_key
        self.session_id = session_id
        self.sessions: List[Dict] = []
    
    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        yield Sidebar(id="sidebar")
        yield ChatPanel(id="chat-panel")
        yield ToolsPanel(id="tools-panel")
        yield Footer()
    
    def on_mount(self) -> None:
        """Called when the app is mounted"""
        self.title = "Xerxo"
        self.sub_title = "AI-Powered Business Operations"
        
        # Focus the input
        chat_input = self.query_one("#chat-input", Input)
        chat_input.focus()
        
        # Add welcome message
        chat_panel = self.query_one("#chat-panel", ChatPanel)
        chat_panel.add_message(
            "assistant",
            "Welcome to Xerxo! I'm your AI assistant.\n\n"
            "I can help you manage tasks, run workflows, search data, and more.\n"
            "Just type your message and press Enter or click Send.\n\n"
            "Tips:\n"
            "• Ctrl+C - Copy last response\n"
            "• Ctrl+N - New chat\n"
            "• Ctrl+T - Toggle tools panel\n"
            "• Ctrl+Q - Quit"
        )
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses"""
        if event.button.id == "send-btn":
            await self.send_message()
        elif event.button.id == "new-chat-btn":
            self.action_new_chat()
    
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle Enter key in input"""
        if event.input.id == "chat-input":
            await self.send_message()
    
    async def send_message(self) -> None:
        """Send the current message to the agent"""
        chat_input = self.query_one("#chat-input", Input)
        message = chat_input.value.strip()
        
        if not message:
            return
        
        chat_input.value = ""
        chat_panel = self.query_one("#chat-panel", ChatPanel)
        tools_panel = self.query_one("#tools-panel", ToolsPanel)
        
        # Add user message
        chat_panel.add_message("user", message)
        
        # Set loading state
        chat_panel.set_loading(True)
        tools_panel.clear()
        
        # Send to agent
        try:
            async with XerxoClient(self.api_url, self.api_key) as client:
                response = await client.agent_run(
                    message=message,
                    session_id=self.session_id,
                    channel="tui"
                )
                
                # Update session ID
                if response.session_id:
                    self.session_id = response.session_id
                
                # Show tool calls
                if response.tool_calls:
                    tools_panel.add_class("-visible")
                    for tc in response.tool_calls:
                        tools_panel.add_tool_execution(
                            tc.get("tool_name", "unknown"),
                            tc.get("status", "completed"),
                            tc.get("result")
                        )
                
                # Add response
                chat_panel.add_message(
                    "assistant",
                    response.response or "No response",
                    response.tool_calls
                )
                
        except Exception as e:
            chat_panel.add_message("assistant", f"[red]Error: {e}[/]")
        
        finally:
            chat_panel.set_loading(False)
            chat_input.focus()
    
    def action_new_chat(self) -> None:
        """Start a new chat session"""
        self.session_id = None
        
        # Clear messages
        container = self.query_one("#messages-container", ScrollableContainer)
        container.remove_children()
        
        # Add welcome message
        chat_panel = self.query_one("#chat-panel", ChatPanel)
        chat_panel.add_message("assistant", "New chat started. How can I help you?")
        
        # Clear tools
        tools_panel = self.query_one("#tools-panel", ToolsPanel)
        tools_panel.clear()
        tools_panel.remove_class("-visible")
    
    def action_toggle_tools(self) -> None:
        """Toggle the tools panel"""
        tools_panel = self.query_one("#tools-panel", ToolsPanel)
        tools_panel.toggle_class("-visible")
    
    def action_toggle_sidebar(self) -> None:
        """Toggle the sidebar"""
        sidebar = self.query_one("#sidebar", Sidebar)
        sidebar.display = not sidebar.display
    
    def action_focus_input(self) -> None:
        """Focus the chat input"""
        chat_input = self.query_one("#chat-input", Input)
        chat_input.focus()
    
    def action_copy_last(self) -> None:
        """Copy the last assistant message to clipboard"""
        import subprocess
        
        container = self.query_one("#messages-container", ScrollableContainer)
        messages = container.query(ChatMessage)
        
        # Find last assistant message
        last_assistant = None
        for msg in messages:
            if msg.role == "assistant":
                last_assistant = msg
        
        if last_assistant:
            content = last_assistant.message_content
            
            # Try to copy to clipboard using system tools
            try:
                # Try pbcopy (macOS)
                process = subprocess.Popen(['pbcopy'], stdin=subprocess.PIPE)
                process.communicate(content.encode('utf-8'))
                self.notify("Copied to clipboard!", severity="information")
            except FileNotFoundError:
                try:
                    # Try xclip (Linux)
                    process = subprocess.Popen(['xclip', '-selection', 'clipboard'], stdin=subprocess.PIPE)
                    process.communicate(content.encode('utf-8'))
                    self.notify("Copied to clipboard!", severity="information")
                except FileNotFoundError:
                    try:
                        # Try xsel (Linux)
                        process = subprocess.Popen(['xsel', '--clipboard', '--input'], stdin=subprocess.PIPE)
                        process.communicate(content.encode('utf-8'))
                        self.notify("Copied to clipboard!", severity="information")
                    except FileNotFoundError:
                        # Save to file as fallback
                        import tempfile
                        import os
                        filepath = os.path.join(tempfile.gettempdir(), "xerxo_last_message.txt")
                        with open(filepath, 'w') as f:
                            f.write(content)
                        self.notify(f"Saved to {filepath}", severity="information")
        else:
            self.notify("No assistant message to copy", severity="warning")
    
    def action_scroll_up(self) -> None:
        """Scroll messages up"""
        container = self.query_one("#messages-container", ScrollableContainer)
        container.scroll_up()
    
    def action_scroll_down(self) -> None:
        """Scroll messages down"""
        container = self.query_one("#messages-container", ScrollableContainer)
        container.scroll_down()


def main():
    """Run the TUI"""
    app = XerxoTUI()
    app.run()


if __name__ == "__main__":
    main()
