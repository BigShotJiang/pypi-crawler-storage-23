"""
Gateway Server - Self-hosted Xerxo gateway

This provides a local gateway server that can:
- Handle channel connections (WhatsApp, Telegram, etc.)
- Route messages to agents
- Provide WebSocket connections for real-time updates
"""

import asyncio
import logging
from datetime import datetime, timezone
from typing import Dict, Optional, List
import uuid

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from xerxo.config import XerxoConfig

logger = logging.getLogger(__name__)


class MessageRequest(BaseModel):
    """Incoming message request"""
    channel: str
    sender_id: str
    message: str
    metadata: Dict = {}


class MessageResponse(BaseModel):
    """Outgoing message response"""
    success: bool
    response: Optional[str] = None
    error: Optional[str] = None


class GatewayState:
    """Gateway state management"""
    
    def __init__(self):
        self.connections: Dict[str, WebSocket] = {}
        self.channel_handlers: Dict[str, "ChannelHandler"] = {}
        self.message_queue: asyncio.Queue = asyncio.Queue()
        self.sessions: Dict[str, Dict] = {}
    
    async def broadcast(self, event_type: str, data: Dict):
        """Broadcast event to all connected clients"""
        message = {"type": event_type, "data": data, "timestamp": datetime.now(timezone.utc).isoformat()}
        
        disconnected = []
        for conn_id, ws in self.connections.items():
            try:
                await ws.send_json(message)
            except Exception:
                disconnected.append(conn_id)
        
        for conn_id in disconnected:
            del self.connections[conn_id]


class ChannelHandler:
    """Base class for channel handlers"""
    
    def __init__(self, channel_type: str, config: Dict):
        self.channel_type = channel_type
        self.config = config
        self.connected = False
    
    async def connect(self) -> bool:
        """Connect to the channel"""
        raise NotImplementedError
    
    async def disconnect(self):
        """Disconnect from the channel"""
        raise NotImplementedError
    
    async def send_message(self, recipient: str, message: str) -> bool:
        """Send a message to a recipient"""
        raise NotImplementedError
    
    async def handle_incoming(self, message: Dict) -> str:
        """Handle an incoming message and return response"""
        raise NotImplementedError


def create_app(config: XerxoConfig = None) -> FastAPI:
    """Create the gateway FastAPI application"""
    
    app = FastAPI(
        title="Xerxo Gateway",
        description="Self-hosted Xerxo gateway server",
        version="1.0.0"
    )
    
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    state = GatewayState()
    app.state.gateway = state
    app.state.config = config or XerxoConfig()
    
    @app.get("/")
    async def root():
        """Gateway root"""
        return {
            "name": "Xerxo Gateway",
            "version": "1.0.0",
            "status": "running"
        }
    
    @app.get("/health")
    async def health():
        """Health check"""
        return {
            "status": "healthy",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "connections": len(state.connections),
            "channels": list(state.channel_handlers.keys())
        }
    
    @app.post("/api/message", response_model=MessageResponse)
    async def handle_message(request: MessageRequest):
        """Handle incoming message from a channel"""
        try:
            # Get or create session
            session_key = f"{request.channel}:{request.sender_id}"
            if session_key not in state.sessions:
                state.sessions[session_key] = {
                    "id": f"session_{uuid.uuid4().hex[:12]}",
                    "channel": request.channel,
                    "sender_id": request.sender_id,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                    "messages": []
                }
            
            session = state.sessions[session_key]
            
            # Add message to session
            session["messages"].append({
                "role": "user",
                "content": request.message,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            
            # Forward to Xerxo API for processing
            from xerxo.client import XerxoClient
            
            async with XerxoClient(
                app.state.config.api_url,
                app.state.config.api_key
            ) as client:
                response = await client.agent_run(
                    message=request.message,
                    user_id=request.sender_id,
                    session_id=session["id"],
                    channel=request.channel
                )
                
                agent_response = response.response or "I couldn't process that message."
                
                # Add to session
                session["messages"].append({
                    "role": "assistant",
                    "content": agent_response,
                    "timestamp": datetime.now(timezone.utc).isoformat()
                })
                
                # Broadcast update
                await state.broadcast("message", {
                    "session_id": session["id"],
                    "channel": request.channel,
                    "sender_id": request.sender_id,
                    "response": agent_response
                })
                
                return MessageResponse(success=True, response=agent_response)
                
        except Exception as e:
            logger.error(f"Error handling message: {e}", exc_info=True)
            return MessageResponse(success=False, error=str(e))
    
    @app.websocket("/ws")
    async def websocket_endpoint(websocket: WebSocket):
        """WebSocket endpoint for real-time updates"""
        await websocket.accept()
        
        conn_id = f"conn_{uuid.uuid4().hex[:8]}"
        state.connections[conn_id] = websocket
        
        logger.info(f"WebSocket connected: {conn_id}")
        
        try:
            while True:
                data = await websocket.receive_json()
                
                # Handle client messages
                msg_type = data.get("type")
                
                if msg_type == "ping":
                    await websocket.send_json({"type": "pong"})
                
                elif msg_type == "subscribe":
                    # Subscribe to events
                    pass
                
                elif msg_type == "message":
                    # Process chat message
                    request = MessageRequest(
                        channel="websocket",
                        sender_id=conn_id,
                        message=data.get("message", "")
                    )
                    result = await handle_message(request)
                    await websocket.send_json({
                        "type": "response",
                        "data": result.dict()
                    })
        
        except WebSocketDisconnect:
            logger.info(f"WebSocket disconnected: {conn_id}")
        except Exception as e:
            logger.error(f"WebSocket error: {e}")
        finally:
            if conn_id in state.connections:
                del state.connections[conn_id]
    
    @app.get("/api/channels")
    async def list_channels():
        """List connected channels"""
        channels = []
        for channel_type, handler in state.channel_handlers.items():
            channels.append({
                "type": channel_type,
                "connected": handler.connected,
                "config": {k: "***" if "token" in k.lower() else v 
                          for k, v in handler.config.items()}
            })
        return {"channels": channels}
    
    @app.post("/api/channels/{channel_type}/connect")
    async def connect_channel(channel_type: str, config: Dict = {}):
        """Connect a channel"""
        # This would initialize the appropriate channel handler
        # For now, just track it
        state.channel_handlers[channel_type] = ChannelHandler(channel_type, config)
        return {"success": True, "message": f"{channel_type} channel registered"}
    
    @app.get("/api/sessions")
    async def list_sessions():
        """List active sessions"""
        return {
            "sessions": [
                {
                    "id": s["id"],
                    "channel": s["channel"],
                    "messages": len(s["messages"]),
                    "created_at": s["created_at"]
                }
                for s in state.sessions.values()
            ]
        }
    
    @app.get("/api/sessions/{session_id}")
    async def get_session(session_id: str):
        """Get session details"""
        for session in state.sessions.values():
            if session["id"] == session_id:
                return {"session": session}
        raise HTTPException(404, "Session not found")
    
    return app
