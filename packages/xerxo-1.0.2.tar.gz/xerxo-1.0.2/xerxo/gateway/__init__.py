"""
Gateway module - Self-hosted Xerxo gateway
"""

from xerxo.gateway.server import create_app

__all__ = ["create_app"]
