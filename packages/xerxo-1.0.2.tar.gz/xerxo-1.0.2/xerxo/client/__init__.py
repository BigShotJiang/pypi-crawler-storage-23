"""
Xerxo API Client - HTTP client for Xerxo platform
"""

import asyncio
import json
from typing import Any, AsyncGenerator, Dict, List, Optional
from urllib.parse import urljoin

import httpx
from pydantic import BaseModel


class AgentRunResponse(BaseModel):
    """Response from agent run"""
    success: bool
    response: Optional[str] = None
    run_id: Optional[str] = None
    tool_calls: List[Dict] = []
    artifacts: List[str] = []
    session_id: Optional[str] = None
    error: Optional[str] = None


class XerxoClient:
    """
    Async HTTP client for Xerxo API
    
    Usage:
        async with XerxoClient(api_url, api_key) as client:
            response = await client.agent_run("Hello")
    """
    
    def __init__(
        self,
        api_url: str = "https://api.xerxo.ai",
        api_key: Optional[str] = None,
        timeout: float = 120.0
    ):
        self.api_url = api_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self._client: Optional[httpx.AsyncClient] = None
    
    async def __aenter__(self):
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(self.timeout),
            headers=self._get_headers()
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._client:
            await self._client.aclose()
    
    def _get_headers(self) -> Dict[str, str]:
        """Get default headers"""
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers
    
    def _url(self, path: str) -> str:
        """Build full URL"""
        return urljoin(self.api_url + "/", path.lstrip("/"))
    
    async def _get(self, path: str, **params) -> Dict:
        """GET request"""
        resp = await self._client.get(self._url(path), params=params)
        resp.raise_for_status()
        return resp.json()
    
    async def _post(self, path: str, data: Dict = None, **params) -> Dict:
        """POST request"""
        resp = await self._client.post(
            self._url(path),
            json=data or {},
            params=params
        )
        resp.raise_for_status()
        return resp.json()
    
    async def _delete(self, path: str, **params) -> Dict:
        """DELETE request"""
        resp = await self._client.delete(self._url(path), params=params)
        resp.raise_for_status()
        return resp.json()
    
    # ═══════════════════════════════════════════
    # Authentication
    # ═══════════════════════════════════════════
    
    async def login(self, username: str, password: str) -> Dict:
        """Login with username and password"""
        resp = await self._client.post(
            self._url("/api/auth/token"),
            data={"username": username, "password": password},
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        resp.raise_for_status()
        return resp.json()
    
    async def whoami(self) -> Dict:
        """Get current user info"""
        return await self._get("/api/auth/me")
    
    # ═══════════════════════════════════════════
    # Agent Loop
    # ═══════════════════════════════════════════
    
    async def agent_run(
        self,
        message: str,
        user_id: str = "default",
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        channel: str = "cli"
    ) -> AgentRunResponse:
        """Execute agent with full agentic loop"""
        data = {
            "message": message,
            "user_id": user_id,
            "session_id": session_id,
            "agent_id": agent_id,
            "channel": channel,
            "stream": False
        }
        result = await self._post("/api/agent-loop/run", data)
        return AgentRunResponse(**result)
    
    async def agent_run_stream(
        self,
        message: str,
        user_id: str = "default",
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None
    ) -> AsyncGenerator[Dict, None]:
        """Execute agent with streaming responses"""
        data = {
            "message": message,
            "user_id": user_id,
            "session_id": session_id,
            "agent_id": agent_id,
            "stream": True
        }
        
        async with self._client.stream(
            "POST",
            self._url("/api/agent-loop/run/stream"),
            json=data
        ) as resp:
            async for line in resp.aiter_lines():
                if line.startswith("data: "):
                    data_str = line[6:]
                    if data_str == "[DONE]":
                        break
                    yield json.loads(data_str)
    
    async def agent_list(self) -> List[Dict]:
        """List all agents"""
        result = await self._get("/api/admin/agents")
        return result.get("agents", [])
    
    async def agent_tools(self, agent_id: Optional[str] = None) -> List[Dict]:
        """Get available tools for an agent"""
        result = await self._get("/api/agent-loop/tools")
        return result.get("tools", [])
    
    async def agent_config(self, agent_id: Optional[str] = None) -> Dict:
        """Get agent configuration"""
        params = {"agent_id": agent_id} if agent_id else {}
        result = await self._get("/api/agent-loop/config", **params)
        return result.get("config", {})
    
    async def agent_runs(self, user_id: str = "default", limit: int = 20) -> List[Dict]:
        """List recent agent runs"""
        result = await self._get("/api/agent-loop/runs", user_id=user_id, limit=limit)
        return result.get("runs", [])
    
    # ═══════════════════════════════════════════
    # Workflows
    # ═══════════════════════════════════════════
    
    async def workflow_list(self, workspace_id: str = "default") -> List[Dict]:
        """List all workflows"""
        result = await self._get("/api/workflows", workspace_id=workspace_id)
        return result.get("workflows", [])
    
    async def workflow_run(
        self,
        workflow_id: str,
        params: Optional[Dict] = None,
        workspace_id: str = "default"
    ) -> Dict:
        """Execute a workflow"""
        data = {"params": params or {}}
        return await self._post(f"/api/v2/workflows/{workflow_id}/run", data, workspace_id=workspace_id)
    
    async def workflow_status(self, run_id: str) -> Dict:
        """Get workflow run status"""
        return await self._get(f"/api/v2/workflows/runs/{run_id}")
    
    async def workflow_analytics(self, workspace_id: str = "default") -> Dict:
        """Get workflow analytics"""
        return await self._get("/api/workflows/analytics", workspace_id=workspace_id)
    
    # ═══════════════════════════════════════════
    # Skills
    # ═══════════════════════════════════════════
    
    async def skill_list(self, user_id: str = "default") -> List[Dict]:
        """List installed skills"""
        result = await self._get("/api/skills", user_id=user_id)
        return result.get("skills", [])
    
    async def skill_run(self, skill_id: str, user_id: str = "default") -> Dict:
        """Execute a skill"""
        return await self._post(f"/api/skills/{skill_id}/run", user_id=user_id)
    
    async def skill_create(self, skill_data: Dict, user_id: str = "default") -> Dict:
        """Create a new skill"""
        return await self._post("/api/skills", skill_data, user_id=user_id)
    
    async def marketplace_browse(
        self,
        category: Optional[str] = None,
        search: Optional[str] = None,
        limit: int = 50
    ) -> Dict:
        """Browse skill marketplace"""
        params = {"limit": limit}
        if category:
            params["category"] = category
        if search:
            params["search"] = search
        return await self._get("/api/skills/marketplace", **params)
    
    async def marketplace_install(self, marketplace_id: str, user_id: str = "default") -> Dict:
        """Install a skill from marketplace"""
        return await self._post(f"/api/skills/marketplace/{marketplace_id}/install", user_id=user_id)
    
    async def skill_publish(
        self,
        skill_id: str,
        category: str = "general",
        tags: List[str] = None,
        user_id: str = "default"
    ) -> Dict:
        """Publish skill to marketplace"""
        data = {
            "skill_id": skill_id,
            "category": category,
            "tags": tags or []
        }
        return await self._post("/api/skills/marketplace/publish", data, user_id=user_id)
    
    # ═══════════════════════════════════════════
    # Tasks
    # ═══════════════════════════════════════════
    
    async def task_list(
        self,
        user_id: str = "default",
        status: Optional[str] = None,
        limit: int = 50
    ) -> List[Dict]:
        """List tasks"""
        params = {"user_id": user_id, "limit": limit}
        if status:
            params["status"] = status
        result = await self._get("/api/tasks", **params)
        return result.get("tasks", [])
    
    async def task_create(
        self,
        title: str,
        description: str = "",
        priority: str = "medium",
        due_date: Optional[str] = None,
        user_id: str = "default"
    ) -> Dict:
        """Create a task"""
        data = {
            "title": title,
            "description": description,
            "priority": priority,
            "due_date": due_date
        }
        return await self._post("/api/tasks", data, user_id=user_id)
    
    async def task_complete(self, task_id: str, user_id: str = "default") -> Dict:
        """Mark task as complete"""
        return await self._post(f"/api/tasks/{task_id}/complete", user_id=user_id)
    
    async def task_delete(self, task_id: str, user_id: str = "default") -> Dict:
        """Delete a task"""
        return await self._delete(f"/api/tasks/{task_id}", user_id=user_id)
    
    # ═══════════════════════════════════════════
    # Channels
    # ═══════════════════════════════════════════
    
    async def channel_list(self, workspace_id: str = "default") -> List[Dict]:
        """List connected channels"""
        result = await self._get("/api/channels", workspace_id=workspace_id)
        return result.get("channels", [])
    
    async def channel_health(self) -> Dict:
        """Get channel health status"""
        return await self._get("/api/channels/whatsapp-health")
    
    async def channel_connect(self, channel_type: str, config: Dict) -> Dict:
        """Connect a new channel"""
        data = {"type": channel_type, **config}
        return await self._post("/api/channels", data)
    
    # ═══════════════════════════════════════════
    # Gateway
    # ═══════════════════════════════════════════
    
    async def gateway_health(self) -> Dict:
        """Check gateway health"""
        return await self._get("/api/health")
    
    async def gateway_status(self) -> Dict:
        """Get gateway status"""
        return await self._get("/api/gateway/status")
    
    # ═══════════════════════════════════════════
    # Cron Jobs
    # ═══════════════════════════════════════════
    
    async def cron_list(self) -> List[Dict]:
        """List cron jobs"""
        result = await self._get("/api/crons")
        return result.get("crons", [])
    
    async def cron_trigger(self, job_id: str) -> Dict:
        """Manually trigger a cron job"""
        return await self._post(f"/api/crons/{job_id}/trigger")


# Synchronous wrapper for CLI usage
def sync_client(api_url: str, api_key: Optional[str] = None) -> XerxoClient:
    """Create a synchronous client wrapper"""
    return XerxoClient(api_url, api_key)


def run_async(coro):
    """Run an async function synchronously"""
    return asyncio.get_event_loop().run_until_complete(coro)
