"""SQLAlchemy connection helpers for Beads' Dolt database."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL, Engine

DEFAULT_DOLT_HOST = "127.0.0.1"
DEFAULT_DOLT_DATABASE = "beads"
DEFAULT_DOLT_USER = "root"
PORT_RANGE_BASE = 13307
PORT_RANGE_SIZE = 1000


class DoltConfigError(RuntimeError):
    """Raised when Dolt connection configuration cannot be resolved."""


@dataclass(frozen=True)
class DoltConnectionConfig:
    """Resolved Dolt SQL server configuration for SQLAlchemy."""

    workspace_root: Path
    beads_dir: Path
    host: str
    port: int
    database: str
    user: str
    password: str | None = None

    def sqlalchemy_url(self) -> URL:
        """Build SQLAlchemy URL for Dolt's MySQL protocol endpoint."""
        return URL.create(
            drivername="mysql+pymysql",
            username=self.user,
            password=self.password,
            host=self.host,
            port=self.port,
            database=self.database,
        )


@dataclass(frozen=True)
class ConnectionCheck:
    """Structured output from a live DB connectivity check."""

    database_name: str
    server_version: str


def _fnv1a_32(data: str) -> int:
    """Compute FNV-1a 32-bit hash (matches beads' Go implementation)."""
    result = 2166136261
    for byte in data.encode("utf-8"):
        result ^= byte
        result = (result * 16777619) & 0xFFFFFFFF
    return result


def _derive_dolt_port(beads_dir: Path) -> int:
    """Match beads internal/doltserver.DerivePort behavior."""
    abs_path = str(beads_dir.resolve())
    return PORT_RANGE_BASE + (_fnv1a_32(abs_path) % PORT_RANGE_SIZE)


def _load_beads_mcp_config() -> Any | None:
    """Load beads_mcp config if available."""
    try:
        from beads_mcp.config import load_config

        return load_config()
    except Exception:
        return None


def _find_nearest_beads_dir(start: Path) -> Path | None:
    """Find nearest .beads directory by walking up from start."""
    current = start.resolve()
    for candidate in (current, *current.parents):
        beads_dir = candidate / ".beads"
        if beads_dir.is_dir():
            return beads_dir
    return None


def _resolve_beads_dir(workspace_root: Path | None) -> Path:
    """Resolve .beads directory using MCP-aligned discovery order."""
    config = _load_beads_mcp_config()

    candidates: list[Path] = []

    if os.environ.get("BEADS_DIR"):
        candidates.append(Path(os.environ["BEADS_DIR"]))

    if config and getattr(config, "beads_dir", None):
        candidates.append(Path(config.beads_dir))

    if workspace_root is not None:
        candidates.append(workspace_root / ".beads")

    if os.environ.get("BEADS_WORKING_DIR"):
        candidates.append(Path(os.environ["BEADS_WORKING_DIR"]) / ".beads")

    if config and getattr(config, "beads_working_dir", None):
        candidates.append(Path(config.beads_working_dir) / ".beads")

    if os.environ.get("BEADS_DB"):
        candidates.append(Path(os.environ["BEADS_DB"]).parent)

    if config and getattr(config, "beads_db", None):
        candidates.append(Path(config.beads_db).parent)

    if workspace_root is not None:
        nearest = _find_nearest_beads_dir(workspace_root)
    else:
        nearest = _find_nearest_beads_dir(Path.cwd())
    if nearest is not None:
        candidates.append(nearest)

    for candidate in candidates:
        if candidate.is_dir():
            return candidate.resolve()

    raise DoltConfigError(
        "Could not find a .beads directory from BEADS_DIR/BEADS_WORKING_DIR/BEADS_DB "
        "or from the current workspace path."
    )


def _load_metadata(beads_dir: Path) -> dict[str, Any]:
    """Load .beads/metadata.json."""
    metadata_path = beads_dir / "metadata.json"
    if not metadata_path.is_file():
        raise DoltConfigError(f"Missing metadata file: {metadata_path}")

    try:
        return json.loads(metadata_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise DoltConfigError(f"Invalid JSON in {metadata_path}: {exc}") from exc


def _is_dolt_config(metadata: dict[str, Any]) -> bool:
    """Check whether metadata/env describes a Dolt-backed workspace."""
    if metadata.get("backend") == "dolt":
        return True

    if metadata.get("dolt_mode"):
        return True

    if any(k.startswith("dolt_") for k in metadata):
        return True

    return os.environ.get("BEADS_DOLT_SERVER_MODE") in {"1", "true", "TRUE"}


def resolve_dolt_connection_config(
    workspace_root: str | Path | None = None,
) -> DoltConnectionConfig:
    """Resolve Dolt SQL server config used by beads process.

    Configuration sources mirror beads behavior where possible:
    env vars > .beads/dolt-server.port > .beads/metadata.json > derived port.
    """
    root_path = Path(workspace_root).resolve() if workspace_root is not None else None
    beads_dir = _resolve_beads_dir(root_path)
    metadata = _load_metadata(beads_dir)

    if not _is_dolt_config(metadata):
        raise DoltConfigError(
            "The resolved beads workspace is not configured for Dolt server mode. "
            "Expected Dolt metadata/BEADS_DOLT_* settings."
        )

    host = (
        os.environ.get("BEADS_DOLT_SERVER_HOST")
        or metadata.get("dolt_server_host")
        or DEFAULT_DOLT_HOST
    )

    env_port = os.environ.get("BEADS_DOLT_SERVER_PORT")
    if env_port:
        try:
            port = int(env_port)
        except ValueError as exc:
            raise DoltConfigError(
                f"Invalid BEADS_DOLT_SERVER_PORT: {env_port}"
            ) from exc
    else:
        port_file = beads_dir / "dolt-server.port"
        if port_file.is_file():
            raw_port = port_file.read_text(encoding="utf-8").strip()
            try:
                port = int(raw_port)
            except ValueError as exc:
                raise DoltConfigError(
                    f"Invalid dolt-server.port value: {raw_port!r}"
                ) from exc
        elif metadata.get("dolt_server_port"):
            port = int(metadata["dolt_server_port"])
        else:
            port = _derive_dolt_port(beads_dir)

    database = (
        os.environ.get("BEADS_DOLT_SERVER_DATABASE")
        or metadata.get("dolt_database")
        or DEFAULT_DOLT_DATABASE
    )

    user = (
        os.environ.get("BEADS_DOLT_SERVER_USER")
        or metadata.get("dolt_server_user")
        or DEFAULT_DOLT_USER
    )

    password = (
        os.environ.get("BEADS_DOLT_PASSWORD")
        or os.environ.get("BEADS_DOLT_SERVER_PASS")
        or None
    )

    return DoltConnectionConfig(
        workspace_root=beads_dir.parent,
        beads_dir=beads_dir,
        host=host,
        port=port,
        database=database,
        user=user,
        password=password,
    )


def create_dolt_engine(config: DoltConnectionConfig) -> Engine:
    """Create SQLAlchemy engine targeting the resolved Dolt server."""
    return create_engine(config.sqlalchemy_url(), pool_pre_ping=True)


def check_connection(engine: Engine) -> ConnectionCheck:
    """Run a minimal live query to validate connectivity and target database."""
    with engine.connect() as connection:
        row = (
            connection.execute(
                text("SELECT DATABASE() AS database_name, VERSION() AS server_version")
            )
            .mappings()
            .one()
        )
    return ConnectionCheck(
        database_name=str(row["database_name"]),
        server_version=str(row["server_version"]),
    )
