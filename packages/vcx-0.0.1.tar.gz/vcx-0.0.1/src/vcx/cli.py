"""Command-line interface for vcx."""

from pathlib import Path

import typer
from sqlalchemy.exc import SQLAlchemyError

from vcx import __version__
from vcx.dolt_sqlalchemy import (
    DoltConfigError,
    check_connection,
    create_dolt_engine,
    resolve_dolt_connection_config,
)

app = typer.Typer(
    name="vcx",
    help="workflow harness",
    add_completion=False,
)


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        typer.echo(f"vcx version: {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool | None = typer.Option(
        None,
        "--version",
        "-v",
        help="Show version and exit.",
        callback=version_callback,
        is_eager=True,
    ),
) -> None:
    """workflow harness."""


@app.command()
def hello(
    name: str = typer.Argument("World", help="Name to greet"),
) -> None:
    """Say hello to someone."""
    typer.echo(f"Hello, {name}!")


@app.command("beads-dolt-connect")
def beads_dolt_connect(
    workspace_root: Path | None = typer.Option(  # noqa: B008
        None,
        "--workspace-root",
        help="Workspace root used to resolve .beads metadata.",
    ),
) -> None:
    """Connect to the Dolt SQL server used by beads and run a validation query."""
    try:
        config = resolve_dolt_connection_config(workspace_root=workspace_root)
        engine = create_dolt_engine(config)
        check = check_connection(engine)
    except DoltConfigError as exc:
        typer.echo(f"Configuration error: {exc}")
        raise typer.Exit(code=1) from exc
    except SQLAlchemyError as exc:
        typer.echo(f"Connection error: {exc}")
        raise typer.Exit(code=1) from exc

    typer.echo("Connected to beads Dolt database via SQLAlchemy.")
    typer.echo(f"Workspace: {config.workspace_root}")
    typer.echo(f"Beads dir: {config.beads_dir}")
    typer.echo(f"Host: {config.host}")
    typer.echo(f"Port: {config.port}")
    typer.echo(f"Database: {check.database_name}")
    typer.echo(f"Server version: {check.server_version}")


if __name__ == "__main__":
    app()
