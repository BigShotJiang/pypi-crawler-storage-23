"""Shared test fixtures and mock setup."""
