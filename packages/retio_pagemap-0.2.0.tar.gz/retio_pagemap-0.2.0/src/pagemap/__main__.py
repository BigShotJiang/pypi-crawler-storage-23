"""Allow running pagemap as a module: python -m pagemap.cli"""

from .cli import main

main()
