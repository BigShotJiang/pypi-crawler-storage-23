from funpayparsers.parsers import PrivateChatPreviewsParser
import timeit



HTML = """
<a href="https://funpay.com/chat/?node=1234567890" class="contact-item" data-id="1234567890" data-node-msg="123123123123" data-user-msg="123123123123">
    <div class="contact-item-photo">
        <div class="avatar-photo" style="background-image: url(https://sfunpay.com/s/avatar/dc/nc/someavatar.jpg);"></div>
    </div>
    <div class="media-user-name">Aboba123</div>
    <div class="contact-item-message">wklejfwlkefj lkwejf lwkefj lwekj2l3kj 2l3kf j2;3lfk j23;lfk j2 ;flkwsjd f;lk2j f;lkwje f;l2kj</div>
    <div class="contact-item-time">23:59</div>
</a>
"""

HTML_10K = '\n'.join(HTML for _ in range(100000))


import time
start=time.time()
parser = PrivateChatPreviewsParser(raw_source=HTML_10K)
result = parser.parse()
stop=time.time()

print('В одном HTML')
print(len(result))
print(stop-start)


r = timeit.timeit('PrivateChatPreviewsParser(raw_source=HTML); parser.parse()', number=100000, globals=globals())
print('100к вызовов')
print(r)
