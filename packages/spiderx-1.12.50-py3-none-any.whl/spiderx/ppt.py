﻿# encoding: utf-8
import re,sys,os,time,datetime,requests,json
from spiderx import sx
from PIL import Image, ImageDraw,ImageFont
from collections import defaultdict
import numpy as np
import imageio
from . import sx
ff=sx.FFMPEG()
fonts_dict={}
def 计算时间(时间毫秒):
    return sx.时间秒转日期格式(int(时间毫秒 / 1000))
class FRAME:
    def __init__(self,frame_num,视频宽,视频高,背景图片,头像图片,显示头像=True,头像尺寸=200,字体路径=None,istest=False):
        self.istest = istest
        self.frame_num=frame_num
        self.frame_fname=f'{frame_num:0=6}.png'
        self.视频宽=视频宽
        self.视频高=视频高
        self.背景图片=self.加载图片(背景图片)
        self.头像图片=self.加载图片(头像图片)
        self.显示头像=显示头像
        self.头像尺寸=头像尺寸
        self.头像尺寸_padding=10
        self.字体路径=字体路径
        #----------------------------
        self.frame_size = (self.视频宽, self.视频高)
        self.frame_size_竖屏 = None #如果
        self.frame_size_default=(800,600) #绘图数据的标准尺寸
        self.img_背景图片 = None
        self.img_导出 = None
        self.img_画图 = None
        self.加载背景()
        if self.显示头像:
            self.加载头像()
    def 颜色转RGBA(self,颜色值,透明度:int=1):
        颜色值 = 颜色值.lstrip('#')
        r = int(颜色值[0:2], 16)  # 0x30 = 48
        g = int(颜色值[2:4], 16)  # 0x00 = 0
        b = int(颜色值[4:6], 16)  # 0x00 = 0
        # 添加透明度
        if 0<=透明度<=1:
            alpha_int = int(255*透明度)  # 127
        else:
            alpha_int = 255
        return (r, g, b, alpha_int)
    def 加载图片(self,图片):
        if isinstance(图片,str):
            if os.path.exists(图片):
                return Image.open(图片).convert('RGBA') #RGBA
            else:
                raise Exception('没有找到图片')
        elif type(图片)!=Image.Image:
            return Image.fromarray(图片).convert('RGBA')
        else:
            return 图片
    def 检查是否转竖屏(self, bg_image):
        if bg_image.size != self.frame_size:
            width, height = bg_image.size
            if width < height:  # 竖向图片
                # 创建透明背景
                bg = Image.new("RGBA", self.frame_size, (255, 255, 255, 0))
                # 计算缩放后的尺寸
                newH = int(self.frame_size[1])
                newW = int(newH * (width / height))
                self.frame_size_竖屏=(newW,newH)
                # 调整图片大小
                bg_image = bg_image.resize((newW, newH),Image.Resampling.LANCZOS)
                bg_image = bg_image.crop((0, 0, newW, self.frame_size[1]))
                # 将图片粘贴到背景中央
                x_position = round((self.frame_size[0] - newW) / 2)
                bg.paste(bg_image, (x_position, 0),bg_image)# 注意第三个参数是遮罩
                bg_image = bg
            else:
                bg_image = bg_image.resize(self.frame_size,Image.Resampling.LANCZOS)
        return bg_image
    def z(self, w=None, h=None,point=(),points=[]):
        '''修正坐标：将坐标从原始尺寸缩放到新尺寸'''
        if self.frame_size_竖屏:
            #下面的应该怎么调整呢
            比例X = self.frame_size_竖屏[0] / self.frame_size[0]  # 宽度缩放
            比例Y = self.frame_size_竖屏[1] / self.frame_size[1]  # 高度缩放
            padding_X=(self.frame_size[0]-self.frame_size_竖屏[0])/2
            padding_Y=(self.frame_size[1]-self.frame_size_竖屏[1])/2
            标准X = self.frame_size[0] / self.frame_size_default[0]  # 宽度缩放
            标准Y = self.frame_size[1] / self.frame_size_default[1]  # 高度缩放
            change_w = lambda w: round(padding_X + (w * 比例X * 标准X))
            change_h = lambda h: round(padding_Y + (h * 比例Y * 标准Y))
            #--------------------------------------------------------------------------------------
            if w is not None:return change_w(w)
            elif h is not None:return change_h(h)
            elif point:return ( change_w(point[0]),change_h(point[1]) )
            elif points:return [ ( change_w(point[0]),change_h(point[1]) ) for point in points ]
        elif self.frame_size != self.frame_size_default:
            #生成尺寸不是默认尺寸修正点位
            标准X = self.frame_size[0] / self.frame_size_default[0]  # 宽度缩放
            标准Y = self.frame_size[1] / self.frame_size_default[1]  # 高度缩放
            change_w = lambda w : round(w * 标准X)
            change_h = lambda h : round(h * 标准Y)
            # --------------------------------------------------------------------------------------
            if w is not None:return change_w(w)
            elif h is not None:return change_h(h)
            elif point:return ( change_w(point[0]),change_h(point[1]) )
            elif points:return [ ( change_w(point[0]),change_h(point[1]) ) for point in points ]
        else:
            change_w = lambda w : w
            change_h = lambda h : h
            # --------------------------------------------------------------------------------------
            if w is not None:return change_w(w)
            elif h is not None:return change_h(h)
            elif point:return ( change_w(point[0]),change_h(point[1]) )
            elif points:return [ ( change_w(point[0]),change_h(point[1]) ) for point in points ]
    def f(self,font_size):
        '''修正字体大小'''
        if self.frame_size_竖屏:
            bl1=self.frame_size_竖屏[1]/self.frame_size[1]
            bl2=self.frame_size[1]/self.frame_size_default[1]
            return int(font_size * bl1 * bl2)
        if self.frame_size != self.frame_size_default:
            # 获取字体高度
            return int(font_size * (self.frame_size[1] / self.frame_size_default[1]))
        return font_size
    def 加载背景(self):
        """加载并调整背景图片尺寸"""
        bg = self.背景图片
        bg = self.检查是否转竖屏(bg_image=bg)
        # 保存原始背景图片用于后续的粘贴操作
        self.img_背景图片 = bg.copy()
        self.img_画图 = ImageDraw.Draw(self.img_背景图片)
        self.img_导出 = self.img_背景图片
    def 加载头像(self):
        """加载头像图片并粘贴到右上角"""
        if self.显示头像 and not self.头像图片 is None:
            pic = self.头像图片
            pic_w, pic_h = pic.size
            scale_factor = pic_w / pic_h
            new_w = self.头像尺寸
            new_h = round(new_w / scale_factor)
            pic_resized = pic.resize((new_w, new_h), Image.Resampling.LANCZOS)          # 缩放头像
            avatar_x = self.视频宽 - new_w - self.头像尺寸_padding
            avatar_y = self.头像尺寸_padding
            pic_pos = (avatar_x, avatar_y)
            self.img_背景图片.paste(pic_resized, pic_pos, pic_resized)
            self.img_导出 = self.img_背景图片
        else:
            # 如果不显示头像，则 final_image 就是原始背景
            self.img_导出 = self.img_背景图片
    def 画直线(self,起点,终点, 颜色="black", 线条宽度=1,透明度=1):
        self.img_画图.line(self.z(points=[起点, 终点]), fill=self.颜色转RGBA(颜色值=颜色,透明度=透明度), width=线条宽度)
    def 文本(self,text, x,y, 颜色="black", 字体路径=None, 字体大小=20,透明度=1):
        if not 字体路径:
            字体路径=self.字体路径
        字体大小 = self.f(font_size=字体大小)
        if 字体路径 and os.path.exists(字体路径):
            font_name=(字体路径,字体大小)
            if font_name in fonts_dict.keys():
                font=fonts_dict[font_name]
            else:
                font = ImageFont.truetype(字体路径, 字体大小)
                fonts_dict[font_name]=font
        else:
            font = ImageFont.load_default(字体大小)
        self.img_画图.text(self.z(point=[x,y]), text, fill=self.颜色转RGBA(颜色值=颜色,透明度=透明度), font=font)
    def 画圆(self, 中心点:tuple, 半径:float, 颜色="black", 线条宽度=1,透明度=1):
        左上角 = (中心点[0] - 半径, 中心点[1] - 半径)
        右下角 = (中心点[0] + 半径, 中心点[1] + 半径)
        self.img_画图.ellipse(self.z(points=[左上角, 右下角]), outline=self.颜色转RGBA(颜色值=颜色,透明度=透明度), width=线条宽度)
    def 画曲线(self,points,颜色='black',线条宽度=1,透明度=1):
        ''' points=[(100,100),(200,200)] '''
        self.img_画图.line(self.z(points=points), fill=self.颜色转RGBA(颜色值=颜色,透明度=透明度), width=线条宽度)
    def 画方块(self,起点,终点, 颜色="black",线条宽度=1,透明度=1):
        x1, y1 = 起点
        x2, y2 = 终点
        # 确保左小于右，上小于下
        x1, x2 = min(x1, x2), max(x1, x2)
        y1, y2 = min(y1, y2), max(y1, y2)
        # 绘制矩形轮廓
        self.img_画图.rectangle([self.z(w=x1), self.z(h=y1), self.z(w=x2), self.z(h=y2)], outline=self.颜色转RGBA(颜色值=颜色,透明度=透明度), width=线条宽度)
    def 画点列表(self,points:list, 颜色="black",透明度=1):
        for point in points:
            # #画加号
            # 半径 = 线条宽度 // 2
            # self.img_画图.ellipse([point[0] - 半径, point[1] - 半径, point[0] + 半径, point[1] + 半径], fill=颜色, outline=颜色)
            self.img_画图.point(self.z(point=point),fill=self.颜色转RGBA(颜色值=颜色,透明度=透明度))
    def 导出图片(self,保存路径=None):
        """返回最终处理好的 PIL Image 对象"""
        if self.img_导出 is None:
            self.img_导出 = self.img_背景图片
        if 保存路径:
            path_dir, fname = os.path.split(保存路径)
            os.makedirs(path_dir,exist_ok=1)
            self.img_导出.save(保存路径)
        else:
            if self.istest:
                save_dir=os.path.abspath('frame_images')
                os.makedirs(save_dir, exist_ok=1)
                save_name=os.path.join(save_dir,self.frame_fname)
                self.img_导出.save(save_name)
            '''
            #if self.img_导出.mode == 'RGBA':
            #import numpy as np
            #return np.array(self.img_导出)
            '''
            return np.array(self.img_导出)
class VIDEO:
    def __init__(self,帧率,视频高,视频宽,视频路径,音频路径,保存路径,显示头像=False,头像尺寸=200,线程数=10,istest=False,font:str=None,start_frame=0):
        self.istest=istest
        self.font=font
        self.分组长度=50
        self.背景图片_文件夹='ppt'
        self.显示头像=显示头像
        self.头像尺寸=头像尺寸
        self.线程数=线程数
        self.帧率=帧率
        self.视频路径=os.path.abspath(视频路径)
        self.音频路径=os.path.abspath(音频路径)
        self.保存路径 = os.path.abspath(保存路径)
        self.生成视频路径=os.path.abspath('create.mp4')
        self.视频高=视频高
        self.视频宽=视频宽
        self.frame_size=(self.视频宽,self.视频高)
        self.frame_size_default=(800,600)
        self.背景图片_image_白色背景 = np.ones((self.frame_size[1], self.frame_size[0], 3), dtype=np.uint8) * 255
        #self.背景图片_image_黑色背景 = np.zeros((self.frame_size[1], self.frame_size[0], 3), dtype=np.uint8)
        self.背景图片_frame_num_data={}
        self.背景图片_docId_data={}
        self.背景图片_docId_原图片_size_newWidth={}
        self.背景图片_docId_image_objects={}
        self.画图数据_docId_列表=defaultdict(list)
        self.start_frame=start_frame
    def 计算帧(self,时间毫秒):
        return round((时间毫秒/1000)*self.帧率)
    def 添加_背景图片(self,docId,时间毫秒,图片链接,数据):
        pic_obj={}
        pic_obj['docId'] = docId
        pic_obj['frame_num']=self.计算帧(时间毫秒)
        pic_obj['show_time']=计算时间(时间毫秒)
        pic_obj['path'] = f'{self.背景图片_文件夹}/{docId}.jpg'
        pic_obj['data'] = 数据
        pic_obj['url'] = 图片链接
        self.背景图片_frame_num_data[pic_obj['frame_num']]=pic_obj
        self.背景图片_docId_data[docId]=pic_obj
    def 下载_背景图片(self):
        os.makedirs('ppt',exist_ok=1)
        for k,p in self.背景图片_frame_num_data.items():
            path=os.path.abspath(p['path'])
            if not os.path.exists(path):
                sx.下载文件(文件路径=path,网址=p['url'])
            if os.path.exists(path):
                pil_img = Image.open(path).convert("RGBA")
                self.背景图片_docId_原图片_size_newWidth[p['docId']] = [pil_img.size, int(self.视频高 * (pil_img.size[0] / pil_img.size[1]))]
                if pil_img.size != self.frame_size:
                   pil_img = pil_img.resize(self.frame_size)
                #pil_img = pil_img.resize((600,800)) #竖屏测试
                self.背景图片_docId_image_objects[p['docId']] = pil_img
    def 添加_画图帧(self,draw_id,类型,时间毫秒,数据,docId):
        draw_obj={}
        draw_obj['draw_id']=draw_id
        draw_obj['type']=类型
        draw_obj['frame_num']=self.计算帧(时间毫秒)
        draw_obj['show_time']=计算时间(时间毫秒)
        draw_obj['pic_id']=docId
        draw_obj['data']=数据
        self.画图数据_docId_列表[docId].append(draw_obj)
    @sx.zsq_try
    def worker(self,args):
        [frame_num,docId,视频帧]=args
        bg_frame = self.背景图片_docId_image_objects[docId]
        new_frame = FRAME(frame_num=frame_num, 视频宽=self.视频宽, 视频高=self.视频高, 显示头像=self.显示头像, 头像尺寸=self.头像尺寸, 头像图片=视频帧,背景图片=bg_frame,字体路径=self.font,istest=self.istest)
        new_frame.frame_size_default=self.frame_size_default
        ''' 画图处理逻辑 '''
        # -----------------------------------------------------------
        draws=self.画图数据_docId_列表[docId]
        shapeIds=[]
        for draw in draws[::-1]:
            if draw['frame_num']<=frame_num:
                tp=draw['type']
                data=draw['data']
                if tp=='text':
                    shapes=sx.json_path(data,'$..shapes')
                    if shapes:
                        for shape in shapes:
                            text = shape['text']
                            shapeId = shape['shapeId']
                            if shapeId not in shapeIds:
                                fontSize = shape['fontSize']
                                textColor =shape['textColor']
                                x = shape['x']
                                y = shape['y']
                                new_frame.文本(text=text,字体大小=fontSize,颜色=textColor,x=x,y=y)
                                shapeIds.append(shapeId)
                    else:
                        text = data['data']['text']
                        shapeId = data['data']['shapeId']
                        if shapeId not in shapeIds:
                            fontSize=data['data']['fontSize']
                            textColor=data['data']['textColor']
                            x=data['data']['x']
                            y=data['data']['y']
                            new_frame.文本(text=text, 字体大小=fontSize,颜色=textColor, x=x, y=y)
                            shapeIds.append(shapeId)
                elif tp=='rectangle':
                    shapeId = sx.json_path(draw, '$..data..shapeId')
                    if shapeId not in shapeIds:
                        thickness = sx.json_path(draw, '$..data..thickness')
                        color = sx.json_path(draw, '$..data..color')
                        startX = sx.json_path(draw, '$..data..startX')
                        startY = sx.json_path(draw, '$..data..startY')
                        width = sx.json_path(draw, '$..data..width')
                        height = sx.json_path(draw, '$..data..height')
                        endX = startX + width
                        endY = startY + height
                        new_frame.画方块(起点=(round(startX) , round(startY)),终点=(round(endX), round(endY)),颜色=color,线条宽度=thickness)
                        shapeIds.append(shapeId)
                elif tp=='line':
                    thickness = sx.json_path(draw, '$..data..thickness')
                    color = sx.json_path(draw, '$..data..color')
                    startX = sx.json_path(draw, '$..data..startX')
                    startY = sx.json_path(draw, '$..data..startY')
                    endX = sx.json_path(draw, '$..data..endX')
                    endY = sx.json_path(draw, '$..data..endY')
                    # 绘制直线
                    new_frame.画直线(起点=(startX, startY),终点=(endX, endY),颜色=color,线条宽度=thickness)
                else:
                    shapeId = sx.json_path(draw, '$..data..shapeId')
                    if shapeId not in shapeIds:
                        points=sx.json_path(draw, '$..data..points')
                        thickness=sx.json_path(draw, '$..data..thickness')
                        color=sx.json_path(draw, '$..data..color')
                        if points:
                           new_frame.画曲线(points=[(x['x'],x['y']) for x in points],颜色=color,线条宽度=thickness)
                        shapeIds.append(shapeId)
        return frame_num, new_frame.导出图片()
    def 生成视频(self):
        try:
            reader = imageio.get_reader(self.视频路径)
            fps=reader.get_meta_data()['fps']
            duration=reader.get_meta_data()['duration']
            #codec=reader.get_meta_data()['codec']
            # size=reader.get_meta_data()['size']
            self.视频_帧数=fps
            if self.帧率>=int(fps):self.帧率=int(fps)
            self.视频_总帧数 = int(fps*duration)
            self.视频_时长=计算时间(时间毫秒=duration*1000)
            self.总帧数 = int(duration * self.帧率)
            #video_info={'帧率':fps,'时长':计算时间(duration*1000),'格式':codec,'尺寸':size,'总帧数':int(fps*duration)}
            #sx.pcolor(str(video_info))
            if self.istest:
                测试分钟数=10
                self.总帧数 = self.start_frame + ( 测试分钟数 * 60)
            frame_zu_step = self.线程数  # 线程数
            frame_zu = sx.列表分组(range(self.总帧数), step=self.分组长度)
            frame_zu_count = len(frame_zu)
            start_time = time.time()
            with imageio.get_writer(
                self.生成视频路径,
                fps=self.帧率,
                codec='libx264',  # H.264编码
                macro_block_size=None,  # 自动选择宏块大小
                pixelformat='yuv420p',  # 对于H.264编码，通常使用yuv420p像素格式以保证兼容性，但默认就是yuv420p，所以可以省略
                ffmpeg_params=[
                    #ultrafast > superfast > veryfast > faster > fast > medium > slow > slower > veryslow
                    '-preset', 'faster',  # 默认 medium 编码速度预设 preset设置为'fast'或'faster'
                    '-crf', '23',  # 如果你想要更小的文件，可以增大crf值（比如25、28），但会降低质量。crf的取值范围是0-51，0为无损，23是默认值，51是最差的质量。
                    '-loglevel', 'error',  # 关键：只显示错误
                ]
            ) as writer:
                def callback(rt):
                    frame_num, frame = rt
                    writer.append_data(frame)
                for i, zu in enumerate(frame_zu):
                    args_list = []
                    for frame_num in zu:
                        if frame_num in self.背景图片_frame_num_data.keys():
                            pic_id = self.背景图片_frame_num_data[frame_num]['docId']
                        if self.istest:
                            if frame_num < self.start_frame:
                                continue
                        视频帧 = Image.fromarray(reader.get_data(frame_num)).convert("RGBA")
                        args_list.append((frame_num,pic_id,视频帧))
                    sx.多线程运行(运行函数=self.worker, 回调函数=callback, 参数列表=args_list, 线程数=frame_zu_step, 异步=False)
                    sx.打印_进度条(字符串=f'线程:{self.线程数} 头像:{self.头像尺寸 if self.显示头像 else "关"} 帧率:{self.视频_帧数}->{self.帧率} [page:{pic_id}]', 当前ID=i, 总数=frame_zu_count, 步长=1)
                end_time = time.time()
                sx.pcolor(f'\n时长[{self.视频_时长}] 耗时[{sx.时间秒转日期格式(round(end_time - start_time))}]')
        except Exception as e:
            sx.打印错误(e)
    def 合并音频(self):
        cmd = [
            ff.ffmpeg_path,
            "-i", self.生成视频路径,  # 视频文件
            "-i", self.音频路径 if self.音频路径 else self.视频路径,  # 音频文件
            "-c:v", "copy",  # 直接复制视频流
            "-c:a", "copy",  # 重新编码音频为AAC格式
            "-map", "0:v:0",  # 使用第一个文件的视频
            "-map", "1:a:0",  # 使用第二个文件的音频
            "-shortest",  # 以最短的流结束
            "-y",  # 覆盖输出
            "-loglevel", "error",  # 只输出错误信息
            self.保存路径  # 输出文件
        ]
        ff.执行(cmd, show=True)
        if os.path.exists(self.生成视频路径):
            os.remove(self.生成视频路径)
        if os.path.exists(self.保存路径):
            sx.pcolor(f'保存路径:{self.保存路径}\n')
    def run(self):
        self.下载_背景图片()
        self.生成视频()
        self.合并音频()
if __name__ == '__main__':
    pass
    # cr=FRAME(frame_num=100, 视频宽=800,视频高=600,背景图片='1.png',头像图片='2.png',显示头像=True,头像尺寸=100,istest=True)
    # cr.文本(text= '你好hello！!abc əʊ',x=200,y=300,颜色='#000000',字体路径='font.ttf',字体大小=24)
    # cr.画直线(起点=(100,100),终点=(300,300),颜色='#300000',线条宽度=3)
    # cr.画点列表(points=[(100,100),(200,200)])
    # cr.画方块(起点=(100,100),终点=(200,200))
    # points = [(50, 350), (150, 50), (250, 350), (350, 50)]
    # cr.画曲线(points, 颜色="blue", 线条宽度=3)
    # cr.画圆(中心点=(200, 200), 半径=100, 颜色="red", 线条宽度=3)
    # image=cr.导出图片('a.png')
    # print(image)
    '''
    a=PPT()
    a.添加_背景图片('...')
    a.添加_画图帧()
    a.run()
    '''