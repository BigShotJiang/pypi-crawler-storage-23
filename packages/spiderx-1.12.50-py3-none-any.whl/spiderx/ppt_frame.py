﻿# encoding: utf-8
import os
from PIL import Image, ImageDraw,ImageFont
fonts_dict={}
class FRAME:
    def __init__(self,frame_num,视频宽,视频高,背景图片,头像图片,显示头像=True,头像尺寸=200,字体路径=None,istest=False):
        self.istest = istest
        self.frame_num=frame_num
        self.frame_fname=f'{frame_num:0=6}.png'
        self.视频宽=视频宽
        self.视频高=视频高
        self.背景图片=self.加载图片(背景图片)
        self.头像图片=self.加载图片(头像图片)
        self.显示头像=显示头像
        self.头像尺寸=头像尺寸
        self.头像尺寸_padding=10
        self.字体路径=字体路径
        self.frame_size=(self.视频宽,self.视频高)
        #----------------------------
        self.img_背景图片 = None
        self.img_导出 = None
        self.img_画图 = None
        self.加载背景()
        if self.显示头像:
            self.加载头像()
    def 颜色转RGBA(self,颜色值,透明度:int=1):
        颜色值 = 颜色值.lstrip('#')
        r = int(颜色值[0:2], 16)  # 0x30 = 48
        g = int(颜色值[2:4], 16)  # 0x00 = 0
        b = int(颜色值[4:6], 16)  # 0x00 = 0
        # 添加透明度
        if 0<=透明度<=1:
            alpha_int = int(255*透明度)  # 127
        else:
            alpha_int = 255
        return (r, g, b, alpha_int)
    def 加载图片(self,图片):
        if isinstance(图片,str):
            return Image.open(path).convert('RGBA') #RGBA
        elif type(图片)!=Image.Image:
            return Image.fromarray(图片).convert('RGBA')
        else:
            return 图片
    def 加载背景(self):
        """加载并调整背景图片尺寸"""
        bg = self.背景图片
        bg = bg.resize((self.视频宽, self.视频高), Image.Resampling.LANCZOS)
        # 保存原始背景图片用于后续的粘贴操作
        self.img_背景图片 = bg.copy()
        self.img_画图 = ImageDraw.Draw(self.img_背景图片)
        self.img_导出 = self.img_背景图片
    def 加载头像(self):
        """加载头像图片并粘贴到右上角"""
        if self.显示头像 and not self.头像图片 is None:
            pic = self.头像图片
            pic_w, pic_h = pic.size
            scale_factor = pic_w / pic_h
            new_w = self.头像尺寸
            new_h = round(new_w / scale_factor)
            pic_resized = pic.resize((new_w, new_h), Image.Resampling.LANCZOS)          # 缩放头像
            avatar_x = self.视频宽 - new_w - self.头像尺寸_padding
            avatar_y = self.头像尺寸_padding
            pic_pos = (avatar_x, avatar_y)
            self.img_背景图片.paste(pic_resized, pic_pos, pic_resized)
            self.img_导出 = self.img_背景图片
        else:
            # 如果不显示头像，则 final_image 就是原始背景
            self.img_导出 = self.img_背景图片
    def 画直线(self,起点,终点, 颜色="black", 线条宽度=1,透明度=1):
        self.img_画图.line([起点, 终点], fill=self.颜色转RGBA(颜色值=颜色,透明度=透明度), width=线条宽度)
    def 文本(self,text, x,y, 颜色="black", 字体路径=None, 字体大小=20,透明度=1):
        if not 字体路径:
            字体路径=self.字体路径
        if 字体路径 and os.path.exists(字体路径):
            font_name=(字体路径,字体大小)
            if font_name in fonts_dict.keys():
                font=fonts_dict[font_name]
            else:
                font = ImageFont.truetype(字体路径, 字体大小)
                fonts_dict[font_name]=font
        else:
            font = ImageFont.load_default(字体大小)
        self.img_画图.text((x,y), text, fill=self.颜色转RGBA(颜色值=颜色,透明度=透明度), font=font)
    def 画圆(self, 中心点:tuple, 半径:float, 颜色="black", 线条宽度=1,透明度=1):
        左上角 = (中心点[0] - 半径, 中心点[1] - 半径)
        右下角 = (中心点[0] + 半径, 中心点[1] + 半径)
        self.img_画图.ellipse([左上角, 右下角], outline=self.颜色转RGBA(颜色值=颜色,透明度=透明度), width=线条宽度)
    def 画曲线(self,points,颜色='red',线条宽度=1,透明度=1):
        ''' points=[(100,100),(200,200)] '''
        self.img_画图.line(points, fill=self.颜色转RGBA(颜色值=颜色,透明度=透明度), width=线条宽度)
    def 画方块(self,起点,终点, 颜色="red",线条宽度=1,透明度=1):
        x1, y1 = 起点
        x2, y2 = 终点
        # 确保左小于右，上小于下
        x1, x2 = min(x1, x2), max(x1, x2)
        y1, y2 = min(y1, y2), max(y1, y2)
        # 绘制矩形轮廓
        self.img_画图.rectangle([x1, y1, x2, y2], outline=self.颜色转RGBA(颜色值=颜色,透明度=透明度), width=线条宽度)
    def 画点列表(self,points:list, 颜色="red",线条宽度=2,透明度=1):
        for point in points:
            # #画加号
            # 半径 = 线条宽度 // 2
            # self.img_画图.ellipse([point[0] - 半径, point[1] - 半径, point[0] + 半径, point[1] + 半径], fill=颜色, outline=颜色)
            self.img_画图.point(point,fill=self.颜色转RGBA(颜色值=颜色,透明度=透明度))
    def 导出图片(self,保存路径=None):
        """返回最终处理好的 PIL Image 对象"""
        if self.img_导出 is None:
            self.img_导出 = self.img_背景图片
        if 保存路径:
            path_dir, fname = os.path.split(保存路径)
            os.makedirs(path_dir,exist_ok=1)
            self.img_导出.save(保存路径)
        else:
            if self.istest:
                save_dir=os.path.abspath('frame_images')
                os.makedirs(save_dir, exist_ok=1)
                save_name=os.path.join(save_dir,self.frame_fname)
                self.img_导出.save(save_name)
            '''
            #if self.img_导出.mode == 'RGBA':
            #import numpy as np
            #return np.array(self.img_导出)
            '''
            return self.img_导出
if __name__ == '__main__':
    cr=CREATE_FRAME(视频宽=800,视频高=600,背景图片='1.png',头像图片='2.png',显示头像=True,头像尺寸=100,istest=True)
    cr.文本(text= '你好hello ！!c !!！是 ee  ə əʊ',x=200,y=300,颜色='#000000',字体路径='font.ttf',字体大小=24)
    cr.画直线(起点=(100,100),终点=(300,300),颜色='#300000',线条宽度=3)
    cr.画点列表(points=[(100,100),(200,200)])
    cr.画方块(起点=(100,100),终点=(200,200))
    points = [(50, 350), (150, 50), (250, 350), (350, 50)]
    cr.画曲线(points, 颜色="blue", 线条宽度=3)
    cr.画圆(中心点=(200, 200), 半径=100, 颜色="red", 线条宽度=3)
    image=cr.导出图片('a.png')
    print(image)
