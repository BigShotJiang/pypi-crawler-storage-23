"""Runtime utilities and production code for pyrig."""
