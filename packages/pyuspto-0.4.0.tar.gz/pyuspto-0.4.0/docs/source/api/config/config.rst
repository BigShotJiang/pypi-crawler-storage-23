USPTOConfig
===========

.. automodule:: pyUSPTO.config
   :members:
   :undoc-members:
   :show-inheritance:
