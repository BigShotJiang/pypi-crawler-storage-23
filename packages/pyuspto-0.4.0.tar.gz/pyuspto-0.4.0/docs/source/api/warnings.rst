Warnings
========

.. automodule:: pyUSPTO.warnings
   :members:
   :undoc-members:
   :show-inheritance:
