PTAB Interferences Client
=========================

.. automodule:: pyUSPTO.clients.ptab_interferences
   :members:
   :undoc-members:
   :show-inheritance:
