Models
======

.. toctree::
   :maxdepth: 2

   base
   bulk_data
   patent_data
   petition_decisions
   ptab
   utils
