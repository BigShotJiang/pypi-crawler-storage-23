Patent Data
===========

.. automodule:: pyUSPTO.models.patent_data
   :members:
   :undoc-members:
   :show-inheritance:
