"""Cozempic - Context weight-loss tool for Claude Code."""

__version__ = "0.6.1"
