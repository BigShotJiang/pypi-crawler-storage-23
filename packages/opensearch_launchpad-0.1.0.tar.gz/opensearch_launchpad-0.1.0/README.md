# opensearch-launchpad

OpenSearch Launchpad.

## Installation

```bash
pip install opensearch-launchpad
```

## Usage

```python
from opensearch_launchpad import hello

print(hello())
```
