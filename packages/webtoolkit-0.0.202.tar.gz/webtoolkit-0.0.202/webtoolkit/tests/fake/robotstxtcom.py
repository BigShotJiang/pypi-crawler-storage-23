robots_txt_example_com_robots = """
User-agent: *
Disallow: /admin/
"""
