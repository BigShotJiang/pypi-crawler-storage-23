from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.content_rating import ContentRating
from ..models.segment_create_request_status import SegmentCreateRequestStatus
from ..models.segment_create_request_storage import SegmentCreateRequestStorage
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.segment_create_request_pos_analysis_type_0 import (
        SegmentCreateRequestPosAnalysisType0,
    )
    from ..models.segment_create_request_rating_analysis_type_0 import (
        SegmentCreateRequestRatingAnalysisType0,
    )
    from ..models.segment_create_request_text_en import SegmentCreateRequestTextEn
    from ..models.segment_create_request_text_es import SegmentCreateRequestTextEs
    from ..models.segment_create_request_text_ja import SegmentCreateRequestTextJa


T = TypeVar("T", bound="SegmentCreateRequest")


@_attrs_define
class SegmentCreateRequest:
    """
    Attributes:
        position (int): Position of the segment within the episode Example: 1133.
        start_time_ms (int): Start time of the segment in milliseconds from the beginning of the episode Example:
            2007255.
        end_time_ms (int): End time of the segment in milliseconds from the beginning of the episode Example: 2008464.
        text_ja (SegmentCreateRequestTextJa):
        storage (SegmentCreateRequestStorage): Storage backend for segment assets Default:
            SegmentCreateRequestStorage.R2. Example: R2.
        hashed_id (str): Hash identifier for the segment (from segment JSON) Example: 0d39e46b14.
        status (SegmentCreateRequestStatus | Unset): Segment status Default: SegmentCreateRequestStatus.ACTIVE. Example:
            ACTIVE.
        text_es (SegmentCreateRequestTextEs | Unset):
        text_en (SegmentCreateRequestTextEn | Unset):
        content_rating (ContentRating | Unset): Content rating level for the segment Example: SAFE.
        rating_analysis (None | SegmentCreateRequestRatingAnalysisType0 | Unset): Raw WD Tagger v3 classifier output
            used to derive content rating
        pos_analysis (None | SegmentCreateRequestPosAnalysisType0 | Unset): POS tokenization results keyed by engine
            (sudachi, unidic)
    """

    position: int
    start_time_ms: int
    end_time_ms: int
    text_ja: SegmentCreateRequestTextJa
    hashed_id: str
    storage: SegmentCreateRequestStorage = SegmentCreateRequestStorage.R2
    status: SegmentCreateRequestStatus | Unset = SegmentCreateRequestStatus.ACTIVE
    text_es: SegmentCreateRequestTextEs | Unset = UNSET
    text_en: SegmentCreateRequestTextEn | Unset = UNSET
    content_rating: ContentRating | Unset = UNSET
    rating_analysis: None | SegmentCreateRequestRatingAnalysisType0 | Unset = UNSET
    pos_analysis: None | SegmentCreateRequestPosAnalysisType0 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.segment_create_request_pos_analysis_type_0 import (
            SegmentCreateRequestPosAnalysisType0,
        )
        from ..models.segment_create_request_rating_analysis_type_0 import (
            SegmentCreateRequestRatingAnalysisType0,
        )

        position = self.position

        start_time_ms = self.start_time_ms

        end_time_ms = self.end_time_ms

        text_ja = self.text_ja.to_dict()

        storage = self.storage.value

        hashed_id = self.hashed_id

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        text_es: dict[str, Any] | Unset = UNSET
        if not isinstance(self.text_es, Unset):
            text_es = self.text_es.to_dict()

        text_en: dict[str, Any] | Unset = UNSET
        if not isinstance(self.text_en, Unset):
            text_en = self.text_en.to_dict()

        content_rating: str | Unset = UNSET
        if not isinstance(self.content_rating, Unset):
            content_rating = self.content_rating.value

        rating_analysis: dict[str, Any] | None | Unset
        if isinstance(self.rating_analysis, Unset):
            rating_analysis = UNSET
        elif isinstance(self.rating_analysis, SegmentCreateRequestRatingAnalysisType0):
            rating_analysis = self.rating_analysis.to_dict()
        else:
            rating_analysis = self.rating_analysis

        pos_analysis: dict[str, Any] | None | Unset
        if isinstance(self.pos_analysis, Unset):
            pos_analysis = UNSET
        elif isinstance(self.pos_analysis, SegmentCreateRequestPosAnalysisType0):
            pos_analysis = self.pos_analysis.to_dict()
        else:
            pos_analysis = self.pos_analysis

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "position": position,
                "startTimeMs": start_time_ms,
                "endTimeMs": end_time_ms,
                "textJa": text_ja,
                "storage": storage,
                "hashedId": hashed_id,
            }
        )
        if status is not UNSET:
            field_dict["status"] = status
        if text_es is not UNSET:
            field_dict["textEs"] = text_es
        if text_en is not UNSET:
            field_dict["textEn"] = text_en
        if content_rating is not UNSET:
            field_dict["contentRating"] = content_rating
        if rating_analysis is not UNSET:
            field_dict["ratingAnalysis"] = rating_analysis
        if pos_analysis is not UNSET:
            field_dict["posAnalysis"] = pos_analysis

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.segment_create_request_pos_analysis_type_0 import (
            SegmentCreateRequestPosAnalysisType0,
        )
        from ..models.segment_create_request_rating_analysis_type_0 import (
            SegmentCreateRequestRatingAnalysisType0,
        )
        from ..models.segment_create_request_text_en import SegmentCreateRequestTextEn
        from ..models.segment_create_request_text_es import SegmentCreateRequestTextEs
        from ..models.segment_create_request_text_ja import SegmentCreateRequestTextJa

        d = dict(src_dict)
        position = d.pop("position")

        start_time_ms = d.pop("startTimeMs")

        end_time_ms = d.pop("endTimeMs")

        text_ja = SegmentCreateRequestTextJa.from_dict(d.pop("textJa"))

        storage = SegmentCreateRequestStorage(d.pop("storage"))

        hashed_id = d.pop("hashedId")

        _status = d.pop("status", UNSET)
        status: SegmentCreateRequestStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = SegmentCreateRequestStatus(_status)

        _text_es = d.pop("textEs", UNSET)
        text_es: SegmentCreateRequestTextEs | Unset
        if isinstance(_text_es, Unset):
            text_es = UNSET
        else:
            text_es = SegmentCreateRequestTextEs.from_dict(_text_es)

        _text_en = d.pop("textEn", UNSET)
        text_en: SegmentCreateRequestTextEn | Unset
        if isinstance(_text_en, Unset):
            text_en = UNSET
        else:
            text_en = SegmentCreateRequestTextEn.from_dict(_text_en)

        _content_rating = d.pop("contentRating", UNSET)
        content_rating: ContentRating | Unset
        if isinstance(_content_rating, Unset):
            content_rating = UNSET
        else:
            content_rating = ContentRating(_content_rating)

        def _parse_rating_analysis(
            data: object,
        ) -> None | SegmentCreateRequestRatingAnalysisType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                rating_analysis_type_0 = SegmentCreateRequestRatingAnalysisType0.from_dict(data)

                return rating_analysis_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SegmentCreateRequestRatingAnalysisType0 | Unset, data)

        rating_analysis = _parse_rating_analysis(d.pop("ratingAnalysis", UNSET))

        def _parse_pos_analysis(
            data: object,
        ) -> None | SegmentCreateRequestPosAnalysisType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                pos_analysis_type_0 = SegmentCreateRequestPosAnalysisType0.from_dict(data)

                return pos_analysis_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SegmentCreateRequestPosAnalysisType0 | Unset, data)

        pos_analysis = _parse_pos_analysis(d.pop("posAnalysis", UNSET))

        segment_create_request = cls(
            position=position,
            start_time_ms=start_time_ms,
            end_time_ms=end_time_ms,
            text_ja=text_ja,
            storage=storage,
            hashed_id=hashed_id,
            status=status,
            text_es=text_es,
            text_en=text_en,
            content_rating=content_rating,
            rating_analysis=rating_analysis,
            pos_analysis=pos_analysis,
        )

        segment_create_request.additional_properties = d
        return segment_create_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
