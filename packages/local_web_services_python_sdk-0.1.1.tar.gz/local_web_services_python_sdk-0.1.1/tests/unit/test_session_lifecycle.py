"""Integration tests: verify LwsSession starts services and responds to requests."""

from __future__ import annotations

import pytest

from lws_testing import LwsSession


@pytest.fixture(scope="module")
def session():
    with LwsSession(
        tables=[{"name": "Orders", "partition_key": "id"}],
        queues=["OrderQueue"],
        buckets=["TestBucket"],
    ) as s:
        yield s


def test_dynamodb_client_is_available(session):
    # Arrange / Act
    client = session.client("dynamodb")

    # Assert
    assert client is not None


def test_dynamodb_put_and_get_item(session):
    # Arrange
    session.reset()
    client = session.client("dynamodb")
    expected_item = {"id": {"S": "order-1"}, "status": {"S": "pending"}}

    # Act
    client.put_item(TableName="Orders", Item=expected_item)
    response = client.get_item(TableName="Orders", Key={"id": {"S": "order-1"}})

    # Assert
    actual_item = response["Item"]
    assert actual_item["id"]["S"] == "order-1"
    assert actual_item["status"]["S"] == "pending"


def test_dynamodb_helper_scan(session):
    # Arrange
    session.reset()
    table = session.dynamodb("Orders")
    table.put({"id": {"S": "a"}, "val": {"S": "1"}})
    table.put({"id": {"S": "b"}, "val": {"S": "2"}})

    # Act
    items = table.scan()

    # Assert
    assert len(items) == 2


def test_s3_put_and_get(session):
    # Arrange
    session.reset()
    bucket = session.s3("TestBucket")
    expected_content = b"hello world"

    # Act
    bucket.put("test/file.txt", expected_content)
    actual_content = bucket.get("test/file.txt")

    # Assert
    assert actual_content == expected_content


def test_sqs_send_and_receive(session):
    # Arrange
    session.reset()
    queue = session.sqs("OrderQueue")
    expected_body = '{"orderId": "42"}'

    # Act
    queue.send(expected_body)
    messages = queue.receive(max_messages=1)

    # Assert
    assert len(messages) == 1
    assert messages[0]["Body"] == expected_body


def test_session_reset_clears_state(session):
    # Arrange
    table = session.dynamodb("Orders")
    table.put({"id": {"S": "to-be-cleared"}})

    # Act
    session.reset()
    items = table.scan()

    # Assert
    assert len(items) == 0


def test_all_services_available(session):
    # Arrange / Act / Assert — all core services should have ports
    expected_services = ["dynamodb", "sqs", "s3", "sns", "stepfunctions", "ssm", "secretsmanager"]
    for svc in expected_services:
        client = session.client(svc)
        assert client is not None, f"Expected service {svc!r} to be available"
