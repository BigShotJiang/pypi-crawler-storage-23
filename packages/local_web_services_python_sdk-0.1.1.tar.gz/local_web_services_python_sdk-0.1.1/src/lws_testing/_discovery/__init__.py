"""Resource discovery from CDK and HCL projects."""
