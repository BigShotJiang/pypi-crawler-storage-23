"""In-process and HTTP transport backends for LWS testing."""
