Installation
------------

Requires Python |minimum-python-version|\+.

.. code-block:: console

   $ pip install sybil-extras
