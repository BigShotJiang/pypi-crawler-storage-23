"""Tests for synkro.enterprise SDK."""

import json
from unittest.mock import MagicMock, patch

import httpx
import pytest

from synkro.enterprise import (
    AsyncSynkro,
    Synkro,
    SynkroAPIError,
    SynkroAuthError,
    SynkroNotFoundError,
    SynkroRateLimitError,
)
from synkro.enterprise._http import BaseHTTPClient, _raise_for_status
from synkro.enterprise.types import (
    DatasetCreateResult,
    LangSmithConnection,
    Policy,
    PolicyCreateResult,
    Project,
    ProjectStatus,
)


# ── Fixtures ──────────────────────────────────────────────


def _mock_response(status_code: int = 200, json_data=None, headers=None):
    """Create a mock httpx.Response."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.is_success = 200 <= status_code < 300
    resp.text = json.dumps(json_data) if json_data else ""
    resp.json.return_value = json_data or {}
    resp.headers = headers or {}
    return resp


def _make_client():
    """Create a Synkro client with a mocked transport."""
    client = Synkro(api_key="sk-test-123", base_url="http://localhost:3000")
    return client


# ── Error Mapping Tests ──────────────────────────────────


class TestErrorMapping:
    def test_401_raises_auth_error(self):
        resp = _mock_response(401)
        with pytest.raises(SynkroAuthError, match="Invalid or expired API key"):
            _raise_for_status(resp)

    def test_404_raises_not_found(self):
        resp = _mock_response(404)
        with pytest.raises(SynkroNotFoundError, match="Resource not found"):
            _raise_for_status(resp)

    def test_429_raises_rate_limit(self):
        resp = _mock_response(429, headers={"Retry-After": "30"})
        with pytest.raises(SynkroRateLimitError, match="Rate limit exceeded") as exc_info:
            _raise_for_status(resp)
        assert exc_info.value.retry_after == "30"

    def test_500_raises_api_error(self):
        resp = _mock_response(500, json_data={"error": "Internal server error"})
        with pytest.raises(SynkroAPIError, match="500: Internal server error") as exc_info:
            _raise_for_status(resp)
        assert exc_info.value.status_code == 500

    def test_400_raises_api_error_with_detail(self):
        resp = _mock_response(400, json_data={"error": "Bad request: missing name"})
        with pytest.raises(SynkroAPIError, match="Bad request: missing name") as exc_info:
            _raise_for_status(resp)
        assert exc_info.value.status_code == 400

    def test_200_does_not_raise(self):
        resp = _mock_response(200)
        _raise_for_status(resp)  # Should not raise


# ── Client Tests ─────────────────────────────────────────


class TestClientInit:
    def test_default_base_url(self):
        client = Synkro(api_key="sk-test")
        assert client._http._client.base_url == httpx.URL("https://api.synkro.sh")
        client.close()

    def test_custom_base_url(self):
        client = Synkro(api_key="sk-test", base_url="http://localhost:3000")
        assert client._http._client.base_url == httpx.URL("http://localhost:3000")
        client.close()

    def test_headers_set(self):
        client = Synkro(api_key="sk-test-key")
        headers = client._http._client.headers
        assert headers["x-api-key"] == "sk-test-key"
        assert headers["content-type"] == "application/json"
        assert "synkro-python/" in headers["user-agent"]
        client.close()

    def test_context_manager(self):
        with Synkro(api_key="sk-test") as client:
            assert client.projects is not None
            assert client.policies is not None
            assert client.integrations is not None

    def test_has_all_resources(self):
        client = Synkro(api_key="sk-test")
        assert hasattr(client, "projects")
        assert hasattr(client, "policies")
        assert hasattr(client, "integrations")
        client.close()

    def test_async_client_init(self):
        client = AsyncSynkro(api_key="sk-test")
        assert hasattr(client, "projects")
        assert hasattr(client, "policies")
        assert hasattr(client, "integrations")


# ── Projects Resource Tests ──────────────────────────────


class TestProjects:
    def test_list(self):
        client = _make_client()
        mock_data = [
            {"id": "p1", "slug": "proj_abc", "name": "Test", "is_active": True},
            {"id": "p2", "slug": "proj_def", "name": "Test 2", "is_active": False},
        ]
        with patch.object(client._http, "get", return_value=mock_data):
            projects = client.projects.list()
        assert len(projects) == 2
        assert isinstance(projects[0], Project)
        assert projects[0].id == "p1"
        assert projects[0].slug == "proj_abc"
        assert projects[1].is_active is False
        client.close()

    def test_create(self):
        client = _make_client()
        mock_data = {"id": "p1", "slug": "proj_abc", "name": "My Project", "is_active": True}
        with patch.object(client._http, "post", return_value=mock_data) as mock_post:
            project = client.projects.create(name="My Project", provider="openai")
        assert isinstance(project, Project)
        assert project.name == "My Project"
        mock_post.assert_called_once_with(
            "/api/projects", json={"name": "My Project", "provider": "openai"}
        )
        client.close()

    def test_create_defaults(self):
        client = _make_client()
        mock_data = {"id": "p1", "slug": "proj_abc", "name": "Default Project", "is_active": True}
        with patch.object(client._http, "post", return_value=mock_data) as mock_post:
            client.projects.create()
        mock_post.assert_called_once_with(
            "/api/projects", json={"name": "Default Project"}
        )
        client.close()

    def test_update(self):
        client = _make_client()
        with patch.object(client._http, "patch", return_value={}) as mock_patch:
            client.projects.update("p1", name="New Name", is_active=False)
        mock_patch.assert_called_once_with(
            "/api/projects/p1", json={"name": "New Name", "is_active": False}
        )
        client.close()

    def test_update_partial(self):
        client = _make_client()
        with patch.object(client._http, "patch", return_value={}) as mock_patch:
            client.projects.update("p1", name="Only Name")
        mock_patch.assert_called_once_with("/api/projects/p1", json={"name": "Only Name"})
        client.close()

    def test_delete(self):
        client = _make_client()
        with patch.object(client._http, "delete", return_value={}) as mock_delete:
            client.projects.delete("p1")
        mock_delete.assert_called_once_with("/api/projects/p1")
        client.close()

    def test_status(self):
        client = _make_client()
        mock_data = {
            "project_id": "p1",
            "slug": "proj_abc",
            "name": "Test",
            "is_active": True,
            "has_api_key": True,
            "has_policy": True,
            "rule_count": 12,
            "is_ready": True,
            "violations_total": 45,
            "violations_24h": 3,
        }
        with patch.object(client._http, "get", return_value=mock_data):
            status = client.projects.status("p1")
        assert isinstance(status, ProjectStatus)
        assert status.is_ready is True
        assert status.rule_count == 12
        assert status.violations_24h == 3
        client.close()

    def test_rotate_slug(self):
        client = _make_client()
        with patch.object(client._http, "post", return_value={"slug": "proj_newslug"}) as mock:
            new_slug = client.projects.rotate_slug("p1")
        assert new_slug == "proj_newslug"
        mock.assert_called_once_with("/api/projects/p1/rotate-slug")
        client.close()


# ── Policies Resource Tests ──────────────────────────────


class TestPolicies:
    def test_list(self):
        client = _make_client()
        mock_data = [
            {
                "id": "pol_1",
                "name": "Expense Policy",
                "policy_text": "All expenses...",
                "rules": [{"id": "R001"}],
                "rule_count": 1,
                "guard_mode": "audit",
                "is_active": True,
            }
        ]
        with patch.object(client._http, "get", return_value=mock_data):
            policies = client.policies.list("p1")
        assert len(policies) == 1
        assert isinstance(policies[0], Policy)
        assert policies[0].id == "pol_1"
        assert policies[0].guard_mode == "audit"
        client.close()

    def test_create(self):
        client = _make_client()
        mock_data = {
            "ok": True,
            "policy_id": "pol_1",
            "rules": [{"id": "R001"}, {"id": "R002"}],
            "rule_count": 2,
            "model": "gpt-4o",
            "timing_ms": 1500,
        }
        with patch.object(client._http, "post", return_value=mock_data) as mock_post:
            result = client.policies.create(
                "p1", text="All expenses require receipts", name="v1", mode="blocking"
            )
        assert isinstance(result, PolicyCreateResult)
        assert result.ok is True
        assert result.rule_count == 2
        assert result.timing_ms == 1500
        mock_post.assert_called_once_with(
            "/api/projects/p1/policies",
            json={
                "policy_text": "All expenses require receipts",
                "guard_mode": "blocking",
                "name": "v1",
            },
        )
        client.close()

    def test_update(self):
        client = _make_client()
        with patch.object(client._http, "patch", return_value={}) as mock_patch:
            client.policies.update("p1", "pol_1", name="v2", mode="blocking")
        mock_patch.assert_called_once_with(
            "/api/projects/p1/policies",
            json={"policy_id": "pol_1", "name": "v2", "guard_mode": "blocking"},
        )
        client.close()

    def test_deactivate(self):
        client = _make_client()
        with patch.object(client._http, "delete", return_value={}) as mock_delete:
            client.policies.deactivate("p1", "pol_1")
        mock_delete.assert_called_once_with(
            "/api/projects/p1/policies", params={"policy_id": "pol_1"}
        )
        client.close()


# ── Integrations Resource Tests ──────────────────────────


class TestIntegrations:
    def test_langsmith_status(self):
        client = _make_client()
        mock_data = {"connected": True, "id": "ls_1", "project_count": 3}
        with patch.object(client._http, "get", return_value=mock_data):
            conn = client.integrations.langsmith_status()
        assert isinstance(conn, LangSmithConnection)
        assert conn.connected is True
        assert conn.project_count == 3
        client.close()

    def test_connect_langsmith(self):
        client = _make_client()
        mock_data = {"connected": True, "id": "ls_1", "status": "active"}
        with patch.object(client._http, "post", return_value=mock_data) as mock_post:
            conn = client.integrations.connect_langsmith(api_key="lsv2_xxx")
        assert conn.connected is True
        mock_post.assert_called_once_with(
            "/api/integrations/langsmith",
            json={"api_key": "lsv2_xxx", "base_url": "https://api.smith.langchain.com"},
        )
        client.close()

    def test_disconnect_langsmith(self):
        client = _make_client()
        with patch.object(client._http, "delete", return_value={}) as mock_delete:
            client.integrations.disconnect_langsmith()
        mock_delete.assert_called_once_with("/api/integrations/langsmith")
        client.close()

    def test_langsmith_projects(self):
        client = _make_client()
        mock_data = [{"name": "proj-a"}, {"name": "proj-b"}]
        with patch.object(client._http, "get", return_value=mock_data):
            projects = client.integrations.langsmith_projects()
        assert len(projects) == 2
        client.close()

    def test_langsmith_toggle(self):
        client = _make_client()
        with patch.object(client._http, "post", return_value={}) as mock_post:
            client.integrations.langsmith_toggle(
                "p1", enabled=True, langsmith_project="my-proj"
            )
        mock_post.assert_called_once_with(
            "/api/integrations/langsmith/toggle",
            json={"project_id": "p1", "enabled": True, "langsmith_project": "my-proj"},
        )
        client.close()

    def test_langsmith_create_dataset(self):
        client = _make_client()
        mock_data = {"dataset_id": "ds_1", "example_count": 5}
        with patch.object(client._http, "post", return_value=mock_data) as mock_post:
            result = client.integrations.langsmith_create_dataset(
                name="test-ds", description="Test dataset"
            )
        assert isinstance(result, DatasetCreateResult)
        assert result.dataset_id == "ds_1"
        assert result.example_count == 5
        mock_post.assert_called_once_with(
            "/api/integrations/langsmith/datasets",
            json={"name": "test-ds", "description": "Test dataset"},
        )
        client.close()


# ── Type Tests ───────────────────────────────────────────


class TestTypes:
    def test_project_optional_fields(self):
        p = Project(id="p1", slug="s", name="n")
        assert p.provider is None
        assert p.is_active is True
        assert p.created_at is None

    def test_policy_defaults(self):
        p = Policy(id="pol_1", name="n", policy_text="t")
        assert p.rules == []
        assert p.rule_count == 0
        assert p.guard_mode == "audit"
        assert p.is_active is True

    def test_langsmith_connection_defaults(self):
        c = LangSmithConnection(connected=False)
        assert c.project_count == 0
        assert c.id is None

    def test_policy_create_result_optional(self):
        r = PolicyCreateResult(ok=True, policy_id="pol_1")
        assert r.rules == []
        assert r.model is None
        assert r.timing_ms is None


# ── Error Class Tests ────────────────────────────────────


class TestErrors:
    def test_synkro_error_is_exception(self):
        with pytest.raises(Exception):
            raise SynkroAuthError("test")

    def test_rate_limit_retry_after(self):
        err = SynkroRateLimitError("limited", retry_after="60")
        assert err.retry_after == "60"
        assert str(err) == "limited"

    def test_api_error_status_code(self):
        err = SynkroAPIError("bad", status_code=422)
        assert err.status_code == 422

    def test_not_found_is_api_error(self):
        err = SynkroNotFoundError("gone")
        assert isinstance(err, SynkroAPIError)
        assert err.status_code == 404
