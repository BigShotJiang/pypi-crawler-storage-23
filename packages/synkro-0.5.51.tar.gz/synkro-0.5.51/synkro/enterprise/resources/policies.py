"""Policies resource — CRUD operations for project policies."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from synkro.enterprise.types import Policy, PolicyCreateResult

if TYPE_CHECKING:
    from synkro.enterprise._http import AsyncBaseHTTPClient, BaseHTTPClient


class Policies:
    """Sync policy operations."""

    def __init__(self, http: BaseHTTPClient):
        self._http = http

    def list(self, project_id: str) -> list[Policy]:
        """GET /api/projects/{project_id}/policies"""
        data = self._http.get(f"/api/projects/{project_id}/policies")
        return [Policy(**p) for p in data]

    def create(
        self,
        project_id: str,
        *,
        text: str,
        name: str | None = None,
        mode: Literal["audit", "blocking"] = "audit",
        model: str | None = None,
    ) -> PolicyCreateResult:
        """POST /api/projects/{project_id}/policies"""
        body: dict = {"policy_text": text, "guard_mode": mode}
        if name is not None:
            body["name"] = name
        if model is not None:
            body["model"] = model
        data = self._http.post(f"/api/projects/{project_id}/policies", json=body)
        return PolicyCreateResult(**data)

    def update(
        self,
        project_id: str,
        policy_id: str,
        *,
        name: str | None = None,
        text: str | None = None,
        mode: Literal["audit", "blocking"] | None = None,
        is_active: bool | None = None,
    ) -> None:
        """PATCH /api/projects/{project_id}/policies"""
        body: dict = {"policy_id": policy_id}
        if name is not None:
            body["name"] = name
        if text is not None:
            body["policy_text"] = text
        if mode is not None:
            body["guard_mode"] = mode
        if is_active is not None:
            body["is_active"] = is_active
        self._http.patch(f"/api/projects/{project_id}/policies", json=body)

    def deactivate(self, project_id: str, policy_id: str) -> None:
        """DELETE /api/projects/{project_id}/policies?policy_id={policy_id}"""
        self._http.delete(
            f"/api/projects/{project_id}/policies", params={"policy_id": policy_id}
        )


class AsyncPolicies:
    """Async policy operations."""

    def __init__(self, http: AsyncBaseHTTPClient):
        self._http = http

    async def list(self, project_id: str) -> list[Policy]:
        """GET /api/projects/{project_id}/policies"""
        data = await self._http.get(f"/api/projects/{project_id}/policies")
        return [Policy(**p) for p in data]

    async def create(
        self,
        project_id: str,
        *,
        text: str,
        name: str | None = None,
        mode: Literal["audit", "blocking"] = "audit",
        model: str | None = None,
    ) -> PolicyCreateResult:
        """POST /api/projects/{project_id}/policies"""
        body: dict = {"policy_text": text, "guard_mode": mode}
        if name is not None:
            body["name"] = name
        if model is not None:
            body["model"] = model
        data = await self._http.post(f"/api/projects/{project_id}/policies", json=body)
        return PolicyCreateResult(**data)

    async def update(
        self,
        project_id: str,
        policy_id: str,
        *,
        name: str | None = None,
        text: str | None = None,
        mode: Literal["audit", "blocking"] | None = None,
        is_active: bool | None = None,
    ) -> None:
        """PATCH /api/projects/{project_id}/policies"""
        body: dict = {"policy_id": policy_id}
        if name is not None:
            body["name"] = name
        if text is not None:
            body["policy_text"] = text
        if mode is not None:
            body["guard_mode"] = mode
        if is_active is not None:
            body["is_active"] = is_active
        await self._http.patch(f"/api/projects/{project_id}/policies", json=body)

    async def deactivate(self, project_id: str, policy_id: str) -> None:
        """DELETE /api/projects/{project_id}/policies?policy_id={policy_id}"""
        await self._http.delete(
            f"/api/projects/{project_id}/policies", params={"policy_id": policy_id}
        )
