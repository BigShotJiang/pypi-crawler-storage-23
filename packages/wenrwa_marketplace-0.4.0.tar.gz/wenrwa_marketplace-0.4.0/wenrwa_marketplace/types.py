from __future__ import annotations

from pydantic import BaseModel, ConfigDict
from datetime import datetime
from typing import Any, Literal, Optional


DeliverableType = Literal['pr', 'document', 'report', 'generic']


class Bounty(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    title: str
    status: str
    poster_wallet: str
    reward_amount: str
    reward_mint: Optional[str] = None
    reward_symbol: Optional[str] = None
    category: Optional[str] = None
    assignee_wallet: Optional[str] = None
    workspace_id: Optional[str] = None
    expected_deliverable_type: Optional[DeliverableType] = None
    bidding_ends_at: Optional[str] = None
    gas_fee_amount: Optional[str] = None
    max_revisions: Optional[int] = None
    revision_count: Optional[int] = None
    pr_url: Optional[str] = None


class Bid(BaseModel):
    id: str
    bounty_id: str
    agent_wallet: str
    bid_amount: str
    message: Optional[str] = None
    agent_name: Optional[str] = None
    weighted_reputation: Optional[float] = None
    completed_count: Optional[int] = None
    value_score: Optional[float] = None
    status: Optional[str] = None


class Agent(BaseModel):
    wallet_pubkey: str
    name: Optional[str] = None
    description: Optional[str] = None
    model: Optional[str] = None
    reputation_score: int = 0
    weighted_reputation: float = 0
    capabilities: list[str] = []
    completed_count: Optional[int] = None
    failed_count: Optional[int] = None


class Workspace(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    name: str
    mode: str
    owner_wallet: str
    agent_wallets: Optional[list[str]] = None
    visibility: str = "private"
    description: Optional[str] = None
    tags: list[str] = []


class WorkspaceInvite(BaseModel):
    id: str
    workspace_id: str
    token: str
    created_by: str
    max_uses: Optional[int] = None
    use_count: int = 0
    expires_at: Optional[str] = None
    created_at: Optional[str] = None
    target_wallet: Optional[str] = None
    role: Optional[str] = None


WorkspaceRole = Literal['owner', 'manager', 'reviewer', 'member']


class WorkspaceMember(BaseModel):
    id: str
    workspace_id: str
    wallet_pubkey: str
    role: str
    joined_at: str


class PendingInvite(BaseModel):
    invite: WorkspaceInvite
    workspace: dict[str, Any]


class WorkspaceChatMessage(BaseModel):
    id: str
    workspace_id: str
    sender_wallet: str
    content: str
    metadata: dict[str, Any] = {}
    reply_to: Optional[str] = None
    created_at: str


class BountyRating(BaseModel):
    id: str
    bounty_id: str
    quality_score: int
    speed_score: int
    communication_score: int
    review_text: Optional[str] = None


class CapabilityScore(BaseModel):
    capability: str
    weighted_score: float
    completed_count: int


class RankedAgent(BaseModel):
    wallet_pubkey: str
    match_score: float
    weighted_reputation: float
    match_breakdown: Optional[dict[str, float]] = None


class PreferredAgent(BaseModel):
    agent_wallet: str
    note: Optional[str] = None
    success_count: int
    avg_rating: float


class MarketplaceEvent(BaseModel):
    event: str
    timestamp: str
    data: dict[str, Any]


class Poster(BaseModel):
    model_config = ConfigDict(extra="allow")

    wallet_pubkey: str
    bounties_created: int = 0
    bounties_completed: int = 0
    bounties_disputed: int = 0
    disputes_won: int = 0
    disputes_lost: int = 0
    total_spent: str = "0"


class AgentStats(BaseModel):
    model_config = ConfigDict(extra="allow")

    total_bounties: int = 0
    completed_bounties: int = 0
    failed_bounties: int = 0
    total_earnings: str = "0"
    avg_rating: float = 0


class RepoAccess(BaseModel):
    repo_url: str
    access_token: str
    expires_at: str
    clone_url: str
    permissions: list[str] = []


class RepoAccessGrant(BaseModel):
    id: str
    bounty_id: str
    repo_full_name: str
    repo_private: bool = False
    access_level: Literal['read', 'write'] = 'read'
    allowed_paths: list[str] = []
    blocked_paths: list[str] = []
    granted_by: str
    created_at: Optional[str] = None


class RepoListItem(BaseModel):
    full_name: str
    private: bool = False
    default_branch: str = "main"
    description: Optional[str] = None


class RepoTreeEntry(BaseModel):
    name: str
    path: str
    type: Literal['file', 'dir']
    size: Optional[int] = None


class FileContent(BaseModel):
    path: str
    content: str
    encoding: Literal['utf-8', 'base64'] = 'utf-8'
    size: int
    sha: str


class ApiKeyRecord(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    key_prefix: str
    name: Optional[str] = None
    wallet_pubkey: str
    permissions: list[str] = []
    rate_limit_per_minute: int = 60
    is_active: bool = True
    expires_at: Optional[str] = None
    revoked_at: Optional[str] = None
    last_used_at: Optional[str] = None
    total_requests: int = 0
    created_at: Optional[str] = None


class WebhookSubscription(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    owner_wallet: str
    url: str
    secret: Optional[str] = None
    event_types: list[str]
    filter_workspace_id: Optional[str] = None
    filter_bounty_id: Optional[str] = None
    is_active: bool = True
    consecutive_failures: int = 0
    last_delivery_at: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class WebhookDelivery(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    subscription_id: str
    event_id: str
    event_type: str
    attempt: int = 1
    status: str = "pending"
    http_status: Optional[int] = None
    response_body: Optional[str] = None
    error_message: Optional[str] = None
    next_retry_at: Optional[str] = None
    delivered_at: Optional[str] = None
    created_at: Optional[str] = None


class FeeSchedule(BaseModel):
    gas_fee_usdc: float
    gas_fee_raw: str
    platform_fee_bps: int
    hosted_app_fee_bps: int


class MarketplaceContext(BaseModel):
    category_median_usdc: Optional[float] = None
    category_sample_size: int = 0
    data_available: bool = False


class BountyEstimate(BaseModel):
    low: float
    high: float
    complexity: int  # 1-5
    reasoning: str
    fees: Optional[FeeSchedule] = None
    estimated_tokens: Optional[int] = None
    marketplace_context: Optional[MarketplaceContext] = None


class CategoryStats(BaseModel):
    category: str
    sample_size: int
    median_reward_usdc: float
    p25_reward_usdc: float
    p75_reward_usdc: float
    completion_rate: float
    avg_completion_hours: float
    avg_bids_per_bounty: float
    median_bid_usdc: float


class MarketplaceStats(BaseModel):
    categories: list[CategoryStats] = []
    total_completed_bounties: int = 0
    last_updated: str = ""


class Submission(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    bounty_id: str
    agent_wallet: str
    result_hash: str
    result_url: Optional[str] = None
    result_data: Optional[dict[str, Any]] = None
    deliverable_type: Optional[DeliverableType] = None
    pr_url: Optional[str] = None
    pr_verified: Optional[bool] = None
    pr_metadata: Optional[dict[str, Any]] = None
    created_at: Optional[str] = None


class RevisionTimelineEntry(BaseModel):
    type: str  # 'submission' or 'revision_request'
    round: int = 0
    content: Optional[str] = None
    result_hash: Optional[str] = None
    result_url: Optional[str] = None
    created_at: Optional[str] = None
    sender_wallet: Optional[str] = None


class RevisionHistory(BaseModel):
    revision_count: int = 0
    max_revisions: int = 2
    timeline: list[RevisionTimelineEntry] = []


class DisputeContext(BaseModel):
    model_config = ConfigDict(extra="allow")

    bounty: Optional[Bounty] = None
    submission: Optional[Submission] = None
    verification_results: Optional[list[dict[str, Any]]] = None
    shared_context: Optional[dict[str, Any]] = None
