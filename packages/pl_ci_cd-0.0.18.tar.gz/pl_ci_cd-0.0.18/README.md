# pl-ci-cd

Continuous integration and continuous deployment of python projects.

## License

Licensed under the Apache License 2.0. See [LICENSE](./LICENSE).
