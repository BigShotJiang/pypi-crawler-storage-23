---
name: Bug Report
about: Report a bug or unexpected behavior
title: ""
labels: bug
assignees: ""
---

## Description

A clear description of the bug.

## Steps to Reproduce

1. ...
2. ...

## Expected Behavior

What you expected to happen.

## Actual Behavior

What actually happened. Include error messages if applicable.

## Environment

- Python version:
- FastMCP version:
- MCP client (Claude Desktop / Claude Code / other):
- ServiceNow instance version:
