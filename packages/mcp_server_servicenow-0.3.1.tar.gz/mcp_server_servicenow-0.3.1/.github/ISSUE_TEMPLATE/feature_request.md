---
name: Feature Request
about: Suggest a new tool or enhancement
title: ""
labels: enhancement
assignees: ""
---

## Description

What would you like to see added or changed?

## Use Case

How would this help your workflow with ServiceNow + AI?

## Proposed Solution

If you have ideas on implementation, share them here.
