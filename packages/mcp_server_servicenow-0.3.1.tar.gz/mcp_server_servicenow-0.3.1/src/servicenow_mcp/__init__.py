"""ServiceNow MCP Server - table, CMDB, system, and update set operations."""

__version__ = "0.3.0"
