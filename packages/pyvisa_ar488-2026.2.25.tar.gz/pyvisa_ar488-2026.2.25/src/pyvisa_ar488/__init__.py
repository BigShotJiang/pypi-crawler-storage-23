"""PyVISA backend for AR488/Prologix GPIB-USB adapters.

Enables pyvisa (and pymeasure) to talk to GPIB instruments through
AR488 or Prologix-compatible adapters over serial or TCP.

Usage (standalone)::

    import pyvisa
    rm = pyvisa.ResourceManager("@ar488")
    instr = rm.open_resource("GPIB0::22::INSTR")
    print(instr.query("*IDN?"))

Usage (bridge mode with mcgpib)::

    from pyvisa_ar488 import AR488VisaLibrary
    lib = AR488VisaLibrary.from_bridge(bridge_connection, event_loop)
    rm = pyvisa.ResourceManager(lib)
"""

from importlib.metadata import PackageNotFoundError, version

from pyvisa_ar488.highlevel import AR488VisaLibrary

__version__ = "unknown"
try:
    __version__ = version("pyvisa-ar488")
except PackageNotFoundError:
    __version__ = "2026.02.25.dev0"

# pyvisa discovers backends by importing pyvisa_<name> and reading WRAPPER_CLASS
WRAPPER_CLASS = AR488VisaLibrary

__all__ = ["AR488VisaLibrary", "WRAPPER_CLASS", "__version__"]
