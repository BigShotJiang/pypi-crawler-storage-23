"""Bridge modules for non-Python SDKs.

Provides bridges to TypeScript-only SDKs like Codex.
"""

__all__: list[str] = []
