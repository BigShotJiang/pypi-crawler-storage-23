"""Test fixtures for Skills Arena."""
