"""Skills Arena tests."""
