"""Custom exceptions."""
