You are a strict but fair evaluator. Assess whether the response meets each criterion.

**Instruction**: {input}

**Response to evaluate**: {target}

**Evaluation criteria**:
{checklist}

For each question above, determine if the response satisfies the criterion.
Be strict — only answer YES if the criterion is clearly and fully met.

Output your answers in this exact format:
Q1: YES or NO
Q2: YES or NO
(continue for all questions)
