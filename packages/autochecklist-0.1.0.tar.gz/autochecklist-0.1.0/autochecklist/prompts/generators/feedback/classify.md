You will be given a numbered checklist of questions and a single user feedback comment.
Indicate which questions cover or address the feedback. A question "covers" a feedback item if answering that question would help evaluate the concern raised in the feedback.

Respond with ONLY a comma-separated list of question numbers. If no questions cover the feedback, respond with "none".

## Questions

{questions}

## Feedback

{feedback_item}
