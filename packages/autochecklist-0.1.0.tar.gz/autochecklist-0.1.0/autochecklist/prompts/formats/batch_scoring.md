## Output Format
Return your response as a JSON object with an "answers" array. For each question, provide its index (1-based, matching Q1, Q2, etc.) and your answer ("YES" or "NO").

Example:
{"answers": [{"question_index": 1, "answer": "YES"}, {"question_index": 2, "answer": "NO"}]}