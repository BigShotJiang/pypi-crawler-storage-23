## Output Format
First analyze the generated text against the question, then provide your judgment.
Return your response as a JSON object with "answer" (either "YES" or "NO") and "reasoning" (your analysis).

Example:
{"answer": "YES", "reasoning": "The text correctly addresses the requirement by providing a detailed explanation of the topic."}