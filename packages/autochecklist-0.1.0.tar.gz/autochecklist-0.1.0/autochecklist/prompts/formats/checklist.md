## Output Format
Return your response as a JSON object with a "questions" array. Each item must have a "question" field containing a yes/no question.

Example:
{"questions": [{"question": "Does the response address the main topic?"}, {"question": "Is the response free of factual errors?"}]}