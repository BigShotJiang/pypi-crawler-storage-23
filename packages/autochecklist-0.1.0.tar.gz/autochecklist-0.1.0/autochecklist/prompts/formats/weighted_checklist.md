## Output Format
Return your response as a JSON object with a "questions" array. Each item must have a "question" field (yes/no question) and a "weight" field (integer 0-100 indicating importance).

Example:
{"questions": [{"question": "Does the response address the main topic?", "weight": 100}, {"question": "Is the tone appropriate?", "weight": 70}]}