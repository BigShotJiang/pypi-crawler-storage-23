"""Tests for checklist scorers."""
