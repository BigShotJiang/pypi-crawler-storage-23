"""Tests for auto-checklists."""
