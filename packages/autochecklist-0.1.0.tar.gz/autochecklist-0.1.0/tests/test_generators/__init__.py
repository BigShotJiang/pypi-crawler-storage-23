"""Tests for checklist generators."""
