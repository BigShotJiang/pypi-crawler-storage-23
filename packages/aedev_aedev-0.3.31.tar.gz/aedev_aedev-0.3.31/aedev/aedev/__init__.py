""" aedev namespace root, providing setup, development and documentation tools/templates for Python projects. """

__version__ = '0.3.31'
