# Surface Command SDK

The `surcom-sdk` helps you build Surface Command data connectors for the Rapid7 platform.

## Installation

* Install the `surcom-sdk`:

  ```bash
  pip install r7-surcom-sdk
  ```

* Verify the installed version:

  ```bash
  surcom --version
  ```

* Install the SDK with debugging dependencies:
  
  ```bash
  pip install 'r7-surcom-sdk[debug]'
  ```

## Configuration

* To configure the `surcom-sdk` you will need an API key. Please read our [documentation](https://docs.rapid7.com/surface-command/build-custom-connectors/#install-and-configure-the-sdk) to get setup and then run:

  ```bash
  surcom config init
  ```

## Documentation

* View detailed help for any SDK command by adding `--help`:
  
  ```bash
  surcom connector --help
  ```

### Additional Resources

- [Configure the SDK](https://docs.rapid7.com/surface-command/build-custom-connectors/).
- [Build an Example Connector](https://docs.rapid7.com/surface-command/build-custom-connectors/#build-an-example-connector).
- [Troubleshoot connector issues](https://docs.rapid7.com/surface-command/build-custom-connectors/#troubleshoot-your-connector).
- [Understand the Attack Surface Management type system](https://docs.rapid7.com/surface-command/asm-type-system/#undefined).
