# Enumerations in the Unified Model

"Enums" describe constrained sets of valid values.  In the unified model, Enum types are used to define these values and map them onto a common vocabulary.

Each connector may have its own list of valid values for an Enum-based property.  For example, "severity" from one source has values "1", "2", "3"; another "low"/"medium"/"high"/"critical", another "INFO"/"MODERATE"/"SEVERE".

We map each enum onto a standard list of values (named "NoeticEnum*" for historical reasons).  The implementation uses reference-properties and a correlated Enum type in the unified model.

Enums use _correlation_ to map between lists of valid values.  This document describes how the Enum classes are constructed, and how to implement an Enum class in a connector.

## Correlation Mapping

Correlation in the Enum type joins multiple enumerated values (e.g. "PROD", "P", "Production") as representing the same value in a unified set.  Each source can then provide its own list of valid values *without any transformation in code* and map them to the standard list.

Some of the unified enumeration lists are smaller than the set of values from each source.  If a company has "Dev", "Test", "UAT1", "UAT2", "Staging", "Production" and "DR" environments, they should each be mapped onto the standard list of just "Development", "Testing" and "Production".

## The Abstract `Enum` Types

The `Enum` base type is correlatable.  It defines three standard properties for enum values:

- `id`: an identifier (often the "technical valid value"; sometimes the same as `value`),
- `value`: a value for display,
- `description`: an optional description of the value.

Then for each specific value set, another abstract type is defined.  These types have no additional properties; they just extend Enum.  Some of these enum types are:

- EnumAssetClass: The high-level type of asset.  This is used for the `asset_class` property of the `core.managed-asset` type, i.e. in Machine, Network and Storage.
- EnumAttackVector: for the `attack_vector` property of a Vulnerability.
- EnumCaseStatus: for the `case_status` property of a Case.
- EnumCloudProvider: for the `provider` property of a `core.cloud-component`.

These abstract Enum types don't yet have any concrete data values. They just define the enumeration, so that a property in the unified model can reference one of these specific sets of valid values.

## The `NoeticEnum` Types

The `NoeticEnum*` types define standardized valid values.

> NOTE: Countries also have multiple standard encodings, but these are defined slightly differently, because it's more convenient to map the various standard identifiers as simple properties rather than correlated entities.

Each of the `NoeticEnum*` types has:

- A standard `id`, which is usually a string that includes the name of the enum as well as its value, e.g. "OSFamily: Windows".  This ID must never change, even if its display-value changes.
- A standard `value` for display, which also fulfills `core.named-object:name` 
- A sort order, so that the enum values can be shown in logical order; for example, Medium severity above Low
- An optional description.

Some enums follow well-recognized standards:

- "Attack vector" uses valid values from CVSS 3.1
- "Country" follows [GENC](https://www.fgdc.gov/standards/news/GENC), which is the official standard for US Government entities
- "Security Classification" follows FIPS-199
- "Severity" follows CVSS 3.1: NONE, LOW, MEDIUM, HIGH, CRITICAL

## Special Case: Asset Class

Asset classification is performed *automatically by the system*.  The `Machine:asset_class` property should not be fulfilled by a connector, because its value will be automatically derived from the other properties of the asset (especially `asset_type`).

## The Source Types

If a source uses a list of valid values (e.g. country codes) that exactly corresponds to the standard values, or a subset of them, then the source property can reference the relevant `NoeticEnum*` type.

Otherwise, the source should define its own concrete Enum type, and provide its list of valid values.  Each of these values must also be mapped to the corresponding standard value.  Typically this is done with properties of the type:

- `id` and `value` and `name` (often all the same: the valid value),
- `map_to`, used to correlate with the Noetic standard list (`correlation-key: EnumId`),
- a `description` if available.

The type definition is part of the relevant connector.  Its values are provided by a file in the `data` directory of the connector (not at runtime by the connector code).

## Source Mapping

Using enums, the source data MUST NOT be transformed to match a standard list, instead it is *mapped* natively.  There is NO need for a derived property or code to perform any custom mapping.
