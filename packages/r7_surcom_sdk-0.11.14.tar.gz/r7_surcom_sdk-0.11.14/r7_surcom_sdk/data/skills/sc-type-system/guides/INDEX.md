# Guides Index

This directory contains guides for working with the Surface Command type system.

| Guide | Description |
|-------|-------------|
| [correlation.md](correlation.md) | How correlatable types group entities from multiple sources |
| [cypher.md](cypher.md) | Writing Cypher queries against the Surface Command graph |
| [datamodel.md](datamodel.md) | Downloading and locating the Surface Command data model |
| [format.md](format.md) | Property `format` specifiers for dates, strings, and IPs |
| [mitigations.md](mitigations.md) | MITRE ATT&CK mitigation codes for security capabilities |
| [refdoc.md](refdoc.md) | Using OpenAPI/Swagger reference schemas in type definitions |
| [review.md](review.md) | Checklist for reviewing and validating type definitions |
| [typedef.md](typedef.md) | Structure and best practices for type definitions |
| [unified_enum_model.md](unified_enum_model.md) | Enumeration types and value mapping |
| [unified_external_attack_model.md](unified_external_attack_model.md) | Domains, IPs, certificates, and external infrastructure |
| [unified_vulnerability_model.md](unified_vulnerability_model.md) | Vulnerability, Exposure, and Finding relationships |
