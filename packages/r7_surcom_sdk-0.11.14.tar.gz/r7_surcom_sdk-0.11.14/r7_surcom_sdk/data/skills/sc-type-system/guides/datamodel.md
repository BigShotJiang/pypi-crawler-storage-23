# Surface Command Data Model

## **IF THE MODEL DOES NOT EXIST:**

- Do not guess, infer, or provide examples without the actual model
- Tell the user: "The Surface Command model is not present in `~/.r7-surcom-sdk/sc-data-model/`. I cannot proceed without it."
- Instruct them to download it using the surcom-sdk:
```bash
surcom model download --all
```
- Explain that:
- Core types will be saved in `~/.r7-surcom-sdk/sc-data-model/core-types/`
- Unified types will be saved in `~/.r7-surcom-sdk/sc-data-model/unified-types/`
- Source types will be saved in `~/.r7-surcom-sdk/sc-data-model/source-types/`
- Alternative download options:
```bash
# To download Core and Unified types only:
surcom model download --unified-types

# To download Source types only:
surcom model download --source-types
```