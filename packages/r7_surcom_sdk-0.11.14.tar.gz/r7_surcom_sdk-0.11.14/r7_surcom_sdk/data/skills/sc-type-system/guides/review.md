## Review Guidelines

Only make changes if specifically requested.

Top level:
* Validate correlation using [the "correlation" guide](../guides/correlation.md).
* Validate keys using [the "keys" guide](../references/x-samos-keys.md).
* If the type uses a reference-schema (`$ref`), refer to [the "refdoc" guide](refdoc.md).  When creating a new type, ALWAYS evaluate whether a reference-schema is suitable.
* Source types MUST NOT use any undocumented `x-samos-` attributes.

Use the sample data to understand the semantics of each property.
* Source types require matching `sample_data`.  Enum types require `data`.
* Identify any gaps, where properties in the type are not present in the sample data, or vice versa.
* Show sample data as an example when making suggestions.

UI:
* Property titles and descriptions must be appropriate.
* Validate table and detail views using [the "x-samos-table" guide](../references/x-samos-table.md) and [the "x-samos-detail" guide](../references/x-samos-detail.md).

Fulfills:
* Identify any fulfillment gaps, where properties in the core/unified model should be fulfilled with the available source properties.
* When searching for fulfills, use the correct YAML structure pattern. For example, to find if a type that fulfills `active` in `core.component`:
  ```bash
  grep -B2 "property-name: active" file.yaml | grep -q "type-name: core.component"
  ```
  This searches for the property-name and checks if the type-name appears in the preceding context.
* Fulfills can appear in both regular properties and derived properties (`x-samos-derived-properties`).

References:
* Reference properties should reference a source type within the same connector namespace (not a unified type or abstract type).
* Verify all [virtual edges](../references/x-samos-virtual.md) for correctness according to the unified model.
* **CRITICAL**: Before referencing a unified type (like `User`, `Machine`), check if a source type exists that extends the unified type in the same namespace (like `EzoAssetSonarMember` for `User`).
* To check for available source types in the same namespace:
  1. List the connector's types directory
  2. Read type definitions to see what unified types they extend
  3. Use source types that extend the unified type you need
* Only reference unified types directly when no suitable source type exists in the connector's namespace.

Other:
* For a Machine type: review `mitigations` following [the "mitigations" guide](mitigations.md).

* For any Enum types, evaluate the correctness of the values based on the sample data, and verify that they are correctly mapped to standard values.

* Types may only use the following `x-samos-` attributes:
    `x-samos-default-hide-from-graph`,
    `x-samos-detail-prefer-type-title`
    `x-samos-derived-properties`,
    `x-samos-detail`,
    `x-samos-extends-types`,
    `x-samos-global-zone`,
    `x-samos-hidden`,
    `x-samos-keys`,
    `x-samos-namespace`,
    `x-samos-supernode`,
    `x-samos-table`,
    `x-samos-type-name`,
    `x-samos-virtual`
* Properties may only use the following `x-samos-` attributes:
    `x-samos-correlation`,
    `x-samos-exclude`,
    `x-samos-fulfills`,
    `x-samos-hidden`,
    `x-samos-immutable`,   
    `x-samos-ref-types` 

