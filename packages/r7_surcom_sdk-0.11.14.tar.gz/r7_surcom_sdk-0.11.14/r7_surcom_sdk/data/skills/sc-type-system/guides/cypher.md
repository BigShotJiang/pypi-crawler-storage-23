# Cypher Queries

Use this guide when generating Cypher queries against the Surface Command graph database.

The graph is built from the `sc-type-system` data model:
- **Nodes** = entity types
- **Properties** = type properties  
- **Edges** = reference properties (from `x-samos-ref-types`); edge labels are literally the property name.

Surface Command uses standard OpenCypher syntax with extensions documented below. **Before writing any query**, consult `~/.r7-surcom-sdk/sc-data-model/` to verify type names, properties, and edge labels exist.

Additional documentation: https://docs.rapid7.com/surface-command/workspace-queries/

---

## Correlated and Source Entities

When querying for a correlated entity, use the unified type name.
Edges that correspond to *properties in the unified model* are attached to the correlated entity, not to the source entity.

If you specifically want the *source entities*, then you can MATCH the source type by name.  If you want *properties* of the source entities, use their extended name with back-ticks:

```cypher
match (u:User) where "OneLoginUser" in u.sources return u.`OneLoginUser:invalid_login_attempts`
```

## Sources Property

The `sources` property on correlatable entities contains a list of type names for the correlated source records. Example: `["SolarWindsOrionAgent", "DarktraceDevice"]`.

---

## Extension Functions and Operators

**Query composition:**
* `INCLUDE 'query-name'` — include an existing saved query, extend with `WITH`

**Case-insensitive operators:**
`ICONTAINS`, `ISTARTS WITH`, `IENDS WITH`, `IEQUALS`, `INOTEQUALS`, `IIN`

**Correlation functions** (for correlated entities only):
* `EVERY(property)` — list of values from each source entity
* `TOP(property)` — value from the preferred source entity

**Date functions:**
* `SINCE(timestamp, "DAYS")` — days since timestamp
* `UTCNOW()` — current date/time
* `TODAY()` — current date

**Networking functions:**
* `IP_IN_CIDR(ip, cidr)` — IP within CIDR range
* `IS_RFC1918(ip)` — RFC1918/RFC6598 address
* `IP_IS_PUBLIC(ip)` — publicly-routable address

---

## Output

- Limit exploratory queries: `LIMIT 25`
- Aggregate with `COLLECT()`
- Sort with `ORDER BY` for consistent results

---

## Performance Rules

**⚡ Filter Early:** Produce the smallest dataset before each operation. Filter nodes *before* traversing edges.

**⚡ Prefer Source Types:** References that traverse to concrete source types (e.g., `Rapid7IVMVulnerability`) are much more efficient than references to unified/abstract types (e.g., `Vulnerability`). Use the concrete type when you know the data source.

**⚡ Use Directional Arrows:** Always include arrows (`-->` or `<--`) in relationship patterns. This improves query performance by controlling graph traversal direction.

**❌ DO NOT:**
- Invent edge labels — verify the edge properties and their `x-samos-ref-types` attribute
- Use `WHERE x IN [list]` for joins — use edges
- Traverse unnecessary edges — use direct paths like `(a:Asset)-->(v:Vulnerability)` instead of `(a:Asset)<--(:Finding)-->(:Exposure)-->(v:Vulnerability)`
- Use regex when `CONTAINS`/`STARTS WITH` suffice

**⚠️ CAUTION:**
- `OPTIONAL MATCH` may scan large numbers of entities. Filter the source nodes as much as possible before the OPTIONAL MATCH.

**✅ DO:**
- Filter before traversing: `MATCH (m:Machine) WHERE ...` then `MATCH (m)-->(v:Vulnerability)`
- Use edges for relationships
- Verify types and properties exist in the model
- Use case-insensitive operators when appropriate

---

## Examples

### Basic Filtering
```cypher
MATCH (m:Machine)
WHERE m.name = 'web-server-01' AND m.asset_class = 'Server'
RETURN m.name, m.asset_class
```

### Source-Specific Properties
```cypher
MATCH (a:Asset)
RETURN a.`Rapid7IVMAsset:osVendor`, a
```

### Graph Traversal
```cypher
MATCH (m:Machine)-->(v:Vulnerability)
WHERE m.os_family ICONTAINS 'Windows' AND v.cvss > 7
RETURN m, v
```

### Filter on Best Value with `top()`
```cypher
MATCH (a:Asset)
WHERE top(a.name) = 'critical-server'
RETURN a
```

### Match All Fulfilling Values with `every()`
```cypher
MATCH (a:Asset)
WHERE TRUE IN every(a.active)
RETURN a
```

### Time-Based Filtering
```cypher
MATCH (m:Machine)
WHERE SINCE(m.last_seen, 'DAYS') < 30
RETURN m
```

### Case-Insensitive Search with Aggregation
```cypher
MATCH (m:Machine)
WHERE m.operating_system ICONTAINS 'windows'
RETURN m.os_family, COUNT(*) AS count
```
