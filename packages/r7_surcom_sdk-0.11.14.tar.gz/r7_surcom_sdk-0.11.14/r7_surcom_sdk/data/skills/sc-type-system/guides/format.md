## Property `format` specifiers

Properties can use a `format` attribute to declare specific data formats.
Some of these directly affect the functionality of the type.
A non-exhaustive list is provided below.

### Date formats

- `format: date`: a string property that represents a date, in ISO-8601 or RFC-1123 format.
- `format: date-time`: a string property that represents a date-time, in ISO-8601 (local or offset) or RFC-1123 format.
- `format: epoch`: an integer or number date-time specified in epoch seconds (e.g. Python `time.time()` or Unix `date +%s`).
- `format: epoch-millis`: an integer or number date-time specified in epoch milliseconds (e.g. JavaScript `new Date().valueOf()`)
- `format: epoch-micros`: an integer date-time specified in epoch microseconds
- `format: epoch-nanos`: an integer date-time specified in epoch nanoseconds (e.g. Python `time.time_ns()`)

### String formats

- `format: ip-addr`: an IPv4 or IPv6 address
- `format: mac-addr`: an EUI-48 MAC address
- `format: email`: an Internet email address
- `format: domain-name`: an Internet domain name
- `format: uri`: a hyperlink to a machine-readable resource
- `format: url`: a hyperlink to a user-readable Web location
- `format: uuid`: a UUID
