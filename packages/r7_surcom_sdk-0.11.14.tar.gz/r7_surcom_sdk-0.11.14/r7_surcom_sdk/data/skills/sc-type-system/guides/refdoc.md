# Reference Schema

Many security products already provide OpenAPI or Swagger definitions for their REST APIs, including schemas to describe the return data.  These OpenAPI or Swagger schemas can be incorporated by reference into a Surface Command type.

To do this, the connector includes a copy of the OpenAPI or Swagger definition as a "reference-schema" file, and references the relevant data schema using a `$ref` directive in the type definition.  The resulting type consists of the reference schema, with the type definition "overlay" applied.

## URL of the `$ref` document

The `$ref` in a type does not reference a "real" URL.  It references a URL that is defined under `reference-schemas` in the `connector.spec.yaml`:

```yaml
reference-schemas:
  - url: https://example.org/api
    file: refdocs/openapi.json
```

The `url` is an arbitrary URL that is resolved by the OpenAPI/Swagger spec that can be found *within the connector* at the `file` location.

Based on this URL, the type's `$ref` uses Json Pointer syntax to reference the schema within the reference-schema file.  The addressed fragment must be a *schema* that defines *properties* that will be inherited by the type definition.  This is usually extracted from the return value of an API call, or a component schema within the OpenAPI document.

This example references a component schema:

```
https://example.org/api#/components/schemas/MyDevice
```

This example references a fragment of an API endpoint's return schema, using Json Pointer syntax:

```
https://example.org/api2#/paths/~1hardware/get/responses/200/content/application~1json/schema/properties/rows/items
```

The properties within the addressed schema fragment become part of the type.  When validating a type, these properties must be included.

## Example

The NIST NVD API includes a JSON file that includes the schema definition for a `cve_item`.  A connector for NVD can include and reference that JSON schema file, and a type definition can incorporate all the properties of the `cve_item` to build a Surface Command type (extended and annotated with the `x-samos-*` attributes).

```yaml
x-samos-type-name: NistCVE
x-samos-namespace: nist.nvd
title: CVE
description: Common Vulnerabilities and Exposures, from the NIST National Vulnerability Database
$ref: https://csrc.nist.gov/schema/nvd/api/2.0/cve_api_json_2.0.schema.20250411#/definitions/cve_item
```