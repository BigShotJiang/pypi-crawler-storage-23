# Correlation

Some types are correlatable.  This means: multiple entities (usually from different sources) each provide a different perspective on the same real-world object.  Examples of correlatable entitles include Machine (Asset), Vulnerability, User (Identity), Certificate.

A _unified type_ is identified as correlatable by extending the `sys.correlatable` system type.

A _source type_ is correlatable if it extends a correlatable unified type.


When extending a correlatable type:

* The `x-samos-extends-types` must specify an appropriate `subtype-priority`.
* There must be at least one _correlatable property_, marked with the `x-samos-correlation` attribute.  (The exception is for Exposure types, which may correlate if they represent well-known objects such as CWE, but are often source-specific; and some types where there are no correlation keys defined in the `sys.correlation-key.json` list).
* Correlation properties must specify a valid `correlation-key` attribute.
