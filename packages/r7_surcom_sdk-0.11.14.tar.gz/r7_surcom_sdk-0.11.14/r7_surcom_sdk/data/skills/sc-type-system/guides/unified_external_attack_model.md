# External Attack Surface Model

This guide describes the unified types for modeling **externally-visible infrastructure**: domains, IP addresses, network services, certificates, and web sites.

All these types are correlatable. `Domain` and `IpAddress` are in the **global data zone** (their primary identifiers—DNS names and IP addresses—are globally unique).

External entities connect to internal assets primarily via `NetworkService` (a Machine can have a list of network services).

## Domain

A DNS name: public domain, private domain, subdomain, hostname, or wildcard (e.g., `*.example.com`).

> NOTE: Not every hostname needs a Domain record—only names visible to the Internet or related to certificates/services.

## DomainName (Deprecated)

`DomainName` is deprecated/hidden. Do not use or reference.  Replaced by `Domain`.

## IpAddress

An IPv4 (`version: "v4"`) or IPv6 (`version: "v6"`) address.

> NOTE: Only create IpAddress entities for managed addresses—public Internet addresses, reserved addresses, or addresses with special purpose.

## NetworkService

An open port on a host responding to network requests. Properties include:
- `hostname` (Domain) or `ip` (IpAddress)
- Transport (TCP/UDP) and port
- Application protocol (HTTPS, SSH, FTP, etc.)
- TLS certificate if presented

## WebSite

A web site or application with a primary URL, referencing `NetworkService` entities that implement it.

## Certificate

A TLS certificate with subject name(s), issuer, serial number/hashes, validity dates, and revocation status.

- `signed_by` → issuer certificate (trust chain)
- `is_self_signed` → true for root/self-signed certificates
- `is_wildcard` → true for wildcard subjects

## Network

A public IP range, VPC, or subnet, typically identified by CIDR (or ASN for BGP routing).

> NOTE: The `IpAddress.belongs_to_network` reference is **maintained automatically** by the system (smallest matching CIDR).

---

Mapping and Relationships:

## DNS Record Mapping

| Record | Representation |
|--------|----------------|
| A | `Domain.resolves_to_refs` → `IpAddress` (v4) |
| AAAA | `Domain.resolves_to_refs` → `IpAddress` (v6) |
| CNAME | `Domain.resolves_to_refs` → `Domain` |
| MX, NS, SRV, TXT | Not modeled |

## Primary Relationships

| From | Property | To | Represents |
|------|----------|----|------------|
| `Domain` | `resolves_to_refs` | `IpAddress`, `Domain` | DNS resolution by A, AAAA and CNAME |
| `IpAddress` | `belongs_to_network` | `Network` | Mapped automatically |
| `NetworkService` | `ip` | `IpAddress` | The address where the service was observed |
| `NetworkService` | `hostname` | `Domain` | The hostname where the service was observed |
| `NetworkService` | `certificate` | `Certificate` (array) | The certificate(s) presented by the service |
| `Certificate` | `domain` | `Domain` | The domain of the subject |
| `Certificate` | `signed_by` | `Certificate` (array) | The issuer trust chain |
| `WebSite` | `services` | `NetworkService` (array) | The services that implement the Web application |
