# Mitigations

Mitigations, encoded using [MITRE ATT&CK](https://attack.mitre.org/mitigations/) mitigation codes, are used to identify the presence of security capabilities that protect against various attack techniques.

The `mitigations` property on `core.component` (present on a Machine, Network, or other resource) is populated with a list of the valid mitigation codes based on the data.

The mitigation codes represent:  "This data provides evidence that this mitigation is active".  A mitigation is only active if the component is correctly configured, for example that an endpoint detection tool is not disabled.

We implement the following subset of mitigation codes.

| ID | Mitigation Name | Description |
| :--- | :--- | :--- |
| **M1001** | Security Updates | Mobile (ONLY) system-level patching. Always set **M1051** if this is set. |
| **M1002** | Attestation | Mobile (ONLY), Apple MDA or similar, Android SafetyNet, or Samsung Knox TIMA Attestation. |
| **M1012** | Enterprise Policy (EMM/MDM) | Mobile (ONLY) device management systems. Often you want to also tag **M1051** (patching). |
| **M1016** | Vulnerability Scanning | Vulnerability scanning **EITHER** on the host **OR** remotely. Any connector that produces vulnerability findings (CVEs) should populate this. |
| **M1017** | User Training | User has received training. |
| **M1021** | Restrict Web-Based Content | Prevent downloads, etc. |
| **M1028** | Operating System Configuration | Apple SIP, or equivalents. |
| **M1032** | Multi-Factor Authentication | User or account has MFA enabled or enforced. |
| **M1033** | Limit Software Installation | Agent enforces software allowlists, software restriction policies, or least privilege access principles. |
| **M1034** | Limit Hardware Installation | Restricts USB or other hardware installation. |
| **M1035** | Limit Access to Resource Over Network | Device managed by a network access control (NAC) or zero-trust system, e.g., Cisco ISE. |
| **M1037** | Filter Network Traffic | Firewall (on the host, or a host agent that enforces use of a network filter). |
| **M1038** | Execution Prevention | MacOS Gatekeeper or similar; allow only signed code / block download execution / etc. |
| **M1040** | Behavior Prevention on Endpoint | Behavioral EDR e.g., syscall hooks that block malicious functionality. |
| **M1041** | Encrypt Sensitive Information | Full-disk encryption on an endpoint, or encryption on a Storage entity. |
| **M1046** | Boot Integrity | Secure Boot, TPM, other boot-loader protections. |
| **M1049** | Antivirus/Antimalware | Traditional AV, signature-based malware detection. |
| **M1050** | Exploit Protection | Data Execution Prevention (DEP), Address Space Layout Randomization (ASLR), Control Flow Guard (CFG), EMET, WDEG "Exploit Guard" or similar. |
| **M1051** | Update Software | Patch management for the OS and/or application software. |
| **M1053** | Data Backup | Evidence of successful backup. |
