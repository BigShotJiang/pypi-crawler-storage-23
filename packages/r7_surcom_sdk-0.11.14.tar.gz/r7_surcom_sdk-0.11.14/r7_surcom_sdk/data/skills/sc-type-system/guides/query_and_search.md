# Query and Search the Type System


The `sc-data-model` contains a complete set of types, in two equivalent formats:

* All the type definitions as YAML files on disk,
* A DuckDB database that contains all the type definitions as JSON.

The database is located at: **`~/.r7-surcom-sdk/sc-data-model/types.duckdb`**

You can use `grep` to search the YAML files for simple strings.
For structured search use `duckdb` (but avoid regex and separate sql files).

## Structure of the DuckDB

The database contains two tables:

### `sc_data_model` - Type Definitions

Contains one row per type with extracted metadata columns for easy querying:

| Column | Type | Description |
|--------|------|-------------|
| `filepath` | VARCHAR | Path to the YAML source file |
| `type_name` | VARCHAR | Unique type identifier (e.g., `User`, `Machine`, `core.principal`) |
| `title` | VARCHAR | Human-readable display name |
| `description` | VARCHAR | Type description |
| `deprecated` | BOOLEAN | Whether the type is deprecated |
| `abstract` | BOOLEAN | Whether the type is abstract (unified/core) vs concrete (source) |
| `aka_type_names` | VARCHAR[] | Alternative type names (aliases) |
| `extends` | VARCHAR[] | List of parent type names this type extends |
| `doc` | JSON | Complete type definition as JSON |
| `doc_text` | VARCHAR | Full document as text (for text search) |

### `sc_data_model_properties` - Property Reference Index

Contains one row per property, with pre-extracted reference types and fulfills mappings for efficient querying:

| Column | Type | Description |
|--------|------|-------------|
| `type_name` | VARCHAR | The type containing this property |
| `property_path` | VARCHAR | Full path to the property (e.g., `fields.assignee.accountId`) |
| `property_name` | VARCHAR | Just the property name |
| `property_type` | VARCHAR | JSON Schema type (`string`, `array`, `object`, etc.) |
| `title` | VARCHAR | Human-readable property title |
| `description` | VARCHAR | Property description |
| `deprecated` | BOOLEAN | Whether the property is deprecated |
| `ref_types` | VARCHAR[] | List of type names from `x-samos-ref-types` |
| `fulfills_type` | VARCHAR | The unified type this property maps to (from `x-samos-fulfills`) |
| `fulfills_property` | VARCHAR | The unified property this maps to (from `x-samos-fulfills`) |

## Example Queries

### Simple Queries Using Extracted Columns

Find all abstract (unified) types:
```sql
SELECT type_name, title, description 
FROM sc_data_model 
WHERE abstract = true
ORDER BY type_name;
```

Find types by name pattern:
```sql
SELECT type_name, title, extends 
FROM sc_data_model 
WHERE type_name LIKE 'Rapid7%'
ORDER BY type_name;
```

Find types that directly extend a specific type:
```sql
SELECT type_name, title, extends 
FROM sc_data_model 
WHERE list_contains(extends, 'Machine')
ORDER BY type_name;
```

### Querying the Type Hierarchy

The `extends` column enables recursive queries to find all types in an inheritance hierarchy:

```sql
-- Find all types that extend core.principal (directly or indirectly)
WITH RECURSIVE principal_hierarchy AS (
    -- Base case: start with the root type
    SELECT type_name, extends, 0 as depth
    FROM sc_data_model 
    WHERE type_name = 'core.principal'
    
    UNION ALL
    
    -- Recursive case: find types extending any type already in the hierarchy
    SELECT s.type_name, s.extends, h.depth + 1
    FROM sc_data_model s
    JOIN principal_hierarchy h ON list_contains(s.extends, h.type_name)
    WHERE h.depth < 5  -- Prevent infinite recursion
)
SELECT DISTINCT 
    p.type_name,
    s.title,
    s.description,
    s.abstract,
    p.extends,
    p.depth
FROM principal_hierarchy p
JOIN sc_data_model s ON p.type_name = s.type_name
ORDER BY p.depth, p.type_name;
```

### Querying Reference Properties

The `sc_data_model_properties` table makes it easy to find types that reference other types
via `x-samos-ref-types`, without needing to parse JSON or search text:

```sql
-- Find all properties that reference the User type
SELECT type_name, property_path, title, ref_types
FROM sc_data_model_properties
WHERE list_contains(ref_types, 'User')
ORDER BY type_name;
```

For finding references to a type hierarchy (e.g., User and all its subtypes):

```sql
-- Find all types that reference any User type (User or types extending it)
WITH RECURSIVE user_hierarchy AS (
    -- Base case: the User unified type
    SELECT type_name, 0 as depth
    FROM sc_data_model 
    WHERE type_name = 'User'
    
    UNION ALL
    
    -- Recursive case: types that extend any type already in the hierarchy
    SELECT s.type_name, h.depth + 1
    FROM sc_data_model s
    JOIN user_hierarchy h ON list_contains(s.extends, h.type_name)
    WHERE h.depth < 5
),
user_types AS (
    SELECT DISTINCT type_name FROM user_hierarchy
)
-- Find all properties whose ref_types array contains any User type
SELECT DISTINCT 
    p.type_name,           -- The type containing the reference
    p.property_path,       -- Full path to the property
    p.title,               -- Human-readable title
    u.type_name as references_user_type
FROM sc_data_model_properties p
CROSS JOIN user_types u
WHERE list_contains(p.ref_types, u.type_name)
ORDER BY p.type_name, p.property_path;
```

### Accessing the Full JSON Document

For complex queries requiring the full type definition, use the `doc` column:

```sql
-- Get a specific property definition from the JSON
SELECT 
    type_name,
    doc->'properties'->'users' as users_property
FROM sc_data_model 
WHERE type_name = 'core.owned-entity';
```

### Querying Fulfills Mappings

The `fulfills_type` and `fulfills_property` columns show how source type properties map to
unified type properties via `x-samos-fulfills`. This is useful for understanding which
connectors populate specific unified model fields.

```sql
-- Find all source properties that fulfill the Machine unified type
SELECT 
    type_name,
    property_path,
    fulfills_property
FROM sc_data_model_properties
WHERE fulfills_type = 'Machine'
ORDER BY fulfills_property, type_name;
```

Example output:
| type_name | property_path | fulfills_property |
|-----------|---------------|-------------------|
| Rapid7InsightAgent | osFingerprints.bestFingerprint.description | operating_system |
| Rapid7ICSInstance | platform | os_family |
| Rapid7IVMAsset | osArchitecture | os_architecture |

```sql
-- Find which source types fulfill Case properties (e.g., for ticketing integrations)
SELECT 
    type_name,
    property_path,
    fulfills_property
FROM sc_data_model_properties
WHERE fulfills_type = 'Case'
ORDER BY type_name, fulfills_property;
```

Example output:
| type_name | property_path | fulfills_property |
|-----------|---------------|-------------------|
| JiraIssue | fields.assignee.accountId | assigned_to_user |
| JiraIssue | fields.created | created_date |
| JiraIssue | fields.creator.accountId | created_by_user |
| JiraIssue | fields.status.name | status |

```sql
-- Find all types that fulfill the User 'email' property
SELECT 
    type_name,
    property_path
FROM sc_data_model_properties
WHERE fulfills_type = 'User' 
  AND fulfills_property = 'email'
ORDER BY type_name;
```