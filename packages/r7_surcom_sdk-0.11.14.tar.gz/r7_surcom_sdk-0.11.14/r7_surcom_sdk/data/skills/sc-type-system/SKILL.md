---
name: sc-type-system
description: Understanding the Surface Command type system / data model.
metadata:
  version: "1.0"
---

# ⚠️ CRITICAL FIRST STEP ⚠️

**YOU MUST PERFORM THIS CHECK FIRST - BEFORE READING ANYTHING ELSE IN THIS SKILL:**

**Step 1:** Use `list_dir` to check if `~/.r7-surcom-sdk/sc-data-model/` exists
**Step 2:** If it does NOT exist, immediately:
  - STOP reading this skill
  - Tell the user: "⚠️ **The Surface Command model is not present.** I cannot answer questions about types without it."
  - Instruct them to run: `surcom model download --all`
  - END your response - do not provide examples or guess at type structures
  
**Step 3:** If it DOES exist, continue using this skill, referencing the `sc-data-model` contents to understand all the available types.

Once downloaded, the data model is located at: **`.github/sc-data-model/`**
- YAML type definitions are in subdirectories: `core-types/`, `unified-types/`, `source-types/`, `enum-types/`
- There's also a DuckDB database for structured queries: **`.github/sc-data-model/types.duckdb`**
- See [query_and_search.md](guides/query_and_search.md) for how to query the database

**IF THE MODEL DOES NOT EXIST:**
  - **STOP IMMEDIATELY** - Do not attempt to answer questions about types or properties
  - **WARN THE USER** - that the model is missing and provide instructions to download it. See  [datamodel.md](guides/datamodel.md)
  - **END YOUR RESPONSE** - Do not continue with any type-related work

---

# Understanding the Surface Command type system

The Surface Command data model is a graph of strongly-typed entities and their relationships. The type system that defines these entities and their interconnections is dynamic and extensible. Surface Command uses OpenAPI to describe each entity type's schema, including its relationships to other types.

When data is imported by a connector, each entity is validated against the schema for the corresponding source type.

The type system includes unified types that support common, consistent behavior. Users can write queries using unified types for a generic, standardized view of the data or use source types to query specific properties. Unified types also enable correlation, which groups multiple source entities that represent the same physical object.

This skill describes the model and its syntax in detail. Understanding the model is essential when developing and validating connectors.


## Quick Reference

| Task | Guide |
|------|-------|
| Query or search the type system | [query_and_search.md](guides/query_and_search.md) |
| Create a new type | [typedef.md](guides/typedef.md) AND [review.md](guides/review.md) |
| Review existing types | [review.md](guides/review.md) |
| Review types for the Vulnerabilities/Exposures/Findings data model | [unified_vulnerability_model.md](guides/unified_vulnerability_model.md) |
| Review types for External Attack Surface (domains, IPs, certificates) | [unified_external_attack_model.md](guides/unified_external_attack_model.md) |
| Review types for Mitigations | [mitigations.md](guides/mitigations.md) |
| Review types for Enums | [unified_enum_model.md](guides/unified_enum_model.md) |
| Use reference schemas | [refdoc.md](guides/refdoc.md) |
| Add derived properties | [x-samos-derived-properties.md](references/x-samos-derived-properties.md) |
| Write Cypher queries | [cypher.md](guides/cypher.md) |

See the [Guides Index](guides/INDEX.md) for a complete list of guides, or the [Reference Index](references/INDEX.md) for `x-samos-*` attribute documentation.


## Type Definitions

A type definition describes the schema for an entity in Surface Command. Each type definition includes properties, relationships to other types, and metadata that defines how the type behaves within Surface Command.

**⚠️ CRITICAL: Internal System Types**
  - **NEVER** search for, read, or reference any type prefixed with `sys.`
  - Types like `sys.taggable`, `sys.correlatable`, `sys.enrichable` are internal system types
  - These types are not available in the Surface Command Model folder and should be completely ignored
  - When you see `sys.*` in `x-samos-extends-types`, skip it and do not attempt to read it
  - Only work with `core.*` types (prefixed with "core."), unified types and source types (no prefix)

- There are three kinds of type definitions:
    - Core abstract types ("mixin", hidden) used for sharing properties across type definitions
    - Unified abstract types (user-visible) that represent common entities in the type system
    - Source types ("concrete") that describe data from a connector or other source.

See [the "typedef" guide](guides/typedef.md) for details.


### Surface Command Custom Attributes

Custom attributes prefixed with `x-samos-` define specific behaviors and relationships in the type system. These attributes are essential for understanding how types interact within Surface Command.

- `x-samos-type-name`: specifies the unique internal ID for a type.
- `x-samos-namespace`: provides a namespace for type-names.
- `x-samos-extends-types`: defines inheritance between types.
- `x-samos-keys`: lists the key properties that identity and reference an entity.
- `x-samos-supernode`: identifies likely graph supernodes.
- `x-samos-table`: defines the default UI columns for a type.
- `x-samos-detail`: defines the primary user interface for a type.
- `x-samos-ref-types`: defines references between types.
- `x-samos-fulfills`: defines property mapping onto the Unified Model.
- `x-samos-derived-properties`: declares properties that are computed from original data.
- `x-samos-hidden`: hides a type or property from the UI.
- `x-samos-exclude`: excludes a property's data from processing.
- `x-samos-correlation`: defines how entities are correlated together.

Each of these attributes has a corresponding guide in the `references/` directory, containing additional details.


## Best Practices

- **⚠️ CRITICAL: When creating or updating types**, you MUST follow [the "review" guide](guides/review.md) to apply validation criteria **during creation**, not after. This ensures:
  - All properties from sample data are included
  - Proper fulfills are applied
  - No `sys.*` types are referenced
  - UI views (table/detail) are appropriate
  - **Reference properties prefer source types in the same namespace** (e.g., use `EzoAssetSonarMember` instead of `User` when both exist)

- When reviewing existing connector source types, follow [the "review" guide](guides/review.md).

- When generating new types, first investigate whether an available reference-schema ("$ref") matches the API response data.

- Always validate the completed type definition using the review guide checklist.
