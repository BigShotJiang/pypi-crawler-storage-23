# Type System Reference Index

This directory contains reference documentation for the `x-samos-*` attributes used in Surface Command type definitions.

## Type-Level Attributes

| Attribute | Description |
|-----------|-------------|
| [x-samos-type-name](x-samos-type-name.md) | Specifies the unique internal ID for a type |
| [x-samos-aka-type-names](x-samos-aka-type-names.md) | Defines alternative names for a type |
| [x-samos-namespace](x-samos-namespace.md) | Provides a namespace for type-names |
| [x-samos-extends-types](x-samos-extends-types.md) | Defines inheritance between types |
| [x-samos-keys](x-samos-keys.md) | Lists the key properties that identify and reference an entity |
| [x-samos-table](x-samos-table.md) | Defines the default UI columns for a type |
| [x-samos-detail](x-samos-detail.md) | Defines the primary user interface for a type |
| [x-samos-derived-properties](x-samos-derived-properties.md) | Declares properties that are computed from original data |
| [x-samos-virtual](x-samos-virtual.md) | Specifies virtual edges using Cypher queries |
| [x-samos-global-zone](x-samos-global-zone.md) | Identifies that a type describes global data |
| [x-samos-supernode](x-samos-supernode.md) | Identifies likely graph supernodes |
| [x-samos-hidden](x-samos-hidden.md) | Hides a type or property from the UI |
| [x-samos-default-hide-from-graph](x-samos-default-hide-from-graph.md) | Guides specific UI behavior for graph display |

## Property-Level Attributes

| Attribute | Description |
|-----------|-------------|
| [x-samos-fulfills](x-samos-fulfills.md) | Defines property mapping onto the Unified Model |
| [x-samos-ref-types](x-samos-ref-types.md) | Defines references between types |
| [x-samos-correlation](x-samos-correlation.md) | Defines how entities are correlated together |
| [x-samos-immutable](x-samos-immutable.md) | Identifies that key data elements do not update |
| [x-samos-exclude](x-samos-exclude.md) | Excludes a property's data from processing |
| [x-samos-hidden](x-samos-hidden.md) | Hides a type or property from the UI |
