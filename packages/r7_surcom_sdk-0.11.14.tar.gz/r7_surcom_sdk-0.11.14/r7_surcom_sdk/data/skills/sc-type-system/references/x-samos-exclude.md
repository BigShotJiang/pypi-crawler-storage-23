## `x-samos-exclude: true`: excludes a property's data from processing

Excluded properties are unavailable for query and display.

This is used to exclude "system data" or other large/unwanted properties in a source type.

### Example

```yaml
properties:
  avatar:
    type: string
    title: Avatar Icon
    # base64 blob of a PNG image, so exclude it
    x-samos-exclude: true
```