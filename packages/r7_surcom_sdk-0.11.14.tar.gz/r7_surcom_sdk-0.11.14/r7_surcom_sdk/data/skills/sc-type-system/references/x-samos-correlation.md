##  `x-samos-correlation`: defines how entities are correlated together 

`x-samos-correlation` indicates that a property value shared by several entities can be used to group those entities together.

This property attribute can only be used in a source type that extends a correlatable type (Machine, etc).

For example, a source Machine record from Active Directory can be matched with source records from ServiceNow and Rapid7. Correlation means that these each provide a different system's viewpoint on a single Machine entity that exists independently of the various security tools.  The unified entity collects the best available view of this machine. The [rules for which property takes priority](#correlation-display-priority) are defined in the unified type and are configurable.

Correlation keys are property values from each of the relevant source types. If a unified type is able to be correlated, then each source type must provide at least one correlation key. Where correlation keys match, the source entities are joined into the correlated unified entity.

The valid correlation-keys are defined in the file `~/.r7-surcom-sdk/sc-data-model/data/sys.correlation-key.json`.
A `correlation-key` attribute must match an `id` in this list, the `correlation-type` must match, and the property data must be appropriate.

For example, a machine with a MAC address, a plain hostname, and an X.500 DN might declare all three as correlation keys:


```yaml
properties:
  distinguishedName:
    title: DN
    x-samos-immutable: true
    x-samos-fulfills:
      type-name: core.component
      property-name: id
    x-samos-correlation:
      correlation-key: Machine.x500-dn
      correlation-type: Machine
      priority: 4
  hostname:
    title: Name
    x-samos-fulfills:
      type-name: core.named-object
      property-name: name
    x-samos-correlation:
      correlation-key: Machine.unqualified-hostname
      correlation-type: Machine
      priority: 3
  mac:
    title: MAC Addresses
    x-samos-correlation:
      correlation-key: MacAddr.value
      correlation-type: Machine
      priority: 3
```

### Correlation display priority

Correlated entities are often treated as a single object for display and searching. Two settings determine which source value is chosen in these situations.

First, each property in the unified type has a `x-samos-best-rule-type` property that defines the algorithm used to select a single source value for display. The options for this property are:

* `priority`: the default behavior.  The top property is chosen according to the `subtype-priority` of the correlated type.  If there are multiple source records with the same type, the most recent is chosen.
* `max-value`: choose the maximum value from among the source records.
* `min-value`: choose the minimum value from among the source records.
* `most-recent`: choose the value from the most recently-updated source record.
* `prefer-true`: if any source value is `true`, the top value is set `true`.
* `prefer-false`: if any source value is `false`, the top value is set `false`.

An example of this can be found in the Vulnerability type.  If any source of vulnerability information says that it has been exploited in the wild, the property should show as `true` in a result table, in the General tab on the asset details panel, and in searches.

```yaml
properties:
  is_exploited:
    type: boolean
    title: Exploited
    x-samos-best-rule-type: "prefer-true"
```

Second, the `subtype-priority` attribute of the `x-samos-extends-types` entry indicates the overall priority of a source, used when choosing the priority (the default `x-samos-best-rule-type` behavior) of a correlated entity.
