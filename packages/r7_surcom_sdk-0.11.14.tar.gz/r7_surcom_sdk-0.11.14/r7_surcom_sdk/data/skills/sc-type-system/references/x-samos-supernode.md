## `x-samos-supernode`: identifies likely graph supernodes

`x-samos-supernode: true` indicates that a type is likely to create high-cardinality graph references.

This flag is used to guide some UI behavior, and also optimizes the database.

Supernode examples include, for example: a "site" that is referenced by every "device".

