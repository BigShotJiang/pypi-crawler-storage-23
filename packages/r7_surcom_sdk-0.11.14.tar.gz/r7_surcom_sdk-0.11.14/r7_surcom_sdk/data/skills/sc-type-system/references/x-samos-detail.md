## `x-samos-detail`: defines the primary user interface for a type

`x-samos-detail` lists the properties that should be shown, and in what order, in a single entity's detail view.
The detail view is the "Slide Out" panel that opens when you click on a row.

Users should generally be presented with actionable (security-relevant) information first (hostname, status, OS, MAC address, configuration information).  Opaque technical properties such as UUIDs can be omitted.

If a property is listed in the schema but not in `x-samos-detail`, it will show up at the bottom of the detail view in alphabetical order under the "Additional Properties" section.

- Similar to `x-samos-table`, the `x-samos-detail` property is defined as an array of property names. These property names correspond to the fields defined in the OpenAPI schema for that type

- The order is respected, so the first item in the list will be the at the top of the detail view, the second item will be below that, and so on.


### Example

#### Example using only `name`

```yaml
x-samos-detail:
  - name: osVersion
  - name: ipAddress

...

properties:
  osVersion:
    type: string
    title: OS Version
  ipAddress:
    type: string
    title: IP Address
```

#### Example using `label`

```yaml
x-samos-detail:
  - name: osVersion
    label: Operating System Version

...

properties:
  osVersion:
    type: string
    title: OS Version
```

## More Complex Use Case

You can specify a parent's property as a column by using the format `parent-type-name:property-name`

### Example

```yaml
x-samos-type-name: Machine

...

x-samos-extends-types:
  - type-name: core.component

...

x-samos-detail:
  - name: name
  - name: core.component:active

properties:
  name:
    type: string
    title: Name

```