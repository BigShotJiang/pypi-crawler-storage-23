## `x-samos-aka-type-names`: defines alternative names for a type

Some unified types have multiple names, for historical reasons.

For example, `Machine` is also named `Asset`, and these names can be used interchangeably.

```yaml
x-samos-type-name: Machine
x-samos-aka-type-names:
  - Asset
```
