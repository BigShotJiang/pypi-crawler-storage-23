`x-samos-virtual`

The `x-samos-virtual` type attribute is used to specify "virtual edges": properties that are not part of the original data,
but fulfill "reference properties" in a base type, using a Cypher query.

This is primarily used for [vulnerability types](../guides/unified_vulnerability_model.md).

The syntax is: a Cypher query (including edge specifications) that links "this entity" (the current type) to another entity of the appropriate type required to fulfill the property.  Types must be concrete source types where possible (the usual exception is `Vulnerability`, since the standard CVE data sources are built-in and not part of each connector).

Example:
```yaml
# in the `SentinelOneAgent` type, which is a Machine
x-samos-virtual:
  # Fulfill the `exposures` property of this Machine, which is a reference to an Exposure type
  exposures:
    type-name: Exposure
    # Exposures are linked via the Finding
    cypher-pattern: >
      <-[:`e:Finding:applies_to`]-(:`SentinelOneFinding`)-[:`e:Finding:vulnerability`]->(:SentinelOneExposure)

  # Fulfill the `vulnerabilities` property of this Machine, which is a reference to a Vulnerability type
  vulnerabilities:
    type-name: Vulnerability
    # Vulnerabilities are linked via the Finding and the Exposure
    cypher-pattern: >
      <-[:`e:Finding:applies_to`]-(:`SentinelOneFinding`)-[:`e:Finding:vulnerability`]->(:SentinelOneExposure)-[:`e:Exposure:vulnerabilities`]->(:Vulnerability)

```
