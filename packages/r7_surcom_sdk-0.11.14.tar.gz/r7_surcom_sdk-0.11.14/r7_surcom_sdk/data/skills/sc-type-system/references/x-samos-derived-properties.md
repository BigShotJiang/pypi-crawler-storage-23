## `x-samos-derived-properties`: declares properties that are computed from original data

Derived properties provide expressions that are evaluated to build values that aren't in the raw type content but are convenient for reference or display. These properties are computed at import time using one of three supported syntaxes: `jsonpath`, `jmespath`, or `expression`.

Derived properties must be used sparingly.  Don't create a derived property simply to fulfill a unified property; instead, apply `x-samos-fulfills` to the original property.

Generally there are only two reasons to use a derived property:
- When a *calculated value* is required, transforming values from the original data, or
- When one source property should fulfill *more than one* unified property with the same value.

## `jsonpath` Syntax
<!-- TODO: need to add more detail here -->
The `jsonpath` syntax is suitable for addressing, extracting, and combining portions of the original content in flexible ways.  It also includes a few extension functions for common operations. To learn more about the syntax, see the [documentation](https://github.com/h2non/jsonpath-ng#jsonpath-syntax).

## `jmespath` Syntax
<!-- TODO: need to add more detail here -->
The `jmespath` syntax has similar capabilities to `jsonpath`. To learn more about the `jmespath` syntax, see the [website](https://jmespath.org/).

## `expression` Syntax

A simple expression-substitution language where you can combine string values from existing properties. To learn more about this, see the [Python `f-strings` syntax documentation](https://docs.python.org/3/tutorial/inputoutput.html#tut-f-strings).

### Examples

#### Example using `jsonpath`

```yaml
x-samos-derived-properties:
  num_macs:
    title: MAC Count
    type: integer
    syntax: jsonpath
    value: "$.macs.`len`"
```

#### Example using `jmespath`

```yaml
x-samos-derived-properties:
    num_macs:
        title: "MAC Count"
        type: integer
        syntax: jmespath
        value: "length(macs)"
```

#### Example: Combining Arrays with `jmespath`

When source data has separate properties for similar data (e.g., IPv4 and IPv6 addresses), use derived properties to combine them into a unified array for fulfillment:

```yaml
x-samos-derived-properties:
  d_ips:
    # Combine IPv4 and IPv6 addresses into single array for Machine:ips
    x-samos-hidden: true
    type: array
    syntax: jmespath
    value: '[v4IpAddrs, v6IpAddrs][]'
    items:
      type: string
      format: ip-addr
    x-samos-fulfills:
      type-name: Machine
      property-name: ips
```

#### Example using `expression`

```yaml
const:
    type: string
    syntax: expression
    value: "{id} (from {source})"
```