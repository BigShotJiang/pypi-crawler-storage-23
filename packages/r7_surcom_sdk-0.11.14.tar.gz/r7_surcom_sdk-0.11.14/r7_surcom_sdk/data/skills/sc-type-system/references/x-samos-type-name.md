## `x-samos-type-name`: specifies the unique internal ID for a type

NOTE: the `x-samos-type-name` is not the display-name.  The `title` is used for display.
