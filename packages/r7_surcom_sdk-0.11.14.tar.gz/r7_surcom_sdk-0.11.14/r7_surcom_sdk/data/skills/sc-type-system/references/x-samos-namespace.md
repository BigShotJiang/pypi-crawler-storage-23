## `x-samos-namespace`: provides a namespace for type-names

- This is used internally to link types and reference schemas to the connector.

- All types within a connector must use the same namespace.

- This is usually the same as the Connector `id` as defined in the Connector's connector.spec.yaml file 