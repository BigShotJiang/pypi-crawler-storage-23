## `x-samos-table`: defines the default UI columns for a type.

The `x-samos-table` type attribute defines the properties are displayed as columns in the Surface Command UI.

- It is a list of objects, each representing a column in the table view for the type. Each object can have the following properties:
    - `name`: The name of the property to display as a column.
    - `label`: (Optional) The label to use as the column header. If not provided
, the property's `title` will be used.

- The order is respected, so the first item in the list will be the first column, the second item will be the second column, and so on.

For usability, there should usually be no more than 7 columns in the table.


### Example

#### Example using only `name`

```yaml
x-samos-table:
  - name: name
  - name: osVersion
  - name: ipAddress

...
properties:
  name:
    type: string
    title: Name
  osVersion:
    type: string
    title: OS Version
  ipAddress:
    type: string
    title: IP Address
```

#### Example using `label`

```yaml
x-samos-table:
  - name: osVersion
    label: Operating System Version

...

properties:
  osVersion:
    type: string
    title: OS Version
```

## More Complex Use Case

You can specify a parent's property as a column by using the format `parent-type-name:property-name`

### Example

```yaml
x-samos-type-name: Machine

...

x-samos-extends-types:
  - type-name: core.component

...

x-samos-table:
  - name: name
  - name: core.component:active

properties:
  name:
    type: string
    title: Name

```