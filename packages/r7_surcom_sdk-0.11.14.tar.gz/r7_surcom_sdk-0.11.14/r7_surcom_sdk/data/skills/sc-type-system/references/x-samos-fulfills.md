## `x-samos-fulfills`: defines property mapping onto the Unified Model

When a source property fulfills a property of an unified type, the value is available for query under both the original property name (on the source type) and also the property name on the unified type. The source property is aliased to the unified name. Fulfilled properties allow a source type to provide values for a property of an unified type.

- Source type properties can fulfill unified type properties using the `x-samos-fulfills` key
- The value is an object with `type-name` and `property-name` properties
- The `type-name` is the `x-samos-type-name` of the unified type
- If the property we want to fulfill is on a parent core type, the `type-name` here should be the parent type
- The `property-name` is the name of the property on the unified type or the core type being fulfilled

### Hints
- Do not provide results for `deprecated: true` properties
- You can only fulfill one property per source property
- Unified array properties MAY be fulfilled from source scalar properties, but NOT the reverse.

### Best Practices

**CRITICAL: When using `x-samos-ref-types` with fulfills:**
- Always prefer referencing source types in the same `x-samos-namespace` over unified types for better performance
- Example: If fulfilling Machine's `users` property and your namespace has a source type that extends `User`, reference the source type (e.g., `EzoAssetSonarMember`) instead of the unified `User` type
- Only reference unified types when no appropriate source type exists in your namespace

### Fulfills Criteria
- Array properties can be fulfilled by single-valued (scalar) properties on the source type but scalar properties cannot be fulfilled by array properties.
- Fulfilling unified properties is optional but recommended.  A source type must fulfill at least one of the base type's key properties.
- If the appropriate value for a unified property isn't directly available in the source data derived properties can be used to fulfill the base. For more information on derived properties, see the [the "x-samos-derived-properties" guide](x-samos-derived-properties.md).
- Enumerated lists, such as operating system family or severity, can be mapped using the `enum` type.

### Examples

#### Example of fulfilling with a reference to a source type in the same namespace (RECOMMENDED)

When fulfilling a property that requires a reference known as a "Reference Property", always check if your namespace has a source type that extends the unified type. This improves performance.

```yaml
# Given: EzoAssetSonarMember extends User and has 'email' as a key
# Task: Fulfill Machine's 'users' property (inherited from core.owned-entity)

properties:
  assigned_to_user_email:
    title: Assigned To User
    type: string
    x-samos-ref-types:
      - type-name: EzoAssetSonarMember  # Use source type in same namespace
        key-name: email
    x-samos-fulfills:
      type-name: core.owned-entity
      property-name: users
```

#### Example of a simple fulfill

```yaml
properties:
  Description:
    title: Description
    type: string
    x-samos-fulfills:
      type-name: core.named-object
      property-name: description

  osVersion:
    title: OS Version
    type: string
    x-samos-fulfills:
      type-name: Machine
      property-name: os_version
```

#### Example of fulfilling an array property with a single string property

- The Machine unified type has a property `hostnames`
- It is an array of strings representing
- The source type has a property `computerDnsName` which is a single string
- In this case we can fulfill an array property with a single value
- We can fulfill the `hostnames` property on the Machine type using the `computerDnsName` property on the source type

```yaml
properties:
  computerDnsName:
    type: string
    x-samos-fulfills:
      type-name: Machine
      property-name: hostnames
```

#### Example of fulfilling a reference property

- The Exposure unified type has a property `vulnerabilities`
- It is an array of references to Vulnerability entities
- The source type has a property `cves` which is an array of strings representing CVE IDs
- In this case we can fulfill the `vulnerabilities` reference property on the Exposure type using the `cves` property on the source type
- Each CVE ID in the `cves` array will be used to reference a Vulnerability entity by its `id`
- Note the indentation of the `x-samos-fulfills` property at the same level as `items`
- Remember: Follow the best practice of referencing source types in your namespace when available (see Best Practices section above)

```yaml
properties:
  cves:
    type: array
    title: CVEs
    items:
      type: string
      x-samos-ref-types:
        - type-name: Vulnerability
          key-name: id
    x-samos-fulfills:
      type-name: Exposure
      property-name: vulnerabilities
```
