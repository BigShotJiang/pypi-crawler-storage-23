## `x-samos-ref-types`: defines references between types

- Properties on Types can reference other Core, Unified or Source type properties using the `x-samos-ref-types` attribute
- This allows complex relationships between entities to be modeled
- A property can reference multiple types
- It is a list of objects with `type-name` and `key-name` properties
  - The `type-name` is the `x-samos-type-name` of the referenced type
  - The `key-name` is one of the `x-samos-keys` defined on the referenced type. This is never the `x-samos-keys` of the source type.

### Example

#### Example referencing a single type

- Usually a Source type property references another Source type in the same namespace
- Here the `AsimilyAnomalyFinding` type has a property `device_id`
- This property references the `AsimilyDevice` type by its `d_device_id` property, which is one of `AsimilyDevice`'s `x-samos-keys`
- Here the property type should be the same as the key type on the referenced type, which is a string

```yaml
x-samos-type-name: AsimilyAnomalyFinding
x-samos-namespace: asimily

x-samos-extends-types:
  - type-name: Finding
...

properties:
  device_id:
    type: string
    title: Device
    x-samos-ref-types:
      - type-name: AsimilyDevice
        key-name: d_device_id
```

#### Example referencing multiple types

- This type has a property `cves`
- It is an array of strings representing CVE IDs
- Each CVE ID can reference a Vulnerability entity by its `id`

```yaml
properties:
  cves:
    title: CVEs
    type: array
    items:
      type: string
      x-samos-ref-types:
        - type-name: Vulnerability
          key-name: id
```