## `x-samos-extends-types`: defines inheritance between types

`x-samos-extends-types` provides a list of abstract "base types" that are inherited by the current type.

Properties of the base types are included in the schema for the current type.

The list is formatted as a list of base types, with an optional `subtype-priority` for any correlatable types.
For example, when extending a correlated type such as Machine:

```yaml
x-samos-extends-types:
  - type-name: Machine
    subtype-priority: 4
```

The following convention is used for subtype priority levels.  The highest level (`7`) is reserved for user values.  The lower levels are suitable for sources that are not the primary authoritative data.

| Priority | Description |
|:-|:-|
| 7 | Data that represents a user override (not from an API connector) |
| 6 | Definitive values provided by the system that manages this object (for example, cloud infrastructure) |
| 5 | Physical data discovered locally (for example, by an endpoint agent) |
| 4 | Physical data discovered remotely (for example, by a network scanner) |
| 3 | Normative catalog data |
| 2 | Non-normative catalog data |
| 1 | Other |
