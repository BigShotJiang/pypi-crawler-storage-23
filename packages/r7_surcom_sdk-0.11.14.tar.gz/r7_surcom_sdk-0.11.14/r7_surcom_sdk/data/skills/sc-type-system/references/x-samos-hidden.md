## `x-samos-hidden: true`: hides a type or property from the UI

Hidden types are not shown in the type explorer or query builder.
Hidden properties are not shown in the table or detail views.
Nevertheless, these types and properties still exist in the graph, and may be used in queries.

If a property or type is `deprecated: true` it should also be `x-samos-hidden: true`.

### Example

```yaml
properties:
  internalId:
    type: string
    title: Internal Identifier
    x-samos-hidden: true
```
