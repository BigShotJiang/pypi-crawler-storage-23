## `x-samos-global-zone`: identifies that a type describes "global data"

"Global" types describe data that has a single global identifier regardless of its context.  Examples include vulnerabilities (the CVE ID is globally assigned), IpAddress (an Internet-routable IP address is globally assigned).

If a type has a base type that is `x-samos-global-zone: true`, the type must also be marked as being in the global data zone.  For all other types, this attribute must not be set.
