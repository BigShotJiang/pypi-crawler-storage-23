## `x-samos-keys`: lists the key properties that identity and reference an entity

Key properties are used to
* uniquely identify an entity (like a database "primary key")
* reference an entity from another (here it's possible that a key is not unique across all entities).

Key properties must be [`x-samos-immutable: true`](x-samos-immutable.md).

A concrete type must have at least one key.
An abstract type does not require keys.
