## `x-samos-default-hide-from-graph: true`: guides specific UI behavior

No additional detail.
