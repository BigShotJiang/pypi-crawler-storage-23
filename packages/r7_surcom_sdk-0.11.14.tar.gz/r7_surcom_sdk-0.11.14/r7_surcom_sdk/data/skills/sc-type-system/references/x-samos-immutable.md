## `x-samos-immutable`: identifies that key data elements do not update.

When data is updated by a connector, the database performs "upsert" based on the type's [key properties](x-samos-keys.md).  The `x-samos-immutable` attribute is required for properties that are used as keys.

If a key property is derived from a content property (e.g. to convert an integer ID to string), the source property should also be marked as immutable, since this better reflects its semantics.  Other properties must not be marked as immutable.