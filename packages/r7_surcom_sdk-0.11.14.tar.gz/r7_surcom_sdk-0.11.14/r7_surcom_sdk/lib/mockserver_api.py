
import logging
import subprocess  # nosec: B404
import time

import requests
from requests.exceptions import HTTPError, JSONDecodeError

from r7_surcom_sdk.lib import constants, sdk_helpers, SurcomSDKException
from r7_surcom_sdk.lib.sdk_terminal_fonts import colors

LOG = logging.getLogger(constants.LOGGER_NAME)


class MockServerAPI:
    """
    This class provides an interface to the MockServer API
    """

    STATE_RUNNING = "running"
    STATE_STOPPED = "stopped"

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 1080
    ):
        """
        Initialize the MockServerAPI instance.

        Contains methods to interact with the MockServer API,
        such as checking status, resetting, and loading expectations.

        Also contains wrappers for docker commands to start and stop the MockServer container.

        :param host: the host address of the MockServer within the container, defaults to "127.0.0.1"
        :type host: str, optional
        :param port: the port to run the MockServer on, defaults to 1080
        :type port: int, optional
        """
        self.host = host
        self.port = port
        self.session = requests.session()

    def _put(
        self,
        endpoint: str,
        params: dict = None,
        json: dict = None,
        timeout: float = constants.REQUESTS_TIMEOUT_SECONDS,
    ):

        LOG.debug(f"Sending request to MockServer API endpoint '{endpoint}' with params '{params}'")

        r = self.session.put(
            url=f"http://{self.host}:{self.port}/mockserver/{endpoint}",
            params=params,
            json=json,
            timeout=timeout
        )

        r.raise_for_status()

        return r

    def start(
        self,
        verbose: bool = False,
        restart: bool = False,
    ):
        """
        Start the MockServer in a Docker container.

        :param verbose: Whether to start the MockServer with verbose logging enabled. Defaults to False.
        :type verbose: bool, optional
        :param restart: Whether to restart the MockServer if it is already running. Defaults to False.
        :type restart: bool, optional
        :raises SurcomSDKException: If the MockServer is already running and restart is False,
            or if there was an error starting the MockServer.
        """

        if self.is_running():

            if restart:
                sdk_helpers.print_log_msg(
                    "Restarting the MockServer...",
                    log_color=colors.OKBLUE,
                )
                self.stop()
                self.wait_until(state=self.STATE_STOPPED)

            else:
                raise SurcomSDKException(f"MockServer is already running on port {self.port}")

        cli_args = [
            "docker", "run", "-d", "--rm",
            "--name", constants.MOCKSERVER_CONTAINER_NAME,
            "-p", f"{self.port}:{self.port}",
            "--env", f"MOCKSERVER_PORT={self.port}",
        ]

        if verbose:
            cli_args.extend(["--env", "MOCKSERVER_LOG_LEVEL=DEBUG"])

        cli_args.append("mockserver/mockserver:latest")

        cmd = " ".join(cli_args)

        sdk_helpers.print_log_msg(
            f"Starting the MockServer using the following command:\n{cmd}",
            log_color=colors.OKBLUE,
        )

        try:

            sdk_helpers.run_subprocess(cli_args, stdout=None, stderr=subprocess.PIPE)

        except SurcomSDKException as e:

            if "is already in use" in str(e):
                sdk_helpers.print_log_msg(
                    "The MockServer is already running. Stop the existing MockServer before starting a new one.",
                    log_color=colors.WARNING,
                )

            raise e

        self.wait_until(state=self.STATE_RUNNING)

        sdk_helpers.print_log_msg("MockServer started.", log_color=colors.OKGREEN)

    def stop(self):
        """
        Stop the MockServer by stopping the Docker container.
        """

        sdk_helpers.print_log_msg(
            "Stopping the MockServer...",
            log_color=colors.OKBLUE,
        )

        if not self.is_running():
            sdk_helpers.print_log_msg(
                "The MockServer is not currently running. Nothing to do.",
                log_color=colors.WARNING
            )
            return

        cli_args = [
            "docker", "rm", "-f", constants.MOCKSERVER_CONTAINER_NAME
        ]

        result = sdk_helpers.run_subprocess(cli_args, capture_output=True)

        # NOTE: when we run docker rm -f on a container that doesn't exist the cmd still returns a 0 exit code
        # so we have to check the stderr for the "No such container" message
        if "No such container" in result.stderr.decode():
            sdk_helpers.print_log_msg(
                "The MockServer is not currently running. Nothing to do.",
                log_color=colors.WARNING
            )

        elif result.returncode == 0:

            self.wait_until(state=self.STATE_STOPPED)

            sdk_helpers.print_log_msg(
                "Stopped the MockServer and removed its container.",
                log_color=colors.OKGREEN
            )

        else:
            sdk_helpers.print_log_msg(
                "An unexpected error occurred while trying to stop the MockServer.",
                log_color=colors.WARNING
            )
            sdk_helpers.print_log_msg(
                f"Command output:\n{result.stdout.decode()}\n{result.stderr.decode()}",
                log_color=colors.WARNING
            )

    def is_running(self) -> bool:
        """
        Check if the MockServer is running by sending a request to the /status endpoint.

        :return: True if the MockServer is running, False otherwise.
        :rtype: bool
        """

        try:
            r = self._put(endpoint="status", timeout=3)

            r_json = r.json()

            if self.port not in r_json.get("ports", []):
                LOG.debug(f"MockServer is not listening on port {self.port}")
                return False

            return r.status_code == 200

        except (HTTPError, JSONDecodeError) as err:
            LOG.debug(f"MockServer is not running or not responding to status checks: {str(err)}")
            return False

        except requests.exceptions.ConnectionError as err:
            LOG.debug(f"Failed to connect to MockServer: {str(err)}")
            return False

    def wait_until(
        self,
        state: str,
        timeout: float = 30
    ) -> bool:
        """
        Wait until the MockServer is running by repeatedly checking the /status endpoint.

        :param timeout: The maximum amount of time to wait for the MockServer to start, in seconds.
            Defaults to 30 seconds.
        :type timeout: float, optional
        :return: True if the MockServer is running within the timeout period,
            else raises a SurcomSDKException indicating that the MockServer failed to start within the timeout period.
        :rtype: bool
        """

        start_time = time.time()

        while time.time() - start_time < timeout:
            if state == self.STATE_RUNNING and self.is_running():
                return True

            elif state == self.STATE_STOPPED and not self.is_running():
                return True

            time.sleep(2)

        raise SurcomSDKException(
            f"Timed out after {timeout} seconds waiting for the MockServer to reach the '{state}' state."
        )

    def reset(self) -> bool:
        """
        Reset the MockServer by sending a request to the /reset endpoint.

        :return: True if the MockServer was successfully reset, False otherwise.
        :rtype: bool
        """

        try:
            r = self._put(endpoint="reset")
            return r.status_code == 200
        except (HTTPError, JSONDecodeError) as err:
            LOG.debug(f"Failed to reset MockServer: {str(err)}")
            return False

    def load_expectation(
        self,
        expectation: dict
    ) -> bool:
        """
        Load an expectation into the MockServer by sending a request to the /expectation endpoint.

        :param expectation: The expectation to load, as a dictionary.
        :type expectation: dict
        :return: True if the expectation was successfully loaded, False otherwise.
        :rtype: bool
        """

        try:
            r = self._put(endpoint="expectation", json=expectation)
            return r.status_code == 200
        except (HTTPError, JSONDecodeError) as err:
            LOG.debug(f"Failed to load expectation into MockServer: {str(err)}")
            return False

    def load_expectation_from_file(
        self,
        path_file: str
    ):
        """
        Load an expectation into the MockServer from a file path.

        Supported file formats are JSON and YAML. If the file format is not supported,
        a warning will be logged we return False.

        :param path_file: The file path to load the expectation from.
        :type path_file: str
        :return: True if the expectation was successfully loaded, False otherwise.
        :rtype: bool
        """

        if not path_file.endswith((".json", ".yaml", ".yml")):
            LOG.warning(f"Unsupported expectation file format for file '{path_file}'. "
                        "Supported formats are JSON and YAML.")
            return False

        expectation = sdk_helpers.read_file(path_file)

        return self.load_expectation(expectation)

    def load_expectations(
        self,
        expectations: list[dict | str]
    ):
        """
        Load multiple expectations into the MockServer from a list of expectation dicts or file paths.

        :param expectations: A list of expectations to load, where each expectation is either a dict
            or a file path string.
        :type expectations: list[dict | str]
        :raises SurcomSDKException: If any expectation in the list is not a dict or a file path string.
        """
        for expectation in expectations:

            if isinstance(expectation, dict):
                self.load_expectation(expectation)

            elif isinstance(expectation, str):
                self.load_expectation_from_file(expectation)

            else:
                raise SurcomSDKException(f"Invalid expectation format: {expectation}. "
                                         "Expectations must be either a dict or a file path string.")

    def get_expectations(self) -> list:
        """
        Get the currently loaded expectations from the MockServer.

        Send a request to the /retrieve endpoint with the type parameter set to "active_expectations".

        :return: A list of the currently loaded active expectations, or an empty list if there was an error.
        :rtype: list
        """

        try:
            r = self._put(endpoint="retrieve", params={"type": "active_expectations"})
            return r.json()
        except (HTTPError, JSONDecodeError) as err:
            LOG.debug(f"Failed to get expectations from MockServer: {str(err)}")
            return []
