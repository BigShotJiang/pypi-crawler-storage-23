# Builds an index using DuckDB

import os
import logging
from datetime import date, datetime

import duckdb
import json
from tempfile import NamedTemporaryFile

from r7_surcom_sdk.lib import constants, sdk_helpers
from r7_surcom_sdk.lib.sdk_terminal_fonts import colors

LOG = logging.getLogger(constants.LOGGER_NAME)


def _json_serializer(obj):
    """Custom JSON serializer for objects not serializable by default json code."""
    if isinstance(obj, (date, datetime)):
        return obj.isoformat()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def _flatten_to_text(obj, depth=0) -> str:
    """Recursively flatten a nested dict/list to searchable text."""
    if depth > 50:  # Prevent infinite recursion
        return ""
    if isinstance(obj, dict):
        parts = []
        for k, v in obj.items():
            parts.append(str(k))
            parts.append(_flatten_to_text(v, depth + 1))
        return " ".join(parts)
    elif isinstance(obj, list):
        return " ".join(_flatten_to_text(item, depth + 1) for item in obj)
    elif obj is None:
        return ""
    else:
        return str(obj)


def _extract_ref_types(ref_types_raw: list) -> list:
    """Extract type names from x-samos-ref-types (handles both string and dict formats)."""
    ref_types = []
    for ref in ref_types_raw or []:
        if isinstance(ref, str):
            ref_types.append(ref)
        elif isinstance(ref, dict) and "type-name" in ref:
            ref_types.append(ref["type-name"])
    return ref_types


def _extract_properties(properties: dict, path_prefix: str = "") -> list:
    """
    Recursively extract all properties from a type definition.

    Handles:
    - Top-level properties
    - Array items (via 'items' key)
    - Nested object properties (via 'properties' key)

    Returns a list of dicts with: property_path, property_name, ref_types, property_def
    """
    results = []
    if not isinstance(properties, dict):
        return results

    for prop_name, prop_def in properties.items():
        if not isinstance(prop_def, dict):
            continue

        # Build the full path
        property_path = f"{path_prefix}.{prop_name}" if path_prefix else prop_name

        # Extract x-samos-ref-types (could be a list of strings or list of objects)
        ref_types = _extract_ref_types(prop_def.get("x-samos-ref-types"))

        # Extract x-samos-fulfills (maps this property to a base type's property)
        fulfills = prop_def.get("x-samos-fulfills")
        fulfills_type = fulfills.get("type-name") if isinstance(fulfills, dict) else None
        fulfills_property = fulfills.get("property-name") if isinstance(fulfills, dict) else None

        results.append({
            "property_path": property_path,
            "property_name": prop_name,
            "ref_types": ref_types,
            "fulfills_type": fulfills_type,
            "fulfills_property": fulfills_property,
            "property_type": prop_def.get("type"),
            "title": prop_def.get("title"),
            "description": prop_def.get("description"),
            "deprecated": prop_def.get("deprecated", False),
        })

        # Recurse into array items
        if "items" in prop_def and isinstance(prop_def["items"], dict):
            items_def = prop_def["items"]
            # Check if items has ref-types (x-samos-ref-types can be on items for arrays)
            items_ref_types = _extract_ref_types(items_def.get("x-samos-ref-types"))

            # Add items entry if it has ref_types
            # Note: x-samos-fulfills is NOT valid on items, only on the array property itself
            if items_ref_types:
                results.append({
                    "property_path": f"{property_path}[]",
                    "property_name": f"{prop_name}[]",
                    "ref_types": items_ref_types,
                    "fulfills_type": None,
                    "fulfills_property": None,
                    "property_type": items_def.get("type"),
                    "title": items_def.get("title"),
                    "description": items_def.get("description"),
                    "deprecated": items_def.get("deprecated", False),
                })

            # Recurse into items properties if present (for nested objects in arrays)
            if "properties" in items_def:
                results.extend(_extract_properties(items_def["properties"], f"{property_path}[]"))

        # Recurse into nested object properties
        if "properties" in prop_def:
            results.extend(_extract_properties(prop_def["properties"], property_path))

    return results


def _get_parent_folders_for_connector_types(
    path_connectors_ws: str,
    paths_extra_repo: list = []
) -> list:

    rtn_list = []

    # NOTE: By default, we always try and get types from
    # the types in the Surcom Connectors repo
    path_git_folder = sdk_helpers.find_folder(
        start_path=path_connectors_ws,
        folder_name=constants.DIR_NAME_GIT_FOLDER
    )

    if path_git_folder:
        rtn_list.append(os.path.dirname(path_git_folder))

    else:
        LOG.debug(f"No '{constants.DIR_NAME_GIT_FOLDER}' folder found in "
                  f"the connectors workspace '{path_connectors_ws}'.")

    for p in paths_extra_repo or []:

        the_path = os.path.abspath(p)

        if os.path.isdir(os.path.join(the_path, constants.DIR_NAME_GIT_FOLDER)):
            sdk_helpers.print_log_msg(
                f"Also looking in '{the_path}' for connector types as specified by the "
                "user via '--paths-extra-repos'...",
                log_level=logging.INFO,
                log_color=colors.OKBLUE
            )
            rtn_list.append(the_path)

        else:
            LOG.debug(f"Provided extra path '{p}' does not contain a valid "
                      "repository with a '.git' folder. Skipping...")

    return rtn_list


def _find_connector_types_folders(repo_root: str) -> list:
    """
    Find all 'types' folders within the repository.
    Excludes build directories and other non-source locations.
    """
    # Directories to skip when searching for types folders
    excluded_dirs = {
        'node_modules', '__pycache__', 'venv', '.venv',
        'build', 'dist', 'target', '.tox', '.eggs', 'egg-info'
    }

    connector_types_folders = []
    for root, dirs, files in os.walk(repo_root):
        # Skip hidden directories and excluded directories
        dirs[:] = [d for d in dirs if not d.startswith('.') and d not in excluded_dirs and not d.endswith('.egg-info')]

        if os.path.basename(root) == "types":
            connector_types_folders.append(root)
    return connector_types_folders


def build_index(
    path_sc_data_model: str,
    path_connectors_ws: str,
    paths_extra_repo: list = []
) -> str:
    """
    Build a DuckDB index of all YAML files in the given data model directory,
    plus any 'types' folders found within the repository.
    Includes full-text search (FTS) indexing for efficient text queries.

    :param path_sc_data_model: Path to the data model directory containing YAML files.
    :param path_connectors_ws: Path to the connectors workspace directory.
    :param paths_extra_repo: Optional extra paths to look for Surface Command types (e.g another repository)
    :return: Path to the created DuckDB database file.
    """

    db_file_path = os.path.join(path_sc_data_model, constants.FILENAME_TYPES_INDEX)

    # 1. Setup DuckDB connection
    # We use a persistent file, not :memory:
    con = duckdb.connect(db_file_path)

    # Load the FTS extension
    con.execute("INSTALL fts")
    con.execute("LOAD fts")

    # 2. Create the tables
    # Main table: promoted top-level properties from type definitions, plus full doc and FTS text
    con.execute("""
        CREATE OR REPLACE TABLE sc_data_model (
            filepath VARCHAR,
            type_name VARCHAR,
            title VARCHAR,
            description VARCHAR,
            deprecated BOOLEAN,
            abstract BOOLEAN,
            aka_type_names VARCHAR[],
            extends VARCHAR[],
            doc JSON,
            doc_text VARCHAR
        )
    """)

    # Properties table: indexes all properties and their type references
    con.execute("""
        CREATE OR REPLACE TABLE sc_data_model_properties (
            type_name VARCHAR,
            property_path VARCHAR,
            property_name VARCHAR,
            property_type VARCHAR,
            title VARCHAR,
            description VARCHAR,
            deprecated BOOLEAN,
            ref_types VARCHAR[],
            fulfills_type VARCHAR,
            fulfills_property VARCHAR
        )
    """)

    sdk_helpers.print_log_msg(
        f"Scanning for YAML files in '{path_sc_data_model}'...",
        log_level=logging.DEBUG
    )

    # Get Core and Unified types from the main data model directory
    # Scan for YAML files with a depth limit of 5 levels to avoid runaway scans
    max_depth = 5
    base_depth = path_sc_data_model.rstrip(os.sep).count(os.sep)
    files = []
    for root, dirs, filenames in os.walk(path_sc_data_model):
        current_depth = root.count(os.sep) - base_depth
        if current_depth >= max_depth:
            dirs.clear()  # Don't descend further
            continue
        for filename in filenames:
            if filename.endswith(".yaml"):
                files.append(os.path.join(root, filename))

    # Find and scan all 'types' folders within the repository
    parent_folders = _get_parent_folders_for_connector_types(
        path_connectors_ws=path_connectors_ws,
        paths_extra_repo=paths_extra_repo
    )

    connector_types_folders = []

    for p in parent_folders:
        connector_types_folders.extend(_find_connector_types_folders(p))

    for connector_types_folder in connector_types_folders:

        sdk_helpers.print_log_msg(
            f"Scanning connector types in '{connector_types_folder}'...",
            log_level=logging.DEBUG
        )
        # Types are directly within this folder (not subfolders)
        for filename in os.listdir(connector_types_folder):
            if filename.endswith(".yaml"):
                files.append(os.path.join(connector_types_folder, filename))

    # 3. Process and Insert
    # We write to temporary JSONL files first.
    # This is often faster than thousands of individual INSERT statements.

    sdk_helpers.print_log_msg(
        f"Processing {len(files)} YAML files...",
        log_level=logging.INFO
    )

    # (Fail on error, there should be no errors when parsing)
    valid_count = 0
    property_records = []
    with NamedTemporaryFile(mode="w", suffix=".jsonl", delete=True, encoding=constants.ENCODING_UTF8) as temp_f:
        for fpath in files:
            # Parse YAML (sdk_helpers.read_file handles encoding and parsing)
            data = sdk_helpers.read_file(fpath)
            if data is None:
                continue

            # Get absolute path
            filepath = os.path.abspath(fpath)

            # Extract promoted top-level properties
            type_name = data.get("x-samos-type-name")
            title = data.get("title")
            description = data.get("description")
            deprecated = data.get("deprecated", False)
            abstract = data.get("x-samos-abstract", False)
            aka_type_names = data.get("x-samos-aka-type-names", [])

            # Extract extends: list of type-names from x-samos-extends-types objects
            extends_types = data.get("x-samos-extends-types", [])
            extends = [ext.get("type-name") for ext in extends_types if ext.get("type-name")]

            # Flatten the document to searchable text for FTS
            doc_text = _flatten_to_text(data)

            # Create a record with promoted properties
            record = {
                "filepath": filepath,
                "type_name": type_name,
                "title": title,
                "description": description,
                "deprecated": deprecated,
                "abstract": abstract,
                "aka_type_names": aka_type_names,
                "extends": extends,
                "doc": data,
                "doc_text": doc_text
            }
            temp_f.write(json.dumps(record, default=_json_serializer) + "\n")
            valid_count += 1

            # Extract all properties for the properties table
            if type_name and "properties" in data:
                props = _extract_properties(data["properties"])
                for prop in props:
                    property_records.append({
                        "type_name": type_name,
                        "property_path": prop["property_path"],
                        "property_name": prop["property_name"],
                        "property_type": prop["property_type"],
                        "title": prop["title"],
                        "description": prop["description"],
                        "deprecated": prop["deprecated"],
                        "ref_types": prop["ref_types"],
                        "fulfills_type": prop["fulfills_type"],
                        "fulfills_property": prop["fulfills_property"]
                    })

        sdk_helpers.print_log_msg(
            f"Parsed {valid_count} YAML files. Ingesting into DuckDB..."
        )

        # Flush to ensure all data is written before DuckDB reads it
        temp_f.flush()

        # 4. Bulk Load into DuckDB
        # NOTE: if the file is empty, read_json_auto will fail, so we only run the SQL if we have valid records
        if valid_count > 0:
            sql = f"""
                INSERT INTO sc_data_model
                SELECT filepath, type_name, title, description, deprecated, abstract,
                       aka_type_names, extends, doc, doc_text
                FROM read_json_auto('{temp_f.name}')
            """  # nosec B608 - temp_f.name is from NamedTemporaryFile, not user input
            con.execute(sql)

    # 4b. Bulk load properties table
    sdk_helpers.print_log_msg(
        f"Indexing {len(property_records)} properties..."
    )

    # NOTE: same here, if we have no properties, we should not run the SQL as read_json_auto will fail on an empty file
    if property_records:
        with NamedTemporaryFile(mode="w", suffix=".jsonl", delete=True, encoding="utf-8") as props_f:
            for prop_record in property_records:
                props_f.write(json.dumps(prop_record) + "\n")
            props_f.flush()

            sql = f"""
                INSERT INTO sc_data_model_properties
                SELECT type_name, property_path, property_name, property_type,
                       title, description, deprecated, ref_types,
                       fulfills_type, fulfills_property
                FROM read_json_auto('{props_f.name}')
            """  # nosec B608 - props_f.name is from NamedTemporaryFile, not user input
            con.execute(sql)

    # 5. Create Full-Text Search index on searchable text columns
    sdk_helpers.print_log_msg(
        "Building full-text search index..."
    )
    con.execute("""
        PRAGMA create_fts_index(
            'sc_data_model',
            'type_name',
            'type_name', 'title', 'description', 'doc_text',
            overwrite=1
        )
    """)

    # Temp file is automatically deleted when context exits
    con.close()

    sdk_helpers.print_log_msg(
        f"Data Model index with FTS saved to '{db_file_path}'",
        log_color=colors.OKGREEN
    )

    return db_file_path
