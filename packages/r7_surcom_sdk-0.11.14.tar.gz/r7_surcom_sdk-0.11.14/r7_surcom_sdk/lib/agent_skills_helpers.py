"""
Module containing helper methods for using Agent Skills
"""
import os
import re
import shutil
import logging
from typing import List
from importlib import resources

from packaging.version import Version


from r7_surcom_sdk.lib import constants, sdk_helpers, SurcomSDKException
from r7_surcom_sdk.lib.sdk_terminal_fonts import fmt, formats

# Get the same logger object that is used in main.py
LOG = logging.getLogger(constants.LOGGER_NAME)


def get_list_of_skills_available() -> List[str]:
    """
    Get a list of skills by looking /data/skills folder

    :return: a list of skill names
    :rtype: List[str]
    """

    skills_dir = resources.files(f"{constants.PACKAGE_NAME}.data.skills")

    return [item.name for item in skills_dir.iterdir()]


def copy_skill_from_resources(
    skill_name: str,
    path_dest: str
) -> str:
    """
    Copy a skill from the resources to a given destination path

    :param skill_name: the name of the skill to copy, should be the name of a folder in /data/skills
    :type skill_name: str
    :param path_dest: the path to copy the skill to, should be a directory
    :type path_dest: str

    :return: the path to the copied skill
    :rtype: str
    """

    if skill_name not in get_list_of_skills_available():
        raise SurcomSDKException(
            f"Skill '{skill_name}' not found in resources",
            solution="Ensure the skill name is correct"
        )

    skill_src = resources.files(f"{constants.PACKAGE_NAME}.data.skills").joinpath(skill_name)
    skill_dst = os.path.join(path_dest, skill_name)

    os.makedirs(skill_dst, exist_ok=True)

    shutil.copytree(skill_src, skill_dst, dirs_exist_ok=True)

    return skill_dst


def prompt_and_install_each_skill(default_to_yes: bool = False):
    """
    Prompt the user to select skills to install from the list of available skills,
    and then copy the selected skills from the resources to the current working directory
    """

    skills_available = get_list_of_skills_available()

    for skill in skills_available:

        install_skill = sdk_helpers.prompt_to_confirm(
            f'''\n{fmt(f"Copy the skill '{skill}'?", f=formats.BOLD)}''',
            raise_exception=False,
            default_to_yes=default_to_yes,
            add_continue_to_prompt=False
        )

        if install_skill:
            copy_skill_from_resources(
                skill_name=skill,
                path_dest=constants.PATH_AGENT_SKILLS
            )

            LOG.debug(f"'{skill}' skill copied to '{constants.PATH_AGENT_SKILLS}'")

        else:
            LOG.debug(f"'{skill}' skill was not copied")


def read_skill_version(
    path_skill_dir: str
) -> Version:
    """
    Read the version of a skill from its skill.md file

    :param path_skill_dir: the path to the skill
    :type path_skill_dir: str
    :return: the version of the skill as a Version object
    :rtype: Version
    """

    version_str = None

    path_skill_md = os.path.join(path_skill_dir, "SKILL.md")

    if not os.path.isfile(path_skill_md):
        raise SurcomSDKException(f"'{path_skill_md}' is not a valid file to read skill version from")

    with open(path_skill_md) as fp:
        for line in fp:
            m = re.match(r'\s*version:\s*["\']?(.+?)["\']?\s*$', line)
            if m:
                version_str = m.group(1)
                break

    if version_str:
        return Version(version_str)

    raise SurcomSDKException(f"Could not find version in '{path_skill_md}'")


def get_skill_version_from_resources(
    skill_name: str
) -> Version:
    """
    Get the version of a skill from the resources by reading its skill.md file

    :param skill_name: the name of the skill, should be the name of a folder in /data/skills
    :type skill_name: str
    :return: the version of the skill as a Version object
    :rtype: Version
    """

    if skill_name not in get_list_of_skills_available():
        raise SurcomSDKException(
            f"Skill '{skill_name}' not found in resources",
            solution="Ensure the skill name is correct"
        )

    path_skill_dir = resources.files(f"{constants.PACKAGE_NAME}.data.skills").joinpath(skill_name)

    return read_skill_version(path_skill_dir=path_skill_dir)


def check_for_skill_updates():
    """
    Check if there are any updates available for the skills installed in the agent by
    comparing the versions of the skills in the resources with the versions of the skills
    installed in the agent. If there are any updates available, log a message to inform the user.
    """

    skills_available = get_list_of_skills_available()
    missing_skills = []
    outdated_skills = []

    for skill in skills_available:

        try:
            version_in_resources = get_skill_version_from_resources(skill)

            path_skill_in_agent = os.path.join(constants.PATH_AGENT_SKILLS, skill)

            if not os.path.isdir(path_skill_in_agent):
                LOG.debug(f"Skill '{skill}' is not currently installed in the agent, an update is available")
                missing_skills.append(skill)
                continue

            version_in_agent = read_skill_version(path_skill_dir=path_skill_in_agent)

            if version_in_resources > version_in_agent:
                LOG.debug(f"Skill '{skill}' has a newer version in resources ({version_in_resources}) than "
                          f"in the agent ({version_in_agent}), an update is available")
                outdated_skills.append(skill)
                continue

        except SurcomSDKException as e:
            LOG.debug(f"Could not check for updates for skill '{skill}'. The error was: {e}")

    msg = "Your Agent Skills are not up to date"

    if missing_skills:

        sdk_helpers.print_log_msg(
            f"{msg}. The following skills are not currently installed: {', '.join(missing_skills)}",
            log_level=logging.WARNING
        )

    if outdated_skills:
        sdk_helpers.print_log_msg(
            f"{msg}. The following skills have newer versions available: {', '.join(outdated_skills)}",
            log_level=logging.WARNING
        )

    if missing_skills or outdated_skills:
        sdk_helpers.print_log_msg(
            f"Run 'surcom config {constants.CMD_INSTALL_SKILLS}' to install or update your skills",
            log_level=logging.WARNING,
            log_format=formats.ITALIC
        )

    else:
        LOG.debug("All skills installed and no updates found")
