import os
import logging
import shutil

from r7_surcom_sdk.lib import SurcomSDKException, constants, sdk_helpers, sdk_config
from r7_surcom_sdk.lib.surcom_api import SurcomAPI
from r7_surcom_sdk.lib.sdk_argparse import Args
from r7_surcom_sdk.lib.sdk_cmd import SurcomSDKSubCommand
from r7_surcom_sdk.lib.sdk_terminal_fonts import colors, formats
from r7_surcom_sdk.lib.download_index import build_index

LOG = logging.getLogger(constants.LOGGER_NAME)


class DownloadCommand(SurcomSDKSubCommand):
    """
    [help]
    Download the {PRODUCT_NAME} Data Model.
    ---

    [description]
    Downloads the Data Model used by our Agent Skills

The model is downloaded to `~/.r7-surcom-sdk/sc-data-model`. This can be customized by setting
the SURCOM_SDK_PATH_ROOT environment variable.

If a model already exists, it will be overwritten. You can use the '--clean' flag to remove the existing model
before downloading.
    ---

    [usage]
    $ {PROGRAM_NAME} {COMMAND} {SUB_CMD} --all
    $ {PROGRAM_NAME} {COMMAND} {SUB_CMD} --source-types --clean
    $ {PROGRAM_NAME} {COMMAND} {SUB_CMD} --all --paths-extra-repos /path/to/repo1 /path/to/repo2
    ---
    """
    def __init__(self, types_parser):

        self.cmd_name = constants.CMD_MODEL
        self.sub_cmd_name = constants.CMD_DOWNLOAD

        cmd_docstr = self.__doc__.format(
            PROGRAM_NAME=constants.PROGRAM_NAME,
            PRODUCT_NAME=constants.PRODUCT_NAME,
            COMMAND=self.cmd_name,
            SUB_CMD=self.sub_cmd_name
        )

        super().__init__(
            parent=types_parser,
            cmd_name=self.sub_cmd_name,
            cmd_docstr=cmd_docstr
        )

        self.cmd_parser.add_argument(
            "--all",
            help="Download all types (core and unified).",
            action="store_true"
        )

        self.cmd_parser.add_argument(
            "--unified-types",
            help="If provided, download the Core and Unified types that are provided by Surface Command.",
            action="store_true"
        )

        self.cmd_parser.add_argument(
            "--source-types",
            help="If provided, download the Source types that are provided by any installed Connectors.",
            action="store_true"
        )

        self.cmd_parser.add_argument(
            "--clean",
            help="If provided, remove the existing Data Model before downloading.",
            action="store_true"
        )

        self.cmd_parser.add_argument(
            "--paths-extra-repo",
            help=(
                "Extra paths to look for Surface Command types when building the Data Model index. "
                "The directory must contain a .git folder to be recognized as a repository, "
                "and the types will be scanned recursively starting from the root of the repository."
            ),
            type=str,
            nargs="*",
            default=None
        )

        self.cmd_parser.add_argument(*Args.yes.flag, **Args.yes.kwargs)

    def _write_types(
        self,
        path_data_model: str,
        type_kind: str,
        types_dict: dict,
    ):
        path_types_folder = os.path.join(path_data_model, type_kind)

        for t_name, t_content in types_dict.items():

            path_type = os.path.join(path_types_folder, f"{t_name}.yaml")
            sdk_helpers.write_file(path_type, t_content, as_yaml=True)

        sdk_helpers.print_log_msg(
            f"Wrote {len(types_dict)} '{type_kind}' to '{path_types_folder}'.",
            log_level=logging.INFO
        )

    def run(self, args):
        SurcomSDKException.command_ran = f"{self.cmd_name} {self.sub_cmd_name}"

        sdk_helpers.print_log_msg(
            f"Starting the '{self.cmd_name} {self.sub_cmd_name}' command",
            divider=True
        )

        if not (args.all or args.source_types or args.unified_types):
            raise SurcomSDKException(
                "You must specify at least one of '--all', '--unified-types' or '--source-types' "
                "to download the Data Model."
            )

        # If the user provided the --clean flag, if there is a model in the .github folder, in
        # this or a parent directory (up to 4 levels) we delete it
        if args.clean:
            path_gh_folder = sdk_helpers.find_folder(os.getcwd(), ".github")

            path_old_model = os.path.join(path_gh_folder, constants.DIR_NAME_SC_DATA_MODEL)
            if os.path.exists(path_old_model):
                sdk_helpers.print_log_msg(
                    f"The '--clean' flag was provided. Removing the old Data Model found at '{path_old_model}'...",
                    log_color=colors.WARNING,
                    log_format=formats.ITALIC
                )
                shutil.rmtree(path_old_model)

        # NOTE: path to the model is always: ~/.r7-surcom-sdk/sc-data-model
        path_sc_data_model = os.path.join(constants.PATH_SURCOM_ROOT, constants.DIR_NAME_SC_DATA_MODEL)
        path_connectors_ws = sdk_config.get_config(constants.CONFIG_NAME_PATH_CONNECTOR_WS)

        connection = sdk_config.get_default_connection(prompt=True, default_to_yes=args.yes)

        surcom_client = SurcomAPI(
            base_url=connection.url,
            api_key=connection.api_key,
            user_agent_str=f"'{self.cmd_name} {self.sub_cmd_name}' command"
        )

        # Check if the model already exists, if so, we remove it and write a new one
        if os.path.exists(path_sc_data_model):
            sdk_helpers.print_log_msg(
                f"An existing Data Model was already found at '{path_sc_data_model}'",
                log_color=colors.WARNING
            )

            if args.clean:
                sdk_helpers.print_log_msg(
                    f"The '--clean' flag was provided. Removing the existing Data Model at '{path_sc_data_model}'...",
                    log_color=colors.WARNING,
                    log_format=formats.ITALIC
                )
                shutil.rmtree(path_sc_data_model)

        if args.all or args.unified_types:

            # Get the Core, Unified and Enum types
            sdk_helpers.print_log_msg("Downloading Unified Types...", log_level=logging.INFO)
            core_types, noetic_builtin_types, enum_types = surcom_client.types_get_core_and_unified_types()

            # Get the Correlation Keys
            sdk_helpers.print_log_msg("Downloading Correlation Keys...", log_level=logging.INFO)
            correlation_keys = surcom_client.get_correlation_keys()

            # Get the Enum Values
            sdk_helpers.print_log_msg("Downloading Enum Values...", log_level=logging.INFO)
            enum_values: dict = surcom_client.get_enum_values()

            sdk_helpers.print_log_msg("Writing Unified types...", log_level=logging.INFO)

            # Write the Core types
            self._write_types(
                path_data_model=path_sc_data_model,
                type_kind="core-types",
                types_dict=core_types
            )

            # Write the Unified types
            self._write_types(
                path_data_model=path_sc_data_model,
                type_kind="unified-types",
                types_dict=noetic_builtin_types
            )

            # Write the Enum types
            self._write_types(
                path_data_model=path_sc_data_model,
                type_kind="enum-types",
                types_dict=enum_types
            )

            # Write the Correlation Keys
            path_correlation_keys = os.path.join(path_sc_data_model, "data", "sys.correlation-key.json")

            sdk_helpers.print_log_msg("Writing Correlation Keys...", log_level=logging.INFO)

            sdk_helpers.write_file(
                path_correlation_keys,
                correlation_keys,
                as_json=True
            )

            sdk_helpers.print_log_msg("Writing Enum Values...", log_level=logging.DEBUG)

            # Write the Enum Values
            for enum_type, enum_value_list in enum_values.items():
                path_enum_values = os.path.join(path_sc_data_model, "data", f"{enum_type}.json")

                sdk_helpers.print_log_msg(f"Writing Enum Values for type '{enum_type}'...", log_level=logging.DEBUG)

                sdk_helpers.write_file(
                    path_enum_values,
                    enum_value_list,
                    as_json=True
                )

        if args.all or args.source_types:

            sdk_helpers.print_log_msg("Downloading Source types...", log_level=logging.INFO)

            source_types = surcom_client.types_get_source_types()

            sdk_helpers.print_log_msg("Writing Source types...", log_level=logging.INFO)

            # Write the Source types
            self._write_types(
                path_data_model=path_sc_data_model,
                type_kind="source-types",
                types_dict=source_types
            )

        # Build the DuckDB index for the downloaded data model
        # This also automatically scans any 'types' folders in the repository
        sdk_helpers.print_log_msg("Building Data Model index...", log_level=logging.INFO)
        build_index(
            path_sc_data_model=path_sc_data_model,
            path_connectors_ws=path_connectors_ws,
            paths_extra_repo=args.paths_extra_repo
        )

        sdk_helpers.print_log_msg(
            f"The {constants.PRODUCT_NAME} Data Model is now available in '{path_sc_data_model}'.",
            log_level=logging.INFO,
            log_color=colors.OKGREEN
        )

        sdk_helpers.print_log_msg(f"Finished running the '{self.cmd_name} {self.sub_cmd_name}' command.", divider=True)
