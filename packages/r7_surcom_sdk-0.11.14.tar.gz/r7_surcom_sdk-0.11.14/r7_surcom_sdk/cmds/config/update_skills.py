import logging
import os
import shutil

from r7_surcom_sdk.lib import (SurcomSDKException, constants, sdk_helpers, agent_skills_helpers)
from r7_surcom_sdk.lib.sdk_argparse import Args
from r7_surcom_sdk.lib.sdk_cmd import SurcomSDKSubCommand
from r7_surcom_sdk.lib.sdk_terminal_fonts import colors, formats

LOG = logging.getLogger(constants.LOGGER_NAME)

# NOTE: this command has been renamed to install-skills


class UpdateSkillsCommand(SurcomSDKSubCommand):
    """
    [help]
    Install the Agent Skills included with the {FULL_PROGRAM_NAME}.
    ---

    [description]
    This command copies the latest skills included with the {FULL_PROGRAM_NAME} to '~/.agents/skills'.

If you already have some of the skills installed, it checks their version.

If any of the installed skills have an older version, you will be prompted to update them to the
latest version that is included in the {FULL_PROGRAM_NAME}.
    ---

    [usage]
    $ {PROGRAM_NAME} {COMMAND} {SUB_CMD}
    $ {PROGRAM_NAME} {COMMAND} {SUB_CMD} -y
    ---
    """
    def __init__(self, connectors_parser):

        self.cmd_name = constants.CMD_CONFIG
        self.sub_cmd_name = constants.CMD_INSTALL_SKILLS

        cmd_docstr = self.__doc__.format(
            PROGRAM_NAME=constants.PROGRAM_NAME,
            FULL_PROGRAM_NAME=constants.FULL_PROGRAM_NAME,
            PRODUCT_NAME=constants.PRODUCT_NAME,
            COMMAND=self.cmd_name,
            SUB_CMD=self.sub_cmd_name
        )

        super().__init__(
            parent=connectors_parser,
            cmd_name=self.sub_cmd_name,
            cmd_docstr=cmd_docstr)

        self.cmd_parser.add_argument(*Args.yes.flag, **Args.yes.kwargs)

    def run(self, args, cmd_download_model):
        SurcomSDKException.command_ran = f"{self.cmd_name} {self.sub_cmd_name}"

        sdk_helpers.print_log_msg(f"Starting the '{self.cmd_name} {self.sub_cmd_name}' command", divider=True)

        available_skills = agent_skills_helpers.get_list_of_skills_available()

        for skill_name in available_skills:

            path_existing_skill = os.path.join(constants.PATH_AGENT_SKILLS, skill_name)

            if not os.path.isdir(path_existing_skill):

                agent_skills_helpers.copy_skill_from_resources(
                    skill_name=skill_name,
                    path_dest=constants.PATH_AGENT_SKILLS
                )

                sdk_helpers.print_log_msg(
                    f"Copied '{skill_name}' to '{path_existing_skill}'",
                    log_color=colors.OKBLUE
                )

            else:
                try:
                    version_existing_skill = agent_skills_helpers.read_skill_version(path_skill_dir=path_existing_skill)
                except SurcomSDKException as e:

                    raise SurcomSDKException(
                        f"Could not read the version of the existing '{skill_name}' skill at '{path_existing_skill}'",
                        solution=f"Delete the directory at '{path_existing_skill}' and try again."
                    ) from e

                version_available_skill = agent_skills_helpers.get_skill_version_from_resources(skill_name=skill_name)

                if version_available_skill == version_existing_skill:
                    sdk_helpers.print_log_msg(
                        f"You have the latest version of the '{skill_name}' skill installed "
                        f"(version {version_existing_skill})",
                        log_color=colors.OKGREEN
                    )

                else:
                    # NOTE: if the existing skill version is different than the available skill version,
                    # we prompt the user to update it. The latest version should always come from the SDK
                    sdk_helpers.print_log_msg(
                        f"A newer version of the '{skill_name}' skill is available (version {version_available_skill}) "
                        f"than the one you currently have installed (version {version_existing_skill})",
                        log_level=logging.WARNING
                    )

                    update_skill = sdk_helpers.prompt_to_confirm(
                        f"Do you want to update the '{skill_name}' skill to the latest version?",
                        raise_exception=False,
                        default_to_yes=args.yes
                    )

                    if update_skill:
                        try:
                            # NOTE: this is safe to do here as we have to read a valid skill file
                            # to get the version, so we know its a valid skill directory
                            shutil.rmtree(path_existing_skill)

                            agent_skills_helpers.copy_skill_from_resources(
                                skill_name=skill_name,
                                path_dest=constants.PATH_AGENT_SKILLS
                            )

                            sdk_helpers.print_log_msg(
                                f"'{skill_name}' skill was updated to version {version_available_skill}"
                            )
                        except SurcomSDKException as e:
                            raise SurcomSDKException(
                                f"Failed to update the '{skill_name}' skill",
                                solution="Try updating the skill manually by deleting the existing skill directory and "
                                "copying over the new one from the package's data/skills directory"
                            ) from e

        sdk_helpers.print_log_msg("Agent Skills up to date!", log_color=colors.OKGREEN, log_format=formats.BOLD)

        download_model = sdk_helpers.prompt_to_confirm(
            "Would you like to also download the latest Data Model?",
            raise_exception=False,
            default_to_yes=args.yes,
            add_continue_to_prompt=False
        )

        if download_model:
            args.paths_extra_repo = []
            args.all = True
            args.clean = True
            cmd_download_model.run(args)

        sdk_helpers.print_log_msg(f"Finished running the '{self.sub_cmd_name}' command.", divider=True)
