import logging

from r7_surcom_sdk.lib import SurcomSDKException, constants, sdk_helpers
from r7_surcom_sdk.lib.mockserver_api import MockServerAPI
from r7_surcom_sdk.lib.sdk_cmd import SurcomSDKSubCommand
from r7_surcom_sdk.lib.sdk_argparse import Args
from r7_surcom_sdk.lib.sdk_terminal_fonts import colors, formats

LOG = logging.getLogger(constants.LOGGER_NAME)


class LoadTutorialCommand(SurcomSDKSubCommand):
    """
    [help]
    Load the expectations needed for the tutorial.
    ---

    [description]
    Starts the MockServer and loads the expectations needed to follow
our 'Build an Example Connector' guide using the Demo Connector.

The guide can be found here: https://docs.rapid7.com/surface-command/build-custom-connectors/#build-an-example-connector

    ---

    [usage]
    $ {PROGRAM_NAME} {COMMAND} {SUB_CMD} [-f]
    ---
    """
    def __init__(self, connectors_parser):

        self.cmd_name = constants.CMD_MOCKSERVER
        self.sub_cmd_name = constants.CMD_LOAD_TUTORIAL

        cmd_docstr = self.__doc__.format(
            PROGRAM_NAME=constants.PROGRAM_NAME,
            COMMAND=self.cmd_name,
            SUB_CMD=self.sub_cmd_name,
            CONFIG_FILE_NAME=constants.CONFIG_FILE_NAME
        )

        super().__init__(
            parent=connectors_parser,
            cmd_name=self.sub_cmd_name,
            cmd_docstr=cmd_docstr)

        self.cmd_parser.add_argument(*Args.follow.flag, **Args.follow.kwargs)

    def run(self, args, cmd_logs):
        SurcomSDKException.command_ran = f"{self.cmd_name} {self.sub_cmd_name}"

        sdk_helpers.print_log_msg(
            f"Starting the '{self.cmd_name} {self.sub_cmd_name}' command.",
            divider=True
        )

        mockserver = MockServerAPI()

        mockserver.start(
            verbose=args.verbose,
            restart=True,
        )

        sdk_helpers.print_log_msg(
            "Loading tutorial expectations into the MockServer...",
            log_color=colors.OKBLUE,
            log_format=formats.ITALIC
        )

        mockserver.wait_until(state=mockserver.STATE_RUNNING)

        tutorial = f"{constants.PACKAGE_NAME}.data.cmds.mockserver.tutorial"

        expectations = [
            sdk_helpers.get_path_to_resource(package_name=tutorial, resource_name="get_permissions.yaml"),
            sdk_helpers.get_path_to_resource(package_name=tutorial, resource_name="get_users.yaml"),
            sdk_helpers.get_path_to_resource(package_name=tutorial, resource_name="get_devices.yaml"),
        ]

        mockserver.load_expectations(expectations)

        sdk_helpers.print_log_msg(
            "Tutorial expectations loaded into the MockServer.",
            log_color=colors.OKGREEN
        )

        if args.follow:
            cmd_logs.run(args)
