import logging
import subprocess  # nosec: B404

from r7_surcom_sdk.lib import SurcomSDKException, constants, sdk_helpers
from r7_surcom_sdk.lib.sdk_cmd import SurcomSDKSubCommand
from r7_surcom_sdk.lib.sdk_terminal_fonts import colors

LOG = logging.getLogger(constants.LOGGER_NAME)


class LogsCommand(SurcomSDKSubCommand):
    """
    [help]
    View the MockServer logs.
    ---

    [description]
    Views the logs of the MockServer running in a Docker container.

This is useful for debugging your MockServer
expectations and troubleshooting any issues with the MockServer.
    ---

    [usage]
    $ {PROGRAM_NAME} {COMMAND} {SUB_CMD}
    ---
    """
    def __init__(self, connectors_parser):

        self.cmd_name = constants.CMD_MOCKSERVER
        self.sub_cmd_name = constants.CMD_LOGS

        cmd_docstr = self.__doc__.format(
            PROGRAM_NAME=constants.PROGRAM_NAME,
            COMMAND=self.cmd_name,
            SUB_CMD=self.sub_cmd_name,
            CONFIG_FILE_NAME=constants.CONFIG_FILE_NAME
        )

        super().__init__(
            parent=connectors_parser,
            cmd_name=self.sub_cmd_name,
            cmd_docstr=cmd_docstr)

    def run(self, args):
        SurcomSDKException.command_ran = f"{self.cmd_name} {self.sub_cmd_name}"

        cli_args = [
            "docker", "logs", "-f", constants.MOCKSERVER_CONTAINER_NAME
        ]

        try:

            sdk_helpers.run_subprocess(cli_args, stdout=None, stderr=subprocess.PIPE)

        except SurcomSDKException as e:

            if "No such container" in str(e):
                sdk_helpers.print_log_msg(
                    "The MockServer is not currently running. Run `surcom mockserver start` "
                    "before trying to view logs.",
                    log_color=colors.WARNING,
                )

            else:
                raise e

        except KeyboardInterrupt:

            sdk_helpers.print_log_msg(
                "Stopped viewing MockServer logs.",
                log_color=colors.WARNING,
                divider=True
            )
