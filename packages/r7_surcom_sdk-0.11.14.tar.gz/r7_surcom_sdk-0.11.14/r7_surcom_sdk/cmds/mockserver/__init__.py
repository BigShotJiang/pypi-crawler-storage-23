
from r7_surcom_sdk.cmds.mockserver.start import StartCommand
from r7_surcom_sdk.cmds.mockserver.stop import StopCommand
from r7_surcom_sdk.cmds.mockserver.logs import LogsCommand
from r7_surcom_sdk.cmds.mockserver.load_tutorial import LoadTutorialCommand
from r7_surcom_sdk.lib import constants
from r7_surcom_sdk.lib.sdk_cmd import SurcomSDKMainCommand


class MockServerCmd(SurcomSDKMainCommand):

    """
    [help]
    Interface with the MockServer to help develop + test connectors.
    ---

    [description]
    The MockServer provides a mocked REST API for your connector, running in a Docker container.
You can use this to develop and test your connectors without needing access to the actual API. Use
the subcommands to start and stop the MockServer, view its logs, and load a tutorial set of expectations.

The default url of the running MockServer locally is http://host.docker.internal:1080
    ---

    [usage]
    $ {PROGRAM_NAME} {COMMAND} start [-p PORT] [-r] [-f]
    $ {PROGRAM_NAME} {COMMAND} stop
    $ {PROGRAM_NAME} {COMMAND} logs
    $ {PROGRAM_NAME} {COMMAND} load-tutorial
    ---
    """
    def __init__(self, parent_parser):

        cmd_docstr = self.__doc__.format(
            PRODUCT_NAME=constants.PRODUCT_NAME,
            PROGRAM_NAME=constants.PROGRAM_NAME,
            CONFIG_FILE_NAME=constants.CONFIG_FILE_NAME,
            COMMAND=constants.CMD_MOCKSERVER
        )

        super().__init__(
            parent=parent_parser,
            cmd_name=constants.CMD_MOCKSERVER,
            cmd_docstr=cmd_docstr
        )

        # Add sub commands
        self.cmd_start = StartCommand(self.cmd_parser)
        self.cmd_stop = StopCommand(self.cmd_parser)
        self.cmd_logs = LogsCommand(self.cmd_parser)
        self.cmd_load_tutorial = LoadTutorialCommand(self.cmd_parser)

    def run(self, args):

        if args.mockserver == constants.CMD_START:
            self.cmd_start.run(args, cmd_logs=self.cmd_logs)

        elif args.mockserver == constants.CMD_STOP:
            self.cmd_stop.run(args)

        elif args.mockserver == constants.CMD_LOGS:
            self.cmd_logs.run(args)

        elif args.mockserver == constants.CMD_LOAD_TUTORIAL:
            self.cmd_load_tutorial.run(args, cmd_logs=self.cmd_logs)

        else:
            self.main_parser.print_help()
