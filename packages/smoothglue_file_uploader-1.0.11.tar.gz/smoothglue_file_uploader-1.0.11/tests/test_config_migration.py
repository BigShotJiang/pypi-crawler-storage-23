import io
from unittest.mock import MagicMock, patch

from django.test import TestCase, override_settings
from django.core.files.uploadedfile import SimpleUploadedFile

from smoothglue.file_uploader.models import Document, DocumentStoreConfiguration
from smoothglue.file_uploader.storage_providers.base import get_storage_provider
from smoothglue.file_uploader.storage_providers.local import LocalFileSystemProvider
from tests.utils import get_test_document_and_file


class TestConfigMigration(TestCase):
    def setUp(self):
        self.config_label = "migration_test"
        self.initial_config = {
            "PROVIDER_CLASS": "smoothglue.file_uploader.storage_providers.local.LocalFileSystemProvider",
            "PROVIDER_CONFIG": {"UPLOAD_PATH": "/tmp/initial"},
            "STORE_CONFIG": True,
        }
        self.new_config = {
            "PROVIDER_CLASS": "smoothglue.file_uploader.storage_providers.local.LocalFileSystemProvider",
            "PROVIDER_CONFIG": {"UPLOAD_PATH": "/tmp/new"},
            "STORE_CONFIG": True,
        }

    def test_config_update_prevent_duplicates(self):
        """Test that updating config updates the existing record instead of creating a new one."""
        # Initialize with initial config
        with override_settings(
            UPLOAD_STORAGE_PROVIDER_CONFIG={self.config_label: self.initial_config}
        ):
            _, model1 = get_storage_provider(self.config_label)
            self.assertIsNotNone(model1)
            self.assertEqual(model1.config, self.initial_config)
            self.assertEqual(DocumentStoreConfiguration.objects.count(), 1)
            initial_id = model1.id

        # Initialize with NEW config
        with override_settings(UPLOAD_STORAGE_PROVIDER_CONFIG={self.config_label: self.new_config}):
            _, model2 = get_storage_provider(self.config_label)
            self.assertIsNotNone(model2)

            # Verify we still only have 1 config record
            self.assertEqual(DocumentStoreConfiguration.objects.count(), 1)

            # Verify the record was updated
            updated_model = DocumentStoreConfiguration.objects.first()
            self.assertEqual(updated_model.id, initial_id)
            self.assertEqual(updated_model.config, self.new_config)

    def test_document_migration(self):
        """Test that documents are moved from old provider to new provider on config update."""

        # Setup initial state
        with override_settings(
            UPLOAD_STORAGE_PROVIDER_CONFIG={self.config_label: self.initial_config}
        ):
            _, model1 = get_storage_provider(self.config_label)

            # Create a document associated with this config
            doc, _ = get_test_document_and_file()
            doc.store_config = model1
            doc.save()

        with patch(
            "smoothglue.file_uploader.models.DocumentStoreConfiguration.get_storage_provider"
        ) as mock_get_old_provider:

            # Setup the old provider mock instance
            mock_old_provider_instance = MagicMock()
            mock_old_provider_instance.download_document.return_value = io.BytesIO(b"old content")
            mock_get_old_provider.return_value = mock_old_provider_instance

            with patch(
                "smoothglue.file_uploader.storage_providers.local.LocalFileSystemProvider.upload_document"
            ) as mock_upload:
                mock_upload.return_value = True

                with override_settings(
                    UPLOAD_STORAGE_PROVIDER_CONFIG={self.config_label: self.new_config}
                ):
                    # This call triggers the migration logic
                    _, _ = get_storage_provider(self.config_label)

                mock_old_provider_instance.download_document.assert_called()
                args, _ = mock_old_provider_instance.download_document.call_args
                self.assertEqual(args[0], doc.path)

                # Check if upload was called.
                self.assertTrue(mock_upload.called)
                args, _ = mock_upload.call_args

                self.assertEqual(mock_upload.call_count, 1)

                # Verify old provider remove was called
                mock_old_provider_instance.remove_document.assert_called()

                # Verify config updated in DB
                updated_model = DocumentStoreConfiguration.objects.get(id=model1.id)
                self.assertEqual(updated_model.config, self.new_config)
