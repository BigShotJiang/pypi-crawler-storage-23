import importlib
import io
from abc import ABC
from typing import Optional, IO

from django.core.exceptions import ImproperlyConfigured
from django.core.files.uploadedfile import InMemoryUploadedFile, SimpleUploadedFile
from django.db import transaction

import logging


from smoothglue.file_uploader.config import (
    FileUploaderSettings,
    StorageProviderConfig,
    ProviderConfig,
)
from smoothglue.file_uploader.models import DocumentStoreConfiguration
from smoothglue.file_uploader.utils import dict_matches_type

logger = logging.getLogger(__name__)


def migrate_documents(
    storage_model: DocumentStoreConfiguration, target_settings_config: StorageProviderConfig
) -> bool:
    """
    Migrates documents from an old storage provider to a new one.
    The documents are downloaded, migrated, have their storage configuration updated and then removed from the old provider.
    """

    old_provider = storage_model.get_storage_provider()
    module_name, class_name = target_settings_config["PROVIDER_CLASS"].rsplit(".", 1)
    new_provider_cls = getattr(importlib.import_module(module_name), class_name)
    new_provider = new_provider_cls(target_settings_config["PROVIDER_CONFIG"])

    successfully_migrated_paths = []
    for doc in storage_model.document_set.all():
        file_stream = old_provider.download_document(doc.path)

        if file_stream:
            new_file = SimpleUploadedFile(doc.name, file_stream.read())

            try:
                if new_provider.upload_document(doc.path, new_file):
                    successfully_migrated_paths.append(doc.path)
            except Exception as e:
                logger.error(f"Upload failed for {doc.name}: {e}")
        else:
            logger.error(f"Failed to download {doc.name} from old provider during migration")

    with transaction.atomic():
        storage_model.config = target_settings_config
        storage_model.save()

    for path in successfully_migrated_paths:
        old_provider.remove_document(path)


class StorageProvider(ABC):
    """Abstract class for defining a storage provider for uploaded files"""

    config_type = ProviderConfig

    def __init__(self, config: dict):
        self.config = self.validated_config(config)

    @classmethod
    def validated_config(cls, config: dict) -> dict:
        """
        Validates that a config dictionary is appropriate for the storage provider
        Args:
            config (dict): the config to validate

        Returns:
            dict: the validated config
        """
        if dict_matches_type(config, cls.config_type):
            return config
        raise ImproperlyConfigured(f"Configuration for {cls.__name__} is invalid")

    def upload_document(self, path: str, data: InMemoryUploadedFile):
        """
        Uploads a file to the storage provider.

        Args:
            path(str): The path to upload the file to
            data(InMemoryUploadedFile): file content to upload

        Returns:
            bool: True if the file was uploaded, False otherwise.
        """
        raise NotImplementedError

    def download_document(self, object_name: str) -> Optional[IO]:
        """
        Downloads a file from the storage provider.

        Args:
            object_name(str): The path of the file to download.

        Returns:
            Optional[IO]: The downloaded file. None if unsuccessful
        """
        raise NotImplementedError

    def remove_document(self, source: str) -> bool:
        """
        Remove a file from storage provider.

        Args:
            source(str): The path of the file to remove.

        Returns:
            bool: True if the file was removed, False otherwise.
        """
        raise NotImplementedError

    def duplicate_document(self, original_path: str, new_path: str) -> bool:
        """
        Copy a file from storage provider.

        Args:
            original_path(str): The path of the file to copy.
            new_path(str): The new path for the file to be copied to.

        Returns:
            bool: True if the file was copied, False otherwise.
        """
        raise NotImplementedError


def get_storage_provider(
    config: str = None,
) -> tuple[StorageProvider, Optional[DocumentStoreConfiguration]]:
    """
    Builds a storage provider instance from the configured class and settings
    If the configuration has changed in settings, it migrates existing documents
    from the old provider to the new one before updating the database.

    Returns:
        StorageProvider: Configured storage provider
    """

    # If no config provided, use the environment-driven selection
    # If that isn't set, fall back to the string "default"
    if config is None:
        config = getattr(FileUploaderSettings, "SELECTED_STORAGE_PROVIDER", "default")

    if isinstance(config, str):
        storage_provider_config = FileUploaderSettings.UPLOAD_STORAGE_PROVIDER_CONFIG.get(config)
        if not storage_provider_config:
            raise ImproperlyConfigured(
                f"UPLOAD_STORAGE_PROVIDER_CONFIG has no configuration for {config}"
            )
    else:
        raise ValueError("config must be a string")

    try:
        dict_matches_type(storage_provider_config, StorageProviderConfig)
    except ValueError as e:
        raise ImproperlyConfigured("Storage provider is not properly configured") from e

    module_name, class_name = storage_provider_config["PROVIDER_CLASS"].rsplit(".", 1)
    storage_provider_cls = getattr(importlib.import_module(module_name), class_name)

    if not issubclass(storage_provider_cls, StorageProvider):
        raise ImproperlyConfigured("storage_provider is not a subclass of StorageProvider")

    target_settings_config = FileUploaderSettings.UPLOAD_STORAGE_PROVIDER_CONFIG.get(config)

    if target_settings_config.get("STORE_CONFIG", True):
        storage_model, created = DocumentStoreConfiguration.objects.get_or_create(
            config_label=config, defaults={"config": target_settings_config}
        )

        if not created and storage_model.config != target_settings_config:
            migrate_documents(storage_model, target_settings_config)

        return storage_model.get_storage_provider(), storage_model

    return storage_provider_cls(target_settings_config["PROVIDER_CONFIG"]), None
