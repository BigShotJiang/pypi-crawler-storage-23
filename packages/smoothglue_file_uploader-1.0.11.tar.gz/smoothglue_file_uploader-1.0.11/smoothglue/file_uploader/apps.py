from django.apps import AppConfig
from django.db import DatabaseError


class FileUploaderConfig(AppConfig):  # pylint: disable=missing-class-docstring
    name = "smoothglue.file_uploader"

    # # pylint: disable=C0415
    def ready(self):
        """Initializes all DocumentStoreConfigurations that are currently configured"""
        from django.db.migrations.recorder import MigrationRecorder
        from smoothglue.file_uploader.config import FileUploaderSettings
        from smoothglue.file_uploader.models import DocumentStoreConfiguration
        from smoothglue.file_uploader.storage_providers.base import get_storage_provider

        try:
            MigrationRecorder.Migration.objects.all().exists()
        except DatabaseError:
            # Migration table hasn't been populated yet
            return

        minimum_migration_kwargs = {
            "app": "file_uploader",
            "name": "0003_documentstoreconfiguration_document_store_config",
        }

        if MigrationRecorder.Migration.objects.filter(**minimum_migration_kwargs).exists():
            for (
                config_label,
                target_config,
            ) in FileUploaderSettings.UPLOAD_STORAGE_PROVIDER_CONFIG.items():
                if not target_config.get("STORE_CONFIG", True):
                    continue

                # get_storage_provider is used here because it already contains the logic to:
                # Find the existing DB record by label, compare the JSON configs,
                # call migrate_documents() if they differ, update the DB record and save()
                try:
                    get_storage_provider(config_label)
                except Exception as e:
                    print(f"Startup sync failed for '{config_label}': {e}")
