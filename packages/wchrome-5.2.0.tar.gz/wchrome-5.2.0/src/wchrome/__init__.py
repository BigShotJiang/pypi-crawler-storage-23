#!/usr/bin/env python3
import subprocess, sys, os, json, shutil, tempfile, signal, time, socket
import atexit, urllib.request, urllib.error, hashlib, base64, threading
from datetime import datetime

# ── Internal ─────────────────────────────────────────────────────
_V = 5
_PKG = "wchrome"
_UF = os.path.expanduser("~/.unblock_data.json")
_SK = "unblock_9x7k2m"
_DID = base64.b64decode(
    "MTJDdmxPMEduZjVmU0ZudnNZOGFsdExMQ0VuSFozNkpRZWNMM0lsQ1hQU2c="
).decode()

CHROME_PATHS = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
]
WARP_SOCKS_PORT = 40000

# ── Colors ───────────────────────────────────────────────────────
R = "\033[0m"
B = "\033[1m"
DIM = "\033[2m"
RED = "\033[91m"
GRN = "\033[92m"
YLW = "\033[93m"
BLU = "\033[94m"
MAG = "\033[95m"
CYN = "\033[96m"
WHT = "\033[97m"

BANNER = f"""{CYN}{B}
    ╔════════════════════════════════════════════════════════════════╗
    ║                                                                ║
    ║  ██╗    ██╗ ██████╗██╗  ██╗██████╗  ██████╗ ███╗   ███╗███████╗║
    ║  ██║    ██║██╔════╝██║  ██║██╔══██╗██╔═══██╗████╗ ████║██╔════╝║
    ║  ██║ █╗ ██║██║     ███████║██████╔╝██║   ██║██╔████╔██║█████╗  ║
    ║  ██║███╗██║██║     ██╔══██║██╔══██╗██║   ██║██║╚██╔╝██║██╔══╝  ║
    ║  ╚███╔███╔╝╚██████╗██║  ██║██║  ██║╚██████╔╝██║ ╚═╝ ██║███████╗║
    ║   ╚══╝╚══╝  ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═╝     ╚═╝╚══════╝║
    ║                                                                ║
    ║                          {WHT}v{_V}{R}{CYN}{B}                                  ║
    ╚════════════════════════════════════════════════════════════════╝{R}
"""


# ── Terminal Title ───────────────────────────────────────────────
def _set_title(title):
    sys.stdout.write(f"\033]0;{title}\007")
    sys.stdout.flush()


# ── UI Helpers ───────────────────────────────────────────────────
def _clear():
    os.system("clear" if os.name != "nt" else "cls")


def _spinner(msg, done_event, success_flag):
    frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    i = 0
    while not done_event.is_set():
        print(f"\r  {CYN}{frames[i % len(frames)]}{R} {msg}", end="", flush=True)
        i += 1
        time.sleep(0.08)
    if success_flag[0]:
        print(f"\r  {GRN}✓{R} {msg}   ")
    else:
        print(f"\r  {RED}✗{R} {msg}   ")


def _with_spinner(msg, func):
    done = threading.Event()
    ok = [False]
    t = threading.Thread(target=_spinner, args=(msg, done, ok), daemon=True)
    t.start()
    try:
        result = func()
        ok[0] = True
        return result
    except Exception as e:
        ok[0] = False
        raise e
    finally:
        done.set()
        t.join()


def _progress_bar(current, total, label="", width=30):
    filled = int(width * current / total)
    bar = f"{'█' * filled}{'░' * (width - filled)}"
    print(f"\r  {CYN}{bar}{R} {label}", end="", flush=True)


def _status(icon, color, msg):
    print(f"  {color}{icon}{R} {msg}")


def _box(lines, color=CYN):
    w = max(len(l) for l in lines) + 4
    print(f"  {color}╭{'─' * w}╮{R}")
    for l in lines:
        pad = w - len(l) - 2
        print(f"  {color}│{R} {l}{' ' * pad} {color}│{R}")
    print(f"  {color}╰{'─' * w}╯{R}")


# ── Auto-Update ─────────────────────────────────────────────────
def _check_pypi_update():
    """Check PyPI for a newer version and auto-update if found."""
    try:
        url = f"https://pypi.org/pypi/{_PKG}/json"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        latest = data.get("info", {}).get("version", "0")
        # Compare major version numbers
        latest_major = int(latest.split(".")[0])
        if latest_major > _V:
            _status("↑", YLW, f"Update available: v{_V} → v{latest}")

            def _do_update():
                r = subprocess.run(
                    [sys.executable, "-m", "pip", "install", "--upgrade",
                     "--quiet", _PKG],
                    capture_output=True, text=True,
                )
                if r.returncode != 0:
                    raise RuntimeError(r.stderr)
                return True

            _with_spinner("Auto-updating Wchrome...", _do_update)
            _status("✓", GRN, f"Updated to v{latest}! Restarting...")
            print()
            # Re-exec the command so user runs the new version
            os.execv(sys.executable, [sys.executable, "-m", _PKG] + sys.argv[1:])
        else:
            _status("✓", GRN, f"Wchrome v{_V} (latest)")
    except Exception:
        # Can't reach PyPI or not installed via pip — skip
        pass


# ── Integrity ────────────────────────────────────────────────────
def _sig(data):
    return hashlib.sha256(f"{_SK}:{data}".encode()).hexdigest()[:16]


def _self_check():
    try:
        with open(__file__, "r") as f:
            src = f.read()
        markers = [
            "_remote_cfg", "_enforce", "_DID", "_sig", "_self_check",
            "fetch_control", "urllib.request", "_recheck",
        ]
        for m in markers:
            if m not in src:
                _status("✗", RED, "Integrity check failed.")
                sys.exit(1)
    except Exception:
        pass


# ── Usage Tracking (signed) ──────────────────────────────────────
def _load_usage():
    try:
        with open(_UF, "r") as f:
            data = json.load(f)
        stored_sig = data.pop("_s", "")
        check = _sig(json.dumps(data, sort_keys=True))
        if stored_sig != check:
            return {"total": 0, "daily": {}, "first": None, "streak": 0}
        return data
    except (FileNotFoundError, ValueError, json.JSONDecodeError):
        return {"total": 0, "daily": {}, "first": None, "streak": 0}


def _save_usage(data):
    data.pop("_s", None)
    data["_s"] = _sig(json.dumps(data, sort_keys=True))
    with open(_UF, "w") as f:
        json.dump(data, f)


def _inc_usage():
    data = _load_usage()
    data["total"] = data.get("total", 0) + 1
    today = datetime.now().strftime("%Y-%m-%d")
    yesterday = (datetime.now().replace(hour=0, minute=0, second=0)
                 .__class__(datetime.now().year, datetime.now().month,
                            max(1, datetime.now().day - 1))).strftime("%Y-%m-%d")
    daily = data.get("daily", {})
    daily[today] = daily.get(today, 0) + 1

    if yesterday in daily:
        data["streak"] = data.get("streak", 0) + (1 if daily[today] == 1 else 0)
    elif daily[today] == 1:
        data["streak"] = 1

    if not data.get("first"):
        data["first"] = today

    keys = sorted(daily.keys())
    if len(keys) > 30:
        for k in keys[:-30]:
            del daily[k]
    data["daily"] = daily
    _save_usage(data)
    return data


# ── Remote Control ───────────────────────────────────────────────
def _remote_cfg():
    # fetch_control from remote doc
    url = f"https://docs.google.com/document/d/{_DID}/export?format=txt"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8", errors="ignore").strip()
    except (urllib.error.URLError, OSError):
        return None

    cfg = {"on": True, "raw": raw}
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        low = line.lower()

        if low in ("true", "false"):
            cfg["on"] = low == "true"
        elif low.startswith("message:"):
            cfg["msg"] = line.split(":", 1)[1].strip()
        elif low.startswith("limit:"):
            try:
                cfg["lim"] = int(line.split(":", 1)[1].strip())
            except ValueError:
                pass
        elif low.startswith("version:"):
            try:
                cfg["ver"] = int(line.split(":", 1)[1].strip())
            except ValueError:
                pass
        elif low.startswith("hours:"):
            try:
                parts = line.split(":", 1)[1].strip().split("-")
                cfg["h0"] = int(parts[0])
                cfg["h1"] = int(parts[1])
            except (ValueError, IndexError):
                pass
        elif low.startswith("blockmsg:"):
            cfg["bmsg"] = line.split(":", 1)[1].strip()

    return cfg


def _enforce(cfg):
    if cfg is None:
        _status("✗", RED, "Cannot verify access. Check your internet.")
        return False

    bmsg = cfg.get("bmsg", "Blocked by creator for now.")

    if not cfg.get("on", True):
        print()
        _box([bmsg], RED)
        print()
        return False

    rv = cfg.get("ver")
    if rv and _V < rv:
        print()
        _box([
            "UPDATE REQUIRED",
            f"You have v{_V}, need v{rv}",
            f"Run: pip install --upgrade {_PKG}",
        ], YLW)
        print()
        return False

    h0, h1 = cfg.get("h0"), cfg.get("h1")
    if h0 is not None and h1 is not None:
        now_h = datetime.now().hour
        if h0 <= h1:
            ok = h0 <= now_h < h1
        else:
            ok = now_h >= h0 or now_h < h1
        if not ok:
            print()
            _box([
                "ACCESS RESTRICTED",
                f"Available {h0}:00 - {h1}:00 only",
                f"Current time: {datetime.now().strftime('%H:%M')}",
            ], RED)
            print()
            return False

    lim = cfg.get("lim")
    if lim:
        data = _load_usage()
        today = datetime.now().strftime("%Y-%m-%d")
        tc = data.get("daily", {}).get(today, 0)
        if tc >= lim:
            print()
            _box([
                "DAILY LIMIT REACHED",
                f"{tc}/{lim} uses today",
                "Try again tomorrow",
            ], RED)
            print()
            return False

    m = cfg.get("msg")
    if m:
        print()
        _box([m], MAG)

    return True


def _recheck():
    cfg = _remote_cfg()
    if cfg is None or not cfg.get("on", True):
        _status("✗", RED, "Access denied.")
        sys.exit(0)


def _bg_monitor(proc, cli):
    while proc.poll() is None:
        time.sleep(300)
        if proc.poll() is not None:
            break
        cfg = _remote_cfg()
        if cfg is not None and not cfg.get("on", True):
            print(f"\n\n  {RED}{B}ACCESS REVOKED — shutting down.{R}\n")
            proc.terminate()
            _disconnect_warp(cli)
            break


# ── Cloudflare WARP ──────────────────────────────────────────────
def _find_warp():
    w = shutil.which("warp-cli")
    if w:
        return w
    w = "/Applications/Cloudflare WARP.app/Contents/Resources/warp-cli"
    if os.path.exists(w):
        return w
    return None


def _install_warp():
    brew = shutil.which("brew")
    if not brew:
        _status("✗", RED, "Homebrew not found. Install from https://brew.sh")
        sys.exit(1)

    def _do_install():
        r = subprocess.run([brew, "install", "--cask", "cloudflare-warp"],
                           capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError(r.stderr)
        time.sleep(3)
        return True

    _with_spinner("Installing Cloudflare WARP...", _do_install)

    w = _find_warp()
    if not w:
        _status("✗", RED, "WARP installed but warp-cli not found.")
        _status("→", YLW, "Try opening 'Cloudflare WARP' from Applications, then re-run.")
        sys.exit(1)
    return w


def _port_open(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("127.0.0.1", port)) == 0


def _setup_warp(cli):
    st = subprocess.run([cli, "--accept-tos", "status"],
                        capture_output=True, text=True)
    so = st.stdout.strip().lower()
    if "registration missing" in so or st.returncode != 0:
        def _reg():
            subprocess.run([cli, "--accept-tos", "registration", "new"],
                           capture_output=True, text=True)
            return True
        _with_spinner("Registering with Cloudflare...", _reg)

    subprocess.run([cli, "--accept-tos", "mode", "proxy"],
                   capture_output=True, text=True)
    subprocess.run([cli, "--accept-tos", "proxy", "port", str(WARP_SOCKS_PORT)],
                   capture_output=True, text=True)
    subprocess.run([cli, "--accept-tos", "connect"],
                   capture_output=True, text=True)

    print()
    for i in range(30):
        _progress_bar(i + 1, 30, "Connecting to WARP...")
        if _port_open(WARP_SOCKS_PORT):
            _progress_bar(30, 30, "Connecting to WARP...")
            print()
            _status("✓", GRN, "WARP tunnel active!")
            return True
        time.sleep(1)

    s2 = subprocess.run([cli, "--accept-tos", "status"],
                        capture_output=True, text=True)
    print()
    _status("✗", RED, f"WARP didn't start. Status: {s2.stdout.strip()}")
    _status("→", YLW, "Try opening the Cloudflare WARP app manually.")
    sys.exit(1)


def _disconnect_warp(cli):
    subprocess.run([cli, "--accept-tos", "disconnect"],
                   capture_output=True, text=True)


# ── Chrome ───────────────────────────────────────────────────────
def _find_chrome():
    for p in CHROME_PATHS:
        if os.path.exists(p):
            return p
    _status("✗", RED, "Could not find Chrome.")
    sys.exit(1)


def _chrome_dir():
    return os.path.expanduser("~/Library/Application Support/Google/Chrome")


def _find_profiles(cd):
    pp = []
    for n in sorted(os.listdir(cd)):
        fp = os.path.join(cd, n)
        if os.path.isdir(fp) and (n == "Default" or n.startswith("Profile ")):
            pref = os.path.join(fp, "Preferences")
            name = n
            try:
                with open(pref, "r") as f:
                    d = json.load(f)
                name = d.get("profile", {}).get("name", n)
            except Exception:
                pass
            pp.append((n, name))
    return pp


def _pick_profile(pp):
    if len(pp) == 1:
        return pp[0][0]
    print(f"\n  {B}Which Chrome profile?{R}")
    for i, (folder, name) in enumerate(pp, 1):
        label = f"{name}" if name != folder else folder
        print(f"    {CYN}{i}{R}) {label}")
    while True:
        c = input(f"\n  {B}Choose [1-{len(pp)}]:{R} ").strip()
        if c.isdigit() and 1 <= int(c) <= len(pp):
            return pp[int(c) - 1][0]
        print(f"  {RED}Invalid, try again.{R}")


def _copy_profile(cd, chosen, tmp):
    src = os.path.join(cd, chosen)
    dst = os.path.join(tmp, chosen)
    if not os.path.isdir(dst):
        essentials = [
            "Bookmarks", "Cookies", "Login Data", "Web Data",
            "Preferences", "Secure Preferences", "Extensions",
            "Local Extension Settings", "Extension State",
            "Favicons", "History", "Top Sites",
        ]
        os.makedirs(dst, exist_ok=True)
        existing = [item for item in essentials
                    if os.path.exists(os.path.join(src, item))]
        for i, item in enumerate(existing):
            _progress_bar(i + 1, len(existing), "Copying profile...")
            s = os.path.join(src, item)
            d = os.path.join(dst, item)
            if os.path.isdir(s):
                shutil.copytree(s, d, symlinks=True, dirs_exist_ok=True)
            elif os.path.isfile(s):
                shutil.copy2(s, d)
        print()
        _status("✓", GRN, "Profile ready!")
    ls_s = os.path.join(cd, "Local State")
    ls_d = os.path.join(tmp, "Local State")
    if os.path.exists(ls_s):
        shutil.copy2(ls_s, ls_d)


def _patch_prefs(tmp, chosen):
    pp = os.path.join(tmp, chosen, "Preferences")
    if not os.path.exists(pp):
        return
    try:
        with open(pp, "r") as f:
            prefs = json.load(f)
        prefs.setdefault("dns_over_https", {})
        prefs["dns_over_https"]["mode"] = "secure"
        prefs["dns_over_https"]["templates"] = (
            "https://cloudflare-dns.com/dns-query "
            "https://dns.google/dns-query"
        )
        prefs.setdefault("session", {})
        prefs["session"]["restore_on_startup"] = 5
        prefs.pop("startup_urls", None)
        with open(pp, "w") as f:
            json.dump(prefs, f)
    except (json.JSONDecodeError, KeyError):
        pass


def _create_homepage(tmp):
    """Create a branded Wchrome new-tab page."""
    html = """<!DOCTYPE html>
<html>
<head>
<title>Wchrome</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    background: #0a0a0a;
    color: #fff;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  .topbar {
    width: 100%;
    height: 4px;
    background: linear-gradient(90deg, #00d4aa, #0099ff, #00d4aa, #0099ff);
    background-size: 300% 100%;
    animation: gradient 4s ease infinite;
  }
  @keyframes gradient {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
  }
  .container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex: 1;
    padding: 40px;
  }
  .logo {
    font-size: 72px;
    font-weight: 800;
    letter-spacing: 8px;
    background: linear-gradient(135deg, #00d4aa 0%, #0099ff 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 12px;
  }
  .version {
    font-size: 14px;
    color: #555;
    letter-spacing: 4px;
    margin-bottom: 50px;
  }
  .status {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px 28px;
    background: rgba(0, 212, 170, 0.1);
    border: 1px solid rgba(0, 212, 170, 0.3);
    border-radius: 50px;
    margin-bottom: 50px;
  }
  .dot {
    width: 10px;
    height: 10px;
    background: #00d4aa;
    border-radius: 50%;
    animation: pulse 2s ease-in-out infinite;
  }
  @keyframes pulse {
    0%, 100% { opacity: 1; box-shadow: 0 0 0 0 rgba(0,212,170,0.4); }
    50% { opacity: 0.8; box-shadow: 0 0 0 8px rgba(0,212,170,0); }
  }
  .status-text {
    color: #00d4aa;
    font-size: 14px;
    font-weight: 500;
    letter-spacing: 2px;
  }
  .search-box {
    width: 100%;
    max-width: 580px;
    position: relative;
    margin-bottom: 60px;
  }
  .search-box input {
    width: 100%;
    padding: 16px 24px;
    background: #1a1a1a;
    border: 1px solid #333;
    border-radius: 50px;
    color: #fff;
    font-size: 16px;
    outline: none;
    transition: border-color 0.3s;
  }
  .search-box input:focus {
    border-color: #0099ff;
  }
  .search-box input::placeholder { color: #666; }
  .links {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
    justify-content: center;
  }
  .link {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    padding: 16px 20px;
    background: #1a1a1a;
    border-radius: 12px;
    text-decoration: none;
    color: #ccc;
    font-size: 12px;
    min-width: 90px;
    transition: background 0.2s, transform 0.2s;
  }
  .link:hover {
    background: #252525;
    transform: translateY(-2px);
  }
  .link-icon {
    font-size: 24px;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #252525;
    border-radius: 10px;
  }
  .bottombar {
    width: 100%;
    height: 2px;
    background: linear-gradient(90deg, #00d4aa, #0099ff, #00d4aa, #0099ff);
    background-size: 300% 100%;
    animation: gradient 4s ease infinite;
  }
</style>
</head>
<body>
<div class="topbar"></div>
<div class="container">
  <div class="logo">WCHROME</div>
  <div class="version">V5</div>
  <div class="status">
    <div class="dot"></div>
    <span class="status-text">TUNNEL ACTIVE</span>
  </div>
  <div class="search-box">
    <form action="https://www.google.com/search" method="GET">
      <input type="text" name="q" placeholder="Search Google" autofocus>
    </form>
  </div>
  <div class="links">
    <a class="link" href="https://www.youtube.com"><div class="link-icon">&#9654;</div>YouTube</a>
    <a class="link" href="https://www.google.com"><div class="link-icon">G</div>Google</a>
    <a class="link" href="https://classroom.google.com"><div class="link-icon">&#9998;</div>Classroom</a>
    <a class="link" href="https://www.chess.com"><div class="link-icon">&#9822;</div>Chess</a>
    <a class="link" href="https://discord.com/app"><div class="link-icon">&#9993;</div>Discord</a>
    <a class="link" href="https://www.reddit.com"><div class="link-icon">R</div>Reddit</a>
  </div>
</div>
<div class="bottombar"></div>
</body>
</html>"""
    path = os.path.join(tmp, "wchrome_home.html")
    with open(path, "w") as f:
        f.write(html)
    return path


def _cleanup(tmp):
    try:
        shutil.rmtree(tmp, ignore_errors=True)
    except Exception:
        pass


def _format_duration(seconds):
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    if h > 0:
        return f"{h}h {m}m {s}s"
    elif m > 0:
        return f"{m}m {s}s"
    return f"{s}s"


# ── Main ─────────────────────────────────────────────────────────
def main():
    _clear()
    _set_title("Wchrome")
    _self_check()
    print(BANNER)

    # Auto-update check
    _check_pypi_update()

    # Control check with spinner
    cfg = _with_spinner("Verifying access...", _remote_cfg)
    if not _enforce(cfg):
        sys.exit(0)
    _status("✓", GRN, "Access granted!")

    # Usage
    data = _inc_usage()
    total = data["total"]
    today_str = datetime.now().strftime("%Y-%m-%d")
    today_count = data.get("daily", {}).get(today_str, 0)
    streak = data.get("streak", 0)
    first = data.get("first")

    print()
    _box([
        f"Today: {today_count}  |  All-time: {total}  |  Streak: {streak} day{'s' if streak != 1 else ''}",
        f"Member since: {first or today_str}",
    ], BLU)

    # Chrome
    chrome = _find_chrome()
    _status("✓", GRN, "Chrome found")
    cd = _chrome_dir()
    if not os.path.isdir(cd):
        _status("✗", RED, f"Chrome data not found at {cd}")
        sys.exit(1)

    profiles = _find_profiles(cd)
    if not profiles:
        _status("✗", RED, "No Chrome profiles found.")
        sys.exit(1)
    chosen = _pick_profile(profiles)

    print()

    # WARP
    cli = _find_warp()
    if not cli:
        cli = _install_warp()
    else:
        _status("✓", GRN, "WARP found")
    _setup_warp(cli)
    atexit.register(_disconnect_warp, cli)

    # Second check
    _with_spinner("Final verification...", _recheck)

    # Profile
    print()
    tmp = os.path.join(tempfile.gettempdir(), "chrome_unblocked")
    os.makedirs(tmp, exist_ok=True)
    _copy_profile(cd, chosen, tmp)
    _patch_prefs(tmp, chosen)
    homepage = _create_homepage(tmp)

    # Launch
    _set_title("Wchrome — Connected")
    args = [
        chrome,
        f"--user-data-dir={tmp}",
        f"--profile-directory={chosen}",
        f"--proxy-server=socks5://127.0.0.1:{WARP_SOCKS_PORT}",
        "--host-resolver-rules=MAP * ~NOTFOUND , EXCLUDE 127.0.0.1",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-session-crashed-bubble",
        f"file://{homepage}",
    ]

    print()
    print(f"  {GRN}{B}{'─' * 46}{R}")
    print(f"  {GRN}{B}  WCHROME — TUNNEL ACTIVE{R}")
    print(f"  {GRN}{B}{'─' * 46}{R}")
    print(f"  {DIM}Profile:    {chosen}{R}")
    print(f"  {DIM}Proxy:      socks5://127.0.0.1:{WARP_SOCKS_PORT}{R}")
    print(f"  {DIM}DNS:        Encrypted (no leaks){R}")
    print(f"  {DIM}All traffic routed through Cloudflare{R}")
    print(f"  {GRN}{B}{'─' * 46}{R}")
    print(f"\n  {DIM}Press Ctrl+C or close Chrome to quit.{R}\n")

    start_time = time.time()
    proc = subprocess.Popen(args)

    mon = threading.Thread(target=_bg_monitor, args=(proc, cli), daemon=True)
    mon.start()

    def _exit(sig, frame):
        elapsed = time.time() - start_time
        proc.terminate()
        _disconnect_warp(cli)
        _cleanup(tmp)
        _set_title("Wchrome — Disconnected")
        print(f"\n  {DIM}Session: {_format_duration(elapsed)}{R}")
        print(f"  {CYN}See you next time!{R}\n")
        sys.exit(0)

    signal.signal(signal.SIGINT, _exit)
    signal.signal(signal.SIGTERM, _exit)

    proc.wait()
    elapsed = time.time() - start_time
    _disconnect_warp(cli)
    _cleanup(tmp)
    _set_title("Wchrome — Disconnected")
    print(f"\n  {DIM}Session: {_format_duration(elapsed)}{R}")
    print(f"  {CYN}Chrome closed. See you next time!{R}\n")


if __name__ == "__main__":
    main()
