from quanta.config._internal import *
