# python-practice-app
This is for practice

# Example Package

This is a simple example package. You can use
[GitHub-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

https://www.geeksforgeeks.org/python/python-projects-beginner-to-advanced/