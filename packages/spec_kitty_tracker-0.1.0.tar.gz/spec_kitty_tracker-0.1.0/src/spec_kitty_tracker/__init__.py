"""spec-kitty-tracker: universal task tracker interface and sync engine."""

from spec_kitty_tracker.capabilities import TrackerCapabilities
from spec_kitty_tracker.conflicts import ConflictRecord, ConflictStrategy
from spec_kitty_tracker.connectors import (
    AzureDevOpsConnector,
    AzureDevOpsConnectorConfig,
    BeadsConnector,
    BeadsConnectorConfig,
    FPConnector,
    FPConnectorConfig,
    GitHubConnector,
    GitHubConnectorConfig,
    GitLabConnector,
    GitLabConnectorConfig,
    InMemoryConnector,
    JiraConnector,
    JiraConnectorConfig,
    LinearConnector,
    LinearConnectorConfig,
)
from spec_kitty_tracker.errors import (
    CapabilityNotSupportedError,
    FailureClass,
    ConnectorConfigError,
    ConnectorRequestError,
    IssueNotFoundError,
    SpecKittyTrackerError,
    SyncConflictError,
    classify_http_status,
)
from spec_kitty_tracker.models import (
    CanonicalIssue,
    CanonicalIssueType,
    CanonicalLink,
    CanonicalStatus,
    ExternalRef,
    LinkType,
    Page,
    SyncCheckpoint,
    TrackerEvent,
    TrackerEventType,
    utcnow,
)
from spec_kitty_tracker.mission_sync import (
    BidirectionalIssueSync,
    DecisionReference,
    MissionSeed,
    MissionUpdate,
    mission_seed_from_issue,
)
from spec_kitty_tracker.policy import CORE_ISSUE_FIELDS, FieldOwner, OwnershipMode, OwnershipPolicy
from spec_kitty_tracker.protocols import LocalIssueStore, TaskTrackerConnector
from spec_kitty_tracker.registry import ConnectorRegistry
from spec_kitty_tracker.store import InMemoryIssueStore
from spec_kitty_tracker.sync import SyncEngine, SyncResult, SyncStats

__version__ = "0.1.0"

__all__ = [
    "AzureDevOpsConnector",
    "AzureDevOpsConnectorConfig",
    "BeadsConnector",
    "BeadsConnectorConfig",
    "BidirectionalIssueSync",
    "CapabilityNotSupportedError",
    "CanonicalIssue",
    "CanonicalIssueType",
    "CanonicalLink",
    "CanonicalStatus",
    "ConflictRecord",
    "ConflictStrategy",
    "ConnectorConfigError",
    "ConnectorRegistry",
    "ConnectorRequestError",
    "CORE_ISSUE_FIELDS",
    "DecisionReference",
    "ExternalRef",
    "FailureClass",
    "FieldOwner",
    "FPConnector",
    "FPConnectorConfig",
    "GitHubConnector",
    "GitHubConnectorConfig",
    "GitLabConnector",
    "GitLabConnectorConfig",
    "InMemoryConnector",
    "InMemoryIssueStore",
    "IssueNotFoundError",
    "JiraConnector",
    "JiraConnectorConfig",
    "LinearConnector",
    "LinearConnectorConfig",
    "LinkType",
    "LocalIssueStore",
    "MissionSeed",
    "MissionUpdate",
    "OwnershipMode",
    "OwnershipPolicy",
    "Page",
    "SpecKittyTrackerError",
    "SyncCheckpoint",
    "SyncConflictError",
    "SyncEngine",
    "SyncResult",
    "SyncStats",
    "classify_http_status",
    "TaskTrackerConnector",
    "TrackerCapabilities",
    "TrackerEvent",
    "TrackerEventType",
    "mission_seed_from_issue",
    "utcnow",
]
