from __future__ import annotations

from spec_kitty_tracker.models import CanonicalStatus


def normalize_priority(value: int | None) -> int | None:
    if value is None:
        return None
    if value < 0:
        return 0
    if value > 4:
        return 4
    return value


def github_state_to_status(state: str) -> CanonicalStatus:
    return CanonicalStatus.DONE if state == "closed" else CanonicalStatus.TODO


def status_to_github_state(status: CanonicalStatus) -> str:
    if status in (CanonicalStatus.DONE, CanonicalStatus.CANCELED):
        return "closed"
    return "open"


def linear_priority_to_canonical(priority: int | None) -> int | None:
    if priority is None:
        return None
    mapping = {0: 4, 1: 0, 2: 1, 3: 2, 4: 3}
    return mapping.get(priority, 4)


def canonical_to_linear_priority(priority: int | None) -> int:
    if priority is None:
        return 0
    mapping = {4: 0, 0: 1, 1: 2, 2: 3, 3: 4}
    return mapping.get(priority, 0)
