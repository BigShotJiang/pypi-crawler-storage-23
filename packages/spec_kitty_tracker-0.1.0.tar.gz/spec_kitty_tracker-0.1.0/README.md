# spec-kitty-tracker

Shared task-tracker abstraction layer for Spec Kitty CLI and SaaS.

## Scope

1. Canonical issue model (`CanonicalIssue`, `ExternalRef`, `CanonicalLink`)
2. Tracker connector protocol with capability negotiation
3. Doctrine-style source-of-truth ownership policies
4. Conflict resolution and deterministic sync engine
5. Bidirectional mission/issue sync bridge with decision reference traceability
6. Connector registry and vendor connector implementations

## Included Connectors

1. `InMemoryConnector` (fully functional reference connector)
2. `BeadsConnector` (explicit `bd` CLI adapter)
3. `FPConnector` (explicit `fp` CLI adapter)
4. `JiraConnector`
5. `LinearConnector`
6. `AzureDevOpsConnector`
7. `GitHubConnector`
8. `GitLabConnector`

The vendor connectors are designed for production integration and may require tenant-specific field mappings.
`BeadsConnector` and `FPConnector` are first-class adapters for local-first native tracker workflows.

## Installation

```bash
pip install -e .
```

For development tools:

```bash
pip install -e ".[dev]"
```

## Quick Example

```python
import asyncio
from spec_kitty_tracker import (
    CanonicalIssue,
    CanonicalIssueType,
    CanonicalStatus,
    ExternalRef,
    InMemoryConnector,
    InMemoryIssueStore,
    OwnershipPolicy,
    OwnershipMode,
    SyncEngine,
)


async def main() -> None:
    connector = InMemoryConnector(name="jira", workspace="example")
    store = InMemoryIssueStore()

    issue = CanonicalIssue(
        ref=ExternalRef(system="jira", workspace="example", id="DEMO-1", key="DEMO-1"),
        title="First issue",
        body="Seed issue",
        status=CanonicalStatus.TODO,
        issue_type=CanonicalIssueType.TASK,
    )

    await connector.create_issue(issue)

    policy = OwnershipPolicy(mode=OwnershipMode.EXTERNAL_AUTHORITATIVE)
    engine = SyncEngine(connector=connector, store=store, policy=policy)
    await engine.pull()

    pulled = await store.get_issue(issue.ref)
    assert pulled is not None


asyncio.run(main())
```

## Design Notes

1. The core contract is intentionally tracker-agnostic.
2. `OwnershipPolicy` makes source-of-truth behavior explicit and auditable.
3. `SyncEngine` supports pull, push, and bidirectional sync with conflict records.
4. Capability flags gate optional features (e.g., hierarchy, dependencies, webhooks).
5. Mission updates are idempotent and persist decision references back to source issues.

## Docs

1. [Architecture](docs/ARCHITECTURE.md)
2. [Connector Contract](docs/CONNECTOR_CONTRACT.md)
3. [Doctrine Policy Modes](docs/DOCTRINE_POLICY.md)
4. [P0 Provider Matrix](docs/provider-matrix.md)
5. [WP04 Contract Alignment Notes](docs/wp04-contract-alignment.md)
6. [WP11 Sync Core Notes](docs/wp11-sync-core-notes.md)
