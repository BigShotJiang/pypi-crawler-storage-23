from spec_kitty_tracker import (
    CanonicalStatus,
    JiraConnector,
    JiraConnectorConfig,
    LinearConnector,
    LinearConnectorConfig,
)


def test_jira_payload_mapping() -> None:
    connector = JiraConnector(
        JiraConnectorConfig(
            base_url="https://example.atlassian.net",
            email="user@example.com",
            api_token="token",
            project_key="PROJ",
        )
    )

    issue = connector._to_canonical(  # noqa: SLF001
        {
            "id": "10001",
            "key": "PROJ-1",
            "fields": {
                "summary": "Issue",
                "description": {
                    "type": "doc",
                    "version": 1,
                    "content": [
                        {
                            "type": "paragraph",
                            "content": [{"type": "text", "text": "Hello"}],
                        }
                    ],
                },
                "status": {"name": "In Progress"},
                "priority": {"name": "High"},
                "issuetype": {"name": "Task"},
                "labels": ["backend"],
            },
        }
    )

    assert issue.ref.key == "PROJ-1"
    assert issue.status == CanonicalStatus.IN_PROGRESS


async def test_linear_payload_mapping() -> None:
    connector = LinearConnector(
        LinearConnectorConfig(api_key="lin_api", team_id="team-1")
    )

    issue = connector._to_canonical(  # noqa: SLF001
        {
            "id": "abc",
            "identifier": "ENG-1",
            "title": "Linear issue",
            "description": "Body",
            "priority": 2,
            "createdAt": "2026-02-26T12:00:00Z",
            "updatedAt": "2026-02-26T13:00:00Z",
            "state": {"id": "st", "name": "In Progress", "type": "started"},
            "labels": {"nodes": [{"name": "feature"}]},
        }
    )

    assert issue.ref.id == "abc"
    assert issue.status == CanonicalStatus.IN_PROGRESS
