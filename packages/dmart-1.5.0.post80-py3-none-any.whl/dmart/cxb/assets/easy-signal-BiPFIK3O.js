const e=Symbol.for("reactiveStores");globalThis[e]||(globalThis[e]={context:null,subscriberQueue:new Map});
