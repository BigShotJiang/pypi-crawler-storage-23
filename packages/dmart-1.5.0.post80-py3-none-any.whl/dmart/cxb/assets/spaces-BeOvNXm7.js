import{w as s}from"./svelte-DmuBgWcI.js";const o=s(null);export{o as s};
