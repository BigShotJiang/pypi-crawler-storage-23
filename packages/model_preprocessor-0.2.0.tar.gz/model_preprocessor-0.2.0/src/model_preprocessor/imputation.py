"""Cross-variable imputation: predict each column from all others."""

from __future__ import annotations

import warnings
from copy import deepcopy

import numpy as np
import pandas as pd
from sklearn.base import clone


class CrossVariableImputer:
    """For every column with missing values, trains a model to predict it
    from all other columns (using mean-imputation as initial fill).
    At transform time, missing values are replaced with model predictions.

    Parameters
    ----------
    model : sklearn estimator
        Must support ``.fit(X, y)`` and ``.predict(X)``.
        A separate clone is trained for each column that had missing values
        during fit.
    """

    def __init__(self, model):
        self._template_model = model
        self._col_means: dict[str, float] = {}
        self._col_models: dict[str, object] = {}
        self._columns: list[str] = []

    def fit(self, df: pd.DataFrame) -> "CrossVariableImputer":
        self._columns = list(df.columns)

        # Step 1: compute column means for initial imputation
        self._col_means = {}
        for col in self._columns:
            self._col_means[col] = float(df[col].mean()) if df[col].notna().any() else 0.0

        # Step 2: mean-impute everything to create a complete matrix
        filled = df.copy()
        for col in self._columns:
            filled[col] = filled[col].fillna(self._col_means[col])

        # Step 3: for each column, fit a model using all other columns
        self._col_models = {}
        for col in self._columns:
            if df[col].isna().sum() == 0:
                continue  # no missingness in training data, skip

            predictors = [c for c in self._columns if c != col]
            if not predictors:
                continue

            X_train = filled[predictors].values
            y_train = filled[col].values

            m = clone(self._template_model)
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                m.fit(X_train, y_train)
            self._col_models[col] = m

        return self

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        result = df.copy()

        # Ensure all expected columns exist; fill extras with mean
        for col in self._columns:
            if col not in result.columns:
                result[col] = self._col_means.get(col, 0.0)

        # Mean-impute first (needed so predictor columns are complete)
        filled = result.copy()
        for col in self._columns:
            if col in filled.columns:
                filled[col] = filled[col].fillna(self._col_means.get(col, 0.0))

        # Replace missing values with model predictions where we have a model
        for col, model in self._col_models.items():
            if col not in result.columns:
                continue
            mask = result[col].isna()
            if not mask.any():
                continue
            predictors = [c for c in self._columns if c != col]
            X_pred = filled.loc[mask, predictors].values
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                preds = model.predict(X_pred)
            result.loc[mask, col] = preds

        # Any remaining NaN (columns without a model) get mean-imputed
        for col in self._columns:
            if col in result.columns:
                result[col] = result[col].fillna(self._col_means.get(col, 0.0))

        # Keep only expected columns in order
        present = [c for c in self._columns if c in result.columns]
        extra = [c for c in result.columns if c not in self._columns]
        return result[present + extra]
