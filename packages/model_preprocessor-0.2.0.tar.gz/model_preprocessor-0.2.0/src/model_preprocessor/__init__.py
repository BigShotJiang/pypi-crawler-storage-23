"""model-preprocessor: Automated feature engineering for tabular data."""

from model_preprocessor.preprocessor import ModelPreprocessor

__version__ = "0.2.0"
__all__ = ["ModelPreprocessor"]
