"""Target encoding and text mining for string columns."""

from __future__ import annotations

import re
from collections import Counter

import numpy as np
import pandas as pd


class TargetEncoder:
    """Smoothed target encoding for low-cardinality string columns.

    For each unique value, the encoded value is a weighted average of:
      - the group mean (mean of target where column == this value)
      - the overall mean (mean of target across all rows)

    The weight is ``min(sqrt(n) / sqrt(100), 1)`` where *n* is the number of
    rows for that value.  Low-sample values shrink toward the overall mean.
    """

    def __init__(self):
        self._mapping: dict[str, float] = {}
        self._overall_mean: float = np.nan

    def fit(self, col: pd.Series, y: pd.Series) -> "TargetEncoder":
        self._overall_mean = float(y.mean())

        tmp = pd.DataFrame({"val": col.astype(str).fillna("__NA__"), "y": y})
        stats = tmp.groupby("val")["y"].agg(["mean", "count"])

        for val, row in stats.iterrows():
            n = row["count"]
            w = min(np.sqrt(n) / np.sqrt(100), 1.0)
            encoded = w * row["mean"] + (1 - w) * self._overall_mean
            self._mapping[val] = encoded

        return self

    def transform(self, col: pd.Series) -> pd.Series:
        filled = col.astype(str).fillna("__NA__")
        return filled.map(self._mapping).fillna(self._overall_mean)


class TextMiner:
    """One-hot encodes tokens from high-cardinality string columns.

    Each cell is tokenised (whitespace + punctuation split, lowercased).
    Only tokens appearing in at least ``min_count`` rows are kept.
    The result is a binary DataFrame with one column per kept token.
    """

    def __init__(self, min_count: int = 30):
        self.min_count = min_count
        self._kept_tokens: list[str] = []
        self._col_name: str = ""

    # simple tokeniser: split on non-alphanumeric
    _SPLIT_RE = re.compile(r"[^a-z0-9]+")

    def _tokenise(self, series: pd.Series) -> pd.Series:
        """Return a Series of sets-of-tokens."""
        return (
            series
            .astype(str)
            .fillna("")
            .str.lower()
            .str.strip()
            .apply(lambda s: set(self._SPLIT_RE.split(s)) - {""})
        )

    def fit(self, col: pd.Series) -> "TextMiner":
        self._col_name = col.name or "txt"
        token_sets = self._tokenise(col)

        counts: Counter = Counter()
        for ts in token_sets:
            counts.update(ts)

        self._kept_tokens = sorted(
            tok for tok, cnt in counts.items() if cnt >= self.min_count
        )
        return self

    def transform(self, col: pd.Series) -> pd.DataFrame:
        token_sets = self._tokenise(col)
        data = {}
        for tok in self._kept_tokens:
            data[f"{self._col_name}__{tok}"] = token_sets.apply(lambda ts: int(tok in ts))
        return pd.DataFrame(data, index=col.index)
