"""Main preprocessor that orchestrates target encoding, text mining, and imputation."""

from __future__ import annotations

import warnings
from typing import Optional

import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge

from model_preprocessor.encoding import TargetEncoder, TextMiner
from model_preprocessor.imputation import CrossVariableImputer


class ModelPreprocessor:
    """End-to-end preprocessor: target-encode strings, text-mine high-cardinality
    columns, and impute missing values using cross-variable prediction.

    Parameters
    ----------
    target : str
        Name of the dependent variable column.
    max_unique : int, default 250
        String columns with <= this many unique values get target-encoded.
        Columns above this threshold get text-mined instead.
    min_token_count : int or None, default None
        Minimum number of rows a text token must appear in to be kept.
        If None, uses max(30, 0.1% of rows).
    impute_model : sklearn estimator or None, default None
        Model used to predict each variable from all others during imputation.
        If None, uses Ridge(alpha=1.0) for speed.
    """

    def __init__(
        self,
        target: str,
        max_unique: int = 250,
        min_token_count: Optional[int] = None,
        impute_model=None,
    ):
        self.target = target
        self.max_unique = max_unique
        self.min_token_count = min_token_count
        self.impute_model = impute_model

        # Fitted state
        self._target_encoders: dict[str, TargetEncoder] = {}
        self._text_miners: dict[str, TextMiner] = {}
        self._imputer: Optional[CrossVariableImputer] = None
        self._numeric_cols: list[str] = []
        self._fitted_columns: list[str] = []  # exact column order after encoding
        self._fitted = False

    def fit(self, df: pd.DataFrame) -> "ModelPreprocessor":
        """Learn encodings and imputation models from training data.

        Parameters
        ----------
        df : DataFrame
            Must contain the ``target`` column.

        Returns
        -------
        self
        """
        if self.target not in df.columns:
            raise ValueError(f"Target column '{self.target}' not found in DataFrame.")

        y = df[self.target].astype(float)
        features = df.drop(columns=[self.target])

        string_cols = features.select_dtypes(include=["object", "category", "string"]).columns.tolist()
        self._numeric_cols = features.select_dtypes(include="number").columns.tolist()

        min_count = self.min_token_count
        if min_count is None:
            min_count = max(30, int(np.ceil(len(df) * 0.001)))

        # --- Phase 1: Encode string columns ---
        self._target_encoders = {}
        self._text_miners = {}

        for col in string_cols:
            n_unique = features[col].nunique()
            if n_unique <= self.max_unique:
                enc = TargetEncoder()
                enc.fit(features[col], y)
                self._target_encoders[col] = enc
            else:
                miner = TextMiner(min_count=min_count)
                miner.fit(features[col])
                self._text_miners[col] = miner

        # --- Phase 2: Transform to numeric for imputation fitting ---
        transformed = self._transform_to_numeric(features)
        self._fitted_columns = list(transformed.columns)

        # --- Phase 3: Fit cross-variable imputer ---
        model = self.impute_model if self.impute_model is not None else Ridge(alpha=1.0)
        self._imputer = CrossVariableImputer(model=model)
        self._imputer.fit(transformed)

        self._fitted = True
        return self

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """Apply learned encodings and imputation to new data.

        Parameters
        ----------
        df : DataFrame
            May or may not contain the target column. If present, it is
            excluded from processing and included as-is in the output.

        Returns
        -------
        DataFrame
            Fully numeric, no missing values (except possibly in target).
        """
        if not self._fitted:
            raise RuntimeError("Call .fit() before .transform().")

        has_target = self.target in df.columns
        if has_target:
            y = df[self.target].copy()
            features = df.drop(columns=[self.target])
        else:
            y = None
            features = df.copy()

        # Phase 1: encode strings
        transformed = self._transform_to_numeric(features)

        # Phase 2: align columns to match training schema
        transformed = self._align_columns(transformed)

        # Phase 3: impute missing values
        transformed = self._imputer.transform(transformed)

        if has_target:
            transformed[self.target] = y.values

        return transformed

    def fit_transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """Convenience method: fit then transform."""
        self.fit(df)
        return self.transform(df)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _transform_to_numeric(self, features: pd.DataFrame) -> pd.DataFrame:
        """Convert string columns to numeric via target encoding or text mining."""
        parts: list[pd.DataFrame] = []

        # Keep existing numeric columns
        num_cols = [c for c in self._numeric_cols if c in features.columns]
        if num_cols:
            parts.append(features[num_cols].copy())

        # Target-encoded columns
        for col, enc in self._target_encoders.items():
            if col in features.columns:
                encoded = enc.transform(features[col])
                parts.append(encoded.to_frame(name=col))

        # Text-mined columns (one-hot)
        for col, miner in self._text_miners.items():
            if col in features.columns:
                ohe = miner.transform(features[col])
                parts.append(ohe)

        if not parts:
            warnings.warn("No columns to process. Returning empty DataFrame.")
            return pd.DataFrame(index=features.index)

        return pd.concat(parts, axis=1)

    def _align_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """Ensure df has exactly the same columns (in order) as the training set.

        - Columns in training but missing from df are added with NaN
          (the imputer will fill them).
        - Columns in df but not in training are dropped.
        """
        for col in self._fitted_columns:
            if col not in df.columns:
                df[col] = np.nan
        return df[self._fitted_columns]
