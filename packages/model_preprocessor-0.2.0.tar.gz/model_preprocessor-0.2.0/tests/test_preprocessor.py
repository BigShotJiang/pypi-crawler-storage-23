"""Tests for model_preprocessor."""

import numpy as np
import pandas as pd
import pytest

from model_preprocessor import ModelPreprocessor
from model_preprocessor.encoding import TargetEncoder, TextMiner
from model_preprocessor.imputation import CrossVariableImputer


# ---------------------------------------------------------------------------
# TargetEncoder
# ---------------------------------------------------------------------------

class TestTargetEncoder:
    def test_high_count_gets_group_mean(self):
        """Values with n >= 100 should get weight=1, i.e. pure group mean."""
        col = pd.Series(["a"] * 200 + ["b"] * 200)
        y = pd.Series([10.0] * 200 + [20.0] * 200)
        enc = TargetEncoder().fit(col, y)
        result = enc.transform(pd.Series(["a", "b"]))
        assert abs(result.iloc[0] - 10.0) < 0.01
        assert abs(result.iloc[1] - 20.0) < 0.01

    def test_low_count_shrinks_to_overall(self):
        """A value with n=1 should be mostly the overall mean."""
        col = pd.Series(["a"] * 100 + ["b"])
        y = pd.Series([10.0] * 100 + [50.0])
        enc = TargetEncoder().fit(col, y)
        result = enc.transform(pd.Series(["b"]))
        overall_mean = y.mean()
        # weight for n=1 is sqrt(1)/sqrt(100)=0.1
        expected = 0.1 * 50.0 + 0.9 * overall_mean
        assert abs(result.iloc[0] - expected) < 0.5

    def test_unseen_value_gets_overall_mean(self):
        col = pd.Series(["a", "b", "a", "b"])
        y = pd.Series([1.0, 2.0, 1.0, 2.0])
        enc = TargetEncoder().fit(col, y)
        result = enc.transform(pd.Series(["c"]))
        assert abs(result.iloc[0] - 1.5) < 0.01


# ---------------------------------------------------------------------------
# TextMiner
# ---------------------------------------------------------------------------

class TestTextMiner:
    def test_keeps_frequent_tokens(self):
        col = pd.Series(["hello world"] * 50 + ["goodbye world"] * 50)
        col.name = "text"
        miner = TextMiner(min_count=40).fit(col)
        result = miner.transform(col)
        assert "text__world" in result.columns
        assert "text__hello" in result.columns
        assert "text__goodbye" in result.columns

    def test_drops_rare_tokens(self):
        col = pd.Series(["common"] * 100 + ["common rare"] * 2)
        col.name = "x"
        miner = TextMiner(min_count=50).fit(col)
        result = miner.transform(col)
        assert "x__common" in result.columns
        assert "x__rare" not in result.columns


# ---------------------------------------------------------------------------
# CrossVariableImputer
# ---------------------------------------------------------------------------

class TestCrossVariableImputer:
    def test_fills_missing(self):
        from sklearn.linear_model import Ridge
        df = pd.DataFrame({
            "a": [1.0, 2.0, 3.0, np.nan, 5.0],
            "b": [10.0, 20.0, 30.0, 40.0, 50.0],
        })
        imp = CrossVariableImputer(model=Ridge()).fit(df)
        result = imp.transform(df)
        assert result["a"].isna().sum() == 0

    def test_no_missing_passthrough(self):
        from sklearn.linear_model import Ridge
        df = pd.DataFrame({"a": [1.0, 2.0], "b": [3.0, 4.0]})
        imp = CrossVariableImputer(model=Ridge()).fit(df)
        result = imp.transform(df)
        pd.testing.assert_frame_equal(result, df)


# ---------------------------------------------------------------------------
# ModelPreprocessor (integration)
# ---------------------------------------------------------------------------

class TestModelPreprocessor:
    @pytest.fixture()
    def sample_df(self):
        rng = np.random.default_rng(42)
        n = 500
        return pd.DataFrame({
            "category": rng.choice(["a", "b", "c", "d"], size=n),
            "numeric1": rng.normal(0, 1, n),
            "numeric2": np.where(rng.random(n) < 0.1, np.nan, rng.normal(5, 2, n)),
            "target": rng.normal(100, 10, n),
        })

    def test_fit_transform_no_missing(self, sample_df):
        pp = ModelPreprocessor(target="target", max_unique=250)
        result = pp.fit_transform(sample_df)
        assert result.isna().sum().sum() == 0
        assert "target" in result.columns

    def test_all_numeric_output(self, sample_df):
        pp = ModelPreprocessor(target="target")
        result = pp.fit_transform(sample_df)
        for col in result.columns:
            assert pd.api.types.is_numeric_dtype(result[col]), f"{col} is not numeric"

    def test_transform_on_new_data(self, sample_df):
        pp = ModelPreprocessor(target="target")
        pp.fit(sample_df)
        new = sample_df.head(10).drop(columns=["target"])
        result = pp.transform(new)
        assert result.isna().sum().sum() == 0
        assert "target" not in result.columns

    def test_high_cardinality_text_mining(self):
        """Columns above max_unique should be text-mined."""
        rng = np.random.default_rng(0)
        n = 5000
        # 20 frequent words (each appears ~750 times) combined into 3-word phrases
        # giving >250 unique combos but frequent individual tokens
        words = [f"word{i}" for i in range(20)]
        col = pd.Series([" ".join(rng.choice(words, size=3)) for _ in range(n)])
        df = pd.DataFrame({
            "text_col": col,
            "target": rng.normal(0, 1, n),
        })
        pp = ModelPreprocessor(target="target", max_unique=250, min_token_count=30)
        result = pp.fit_transform(df)
        assert result.isna().sum().sum() == 0
        # should have one-hot columns from text mining
        text_cols = [c for c in result.columns if c.startswith("text_col__")]
        assert len(text_cols) > 0

    # ------------------------------------------------------------------
    # Train / test split scenarios
    # ------------------------------------------------------------------

    def test_train_test_same_columns(self, sample_df):
        """Test set output should have the same feature columns as train."""
        train = sample_df.iloc[:400]
        test = sample_df.iloc[400:].drop(columns=["target"])

        pp = ModelPreprocessor(target="target")
        train_out = pp.fit_transform(train)
        test_out = pp.transform(test)

        train_features = [c for c in train_out.columns if c != "target"]
        assert list(test_out.columns) == train_features
        assert test_out.isna().sum().sum() == 0

    def test_test_unseen_category(self, sample_df):
        """Unseen categories in test should get the overall mean, not crash."""
        train = sample_df.copy()
        pp = ModelPreprocessor(target="target")
        pp.fit(train)

        test = pd.DataFrame({
            "category": ["never_seen_before", "also_new"],
            "numeric1": [1.0, np.nan],
            "numeric2": [np.nan, 3.0],
        })
        result = pp.transform(test)
        assert result.isna().sum().sum() == 0
        assert len(result) == 2

    def test_test_missing_string_column(self):
        """If a string column from train is entirely absent in test,
        it should be filled (NaN → imputed)."""
        rng = np.random.default_rng(99)
        n = 200
        train = pd.DataFrame({
            "cat1": rng.choice(["x", "y"], n),
            "cat2": rng.choice(["p", "q"], n),
            "num": rng.normal(0, 1, n),
            "target": rng.normal(10, 1, n),
        })
        pp = ModelPreprocessor(target="target")
        pp.fit(train)

        # test has cat1 but not cat2
        test = pd.DataFrame({
            "cat1": ["x", "y", "x"],
            "num": [0.5, -0.5, 1.0],
        })
        result = pp.transform(test)
        assert "cat2" in result.columns
        assert result.isna().sum().sum() == 0

    def test_test_extra_column_ignored(self, sample_df):
        """Columns in test that weren't in train should be dropped."""
        pp = ModelPreprocessor(target="target")
        pp.fit(sample_df)

        test = sample_df.head(5).drop(columns=["target"]).copy()
        test["brand_new_col"] = 999
        result = pp.transform(test)
        assert "brand_new_col" not in result.columns

    def test_test_with_all_missing_numeric(self, sample_df):
        """A numeric column that is entirely NaN in test should be imputed."""
        pp = ModelPreprocessor(target="target")
        pp.fit(sample_df)

        test = sample_df.head(10).drop(columns=["target"]).copy()
        test["numeric2"] = np.nan
        result = pp.transform(test)
        assert result["numeric2"].isna().sum() == 0
