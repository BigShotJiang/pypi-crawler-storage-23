from __future__ import annotations

import json
from pathlib import Path
from typing import List

from .symbol_logic import RootSpec


def build_concepts(specs: List[RootSpec], out_path: Path) -> Path:
    payload = [
        {
            "concept": s.aliases[0] if s.aliases else s.gloss,
            "gloss": s.gloss,
            "semantic_class": s.semantic_class,
            "symbol": s.symbol,
            "root": s.root,
            "aliases": list(s.aliases),
        }
        for s in specs
    ]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return out_path


def build_grammar_reference(out_path: Path) -> Path:
    payload = {
        "language_name": "LogiGlyph ASCII",
        "version": "1.0",
        "writing_system": "ASCII symbols (lg_<class>_<root>)",
        "translation_conventions": {
            "word_order": "Default SVO (subject-verb-object) in examples",
            "articles": "Dropped during EN->lang translation (a/an/the)",
            "unknown_words": "Passed through unchanged",
            "plural_hint": "Simple fallback may append relation marker for plain -s forms",
            "morphology": "Basic lemmatization for -s, -es, -ed, -ing",
        },
        "semantic_classes": [
            {"name": "entity", "tag": "e"},
            {"name": "action", "tag": "a"},
            {"name": "quality", "tag": "q"},
            {"name": "relation", "tag": "r"},
            {"name": "abstract", "tag": "x"},
        ],
        "symbol_format": "lg_<class_tag>_<onset><vowel><coda_or_underscore>",
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return out_path
