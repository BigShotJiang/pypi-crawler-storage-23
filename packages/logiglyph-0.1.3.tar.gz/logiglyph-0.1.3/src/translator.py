from __future__ import annotations

import re
from typing import Dict, List

from .dictionary_tool import build_lookup, build_reverse_lookup
from .symbol_logic import RootSpec


TOKEN_RE = re.compile(r"[A-Za-z0-9_]+|[^\sA-Za-z0-9_]")
WORD_RE = re.compile(r"^[a-z0-9_]+$")
STOPWORDS = {
    "a",
    "an",
    "the",
    "to",
    "of",
    "in",
    "on",
    "at",
    "for",
    "and",
}


def _tokenize(text: str) -> List[str]:
    return TOKEN_RE.findall(text.lower())


def _lemmatize(token: str) -> List[str]:
    out = [token]
    if token.endswith("ies") and len(token) > 4:
        out.append(token[:-3] + "y")
    if token.endswith("ing") and len(token) > 5:
        out.append(token[:-3])
        out.append(token[:-3] + "e")
    if token.endswith("ed") and len(token) > 4:
        out.append(token[:-2])
        out.append(token[:-1])
    if token.endswith("es") and len(token) > 4:
        out.append(token[:-2])
    if token.endswith("s") and len(token) > 3:
        out.append(token[:-1])
    # Preserve order but deduplicate.
    seen = set()
    dedup = []
    for c in out:
        if c not in seen:
            dedup.append(c)
            seen.add(c)
    return dedup


def _alias_lookup(specs: List[RootSpec]) -> Dict[str, RootSpec]:
    out: Dict[str, RootSpec] = {}
    for s in specs:
        out[s.gloss] = s
        for a in s.aliases:
            out[a] = s
    return out


def _detokenize(tokens: List[str]) -> str:
    text = " ".join(tokens)
    text = re.sub(r"\s+([,.;:!?])", r"\1", text)
    text = re.sub(r"\(\s+", "(", text)
    text = re.sub(r"\s+\)", ")", text)
    return text.strip()


def translate_en_to_lang(text: str, specs: List[RootSpec]) -> str:
    lookup = build_lookup(specs)
    aliases = _alias_lookup(specs)
    tokens = _tokenize(text)
    out: List[str] = []
    for t in tokens:
        if WORD_RE.match(t) and t in STOPWORDS:
            continue
        if t in aliases:
            out.append(aliases[t].symbol)
            continue
        # Basic morphology fallback:
        # plural -> root + relation marker if available
        if t.endswith("s") and t[:-1] in lookup:
            out.append(lookup[t[:-1]].symbol)
            rel = lookup.get("group_27") or next((s for s in specs if s.semantic_class == "relation"), None)
            if rel:
                out.append(rel.symbol)
            continue
        if WORD_RE.match(t):
            for lemma in _lemmatize(t):
                if lemma in aliases:
                    out.append(aliases[lemma].symbol)
                    break
            else:
                out.append(t)
            continue
        out.append(t)
    return _detokenize(out)


def translate_lang_to_en(text: str, specs: List[RootSpec]) -> str:
    reverse = build_reverse_lookup(specs)
    tokens = _tokenize(text)
    out: List[str] = []
    for tok in tokens:
        if tok in reverse:
            out.append(reverse[tok].aliases[0] if reverse[tok].aliases else reverse[tok].gloss)
        else:
            out.append(tok)
    return _detokenize(out)
