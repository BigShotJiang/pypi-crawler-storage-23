from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

from .dictionary_tool import load_dictionary
from .symbol_logic import RootSpec
from .translator import translate_en_to_lang, translate_lang_to_en


@dataclass
class TranslationResult:
    text: str


class LanguageModule:
    """Reusable API for integrating translation in other Python programs."""

    def __init__(self, dictionary_path: str | Path = "data/dictionary.json"):
        self.dictionary_path = Path(dictionary_path)
        self.specs: List[RootSpec] = load_dictionary(self.dictionary_path)
        self.symbol_to_gloss: Dict[str, str] = {s.symbol: s.gloss for s in self.specs}
        self.gloss_to_symbol: Dict[str, str] = {s.gloss: s.symbol for s in self.specs}

    def translate(self, text: str) -> TranslationResult:
        out = translate_en_to_lang(text, self.specs)
        return TranslationResult(text=out)

    def reverse(self, text: str) -> str:
        return translate_lang_to_en(text, self.specs)

    def install_note(self) -> str:
        return "Symbols are ASCII (lg_<class>_<root>) and render in any standard font."
