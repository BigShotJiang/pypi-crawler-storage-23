from __future__ import annotations

import argparse
from pathlib import Path

from .dictionary_tool import generate_dictionary, load_dictionary, save_dictionary
from .language_pack import build_concepts, build_grammar_reference
from .translator import translate_en_to_lang, translate_lang_to_en


def _cmd_generate_dictionary(args: argparse.Namespace) -> int:
    specs = generate_dictionary(count=args.count, model=args.model)
    save_dictionary(specs, Path(args.out))
    print(f"Dictionary saved: {args.out} ({len(specs)} roots)")
    return 0


def _cmd_translate(args: argparse.Namespace) -> int:
    specs = load_dictionary(Path(args.dict))
    if args.reverse:
        translated = translate_lang_to_en(args.text, specs)
    else:
        translated = translate_en_to_lang(args.text, specs)
    print(translated)
    return 0


def _cmd_build_language_pack(args: argparse.Namespace) -> int:
    specs = load_dictionary(Path(args.dict))
    concepts_path = build_concepts(specs, Path(args.concepts_out))
    grammar_path = build_grammar_reference(Path(args.grammar_out))
    print(f"Concepts saved: {concepts_path}")
    print(f"Grammar reference saved: {grammar_path}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Agglutinative language toolkit")
    sp = p.add_subparsers(dest="command", required=True)

    g = sp.add_parser("generate-dictionary", help="Generate root dictionary using g4f")
    g.add_argument("--count", type=int, default=96, help="Number of roots")
    g.add_argument("--model", default="gpt-5-mini", help="g4f model name")
    g.add_argument("--out", default="data/dictionary.json", help="Output dictionary JSON")
    g.set_defaults(func=_cmd_generate_dictionary)

    t = sp.add_parser("translate", help="Translate between English and symbol language")
    t.add_argument("--dict", default="data/dictionary.json", help="Input dictionary JSON")
    t.add_argument("--text", required=True, help="Text to translate")
    t.add_argument("--reverse", action="store_true", help="Translate from language to English")
    t.set_defaults(func=_cmd_translate)

    l = sp.add_parser("build-language-pack", help="Build concepts and grammar reference JSON files")
    l.add_argument("--dict", default="data/dictionary.json", help="Input dictionary JSON")
    l.add_argument("--concepts-out", default="data/concepts.json", help="Output concepts JSON")
    l.add_argument("--grammar-out", default="data/grammar_reference.json", help="Output grammar reference JSON")
    l.set_defaults(func=_cmd_build_language_pack)

    return p


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
