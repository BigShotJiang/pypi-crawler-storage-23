"""Argus-Ops: AI-powered infrastructure monitoring and remediation CLI."""

__version__ = "0.4.0"
