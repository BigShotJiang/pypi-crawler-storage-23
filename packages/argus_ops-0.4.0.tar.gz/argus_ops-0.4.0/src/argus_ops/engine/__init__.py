"""Core orchestration engine."""
from argus_ops.engine.pipeline import Pipeline

__all__ = ['Pipeline']
