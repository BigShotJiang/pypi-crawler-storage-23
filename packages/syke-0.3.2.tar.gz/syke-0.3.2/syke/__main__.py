"""Entry point: python -m syke"""

from syke.cli import cli

if __name__ == "__main__":
    cli()
