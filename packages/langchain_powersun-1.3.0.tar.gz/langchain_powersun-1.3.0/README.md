# langchain-powersun

LangChain integration for [PowerSun.vip](https://powersun.vip) — the TRON Energy & Bandwidth marketplace and DEX swap aggregator for AI agents.

## Install

```bash
pip install langchain-powersun
```

## Quick Start

```python
from langchain_powersun import PowerSunToolkit

# Public tools (market data, estimates)
tools = PowerSunToolkit().get_tools()

# With authentication (buy energy, check balance)
tools = PowerSunToolkit(api_key="ps_your_key").get_tools()

# Use with any LangChain agent
from langchain.agents import create_react_agent
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o")
agent = create_react_agent(llm, tools)
agent.invoke({"input": "What's the current price of TRON energy on PowerSun?"})
```

## Available Tools (12)

### Registration Tools (public, no auth required)

| Tool | Description |
|------|-------------|
| `powersun_register` | Start registration — get a challenge to sign with your TRON wallet |
| `powersun_verify_registration` | Submit wallet signature → get API key |

### Market Tools (public, no auth required)

| Tool | Description |
|------|-------------|
| `powersun_get_prices` | Energy & Bandwidth prices for all duration tiers |
| `powersun_estimate_cost` | Calculate exact cost for transactions |
| `powersun_get_available_resources` | Available Energy & Bandwidth |
| `powersun_get_market_overview` | Full market snapshot |

### Buyer Tools (auth recommended)

| Tool | Description |
|------|-------------|
| `powersun_buy_energy` | Purchase Energy delegation |
| `powersun_get_balance` | Account balance and deposit info |
| `powersun_get_order_status` | Order status with delegation progress |
| `powersun_broadcast_transaction` | Broadcast pre-signed tx with auto Energy (API key, x402, or 402) |

### Swap Tools (auth required)

| Tool | Description |
|------|-------------|
| `powersun_get_swap_quote` | Get swap quote for SunSwap DEX (TRX, USDT, USDC, SUN, BTT, WIN, JST, any TRC-20) |
| `powersun_execute_swap` | Execute signed swap TX with auto Energy (API key, x402, or 402) |

## Why PowerSun?

- **Only 10% commission** — lowest on the market
- **Save 20-50%** on TRON transaction fees
- **Instant delegation** — Energy arrives within seconds
- **AI-native** — built for autonomous agent workflows

## Links

- **Platform:** [powersun.vip](https://powersun.vip)
- **MCP Server:** [powersun.vip/mcp](https://powersun.vip/mcp)
- **API Docs:** [powersun.vip/api-docs](https://powersun.vip/api-docs)

## License

MIT
