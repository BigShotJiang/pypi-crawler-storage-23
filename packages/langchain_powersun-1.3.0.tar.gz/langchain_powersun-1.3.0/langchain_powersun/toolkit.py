"""PowerSun toolkit — provides all tools as a ready-to-use collection."""

from __future__ import annotations

from typing import List

from langchain_core.tools import BaseTool

from langchain_powersun.client import PowerSunClient
from langchain_powersun.tools import ALL_TOOLS


class PowerSunToolkit:
    """LangChain toolkit for PowerSun.vip TRON Energy marketplace.

    Usage::

        from langchain_powersun import PowerSunToolkit

        # Public tools only (market data)
        tools = PowerSunToolkit().get_tools()

        # With authentication (buy energy, check balance)
        tools = PowerSunToolkit(api_key="ps_your_key").get_tools()

        # Use with any LangChain agent
        from langchain.agents import create_react_agent
        agent = create_react_agent(llm, tools)
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = "https://powersun.vip",
    ):
        self.client = PowerSunClient(api_key=api_key, base_url=base_url)

    def get_tools(self) -> List[BaseTool]:
        """Return all PowerSun tools with the configured client."""
        return [tool_cls(client=self.client) for tool_cls in ALL_TOOLS]
