"""Entry point for lockin CLI."""

from lockin.cli import main

if __name__ == "__main__":
    main()
