"""Lockin — CLI focus blocker for macOS."""

__version__ = "0.5.0"
