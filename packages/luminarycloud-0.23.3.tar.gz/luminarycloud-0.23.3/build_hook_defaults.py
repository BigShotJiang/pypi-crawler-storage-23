import importlib.util
import json
import os
import shutil
import sys
import tempfile
from typing import Any

from hatchling.builders.hooks.plugin.interface import BuildHookInterface

"""
Custom build hook to allow build-time configuration of certain SDK defaults.
If the environment variable SDK_DEFAULTS is set to some JSON string, this build hook will:
    1. validate the JSON (see script/validate_defaults.py for details)
    2. make a backup of the existing defaults.json
    3. write SDK_DEFAULTS to defaults.json

(Build the wheel)

    4. restore the backup so that the SDK source is unmodified
"""


class CustomBuildHook(BuildHookInterface):
    _sdk_defaults_path = ""
    _temp_dir = None
    _temp_defaults_path = ""
    _wrote_defaults = False

    # This is ugly but it lets the SDK validate at runtime while preventing us from duplicating
    # the validation logic here
    def _import_validator(self) -> Any:
        if "_validate_defaults" in sys.modules:
            return sys.modules["_validate_defaults"]

        module_path = os.path.join(
            os.path.dirname(__file__), "luminarycloud", "_config", "_validate_defaults.py"
        )
        spec = importlib.util.spec_from_file_location("_validate_defaults", module_path)
        assert spec is not None
        mod = importlib.util.module_from_spec(spec)
        sys.modules["_validate_defaults"] = mod
        assert spec.loader is not None
        spec.loader.exec_module(mod)
        print(f"Loaded _validate_defaults from {module_path}")

        return mod

    def initialize(self, version: str, build_data: dict) -> None:
        super().initialize(version, build_data)
        print("build_hook_defaults start")
        self._sdk_defaults_path = os.path.join(
            self.root, "luminarycloud", "_config", "defaults.json"
        )
        env_defaults = os.environ.get("SDK_DEFAULTS")
        if env_defaults:
            print("SDK_DEFAULTS provided")
            defaults = json.loads(env_defaults)
            _validate = self._import_validator()
            _validate.validate_defaults(defaults)

            self._temp_dir = tempfile.TemporaryDirectory()
            self._temp_defaults_path = os.path.join(self._temp_dir.name, "defaults.json")
            shutil.copy2(self._sdk_defaults_path, self._temp_defaults_path)
            print(f"Copied existing defaults.json to {self._temp_defaults_path}")

            with open(self._sdk_defaults_path, "w") as f:
                f.write(os.environ["SDK_DEFAULTS"])
                self._wrote_defaults = True

    def finalize(self, version: str, build_data: dict[str, Any], artifact_path: str) -> None:
        super().finalize(version, build_data, artifact_path)
        if self._wrote_defaults:
            assert self._temp_dir is not None
            shutil.copy2(self._temp_defaults_path, self._sdk_defaults_path)
            print(f"Restored defaults.json from {self._temp_defaults_path}")
        if self._temp_dir:
            self._temp_dir.cleanup()
            print(f"Cleaned up {self._temp_dir.name}")
        print("build_hook_defaults finalized")
