# Copyright 2025 Luminary Cloud, Inc. All Rights Reserved.
from datetime import datetime

from .._client import get_default_client
from .._proto.api.v0.luminarycloud.physics_ai import physics_ai_pb2 as physaipb
from .._proto.base import base_pb2 as basepb
from .._wrapper import ProtoWrapper, ProtoWrapperBase
from ..types.ids import PhysicsAiArchitectureVersionID, PhysicsAiTrainingJobID


def get_training_job(training_job_id: PhysicsAiTrainingJobID) -> "PhysicsAiTrainingJob":
    """
    Get a Physics AI training job by ID.

    Args:
        training_job_id: The ID of the training job to retrieve.

    Returns:
        The training job.
    """
    req = physaipb.GetTrainingJobRequest(training_job_id=training_job_id)
    resp = get_default_client().GetTrainingJob(req)
    return PhysicsAiTrainingJob(resp.training_job)


@ProtoWrapper(physaipb.PhysicsAiTrainingJob)
class PhysicsAiTrainingJob(ProtoWrapperBase):
    """
    Represents a Physics AI training job.
    """

    id: str
    architecture_version_id: PhysicsAiArchitectureVersionID
    user_id: str
    training_config: str
    training_data_source_type: physaipb.TrainingDataSourceType
    training_description: str
    external_dataset_uri: str
    dataset_id: str
    initialization_type: physaipb.ModelInitializationType
    base_model_version_id: str
    status: basepb.JobStatus
    error_message: str
    output_model_version_id: str
    creation_time: datetime
    update_time: datetime
    _proto: physaipb.PhysicsAiTrainingJob

    def get_status(self) -> str:
        return basepb.JobStatusType.Name(self.status.typ)

    def cancel(self) -> None:
        """
        Cancel this training job.

        This method requests cancellation of the training job. If the job is already
        suspended or suspending, this is a no-op.
        """
        req = physaipb.CancelTrainingJobRequest(training_job_id=self.id)
        get_default_client().CancelTrainingJob(req)

    def list_checkpoints(self) -> list["TrainingCheckpointEntry"]:
        """
        List training checkpoints for this job.

        Parameters
        ----------
        epoch : List[int], optional
            Filter by epoch. If not provided, returns checkpoints from all epochs.

        Returns
        -------
        List[TrainingCheckpointEntry]
            A list of training checkpoint entries, ordered by epoch ascending.
        """
        req = physaipb.ListTrainingCheckpointsRequest(training_job_id=self.id)
        response = get_default_client().ListTrainingCheckpoints(req)
        return [TrainingCheckpointEntry(entry) for entry in response.checkpoints]


@ProtoWrapper(physaipb.TrainingCheckpointEntry)
class TrainingCheckpointEntry(ProtoWrapperBase):
    """
    Represents a training checkpoint entry.
    Includes checkpoint data (train loss, val loss, and learning rate)
    """

    id: str
    training_job_id: PhysicsAiTrainingJobID
    run_id: str
    epoch: int
    creation_time: datetime
    best_val_loss: float | None
    is_best_model: bool
    train_loss: float | None
    val_loss: float | None
    learning_rate: float | None


def list_training_jobs() -> list[PhysicsAiTrainingJob]:
    """
    List Physics AI training jobs for the current user.

    Returns
    -------
    List[PhysicsAiTrainingJob]
        A list of training jobs, ordered by creation time (newest first).

    Examples
    --------
    List all training jobs:

    >>> jobs = list_training_jobs()
    >>> for job in jobs:
    ...     print(f"{job.id}: {job.get_status()}")
    """
    req = physaipb.ListTrainingJobsRequest()
    response = get_default_client().ListTrainingJobs(req)
    return [PhysicsAiTrainingJob(job) for job in response.training_jobs]
