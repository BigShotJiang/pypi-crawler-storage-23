# Copyright 2025 Luminary Cloud, Inc. All Rights Reserved.
import copy
from dataclasses import dataclass, field
import json
from typing import Any

from google.protobuf.json_format import ParseDict
from google.protobuf.struct_pb2 import Struct

from .._client import get_default_client
from .._proto.api.v0.luminarycloud.physics_ai import physics_ai_pb2 as physaipb
from .._proto.quantity import quantity_pb2 as quantitypb
from .._wrapper import ProtoWrapper, ProtoWrapperBase
from ..types.ids import PhysicsAiArchitectureID, PhysicsAiArchitectureVersionID
from ..enum.physics_ai_lifecycle_state import PhysicsAiLifecycleState
from ..enum.quantity_type import QuantityType, _get_quantity_metadata

from .training_jobs import PhysicsAiTrainingJob


@dataclass
class OutputQuantity:
    """An output quantity with optional per-component bounds for extreme sample filtering.

    For scalars, bounds is a single (min, max) tuple.
    For vectors, bounds can be:
      - A single (min, max) tuple applied uniformly to all components
      - A list of (min, max) tuples, one per component

    Examples
    --------
    >>> OutputQuantity(QuantityType.PRESSURE_TIME_AVERAGE, bounds=(0.0, 7.2e4))
    >>> OutputQuantity(QuantityType.WALL_SHEAR_STRESS_TIME_AVERAGE, bounds=(-1e4, 1e4))
    >>> OutputQuantity(QuantityType.WALL_SHEAR_STRESS_TIME_AVERAGE,
    ...     bounds=[(-1e4, 1e4), (-500, 500), (-500, 500)])
    """

    quantity: QuantityType
    bounds: tuple[float, float] | list[tuple[float, float]] | None = None


@dataclass
class ModelOutputs:
    """
    Defines the output variables for the model.

    Parameters
    ----------
    surface : list[QuantityType | OutputQuantity], optional
        Surface outputs to predict (e.g., PRESSURE, WALL_SHEAR_STRESS).
        Each item can be a bare QuantityType or an OutputQuantity with bounds.
    volume : list[QuantityType | OutputQuantity], optional
        Volume outputs to predict (e.g., VELOCITY, PRESSURE).
        Each item can be a bare QuantityType or an OutputQuantity with bounds.
    """

    surface: list[QuantityType | OutputQuantity] | None = None
    volume: list[QuantityType | OutputQuantity] | None = None


@dataclass
class InputParameter:
    """
    Defines an input parameter for the model with reference values for normalization.

    Type is inherited from the dataset's ParameterSchema, so only the name and
    optional reference values need to be specified here.

    Parameters
    ----------
    name : str
        Parameter name (must exist in the dataset's ParameterSchema)
    reference : list[float], optional
        Reference value(s) for normalization. If not provided, falls back to
        the default_reference from the dataset's ParameterSchema. For scalars,
        a single-element list. For vectors, the number of elements must match
        the dimension from the schema.

    Examples
    --------
    >>> # Use schema defaults (no reference specified)
    >>> air_density = InputParameter(name="air_density")
    >>> # Override with custom reference values
    >>> velocity = InputParameter(name="inlet_velocity", reference=[30.0, 0.0, 0.0])
    >>> # Scalar parameter with explicit reference
    >>> stream_velocity = InputParameter(name="stream_velocity", reference=[148.28])
    """

    name: str
    reference: list[float] = field(default_factory=list)


@ProtoWrapper(physaipb.PhysicsAiArchitectureVersion)
class PhysicsAiArchitectureVersion(ProtoWrapperBase):
    """
    Represents a specific version of a Physics AI architecture.

    .. warning:: This feature is experimental and may change or be removed without notice.
    """

    id: PhysicsAiArchitectureVersionID
    name: str
    architecture_name: str
    changelog: str
    lifecycle_state: PhysicsAiLifecycleState
    _proto: physaipb.PhysicsAiArchitectureVersion

    def train(
        self,
        dataset_id: str,
        outputs: ModelOutputs | None = None,
        inputs: list[InputParameter] | None = None,
    ) -> PhysicsAiTrainingJob:
        """
        Submit a training job for this architecture version.

        Parameters
        ----------
        dataset_id : str
            ID of a managed dataset to train on.
        outputs : ModelOutputs, optional
            Output variables for the model (surface and/or volume quantities).
        inputs : list[InputParameter], optional
            Input parameters for the model with reference values for normalization.
            Parameter names must exist in the dataset's ParameterSchema.

        Returns
        -------
        PhysicsAiTrainingJob
            The submitted training job object

        Examples
        --------
        >>> from luminarycloud.enum.quantity_type import QuantityType
        >>> from luminarycloud.physics_ai.architectures import ModelOutputs, InputParameter
        >>>
        >>> job = arch_version.train(
        ...     dataset_id="dataset-abc123",
        ...     outputs=ModelOutputs(
        ...         surface=[QuantityType.PRESSURE_TIME_AVERAGE, QuantityType.WALL_SHEAR_STRESS_TIME_AVERAGE],
        ...         volume=[QuantityType.VELOCITY_TIME_AVERAGE],
        ...     ),
        ...     inputs=[
        ...         InputParameter(name="stream_velocity", reference=[148.28]),
        ...         InputParameter(name="air_density", reference=[0.38]),
        ...     ],
        ... )
        """
        return _internal_train(
            architecture_version=self,
            dataset_id=dataset_id,
            outputs=outputs,
            inputs=inputs,
        )


def _build_output_quantities(
    items: list[QuantityType | OutputQuantity],
) -> list[physaipb.TrainingOutputQuantity]:
    """Convert SDK output types to proto TrainingOutputQuantity messages.

    Bare QuantityType -> TrainingOutputQuantity with no bounds.
    OutputQuantity with tuple bounds -> expand to per-component bounds.
    OutputQuantity with list[tuple] bounds -> pass through per-component.
    """
    result: list[physaipb.TrainingOutputQuantity] = []
    for item in items:
        if isinstance(item, QuantityType):
            result.append(
                physaipb.TrainingOutputQuantity(
                    quantity_type=quantitypb.QuantityType.Value(item.name),
                )
            )
        elif isinstance(item, OutputQuantity):
            qt = quantitypb.QuantityType.Value(item.quantity.name)
            meta = _get_quantity_metadata(item.quantity)
            component_count = meta.size  # 1 for scalar, 3 for vector

            if item.bounds is None:
                result.append(physaipb.TrainingOutputQuantity(quantity_type=qt))
            elif isinstance(item.bounds, tuple):
                # Single (min, max) -> expand to all components
                lo, hi = item.bounds
                if lo >= hi:
                    raise ValueError(
                        f"bounds_min ({lo}) must be less than bounds_max ({hi}) "
                        f"for {item.quantity.name}"
                    )
                result.append(
                    physaipb.TrainingOutputQuantity(
                        quantity_type=qt,
                        bounds_min=[lo] * component_count,
                        bounds_max=[hi] * component_count,
                    )
                )
            elif isinstance(item.bounds, list):
                # List of (min, max) tuples, one per component
                if len(item.bounds) != component_count:
                    raise ValueError(
                        f"bounds list length ({len(item.bounds)}) must match component count "
                        f"({component_count}) for {item.quantity.name}"
                    )
                bounds_min = []
                bounds_max = []
                for lo, hi in item.bounds:
                    if lo >= hi:
                        raise ValueError(
                            f"bounds_min ({lo}) must be less than bounds_max ({hi}) "
                            f"for {item.quantity.name}"
                        )
                    bounds_min.append(lo)
                    bounds_max.append(hi)
                result.append(
                    physaipb.TrainingOutputQuantity(
                        quantity_type=qt,
                        bounds_min=bounds_min,
                        bounds_max=bounds_max,
                    )
                )
            else:
                raise ValueError(
                    f"Invalid bounds type for {item.quantity.name}: {type(item.bounds)}"
                )
        else:
            raise ValueError(f"Invalid output type: {type(item)}")
    return result


def _internal_train(
    architecture_version: PhysicsAiArchitectureVersion,
    dataset_id: str | None = None,
    outputs: ModelOutputs | None = None,
    inputs: list[InputParameter] | None = None,
    hyperparameters: dict[str, Any] | None = None,
    config: dict | None = None,
) -> PhysicsAiTrainingJob:
    """
    Submit a training job with internal configuration options.

    This is an internal function.
    Not part of the public SDK API. May change without notice.
    """
    # Build typed proto fields for outputs
    surface_outputs: list[physaipb.TrainingOutputQuantity] = []
    volume_outputs: list[physaipb.TrainingOutputQuantity] = []

    if outputs:
        if outputs.surface:
            surface_outputs = _build_output_quantities(outputs.surface)
        if outputs.volume:
            volume_outputs = _build_output_quantities(outputs.volume)

    # Type is inherited from the dataset's ParameterSchema at HydraConfig generation time
    input_parameters: list[physaipb.TrainingInputParameter] = []
    if inputs:
        for param in inputs:
            input_parameters.append(
                physaipb.TrainingInputParameter(
                    name=param.name,
                    reference=param.reference,
                )
            )

    # Build training_config JSON for internal fields only (resources, priority_class, etc.)
    internal_config: dict = copy.deepcopy(config) if config else {}

    # Apply defaults for internal fields
    internal_config.setdefault("custom_args", "")
    internal_config.setdefault("priority_class", "internal-training-job-priority")
    internal_config.setdefault("resources", {})
    internal_config["resources"].setdefault("process_cpus", 8)
    internal_config["resources"].setdefault("train_gpus", 1)
    internal_config["resources"].setdefault("test_gpus", 1)
    internal_config.setdefault("mode", "full")

    training_config_json = json.dumps(internal_config, indent=2)

    # Convert hyperparameters dict to Struct proto (if provided)
    hyperparameters_struct = None
    if hyperparameters:
        hyperparameters_struct = ParseDict(hyperparameters, Struct())

    # Build training description
    if internal_config.get("description"):
        description = internal_config["description"]
    else:
        description = f"Training job for architecture {architecture_version.name}"
        if internal_config.get("custom_args"):
            description += f" with custom args: {internal_config['custom_args']}"

    req = physaipb.SubmitTrainingJobRequest(
        architecture_version_id=architecture_version.id,
        training_description=description,
        training_config=training_config_json,
        initialization_type=physaipb.MODEL_INITIALIZATION_TYPE_RANDOM,
        base_model_version_id="",
        dataset_id=dataset_id if dataset_id else "",
        surface_outputs=surface_outputs,
        volume_outputs=volume_outputs,
        input_parameters=input_parameters,
        hyperparameters=hyperparameters_struct,
    )

    response = get_default_client().SubmitTrainingJob(req)

    return PhysicsAiTrainingJob(response.training_job)


@ProtoWrapper(physaipb.PhysicsAiArchitecture)
class PhysicsAiArchitecture(ProtoWrapperBase):
    """
    Represents a Physics AI architecture with all its versions.

    .. warning:: This feature is experimental and may change or be removed without notice.
    """

    id: PhysicsAiArchitectureID
    name: str
    description: str
    versions: list[PhysicsAiArchitectureVersion]
    _proto: physaipb.PhysicsAiArchitecture

    def get_latest_version(self) -> PhysicsAiArchitectureVersion | None:
        """
        Get the latest version of this architecture based on name.

        Returns
        -------
        PhysicsAiArchitectureVersion or None
            The first architecture version, or None if no versions exist.
            Note: Version ordering is now determined by the backend.
        """
        if not self.versions:
            return None
        return self.versions[0]


def list_architectures() -> list[PhysicsAiArchitecture]:
    """
    List available Physics AI architectures for model training.

    .. warning:: This feature is experimental and may change or be removed without notice.

    Returns
    -------
    list[PhysicsAiArchitecture]
        A list of all available Physics AI architectures.
    """
    req = physaipb.ListArchitecturesRequest()
    res = get_default_client().ListArchitectures(req)
    return [PhysicsAiArchitecture(arch) for arch in res.architectures]
