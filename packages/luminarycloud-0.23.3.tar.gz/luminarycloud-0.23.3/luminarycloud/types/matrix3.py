# Copyright 2023-2024 Luminary Cloud, Inc. All Rights Reserved.
from dataclasses import dataclass, field

from .._proto.base import base_pb2 as basepb
from .vector3 import Vector3


@dataclass
class Matrix3:
    """Represents a 3x3 matrix."""

    a: Vector3 = field(default_factory=Vector3)
    b: Vector3 = field(default_factory=Vector3)
    c: Vector3 = field(default_factory=Vector3)

    def _to_proto(self) -> basepb.Matrix3:
        return basepb.Matrix3(
            a=self.a._to_base_proto(),
            b=self.b._to_base_proto(),
            c=self.c._to_base_proto(),
        )

    def _to_ad_proto(self) -> basepb.AdMatrix3:
        return basepb.AdMatrix3(
            a=self.a._to_ad_proto(),
            b=self.b._to_ad_proto(),
            c=self.c._to_ad_proto(),
        )

    def _from_proto(self, proto: basepb.Matrix3) -> None:
        self.a._from_base_proto(proto.a)
        self.b._from_base_proto(proto.b)
        self.c._from_base_proto(proto.c)

    def _from_ad_proto(self, proto: basepb.AdMatrix3) -> None:
        self.a._from_ad_proto(proto.a)
        self.b._from_ad_proto(proto.b)
        self.c._from_ad_proto(proto.c)
