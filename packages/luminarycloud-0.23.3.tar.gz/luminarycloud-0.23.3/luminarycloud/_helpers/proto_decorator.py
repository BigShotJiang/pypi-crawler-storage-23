# Copyright 2025 Luminary Cloud, Inc. All Rights Reserved.
from typing import (
    Generic,
    TypeVar,
    get_type_hints,
)

from google.protobuf.descriptor import FieldDescriptor
from google.protobuf.message import Message

from luminarycloud._proto.api.v0.luminarycloud.common import common_pb2 as commonpb
from luminarycloud._proto.base import base_pb2 as basepb
from luminarycloud.types import LcFloat, Vector3
from luminarycloud.types.adfloat import _from_ad_proto, _lcfloat_to_float, _to_ad_proto
from luminarycloud.types.vector3 import (
    _to_vector3_ad_proto,
    _to_vector3_base_proto,
    _to_vector3_proto,
)

P = TypeVar("P", bound=Message)
C = TypeVar("C")


# Abstract mixin to satisfy the type checker when using `@proto_decorator`.
# Declares statically that `_to_proto` and `_from_proto` will be added by the decorator.
class ProtoConvertible(Generic[P]):
    def _to_proto(self) -> P: ...

    def _from_proto(self, proto: P) -> None: ...


class proto_decorator(Generic[P]):
    """
    A decorator that adds `_to_proto` and `_from_proto` methods to instances of a class and a
    `from_proto` method to the class.

    NOTE: only works for primitive, Vector3, AdFloatType, and AdVector3 fields right now.
    """

    proto_type: type[P]

    def __init__(decorator, proto_type: type[P]):
        decorator.proto_type = proto_type

    def __call__(decorator, cls: type[C]) -> type[C]:
        type_hints = get_type_hints(cls)
        proto_fields: list[FieldDescriptor] = decorator.proto_type.DESCRIPTOR.fields

        def _to_proto(self: type[C]) -> P:
            proto = decorator.proto_type()
            for proto_field in proto_fields:
                if proto_field.name not in type_hints:
                    continue  # don't try to match fields that aren't in the wrapper class
                value = getattr(self, proto_field.name)
                proto_value = getattr(proto, proto_field.name)
                if isinstance(proto_value, basepb.AdFloatType):
                    proto_value.CopyFrom(_to_ad_proto(value))
                elif isinstance(proto_value, basepb.AdVector3):
                    proto_value.CopyFrom(_to_vector3_ad_proto(value))
                elif isinstance(proto_value, basepb.Vector3):
                    proto_value.CopyFrom(_to_vector3_base_proto(value))
                elif isinstance(proto_value, commonpb.Vector3):
                    proto_value.CopyFrom(_to_vector3_proto(value))
                elif isinstance(proto_value, Message):
                    proto_value.CopyFrom(value._to_proto())
                else:  # proto field is primitive type
                    if isinstance(value, LcFloat):
                        proto_value = _lcfloat_to_float(value)
                    else:
                        setattr(proto, proto_field.name, value)
            return proto

        setattr(cls, "_to_proto", _to_proto)

        def _from_proto(self: type[C], proto: type[P]) -> None:
            for proto_field in proto_fields:
                _type = type_hints.get(proto_field.name, None)
                if not _type:
                    continue  # don't try to match fields that aren't in the wrapper class
                proto_value = getattr(proto, proto_field.name)
                if isinstance(proto_value, basepb.AdFloatType):
                    setattr(self, proto_field.name, _from_ad_proto(proto_value))
                elif issubclass(_type, Vector3):
                    vec = getattr(self, proto_field.name)
                    if isinstance(proto_value, basepb.Vector3):
                        vec._from_proto(proto_value)
                    elif isinstance(proto_value, basepb.AdVector3):
                        vec._from_ad_proto(proto_value)
                else:
                    setattr(self, proto_field.name, proto_value)
            return None

        setattr(cls, "_from_proto", _from_proto)

        return cls
