# Copyright 2026 Luminary Cloud, Inc. All Rights Reserved.

# This is a separate file with no dependencies outside the standard library to allow validating
# defaults at build time.

from typing import Any


def validate_defaults(defaults: dict[str, Any]) -> None:
    assert "LC_DOMAIN" in defaults, "LC_DOMAIN must be defined"

    assert "INTERACTIVE_AUTH_ENABLED" in defaults, "INTERACTIVE_AUTH_ENABLED must be defined"
    assert isinstance(defaults["INTERACTIVE_AUTH_ENABLED"], bool)
    if defaults["INTERACTIVE_AUTH_ENABLED"]:
        msg = "Auth0 information must be defined if interactive auth is enabled"
        assert "LC_AUTH_DOMAIN" in defaults, msg
        assert "LC_AUTH_CLIENT_ID" in defaults, msg
        assert "LC_AUTH_SERVICE_ID" in defaults, msg
        assert "ALLOWED_CALLBACK_PORTS" in defaults, msg
