# Copyright 2026 Luminary Cloud, Inc. All Rights Reserved.
import json
import os
import platform
from typing import List, cast

from dotenv import load_dotenv

from ._validate_defaults import validate_defaults

load_dotenv()

with open(os.path.join(os.path.dirname(__file__), "defaults.json"), "r") as f:
    defaults = json.load(f)
    validate_defaults(defaults)

    LC_DOMAIN: str = os.getenv("LC_DOMAIN") or defaults["LC_DOMAIN"]
    INTERACTIVE_AUTH_ENABLED: bool = defaults["INTERACTIVE_AUTH_ENABLED"]
    if INTERACTIVE_AUTH_ENABLED:
        # Default to the credentials defined in defaults.json.
        # For the PyPI release, this is the prod tenant.
        LC_AUTH_DOMAIN: str = os.getenv("LC_AUTH_DOMAIN") or defaults["LC_AUTH_DOMAIN"]
        LC_AUTH_CLIENT_ID: str = os.getenv("LC_AUTH_CLIENT_ID") or defaults["LC_AUTH_CLIENT_ID"]
        LC_AUTH_SERVICE_ID: str = os.getenv("LC_AUTH_SERVICE_ID") or defaults["LC_AUTH_SERVICE_ID"]

        # These should match the `allowed_callbacks` field in the Auth0 application configuration.
        # https://en.wikipedia.org/wiki/List_of_TCP_and_UDP_port_numbers
        ALLOWED_CALLBACK_PORTS: List[int] = defaults["ALLOWED_CALLBACK_PORTS"]
        LC_REFRESH_ROTATION = os.environ.get("LC_REFRESH_ROTATION", "").upper() == "TRUE"
    else:
        LC_AUTH_DOMAIN = ""
        LC_AUTH_CLIENT_ID = ""
        LC_AUTH_SERVICE_ID = ""
        ALLOWED_CALLBACK_PORTS = []
        LC_REFRESH_ROTATION = False

LC_API_KEY = os.getenv("LC_API_KEY")

TIMEOUT = 5

LC_CREDENTIALS_DIR = os.getenv("LC_CREDENTIALS_DIR")
if LC_CREDENTIALS_DIR is None:
    system = platform.system()
    if system in ["Linux", "Darwin"]:
        LC_CREDENTIALS_DIR = os.path.expanduser("~/.config/luminarycloud")
    elif system == "Windows" and os.getenv("APPDATA"):
        APPDATA = cast(str, os.getenv("APPDATA"))
        LC_CREDENTIALS_DIR = os.path.join(APPDATA, "Roaming/luminarycloud")
