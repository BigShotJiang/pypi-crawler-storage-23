from enum import Enum
from .._proto.api.v0.luminarycloud.simulation import simulation_pb2 as simulationpb
from .._proto.clusterconfig import clusterconfig_pb2 as clusterconfigpb


# We don't inherit from StrEnum because that was added in Python 3.11, but we still want to support
# older versions. Inheriting from str and Enum gives us the StrEnum-like behavior we want.
class GPUType(str, Enum):
    """
    Represents a GPU type.
    """

    UNSPECIFIED = "unspecified"
    CPU = "cpu"
    T4 = "t4"
    V100 = "v100"
    A100 = "a100"
    A100_80 = "a100_80"
    H100 = "h100"

    def __str__(self) -> str:
        return self.value

    def _to_sim_options_gpu_type(self) -> int:
        if self == GPUType.UNSPECIFIED:
            return simulationpb.SimulationOptions.GPU_TYPE_UNSPECIFIED
        elif self == GPUType.T4:
            return simulationpb.SimulationOptions.GPU_TYPE_T4
        elif self == GPUType.V100:
            return simulationpb.SimulationOptions.GPU_TYPE_V100
        elif self == GPUType.A100:
            return simulationpb.SimulationOptions.GPU_TYPE_A100
        elif self == GPUType.H100:
            return simulationpb.SimulationOptions.GPU_TYPE_H100
        else:
            raise ValueError(f"Invalid GPU type: {self.value}")

    def _to_clusterconfig_gpu_type(self) -> int:
        if self == GPUType.UNSPECIFIED:
            return clusterconfigpb.GPUType.UNSPECIFIED
        elif self == GPUType.CPU:
            return clusterconfigpb.GPUType.CPU
        elif self == GPUType.T4:
            return clusterconfigpb.GPUType.T4
        elif self == GPUType.V100:
            return clusterconfigpb.GPUType.V100
        elif self == GPUType.A100:
            return clusterconfigpb.GPUType.A100
        elif self == GPUType.A100_80:
            return clusterconfigpb.GPUType.A100_80
        elif self == GPUType.H100:
            return clusterconfigpb.GPUType.H100
        else:
            raise ValueError(f"Invalid GPU type: {self.value}")
