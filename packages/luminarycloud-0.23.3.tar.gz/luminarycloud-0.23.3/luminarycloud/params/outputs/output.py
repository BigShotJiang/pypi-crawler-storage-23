# Copyright 2024 Luminary Cloud, Inc. All Rights Reserved.

from dataclasses import dataclass
from luminarycloud.params._lib import ParamGroupWrapper
from luminarycloud._helpers import CodeRepr
from luminarycloud._proto.output import output_pb2 as outputpb


@dataclass(kw_only=True)
class Output(CodeRepr, ParamGroupWrapper[outputpb.Output]):
    """
    Represents a quantity that can be extracted from the output of a simulation via an
    OutputDefinition ID.

    NOTE: This class is only used to represent outputs in SimulationParam, for example to setup
    adjoint analysis or nonlinear control equations. The interface to define and download outputs
    uses OutputDefinition directly.
    """

    name: str = ""
    "The name of the output."
    output_definition_id: str = ""
    "The ID of the output def"

    def _to_proto(self) -> outputpb.Output:
        _proto = outputpb.Output()
        _proto.name = self.name
        _proto.id = self.output_definition_id
        return _proto

    def _from_proto(self, proto: outputpb.Output) -> None:
        self.name = proto.name
        self.output_definition_id = proto.id
