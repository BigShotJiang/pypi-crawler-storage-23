# Copyright 2024 Luminary Cloud, Inc. All Rights Reserved.
from dataclasses import dataclass

from luminarycloud._helpers import CodeRepr
from luminarycloud._helpers.proto_decorator import ProtoConvertible, proto_decorator
from luminarycloud._proto.cad import shape_pb2 as shapepb
from luminarycloud.types import Vector3
from luminarycloud.types.adfloat import LcFloat
from luminarycloud.types.vector3 import Vector3Like, _to_vector3


class Shape(CodeRepr, ProtoConvertible):
    pass


@dataclass(kw_only=True)
@proto_decorator(shapepb.Sphere)
class Sphere(Shape):
    center: Vector3
    radius: LcFloat

    def __init__(
        self,
        *,
        center: Vector3Like | None = None,
        radius: float = 0.0,
    ):
        self.center = _to_vector3(center)
        self.radius = radius


@dataclass(kw_only=True)
@proto_decorator(shapepb.SphereShell)
class SphereShell(Shape):
    center: Vector3
    radius: float
    radius_inner: float

    def __init__(
        self,
        *,
        center: Vector3Like | None = None,
        radius: float = 0.0,
        radius_inner: float = 0.0,
    ):
        self.center = _to_vector3(center)
        self.radius = radius
        self.radius_inner = radius_inner


@dataclass(kw_only=True)
@proto_decorator(shapepb.HalfSphere)
class HalfSphere(Shape):
    center: Vector3
    radius: LcFloat
    normal: Vector3

    def __init__(
        self,
        *,
        center: Vector3Like | None = None,
        radius: float = 0.0,
        normal: Vector3Like | None = None,
    ):
        self.center = _to_vector3(center)
        self.radius = radius
        self.normal = _to_vector3(normal)


@dataclass(kw_only=True)
@proto_decorator(shapepb.Cube)
class Cube(Shape):
    min: Vector3
    max: Vector3

    def __init__(
        self,
        *,
        min: Vector3Like | None = None,
        max: Vector3Like | None = None,
    ):
        self.min = _to_vector3(min)
        self.max = _to_vector3(max)


@dataclass(kw_only=True)
@proto_decorator(shapepb.OrientedCube)
class OrientedCube(Shape):
    min: Vector3
    max: Vector3
    origin: Vector3
    x_axis: Vector3
    y_axis: Vector3

    def __init__(
        self,
        *,
        min: Vector3Like | None = None,
        max: Vector3Like | None = None,
        origin: Vector3Like | None = None,
        x_axis: Vector3Like | None = None,
        y_axis: Vector3Like | None = None,
    ):
        self.min = _to_vector3(min)
        self.max = _to_vector3(max)
        self.origin = _to_vector3(origin)
        self.x_axis = _to_vector3(x_axis)
        self.y_axis = _to_vector3(y_axis)


@dataclass(kw_only=True)
@proto_decorator(shapepb.Cylinder)
class Cylinder(Shape):
    start: Vector3
    end: Vector3
    radius: LcFloat

    def __init__(
        self,
        *,
        start: Vector3Like | None = None,
        end: Vector3Like | None = None,
        radius: float = 0.0,
    ):
        self.start = _to_vector3(start)
        self.end = _to_vector3(end)
        self.radius = radius


@dataclass(kw_only=True)
@proto_decorator(shapepb.AnnularCylinder)
class AnnularCylinder(Shape):
    start: Vector3
    end: Vector3
    radius: float
    radius_inner: float

    def __init__(
        self,
        *,
        start: Vector3Like | None = None,
        end: Vector3Like | None = None,
        radius: float = 0.0,
        radius_inner: float = 0.0,
    ):
        self.start = _to_vector3(start)
        self.end = _to_vector3(end)
        self.radius = radius
        self.radius_inner = radius_inner


@dataclass(kw_only=True)
@proto_decorator(shapepb.Torus)
class Torus(Shape):
    center: Vector3
    normal: Vector3
    major_radius: float
    minor_radius: float

    def __init__(
        self,
        *,
        center: Vector3Like | None = None,
        normal: Vector3Like | None = None,
        major_radius: float = 0.0,
        minor_radius: float = 0.0,
    ):
        self.center = _to_vector3(center)
        self.normal = _to_vector3(normal)
        self.major_radius = major_radius
        self.minor_radius = minor_radius


@dataclass(kw_only=True)
@proto_decorator(shapepb.Cone)
class Cone(Shape):
    apex: Vector3
    base_center: Vector3
    base_radius: float

    def __init__(
        self,
        *,
        apex: Vector3Like | None = None,
        base_center: Vector3Like | None = None,
        base_radius: float = 0.0,
    ):
        self.apex = _to_vector3(apex)
        self.base_center = _to_vector3(base_center)
        self.base_radius = base_radius
