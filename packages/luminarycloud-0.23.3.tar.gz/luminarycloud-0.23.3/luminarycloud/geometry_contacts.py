# Copyright 2026 Luminary Cloud, Inc. All Rights Reserved.
from __future__ import annotations

import logging
from time import sleep, time
from typing import TYPE_CHECKING

import luminarycloud as lc
from luminarycloud.exceptions import SDKException, Timeout

from ._client import get_default_client
from ._proto.api.v0.luminarycloud.geometry import geometry_pb2 as geometrypb
from ._wrapper import ProtoWrapperBase

if TYPE_CHECKING:
    from .geometry import Geometry

logger = logging.getLogger(__name__)


class GeometryContactsError(SDKException):
    """Raised when geometry contacts computation fails."""

    pass


def wait_for_geometry_contacts(
    geometry_id: str,
    geometry_version_id: str,
    project_id: str,
    *,
    interval_seconds: float = 2,
    timeout_seconds: float = float("inf"),
) -> GeometryContacts:
    """
    Waits for geometry contacts computation to complete.

    Polls the GetGeometryContacts RPC until the computation is found
    and either succeeds or fails.

    Parameters
    ----------
    geometry_id: str
        The geometry ID
    geometry_version_id: str
        The geometry version ID
    project_id: str
        The project ID
    interval_seconds: float
        Number of seconds between polls. Default is 2 seconds.
    timeout_seconds: float
        Number of seconds before the operation times out.
        Default is infinity.

    Returns
    -------
    GeometryContacts
        The computed geometry contacts.

    Raises
    ------
    Timeout
        If the operation times out before completion.
    """
    deadline = time() + timeout_seconds
    while True:
        if time() >= deadline:
            raise Timeout("Timed out waiting for geometry contacts to be computed.")

        response = get_geometry_contacts(geometry_id, geometry_version_id, project_id)

        if response.found:
            if response.operation_error:
                raise GeometryContactsError(
                    f"Geometry contacts computation failed with error. Issues: {response.issues}"
                )
            return response

        # not yet found/complete, continue polling
        sleep(max(0, min(interval_seconds, deadline - time())))


class Contact:
    """Represents a single contact between two surfaces."""

    def __init__(self, id: str, side_a: list[str], side_b: list[str]):
        self.id = id
        self.side_a = side_a
        self.side_b = side_b

    def __repr__(self) -> str:
        return f"Contact(id={self.id}, " f"side_a={self.side_a}, " f"side_b={self.side_b})"


class GeometryContacts(ProtoWrapperBase):
    _proto: "geometrypb.GetGeometryContactsResponse"

    def __init__(self, proto: "geometrypb.GetGeometryContactsResponse"):
        self._proto = proto
        self.geometry_id: str = ""
        self.geometry_version_id: str = ""
        self.project_id: str = ""

    @property
    def found(self) -> bool:
        """Whether the contacts computation was found."""
        return self._proto.contacts.found

    @property
    def operation_error(self) -> bool:
        """Whether the contacts computation encountered an error."""
        return self._proto.contacts.operation_error

    @property
    def contacts(self) -> list[Contact]:
        """List of computed contacts."""
        return [
            Contact(
                id=c.id,
                side_a=list(c.side_a),
                side_b=list(c.side_b),
            )
            for c in self._proto.contacts.contacts
        ]

    @property
    def issues(self) -> list:
        """List of issues/warnings from the computation."""
        return list(self._proto.contacts.issues)

    def geometry(self) -> "Geometry":
        """Get the geometry these contacts are for."""
        return lc.get_geometry(self.geometry_id)

    def refresh(self) -> "GeometryContacts":
        """
        Sync the GeometryContacts object with the backend.

        Returns
        -------
        GeometryContacts
            Updated contacts consistent with the backend.
        """
        self._proto = get_geometry_contacts(
            self.geometry_id, self.geometry_version_id, self.project_id
        )._proto
        return self

    def wait(
        self,
        *,
        interval_seconds: float = 2,
        timeout_seconds: float = float("inf"),
    ) -> bool:
        """
        Wait until the geometry contacts computation has either completed or failed.

        Mutates self with the final status and results.

        Parameters
        ----------
        interval_seconds : float, optional
            Number of seconds between polls. Default is 2 seconds.
        timeout_seconds : float, optional
            Number of seconds before timeout.

        Returns
        -------
        bool
            True if computation completed without error, False if operation_error is True.
        """
        computed_contacts = wait_for_geometry_contacts(
            self.geometry_id,
            self.geometry_version_id,
            self.project_id,
            interval_seconds=interval_seconds,
            timeout_seconds=timeout_seconds,
        )
        # Update self with the final results
        self._proto = computed_contacts._proto
        return self.operation_error is False


def get_geometry_contacts(
    geometry_id: str,
    geometry_version_id: str,
    project_id: str,
) -> GeometryContacts:
    """
    Get computed contacts for a specific geometry version.

    Parameters
    ----------
    geometry_id : str
        The geometry ID
    geometry_version_id : str
        The geometry version ID
    project_id : str
        The project ID

    Returns
    -------
    GeometryContacts
        The contacts information (may indicate not found if not yet computed)

    Examples
    --------
    >>> contacts = lc.get_geometry_contacts("geo-123", "gv-456")
    >>> if contacts.found:
    ...     print(f"Found {len(contacts.contacts)} contacts")
    """
    req = geometrypb.GetGeometryContactsRequest(
        geometry_id=geometry_id,
        geometry_version_id=geometry_version_id,
        project_id=project_id,
    )
    res = get_default_client().GetGeometryContacts(req)
    contacts = GeometryContacts(res)
    contacts.geometry_id = geometry_id
    contacts.geometry_version_id = geometry_version_id
    contacts.project_id = project_id
    return contacts
