import logging
from time import sleep
from collections.abc import Callable
from typing import MutableMapping
import requests

from .._auth import Auth0Client
from .. import __version__


MAX_ERROR_BODY_LENGTH = 1000
REDACTED_HEADERS = ["Authorization", "x-api-key"]

logger = logging.getLogger(__name__)


# We sometimes get transient `404: fault filter abort` errors from the envoy proxies that GCP seems to
# use for their LBs that are installed via GKE's gateway. These should be retried.
def _is_retryable_fault_filter_abort_response(resp: requests.Response) -> bool:
    return resp.status_code == 404 and resp.text.strip() == "fault filter abort"


class HTTPErrorWithBody(requests.HTTPError):
    """Custom HTTPError that includes response body text."""

    def __init__(self, response: requests.Response, *args, **kwargs):
        body_preview = response.text[:MAX_ERROR_BODY_LENGTH] + (
            "... [truncated]" if len(response.text) > MAX_ERROR_BODY_LENGTH else ""
        )
        message = f"{response.status_code} Error for {response.url}\nBody: {body_preview}"
        super().__init__(message, response=response, *args, **kwargs)


class HttpClient:
    def __init__(
        self,
        base_url: str,
        api_key: str | None = None,
        auth0_client: Auth0Client | None = None,
        *,
        timeout: int | None = 300,
        max_retries: int = 20,
        backoff_factor: float = 0.3,
        max_retry_backoff_seconds: float = 20,
        retry_on_response: Callable[[str, requests.Response], bool] | None = None,
        retry_on_exception: Callable[[str, Exception], bool] | None = None,
        log_body: bool = True,
        max_body_log_length: int = 500,
    ):
        if not base_url.startswith("http"):
            base_url = f"https://{base_url}"
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers["x-client-version"] = f"python-sdk-v{__version__}"
        if api_key:
            self.session.headers["x-api-key"] = api_key
            self.auth0_client = None
        elif auth0_client:
            self.auth0_client = auth0_client
        else:
            raise ValueError("Either api_key or auth0_client must be provided")
        self.timeout = timeout
        self.log_body = log_body
        self.max_body_log_length = max_body_log_length
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor
        self.max_retry_backoff_seconds = max_retry_backoff_seconds
        self.retry_on_response = retry_on_response or self._default_should_retry_response
        self.retry_on_exception = retry_on_exception or self._default_should_retry_exception

    def _url(self, path: str) -> str:
        return f"{self.base_url}/{path.lstrip('/')}"

    def _sanitize_headers(
        self, headers: MutableMapping[str, str | bytes]
    ) -> MutableMapping[str, str | bytes]:
        clean: MutableMapping[str, str | bytes] = {}
        for k, v in headers.items():
            if k in REDACTED_HEADERS:
                clean[k] = "[REDACTED]"
            else:
                clean[k] = v
        return clean

    def _log_request(self, method: str, url: str, kwargs: dict):
        if not logger.isEnabledFor(logging.DEBUG):
            return
        line = f"REQUEST {method} {url}\nHeaders: {self._sanitize_headers(self.session.headers)}"
        if self.log_body:
            body = kwargs.get("json") or kwargs.get("data")
            body_str = str(body)
            if body_str and len(body_str) > self.max_body_log_length:
                body_str = body_str[: self.max_body_log_length] + "... [truncated]"
            line += f"\nBody: {body_str}"
        logger.debug(line)

    def _log_response(self, resp: requests.Response):
        if not logger.isEnabledFor(logging.DEBUG):
            return
        line = f"RESPONSE {resp.status_code} {resp.url}\nHeaders: {resp.headers}"
        if self.log_body:
            line += f"\nBody: {self._truncate_body(resp.text.strip())}"
        logger.debug(line)

    def _truncate_body(self, body: str) -> str:
        if not body or len(body) <= self.max_body_log_length:
            return body
        return body[: self.max_body_log_length] + "... [truncated]"

    def _authenticate_session(self) -> None:
        if self.auth0_client:
            self.session.headers["Authorization"] = (
                f"Bearer {self.auth0_client.fetch_access_token()}"
            )

    # This method, which takes a full URL instead of just a path, is made public so the upload
    # helper can use it to make authenticated requests to a gcsproxy endpoint which is hosted by
    # jobmaster, not apiserver
    def raw_request(self, method: str, url: str, **kwargs) -> requests.Response:
        self._authenticate_session()

        backoff_index = 0
        max_retries = max(self.max_retries, 0)

        while True:
            self._log_request(method, url, kwargs)
            try:
                resp = self.session.request(method, url, timeout=self.timeout, **kwargs)
            except Exception as error:
                should_retry = self.retry_on_exception(method.upper(), error)
                if not should_retry or backoff_index >= max_retries:
                    raise
                backoff = self._retry_backoff(backoff_index)
                logger.debug(
                    "Retrying %s %s in %s seconds after transient request exception: %s",
                    method,
                    url,
                    backoff,
                    error,
                )
                sleep(backoff)
                backoff_index += 1
                continue

            self._log_response(resp)
            should_retry = self.retry_on_response(method.upper(), resp)
            if not should_retry or backoff_index >= max_retries:
                return resp

            backoff = self._retry_backoff(backoff_index)
            logger.debug(
                "Retrying %s %s in %s seconds after transient %s response body=%r",
                method,
                url,
                backoff,
                resp.status_code,
                self._truncate_body(resp.text.strip()),
            )
            sleep(backoff)
            backoff_index += 1

    def _retry_backoff(self, backoff_index: int) -> float:
        # Keep this deterministic and bounded. with backoff_factor=0.3 this yields:
        # 0.6s, 1.2s, 2.4s, ... up to max_retry_backoff_seconds.
        return min((2 ** (backoff_index + 1)) * self.backoff_factor, self.max_retry_backoff_seconds)

    @staticmethod
    def _default_should_retry_response(_method: str, resp: requests.Response) -> bool:
        return resp.status_code in {
            500,
            502,
            503,
            504,
            429,
        } or _is_retryable_fault_filter_abort_response(resp)

    @staticmethod
    def _default_should_retry_exception(_method: str, error: Exception) -> bool:
        return isinstance(error, requests.exceptions.RequestException)

    def _json_or_error(self, resp: requests.Response) -> dict:
        if resp.status_code >= 400:
            raise HTTPErrorWithBody(resp)
        return resp.json() if resp.text else {}

    # ---- Raw methods ----
    def raw_get(self, path: str, **kwargs) -> requests.Response:
        return self.raw_request("GET", self._url(path), **kwargs)

    def raw_post(self, path: str, body: dict | None = None, **kwargs) -> requests.Response:
        return self.raw_request("POST", self._url(path), json=body, **kwargs)

    def raw_put(self, path: str, body: dict | None = None, **kwargs) -> requests.Response:
        return self.raw_request("PUT", self._url(path), json=body, **kwargs)

    def raw_patch(self, path: str, body: dict | None = None, **kwargs) -> requests.Response:
        return self.raw_request("PATCH", self._url(path), json=body, **kwargs)

    def raw_delete(self, path: str, **kwargs) -> requests.Response:
        return self.raw_request("DELETE", self._url(path), **kwargs)

    def raw_head(self, path: str, **kwargs) -> requests.Response:
        return self.raw_request("HEAD", self._url(path), **kwargs)

    # ---- JSON convenience methods ----
    def get(self, path: str, **kwargs) -> dict:
        return self._json_or_error(self.raw_get(path, **kwargs))

    def post(self, path: str, body: dict | None = None, **kwargs) -> dict:
        return self._json_or_error(self.raw_post(path, body, **kwargs))

    def put(self, path: str, body: dict | None = None, **kwargs) -> dict:
        return self._json_or_error(self.raw_put(path, body, **kwargs))

    def patch(self, path: str, body: dict | None = None, **kwargs) -> dict:
        return self._json_or_error(self.raw_patch(path, body, **kwargs))

    def delete(self, path: str, **kwargs) -> dict:
        return self._json_or_error(self.raw_delete(path, **kwargs))

    def head(self, path: str, **kwargs) -> dict:
        resp = self.raw_head(path, **kwargs)
        if resp.status_code >= 400:
            raise HTTPErrorWithBody(resp)
        return dict(resp.headers)
