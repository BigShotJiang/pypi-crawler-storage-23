import grpc

from ..exceptions import SDKException


class FailInterceptor(
    grpc.UnaryUnaryClientInterceptor,
    grpc.UnaryStreamClientInterceptor,
    grpc.StreamUnaryClientInterceptor,
    grpc.StreamStreamClientInterceptor,
):
    """
    If added to a GRPC channel, this will cause any calls to fail and report a message to the user.
    """

    def __init__(self, message: str):
        super().__init__()
        self._message = message

    def intercept_unary_unary(self, continuation, client_call_details, request):
        raise SDKException(self._message)

    def intercept_unary_stream(self, continuation, client_call_details, request):
        raise SDKException(self._message)

    def intercept_stream_unary(self, continuation, client_call_details, request):
        raise SDKException(self._message)

    def intercept_stream_stream(self, continuation, client_call_details, request):
        raise SDKException(self._message)
