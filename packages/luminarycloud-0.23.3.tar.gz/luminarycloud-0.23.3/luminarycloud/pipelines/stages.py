# Copyright 2025 Luminary Cloud, Inc. All Rights Reserved.
from dataclasses import dataclass

from .core import StandardStage, StageInputs, StageOutputs
from .flowables import PipelineOutputGeometry, PipelineOutputMesh, PipelineOutputSimulation
from .parameters import BoolPipelineParameter, StringPipelineParameter, IntPipelineParameter


@dataclass
class ReadGeometryOutputs(StageOutputs):
    geometry: PipelineOutputGeometry
    """
    The resultant Geometry.
    """


class ReadGeometry(StandardStage[ReadGeometryOutputs]):
    """
    Reads a Geometry into the Pipeline, optionally makes a copy of it, and optionally mutates that
    copy by applying a named variable set (NVS). Also runs a geometry check and fails if the check
    produces errors.

    Parameters
    ----------
    geometry_id : str | StringPipelineParameter
        The ID of the Geometry to retrieve.
    use_geo_without_copying : bool | BoolPipelineParameter
        By default, this is False, meaning that each Geometry this stage references will be copied
        and the PipelineJob will actually operate on the copied Geometry. This is done for multiple
        reasons, one of which is so that a PipelineJob can be based on a single parametric Geometry
        which each run of the job modifies by applying a NamedVariableSet. That modification mutates
        the Geometry, so those runs can only happen in parallel without interfering with each other
        if they each operate on a different copy of the Geometry. (The second reason is discussed
        in the "Details" section below.)

        However, if you've already prepared your Geometry in advance and you don't want the
        PipelineJob to create copies, you can set this to True. In that case, the referenced
        Geometry will be used directly without being copied.

        IMPORTANT: If you set this to True, you must ensure no two PipelineJobRuns operate on the
        same Geometry, i.e. no two PipelineArgs rows contain the same Geometry ID.

    Outputs
    -------
    geometry : PipelineOutputGeometry
        The resultant Geometry.

    Named Variable Set support
    --------------------------
    If the pipeline job's arguments have no `PP_NAMED_VARIABLE_SET_ID` column, the stage just copies
    the specified Geometry and outputs the copy. If the arguments do include that column, the stage
    copies the specified Geometry and applies the specified NVS to it to produce a variant.

    Details
    -------
    Unless `use_geo_without_copying` is `True`, this stage always produces a copy of the specified
    Geometry. One reason for this is described in the description of the `use_geo_without_copying`
    parameter above. The other reason is that as much as possible, pipelines try to behave as if all
    of their computation occurs the moment they are invoked, even though some of that computation
    might happen hours or days later. This makes pipeline jobs more predictable and understandable.
    But Geometries are mutable, so to achieve this behavior, we need to make a copy of the
    referenced Geometry as it existed at the time the pipeline was invoked.
    """

    def __init__(
        self,
        *,
        stage_name: str | None = None,
        geometry_id: str | StringPipelineParameter,
        use_geo_without_copying: bool | BoolPipelineParameter = False,
    ):
        super().__init__(
            stage_name,
            {"geometry_id": geometry_id, "use_geo_without_copying": use_geo_without_copying},
            StageInputs(self),
            ReadGeometryOutputs._instantiate_for(self),
        )


@dataclass
class ReadMeshOutputs(StageOutputs):
    mesh: PipelineOutputMesh
    """
    The Mesh read from the given `mesh_id`.
    """


class ReadMesh(StandardStage[ReadMeshOutputs]):
    """
    Reads a Mesh into the Pipeline.

    Does not complete until the Mesh is ready for simulation.  Fails if the meshing job completes
    with errors.

    Parameters
    ----------
    mesh_id : str | StringPipelineParameter
        The ID of the Mesh to retrieve.

    Outputs
    -------
    mesh : PipelineOutputMesh
        The Mesh with the given `mesh_id`.
    """

    def __init__(
        self,
        *,
        stage_name: str | None = None,
        mesh_id: str | StringPipelineParameter,
    ):
        super().__init__(
            stage_name,
            {"mesh_id": mesh_id},
            StageInputs(self),
            ReadMeshOutputs._instantiate_for(self),
        )


@dataclass
class WaitForMeshOutputs(StageOutputs):
    mesh: PipelineOutputMesh
    """
    The Mesh that will be waited for.
    """


class WaitForMesh(StandardStage[WaitForMeshOutputs]):
    """
    Waits for a Mesh to be ready for simulation.

    This is useful if you have a more complicated meshing setup than the `Mesh` stage can handle.

    For example, you can use a `RunScript` stage to call `lc.create_or_get_mesh()` with arbitrary
    meshing parameters, then pass the resulting mesh to this stage to wait for it to be ready.
    Mesh creation can take minutes to hours, and `RunScript` has a short timeout, so you can't wait
    for it to complete in the `RunScript` stage, but `lc.create_or_get_mesh()` returns immediately
    and mesh creation happens asynchronously, so you can wait for it to be ready in this stage.

    Parameters
    ----------
    mesh : PipelineOutputMesh
        The Mesh to wait for.

    Outputs
    -------
    mesh : PipelineOutputMesh
        The same Mesh that was passed in as input. It will now be in a `COMPLETED` status, and ready
        to be used in a Simulation.
    """

    def __init__(
        self,
        *,
        stage_name: str | None = None,
        mesh: PipelineOutputMesh,
    ):
        super().__init__(
            stage_name,
            {},
            StageInputs(self, mesh=(PipelineOutputMesh, mesh)),
            WaitForMeshOutputs._instantiate_for(self),
        )


@dataclass
class MeshOutputs(StageOutputs):
    mesh: PipelineOutputMesh
    """The Mesh generated from the given Geometry."""


class Mesh(StandardStage[MeshOutputs]):
    """
    Generates a Mesh from a Geometry.

    This is the basic stage for generating a minimal Mesh or a Mesh with a target number of control
    volumes. If you need a more custom setup with arbitrary mesh generation params, use the
    `RunScript` stage to set up your params and follow it with a `WaitForMesh` stage.

    Parameters
    ----------
    geometry : PipelineOutputGeometry
        The Geometry to mesh.
    mesh_name : str | StringPipelineParameter | None
        The name to assign to the Mesh. If None, a default name will be used.
    target_cv_count : int | IntPipelineParameter | None
        The target number of control volumes to generate. If None, a minimal mesh will be generated.
        Default: None

    Outputs
    -------
    mesh : PipelineOutputMesh
        The generated Mesh.
    """

    def __init__(
        self,
        *,
        stage_name: str | None = None,
        geometry: PipelineOutputGeometry,
        mesh_name: str | StringPipelineParameter | None = None,
        target_cv_count: int | IntPipelineParameter | None = None,
    ):
        super().__init__(
            stage_name,
            {
                "mesh_name": mesh_name,
                "target_cv_count": target_cv_count,
            },
            StageInputs(self, geometry=(PipelineOutputGeometry, geometry)),
            MeshOutputs._instantiate_for(self),
        )


@dataclass
class SimulateOutputs(StageOutputs):
    simulation: PipelineOutputSimulation
    """The Simulation."""


class Simulate(StandardStage[SimulateOutputs]):
    """
    Runs a Simulation.

    Parameters
    ----------
    mesh : PipelineOutputMesh
        The Mesh to use for the Simulation.
    sim_template_id : str | StringPipelineParameter
        The ID of the SimulationTemplate to use for the Simulation.
    sim_name : str | StringPipelineParameter | None
        The name to assign to the Simulation. If None, a default name will be used.
    batch_processing : bool | BoolPipelineParameter
        If True, the Simulation will run as a standard job. If False, the Simulation will run as a
        priority job. Default: True

    Outputs
    -------
    simulation : PipelineOutputSimulation
        The Simulation.

    Named Variable Set support
    --------------------------
    If the pipeline job's arguments have a `PP_NAMED_VARIABLE_SET_ID` column, the specified NVS will
    be applied to the Simulation that gets created.
    """

    def __init__(
        self,
        *,
        stage_name: str | None = None,
        mesh: PipelineOutputMesh,
        sim_name: str | StringPipelineParameter | None = None,
        sim_template_id: str | StringPipelineParameter,
        batch_processing: bool | BoolPipelineParameter = True,
    ):
        super().__init__(
            stage_name,
            {
                "batch_processing": batch_processing,
                "sim_name": sim_name,
                "sim_template_id": sim_template_id,
            },
            StageInputs(self, mesh=(PipelineOutputMesh, mesh)),
            SimulateOutputs._instantiate_for(self),
        )
