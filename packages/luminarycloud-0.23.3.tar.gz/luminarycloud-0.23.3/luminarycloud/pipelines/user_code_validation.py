from __future__ import annotations

import ast
import builtins
import inspect
import symtable
import textwrap
import types
from dataclasses import dataclass
from typing import Callable, Iterable, Union


PROVIDED_GLOBALS = {"luminarycloud", "lc"}
ALL_ALLOWED_GLOBALS = set(dir(builtins)) | PROVIDED_GLOBALS


@dataclass(frozen=True)
class ValidatedFunction:
    """Result of validation."""

    source: str
    entrypoint: str


class FunctionValidationError(ValueError):
    pass


def _param_name_set(fn_node: ast.FunctionDef | ast.AsyncFunctionDef) -> frozenset[str]:
    """
    Return the set of parameter names for the function, excluding kwargs.
    """
    a = fn_node.args
    if a.posonlyargs:
        raise FunctionValidationError("Positional-only arguments are not supported.")
    if a.vararg:
        raise FunctionValidationError("Variable-length arguments are not supported.")
    return frozenset(x.arg for x in a.args)


def validate_portable_top_level_function(
    fn: Callable | str,
    *,
    must_have_params: set[str],
    can_have_params: set[str],
) -> ValidatedFunction:
    """
    Validate that `fn` is a function which has no freevars and no globals beyond builtins, and
    comports with the given must_have_params and can_have_params.

    Raises FunctionValidationError on any violation.
    """

    if isinstance(fn, str):
        src = textwrap.dedent(fn)
    else:
        try:
            source_lines, _ = inspect.getsourcelines(fn)
        except (OSError, IOError, TypeError) as exc:
            raise ValueError(f"Unable to retrieve source for function: {exc}") from exc
        # Drop decorator lines (everything before the `def`)
        for i, line in enumerate(source_lines):
            if line.lstrip().startswith("def "):
                source_lines = source_lines[i:]
                break
        src = textwrap.dedent("".join(source_lines))
    if not src.endswith("\n"):
        src += "\n"
    parsed = ast.parse(src, filename="<string>", mode="exec")
    body = parsed.body

    if len(body) != 1 or not isinstance(body[0], ast.FunctionDef):
        found = [type(n).__name__ for n in body]
        raise FunctionValidationError(
            "Code must contain exactly one top-level function definition and nothing else at the top level. "
            f"Found top-level items: {found}"
        )

    fn_node = body[0]
    fn_name = fn_node.name

    actual_params = _param_name_set(fn_node)

    if actual_params - can_have_params != must_have_params:
        raise FunctionValidationError(
            f"Parameter mismatch for function {fn_name!r}.\n"
            f"Your function takes: {sorted(actual_params)}\n"
            f"It must take all stage inputs and params: {sorted(must_have_params)}\n"
            f"It can also take these implicit params: {sorted(can_have_params)}\n"
            f"Your function's extra params are: {sorted(actual_params - must_have_params - can_have_params)}\n"
            f"Your function's missing params are: {sorted(must_have_params - actual_params)}"
        )

    st = symtable.symtable(src, filename="<string>", compile_type="exec")

    # Find the function's symbol table (top-level child)
    fn_st = None
    for child in st.get_children():
        if child.get_type() == "function" and child.get_name() == fn_name:
            fn_st = child
            break
    if fn_st is None:
        # This should not happen given the AST check, but keep it explicit.
        raise FunctionValidationError(f"Could not locate symbol table for {fn_name!r}")

    freevars = [s.get_name() for s in fn_st.get_symbols() if s.is_free()]
    if freevars:
        raise FunctionValidationError(
            f"Function {fn_name!r} closes over nonlocals/free variables: {sorted(set(freevars))}"
        )

    globals_used = [s.get_name() for s in fn_st.get_symbols() if s.is_global()]
    disallowed_globals = sorted({g for g in globals_used if g not in ALL_ALLOWED_GLOBALS})

    if disallowed_globals:
        raise FunctionValidationError(
            "RunScript functions must not rely on non-local variables, including imports. All "
            f"modules your script needs (except {', '.join(PROVIDED_GLOBALS)}) must be imported in "
            f"the function body. Found non-local variables: {', '.join(disallowed_globals)}"
        )

    return ValidatedFunction(source=src, entrypoint=fn_name)
