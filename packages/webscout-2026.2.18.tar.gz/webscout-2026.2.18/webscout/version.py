
__version__ = "2026.2.18"
__prog__ = "webscout"
