# Links

Some interesting sites

- [Music and artificial intelligence](https://en.wikipedia.org/wiki/Music_and_artificial_intelligence)

- [DEEP LEARNING FOR MUSIC GENERATION](https://carlosholivan.github.io/DeepLearningMusicGeneration/)

- [A Comprehensive Survey on Deep Music Generation: Multi-level Representations, Algorithms, Evaluations, and Future Directions](https://arxiv.org/pdf/2011.06801)
