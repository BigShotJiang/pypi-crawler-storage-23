"""Subject commands for iFlow CLI."""

import asyncio

import click

from iflow.api import APIError, MinerAPIClient
from iflow.config import require_project
from iflow.curl import miner_curl


@click.group()
def subjects():
    """Manage subjects (patients)."""
    pass


@subjects.command("list")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.option("--limit", default=20, help="Maximum subjects to display")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def list_subjects(project: str | None, limit: int, curl: bool):
    """List subjects for a project.

    \b
    Examples:
      iflow subjects list
      iflow subjects list --limit 50
    """
    project_id = require_project(project)

    if curl:
        params = {"limit": str(limit)}
        print(miner_curl("GET", "/subjects", project_id, params=params))
        return

    async def _list():
        client = MinerAPIClient()
        try:
            subjects_list = await client.list_subjects(
                project_id=project_id,
                limit=limit,
            )

            if not subjects_list:
                click.echo("No subjects found.")
                return

            click.echo(f"{'ID':<40} {'NAME':<25} {'EXTERNAL ID':<20} {'SEX':<10}")
            click.echo("-" * 95)

            for s in subjects_list:
                name = s.name or "-"
                ext_id = s.external_id or "-"
                click.echo(f"{s.id:<40} {name:<25} {ext_id:<20} {s.sex:<10}")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_list())


# Model column keys that get promoted to top-level API fields
SUBJECT_MODEL_FIELDS = {"sex", "date_of_birth", "external_id", "diagnosis", "clinical_notes"}


def _parse_properties(properties: tuple[str, ...], model_fields: set[str]) -> tuple[dict, dict]:
    """Split --property key=value pairs into model fields and JSONB properties."""
    data: dict = {}
    props: dict = {}
    for kv in properties:
        if "=" not in kv:
            raise click.BadParameter(
                f"Invalid format: '{kv}'. Use key=value",
                param_hint="--property",
            )
        k, v = kv.split("=", 1)
        if k in model_fields:
            data[k] = v
        else:
            props[k] = v
    return data, props


@subjects.command("create")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.option("-n", "--name", required=True, help="Subject name/ID")
@click.option(
    "-P", "--property", "properties", multiple=True,
    help="Property key=value (repeatable). Model keys: sex, date_of_birth (YYYY-MM-DD), external_id, diagnosis",
)
@click.option("--tag", "-t", multiple=True, help="Tag for the subject")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def create_subject(
    project: str | None,
    name: str,
    properties: tuple[str, ...],
    tag: tuple[str, ...],
    curl: bool,
):
    """Create a new subject (patient).

    \b
    All fields except --name are passed via --property/-P key=value:
      iflow subjects create -n "Patient Smith" -P sex=male -P surname=Smith
      iflow subjects create -n "SUB-001" -P external_id=MRN-12345 -P diagnosis="Hereditary cancer"

    \b
    Known model keys (stored as columns): sex, date_of_birth (YYYY-MM-DD), external_id, diagnosis, clinical_notes
    All dates use YYYY-MM-DD format (e.g., 2026-01-15).
    Other keys are stored in properties JSONB: first_name, surname, gender, etc.
    """
    project_id = require_project(project)

    model_data, props = _parse_properties(properties, SUBJECT_MODEL_FIELDS)
    data: dict = {"name": name, **model_data}
    if tag:
        data["tags"] = list(tag)
    if props:
        data["properties"] = props

    if curl:
        print(miner_curl("POST", "/subjects", project_id, data=data))
        return

    async def _create():
        client = MinerAPIClient()
        try:
            subject = await client.create_subject(
                project_id=project_id,
                name=name,
                external_id=model_data.get("external_id"),
                sex=model_data.get("sex", "unknown"),
                date_of_birth=model_data.get("date_of_birth"),
                diagnosis=model_data.get("diagnosis"),
                clinical_notes=model_data.get("clinical_notes"),
                tags=list(tag) if tag else None,
                properties=props or None,
            )

            click.echo("Subject created successfully!")
            click.echo(f"  ID: {subject.id}")
            if subject.name:
                click.echo(f"  Name: {subject.name}")
            if subject.external_id:
                click.echo(f"  External ID: {subject.external_id}")
            click.echo(f"  Sex: {subject.sex}")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_create())


@subjects.command("get")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("subject_id")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
def get_subject(project: str | None, subject_id: str, curl: bool):
    """Get details of a subject.

    SUBJECT_ID is the subject identifier.
    """
    project_id = require_project(project)

    if curl:
        print(miner_curl("GET", f"/subjects/{subject_id}", project_id))
        return

    async def _get():
        client = MinerAPIClient()
        try:
            subject = await client.get_subject(project_id, subject_id)

            click.echo(f"Subject: {subject.name or subject.id}")
            click.echo(f"  ID: {subject.id}")
            if subject.name:
                click.echo(f"  Name: {subject.name}")
            if subject.external_id:
                click.echo(f"  External ID: {subject.external_id}")
            click.echo(f"  Sex: {subject.sex}")
            if subject.date_of_birth:
                click.echo(f"  Date of Birth: {subject.date_of_birth}")
            if subject.diagnosis:
                click.echo(f"  Diagnosis: {subject.diagnosis}")
            if subject.created_at:
                click.echo(f"  Created: {subject.created_at}")
            if subject.tags:
                click.echo(f"  Tags: {', '.join(subject.tags)}")
            if subject.properties:
                click.echo("  Properties:")
                for k, v in subject.properties.items():
                    click.echo(f"    {k}: {v}")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_get())


@subjects.command("delete")
@click.option("-p", "--project", help="Project ID (uses default if not specified)")
@click.argument("subject_id")
@click.option("--curl", is_flag=True, help="Output curl command instead of executing")
@click.confirmation_option(prompt="Are you sure you want to delete this subject?")
def delete_subject(project: str | None, subject_id: str, curl: bool):
    """Delete a subject (cascades to samples).

    SUBJECT_ID is the subject identifier.
    """
    project_id = require_project(project)

    if curl:
        print(miner_curl("DELETE", f"/subjects/{subject_id}", project_id))
        return

    async def _delete():
        client = MinerAPIClient()
        try:
            await client.delete_subject(project_id, subject_id)
            click.echo(f"Subject {subject_id} deleted.")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_delete())
