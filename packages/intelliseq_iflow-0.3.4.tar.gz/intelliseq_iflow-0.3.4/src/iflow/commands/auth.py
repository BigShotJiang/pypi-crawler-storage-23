"""Authentication commands."""

import asyncio

import click
from rich.console import Console

from iflow.auth import (
    AuthError,
    TokenInfo,
    clear_token,
    device_flow_login,
    get_stored_token,
    is_token_expired,
    store_token,
)
from iflow.config import (
    ENVIRONMENTS,
    apply_environment,
    set_project_context,
)

console = Console()


async def detect_environment_by_api(access_token: str) -> str | None:
    """Detect environment by trying token against each environment's API."""
    import httpx

    for env_key, env_config in ENVIRONMENTS.items():
        admin_url = env_config["admin_url"]
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(
                    f"{admin_url}/api/v1/projects",
                    headers={"Authorization": f"Bearer {access_token}"},
                )
                if response.status_code == 200:
                    return env_key
        except Exception:
            continue
    return None


async def auto_configure_after_login(
    access_token: str, skip_env_detection: bool = False
) -> None:
    """Auto-configure environment and project after successful login."""
    from iflow.api import AdminAPIClient, APIError

    # 1. Auto-detect environment by probing APIs (skip if already selected via prompt)
    if not skip_env_detection:
        detected_env = await detect_environment_by_api(access_token)

        if detected_env:
            apply_environment(detected_env)
            env_name = ENVIRONMENTS[detected_env]["name"]
            console.print(f"[dim]Environment:[/dim] {env_name} (auto-detected)")

    # 3. Try to auto-select project if only one available
    try:
        client = AdminAPIClient(token=access_token)
        projects = await client.list_projects()

        if len(projects) == 1:
            p = projects[0]
            set_project_context(p.id, p.name, p.org_id, p.org_name, p.bucket_name)
            console.print(f"[dim]Project:[/dim] {p.name} (auto-selected)")
        elif len(projects) > 1:
            console.print(f"[dim]Found {len(projects)} projects.[/dim]")
            console.print("Run [cyan]iflow config select-project[/cyan] to choose one.")
        else:
            console.print("[dim]No projects available.[/dim]")
    except APIError:
        # Silently skip auto-configuration if API fails
        pass


def prompt_environment() -> str:
    """Prompt user to select environment for login."""
    console.print("\n[bold]Select environment:[/bold]")
    env_list = list(ENVIRONMENTS.items())
    for i, (key, env) in enumerate(env_list, 1):
        console.print(f"  {i}. {env['name']} ({key})")

    while True:
        choice = console.input("\nEnter choice [1-3]: ").strip()
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(env_list):
                return env_list[idx][0]
        except ValueError:
            pass
        console.print("[red]Invalid choice. Please enter 1, 2, or 3.[/red]")


@click.command()
@click.option(
    "--token", "-t", envvar="IFLOW_TOKEN",
    help="PAT for headless/CI auth (or IFLOW_TOKEN env)",
)
@click.option(
    "--env",
    type=click.Choice(["prod", "stg", "dev"]),
    default="stg",
    help="Environment (default: stg)",
)
def login(token: str | None, env: str):
    """
    Login to iFlow.

    \b
    Without --token, opens browser for interactive OAuth login (Device Flow).
    On headless/CI environments, use --token or set IFLOW_TOKEN env var.

    \b
    Examples:
      iflow login                           # Opens browser for OAuth login
      iflow login --env prod                # Use production environment
      iflow login --token YOUR_PAT          # PAT auth (headless/CI)
      IFLOW_TOKEN=YOUR_PAT iflow login      # Via env var
    """
    import time

    apply_environment(env)
    env_name = ENVIRONMENTS[env]["name"]
    console.print(f"[dim]Environment: {env_name}[/dim]")

    try:
        if token:
            # Use Personal Access Token directly
            console.print("[dim]Using Personal Access Token...[/dim]")
            token_info = TokenInfo(
                access_token=token,
                refresh_token=None,
                expires_at=time.time() + 86400 * 365,  # Assume 1 year validity
                token_type="Bearer",
            )
            store_token(token_info)
            console.print("[green]Successfully logged in with PAT![/green]")
            console.print()
            # Auto-configure environment and project
            asyncio.run(auto_configure_after_login(token))
            return

        # Device Flow: opens browser, shows clickable URL for non-graphical envs
        token_info = asyncio.run(device_flow_login())
        store_token(token_info)
        console.print("[green]Successfully logged in![/green]")
        console.print()
        # Auto-configure project (environment already selected)
        asyncio.run(auto_configure_after_login(token_info.access_token, skip_env_detection=True))
    except AuthError as e:
        console.print(f"[red]Login failed:[/red] {e}")
        raise SystemExit(1)
    except KeyboardInterrupt:
        console.print("\n[yellow]Login cancelled.[/yellow]")
        raise SystemExit(1)


@click.command()
def logout():
    """Logout and clear stored credentials."""
    clear_token()
    console.print("[green]Logged out successfully.[/green]")


@click.command()
def status():
    """Show current authentication status."""
    from iflow.config import get_settings

    token = get_stored_token()

    if not token:
        console.print("[yellow]Not logged in.[/yellow]")
        console.print("Run [bold]iflow login[/bold] to authenticate.")
        return

    if is_token_expired(token):
        console.print("[yellow]Token expired.[/yellow]")
        console.print("Run [bold]iflow login[/bold] to re-authenticate.")
        return

    console.print("[green]Logged in.[/green]")

    # Show environment
    settings = get_settings()
    env_name = ENVIRONMENTS.get(settings.environment, {}).get("name", settings.environment)
    console.print(f"Environment: [cyan]{env_name}[/cyan]")

    # Try to decode token to show user info
    try:
        import base64
        import json

        # Decode JWT payload (middle part)
        payload_b64 = token.access_token.split(".")[1]
        # Add padding if needed
        payload_b64 += "=" * (4 - len(payload_b64) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64))

        if "email" in payload:
            console.print(f"User: [cyan]{payload['email']}[/cyan]")
        elif "sub" in payload:
            console.print(f"Subject: [cyan]{payload['sub']}[/cyan]")

    except Exception:
        pass  # Don't fail if we can't decode token
