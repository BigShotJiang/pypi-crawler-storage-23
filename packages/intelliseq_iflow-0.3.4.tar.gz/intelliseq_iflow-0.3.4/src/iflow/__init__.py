"""iseq-flow - CLI tool for IntelliSeq Flow cloud file management."""

__version__ = "0.3.2"
