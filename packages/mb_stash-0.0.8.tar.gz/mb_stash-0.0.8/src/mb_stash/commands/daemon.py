"""Hidden CLI command: run the daemon process."""

import os
import subprocess  # nosec B404

import typer

from mb_stash.app_context import use_context
from mb_stash.daemon.server import run_server


def daemon(ctx: typer.Context) -> None:
    """Run the daemon process. Not intended for manual use."""
    app_ctx = use_context(ctx)
    if os.getppid() != 1:
        # Not yet adopted by launchd. Re-spawn as a proper daemon and exit so the
        # child process is reparented to launchd regardless of the caller (Raycast,
        # terminal, etc.). subprocess.Popen uses fork+exec, safe after pyobjc imports.
        # Args are fully internal — no user input reaches this call.
        subprocess.Popen(  # noqa: S603  # nosec B603
            [*app_ctx.cfg.cli_base_args(), "daemon"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        return
    run_server(app_ctx.cfg)
