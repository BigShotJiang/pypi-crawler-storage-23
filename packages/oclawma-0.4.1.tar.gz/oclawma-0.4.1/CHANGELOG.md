# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.0] - 2025-02-21

### Added
- Vector Memory (RAG) implementation with ChromaDB
- Skill Discovery & Marketplace system
- Official GitHub skill for repository operations
- Official Kubernetes skill for cluster management
- Self-improvement tools integration
- Error Pattern Learning with automatic correction
- Safety Guard integration with configurable levels
- Context Compression Suggestions
- Thin Sub-Agent Spawn for parallel task execution
- Configuration System with YAML profiles
- Rolling History Summarization
- Kimi.com cloud provider support with K2.5 model
- Docker, AWS, and Terraform example skills
- Comprehensive documentation with MkDocs
- PyPI release workflow with trusted publishing
- CLI polish and UI/UX improvements

### Changed
- Improved lazy skill loading performance
- Enhanced token counting accuracy
- Better error handling across all modules

### Fixed
- FunctionSkill.list_tools() to return tools without loading
- Various edge cases in provider fallback logic

## [0.1.0] - 2025-02-21

### Added
- Core framework with provider abstraction
- Ollama provider for local LLMs
- Kimi provider for cloud LLMs
- Fallback provider with automatic failover
- Skill registry with filesystem discovery
- Entry point discovery for pip packages
- YAML-based skill manifests
- Lazy loading for skills
- Token count caching
- Context budget with warnings at 75% and 87%
- Rolling history summarizer
- Built-in tools (read_file, write_file, exec_command)
- Interactive session with command handling
- Session statistics tracking
- Safety levels (strict, normal, permissive)
- CLI with Click
- Test suite with pytest
- Documentation site with MkDocs

[Unreleased]: https://github.com/openclaw/oclawma/compare/v0.2.0...HEAD
[0.2.0]: https://github.com/openclaw/oclawma/releases/tag/v0.2.0

### Added
- Core framework with provider abstraction
- Ollama provider for local LLMs
- Kimi provider for cloud LLMs
- Fallback provider with automatic failover
- Skill registry with filesystem discovery
- Entry point discovery for pip packages
- YAML-based skill manifests
- Lazy loading for skills
- Token count caching
- Context budget with warnings at 75% and 87%
- Rolling history summarizer
- Built-in tools (read_file, write_file, exec_command)
- Interactive session with command handling
- Session statistics tracking
- Safety levels (strict, normal, permissive)
- CLI with Click
- Test suite with pytest
- Documentation site with MkDocs

[Unreleased]: https://github.com/openclaw/oclawma/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/openclaw/oclawma/releases/tag/v0.1.0
