"""Tests for OCLAWMA."""

from click.testing import CliRunner

from oclawma import __version__
from oclawma.cli import cli


class TestVersion:
    """Test version information."""

    def test_version_constant(self) -> None:
        """Test that version is defined."""
        assert __version__ == "0.2.0"

    def test_version_cli(self) -> None:
        """Test CLI version flag."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "oclawma" in result.output
        assert __version__ in result.output


class TestCLI:
    """Test CLI functionality."""

    def test_cli_help(self) -> None:
        """Test CLI help output."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "OCLAWMA" in result.output
        assert "Workflow Management Agent" in result.output

    def test_cli_no_args(self) -> None:
        """Test CLI with no arguments shows help."""
        runner = CliRunner()
        result = runner.invoke(cli)
        # Click returns exit code 0 or 2 when no subcommand provided (shows help)
        assert result.exit_code in (0, 2)
        assert "Usage:" in result.output
