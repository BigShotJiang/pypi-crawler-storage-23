"""Tests for the example skill."""

import pytest
from oclawma.skills import SkillMetadata

from oclawma_skill_example import ExampleSkill


@pytest.fixture
def metadata():
    """Create test metadata."""
    return SkillMetadata(
        name="example",
        version="1.0.0",
        description="Test skill",
        author="Test Author",
    )


@pytest.fixture
def skill(metadata):
    """Create a test skill instance."""
    return ExampleSkill(metadata)


class TestGreet:
    """Tests for the greet tool."""

    async def test_greet_default(self, skill):
        """Test greet with default name."""
        result = await skill._greet()

        assert result["success"] is True
        assert result["output"] == "Hello, World!"

    async def test_greet_custom_name(self, skill):
        """Test greet with custom name."""
        result = await skill._greet(name="Alice")

        assert result["success"] is True
        assert result["output"] == "Hello, Alice!"

    async def test_greet_enthusiastic(self, skill):
        """Test greet with enthusiasm."""
        result = await skill._greet(name="Bob", enthusiastic=True)

        assert result["success"] is True
        assert result["output"] == "Hello, Bob!!!"

    async def test_greet_no_enthusiasm(self, skill):
        """Test greet without enthusiasm."""
        result = await skill._greet(name="Charlie", enthusiastic=False)

        assert result["success"] is True
        assert result["output"] == "Hello, Charlie!"


class TestEcho:
    """Tests for the echo tool."""

    async def test_echo_simple(self, skill):
        """Test basic echo."""
        result = await skill._echo(message="Hello World")

        assert result["success"] is True
        assert result["output"] == "Hello World"

    async def test_echo_uppercase(self, skill):
        """Test echo with uppercase."""
        result = await skill._echo(message="Hello World", uppercase=True)

        assert result["success"] is True
        assert result["output"] == "HELLO WORLD"

    async def test_echo_empty_message(self, skill):
        """Test echo with empty message."""
        result = await skill._echo(message="")

        assert result["success"] is False
        assert "empty" in result["error"].lower()


class TestInfo:
    """Tests for the info tool."""

    async def test_info_structure(self, skill):
        """Test info returns correct structure."""
        result = await skill._info()

        assert result["success"] is True
        assert "output" in result

        output = result["output"]
        assert output["name"] == "example"
        assert output["version"] == "1.0.0"
        assert "tools" in output
        assert "greet" in output["tools"]
        assert "echo" in output["tools"]
        assert "info" in output["tools"]


class TestSkillLoading:
    """Tests for skill loading behavior."""

    def test_skill_not_loaded_initially(self, skill):
        """Skill should not be loaded on creation."""
        assert skill.is_loaded is False

    def test_skill_loads_on_tool_access(self, skill):
        """Skill should load when tools are accessed."""
        _ = skill.tools  # Access tools property
        assert skill.is_loaded is True

    def test_tools_available(self, skill):
        """All expected tools should be available."""
        skill.load()  # Explicitly load

        assert "greet" in skill.tools
        assert "echo" in skill.tools
        assert "info" in skill.tools

    def test_tool_count(self, skill):
        """Skill should have 3 tools."""
        skill.load()
        assert len(skill.tools) == 3


class TestSkillMetadata:
    """Tests for skill metadata."""

    def test_metadata_preserved(self, metadata):
        """Skill should preserve metadata."""
        skill = ExampleSkill(metadata)

        assert skill.metadata.name == "example"
        assert skill.metadata.version == "1.0.0"
        assert skill.metadata.author == "Test Author"
