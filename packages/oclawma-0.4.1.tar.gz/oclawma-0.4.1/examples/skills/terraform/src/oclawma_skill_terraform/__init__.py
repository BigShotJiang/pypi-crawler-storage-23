"""OCLAWMA Skill: Terraform

Official Terraform skill for OCLAWMA providing comprehensive infrastructure
as code management capabilities including init, plan, apply, destroy, and
state management.

Installation:
    pip install oclawma-skill-terraform

Usage:
    from oclawma.skills import SkillRegistry

    registry = SkillRegistry()
    # Skill is automatically discovered via entry points

    # Initialize Terraform
    result = await registry.execute_tool("terraform", "init")

    # Generate plan
    result = await registry.execute_tool("terraform", "plan")

For more information, see SKILL.md in the package root.
"""

from .skill import TerraformSkill

__version__ = "1.0.0"
__all__ = ["TerraformSkill"]
