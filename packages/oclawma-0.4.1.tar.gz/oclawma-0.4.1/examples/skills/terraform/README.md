# OCLAWMA Skill: Terraform

Official Terraform skill for OCLAWMA providing comprehensive infrastructure as code management capabilities.

## Features

- **Lifecycle Management** - Initialize, plan, apply, and destroy infrastructure
- **Configuration** - Validate and format Terraform files
- **State Management** - List, show, move, and remove state items
- **Workspaces** - Manage multiple environments
- **Resource Management** - Import, taint, and untaint resources
- **Output Management** - View Terraform outputs

## Quick Start

```python
from oclawma.skills import SkillRegistry

# Create registry (skill auto-discovered via entry points)
registry = SkillRegistry()

# Initialize Terraform
result = await registry.execute_tool("terraform", "init", path="./infra")

# Validate configuration
result = await registry.execute_tool("terraform", "validate", path="./infra")

# Generate plan
result = await registry.execute_tool("terraform", "plan", path="./infra")

# Apply with auto-approval
result = await registry.execute_tool(
    "terraform", "apply",
    path="./infra",
    auto_approve=True
)

# Show outputs
result = await registry.execute_tool(
    "terraform", "output",
    path="./infra"
)

# Destroy infrastructure
result = await registry.execute_tool(
    "terraform", "destroy",
    path="./infra",
    auto_approve=True
)
```

## Installation

```bash
pip install oclawma-skill-terraform
```

### Prerequisites

- **Terraform** - Installed and in PATH (v1.0+ recommended)
- **Valid Terraform configuration** - For operations to work

## Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `TF_VAR_*` | - | Terraform variables |
| `TF_DATA_DIR` | `.terraform` | Data directory |
| `TF_PLUGIN_CACHE_DIR` | - | Plugin cache directory |

## Documentation

See [SKILL.md](SKILL.md) for detailed documentation on all available tools.

## Development

```bash
# Clone
git clone https://github.com/openclaw/oclawma-skill-terraform.git
cd oclawma-skill-terraform

# Setup
python -m venv venv
source venv/bin/activate
pip install -e ".[dev]"

# Test
pytest

# Lint
black src tests
ruff check src tests
mypy src
```

## License

MIT License - see [LICENSE](LICENSE) file.
