# OCLAWMA Skill: Kubernetes

Official Kubernetes skill for OCLAWMA providing comprehensive cluster management capabilities.

## Features

- **kubectl Wrapper** - Execute any kubectl command with proper error handling
- **Pod Management** - List, describe, get logs, and exec into pods
- **Deployment Management** - Scale deployments, manage rollouts
- **Helm Support** - Full Helm lifecycle (install, upgrade, uninstall, status, values)
- **Context Management** - Switch between clusters easily
- **Resource Monitoring** - Pod and node resource usage (top)
- **Event Monitoring** - Watch cluster events
- **Port Forwarding** - Forward local ports to pods/services

## Quick Start

```python
from oclawma.skills import SkillRegistry

# Create registry (skill auto-discovered via entry points)
registry = SkillRegistry()

# List pods
result = await registry.execute_tool("kubernetes", "get_pods")

# Get logs from a pod
result = await registry.execute_tool(
    "kubernetes", "get_logs",
    pod="my-app-xxx", tail=100
)

# Scale a deployment
result = await registry.execute_tool(
    "kubernetes", "scale_deployment",
    name="my-app", replicas=5
)

# Install a Helm chart
result = await registry.execute_tool(
    "kubernetes", "helm_install",
    name="nginx",
    chart="oci://registry-1.docker.io/bitnamicharts/nginx",
    namespace="web",
    create_namespace=True
)
```

## Installation

```bash
pip install oclawma-skill-kubernetes
```

### Prerequisites

- **kubectl** - Installed and in PATH
- **Helm** (optional) - For Helm operations
- Valid kubeconfig at `~/.kube/config` or set `KUBECONFIG`

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `KUBECONFIG` | `~/.kube/config` | Path to kubeconfig |
| `KUBECTL_NAMESPACE` | `default` | Default namespace |
| `KUBECTL_CONTEXT` | - | Default context |

## Documentation

See [SKILL.md](SKILL.md) for detailed documentation on all available tools.

## Development

```bash
# Clone
git clone https://github.com/openclaw/oclawma-skill-kubernetes.git
cd oclawma-skill-kubernetes

# Setup
python -m venv venv
source venv/bin/activate
pip install -e ".[dev]"

# Test
pytest

# Lint
black src tests
ruff check src tests
mypy src
```

## License

MIT License - see [LICENSE](LICENSE) file.
