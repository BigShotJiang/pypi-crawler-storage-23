# OCLAWMA Skill: Docker

Official Docker skill for OCLAWMA providing comprehensive container management capabilities.

## Features

- **Container Lifecycle** - Run, start, stop, restart, and remove containers
- **Container Operations** - View logs, execute commands, inspect containers, monitor stats
- **Image Management** - Pull, build, list, and remove images
- **Network Management** - Create, list, and remove Docker networks
- **Volume Management** - Create, list, and remove volumes
- **System Operations** - Prune unused resources
- **Docker Compose** - Start and stop multi-container applications

## Quick Start

```python
from oclawma.skills import SkillRegistry

# Create registry (skill auto-discovered via entry points)
registry = SkillRegistry()

# List running containers
result = await registry.execute_tool("docker", "ps", all=True)

# Run a new container
result = await registry.execute_tool(
    "docker", "run",
    image="nginx:latest",
    name="my-nginx",
    ports=["8080:80"],
    detach=True
)

# Get container logs
result = await registry.execute_tool(
    "docker", "logs",
    container="my-nginx", tail=100
)

# Execute command in container
result = await registry.execute_tool(
    "docker", "exec",
    container="my-nginx",
    command="ls -la /usr/share/nginx/html"
)

# Start Docker Compose services
result = await registry.execute_tool(
    "docker", "compose_up",
    file="docker-compose.yml",
    detach=True
)
```

## Installation

```bash
pip install oclawma-skill-docker
```

### Prerequisites

- **Docker** - Installed and in PATH
- **Docker Compose** (optional) - For compose operations

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DOCKER_HOST` | - | Docker daemon socket |

## Documentation

See [SKILL.md](SKILL.md) for detailed documentation on all available tools.

## Development

```bash
# Clone
git clone https://github.com/openclaw/oclawma-skill-docker.git
cd oclawma-skill-docker

# Setup
python -m venv venv
source venv/bin/activate
pip install -e ".[dev]"

# Test
pytest

# Lint
black src tests
ruff check src tests
mypy src
```

## License

MIT License - see [LICENSE](LICENSE) file.
