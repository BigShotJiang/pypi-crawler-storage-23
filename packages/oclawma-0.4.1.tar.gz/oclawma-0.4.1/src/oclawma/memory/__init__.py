"""Vector Memory module for Oclawma.

This module provides Retrieval-Augmented Generation (RAG) capabilities
using sqlite-vss for vector storage and similarity search.

Features:
- Vector storage using sqlite-vss (SQLite Vector Similarity Search)
- Embeddings via Kimi API or local Ollama
- Indexing of MEMORY.md and conversation history
- Top-K similarity retrieval
- Query interface: "What do I know about X?"
"""

from oclawma.memory.embeddings import (
    EmbeddingProvider,
    KimiEmbeddingProvider,
    OllamaEmbeddingProvider,
)
from oclawma.memory.indexer import MemoryIndexer
from oclawma.memory.query import MemoryQuery
from oclawma.memory.store import MemoryChunk, SearchResult, VectorMemoryStore

__all__ = [
    "VectorMemoryStore",
    "MemoryChunk",
    "SearchResult",
    "EmbeddingProvider",
    "KimiEmbeddingProvider",
    "OllamaEmbeddingProvider",
    "MemoryIndexer",
    "MemoryQuery",
]
