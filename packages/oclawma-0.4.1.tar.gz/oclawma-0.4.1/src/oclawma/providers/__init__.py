"""Provider integrations for Oclawma."""

from oclawma.providers.base import (
    AuthenticationError,
    BaseProvider,
    CompletionError,
    CompletionRequest,
    CompletionResponse,
    FinishReason,
    Message,
    ModelNotFoundError,
    ProviderConnectionError,
    ProviderError,
    RateLimitError,
    UsageStats,
)
from oclawma.providers.fallback import ContextOverflowError, FallbackProvider
from oclawma.providers.kimi import KimiProvider
from oclawma.providers.ollama import OllamaProvider

__all__ = [
    # Base classes
    "BaseProvider",
    "Message",
    "CompletionRequest",
    "CompletionResponse",
    "UsageStats",
    "FinishReason",
    # Exceptions
    "ProviderError",
    "ProviderConnectionError",
    "AuthenticationError",
    "RateLimitError",
    "ModelNotFoundError",
    "CompletionError",
    "ContextOverflowError",
    # Providers
    "OllamaProvider",
    "KimiProvider",
    "FallbackProvider",
]
