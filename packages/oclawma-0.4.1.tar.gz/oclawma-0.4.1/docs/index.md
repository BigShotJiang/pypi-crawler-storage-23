# Documentation Index

Welcome to the OCLAWMA documentation!

## Quick Links

- [Installation Guide](installation.md) - Get started with OCLAWMA
- [Configuration Reference](configuration.md) - Environment variables and settings
- [Skill Development Guide](skill-development.md) - Create your own skills
- [Architecture Overview](architecture.md) - System design and components
- [API Reference](api-reference.md) - Python API documentation

## Guides

### For Users

1. [Installation Guide](installation.md)
   - Requirements
   - Install from PyPI
   - Install from source
   - Provider setup (Ollama, Kimi)
   - Troubleshooting

2. [Configuration Reference](configuration.md)
   - Environment variables
   - Configuration file
   - Provider configuration
   - Session settings
   - Safety levels
   - Context budget

### For Developers

3. [Skill Development Guide](skill-development.md)
   - What is a skill?
   - Quick start
   - Creating YAML skills
   - Creating Python skills
   - Creating pip packages
   - Best practices
   - Examples

4. [Architecture Overview](architecture.md)
   - High-level architecture
   - Core components
   - Data flow
   - Provider system
   - Skill system
   - Context management
   - Safety system

5. [API Reference](api-reference.md)
   - Providers
   - Skills
   - Tools
   - Session
   - Context budget

## Other Documents

- [SKILL_PACKAGING.md](SKILL_PACKAGING.md) - Specification for pip-installable skills

## External Resources

- [GitHub Repository](https://github.com/openclaw/oclawma)
- [PyPI Package](https://pypi.org/project/oclawma)
- [Issue Tracker](https://github.com/openclaw/oclawma/issues)
- [Discussions](https://github.com/openclaw/oclawma/discussions)

## Contributing

See [CONTRIBUTING.md](../CONTRIBUTING.md) for guidelines on:
- Setting up development environment
- Making changes
- Testing
- Code style
- Submitting pull requests
