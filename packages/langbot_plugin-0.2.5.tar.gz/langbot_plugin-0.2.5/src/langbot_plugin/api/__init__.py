"""All entities in this directory are designed for plugin development, and compatibility issues need to be considered when updating."""

"""该目录下的一切实体均为插件开发设计，在更新时需要考虑兼容性问题。"""
