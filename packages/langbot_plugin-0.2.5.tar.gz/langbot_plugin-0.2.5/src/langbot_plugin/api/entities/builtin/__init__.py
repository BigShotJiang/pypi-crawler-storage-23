"""This package contains entities that are depended on by LangBot itself."""
