# Changelog

See the full changelog on GitHub: [CHANGELOG.md](https://github.com/deftio/pocketdock/blob/main/CHANGELOG.md)
