"""Validation utilities."""
