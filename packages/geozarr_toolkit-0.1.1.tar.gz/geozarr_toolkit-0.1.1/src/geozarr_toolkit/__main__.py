"""Entry point for python -m geozarr_toolkit."""

from geozarr_toolkit.cli import main

if __name__ == "__main__":
    main()
