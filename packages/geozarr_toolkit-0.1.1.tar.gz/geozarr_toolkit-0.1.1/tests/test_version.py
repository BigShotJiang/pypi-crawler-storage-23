import geozarr_toolkit


def test_version() -> None:
    assert geozarr_toolkit.__version__
