Functions for validating convention compliance.

::: geozarr_toolkit.validate_spatial
    options:
      show_source: false

::: geozarr_toolkit.validate_proj
    options:
      show_source: false

::: geozarr_toolkit.validate_multiscales
    options:
      show_source: false

::: geozarr_toolkit.validate_group
    options:
      show_source: false

::: geozarr_toolkit.validate_attrs
    options:
      show_source: false

::: geozarr_toolkit.detect_conventions
    options:
      show_source: false
