Functions for converting metadata to/from GeoZarr

::: geozarr_toolkit.from_geotransform
    options:
      show_source: false

::: geozarr_toolkit.from_rioxarray
    options:
      show_source: false
