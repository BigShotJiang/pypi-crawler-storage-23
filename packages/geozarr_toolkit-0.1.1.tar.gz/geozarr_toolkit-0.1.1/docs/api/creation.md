Functions for creating convention-compliant metadata.

::: geozarr_toolkit.create_zarr_conventions
    options:
      show_source: false

::: geozarr_toolkit.create_spatial_attrs
    options:
      show_source: false

::: geozarr_toolkit.create_proj_attrs
    options:
      show_source: false

::: geozarr_toolkit.create_multiscales_layout
    options:
      show_source: false

::: geozarr_toolkit.create_geozarr_attrs
    options:
      show_source: false

