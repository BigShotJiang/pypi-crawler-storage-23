"""Custom exceptions for Interceptor."""

from __future__ import annotations


class InterceptorError(Exception):
    """Base exception for all Interceptor errors."""


class PolicyLoadError(InterceptorError):
    """Raised when a YAML policy file cannot be loaded or parsed."""


class ConfirmationRequired(InterceptorError):
    """Raised when a tool call requires explicit confirmation before proceeding."""


class ThrottleError(InterceptorError):
    """Raised when a tool call is blocked due to retry throttling."""


class OverrideTokenError(InterceptorError):
    """Raised when an override token is invalid, expired, or already consumed."""
