"""Rich-formatted console output for Interceptor decisions."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from interceptor.types import Decision, RiskLevel

_RISK_COLORS: dict[RiskLevel, str] = {
    RiskLevel.LOW: "green",
    RiskLevel.MEDIUM: "yellow",
    RiskLevel.HIGH: "red",
}


class InterceptorLogger:
    """Print structured, color-coded decision panels to the console."""

    def __init__(self, console: Console | None = None) -> None:
        self._console = console or Console()

    def print_decision(self, decision: Decision) -> None:
        """Render a decision as a rich panel."""
        color = _RISK_COLORS.get(decision.risk_level, "white")

        body = Text()
        body.append("Risk:     ", style="bold")
        body.append(f"{decision.risk_level.value}\n", style=f"bold {color}")
        body.append("Mode:     ", style="bold")
        body.append(f"{decision.mode.value}\n")
        body.append("Decision: ", style="bold")
        body.append(f"{decision.decision.value}\n", style=f"bold {color}")
        body.append("Intent:   ", style="bold")
        body.append(f"{decision.intent_summary}\n")
        body.append("Reason:   ", style="bold")
        body.append(decision.reason)

        if decision.explanation:
            body.append("\n")
            body.append(">> ", style="bold cyan")
            body.append(decision.explanation, style="italic cyan")

        panel = Panel(
            body,
            title="[bold]INTERCEPTOR[/bold]",
            border_style=color,
            expand=False,
        )
        self._console.print(panel)
