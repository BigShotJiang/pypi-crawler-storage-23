"""Core types and Pydantic models for Interceptor."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel


class RiskLevel(str, Enum):
    """Risk classification levels."""

    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class Mode(str, Enum):
    """Enforcement modes."""

    STRICT = "strict"
    BALANCED = "balanced"
    OBSERVE = "observe"


class DecisionVerdict(str, Enum):
    """Possible verdicts for an intercepted call."""

    ALLOWED = "allowed"
    BLOCKED = "blocked"
    CONFIRMATION_REQUIRED = "confirmation_required"


class Decision(BaseModel):
    """Structured decision returned by the Interceptor."""

    allowed: bool
    risk_level: RiskLevel
    mode: Mode
    decision: DecisionVerdict
    intent_summary: str
    reason: str
    explanation: str | None = None
    """Optional plain-English summary of what is about to happen.

    Populated for MEDIUM and HIGH risk actions only.  Provides a concise,
    human-readable description of the action and its potential impact.
    """
