# Interceptor

> Runtime enforcement layer for autonomous AI agents.

Interceptor intercepts tool calls before execution and applies **policy enforcement**, **risk classification**, **role-based approval**, and **execution control** — so your AI agents never run unchecked.

## Installation

```bash
pip install interceptor
```

Or install from source:

```bash
git clone https://github.com/interceptor/interceptor.git
cd interceptor
pip install -e ".[dev]"
```

## Quick Start

```python
from interceptor import Interceptor

guard = Interceptor(mode="strict")

decision = guard.run(
    tool_name="delete_file",
    args={"path": "/tmp/data.csv"},
    user_role="user",
)

print(decision.allowed)       # False
print(decision.risk_level)    # HIGH
print(decision.decision)      # blocked
```

Console output:

```
┌──────────── INTERCEPTOR ────────────┐
│ Risk:     HIGH                      │
│ Mode:     strict                    │
│ Decision: blocked                   │
│ Intent:   Agent intends to call     │
│           delete_file with          │
│           path=/tmp/data.csv        │
│ Reason:   HIGH risk action requires │
│           admin approval.           │
└─────────────────────────────────────┘
```

## Strict Mode

```python
guard = Interceptor(mode="strict")

# HIGH  → blocked (unless admin)
# MEDIUM → confirmation required
# LOW   → allowed
```

## Balanced Mode

```python
guard = Interceptor(mode="balanced")

# HIGH   → confirmation required
# MEDIUM → allowed with warning
# LOW    → allowed
```

## Observe Mode

```python
guard = Interceptor(mode="observe")

# Never blocks — logs risk and intent only
```

## YAML Policy

Create a `policy.yaml`:

```yaml
tools:
  delete_file:
    risk: HIGH
  write_file:
    risk: MEDIUM

keywords:
  - drop
  - overwrite
```

Load it:

```python
guard = Interceptor(mode="strict", policy_path="policy.yaml")
```

## Role-Based Approval

```python
# Blocked for regular users
decision = guard.run("delete_file", {"path": "/data"}, user_role="user")
assert not decision.allowed

# Allowed for admins
decision = guard.run("delete_file", {"path": "/data"}, user_role="admin")
assert decision.allowed
```

## Override Tokens

```python
token = guard.generate_override_token()

decision = guard.run(
    "delete_file",
    {"path": "/data"},
    user_role="user",
    override_token=token,
)
assert decision.allowed  # one-time bypass
```

## Decorator

```python
from interceptor import Interceptor, intercept

guard = Interceptor(mode="strict")

@intercept(guard, user_role="admin")
def delete_file(path: str) -> str:
    return f"Deleted {path}"

result = delete_file(path="/tmp/data.csv")
```

## License

MIT
