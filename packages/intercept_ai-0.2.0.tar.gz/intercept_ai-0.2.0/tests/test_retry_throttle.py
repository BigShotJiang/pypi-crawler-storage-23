"""Tests for retry throttling."""

from interceptor import Interceptor, RiskLevel


def test_not_throttled_within_limit():
    guard = Interceptor(mode="strict", retry_limit=3, retry_window=60)
    # Two calls — under limit
    guard.run("read_file", {"key": "a"}, user_role="user")
    d = guard.run("read_file", {"key": "b"}, user_role="user")
    assert d.allowed
    assert d.risk_level == RiskLevel.LOW


def test_throttled_after_limit():
    guard = Interceptor(mode="strict", retry_limit=3, retry_window=60)
    # Exhaust the limit (record happens inside run)
    for _ in range(3):
        guard.run("read_file", {"key": "x"}, user_role="user")
    # 4th call should be escalated to HIGH and blocked for user
    d = guard.run("read_file", {"key": "y"}, user_role="user")
    assert d.risk_level == RiskLevel.HIGH
    assert not d.allowed


def test_different_tools_independent():
    guard = Interceptor(mode="strict", retry_limit=2, retry_window=60)
    guard.run("tool_a", {}, user_role="user")
    guard.run("tool_a", {}, user_role="user")
    # tool_b should be unaffected
    d = guard.run("tool_b", {}, user_role="user")
    assert d.allowed
