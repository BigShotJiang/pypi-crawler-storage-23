"""Tests for strict mode behavior."""

from interceptor import Decision, Interceptor, RiskLevel


def test_strict_blocks_high_risk_for_user():
    guard = Interceptor(mode="strict")
    d = guard.run("delete_file", {"path": "/tmp/data.csv"}, user_role="user")
    assert not d.allowed
    assert d.risk_level == RiskLevel.HIGH
    assert d.decision.value == "blocked"


def test_strict_allows_high_risk_for_admin():
    guard = Interceptor(mode="strict")
    d = guard.run("delete_file", {"path": "/tmp/data.csv"}, user_role="admin")
    assert d.allowed
    assert d.risk_level == RiskLevel.HIGH


def test_strict_confirmation_required_for_medium():
    guard = Interceptor(mode="strict")
    d = guard.run("write_file", {"path": "/tmp/out.txt"}, user_role="user")
    # write_file + path arg → MEDIUM risk (path heuristic)
    assert d.risk_level == RiskLevel.MEDIUM
    assert d.decision.value == "confirmation_required"


def test_strict_allows_low_risk():
    guard = Interceptor(mode="strict")
    d = guard.run("read_file", {"key": "value"}, user_role="user")
    assert d.allowed
    assert d.risk_level == RiskLevel.LOW
    assert d.decision.value == "allowed"


def test_observe_never_blocks():
    guard = Interceptor(mode="observe")
    d = guard.run("delete_file", {"path": "/critical/data"}, user_role="user")
    assert d.allowed
    assert d.risk_level == RiskLevel.HIGH
    assert d.decision.value == "allowed"


def test_balanced_confirms_high():
    guard = Interceptor(mode="balanced")
    d = guard.run("delete_file", {"path": "/tmp/data.csv"}, user_role="user")
    assert d.risk_level == RiskLevel.HIGH
    assert d.decision.value == "confirmation_required"


def test_balanced_allows_medium_with_warning():
    guard = Interceptor(mode="balanced")
    d = guard.run("write_file", {"path": "/tmp/out.txt"}, user_role="user")
    assert d.allowed
    assert d.risk_level == RiskLevel.MEDIUM
    assert "warning" in d.reason.lower()


def test_decision_has_explanation_for_high_risk():
    guard = Interceptor(mode="strict")
    d = guard.run("delete_file", {"path": "/tmp/data.csv"}, user_role="user")
    assert d.explanation is not None
    assert "destructive" in d.explanation.lower()


def test_decision_no_explanation_for_low_risk():
    guard = Interceptor(mode="strict")
    d = guard.run("read_file", {"key": "value"}, user_role="user")
    assert d.explanation is None
