"""Intermediate representation for Namel3ss."""

from namel3ss.ir.nodes import *  # noqa: F401,F403
