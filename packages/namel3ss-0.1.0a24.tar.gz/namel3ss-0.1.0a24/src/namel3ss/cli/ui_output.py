from __future__ import annotations

from namel3ss.cli.json_io import dumps_pretty
from namel3ss.traces.plain import format_plain
from namel3ss.version import get_version

def print_usage() -> None:
    usage = """Usage:
  n3 <command> [file.ai]
  python -m namel3ss <command> [file.ai]

namel3ss is an AI-native programming language. Every valid .ai file is an application. Studio is optional (inspector only; browser renders the app).

Start
  n3 init <project_name>          # create a deterministic starter project
  n3 new <template> <name>        # scaffold a project
  n3 kb                           # knowledge template
  n3 ops                          # operations template
  n3 aid                          # support template
  n3 list                         # list templates
  n3 run [file.ai]                # run app in browser (production UI, default: ./app.ai)
  n3 run studio [file.ai]         # run Studio inspector (alias of `n3 studio`)
  n3 run [file.ai] --studio       # Studio mode flag alias
  n3 serve [file.ai]              # run app as long-running service mode
  n3 dev [file.ai]                # dev loop, alias of run (browser)
  n3 studio [file.ai]             # inspect/debug in Studio
  n3 studio connect <session_id>  # inspect a remote service session snapshot
  n3 session list|kill ...        # list or terminate service sessions
  n3 console [file.ai]            # alias of Studio with console workflows

Quality
  n3 check [file.ai]              # static validation
  n3 expand [file.ai]             # print preset-expanded source (deterministic)
  n3 fmt [file.ai]                # format app file
  n3 actions <file.ai> [--json]   # list actions (positional 'json' stays supported)
  n3 ui <file.ai>                 # print UI manifest

Ship
  n3 build [file.ai]              # build deployable bundle (alias: pack <file.ai>)
  n3 pack add <name[@version]>    # capability packs (contract)
  n3 manifest [file.ai]           # print compiled manifest payload (for diffing/inspection)
  n3 validate theme [file.ai]     # validate theme tokens and contrast contracts
  n3 clean                        # remove runtime artifacts

Advanced
  n3 preview [file.ai]            # production-like browser preview
  n3 start [file.ai]              # serve build artifacts
  n3 ship --to T --back           # promote build, alias promote/back
  n3 where [file.ai]              # show active target and build
  n3 proof <file.ai> --json       # write engine proof
  n3 verify <file.ai> --prod      # governance checks
  n3 when <file.ai> --json        # check spec compatibility
  n3 how | what | why | with      # explain the last run
  n3 lint <file.ai> [check]       # lint (strict tools via --strict-tools)
  n3 graph | exports <file.ai>    # dependency graph or exports (use --json)
  n3 data | persist <file.ai> ... # data status, reset, export, import
  n3 secrets | observe | explain  # secrets, observability, engine explain
  n3 trace list|show ...          # list run traces and inspect one run
  n3 replay [app.ai] [--log ...] # replay explain logs with seed + retrieval metadata checks
  n3 debug pause|step|back|replay # time-travel trace debugger controls
  n3 export traces ...            # export run traces to OTLP endpoint
  n3 observability init [file.ai] # create default observability.yaml
  n3 docs [file.ai]               # API docs portal and spec (use --offline for local docs path)
  n3 sdk generate --lang L ...     # client SDK generation (python, typescript, go, rust)
  n3 sdk postman --out FILE        # Postman collection
  n3 metrics [file.ai]             # AI metrics summary
  n3 ast dump [file.ai]            # canonical AST/CIR dump
  n3 type check [file.ai]          # static type check and inference diagnostics
  n3 schema infer|migrate [file.ai] # schema inference and migration plan
  n3 concurrency check [file.ai]   # static checks for async and parallel safety
  n3 compile ...                   # compile pure flows to c, python, rust, or wasm projects
  n3 wasm run <module.wasm> ...    # execute wasm module with local runtime
  n3 trigger list|register ...     # manage webhook, upload, timer, and queue triggers
  n3 feedback list [file.ai]       # list user feedback entries
  n3 dataset list|history|add-version ... # manage dataset versions and lineage
  n3 train ...                     # deterministic custom model training and registration
  n3 retrain schedule|list|run ... # schedule, inspect, and execute retrain jobs
  n3 model canary ...              # configure canary/shadow model routing
  n3 models list|add|deprecate ... # manage the local model registry
  n3 tenant add|list|set-current ... # manage tenant isolation config
  n3 federation add-contract|list|remove-contract ... # manage cross-tenant contracts
  n3 cluster status|scale|deploy ... # inspect and control cluster scaling
  n3 version list ...              # manage route, flow, and model versions
  n3 quality check|fix ...         # run quality gates and suggestions
  n3 mlops ...                     # register and fetch model registry metadata
  n3 policy check|enforce ...      # enforce global governance policies
  n3 marketplace ...               # publish, search, and install marketplace items
  n3 tutorial list|run ...         # interactive lessons and progress tracking
  n3 playground check|run ...      # sandboxed snippet validation and execution
  n3 scaffold test <flow> ...      # generate a flow test skeleton
  n3 package build ...             # deterministic project archive build
  n3 lsp stdio|check ...           # language server and diagnostics
  n3 prompts list [file.ai]        # list prompt templates
  n3 conventions check [file.ai]   # conventions config summary
  n3 formats list [file.ai]        # response formats summary
  n3 audit [file.ai]               # sensitive audit log (or audit list/filter)
  n3 auth [file.ai]                # route permissions + user role commands
  n3 secret list|add|get ...       # encrypted vault commands
  n3 security check|purge ...      # security posture and retention cleanup
  n3 sensitive [file.ai]           # manage sensitive flows and keys
  n3 sandbox [file.ai]             # sandbox build/run helpers
  n3 create plugin <name>          # scaffold a custom UI plugin package
  n3 create ui_pack <name>         # scaffold a reusable UI pack folder
  n3 plugin new <lang> <name>      # scaffold a plugin project
  n3 plugin search <keyword>       # discover community extensions
  n3 plugin info <name@version>    # inspect metadata, permissions, and trust
  n3 plugin install <name@version> # install extension package (use --yes for consent)
  n3 plugin update <name>          # update installed extension
  n3 plugin trust <name@version>   # trust an extension hash locally (requires --yes)
  n3 plugin revoke <name@version>  # revoke local trust
  n3 plugin list --installed       # list installed extensions with trust status
  n3 publish plugin <path>         # publish plugin package to local registry
  n3 install plugin <name@version> # install plugin package from local registry
  n3 list plugins                  # list published plugin versions in registry
  n3 memory | kit | exists        # memory recall, adoption kit, contract status
  n3 tools | packs | registry     # tool and pack management commands
  n3 pkg | pattern | test | eval  # packages, patterns, tests, evaluation
  n3 version | reserved | icons   # metadata, versioning, and discovery
  n3 help                         # this help

Notes:
  file.ai is optional and defaults to ./app.ai when present
  if app.ai is missing: run `n3 <command> <file.ai>` or create app.ai
  legacy forms like `n3 run app.ai --target T --json` and `n3 actions app.ai json` remain supported
  n3 run defaults to production UI mode; use `n3 studio` (or `n3 run studio`) for Studio
  Studio inspects; the browser renders the app
"""
    print(usage.strip())

def print_payload(payload: object, json_mode: bool) -> None:
    if json_mode:
        print(dumps_pretty(payload))
    else:
        print(format_plain(payload))

def print_version() -> None:
    print(f"namel3ss {get_version()}")
