from __future__ import annotations

import json
import os

from namel3ss.config.model import AppConfig
from namel3ss.errors.base import Namel3ssError
from namel3ss.errors.guidance import build_guidance_message


ENV_IDENTITY_JSON = "N3_IDENTITY_JSON"
ENV_IDENTITY_PREFIX = "N3_IDENTITY_"
ENV_AUTH_SIGNING_KEY = "N3_AUTH_SIGNING_KEY"
ENV_AUTH_ALLOW_IDENTITY = "N3_AUTH_ALLOW_IDENTITY"
ENV_AUTH_USERNAME = "N3_AUTH_USERNAME"
ENV_AUTH_PASSWORD = "N3_AUTH_PASSWORD"
ENV_AUTH_IDENTITY_JSON = "N3_AUTH_IDENTITY_JSON"
ENV_AUTH_CREDENTIALS_JSON = "N3_AUTH_CREDENTIALS_JSON"
ENV_ANSWER_PROVIDER = "N3_ANSWER_PROVIDER"
ENV_ANSWER_MODEL = "N3_ANSWER_MODEL"
ENV_EMBEDDING_PROVIDER = "N3_EMBEDDING_PROVIDER"
ENV_EMBEDDING_MODEL = "N3_EMBEDDING_MODEL"
ENV_EMBEDDING_VERSION = "N3_EMBEDDING_VERSION"
ENV_EMBEDDING_DIMS = "N3_EMBEDDING_DIMS"
ENV_EMBEDDING_PRECISION = "N3_EMBEDDING_PRECISION"
ENV_EMBEDDING_CANDIDATE_LIMIT = "N3_EMBEDDING_CANDIDATE_LIMIT"
ENV_PERFORMANCE_ASYNC_RUNTIME = "N3_ASYNC_RUNTIME"
ENV_PERFORMANCE_MAX_CONCURRENCY = "N3_MAX_CONCURRENCY"
ENV_PERFORMANCE_CACHE_SIZE = "N3_CACHE_SIZE"
ENV_PERFORMANCE_ENABLE_BATCHING = "N3_ENABLE_BATCHING"
ENV_PERFORMANCE_METRICS_ENDPOINT = "N3_PERFORMANCE_METRICS_ENDPOINT"
ENV_DETERMINISM_SEED = "N3_DETERMINISM_SEED"
ENV_DETERMINISM_EXPLAIN = "N3_EXPLAIN"
ENV_DETERMINISM_REDACT_USER_DATA = "N3_REDACT_USER_DATA"
ENV_AUDIT_POLICY = "N3_AUDIT_POLICY"
RESERVED_TRUE_VALUES = {"1", "true", "yes", "on"}
RESERVED_FALSE_VALUES = {"0", "false", "no", "off"}


def apply_env_overrides(config: AppConfig) -> bool:
    used = False
    host = os.getenv("NAMEL3SS_OLLAMA_HOST")
    if host:
        config.ollama.host = host
        used = True
    timeout = os.getenv("NAMEL3SS_OLLAMA_TIMEOUT_SECONDS")
    if timeout:
        try:
            config.ollama.timeout_seconds = int(timeout)
        except ValueError as err:
            raise Namel3ssError("NAMEL3SS_OLLAMA_TIMEOUT_SECONDS must be an integer") from err
        used = True
    api_key = os.getenv("NAMEL3SS_OPENAI_API_KEY")
    if api_key:
        config.openai.api_key = api_key
        used = True
    base_url = os.getenv("NAMEL3SS_OPENAI_BASE_URL")
    if base_url:
        config.openai.base_url = base_url
        used = True
    anthropic_key = os.getenv("NAMEL3SS_ANTHROPIC_API_KEY")
    if anthropic_key:
        config.anthropic.api_key = anthropic_key
        used = True
    gemini_key = os.getenv("NAMEL3SS_GEMINI_API_KEY")
    if gemini_key:
        config.gemini.api_key = gemini_key
        used = True
    mistral_key = os.getenv("NAMEL3SS_MISTRAL_API_KEY")
    if mistral_key:
        config.mistral.api_key = mistral_key
        used = True
    answer_provider = os.getenv(ENV_ANSWER_PROVIDER)
    if answer_provider:
        config.answer.provider = answer_provider
        used = True
    answer_model = os.getenv(ENV_ANSWER_MODEL)
    if answer_model:
        config.answer.model = answer_model
        used = True
    embedding_provider = os.getenv(ENV_EMBEDDING_PROVIDER)
    if embedding_provider:
        config.embedding.provider = embedding_provider
        used = True
    embedding_model = os.getenv(ENV_EMBEDDING_MODEL)
    if embedding_model:
        config.embedding.model = embedding_model
        used = True
    embedding_version = os.getenv(ENV_EMBEDDING_VERSION)
    if embedding_version:
        config.embedding.version = embedding_version
        used = True
    embedding_dims = os.getenv(ENV_EMBEDDING_DIMS)
    if embedding_dims:
        try:
            config.embedding.dims = int(embedding_dims)
        except ValueError as err:
            raise Namel3ssError("N3_EMBEDDING_DIMS must be an integer") from err
        used = True
    embedding_precision = os.getenv(ENV_EMBEDDING_PRECISION)
    if embedding_precision:
        try:
            config.embedding.precision = int(embedding_precision)
        except ValueError as err:
            raise Namel3ssError("N3_EMBEDDING_PRECISION must be an integer") from err
        used = True
    embedding_candidate_limit = os.getenv(ENV_EMBEDDING_CANDIDATE_LIMIT)
    if embedding_candidate_limit:
        try:
            config.embedding.candidate_limit = int(embedding_candidate_limit)
        except ValueError as err:
            raise Namel3ssError("N3_EMBEDDING_CANDIDATE_LIMIT must be an integer") from err
        used = True
    async_runtime = os.getenv(ENV_PERFORMANCE_ASYNC_RUNTIME)
    if async_runtime is not None:
        token = async_runtime.strip().lower()
        if token in RESERVED_TRUE_VALUES:
            config.performance.async_runtime = True
        elif token in RESERVED_FALSE_VALUES:
            config.performance.async_runtime = False
        else:
            raise Namel3ssError("N3_ASYNC_RUNTIME must be true or false")
        used = True
    max_concurrency = os.getenv(ENV_PERFORMANCE_MAX_CONCURRENCY)
    if max_concurrency:
        try:
            value = int(max_concurrency)
        except ValueError as err:
            raise Namel3ssError("N3_MAX_CONCURRENCY must be an integer") from err
        if value < 1:
            raise Namel3ssError("N3_MAX_CONCURRENCY must be >= 1")
        config.performance.max_concurrency = value
        used = True
    cache_size = os.getenv(ENV_PERFORMANCE_CACHE_SIZE)
    if cache_size:
        try:
            value = int(cache_size)
        except ValueError as err:
            raise Namel3ssError("N3_CACHE_SIZE must be an integer") from err
        if value < 0:
            raise Namel3ssError("N3_CACHE_SIZE must be >= 0")
        config.performance.cache_size = value
        used = True
    enable_batching = os.getenv(ENV_PERFORMANCE_ENABLE_BATCHING)
    if enable_batching is not None:
        token = enable_batching.strip().lower()
        if token in RESERVED_TRUE_VALUES:
            config.performance.enable_batching = True
        elif token in RESERVED_FALSE_VALUES:
            config.performance.enable_batching = False
        else:
            raise Namel3ssError("N3_ENABLE_BATCHING must be true or false")
        used = True
    metrics_endpoint = os.getenv(ENV_PERFORMANCE_METRICS_ENDPOINT)
    if metrics_endpoint:
        config.performance.metrics_endpoint = metrics_endpoint
        used = True
    determinism_seed = os.getenv(ENV_DETERMINISM_SEED)
    if determinism_seed is not None:
        token = determinism_seed.strip()
        lowered = token.lower()
        if not token or lowered in {"null", "none"}:
            config.determinism.seed = None
        elif token.isdigit():
            parsed = int(token)
            if parsed < 0:
                raise Namel3ssError("N3_DETERMINISM_SEED must be >= 0")
            config.determinism.seed = parsed
        else:
            config.determinism.seed = token
        used = True
    determinism_explain = os.getenv(ENV_DETERMINISM_EXPLAIN)
    if determinism_explain is not None:
        token = determinism_explain.strip().lower()
        if token in RESERVED_TRUE_VALUES:
            config.determinism.explain = True
        elif token in RESERVED_FALSE_VALUES:
            config.determinism.explain = False
        else:
            raise Namel3ssError("N3_EXPLAIN must be true or false")
        used = True
    redact_user_data = os.getenv(ENV_DETERMINISM_REDACT_USER_DATA)
    if redact_user_data is not None:
        token = redact_user_data.strip().lower()
        if token in RESERVED_TRUE_VALUES:
            config.determinism.redact_user_data = True
        elif token in RESERVED_FALSE_VALUES:
            config.determinism.redact_user_data = False
        else:
            raise Namel3ssError("N3_REDACT_USER_DATA must be true or false")
        used = True
    audit_policy = os.getenv(ENV_AUDIT_POLICY)
    if audit_policy is not None:
        token = audit_policy.strip().lower()
        if token not in {"required", "optional", "forbidden"}:
            raise Namel3ssError("N3_AUDIT_POLICY must be required, optional, or forbidden")
        config.audit.mode = token
        used = True
    target = os.getenv("N3_PERSIST_TARGET")
    if target:
        config.persistence.target = normalize_target(target)
        used = True
    elif persist_enabled():
        config.persistence.target = "sqlite"
        used = True
    db_path = os.getenv("N3_DB_PATH")
    if db_path:
        config.persistence.db_path = db_path
        used = True
    database_url = os.getenv("N3_DATABASE_URL")
    if database_url:
        config.persistence.database_url = database_url
        used = True
    edge_kv_url = os.getenv("N3_EDGE_KV_URL")
    if edge_kv_url:
        config.persistence.edge_kv_url = edge_kv_url
        used = True
    replica_urls = os.getenv("N3_REPLICA_URLS")
    if replica_urls:
        values = [item.strip() for item in replica_urls.split(",")]
        config.persistence.replica_urls = [item for item in values if item]
        used = True
    tool_timeout = os.getenv("N3_PYTHON_TOOL_TIMEOUT_SECONDS")
    if tool_timeout:
        try:
            config.python_tools.timeout_seconds = int(tool_timeout)
        except ValueError as err:
            raise Namel3ssError("N3_PYTHON_TOOL_TIMEOUT_SECONDS must be an integer") from err
        used = True
    service_url = os.getenv("N3_TOOL_SERVICE_URL")
    if service_url:
        config.python_tools.service_url = service_url
        used = True
    foreign_strict = os.getenv("N3_FOREIGN_STRICT")
    if foreign_strict is not None:
        config.foreign.strict = foreign_strict.strip().lower() in RESERVED_TRUE_VALUES
        used = True
    foreign_allow = os.getenv("N3_FOREIGN_ALLOW")
    if foreign_allow is not None:
        config.foreign.allow = foreign_allow.strip().lower() in RESERVED_TRUE_VALUES
        used = True
    used = apply_authentication_env(config) or used
    used = apply_identity_env(config) or used
    return used


def apply_identity_env(config: AppConfig) -> bool:
    used = False
    identity_json = os.getenv(ENV_IDENTITY_JSON)
    if identity_json:
        try:
            parsed = json.loads(identity_json)
        except json.JSONDecodeError as err:
            raise Namel3ssError(_identity_json_error(str(err))) from err
        if not isinstance(parsed, dict):
            raise Namel3ssError(_identity_json_error("Expected a JSON object"))
        config.identity.defaults = dict(parsed)
        return True
    for key, value in os.environ.items():
        if not key.startswith(ENV_IDENTITY_PREFIX) or key == ENV_IDENTITY_JSON:
            continue
        field = key[len(ENV_IDENTITY_PREFIX):].lower()
        if not field:
            continue
        config.identity.defaults[field] = value
        used = True
    return used


def apply_authentication_env(config: AppConfig) -> bool:
    used = False
    signing_key = os.getenv(ENV_AUTH_SIGNING_KEY)
    if signing_key:
        config.authentication.signing_key = signing_key
        used = True
    allow_identity = os.getenv(ENV_AUTH_ALLOW_IDENTITY)
    if allow_identity is not None:
        config.authentication.allow_identity = allow_identity.strip().lower() in RESERVED_TRUE_VALUES
        used = True
    username = os.getenv(ENV_AUTH_USERNAME)
    if username:
        config.authentication.username = username
        used = True
    password = os.getenv(ENV_AUTH_PASSWORD)
    if password:
        config.authentication.password = password
        used = True
    identity_json = os.getenv(ENV_AUTH_IDENTITY_JSON)
    if identity_json:
        parsed = _parse_auth_json(identity_json, ENV_AUTH_IDENTITY_JSON)
        if not isinstance(parsed, dict):
            raise Namel3ssError(_auth_json_error(ENV_AUTH_IDENTITY_JSON, "Expected a JSON object"))
        config.authentication.identity = dict(parsed)
        used = True
    credentials_json = os.getenv(ENV_AUTH_CREDENTIALS_JSON)
    if credentials_json:
        parsed = _parse_auth_json(credentials_json, ENV_AUTH_CREDENTIALS_JSON)
        if not isinstance(parsed, dict):
            raise Namel3ssError(_auth_json_error(ENV_AUTH_CREDENTIALS_JSON, "Expected a JSON object"))
        username = parsed.get("username")
        password = parsed.get("password")
        identity = parsed.get("identity")
        if username is not None:
            config.authentication.username = str(username)
        if password is not None:
            config.authentication.password = str(password)
        if isinstance(identity, dict):
            config.authentication.identity = dict(identity)
        used = True
    return used


def normalize_target(raw: str) -> str:
    normalized = raw.strip().lower()
    if normalized in {"memory", "mem", "none", "off"}:
        return "memory"
    if normalized in {"sqlite", "postgres", "mysql", "edge"}:
        return normalized
    raise Namel3ssError(
        build_guidance_message(
            what=f"Unsupported persistence target '{raw}'.",
            why="Targets must be one of sqlite, postgres, mysql, edge, or memory.",
            fix="Set N3_PERSIST_TARGET to a supported value.",
            example="N3_PERSIST_TARGET=sqlite",
        )
    )


def persist_enabled() -> bool:
    value = os.getenv("N3_PERSIST", "").strip().lower()
    return value in RESERVED_TRUE_VALUES


def _identity_json_error(details: str) -> str:
    return build_guidance_message(
        what="Identity JSON is invalid.",
        why=f"Parsing N3_IDENTITY_JSON failed: {details}.",
        fix="Provide a valid JSON object for identity defaults.",
        example='N3_IDENTITY_JSON={"email":"dev@example.com","role":"admin"}',
    )


def _auth_json_error(label: str, details: str) -> str:
    return build_guidance_message(
        what=f"{label} is invalid.",
        why=f"Parsing {label} failed: {details}.",
        fix="Provide a valid JSON object for authentication settings.",
        example=f'{label}={{"username":"dev","password":"dev","identity":{{"role":"admin"}}}}',
    )


def _parse_auth_json(value: str, label: str) -> dict:
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as err:
        raise Namel3ssError(_auth_json_error(label, str(err))) from err
    if not isinstance(parsed, dict):
        raise Namel3ssError(_auth_json_error(label, "Expected a JSON object"))
    return parsed


__all__ = [
    "ENV_IDENTITY_JSON",
    "ENV_IDENTITY_PREFIX",
    "ENV_AUTH_SIGNING_KEY",
    "ENV_AUTH_ALLOW_IDENTITY",
    "ENV_AUTH_USERNAME",
    "ENV_AUTH_PASSWORD",
    "ENV_AUTH_IDENTITY_JSON",
    "ENV_AUTH_CREDENTIALS_JSON",
    "ENV_ANSWER_PROVIDER",
    "ENV_ANSWER_MODEL",
    "ENV_EMBEDDING_PROVIDER",
    "ENV_EMBEDDING_MODEL",
    "ENV_EMBEDDING_VERSION",
    "ENV_EMBEDDING_DIMS",
    "ENV_EMBEDDING_PRECISION",
    "ENV_EMBEDDING_CANDIDATE_LIMIT",
    "ENV_PERFORMANCE_ASYNC_RUNTIME",
    "ENV_PERFORMANCE_MAX_CONCURRENCY",
    "ENV_PERFORMANCE_CACHE_SIZE",
    "ENV_PERFORMANCE_ENABLE_BATCHING",
    "ENV_PERFORMANCE_METRICS_ENDPOINT",
    "ENV_DETERMINISM_SEED",
    "ENV_DETERMINISM_EXPLAIN",
    "ENV_DETERMINISM_REDACT_USER_DATA",
    "ENV_AUDIT_POLICY",
    "RESERVED_TRUE_VALUES",
    "RESERVED_FALSE_VALUES",
    "apply_env_overrides",
    "normalize_target",
]
