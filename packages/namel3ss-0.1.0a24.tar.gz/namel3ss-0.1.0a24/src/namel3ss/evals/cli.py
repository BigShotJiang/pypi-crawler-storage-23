from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json

from namel3ss.evals.ai_flow_eval import run_ai_flow_eval
from namel3ss.evals.loader import load_eval_suite
from namel3ss.evals.runner import render_eval_text, run_eval_suite
from namel3ss.evals.prompt_eval import run_prompt_eval
from namel3ss.cli.app_path import resolve_app_path
from namel3ss.errors.base import Namel3ssError
from namel3ss.errors.guidance import build_guidance_message


DEFAULT_OUTPUT_DIR = Path(".namel3ss") / "outcome"
DEFAULT_JSON_NAME = "eval_report.json"
DEFAULT_TXT_NAME = "eval_report.txt"


@dataclass(frozen=True)
class _EvalParams:
    suite_path: Path
    json_path: Path
    txt_path: Path | None
    fast: bool


def run_eval_command(args: list[str]) -> int:
    if args and args[0] == "prompt":
        return _run_prompt_eval_command(args[1:])
    if args and args[0] == "flow":
        return _run_flow_eval_command(args[1:])
    params = _parse_args(args)
    suite = load_eval_suite(params.suite_path)
    report = run_eval_suite(suite, fast=params.fast)
    payload = json.dumps(report.as_dict(), indent=2, sort_keys=True) + "\n"
    params.json_path.parent.mkdir(parents=True, exist_ok=True)
    params.json_path.write_text(payload, encoding="utf-8")
    text = render_eval_text(report)
    if params.txt_path is not None:
        params.txt_path.parent.mkdir(parents=True, exist_ok=True)
        params.txt_path.write_text(text + "\n", encoding="utf-8")
    if not params.fast:
        print(text)
    return 0 if report.status == "pass" else 1


def _run_prompt_eval_command(args: list[str]) -> int:
    prompt_name = None
    input_path: Path | None = None
    app_arg: str | None = None
    out_dir: Path | None = None
    json_mode = False
    idx = 0
    while idx < len(args):
        arg = args[idx]
        if arg == "--input":
            if idx + 1 >= len(args):
                raise Namel3ssError(_missing_prompt_flag("--input"))
            input_path = Path(args[idx + 1])
            idx += 2
            continue
        if arg == "--out-dir":
            if idx + 1 >= len(args):
                raise Namel3ssError(_missing_prompt_flag("--out-dir"))
            out_dir = Path(args[idx + 1])
            idx += 2
            continue
        if arg == "--app":
            if idx + 1 >= len(args):
                raise Namel3ssError(_missing_prompt_flag("--app"))
            app_arg = args[idx + 1]
            idx += 2
            continue
        if arg == "--json":
            json_mode = True
            idx += 1
            continue
        if arg.startswith("--"):
            raise Namel3ssError(_unknown_prompt_flag(arg))
        if prompt_name is None:
            prompt_name = arg
            idx += 1
            continue
        raise Namel3ssError(_too_many_prompt_args_message())
    if not prompt_name:
        raise Namel3ssError(_missing_prompt_name_message())
    if input_path is None:
        raise Namel3ssError(_missing_prompt_flag("--input"))
    app_path = resolve_app_path(app_arg)
    payload = run_prompt_eval(
        prompt_name=prompt_name,
        input_path=input_path,
        app_path=Path(app_path),
        out_dir=out_dir,
    )
    if json_mode:
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 0
    summary = payload.get("summary") if isinstance(payload, dict) else None
    if isinstance(summary, dict):
        print(f'Prompt "{prompt_name}" evaluation')
        for key in sorted(summary.keys()):
            print(f"  {key}: {summary[key]}")
    else:
        print(f'Prompt "{prompt_name}" evaluation complete.')
    return 0


def _run_flow_eval_command(args: list[str]) -> int:
    flow_name = None
    app_arg: str | None = None
    out_dir: Path | None = None
    json_mode = False
    idx = 0
    while idx < len(args):
        arg = args[idx]
        if arg == "--out-dir":
            if idx + 1 >= len(args):
                raise Namel3ssError(_missing_flow_flag("--out-dir"))
            out_dir = Path(args[idx + 1])
            idx += 2
            continue
        if arg == "--app":
            if idx + 1 >= len(args):
                raise Namel3ssError(_missing_flow_flag("--app"))
            app_arg = args[idx + 1]
            idx += 2
            continue
        if arg == "--json":
            json_mode = True
            idx += 1
            continue
        if arg.startswith("--"):
            raise Namel3ssError(_unknown_flow_flag(arg))
        if flow_name is None:
            flow_name = arg
            idx += 1
            continue
        raise Namel3ssError(_too_many_flow_args_message())
    if not flow_name:
        raise Namel3ssError(_missing_flow_name_message())
    app_path = resolve_app_path(app_arg)
    payload = run_ai_flow_eval(
        flow_name=flow_name,
        app_path=Path(app_path),
        out_dir=out_dir,
    )
    if json_mode:
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 0
    print(f'Flow "{flow_name}" evaluation')
    print(f'  model: {payload.get("model")}@{payload.get("model_version")}')
    print(f'  dataset: {payload.get("dataset")}')
    results = payload.get("results")
    if isinstance(results, dict):
        for key in sorted(results.keys()):
            print(f"  {key}: {results[key]}")
    return 0


def _parse_args(args: list[str]) -> _EvalParams:
    json_path: Path | None = None
    txt_path: Path | None = None
    out_dir = DEFAULT_OUTPUT_DIR
    out_dir_explicit = False
    fast = False
    suite_path: Path | None = None
    idx = 0
    while idx < len(args):
        arg = args[idx]
        if arg == "--out-dir":
            if idx + 1 >= len(args):
                raise Namel3ssError(_missing_flag_value("--out-dir"))
            out_dir = Path(args[idx + 1])
            out_dir_explicit = True
            idx += 2
            continue
        if arg.startswith("--out-dir="):
            out_dir = Path(arg.split("=", 1)[1])
            out_dir_explicit = True
            idx += 1
            continue
        if arg == "--json":
            if idx + 1 >= len(args):
                raise Namel3ssError(_missing_flag_value("--json"))
            json_path = Path(args[idx + 1])
            idx += 2
            continue
        if arg.startswith("--json="):
            json_path = Path(arg.split("=", 1)[1])
            idx += 1
            continue
        if arg == "--txt":
            if idx + 1 >= len(args):
                raise Namel3ssError(_missing_flag_value("--txt"))
            txt_path = Path(args[idx + 1])
            idx += 2
            continue
        if arg.startswith("--txt="):
            txt_path = Path(arg.split("=", 1)[1])
            idx += 1
            continue
        if arg == "--fast":
            fast = True
            idx += 1
            continue
        if arg.startswith("--"):
            raise Namel3ssError(_unknown_flag_message(arg))
        if suite_path is not None:
            raise Namel3ssError(_too_many_args_message())
        suite_path = Path(arg)
        idx += 1
    suite_path = suite_path or Path.cwd() / "evals"
    json_path = json_path or (out_dir / DEFAULT_JSON_NAME)
    if txt_path is None and out_dir_explicit:
        txt_path = out_dir / DEFAULT_TXT_NAME
    return _EvalParams(suite_path=suite_path, json_path=json_path, txt_path=txt_path, fast=fast)


def _missing_flag_value(flag: str) -> str:
    if flag == "--out-dir":
        example = "n3 eval --out-dir .namel3ss/outcome"
    else:
        name = DEFAULT_TXT_NAME if flag == "--txt" else DEFAULT_JSON_NAME
        example = f"n3 eval {flag} .namel3ss/outcome/{name}"
    return build_guidance_message(
        what=f"{flag} flag is missing a value.",
        why="eval requires a file path when the flag is present.",
        fix=f"Pass a path after {flag}.",
        example=example,
    )


def _unknown_flag_message(flag: str) -> str:
    return build_guidance_message(
        what=f"Unknown flag '{flag}'.",
        why="eval supports --json, --txt, --out-dir, and --fast.",
        fix="Remove the unsupported flag.",
        example="n3 eval --out-dir .namel3ss/outcome",
    )


def _too_many_args_message() -> str:
    return build_guidance_message(
        what="eval accepts at most one positional path.",
        why="Provide a suite.json file or a directory containing suite.json.",
        fix="Remove the extra arguments.",
        example="n3 eval evals",
    )


def _missing_prompt_name_message() -> str:
    return build_guidance_message(
        what="Prompt name is missing.",
        why="Prompt eval needs a prompt name.",
        fix="Provide the prompt name after 'prompt'.",
        example="n3 eval prompt summary_prompt --input samples.json",
    )


def _missing_prompt_flag(flag: str) -> str:
    example = "n3 eval prompt summary_prompt --input samples.json"
    if flag == "--out-dir":
        example = "n3 eval prompt summary_prompt --input samples.json --out-dir .namel3ss/observability/evals"
    if flag == "--app":
        example = "n3 eval prompt summary_prompt --input samples.json --app app.ai"
    return build_guidance_message(
        what=f"{flag} flag is missing a value.",
        why="Prompt eval needs a value for this flag.",
        fix=f"Provide a value after {flag}.",
        example=example,
    )


def _unknown_prompt_flag(flag: str) -> str:
    return build_guidance_message(
        what=f"Unknown flag '{flag}'.",
        why="Prompt eval supports --input, --out-dir, --app, and --json.",
        fix="Remove the unsupported flag.",
        example="n3 eval prompt summary_prompt --input samples.json",
    )


def _too_many_prompt_args_message() -> str:
    return build_guidance_message(
        what="eval prompt accepts at most one prompt name.",
        why="Provide a single prompt name.",
        fix="Remove the extra arguments.",
        example="n3 eval prompt summary_prompt --input samples.json",
    )


def _missing_flow_name_message() -> str:
    return build_guidance_message(
        what="Flow name is missing.",
        why="Flow eval needs an AI flow name.",
        fix="Provide the flow name after 'flow'.",
        example='n3 eval flow "answer_question"',
    )


def _missing_flow_flag(flag: str) -> str:
    example = 'n3 eval flow "answer_question" --app app.ai'
    if flag == "--out-dir":
        example = 'n3 eval flow "answer_question" --out-dir .namel3ss/observability/evals/ai'
    return build_guidance_message(
        what=f"{flag} flag is missing a value.",
        why="Flow eval needs a value for this flag.",
        fix=f"Provide a value after {flag}.",
        example=example,
    )


def _unknown_flow_flag(flag: str) -> str:
    return build_guidance_message(
        what=f"Unknown flag '{flag}'.",
        why="Flow eval supports --app, --out-dir, and --json.",
        fix="Remove the unsupported flag.",
        example='n3 eval flow "answer_question" --json',
    )


def _too_many_flow_args_message() -> str:
    return build_guidance_message(
        what="eval flow accepts at most one flow name.",
        why="Provide a single AI flow name.",
        fix="Remove extra arguments.",
        example='n3 eval flow "answer_question"',
    )


__all__ = ["run_eval_command"]
