"""Bundled read-only examples for namel3ss."""
