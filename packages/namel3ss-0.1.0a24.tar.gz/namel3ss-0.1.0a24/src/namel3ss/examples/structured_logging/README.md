# Structured Logging Example

Project: {{PROJECT_NAME}}

Single-concept example: emit structured log events, a counter metric, and trace spans from a flow.

How to use it:
- copy this folder to a new project directory
- run `n3 app.ai check`
- run `n3 run` to try it in the browser and view Logs, Tracing, and Metrics in Studio
