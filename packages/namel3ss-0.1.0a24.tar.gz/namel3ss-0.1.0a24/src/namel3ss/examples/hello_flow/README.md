# Hello Flow Example

Project: {{PROJECT_NAME}}

Single-concept example: one flow creates a record and a page renders it.

How to use it:
- copy this folder to a new project directory
- run `n3 app.ai check`
- run `n3 run` to try it in the browser
