from __future__ import annotations

from namel3ss.ast.pages import SliderItem

__all__ = ["SliderItem"]

