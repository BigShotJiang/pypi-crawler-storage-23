from __future__ import annotations

from namel3ss.ast.pages import TooltipItem

__all__ = ["TooltipItem"]

