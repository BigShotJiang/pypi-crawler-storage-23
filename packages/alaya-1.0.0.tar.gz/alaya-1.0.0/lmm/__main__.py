"""Allow ``python -m lmm`` to invoke the CLI."""

from lmm.cli import main

main()
