
# Licenses

## This Project

```text
    --8<-- "license.md"
```

## Third-Party Libraries

### License Summary

{{ make_third_party_license_summary() }}

### Details

{{ make_third_party_license_table() }}
