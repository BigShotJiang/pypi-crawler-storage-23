<search-stock-image-tool>
Search royalty-free stock images from Pixabay for design work.

<best-practices>
- Best for: stock photography, illustrations, backgrounds, abstract concepts
- All images are royalty-free with commercial usage rights
- Image URLs are auto-verified for accessibility before returning
- Use `download` tool to save images you need
- For specific characters/celebrities/real-world entities, use search_image instead
</best-practices>
</search-stock-image-tool>
