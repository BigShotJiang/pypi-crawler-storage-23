"""Tests for token counters."""

from context_manager.budget.char_counter import CharCounter


class TestCharCounter:
    def test_basic_count(self):
        counter = CharCounter(chars_per_token=4)
        assert counter.count("hello world!") == 3  # 12 chars / 4

    def test_minimum_one(self):
        counter = CharCounter()
        assert counter.count("a") == 1

    def test_model_name(self):
        counter = CharCounter()
        assert counter.model_name() == "char-estimate"

    def test_custom_ratio(self):
        counter = CharCounter(chars_per_token=2)
        assert counter.count("abcdef") == 3


class TestGetCounter:
    def test_fallback_to_char_counter(self):
        """When no optional deps installed, should fall back gracefully."""
        from context_manager.budget import get_counter

        counter = get_counter("unknown-model-xyz")
        # Should not raise — falls back to CharCounter or tiktoken.
        assert counter.count("hello") >= 1
