"""Tests for context_manager.models."""

from context_manager.models import ContextBlock, Priority


class TestPriority:
    def test_ordering(self):
        assert Priority.LOW < Priority.MEDIUM < Priority.HIGH < Priority.CRITICAL

    def test_from_str(self):
        assert Priority.from_str("critical") == Priority.CRITICAL
        assert Priority.from_str("LOW") == Priority.LOW
        assert Priority.from_str("Medium") == Priority.MEDIUM

    def test_int_values(self):
        assert int(Priority.LOW) == 1
        assert int(Priority.CRITICAL) == 4


class TestContextBlock:
    def test_defaults(self):
        block = ContextBlock(content="hello")
        assert block.role == "user"
        assert block.priority == Priority.MEDIUM
        assert block.metadata == {}
        assert block.token_count is None
        assert len(block.id) == 8

    def test_string_priority_conversion(self):
        block = ContextBlock(content="x", priority="high")
        assert block.priority == Priority.HIGH

    def test_custom_role_and_metadata(self):
        block = ContextBlock(
            content="data",
            role="system",
            priority=Priority.CRITICAL,
            metadata={"source": "rag"},
        )
        assert block.role == "system"
        assert block.metadata["source"] == "rag"
