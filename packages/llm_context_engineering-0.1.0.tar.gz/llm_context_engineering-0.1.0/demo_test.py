"""
End-to-end demo of llm-context-manager
=======================================
Run with: python demo_test.py

This walks through every step of the pipeline so you can see
what happens at each stage: adding blocks, token counting,
priority pruning, compilation, and visualization.
"""

from context_manager.engine import ContextEngine
from context_manager.models import ContextBlock, Priority
from context_manager.budget.char_counter import CharCounter
from context_manager.strategies.priority import PriorityPruning

# ── helpers ──────────────────────────────────────────────────────────────────

SEPARATOR = "=" * 70


def header(title: str) -> None:
    print(f"\n{SEPARATOR}")
    print(f"  {title}")
    print(SEPARATOR)


# ── Step 1: Initialize the engine ────────────────────────────────────────────

header("STEP 1 — Initialize the Engine")

# Using CharCounter (1 char = 1 token) so the math is easy to follow.
# In production you'd just pass model="gpt-4" and it auto-resolves.
engine = ContextEngine(
    model="demo",
    token_limit=200,
    pruning_strategy=PriorityPruning(),
    counter=CharCounter(chars_per_token=1),  # 1 char = 1 token
)

print(f"  Model       : {engine._model}")
print(f"  Token limit : {engine.token_limit}")
print(f"  Counter     : {engine._counter.__class__.__name__}")
print(f"  Strategy    : {engine._strategy.__class__.__name__}")

# ── Step 2: Add context blocks with different priorities ─────────────────────

header("STEP 2 — Add Context Blocks")

blocks_to_add = [
    ContextBlock(
        content="You are a helpful AI assistant specialized in Python programming.",
        role="system",
        priority="critical",
    ),
    ContextBlock(
        content="User: How do I use list comprehensions in Python?",
        role="history",
        priority="high",
    ),
    ContextBlock(
        content="AI: List comprehensions provide a concise way to create lists.",
        role="history",
        priority="high",
    ),
    ContextBlock(
        content="Python list comprehensions were introduced in PEP 202 and allow "
                "developers to generate new lists by applying an expression to each "
                "item in an existing iterable.",
        role="rag_context",
        priority="medium",
    ),
    ContextBlock(
        content="Guido van Rossum created Python in 1991. He was born in the "
                "Netherlands. Python is named after Monty Python.",
        role="rag_context",
        priority="low",
        metadata={"source": "wikipedia", "relevance": 0.3},
    ),
    ContextBlock(
        content="The weather in Jakarta today is sunny with a high of 33°C. "
                "This is completely irrelevant to the user's question.",
        role="rag_context",
        priority="low",
        metadata={"source": "weather_api", "relevance": 0.01},
    ),
]

for i, block in enumerate(blocks_to_add, 1):
    engine.add(block)
    print(f"  [{i}] Added: role={block.role:12s} | priority={block.priority.name:8s} | "
          f"tokens={block.token_count:>3d} | content={block.content[:50]}...")

print(f"\n  Total blocks : {len(engine.blocks)}")
print(f"  Total tokens : {engine.total_tokens}")
print(f"  Token limit  : {engine.token_limit}")
print(f"  Over budget? : {'YES ⚠️' if engine.total_tokens > engine.token_limit else 'No ✅'}")

# ── Step 3: Compile (triggers priority pruning) ─────────────────────────────

header("STEP 3 — Compile (Priority Pruning)")

print(f"  Before: {engine.total_tokens} tokens across {len(engine.blocks)} blocks")
print(f"  Budget: {engine.token_limit} tokens")
print()

result = engine.compile()

print(f"  After pruning: {engine.compiled_tokens} tokens across {len(result)} messages")
print(f"  Remaining budget: {engine.remaining_tokens} tokens")

# ── Step 4: Inspect what was kept vs dropped ─────────────────────────────────

header("STEP 4 — Summary (Kept vs Dropped)")

summary = engine.summary()
print(f"  Model          : {summary['model']}")
print(f"  Token limit    : {summary['token_limit']}")
print(f"  Total blocks   : {summary['total_blocks']}")
print(f"  Kept blocks    : {summary['kept_blocks']}")
print(f"  Dropped blocks : {summary['dropped_blocks']}")
print(f"  Compiled tokens: {summary['compiled_tokens']}")
print(f"  Remaining      : {summary['remaining_tokens']}")

if summary["dropped"]:
    print("\n  ❌ Dropped blocks:")
    for d in summary["dropped"]:
        print(f"     - id={d['id']} | role={d['role']:12s} | "
              f"priority={d['priority']:8s} | tokens={d['tokens']}")

# ── Step 5: Visualize token usage ────────────────────────────────────────────

header("STEP 5 — Visualization")

engine.visualize()

# ── Step 6: Show the final compiled output ───────────────────────────────────

header("STEP 6 — Final Compiled Messages (ready for LLM)")

for i, msg in enumerate(result, 1):
    print(f"\n  Message {i}:")
    print(f"    role   : {msg['role']}")
    print(f"    content: {msg['content'][:80]}{'...' if len(msg['content']) > 80 else ''}")

# ── Step 7: Show registry auto-resolution ────────────────────────────────────

header("STEP 7 — Registry Auto-Resolution (which counter for which model?)")

from context_manager.budget.registry import get_counter

test_models = [
    "gpt-4",
    "gpt-4o",
    "o1",
    "o3-mini",
    "meta-llama/Meta-Llama-3-8B",
    "gemini-2.0-flash",
    "gemma-2-9b",
    "claude-sonnet-4-20250514",
    "claude-3-haiku-20240307",
    "some-unknown-model",
]

for model in test_models:
    try:
        counter = get_counter(model)
        name = counter.__class__.__name__
    except ImportError as e:
        name = f"ImportError ({e.__class__.__name__})"
    except Exception as e:
        name = f"Error: {e}"
    print(f"  {model:40s} → {name}")

# ── Done ─────────────────────────────────────────────────────────────────────

header("DONE ✅")
print("  All steps completed successfully!")
print("  Delete this file when you're done: rm demo_test.py\n")
