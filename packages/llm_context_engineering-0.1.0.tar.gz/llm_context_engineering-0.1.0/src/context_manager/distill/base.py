"""Base classes for context distillation (token compression)."""

from __future__ import annotations

from abc import ABC, abstractmethod


class Compressor(ABC):
    """Abstract base class for context compressors."""

    @abstractmethod
    def compress(
        self,
        text: str,
        target_token_count: int | None = None,
    ) -> str:
        """Compress the given text to reduce token usage.

        Args:
            text: The input text to compress.
            target_token_count: Optional target token count. If not
                provided, the compressor uses its default strategy
                (e.g. keeping top 50% of information).

        Returns:
            The compressed text string.
        """

    @abstractmethod
    def model_name(self) -> str:
        """Return the name or identifier of the underlying model."""
