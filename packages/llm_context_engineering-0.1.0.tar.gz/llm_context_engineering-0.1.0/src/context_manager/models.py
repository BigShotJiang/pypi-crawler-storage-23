"""Core data models for context blocks."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from uuid import uuid4


class Priority(enum.IntEnum):
    """Priority levels for context blocks (higher value = higher priority)."""

    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4

    @classmethod
    def from_str(cls, value: str) -> Priority:
        """Create Priority from a case-insensitive string."""
        return cls[value.upper()]


@dataclass
class ContextBlock:
    """A single unit of context to include in the LLM prompt.

    Attributes:
        content: The text content of this block.
        role: Semantic role (e.g. 'system', 'history', 'rag_context').
        priority: Importance level for budget pruning.
        metadata: Optional key-value metadata.
        token_count: Cached token count (set by the engine).
        id: Unique identifier for this block.
    """

    content: str
    role: str = "user"
    priority: Priority | str = Priority.MEDIUM
    metadata: dict | None = None
    token_count: int | None = None
    can_compress: bool = False
    id: str = field(default_factory=lambda: uuid4().hex[:8])

    def __post_init__(self) -> None:
        if isinstance(self.priority, str):
            self.priority = Priority.from_str(self.priority)
        if self.metadata is None:
            self.metadata = {}
