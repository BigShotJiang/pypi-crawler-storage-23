"""Token budget management — counting and limiting tokens."""

from context_manager.budget.base import TokenCounter
from context_manager.budget.registry import get_counter

__all__ = [
    "TokenCounter",
    "get_counter",
    "AnthropicCounter",
    "GoogleCounter",
]


def __getattr__(name: str):
    """Lazy imports to avoid requiring all optional dependencies."""
    if name == "GoogleCounter":
        from context_manager.budget.google_counter import GoogleCounter

        return GoogleCounter
    if name == "AnthropicCounter":
        from context_manager.budget.anthropic_counter import AnthropicCounter

        return AnthropicCounter
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
