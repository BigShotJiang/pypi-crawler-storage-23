"""Abstract base class for token counters."""

from __future__ import annotations

from abc import ABC, abstractmethod


class TokenCounter(ABC):
    """Interface for counting tokens in a string."""

    @abstractmethod
    def count(self, text: str) -> int:
        """Return the number of tokens in *text*."""

    @abstractmethod
    def model_name(self) -> str:
        """Return the model identifier this counter targets."""
