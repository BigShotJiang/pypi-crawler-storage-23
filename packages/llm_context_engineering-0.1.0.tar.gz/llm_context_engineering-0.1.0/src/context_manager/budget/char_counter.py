"""Simple character-based fallback counter (no dependencies)."""

from __future__ import annotations

from context_manager.budget.base import TokenCounter

# Rough average: 1 token ≈ 4 characters for English text.
_CHARS_PER_TOKEN = 4


class CharCounter(TokenCounter):
    """Estimate token count by character length (dependency-free fallback)."""

    def __init__(self, chars_per_token: int = _CHARS_PER_TOKEN) -> None:
        self._ratio = chars_per_token

    def count(self, text: str) -> int:
        """Return estimated token count."""
        return max(1, len(text) // self._ratio)

    def model_name(self) -> str:
        return "char-estimate"
