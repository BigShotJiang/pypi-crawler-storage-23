"""Semantic pruning — deduplicate context blocks by meaning."""

from context_manager.prune.base import Embedder
from context_manager.prune.deduplicator import Deduplicator

__all__ = ["Deduplicator", "Embedder", "FastEmbedEmbedder"]


def __getattr__(name: str):
    """Lazy imports to avoid requiring fastembed at import time."""
    if name == "FastEmbedEmbedder":
        from context_manager.prune.fastembed_embedder import (
            FastEmbedEmbedder,
        )

        return FastEmbedEmbedder
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
