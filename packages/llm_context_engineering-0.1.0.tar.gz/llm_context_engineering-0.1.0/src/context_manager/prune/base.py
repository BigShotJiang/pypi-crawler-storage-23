"""Abstract base class for embedding providers."""

from __future__ import annotations

from abc import ABC, abstractmethod


class Embedder(ABC):
    """Interface for generating vector embeddings from text.

    Implementations convert a list of text strings into dense float
    vectors suitable for similarity comparison.
    """

    @abstractmethod
    def embed(self, texts: list[str]) -> list[list[float]]:
        """Return an embedding vector for each string in *texts*."""

    @abstractmethod
    def model_name(self) -> str:
        """Return the identifier of the embedding model in use."""
