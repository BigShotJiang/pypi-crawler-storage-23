"""Abstract base for pruning strategies."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from context_manager.models import ContextBlock


class PruningStrategy(ABC):
    """Interface for deciding which blocks to keep within a token budget."""

    @abstractmethod
    def prune(
        self,
        blocks: list[ContextBlock],
        token_budget: int,
    ) -> list[ContextBlock]:
        """Return a subset of *blocks* that fits within *token_budget*.

        Each block must already have ``token_count`` populated.
        """
