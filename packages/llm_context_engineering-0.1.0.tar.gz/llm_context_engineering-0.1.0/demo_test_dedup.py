"""
End-to-end demo of Semantic Pruner (Deduplicator)
===================================================
Run with: python demo_test_dedup.py

This demonstrates both block-level and chunk-level deduplication
using real FastEmbed embeddings — no mocks.
"""

from context_manager.engine import ContextEngine
from context_manager.models import ContextBlock, Priority
from context_manager.budget.char_counter import CharCounter
from context_manager.prune import Deduplicator
from context_manager.strategies.priority import PriorityPruning

# ── helpers ──────────────────────────────────────────────────────────────────

SEPARATOR = "=" * 70


def header(title: str) -> None:
    print(f"\n{SEPARATOR}")
    print(f"  {title}")
    print(SEPARATOR)


# ── Step 1: Block-level deduplication ────────────────────────────────────────

header("STEP 1 — Block-Level Deduplication")

print("  Initialising FastEmbed model (first run downloads ~50 MB)...\n")

dedup = Deduplicator(threshold=0.85)

blocks = [
    ContextBlock(
        content=(
            "Python is one of the most popular programming languages in the world. "
            "It was created by Guido van Rossum and first released in 1991. Python "
            "emphasizes code readability with its notable use of significant indentation. "
            "Its language constructs and object-oriented approach aim to help programmers "
            "write clear, logical code for small and large-scale projects."
        ),
        role="rag_context",
        priority="high",
        metadata={"source": "doc_1", "topic": "python_overview"},
    ),
    ContextBlock(
        content=(
            "Guido van Rossum developed Python in the late 1980s and released it in 1991. "
            "Python is widely regarded as one of the most popular programming languages today. "
            "The language is known for its clear syntax and readability, making it ideal for "
            "beginners and experienced developers alike. Python supports multiple programming "
            "paradigms including procedural, object-oriented, and functional programming."
        ),
        role="rag_context",
        priority="medium",
        metadata={"source": "doc_2", "topic": "python_overview"},
    ),
    ContextBlock(
        content=(
            "Machine learning is a subset of artificial intelligence that focuses on "
            "building systems that learn from data. Unlike traditional programming where "
            "rules are explicitly coded, ML algorithms identify patterns in data and make "
            "decisions with minimal human intervention. Common ML techniques include "
            "supervised learning, unsupervised learning, and reinforcement learning."
        ),
        role="rag_context",
        priority="medium",
        metadata={"source": "doc_3", "topic": "machine_learning"},
    ),
    ContextBlock(
        content=(
            "Python programming language was designed by Guido van Rossum and made "
            "available to the public in 1991. Python has gained enormous popularity "
            "because of its simple and readable syntax. It is commonly used in web "
            "development, data science, artificial intelligence, and scientific computing. "
            "Python's design philosophy emphasizes code readability and simplicity."
        ),
        role="rag_context",
        priority="low",
        metadata={"source": "doc_4", "topic": "python_overview"},
    ),
    ContextBlock(
        content=(
            "Docker is a platform for developing, shipping, and running applications "
            "inside lightweight containers. Containers package an application with all "
            "its dependencies, ensuring consistency across development, testing, and "
            "production environments. Docker uses OS-level virtualization and is much "
            "more efficient than traditional virtual machines."
        ),
        role="rag_context",
        priority="medium",
        metadata={"source": "doc_5", "topic": "docker"},
    ),
]

print(f"  Total blocks BEFORE dedup: {len(blocks)}\n")
for i, b in enumerate(blocks, 1):
    src = b.metadata.get("source", "?")
    topic = b.metadata.get("topic", "?")
    print(
        f"  [{i}] source={src:6s} | topic={topic:20s} | "
        f"priority={b.priority.name:8s} | {b.content[:60]}..."
    )

result = dedup.deduplicate(blocks)

print(f"\n  Total blocks AFTER dedup : {len(result)}")
print(f"  Removed: {len(blocks) - len(result)} duplicate(s)\n")
for i, b in enumerate(result, 1):
    src = b.metadata.get("source", "?")
    topic = b.metadata.get("topic", "?")
    print(
        f"  ✅ [{i}] source={src:6s} | topic={topic:20s} | "
        f"priority={b.priority.name:8s} | {b.content[:60]}..."
    )


# ── Step 2: Chunk-level deduplication ────────────────────────────────────────

header("STEP 2 — Chunk-Level Deduplication (inside a single block)")

rag_block = ContextBlock(
    content=(
        "Python is a high-level, general-purpose programming language. Its design "
        "philosophy emphasizes code readability with the use of significant indentation. "
        "Python is dynamically typed and garbage-collected. It supports multiple "
        "programming paradigms, including structured, object-oriented, and functional "
        "programming."
        "\n\n"
        "Kubernetes is an open-source container orchestration system for automating "
        "software deployment, scaling, and management. Originally designed by Google, "
        "it is now maintained by the Cloud Native Computing Foundation. Kubernetes "
        "works with Docker and other container runtimes."
        "\n\n"
        "The Python programming language was created by Guido van Rossum and was first "
        "released in 1991. Python is designed to be highly readable and uses significant "
        "whitespace. It supports object-oriented, procedural, and functional programming "
        "paradigms and has a comprehensive standard library."
        "\n\n"
        "RESTful APIs use HTTP methods to perform CRUD operations on resources. The most "
        "common methods are GET, POST, PUT, PATCH, and DELETE. REST is stateless, meaning "
        "each request contains all the information needed to process it. This architecture "
        "is widely used in modern web services and microservices."
        "\n\n"
        "Python is a versatile language known for its simplicity and readability. Guido "
        "van Rossum released the first version of Python in 1991. The language has grown "
        "to become one of the most widely-used programming languages, especially popular "
        "in data science, machine learning, and web development."
    ),
    role="rag_context",
    priority="medium",
    metadata={"source": "vector_db", "query": "Python programming"},
)

chunks_before = [c.strip() for c in rag_block.content.split("\n\n") if c.strip()]
print(f"  Total chunks BEFORE dedup: {len(chunks_before)}\n")
for i, chunk in enumerate(chunks_before, 1):
    print(f"  [{i}] {chunk[:80]}...")

cleaned_block = dedup.deduplicate_chunks(rag_block, separator="\n\n")
chunks_after = [c.strip() for c in cleaned_block.content.split("\n\n") if c.strip()]

print(f"\n  Total chunks AFTER dedup : {len(chunks_after)}")
print(f"  Removed: {len(chunks_before) - len(chunks_after)} duplicate chunk(s)\n")
for i, chunk in enumerate(chunks_after, 1):
    print(f"  ✅ [{i}] {chunk[:80]}...")


# ── Step 3: Full pipeline with engine ────────────────────────────────────────

header("STEP 3 — Full Pipeline (Chunk Dedup → Block Dedup → Priority Pruning)")

engine = ContextEngine(
    model="demo",
    token_limit=500,
    pruning_strategy=PriorityPruning(),
    counter=CharCounter(chars_per_token=1),
    deduplicator=dedup,
)

# System prompt — critical, always kept
engine.add(ContextBlock(
    content="You are a helpful AI assistant specialized in Python programming.",
    role="system",
    priority="critical",
))

# User question
engine.add(ContextBlock(
    content="User: What are list comprehensions in Python?",
    role="history",
    priority="high",
))

# Pre-cleaned RAG block (chunk-deduped)
engine.add(cleaned_block)

# Another duplicate RAG block (will be caught by block-level dedup)
engine.add(ContextBlock(
    content=(
        "Python is a high-level programming language with clean, readable syntax. "
        "Created by Guido van Rossum and first released in 1991, Python supports "
        "multiple paradigms including OOP, procedural, and functional programming."
    ),
    role="rag_context",
    priority="low",
    metadata={"source": "doc_duplicate"},
))

# Irrelevant context — low priority, likely dropped by budget
engine.add(ContextBlock(
    content=(
        "The weather in Jakarta today is sunny with a high of 33°C and humidity "
        "at 75%. Tomorrow expects scattered showers in the afternoon with "
        "temperatures ranging from 25°C to 31°C."
    ),
    role="rag_context",
    priority="low",
    metadata={"source": "weather_api"},
))

print(f"  Blocks added   : {len(engine.blocks)}")
print(f"  Total tokens   : {engine.total_tokens}")
print(f"  Token limit    : {engine.token_limit}")
print(f"  Over budget?   : {'YES ⚠️' if engine.total_tokens > engine.token_limit else 'No ✅'}")

result = engine.compile()

print(f"\n  After compile:")
print(f"  Kept messages  : {len(result)}")
print(f"  Compiled tokens: {engine.compiled_tokens}")
print(f"  Remaining      : {engine.remaining_tokens}")

# ── Step 4: Show summary & visualization ─────────────────────────────────────

header("STEP 4 — Summary")

summary = engine.summary()
print(f"  Total blocks   : {summary['total_blocks']}")
print(f"  Kept blocks    : {summary['kept_blocks']}")
print(f"  Dropped blocks : {summary['dropped_blocks']}")

if summary["dropped"]:
    print("\n  ❌ Dropped blocks:")
    for d in summary["dropped"]:
        print(
            f"     - id={d['id']} | role={d['role']:12s} | "
            f"priority={d['priority']:8s} | tokens={d['tokens']}"
        )

header("STEP 5 — Visualization")
engine.visualize()

# ── Step 5: Final output ─────────────────────────────────────────────────────

header("STEP 6 — Final Compiled Messages (ready for LLM)")

for i, msg in enumerate(result, 1):
    content = msg["content"]
    print(f"\n  Message {i}:")
    print(f"    role   : {msg['role']}")
    print(f"    content: {content[:100]}{'...' if len(content) > 100 else ''}")

# ── Done ─────────────────────────────────────────────────────────────────────

header("DONE ✅")
print("  All deduplication steps completed successfully!")
print("  Delete this file when you're done: rm demo_test_dedup.py\n")
