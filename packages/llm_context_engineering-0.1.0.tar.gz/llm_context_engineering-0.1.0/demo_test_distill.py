"""
End-to-end demo of Context Distillation (LLMLingua-2)
=====================================================
Run with: python demo_test_distill.py

This demonstrates compressing a long context block using the
microsoft/llmlingua-2-xlm-roberta-large-meetingbank model.
"""

from context_manager.distill import LLMLinguaCompressor
from context_manager.engine import ContextEngine
from context_manager.models import ContextBlock, Priority
from context_manager.budget.char_counter import CharCounter

SEPARATOR = "=" * 70


def header(title: str) -> None:
    print(f"\n{SEPARATOR}")
    print(f"  {title}")
    print(SEPARATOR)


# ── Step 1: Initialize Compressor ────────────────────────────────────────────

header("STEP 1 — Initialize LLMLingua-2 Compressor")
print("  Loading model (this may take a moment on first run)...")

# Using the recommended small model for distillation
compressor = LLMLinguaCompressor(
    model_name="microsoft/llmlingua-2-xlm-roberta-large-meetingbank",
    device_map="cpu",  # Use "cuda" or "mps" if available
)
print("  Compressor initialized.")


# ── Step 2: Define Long Context ──────────────────────────────────────────────

header("STEP 2 — original Long Context")

# A sample text about the history of computing (approx. 300 words)
long_text = (
    "The history of computing is longer than the history of computing hardware "
    "and modern computing technology and includes the history of methods intended "
    "for pen and paper or for chalk and slate, with or without the aid of tables. "
    "Concrete devices (digital computing processors) have a long history. "
    "The earliest known tool for use in computation is the abacus, and it was thought "
    "to have been invented in Babylon circa 2400 BC. Its original style of usage was "
    "by lines drawn in sand with pebbles. Abaci are still used today. "
    "The Antikythera mechanism is believed to be the earliest known mechanical analog "
    "computer. It was designed to calculate astronomical positions. It was likely "
    "constructed in 100 BC. "
    "Charles Babbage, an English mechanical engineer and polymath, originated the "
    "concept of a programmable computer. Considered the 'father of the computer', "
    "he conceptualized and invented the first mechanical computer in the early 19th "
    "century. After working on his revolutionary difference engine, designed to aid "
    "in navigational calculations, in 1833 he realized that a much more general design, "
    "an Analytical Engine, was possible. The input of programs and data was to be "
    "provided to the machine via punched cards, a method being used at the time to "
    "direct mechanical looms such as the Jacquard loom. For output, the machine would "
    "have a printer, a curve plotter and a bell. The machine would also be able to "
    "punch numbers onto cards to be read in later. The Engine incorporated an "
    "arithmetic logic unit, control flow in the form of conditional branching and "
    "loops, and integrated memory, making it the first design for a general-purpose "
    "computer that could be described in modern terms as Turing-complete."
)

original_len = len(long_text)
print(f"  Length: {original_len} chars")
print(f"  Preview: {long_text[:100]}...")


# ── Step 3: Run Compression via Engine ───────────────────────────────────────

header("STEP 3 — Run Compression via ContextEngine")

engine = ContextEngine(
    model="demo",
    token_limit=1000,
    compressor=compressor,
    counter=CharCounter(),  # Simple char counter for demo
)

# Add a block marked for compression
engine.add(ContextBlock(
    content=long_text,
    role="rag_context",
    priority=Priority.HIGH,
    can_compress=True,  # <--- This triggers the compressor
    metadata={"source": "wikipedia_history_of_computing"},
))

# Add a control block (NOT compressed)
control_text = "This is a short control block that should remain untouched."
engine.add(ContextBlock(
    content=control_text,
    role="user",
    can_compress=False,
))

print("  Compiling context...")
result = engine.compile()

# Analyze results
compressed_block = result[0]
control_block = result[1]
compressed_text = compressed_block["content"]

compressed_len = len(compressed_text)
ratio = compressed_len / original_len

print(f"\n  Original Length   : {original_len} chars")
print(f"  Compressed Length : {compressed_len} chars")
print(f"  Compression Ratio : {ratio:.2f} (approx {(1-ratio)*100:.1f}% reduction)")
print(f"\n  Compressed Text Preview:\n  {compressed_text[:200]}...")

print("\n  Control Block check:")
if control_block["content"] == control_text:
    print("  ✅ Control block remained unchanged.")
else:
    print("  ❌ Control block was modified!")


# ── Conclusion ───────────────────────────────────────────────────────────────

header("DONE ✅")
print("  Context Distillation demo completed.")
print("  Delete this file when done: rm demo_test_distill.py")
