# atlas_occurrences()
"""
if atlas in ["Australia","ALA"]:

    # check for assertions and lump them with filters, as filters takes care of these
    if filters is not None and assertions is not None:
        if type(assertions) is list:
            filters += assertions
        else:
            filters.append(assertions)
    elif filters is None and assertions is not None:
        filters=assertions

    # create payload
    payload = add_to_payload_ALA(payload=payload,atlas=atlas,taxa=taxa,filters=filters,polygon=polygon,
                                bbox=bbox,simplify_polygon=simplify_polygon,scientific_name=scientific_name)

    # try this for payload
    if payload is None:
        return None

    # create the query id
    qid_URL, method2 = get_api_url(column1="api_name",column1value="occurrences_qid")
    qid = requests.request(method2,qid_URL,data=payload,headers=headers)

    # create the URL to grab your queryID and counts
    if use_data_profile:
        data_profile_list = list(show_all(profiles=True)['shortName'])
        baseURL = apply_data_profile(baseURL=baseURL,data_profile_list=data_profile_list)

    # Add qa=None to not get any assertions
    if fields is None:
        selected_fields = galah_select(select="basic",atlas=atlas)
        if mint_doi:
            URL = baseURL + "fq=%28qid%3A" + qid.text + "%29&" + selected_fields + "&qa=none&flimit=-1&mintDoi=TRUE"
        else:
            URL = baseURL + "fq=%28qid%3A" + qid.text + "%29&" + selected_fields + "&qa=none&flimit=-1"
    elif fields == "all":
        if mint_doi:
            URL = baseURL + "fq=%28qid%3A" + qid.text + "%29&qa=none&flimit=-1&mintDoi=TRUE"
        else:
            URL = baseURL + "fq=%28qid%3A" + qid.text + "%29&qa=none&flimit=-1"
    else:
        # print("am I here?")
        if mint_doi:
            URL = baseURL + "fq=%28qid%3A" + qid.text + "%29&" + galah_select(select=fields,atlas=atlas) + "&qa=none&flimit=-1&mintDoi=TRUE"
        else:
            URL = baseURL + "fq=%28qid%3A" + qid.text + "%29&" + galah_select(select=fields,atlas=atlas) + "&qa=none&flimit=-1"

    if verbose:
        print()
        print("headers: {}".format(headers))
        print("payload for queryID: {}".format(payload))
        print("queryID URL: {}".format(qid_URL))
        print("method: {}".format(method2))
        print()
        print("qid for query: {}".format(qid.text))
        print("URL for result:{}".format(URL))
        print("method: {}".format(method))
        print()

    # get data
    response = requests.request(method,URL,headers=headers)

else:
"""

# atlas_species()
"""
    # create payload variable so it is available for some atlases
    payload = {}
    
    if atlas in ["Australia","ALA"]:
        
        # create payload and add buffer to polygon if user specifies it
        payload = add_to_payload_ALA(payload=payload,atlas=atlas,taxa=taxa,filters=filters,polygon=polygon,
                                     bbox=bbox,simplify_polygon=simplify_polygon,scientific_name=scientific_name)

        # create the query id
        qid_URL, method2 = get_api_url(column1="api_name",column1value="occurrences_qid")
        qid = requests.request(method2,qid_URL,data=payload,headers=headers)
        
        # create the URL to grab the species ID and lists
        if use_data_profile:
            data_profile_list = list(show_all(profiles=True)['shortName'])
            baseURL = apply_data_profile(baseURL=baseURL,use_data_profile=use_data_profile,data_profile_list=data_profile_list)
            URL = baseURL + "fq=%28qid%3A" + qid.text + "%29&facets={}&lookup=True".format(rankID)
            if counts:
                URL += "&count=true"
        else:
            URL = baseURL + "?fq=%28qid%3A" + qid.text + "%29&facets={}&lookup=True".format(rankID)
            if counts:
                URL += "&count=true"

        if verbose:
            print()
            print("headers: {}".format(headers))
            print()
            print("payload for queryID: {}".format(payload))
            print("queryID URL: {}".format(qid_URL))
            print("method: {}".format(method2))
            print()
            print("qid for query: {}".format(qid.text))
            print("URL for result:{}".format(URL))
            print("method: {}".format(method))
            print()

        # get data
        response = requests.request(method,URL,headers=headers)

        # check for daily maximum
        if response.status_code == 429:
            raise ValueError("You have reached the maximum number of daily queries for the ALA.")
        
        # return data as pandas dataframe
        return pd.read_csv(io.StringIO(response.text))
"""

# galah_group_by
"""
if atlas in ["Australia","ALA"]:
    # try startingURL2
    #startingURL2,method = get_api_url(column1='called_by',column1value='atlas_counts',column2="api_name",
    #                            column2value="records_counts")

    # get response from your query, which will include all available fields
    qid_URL, method2 = get_api_url(column1="api_name",column1value="occurrences_qid")
    qid = requests.request(method2,qid_URL,data=payload,headers=headers)
    facets = "".join("&facets={}".format(g) for g in group_by)
    if startingURL[-1] == "&":
        URL = startingURL + "fq=%28qid%3A" + qid.text + "%29" + facets + "&flimit=-1&pageSize=0"
    else:
        URL = startingURL + "?fq=%28qid%3A" + qid.text + "%29" + facets + "&flimit=-1&pageSize=0"

    # check to see if the user wants the URL for querying
    if verbose:
        print()
        print("headers: {}".format(headers))
        print()
        print("payload for queryID: {}".format(payload))
        print("queryID URL: {}".format(qid_URL))
        print("method: {}".format(method2))
        print()
        print("qid for query: {}".format(qid.text))
        print("URL for result:{}".format(URL))
        print("method: {}".format(method))
        print()

    response = requests.request(method,URL,headers=headers)
    response_json = response.json()
    facets_array=[]

else:
"""

"""
            # loop over each facet
            #for facet in f:
            if atlas in ["Australia","ALA"]:
            
                # check for fq in payload
                if "fq" not in payload:
                    payload["fq"] = [f]
                else:
                    payload["fq"].append(f)
                    
                payload_for_querying = copy.deepcopy(payload)
                
                # create payload and get qid
                qid_URL, method2 = get_api_url(column1="api_name",column1value="occurrences_qid")
                qid = requests.request(method2,qid_URL,data=payload,headers=headers)
                if startingURL[-1] == "&":
                    tempURL = startingURL + "fq=%28qid%3A" + qid.text + "%29" 
                else:
                    tempURL = startingURL + "?fq=%28qid%3A" + qid.text + "%29"
                if any("lsid" in fq for fq in payload['fq']):
                    index = [idx for idx, s in enumerate(payload['fq']) if 'lsid' in s][0]
                    payload["fq"] = [payload["fq"][index]]
                else:
                    payload["fq"] = []
                if filters is not None:
                    payload = add_to_payload_ALA(payload=payload,
                                                    atlas=atlas,
                                                    filters=filters)
                tempURL += "&facets={}".format(group_by[-1])
                
            else:
            """


"""
atlas_occurrences()

    # # test to check if atlas is working
    # requestURL, method = get_api_url(
    #     column1="called_by",
    #     column1value="atlas_counts",
    #     column2="api_name",
    #     column2value="records_counts",
    # )
    # requestURL += "?pageSize=0"

    # # check if the atlas is working - if not, let the user know
    # response = requests.request(method, requestURL, headers=headers)
    # try:
    #     response.raise_for_status()
    #     if test:
    #         return
    # except requests.exceptions.HTTPError as e:
    #     print("The {} atlas might be down...")
    #     print("Error: " + str(e))
    #     sys.exit()
"""
