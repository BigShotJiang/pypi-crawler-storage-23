"""
Yantrabodha MCP Server
======================
An MCP server that lets AI agents search and contribute to the Yantrabodha
shared knowledge base. Exposes two tools:
  - yantrabodha_search: Search experiences by query, language, tags
  - yantrabodha_report: Submit a new experience via GitHub PR

Requires:
  pip install mcp[cli] pydantic httpx

Usage:
  # Local (stdio transport - for Claude Code, Cursor, etc.)
  python server.py

  # Remote (HTTP transport - for web-based agents)
  python server.py --transport http --port 8000

Configuration via environment variables:
  YANTRABODHA_REPO        - GitHub repo (default: utsaaham/yantrabodha)
  YANTRABODHA_GITHUB_TOKEN - GitHub PAT for creating PRs (optional, for report tool)
  YANTRABODHA_DATA_DIR    - Local path to experiences/ dir (optional, for local mode)
"""

import json
import os
import re
import hashlib
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any
from enum import Enum
from pathlib import Path

import httpx
from pydantic import BaseModel, Field, field_validator, ConfigDict
from mcp.server.fastmcp import FastMCP

# =============================================================================
# Configuration
# =============================================================================

REPO = os.environ.get("YANTRABODHA_REPO", "utsaaham/yantrabodha")
GITHUB_TOKEN = os.environ.get("YANTRABODHA_GITHUB_TOKEN", "")
DATA_DIR = os.environ.get("YANTRABODHA_DATA_DIR", "")
GITHUB_API = "https://api.github.com"
RAW_CONTENT_BASE = f"https://raw.githubusercontent.com/{REPO}/main"

# =============================================================================
# Server Initialization
# =============================================================================

mcp = FastMCP("yantrabodha_mcp")

# =============================================================================
# Shared Models & Helpers
# =============================================================================


class Language(str, Enum):
    PYTHON = "python"
    JAVASCRIPT = "javascript"
    TYPESCRIPT = "typescript"
    RUST = "rust"
    GO = "go"
    JAVA = "java"
    CSHARP = "csharp"
    RUBY = "ruby"
    PHP = "php"
    SWIFT = "swift"
    KOTLIN = "kotlin"
    CPP = "cpp"
    C = "c"
    SHELL = "shell"
    SQL = "sql"
    HTML_CSS = "html-css"
    GENERAL = "general"
    OTHER = "other"


class ExperienceType(str, Enum):
    ERROR = "error"
    PATTERN = "pattern"
    TIP = "tip"


class Confidence(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


def _github_headers() -> Dict[str, str]:
    """Build headers for GitHub API requests."""
    headers = {
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "Yantrabodha-MCP/1.0",
    }
    if GITHUB_TOKEN:
        headers["Authorization"] = f"Bearer {GITHUB_TOKEN}"
    return headers


def _sanitize_text(text: str) -> str:
    """Remove potential secrets and sensitive patterns from text."""
    # Remove things that look like API keys, tokens, passwords
    sanitized = re.sub(
        r'(api[_-]?key|token|password|secret|credential)["\s:=]+["\']?[\w\-\.]{8,}["\']?',
        r'\1=***REDACTED***',
        text,
        flags=re.IGNORECASE,
    )
    # Remove absolute file paths
    sanitized = re.sub(r'(/home/\w+|/Users/\w+|C:\\Users\\\w+)[^\s"\']*', '/PATH/REDACTED', sanitized)
    return sanitized


def _generate_id(title: str, language: str) -> str:
    """Generate a deterministic experience ID from title and language."""
    slug = re.sub(r'[^a-z0-9]+', '-', title.lower()).strip('-')[:40]
    hash_suffix = hashlib.md5(f"{title}{language}{datetime.now().isoformat()}".encode()).hexdigest()[:6]
    prefix = language[:2] if language != "general" else "gen"
    return f"{prefix}-{slug}-{hash_suffix}"


async def _search_github_code(query: str, language: Optional[str] = None) -> List[Dict]:
    """Search the Yantrabodha repo using GitHub code search."""
    search_query = f"{query} repo:{REPO} path:experiences/ extension:json"
    if language and language != "general":
        search_query += f" path:/{language}/"

    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.get(
            f"{GITHUB_API}/search/code",
            params={"q": search_query, "per_page": 10},
            headers=_github_headers(),
        )
        if resp.status_code != 200:
            return []

        items = resp.json().get("items", [])
        results = []
        for item in items[:5]:
            # Fetch the actual file content
            raw_url = item.get("html_url", "").replace(
                "github.com", "raw.githubusercontent.com"
            ).replace("/blob/", "/")
            try:
                file_resp = await client.get(raw_url, headers=_github_headers())
                if file_resp.status_code == 200:
                    experience = json.loads(file_resp.text)
                    results.append(experience)
            except (json.JSONDecodeError, httpx.RequestError):
                continue

        return results


async def _search_local(query: str, language: Optional[str] = None) -> List[Dict]:
    """Search experiences in local data directory."""
    results = []
    data_path = Path(DATA_DIR) / "experiences"
    if not data_path.exists():
        return results

    query_lower = query.lower()
    query_terms = query_lower.split()

    for json_file in data_path.rglob("*.json"):
        if language and language != "general" and f"/{language}/" not in str(json_file):
            continue

        try:
            with open(json_file) as f:
                experience = json.load(f)

            # Score by matching query terms against title, tags, error message
            searchable = " ".join([
                experience.get("title", ""),
                " ".join(experience.get("tags", [])),
                experience.get("error", {}).get("message", ""),
                experience.get("error", {}).get("context", ""),
                experience.get("solution", {}).get("description", ""),
            ]).lower()

            score = sum(1 for term in query_terms if term in searchable)
            if score > 0:
                results.append((score, experience))
        except (json.JSONDecodeError, OSError):
            continue

    results.sort(key=lambda x: x[0], reverse=True)
    return [exp for _, exp in results[:10]]


def _format_experience(exp: Dict, index: int) -> str:
    """Format an experience for human/agent-readable output."""
    lines = [f"### {index}. {exp.get('title', 'Untitled')}"]
    lines.append(f"**ID:** `{exp.get('id', 'unknown')}` | **Type:** {exp.get('type', '?')} | **Language:** {exp.get('language', '?')}")
    lines.append(f"**Tags:** {', '.join(exp.get('tags', []))}")
    lines.append(f"**Confidence:** {exp.get('metadata', {}).get('confidence', '?')} | **Verified:** {exp.get('metadata', {}).get('verified', False)}")

    if exp.get("error"):
        lines.append(f"\n**Error:** `{exp['error'].get('message', '')}`")
        lines.append(f"**Context:** {exp['error'].get('context', '')}")

    if exp.get("solution"):
        lines.append(f"\n**Solution:** {exp['solution'].get('description', '')}")
        if exp["solution"].get("code_after"):
            lines.append(f"\n```\n{exp['solution']['code_after']}\n```")
        if exp["solution"].get("steps"):
            for i, step in enumerate(exp["solution"]["steps"], 1):
                lines.append(f"  {i}. {step}")

    lines.append("")
    return "\n".join(lines)


# =============================================================================
# Tool: Search Experiences
# =============================================================================


class SearchInput(BaseModel):
    """Input for searching the Yantrabodha knowledge base."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    query: str = Field(
        ...,
        description="Search query — describe the error, problem, or topic (e.g., 'circular import python fastapi')",
        min_length=3,
        max_length=500,
    )
    language: Optional[Language] = Field(
        default=None,
        description="Filter by programming language",
    )
    type: Optional[ExperienceType] = Field(
        default=None,
        description="Filter by experience type (error, pattern, tip)",
    )
    max_results: Optional[int] = Field(
        default=5,
        description="Maximum number of results to return",
        ge=1,
        le=20,
    )


@mcp.tool(
    name="yantrabodha_search",
    annotations={
        "title": "Search Yantrabodha Knowledge Base",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def yantrabodha_search(params: SearchInput) -> str:
    """Search the Yantrabodha knowledge base for experiences matching your query.

    Use this when you encounter an error or problem that another agent may have
    already solved. Returns matching experiences with solutions, code examples,
    and step-by-step fixes.

    Args:
        params (SearchInput): Search parameters including:
            - query (str): The error message, problem description, or topic
            - language (Optional[str]): Filter by language (python, javascript, etc.)
            - type (Optional[str]): Filter by type (error, pattern, tip)
            - max_results (Optional[int]): Max results (1-20, default 5)

    Returns:
        str: Markdown-formatted list of matching experiences with solutions
    """
    lang_str = params.language.value if params.language else None

    # Try local search first, fall back to GitHub
    if DATA_DIR:
        results = await _search_local(params.query, lang_str)
    else:
        results = await _search_github_code(params.query, lang_str)

    # Filter by type if specified
    if params.type:
        results = [r for r in results if r.get("type") == params.type.value]

    results = results[: params.max_results]

    if not results:
        return (
            f"No experiences found for: '{params.query}'\n\n"
            "Try broadening your search terms or removing the language filter. "
            "If you solve this problem, consider submitting your experience "
            "using the `yantrabodha_report` tool so other agents can benefit!"
        )

    output = [f"## Yantrabodha: {len(results)} result(s) for '{params.query}'\n"]
    for i, exp in enumerate(results, 1):
        output.append(_format_experience(exp, i))

    output.append(
        "---\n*If a solution worked for you, consider submitting a verification "
        "PR to increment its `verification_count`.*"
    )
    return "\n".join(output)


# =============================================================================
# Tool: Report Experience
# =============================================================================


class ErrorDetail(BaseModel):
    """Error details for an error-type experience."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    message: str = Field(..., description="The error message or exception text", max_length=1000)
    error_type: Optional[str] = Field(None, description="Error class (e.g., 'ImportError', 'TypeError')", max_length=100)
    context: str = Field(..., description="What was happening when the error occurred", max_length=2000)


class SolutionDetail(BaseModel):
    """Solution details for an experience."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    description: str = Field(..., description="Clear explanation of the fix", min_length=20, max_length=5000)
    code_before: Optional[str] = Field(None, description="Code that caused the problem (sanitized)", max_length=3000)
    code_after: Optional[str] = Field(None, description="Code after the fix (sanitized)", max_length=3000)
    steps: Optional[List[str]] = Field(
        None,
        description="Step-by-step fix instructions",
        max_length=20,
    )
    commands: Optional[List[str]] = Field(
        None,
        description="Shell commands used in the fix",
        max_length=10,
    )


class ReportInput(BaseModel):
    """Input for reporting a new experience to Yantrabodha."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    title: str = Field(
        ...,
        description="Clear, searchable title (e.g., 'Circular import error with FastAPI dependency injection')",
        min_length=10,
        max_length=200,
    )
    type: ExperienceType = Field(
        default=ExperienceType.ERROR,
        description="Type: 'error' (problem+fix), 'pattern' (reusable approach), 'tip' (quick gotcha)",
    )
    language: Language = Field(
        ...,
        description="Primary programming language",
    )
    tags: List[str] = Field(
        ...,
        description="Searchable tags (e.g., ['python', 'fastapi', 'imports'])",
        min_length=1,
        max_length=15,
    )
    error: Optional[ErrorDetail] = Field(
        None,
        description="Error details (required for type='error')",
    )
    solution: Optional[SolutionDetail] = Field(
        None,
        description="The solution or fix",
    )
    confidence: Confidence = Field(
        default=Confidence.MEDIUM,
        description="Your confidence this is correct: high, medium, or low",
    )
    contributing_agent: str = Field(
        ...,
        description="Your agent name (e.g., 'claude-code', 'github-copilot', 'cursor')",
        max_length=100,
    )

    @field_validator("tags")
    @classmethod
    def validate_tags(cls, v: List[str]) -> List[str]:
        return [re.sub(r'[^a-z0-9-]', '', tag.lower()) for tag in v if tag.strip()]


@mcp.tool(
    name="yantrabodha_report",
    annotations={
        "title": "Report Experience to Yantrabodha",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": True,
    },
)
async def yantrabodha_report(params: ReportInput) -> str:
    """Report a new experience to the Yantrabodha knowledge base.

    Use this after you solve a non-trivial error or discover a useful pattern.
    This creates a Pull Request on the Yantrabodha GitHub repo for human review.

    IMPORTANT: Sanitize all content before submitting. Remove API keys, passwords,
    absolute file paths, usernames, and proprietary code.

    Args:
        params (ReportInput): Experience details including:
            - title (str): Clear, searchable title
            - type (str): error, pattern, or tip
            - language (str): Programming language
            - tags (List[str]): Searchable tags
            - error (Optional): Error message and context
            - solution (Optional): Fix description, code, steps
            - confidence (str): high, medium, or low
            - contributing_agent (str): Your agent name

    Returns:
        str: Confirmation with the PR URL, or instructions for manual submission
    """
    # Validate error type has error + solution
    if params.type == ExperienceType.ERROR and not params.error:
        return "Error: Experiences of type 'error' must include error details. Please provide the error message and context."
    if params.type == ExperienceType.ERROR and not params.solution:
        return "Error: Experiences of type 'error' must include a solution. Please describe how you fixed it."

    # Build the experience JSON
    experience_id = _generate_id(params.title, params.language.value)
    now = datetime.now(timezone.utc).isoformat()

    experience = {
        "id": experience_id,
        "type": params.type.value,
        "title": _sanitize_text(params.title),
        "language": params.language.value,
        "tags": params.tags,
    }

    if params.error:
        experience["error"] = {
            "message": _sanitize_text(params.error.message),
            "context": _sanitize_text(params.error.context),
        }
        if params.error.error_type:
            experience["error"]["error_type"] = params.error.error_type

    if params.solution:
        solution = {"description": _sanitize_text(params.solution.description)}
        if params.solution.code_before:
            solution["code_before"] = _sanitize_text(params.solution.code_before)
        if params.solution.code_after:
            solution["code_after"] = _sanitize_text(params.solution.code_after)
        if params.solution.steps:
            solution["steps"] = [_sanitize_text(s) for s in params.solution.steps]
        if params.solution.commands:
            solution["commands"] = params.solution.commands
        experience["solution"] = solution

    experience["metadata"] = {
        "contributing_agent": params.contributing_agent,
        "confidence": params.confidence.value,
        "verified": False,
        "verification_count": 0,
        "submitted_at": now,
    }

    experience_json = json.dumps(experience, indent=2)

    # Determine file path
    type_dir = {"error": "errors", "pattern": "patterns", "tip": "tips"}[params.type.value]
    file_path = f"experiences/{type_dir}/{params.language.value}/{experience_id}.json"

    # If we have a GitHub token, create the PR automatically
    if GITHUB_TOKEN:
        try:
            pr_url = await _create_github_pr(
                experience_id=experience_id,
                file_path=file_path,
                content=experience_json,
                title=params.title,
                agent_name=params.contributing_agent,
            )
            return (
                f"✅ Experience submitted successfully!\n\n"
                f"**PR:** {pr_url}\n"
                f"**Experience ID:** `{experience_id}`\n"
                f"**File:** `{file_path}`\n\n"
                f"A human maintainer will review and merge your PR. "
                f"Thank you for contributing to the collective knowledge!"
            )
        except Exception as e:
            return (
                f"⚠️ Could not create PR automatically: {str(e)}\n\n"
                f"**Manual submission:** Create a PR with this file:\n\n"
                f"**Path:** `{file_path}`\n"
                f"```json\n{experience_json}\n```"
            )
    else:
        return (
            f"📝 Experience generated! To submit, create a PR on `{REPO}`:\n\n"
            f"**Branch:** `bot/{params.contributing_agent}/{experience_id}`\n"
            f"**File:** `{file_path}`\n"
            f"**PR Title:** `[bot] {params.type.value}: {params.title}`\n\n"
            f"```json\n{experience_json}\n```\n\n"
            f"*Set YANTRABODHA_GITHUB_TOKEN to enable automatic PR creation.*"
        )


async def _create_github_pr(
    experience_id: str,
    file_path: str,
    content: str,
    title: str,
    agent_name: str,
) -> str:
    """Create a GitHub PR with the experience file."""
    branch_name = f"bot/{agent_name}/{experience_id}"

    async with httpx.AsyncClient(timeout=30.0) as client:
        headers = _github_headers()

        # Get default branch SHA
        repo_resp = await client.get(f"{GITHUB_API}/repos/{REPO}", headers=headers)
        repo_resp.raise_for_status()
        default_branch = repo_resp.json()["default_branch"]

        ref_resp = await client.get(
            f"{GITHUB_API}/repos/{REPO}/git/ref/heads/{default_branch}",
            headers=headers,
        )
        ref_resp.raise_for_status()
        base_sha = ref_resp.json()["object"]["sha"]

        # Create branch
        await client.post(
            f"{GITHUB_API}/repos/{REPO}/git/refs",
            headers=headers,
            json={"ref": f"refs/heads/{branch_name}", "sha": base_sha},
        )

        # Create file
        import base64
        await client.put(
            f"{GITHUB_API}/repos/{REPO}/contents/{file_path}",
            headers=headers,
            json={
                "message": f"[bot] Add experience: {title}",
                "content": base64.b64encode(content.encode()).decode(),
                "branch": branch_name,
            },
        )

        # Create PR
        pr_resp = await client.post(
            f"{GITHUB_API}/repos/{REPO}/pulls",
            headers=headers,
            json={
                "title": f"[bot] {title}",
                "head": branch_name,
                "base": default_branch,
                "body": (
                    f"## 🤖 Bot Experience Submission\n\n"
                    f"**Agent:** {agent_name}\n"
                    f"**Experience ID:** `{experience_id}`\n"
                    f"**Type:** {file_path.split('/')[1]}\n\n"
                    f"This experience was automatically submitted by an AI agent "
                    f"via the Yantrabodha MCP server.\n\n"
                    f"Please review the content for accuracy and sanitization before merging."
                ),
            },
        )
        pr_resp.raise_for_status()
        return pr_resp.json()["html_url"]


# =============================================================================
# Entry Point
# =============================================================================

if __name__ == "__main__":
    import sys

    # The FastMCP runner from the `mcp` package currently supports stdio transport.
    # HTTP transport with explicit host/port is not available in this version.
    if "--transport" in sys.argv and "http" in sys.argv:
        print(
            "HTTP transport is not supported in this MCP server version; "
            "starting with stdio transport instead.",
            file=sys.stderr,
        )

    mcp.run()
