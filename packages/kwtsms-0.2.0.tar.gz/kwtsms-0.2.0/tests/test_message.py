"""Tests for clean_message()."""
from kwtsms import clean_message


def test_strips_emoji():
    result = clean_message("Hello 🎉")
    assert "🎉" not in result
    assert "Hello" in result


def test_converts_arabic_indic_digits_to_latin():
    # ١٢٣ = 123 in Arabic-Indic digits
    assert clean_message("Order ١٢٣") == "Order 123"


def test_strips_zero_width_space():
    assert clean_message("Hello\u200BWorld") == "HelloWorld"


def test_strips_html_tags():
    assert clean_message("Hello<b>World</b>") == "HelloWorld"


def test_preserves_arabic_text():
    # Arabic letters must NOT be stripped
    assert clean_message("مرحبا") == "مرحبا"


def test_preserves_newlines():
    assert clean_message("Line1\nLine2") == "Line1\nLine2"


def test_strips_bom():
    assert clean_message("\uFEFFHello") == "Hello"


def test_strips_soft_hyphen():
    assert clean_message("soft\u00ADhyphen") == "softhyphen"
