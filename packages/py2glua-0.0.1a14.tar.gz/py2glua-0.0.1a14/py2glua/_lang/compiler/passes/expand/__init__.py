from .anonymous import CollectAnonymousFunctionsPass, RewriteAnonymousFunctionsPass
from .context_manager import CollectContextManagersPass, RewriteWithContextManagerPass
from .expand_context import ExpandContext
from .inline import CollectInlineFunctionsPass, RewriteInlineCallsPass
from .normalize_args import CollectLocalSignaturesPass, NormalizeCallArgumentsPass
from .rewrite_class_ctor_calls import (
    CollectClassRuntimePass,
    RewriteClassCtorCallsPass,
    RewriteClassMethodDecoratorsPass,
    RewriteInstanceMethodCallsPass,
)
