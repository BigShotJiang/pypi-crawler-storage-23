"""Tiferet Interfaces Settings"""

# *** imports

# ** infra
from abc import ABC

# *** interfaces

# ** interface: service
class Service(ABC):
    '''
    The service interface as an abstract base class.
    '''

    pass
