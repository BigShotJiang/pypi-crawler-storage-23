"""Tiferet Interfaces Exports"""

# *** exports

# ** app
from .settings import Service
