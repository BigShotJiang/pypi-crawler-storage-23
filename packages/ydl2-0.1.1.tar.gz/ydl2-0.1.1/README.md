# ydl

`ydl2` 是一个对 `cv2` 的轻量二次封装工具包，用于日常计算机视觉工程中**反复出现但 cv2 没直接提供的功能**。

## 安装

```bash
pip install ydl2