import asyncio

from beni import btask

from .tasks import *


def run():
    btask.options.lock = 0  # 允许多开
    coro = btask.main
    if not asyncio.iscoroutine(coro):
        coro = btask.main()
    asyncio.run(coro)
