# Credit: Dai Chao Online
import subprocess
import logging

class HardwareManager:
    @staticmethod
    def get_hardware():
        try:
            cmd = 'powershell "Get-CimInstance -Class Win32_ComputerSystemProduct | Select-Object -ExpandProperty UUID"'
            result = subprocess.check_output(cmd, shell=True)
            uuid = result.decode().strip()
            if uuid and "FFFF" not in uuid:
                return uuid
        except Exception as e:
            logging.error(f"[PowerShell] Failed: {e}")

        try:
            result = subprocess.check_output("wmic csproduct get uuid", shell=True)
            lines = result.decode().splitlines()
            if len(lines) >= 2:
                uuid = lines[1].strip()
                if uuid and uuid != "FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF":
                    return uuid
        except Exception as e:
            logging.error(f"[WMIC] Failed: {e}")

        raise RuntimeError("Cannot retrieve hardware ID; license system cannot start.")   