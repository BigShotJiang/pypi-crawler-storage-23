 # TrainKeeper Project
 
 Minimal project scaffold with reproducible runs.
 
 ## Run
 ```bash
 python train.py
 ```
