"""MCP adapters for MnemoCore."""
