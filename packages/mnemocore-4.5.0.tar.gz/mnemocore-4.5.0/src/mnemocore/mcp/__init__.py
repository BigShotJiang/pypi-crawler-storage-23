"""MnemoCore MCP package."""
