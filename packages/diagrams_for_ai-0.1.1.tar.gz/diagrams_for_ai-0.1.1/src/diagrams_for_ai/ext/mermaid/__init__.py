"""Mermaid flowchart import extension for diagrams_for_ai."""

from diagrams_for_ai.ext.mermaid.parser import parse_mermaid

__all__ = ["parse_mermaid"]
